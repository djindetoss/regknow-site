# Deep Contextualized Word Representations

- **Authors:** Matthew E. Peters, Mark Neumann, Mohit Iyyer, Matt Gardner, Christopher Clark, Kenton Lee, Luke Zettlemoyer
- **Issuer:** Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies (NAACL-HLT)
- **Type:** Scientific article
- **Published:** 2018-01-01
- **Language:** en
- **DOI:** 10.18653/v1/n18-1202
- **Source:** https://doi.org/10.18653/v1/n18-1202
- **Licence:** CC-BY

## Page 1

Proceedings of NAACL-HLT 2018, pages 2227–2237
New Orleans, Louisiana, June 1 - 6, 2018. c⃝2018 Association for Computational Linguistics
Deep contextualized word representations
Matthew E. Peters†, Mark Neumann†, Mohit Iyyer†, Matt Gardner†,
{matthewp,markn,mohiti,mattg}@allenai.org
Christopher Clark⇤, Kenton Lee⇤, Luke Zettlemoyer†⇤
{csquared,kentonl,lsz}@cs.washington.edu
†Allen Institute for Artiﬁcial Intelligence
⇤Paul G. Allen School of Computer Science & Engineering, University of Washington
Abstract
We introduce a new type of deep contextual-
ized word representation that models both (1)
complex characteristics of word use (e.g., syn-
tax and semantics), and (2) how these uses
vary across linguistic contexts (i.e., to model
polysemy). Our word vectors are learned func-
tions of the internal states of a deep bidirec-
tional language model (biLM), which is pre-
trained on a large text corpus. We show that
these representations can be easily added to
existing models and signiﬁcantly improve the
state of the art across six challenging NLP
problems, including question answering, tex-
tual entailment and sentiment analysis.
We
also present an analysis showing that exposing
the deep internals of the pre-trained network is
crucial, allowing downstream models to mix
different types of semi-supervision signals.
1
Introduction
Pre-trained word representations (Mikolov et al.,
2013; Pennington et al., 2014) are a key compo-
nent in many neural language understanding mod-
els.
However, learning high quality representa-
tions can be challenging.
They should ideally
model both (1) complex characteristics of word
use (e.g., syntax and semantics), and (2) how these
uses vary across linguistic contexts (i.e., to model
polysemy). In this paper, we introduce a new type
of deep contextualized word representation that
directly addresses both challenges, can be easily
integrated into existing models, and signiﬁcantly
improves the state of the art in every considered
case across a range of challenging language un-
derstanding problems.
Our representations differ from traditional word
type embeddings in that each token is assigned a
representation that is a function of the entire input
sentence. We use vectors derived from a bidirec-
tional LSTM that is trained with a coupled lan-
guage model (LM) objective on a large text cor-
pus. For this reason, we call them ELMo (Em-
beddings from Language Models) representations.
Unlike previous approaches for learning contextu-
alized word vectors (Peters et al., 2017; McCann
et al., 2017), ELMo representations are deep, in
the sense that they are a function of all of the in-
ternal layers of the biLM. More speciﬁcally, we
learn a linear combination of the vectors stacked
above each input word for each end task, which
markedly improves performance over just using
the top LSTM layer.
Combining the internal states in this manner al-
lows for very rich word representations. Using in-
trinsic evaluations, we show that the higher-level
LSTM states capture context-dependent aspects
of word meaning (e.g., they can be used with-
out modiﬁcation to perform well on supervised
word sense disambiguation tasks) while lower-
level states model aspects of syntax (e.g., they can
be used to do part-of-speech tagging). Simultane-
ously exposing all of these signals is highly bene-
ﬁcial, allowing the learned models select the types
of semi-supervision that are most useful for each
end task.
Extensive experiments demonstrate that ELMo
representations work extremely well in practice.
We ﬁrst show that they can be easily added to
existing models for six diverse and challenging
language understanding problems, including tex-
tual entailment, question answering and sentiment
analysis. The addition of ELMo representations
alone signiﬁcantly improves the state of the art
in every case, including up to 20% relative error
reductions. For tasks where direct comparisons
are possible, ELMo outperforms CoVe (McCann
et al., 2017), which computes contextualized rep-
resentations using a neural machine translation en-
coder.
Finally, an analysis of both ELMo and
CoVe reveals that deep representations outperform
2227

## Page 2

those derived from just the top layer of an LSTM.
Our trained models and code are publicly avail-
able, and we expect that ELMo will provide simi-
lar gains for many other NLP problems.1
2
Related work
Due to their ability to capture syntactic and se-
mantic information of words from large scale un-
labeled text, pretrained word vectors (Turian et al.,
2010; Mikolov et al., 2013; Pennington et al.,
2014) are a standard component of most state-of-
the-art NLP architectures, including for question
answering (Liu et al., 2017), textual entailment
(Chen et al., 2017) and semantic role labeling
(He et al., 2017). However, these approaches for
learning word vectors only allow a single context-
independent representation for each word.
Previously proposed methods overcome some
of the shortcomings of traditional word vectors
by either enriching them with subword informa-
tion (e.g., Wieting et al., 2016; Bojanowski et al.,
2017) or learning separate vectors for each word
sense (e.g.,
Neelakantan et al., 2014). Our ap-
proach also beneﬁts from subword units through
the use of character convolutions, and we seam-
lessly incorporate multi-sense information into
downstream tasks without explicitly training to
predict predeﬁned sense classes.
Other
recent
work
has
also
focused
on
learning
context-dependent
representations.
context2vec (Melamud et al., 2016) uses a
bidirectional Long Short Term Memory (LSTM;
Hochreiter and Schmidhuber, 1997) to encode the
context around a pivot word. Other approaches
for learning contextual embeddings include the
pivot word itself in the representation and are
computed with the encoder of either a supervised
neural machine translation (MT) system (CoVe;
McCann et al., 2017) or an unsupervised lan-
guage model (Peters et al., 2017). Both of these
approaches beneﬁt from large datasets, although
the MT approach is limited by the size of parallel
corpora. In this paper, we take full advantage of
access to plentiful monolingual data, and train
our biLM on a corpus with approximately 30
million sentences (Chelba et al., 2014). We also
generalize these approaches to deep contextual
representations, which we show work well across
a broad range of diverse NLP tasks.
1http://allennlp.org/elmo
Previous work has also shown that different lay-
ers of deep biRNNs encode different types of in-
formation.
For example, introducing multi-task
syntactic supervision (e.g., part-of-speech tags) at
the lower levels of a deep LSTM can improve
overall performance of higher level tasks such as
dependency parsing (Hashimoto et al., 2017) or
CCG super tagging (Søgaard and Goldberg, 2016).
In an RNN-based encoder-decoder machine trans-
lation system, Belinkov et al. (2017) showed that
the representations learned at the ﬁrst layer in a 2-
layer LSTM encoder are better at predicting POS
tags then second layer. Finally, the top layer of an
LSTM for encoding word context (Melamud et al.,
2016) has been shown to learn representations of
word sense. We show that similar signals are also
induced by the modiﬁed language model objective
of our ELMo representations, and it can be very
beneﬁcial to learn models for downstream tasks
that mix these different types of semi-supervision.
Dai and Le (2015) and Ramachandran et al.
(2017) pretrain encoder-decoder pairs using lan-
guage models and sequence autoencoders and then
ﬁne tune with task speciﬁc supervision. In con-
trast, after pretraining the biLM with unlabeled
data, we ﬁx the weights and add additional task-
speciﬁc model capacity, allowing us to leverage
large, rich and universal biLM representations for
cases where downstream training data size dictates
a smaller supervised model.
3
ELMo: Embeddings from Language
Models
Unlike most widely used word embeddings (Pen-
nington et al., 2014), ELMo word representations
are functions of the entire input sentence, as de-
scribed in this section. They are computed on top
of two-layer biLMs with character convolutions
(Sec. 3.1), as a linear function of the internal net-
work states (Sec. 3.2). This setup allows us to do
semi-supervised learning, where the biLM is pre-
trained at a large scale (Sec. 3.4) and easily incor-
porated into a wide range of existing neural NLP
architectures (Sec. 3.3).
3.1
Bidirectional language models
Given a sequence of N tokens, (t1, t2, ..., tN), a
forward language model computes the probability
of the sequence by modeling the probability of to-
2228

## Page 3

ken tk given the history (t1, ..., tk−1):
p(t1, t2, . . . , tN) =
N
Y
k=1
p(tk | t1, t2, . . . , tk−1).
Recent state-of-the-art neural language models
(J´ozefowicz et al., 2016; Melis et al., 2017; Mer-
ity et al., 2017) compute a context-independent to-
ken representation xLM
k
(via token embeddings or
a CNN over characters) then pass it through L lay-
ers of forward LSTMs. At each position k, each
LSTM layer outputs a context-dependent repre-
sentation −!
h LM
k,j where j = 1, . . . , L. The top layer
LSTM output, −!
h LM
k,L , is used to predict the next
token tk+1 with a Softmax layer.
A backward LM is similar to a forward LM, ex-
cept it runs over the sequence in reverse, predict-
ing the previous token given the future context:
p(t1, t2, . . . , tN) =
N
Y
k=1
p(tk | tk+1, tk+2, . . . , tN).
It can be implemented in an analogous way to a
forward LM, with each backward LSTM layer j
in a L layer deep model producing representations
 −
h LM
k,j of tk given (tk+1, . . . , tN).
A biLM combines both a forward and backward
LM. Our formulation jointly maximizes the log
likelihood of the forward and backward directions:
N
X
k=1
( log p(tk | t1, . . . , tk−1; ⇥x, −!
⇥LSTM, ⇥s)
+ log p(tk | tk+1, . . . , tN; ⇥x, −
⇥LSTM, ⇥s) ) .
We tie the parameters for both the token represen-
tation (⇥x) and Softmax layer (⇥s) in the forward
and backward direction while maintaining sepa-
rate parameters for the LSTMs in each direction.
Overall, this formulation is similar to the approach
of Peters et al. (2017), with the exception that we
share some weights between directions instead of
using completely independent parameters. In the
next section, we depart from previous work by in-
troducing a new approach for learning word rep-
resentations that are a linear combination of the
biLM layers.
3.2
ELMo
ELMo is a task speciﬁc combination of the in-
termediate layer representations in the biLM. For
each token tk, a L-layer biLM computes a set of
2L + 1 representations
Rk
=
{xLM
k
, −!
h LM
k,j , −
h LM
k,j | j = 1, . . . , L}
=
{hLM
k,j | j = 0, . . . , L},
where hLM
k,0
is the token layer and hLM
k,j
=
[−!
h LM
k,j ; −
h LM
k,j ], for each biLSTM layer.
For inclusion in a downstream model, ELMo
collapses all layers in R into a single vector,
ELMok = E(Rk; ⇥e).
In the simplest case,
ELMo just selects the top layer, E(Rk) = hLM
k,L ,
as in TagLM (Peters et al., 2017) and CoVe (Mc-
Cann et al., 2017). More generally, we compute a
task speciﬁc weighting of all biLM layers:
ELMotask
k
= E(Rk; ⇥task) = γtask
L
X
j=0
stask
j
hLM
k,j .
(1)
In (1), stask are softmax-normalized weights and
the scalar parameter γtask allows the task model to
scale the entire ELMo vector. γ is of practical im-
portance to aid the optimization process (see sup-
plemental material for details). Considering that
the activations of each biLM layer have a different
distribution, in some cases it also helped to apply
layer normalization (Ba et al., 2016) to each biLM
layer before weighting.
3.3
Using biLMs for supervised NLP tasks
Given a pre-trained biLM and a supervised archi-
tecture for a target NLP task, it is a simple process
to use the biLM to improve the task model. We
simply run the biLM and record all of the layer
representations for each word. Then, we let the
end task model learn a linear combination of these
representations, as described below.
First consider the lowest layers of the super-
vised model without the biLM. Most supervised
NLP models share a common architecture at the
lowest layers, allowing us to add ELMo in a
consistent, uniﬁed manner.
Given a sequence
of tokens (t1, . . . , tN), it is standard to form a
context-independent token representation xk for
each token position using pre-trained word em-
beddings and optionally character-based represen-
tations. Then, the model forms a context-sensitive
representation hk, typically using either bidirec-
tional RNNs, CNNs, or feed forward networks.
To add ELMo to the supervised model, we
ﬁrst freeze the weights of the biLM and then
2229

## Page 4

concatenate the ELMo vector ELMotask
k
with
xk and pass the ELMo enhanced representation
[xk; ELMotask
k
] into the task RNN. For some
tasks (e.g., SNLI, SQuAD), we observe further
improvements by also including ELMo at the out-
put of the task RNN by introducing another set
of output speciﬁc linear weights and replacing hk
with [hk; ELMotask
k
]. As the remainder of the
supervised model remains unchanged, these addi-
tions can happen within the context of more com-
plex neural models. For example, see the SNLI
experiments in Sec. 4 where a bi-attention layer
follows the biLSTMs, or the coreference resolu-
tion experiments where a clustering model is lay-
ered on top of the biLSTMs.
Finally, we found it beneﬁcial to add a moder-
ate amount of dropout to ELMo (Srivastava et al.,
2014) and in some cases to regularize the ELMo
weights by adding λkwk2
2 to the loss. This im-
poses an inductive bias on the ELMo weights to
stay close to an average of all biLM layers.
3.4
Pre-trained bidirectional language model
architecture
The pre-trained biLMs in this paper are similar to
the architectures in J´ozefowicz et al. (2016) and
Kim et al. (2015), but modiﬁed to support joint
training of both directions and add a residual con-
nection between LSTM layers. We focus on large
scale biLMs in this work, as Peters et al. (2017)
highlighted the importance of using biLMs over
forward-only LMs and large scale training.
To balance overall language model perplexity
with model size and computational requirements
for downstream tasks while maintaining a purely
character-based input representation, we halved all
embedding and hidden dimensions from the single
best model CNN-BIG-LSTM in J´ozefowicz et al.
(2016). The ﬁnal model uses L = 2 biLSTM lay-
ers with 4096 units and 512 dimension projections
and a residual connection from the ﬁrst to second
layer. The context insensitive type representation
uses 2048 character n-gram convolutional ﬁlters
followed by two highway layers (Srivastava et al.,
2015) and a linear projection down to a 512 repre-
sentation. As a result, the biLM provides three lay-
ers of representations for each input token, includ-
ing those outside the training set due to the purely
character input. In contrast, traditional word em-
bedding methods only provide one layer of repre-
sentation for tokens in a ﬁxed vocabulary.
After training for 10 epochs on the 1B Word
Benchmark (Chelba et al., 2014), the average for-
ward and backward perplexities is 39.7, compared
to 30.0 for the forward CNN-BIG-LSTM. Gener-
ally, we found the forward and backward perplex-
ities to be approximately equal, with the backward
value slightly lower.
Once pretrained, the biLM can compute repre-
sentations for any task. In some cases, ﬁne tuning
the biLM on domain speciﬁc data leads to signiﬁ-
cant drops in perplexity and an increase in down-
stream task performance. This can be seen as a
type of domain transfer for the biLM. As a result,
in most cases we used a ﬁne-tuned biLM in the
downstream task. See supplemental material for
details.
4
Evaluation
Table 1 shows the performance of ELMo across a
diverse set of six benchmark NLP tasks. In every
task considered, simply adding ELMo establishes
a new state-of-the-art result, with relative error re-
ductions ranging from 6 - 20% over strong base
models. This is a very general result across a di-
verse set model architectures and language under-
standing tasks. In the remainder of this section we
provide high-level sketches of the individual task
results; see the supplemental material for full ex-
perimental details.
Question answering The Stanford Question
Answering Dataset (SQuAD) (Rajpurkar et al.,
2016) contains 100K+ crowd sourced question-
answer pairs where the answer is a span in a given
Wikipedia paragraph. Our baseline model (Clark
and Gardner, 2017) is an improved version of the
Bidirectional Attention Flow model in Seo et al.
(BiDAF; 2017). It adds a self-attention layer af-
ter the bidirectional attention component, simpli-
ﬁes some of the pooling operations and substitutes
the LSTMs for gated recurrent units (GRUs; Cho
et al., 2014). After adding ELMo to the baseline
model, test set F1 improved by 4.7% from 81.1%
to 85.8%, a 24.9% relative error reduction over the
baseline, and improving the overall single model
state-of-the-art by 1.4%. A 11 member ensem-
ble pushes F1 to 87.4, the overall state-of-the-art
at time of submission to the leaderboard.2
The
increase of 4.7% with ELMo is also signiﬁcantly
larger then the 1.8% improvement from adding
CoVe to a baseline model (McCann et al., 2017).
2As of November 17, 2017.
2230

## Page 5

TASK
PREVIOUS SOTA
OUR
BASELINE
ELMO +
BASELINE
INCREASE
(ABSOLUTE/
RELATIVE)
SQuAD
Liu et al. (2017)
84.4
81.1
85.8
4.7 / 24.9%
SNLI
Chen et al. (2017)
88.6
88.0
88.7 ± 0.17
0.7 / 5.8%
SRL
He et al. (2017)
81.7
81.4
84.6
3.2 / 17.2%
Coref
Lee et al. (2017)
67.2
67.2
70.4
3.2 / 9.8%
NER
Peters et al. (2017)
91.93 ± 0.19
90.15
92.22 ± 0.10
2.06 / 21%
SST-5
McCann et al. (2017)
53.7
51.4
54.7 ± 0.5
3.3 / 6.8%
Table 1: Test set comparison of ELMo enhanced neural models with state-of-the-art single model baselines across
six benchmark NLP tasks. The performance metric varies across tasks – accuracy for SNLI and SST-5; F1 for
SQuAD, SRL and NER; average F1 for Coref. Due to the small test sizes for NER and SST-5, we report the mean
and standard deviation across ﬁve runs with different random seeds. The “increase” column lists both the absolute
and relative improvements over our baseline.
Textual entailment Textual entailment is the
task of determining whether a “hypothesis” is
true, given a “premise”.
The Stanford Natu-
ral Language Inference (SNLI) corpus (Bowman
et al., 2015) provides approximately 550K hypoth-
esis/premise pairs.
Our baseline, the ESIM se-
quence model from Chen et al. (2017), uses a biL-
STM to encode the premise and hypothesis, fol-
lowed by a matrix attention layer, a local infer-
ence layer, another biLSTM inference composi-
tion layer, and ﬁnally a pooling operation before
the output layer.
Overall, adding ELMo to the
ESIM model improves accuracy by an average of
0.7% across ﬁve random seeds. A ﬁve member
ensemble pushes the overall accuracy to 89.3%,
exceeding the previous ensemble best of 88.9%
(Gong et al., 2018).
Semantic role labeling A semantic role label-
ing (SRL) system models the predicate-argument
structure of a sentence, and is often described as
answering “Who did what to whom”. He et al.
(2017) modeled SRL as a BIO tagging problem
and used an 8-layer deep biLSTM with forward
and backward directions interleaved, following
Zhou and Xu (2015). As shown in Table 1, when
adding ELMo to a re-implementation of He et al.
(2017) the single model test set F1 jumped 3.2%
from 81.4% to 84.6% – a new state-of-the-art on
the OntoNotes benchmark (Pradhan et al., 2013),
even improving over the previous best ensemble
result by 1.2%.
Coreference resolution Coreference resolution
is the task of clustering mentions in text that re-
fer to the same underlying real world entities. Our
baseline model is the end-to-end span-based neu-
ral model of Lee et al. (2017). It uses a biLSTM
and attention mechanism to ﬁrst compute span
representations and then applies a softmax men-
tion ranking model to ﬁnd coreference chains. In
our experiments with the OntoNotes coreference
annotations from the CoNLL 2012 shared task
(Pradhan et al., 2012), adding ELMo improved the
average F1 by 3.2% from 67.2 to 70.4, establish-
ing a new state of the art, again improving over the
previous best ensemble result by 1.6% F1.
Named entity extraction The CoNLL 2003
NER task (Sang and Meulder, 2003) consists of
newswire from the Reuters RCV1 corpus tagged
with four different entity types (PER, LOC, ORG,
MISC). Following recent state-of-the-art systems
(Lample et al., 2016; Peters et al., 2017), the base-
line model uses pre-trained word embeddings, a
character-based CNN representation, two biLSTM
layers and a conditional random ﬁeld (CRF) loss
(Lafferty et al., 2001), similar to Collobert et al.
(2011). As shown in Table 1, our ELMo enhanced
biLSTM-CRF achieves 92.22% F1 averaged over
ﬁve runs. The key difference between our system
and the previous state of the art from Peters et al.
(2017) is that we allowed the task model to learn a
weighted average of all biLM layers, whereas Pe-
ters et al. (2017) only use the top biLM layer. As
shown in Sec. 5.1, using all layers instead of just
the last layer improves performance across multi-
ple tasks.
Sentiment analysis The ﬁne-grained sentiment
classiﬁcation task in the Stanford Sentiment Tree-
bank (SST-5; Socher et al., 2013) involves select-
ing one of ﬁve labels (from very negative to very
positive) to describe a sentence from a movie re-
view.
The sentences contain diverse linguistic
phenomena such as idioms and complex syntac-
2231

## Page 6

Task
Baseline
Last Only
All layers
λ=1
λ=0.001
SQuAD
80.8
84.7
85.0
85.2
SNLI
88.1
89.1
89.3
89.5
SRL
81.6
84.1
84.6
84.8
Table 2: Development set performance for SQuAD,
SNLI and SRL comparing using all layers of the biLM
(with different choices of regularization strength λ) to
just the top layer.
Task
Input
Only
Input &
Output
Output
Only
SQuAD
85.1
85.6
84.8
SNLI
88.9
89.5
88.7
SRL
84.7
84.3
80.9
Table 3: Development set performance for SQuAD,
SNLI and SRL when including ELMo at different lo-
cations in the supervised model.
tic constructions such as negations that are difﬁ-
cult for models to learn. Our baseline model is
the biattentive classiﬁcation network (BCN) from
McCann et al. (2017), which also held the prior
state-of-the-art result when augmented with CoVe
embeddings. Replacing CoVe with ELMo in the
BCN model results in a 1.0% absolute accuracy
improvement over the state of the art.
5
Analysis
This section provides an ablation analysis to vali-
date our chief claims and to elucidate some inter-
esting aspects of ELMo representations. Sec. 5.1
shows that using deep contextual representations
in downstream tasks improves performance over
previous work that uses just the top layer, regard-
less of whether they are produced from a biLM or
MT encoder, and that ELMo representations pro-
vide the best overall performance. Sec. 5.3 ex-
plores the different types of contextual informa-
tion captured in biLMs and uses two intrinsic eval-
uations to show that syntactic information is better
represented at lower layers while semantic infor-
mation is captured a higher layers, consistent with
MT encoders. It also shows that our biLM consis-
tently provides richer representations then CoVe.
Additionally, we analyze the sensitivity to where
ELMo is included in the task model (Sec. 5.2),
training set size (Sec. 5.4), and visualize the ELMo
learned weights across the tasks (Sec. 5.5).
5.1
Alternate layer weighting schemes
There are many alternatives to Equation 1 for com-
bining the biLM layers. Previous work on con-
textual representations used only the last layer,
whether it be from a biLM (Peters et al., 2017) or
an MT encoder (CoVe; McCann et al., 2017). The
choice of the regularization parameter λ is also
important, as large values such as λ = 1 effec-
tively reduce the weighting function to a simple
average over the layers, while smaller values (e.g.,
λ = 0.001) allow the layer weights to vary.
Table 2 compares these alternatives for SQuAD,
SNLI and SRL. Including representations from all
layers improves overall performance over just us-
ing the last layer, and including contextual rep-
resentations from the last layer improves perfor-
mance over the baseline.
For example, in the
case of SQuAD, using just the last biLM layer im-
proves development F1 by 3.9% over the baseline.
Averaging all biLM layers instead of using just the
last layer improves F1 another 0.3% (comparing
“Last Only” to λ=1 columns), and allowing the
task model to learn individual layer weights im-
proves F1 another 0.2% (λ=1 vs. λ=0.001). A
small λ is preferred in most cases with ELMo, al-
though for NER, a task with a smaller training set,
the results are insensitive to λ (not shown).
The overall trend is similar with CoVe but with
smaller increases over the baseline. For SNLI, av-
eraging all layers with λ=1 improves development
accuracy from 88.2 to 88.7% over using just the
last layer. SRL F1 increased a marginal 0.1% to
82.2 for the λ=1 case compared to using the last
layer only.
5.2
Where to include ELMo?
All of the task architectures in this paper include
word embeddings only as input to the lowest layer
biRNN. However, we ﬁnd that including ELMo at
the output of the biRNN in task-speciﬁc architec-
tures improves overall results for some tasks. As
shown in Table 3, including ELMo at both the in-
put and output layers for SNLI and SQuAD im-
proves over just the input layer, but for SRL (and
coreference resolution, not shown) performance is
highest when it is included at just the input layer.
One possible explanation for this result is that both
the SNLI and SQuAD architectures use attention
layers after the biRNN, so introducing ELMo at
this layer allows the model to attend directly to the
biLM’s internal representations. In the SRL case,
2232

## Page 7

Source
Nearest Neighbors
GloVe
play
playing, game, games, played, players, plays, player,
Play, football, multiplayer
biLM
Chico Ruiz made a spec-
tacular play on Alusik ’s
grounder {.. . }
Kieffer , the only junior in the group , was commended
for his ability to hit in the clutch , as well as his all-round
excellent play .
Olivia
De
Havilland
signed to do a Broadway
play for Garson {. .. }
{. ..} they were actors who had been handed fat roles in
a successful play , and had talent enough to ﬁll the roles
competently , with nice understatement .
Table 4: Nearest neighbors to “play” using GloVe and the context embeddings from a biLM.
Model
F1
WordNet 1st Sense Baseline
65.9
Raganato et al. (2017a)
69.9
Iacobacci et al. (2016)
70.1
CoVe, First Layer
59.4
CoVe, Second Layer
64.7
biLM, First layer
67.4
biLM, Second layer
69.0
Table 5: All-words ﬁne grained WSD F1. For CoVe
and the biLM, we report scores for both the ﬁrst and
second layer biLSTMs.
the task-speciﬁc context representations are likely
more important than those from the biLM.
5.3
What information is captured by the
biLM’s representations?
Since adding ELMo improves task performance
over word vectors alone, the biLM’s contextual
representations must encode information gener-
ally useful for NLP tasks that is not captured
in word vectors.
Intuitively, the biLM must
be disambiguating the meaning of words using
their context.
Consider “play”, a highly poly-
semous word.
The top of Table 4 lists near-
est neighbors to “play” using GloVe vectors.
They are spread across several parts of speech
(e.g., “played”, “playing” as verbs, and “player”,
“game” as nouns) but concentrated in the sports-
related senses of “play”. In contrast, the bottom
two rows show nearest neighbor sentences from
the SemCor dataset (see below) using the biLM’s
context representation of “play” in the source sen-
tence. In these cases, the biLM is able to disam-
biguate both the part of speech and word sense in
the source sentence.
These observations can be quantiﬁed using an
Model
Acc.
Collobert et al. (2011)
97.3
Ma and Hovy (2016)
97.6
Ling et al. (2015)
97.8
CoVe, First Layer
93.3
CoVe, Second Layer
92.8
biLM, First Layer
97.3
biLM, Second Layer
96.8
Table 6: Test set POS tagging accuracies for PTB. For
CoVe and the biLM, we report scores for both the ﬁrst
and second layer biLSTMs.
intrinsic evaluation of the contextual representa-
tions similar to Belinkov et al. (2017). To isolate
the information encoded by the biLM, the repre-
sentations are used to directly make predictions for
a ﬁne grained word sense disambiguation (WSD)
task and a POS tagging task. Using this approach,
it is also possible to compare to CoVe, and across
each of the individual layers.
Word sense disambiguation Given a sentence,
we can use the biLM representations to predict
the sense of a target word using a simple 1-
nearest neighbor approach, similar to Melamud
et al. (2016).
To do so, we ﬁrst use the biLM
to compute representations for all words in Sem-
Cor 3.0, our training corpus (Miller et al., 1994),
and then take the average representation for each
sense. At test time, we again use the biLM to com-
pute representations for a given target word and
take the nearest neighbor sense from the training
set, falling back to the ﬁrst sense from WordNet
for lemmas not observed during training.
Table 5 compares WSD results using the eval-
uation framework from Raganato et al. (2017b)
across the same suite of four test sets in Raganato
et al. (2017a). Overall, the biLM top layer rep-
2233

## Page 8

resentations have F1 of 69.0 and are better at
WSD then the ﬁrst layer. This is competitive with
a state-of-the-art WSD-speciﬁc supervised model
using hand crafted features (Iacobacci et al., 2016)
and a task speciﬁc biLSTM that is also trained
with auxiliary coarse-grained semantic labels and
POS tags (Raganato et al., 2017a).
The CoVe
biLSTM layers follow a similar pattern to those
from the biLM (higher overall performance at the
second layer compared to the ﬁrst); however, our
biLM outperforms the CoVe biLSTM, which trails
the WordNet ﬁrst sense baseline.
POS tagging To examine whether the biLM
captures basic syntax, we used the context repre-
sentations as input to a linear classiﬁer that pre-
dicts POS tags with the Wall Street Journal portion
of the Penn Treebank (PTB) (Marcus et al., 1993).
As the linear classiﬁer adds only a small amount
of model capacity, this is direct test of the biLM’s
representations. Similar to WSD, the biLM rep-
resentations are competitive with carefully tuned,
task speciﬁc biLSTMs (Ling et al., 2015; Ma and
Hovy, 2016). However, unlike WSD, accuracies
using the ﬁrst biLM layer are higher than the
top layer, consistent with results from deep biL-
STMs in multi-task training (Søgaard and Gold-
berg, 2016; Hashimoto et al., 2017) and MT (Be-
linkov et al., 2017). CoVe POS tagging accuracies
follow the same pattern as those from the biLM,
and just like for WSD, the biLM achieves higher
accuracies than the CoVe encoder.
Implications for supervised tasks Taken to-
gether, these experiments conﬁrm different layers
in the biLM represent different types of informa-
tion and explain why including all biLM layers is
important for the highest performance in down-
stream tasks. In addition, the biLM’s representa-
tions are more transferable to WSD and POS tag-
ging than those in CoVe, helping to illustrate why
ELMo outperforms CoVe in downstream tasks.
5.4
Sample efﬁciency
Adding ELMo to a model increases the sample ef-
ﬁciency considerably, both in terms of number of
parameter updates to reach state-of-the-art perfor-
mance and the overall training set size. For ex-
ample, the SRL model reaches a maximum devel-
opment F1 after 486 epochs of training without
ELMo. After adding ELMo, the model exceeds
the baseline maximum at epoch 10, a 98% relative
decrease in the number of updates needed to reach
Figure 1: Comparison of baseline vs. ELMo perfor-
mance for SNLI and SRL as the training set size is var-
ied from 0.1% to 100%.
Figure 2: Visualization of softmax normalized biLM
layer weights across tasks and ELMo locations. Nor-
malized weights less then 1/3 are hatched with hori-
zontal lines and those greater then 2/3 are speckled.
the same level of performance.
In
addition,
ELMo-enhanced
models
use
smaller training sets more efﬁciently than mod-
els without ELMo. Figure 1 compares the per-
formance of baselines models with and without
ELMo as the percentage of the full training set is
varied from 0.1% to 100%. Improvements with
ELMo are largest for smaller training sets and
signiﬁcantly reduce the amount of training data
needed to reach a given level of performance. In
the SRL case, the ELMo model with 1% of the
training set has about the same F1 as the baseline
model with 10% of the training set.
5.5
Visualization of learned weights
Figure
2
visualizes
the
softmax-normalized
learned layer weights.
At the input layer, the
task model favors the ﬁrst biLSTM layer.
For
coreference and SQuAD, the this is strongly
favored, but the distribution is less peaked for
the other tasks.
The output layer weights are
relatively balanced, with a slight preference for
the lower layers.
2234

## Page 9

Task
GloVe
ELMo
ELMo
ELMo +
type
GloVe
SQuAD
80.8
81.4
85.3
85.6
SNLI
88.1
88.5
89.1
89.5
SRL
81.6
81.7
84.5
84.7
Table 7:
Development set ablation analysis for
SQuAD, SNLI and SRL comparing different choices
for the context-independent type representation and
contextual representation. From left to right, the table
compares systems with only GloVe vectors; only the
ELMo context-independent type representation with-
out the ELMo biLSTM layers; full ELMo representa-
tions without GloVe; both GloVe and ELMo.
5.6
Contextual vs. sub-word information
In addition to the contextual information cap-
tured in the biLM’s biLSTM layers, ELMo rep-
resentations also contain sub-word information in
the fully character based context insensitive type
layer, xLM
k
.
To analyze the relative contribu-
tion of the contextual information compared to the
sub-word information, we ran an additional ab-
lation that replaced the GloVe vectors with just
the biLM character based xLM
k
layer without the
biLM biLSTM layers. Table 7 summarizes the re-
sults for SQuAD, SNLI and SNLI. Replacing the
GloVe vectors with the biLM character layer gives
a slight improvement for all tasks (e.g. from 80.8
to 81.4 F1 for SQuAD), but overall the improve-
ments are small compared to the full ELMo model.
From this, we conclude that most of the gains in
the downstream tasks are due to the contextual in-
formation and not the sub-word information.
5.7
Are pre-trained vectors necessary with
ELMo?
All of the results presented in Sec.4 include pre-
trained word vectors in addition to ELMo repre-
sentations. However, it is natural to ask whether
pre-trained vectors are still necessary with high
quality contextualized representations. As shown
in the two right hand columns of Table 7, adding
GloVe to models with ELMo generally provides
a marginal improvement over ELMo only models
(e.g. 0.2% F1 improvement for SRL from 84.5 to
84.7).
6
Conclusion
We have introduced a general approach for learn-
ing high-quality deep context-dependent represen-
tations from biLMs, and shown large improve-
ments when applying ELMo to a broad range of
NLP tasks. Through ablations and other controlled
experiments, we have also conﬁrmed that the
biLM layers efﬁciently encode different types of
syntactic and semantic information about words-
in-context, and that using all layers improves over-
all task performance.
References
Jimmy Ba, Ryan Kiros, and Geoffrey E. Hinton. 2016.
Layer normalization. CoRR abs/1607.06450.
Yonatan Belinkov, Nadir Durrani, Fahim Dalvi, Has-
san Sajjad, and James R. Glass. 2017. What do neu-
ral machine translation models learn about morphol-
ogy? In ACL.
Piotr Bojanowski, Edouard Grave, Armand Joulin, and
Tomas Mikolov. 2017. Enriching word vectors with
subword information. TACL 5:135–146.
Samuel R. Bowman, Gabor Angeli, Christopher Potts,
and Christopher D. Manning. 2015.
A large an-
notated corpus for learning natural language infer-
ence.
In Proceedings of the 2015 Conference on
Empirical Methods in Natural Language Processing
(EMNLP). Association for Computational Linguis-
tics.
Ciprian Chelba, Tomas Mikolov, Mike Schuster, Qi Ge,
Thorsten Brants, Phillipp Koehn, and Tony Robin-
son. 2014. One billion word benchmark for mea-
suring progress in statistical language modeling. In
INTERSPEECH.
Qian Chen, Xiao-Dan Zhu, Zhen-Hua Ling, Si Wei,
Hui Jiang, and Diana Inkpen. 2017. Enhanced lstm
for natural language inference. In ACL.
Jason Chiu and Eric Nichols. 2016.
Named entity
recognition with bidirectional LSTM-CNNs.
In
TACL.
Kyunghyun Cho, Bart van Merrienboer, Dzmitry Bah-
danau, and Yoshua Bengio. 2014. On the properties
of neural machine translation: Encoder-decoder ap-
proaches. In SSST@EMNLP.
Christopher Clark and Matthew Gardner. 2017. Sim-
ple and effective multi-paragraph reading compre-
hension. CoRR abs/1710.10723.
Kevin Clark and Christopher D. Manning. 2016. Deep
reinforcement learning for mention-ranking corefer-
ence models. In EMNLP.
Ronan Collobert, Jason Weston, L´eon Bottou, Michael
Karlen, Koray Kavukcuoglu, and Pavel P. Kuksa.
2011.
Natural language processing (almost) from
scratch. In JMLR.
Andrew M. Dai and Quoc V. Le. 2015.
Semi-
supervised sequence learning. In NIPS.
2235

## Page 10

Greg Durrett and Dan Klein. 2013. Easy victories and
uphill battles in coreference resolution. In EMNLP.
Yarin Gal and Zoubin Ghahramani. 2016. A theoret-
ically grounded application of dropout in recurrent
neural networks. In NIPS.
Yichen Gong, Heng Luo, and Jian Zhang. 2018. Nat-
ural language inference over interaction space. In
ICLR.
Kazuma Hashimoto, Caiming Xiong, Yoshimasa Tsu-
ruoka, and Richard Socher. 2017. A joint many-task
model: Growing a neural network for multiple nlp
tasks. In EMNLP 2017.
Luheng He, Kenton Lee, Mike Lewis, and Luke S.
Zettlemoyer. 2017.
Deep semantic role labeling:
What works and what’s next. In ACL.
Sepp Hochreiter and J¨urgen Schmidhuber. 1997. Long
short-term memory. Neural Computation 9.
Ignacio Iacobacci, Mohammad Taher Pilehvar, and
Roberto Navigli. 2016. Embeddings for word sense
disambiguation: An evaluation study. In ACL.
Rafal J´ozefowicz, Oriol Vinyals, Mike Schuster, Noam
Shazeer, and Yonghui Wu. 2016. Exploring the lim-
its of language modeling. CoRR abs/1602.02410.
Rafal
J´ozefowicz,
Wojciech
Zaremba,
and
Ilya
Sutskever. 2015. An empirical exploration of recur-
rent network architectures. In ICML.
Yoon Kim, Yacine Jernite, David Sontag, and Alexan-
der M Rush. 2015. Character-aware neural language
models. In AAAI 2016.
Diederik P. Kingma and Jimmy Ba. 2015. Adam: A
method for stochastic optimization. In ICLR.
Ankit Kumar, Ozan Irsoy, Peter Ondruska, Mohit
Iyyer, Ishaan Gulrajani James Bradbury, Victor
Zhong, Romain Paulus, and Richard Socher. 2016.
Ask me anything: Dynamic memory networks for
natural language processing. In ICML.
John D. Lafferty, Andrew McCallum, and Fernando
Pereira. 2001.
Conditional random ﬁelds: Prob-
abilistic models for segmenting and labeling se-
quence data. In ICML.
Guillaume Lample, Miguel Ballesteros, Sandeep Sub-
ramanian, Kazuya Kawakami, and Chris Dyer. 2016.
Neural architectures for named entity recognition.
In NAACL-HLT.
Kenton Lee, Luheng He, Mike Lewis, and Luke S.
Zettlemoyer. 2017. End-to-end neural coreference
resolution. In EMNLP.
Wang Ling, Chris Dyer, Alan W. Black, Isabel Tran-
coso, Ramon Fermandez, Silvio Amir, Lu´ıs Marujo,
and Tiago Lu´ıs. 2015.
Finding function in form:
Compositional character models for open vocabu-
lary word representation. In EMNLP.
Xiaodong Liu, Yelong Shen, Kevin Duh, and Jian-
feng Gao. 2017.
Stochastic answer networks for
machine reading comprehension.
arXiv preprint
arXiv:1712.03556 .
Xuezhe Ma and Eduard H. Hovy. 2016. End-to-end
sequence labeling via bi-directional LSTM-CNNs-
CRF. In ACL.
Mitchell P. Marcus, Beatrice Santorini, and Mary Ann
Marcinkiewicz. 1993.
Building a large annotated
corpus of english: The penn treebank.
Computa-
tional Linguistics 19:313–330.
Bryan McCann, James Bradbury, Caiming Xiong, and
Richard Socher. 2017. Learned in translation: Con-
textualized word vectors. In NIPS 2017.
Oren Melamud, Jacob Goldberger, and Ido Dagan.
2016. context2vec: Learning generic context em-
bedding with bidirectional lstm. In CoNLL.
G´abor Melis, Chris Dyer, and Phil Blunsom. 2017. On
the state of the art of evaluation in neural language
models. CoRR abs/1707.05589.
Stephen Merity, Nitish Shirish Keskar, and Richard
Socher. 2017. Regularizing and optimizing lstm lan-
guage models. CoRR abs/1708.02182.
Tomas Mikolov, Ilya Sutskever, Kai Chen, Greg S Cor-
rado, and Jeff Dean. 2013. Distributed representa-
tions of words and phrases and their compositional-
ity. In NIPS.
George A. Miller, Martin Chodorow, Shari Landes,
Claudia Leacock, and Robert G. Thomas. 1994. Us-
ing a semantic concordance for sense identiﬁcation.
In HLT.
Tsendsuren Munkhdalai and Hong Yu. 2017. Neural
tree indexers for text understanding. In EACL.
Arvind Neelakantan, Jeevan Shankar, Alexandre Pas-
sos, and Andrew McCallum. 2014. Efﬁcient non-
parametric estimation of multiple embeddings per
word in vector space. In EMNLP.
Martha Palmer, Paul Kingsbury, and Daniel Gildea.
2005. The proposition bank: An annotated corpus of
semantic roles. Computational Linguistics 31:71–
106.
Jeffrey Pennington, Richard Socher, and Christo-
pher D. Manning. 2014. Glove: Global vectors for
word representation. In EMNLP.
Matthew E. Peters, Waleed Ammar, Chandra Bhaga-
vatula, and Russell Power. 2017. Semi-supervised
sequence tagging with bidirectional language mod-
els. In ACL.
Sameer Pradhan, Alessandro Moschitti, Nianwen Xue,
Hwee Tou Ng, Anders Bj¨orkelund, Olga Uryupina,
Yuchen Zhang, and Zhi Zhong. 2013. Towards ro-
bust linguistic analysis using ontonotes. In CoNLL.
2236

## Page 11

Sameer Pradhan, Alessandro Moschitti, Nianwen Xue,
Olga Uryupina, and Yuchen Zhang. 2012.
Conll-
2012 shared task:
Modeling multilingual unre-
stricted coreference in ontonotes.
In EMNLP-
CoNLL Shared Task.
Alessandro Raganato, Claudio Delli Bovi, and Roberto
Navigli. 2017a. Neural sequence learning models
for word sense disambiguation. In EMNLP.
Alessandro Raganato, Jose Camacho-Collados, and
Roberto Navigli. 2017b. Word sense disambigua-
tion: A uniﬁed evaluation framework and empirical
comparison. In EACL.
Pranav Rajpurkar, Jian Zhang, Konstantin Lopyrev, and
Percy Liang. 2016. Squad: 100, 000+ questions for
machine comprehension of text. In EMNLP.
Prajit Ramachandran, Peter Liu, and Quoc Le. 2017.
Improving sequence to sequence learning with unla-
beled data. In EMNLP.
Erik F. Tjong Kim Sang and Fien De Meulder.
2003. Introduction to the CoNLL-2003 shared task:
Language-independent named entity recognition. In
CoNLL.
Min Joon Seo, Aniruddha Kembhavi, Ali Farhadi, and
Hannaneh Hajishirzi. 2017. Bidirectional attention
ﬂow for machine comprehension. In ICLR.
Richard Socher, Alex Perelygin, Jean Y Wu, Jason
Chuang, Christopher D Manning, Andrew Y Ng,
and Christopher Potts. 2013. Recursive deep mod-
els for semantic compositionality over a sentiment
treebank. In EMNLP.
Anders Søgaard and Yoav Goldberg. 2016.
Deep
multi-task learning with low level tasks supervised
at lower layers. In ACL 2016.
Nitish
Srivastava,
Geoffrey
E.
Hinton,
Alex
Krizhevsky, Ilya Sutskever, and Ruslan Salakhutdi-
nov. 2014. Dropout: a simple way to prevent neural
networks from overﬁtting.
Journal of Machine
Learning Research 15:1929–1958.
Rupesh Kumar Srivastava, Klaus Greff, and J¨urgen
Schmidhuber. 2015. Training very deep networks.
In NIPS.
Joseph P. Turian, Lev-Arie Ratinov, and Yoshua Ben-
gio. 2010. Word representations: A simple and gen-
eral method for semi-supervised learning. In ACL.
Wenhui Wang, Nan Yang, Furu Wei, Baobao Chang,
and Ming Zhou. 2017.
Gated self-matching net-
works for reading comprehension and question an-
swering. In ACL.
John Wieting, Mohit Bansal, Kevin Gimpel, and Karen
Livescu. 2016. Charagram: Embedding words and
sentences via character n-grams. In EMNLP.
Sam Wiseman, Alexander M. Rush, and Stuart M.
Shieber. 2016. Learning global features for coref-
erence resolution. In HLT-NAACL.
Matthew D. Zeiler. 2012. Adadelta: An adaptive learn-
ing rate method. CoRR abs/1212.5701.
Jie Zhou and Wei Xu. 2015. End-to-end learning of
semantic role labeling using recurrent neural net-
works. In ACL.
Peng Zhou, Zhenyu Qi, Suncong Zheng, Jiaming Xu,
Hongyun Bao, and Bo Xu. 2016. Text classiﬁcation
improved by integrating bidirectional lstm with two-
dimensional max pooling. In COLING.
2237


---

# Development and evaluation of a deep learning model for protein-ligand binding affinity prediction

- **Authors:** Marta M Stepniewska-Dziubinska, Piotr Zielenkiewicz, Pawel Siedlecki
- **Issuer:** Bioinformatics (Oxford, England)
- **Type:** Scientific article
- **Published:** 2018-11-01
- **Language:** en
- **DOI:** 10.1093/bioinformatics/bty374
- **Source:** https://pubmed.ncbi.nlm.nih.gov/29757353/
- **Licence:** CC-BY

## Section: Abstract

AbstractMotivationStructure based ligand discovery is one of the most successful approaches for augmenting the drug discovery process. Currently, there is a notable shift towards machine learning (ML) methodologies to aid such procedures. Deep learning has recently gained considerable attention as it allows the model to ‘learn’ to extract features that are relevant for the task at hand.ResultsWe have developed a novel deep neural network estimating the binding affinity of ligand–receptor complexes. The complex is represented with a 3D grid, and the model utilizes a 3D convolution to produce a feature map of this representation, treating the atoms of both proteins and ligands in the same manner. Our network was tested on the CASF-2013 ‘scoring power’ benchmark and Astex Diverse Set and outperformed classical scoring functions.Availability and implementationThe model, together with usage instructions and examples, is available as a git repository at http://gitlab.com/cheminfIBB/pafnucy.Supplementary information Supplementary data are available at Bioinformatics online.

## Section: 1 Introduction

Structure-based virtual screening techniques are some of the most successful methods for augmenting the drug discovery process (Bajusz et al., 2017; Fradera and Babaoglu, 2017). With structure-based screening, one tries to predict binding affinity (or more often, a score related to it) between a target and a candidate molecule based on a 3D structure of their complex. This allows to rank and prioritize molecules for further processing and subsequent testing. Numerous scoring schemes have been developed to aid this process, most of them use statistical and/or expert analysis of available protein–ligand structures (Morris et al., 2009; Muegge, 2006; Verdonk et al., 2003). Currently, there is a notable shift towards scoring functions using machine learning (ML) methodologies, and this have been highlighted by several reviews (Cheng et al., 2012; Lima et al., 2016; Ma et al., 2013). These methods are naturally capable of capturing non-linear and complex relationships in the available data.

Rather than ‘manually’ creating rules using expert knowledge and statistical inference, ML models use arbitrary functions with adjustable parameters that are capable of transforming the input (in this scenario, a protein–ligand complex) to the output (a score related to protein–ligand binding affinity). Briefly, when the model is presented with examples of input data paired with the desired outcome, it ‘learns’ to return predictions that are in agreement with the values provided. Typically the process of learning is incremental; by introducing small changes to the model parameters, the prediction is moved closer to the target value. Prime examples of ML scoring functions are RF-Score (Ballester and Mitchell, 2010), which uses random forest, and NNscore (Durrant and McCammon, 2010, 2011), which uses an ensemble of shallow neural networks. These scoring functions were proven useful in virtual screening campaigns and yielded more active compounds than their classical counterparts (Kinnings et al., 2011; Wójcikowski et al., 2017).

However, one drawback of such ML approaches is that they still rely on feature engineering, i.e. they utilize expert knowledge to define rules that will become the basis of input data preprocessing. Hence, one can argue that they are just more sophisticated classical scoring functions with more complex rules.

The ML rule of thumb says that in order to establish a good predictive model, the model needs a lot of data to be able to distinguish more general trends and patterns from noise. The growing amount of both structural data and affinity measurements has allowed researchers to explore deep learning. Briefly, a deep neural network consists of multiple layers of non-linear transformations that extract and combine information from data to develop sophisticated relationships between the input and the output. One of the main advantages of deep learning is that it allows for the reduction of feature engineering: the model learns to extract features as a natural consequence of the process of fitting the model’s parameters to the available data. It is clear that choosing the representation of the input data has a profound impact on the predictive power of a model. Currently, there is a lot of effort in the field to incorporate feature extraction directly into the ML model. In such an approach, a learnable molecule representation replaces classical descriptors and fingerprints and becomes the first part of the model. Then, this representation is trained together with the predictive part of the model to extract features that are useful in solving a specific task. With such a design, it is therefore theoretically possible to find and quantify relationships and/or mechanisms that have not yet been discovered or are unknown to the experts (Nketia et al., 2017; Zhang et al., 2017).

Deep learning has been relatively widely used by the bioinformatics (Alipanahi et al., 2015; Jiménez et al., 2017; Jurtz et al., 2017; Leung et al., 2014; Park and Kellis, 2015) and computational biology community (Angermueller et al., 2016). Several promising examples of deep learning methods have also been shown for computer-aided drug design (CADD). In what follows, we first focus on ligand-based methods, which are in general more established, and then we continue with structure-based models.

The simplest deep models in ligand-based design use molecular fingerprints as feature vectors and fully-connected (dense) neural networks built on top of them. Such approaches were proven successful; they outperform other ML methods in predicting bioactivity (Lenselink et al., 2017) and other properties of small molecules, like aqueous solubility (Lusci et al., 2013) or toxicity (Xu et al., 2015).

Additionally, neural network model allows to easily create multi-task classifiers or regressors, predicting, for example, activities against multiple targets at once. It has been shown that such QSAR models perform better than single-task networks (Dahl et al., 2014; Lenselink et al., 2017; Ma et al., 2015; Ramsundar et al., 2017; Xu et al., 2017), as they benefit from more training data, but also because they are able to ‘share’ internal representations between tasks, and therefore learn to recognize more general patterns in the data.

As mentioned previously, neural networks allow for more flexibility in terms of how the data are provided to the model, so that it might learn the best representation for its purpose. One approach to achieve this is to use convolutions on the molecular graph, allowing relevant patterns in this graph to be identified (Duvenaud et al., 2015; Kearnes et al., 2016). Another way is to use a recurrent neural network on directed acyclic representations of the molecular graph (Lusci et al., 2013), or even apply natural-language processing techniques to molecules encoded with SMILES strings (Jastrzȩbski et al., 2016).

Application of deep models to de novo ligand design has also been explored. There are several examples of models which use autoencoders and/or recurrent neural networks that are able to propose new molecules with desired properties (Ertl et al., 2017; Gómez-Bombarelli et al., 2017; Olivecrona et al., 2017; Segler et al., 2017). Using autoencoders also allows to represent molecules with short, real-valued vectors (extracted from the bottleneck layer), which facilitates exploration of the chemical space (Gómez-Bombarelli et al., 2017).

Although deep learning is more readily used in ligand-based regimes, there are currently a couple of interesting examples of structure-based neural networks. In AtomNet (Wallach et al., 2015), input—molecular complex—is discretized to a 3D grid and fed directly into a convolutional neural network. Instead of data preprocessing, the model uses a learnable representation to recognize different groups of interacting atoms. AtomNet is a classification method that yields 1 if the ligand is active and 0 otherwise. Another similar model was created by Ragoza et al. (2016) and trained to perform two independent classification tasks: activity and pose prediction. However, with classification methods, we lose information about the strength of the interaction between the protein and the ligand.

Since neural networks are also suitable for regression, Gomes et al. (2017) created a model predicting the energy gap between a bounded protein–ligand complex and an unbounded state. In their work, radial pooling filters with learnable mean and variance were used to process the input. Such filters enabled the production of a summary of the atom’s environment and a representation that was invariant to atom ordering and the orientation of the complex.

Taking into account the current findings and aforementioned approaches, we have developed Pafnucy (pronounced ‘paphnusy’)—a novel deep neural network tailored for many structure-based approaches, including derivative prioritization and virtual screening. Similar to Ragoza et al. (2016), the input structure is represented with a 3D grid, and a combination of convolutional and dense layers is used; however, our model tries to predict the exact binding affinity value. Pafnucy utilizes a more natural approach to atom description in which both proteins and ligands have the same atom types. This approach serves as a regularization technique as it forces the network to discover general properties of interactions between proteins and ligands. Additionally, the design of Pafnucy provides insight into the feature importance and information extraction that is done during learning and the final prediction of binding affinity. The network was implemented with TensorFlow (Abadi et al., 2015) using Python API and trained on the PDBbind database (Liu et al., 2017). The source code, trained model and usage instructions are available as a git repository at http://gitlab.com/cheminfIBB/pafnucy.

## Section: 2 Materials and methods

Pafnucy’s architecture. The molecular complex is represented with a 4D tensor, processed by threee convolutional layers and three dense (fully-connected) layers to predict the binding affinity

## Section: 2 Materials and methods › 2.1 Data › Representation of a molecular complex

Three-dimensional structures of protein–ligand complexes require specific transformations and encoding in order to be utilized by a neural network. In our approach, we cropped the complex to a defined size of 20-Å cubic box focused at the geometric center of a ligand. We then discretized the positions of heavy atoms using a 3D grid with 1-Å resolution (see Supplementary Fig. S1). This approach allowed for the representation of the input as a 4D tensor in which each point is defined by Cartesian coordinates (the first 3 dimensions of the tensor) and a vector of features (the last dimension).

In Pafnucy, 19 features were used to describe an atom:

The SMARTS patterns were defined the same way as in our previous project (Stepniewska-Dziubinska et al., 2017). The partial charges were scaled by the training set’s standard deviation in order to get a distribution with a unit standard deviation, which improves learning. In case of collisions (multiple atoms in a single grid point), which rarely occur for a 1-Å grid, features from all colliding atoms were added.

## Section: 2 Materials and methods › 2.1 Data › Dataset preparation

The network was trained and tested with protein–ligand complexes from the PDBbind database v. 2016 (Liu et al., 2017). This database consists of 3D structures of molecular complexes and their corresponding binding affinities expressed with pKa (−log ⁡Kd or −log ⁡Ki) values. PDBBind complexes were divided by Liu et al. into 3 overlapping subsets. The general set includes all available data. From this set, the refined set, which comprises complexes with higher quality, is subtracted. Finally, the complexes from the refined set are clustered by protein similarity, and 5 representative complexes are selected from each cluster. This fraction of the database is called the core set and is designed as a high-quality benchmark for structure-based CADD methods.

To properly employ PDBbind information and prevent data leakage, we have split the data into disjoint subsets, i.e. the refined set was subtracted from the general set, and the core set was subtracted from the refined set so that there are no overlaps between the three subsets. Next, we have discarded all protein–protein, protein–nucleic acid, and nucleic acid–ligand complexes from these new datasets. Finally, in order to evaluate our model with the CASF-2013 ‘scoring power’ benchmark (Li et al., 2014), we needed to exclude all data that overlap with the 195 complexes used in CASF-2013. We therefore excluded a total of 87 overlapping complexes (5 were part of the general set, and 82 were part of the refined set) from the training and validation sets. For the list of excluded structures see Supplementary Table S1.

All complexes used in this study were protonated and charged using UCSF Chimera (Pettersen et al., 2004) with Amber ff14SB for standard residues and AM1-BCC for non-standard residues and ligands. No additional improvements nor calibration was performed on the complexes; this default protocol was chosen to be in line with (Li et al., 2014) to be able to compare Pafnucy to other methods tested on the CASF-2013 ‘scoring power’ benchmark.

The remaining complexes of the PDBbind v. 2016 dataset were divided as follows: (i) 1000 randomly selected complexes from the refined set were used in validation, (ii) the whole core set (290 complexes) was used as an external test set, (iii) all other complexes (remainder of the refined set and the general set, 11906 in total) were used as the training set. In summary, the general and refined sets were used to train the model and select the hyperparameters, while the core set was used as an external test set that was unknown to the model during training and validation. The scheme illustrating relationships between the subsets and dataset partitioning is available in Supplementary Figure S2.

Atomic features were calculated using Open Babel (O'Boyle et al., 2011), and the complexes were transformed into grids. Helper functions used to prepare the data and Jupyter Notebook with all preprocessing steps are available at http://gitlab.com/cheminfIBB/pafnucy.

As an additional external test set, we used 73 complexes from the Astex Diverse Set (Hartshorn et al., 2007). This dataset, although substantially smaller than PDBbind subsets, provides Pafnucy with structures from an independent source, and can help in detecting generalization problems related to database-specific artefacts. Of 85 complexes in the Astex Diverse Set, we excluded those without binding affinity (11 complexes) and those present in the PDBbind database (a single complex, PDB ID: 1YVF, was present in the general set). The remaining structures were prepared the same way as the PDBbind database. This dataset was used in order to test Pafnucy on structures from a different source.

## Section: 2 Materials and methods › 2.2 Network

Pafnucy’s architecture. The molecular complex is represented with a 4D tensor, processed by threee convolutional layers and three dense (fully-connected) layers to predict the binding affinity

## Section: 2 Materials and methods › 2.2 Network › Architecture

The architecture used in Pafnucy is a deep convolutional neural network with a single output neuron for predicting the binding affinity. The model consists of two parts: the convolutional and dense parts, with different types of connections between layers (see Fig. 1). Convolution, from which the name ‘convolutional’ stems, is a mathematical operation that mixes two functions together. Most neural network libraries actually substitute the convolution operation with cross-correlation (Goodfellow et al., 2016), which has a more intuitive interpretation and measures the similarity of two functions. The model discovers patterns that are encoded by the filters in the convolutional layer and creates a feature map with spatial occurrences for each pattern in the data.

Pafnucy’s input—molecular complex—is represented with a 4D tensor and treated like a 3D image with multiple color channels. Each position of an input (x, y and z coordinates) is described by a vector of 19 properties (see Section 2.1.1), which is analogous to how each pixel of an image (x and y coordinates) is described by a vector of intensities of three basic colors.

First, the input is processed by a block of 3D convolutional layers combined with a max pooling layer. Pafnucy uses 3 convolutional layers with 64, 128 and 256 filters. Each layer has 5-Å cubic filters and is followed by a max pooling layer with a 2-Å cubic patch. The result of the last convolutional layer is flattened and used as input for a block of dense (fully-connected) layers. We used 3 dense layers with 1000, 500 and 200 neurons. In order to improve generalization, dropout with drop probability of 0.5 was used for all dense layers. We also experimented with 0.2 dropout and no dropout and achieved worse results on the validation set.

Both convolutional and dense layers are composed of rectified linear units (ReLU). ReLU was chosen because it speeds up the learning process compared with other types of activations. We also experimented with Tanh units and achieved a very similar prediction accuracy, but learning was much slower.

Pafnucy’s architecture. The molecular complex is represented with a 4D tensor, processed by threee convolutional layers and three dense (fully-connected) layers to predict the binding affinity

## Section: 2 Materials and methods › 2.2 Network › Training

The initial values of the convolutional filter weights were drawn from a truncated normal distribution with 0 mean and 0.001 standard deviation and corresponding biases were set to 0.1. The weights in the dense layers were initialized with a truncated normal distribution with 0 mean and a standard deviation of 1/n, where n is the number of incoming neurons for a given layer. The corresponding biases were set to 1.0.

The Adam optimizer was used to train the network with a 10−5 learning rate and 5 examples per mini-batch (The training set contains 11906 complexes; therefore, the last batch actually consisted of 6 complexes instead of 5.). Larger batch sizes (10 and 20 examples) were also tested but resulted in worse performance. Training was carried out for 20 epochs, and the model with the lowest error on the validation set was selected (in the case of the network described in this work, it was after 14 epochs of training).

To reduce overfitting, we used the dropout approach mentioned earlier and L2 weight decay with λ=0.001. Using a higher value (λ=0.01) decreased the model’s capacity too much and resulted in higher training and validation errors. In addition to providing regularization, L2 allows us to investigate feature importance. If a weight differs from 0 considerably,

information it transfers must be important for the model to make a prediction (see Section 4).

An important part of our approach was to develop a model that was not sensitive to ligand–receptor complex orientation. Therefore every structure was presented to the network in 24 different orientations (i.e. all possible combinations of 90° rotations of a cubic box), yielding 24 different training examples per protein–ligand complex.

By using systematic rotations of complexes during training, we anticipated that the network would learn more general rules about protein–ligand interactions and lead to better performance on new data. Indeed, in our experiments, we observed a much worse performance of models trained on single orientations regardless of the hyperparameters used to define a particular network.

## Section: 3 Results

The error on training and validation sets was monitored during learning (see Supplementary Fig. S3). Although the model was trained on 24 different rotations of each complex, the RMSE (root mean square error) was calculated for the original orientation only in order to speed up the computations.

After 14 epochs of training, the model started to overfit, and the error on the validation set started to slowly yet steadily increase. The best set of weights of the network, obtained after 14 epochs of training, was saved and used as the final model. Model performance was evaluated on all subsets of the data (see Table 1 and Fig. 2). For each complex in the dataset, affinity was predicted and compared to the real value. Prediction error was measured with RMSE and MAE (mean absolute error). The correlation between the scores and experimentally measured binding constants was assessed with the Pearson’s correlation coefficient (R) and the standard deviation in regression (SD). SD is a measure used in CASF (Li et al., 2014) and is defined as follows:

where ti and yi are the measured and predicted affinities for the ith complex, whereas a and b are the slope and the intercept of the regression line between measured and predicted values, respectively.

As expected, the network achieves the lowest error on the training set (Fig. 2c), which was used to find the weights of the network. More importantly, Pafnucy also returns accurate predictions for the two test sets (Fig. 2a and b), which were unknown to the model during training and validation. The results on the CASF-2013 ‘scoring power’ benchmark (PDBbind v. 2013 core set), although substantially worse than for other subsets, are still better than those for any other scoring function tested by Li et al. (2014)—the best-performing X-Score had R = 0.61 and SD = 1.78, while our model achieved R = 0.70 and SD = 1.61 (see Table 2). To our knowledge, the only scoring function with better performance published so far is RF-Score v3, which achieves R = 0.74 and SD = 1.51 on CASF-2013 [results were calculated with ODDT (Wójcikowski et al., 2015)].

We also compared Pafnucy to X-Score on the Astex Diverse Set (Table 3). This experiment provides Pafnucy with a test set completely separate from the data provided by Liu et al.

Both methods have comparable errors to those obtained on the PDBbind data. As expected, Pafnucy outperforms X-Score on the Astex Diverse Set, regardless of which measure is used. The observed correlation, however, is lower for both methods. This effect is partially due to the fact that the Astex dataset contains only 73 complexes, and therefore, correlation is much more sensitive to small changes in the predictions than for bigger subsets.

Pafnucy’s performance

Predictions for two test sets (core sets from PDBbind v. 2016 and v. 2013), training set and validation set

Results on the CASF-2013 ‘scoring power’ benchmark (PDBbind v. 2013 core set)

Predictions accuracy on the Astex Diverse Set

## Section: 4 Discussion

Range of weights for each input channel (feature). Outliers are not shown

The most important parts of the input. Regardless of the complex orientation, the same region of the input had the highest impact on the prediction. Note that the second plot is rotated back about the X-axis to ease the comparison. (a) Original orientation. (b) Rotated by 180° about the X-axis. (c) Protein–ligand interactions. Graphic was generated with Poseview (Stierand and Rarey, 2010)

Activations on the hidden layers for two orientations of the PDE10A complex (PDB ID: 3WS8). Darker colors indicate higher values. Cosine distances (d) between the activation patterns for each layer are provided

## Section: 4 Discussion › 4.1 stability of the results with respect to input rotation

One of the biggest challenges of this project was to properly handle the orientation of a molecular complex. This problem occurs also in image recognition—the input looks differently when an object is shown from a different angle, yet it contains the same information about the underlying real object. There are two main approaches to dealing with this issue: by using a representation invariant to the complex position (e.g. molecule-level features or internal coordinates), or by creating a model that would be robust to the input orientation. The model presented in this work uses the latter approach, similarly to how 2D convolutional neural networks are used in image recognition. Therefore, to generalize well, the model needed to learn to extract information from differently presented input. In order to achieve this, we augmented the dataset with systematic rotations of the input data. If Pafnucy was trained correctly, it should return similar predictions regardless of the orientation of the complex.

To test the model’s stability we selected the PDE10A protein, a cAMP/cGMP phosphodiesterase important in signal transduction and recently linked to neuropsychiatric disorders (MacMullen et al., 2017). PDE10A is complexed with 57 different ligands in the PDBBind database (41 complexes in the training set, 6 in the validation and 10 in the test set). Each of the complexes was presented to the model in 24 different rotations, and the distribution of returned predictions was analyzed. As anticipated, the variability of the predicted binding constants is low (see Supplementary Fig. S4). Additionally, the variability does not depend on the value of the prediction nor the subset the molecule belongs to.

## Section: 4 Discussion › 4.2 How Pafnucy sees and processes the data

Neural networks are often deemed harder to analyze and interpret than simpler models and are sometimes regarded as ‘black-boxes’. The worry is that a model can yield good predictions for the wrong reasons (e.g. artefacts hidden in the data) and therefore will not generalize well for new datasets. In order to trust a neural network and its predictions, one needs to ensure that the model uses information that is relevant to the task at hand. In this section, we analyze which parts of the input are the most important and have the biggest impact on the predictions.

In the case of random forests, for example, there is an established way to calculate feature importance based on the impurity decrease (Breiman et al., 1984). With neural networks, there is no such consensus, as the interpretation of the model’s parameters may differ considerably between networks with different architectures.

In the case of Pafnucy, which was trained with L2, we can estimate feature importance by looking at the distributions of weights associated with the convolutional filters in the first hidden layer. Their initial values were close to 0 (see Section 2.2.2 for more details). During training, the weights tend to spread and form wider ranges, as weights with higher absolute values pass more information to the deeper layers of the network. Because Pafnucy was trained with L2 regularization, only crucial weights were likely to have such high absolute values.

The input was represented using 19 channels, some of which were expected to be of low relevance for the model (e.g. the boron atom type). As we can see in the Figure 3, the feature with the widest range is the moltype—feature distinguishing the protein from the ligand. This result implies that Pafnucy learned that binding affinity depends on the relationship between the two molecules and that recognizing them is crucial. Additionally, the weights for selenium and boron atom types (Se and B, respectively) barely changed during training and are close to 0. This result can be interpreted in two ways: either the network found other features of protein–ligand complexes more important for binding affinity, or due to infrequent occurrence of these atom types in ligands the network was not able to find any general patterns for their influence on binding affinity.

To further inspect how the network utilizes the input, we analyzed the impact of missing data on the prediction. To inspect this, we selected one of the PDE10A complexes with a benzimidazole inhibitor (complex PDB ID: 3WS8; ligand PDB ID: X4C). The experiment was carried out as follows: we produced 343 corrupted complexes with some missing data and predicted the binding affinity for each. The missing data were produced by deleting a 5-Å cubic box from the original data. We slid the box with a 3-Å step (in every direction), thus yielding 73=343 corrupted inputs. Next, we rotated the complex by 180° about the X-axis and followed the same procedure, thus yielding another 343 corrupted inputs. Then, for each of the two orientations, we took 10 corrupted inputs that had the highest drop in predicted affinity (Fig. 4). We wanted to find which atoms’ absence caused the highest drops in the predictions.

As we can see in Figure 4a and b, for both orientations, we identified the same region containing the ligand and its nearest neighbourhood. The boxes contain the amino-acids participating in the interactions with the ligand, i.e. Gln726, which forms a hydrogen bond, and Phe729, which forms a π−π interaction with the ligand (Fig. 4c).

Additionally, if we considered 15 corrupted complexes with the highest drop in predictions, we find other amino-acids interacting with the ligand: Tyr693, which forms a hydrogen bond, and Met713, which forms hydrophobic contacts with the ligand. The methodology presented above can be applied to other complexes in order to elucidate specific ligand–receptor interactions with the most profound effect on the prediction.

Going back to the uncorrupted input, we wanted to investigate how Pafnucy managed to give almost identical predictions for two different orientations of the complex (the second rotated about the X-axis by 180°). For this inquiry, we analyzed the activations of the hidden layers for the two inputs.

In Figure 5, we can see that the first hidden layer has very different activation patterns for the two orientations of the input. Pafnucy gets very different data and needs to use different filters in the first convolutional layer to process them. However, the closer we get to the output layer, the more similar the activations become. We can clearly see that our model learned to extract the same information from differently presented data.

Range of weights for each input channel (feature). Outliers are not shown

The most important parts of the input. Regardless of the complex orientation, the same region of the input had the highest impact on the prediction. Note that the second plot is rotated back about the X-axis to ease the comparison. (a) Original orientation. (b) Rotated by 180° about the X-axis. (c) Protein–ligand interactions. Graphic was generated with Poseview (Stierand and Rarey, 2010)

Activations on the hidden layers for two orientations of the PDE10A complex (PDB ID: 3WS8). Darker colors indicate higher values. Cosine distances (d) between the activation patterns for each layer are provided

## Section: 5 Conclusions

In this work we presented a deep neural network, Pafnucy, which can be used in structure based ligand discovery campaigns; as a scoring function in virtual screening or affinity predictor for novel molecules after a complex is generated. Pafnucy can be also utilized directly during the docking procedure to guide ligand pose optimization. The model was tested on the CASF-2013 ‘scoring power’ benchmark and outperformed all 20 state-of-the-art scoring functions tested by the CASF-2013 authors. The results obtained and the careful analysis of the network show that Pafnucy makes reliable predictions based on relevant features.

Predicting the impact of small molecules on diverse biologically important protein targets has long been sought by researchers. Pafnucy can be either applied to test multiple compounds against a single protein, or to test multiple proteins against a single compound. It can therefore help in discovering new potential drugs, but also in investigating side effects of bioactive molecules. By anticipating the potential impact of new drugs on the biology of the cell, Pafnucy may contribute to such disciplines as systems medicine and systems biology.

The approaches used in the analyses presented in the ‘Discussion’ are general and can be applied to other predictive models for drug discovery. Finding the most important features and parts of a molecular complex can help researchers to design better compounds, but also to better understand and improve their models.

Because Pafnucy is a neural network, it is also possible to calculate and analyze its gradients. During training, gradients are used to optimize model parameters. However, they can also be calculated for the input and point to beneficial changes in a molecule’s conformation (finding optimal pose during docking) or composition (lead optimization).

Pafnucy and its source code, together with the Jupyter Notebooks used to prepare the data and analyze the results, are freely available at http://gitlab.com/cheminfIBB/pafnucy. Usage examples and scripts are also available to facilitate the most common use-cases: preparing the input data, predicting binding affinity and training a new network. We hope that these features will make Pafnucy easily applicable and adaptable by other researchers. In addition, we are working on a more flexible implementation of the model, that will allow the user to easily manipulate network parameters and molecular complex representation, with minimal programming knowledge.

Preparing the environment with all needed dependencies and using the model for the new data can be done with minimum effort:

## Section: Supplementary Material

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

## Section: Acknowledgements

The authors thank Maciej Wójcikowski for providing the data and X-Score results for the Astex Diverse Set and Maciej Dziubiński for his help in revising the manuscript.

## Section: Acknowledgements › Funding

This work was supported by the Polish Ministry of Science and Higher Education (POIG.02.03.00-00-003/09-00 and IP2010 037470).

## Section: Associated Data

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.

Click here for additional data file.


---

# Multi-objective de novo drug design with conditional graph generative model

- **Authors:** Yibo Li, Liangren Zhang, Zhenming Liu
- **Issuer:** Journal of Cheminformatics
- **Type:** Scientific article
- **Published:** 2018-07-24
- **DOI:** 10.1186/s13321-018-0287-6
- **Source:** https://doi.org/10.1186/s13321-018-0287-6
- **Licence:** CC-BY

## Section: Abstract

AbstractRecently, deep generative models have revealed itself as a promising way of performing de novo molecule design. However, previous research has focused mainly on generating SMILES strings instead of molecular graphs. Although available, current graph generative models are are often too general and computationally expensive. In this work, a new de novo molecular design framework is proposed based on a type of sequential graph generators that do not use atom level recurrent units. Compared with previous graph generative models, the proposed method is much more tuned for molecule generation and has been scaled up to cover significantly larger molecules in the ChEMBL database. It is shown that the graph-based model outperforms SMILES based models in a variety of metrics, especially in the rate of valid outputs. For the application of drug design tasks, conditional graph generative model is employed. This method offers highe flexibility and is suitable for generation based on multiple objectives. The results have demonstrated that this approach can be effectively applied to solve several drug design problems, including the generation of compounds containing a given scaffold, compounds with specific drug-likeness and synthetic accessibility requirements, as well as dual inhibitors against JNK3 and GSK-3β. Electronic supplementary materialThe online version of this article (10.1186/s13321-018-0287-6) contains supplementary material, which is available to authorized users.Keywords: Deep learning, De novo drug design, Graph generative model

## Section: Background

The ultimate goal of drug design is the discovery of new chemical entities with desirable pharmacological properties. Achieving this goal requires medicinal chemists to explore the chemical space for new molecules, which is proved to be extremely difficult, mainly due to the size and complexity of the chemical space. It is estimated that there are around 1060-10100 synthetically available molecules [1]. Meanwhile, the space of chemical compounds exhibits a discontinues structure, making searching difficult to perform [2].

De novo molecular design aims at assisting this processes with computer-based methods. Early works have developed various algorithms to produce new molecular structures, such as atom based elongation or fragment based combination [3, 4]. Those algorithms are often coupled with global optimization techniques such as ant colony optimization [5, 6], genetic algorithms [7, 8] or particle swam optimization [9] for the generation of molecules with desired properties.

Recent developments in deep learning [10] have shed new light on the area of de novo molecule generation. Previous works have shown that deep generative models are very effective in modeling the SMILES representation of molecules using recurrent neural networks (RNN), an architecture that has been extensively applied to tasks related sequential data [11]. Segler et al. [12] applied SMILES language model (LM) on the task of generating focused molecule libraries by fine-tuning the trained network with a smaller set of molecules with desirable properties. Olivecrona et al. [13] used a GRU [14] based LM trained on the ChEMBL [15] dataset to generate SMILES string. The mode is then fine-tuned using reinforcement learning for the generation of molecules with specific requirements. Popova et al. [16] proposed to integrate the generative and predictive network together in the generation phase. Beside language model, Gómez–Bombarelli et al. [13] used variational autoencoder (VAE) [17] to generate drug-like compounds from ZINC database [18]. This work aimed at obtaining a bi-directional mapping between molecule space and a continuous latent space so that operations on molecules can be achieved by manipulating the latent representation. Blaschke et al. [19] compared different architectures for VAE and applied it to the task of designing active compounds against DRD2.

The researches described above demonstrated the effectiveness of SMILES based model regarding molecule generation. However, producing valid SMILES strings requires the model to learn rules that are irrelevant to molecular structures, such as the SMILES grammar and atom ordering, which increases the burden of the model and makes the SMILES string a less preferable representation compared with molecular graphs. Research in deep learning has recently enabled the direct generation of molecular graphs. Johnson et al. [20] proposed a sequential generation approach for graphs. Though their implementation is mainly for reasoning tasks, this framework is potentially applicable to molecule generation. A more recent method [21] was proposed for generating the entire graph all at once. This model has been successfully applied to the generation of small molecular graphs. The implementation that is most similar to ours is by the recent work by Li et al. [22] using a sequential decoding scheme similar to that by Johnson et al. Decoding invariance is introduced by sampling different atom ordering from a predefined distribution. This method has been applied to the generation of molecules with less than 20 heavy atoms from ChEMBL dataset. Though inspiring, the methods discussed above have a few common problems. First of all, the generators proposed are relatively general. This design allows those techniques to be applied to various scenarios but requires further optimization for application in molecule generation. Secondly, many of those models suffer from scalability issue, which restricts the application to molecules with small sizes.

In this work, we propose a graph-based generator that is more suited for molecules. The model is scaled to cover compounds containing up to 50 heavy atoms in the ChEMBL dataset. Results show the graph-based model proposed is able to outperform SMILES based methods in a variety metrics, including the rate of valid outputs, KL and JS divergence of molecular properties, as well as NLL loss. A conditional version of the model is employed to solve various drug design related tasks with multiple objectives, and results have demonstrated promising performance.

## Section: Methods

Cimetidine and its graph based representation. In the graph based generative models, molecules (see a) are represented as graphs G=(V,E) (see b), where atoms are bonds are viewed as nodes and edges respectively. Atom types are specified by three parameters: the atomic symbol (or equally the atomic number), the number of explicit hydrogens attached, and the number of formal charges (see c). For bond types, only single, double, triple and aromatic bonds are considered in this work (see d)

A schematic representation of molecule generation process. Starting with the empty graph G0, initialization is performed to add the first atom. At each step, a graph transition (append, connect or terminate) is sampled and performed on the intermediate molecule structure. The probability for sampling each transition is given by pθ(t|Gi,…,G0), which is parametrized using deep neural network. Finally, termination operation is performed to end the generation

The two type of graph generative architectures explored in this work: a MolMP: this architecture treats graph generation as a Markov process, in which the transition of Gi only depends on the current state of the graph, not on the history. b MolRNN: this architecture adds a single molecule level recurrent unit to MolMP

Network architecture for MolMP. This figure shows the detailed model architecture for MolMP. MolRNN adopts a structure highly similar to that of MolMP, except the inclusion of a molecule level recurrent unit

Architecture of graph convolutional layer. At each layer, the output representation for atom v is given by: (1) the input representation of v from previous layers, (2) information of local neighbors and (3) information of distant neighbors

Conditonal generative models: a For the generation of molecules based on a given requriement, the requriement (query) is first converted to the numerical representation called conditoinal code, the generative model is then modified to be conditioned on the conditonal code. b Scaffold based molecule generation: The model is required to generate molecules based on a given scaffold. This requriement is first converted to the conditional code called scaffold fingerprint. Then the molecule containing the query scaffold is generated based on the fingerprint. c Generation based on drug-likeness and synthetic accessibility: Drug-likeness and synthetic accessibility are first quantized using QED and SAscore. Then model then generates molecules based on the two properties. d Designing of dual inhibitors of JNK3 and GSK-3β: the generation process is based on the bioactivity fingerprint containing the activity requirement of each target

Workflow for scaffold based molecule generation. Scaffold set S is first extracted from compounds in DrugBank. The conditional code c is set to be the substructure fingerprint based on S. Training is performed with the training samples labeled with cG. After training, scaffold based generation is performed using the fingerprint cs of the query scaffold s∈S

## Section: Methods › Molecular graph

Molecular graph is a way of representating the structural information of molecules using graphs (G=(V,E)). Atoms and bonds in the molecule are viewed as graph nodes (v∈V) and edges (e∈E). Each node is labeled with its corresponding atom type, while each edge is labeled with its corresponding bond type. We refer the set of all atom types and bond types as A and B respectively. In this work, the atom type is specified using three variables: the atomic symbol (or equally the atomic number), the number of explicit hydrogens attached, and the number of formal charges. For example, the nitrogen atom in pyrrole can be represented as the triple (“N”, 1, 0). The set of all atom types (A) is extracted from molecules in the ChEMBL dataset (see Additional file 1: Supplementary Text 1), and contains 33 members in total. For bonds, we only consider the following four bond types: single, double, triple and aromatic. A visualized demonstration of molecular graph is given in Fig. 1.

Cimetidine and its graph based representation. In the graph based generative models, molecules (see a) are represented as graphs G=(V,E) (see b), where atoms are bonds are viewed as nodes and edges respectively. Atom types are specified by three parameters: the atomic symbol (or equally the atomic number), the number of explicit hydrogens attached, and the number of formal charges (see c). For bond types, only single, double, triple and aromatic bonds are considered in this work (see d)

## Section: Methods › Graph generative model

We now consider the deep generative models that can directly output molecular graphs. In this work, we mainly focus on sequential graph generators, which build graph by iteratively refining its intermediate structure. The process starts from the empty graph G0=(∅,∅). At step i, a graph transition ti is selected from the set of all available transition actions T(Gi) based on the generation history (G0,…,Gi). The selection is done by sampling ti from a probability distribution ti∼pθ(ti|Gi,…,G0), which is parametrized by a deep network. Then, ti is performed on Gi to get the graph structure for the next step Gi+1=ti(Gi). At the final step n, termination operation t∗ is performed and the model outputs G=Gn as the final result.

The entire process is illustrated in Fig. 2. We call the mapping T, which determines all available graph transitions at each step, a decoding scheme. The sequence r=((G0,t0),(G1,t1),…,(Gn,tn)) is called a decoding route of G, and the distribution pθ(ti|Gi,…,G0) is called a decoding policy.

Previous graph generative models are usually too general and less optimized for the generation of molecular graphs. Here we offer the following optimizations:

The following three sections are devoted to the detailed discussions of the optimizations above.

A schematic representation of molecule generation process. Starting with the empty graph G0, initialization is performed to add the first atom. At each step, a graph transition (append, connect or terminate) is sampled and performed on the intermediate molecule structure. The probability for sampling each transition is given by pθ(t|Gi,…,G0), which is parametrized using deep neural network. Finally, termination operation is performed to end the generation

## Section: Methods › Decoding scheme

The transitions in T(Gi) given the intermediate state Gi is restricted to the following four types:

The entire process is shown in Fig. 2, and a more detailed illustration is provided in Additional file 2: Figure S1 and S2. In theory, T(G) should not contain actions that violate the chemical validity of molecules. However, in order to test the ability for the model to learn those constraints, we do not explicity exclude those actions from T(G) during training.

Note that compared with the implementation in [22], the action of adding new atom and the action of connecting it to the molecule is merged into a single “append” step. This helps to reduce the number of steps during generation. It is easy to show that the number of steps required for generating graph G=(V,E) equals exactly to |E|+2, which is generally much smaller than the length of the corresponding SMILES string (as shown in Additional file 2: Figure S3).

## Section: Methods › Decoding policy

During generation, the decoding policy pθ need to specify the probability value for each graph transition in T(Gi). More specifically, pθ need to output the following probability values:

A visualized depiction of pvA, pvC and p∗ is shown in Fig. 2. The decoding policy pθ is parameterized using neural network. At each step, the network accepts the the decoding history (G0,…,Gi) as input and calculates the probability values (pvA, pvC, p∗) as output. In this work, we explored two novel graph generation architectures, namely MolMP and MolRNN. Unlike the methods proposed in [20, 22], the two architectures do not involve atom level recurrency, which helps to increase the scalability of the model.

The two type of graph generative architectures explored in this work: a MolMP: this architecture treats graph generation as a Markov process, in which the transition of Gi only depends on the current state of the graph, not on the history. b MolRNN: this architecture adds a single molecule level recurrent unit to MolMP

Network architecture for MolMP. This figure shows the detailed model architecture for MolMP. MolRNN adopts a structure highly similar to that of MolMP, except the inclusion of a molecule level recurrent unit

Architecture of graph convolutional layer. At each layer, the output representation for atom v is given by: (1) the input representation of v from previous layers, (2) information of local neighbors and (3) information of distant neighbors

## Section: Methods › Decoding policy › MolMP

MolMP models graph generation as a Markov process, where the transition of Gi only depends on the current state of the graph, not on the history (Fig. 3a). This means that pθ(t|Gi,…,G0)=pθ(t|Gi). Since this type of architecture does not include any recurrent units, it will be less expensive compared with RNN based models. Moreover, the computation at different steps can be easily parallelized during training. The detailed architecture of MolMP is given as follows:

The architecture of the entire network is shown in Fig. 4.

The two type of graph generative architectures explored in this work: a MolMP: this architecture treats graph generation as a Markov process, in which the transition of Gi only depends on the current state of the graph, not on the history. b MolRNN: this architecture adds a single molecule level recurrent unit to MolMP

Network architecture for MolMP. This figure shows the detailed model architecture for MolMP. MolRNN adopts a structure highly similar to that of MolMP, except the inclusion of a molecule level recurrent unit

## Section: Methods › Decoding policy › MolRNN

The second architecture adds a single molecule level recurrent unit to MolMP, as shown in Fig. 3. We refer to this method as MolRNN. The model architecture is specified as follows:

The overall architecture of MolRNN is highly similar to that of MolMP. However, it is found that the molecule level recurrent unit in MolRNN provides significant improvements to the model performance (see “Model performance and sample quality”), while inducing little extra computational cost compared with MolMP.

## Section: Methods › Decoding policy › Graph convolution

In this work, we rely on graph convolutional network (GCN) [24] to extract information from intermediate graph states Gi. Each graph convolutional layer adopts the “BN-ReLU-Conv” structure as described before. In terms of the convolution part, the architecture is structured as follows:

where hvl is the output representation of atom v at layer l, and hvl-1 is the input representation. Nbbond(v) is the set of all atoms directly connected to atom v with bond of type b, and Ndpath(v) is the set of all atoms whose distance to atom v equals to d. D represents the receptive field size, which is set to 3 in this work. Wl, Θbl and Φdl are weight parameters of layer l.

In brief, the output representation of atom v at each layer l (hvl) is calculated according to the following information:

The architecture is illustrated in Fig. 5. Our implementation of graph convolution is similar to the edge conditioned convolution by Simonovsky et al. [25], except that we directly include the information of remote neighbors of v in order to achieve a larger receptive field with fewer layers.

Architecture of graph convolutional layer. At each layer, the output representation for atom v is given by: (1) the input representation of v from previous layers, (2) information of local neighbors and (3) information of distant neighbors

## Section: Methods › Likelihood function

To train the generative model, we need to maximize the log-likelihood pθ(G) for the training samples. However, for the step-wise generative models discussed above, the likelihood is only tractable for a given decoding route r=((G0,t0),(G1,t1),…,(Gn,tn)):

While the marginal likelihood can be computed as:

where R(G) is the set of all possible decoding route for G. The marginal likelihood function is intractable for most molecules encountered in drug design. One way to resolve this problem is to use importance sampling as proposed in [22]:

where q(r|G) is a predefined distribution on R(G). Both the deterministic and the fully randomized q(r|G) were explored in the previous work [22]. However, a more desirable solution would lie in somewhere between deterministic decoding and fully randomized decoding. In this work, instead of sample from the distribution q(r|G), we sample r from distribution qα(r|G) that is parameterized by 0≤α≤1. qα(r|G) is designed such that the decoding will largely follow depth first decoding with canonical ordering, but at each step, there is a small possibility 1-α that the model will make a random mistake. In this way, the parameter α measures can be used to control the randomness of the distribution qα. The algorithm is shown in Additional file 1: Supplementary Text 4.

For α=1, the distribution falls back to the deterministic decoding. The parameter α is treated as a hyperparameter which is optimized for model performance. We tried α∈{1.0,0.8,0.6} on both MolMP and MolRNN.

## Section: Methods › Conditional generative model

Most molecule design tasks require to produce compounds satisfying certain criteria, such as being synthetically available or having a high affinity for a certain target. Previous researches have developed various methods to achieve objective directed molecule generation. Segler et al. [12] used transfer learning in the design of focused compound libraries. Olivecrona et al. [13] applied reinforcement learning (RL) in the objective based chemical design and have reported promising performance in various tasks. Guimaraes et al. [26] proposed ORGAN, which combines SeqGAN with an domain-specific objective term, and showed that ORGAN is effective in the optimization of different molecular properties. Neil et al. [27] created a benchmark analysis of various RL based method in different tasks of molecule design. In this work, we explored another way to achieve requirement based molecule design using conditional generative model. We first convert the given requirement to the numerial representation called conditional code (c), and the generative model is then modified to be conditioned on c. For graph generative model, this means that the decoding policy is now pθ(ti|Gi,…,G0,c) (see Fig. 6). Compared with previous approaches by Olivecrona et al. and Guimaraes et al., conditional generative model does not require reinforcement learning, and provides the following flexibilities:

Both graph based and SMILES based conditional generators are implemented in this work. For graph based model, the graph convolution is modified to include c as input:

Simply state, c is included in the graph convoludion architecture by adding an additional term Ψlc to the unconditional implementation in Eq. 12. For SMILELS based model, the conditional code is included by concatenating it with the input at each step: xi′=Concat(xi,c). where xi is the one-hot representation of the SMILES charactor input at step i.

Conditional models have already been used by the previous work [21] for molecule generation, but was restricted to simple properties such as the number of heavy atoms as conditional codes. Also, the method have not yet applied to multi-objective molecule generation. Here, we apply this method to other more complexed drug design tasks, including scaffold-based generation, property-based generation and the design of dual inhibitor of JNK3 and GSK-3β (see 6). The best performing graph and SMILES based generator (see “Model performance and sample quality”) are implemented in conditionalized version and applied to those tasks.

Conditonal generative models: a For the generation of molecules based on a given requriement, the requriement (query) is first converted to the numerical representation called conditoinal code, the generative model is then modified to be conditioned on the conditonal code. b Scaffold based molecule generation: The model is required to generate molecules based on a given scaffold. This requriement is first converted to the conditional code called scaffold fingerprint. Then the molecule containing the query scaffold is generated based on the fingerprint. c Generation based on drug-likeness and synthetic accessibility: Drug-likeness and synthetic accessibility are first quantized using QED and SAscore. Then model then generates molecules based on the two properties. d Designing of dual inhibitors of JNK3 and GSK-3β: the generation process is based on the bioactivity fingerprint containing the activity requirement of each target

## Section: Methods › Scaffold-based generation

The concept of molecular scaffold has long been of significant importance in medicinal chemistry [28]. Though various definitions are available, the most widely accepted definition is given by Bemis and Murcko [29], who proposed derive the scaffold of a given molecule by removing all side chain atoms. Studies have found various scaffolds that have privileged characteristics in terms of the activity of certain target [30–32]. Once such privileged structure is found, a related task is to produce compound libraries containing such scaffolds for subsequent screening.

Here, conditional graph generative model is applied to generate compounds containing scaffold s, which is drawn from the pre-defined scaffold set S={si}i=1NS. The set S is extracted from the list of approved drugs in DrugBank [33]. Two types of structures are extracted from the molecules to construct S: (1) the Bemis–Murcko scaffolds, and (2) ring assemblies. Ring assemblies are included in S since we found that including extra structural information beside Bemis–Murcko scaffolds helps to improve the conditional generation performance. Detailed scaffold extraction workflow is shown in Additional file 1: Supplementary Text 2. For each molecule G, the conditional code c=(c1,c2,…,cNS) is set to be the binary vector such that ci=1 if G contains si as substructure, and ci=0 otherwise. We refer c as the scaffold fingerprint of G, as it can in fact be viewed as a substructure fingerprint based on scaffold set S. To generate molecule containing substructure s∈S, the fingerprint cs for s is used as conditional code. The output should contain two type of molecules:

The procedure is better demonstrated in Fig. 7. Using this method, detailed control can be performed on the scaffold of the output structure.

Workflow for scaffold based molecule generation. Scaffold set S is first extracted from compounds in DrugBank. The conditional code c is set to be the substructure fingerprint based on S. Training is performed with the training samples labeled with cG. After training, scaffold based generation is performed using the fingerprint cs of the query scaffold s∈S

## Section: Methods › Generation based on synthetic accessibility and drug-likeness

Drug-likeness and synthetic accessibility are two properties that have significant importance in the development of novel drug candidate. Drug-likeness measures the consistency of a given compound with the currently known drugs in terms of the structural or physical properties, and is frequently used to filter out obvious non-drug like compounds in the early phase of screening [34, 35]. Synthetic accessibility is also an important property for de novo drug design since subsequent experimental validation requires synthesis of the given compound [36]. In this task, the model is required to generate molecules according to a given level of drug-likeness and synthetic accessibility. The drug-likeness is measured using the Quantitative Estimate of Drug-likeness (QED) [37], and synthetic accessibility is evaluated using the SA score [36]. The conditional code c is defined as c=(QED,SA), where the QED and SA score is all calculated using RDKit [38].

In practice, instead of specifying a single value of QED and SA score, we often use intervals to express the requirements for desired output molecules. This means that we are required to sample molecules from the distribution pθ(G|c∈C), where the generation requirement is described as a set C instead of a single point c. Here, we samples from pθ(G|c∈C) by first drawing c from p(c|c∈C), and then drawing G from pθ(G|c). Sampling from p(c|c∈C) can be achieved by first sample c from p(c) using molecules from the test set, then filter c according to the requirement c∈C.

## Section: Methods › Designing dual inhibitor against JNK3 and GSK-3β

With the ability to model multiple requirements at once, conditional generative models can be used to design compounds with specific activity profiles for multiple targets. Here, we consider the task of designing dual inhibitors against both c-Jun N-terminal kinase 3 (JNK3) and glycogen synthase kinase-3 beta (GSK-3β). Both of the two targets are serine/threonine (S/T) kinases, and have shown to be related to the pathogenesis of various types of diseases [39, 40]. Notably, both JNK3 and GSK-3β are shown to be potential target in the treatment of Alzheimer’s disease (AD). Jointly inhibiting JNK3 and GSK-3β may provide potential benefit for the treatment of AD.

The conditional code is set to be c=(cJNK3,cGSK-3β), where cJNK3, cGSK-3β are binary values indicating whether the compound is active against JNK3 and GSK-3β. For compounds in the ChEMBL dataset, cJNK3 and cGSK-3β are labeled using a separately trained predictor. Random forest (RF) classifier, which has been demonstrated to provide good performance for kinase activity prediction [41], is used as the predictor for GSK-3β and JNK3 activity. Here, we use ECFP6 [42] as the descriptor. The predictive model is trained using activity data from ExCAPE-DB [43], which is an integrated database with activity values from ChEMBL and PubChem [44]. Workflow for data extraction and predictor training is provided in Additional file 1: Supplementary Text 3. It is found that there is only 1.2% of molecules in ChEMBL that is predicted to be active against JNK3 or GSK-3β. This imbalance results in low enrichment rate during conditioned generation. For better result, the model is first trained under the unconditioned setting, and then fine-tuned based on the 1.2% molecules mentioned above.

## Section: Methods › Training details

The graph generative models are trained using the ChEMBL dataset. The data processing workflow largely follows Olivecrona et al. [13], as described in Additional file 1: Supplementary Text 1. MXNet [45] is used to implement the networks, and Adam optimizer [46] is used for network training. An initial learning rate of 0.001 is used together with a decay rate of 0.001 for every 100 iterations. Other parameters of the optimizer are set to be the default values suggested in [46] (that is, β1=0.9,β2=0.999 and ϵ=10-8). The training lasts for 5 epochs, and the size of each mini-batch is set to 200 during the training.

During training, the decoding route is drawn from the distribution qα(r|G). We tried three α values: 1.0, 0.8 and 0.6, as discussed previously. For α=1.0, k is set to 1 and the training can be performed on a single Nvidia GeForce GTX 1080Ti GPU for both MolMP and MolRNN. The training lasts for 14h for MolMP and 16h for MolRNN. For α=0.8 and α=0.6, k is set to 5 and the training is performed synchronously on 4 GPUs. The training lasts for 30h for MolMP and 35h for MolRNN.

For scaffold based and property based generation tasks, the conditonal graph generator is trained using the same setting as unconditional model. For the generation of GSK-3β and JNK3 inhibitors, the model is first trained using the full dataset, and the fine tuned on the subset that is predicted to be active against GSK-3β or JNK3. The fine-tuning uses a learning rate of 0.0001 and a decay rate of 0.002 for every 100 iterations. The fine-tuning lasts for 10 epochs, and takes 1h to finish.

In theory, the hyperparameters for the models mentioned above, including the training condition (batch size, learning rate, decay rate, β1, β2), model architectures(the number of convolutional layers, the hidden size in each layer) as well as α, should be optimized to achieve the best performance. However, due to the computational cost of both MolMP and MolRNN, we are unable to systematically optimize the hyperparameters. A througout discussion is only given for α, which determines the degree of randomness of qα. No optimization is performed on model architecture except fitting it into the memory.

## Section: Methods › Comparison with SMILES based methods

The proposed graph-based model is compared with several SMILES based models. Two type of methods, variational autoencoder (VAE) and language model (LM), are considered in this comparison. The implementation of SMILES VAE follows Gómez-Bombarelli et al. [2]. The encoder contains three 1D convolutional layers, with 9, 9, 10 filters and 9, 9, 11 kernels each, and a fully connected layer with 435 hidden units. The model uses 196 latent variables and a decoder with three GRU layers with 488 hidden units. VAE for sequential data faces from the issue of “optimization challenge” [47, 48]. While the original implementation uses KL-annealing to tackle this problem, we follow the method provided by Kingma et al. [49] by controlling the level of free bits. This offers higher flexibility and stability compared with KL-annealing. We restrict the minimal level of free bits to 0.03 for each latent variable.

For LM, two types recurrent units are adopted. The first type uses GRU, and includes two architectures: the first architecture (SMILES GRU1) consists of three GRU layers with 512 hidden units each, and the second (SMILES GRU2), uses a wider GRU architecture with 1024 units, following the implementation by Olivecrona et al. [13]. Beside GRU, we also included a LSTM based SMILES language model following Segler et al. [12]. This architecture uses three LSTM layers, each with 1024 units.

## Section: Methods › Comparison with reinforcement learning (RL) based methods

We also compared the performance of conditional generative model with three RL based method. The first method, which is proposed by Olivecrona et al., maximizes following objective during model optimization:

where p(x) is the Prior network pre-trained using ChEMBL dataset, and q(x) is the Agent network for task-specific molecule generation. SMILES GRU2 is used as the architecture for Prior and Agent.

This method is refered to as “REINVENT” [13]. We also include the following two baselines in the comparison. The first is a non-regularized RL method with the following objective:

We refer to this method as “Naive RL”. The second method includes a prior term in addition to 19:

We refer to this method as “RL + Prior”.

## Section: Methods › Evaluation metrics

Several metrics have been employed to evaluate the performance of generative models:

## Section: Methods › Evaluation metrics › Sample validity

To test whether the generative models are capable of producing chemically correct outputs, 300,000 structures are generated for each model, and subsequently evalulated by RDKit for the rate of valid outputs. We also evaluate the ability of each model to produce novel structures. This is done by accessing the rate of generated compounds that do not occure inside the training set.

## Section: Methods › Evaluation metrics › DKL and DJS for molecular properties

A good molecule generator should correctly model the distribution of important molecular properties. Therefore, the distribution of molecular weight (MW), log-partition coefficient (LogP) and QED between the generated dataset (pg) and the test set (pdata) is compared for each method using Kullback–Leibler divergence (DKL) and Jensen–Shannon divergence(DJS):

DKL and DJS are widely used in deep generated models for both training [17, 50] and evaluation [51]. Here, the two values are determined using kernel density method implemented in SciPy [52]. We used a gaussian kernel with bandwidth selected based on Scott’s Rule [53].

## Section: Methods › Evaluation metrics › Performance metrics (Rc, Kcc′ and EORc) for task specific molecule design

For discrete conditional codes c, let Mc be the set containing molecules sampled from distribution pθ(G|c). Mc is obtained by first sampling molecule graphs conditioned on c and then removing invalid molecules. The size of |Mc| is set to 1000. Let Ncc′ be the set of molecules in Mc that satisfy the condition c′ (c′ may be different from c). The ratio Kcc′ is defined as:

The matrix Kcc′ can be used to evaluate the ability of the model to control the output based on conditional code c. When c=c′, this value gives the rate of correctly generated outputs, denoted by Rc. High quality conditional models should have a high value of Rc and low values of Kcc′ for c≠c′. In paractice, we find that the value of Kcc′ for scaffold and property based generation is significantly samller than Rc and have relatively low influence on the model’s performance. Therefore, the result of Kcc′ is omitted for scaffold and property based task, and is only reported for the task of kinase inhibitor design.

Let Rc0 be the rate of molecules in the training data that satisfy condition c. The enrichment over random EORc is defined as:

The definition is similar to that used in previous work [12], except that in their implementation Rc0 is calculated using the generated samples from the unconditioned model pθ(G). For continuous codes, a subset C of the conditional code space is used to describe the generation requirements. MC is sampled from pθ(G|c∈C), and values for KCC′, RC and EORC can be calculated in a similar manner.

## Section: Methods › Evaluation metrics › Rate of reproduced active compounds

For target based generation tasks, the rate of reproduced molecules is also reported following previous works [12, 13]. Take JNK3 as an example. During the evaluation, two sets of outputs are generated using two conditions: JNK3(+), GSK-3β (−) and JNK3(+), GSK-3β(+). The two set of outputs are denoted Mc1and Mc2respectively. Here, the size of |Mc1| and |Mc2| are both set to 50,000. Let T be the set containing the active molecules within the test set of JNK3. The rate of reproduced molecules (reprod) is calculated as:

For GSK-3β, the calculation can be done in a similar manner.

## Section: Methods › Evaluation metrics › Sample diversity

For a good objective based molecule generator, the outputs are not only required to satisfy the given condition c, but also required to be structurally diverse. Benhenda [54] have suggested that the diversity of the model outputs should be consistent with the natural diversity of molecules satisfying the c. Also, Benhenda proposed to use the following statistics to evaluate the structural diversity of a given set of compounds:

where M is the set of sampled molecules, and Td(x,y) is the Tanimoto-distance between the two molecules x and y. Td(x,y) is defined using the Tanimoto-similarity Ts: Td(x,y)=1-Ts(x,y). This metric is called the internal diversity of the molecule set M.

For each condition c, the natural diversity Ic0 is first calculated using molecules in ChEMBL. The diversity of conditional outputs Ic is then calculated for each model. Note that when calculating Ic0 and Ic, we only include molecules that satisfy the condition c. Finally, the value |Ic-Ic0| is compared among different models for their ability to reconstruct the natural compound diversity.

## Section: Results and discussion

A visualized demonstration of model outputs. a–c. Output samples by MolRNN. Results are grouped by molecular weight (a MW < 300, b 300 ≤ MW < 500, c MW ≥ 500); d, e Common mistakes made by SMILES based model and graph based model respectively; f Examples of broken aromaticity occurred during graph generation

Comparison between SMILES based and graph-based generators in output validity

Comparison between SMILES based and graph-based generators in DKL(×10-3) and DJS(×10-3)

Results of scaffold based generation. a Candesartan and the extracted scaffolds (scaffold 1–4); b Output samples based on scaffold 1–4

Performance of graph based and SMILES based model on scaffold diversification tasks

The comparison between condtional generative models RL based models in the task of generating molecules containing scaffold 4

Location of C1∼C4 and c1∼c4. a Distribution of QED and SAscore in the ChEMBL dataset; b Location of input conditions (C1∼C4 and c1∼c4)

Performance of graph based and SMILES based model on property based generation tasks

The comparison between condtional generative models RL based models in the task of generating molecules satisfying condition C1 (that is, QED > 0.84 and SA score < 1.9)

Distribution of QED and SAscore for generated results: the upper row indicates distribution of QED and SAscore of molecules generated under conditions C1, C2 , C3 and C4. The conditions C1∼C4 are shown as intervals represented by error bar. The lower row indicates distribution of QED and SAscore of molecules generated using single point conditions (c1, c2, c3 and c4). The conditions c1∼c4 are represented as dots in the plot

Samples generated under the four predefined conditions on drug-likeness and synthetic accessibility score

Performance of graph based and SMILES based model on inhibitor generation, results are reported as Mean±SD

The Kcc′ matrix for kinase inhibitor generation task, the diagnal elements Kcc=Rc are omitted since they have been reported in Table 7

The comparison between condtional generative models RL based models in the task of generating dual inhibitors against GSK-3β and JNK3

Visualizing the distribution of generated samples for each target. The figure shows the t-SNE visualization of: a molecules form test set of GSK-3β and samples conditioned on JNK3(−), GSK-3β(+), b molecules from test set of GSK-3β and samples conditioned on JNK3(+), GSK-3β(+). c Molecules from test set of JNK3 and samples conditioned on JNK3(+), GSK-3β(−), d molecules from test set of JNK3 and samples conditioned on JNK3(+), GSK-3β(+)

Samples conditioned on different selectivity conditions. a–c Generated samples under different condition of selectivity (a for dual inhibitors, b for GSK-3β selective inhibitors, and c for JNK3 selective inhibitors); d, e Some recovered actives of JNK3 and GSK-3β respectively. a Generated dual inhibitors. b Generated GSK-3β selective inhibiors. c Generated JNK3 selective inhibiors. d Recovered JNK3 inhibitors. e Recovered GSK-3β inhibitors

## Section: Results and discussion › Model performance and sample quality

Several randomly generated samples by MolRNN are grouped by molecular weight and shown in Fig. 8a–c. The qauntitative comparison between SMILES based and graph based models (MolMP and MolRNN) has been performed, and the results are summarized in Tables 1 and 2. We first analysed the model performance in terms of the rate of valid outputs and the rate of valid and novel outputs. It can be seen from the results that both MolRNN and MolMP outperform all SMILES based methods. It is also noted that changing α from 1.0 to 0.8 can significantly increase the rate of valid outputs for both MolMP and MolRNN. Further decreasing α produces only marginal effect. The high validity of output structures by graph-based model is not surprising as the generation of SMILES poses much stricter rules to the output compared with the generation of molecular graphs.

Figure 8d, e summarize respectively the common mistakes made by SMILES-based and graph-based model during generation. Results in Fig. 8d show that the most common cause of invalid output for SMILES based models is grammar mistakes, such as unclosed parentheses or unpaired ring numberings. But for the graph-based model, the majority of invalid output is caused by broken aromaticity, as demonstrated in Fig. 8f. This is likely a result of stepwise decoding pattern of graph-based models, as the decoder can only see part of the aromatic structure during generation, while the determination of aromaticity requires the information of the entire ring. It is also observed that mistakes related to atom valance are relatively minor, meaning that those rules are easy to learn using graph convolution.

Graph-based methods also have the advantage of giving highly interpretable outputs compared with SMILES. This means that a large portion of invalid outputs can be easily corrected if necessary. For example, broken aromaticity can be restored by literately refining the number explicit hydrogens of aromatic atoms, and unclosed aromatic rings can be corrected simply by connecting the two ends using a new aromatic bond. Though possible, those corrections may introduce additional bias to the output samples depending on the implementation, thus not adopted in the subsequent tasks.

Next, we investigate the ability for the generators to learn the distribution of molecular properties, as demonstrated in Table 2. Results have shown that MolRNN gives the best performance in DKL and DJS for molecular weight (MW) and QED, while SMILES GRU2 gives the best performance for LogP. For MolMP, although it is able to outperform SMILES GRU1 in the rate of valid outputs, it fails to give better performance in DKL and DJS. This observation suggest that the molecule level recurrent unit in MolRNN can significantly imporved the ability for the model to learn information about the data distribution.

When it comes to the influence of α to DKL and DJS, it is found that changing α from 1.0 to 0.8 can significantly improve the perforamnce of MolMP and MolRNN for all molecular properties. Further decreasing α to 0.6 will have different effect for MolMP and MolRNN. For MolMP, this will hurt the overall performance of DKL and DJS, while for MolRNN, this will inprove the performance for molecular weight, but will significantly decrease the performance of LogP. Overall, α=0.8 will be a better choise for MolMP, and α=0.6 will be more suited for MolRNN.

Generally, MolRNN have showed significant advantages among all generative mdoels considered. In the subsequent evaluation of conditonal generative models, the best performing graph based model (MolRNN) and the best performing SMILES based model (SMILES GRU2) are implemented as conditonal models and are compared among all tasks.

A visualized demonstration of model outputs. a–c. Output samples by MolRNN. Results are grouped by molecular weight (a MW < 300, b 300 ≤ MW < 500, c MW ≥ 500); d, e Common mistakes made by SMILES based model and graph based model respectively; f Examples of broken aromaticity occurred during graph generation

Comparison between SMILES based and graph-based generators in output validity

Comparison between SMILES based and graph-based generators in DKL(×10-3) and DJS(×10-3)

## Section: Results and discussion › Scaffold-based generation

In the first task, conditional generative models are trained to produce molecules based on given scaffolds. To illustrate the result, scaffold 1, extracted from the antihypertensive drug Candesartan (see Fig. 9a), is used as an example, along with several related scaffolds (scaffold 2–4) derived from scaffold 1 (Fig. 9a). Conditional codes c are constructed for each type of scaffold, and output structures are produced according to the corresponding code.

Results for both the SMILES based and graph based conditional generator are given in Table 3. In terms of output validity, graph based model is able to produce a higher fraction of valid outputs for scaffolds 1–4, compared with SMILES based methods, which is similar to the results of unconditional models

In terms of the rate of correctly generated outputs (Rc), although the models are unable to achieve 100% correctness, the Rc results are significantly higher than Rc0, offering high enrichment rate over random. Both graph based and SMILES based model are able to achieve EORc>1000 for scaffold 1–3 as well as EORc>100 for scaffold 4, showing promising ability for the model to produce enriched output according to the given scaffold query. By comparing the result of Rc between the two type of architectures, it is found that graph based model have a higher performance for scaffold 3, while SMILES based method have a higher performance for scaffold 2. The two model have similar performance for scaffold 1 and scaffold 4.

The structural diversity of the output samples is also evaluated for each model. Both graph based and SMILES based methods have resulted in a slightly lower output diversity Ic compared with the natural diversity Ic0. For scaffold 2, the graph based method have better performance compared with SMILES based method, while for scaffold 4, the SMILES based methods yields better result. For scaffold 1 and 3, the difference is not significant between graph based and SMILES based method.

A comparison between conditional generative model and RL based approach is performed, using scaffold 4 as example. We set σ=20, and formulate the score function Sc(x) as follows:

The result is summarized in Table 4. It is easily observed that all RL based approaches, including Naive RL, RL + Prior and REINVENT, are capable of achieving near perfect result on Rc. However, in terms of output diversity, the RL based methods yields worse performance compared with conditional generative models. Among them, Naive RL result in the lowest output diversity of 0.468, followed by the RL + Prior, whose output diversity is 0.55. REINVENT results in a much higher output diversity of 0.750, but is still lower than that of conditional generative models.

The results above shows that conditional generators and RL based methods have opposite performance on Rc and Ic. This is mainly caused by the fact that the two methods actually operate on different objectives. The former, which is trained under maximum likelihood estimation (MLE), optimizes DKL(p(x|c)||qθ) (the proof is given in Additional file 1: Supplementary Text 5). During training, conditional generative model are encouraged to cover all modes in the data distribution, but are not punish for malicious modes, and therefore result in lower Rc.

The RL based approach, however, optimizes a completely different objective. It can be proved that maximizing Eq. 18 is equivalent to minimizing the reviersed KL divergence DKL(qθ||p(x|c)). In fact, if the score σS(x) is formulated as logp(c|x), which is the log-likelihood for the molecule x to satisfy the requirement c, we can obtain the following relationship between G(x) ans DKL:

The derivation is given in Additional file 1: Supplementary Text 6. This objective will force the model to comply with the given condition c, but may result in potential mode collapse, and therefore lower output diversity. In short, conditonal generative model and RL based methods each emphasizes different aspect of the molecule distribution, and future research may explore the possibility to combine those methods.

Several generated samples by graph based model are given for each scaffold in Fig. 9b. Recall that the outputs given scaffold s should contain two type of molecules: (1) molecules with s as its Bemis–Murcko scaffold and (2) molecule whose Bemis–Murcko scaffold contains s but does not reside inside S. Both types are observed for scaffold 1–4 as shown in Fig. 9b. By further investigating the generated samples, it is observed that the model seems to have learnt about the side chains characteristics each scaffold. For example, samples generated from scaffold 1–3 usually have their substitutions occur at restricted positions, and frequently contains a long aliphatic side chain. Interestingly, this actually reflects the structural activity relationship (SAR) for angiotensin II (Ang II) receptor antagonists [55]. In fact, scaffold 1–3 have long been treated as a privileged structure against Ang II receptors [28], and as a result, molecules with scaffold 1–3 are largely biased to those who matches the SAR rules for the target. When trained with the biased dataset, the model can memorize the underlying structural activity relationship as a byproduct of scaffold based learning. This characteristic is beneficial for the generation of libraries containing specified privileged structures.

Results of scaffold based generation. a Candesartan and the extracted scaffolds (scaffold 1–4); b Output samples based on scaffold 1–4

Performance of graph based and SMILES based model on scaffold diversification tasks

The comparison between condtional generative models RL based models in the task of generating molecules containing scaffold 4

## Section: Results and discussion › Generation based on drug-likeness and synthetic accessibility

In this task, the generative model is used to produce molecules according to the requirement on drug-likeness and synthetic accessibility. The conditional code is specified as c=(QED,SA). In the first experiments, the models are required to generate molecules based on the following requirements expressed as subsets of conditional code space: C1=(0.84,1)×(0,1.9), C2=(0,0.27)×(0,2.5), C3=(0.84,1)×(3.4,+∞) and C4=(0,0.27)×(4.8,+∞).

The values are determined from the distribution of QED and SA in ChEMBL dataset (see Fig. 10a) using the 90 and 10% quantile. The conditions are illustrated in Fig. 10d. The four sets represent four classes of molecules respectively and the first class C1, which contains structures with high drug-likeness and high synthetic accessibility, defines the set of compounds that are most important for drug design.

Quantitative evaluations of graph based and SMILES based models are demonstrated in Table 5. Again, under all conditions (C1∼C4), the graph based model is able to outperform SMILES based model on the rate of valid outputs. The difference is most significant for conditions specifying low synthetic accessibility (that is, high SAscore, which is given by C3 and C4). This observation suggests that SMILES based model have difficulty in generating complex structures while maintaining the structural validity.

The graph based model also provides better performance in terms of RC and EORC as shown in Table 5. It is noted that both graph and SMILES based models result in comparatively low RC and EORC on condition C3, which corresponds to molecules with high drug-likeness and low synthetic accessibility. However, this result is relatively easy to understand. Since the definition of drug-likeness contains the requriement for high synthetic accessibility, therefore finding molecules with high QED score and high SAscore is in itself a difficult task. For other conditions, the RC results for both models varies from 50 to 70%. Those values are lower compared with scaffold based task, but nonetheless showing enrichments for all conditions over the distribution from ChEMBL. The diversity of generated samples are also reported.Different from the performance in %valid and Rc, SMILES based method is able to produce outputs with slighly higher diversity compared with graph based method. The different is statistically significant for tasks C1 and C3.

We compared conditional generative model with RL based methods using C1 as example. Similar to “Scaffold-Based Generation”, we set σ to 20, and use the discrete score function SC(x) defined in Eq. 27. The results are summarized in Table 6. Overall, the performance of RL based methods are similar to that in the scaffold-based task. All RL methods are able to achieve high level of Rc, but with lower output diversity.

For a visualized demonstration, the distributions of QED and SA score for the output samples from graph based generator are shown in Fig. 11. Random samples are also chosen for each class and are visualization in Fig. 12. The structural features for the output samples are mostly consistent with the predefined conditions, with small and simple molecules for C1 and highly complex molecules for C4.

Note that conditional models also support generation based on a given point of QED and SAscore. This is demonstrated visually using graph based conditional model. Now, the molecule generation process is conditioned on a single points of conditional code c. Here, we use four different conditions as specified as follows: c1=(0.84,1.9), c2=(0.27,2.5), c3=(0.84,3.8) and c4=(0.27,4.8). Those conditons are also demonstrated in Fig. 10.

The distributions of QED and SAscore for the output molecules by graph based model are shown in Fig. 10e–h. Results show that, although the requirement is specified using a single value of QED and SAscore, the distribution of the two properties for output samples are relatively dispersed. This result is not surprising since the QED and SAscore score are relatively abstract descriptions of structural features of molecules, and a small modification of molecule structure may lead to significant changes in QED and SA scores. Nonetheless, it can be found that the generated samples are enriched around the corresponding code c. It is also observed that the distribution of SAscore is more concentrated than that of QED. This is probably because that SAscore is direct measurement of molecular graph complexity, which may be easier to model for the graph based generator. In contrast, QED is a more abstract descriptor related to various molecular properties.

Location of C1∼C4 and c1∼c4. a Distribution of QED and SAscore in the ChEMBL dataset; b Location of input conditions (C1∼C4 and c1∼c4)

Performance of graph based and SMILES based model on property based generation tasks

The comparison between condtional generative models RL based models in the task of generating molecules satisfying condition C1 (that is, QED > 0.84 and SA score < 1.9)

Distribution of QED and SAscore for generated results: the upper row indicates distribution of QED and SAscore of molecules generated under conditions C1, C2 , C3 and C4. The conditions C1∼C4 are shown as intervals represented by error bar. The lower row indicates distribution of QED and SAscore of molecules generated using single point conditions (c1, c2, c3 and c4). The conditions c1∼c4 are represented as dots in the plot

Samples generated under the four predefined conditions on drug-likeness and synthetic accessibility score

## Section: Results and discussion › Generating dual inhibitors for JNK3 and GSK-3β

In this task, the models are used to generate dual inhibitor for JNK3 and GSK-3β. A predictive model is first used to label the conditional code for ChEMBL dataset, and the conditional graph generator is trained on the labeled training set. The two predictors yield good results in general, with AUC = 0.983 for JNK3 and AUC = 0.984 for GSK-3β. The ROC curves for the two models are show in Additional file 2: Figure S4.

Results for both the SMILES based and graph based conditional generator are given in Table 7. In terms of output validity, graph based model outperforms SMILES based model in generating GSK-3β selective and JNK3 selective compounds, but for the generation of dual inhibitors, SMILES based model achieves better performance. In terms of Rc and EORc, SMILES based model is able to obtain better performance in generating dual inhibitors and selective inhibitors against GSK-3β, while the graph based model performs better in the task of generating JNK3 selective inhibitors.The Kcc′ matrices for graph based and SMILES based model are shown in Table 8. For both graph based and SMILES based model, it is noted that when generating compounds that is active to both JNK3 and GSK-3β, there is a significant amount of outputs falling into the category of GSK-3β positive and JNK3 negative. Nonetheless, in terms of the enrichment over random EORc, the two models are able to achieve high performance for all selectivity combinations. Note that selective inhibitors for GSK-3β are relatively enriched in ChEMBL database, according to the result of the predictor. In comparison, the selective inhibitors against JNK3 and the dual inhibitor for both JNK3 and GSK-3β are much rarer. However, the model is still able to achieve significant enrichment for the two types of selectivity. The result shows potential application for target combinations that have low data enrichment rate.

Similar to previous tasks, a comparison with RL based methods is performed. Here, we mainly focus on the task to generate joint inhibitors to JNK3 and GSK-3β. In terms of the design of score function, we have employed Sc(x) similar to that used in previous tasks (Eq. 27). The value of σ is set to 20 for Sd. The results are summarized in Table 9. Note that result for RL + Prior is omited, since in this task, we found that it tends to collapse quickly to a single molecule that could not provide meaningful result. The performance of Naive RL and REINVENT is similar to that reported in previous sections. Both RL based methods achieves high value of Rc, but have much lower output diversity.

To better demonstrate the structural distribution of the generated samples, visualization based on t-SNE [56]is performed using the ECFP6 fingerprint. The generated samples under different selectivity specifications and molecules in the test set for each target are projected into two-dimensional embeddings and are shown in Fig. 13a–d. According to the result, it is shown that the conditional generator tends to produce molecules near the test set samples, which is consistent with observations based on other methods [12]. It is also observed that molecules generated under different selectivity condition occupy distinct region of chemical space.

For each selectivity condition, several molecules are sampled using the model and are demonstrated in Fig. 14a–c. By investigating the generated structures in detail, it can be observed that the model tends to generate samples containing well-established scaffold for the corresponding target. For JNK3, structures such as diaminopurines [57] and triazolones [58], which have been frequently used in the design of JNK inhibitors, show high occurrence in the generated samples. The observation is the same for GSK-3β, with example like 2,3-bis-arylmaleimides, a class of widely studied inhibitors of GSK-3 [59]. On the other hand, aminopyrimidines are frequently shown in the outputs of all selectivity conditions, but they are more enriched in generated dual inhibitors. Those observations show good interpretability of the outputs, and indicate that the structural features of generated samples are in line with the existing knowledge about the two targets.

Finally, we report the percentage of reproduced samples from the test set for each target. From the result, 10.3% of molecules are reproduced for JNK3 and, 6.0% of molecules are reproduced for GSK-3β. Note that molecules in the test sets for each targets have been excluded from the ChEMBL training set in this task, which means that the method is capable of generating molecules that have been confirmed to be positive, without seeing them in the training set of predictive model and conditional generative model.

Several recovered actives are shown in Fig. 14d–e. Those molecules show relatively high diversity in structure, indicating that the model does not collapse to a subgroup of active compounds. A quantitative evaluation is performed using the internal diversity, and the result shows that the recovered GSK-3β inhibitors have a internal diversity of 0.819, while the recovered JNK3 inhibitors have a internal diversity of 0.761. Those values, although slighly lower, are relatively close to the diversity of test set molecules, which are 0.867 for GSK-3β and 0.852 for JNK3.

Performance of graph based and SMILES based model on inhibitor generation, results are reported as Mean±SD

The Kcc′ matrix for kinase inhibitor generation task, the diagnal elements Kcc=Rc are omitted since they have been reported in Table 7

The comparison between condtional generative models RL based models in the task of generating dual inhibitors against GSK-3β and JNK3

Visualizing the distribution of generated samples for each target. The figure shows the t-SNE visualization of: a molecules form test set of GSK-3β and samples conditioned on JNK3(−), GSK-3β(+), b molecules from test set of GSK-3β and samples conditioned on JNK3(+), GSK-3β(+). c Molecules from test set of JNK3 and samples conditioned on JNK3(+), GSK-3β(−), d molecules from test set of JNK3 and samples conditioned on JNK3(+), GSK-3β(+)

Samples conditioned on different selectivity conditions. a–c Generated samples under different condition of selectivity (a for dual inhibitors, b for GSK-3β selective inhibitors, and c for JNK3 selective inhibitors); d, e Some recovered actives of JNK3 and GSK-3β respectively. a Generated dual inhibitors. b Generated GSK-3β selective inhibiors. c Generated JNK3 selective inhibiors. d Recovered JNK3 inhibitors. e Recovered GSK-3β inhibitors

## Section: Conclusions

In this work, a new framework for de novo molecular design is proposed based on graph generative model and is applied to solve different drug design problems. The graph generator is designed to be more fitted to the tasks of molecule generation using a simple decoding scheme and a graph convolutional architecture that is less computationally expensive. Furthermore, a more flexible way of introducing decoding invariance is also suggested. The method is trained using molecules in ChEMBL dataset and has demonstrated better performance compared with SMILES based methods, especially in terms of the rate of valid outputs.

To generate molecules with specific requirements, we propose to use conditional generative model, which offers high flexibility and do not require reinforcement learning. The model is applied to solve problems that is highly related to drug design, such as generating molecules based on a given scaffold, generating molecules with good drug-likeness and synthetic accessibility and the generation of molecules with specific profile against multiple targets. Results have showed that the conditional generative model can effectively produce enriched outputs based on the given requirements. A comparison with RL based method is performed, and results shows that although conditional generative model yields lower output accuracy, but it is capable of achieving higher output diversity.

This work can be extended in various aspects. First of all, the models used in this work completely ignores the stereochemistry information for molecules. In fact, stereochemistry is extremely important in the process of drug development, and introducing this information helps to improve the applicability of existing models. Secondly, for the target based generation, it will be much more helpful to jointly train the generator and the decoder, utilizing strategies such as semi-supervised learning [60, 61]. Finally, besides the three tasks experimented in this work, conditional graph generator can be used in many other scenarios. To summarize, the graph generative architecture proposed in this work gives promising result in various drug design tasks, and it is worthwhile to explore other potential applications using this method.

## Section: Additional files

Additional file 1. Containing additional information about the implementation details of experiments.

Additional file 2. Contianing supplementary figures.

## Section: Additional files

Additional file 1. Containing additional information about the implementation details of experiments.

Additional file 2. Contianing supplementary figures.

## Section: Author's contributions

YL formulated the concept and contributed to the implementation. YL wrote the manuscript, LZ and ZL reviewed and edited the manuscript. All authors read and approved the final manuscript.

## Section: Author's contributions › Acknowledgements

We would like to thank Xiaodong Dou for his help on the discussion of generated inhibitors of JNK3 and GSK3β. Thanks to Bo Yang who helped with the profiling of Additional file 1: Supplementary Text 8.

## Section: Author's contributions › Competing interests

The authors declare that they have no competing interests.

## Section: Author's contributions › Availability of data and materials

The materials supporing this article, including the source code, sampled molecules and pretrained models, are available at: https://github.com/kevinid/molecule_generator.

## Section: Author's contributions › Funding

This research was supported by the National Natural Science Foundation of China (Grant Nos. 81573273, 81673279 21572010 and 21772005), the National Major Scientific and Technological Special Project for “Significant New Drugs Development” (2018ZX09735001-003) and Beijing Natural Science Foundation (7172118).

## Section: Author's contributions › Ethics approval and consent to participate

Not applicable.

## Section: Author's contributions › Consent for publication

The authors declare no competing fnancial interests.

## Section: Author's contributions › Publisher’s Note

Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

## Section: Contributor Information

Liangren Zhang, Email: liangren@bjmu.edu.cn.

Zhenming Liu, Email: zmliu@bjmu.edu.cn.

## Section: Associated Data

Additional file 1. Containing additional information about the implementation details of experiments.

Additional file 2. Contianing supplementary figures.

## Section: Associated Data › Supplementary Materials

Additional file 1. Containing additional information about the implementation details of experiments.

Additional file 2. Contianing supplementary figures.

## Section: Associated Data › Data Availability Statement

The materials supporing this article, including the source code, sampled molecules and pretrained models, are available at: https://github.com/kevinid/molecule_generator.


---

# The rise of deep learning in drug discovery

- **Authors:** Hongming Chen, Ola Engkvist, Yinhai Wang, Marcus Olivecrona, Thomas Blaschke
- **Issuer:** Drug Discovery Today
- **Type:** Scientific article
- **Published:** 2018-01-31
- **DOI:** 10.1016/j.drudis.2018.01.039
- **Source:** https://doi.org/10.1016/j.drudis.2018.01.039
- **Licence:** CC-BY

## Section: Abstract

Over the past decade, deep learning has achieved remarkable success in various artificial intelligence research areas. Evolved from the previous research on artificial neural networks, this technology has shown superior performance to other machine learning algorithms in areas such as image and voice recognition, natural language processing, among others. The first wave of applications of deep learning in pharmaceutical research has emerged in recent years, and its utility has gone beyond bioactivity predictions and has shown promise in addressing diverse problems in drug discovery. Examples will be discussed covering bioactivity prediction, de novo molecular design, synthesis prediction and biological image analysis.


---

# High-Level Expert Group on AI: ethics guidelines for trustworthy AI

- **Issuer:** European Commission
- **Type:** Guideline
- **Published:** 2019-04-08
- **Language:** en
- **Source:** https://digital-strategy.ec.europa.eu/en/library/ethics-guidelines-trustworthy-ai
- **Licence:** EU-reuse

## Section: Text

According to the Guidelines, trustworthy AI should be:
(1) lawful - respecting all applicable laws and regulations
(2) ethical - respecting ethical principles and values
(3) robust - both from a technical perspective while taking into account its social environment

## Section: Download the Guidelines in your language below:

BG | CS | DE | DA | EL | EN | ES | ET | FI | FR | HR | HU | IT | LT | LV | MT | NL | PL | PT | RO | SK | SL | SV
The Guidelines put forward a set of 7 key requirements that AI systems should meet in order to be deemed trustworthy. A specific assessment list aims to help verify the application of each of the key requirements:
- Human agency and oversight: AI systems should empower human beings, allowing them to make informed decisions and fostering their fundamental rights. At the same time, proper oversight mechanisms need to be ensured, which can be achieved through human-in-the-loop, human-on-the-loop, and human-in-command approaches
- Technical Robustness and safety: AI systems need to be resilient and secure. They need to be safe, ensuring a fall back plan in case something goes wrong, as well as being accurate, reliable and reproducible. That is the only way to ensure that also unintentional harm can be minimized and prevented.
- Privacy and data governance: besides ensuring full respect for privacy and data protection, adequate data governance mechanisms must also be ensured, taking into account the quality and integrity of the data, and ensuring legitimised access to data.
- Transparency: the data, system and AI business models should be transparent. Traceability mechanisms can help achieving this. Moreover, AI systems and their decisions should be explained in a manner adapted to the stakeholder concerned. Humans need to be aware that they are interacting with an AI system, and must be informed of the system’s capabilities and limitations.
- Diversity, non-discrimination and fairness: Unfair bias must be avoided, as it could could have multiple negative implications, from the marginalization of vulnerable groups, to the exacerbation of prejudice and discrimination. Fostering diversity, AI systems should be accessible to all, regardless of any disability, and involve relevant stakeholders throughout their entire life circle.
- Societal and environmental well-being: AI systems should benefit all human beings, including future generations. It must hence be ensured that they are sustainable and environmentally friendly. Moreover, they should take into account the environment, including other living beings, and their social and societal impact should be carefully considered.
- Accountability: Mechanisms should be put in place to ensure responsibility and accountability for AI systems and their outcomes. Auditability, which enables the assessment of algorithms, data and design processes plays a key role therein, especially in critical applications. Moreover, adequate an accessible redress should be ensured.
The AI HLEG has also prepared a document which elaborates on a Definition of Artificial Intelligence used for the purpose of the Guidelines.

## Section: Download the Definition of AI in your language below:

BG | CS | DE | DA | EL | EN | ES | ET | FI | FR | HR | HU | IT | LT | LV | MT | NL | PL | PT | RO | SK | SL | SV

## Section: Piloting Process

The document also provides an assessment list that operationalises the key requirements and offers guidance to implement them in practice. Starting from the 26th of June, this assessment list underwent a piloting process, to which all stakeholders were invited to test the assessment list and provide practical feedback on how it can be improved.
Feedback was received through different tracks:
- An open survey or “quantitative analysis” sent to all those who registered to the piloting
- In-depth interviews with a number of representative organisations to gather more detailed feedback for different sectors
- Continuous possibility to upload feedback and best practices through the European AI Alliance

## Section: The piloting phase closed on 1 December 2019

Based on the feedback received, the AI HLEG presented the final Assessment List for Trustworthy AI (ALTAI) in July 2020. ALTAI is practical tool that translates the Ethics Guidelines into an accessible and dynamic (self-assessment) checklist. The checklist can be used by developers and deployers of AI who want to implement the key requirements in practice. This new list is available as a prototype web based tool and in PDF format.

## Section: Last update

31 January 2024


---

# Improving the Accuracy of Protein-Ligand Binding Affinity Prediction by Deep Learning Models: Benchmark and Model

- **Authors:** Mohammad Rezaei, Yanjun Li, Xiaolin Li, Chenglong Li
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2019-09-23
- **DOI:** 10.26434/chemrxiv.9866912.v1
- **Source:** https://doi.org/10.26434/chemrxiv.9866912.v1
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Introduction: The ability to discriminate among ligands binding to the same protein target in terms of their relative binding affinity lies at the heart of structure-based drug design. Any improvement in the accuracy and reliability of binding affinity prediction methods decreases the discrepancy between experimental and computational results. Objectives: The primary objectives were to find the most relevant features affecting binding affinity prediction, least use of manual feature engineering, and improving the reliability of binding affinity prediction using efficient deep learning models by tuning the model hyperparameters. Methods: The binding site of target proteins was represented as a grid box around their bound ligand. Both binary and distance-dependent occupancies were examined for how an atom affects its neighbor voxels in this grid. A combination of different features including ANOLEA, ligand elements, and Arpeggio atom types were used to represent the input. An efficient convolutional neural network (CNN) architecture, DeepAtom, was developed, trained and tested on the PDBbind v2016 dataset. Additionally an extended benchmark dataset was compiled to train and evaluate the models. Results: The best DeepAtom model showed an improved accuracy in the binding affinity prediction on PDBbind core subset (Pearson’s R=0.83) and is better than the recent state-of-the-art models in this field. In addition when the DeepAtom model was trained on our proposed benchmark dataset, it yields higher correlation compared to the baseline which confirms the value of our model. Conclusions: The promising results for the predicted binding affinities is expected to pave the way for embedding deep learning models in virtual screening and rational drug design fields.


---

# A Bayesian machine learning approach for drug target identification using diverse data types

- **Authors:** Neel S. Madhukar, Prashant K. Khade, Linda Huang, Kaitlyn M. Gayvert, Giuseppe Galletti, Martin Stogniew, Joshua E. Allen, Paraskevi Giannakakou, Olivier Elemento
- **Issuer:** Nature Communications
- **Type:** Scientific article
- **Published:** 2019-11-19
- **DOI:** 10.1038/s41467-019-12928-6
- **Source:** https://doi.org/10.1038/s41467-019-12928-6
- **Licence:** CC-BY

## Section: Abstract

AbstractDrug target identification is a crucial step in development, yet is also among the most complex. To address this, we develop BANDIT, a Bayesian machine-learning approach that integrates multiple data types to predict drug binding targets. Integrating public data, BANDIT benchmarked a ~90% accuracy on 2000+ small molecules. Applied to 14,000+ compounds without known targets, BANDIT generated ~4,000 previously unknown molecule-target predictions. From this set we validate 14 novel microtubule inhibitors, including 3 with activity on resistant cancer cells. We applied BANDIT to ONC201—an anti-cancer compound in clinical development whose target had remained elusive. We identified and validated DRD2 as ONC201’s target, and this information is now being used for precise clinical trial design. Finally, BANDIT identifies connections between different drug classes, elucidating previously unexplained clinical observations and suggesting new drug repositioning opportunities. Overall, BANDIT represents an efficient and accurate platform to accelerate drug discovery and direct clinical application.Subject terms: Data integration, Machine learning, Target identification

## Section: Introduction

It typically takes 15 years and 2.6 billion dollars to go from a small molecule in the lab to an approved drug1–3, and for natural products and phenotypic screen derived small molecules, one of the greatest bottlenecks is identifying the targets of any candidate molecules2,4. Proper understanding of binding targets can position drugs for ideal indications and patients, allow for better analog design, and explain observed adverse events. There exist a number of experimental approaches for target identification ranging from affinity pull-downs to genome-wide knockdown screens4,5, but these approaches are labor, resource, and time intensive, not to mention failure prone.

Computational approaches have the potential to substantially reduce the work and resources needed for drug target identification. Traditionally, ligand-based approaches take known binding targets for a given drug and attempt to find other drugs or proteins that are sufficiently similar6. However, to achieve high predictive power they require a large input of known binding partners for each tested drug, and therefore can only be used on drugs which have prior comprehensive target information6,7. Molecular docking, another commonly used approach, uses simulations of small molecules interacting with proteins to model if and how a drug may bind a given protein8,9. However, this approach requires significant computational power and complex 3D structures for each queried protein—data that is often unavailable.

Past work has used posttreatment gene expression changes and side effects to predict drugs new mechanisms for a given compound10–14. However, the majority of approaches rely on structural similarity between a queried compound and a database of drugs with known targets to predict new targets for the queried compound15–17. Yet, by relying on only a single data type these methods are more susceptible to data-specific noise and suffer from limited utility and accuracy. In addition, as new data types become more accessible and available, we expect single data-type methods to become less utilized by researchers.

Recently we have seen more methods emerging that attempt to integrate multiple different data types within a similarity based or data-driven framework18–21. However these approaches still suffer from a few limitations:

To overcome these limitations, we introduce BANDIT, a drug-target prediction platform. BANDIT uses a Bayesian approach to integrate a number of diverse data types in an unbiased manner and provides a platform that allows for simple integration of new datatypes as they become available. Additionally, by integrating multiple different data types BANDIT is not reliant on any one experiment for its predictions and can achieve greater predictive power compared to single data type methods. Tested on ~2000 different compounds, BANDIT achieves a high accuracy at identifying shared target interactions, uncovers novel targets for the treatment of cancer, and can be used to quickly pinpoint potential therapeutics with novel mechanisms of action to accelerate drug development.

## Section: Results

BANDIT exploits the individual predictive powers of each data type. a Density plots showing how various different similarity scores correlate with one another, with darker area corresponding to a higher density of values. R2 and P value were calculated using a pearson correlation. b Distributions of similarity scores across two sets—drug pairs known to share a target and those with no known shared targets. P values and D statistics were calculated using the Kolmogorov–Smirnov test. c Schematic of BANDIT’s method of integrating multiple data types to predict shared target drug pairs

BANDIT can accurately predict shared targets and specific target interactions. a Area under the receiver-operating curve for different sets of data types. SE = Side effects; C = CMap; N = NCI60; B = Bioassays; S = Structure. b Ratio of true positives to false positives at different likelihood ratio cutoffs. c Schematic of the BANDIT voting schematic for predicting specific target interactions. d Accuracy level of BANDIT’s voting algorithm at various likelihood ratio cutoffs. e Schematic of two proposed operating scenarios for BANDIT

Microtubules are a correct target of the newly identified small molecules. Effect of various compounds (1 μM) on the microtubule integrity of MDA-MB-231 cells after 6 h of treatment. a Control with DMSO (Scale bar: 5 μm), b Vinblastine as a positive control, c Compound #16, d Compound #15, e Compound #24 f Compound #2. g Dose dependent effect of Compound #12 and h Compound #13. i Box plot showing the % tubulin in the pellet compared to the supernatant for depolymerizing drugs at 1 and 10 μM. The median is denoted by the center line and the min/max are represented by the whiskers. Each individual replicate is represented by a point in the box plot

BANDIT predicted small molecules can act on resistant cells. Effect of various compounds on the microtubule integrity of 1A9-ERB cells after 6 h of treatment: a Control with DMSO (Scale bar: 5 μm), 100 nM of b Eribulin and c Vinblastine, and 1 μM of d Compound #15, e Compound #16 and f Compound #24

ONC201 is a selective DRD2 antagonist. a BANDIT target predictions for ONC201. Connections between ONC201 and known drugs are weighted based on the likelihood ratio and predicted targets are sized based on the prediction strength. b Antagonism of ligand-stimulated dopamine receptors by ONC201. c Schild analysis of DRD2L antagonism by ONC201 using arrestin recruitment or d cAMP modulation reporters. Error bars represent 1 standard deviation

BANDIT can predict specific mechanisms of action and connections between drug classes. a Hierarchical clustering of drugs known to target microtubules and b drugs known to target protein kinases. c Network of drugs based on shared target interactions. Drugs are colored based on their most prevalent ATC code. Three specific clusters corresponding to beta-blockers and Parkinson’s medications, anti-retrovirals and statins, and opioids and antimicrotubule drugs are highlighted

## Section: Results › An integrative approach leads to an increase in accuracy

In the age of Big Data there has been an explosion of techniques that permit genomic, chemical, clinical, and pharmacological measurements to characterize a small molecule’s mechanism. Many such measurements are either already published or are reasonably straightforward to perform. We hypothesized that integrating the multiple pieces of evidence provided by each data type into a cohesive prediction framework would dramatically improve target predictions. To test this hypothesis, we developed BANDIT: a Bayesian ANalysis to determine Drug Interaction Targets. BANDIT integrates over 20,000,000 data points from six distinct data types—drug efficacies22, post-treatment transcriptional responses10,11, drug structures23,24, reported adverse effects25, bioassay results23,24, and known targets26,27—to predict drug–target interactions. This underlying database contains information on approximately 2000 different drugs with 1670 different known targets and over 100,000 unique orphan compounds (compounds with no known targets).

For each data type we calculate a similarity score for all drug pairs with known targets. Since each dataset uses a distinct reporting metric, the similarity calculation was specific to the data type being considered (Supplementary Fig. 1; “Methods”). Previous approaches have argued that high similarity in one feature indicates high similarity in others, implying that only one or two data types are sufficient for target prediction since others can be inferred28. However, using our expanded database, we found little overall correlation across different similarity scores (Fig. 1a; Supplementary Fig. 2). These results suggest that each data type is measuring a distinct aspect of a molecule’s activity and further supported our hypothesis that integrating multiple data types could significantly improve target prediction accuracy.

We next separated drug pairs into those that shared at least one known target (~3% of all pairs) and pairs with no known shared targets. We applied a Kolmogorov–Smirnov test to each similarity score and used the associated D statistic to calculate the degree a given data type could separate out drug pairs that shared targets (Fig. 1b). We found that all features were able to significantly separate the two classes (P < 2e−16), and structural similarity was found to be the most discriminative among all features evaluated (DStructure = 0.39). In addition, we discovered that similarity across an unbiased set of bioassays and the relatively simple NCI-60 growth inhibition screen could strongly differentiate shared target drug pairs (DBioassay = 0.327 and DGI50 = 331), while, surprisingly13,14,29, transcriptional responses (DTResponse = 0.1) and reported adverse effects (DSideEffect = 0.14) were much weaker differentiators. This information not only identifies the strengths of each data type, but will also allow researchers to efficiently prioritize experiments when faced with limited resources.

For every drug pair, BANDIT converts each individual similarity score into a distinct likelihood ratio. These individual likelihood ratios are then combined to obtain a total likelihood ratio (TLR) that is proportional to the odds of two drugs sharing a target given all available evidence (Fig. 1c; “Methods”). We chose to use a likelihood ratio approach because the ability to integrate available data (including newly generated data types) without a drastic change in protocol and the underlying interpretability in identifying how individual features contribute to a given prediction. We calculated TLRs for all possible drug pairs with known targets and the output was evaluated using 5-fold cross validation. We observed an Area Under the Receiver Operating Curve (AUROC) of 0.89 demonstrating that BANDIT’s integrative approach can accurately identify drugs that share targets. To further test this, we compared the ROC curve and Precision-Recall curve of BANDIT to one where we randomly shuffled the likelihood values (representing what you would expect if BANDIT’s TLR had no predictive power), and saw an improvement compared to random in both tests (Supplementary Figs. 3, 4). We then recomputed the AUROC while varying the number of included data types and observed an overall increase in predictive power as we added new data types, regardless of the addition order (Fig. 2a, Supplementary Table 1). As expected, we observed that the variables that had the greatest increase in AUROC were the same variables that showed the greatest separation in the KS tests. This result verified the power of BANDIT’s Big Data approach and demonstrated how separate information sources can be combined to yield predictions more powerful than those obtained from any individual source (Supplementary Fig. 5). This was confirmed using the KS test where we saw that the TLR output could better separate shared target drug pairs than any individual similarity score with a drastic increase in performance when focusing on drug pairs with all 5 data types (DTLR = 0.69, Supplementary Fig. 6). Furthermore, we observed that BANDIT’s ratio of true to false positives continually increased as we raised the cutoff value, indicating that BANDIT can effectively pick out high quality shared-target predictions (Fig. 2b, Supplementary Fig. 7). In addition we found that BANDIT could pinpoint known shared target drugs better than many existing shared target prediction methods (“Methods”).

BANDIT exploits the individual predictive powers of each data type. a Density plots showing how various different similarity scores correlate with one another, with darker area corresponding to a higher density of values. R2 and P value were calculated using a pearson correlation. b Distributions of similarity scores across two sets—drug pairs known to share a target and those with no known shared targets. P values and D statistics were calculated using the Kolmogorov–Smirnov test. c Schematic of BANDIT’s method of integrating multiple data types to predict shared target drug pairs

BANDIT can accurately predict shared targets and specific target interactions. a Area under the receiver-operating curve for different sets of data types. SE = Side effects; C = CMap; N = NCI60; B = Bioassays; S = Structure. b Ratio of true positives to false positives at different likelihood ratio cutoffs. c Schematic of the BANDIT voting schematic for predicting specific target interactions. d Accuracy level of BANDIT’s voting algorithm at various likelihood ratio cutoffs. e Schematic of two proposed operating scenarios for BANDIT

## Section: Results › BANDIT accurately predicts specific target interactions

We next investigated how we could use BANDIT to replicate results from published experimental screens. Peterson et al.30 tested 178 known protein kinase inhibitors against a panel of 300 different kinases and measured the level of inhibition (in terms of percent remaining kinase activity) for each inhibitor–kinase pair. We examined all orphan molecules—molecules with no known targets—in both the Peterson kinase database and BANDIT’s, and, used BANDIT to predict potential kinases targets for each orphan molecule (“Methods”). We observed that the kinase targets BANDIT predicted for each orphan molecule had higher levels of reported inhibition in the Peterson dataset than non-predictions (p < 1e−5; Supplementary Fig. 8). This result highlights how we could use BANDIT to guide experimental screens while minimizing operational costs.

Moving forward from shared-target predictions, we examined whether for a given drug BANDIT could be used to predict a specific binding target. We hypothesized that if a protein appeared as a known target in a large number of shared target predictions, then it is likely a target for the tested orphan molecule. To test this hypothesis, we developed a voting algorithm to predict specific targets for each orphan small molecule by identifying recurring targets (Fig. 2c, “Methods”). We applied our voting method to all drugs in our database with known targets and observed the accuracy level—measured by whether BANDIT correctly identified a known drug target—steadily increased as we raised the TLR cutoff for a shared target prediction before reaching an overall accuracy of ~90% (Fig. 2d). This demonstrated that BANDIT could be used to accurately identify specific targets for a diverse set of small molecules.

We then used BANDIT to predict novel targets for 14,000+ small molecules with no known targets or mechanisms of action in our database. Each of these molecules had data available in at least three of the five data types considered by BANDIT. We confidently predicted targets for 4167 unique small molecules (30% of our original set), with predictions spanning over 560 distinct protein targets. By setting a higher TLR cutoff for predictions and requiring a higher number of votes for any predicted targets, we further narrowed this list to 720 high confidence target predictions. Based on this, we envisioned two main operating scenarios for BANDIT: (1) Using BANDIT in combination with a library of orphan small molecules to identify new small molecules targeting a specific protein and (2) to integrate BANDIT directly into the drug development pipeline to predict targets and guide experiments for drugs currently in development (Fig. 2e).

## Section: Results › Discovery of novel microtubule-targeting compounds

Beginning with the first operating scenario, we used BANDIT to identify novel ways to target microtubules. Antimicrotubule drugs make up one of the largest and most widely used classes of cancer chemotherapeutics, with tubulin being one of the most validated anticancer targets to date31–34. Interestingly, and unlike most classes of chemotherapy drugs or targeted-therapies in oncology, microtubule inhibitors are further sub-categorized as microtubule-stabilizing (e.g. taxanes) and microtubule-depolymerizing drugs (e.g. vinca alkaloids). Each class shifts the cellular equilibrium that normally exists between soluble tubulin dimers and microtubule polymers, towards microtubules (taxanes) or soluble tubulin (vinca alkaloids). Despite the clinical success of the entire class of microtubule inhibitors, the development of drug resistance—which is the number one cause of cancer mortality in metastatic patients—limits their clinical applicability35. Hence, the discovery of novel microtubule-targeting small molecules could significantly improve cancer therapy by identifying compounds with activity on refractory tumors. To this aim, we further focused our list of high confidence orphan-target predictions to small molecules predicted to target microtubules. To see how our novel predictions related to known microtubule-targeting therapeutics, we created a network of all known and predicted antimicrotubule small molecules with edges representing a predicted shared target interaction (Supplementary Fig. 9). Interestingly we found that the known microtubule-targeting agents tended to cluster together based on their distinct mechanism of action. For instance, we observed Paclitaxel clustering with Cabazitaxel and Docetaxel—all known microtubule-stabilizing drugs—while Colchicine clustered with other known microtubule-destabilizing drugs such as Podophyllotoxin. This is especially exciting since it demonstrates the potential for BANDIT to be used not only to identify a specific target for an orphan molecule but to differentiate between different modes of action on the same target.

From our list of top antimicrotubule drug predictions (TLR > 100) we obtained a set of 24 compounds with varying structures for experimental testing (“Methods”, Supplementary Table 2). We chose human breast cancer MDA-MB-231 cells for the validation experiments as microtubule-inhibitors (both stabilizing and destabilizing) are commonly used in the treatment of breast cancer patients. Cells were treated for 6 h with 1 and 10 μM of each small molecule, and the integrity of the microtubule cytoskeleton (assessed by confocal microscopy following tubulin immunofluorescence) was used as the bio-assay endpoint. Additionally, to identify any compounds that may have poor cellular permeability, we performed a crude-tubulin assay in which cell were lysed in the presence of 10 μM of each compound for 30 min before separating polymerized from soluble tubulin by centrifugation. Our results showed that 14 of the 24 orphan small molecules exhibited significant effects on microtubules (Fig. 3a–f, Supplementary Figs. 10–15, Supplementary Table 2), with 13 compounds showing success in both the cell-based and crude-tubulin assays, and one compound (#3) showing activity only in the crude-tubulin assay. Overall, this represents a much higher success rate (58%) than one would expect by chance (p < 2e−16, “Methods”). In addition, we found that only nine out of these confirmed 14 hits would have been predicted to bind microtubules by drug target prediction methods that relied only on compound structure16,17. To more accurately quantify the extent of drug–target engagement, we employed a second biochemical assay quantifying the effect that each small molecule exerted on the equilibrium between microtubule polymers and soluble tubulin, following 6 h of treatment (Supplementary Fig. 16). Our results confirmed and corroborated the microscopy results, further revealing that while several small molecules had maximal microtubule-inhibitory activity at the lowest dose (1⌠M) (Fig. 3c–f), others exhibited a dose-dependent effect on microtubule depolymerization (e.g. compounds #12, #13), further establishing microtubules as their bona-fide target (Fig. 3g–i). Taken together, these experiments confirmed the predicted targets and mechanism of action for the majority of the newly identified microtubule inhibitors. While further testing will be needed before these small molecules can be used clinically, these results do demonstrate how BANDIT can be used on compound libraries to identify small molecules acting on specific targets.

To inform future clinical development for these newly identified microtubule inhibitors, we next tested their activity against resistance models. In the case of microtubule inhibitors, overcoming drug resistance is especially challenging as the mechanisms are often multifactorial. As previously demonstrated, BANDIT can accurately identify a set of structurally diverse small molecules that all bind a common target (in this case microtubules), therefore we next investigated whether any of our newly identified microtubule-depolymerizing small molecules could successfully act on tumors resistant to other known antimicrotubule drugs. Using the 1A9 human ovarian carcinoma cell line—which has previously been used successfully in selecting microtubule-inhibitor resistant clones and for high throughput small molecule screening,36–40—we created clones resistant to Eribulin mesylate, a microtubule depolymerizing drug that is FDA approved for the treatment of docetaxel-refractory breast cancer patients41,42 (Fig. 4a). Interestingly, recent clinical data demonstrated that fewer than 50% of breast cancer patients showed any detectable response after treatment with Eribulin, further highlighting the importance of finding new molecules that share the same validated target but are active against the large population of refractory patients43. Using 72-h growth inhibition assays we observed that the Eribulin-resistant 1A9 cells (1A9-ERB) were more than 7000 fold more resistant to Eribulin than the parental cells and exhibited cross-resistance to all classes of clinically used microtubule-depolymerizing drugs (Supplementary Table 3). To test whether the drug-resistance phenotype was due to impaired drug–target engagement, we treated parental and resistant cells for 6 h with 1 μM of Eribulin or each of the FDA-approved depolymerizing drugs. Consistent with their drug resistance phenotypes, our results showed lack of drug-induced microtubule depolymerization in 1A9-ERB cells in contrast to the complete depolymerization observed in the microtubule network of drug-sensitive 1A9 parental cells (Fig. 4b, c, Supplementary Figs. 17, 18). These on-target drug efficacy results are in agreement with the lack of anticancer activity revealed by the growth inhibition data, further highlighting the importance of discovering novel small molecules that could act on these refractory tumors. We tested the top four performing small molecules (#15, 16, 24, and 2) on the 1A9-ERB cells and found that three out of four compounds tested, were active against the 1A9-ERB cells and effectively depolymerized microtubules, as evidenced by the diffuse soluble tubulin staining following drug treatment (Fig. 4d–f, Supplementary Figs. 17, 18), in contrast to the fine and intricate microtubule network observed in untreated cells (Fig. 4). Compound #15, which was the most active of the four compounds, was tested using growth inhibition assays and was found to almost completely circumvent drug-resistance from 7050-fold observed with Eribulin down to 4-fold (Supplementary Table 3). While further in vitro and in vivo studies are required for the clinical development of these compounds, these results clearly demonstrate BANDIT’s utility in identifying lead small molecules with potential activity against drug resistance tumor models without the labor- and cost-intensive physical screening of thousands of small molecules. Compounds such as these could represent the next generation of clinically developed drugs reducing the need for extensive medicinal chemistry and structure–activity studies.

Microtubules are a correct target of the newly identified small molecules. Effect of various compounds (1 μM) on the microtubule integrity of MDA-MB-231 cells after 6 h of treatment. a Control with DMSO (Scale bar: 5 μm), b Vinblastine as a positive control, c Compound #16, d Compound #15, e Compound #24 f Compound #2. g Dose dependent effect of Compound #12 and h Compound #13. i Box plot showing the % tubulin in the pellet compared to the supernatant for depolymerizing drugs at 1 and 10 μM. The median is denoted by the center line and the min/max are represented by the whiskers. Each individual replicate is represented by a point in the box plot

BANDIT predicted small molecules can act on resistant cells. Effect of various compounds on the microtubule integrity of 1A9-ERB cells after 6 h of treatment: a Control with DMSO (Scale bar: 5 μm), 100 nM of b Eribulin and c Vinblastine, and 1 μM of d Compound #15, e Compound #16 and f Compound #24

## Section: Results › BANDIT uncovers ONC201’s selective antagonism of DRD2

Given BANDIT’s demonstrated capability to accurately identify specific targets for orphan small molecules, we next investigated how we could integrate BANDIT directly into the drug development pipeline and test its ability to predict targets for small molecules with promising clinical activity but without a specific target. Therefore we applied BANDIT to ONC201—an orphan small molecule discovered through a phenotypic screen for p53-independent inducers of TRAIL-mediated apoptosis—currently in multiple phase II clinical trials for select advanced cancers. Despite its promising preclinical and early clinical anticancer activity and its reported effects on a few signaling pathways, including Akt/ERK pathway44–46, a bona-fide target for this compound remained elusive.

To identify direct binding targets for ONC201, we used BANDIT to compute likelihood ratios between ONC201 and all drugs with known targets in BANDIT’s database. BANDIT’s top shared target prediction were between ONC201 and Oxiperomide and Thioridazine, both dopaminergic antagonists previously used the treatment of dyskinesias and schizophrenia respectively47–50. Interestingly, our voting analysis indicated that the most likely targets of ONC201 were dopamine receptors—specifically DRD2—and adrenergic receptor alpha (Fig. 5a), both of which are members of the G-protein coupled receptor (GPCR) superfamily. Further highlighting the novelty of these predictions, we found that DRD2 was not predicted as a target of ONC201 by other commonly used target prediction algorithms (such as SEA and SuperPred)15,16.

To test these predicted targets we performed in vitro profiling of GPCR activity using a hetereologous reporter assay for arrestin recruitment, which is a hallmark of GPCR activation51. Our results indicated that ONC201 selectively antagonized the D2-like (DRD2/3/4), but not D1-like (DRD1/5), subfamily of dopamine receptors (Fig. 5b; Supplementary Fig. 19A), with no observed antagonism of other GPCRs under the evaluated conditions. Among the DRD2 family, ONC201 antagonized both short and long isoforms of DRD2 and DRD3, with weaker potency for DRD4. Further characterization of ONC201-mediated antagonism of arrestin recruitment to DRD2L was assessed by a Gaddam/Schild EC50 shift analysis, which determined a dissociation constant of 2.9 μM for ONC201 that is equivalent to its effective dose in many human cancer cells (Fig. 5c). Confirmatory results were obtained for cAMP modulation in response to ONC201, which is another measure of DRD2L activation (Fig. 5d). The ability of dopamine to completely reverse the dose-dependent antagonism of up to 100 μM ONC201 suggests direct, competitive antagonism of DRD2L (Supplementary Fig. 19B, C). In agreement with the specificity of ONC201 for the target predicted by BANDIT, no significant interactions were identified between ONC201 and nuclear hormone receptors or the kinome (Supplementary Fig. 19D, E). Interestingly, a biologically inactive constitutional isomer of ONC20152 did not inhibit DRD2L, suggesting that antagonism of this receptor could be linked to its biological activity (Supplementary Fig. 19F). Additionally, since this discovery (first published in a preprint of this work)53 follow-up publications have further elucidated the role of DRD2 in the anticancer activity of ONC201 through knockout, efficacy based, and clinical studies54,55. In summary, these results showed that ONC201 selectively antagonizes the D2-like subfamily of dopamine receptors, which is an unconventional target for oncology drugs and further demonstrate BANDIT’s ability to act as a tool to advance drug development.

This unexpected discovery on the DRD2 being a direct-binding target for ONC201, has also led to the design and launch of a clinical trial of ONC201 in pheochromocytomas, owing to high levels of DRD2 expression in this rare tumor type (trial identifier: NCT03034200). Taken together, these results demonstrate the extreme potential of BANDIT to expedite drug development by using global, novel drug-target engagement predictions in combination with gene expression studies to enable the identification of select patient and indications groups more likely to benefit from a particular drug treatment.

ONC201 is a selective DRD2 antagonist. a BANDIT target predictions for ONC201. Connections between ONC201 and known drugs are weighted based on the likelihood ratio and predicted targets are sized based on the prediction strength. b Antagonism of ligand-stimulated dopamine receptors by ONC201. c Schild analysis of DRD2L antagonism by ONC201 using arrestin recruitment or d cAMP modulation reporters. Error bars represent 1 standard deviation

## Section: Results › BANDIT can identify specific drug mechanisms

Following validation that BANDIT could accurately determine the specific targets for small molecules, we then examined how it could also be used to understand the target binding mechanism, otherwise known as its mechanism of action (MoA). First we used BANDIT to test all known microtubule-targeting drugs, and created a hierarchical cluster based on their TLR outputs (“Methods”). We observed a clean separation between known microtubule depolymerizing and polymerizing agents (Fig. 6a). A similar MoA-based clustering was observed when we tested all known protein kinase inhibitors, which showed a clear separation between receptor tyrosine kinase inhibitors, serine/threonine kinase inhibitors, and nucleoside analogs (Fig. 6b). Overall these results demonstrate that BANDIT can be used to differentiate small molecules based on their specific MoA without additional model training. Combined with the earlier voting algorithm, this demonstrates an efficient pipeline for small molecule target and mechanism identification: first using BANDIT to predict targets for an orphan small molecule, followed by clustering with other drugs known to act on the same target to discern MoA.

BANDIT can predict specific mechanisms of action and connections between drug classes. a Hierarchical clustering of drugs known to target microtubules and b drugs known to target protein kinases. c Network of drugs based on shared target interactions. Drugs are colored based on their most prevalent ATC code. Three specific clusters corresponding to beta-blockers and Parkinson’s medications, anti-retrovirals and statins, and opioids and antimicrotubule drugs are highlighted

## Section: Results › Identifying connections within the drug universe

We next used BANDIT to get an overview of how different classes of drugs, spanning the entire clinical landscape, may be related to one another. Based on the TLR between each drug pair, we constructed a network representative of the drug universe, or all known drugs with at least one predicted shared target interaction (Fig. 6c). Each drug was classified according to its 1st order Anatomical Therapeutic Chemical (ATC) classification—characteristic of the type and intended use of each drug. As expected, drugs of a similar ATC code cluster together, however we also observed many unexpected clusters indicative of drug mechanisms or effect. Interestingly, among all classes of chemotherapeutics, microtubule inhibitors clustered together with camptothecin analogs, for which a dual role as topoisomerase I and tubulin polymerization inhibitors has been previously reported56, but which is not widely acknowledged in clinical oncology. Conversely, we unexpectedly found opioids closely interconnected with microtubule targeting agents; this unanticipated observation is in line with previous reports showing how exposure to microtubule targeting drugs can increase the levels of the opioid receptor in rat cerebellums and that treatment of cardiac myocytes with opioids induces microtubule alterations57,58. This unexploited finding could reveal novel biology linking the opioid receptor signaling pathway with the microtubule cytoskeleton, as well as potentially represent an example of drug repurposing, suggesting novel clinical indications for drugs already FDA-approved. As further proof of the clinical value of the broad universe clustering information revealed by BANDIT, we detected close clustering of known beta-blockers with many Parkinson’s medications, which was especially interesting given that one of the most controversial clinical applications of beta-blockers was to reduce tremors in Parkinson’s patients59. Drug clustering was also strongly indicative of potential side effects, as suggested by the link between antiretroviral medications, which often cause metabolic side effects like hypercholesterolemia, and statins, FDA-approved cholesterol lowering drugs60. Overall we believe this broad universe clustering approach could greatly advance future drug development by indicating novel potentially synergistic drug combinations, potentially cumulative side effects, and by assisting in drug repositioning.

## Section: Discussion

We have developed BANDIT, an integrative Big-Data approach that combines a set of individually weak features into a single reliable and robust predictor of shared-target drug relationships and individual drug binding targets. Our predictions replicated shared-target relationships, individual drug–target relationships, and known mechanisms of action within our test set and replicated results of large-scale experimental screens. Moreover, we experimentally confirmed several of our novel predictions using different bioassays and model systems and demonstrated BANDIT’s capability to efficiently discover novel small molecules, which could be used in refractory tumors. Finally, BANDIT can be used on a broader scale to discern mechanisms of approved drugs, characterize the global drug universe landscape, explain existing, yet puzzling, clinical phenotypes, and repurpose drugs for new indications.

In addition, as BANDIT can be continually augmented with new and diverse datasets, we expect its predictive power to increase as new data becomes available. This is due to one of the key strengths of the Bayesian framework, as it can easily accommodate new features and quickly evaluate their individual predictive power by computing direct probabilities. However, as more information becomes available there are many aspects of the current implementation that can be improved. For instance, we can better understand the dependencies between distinct data types and model those within our Bayesian network, and as more information on binding kinetics becomes available, BANDIT could be adapted to better predict on versus off-target effects. As drug development often stops in early clinical studies due to unanticipated toxic side effects, BANDIT could help overcome these roadblocks by identifying side effects due to unknown off-target bindings.

In summary, we show herein the potential of BANDIT in expediting drug development, as it spans the entire space ranging from new target identification and validation to clinical candidate development and drug repurposing. By allowing researchers to quickly obtain target predictions it could streamline all subsequent development efforts and save scientists both time and resources. Furthermore, BANDIT could be used to rapidly screen a large database of compounds and efficiently identify any promising therapeutics that could be further evaluated. Overall our results demonstrate that BANDIT is a novel and effective screening and target-prediction platform for drug development and is poised to positively impact current efforts.

## Section: Methods › Datasets

Growth inhibition data: We used publicly available growth inhibition data from the National Cancer Institute’s Development Therapeutics Program (NCI-DTP). Each of the NCI60 cell lines were treated with a small molecule and the concentration that caused a 50% decrease in cell growth was measured. When there were multiple high quality experiments done for the same compound, we averaged the values to obtain a single GI50 value for each small molecule—cell line pair. Contains data on 20,000+ unique compounds. Version 1.6.2 was downloaded from cellminer.com.

Gene expression data: All post-treatment gene expression data was downloaded from the Broad Connectivity Map (CMap) project. Fold change data across all cell lines were averaged to obtain a single gene expression signature for each compound. Contains data on 1309 different compounds. Build 02 was downloaded from the Broad CMap Portal.

Adverse effects: Side effects (mined from drug package inserts and public information) were downloaded from the SIDER database. Each side effect was classified using the MedDRA (version 16.1) dictionary.

Bioassays/Chemical structures: All bioassay results and chemical structures were downloaded from PubChem and organized based on each small molecule’s PubChem Compound Identification (CID).

Known Drug Targets: All known drug targets were extracted from the DrugBank database (Version 4.1).

## Section: Methods › Calculating similarity scores

Growth Inhibition Data: For each pair of drugs we calculated a pearson correlation value across the 60 data points (Supplementary Fig. 1).

Gene expression and Chemogenomic Fitness Scores: A pearson correlation was used to measure the degree of similarity for the profiles of two drugs

Bioassays: All bioassays were classified as either positive or negative based on the data available in Pubchem. A jaccard index was calculated based on the number of shared “positive” assays between two drugs. We required that each drug pair have been tested in at least one similar assay for a similarity score to be calculated.

Chemical Structures: For each drug we extracted the isomeric SMILES and used the atom-pair method61 to calculate the DICE coefficient based structural similarity between two compounds (Supplementary Fig. 1). Other structural similarity methods (such as ECFP with Tanimoto coefficients) were evaluated as well, however all had a lower overall predictive power—measured by the D-statistic from a KS test—therefore the DICE similarity was ultimately chosen.

Adverse Effects: Using the SIDER2 database25 we extracted the “preferred term” side effects for each drug. A jaccard index was then calculated for the shared side effects for each drug pair.

## Section: Methods › Calculating correlations between similarity types

To combine data from different databases, we mapped information from each drug back to a PubChem compound identifier (CID) that was used for all subsequent integration. For each pair of similarity scores we separated out drug pairs where both similarity types were measured and plotted the different similarity scores against one another (Fig. 1a, Supplementary Fig. 2). We computed the Pearson correlation coefficient (PCC) and the coefficient of determination (R2) between each pair of similarity scores. Across all pairs, we observed a low correlation—measured by both the PCC and R2. This finding demonstrated that high similarity of one type does not necessarily implied high similarity in another.

## Section: Methods › Calculating the total likelihood ratio

For each data type BANDIT calculates a likelihood ratio L(sn) is defined as the fraction of drug pairs with a shared target (ST pairs) having a given similarity score sn, divided by the fraction of the non-ST pairs with the same similarity score:

For each data type we binned similarity scores into 20 evenly spaced intervals and calculated the likelihood value for all similarity scores in each bin. We then fit an exponential function (using the R “predict” and “exp” methods) to each data type, and this was used to calculate likelihood values for new cases.

Our previous analysis highlighted the minimal correlation between the similarity types and how data types could be modeled using a Naïve Bayes framework. This implies that the joint probability of two drugs sharing a target given a set of similarity scores can be modeled as the product involving individual similarity scores. Overall we decided to use this Bayesian framework for multiple reasons, such as the readily interpretable nature of a likelihood ratio compared to other more complicated machine learning scores and the ability to easily add in new data types as they become available.

Therefore the total likelihood ratio L(s) can be expressed as the product of the individual likelihood ratios:

The total likelihood ratio (TLR) is then proportional to the odds of two drugs sharing a given target n given sources of information. If a data type was not available for a given compound then the median value of all similarity scores for that data type was used to calculate the likelihood value. This imputation was done after the similarity to likelihood conversion was established (Eq. 1) so as not to skew likelihood values.

## Section: Methods › Testing against drugs with known targets

Drug targets were extracted from DrugBank and drug pairs were classified as a “shared-target” pair if they had at least one target in common. We used fivefold cross validation to split our set of drug pairs into a test and training set containing 20% and 80% of the drug pairs respectively. We sub-sampled the two classes (ST and non-ST drug pairs) and required the ratio of true positives (ST pairs) to true negatives (non-ST pairs) to remain the same as the total set. For each fold we computed TLRs for each drug pair in the test set based on the background probabilities within the training set. Each of the five test folds combined at the end to produce an ROC Curve and calculate the AUROC value. We calculated the AUROC value for each individual likelihood ratio from a single data type (Supplementary Fig. 5).

We performed this analysis with the TLR output while varying the number of data types being considered and found a significant increase in the predictive power, measured by the AUROC, as we increased the number of included datasets (Fig. 2a). We computed two sets of ROC curves—one where we required drugs have available data in each included data type (our preferred method) and another where we imputed the data type median for each missing data type. We varied the order in which datasets were added and observed a positive relationship between AUROC value and the number of included data types regardless of the addition order. We tested this by selecting each possible combination of the five data types and computing the AUROC using five-fold cross validation and observed an increase in the average AUROC as the total number of included data types increased (Supplementary Table 1). Furthermore, we used a KS test to measure how our TLR value could separate out ST and non-ST pairs and saw that in each case our TLR value outperformed any individual variable (Supplementary Fig. 6). We repeated this analysis increasing the minimum number of data types we required a pair of compounds to have and saw the separation steadily improve (D = 0.44–0.69).

## Section: Methods › Comparison to existing drug target prediction methods

Campillos et al.13: In their paper “Drug Target Identification Using Side-Effect Similarity,” Campillos et al. report that they used their method to test 246,051 drug pairs (in which 6681 were known to share targets) to predict shared target relationships13. In comparison to BANDIT, this method relied on only side effect similarities to identify shared target drugs. They report that out of their top 409 predictions (representing the top 166% of all predictions), 192 were known to share targets (representing an accuracy of 47%). When we performed a similar test on our top 166% of predictions (2160 drugs pairs out of 1,301,691 total), we found that 1649 were known to share targets. This represents a 76% accuracy for top predictions—a significant improvement from the 47% reported by Campillos et al. To further evaluate our comparative accuracy, we also looked deeper to the top 1.2% of predictions. In their paper, Campillos et al. report that out of their top 2903 predictions (representing the top 1.2%), 956 were known to share targets (representing a 33% accuracy). When we evaluated our top 1.2% of predictions (15,620 drug pairs) we found that 6,884 were known to share at least one target (44% accuracy), once again highlighting BANDIT’s increased accuracy to established methods (Supplementary Table 4).

Wang et al.14: In their paper “Prediction of Drug–Target Interactions for Drug Repositioning Only Based on Genomic Expression Similarity” Wang et al. report an AUC of 0.66 when predicting shared target relationship of compounds in the CMap database using the BAES method, which integrates batch corrected gene expression information. Using BANDIT we observed a higher AUC when evaluated on all compounds in our database that were tested by CMap (Supplementary Table 4).

Caniza et al.62: In their paper “Mining the biomedical literature to predict shared drug targets in DrugBank” Caniza et al. compared multiple similarity driven approaches based on prior biomedical literature to identify how well they could identify drugs which share at least one target (AUC = 0.51–0.69). Each of these methods uses semantic similarity approaches to find shared target drugs, but only integrate drug MESH terms or chemical structures. We found that BANDIT outperformed each of these methods when tested on all drugs (Supplementary Table 4).

## Section: Methods › Replicating kinase experimental screen

We first separated out the kinases in the Peterson et al. database30 that were classified as BANDIT orphan small molecules —molecules that were in at least two of the considered BANDIT databases and had no known targets (11 unique compounds). For each orphan kinase inhibitor we used BANDIT to predict shared target drugs. Each known kinase target of the shared target drugs was classified as a potential kinase target of the orphan inhibitor. We then observed that the “percent remaining kinase activity” was significantly lower between the orphan kinase inhibitors and the BANDIT predicted kinases than between the orphan inhibitors and any non-predicted kinases (Wilcoxon Rank Sum Test P = 3.62e−06) (Supplementary Fig. 8).

## Section: Methods › Specific target voting

For each orphan small molecule, we identified all shared target drug predictions, or any drugs with known targets that exceeded a given BANDIT likelihood ratio. For each shared target drug prediction, we compiled all known targets of that given drug and ranked specific protein targets based on how often it appeared as known target in shared drug target predictions. Votes for particular protein targets were weighted based on the likelihood ratio of the shared target prediction they originated from. The top voted target for each orphan small molecule that we tested was then predicted to be a novel specific target (Fig. 2e).

To test the accuracy, we used leave-one-out cross validation on our test set of drugs with known targets. For each drug we used BANDIT to compare it to all other drugs with known targets and identify the top ranked target for the tested drug. This was repeated for every drug in our test set and we calculated how often the top ranked target was a known target of the drug being tested. We recomputed these accuracies while varying the likelihood ratio cutoff for a drug pair to be considered a shared-target prediction. As expected we observed a steady increase in accuracy as we increased the cutoff value, with the accuracy plateauing at an accuracy level of ~90%—revealing that BANDIT’s voting protocol could accurately identify specific targets (Fig. 2f). We also redid this test using fivefold cross validation and observed little difference in overall accuracy (plateauing at ~87% accuracy).

## Section: Methods › Identification of novel antimicrotubule small molecules

For each orphan small molecule in BANDIT (defined as a molecule tested in any of the individual databases but without any known targets in DrugBank) we used the BANDIT voting protocol to predict specific protein targets. We required that each orphan small molecule be in at least three of BANDIT’s databases, leaving us with a set of ~15,000 small molecules. To refine our initial list of predictions into a high confidence set, we required a TLR cutoff of 500, that each predicted target appear in the majority of shared target predictions, and that the highest ranked target appear in the top shared target prediction for each orphan molecule. From this list of high confidence predictions, we identified a set of small molecules predicted to bind to microtubules.

For each predicted microtubule inhibitor (MTI) we examined how it related to known MTIs using a network approach (Supplementary Fig. 9). We required that each predicted MTI have a TLR greater than 500 with at least two known MTIs. Each edge in our network represents a predicted shared target interaction with the length and width of each corresponding to the strength of the prediction (measured by the TLR value). We used the Fruchterman Reingold projection within the R igraph package. We observed a distinct clustering of known MTIs based on their mechanism of action.

Most of the novel MTIs we predicted were not easily obtained, thus we specifically focused on the subset that we could obtain from the National Cancer Institute’s Developmental Therapeutics Program (Supplementary Table 2).

## Section: Methods › Microtubule imaging/testing

Human breast MDA-MB-231 cells were obtained from the American Type Culture Collection (ATCC, Manassas, VA) and cultured in DMEM (obtained from Corning Cellgro) with 10% fetal bovine serum and 1% penicillin and streptomycin. Cells were plated at the density of 90,000 cells/ml onto 12 mm round cover slips in 48 well plates for 24 h and then treated for 6 h with small molecules at the given concentrations. Small molecules (obtained from the NCI Drug Bank) were dissolved in DMSO and stored at −20 °C. Control experiments were done using DMSO and it was <0.5% of total media volume. After 6 h drug treatment media was removed and cells were permeabilized with 0.5% Triton X-100 and fixed with PHEMO Buffer (3.7% formaldehyde, 0.05% glutaraldehyde, 0.068 M Pipes, 0.025 M HEPES, 0.015 M EGTANa2, 0.003 M MgCl26H2O and 10% DMSO and adjust pH = 6.8) for 10 min. Fixed cells were washed three times with PBS buffer. Cells were blocked with 10% goat serum at room temperature for 10 min. Cells were incubated with monoclonal α-tubulin antibody (1:1000 dilution, clone YL 1/2, obtained from EMD Millipore, cat#MAB1864), for 1 h and washed three times with PBS buffer before incubation with a secondary Alexa Fluor 488 goat anti-mouse antibody (1:500 dilution, obtained from Invitrogen, cat# A-11006). Cell chromatin was stained with DAPI for 5 min and washed with water three times. Cover slips were mounted and photographed in a RSM 700 microscope for microtubule visualization. DNA was counterstained with DAPI. Images were acquired with Zeiss LSM 700 confocal microscope under a 63×/1.4NA objective (Zeiss, Germany) (Fig. 3a–h, Supplementary Figs. 10–15).

A Fisher’s exact test was used to determine whether the number of observed successes—defined as a predicted microtubule inhibitor showing an effect against microtubules in imaging—was greater than what would be expected by random chance. To determine the background probability we used the number of drugs with known targets in our database that were known to target microtubules (~1%).

## Section: Methods › Microtubule effect quantification

Following 6 h treatment, cells (12 well plate) were washed once with warm phosphate-buffered saline. Each well was incubated with 150 μL either with low salts or high salt buffer at 37 °C for 10 min. Cell were then scraped and were either lysed in low salt buffer to test for the degree of tubulin polymerization (20 mM Tris–HCl pH 6.8, 1 mM MgCl2, 2 mM EGTA, 0.5% NP-40, 1× protease inhibitor cocktail and 0.5% NP-40) or high salt buffer to test for the degree of tubulin depolymerization (0.1 M Pipes, 1 mM EGTA, 1 mM MgSO4, 30% glycerol, 5% DMSO, 1 mM DTT, 0.02% NAAzide, 0.125% NP-40, 1 mM DTT and 1× protease inhibitor cocktail). Samples were spun at max speed in a tabletop centrifuge for 30 min at room temperature. The supernatant (S) was separated from the pellet (P). The pellet was resuspended in 150 μL 1 × Laemmli buffer and sonicated. Equal volumes of supernatant and pellet samples were loaded onto a 12% gel for a western blot. Tubulin bands were visualized with a DM1 monoclonal antibody (1:5000 dilution obtained from Sigma-Aldrich, cat# T9026). % Tubulin in pellet levels were calculated as the densitometric value of the pellet band divided by the total densitometric value of the pellet and supernatant bands times 100. Three biological repeats were performed (Supplementary Fig. 16).

## Section: Methods › Treatment against resistant cell lines

The 1A9 is a clone of the human ovarian carcinoma cell line, A2780. 1A9-ERB is a clone of the 1A9 human ovarian carcinoma cell line resistant to the effects of Eribulin mesylate. It was prepared by exposing 1A9 cells to 1 ng/ml Eribulin (obtained from Eisai pharmaceuticals) in the presence of 10 μg/ml verapamil (obtained from Acros Organics), a Pgp antagonist. The cells were maintained in the 0.5 ng/ml eribulin and 10 μg/ml verapamil concentrations. Cells were removed from this drug solution 3 days prior to any future experimentation. Additional treatment and imaging was done using the same protocols as described earlier (Supplementary Figs. 17–19).

Growth inhibition activity was determined using 96 well plates. Cells were seeded at density of 4000 cells/well for 24 h. Cell were exposed to 1 ml serial dilution (0.014–8100 nM) of different drugs for 72 h. An SRB assay was performed to determine the cell viability. GI50 was determined as drug concentration that causes a 50% decrease in cell growth. Experiments were repeated at least three times to obtain the mean and standard deviation for each experiment.

## Section: Methods › Characterization of ONC201-DRD2 interaction

ONC201 dihydrochloride was obtained from Oncoceutics. GPCR arrestin recruitment and cAMP modulation reporter assays were performed using PathHunterTM (DiscoveRx) beta-arrestin cells expressing one of several GPCR targets and HitHunter cAMP cells, respectively63. For arrestin recruitment, cells were plated onto 384-well white solid bottom assay plates (Corning 3570) at 5000 cells per well in a 20 µL volume in the appropriate cell plating reagent. Cells were incubated at 37 °C, 5% CO2 for 18–24 h. Samples were prepared in buffer containing 0.05% fatty-acid free BSA (Sigma). For agonist mode tests, samples (5 µL) were added to pre-plated cells and incubated for 90 min at 37 °C, 5% CO2. For antagonist mode tests, samples (5 µL) were added to pre-plated cells and incubated for 30 min at 37 °C, 5% CO2 followed by addition of EC80 agonist (5 µL) for 90 min at 37 °C, 5% CO2. For Schild analysis, samples (5 µL) were added to pre-plated cells and incubated for 30 min at 37 °C, 5% CO2 followed by addition of serially diluted agonist (5 µL) for 90 min at 37 °C, 5% CO2. Control wells defining the maximal and minimal response for each assay mode were tested in parallel. Arrestin recruitment was measured by addition of 15 µL PathHunter Detection reagent and incubated for 1–2 h at room temperature and read on a Perkin Elmer Envision Plate Reader. For agonist and antagonist tests, data was normalized for percent efficacy using the appropriate controls and fitted to a sigmoidal dose–response (variable slope), Y = Bottom + (Top-Bottom)/(1 + 10^((LogEC50-X)*HillSlope)), where X is the log concentration of compound. For cAMP modulation, a method similar to that for arrestin recruitment was used with the DiscoveRx HitHunter cAMP XS + assay and measured by incubation with cAMP XS + Ab reagent and cAMP XS + ED/CL lysis cocktail for 1 h followed by incubation with cAMP XS + EA reagent for 3 h at room temperature.

For Schild analysis, data was normalized for percent efficacy using the appropriate controls and fitted to a Gaddum/Schild EC50 shift using global fitting, where Y = Bottom + (Top-Bottom)/(1 + 10^((LogEC-X)*HillSlope)), Antag = 1 + (B/(10^(−1*pA2)))^SchildSlope and LogEC = Log(EC50*Antag). EC50/IC50 analysis was performed in CBIS data analysis suite (Cheminnovation) and Schild analysis performed in GraphPad Prism 6.0.5.

Kinase inhibition assays for the kinome were performed by Reaction Biology Corp30. In vitro kinase panel profiling was performed using the “HotSpot” assay platform. Briefly, kinase, substrate, cofactors were prepared in reaction buffer at room temperature. Compound, ATP and 33P ATP was added to a final concentration of 10 μM. Spotting of the reactions was done with ion exchange filter paper. Unbound phosphate was removed in phosphoric acid. Kinase activity data was expressed as % remaining kinase activity in test samples compared to vehicle. IC50 values and curve fits were obtained.

The nuclear hormone receptor profiling (S16) was performed by DiscoverX64–66. In this system, a CHO cell expressing a portion of betagalactosidase in the nucleus is stably transfected with a nuclear hormone receptor construct fused to a complementary portion of beta-galactosidase prolabel. Upon ligand binding, the fusion protein translocates to the nucleus, allowing chemiluminescent detection. Cells at a range of densities were resuspended in assay buffer into white-tissue culture-treated multi-well plates and increasing concentrations of control compounds were dispensed. The plate was incubated for 3 h at 37 °C and 5% CO2. PathHunter detection reagent was added to each well prior to incubation for 1 h at room temperature and reading relative luminescence. Dose response curves were plotted using Prism.

## Section: Methods › Drug mechanism clustering

For each drug pair we converted the TLR between them into a distance metric used to estimate closeness between any two drugs:

We next separated all drugs know to target microtubules that were in at least three of BANDIT’s dataset. With the BANDIT distance metric as an input we created a hierarchical cluster of all known MTIs using the hclust R method with an average based clustering method. Known MTIs were labeled based on whether they were known to polymerize or depolymerize microtubules, and we observed a distinct separation based on the mechanism of action (MoA). We repeated this clustering while removing drug structures from our likelihood calculations and continued to see a MoA-based separation (Supplementary Fig. 20). This revealed that BANDIT’s clustering approach is not dependent on any single data type, and that observed results are due to BANDIT’s integrative approach. This analysis was then repeated using similar conditions for known protein kinases.

## Section: Methods › Drug universe clustering

Using the same protocol as was used to create the MTI network, we created a network of all drugs with known targets with each edge representing a predicted shared target interaction and the edge weight corresponding to the strength of the interaction. Using the KEGG drug database67 and DrugBank27 we annotated each drug based on its most prevalent ATC code and colored each drug accordingly. We specifically isolated out three clusters representing: (1) beta-blockers with Parkinson’s medications, (2) antiretrovirals and statins and (3) opioids and microtubule inhibitors.

To get a better understanding of how orphan small molecules fit into this drug universe we computed the distance between every pair of small molecules and used multi-dimensional scaling to visualize the overall structure (Supplementary Fig. 21). We used the same distance metric as described in the mechanism of action clustering section to create a distance matrix between all small molecules (known drugs and orphan) and used the R cmdscale package for the multi-dimensional scaling. We noticed a definite structure with known drugs tightly clustering around each other, while orphan molecules had a more diffuse organization. One explanation for this structure is that drugs with known targets are more likely to be used to treat patients and thus may have similar effects due to safety precautions, whereas orphan molecules which have not gone through clinical trials and FDA approval are more likely to have a wide variety of effects and characteristics.

## Section: Methods › Reporting summary

Further information on research design is available in the Nature Research Reporting Summary linked to this article.

## Section: Supplementary information

Supplementary Information

Peer Review File

Reporting Summary

## Section: Supplementary information

Supplementary Information

Peer Review File

Reporting Summary

## Section: Acknowledgements

The authors would like to thank the members of the Elemento Lab and Giannakakou Lab for their feedback and discussions. O.E. is supported by NIH grants U24 CA210989, R01 CA194547, P50CA211024, UL1TR002384 and Emerson Collective Cancer Research Fund. Support was also provided for N.S.M. and K.G. by the PhRMA Foundation Pre Doctoral Informatics Fellowship and by the Tri-Institutional Training Program in Computational Biology and Medicine.

## Section: Author contributions

N.S.M. and O.E. conceived, designed, and developed the methodology for this work. N.S.M, L.H., K.G. and O.E. analyzed and interpreted the data and developed the computational methodology. P.K.K., G.G. and P.G. designed and carried out the experimental screening of the anti-microtubule compounds. M.S. and J.E.A. designed and supervised all experimental work related to ONC201. O.E. supervised the study.

## Section: Data availability

All data used for the analyses in this paper is publicly available. Further information on the specific sources could be found in the “Datasets” portion of the Methods section.

## Section: Code availability

Select pieces of custom code can be made available upon request.

## Section: Competing interests

O.E. and N.S.M are co-founders and equity holders in One Three Biotech, Inc, a company that may use some of the methods described in this article for commercial purpose. O.E. and N.S.M. have filed a patent application on the Bayesian data integrative computational method for predicting binding targets of chemicals (BANDIT) described in this article (US Patent App. 16/315,625). J.E.A. and M.S. are employees and shareholders of Oncoceutics. The remaining authors declare no competing interests.

## Section: Contributor Information

Joshua E. Allen, Email: josh.allen@oncoceutics.com

Paraskevi Giannakakou, Email: pag2015@med.cornell.edu.

Olivier Elemento, Email: ole2001@med.cornell.edu.

## Section: Supplementary information

Supplementary information is available for this paper at 10.1038/s41467-019-12928-6.

## Section: Associated Data

Supplementary Information

Peer Review File

Reporting Summary

## Section: Associated Data › Supplementary Materials

Supplementary Information

Peer Review File

Reporting Summary

## Section: Associated Data › Data Availability Statement

All data used for the analyses in this paper is publicly available. Further information on the specific sources could be found in the “Datasets” portion of the Methods section.

Select pieces of custom code can be made available upon request.


---

# A de novo molecular generation method using latent vector based generative adversarial network

- **Authors:** Oleksii Prykhodko, Simon Johansson, Panagiotis-Christos Kotsias, Josep Arús‐Pous, Esben Jannik Bjerrum, Ola Engkvist, Hongming Chen
- **Issuer:** Journal of Cheminformatics
- **Type:** Scientific article
- **Published:** 2019-12-01
- **Language:** en
- **DOI:** 10.1186/s13321-019-0397-9
- **Source:** https://doi.org/10.1186/s13321-019-0397-9
- **Licence:** CC-BY

## Section: Abstract

Deep learning methods applied to drug discovery have been used to generate novel structures. In this study, we propose a new deep learning architecture, LatentGAN, which combines an autoencoder and a generative adversarial neural network for de novo molecular design. We applied the method in two scenarios: one to generate random drug-like compounds and another to generate target-biased compounds. Our results show that the method works well in both cases. Sampled compounds from the trained model can largely occupy the same chemical space as the training set and also generate a substantial fraction of novel compounds. Moreover, the drug-likeness score of compounds sampled from LatentGAN is also similar to that of the training set. Lastly, generated compounds differ from those obtained with a Recurrent Neural Network-based generative model approach, indicating that both methods can be used complementarily.

## Section: Introduction

There has been a surge of deep learning methods applied to cheminformatics in the last few years [1–5]. Whereas much impact has been demonstrated in deep learning methods that replace traditional machine learning (ML) approaches (e.g., QSAR modelling [6]), a more profound impact is the application of generative models in de novo drug design [7–9]. Historically, de novo design was performed by searching virtual libraries based on known chemical reactions alongside a set of available chemical building blocks [10] or by using transformational rules based on the expertise of medicinal chemists to design analogues to a query structure [11]. While many successes using these techniques have been reported in literature [12], it is worthwhile to point out that these methods rely heavily on predefined rules of structure generation and do not have the concept of learning prior knowledge on how drug-like molecules should be. In contrast, deep generative models learn how to generate molecules by generalizing the probability of the generation process of a large set of chemical structures (i.e., training set). Then, structure generation is basically a sampling process following the learned probability distribution [7, 8, 13, 14]. It is a data-driven process and requires very few predefined rules.

Early attempted architectures were inspired by the deep learning methods used in natural language processing (NLP) [7, 15]. A recurrent neural network (RNN) trained with a set of molecules represented as SMILES strings [16] is able to generate a much bigger chemical space than the training set. Later on, the REINVENT method was proposed, which combines RNNs with reinforcement learning to generate structures with desirable properties [8]. Another architecture, the variational autoencoder (VAE), was also shown to generate novel chemical space [9, 17]. This architecture is comprised of an encoder, that converts the molecule to a latent vector representation and a decoder, from which the latent representation tries to generate the input molecule again. By changing the internal latent representation and decoding it, new chemical space can be obtained. More studies followed that improved the architecture, in both making it more robust and improving the quality of the latent representation generated [18–20]. One special mention is the use of randomized SMILES [14, 21, 22]. Instead of using a unique SMILES representation for each molecule, different representations are used in every stage of the training. With this improvement, the quality of the chemical space generated in both RNNs and VAEs is much higher and the models tend to overfit much less. Besides the SMILES string based de novo structure generation methods, methods of generating molecules based on molecular graphs have also been proposed and, by using them, molecules can be directly generated step-by-step as molecular graphs [23–26].

Generative adversarial neural (GAN) networks [27] have become a very popular architecture for generating highly realistic content [28]. A GAN has two components, a generator and a discriminator, that compete against each other during training. The generator generates artificial data and the discriminator attempts to distinguish it from real data. The model is trained until the discriminator is unable to distinguish the artificial data from the real data. The first use in molecule generation was ORGAN [29] and its improved version, ORGANIC [30]. The former was tested with both molecular generation as well as musical scores, whereas the latter was targeted directly at inverse design of molecules. ORGANIC had trouble optimizing towards the discrete values from the Lipinski Rule of Five [31] heuristic score but showed some success in optimizing the QED [11] score. An algorithm combining GAN with RL was also used in RANC [32] and ATNC [33] where the central RNN was substituted by a differential neural computer (DNC) [34], a more advanced recurrent neural network architecture. The authors demonstrated that DNC-based architectures can handle longer SMILES and generate more diversity.

In this study, a new molecular generation strategy is described which combines an autoencoder and a GAN. The difference between this method and previous GAN methods such as ORGANIC and RANC is that the generator and discriminator network do not use SMILES strings as input, but instead n-dimensional vectors derived from the code-layer of an autoencoder trained as a SMILES heteroencoder [35]. This allows the model to focus on optimizing the sampling and not worry about SMILES syntax issues. The decoder part of a pretrained heteroencoder [22] neural network was used to translate the generated n-dimensional vector into molecular structures. We first trained the GAN on a set of ChEMBL [36] compounds and, after training, the GAN model was able to generate drug-like structures. Next, additional GAN models were trained on three target specific datasets (corresponding to EGFR, HTR1A and S1PR1 targets). Our results show that these GAN model can generate compounds which are similar to the ones in the training set but are still novel structures. We envision the LatentGAN to be a useful tool for de novo molecule design.

## Section: Methods and materials

Workflow of the LatentGAN. The latent vectors generated from the encoder part of the heteroencoder is used as the input for the GAN. Once the training of the GAN is finished, new compounds are generated by first sampling the generator network of the GAN and then converting the sampled latent vector into a molecular structure using the decoder component of the heteroencoder

Targeted data set and the performance of the SVM models

## Section: Methods and materials › Heteroencoder architecture

A heteroencoder is an autoencoder architecture trained on pairs of different representations of the same entity, i.e. different non-canonical SMILES of the same molecule. It consists of two neural networks, namely, the encoder and decoder, which are jointly trained as a transformation pipeline. The encoder is responsible for translating one-hot encoded SMILES strings into a numerical latent representation whereas the decoder accepts this latent representation and attempts to reconstruct one of the possible non-canonical SMILES string that it represents. The implementation followed the architecture previously reported in [22] with some changes (Fig. 1, bottom).Fig. 1Workflow of the LatentGAN. The latent vectors generated from the encoder part of the heteroencoder is used as the input for the GAN. Once the training of the GAN is finished, new compounds are generated by first sampling the generator network of the GAN and then converting the sampled latent vector into a molecular structure using the decoder component of the heteroencoder

Initially, the one-hot encoded SMILES string is propagated through a two-layer bidirectional encoder with 512 Long Short-Term Memory [26] units per layer, half of which are used for the forward and half for the backward direction. The output of both directions is then concatenated and input to a feed-forward layer with 512 dimensions. As a regularizing step during training, the resulting vector is perturbed by applying additive zero-centered gaussian noise with a standard deviation of 0.1. The latent representation of the molecule is fed to a feed-forward layer, the output of which is copied and inserted as hidden and cell states to a four-layer unidirectional LSTM RNN decoder with the same specifications as the encoder. Finally, the output of the last layer is processed by a feed-forward layer with softmax activation, to return the probability of sampling each character of the known character set of the dataset. Batch normalization with a momentum value of 0.9 [37] is applied on the output of every hidden layer, except for the gaussian noise layer.

The heteroencoder network was trained for 100 epochs with a batch size of 128 and using a constant learning rate of 10−3 for the first 50 epochs and an exponential decay following that, reaching a value of 10−6 in the final epoch. The decoder was trained using the teacher’s forcing method [38]. The model was trained using the decoding loss function of categorial cross entropy between the decoded and the training SMILES. After training the heteroencoder, the noise layer is deactivated, resulting in a deterministic encoding and decoding of the GAN training and sampled sets.

Workflow of the LatentGAN. The latent vectors generated from the encoder part of the heteroencoder is used as the input for the GAN. Once the training of the GAN is finished, new compounds are generated by first sampling the generator network of the GAN and then converting the sampled latent vector into a molecular structure using the decoder component of the heteroencoder

## Section: Methods and materials › The GAN architecture

A Wasserstein GAN with gradient penalty (WGAN-GP) [39, 40] was chosen as a GAN model. Every GAN consists of two neural networks, generator and discriminator that train simultaneously (Fig. 1, top). First, the discriminator, usually called the critic in the context of WGANs, tries to distinguish between real data and fake data. It is formed by three feed-forward layers of 256 dimensions each with the leaky ReLU [41] activation function between, except for the last layer where no activation function was used. Second, the generator consists of five feed-forward layers of 256 dimensions each with batch normalization and leaky ReLU activation function between each.

## Section: Methods and materials › Workflow for training and sampling of the LatentGAN

The heteroencoder model was first pre-trained on the ChEMBL database for mapping structures to latent vectors. To train the full GAN model, first the latent vector h of the training set was generated using the encoder part of the heteroencoder. Then, it was used as the true data input for the discriminator, while a set of random vectors sampled from a uniform distribution were taken as fake data input to the generator. For every five batches of training for the discriminator, one batch was assigned to train the generator, so that the critic is kept ahead while providing the generator with higher gradients. Once the GAN training was finished, the Generator was sampled multiple times and the resulting latent vectors were fed into the decoder to obtain the SMILES strings of the underlying molecules.

## Section: Methods and materials › Dataset and machine learning models for scoring

The heteroencoder was trained on 1,347,173 SMILES from the ChEMBL [36] dataset. This is a subset of ChEMBL 25 without duplicates that has been standardized using the MolVS [42] v0.1.1 package with respect to the fragment, charge, isotope, stereochemistry and tautomeric states. The set is limited to SMILES of containing only [H, C, N, O, S, Cl, Br] atoms and a total of 50 heavy atoms or less. Furthermore, molecules known to be active towards DRD2 were removed as part of an experiment for the heteroencoder (the process of which can be found at [35], which uses the same decoder model, but not the encoder). A set of randomly selected 100,000 ChEMBL compounds were later selected for training a general GAN model. Moreover, three target datasets (corresponding to EGFR, S1PR1 and HTR1A) were extracted from ExCAPE-DB [43] for training target specific GANs. The ExCAPE-DB datasets were then clustered into training and test sets so that chemical series were assigned either to the training or to the test set (Table 1). To benchmark the performance of the targeted models, RNN based generative models for the three targets were also created by first training a prior RNN model on the same ChEMBL set used for training the heteroencoder model and then using transfer learning [7] on each focused target set. Target prediction models were calculated for each target using the Support vector machine learning (SVM) implementation in the Scikit-learn [44] package and the 2048-length FCFP6 fingerprint were calculated using RDKit [45].Table 1Targeted data set and the performance of the SVM modelsTargetTraining setTest setSVM modelROC-AUCKappa valueEGFR294923260.8500.56HTR1A48,28323,0480.9930.90S1PR149,38123,7450.9950.91Training set size (training set), test set size (test set), receiver operating characteristic area under the curve (ROC-AUC), kappa value

Targeted data set and the performance of the SVM models

## Section: Methods and materials › Related works

A related architecture to the LatentGAN is the Adversarial Autoencoder (AAE) [46]. The AAE uses a discriminator to introduce adversarial training to the autoencoder and is trained typically using a 3-step training scheme of (a) discriminator, (b) encoder, (c) encoder and decoder, compared to the LatentGANs 2-step training. The AAE have been used in generative modeling of molecules to sample molecular fingerprints using additional encoder training steps [47], as well as SMILES representations [48, 49]. In other application areas, Conditional AAEs with similar training schemes have been applied to manipulate images of faces [50]. For the later application, approaches that have utilized multiple discriminators have been used to combine conditional VAEs and conditional GANs to enforce constraints on the latent space [51] and thus increase the realism of the images.

## Section: Results and discussion

The performance of heteroencoder in both the training and test sets

Plot of the first two PCA components (explained variance 74.1%) of a set of 200,000 generated molecules from the ChEMBL LatentGAN model using the MQN fingerprint

Metrics obtained from a 50,000 SMILES sample of all the models trained

Venn diagram of LatentGAN (red) and RNN (blue) active compounds/scaffolds

The distribution of Murcko scaffold similarity (left) and FCFP6 Tanimoto compound similarity (right) to the training set of molecules generated by LatentGAN models for a EGFR, b S1PR1 and c HTR1A

PCA analysis for a EGFR (explained variance 82.8%), b HTR1A (explained variance 75.0%) and c S1PR1 (explained variance 79.3%) dataset. The red dots are the training set, the blue dots are the predicted inactive compounds in the sampled set and other dots are the predicted actives in the sampled set with different level of probability of being active

The same PCA analysis, showing the Murcko scaffold similarities of the predicted active compounds for a EGFR (explained variance 80.2%), b HTR1A (explained variance 74.1%) and c S1PR1 (explained variance 71.3%). Note that due to the lower amount in the outlier region of c, the image has been rotated slightly. No significant relationship between the scaffold similarities and the regions was found. For a separation of the generated points by similarity interval, see Additional file 1

Examples generated by the LatentGAN. Compound 1-3 are generated by the EGFR model, 4–6 are generated by HTR1A model and 7–9 are generated by S1PR1 model

QED distributions of sampled molecules from EGFR (a), HTR1A (b) and S1PR1 (c)

SA distributions of sampled molecules from EGFR (a), HTR1A (b) and S1PR1 (c)

## Section: Results and discussion › Training the heteroencoder

The heteroencoder was trained on the 1,347,173 ChEMBL dataset compounds for 100 epochs. SMILES generated validity for the whole training set was 99% and 18% of the molecules were not reconstructed properly. Notice that the reconstruction error corresponds to decoding to a valid SMILES that belongs to a different compound; reconstruction to a different SMILES of the same molecule is not counted as an error. Test set compounds were taken as input to the encoder and their latent values were calculated and then decoded to SMILES string, the validity and reconstruction error of test set are 98% and 20% respectively (Table 2).Table 2The performance of heteroencoder in both the training and test setsDataset# compoundsValidity (%)Reconstruction error (%)Training set974,1059918Test set10,8239820Percent of valid SMILES strings generated by the decoder (validity), percent of molecules not reconstructed correctly from valid SMILES (reconstruction error)

The performance of heteroencoder in both the training and test sets

## Section: Results and discussion › Training on the ChEMBL subset

A LatentGAN was trained on a randomly selected 100,000 ChEMBL subset with the objective of obtaining drug-like compounds. The model was trained for 30,000 epochs until both discriminator and generator models had converged. Next, 200,000 compounds were generated from the LatentGAN model and were compared with the 100,000 ChEMBL training compounds to examine the coverage of the chemical space. The MQN [52] fingerprint was generated for all compounds in both sets and the top two principal components of a PCA were plotted (Fig. 2) and shows how both compound sets cover a similar chemical space.Fig. 2Plot of the first two PCA components (explained variance 74.1%) of a set of 200,000 generated molecules from the ChEMBL LatentGAN model using the MQN fingerprint

Plot of the first two PCA components (explained variance 74.1%) of a set of 200,000 generated molecules from the ChEMBL LatentGAN model using the MQN fingerprint

## Section: Results and discussion › Training on the biased dataset

Another interesting question to answer is if the LatentGAN can be trained to generate target specific compounds. The active compounds of training set were then used as the real data to train the LatentGAN. Each GAN model was trained 10,000 epochs and once the training was finished, 50,000 compounds were sampled from the generator and decoded with the heteroencoder. Then, three targets (EGFR, HTR1A and S1PR1) were selected and SVM target prediction models were built (see methods) to predict target activity on each target using the corresponding model (Table 3). Results show that in all cases validity was above 80% and the uniqueness of valid compound was 56%, 66% and 31% for EGFR, HTR1A and S1PR1 respectively. Comparing with the sample set of ChEMBL model these numbers are much lower, but this can be due to the smaller size of training sets. Additionally, RNN models with transfer learning trained on the three targets (see “Methods and materials”) show a higher percentage of validity, but their percentage of uniqueness is lower in all cases except for S1PR1. Regarding the novelty, the values are 97%, 95% and 98% for EGFR, HTR1A and S1PR1 respectively and are slightly higher than the values of the RNN transfer learning models. This demonstrates that LatentGAN not only can generate valid SMILES but also most of them are novel to the training set, which is very important for de novo design tasks. All the sampled valid SMILES were then evaluated by the SVM models and a high percentage of the LatentGAN generated ones were predicted as active for these three targets (71%, 71% and 44%, for EGFR, HTR1A and S1PR1 respectively). These scores were better than the RNN models with respect to EGFR, but worse with respect to other two. Additionally, the comparison between LatentGAN and RNN generated active structures (Fig. 3) shows that the overlap is very small between the two architectures at both compound and scaffold levels. The compounds generated by LatentGAN were evaluated using the RNN model for a probabilistic estimation of whether the RNN model eventually would cover the LatentGAN output space, and it was shown to be very unlikely (see Additional file 1). This highlights that both architectures can work complementarily.Table 3Metrics obtained from a 50,000 SMILES sample of all the models trainedDatasetArch.Valid (%)Unique (%)Novel (%)Active (%)Recovered actives/total actives (%)Recovered neighborsEGFRGAN865697715.26196RNN964695657.74238HTR1AGAN866695715.05284RNN965090817.28384S1PR1GAN893198440.9324RNN973597653.7243Dataset used (Dataset), Architecture used (Arch.), Percent of valid molecules in the sampled set (Valid), Percent of valid unique compounds (Unique), Percent of unique novel (not present in the training set) compounds (Novel), Percent of unique active compounds (Active), Recovered actives from the test set given the entire number of actives in the test set (Recovered actives/Total Actives), Recovered neighbors of active compounds using FCFP6 fingerprint with 2048 bits and a threshold Tanimoto similarity of 0.7 Fig. 3Venn diagram of LatentGAN (red) and RNN (blue) active compounds/scaffolds

Full compound and Murcko scaffold [53] similarity was calculated between the actives in the sampled set and the actives in training set. Results (Fig. 4) show that, for each target, there are around 5% of generated compounds that are identical to the training sets. Additionally, there are around 25%, 24% and 21% compounds having similarity lower than 0.4 to the training set in EGFR, HTR1A and S1PR1 respectively. This means that LatentGAN is able to generate very dissimilar compounds to the training set. In terms of scaffold similarity comparison, it is not surprising that the percentage of scaffolds identical to the training set is much higher for all the targets. Nevertheless, around 14% of scaffolds in the sample set have low similarity to the training set (< 0.4) for all three tested cases.Fig. 4The distribution of Murcko scaffold similarity (left) and FCFP6 Tanimoto compound similarity (right) to the training set of molecules generated by LatentGAN models for a EGFR, b S1PR1 and c HTR1A

A PCA analysis using the MQN fingerprint was performed to compare the chemical space of sampled sets and training sets of all targets and shows that the sampled compound sets cover most of the chemical space of the training sets (Fig. 5). Interestingly, there are some regions in the PCA plots where most of the sampled compounds around the training compounds are predicted as inactive, for example the left lower corner in EGFR (Fig. 5a) and the right-hand side region in S1PR1 (Fig. 5c). The training compounds in those regions are non-druglike compounds and outliers in the training set and the SVM models predicted them as inactive. No conclusive relationship between these regions of outliers and the scaffolds of lower similarity (Fig. 6). Additionally, we also evaluated the amount of the actives in the test set recovered by the sample set (Table 3). It is interesting to note that there are more active compounds belonging to the test set recovered by RNN model for all three targets, indicating that using multiple types of generative model for structure generation can be a viable strategy. Lastly, some examples generated by LatentGAN were drawn (Fig. 7) and the QED drug-likeness score [11] and Synthetic Accessibility (SA) score [54] distributions for each of the targets were plotted (Figs. 8 and 9, respectively). Training set compounds have a slightly higher drug-likeness, yet the overall distributions are similar, showing that LatentGAN models can generate drug-like compounds.Fig. 5PCA analysis for a EGFR (explained variance 82.8%), b HTR1A (explained variance 75.0%) and c S1PR1 (explained variance 79.3%) dataset. The red dots are the training set, the blue dots are the predicted inactive compounds in the sampled set and other dots are the predicted actives in the sampled set with different level of probability of being active Fig. 6The same PCA analysis, showing the Murcko scaffold similarities of the predicted active compounds for a EGFR (explained variance 80.2%), b HTR1A (explained variance 74.1%) and c S1PR1 (explained variance 71.3%). Note that due to the lower amount in the outlier region of c, the image has been rotated slightly. No significant relationship between the scaffold similarities and the regions was found. For a separation of the generated points by similarity interval, see Additional file 1 Fig. 7Examples generated by the LatentGAN. Compound 1-3 are generated by the EGFR model, 4–6 are generated by HTR1A model and 7–9 are generated by S1PR1 model Fig. 8QED distributions of sampled molecules from EGFR (a), HTR1A (b) and S1PR1 (c) Fig. 9SA distributions of sampled molecules from EGFR (a), HTR1A (b) and S1PR1 (c)

Metrics obtained from a 50,000 SMILES sample of all the models trained

Venn diagram of LatentGAN (red) and RNN (blue) active compounds/scaffolds

The distribution of Murcko scaffold similarity (left) and FCFP6 Tanimoto compound similarity (right) to the training set of molecules generated by LatentGAN models for a EGFR, b S1PR1 and c HTR1A

PCA analysis for a EGFR (explained variance 82.8%), b HTR1A (explained variance 75.0%) and c S1PR1 (explained variance 79.3%) dataset. The red dots are the training set, the blue dots are the predicted inactive compounds in the sampled set and other dots are the predicted actives in the sampled set with different level of probability of being active

The same PCA analysis, showing the Murcko scaffold similarities of the predicted active compounds for a EGFR (explained variance 80.2%), b HTR1A (explained variance 74.1%) and c S1PR1 (explained variance 71.3%). Note that due to the lower amount in the outlier region of c, the image has been rotated slightly. No significant relationship between the scaffold similarities and the regions was found. For a separation of the generated points by similarity interval, see Additional file 1

Examples generated by the LatentGAN. Compound 1-3 are generated by the EGFR model, 4–6 are generated by HTR1A model and 7–9 are generated by S1PR1 model

QED distributions of sampled molecules from EGFR (a), HTR1A (b) and S1PR1 (c)

SA distributions of sampled molecules from EGFR (a), HTR1A (b) and S1PR1 (c)

## Section: Results and discussion › Comparison with similar generative networks

The LatentGAN was assessed using the MOSES benchmark platform [48], where several generative metrics are used to evaluate the properties of molecular generative networks on a sample of 30,000 SMILES after training on a canonical SMILES subset of the ZINC database [55] of size 1,584,663. The full table of results for the MOSES benchmark is maintained and regularly updated at [56]. When compared to the similar structured networks of VAE, JTN-VAE [20] and AAE, it is noticeable that VAE model have an output distribution that has a significant overlap with the training set, as shown by the high scores of most test metrics (where the test set has a similar distribution to the training set) and the low novelty, indicating a mode collapse. When compared against the JTN-VAE and AAE models, the LatentGAN has shows comparable or better results in the Fréchet ChemNet Distance (FCD) [57], Fragment (Frag) and Scaffold (Scaf) similarities, while producing slightly worse results in the cosine similarity to the nearest neighbor in the test set (SNN).

## Section: Results and discussion › On the properties of autoencoder latent spaces

In earlier VAE or AAE based architectures for generative molecular models, the role of the encoder is to forcefully fit the latent space of the training data to a Gaussian prior [47] or at least some continuous distribution [9], achieved in the latter with a loss function based on Kullback–Leibler (KL) divergence [58]. This requires the assumption that by interpolating in the latent space between two molecules, the decoded molecule would then have either a structure or property that also lies between these molecules. This is not an intuitive representation, as the chemical space is clearly discontinuous—there is nothing between e.g. C4H10 and C5H12. The LatentGAN heteroencoder instead makes no assumption with regards to the latent space as no ground truth exists for this representation. Instead it is trained based strictly on the categorial cross entropy loss of the reconstruction. The result in a space of encoded latent vectors that the GAN later trains on that does not necessarily have to be continuous.

The complexity of the SMILES representation can also be a problem the training, as molecules of similar structures can have very different canonical SMILES when the starting atom changes, resulting in dissimilar latent representations of the same molecule. By training on non-canonical (random) SMILES [14, 21], this issue is alleviated since different non-canonical forms of the same molecule are encoded to the same latent space point which furthermore leads to a more chemically relevant latent space [22]. In addition, the multiple representations of the same molecule during training reduces the risk of overfitting the conditional probabilities of the decoder towards compounds who share a common substring of the SMILES in the canonical representation.

## Section: Conclusions

A new molecule de novo design method, LatentGAN, was proposed by combining a heteroencoder and a generative adversarial network. In our method, the pretrained autoencoder was used to map the molecular structure to latent vector and the GAN was trained using latent vectors as input as well as output, all in separate steps. Once the training of the GAN was finished, the sampled latent vectors were mapped back to structures by the decoder of the autoencoder neural network. As a first experiment, after training on a subset of ChEMBL compounds, the LatentGAN was able to generate similar drug-like compounds. We later applied the method on three target biased datasets (EGFR, HTR1A and S1PR1) to investigate the capability of the LatentGAN to generate biased compounds. Encouragingly, our results show that most of the sampled compounds from the trained model are predicted to be active to the target which it was trained against, with a substantial portion of the sampled compounds being novel with respect to the training set. Additionally, after comparing the structures generated from the LatentGAN and the RNN based models for the corresponding targets, it seems that there is very little overlap among the two sets implying that the two types of models can be complementary to each other. In summary, these results show that LatentGAN can be a valuable tool for de novo drug design.

## Section: Supplementary information

Additional file 1. Supplementary figures and table.

## Section: Supplementary information

Additional file 1. Supplementary figures and table.

Additional file 1. Supplementary figures and table.


---

# A Machine Learning-Based Prediction Platform for P-Glycoprotein Modulators and Its Validation by Molecular Docking

- **Authors:** Onat Kadioglu, Thomas Efferth
- **Issuer:** Cells
- **Type:** Scientific article
- **Published:** 2019-10-21
- **Language:** en
- **DOI:** 10.3390/cells8101286
- **Source:** https://pubmed.ncbi.nlm.nih.gov/31640190/
- **Licence:** CC-BY

## Section: Abstract

P-glycoprotein (P-gp) is an important determinant of multidrug resistance (MDR) because its overexpression is associated with increased efflux of various established chemotherapy drugs in many clinically resistant and refractory tumors. This leads to insufficient therapeutic targeting of tumor populations, representing a major drawback of cancer chemotherapy. Therefore, P-gp is a target for pharmacological inhibitors to overcome MDR. In the present study, we utilized machine learning strategies to establish a model for P-gp modulators to predict whether a given compound would behave as substrate or inhibitor of P-gp. Random forest feature selection algorithm-based leave-one-out random sampling was used. Testing the model with an external validation set revealed high performance scores. A P-gp modulator list of compounds from the ChEMBL database was used to test the performance, and predictions from both substrate and inhibitor classes were selected for the last step of validation with molecular docking. Predicted substrates revealed similar docking poses than that of doxorubicin, and predicted inhibitors revealed similar docking poses than that of the known P-gp inhibitor elacridar, implying the validity of the predictions. We conclude that the machine-learning approach introduced in this investigation may serve as a tool for the rapid detection of P-gp substrates and inhibitors in large chemical libraries.

## Section: 1. Introduction

ATP-binding cassette (ABC) transporters are energy-dependent efflux pumps responsible for the active efflux of drugs, thereby reducing their intracellular concentration. Due to overexpression of ABC transporters in tumor cells, multidrug resistance (MDR) develops, which leads to the failure of chemotherapy with fatal consequences for cancer patients [1]. P-glycoprotein, being a well-known member among the ABC transporter family, is encoded by the ABCB1/MDR1 gene. It is an important determinant of MDR [2,3,4] and upregulated in many clinically resistant and refractory tumors [5,6]. Its overexpression in tumor cells is associated with efficient extrusion of a large number of established anticancer drugs and natural cytotoxic products out of cancer cells, representing a major drawback of cancer chemotherapy [7]. Resistance is either inherently present or will be acquired during chemotherapy [8,9,10]. Hence, P-glycoprotein (P-gp) represents an important target to search for pharmacological inhibitors to overcome MDR [11]. Targeting P-gp to overcome MDR is of importance to achieve higher success rates for chemotherapy. The concept is to combine P-gp inhibitors with established chemotherapy drugs to resensitize tumors [12,13,14,15].

Machine learning and artificial intelligence are recently acquiring increasing interest in the area of drug discovery [16,17,18] because these methods have an enormous potential to speed up the preclinical development processes at minimal costs. For this purpose, we utilized a machine learning strategy in order to establish a prediction platform that allows to predict whether a given compound behaves as a substrate or an inhibitor of P-gp.

Available natural compound databases serve as an invaluable source to identify novel lead compounds that possess activity against certain diseases or disorders by focusing on particular target biomarker proteins. As a majority of established anticancer drugs are of natural origin [19], natural products may serve as lead compounds for derivatization to obtain novel chemical entities with improved pharmacological features. Analyses of the interaction between the compounds and the target protein with molecular docking provide clues about the possible binding mode and binding energy, as we reported before [11,20,21]. Selecting P-gp as target protein, the interaction of test compounds can be compared with that of known P-gp inhibitors, such as verapamil, valspodar, tariquidar, or elacridar, in order to assess their binding properties, docking poses, and binding energies. In those cases, where the test compounds yielded by using the P-gp modulator prediction platform possess similar docking poses and comparable binding energies as known inhibitors, it could be concluded that these compounds may be potential P-gp inhibitors.

In the present study, we used machine learning strategies to establish such a P-gp modulator prediction platform for compounds by using defined chemical descriptors to predict whether a given compound can behave as a substrate or an inhibitor of P-gp. Selected compounds from inhibitor or substrate classes were subjected to molecular docking for further verification and compared with known P-gp inhibitors and substrates.

## Section: 2. Material and Methods › 2.1. Preparation of Compound List and Calculation of Chemical Descriptors

For the P-gp modulator/non-modulator prediction model, a compound list with modulators and non-modulators from Broccatelli et al. [22] was used. Compounds for learning and validation steps were randomly selected. Thirty-two modulator and thirty-two non-modulator compounds were used for the learning step, while 16 modulator and 16 non-modulator substances were used for the validation step (Table 1). For the P-gp inhibitor/substrate prediction model, a list of P-gp substrates and inhibitors was prepared by referring to the literature [23], yielding a total of 60 compounds (34 inhibitors, 26 substrates). Again, compounds for learning and validation steps were randomly selected. Forty compounds (20 inhibitors, 20 substrates) were used for learning and model establishment. The remaining 20 compounds (14 inhibitors, 6 substrates) were used for the external validation step (Table 2).

Data Warrior software is a multipurpose chemistry data visualization and data analysis program that calculates various molecular descriptors and properties for a given set of compounds. It was used to calculate the chemical descriptors as previously reported [24,25]. After calculation of the 32 chemical descriptors, correlation coefficients between descriptors and correlation of the descriptors with the P-gp modulator category (substrate or inhibitor) were determined using SPSS statistics software version 23.0.0.3 (IBM, Armonk, NY: IBM Corp, USA). If the correlation coefficient between the P-gp modulator category (substrate or inhibitor) and a certain descriptor was below 0.1, this descriptor was omitted. Only descriptors correlating with the P-gp modulator (substrate or inhibitor) category above 0.1 were selected for further processing. As a next step, descriptors having a pairwise correlation coefficient to the P-gp modulator category lower than 0.9 were excluded [26]. By this strategy, relevant descriptors without an issue of over-fitting can be selected.

## Section: 2. Material and Methods › 2.2. P-Glycoprotein Modulator Prediction Model Establishment

At first, a model, which can predict whether a given compound is a P-gp modulator, was built by using the compound list from Broccatelli et al. [22] After applying the descriptor selection criteria by considering the relevancy and over-fitting issues, “logP”, “H-donors”, “polar surface area”, “ligand efficiency dependent lipophilicity”, “molecular complexity”, “stereo centers”, “rotatable bonds”, “rings closures”, “aromatic rings”, “sp-3 atoms”, “amides”, “amines”, “alkyl-amines, ”and “basic nitrogens” were considered for the preparation of the P-gp modulator/non-modulator prediction model. Various classification algorithms with the leave-one-out random sampling method were tested, i.e., k-Nearest Neighboring (kNN), Neural Network, Random Forest (RF), and Support Vector Machine (SVM). Receiver operating characteristic (ROC) curves are depicted in Figure 1. The receiver operating characteristic (ROC) curve plotted the true positive rate (= sensitivity) against the false positive rate (= 1-specificity). The RF algorithm performed better than the other classification algorithms both in learning and validation steps. The overall performance for the established model based on RF algorithm is summarized in Table 3. The establishment of the P-gp modulator/non-modulator and P-gp inhibitor/substrate prediction models were performed by using the machine learning software Orange (Ljubljana, Slovenia) [27].

After applying the descriptor selection criteria by considering the relevancy and over-fitting issues, “logP”, “total surface area”, “shape index”, “molecular flexibility”, “rotatable bonds”, “aromatic rings”, “aromatic atoms”, “aromatic nitrogens”, “basic nitrogens”, “symmetric atoms”, and “acidic oxygens” were considered for P-gp inhibitor/substrate prediction model preparation. Various classification algorithms with the leave-one-out random sampling method were tested, i.e., kNN, Neural Network, RF, and SVM. The ROC curves are depicted in Figure 2. The RF algorithm performed better than the other classification algorithms. The overall performance for the established model is summarized in Table 4.

In order to evaluate the model performance further and select potential inhibitors, a P-gp modulator compound list consisting of 643 compounds from ChEMBL was used.

## Section: 2. Material and Methods › 2.3. Molecular Docking

The recently published human P-gp structure was used (nanodisc reconstituted in complex with UIC2 fab and paclitaxel at the drug-binding pocket, PDB ID: 6QEX, in the absence of a lipid bilayer) [28]. The Fab chains were deleted. The bound ligands marked as “HETATM” including taxol were also deleted from the PDB structure file in order to prevent interference with molecular docking. The preparation of the final receptor structure as “.pdbqt” file was performed with Autodock tools 1.5.7. Selected compounds from inhibitor and substrate classes have been subjected to an automated and comprising molecular docking campaign by using the high-performance supercomputer MOGON (Johannes Gutenberg University, Mainz). Compound flexibilities were taken into account and a rigid receptor structure was used. At first, three independent screening of all 643 compounds from ChEMBL with Autodock Vina algorithm was performed by focusing on the drug-binding pocket of P-gp, where the majority of the known inhibitors and substrates bind to. The grid parameters are listed in Table 5.

Afterward, the top 20 compounds in terms of binding energy yielded from both inhibitor and substrate predictions were selected for molecular docking. Each molecular docking was based on three independent dockings each consisting of 2,500,000 calculations. This means that each data point represents the mean value of 7,500,000 individual MOGON-based calculations. The Autodock 4 algorithm was used for defined molecular docking calculations on the drug-binding pocket of P-gp as described before [11], and Visual Molecular Dynamics (VMD) software (Theoretical and Computational Biophysics group at the Beckman Institute, University of Illinois at Urbana-Champaign) was used for the visualization of the docking poses. Estimated inhibition constants were calculated by the Autodock algorithm with the equation:(1)Ki=exp(ΔGR*T) Ki (M)ΔG (cal/mol) = 1000 * LBE (lowest binding energy, kcal/mol)R (cal/mol-K): gas constant, 1.986 cal/mol-KT (K): room temperature, 298 K

## Section: 2. Material and Methods › 2.4. Boxplot Analysis

The distribution of the values for the descriptors used for the P-gp inhibitor/substrate prediction model and the comparison for the predicted inhibitors and substrates among the ChEMBL P-gp modulator list were subjected to Boxplot analysis using Microsoft Excel 2019 (Microsoft, USA). Statistical significances were evaluated by the t-test (two-tailed, two-sample unequal variance).

## Section: 3. Results › 3.1. P-glycoprotein Modulator Predictions

The P-gp modulator/non-modulator prediction model was evaluated with the validation set as mentioned in the corresponding method part. The RF algorithm reached 0.938 for all parameters. The ChEMBL P-gp modulator list of 643 compounds was tested, and 641 out of 643 substances were correctly predicted as modulators.

The P-gp inhibitor/substrate prediction model with the ChEMBL P-gp modulator list of 643 compounds was evaluated. A total of 493 substances were predicted as inhibitors, and 150 compounds were predicted as substrates. Subjecting all compounds to Autodock Vina screening allowed to rank them according to their binding energies. The top 20 inhibitor predictions with strong interaction to P-gp are shown in Table 6. These inhibitors were selected for subsequent molecular docking. The top 20 substrate predictions with strong interaction to P-gp are shown in Table 7. These substrates were also selected substances for subsequent molecular docking. The complete predictions for all 493 inhibitors together with their binding affinities to P-gp are shown in Supplementary Table S1, while all predictions for the 150 substrates and their affinities to P-gp are listed in Supplementary Table S2. The average lowest binding energy (LBE) was -8.155 for the inhibitors and -9.289 for the substrates.

Among the 493 inhibitor compounds were 117 natural products (= 23.7%), while all other compounds were of synthetic origin (Supplementary Table S1). The proportion of natural products was higher among the predicted P-gp substrates (69/150 = 46%) (Supplementary Table S2). This trend was even more apparent if we focused on the top 20 inhibitor or substrate compounds only (Table 6 and Table 7). Here, 2/20 (= 10%) were predicted inhibitors, but 11/20 (= 55%) were predicted substrates, indicating that P-glycoprotein may expel natural xenobiotics from cells with higher probability.

## Section: 3. Results › 3.2. Molecular Docking

After running the prediction model on the P-gp modulator list from ChEMBL and the Autodock VINA screening, the top 20 compounds from the inhibitor class and the top 20 compounds from the substrate class were selected for molecular docking analyses on human P-gp. The lowest binding energies (LBE) and predicted inhibition constants are listed in Table 8 for the inhibitors and Table 9 for the substrates.

The negative control compounds (oxprenolol, promazine, riluzole) revealed weaker interaction with P-gp (Table 10) and slightly different docking pose as well (Figure 3).

As can be seen in Figure 4, the predicted inhibitors possessed similar docking poses as elacridar at the drug-binding pocket of P-gp. Similar results were observed for the substrates: The predicted substrates revealed similar docking poses as doxorubicin. Hence, these results validated the precision and reliability of the model.

Predicted inhibitors and substrates interact with P-gp significantly stronger than the negative control compounds. This is clear both from the binding energies and predicted inhibition constants. Binding energies of non-modulators are within −5.380 (piluzole) to −6.933 (promazine) kcal/mol and the predicted inhibition constants are within 8.273–114.080 µM, whereas binding energies for the predicted substrates are within −7.337 (vindoline) to −12.500 (latilagescene G) and for the predicted inhibitors −8.900 (3-methylcholanthrene) to −13.537 (karavoate P). Predicted inhibition constants for the predicted substrates are within 0.001–4.363 and for the predicted inhibitors 0.0002–0.300 µM. Docking pose of the negative control compounds differs from that of inhibitors and substrates. Overall, it can be speculated that the predicted inhibitors interact with P-gp stronger than the predicted substrates and the non-modulators are making weak interactions with P-gp and they bind to a different site.

The distribution of the values for the descriptors used to build the model and the comparison for the predicted inhibitors and substrates in terms of those descriptor values were performed with Boxplot analysis. As can be seen from Figure 5, the inhibitors revealed significantly different values for all descriptors except logP and acidic oxygens. The average values of descriptors for inhibitors and substrates are listed in Table 11.

## Section: 4. Discussion

In the present study, we utilized machine learning methods based on leave-one-out random sampling in order to develop a P-gp modulator prediction platform by using chemical descriptors. The main focus was to predict whether a given compound can behave as substrate or inhibitor of P-gp. The RF classification algorithm (AUC:0.774) outperformed the other tested algorithms (kNN—0.676, Neural Network—0.745, SVM—0.720). Performance scores for the external validation set were even higher than the learning set with better sensitivity (0.786 vs. 0.750), specificity (0.833 vs. 0.700), overall prediction accuracy (0.800 vs. 0.725), and precision (0.917 vs. 0.714). Further testing with the P-gp modulator list from ChEMBL yielded promising results with accurate predictions. Four compounds from inhibitor and four compounds from substrate prediction list were selected for molecular docking analyses. Validations with molecular docking on a recently released human P-gp structure were performed in terms of binding energy and docking poses by including known inhibitor (elacridar) and substrate (doxorubicin) as controls. Curcumin, miconazole, tacrolimus, and venlafaxine revealed a similar docking pose at the drug-binding pocket of P-gp with comparable binding energies with that of elacridar. MK-3207, rifampin, vindoline, and voacamine revealed similar docking poses and comparable binding energy with those of doxorubicin. Overall, the precision and reliability of the model were further confirmed.

Machine learning and artificial intelligence attracted increasing interest in the drug discovery area [18,29,30], and utilizing these methods possess great potential for drug discovery, as they save time and costs during the preclinical steps. The RF algorithm depends on multiple decision trees that are built based on the training data, and a majority voting scheme is used to make classification or regression predictions [31]. RF application to drug discovery has been recently reported, and it outperformed other algorithms such as SVM and NN in terms of feature selection [32].

There are various studies in the literature that utilized machine-learning strategies focusing on P-gp. One study pointed out a P-gp substrate prediction model based on RF algorithm to estimate transport potential for central nervous system drugs, accuracy lies between 0.713 and 0.846 whereas precision is between 0.633 and 0.777 [33]. Our P-gp modulator prediction model involves an accuracy of 0.953 for the learning set and 0.938 for the validation set, and our P-gp inhibitor prediction model has an accuracy value of 0.725 for the learning set and 0.800 for the validation set. In terms of precision, our models also perform better. Modulator prediction model involves a precision of 0.968 for the learning set and 0.938 for the validation set. Inhibitor prediction model has a 0.714 precision for the learning set and 0.917 for the validation set. Similarly, a P-gp substrate efflux ratio prediction model has been recently reported based on SVM algorithm [34]. The affinities of flavonoids to P-gp have been evaluated with an SVM-based model and a high correlation with the experimental data has been achieved [35]. Another study involving P-gp inhibitor prediction was performed for chalcone derivatives and selected inhibitor candidates were analyzed in terms of their docking pose on a homology model of human P-gp [36]. The prediction of blood–brain barrier permeability mechanism of central nervous system drugs has been utilized with an SVM-based model [37]. Binding pattern prediction based on pharmacophore ensemble/SVM method for potential P-gp inhibitors was also recently reported [38]. Another SVM-based model coupled with molecular docking aimed to predict whether a given compound may act as P-gp substrate, the accuracy lies between 0.750 and 0.800, specificity between 0.750 and 0.810, and sensitivity between 0.740 and 0.790 [39]. Our modulator prediction model outperforms that model in all those parameters. Our inhibitor prediction model outperforms in the validation set. Similarly, in 2004, SVM-based P-gp substrate prediction model was reported; sensitivity was 0.812, specificity was 0.792, and accuracy was 0.794 [40]. Our modulator prediction model outperforms that model in all those parameters. Our inhibitor prediction model outperforms in the validation set for the specificity and accuracy parameters. In general, these previously published studies have certain disadvantages, e.g., low performance scores in terms of prediction, focusing on only P-gp substrate prediction or molecular docking with homology models but not crystal structures. Our model is superior compared to the previously published studies for several reasons. It is based on leave-one-out random sampling RF algorithm, focused on both natural as well as synthetic compounds, has high sensitivity, specificity, predictive accuracy, and precision to predict at first P-gp modulator/non-modulator and as a next step to predict P-gp substrate/inhibitor depending on various chemical descriptors, and it was coupled with molecular docking using the recently released crystal structure of human P-gp. The fact that predictions on the P-gp modulator list of compounds from ChEMBL was validated with accurate molecular docking results was also advantageous for our model. Furthermore, after the initial compound screening, selected inhibitors revealed similar docking poses as elacridar (as positive control for an inhibitor) and selected substrates revealed similar docking poses as doxorubicin (as positive control for a substrate). Non-modulators have significantly weaker interaction with P-gp and they bind to a slightly different position. Overall, those observations provide further clues for the reliability of the prediction model.

Selected inhibitors and substrates after the virtual screening are supported by literature; astemizole [41], cryptotanshinone [42], dihydrocytochalasin B [43], jolkinol B [44], latilagascenes D [45], lonafarnib [46], tariquidar [12], zosuquidar [47], acetyldigitoxin [48], bromocriptine [49], candesartan cilexetil [50], cepharanthin [51], cytochalasin E [52], digitoxin [53], digoxin [54], dihydroergosrictine [55], dofequidar [56], ergocristine [55], irinotecan [57], latilagascenes E [45], MK-3207 [58], paclitaxel [59], vindoline [60].

Many cancer types involve P-gp overexpression, which is associated with increased efflux of established anticancer drugs and natural cytotoxic products out of cancer cells. This phenomenon represents a major drawback of cancer chemotherapy with limitations in killing tumor populations due to MDR [61,62]. P-gp overexpression is indeed one of the main reasons for MDR and thus inadequate chemotherapy success rate. Targeting P-gp is critical to achieve high success rates for chemotherapy, therefore, identification of novel P-gp inhibitors is critical in that regard.

Our prediction platform for P-gp modulators facilitates to predict whether a given compound can behave as a substrate or an inhibitor of P-gp. The selection of potential inhibitors can be further validated by molecular docking and the comparison of the binding energy and docking pose with those of known P-gp inhibitors. As a next step in the future, our model may be helpful to identify potential novel P-gp inhibitors and to develop effective chemotherapy strategies involving combination therapy with targeted chemotherapy drugs and identified P-gp inhibitors.

## Section: 5. Conclusion

In the present study, we established P-gp modulator/non-modulator and inhibitor/substrate prediction models based on the RF algorithm and leave-one-out random sampling. Validation with molecular docking was performed. The identification of novel P-gp inhibitors is critical to overcome MDR and to achieve better chemotherapy strategies. This model can predict whether a given compound can behave as substrate or inhibitor of P-gp, and will be, thus, helpful to identify potential P-gp inhibitors.


---

# BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding

- **Authors:** Jacob Devlin, Ming-Wei Chang, Kenton Lee, Kristina Toutanova
- **Issuer:** Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies (NAACL-HLT)
- **Type:** Scientific article
- **Published:** 2019-01-01
- **DOI:** 10.18653/v1/n19-1423
- **Source:** https://doi.org/10.18653/v1/n19-1423
- **Licence:** CC-BY

## Section: Abstract

Jacob Devlin, Ming-Wei Chang, Kenton Lee, Kristina Toutanova. Proceedings of the 2019 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies, Volume 1 (Long and Short Papers). 2019.


---

# DeepAffinity: interpretable deep learning of compound–protein affinity through unified recurrent and convolutional neural networks

- **Authors:** Mostafa Karimi, Di Jia Wu, Zhangyang Wang, Yang Shen
- **Issuer:** Bioinformatics
- **Type:** Scientific article
- **Published:** 2019-02-15
- **DOI:** 10.1093/bioinformatics/btz111
- **Source:** https://doi.org/10.1093/bioinformatics/btz111
- **Licence:** CC-BY-NC-ND

## Section: Abstract

MOTIVATION: Drug discovery demands rapid quantification of compound-protein interaction (CPI). However, there is a lack of methods that can predict compound-protein affinity from sequences alone with high applicability, accuracy and interpretability. RESULTS: We present a seamless integration of domain knowledges and learning-based approaches. Under novel representations of structurally annotated protein sequences, a semi-supervised deep learning model that unifies recurrent and convolutional neural networks has been proposed to exploit both unlabeled and labeled data, for jointly encoding molecular representations and predicting affinities. Our representations and models outperform conventional options in achieving relative error in IC50 within 5-fold for test cases and 20-fold for protein classes not included for training. Performances for new protein classes with few labeled data are further improved by transfer learning. Furthermore, separate and joint attention mechanisms are developed and embedded to our model to add to its interpretability, as illustrated in case studies for predicting and explaining selective drug-target interactions. Lastly, alternative representations using protein sequences or compound graphs and a unified RNN/GCNN-CNN model using graph CNN (GCNN) are also explored to reveal algorithmic challenges ahead. AVAILABILITY AND IMPLEMENTATION: Data and source codes are available at https://github.com/Shen-Lab/DeepAffinity. SUPPLEMENTARY INFORMATION: Supplementary data are available at Bioinformatics online.


---

# DeepConv-DTI: Prediction of drug-target interactions via deep learning with convolution on protein sequences

- **Authors:** Ingoo Lee, Jongsoo Keum, Hojung Nam
- **Issuer:** PLoS Computational Biology
- **Type:** Scientific article
- **Published:** 2019-06-14
- **DOI:** 10.1371/journal.pcbi.1007129
- **Source:** https://doi.org/10.1371/journal.pcbi.1007129
- **Licence:** CC-BY

## Section: Abstract

AbstractIdentification of drug-target interactions (DTIs) plays a key role in drug discovery. The high cost and labor-intensive nature of in vitro and in vivo experiments have highlighted the importance of in silico-based DTI prediction approaches. In several computational models, conventional protein descriptors have been shown to not be sufficiently informative to predict accurate DTIs. Thus, in this study, we propose a deep learning based DTI prediction model capturing local residue patterns of proteins participating in DTIs. When we employ a convolutional neural network (CNN) on raw protein sequences, we perform convolution on various lengths of amino acids subsequences to capture local residue patterns of generalized protein classes. We train our model with large-scale DTI information and demonstrate the performance of the proposed model using an independent dataset that is not seen during the training phase. As a result, our model performs better than previous protein descriptor-based models. Also, our model performs better than the recently developed deep learning models for massive prediction of DTIs. By examining pooled convolution results, we confirmed that our model can detect binding sites of proteins for DTIs. In conclusion, our prediction model for detecting local residue patterns of target proteins successfully enriches the protein features of a raw protein sequence, yielding better prediction results than previous approaches. Our code is available at https://github.com/GIST-CSBL/DeepConv-DTI.

## Section: Introduction

The identification of drug-target interactions (DTIs) plays a key role in the early stage of drug discovery. Thus, drug developers screen for compounds that interact with specified targets with biological activities of interest. However, the identification of DTIs in large-scale chemical or biological experiments usually takes 2~3 years of experiments, with high associated costs [1]. Therefore, with the accumulation of drugs, targets, and interaction data, various computational methods have been developed for the prediction of possible DTIs to aid in drug discovery.

Among computational approaches, docking methods, which simulate the binding of a small molecule and a protein using 3D structure, were initially studied. Docking methods recruit various scoring functions and mode definitions to minimize free energy for binding. Docking methods have advanced by themselves, and recently, the Docking Approach using Ray-Casting (DARC) model identified 21 compounds by using an elaborate binding pocket topography mapping methodology, and the results were reproduced in a biochemical assay [2]. In addition, studies have examined several similarity-based methods in which it was assumed that drugs bind to proteins similar to known targets and vice versa. One of the early methods is that of Yamanashi et al., which utilized a kernel regression method to use the information on known drug interactions as the input to identify new DTIs, combining a chemical space and genomic spaces into a pharmacological space [3]. To overcome the requirement of the bipartite model for massive computational power, Beakley et al. developed the bipartite local model, which trains the interaction model locally but not globally. In addition to substantially reducing the computational complexity, this model exhibited higher performance than the previous model [4]. As another approach to DTI prediction models, matrix factorization methods have been recruited to predict DTIs, which approximate multiplying two latent matrices representing the compound and target protein to an interaction matrix and similarity score matrix [5, 6]. In this work, regularized matrix factorization methods successfully learn the manifold lying under DTIs, giving the highest performance among previous DTI prediction methods. However, similarity-based methods are not commonly used at present to predict DTIs, as researchers have found that similarity-based methods work well for DTIs within specific protein classes but not for other classes [7]. In addition, some proteins do not show strong sequence similarity with proteins sharing an identical interacting compound [8].

Thus, feature-based models that predict DTI features of drugs and targets have been studied [9–11]. For feature-based DTI prediction models, a fingerprint is the most commonly used descriptor of the substructure of a drug [12]. With a drug fingerprint, a drug is transformed into a binary vector whose index value represents the existence of the substructure of the drug. For proteins, composition, transition, and distribution (CTD) descriptors are conventionally used as computational representations [13]. Unfortunately, feature-based models that use protein descriptors and drug fingerprints showed worse performance than previous conventional quantitative structure-activity relationship (QSAR) models [9]. To improve the performance of feature-based models, many approaches have been developed, such as the use of interactome networks [14, 15] and minwise hashing [16]. Although various protein and chemical descriptors have been introduced, feature-based models do not show sufficiently good predictive performance [17]. For conventional machine learning models, features must be built to be readable by modeling from original raw forms, such as simplified molecular-input line entry system (SMILES) and amino acid sequences. During transformation, rich information, such as local residue patterns or relationships, is lost. In addition, it is hard to recover lost information using traditional machine learning models.

In recent years, many deep learning approaches have recently been developed and recruited for omics data processing [18] as well as drug discovery [19], and these approaches seem to be able to overcome limitations. For example, DeepDTI built by Wen et al. used the deep belief network (DBN) [20], with features such as the composition of amino acids, dipeptides, and tripeptides for proteins and extended-connectivity fingerprint (ECFP) [21] for drugs [7]. The authors also discussed how deep-learning-based latent representations, which are nonlinear combinations of original features, can overcome the limitations of traditional descriptors by showing the performance in each layer. In another study by Peng et al. [22], MFDR employed sparse Auto-Encoder (SAE) to abstract original features into a latent representation with a small dimension. With latent representation, they trained a support vector machine (SVM), which performed better than previous methods, including feature- and similarity-based methods. In another study called DL-CPI by Tian et al. [23], domain binary vectors were employed to represent the existence of domains used to describe proteins.

One way to reduce the loss of feature information is to process raw sequences and SMILES as their forms. In a paper by Öztürk et al., DeepDTA was used to represent raw sequences and SMILES as one-hot vectors or labels [24]. With a convolutional neural network (CNN), the authors extracted local residue patterns to predict the binding affinity between drugs and targets. As a result, their model exhibited better performance on a kinase family bioassay dataset [25, 26] than the previous model, kronRLS [27] and SimBoost [28]. Because their model is optimized by densely constructed kinase affinities, DeepDTA is appropriate to predict kinase affinities not to predict new DTIs with various protein classes. Furthermore, they evaluated their performances on the identical dataset, rather than on independent dataset from new sources or databases.

To overcome the aforementioned problems, here, we introduce a deep learning model that predicts massive-scale DTIs using raw protein sequences not only for various target protein classes but also for diverse protein lengths. The overall pipeline of our model is depicted in Fig 1. First, for the training model, we collected large-scale DTIs integrated from various DTI databases, such as DrugBank [29], International Union of Basic and Clinical Pharmacology (IUPHAR) [30], and Kyoto Encyclopedia of Genes and Genomes (KEGG) [31]. Second, in model construction, we adopted convolution filters on the entire sequence of a protein to capture local residue patterns, which are the main protein residues participating in DTIs. By pooling the maximum CNN results of sequences, we can determine how given protein sequences match local residue patterns participating in DTIs. Using these data as input variables for higher layers, our model constructs, abstracts and organizes protein features. After new protein features are generated, our model concatenates protein features with drug features, which come from fingerprints in the fully connected layer and predict the probability of DTIs via higher fully connected layers. Third, we optimized the model with DTIs from MATADOR [32] and negative interactions predicted from Liu et al. [33]. Finally, with the optimized model, we predicted DTIs from bioassays such as PubChem BioAssays [34] and KinaseSARfari [35] to estimate the performance of our model. As a result, our model exhibits better performance than previous models.

First, we collected training DTI datasets from various databases (DrugBank, KEGG, IUPHAR). Second, we constructed the neural network model using convolution, which is able to capture local residue patterns that can help the DTIs. Third, we optimized the hyperparameters with an external validation dataset that we constructed. Finally, we predicted DTIs from bioassays (independent test dataset) and evaluated the performance of our model. The numbers (#) of compounds, proteins and DTIs are summarized in each step.

## Section: Results

The AUPR and AUC of the convolution, CTD, and similarity descriptors are shown in panels (A) and (B), respectively.

We measured various performances such as sensitivity (Sen.), specificity (Spe.), precision (Pre.), accuracy (Acc.), and F1 score (F1) from the prediction results given by descriptors (A-D). (A) All queried PubChem datasets. (B) PubChem dataset whose compounds are not in the training dataset. (C) PubChem dataset whose targets are not in the training dataset. (D) PubChem dataset whose compounds and targets are not in the training dataset. Our convolution model shows better performances for all datasets in terms of accuracy and F1 score.

We compared performances of our model on independent test dataset (PubChem) with previous models (MFDR, DeepDTI, and DeepDTA). Our model gives better performances than previous models for accuracy and F1 metrics.

We executed a right-tailed t-test for the number of covering binding sites from the convolution results with a null distribution, which was constructed from the randomly generated convolution results in the sc-PDB database consisting of 7,179. Because each sc-PDB test has many windows, we selected the most significant p-values adjusted by the Benjamini-Hochberg procedure and examined whether they were significant at levels of 1%, 5% and 10%. The results showed that 14.6%, 30.3% and 42.2% of sc-PDB entries were significantly enriched, respectively (A-C).

We visualized two highly scored sc-PDB entries from two perspectives—the whole receptor-ligand complex and binding site-ligand perspectives—by using UCSF Chimera. To visualize convolution results with a simplified view, first, we selected the top 5 ranked globally max-pooled results among all filters for each window because whole protein sequences are usually covered by convolution results if we select all results. Second, we rendered residues covered by the convolution results by the number of covering convolution results. (A) Complex of the ion channel protein Peptidyl-prolyl cis-trans isomerase FKBP1A (FKB1A_HUMAN in UniProt), which has a short sequence length (108), and FKA in the PDB ligand (1a7x_1 in sc-PDB). As we can see, the number of convolution results near the ligand is more than the number for the other region. (B) For the binding site and ligand of 1a7x_1, most of the binding sites are highly covered by the convolution results. (C) Complex of the kinase protein MAP kinase-activated protein kinase 2 (MAPK2_HUMAN in UniProt) with a sequence length of 400 and ADP in the PDB ligand (1ny3_1 in sc-PDB). Although half of the protein sequence is not represented as a 3D structure, our convolution results cover regions close to ligand binding sites in a biased manner. However, some residues far from binding sites are also highlighted by convolution results, potentially indicating some important structural motifs for binding. (D) For the binding site and ligand of 1ny3_1, most binding sites are covered by the convolution results, although some residues are not covered.

## Section: Results › Performances of the validation dataset and selected hyperparameters

As a normal step of hyperparameter setting, we first tuned the learning rate of the weight update to 0.0001. After the learning rate was fixed, we benchmarked the sizes and number of windows, hidden layers of the drug features, and the concatenating layers with the area under precision-recall (AUPR) on the external unseen validation dataset, which was built with MATADOR and a highly credible negative dataset. Finally, we selected the hyperparameters of the model, as shown in Table A in S1 Text, with the external unseen validation dataset, yielding an AUPR of 0.832 and area under the curve (AUC) of 0.852, as shown in Fig 2. The AUPR value of our model was less than the AUPR of the similarity descriptor; however, that does not mean that our method has lower prediction performance than the similarity method because the size of the validation is too small to evaluate the general performance. In addition, we further examined the effect of fixed maximum protein length on the prediction performance. As shown in Fig A in S1 Text, we confirmed that the prediction performance of our model is not biased to the fixed maximum protein length. Finally, the fully optimized model is visualized as a graph, shown in S1 Fig, respective to our model, the CTD descriptor, and similarity descriptors. In the same manner, we built and optimized models that use other protein descriptors with the same activation function, learning rate, and decay rate.

The AUPR and AUC of the convolution, CTD, and similarity descriptors are shown in panels (A) and (B), respectively.

## Section: Results › Comparison of performance with other protein descriptors

After the hyperparameters were tuned, we compared the performance based on the independent test datasets with the different protein descriptors, the CTD descriptor (which is usually used in the conventional chemo-genomic model) [13], the normalized Smith-Waterman (SW) score [36], and our convolution method. The results showed that our model exhibited better performance than the other protein descriptors for all datasets, as shown in Fig 3 and Fig B in S1 Text. With the threshold selected by the equal error rate (EER) [37], our model performed equally well with both the PubChem and KinaseSARfari datasets, indicating that our model has general application power. Our convolution method gave the highest accuracy score and F1 score for the PubChem dataset (Fig 3A) [34] and its subsets (Fig 3B–3D) and a slightly lower F1 score for the KinaseSARfari dataset (Fig B in S1 Text) [35]. The CTD descriptor gave the lowest score for any dataset and any metric, which implies that CTD is less informative and less enriched than the other descriptors. Here, we also observed that the model performance using a similarity descriptor for the KinaseSARfari dataset was similar to that of the proposed model. We can interpret this result as the similarity descriptor acts as an informative feature as a local residue pattern at the domain level, not the whole protein complex.

We measured various performances such as sensitivity (Sen.), specificity (Spe.), precision (Pre.), accuracy (Acc.), and F1 score (F1) from the prediction results given by descriptors (A-D). (A) All queried PubChem datasets. (B) PubChem dataset whose compounds are not in the training dataset. (C) PubChem dataset whose targets are not in the training dataset. (D) PubChem dataset whose compounds and targets are not in the training dataset. Our convolution model shows better performances for all datasets in terms of accuracy and F1 score.

## Section: Results › Performance comparison with a previous model

In addition to the comparison between convolution in our model and other protein descriptors, in this section, we compared the performance of our model against recently developed deep-learning-based models. We selected three deep learning models for comparisons, SAE (MFDR, Peng et al, 2016) [22], DBN (DeepDTI, Wen et al, 2017) [7] and CNN (DeepDTA, Ozturk et al, 2018). First, MFDR trains SAE in an unsupervised manner, while proteins are represented by multi-scale local descriptor feature [38] and compounds are represented by PubChem fingerprints as input and output for SAE. With trained deep representations of sparse Auto-Encoder, they performed 5-fold cross-validation by using SVM. As a result, their model gives better performances than previous bipartite local models. Because the authors do not provide the model, we implemented the MFDR model with optimized parameters the author provided in their original paper. We tested the validity of implemented MFDR and confirmed that the implemented model produces reasonably same performance compared to the results from its original work (see Fig C S1 Text). Second, DeepDTI built by Wen et al. is based on DBN [20], which is a stack of restricted Boltzmann machine (RBM). DeepDTI takes amino acid, dipeptide and tripeptide compositions (protein sequence composition descriptors, PSC) as the protein input and ECFP with radius 1, 2 and 3 as the compound input. We used DeepDTI with the code that the authors provided (https://github.com/Bjoux2/DeepDTIs_DBN) and optimized hyperparameters as the authors mentioned. Third, DeepDTA built by Ozturk et al. used stacked CNN on protein sequences and SMILES to predict affinity between target protein and compound. DeepDTA is optimized for Davis [25] and KIBA [26] dataset which contains kinases protein, their inhibitors, and dense affinity values, showing better prediction performances than previous affinity prediction models. We also used DeepDTA with the code from the original work (https://github.com/hkmztrk/DeepDTA) and optimized hyperparameters they provided. For the DTI prediction performance comparison, we activate the last layer with sigmoid function to predict interaction, not affinity, also we changed loss function as binary cross-entropy from mean squared error. It should be noticed that we compared the performance of all three models by training and testing with the same data set we used for a fair comparison.

Results of performance comparison between our proposed model and the three related models are shown in Fig 4, showing that performances (accuracy, F1) of our model (DeepConv-DTI) are better than other models. MFDR which gave high AUC in 5-fold cross-validation shows decreased performances in the independent test dataset. We can speculate that SAE which learns deep representation of DTI in an unsupervised way is not appropriate for a case that datasets are composed of various protein classes. In the case of DeepDTI, DeepDTI takes physicochemical properties (PSC) of whole protein sequence including subsequences or domains which do not participate in the interaction with compounds, resulting in worse performance than our model which extracts local residue patterns. For DeepDTA, DeepDTA also shows worse performances than our model with having a relatively large variance. We interpret the worse performance of DeepDTA as follows. DeepDTA is optimized for a densely constructed dataset with specific protein class, while the training dataset in this comparison covers various protein classes (kinase, protease, ion channel, nuclear receptor, GPCR, etc), not only kinase class. Thus, DeepDTA which is specialized for a specific protein class could not achieve better prediction performance in the generalized protein classes.

In addition to the three models we compared, we also compared our model with DL-CPI [23] built by Tian et al. which used protein domain information. For proteins whose domain information is not in Pfam [39], datasets for training, validation and test are not fully available. Therefore, we independently compared performances between DL-CPI and our model by additionally built the training, validation, and test datasets. Performance comparison results are described in Fig E in S1 Text. We confirmed that the proposed model shows better performance than DL-CPI. Because protein descriptor of DL-CPI is sparse, containing few values in large dimension, which may decrease performances.

In overall, our model shows better performance than previous deep learning models in an independent test dataset from a different database, which contains distinct DTIs, dealing with DTIs with various protein classes and their interacting compounds.

We compared performances of our model on independent test dataset (PubChem) with previous models (MFDR, DeepDTI, and DeepDTA). Our model gives better performances than previous models for accuracy and F1 metrics.

## Section: Results › Analysis of convolution results

Because we pooled the maximum convolution results by each filter for each window, the pooled results could highlight regions of matches with local residue patterns. Although we cannot measure exactly how those values affect the DTI prediction results, the pooled maximum convolution result will affect the prediction performance by going through higher fully connected layers. Therefore, if our model is capable of capturing local residue patterns, it would give high values to important protein regions, such as actual binding sites.

Examining and validating the convolution results from the intermediate layer showed that our model could capture local residue patterns that participate in DTIs. The sc-PDB database provides atom-level descriptions of proteins, ligands, and binding sites from complex structures [40]. By parsing binding site annotations, we can query binding sites between protein domains and pharmacological ligands for 7,179 entries of Vertebrata. From the queried binding sites and pooled maximum convolution results, we statistically test our assumption that the pooled maximum convolution results cover the important regions, including binding sites. Each window has 128 pooled convolution results, which shows bias in covering some regions. Thus, we randomly generated 128 convolution results 10,000 times for each sc-PDB entry and counted how many of those random results covered each amino acid in the binding sites, which resulted in the construction of normal distributions. For each normal distribution constructed by the randomly generated convolution results, considered a null hypothesis, we executed a right-tailed t-test with the number from the convolution results of our model for each window. Because we did not know which window detects the binding site, we took the most significant p-value (minimum p-value adjusted by the Benjamini-Hochberg procedure [41]). The sc-PDB entry information and p-values of a window for each sc-PDB entry are summarized in the S1 File. We summarize the results of binding site detection from the most significant p-value among windows by significance level cutoff in Fig 5. In addition, we examined sc-PDB entries with the most significant p-values for diverse window sizes. We visualized two high-score sc-PDB entries from two perspectives—the whole receptor-ligand complex and binding site-ligand perspectives—by using UCSF Chimera [42] as shown in Fig 6. To visualize convolution results with a simplified view, first, we selected the top 5 ranked globally max-pooled results among all filters for each window because whole protein sequences are usually covered by convolution results if we select all results. Second, we rendered residues covered by convolution results by the number of covering convolution results. We visualized two sc-PDB entries, 1a7x_1 and 1ny3_1. 1a7x_1, representing the complex of the ion channel, protein Peptidyl-prolyl cis-trans isomerase FKBP1A (FKB1A_HUMAN in UniProt), which has a short sequence length (108), and BENZYL-CARBAMIC ACID [8-DEETHYL-ASCOMYCIN-8-YL]ETHYL ESTER (FKA in PDB ligand) [43]. 1ny3_1 is the complex of the kinase protein, MAP kinase-activated protein kinase 2 (MAPK2_HUMAN in UniProt) with sequence length 400, and ADENOSINE-5’-DIPHOSPHATE (ADP in PDB ligand) [44]. Through the above evaluation, we can confirm that our proposed model is capable of capturing local residue patterns of proteins that are considered important features for DTI prediction, such as actual binding sites.

We executed a right-tailed t-test for the number of covering binding sites from the convolution results with a null distribution, which was constructed from the randomly generated convolution results in the sc-PDB database consisting of 7,179. Because each sc-PDB test has many windows, we selected the most significant p-values adjusted by the Benjamini-Hochberg procedure and examined whether they were significant at levels of 1%, 5% and 10%. The results showed that 14.6%, 30.3% and 42.2% of sc-PDB entries were significantly enriched, respectively (A-C).

We visualized two highly scored sc-PDB entries from two perspectives—the whole receptor-ligand complex and binding site-ligand perspectives—by using UCSF Chimera. To visualize convolution results with a simplified view, first, we selected the top 5 ranked globally max-pooled results among all filters for each window because whole protein sequences are usually covered by convolution results if we select all results. Second, we rendered residues covered by the convolution results by the number of covering convolution results. (A) Complex of the ion channel protein Peptidyl-prolyl cis-trans isomerase FKBP1A (FKB1A_HUMAN in UniProt), which has a short sequence length (108), and FKA in the PDB ligand (1a7x_1 in sc-PDB). As we can see, the number of convolution results near the ligand is more than the number for the other region. (B) For the binding site and ligand of 1a7x_1, most of the binding sites are highly covered by the convolution results. (C) Complex of the kinase protein MAP kinase-activated protein kinase 2 (MAPK2_HUMAN in UniProt) with a sequence length of 400 and ADP in the PDB ligand (1ny3_1 in sc-PDB). Although half of the protein sequence is not represented as a 3D structure, our convolution results cover regions close to ligand binding sites in a biased manner. However, some residues far from binding sites are also highlighted by convolution results, potentially indicating some important structural motifs for binding. (D) For the binding site and ligand of 1ny3_1, most binding sites are covered by the convolution results, although some residues are not covered.

## Section: Results › t-SNE visualization of proteins

From the results shown in Fig 6, we can confirm that our model can capture the local residue patterns of proteins that participate in DTIs. Thus, to examine further characteristics of the captured protein local residue patterns, we visualized the protein features from the fully connected layer after the global max-pooling of convolution results. We visualized 1,527 proteins used in the training dataset categorized in various protein classes. Specifically, we visualized 257 GPCRs, 44 nuclear receptors, 304 ion channel receptors, 604 kinases, and 318 proteases. For visualization, we conducted t-distributed stochastic neighbor embedding (t-SNE) for dimension reduction and visualization [45]. t-SNE can map high-dimensional features to low-dimensional ones, such as 2-dimensional features, minimizing information loss during dimension reduction. Surprisingly, although our model is not intended to identify protein classes, it can roughly discriminate protein classes from the intermediate protein layer, as shown in Fig G in S1 Text.

## Section: Discussion

In this work, we built a novel DTI prediction model to extract local residue patterns of whole target protein sequences with CNN. We trained the model with DTIs from various drug databases and optimized the model with an external validation dataset. As a result, the detected local features of protein sequences perform better than other protein descriptors, such as CTD and SW scores. Our model also performs better than a previous model built on DBN. In addition, by analyzing pooled convolution results and statistically and manually comparing them with annotations from sc-PDB entries, we showed that, for some proteins, our model is capable of detecting important regions, including binding sites. Therefore, our approach of capturing local residue patterns with CNN successfully enriches protein features for DTI prediction.

The number of 3D structures in Protein Data Bank [46] is relatively smaller than the number of sequences, limiting 3D structure-based DTI prediction methods. For example, the number of PDB entries for Homo sapiens is 42,745, while the number of protein sequences for Homo sapiens is 177,661 in UniProtKB. However, our method does not depend on the 3D structure of proteins because it considers only protein sequence, rather than classical protein feature descriptors such as the CTD descriptor and normalized SW score. As a result, our method can be more generally applied to predict DTIs than methods needing 3D structures.

Although our model shows improved prediction performance, there is still room for improvement. First, we simply used Morgan/Circular fingerprints, which are binary and have large dimensions. Therefore, we will use more informative chemical descriptors, based on neural networks for DTI prediction, to achieve advanced performance. Second, as shown in a previous study [47], considering 3D structure information is an effective substitution for chemical elaboration. Therefore, in the future, we will elaborate upon our model by considering 3D structure features.

## Section: Materials and methods

First, we transformed the protein sequence to an embedding vector with a fixed size, and the margins were padded, which are marked as $ and the corresponding embedding vectors. Second, we executed convolution along the sequence. Third, for each filter of window size, we pooled the max value. By concatenating all of the max-pooling values, we built a protein feature vector whose dimension is multiplying the number (#) of filters by the number (#) of windows.

## Section: Materials and methods › Building dataset

To build the training dataset, we obtained known DTIs from three databases: DrugBank, KEGG, and IUPHAR. To remove duplicate DTIs among the three databases, we unified the identifiers of the compounds and the proteins. For the drugs, we standardized the identifiers of the compounds in the DrugBank and KEGG databases with the InChI descriptor. For the proteins, we unified the identifiers of the proteins as UniProtKB/Swiss-Prot accessions [48]. Among the collected DTIs, we selectively removed proteins of Prokaryota and single-cell Eukaryota, retaining only proteins of Vertebrata. Finally, 11,950 compounds, 3,675 proteins, and 32,568 DTIs were obtained in total. Because all collected DTIs are regarded as positive samples for training and negative DTIs are not defined in the databases above, a random negative DTI dataset is inevitably generated. To reduce bias from the random generation of negative DTIs, we built ten sets of negative DTIs exclusively from the positive dataset. The detailed statistics of the collected training dataset are shown in Table D in S1 Text.

To optimize our model with the most adequate hyperparameters, we constructed an external validation dataset that had not seen DTIs in the training phase. We collected positive DTIs from the MATADOR database [32], including ‘DIRECT’ protein annotations, and all DTIs observed in the training dataset were excluded. To build a credible negative dataset, we obtained negative DTIs via the method of Liu et al. [33]. This method selects candidate negative DTIs with low similarity to known positive DTIs. From the obtained negative dataset, we balanced the negative dataset with the positive dataset, using a negative score (>0.95). As a result, 370 positive DTIs and 507 negative DTIs were queried for the external validation set. The statistics of the external validation dataset are summarized in Table E in S1 Text.

To evaluate our model, we built two independent test datasets from the PubChem BioAssay database [34] and ChEMBL KinaseSARfari [35]; these datasets consisted of results from experimental assays. To obtain positive DTIs from PubChem, we collected ‘Active’ DTIs from the assays with the dissociation constant (Kd < 10μm) [49]. Because we sought to predict whether a drug binds to a protein, among the many types of assays (Potency, IC50, AC50, EC50, Kd, Ki), evaluation of the dissociation constant (Kd) was the most appropriate assay for obtaining positive samples. For the negative samples, we took the samples annotated as ‘Inactive’ from the other assay types. Because there were too many negative samples in the PubChem BioAssay database, we first collected only negative samples whose drug or target was included in the positive samples from the PubChem BioAssay database. Second, we selected as many random negative samples as positive DTIs from PubChem BioAssay. As a result, total 36,456 positive and negative samples were built with 21,907 drugs and 698 proteins. For the performance evaluation, we created three subsets of the PubChem bioassay independent dataset for humans, which consisted of only new compounds, new proteins, and new DTIs. Detailed summaries of the PubChem dataset and its subset are shown in Table F in S1 Text. We also collected samples from KinaseSARfari. KinaseSARfari consists of assays involving a compound that binds to a kinase domain. To obtain positive samples from KinaseSARfari, we considered each assay result with a dissociation constant of (Kd < 10μm) as positive [49]; this value is sufficiently small to be considered positive. In contrast to the PubChem BioAssay, the number of negative samples was similar to the number of positive samples in KinaseSARfari; therefore, we did not sample the negative samples. We collected 3,835 positive samples and 5,520 negative samples with 3,379 compounds and 389 proteins. Detailed statistics of the KinaseSARfari dataset are shown in Table F in S1 Text. In addition, we summarize the portion of the protein class in each dataset in Fig H in S1 Text. Here, we confirmed that the training and the validation datasets were not biased toward a specific protein class.

## Section: Materials and methods › Drug feature representation

In our model, we used the raw protein sequence as the input for the protein but did not use the raw SMILES string as the input for the drug. For the drug, we used the Morgan/Circular drug fingerprint, which analyzes molecules as a graph and retrieves substructures of molecular structures from subgraphs of the whole molecular graph [21]. Specifically, we used RDKit [50] to yield a Morgan/Circular fingerprint with a radius of 2 from a raw SMILES string. Finally, each drug can be represented as a binary vector with a length of 2,048, whose indices indicate the existence of specific substructures.

## Section: Materials and methods › Deep neural network model

First, we transformed the protein sequence to an embedding vector with a fixed size, and the margins were padded, which are marked as $ and the corresponding embedding vectors. Second, we executed convolution along the sequence. Third, for each filter of window size, we pooled the max value. By concatenating all of the max-pooling values, we built a protein feature vector whose dimension is multiplying the number (#) of filters by the number (#) of windows.

## Section: Materials and methods › Deep neural network model › Overall schema of the deep learning network

We extracted the local residue patterns from protein sequences via CNN and yielded a latent representation of drug fingerprints via fully connected layers. After processing both the drug and protein layers, we concatenated these layers and constructed the fully connected layer, resulting in the output. Every layer except the output layer was activated with the exponential linear unit (ELU) function [51].

The output layer was activated with the sigmoid function for classification. The whole neural network model was implemented with Keras (2.16) [52].

## Section: Materials and methods › Deep neural network model › Convolution layer with protein embedding vector

One of the difficulties in describing the protein features for the machine learning model and the deep learning model was that the protein lengths were all different. Another difficulty was that only certain parts of a protein, such as specific domains or motifs, are involved in DTIs, rather than the whole protein structure. As a result, the physicochemical properties of the whole protein sequence do not seem to be appropriate features for predicting DTIs due to noise information from the portions of the sequence that are not involved in the DTIs. Thus, the extraction of local residue patterns involved in the DTIs is necessary for precise prediction, and CNN is known to capture important local patterns from the whole space. The overall schema of convolutional layers is depicted in Fig 7. The model starts with an embedding to transform each amino acid to the corresponding embedding vector. The embedding layer is a lookup table of embedding vectors. Embedding vector values are randomly initialized by the Xavier initializer (denoted ‘glorot normal’ in keras), which imposes normal distribution of weights and variance of output following variance of input [53]. Embedding vectors are trainable, meaning that embedding vector values are also changed to optimize loss during training. From the lookup table, the embedding matrix for the protein sequence is constructed by querying embedding vectors corresponding to amino acids from the embedding layer, as described in Fig I in S1 Text. The length of the embedding matrix for all proteins was set to the same as the maximum protein length, i.e., 2,500, and the margins were padded with null labels ($) and the corresponding embedding vectors, which would give a meaningless convolution result that is filtered out during global max-pooling as depicted in Fig J in S1 Text. As a result, an embedding layer was constructed for protein features. We executed convolution on the embedding layer of the protein along the sequence in 1D fashion with striding 1, with convolution from jth the to the (j+WS)th amino acids in sequence, which can be defined as

Convolution for the whole sequence results in a (MPL-WS+1) size convolution layer for each filter, where WS is the window size. Finally, to extract the most important local feature, we conducted global max-pooling for each filter, which is defined as

where j covers all of the convolution results of the embedding matrix from protein sequence pk, resulting in a filter-sized vector with a max-valued convolution result for each window, which does not induce bias from the locations of local residue patterns and the maximum protein length. After pooling all convolution results, we concatenated them to represent the important local patterns for interactions as a vector-formatted feature. Finally, for the organization and abstraction of protein features, concatenated max-pooling results are fed into fully connected layers, which constructs a latent representation of protein.

First, we transformed the protein sequence to an embedding vector with a fixed size, and the margins were padded, which are marked as $ and the corresponding embedding vectors. Second, we executed convolution along the sequence. Third, for each filter of window size, we pooled the max value. By concatenating all of the max-pooling values, we built a protein feature vector whose dimension is multiplying the number (#) of filters by the number (#) of windows.

## Section: Materials and methods › Deep neural network model › Fully connected layers for drug fingerprints and concatenating layer

As mentioned in the Introduction, latent representations of the drug fingerprint descriptors made by fully connected layer are useful for predicting DTIs. After features of the protein and drug were refined by the neural network, we concatenated them and constructed fully connected layers to predict whether the drug and target interact.

## Section: Materials and methods › Deep neural network model › Calculation of loss and weight optimization

Using the constructed deep neural model, the input flows to the output layer in a feed-forward fashion. The deep neural model calculates loss with binary cross-entropy:

To prevent overfitting, we penalized the loss function with L2-norm:

Finally, we updated the weights using the Adam optimizer [54] with a penalized loss to give a generalized prediction for the model.

## Section: Materials and methods › Deep neural network model › Regularizations of the neural network

In the artificial neural network technique, there are several ways to prevent overfitting. Currently, dropout and batch normalization are most frequently used to regularize neural networks. Dropout masks hidden nodes in the training phase, which makes a subset of hidden nodes unavailable to predict results for training labels [55]. By masking some hidden nodes in training, dropout generalizes the model, making the model independent of a specific dataset. We used 1-dimensional spatial dropout on the embedding layer [56]. In addition, we used a batch normalization technique to prevent overfitting except in the embedding layer. Batch normalization normalizes the outputs of the neural network with a mean of 0 and a standard deviation of 1 on a minibatch. However, batch normalization could induce a loss in the influence of parameters and linearity of network outputs, rather than nonlinearity. Thus, batch normalization induces a scale factor and a shift factor for normalized outputs, whose values are also introduced in the learning phase, to resolve the problem [57].

## Section: Materials and methods › Deep neural network model › Selection of hyperparameters

In our deep learning models, hyperparameters, such as the learning rate and window sizes that affect performance, are tuned during cross-validation. However, the hyperparameters should not be determined based on the performance of the subset of the training dataset because the negative datasets are randomly sampled. With the external validation dataset, we first determined the learning rate because a model with a high learning rate is unable to learn a pattern. After the learning rate was selected, we selected activation function and regularization parameters such as the dropout ratio. Finally, we employed a grid-search method for optimization of the other hyperparameters that determine neural network shape. The search range of optimization is summarized in Table A in S1 Text. We identified hyperparameters that exhibited the best AUPR, which is an appropriate performance evaluation metric for the accuracy of classifying the positive sample. The other descriptors to compare with our methods are numerical vectors, which do not have locality. Therefore, we put fully connected layers on the protein descriptors. We also employed a grid-search strategy while sustaining hyperparameters not related to model shape. When the AUPR is measured, the optimal threshold can be given by the EER [37].

where θ is the classification threshold and γ is the constant determining the cost ratio for misclassification from precision and recall, which is set at 2 in our model.

## Section: Materials and methods › Sparse Auto-Encoder (SAE) construction

SAE is Auto-Encoder whose distribution of latent representations is regularized with sparsity term [58]. In loss calculation, Kullback-Leibler divergence (KLD) loss between Bernoulli distributions each dimension in latent representation ρ^ and desired sparsity parameter ρ is added to reconstruction loss of Auto-Encoder and ridge loss for weights.

where

During the training of the neural network, KLD acts as a constraint for latent representation following desired sparsity parameter. As a result, for each dimension of latent representation, only a few samples are activated, giving a more reliable representation of original input. In the previous study, MFDR used SAE to build an informative latent representation of DTI, which are composed of multi-scale local descriptors [38] and PubChem fingerprints.

## Section: Materials and methods › Deep belief network (DBN) construction

DBN is a generative graphical model proposed by Geoffrey Hinton [20]. DBN is actually a stack of an RBM. RBM consists of visible and hidden units, constructing a bipartite graph. In RBM, probabilistic distribution of visible units is learned in an unsupervised way, with a probabilistic distribution of visible and hidden units

and marginal distribution of visible units

to maximize the probability of visible units for V in a training set with weight matrix W

In DBN, during stacking of RBMs, hidden units of the previous RBM are fed as visible layers of the next RBM. In addition, RBM adopts contrastive divergence for fast training, which uses gradient descent and Gibbs sampling. In a previous study, DeepDTI, the input concatenation of drug and target protein features, PSC descriptors and ECFP with a radius of 1, 2 and 3, was considered a first visible layer. The authors attached logistic regression to the last hidden units to predict DTIs.

## Section: Materials and methods › Evaluation of performances

To measure the prediction performance of our deep neural model based on the independent test dataset after the classification threshold was fixed, we obtained the following performance metrics: sensitivity (Sen.), specificity (Spe.), precision (Pre.), accuracy (Acc.), and the F1 measure (F1). See the formulas below:

where TP is true positive, TN is true negative, FP is false positive, FN is false negative, T is positive, and N is negative.

## Section: Supporting information

(PDF)

Click here for additional data file.

(PDF)

Click here for additional data file.

(CSV)

Click here for additional data file.

## Section: Data Availability

All code we used in manuscript are available from GitHub repository (https://github.com/GIST-CSBL/DeepConv-DTI)

## Section: Funding Statement

This work was supported by the National Research Foundation of Korea (NRF) grant funded by the Korea government (NRF-2018M3A9A7053266), the Bio-Synergy Research Project (NRF-2017M3A9C4092978) of the Ministry of Science and ICT through the National Research Foundation. The funders had no role in study design, data collection and analysis, decision to publish, or preparation of the manuscript.

## Section: Associated Data

(PDF)

Click here for additional data file.

(PDF)

Click here for additional data file.

(CSV)

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

(PDF)

Click here for additional data file.

(PDF)

Click here for additional data file.

(CSV)

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

All code we used in manuscript are available from GitHub repository (https://github.com/GIST-CSBL/DeepConv-DTI)


---

# Examining the Use of Real-World Evidence in the Regulatory Process

- **Authors:** Brett K Beaulieu-Jones, Samuel G Finlayson, William Yuan, Russ B Altman, Isaac S Kohane, Vinay Prasad, Kun-Hsing Yu
- **Issuer:** Clinical pharmacology and therapeutics
- **Type:** Scientific article
- **Published:** 2019-11-14
- **Language:** en
- **DOI:** 10.1002/cpt.1658
- **Source:** https://pubmed.ncbi.nlm.nih.gov/31562770/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractThe 21st Century Cures Act passed by the United States Congress mandates the US Food and Drug Administration to develop guidance to evaluate the use of real‐world evidence (RWE) to support the regulatory process. RWE has generated important medical discoveries, especially in areas where traditional clinical trials would be unethical or infeasible. However, RWE suffers from several issues that hinder its ability to provide proof of treatment efficacy at a level comparable to randomized controlled trials. In this review article, we summarized the advantages and limitations of RWE, identified the key opportunities for RWE, and pointed the way forward to maximize the potential of RWE for regulatory purposes.

## Section: Text

Real‐world data (RWD) and real‐world evidence (RWE) have received substantial attention from medical researchers and regulators in recent years.1, 2 The US Food and Drug Administration (FDA) defines data relating to patient health status and the delivery of healthcare (such as electronic health records (EHRs), claims and billing activities, product and disease registries, and patient‐generated data) as real‐world data (RWD), and the analysis of these data regarding usage and effectiveness are termed real‐world evidence (RWE).3 The European Medicines Agency (EMA) similarly defines RWD as defined as “routinely collected data relating to a patient's health status or the delivery of health care from a variety of sources other than traditional clinical trials” and expressed interest in using RWD for regulatory decision making.4 RWE presents great potential to accelerate therapy development and to monitor the successes and failures or both newly approved and existing therapies.5 It is critical that stakeholders, including researchers, both academic and industry, providers, regulators, administrators, and patients understand the limitations of RWE. RWE is not generated with a particular study question in mind but are generated primarily for clinical care and billing purposes. As such, appropriate use of RWE must be driven by well‐designed guidelines and regulations to ensure accurate, unbiased findings. If used correctly, RWE could supplement traditional clinical research to aid therapeutic development, clinical decision making efficiency gains in healthcare, and improved access to therapeutics for underserved populations. Examples of promise in each of these areas can be seen in the results of the EMA's adaptive pathways pilot.6 If used incorrectly, RWE could lead to spurious approvals, financial waste, and most importantly cause harm to patients.

To date, RWE has been used primarily to perform postmarketing surveillance to monitor drug safety and detect adverse events. RWE has also been particularly effective when the outcome of interest is rare, in cases where a very long follow‐up period is required to assess the health outcomes, or when it is difficult to perform randomized controlled trials (RCTs), such as in pediatric or pregnant populations. An early example was the discovery of a link between the ingestion of diethylstilbestrol during pregnancy and vaginal adenocarcinoma of the offsprings using observational data.7 More recent studies linked the use of angiotensin‐converting enzyme inhibitors while pregnant to congenital malformations8 and the exposure of selective serotonin reuptake inhibitors to persistent pulmonary hypertension in newborns.9, 10 Most recently, RWE has shown postmarketing evidence that it may have an important role to play in understanding drug effectiveness and adverse events based on differences of metabolism in various racial and genetic groups.11, 12, 13, 14

There is a growing interest in the usage of RWE by regulatory agencies to evaluate the safety and efficacy of medical treatments.2, 5, 15, 16, 17 In particular, Congress has mandated that the FDA increase focus on RWE for regulatory decision making both for new approvals and evaluating additional indications for approved therapies18 and the FDA has testified on progress toward implementing this focus.19 The EMA recently accepted an RWE‐based control arm during their analysis of Alecensa effectiveness compared with the standard of care.20, 21, 22 In addition, the FDA has established partnerships with private companies whose goal is to use RWD in regulatory decision making, including using synthetic control arms.20

Although some have been enthusiastic about the ability for observational RWD to substitute for RCTs, others have expressed caution. Booth et al.23 contend that RWD should not be used as a replacement for clinical trials due to the inability to compare outcomes of nonrandomized groups. A recent comprehensive empirical analysis of treatments in oncology confirms this finding. The results on replicating clinical trials in observational data are highly mixed, Concato et al.24 concluded that well‐designed observational trials closely estimated the effects of treatment when compared with RCTs on the same subject. On the other hand, Soni et al.25 found a poor correlation between the hazard ratio seen in observational studies vs. randomized trials on the same topic. There is limited evidence that some RCTs may be difficult to replicate.26, 27, 28 This could be due to population and effect sizes, population demographics, or other factors.

RWE may provide valuable insight into the effectiveness and generalizability of interventions in practice, even as RCTs are unlikely to be supplanted as the gold standard for measuring intervention efficacy. It is important to consider the higher level of evidence RCTs provide than RWE when making a regulatory decision.29 We should aim to use the highest standard possible while acknowledging it is not feasible for RCTs to answer all clinical questions related to drug effectiveness. The reasons where RCT might not be feasible include (i) prohibitive cost,30, 31 (ii) when the standard of care is effective and/or administering a placebo is unethical,32 and (iii) in rare diseases where patient recruitment is challenging.33, 34, 35 In addition, RCTs are typically performed in a relatively homogenous cohort that is less diverse than the real‐world population in terms of age, race, socioeconomic status, geography, clinical setting, disease severity, patient history, and patient willingness to seek treatment.36, 37, 38, 39, 40 Finally, over time, indications for therapeutics often expand to indications and population groups they were not originally tested in. Pragmatic and other modern trial designs may mitigate some of these challenges, for example, by improving generalizability, but fundamental issues of cost, time, and difficult recruitment remain.41 Pharmaceuticals have been approved without RCTs but should be limited to cases where the potential burden of an incorrect treatment estimation is outweighed by the burden of conducting an RCT.42 It is critical to utilize alternatives to supplement but not supplant RCTs both in the form of pragmatic trials and RWE‐based analyses.

The FDA has taken action in an attempt to reduce the burden in both time and cost of bringing a new therapy to market, through the accelerated regulatory decision regulations initially put in place in 1992 and expanded in 2012.43 These regulations allow for surrogate and intermediate end points when a therapy addressed a serious condition without existing options. In the 5 years following final guidance from the FDA in May 2014, 71 therapies have been approved through the accelerated pathway.44 This is in comparison to 25 in the 5 years prior to this guidance. In addition, in 2012, the FDA established the “breakthrough therapy designation” for therapies intended to treat serious or life‐threatening conditions where the therapy may demonstrate substantial improvement.45 From April 2015 to March 2019, 24 drugs have received breakthrough therapy designation. Due to the fact that clinical end points (i.e., outcomes that show direct clinical benefits, such as increased overall survival) may take a long time to develop, many drug trials with breakthrough therapy designation use surrogate end points, which are measurements or signs predictive of clinical outcomes but do not directly measure clinical benefits.46, 47 Examples of surrogate end points include blood pressure for hypertension drugs and serum low‐density lipoprotein cholesterol for hypercholesterolemia treatments.47 Shorter trials and the use of surrogate end points present a strong need for postapproval surveillance for both safety and effectiveness, especially in the context of traditional clinical end points. The use of shorter trials and surrogate end points to accelerate regulatory decisions may suggest that the traditional process is unnecessarily slow and wasteful. However, it is also possible that the extensive use of these shortcuts will lead to suboptimal decisions because there is no guarantee improvement as measured by surrogate end points will translate to traditional end points.

In this light, we ask the question: “What is the role of RWE in the regulatory process?” In this review, we first lay out some of the primary reasons RWE is not suited to replace RCTs. We then examine some areas RWE is well‐suited to supplement and enhance the regulatory process as well as providing postapproval guidance.

## Section: Limitations for RWE for Regulatory Decision Making

Here, we examine the limitations of commonly used methods for applying RWD to inform regulatory decision making. We focus on the limitations of RWE to be used in the comparative effectiveness analyses conducted in phase II and phase III RCTs. We, therefore, narrowly examine three types of studies that have been proposed as ways to perform these comparative effectiveness analyses of therapies from RWD: (i) Virtual Comparative Effectiveness Studies ascertain outcomes in both an intervention and control group from an RWD source.48, 49 (ii) Studies using Historical Control Arms compare retrospective RWD‐derived controls against an uncontrolled treatment arm.50 (iii) Studies using Synthetic (Real‐World) Control Arms pair an uncontrolled treatment arm with concurrent RWD controls.22

Each of the three study designs of RWE has significant issues that prevent the ability to achieve a level of evidence on par with RCTs. Because of challenges in drawing causal conclusions of treatment efficacy from RWE they are not suited to replace RCTs. Table 1 shows how the specific limitations discussed apply to each form of study design. Most of these mechanisms to use RWE are affected by multiple limitations. Below, we describe these concerns and then link them to each of these three forms of evidence.

Examination of the issues pertinent to each purpose of RWE

## Section: Limitations for RWE for Regulatory Decision Making › A. Unobserved confounders

Of the sources of RWD, the EHR is generally considered to provide the most granular view of patient care; although insurance claims may provide a higher level of completeness of care. Neither of these data sources is designed for secondary analysis: EHR is primarily intended for patient care, whereas claims data is designed for financial billing and reimbursement. As a result, there are potentially unobserved factors influencing a physician's decision to pursue a particular course of treatment in a systematic manner, preventing the direct comparison of outcomes between treatment arms or direct comparisons to RCT findings. Traditionally, these factors are addressed using randomization because random treatment assignment would not allow for systematic differences between exposed/nonexposed arms. This is not possible using observational data. Several examples of these factors include:

## Section: Limitations for RWE for Regulatory Decision Making › B. Medicine changes over time

Historical control arms are by nature historical and as new treatments and technologies, new guidelines, and environmental or socioeconomic changes are introduced medicine changes. This was demonstrated by Sacks et al.50 in 1982 when they showed that 80% (44 of 56) historical control trials found the treatment of interest better than the control, but only 20% of RCTs agreed. For six different clinical areas, they found the results of the trials were more dependent on the method of control groups than on the therapy being considered. In a similar vein, Zia et al.57 identified 43 phase III clinical trials that used identical therapeutic regimens to their corresponding phase II study. Only 28% of the phase III studies were “positive” and 81% had lower effect sizes than their corresponding phase II study. The effect of time trends in medicine is evident even over the course of a single outcome‐adaptive trial.58, 59 Outcome‐adaptive trials work by adjusting treatment assignment probabilities based on which treatment arm is doing better in order to subject as many participants as possible to the most promising treatment. When a treatment arm seems promising at the beginning of a trial, patients are disproportionately enrolled in the promising arm. This means that the average date of enrollment can be much later in some arms than others.

## Section: Limitations for RWE for Regulatory Decision Making › C. Trials may change participant and provider behavior—the “Hawthorne Effect”

Clinical trial protocols may result in different behavior than typical clinical practice. Although difficult to measure, there is weak evidence of a protocol or “Hawthorne effect” leading to participants of clinical trials having better outcomes than typical clinical practice.60 McCarney et al.61 performed a placebo‐based randomized trial in dementia, which found that participants receiving more frequent follow‐up visits achieved better cognitive and carer‐rated quality‐of‐life outcomes. Similarly, behavioral changes, such as the more frequent follow‐up of clinical trial participants, may result in better medication adherence than real‐world settings.62 In traditional RCTs, both arms of the trial may experience the Hawthorne effect. When using historic or synthetic controls only the traditional intervention arm would experience the Hawthorne effect.

## Section: Limitations for RWE for Regulatory Decision Making › D. Closer monitoring of adverse effects in trials

The combination of more frequent follow‐up and specific attention paid to adverse drug events may lead to lower rates of adverse drug events in routine clinical practice compared with clinical trials. In addition, relatively minor adverse effects may not be billed against or recorded in the context of more serious diagnoses (e.g., nausea on a chemotherapy protocol). Several studies have shown that harm in oncology RCTs is underreported and may not even follow protocols.63 RWE may underestimate important patient safety concerns.

## Section: Limitations for RWE for Regulatory Decision Making › E. Lack of pretrial registration and multiple testing

It is critical that clinical trials be registered prior to any analysis of results that occur to prevent unreported multiple testing.64, 65 Many statistical methods have been proposed to minimize false discovery in studies involving testing multiple hypotheses simultaneously, and the need for correction is well recognized in biomedical research. However, some forms of multiple testing are more difficult to identify. As an illustration, there are several widely distributed datasets (e.g., Truven MarketScan, Optum Claims data, etc.), and it is likely that multiple investigators will ask similar questions using these datasets. The multiple testing nature of large and uncoordinated efforts may not be apparent to individual investigators involved nor to the scientific community, and the likelihood of false positives would remain uncorrected.66 To highlight this issue, Silberzahn et al.67 distributed the same dataset to 29 teams with a total of 61 data analysts and asked the question, “Are soccer referees more likely to give red cards to dark‐skin‐toned players than light skin‐toned‐players?” Twenty of the 29 teams found a positive effect, the other 9 found no significant relationship and the estimated effect sizes ranged from 0.89–2.93. This study makes explicit a phenomenon that is largely hidden from view, multiple chances and analytical approaches to explore an observational hypothesis may result in different point estimates. Given the financial stakes in regulatory outcomes, there are strong incentives for reporting of positive results. Because explorational analyses may be performed prior to registration or in the absence of registration, multiple hypothesis testing may plague RWE efforts. Preregistration of methods in RCT studies prevents this type of manipulation, both deliberate and inadvertent, and provides a measure of methodological transparency.

## Section: Limitations for RWE for Regulatory Decision Making › F. Weaknesses of propensity score methods

Propensity score matching and adjustment are popular approaches to account for high‐dimensional confounders in observational studies.68 In propensity score matching, researchers construct a matched population of treated and nontreated individuals based on their probabilities of receiving the treatment. By pairing every treated patient with one or more nontreated patients that were roughly equally likely to have received the treatment, propensity score matching seeks to balance the underlying factors associated with treatment assignment. In propensity score adjustment, the high‐dimensional confounders are summarized by a propensity score, which can then be adjusted in downstream analyses.68, 69

In practice, propensity score methods are difficult to properly execute and evaluate.70 For instance, it is very difficult to determine if a given propensity score model has been correctly specified. The traditional method for evaluating predictive performance fails to properly evaluate the quality of a propensity score model because unmeasured confounding and the randomness in treatment assignment both contribute to the deviation of the model from the observed data. As such, it can be difficult for a reader to determine whether the model has sufficiently adjusted for confounding.70

The deployment of the propensity score is also not straightforward. Because propensity scores from two patients are rarely exactly equal, defining “close enough” propensities for two patients to count as a match involves a delicate balance between excessively loose cutoffs (which risks undercutting the notion of matching itself) and highly stringent cutoffs (which may exclude too many patients from the analysis). The process of propensity matching almost inevitably changes the population being studied in ways difficult to interpret by systematically excluding some subset of patients that fail to achieve a proper match in the other “arm” of the analysis. Ultimately, this means that propensity score matching may provide causal estimates about the effect of the intervention on a different population than the study originally sought to investigate.

## Section: Limitations for RWE for Regulatory Decision Making › G. Inability to compare RWD preapproval of the experimental treatment

The efficacy of a treatment cannot be evaluated from RWD until it is used widely enough for there to be a substantial body of data. In general, this means that treatment needs to already be approved for the indication of interest. In rare cases, there may be significant off‐label usage, but the reasoning behind this off‐label usage should be carefully considered in terms of its impacts on patient selection.71, 72 Significant differences between the patients receiving the off‐label treatment vs. the existing standard of care could exist, resulting in issues of generalizability. The inability to compare observations preapproval to observations in the general population is especially pertinent to the experimental arm, but there may also be subtle changes in the standard of care that can be difficult to identify from RWD (e.g., dosing, timing, and adherence).73, 74 Finally, off‐label prescription with the hope of generating RWD is an inefficient mechanism of hypothesis testing, which is often optimized by formal trials.

## Section: Limitations for RWE for Regulatory Decision Making › H. Opportunity for conflict of interest

Therapy approval decisions are binary outcomes with the potential for profound impact on patients, employees, shareholders, and other stakeholders. Because of this, there represents an outsized incentive for a variety of parties to cheat the system, regardless of the study design. It was recently revealed that there was “data manipulation” in the data provided to the FDA during the approval process for Zolgensma.75, 76 In RWE, this poses a potentially bigger issue given the retrospective nature of data. The bar for exploitation is lower than prospective studies and exploitation becomes less black and white. It is not possible to ensure that trial organizers have not already analyzed the data to ensure that the control arm is penalized. This could be done through manipulation of the inclusion and exclusion criteria, the method of propensity matching between the trial subjects and the subjects derived from RWD or other intentional selections. For example, Sacks et al.50 found that historical control groups generally did significantly worse than RCT control groups across 50 reported clinical trials. The retrospective population selection task exhibits the opportunity for exploitation that is difficult to uncover, especially when considering potential financial implications. Although there is the opportunity for bad actors to cheat the system regardless of study type, RWE‐based studies can be performed by a smaller set of investigators where there are less exposure and transparency to the protocol.

## Section: Limitations for RWE for Regulatory Decision Making › I. Completeness of data and loss of follow‐up

Of the three most commonly used sources of RWD, EHR and hospital‐based administration both suffer from the fact that they do not record any care received outside of a particular hospital system and oftentimes contain incomplete regard with respect to a particular EHR (e.g., inpatient vs. ambulatory). This leads to challenges in ensuring completeness of care in RWD‐based studies using EHR data. In addition, over 50% of the United States receives healthcare insurance through their employment.77 The average tenure of employment is just 4.3 years for men and 4 years for women.78 This short tenure means even insurance claims datasets present challenges when considering the completeness of care and follow‐up coverage. Record incompleteness, defined as instances when fewer than 50% of enrollees have at least one claim in a given year, can be caused by administrative phenomena, such as company or record mergers, as well as subcontracting of service.79

## Section: Limitations for RWE for Regulatory Decision Making › J. Measurement error in identifying patient status from RWD

EHRs and administrative data were not initially intended for specific studies, thus, these records may not be sufficiently granular to ascertain the phenotypic status of the patients. Researchers need to make additional assumptions or resort to proxy measures to infer the disease status of the patients under study. Additionally, previous studies showed that different hospitals have dissimilar approaches of disease and procedure coding, even when using the same standard lexicon of diagnostic and procedure codes. Data harmonization efforts and calibration studies are necessary to enhance the accuracy of inferring patient statuses using the limited, and sometimes inconsistent, descriptors in the RWD.

## Section: The Way Forward: How Can We Capture Value From RWE to Effectively Improve Patient Treatment?

Although RWD analyses are susceptible to the biases and issues summarized above, they hold promise in complementing trial analyses and enable the evaluation of numerous biological hypotheses at a minimal cost. Below, we discuss the approaches that could maximize the value and potential of RWE with particular attention to the approval and postapproval surveillance processes (Table 2).

Key needs and opportunities for RWE

## Section: The Way Forward: How Can We Capture Value From RWE to Effectively Improve Patient Treatment? › Integrate results from multiple designs of observational studies to triangulate effect estimates

As discussed in the previous section, RWE generated from different study designs suffers from different sources of biases, and causal inference based on RWD relies on strong assumptions rarely met in practice. Nonetheless, by combining the results generated by different study designs, we can better estimate the risks and benefits of treatment strategies.80 For example, cohort studies using RWD suffer from unmeasured confounding, whereas the use of instrumental variables relies on instrumental assumptions.81 Because these two study designs require different sets of assumptions, we can estimate the extent of assumption violation and its impact on the risk estimates. Similarly, we can further incorporate the results from natural experiments82 and negative control analyses83 to gauge the effects of treatments and unmeasured confounders. By comparing the results from different approaches, we can determine the possible range of the true estimates with a greater level of confidence. Nonetheless, given the fact that different study designs and analytical methods possess distinct pros and cons, researchers need to be vigilant about the interpretation of their combined results.80 Effect triangulation approaches have successfully estimated causal effects in settings with strong confounding, such as the effects of lowering systolic blood pressure on the risk of coronary heart disease.80, 84

## Section: The Way Forward: How Can We Capture Value From RWE to Effectively Improve Patient Treatment? › Leverage new statistical approaches for causal analyses

Philosophers have attempted to understand causality since the age of enlightenment,85 and epidemiologists proposed several criteria to evaluate the linkage between causes and effects.86 Recent developments of statistical methods allow causal inference from observational data while minimizing biases insurmountable by conventional approaches.70 As an illustration, in the presence of time‐varying confounders, traditional variable adjustment approaches will inevitably result in biases, due to the fact that subsequent measurements after the baseline are likely affected by the treatments. The g‐methods, a group of statistical approaches, can account for the time‐varying confounders and treatment‐confounder feedback that commonly reside in observational data.87, 88, 89 In addition, recently developed multiple robust statistical approaches can reduce the risk of model misspecification by relaxing the assumptions needed to achieve unbiased estimates.90, 91 For example, doubly robust methods can consistently estimate the effects of treatments if either the confounder‐treatment relation or the confounder/treatment‐outcome relation is correctly modeled,90 which would be helpful in settings where model misspecification raises significant concern. It is worth noting that the causal identification conditions (i.e., exchangeability, positivity, and consistency) still need to hold in order to get accurate effect estimates. In high‐dimensional settings, machine‐learning approaches can model the high‐level interactions among the variables and facilitate dimension reduction.92 These methods can accommodate the large number of variables extracted from EHRs and other RWDs.

## Section: The Way Forward: How Can We Capture Value From RWE to Effectively Improve Patient Treatment? › Establish a robust infrastructure for randomized registry trials

Integration of EHRs into a large‐scale data registry would allow for real‐time matching against clinical trials and for physicians to be immediately notified if a patient was a potential fit.93 After patients were enrolled in the trial, the treatment could be randomized and follow‐up could occur at their normal point of care.94 This would have the potential to massively reduce enrollment and follow‐up costs while increasing the diversity of populations included in clinical trials. This cost reduction could enable randomized trials to answer a wider scope of questions. In particular, it may allow randomized registry trials to be performed postapproval for comparative effectiveness analysis and additional trials sponsored by government and nonprofit organizations.

## Section: The Way Forward: How Can We Capture Value From RWE to Effectively Improve Patient Treatment? › Perform postapproval surveillance and validate that efficacy translates to effectiveness

Although clinical trials measure drug efficacy, it is important to perform postapproval surveillance to determine whether efficacy is generalizable to a broader population. Postapproval surveillance would allow drug pricing to take into account the real‐world value delivered. In addition, due to size restrictions, clinical trials may not capture rare adverse effects95 or drug–drug interactions96 that could be discovered through RWD analysis.

## Section: The Way Forward: How Can We Capture Value From RWE to Effectively Improve Patient Treatment? › Use RWD to measure how closely trial populations resemble real‐world populations

This would enable trial organizers to plan representative trials and regulators to determine where additional trials may be necessary. In addition, if there is truly a heterogeneity of effects, it is unlikely to be detected in a homogenous trial population. It is, therefore, important to monitor both effectiveness and safety in the larger heterogeneous population that the therapy is given to.

## Section: The Way Forward: How Can We Capture Value From RWE to Effectively Improve Patient Treatment? › Preregistration of RWD analyses

Establishing a preregistration requirement for RWD analyses is an effective approach to reduce the risk of multiple hypotheses testing and p‐hacking.97, 98 However, many observational datasets, such as Medicare,99 Medicaid,100 and Marketscan,101 are available and fully accessible to the researchers before the conception of specific RWD studies, which makes adequate preregistration a significant challenge. Combining a preregistration mechanism with a requirement to validate the identified effects on prospective patient cohorts could mitigate the risk of false discovery due to p‐hacking.97

## Section: The Way Forward: How Can We Capture Value From RWE to Effectively Improve Patient Treatment? › Complement RCTs and pragmatic trials with RWD

Although RCTs and pragmatic trials generate high‐quality evidence for establishing causality24, 102 and inform real‐world practice,41, 103 respectively, it is infeasible to answer all clinically important research questions by setting up a series of trials. In addition to using multiple sources of RWE to arrive at better risk estimates (“Integrate Results From Multiple Designs of Observational Studies to Triangulate Effect Estimates” section), researchers could further leverage the hypotheses generated by RWD to inform trial design, or when the subgroup analyses of trials are underpowered, conduct RWD studies to further identify the participants who would likely benefit from the treatments under study.104

## Section: The Way Forward: How Can We Capture Value From RWE to Effectively Improve Patient Treatment? › Establish reporting guidelines of RWE

Many reporting guidelines have been established for observational studies, but the specific requirements for using RWE for regulatory approval remains unclear. Widely accepted guidelines for academic publication include the REporting of studies Conducted using Observational Routinely collected health Data (RECORD)105 and STrengthening the Reporting of OBservational studies in Epidemiology (STROBE) guidelines.106 However, researchers have called for more stringent and specific approaches for subfields of epidemiology, such as the RECORD‐PE statement for pharmacoepidemiological research.107 Similar efforts are needed to enhance the validity and reproducibility of RWE for regulatory purposes. In particular, regulatory agencies need to set specific requirements for the study participants, variables, measurement methods, data curation procedures, analytical approaches, and accessibility of the data and codes used in demonstrating the effectiveness of treatments using RWD.

## Section: The Way Forward: How Can We Capture Value From RWE to Effectively Improve Patient Treatment? › Establish a structure for the postapproval evaluation of clinical practice guidelines and predictive algorithms

Historically, postapproval marketing of drugs involved a wide network of pharmaceutical sales representatives attempting to visit physicians to provide samples and detailing.51, 108 In the 21st century, there has been an increased interest in establishing standardized clinical practice guidelines, for example, Choosing Wisely,109 and in providing predictive drug recommendations as a part of personalized,110 and precision medicine,111 Standardizing care is a core component of improving the process with which care is delivered in the structure, process, and outcome framework for evaluating healthcare quality.112 Personalized drug recommendations offer the promise to provide patients with the drugs they are most likely to benefit from. This transition from individualized decision making presents a great potential to improve care and to deliver evidence‐based medicine. However, it also presents the potential for postapproval marketing to shift from one‐on‐one encounters to influence at the system level through guidelines and algorithms. It is critical for RWE‐based guidelines and recommendation systems to be thoroughly evaluated by independent third parties in the form of regulatory agencies and physician societies.

## Section: The Way Forward: How Can We Capture Value From RWE to Effectively Improve Patient Treatment? › Determine value‐based reimbursement of drugs

Value‐based drug pricing has been discussed for over a decade.113, 114, 115 RWD analyses can reveal the actual effectiveness of the drugs in real‐world use cases, and, hence, inform the value created for the patients.116 Tracking the longitudinal health outcomes of patients receiving the treatments under the usual circumstances of healthcare practice is crucial for determining the true value of therapies. If it is to succeed, how value is attributed must be carefully regulated and monitored.

## Section: Conclusions

RWE presents a unique opportunity to accelerate the development of new therapies and to evaluate both the efficacy and the effectiveness of these treatments. However, researchers and regulators should take heed of the limitations of RWE and the potential biases lurking in RWD. Although there is significant value in utilizing RWE preregulatory approval (e.g., identifying subpopulations of need) and postregulatory approval (e.g., safety and surveillance), there are significant barriers to reliably using observational data as a key component of the regulatory process. Conflicting studies on attempts to replicate clinical trials using RWE show the potential risks and brittleness of RWE‐based comparative effectiveness.24, 25 This view is further supported by the discrepancies between trial results and those from RWD,117, 118, 119, 120 including a recent failed attempt at Facebook121 to replicate RCTs with large‐scale RWD analyses in a nonmedical context.

The appropriate use of RWE must be driven by forward‐thinking best practices, guidelines, and regulations to avoid spurious or biased findings. Increased data availability presents many opportunities but also brings with it the potential for biases in a system with outsized financial incentives. Traditional approaches, including preregistration, may not be sufficient when it is not possible to know which analyses have already been performed. It is critical to acknowledge the history and strengths of traditional RCTs especially in regard to initial approvals. RCTs should not be replaced for approval but can be supplemented to better understand treatment effectiveness in the real world. Prospective follow‐up studies driven by unconflicted parties will be critical to decision making around postapproval therapy surveillance and reimbursement. The appropriate use of RWE offers promise to accelerate the development of therapies while making their delivery safer, more targeted, and more efficient in real‐world settings.

## Section: Funding

This study was funded by the National Library of Medicine (NLM) T15LM007092 (B.K.B.‐J.), Harvard Data Science Fellowship (K.‐H.Y.), and National Institute of General Medical Sciences (NIGMS) T32GM007753 (S.G.F.).

## Section: Conflict of Interest

All other authors declared no competing interests for this work.

## Section: Disclosures

Dr. Prasad reports receiving royalties from his book Ending Medical Reversal; that his work is funded by the Laura and John Arnold Foundation; that he has received honoraria for grand rounds/lectures from several universities, medical centers, and professional societies, and payments for contributions to Medscape; and that he is not compensated for his work at the Veterans Affairs Medical Center in Portland, Oregon, or the Health Technology Assessment Subcommittee of the Oregon Health Authority. Dr. Beaulieu‐Jones reports owning equity in Progknowse Inc. outside of the submitted work. Progknowse is a company working with academic and community‐based health systems to integrate clinical data and enhance data science capabilities.

## Section: Contributor Information

Brett K. Beaulieu‐Jones, Email: brett_beaulieu-jones@hms.harvard.edu.

Kun‐Hsing Yu, Email: Kun-Hsing_Yu@hms.harvard.edu.


---

# Graph Convolutional Neural Networks for Predicting Drug-Target Interactions

- **Authors:** Wen Torng, Russ Biagio Altman
- **Issuer:** Journal of Chemical Information and Modeling
- **Type:** Scientific article
- **Published:** 2019-10-03
- **DOI:** 10.1021/acs.jcim.9b00628
- **Source:** https://doi.org/10.1021/acs.jcim.9b00628
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Accurate determination of target-ligand interactions is crucial in the drug discovery process. In this paper, we propose a graph-convolutional (Graph-CNN) framework for predicting protein-ligand interactions. First, we built an unsupervised graph-autoencoder to learn fixed-size representations of protein pockets from a set of representative druggable protein binding sites. Second, we trained two Graph-CNNs to automatically extract features from pocket graphs and 2D ligand graphs, respectively, driven by binding classification labels. We demonstrate that graph-autoencoders can learn fixed-size representations for protein pockets of varying sizes and the Graph-CNN framework can effectively capture protein-ligand binding interactions without relying on target-ligand complexes. Across several metrics, Graph-CNNs achieved better or comparable performance to 3DCNN ligand-scoring, AutoDock Vina, RF-Score, and NNScore on common virtual screening benchmark data sets. Visualization of key pocket residues and ligand atoms contributing to the classification decisions confirms that our networks are able to detect important interface residues and ligand atoms within the pockets and ligands, respectively.


---

# Machine learning applications in drug development

- **Authors:** Clémence Réda, Emilie Kaufmann, Andrée Delahaye-Duriez
- **Issuer:** Computational and structural biotechnology journal
- **Type:** Scientific article
- **Published:** 2019-12-26
- **Language:** en
- **DOI:** 10.1016/j.csbj.2019.12.006
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33489002/
- **Licence:** CC-BY

## Section: Abstract

Graphical abstract

## Section: Introduction

A great variety of experimental data, at a chemical, transcriptomic, or genomic-level is available to readily use for drug development. Summarizing the huge amount of biological data at hand into meaningful models, to grasp the full mechanism of diseases, seems harder and harder. However, systems biology and machine learning approaches are continuously enhanced in order to accelerate the path to efficient drug development. We will focus on three significant related and intermingled questions, that can be subject to automation: drug discovery, drug testing, and drug repurposing. Firstly, this review briefly dwells on the current context in drug development. Later, we will review generic machine learning algorithms, and more specifically, we will focus on sequential learning algorithms and recommender systems. These algorithms have also proven themselves useful in other research fields, and are active biomedical fields of research.

Representation of the four stages of drug development, along with Phase IV, which occurs after the start of drug marketing.

Evolution of average development cost in a cohort of 12 major phamaceutical labs, in millions of dollars, between 2010 and 2018 [10].

## Section: Introduction › Drug development

Representation of the four stages of drug development, along with Phase IV, which occurs after the start of drug marketing.

Evolution of average development cost in a cohort of 12 major phamaceutical labs, in millions of dollars, between 2010 and 2018 [10].

## Section: Introduction › Drug development › Current context in drug development

Development of new drugs is a time-consuming and costly process. Indeed, in order to ensure both the patients' safety and drug effectiveness, prospective drugs must undergo a competitive and long procedure. Drug development is roughly split into four major stages, called phases. Phase 0 comprises basic research/drug discovery and preclinical tests, which aim at assessing the efficiency and body processing of the drug candidate. The last three stages are clinical trials: study of dose-toxicity, short-lived side effects, and kinetic relationships (Phase I); determination of drug performance (Phase II); and comparison of the molecule to the standard-of-care (Phase III). An optional Phase IV can be post-drug marketing to monitor long-lasting side effects and drug combination with other therapies. See Fig. 1 for the whole drug development timeline. This pipeline takes at least 5 years to be completed [1], and can last up to 15 years [2]. The minimal amount of time covers the setup of preclinical and clinical tests (Phases 0 up to III), that is, the time to ponder upon and write down the study design, to recruit and select patients, to analyze the results, and so on, let alone to perform the actual wet-lab experiments.Fig. 1Representation of the four stages of drug development, along with Phase IV, which occurs after the start of drug marketing.

Clinical development time (that is, from Phase I) has steadily increased. For drugs approved in 2005–2006, the average clinical development time was 6.4 years, whereas it increased up to 9.1 years for 2008–2012 drug candidates [3]. This might denote an issue in assessing drug effects and benefits. Conversely, the high failure rate of drug development pipelines, often at late stages of clinical testing, has always been a critical issue [4]. In clinical trials occurred between 1998 and 2008 (in Phases II and III), [5] have reported a failure rate of 54%. Main reasons for failure were the lack of efficacy (57% of the failing drug candidates), and safety concerns (17%). Among safety concerns were increased risk of death or of serious side effects, which were still the main reasons of failure in Phases II and III in 2012 [3], and in 2019 [7]. For drug pipelines starting in 2007–2009, the gap in estimated success rates in 2012 was particularly steep between Phase II (first patient-dose) and Phase III (first clinical trial-dose). This means that Phase II, which is related to drug performance assessment, is particularly discriminatory: only 14% of the drug candidates that reached Phase II, compared to 64% of the drug pipelines reaching Phase III, were eventually marketed [7]. This can still be observed for drug pipelines starting in 2015–2017 [6]. 25% of the drug candidates that reached Phase II, compared to 62% of the drug pipelines reaching Phase III, were approved (estimation made in 2019).

Meanwhile, total capitalized expected cost of drug development was estimated at $868 million for approved drugs in 2006, with an average clinical development cost of $487 million, according to the public Pharma projects database [9]. There are large variations due to drug type ($479 million for a HIV drug, compared to $936 million for a rheumatoid arthritis drug) [8]. The recent study of a cohort of 12 large pharmaceutical labs led by [10] shows that total development cost per approved drug has skyrocketed from 2016 to 2018 (from $1,477 to $2,168 million), and almost increased two-fold in eight years (from 2010 to 2018) (see Fig. 2). It is worth noticing that, in the meantime, the number of discovered molecules that have reached the late clinical test stage for this cohort dropped by 22% [10]. Moreover, clinical trials pose a barrier to rapid drug development. The cost and time involved in patient recruitment has been increasing. There is a high failure rate and consequent financial loss in product development. Drug efficiency assessment might not be carried to term because of prematurely-stopped clinical testing, due to the lack of funding [11]. These factors contribute to the decrease in approved drugs.Fig. 2Evolution of average development cost in a cohort of 12 major phamaceutical labs, in millions of dollars, between 2010 and 2018 [10].

In a nutshell, all these figures show an expensive, time-consuming, and frustrating R&D context. Although efforts have been made in order to tackle these issues (as shown by the 2019 figures of success rates between Phases II and III), there is still room for improvement in terms of study planning, as suggested in [11], or designing more insightful preclinical testing [1].

Representation of the four stages of drug development, along with Phase IV, which occurs after the start of drug marketing.

Evolution of average development cost in a cohort of 12 major phamaceutical labs, in millions of dollars, between 2010 and 2018 [10].

## Section: Introduction › The future of drug development

This context has indeed transformed the pharmaceutical industry in the span of ten years. Even the biggest pharmaceutical companies encounter productivity issues, in terms of number of approved molecules with regard to the number of drug candidates [4]. Although a few political efforts have been made to promote orphan disease research [12], this situation has led the pharmaceutical industry to focus on the most profitable diseases. Between 2017 and 2018, the number of active drug pipelines for cancer therapy has increased by 7.6%, whereas the number of anti-infective drugs has dropped by 9.3% [9]. The most studied diseases in 2018, in terms of number of active drug pipelines, are cancer subtypes (breast, lung), diabetes, and Alzheimer’s disease [9]. This observation raises the issue of finding therapies for rarer, complex diseases, where the limited number of patients might hinder meaningful studies to be carried on; or for tropical diseases, where the drug development cost might be too prohibitive with respect to the estimated selling profits [13].

As highlighted by many articles [14], [15], [16], one rather inexpensive way to improve these numbers might be to automate some important but repetitive data processing and analysis tasks, more especially, through robotics [17] and Machine Learning (ML) methods [18]. Indeed, a lot of blossoming collaborations between Artificial Intelligence (AI) and Machine Learning (ML) companies and pharmaceutical labs, as well as universities and research centres [18], [19], [20], slowly bridge the gap in bioinformatics between applied mathematics, computer sciences and biology. This would allow to accelerate drug development pipelines as they might be computationally, thus automatically, performed and less prone to human-related technical mistakes. Authors of [21] estimate their use would shrink the drug candidate identification phase from a few months to one year. Still, one should remain cautious, and not expect computational methods to solve completely the failure rate problem [22]. Nonetheless, integrating ML methods into drug development pipelines might also decrease drug development cost and time [23], and make therapies more patient-oriented, as the easier integration of multiview data might allow implementation or enhancement of precision medicine techniques [24], [25]. Conversely, systematic methods allow study replication and reusability, and enable standardized, transparent data quality control and sharing [26], and in silico identification of promising targets. These methods could also provide quantitative values to assess and compare the efficiency of candidate molecules, before any wet-lab experiment or preclinical test.

## Section: Introduction › Towards an automated search for therapies

In order to recontextualize research in drug development, we suggest reading the introductory part of the following referenced papers [13], [23], [27], [28]. Even though a fully-automated drug development pipeline seems out of reach for now [13], the combined efforts from biology, medicine, bioinformatics, computer science and mathematics communities have been spent on improving each part of the drug development pipeline – for example, drug discovery through high-throughput screening (HTS) of drugs via genomic and transcriptomic data [29], genome-wide association studies (GWAS) to uncover new relevant drug targets [30], and increasing application of generic algorithms from machine learning. The use of these methods makes sense in a context where a large quantity and diversity of curated information is available about drugs and their therapeutic indications, disease/aggravating factor targets, disease pathways, and gene/protein regulatory interactions.

## Section: Sequential learning and recommender systems in machine learning

Machine learning (ML) is a subfield of artificial intelligence (AI) in computer science. Here, a ML algorithm designates any computational method where results from past actions or decisions, or past observations, are used to improve predictions or future decision-making. ML techniques are now extremely popular in drug development (see [13], [27], [31] for recent surveys) as they allow automation of highly-dimensional, noisy biological data analysis.

Many different machine learning tasks have been studied, which fall broadly into three categories. The first one is supervised learning, in which the goal is to predict the label of new observations given a large database of labelled examples. Several supervised learning algorithms have been applied in a biological context, such as Support Vector Machines [32] or (Deep) Neural Networks [33]. The second task is unsupervised learning, and it aims at detecting underlying relationships or patterns in unlabeled data. Dimension reduction methods, like Principal Component Analysis (PCA), fall in this class. But other unsupervised problems are also studied in the context of drug development, such as density estimation, clustering (grouping data) or even collaborative filtering. We shall elaborate on some examples below. The third type of task is sequential learning, where algorithms rely on trial-and-error, and iteratively use external observations in order to find the best decision with respect to the environment they interact with.

A large literature has dwelled on the use of sequential learning algorithms, where an agent, that is, a goal-oriented entity interacting with its environment, must make one choice at a time according to previous observations of the environment (from which the input data originate) they are interacting with. While offline –or batch– methods use batches of data in order to learn, online –or sequential learning– algorithms process one data point at a time (receiving a stream of data), and update their prediction or decision accordingly.

Multi-Armed Bandit (MAB) algorithms [34] constitute a popular and versatile family of sequential decision-making algorithms, and were actually motivated by clinical trials, as we shall see. In MABs, a fixed set of actions, called arms, is available. An agent sequentially interacts with the environment by selecting arms, as illustrated in Fig. 3 below. Each arm selection produces some noisy observation, often interpreted as a reward. However, the average reward associated with each arm is initially unknown to the agent, and has to be learnt in the process while achieving a certain objective. Typically, this objective could be to discover the most efficient arm(s), that is, the arm(s) with highest average reward, or to maximize the total reward accumulated across iterated arm selections [35]. See the following referenced paper [36] for a comparison between bandit problems.Fig. 3A K-armed bandit, where the learning agent interacts with its environment by sequentially selecting arms, and updating its strategy using the observations it obtains.

Recommender systems are closely linked to MABs, as MABs can be used to design sequential recommender systems, see for instance the following referenced examples [37], [38]. Recommender systems actually belong to different families of ML methods, since a recommender system broadly designates an algorithm which aims at predicting rating of a given user which tests a given object. Refer to [39] for a review of the topic. A large part of the literature about recommender systems is motivated by commercial purposes, see for instance [40], [41], [42]. However, we will show that this flexible class of algorithms can actually be applied to solve drug development-related problems.

In the next section, we will review interesting applications of ML in a pseudo-chronological order of appearance in a drug development pipeline –namely, drug discovery, drug repurposing and drug testing– in which established ML algorithms of the three described classes are involved. We will focus on a subset of ML methods, which comprises sequential learning algorithms and recommender systems. Although they are rarely reviewed in a biomedical setting, they have been investigated for tackling drug development-related problems.

A K-armed bandit, where the learning agent interacts with its environment by sequentially selecting arms, and updating its strategy using the observations it obtains.

## Section: Examples of machine learning applied to drug development

Generative Adversarial Networks for Drug Discovery. A Generative Adversarial Network is a set of two neural networks, the Generator and the Discriminator. These two networks are trained at the same time.

Randomized Clinical Trial (RCT) versus Adaptive Clinical Trial (ACT) for Phase III. A Randomized Clinical Trial (RCT) “randomly” assign patients to treatment arms (ensuring balance of covariates of interest) before testing, whereas an Adapted Clinical Trial sequentially assigns patients to treatment arms according to previous testing results.

## Section: Examples of machine learning applied to drug development › Drug discovery

Drug discovery is usually considered the first stage of a drug development pipeline [43], and is an exploratory step which aims at uncovering putative drug candidates or gene targets, or causal factors, of a given disease or a given chemical compound. A variety of supervised learning methods (for instance, Support Vector Machines and Deep Learning [44], [45], [46], regression methods [47], [48]) and unsupervised learning methods [13] applied to biomedical problems have been thoroughly reviewed in the last decade, with a growing interest in Deep Learning (DL). For further review for DL methods applied to drug discovery, please refer to [33], [49]. Applications may tackle interesting problems in drug discovery: for example, drug candidate identification via molecule docking, in order to predict and preselect interesting drug-target interactions for further research [43]; and protein engineering, that is, de novo molecular design of proteins with specific expected binding or motif functions [44].

A fairly recent breakthrough in protein design uses generative DL, more precisely, Generative Adversarial Networks (GANs [50]). A GAN is made of two simultaneously trained neural networks (NN) with distinct roles: a Generator, which is trained to sample instances (“generated instances”), and a Discriminator. The goal of the latter is to recognize training instances from generated ones, by assigning them a probability value of the considered instance being sampled from the training set. The objective is to train the Generator to create fake instances that are able to “fool” the Discriminator, that is, which are convincing enough with respect to the underlying “goodness” function represented by the Discriminator. See Fig. 4 which illustrates a GAN. For instance, [51] have applied GANs to generate DNA sequences matching specific DNA motifs, that is, short DNA sequence variants which are associated with a specific function. As a proof-of-concept, highly-rated samples obtained via this procedure, exhibiting one or several copies of the desired motif, were shown. Another paper [52] uses, as “predictor“ network, a NN which predicts the probability of the (generated) DNA sequence of coding for an antimicrobial peptide (AMP), and have succeeded in training a GAN which returns 77.08% of the time AMP-coding sequences.Fig. 4Generative Adversarial Networks for Drug Discovery. A Generative Adversarial Network is a set of two neural networks, the Generator and the Discriminator. These two networks are trained at the same time.

Drug discovery problems have also motivated research in black-box optimization, mostly using Bayesian Optimization (BO), see for instance the following referenced examples [53], [54]. Bayesian Optimization is a field of research for finding global optimum (i.e., either maximizers or minimizers) of a black-box function by sequentially selecting where to evaluate this function. Indeed, the so-called black-box objective function is accessible only through its values at selected points, and might be costly to evaluate. The interest in a sequential strategy is to adaptively choose where to collect information next (which defines a so-called acquisition function). The motivation for viewing some drug discovery tasks as a black-box optimization problem comes from the fact that they usually rely on expensive simulations (at chemical-level), for instance, protein-folding [55], making automatic drug screening and assessment via these operations time-consuming.

The specificity of BO is to choose a prior probability distribution (embedding a priori knowledge, simply called prior) on the objective function: e.g., one assumes that the objective function is a sample of a given probability distribution over functions. This prior is then updated after each new function evaluation into a posterior distribution, which in turns guides the selecting of the new point to evaluate. For instance, in [56], the authors apply BO to design gene sequences which maximize transcription and translation rates, from initial sequences. The optimization is performed on feature vectors of fixed length associated with the gene sequences, and the objective function f is the function which, given a gene sequence feature vector, returns the associated transcription and translation rate functions. The prior upon the objective function is a Gaussian Process, classically used in BO [57]. The authors then use as acquisition function the average objective, which will maximize the average of the transcription and translation rates. The feature vector maximizing this acquisition function will then define an optimal gene design rule (for instance, frequencies of amino acid codons) for the maximization of both transcription and translation rates. Since several codons can code for the same amino acid, given a set of sequences coding for a protein of interest, these sequences can be ranked according to the similarity of their corresponding feature vector with the optimal gene design rules that have been derived. The idea is to produce then the protein of interest with lower costs, since the protein production rate is maximized.

Another example of applications of BO to drug discovery is to stimulate the discovery of new chemical compounds [58], that is, finding small molecules that might optimize for a property of interest, while being chemically different from known compounds. This approach might cope with the caveats of previous methods [59].

Generative Adversarial Networks for Drug Discovery. A Generative Adversarial Network is a set of two neural networks, the Generator and the Discriminator. These two networks are trained at the same time.

## Section: Examples of machine learning applied to drug development › Drug testing

Once one or several drug candidates are selected, preclinical (Phase 0) and clinical development (Phases I up to III) start. Drug properties, related to body processing of the candidate molecule, should be assessed in early phases: e.g., the ADME properties: absorption, distribution, metabolism and excretion, along with the toxicity levels. Evaluation of their efficacy is performed later during Phases II and III. Automation and development of in silico prediction models might save time and money on later testing stages, and subsequent in vitro and in vivo experiments. Moreover, these methods might come to sometimes replace experiments on animal models, since some agencies start banning animal testing [60]. Such instances of potential in silico guiding of wet-lab experiments can be found in [61], [62], [63]; in particular, [62], [63] describe the application of Bayesian multi-armed bandit methods to Phase I studies.

For instance, in [61], a graph-based framework is developed in order to build a prediction model for perturbation experiments, provided time-series expression data and putative gene regulatory interactions between genes of interest. The resulting model can then predict expression levels for the selected set of genes after Knock Out and Over Expression perturbations. This method might help assessing the drug effects on pathways after perturbation of the drug targets. The authors have validated their method on a mouse pluripotency model, with in vitro experiments, and report that 60.7% of the predicted phenotypes could be reproduced in vitro.

Moreover, given the intrinsic sequential nature of a clinical trial, in which patients are given treatments, one (group of) patient(s) after the other, MAB algorithms would be natural candidates to be used in further phases of drug testing. However, nowadays, the motivation for developing new bandit algorithms has entirely shifted to applications to online content optimization, such as sequential recommender systems [42]. Bandit designs appear to have been seldomly used in human clinical trials. Traditional randomized clinical trial (RCT) (where, at the beginning of the trial, each patient from the pool of subjects is randomly assigned to and treated with a random treatment until the end of the clinical trial) have been the gold standard since the 1960’s. Notwithstanding, the past years have witnessed an increased interest in all kind of Adaptive Clinical Trials (ACT), in which the next allocated treatment could be dependent of the outcome of previously allocated treatments. We will now elaborate on the latter. See Fig. 5 for a comparison between RCTs and ACTs.Fig. 5Randomized Clinical Trial (RCT) versus Adaptive Clinical Trial (ACT) for Phase III. A Randomized Clinical Trial (RCT) “randomly” assign patients to treatment arms (ensuring balance of covariates of interest) before testing, whereas an Adapted Clinical Trial sequentially assigns patients to treatment arms according to previous testing results.

Seen as a MAB, a Phase III clinical trial proceeds as follows: given K treatments (arms), where each of them has an unknown probability of success p1, p2, …, pK, one of the treatments It is chosen for the tth patient, and its efficiency (the associated reward value) is subsequently measured. Under the simplest MAB model for a clinical trial, a reward Xt = 1 is obtained if the treatment is successful, and Xt = 0 if the treatment fails. The allocation is adaptive in that the selection of It may depend on I1, X1, I2, X2, …, It-1, Xt-1, that is, on the previously given treatments and their observed outcomes. This adaptivity could lead to a smaller sample size to attain a given power, or early stopping for toxicity or futility of a treatment [64], by automatically performing interim analyses [65]. The problem of maximizing rewards in such a bandit model was extensively studied from the 1950’s, either from a frequentist view [66], [67] (where the success probabilities are treated as unknown parameters to be inferred); or from a Bayesian view [68], [69] (where success probabilities are assumed to come from some prior distribution, similarly to Bayesian optimization). Maximizing rewards amounts to maximizing the number of cured patients, which is (arguably) not the purpose of a clinical trial. Yet, the statistical community has also looked at the different problem of finding, as quickly and accurately as possible, the treatment with the largest probability of success. This was studied for example under the name “ranking and selection” [70], [71] and later best arm identification [72], [73]. An interesting take-out from the bandit literature is that the two objectives of treatment identification and curing patients cannot be achieved (optimally) by the same allocation strategy [74].

However, as attractive as the idea of determining the best treatment while treating properly as many patients as possible [75] is, the use of ACTs remains quite rare. This might be due to intrinsic differences between traditional clinical trial methodology and data-dependent allocation, as suggested by [124]. For example, balance between prognostic covariates in each treated group of patients is required for statistical relevance [76]. The use of ACTs might also be hindered by practical reasons in the clinical trial setting, for instance, when one must deal with considerably delayed feedback, as reported by [77]. Nonetheless, these drawbacks might be mitigated by the benefit-risk ratio of the treatment. For life-threatening diseases, an adaptive clinical trial might be a hope for the patients to improve their condition [78], for best empirical treatments, using previous observations, can be assigned to patients.

Despite this initial hostility to ACTs, there has been a recent surge of interest in promoting their actual use. As a notable sign of this evolution, the FDA has updated a draft of guidelines concerning adaptive clinical trials [79], listing in particular several concrete examples of successful adaptive trials. Similarly, [124] presents some examples and promotes some good practice for using ACTs. In the meantime, the authors in [77] have performed multiple simulations illustrating the characteristics of usual bandit algorithms (mostly aimed at maximizing rewards) in terms of allocation and final selection (statistical power), in order to popularize their use.

Among existing bandit algorithms, Bayesian algorithms have achieved a certain popularity. Interestingly, the very first bandit algorithm can be traced back to the work of Thompson in 1933 [35], who suggests randomizing the treatments according to their posterior probability of being optimal. This principle (now sometimes called Thompson Sampling or posterior sampling) was rediscovered around ten years ago in the ML community for its excellent empirical performance in complex models [80]. Interestingly, the use of (variants of) this principle appears to have been proposed as well in different context of drug testing. For example, for phase II trials [81] present a compromise between RCT and Thompson Sampling, while [64] present a proof-of-concept of a phase II trial for the Alzheimer disease that rely on such posterior sampling ideas. More broadly, several examples of successful Bayesian adaptive designs have emerged over the last 20 years, and we refer the reader to [82], [63] for a survey.

Furthermore, research is ongoing in order to tackle for instance the issue of delayed feedback, see for instance [83]. ACTs might allow clinical trials to take explicitly into account inter-patient variability [84], or additional information about the patient [85].

Randomized Clinical Trial (RCT) versus Adaptive Clinical Trial (ACT) for Phase III. A Randomized Clinical Trial (RCT) “randomly” assign patients to treatment arms (ensuring balance of covariates of interest) before testing, whereas an Adapted Clinical Trial sequentially assigns patients to treatment arms according to previous testing results.

## Section: Examples of machine learning applied to drug development › Drug repurposing

The challenges of designing new molecular entities, and testing them through all clinical phases, has generated research interest in a more profitable and efficient technique, called drug repurposing, or drug repositioning. This approach aims at studying already available drugs and chemical compounds to find them new therapeutic indications. This strategy is useful when repurposed drugs have well-documented safety-profiles (that is, side effects and treatments are known), and known mechanism of action.

Different approaches have been used to tackle the drug repurposing problem. For example, some rely on automatic processing of Electronic Health Records (EHR), clinical trial data, and text mining methods to identify correlations between drug molecules and gene or protein targets in literature [86], [87], [88]. However, this approach might be sensitive, but not really specific, since text interpretation is still a hard problem, and the relationship between disease factors and drugs might not be clear. The current state-of-the-art methods seem to have turned to different paradigms of repurposing, see for instance the following reviews for a classification of these different methods [27], [89], [90].

However, most of these methods rely on a rather strong hypothesis, which is that similarity between elements – for instance, chemical composition of drug molecules – implies correlation at therapeutic effect level, or at drug target level. Nonetheless, counter-examples to this hypothesis have been shown to lead to disastrous events: for instance, thalidomide exists as two chiral forms (same chemical composition but having mirrored structures). One of these forms can treat morning sickness; the other form can have teratogen effects [91].

An attempt to quantify more accurately drug effects is signature reversion, also called connectivity mapping, which focuses on expression measurements: given a pathological phenotype (“query signature”) associated with the disease at study, the objective is to identify which treatments are most able to revert this signature. This operation is performed via comparisons of the query signature with so-called drug signatures, that is, vectorized summaries of genewise expression changes due to the considered drugs. This approach has recorded some successes in drug repurposing; see for instance [29] for a comprehensive review of this type of method. However, note that relying only on transcriptomic measurements to understand the mechanism behind a disease might lead to wrong directions when these cannot account for its causal factors. Moreover, drug repurposing procedures that directly use drug signatures extracted from LINCS database [92], either to compute a similarity measure, or to predict treatment effects at transcriptome level, are biased: indeed, the drug signatures that have been computed in LINCS are measured in cancerous or immortalized or pluripotent cells – which (post) transcriptomic regulation might differ from healthy cells.

Furthermore, especially in matrix factorization and some deep learning methods that perform a dimension reduction or, more generally, feature learning on the drug signatures, the learned features often hardly make sense biologically speaking, which prevents easy interpretation of the results and sanity checks.

Another way of solving the drug repurposing problem, as emphasized by [27], is to see it as a recommender system problem, where an agent should “recommend” best available options. Here, the agent should select the most promising drug candidates with respect to the disease or the target at study. Some recent papers have adopted this approach: for instance, in both [89], [93], the authors have designed a graph-based method to predict drug-target or drug-disease interactions. Given a drug, the model predicts a list of fixed length, that contains disease-related targets most likely affected by the chemical compound.

In [89], the algorithm tackles the problem of predicting drug-target interactions (DTI). It relies on a given input bipartite graph of drugs on the one side, and disease-associated gene targets on the other side, which adjacency matrix is denoted A, of size n × m (n is the number of targets, and m the number of considered drugs). An edge connects a drug and a target if and only if the drug targets this gene (meaning, for a pair of nodes (i,j), A(i,j) = 1 if and only if j is a drug targeting gene i, else A(i,j) = 0). In a recommender system point of view, the goal of the algorithm is to determine how probable (high) the considered drug (user) will target (rate) a given gene (object). The authors of [89] compute a weight matrix W, of size n × n, which depends on A and on drug-drug and target-target similarities (importance of each type of similarity might be parametrized): Wij is the coefficient corresponding to the probability that a drug will also target j knowing that it targets gene i. In order to make the inference about the missing edges between drugs and targets, one then computes matrix R = WA.

## Section: Use of data relevant for drug development

In the next section, we give a summary of the fairly new data types that are openly available as of 2019, and that might be useful in regard to drug development challenges, as many datasets can be integrated to training, validation and feature data for the related algorithms. Indeed, what allows ML techniques to really be efficient is publicly available, curated, annotated data. Multiple types of datasets might be relevant with respect to drug development and drug repositioning questions: information about drug candidates, that are, for instance, the chemical structure of the active molecule, disease gene/protein targets, mechanism of action of drugs, but also their documented side effects. One might also be interested in deducing interesting drug candidates by comparing pairs of diseases, of drugs, of protein targets, and applying the principle of “guilt-by-association”. Integrating multi-view data in a drug development method has been shown to increase its accuracy [94], [95], [96]. In this section and in Table 1, we will review currently a few publicly available datasets according to their type which are of interest in a drug development pipeline.Table 1List of datasets that are relevant for drug development, ordered according to their type. *When provided by the contributors to the database.Data TypeDescriptionDatabases (name, reference, date of last data update*, URL, size*)APIGenomic data(1) Compilation of disease-gene associations; different species are represented in CTD, while the other two databases refer to the human. In CTD, some interactions are manually curated instead of being computationally inferred. OpenTargets and DisGeNET gather data from several curated sources. All of these databases provide a coefficient for each disease-gene association quantifying its corresponding level of evidence.OpenTargets [97], (2019–11)https://www.opentargets.org/27,069 targets × 13,579 diseasesYesComparative Toxicogenomics Database (CTD) [98], (2019–11)https://ctdbase.org/Curated: 8,637 × 5816Inferred: 48,634 × 3168YesDisGeNET [99], (2019–07)http://www.disgenet.org/17,549 targets × 24,166 diseases/traitsYes(2) SNP reporting; COSMIC reports expert manually-curated data.COSMIC [100], (2019–09)https://cancer.sanger.ac.uk/cosmic1,207,190 copy number variants 9,197,630 gene expression variants7,929,832 differentially methylated CpGs13,099,101 non coding variantsYes(3) Regulatory system (e.g., cis-regulatory modules) data: in CisView, the focus is on the mouse (Mus musculus), and data is collected using a TF binding motif analysis on ChiP-seq experiments. It reports several measures of interest, such as conservation scores and quality assessment of the inferred bindings. UK BioBank collects various types of information (genomics, imaging) in a huge anonymous human cohort (around 500,000 people).CisView [101], (2016–12)https://lgsun.irp.nia.nih.gov/geneindex/cisview.htmlNoUK BioBank [102], (2019–09)https://www.ukbiobank.ac.uk/YesInteraction data(1) Protein-protein or pathway information; STRING reports PPIs (protein-protein interactions) for thousands of organisms, classified according to their level of evidence: computationally inferred (via functional enrichment analysis), experimentally-proven or extracted from curated databases. A score combining all this information is associated to each PPI. KEGG gathers manually assembled biological (signaling and metabolic) pathways.STRING database [103], (2019–01)https://string-db.org/24,584,628 proteins and 3,123,056,667 interactionsYesKEGG Pathway database [104] (2019–11)https://www.genome.jp/kegg/pathway.htmlYes(2) Biological models of gene and pathway interactions; CausalBioNet collects manually curated rat, mouse and human models which are machine readable (encoded into BEL language, convertible into SBML). BioModels lists literature-based (some of them being manually curated) models, and computationally inferred ones, mostly in SBML format.Causal BioNet [105]http://causalbionet.com/NoBioModels [106], (2017–06)https://www.ebi.ac.uk/biomodels/Manually curated: 831 modelsLiterature-based: 1640 modelsYes(3) Drug signatures (genewise expression changes due to treatment) in human immortalized cell lines, from standardized experiments. CMap is a preliminary version of LINCS L1000, and is not supported anymore.Connectivity Map (CMap) [107]https://portals.broadinstitute.org/cmap/1309 compounds × 4 cell lines × 154 concentrationsYesLINCS [92]https://clue.io/lincs51,423 perturbation types2570 cell lines4 dosesYesDrug-Disease associationsThese databases provide information about disease potential therapeutic targets, along with interacting chemical compounds. PROMISCUOUS reports text-mining (from literature) based associations, however some of the texts are manually curated.Therapeutic Target Database (TTD) [108], (2019–07)http://bidd.nus.edu.sg/group/cjttd/3419 targets × 37316 drugsNoPROMISCUOUS [109]http://bioinformatics.charite.de/promiscuous/10,208,308 proteins × 25,170 compoundsNoClinical trialsRepositories of clinical trial settings, status, and results. ClinicalTrials.gov is a large database which mostly collects information about US-located trials (formatted in XML), whereas RepoDB provides visualization and data querying. Clinical trial data is a good source of information for Machine Learning methods, because it lists negative results as well (that is, drugs that failed to prove to be of use in treatment), and potentially the reasons for failure.RepoDB [110], (2017–07)http://apps.chiragjpgroup.org/repoDB/1571 approved drugs × 2051 diseasesNoClinicalTrials.govhttps://clinicaltrials.gov323,890 studiesYesChemical & Drug data(1) Protein-related; automatic annotations.UniProt [111], (2019–11)https://www.uniprot.org/561,356 proteins (Swiss-Prot dataset)181,787,788 proteins (TrEMBL)Yes(2) Drug-related; comprises approved, withdrawn drugs, as well as tool chemical compounds, and reports their potential indications.Drug Bank [112], (2019-07)https://www.drugbank.ca/13,450 drugsYes(3) ADMET drug properties (among other types of relevant drug information).ChEMBL [113], (2018-12)https://www.ebi.ac.uk/chembl/1,879,206 compounds × 12,482 targetsYes

List of datasets that are relevant for drug development, ordered according to their type. *When provided by the contributors to the database.

## Section: Use of data relevant for drug development › Data types

We mainly focused on datasets which are publicly available online, where the associated data is either easy to download and automatically read, or easy to get access to via an API (Application Programming Interface). This criterion is crucial as it allows data to be easily integrated into a computational method. We required as well that they contain high-quality data – meaning, expert-curated or processed in a relevant way that discards purely correlative assumptions and provides a confidence score – in large quantities, so to avoid having to gather data from different sources which are preprocessed in different, non comparable, ways. Moreover, whenever possible, we also focused on databases which benefited from recent updates (less than one year), in order to ensure that they are still maintained and relevant.

## Section: Use of data relevant for drug development › Feature selection

In ML and statistics, feature selection aims at trimming or transforming (raw) input data in order to only feed valuable information to the prediction model. This step should not be considered optional when designing ML algorithms. If not applied to the input data, the algorithm might actually learn artifacts, be biased, or even only learn rubbish. As such, feature selection is of paramount importance in order to ensure study replication and to guarantee that the developed prediction model will be useful [114]. Feature selection allows data denoising and thus reducing the batch effect.

This step can either be manually performed, by carefully selecting biologically-relevant features, and then proceed to test them sequentially and assessing their usefulness; or either automatically, by designing an algorithm which will learn these useful features by itself.

The advantage of the manual way is that good model interpretability usually follows, provided one can quantify from the trained model the strength of the influence of each feature (for instance, it is ensured when using linear regression models). Multiple ML methods exist in order to select a subset of preselected features that satisfies interesting properties, such as being predictive of the expected outcome, and being non redundant. For instance, in a drug development setting, statistical methods, random forests, and gradient boosting algorithms helped to successfully predict therapeutic targets from selected features linking genes and diseases of the Open Targets platform [97], or based on gene expression profiles of the LINCS database [92]. The algorithms used for feature selection are usually classified into three major categories: filter, wrapper and embedded methods, where the latter is a hybrid of the former two. See [115] for a comprehensive introduction to feature selection.

Automatic feature selection algorithms can take advantage of the great flexibility and learning power of Deep Neural Networks, that, provided the raw input data and the expected outcome, create the most discriminant features [116], [117]. For instance, the deepDR approach developed in [116] uses an Auto-Encoder (AE) to generate informative features from heterogenous drug-related data, in order to predict new drug-disease pairs. An AE comprises of two neural networks, one Encoder, and one Decoder. The Encoder will project the raw data onto a latent space of features, such that the Decoder is able to reproduce the expected outcomes given the feature vectors associated with the raw input. However, as in any application of Deep Learning, careful training and regularization of these networks should be performed in order to ensure the relevance of the learned features.

## Section: Perspectives › Seeing the organism as a whole system: integration of system biology-related methods to drug development

The power of systems biology and network-based approaches comes from the analysis of multiple genes in functionally enriched pathway, as opposed to traditional single gene and single target approaches. Integration of system biology-related methods to drug development has been implemented for epilepsy in [118], and has allowed the identification of drug target candidates in a systematic way [29], and of a gene module which global expression is highly anti-correlated to epileptic phenotypes [118]. A whole set of genes (a gene module) can be targeted for treatment instead of screening drugs against a single relevant target. Indeed, papers have emphasized on the importance of small-effect gene in a system biology model, as their belonging to highly interconnected gene regulatory networks (GRNs) implies that any slight perturbation on these genes might impact significantly “core” disease genes [24]. A large and active literature [119] has emerged about the formalization, the building and the validation of such GRNs, along with the identification of gene modules highly correlated with pathological phenotype. As GRNs are assumed to mirror gene activity with regard to other genes’ expression, building them usually require (time-series) expression data. These data can be extracted from databases recording measurements of expression after genewise perturbations – for instance, in [120], which relies on Knock Down gene expression measurements collected in LINCS. Even if not yet described today, it can be expected that future methods will take advantage of the use of a restricted part of a GRN to predict in silico the effect of a chemical compound on a set of genes of interest.

## Section: Perspectives › Precision, or personalized, medicine

Papers have underlined the variability between patients in terms of disease outcome, drug side effect or even drug action [121] due to genomic variation. Precision medicine aims at tailoring a therapy for a specific patient, by taking into account their transcriptomic profiles, genotype, somatic mutations, etc. [25]. If the integration of multi-view data often allows the prediction model to be more accurate [94], [95], it raises the issue of processing, denoising high-dimensional and heterogeneous data (and how to perform feature selection in this case). Practical issues must also be faced, as the data needed to run the model might not be routinely obtained at any hospital, as noticed in [114].

## Section: Summary and outlook

A few takeaway messages can be highlighted from the vast literature about drug development-related methods.

Firstly, since the 2010’s, there is a widely acknowledged decrease in productivity of the drug development industry (the extent of which may vary according to the disease at study), that is likely due to the increasing complexity of diseases to tackle, and to the high average drug development cost. This observation has led several pharmaceutical groups and labs to be interested in ML techniques, along with robotics, in order to decrease drug development time, and also to share observational data and clinical trial results [26], [122]. Even if these efforts only result in a small decrease in drug failure rate during clinical development, this would be a both financially and scientifically profitable improvement for drug development.

Secondly, data availability and quality are key ingredients for the success of ML methods. There are hundreds of online publicly, curated databases which, provided some scripting efforts, can be integrated modularly to drug development pipelines. The feature selection step, which selects and transforms raw data to generate useful model inputs, has been shown to be of paramount importance in order to understand, and to obtain relevant results from ML applications. A variety of methods is now available in order to tackle this problem, and select valid, discriminatory features for prediction or decision model inputs.

Finally, the use of statistical learning algorithms is not short of challenges and should be handled with care. Nonetheless, the field of research seems ripe enough to be applied in at least semi-automated drug development pipelines; there is a growing number of papers published on both relevant data processing, and on algorithms applied for biomedical purposes. Subtle and powerful ML generic algorithms, such as refined DL architectures and sequential algorithms (that have been proven to be useful in a number of non-biology related fields of research), are becoming more and more prominent in biomedical research. They have been applied, with some success, to inherently complex problems, for instance, for adapted clinical trials, in vitro experiment prediction or guiding, or de novo protein design. Standardization, systematic validation and comparison of drug development methods on independent datasets are anticipated in the future [123].

In the light of new challenging problems, such as designing algorithms generating targeted recommendations for precision medicine, and modelling drug responses as outputs of a much larger system than a handful of genes, modern ML methods might be a useful tool to further enhance drug development.

## Section: Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.


---

# Machine learning in drug development: Characterizing the effect of 30 drugs on the QT interval using Gaussian process regression, sensitivity analysis, and uncertainty quantification

- **Authors:** Francisco Sahli Costabal, Kristen Matsuno, Jiang Yao, Paris Perdikaris, Ellen Kuhl
- **Issuer:** Computer methods in applied mechanics and engineering
- **Type:** Scientific article
- **Published:** 2019-02-02
- **Language:** en
- **DOI:** 10.1016/j.cma.2019.01.033
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32863454/
- **Licence:** CC-BY

## Section: Abstract

Prolonged QT intervals are a major risk factor for ventricular arrhythmias and a leading cause of sudden cardiac death. Various drugs are known to trigger QT interval prolongation and increase the proarrhythmic potential. Yet, how precisely the action of drugs on the cellular level translates into QT interval prolongation on the whole organ level remains insufficiently understood. Here we use machine learning techniques to systematically characterize the effect of 30 common drugs on the QT interval. We combine information from high fidelity three-dimensional human heart simulations with low fidelity one-dimensional cable simulations to build a surrogate model for the QT interval using multi-fidelity Gaussian process regression. Once trained and cross-validated, we apply our surrogate model to perform sensitivity analysis and uncertainty quantification. Our sensitivity analysis suggests that compounds that block the rapid delayed rectifier potassium current I Kr have the greatest prolonging effect of the QT interval, and that blocking the L-type calcium current I CaL and late sodium current I NaL shortens the QT interval. Our uncertainty quantification allows us to propagate the experimental variability from individual block-concentration measurements into the QT interval and reveals that QT interval uncertainty is mainly driven by the variability in I Kr block. In a final validation study, we demonstrate an excellent agreement between our predicted QT interval changes and the changes observed in a randomized clinical trial for the drugs dofetilide, quinidine, ranolazine, and verapamil. We anticipate that both the machine learning methods and the results of this study will have great potential in the efficient development of safer drugs.


---

# Trial designs using real-world data: The changing landscape of the regulatory approval process

- **Authors:** Elodie Baumfeld Andre, Robert Reynolds, Patrick Caubel, Laurent Azoulay, Nancy A Dreyer
- **Issuer:** Pharmacoepidemiology and drug safety
- **Type:** Scientific article
- **Published:** 2019-12-10
- **Language:** en
- **DOI:** 10.1002/pds.4932
- **Source:** https://pubmed.ncbi.nlm.nih.gov/31823482/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractPurposeThere is a need to develop hybrid trial methodology combining the best parts of traditional randomized controlled trials (RCTs) and observational study designs to produce real‐world evidence (RWE) that provides adequate scientific evidence for regulatory decision‐making.MethodsThis review explores how hybrid study designs that include features of RCTs and studies with real‐world data (RWD) can combine the advantages of both to generate RWE that is fit for regulatory purposes.ResultsSome hybrid designs include randomization and use pragmatic outcomes; other designs use single‐arm trial data supplemented with external comparators derived from RWD or leverage novel data collection approaches to capture long‐term outcomes in a real‐world setting. Some of these approaches have already been successfully used in regulatory decisions, raising the possibility that studies using RWD could increasingly be used to augment or replace traditional RCTs for the demonstration of drug effectiveness in certain contexts. These changes come against a background of long reliance on RCTs for regulatory decision‐making, which are labor‐intensive, costly, and produce data that can have limited applicability in real‐world clinical practice.ConclusionsWhile RWE from observational studies is well accepted for satisfying postapproval safety monitoring requirements, it has not commonly been used to demonstrate drug effectiveness for regulatory purposes. However, this position is changing as regulatory opinions, guidance frameworks, and RWD methodologies are evolving, with growing recognition of the value of using RWE that is acceptable for regulatory decision‐making.Keywords: external control, long‐term follow‐up study leveraging RWD, pharmacoepidemiology, pragmatic trial, real‐world data (RWD), real‐world evidence (RWE)

## Section: INTRODUCTION

Randomized controlled trials (RCTs) have been considered the gold standard to demonstrate efficacy since the 1960s.1, 2 While current routes to market for investigational drugs typically require at least two pivotal RCTs, these are time‐consuming, costly, and produce evidence that can have limited applicability in real‐world clinical practice. There is, therefore, a move towards investigating innovative ways to improve the efficiency of clinical research.3, 4

The controlled nature of an RCT offers advantages in evidence generation as there are standard methods to reduce bias (like randomization and blinding), and they have comprehensive measurement of outcomes to demonstrate efficacy against both active and placebo controls.5 However, RCTs do not accurately reflect real‐world circumstances under which patients are treated; thus, there is often a need for observational studies to support additional evidence generation, particularly around questions of safety.

Real‐world data (RWD) forms the basis for real‐world evidence (RWE) and can be extracted from a broad range of sources such as patient registries, health care databases, claims databases, patient networks, social media, and patient‐generated data from wearables.6, 7, 8, 9 The definitions of RWD and RWE are relatively consistent between key regulatory agencies (see Table 1).7, 8, 10 While RWE from observational studies is well accepted for post‐approval safety monitoring and to answer pharmacoeconomic questions3, 11, 12 its contribution to regulatory decisions around effectiveness has been more limited. Indeed, evidence quality can be compromised by confounding by indication or a general lack of rigorous collection standards.5 There is, therefore, a need for the development of novel trial methodologies that can take the best parts of traditional RCT and observational study designs to produce RWE that provides adequate scientific evidence for regulatory decision‐making. It has already been recognised by health authorities that there is a wide spectrum of potential uses of RWD/RWE in clinical studies, some of which preserve key features such as randomization.13

Definitions of RWD and RWE from some key international regulatory authorities

## Section: REGULATORS ARE WILLING TO EMBRACE NEW APPROACHES TO RWE

While acceptance of the role RWE could play in regulatory decision‐making is not universal, opinions within regulatory agencies are evolving, and there is a growing acknowledgement that the current drug approval process no longer fully meets current health care needs.14 For example, Dr Janet Woodcock, Director of the US Food and Drug Administration (FDA) Center for Drug Evaluation and Research, has acknowledged that the current drug approval system is “broken” and expressed the agency's commitment to find new ways to collect and utilize patient data to improve the process.14 Dr Woodcock has said, “FDA will work with its stakeholders to understand how RWE can best be used to increase the efficiency of clinical research and answer questions that may not have been answered in the trials that led to the drug approval, for example how a drug works in populations that weren't studied prior to approval.”14

The use of RWE to support effectiveness decisions has been used in rare diseases, as highlighted by the examples of BAVENCIO and BLINCYTO (Case study boxes 1 and 2), both of which received accelerated approval using data from external, historical controls.15, 16 The case of BLINCYTO is of particular interest, as it was subsequently approved as a treatment for minimal residual disease in patients with acute lymphoblastic leukemia.17 This approval was based on the results of a single‐arm trial supported by RWE providing benchmarking information and was the first example of the FDA approving a drug for minimal residual disease.18 A randomized clinical trial incorporating pragmatic design elements was also recently used to support a label extension for a drug treating a more common condition, schizophrenia, as demonstrated by the example of INVEGA/SUSTENNA (Case study box 3).19, 20, 21 This demonstrates the willingness of regulatory authorities to consider RWE for regulatory decision‐making when there is an unmet medical need.22

Regulators (including the FDA and European Medicines Agency [EMA]), data science companies (eg, Flatiron Health, New York, NY, USA, and IQVIA, Research Triangle Park, NC), and pharmaceutical companies are actively evaluating ways to embrace RWE to optimize the drug development cycle.23 While the FDA and EMA are often seen to be at the forefront of these changes, other agencies are also leading the way in producing their own guidance, sharing different perspectives and approaches based on their specific needs and region characteristics.

The Japanese Pharmaceuticals and Medical Devices Agency (PMDA) has recently updated its regulations and published guidelines to encourage the use of RWD to satisfy post‐safety requirements and has shown a willingness to expand its application to regulatory assessments other than safety (see Table 2).39 More active discussions in this area are expected, and the agency anticipates further international collaborations that utilize RWD for better regulation of drug life cycles.38

Similarly, Health Canada has published guidance to optimize the use of RWE for regulatory decision‐making,40 and a draft guidance has been issued for comments by the National Medical Products Administration of China, which includes some use cases showing how RWE has already been used for regulatory labelling.41 Indeed, Health Canada has begun to consider RWE as part of the totality of evidence to support its regulatory decisions, as illustrated by the fact that in April 2019 they approved an expansion of the existing approved pediatric indication for Prevnar 13 to include acute otitis media in children 6 weeks to 5 years of age using real‐world data from the National Ambulatory Medical Care Survey and National Hospital Ambulatory Medical Care Survey.42, 43 Health Canada is also collaborating with Health Technology Assessment (HTA) partners to establish a joint document that aims to formalize and optimize the use of RWE throughout the drug life cycle.44 Similarly, in Europe, the report of the HMA‐EMA joint big data taskforce has also reinforced the need for collaboration across all stakeholders, from regulators to payers, HTA bodies, patients, academia, and industry to assess how RWE can contribute to effectiveness decisions.25

Examples of recent regulator‐supported initiatives that drive forward the application of RWE

## Section: THE EMERGING RULES FOR RWE THAT IS FIT FOR REGULATORY PURPOSES

The 21st Century Cures Act and PDUFA VI requires the FDA to accelerate drug development and approval processes, and more specifically, to produce guidance on how to incorporate patient perspectives and innovative study designs, including RWE, into the drug development process.45, 46, 47 The recently published FDA framework for evaluation of how RWE can be incorporated into the regulatory approval process highlights the key topics for which full evaluation will be undertaken.8

There is a need to define the rules for RWE that is fit for regulatory purposes. However, while the development of innovative trial designs is being actively encouraged by the major regulatory agencies, particularly with the FDA's Complex Innovative Trial Designs Pilot Program and Clinical Trials Transformation Initiative and the EMA's adaptive pathways initiative, the required standards to produce RWE that is acceptable for regulatory decision‐making have not yet been fully defined.29, 30, 34 Although regulators are open to proposals for studies with RWD and receiving RWE, the decision to pursue an innovative study design as part of a clinical development program and regulatory approval strategy is not straightforward, as the routes to obtaining pilot guidance are complex and the “rules” for acceptance of evidence in regulatory decision‐making are not yet firmly defined. It is therefore essential to engage with regulatory authorities early to obtain alignment on objectives, inform the study design, and ensure the study design and data are acknowledged as “fit‐for‐purpose” before conducting a study that may not meet the regulatory goals.

To aid this process, several stakeholders have published frameworks and recommendations for the creation of RWE suitable for use in regulatory decisions. The Duke‐Margolis Center for Health Policy, with support from the FDA, released a white paper on the regulatory use of RWE in 2017 following open consultation with academics, patients, and industry.48 Emphasizing considerations for developing RWE that is fit for regulatory purposes, they identified several areas for practical improvement, including the need to ensure that the appropriate RWD sources are matched with appropriate study designs and data collection and handling methods to address the research question. They also encourage the formation of transparent collaborations and the sharing of datasets. Professional societies have also weighed in here too, with the International Society for Pharmacoeconomics and Outcomes Research and the International Society for Pharmacoepidemiology publishing recommendations for good procedural practices for RWE, aiming to build trust and expand its current use in health care decision‐making.49 Many of the recommendations made in these aforementioned publications have been formalized in the FDA framework document.8

An important part of planning innovative studies to produce RWE that provides adequate scientific evidence for regulatory decision‐making is preparation of a thorough analytical plan at the outset of the study. This is already an integral part of most traditional pivotal and post‐safety trials and should reasonably be extended to effectiveness studies that use RWD. Some also argue that pivotal and safety outcome RCTs and observational post authorization safety studies should be registered on appropriate repositories (eg, ClinicalTrials.gov or the EU PAS Register) prior to study initiation as a requirement of the regulatory process. Whether RWE studies will be required to be registered in such a way is a topic of ongoing debate, with opinion sharply divided. Registration by itself is no guarantee of study quality, and any benefit from registration would be heavily dependent on what information would be required to be posted (eg, study protocols, methodological details, etc.). Further discussions between stakeholders will be required before a consensus develops.

In a separate framework on the regulatory use of RWE, Dreyer (2018) has discussed the requirement and transferability of key RCT study design elements to real‐world studies. This builds on the current thinking around clinical outcomes from RWD analysis, suggesting that outcomes should be patient‐centric and should be observable and relevant to daily clinical practice. Specific issues are addressed, such as blinding, which is routinely used in RCTs, but is often impractical to achieve under “real‐world” circumstances, especially when comparing pharmacologic and nonpharmacologic treatments and when using a selection of “standard of care” comparators, which differ by locale, and while informative, would be impossible to blind. Furthermore, blinding might not be necessary for objective outcomes such as the results of a blood tests and imaging, for example, where in most cases, third‐party raters, such as pathologists, are essentially blinded to treatment.50 The importance of using data sources that are “fit for purpose” and the familiarity of researchers with potential sources of bias or error so that the most appropriate study methodology is employed is also emphasized. Analytical methods should be transparent, defined up front, and optimized to answer the research question.

Regulators and industry have acknowledged the value of scientifically rigorous and innovative study methodologies as the key route to achieving the standard of substantial evidence for RWE.8, 48, 51 As a means to achieve this, the FDA framework proposes that the following should be considered: (a) whether the RWD are fit for use; (b) whether the trial or study design used to generate RWE can provide adequate scientific evidence to answer or help answer the regulatory question; (c) whether the study conduct meets FDA regulatory requirements (eg, for study monitoring and data collection).8 It should be noted that strict applicability of these rules, particularly for monitoring, is rarely feasible for studies that rely on existing data, since the identities of patient and care providers are masked to protect privacy in most secondary data sources.

Similarly, the EMA in its recent report on the use of large datasets for RWE made several recommendations to improve the quality of RWE, including the need to define standard formats for documenting datasets, protocols, and tools used to ensure study reproducibility. In addition, it emphasizes the need to ensure that outcome measures from novel data sources such as wearables should be reflective of a defined clinical benefit.25 If these considerations and recommendations are fully addressed by novel study methodologies, the quality of RWE will improve, and studies using RWD could increasingly be used in support of decisions about therapeutic effectiveness. The development of sufficiently robust RWE will ultimately depend on the ability of experts such as pharmacoepidemiologists, statisticians, data scientists, and academics to develop these new methodologies to optimize hybrid study designs, RWD collection and analysis in a way that is compliant with our current understanding of best practice for RWE generation, and open to regulatory scrutiny.8 Sponsors and data owners should proactively identify and develop standard operating procedures to be prepared for FDA audits and oversight by defining requirements for record retention, auditing, and patient privacy.

## Section: MODERNIZING THE CLASSICAL RCT

Some specific hybrid study designs under consideration for regulatory decision‐making by the FDA fall into three broad categories: (a) investigational new drug submissions for RCTs that use RWD to capture clinical outcomes or safety data, including pragmatic and large simple trials; (b) protocols for single‐arm trials that use external controls; (c) clinical trials using RWE to fulfil a post‐marketing requirement for further evaluation of safety or effectiveness to support a regulatory decision.24

Examples of FDA and EMA accelerated approvals, full approvals, and label expansions that used RWE to support regulatory decision‐making in the past decade

## Section: MODERNIZING THE CLASSICAL RCT › Pragmatic and large simple trials

Pragmatic and large simple trials mirror many of the features of RCTs including randomization but are typically very large RCTs and enable a broader patient group to participate. These trials are increasingly being used to demonstrate effectiveness in a daily clinical practice setting and allow more clinically meaningful outcomes to be studied, creating readily transferable benefits for patients. This notion links in with the ever‐developing narrative around patient‐centric care and the increasing involvement of patients in the drug development process, aiming to increase the relevance of new therapeutic interventions to the patient experience.52, 53 One of the first examples of a large simple trial was the Salk polio vaccine field trial of 1954, which led to regulatory approval of the vaccine and a nationwide public health response to eradicate polio.54 More recently, the feasibility of pragmatic trials was also tested by the label expansion achieved for Janssen's INVEGA SUSTENNA (Case study 3) that was based on the findings of the Paliperidone Palmitate Research in Demonstrating Effectiveness (PRIDE) trial which was designed to include treatment randomization and pragmatic outcomes.19, 20, 21 The trial was uniquely designed to mirror the population of adults living with serious and poorly controlled schizophrenia that health care professionals commonly see in clinical practice.55

## Section: MODERNIZING THE CLASSICAL RCT › External controls

Non‐randomized clinical trials involving comparison against external controls have already been used to demonstrate effectiveness in an ever‐increasing number of cases, often relating to rare diseases. These types of designs are particularly useful where randomization may not be feasible or ethical, or where there are limited numbers of patients with a given condition.

Trials with external controls have also been the subject of recent innovation. In Table 3, we have compiled a list of examples where RWE has been used in the past decade to support regulatory decisions on effectiveness that have led to accelerated approval, full approval, or label expansion. The examples fall into three broad categories: (a) approvals based on data from registry‐like case series; (b) approvals where external control data have been obtained from registries, medical records, scientific literature, etc.; (c) approvals based on data from expanded access programs.

Examples of FDA and EMA accelerated approvals, full approvals, and label expansions that used RWE to support regulatory decision‐making in the past decade

## Section: MODERNIZING THE CLASSICAL RCT › Long‐term follow‐up studies using RWD

Many post‐marketing requirement and commitment studies of safety rely on observational designs and methods. There are instances, however, where evidence about safety from RCTs is preferred or required due to feasibility (eg, level of measurement and/or monitoring). These studies often include a secondary aim of evaluating efficacy endpoints. While pragmatic approaches to randomized, comparative safety studies have been tested in the past,103 the regulatory framework for RWE along with new technology and data have created new opportunities for conducting streamlined safety and efficacy studies. The capture of RWD using methodologies such as decentralization (eg, trained nurses), direct‐to‐patient approaches (eg, wearables, patient‐reported outcomes), or databases (eg, registries, claims) could be leveraged to capture long‐term outcomes, and may be considered another step towards the adoption of hybrid study designs to improve clinical efficiencies. These innovative approaches are also potentially useful when conducting long‐term studies of pre‐approval, investigational drugs, particularly when the safety and effectiveness outcomes of interest require longer follow‐up durations.

While most traditional data processing and analysis tools applicable to RWD can be used to identify and reduce the impact of some of the limitations inherent in real‐world studies, such as potential confounding factors, real‐world datasets require development of new methodologies or applications to unlock their full potential.9, 11, 97 The growth of machine learning and the application of natural language processing to RWD will bring additional opportunities in the future, enabling even more meaningful outcomes to be elucidated from the wealth of available RWD.9 Machine learning techniques have already been used to enhance the prediction accuracy of algorithms to identify women with early and advanced stage breast cancer in a claims database using predictive modeling.98

These examples demonstrate the potential that hybrid study methodologies offer by combining the best features of RCTs and studies with RWD, while negating some of the drawbacks. This approach could therefore potentially augment or even replace RCTs for regulatory decision‐making in certain situations, and as researchers, clinicians, and regulators gain more experience with these types of study designs, they may become more accepted and applied more widely.

## Section: CONCLUSIONS

RWE has typically been associated with lower‐quality evidence than that from RCTs, but this opinion is changing as guidance frameworks and the study methodologies using RWD are evolving. The development and refinement of hybrid study designs consolidate the benefits of RCTs and RWD while minimizing the limitations of both traditional study types. This has the potential to generate RWE that provides adequate scientific evidence for regulatory decision‐making, a potential that is increasingly being realized, with a growing number of examples demonstrating how RWE can be used to support and drive decisions on effectiveness.

Further acceptance of RWE by regulators and other key stakeholders has the potential to make drug development more efficient and generate a paradigm shift in the drug approval process. Progress towards this goal can be aided by the early establishment of a cross‐disciplinary team to provide expert judgment on the appropriate research question, study design, systematic evaluation of feasibility, pre‐specification of the study protocol, and validation, where needed. Pharmacoepidemiologists can play an important role in supporting cross‐functional teams in adapting to the changing landscape where RCTs are increasing reliance on RWD. While pharmacoepidemiologists have historically played a central role in the design and implementation of post‐approval safety studies, they have the knowledge and skills to support colleagues in clinical development to implement these hybrid designs and leverage the recommendations of the RWE frameworks being developed. This is critical in ensuring wider acceptance of RWE for regulatory decision‐making, given the complexity of some of these modern designs.

Trial designs using RWD represents a logical, much‐needed step in the development and future‐proofing of the regulatory approval system, but will require regulators, pharmaceutical companies, and RWE experts to collaborate early on to unlock the scientific potential of RWD through innovative study designs generating solid and dependable RWE, as well as to address privacy concerns that often accompany linking primary and secondary data.

## Section: DECLARATION OF CONFLICTING INTERESTS

E.B.A. and P.C. are employees and shareholders of Pfizer, but the expressed views are their own. R.R. was an employee of Pfizer while this manuscript was in development. N.D. is an employee of IQVIA and is actively involved in the design and conduct of innovative RW studies, as described here; IQVIA contributed the external comparators used for the avelumab approval in the European Union.

## Section: FUNDING

E.B.A. and P.C. are employees of Pfizer, and publication related fees were met by Pfizer. Non‐Pfizer authors received no funding.

## Section: ACKNOWLEDGEMENTS

Authors would like to thank Karen Handley of Pfizer for assistance with sourcing references. Medical writing assistance for this manuscript was provided by Jennifer Bodkin, PhD, CMPP, and Paul Hassan, PhD, CMPP of Engage Scientific Solutions and was funded by Pfizer.

## Section: Text

Baumfeld Andre E, Reynolds R, Caubel P, Azoulay L, Dreyer NA. Trial designs using real‐world data: The changing landscape of the regulatory approval process. Pharmacoepidemiol Drug Saf. 2020;29:1201–1212. 10.1002/pds.4932


---

# Drug Repurposing for COVID-19 using Graph Neural Network with Genetic, Mechanistic, and Epidemiological Validation

- **Authors:** Kang-Lin Hsieh, Yinyin Wang, Luyao Chen, Zhongming Zhao, Sean Savitz, Xiaoqian Jiang, Jing Tang, Yejin Kim
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2020-12-11
- **DOI:** 10.21203/rs.3.rs-114758/v1
- **Source:** https://doi.org/10.21203/rs.3.rs-114758/v1
- **Licence:** CC-BY

## Section: Abstract

Abstract Amid the pandemic of 2019 novel coronavirus disease (COVID-19) infected by SARS-CoV-2, a vast amount of drug research for prevention and treatment has been quickly conducted, but these efforts have been unsuccessful thus far. Our objective is to prioritize repurposable drugs using a drug repurposing pipeline that systematically integrates multiple SARS-CoV-2 and drug interactions, deep graph neural networks, and in-vitro/population-based validations. We first collected all the available drugs (n= 3,635) involved in COVID-19 patient treatment through CTDbase. We built a SARS-CoV-2 knowledge graph based on the interactions among virus baits, host genes, pathways, drugs, and phenotypes. A deep graph neural network approach was used to derive the candidate drug’s representation based on the biological interactions. We prioritized the candidate drugs using clinical trial history, and then validated them with their genetic profiles, in vitro experimental efficacy, and electronic health records. We highlight the top 22 drugs including Azithromycin, Atorvastatin, Aspirin, Acetaminophen, and Albuterol. We further pinpointed drug combinations that may synergistically target COVID-19. In summary, we demonstrated that the integration of extensive interactions, deep neural networks, and rigorous validation can facilitate the rapid identification of candidate drugs for COVID-19 treatment. This paper had been uploaded to arXiv : https://arxiv.org/abs/2009.10931
