# Cyto-Safe: A Machine Learning Tool for Early Identification of Cytotoxic Compounds in Drug Discovery

- **Authors:** Francisco L Feitosa, Victoria F Cabral, Igor H Sanches, Sabrina Silva-Mendonca, Joyce V V B Borba, Rodolpho C Braga, Carolina Horta Andrade
- **Issuer:** Journal of chemical information and modeling
- **Type:** Scientific article
- **Published:** 2024-12-11
- **Language:** en
- **DOI:** 10.1021/acs.jcim.4c01811
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39661446/
- **Licence:** CC-BY

## Section: Abstract

Cytotoxicity is essential in drug discovery, enabling early evaluation of toxic compounds during screenings to minimize toxicological risks. In vitro assays support high-throughput screening, allowing for efficient detection of toxic substances while considerably reducing the need for animal testing. Additionally, AI-based Quantitative Structure–Activity Relationship (AI-QSAR) models enhance early stage predictions by assessing the cytotoxic potential of molecular structures, which helps prioritize low-risk compounds for further validation. We present a freely accessible web application designed for identifying potential cytotoxic compounds utilizing QSAR models. This application utilizes machine learning techniques and is built on a data set of approximately 90,000 compounds, evaluated against two cell lines, 3T3 and HEK 293. Users can interact with the app by inputting a SMILES representation, uploading CSV or SDF files, or sketching molecules. The output includes a binary prediction for each cell line, a confidence percentage, and an explainable AI (XAI) analysis. Cyto-Safe web-app version 1.0 is available at http://insightai.labmol.com.br/.

## Section: Introduction

Cell viability and cytotoxicity assays are fundamental tools used in biomedical research to measure the cytotoxic effects of various substances on living cells. Cytotoxicity specifically refers to the detrimental impacts these substances have on cellular health, often leading to cell death.1 These assays are critical for drug screening, identifying compounds that demonstrate cytotoxic effects which are then typically excluded in both target-based and cell-based phenotypic screenings. This is particularly vital in the context of oncology and neurodegenerative diseases, where understanding substance toxicity is crucial for drug development.2

A significant advantage of in vitro assays is their ability to perform high-throughput screening, allowing researchers to efficiently identify toxic compounds or potential therapeutic agents from large numbers of samples. Additionally, these assays align with the growing emphasis on ethical research by reducing the need for animal testing, making them increasingly valuable in the scientific community.3,4 They operate by measuring various cellular functions that indicate cytotoxicity, such as cell membrane permeability, enzyme activity, cell adherence, ATP production, coenzyme production, and nucleotide uptake activity.5 Accurately predicting chemical-induced cytotoxicity early in the drug development process (preferably before the compounds are even synthesized) is essential. Early detection of cytotoxicity can help prevent costly failures in later stages of development and ensures that only the most promising candidates advance.

The increasing costs associated with ADME/Tox (Absorption, Distribution, Metabolism, Excretion, and Toxicity) studies have spurred the development of in silico methods, particularly within large pharmaceutical companies that possess extensive and internally consistent data sets. While initial computational efforts outside the pharmaceutical sector faced limitations due to smaller data sets, the growing availability of larger data sets in public repositories has significantly improved the potential for successful model development.6 The use of artificial intelligence (AI) to build cytotoxicity models shows great promise for enhancing early stage cytotoxicity prediction. By predicting the cytotoxic potential of chemical compounds based on their molecular structures, these computational models can support virtual screening campaigns, helping to prioritize compounds with lower cytotoxic risks for further experimental validation. This approach streamlines the identification of viable drug candidates.

Building on insights from our previous research,7−10 we have developed QSAR models using a diverse data set of compounds tested on 3T3 and HEK-293 cell lines. We present a new web-accessible application designed to predict the cytotoxicity potential of chemicals, integrating a carefully curated database of 3T3 and HEK-293 cytotoxicity data. The web app features novel models for predicting cytotoxicity, developed exclusively with open-source tools. Available as a web version (version 1.0), it facilitates efficient virtual screening of chemical libraries, aiding in the identification of potential cytotoxic compounds for further investigation. The result includes a binary prediction for each cell line, a confidence percentage, and an explainable AI (XAI) analysis for visual interpretation of the results. This tool can be freely accessed at LabMol Insight AI portal http://insightai.labmol.com.br/.

## Section: CYTO-SAFE › Data Collection

Cytotoxicity data was sourced from a data set provided by the National Center for Advancing Translational Sciences (NCATS).11 This data set includes the results of approximately 90,000 compounds tested for cytotoxicity using the luciferase assay, commercially known as CellTiter-Glo, in a 48 h of incubation time, across two different cell lines: 3T3 and HEK 293. The original data can be accessed via PubChem under AID 1345082 and AID 1345083.

## Section: CYTO-SAFE › Data Cleaning and Curation

Initially, both data sets comprised 93,781 records. However, after eliminating entries with inconclusive outcomes and incomplete chemical structure information, the analysis yielded 67,041 compounds from the 3T3 series and 64,508 compounds from the HEK 293 series.

Subsequently, we implemented a rigorous data curation protocol as described by Fouches et al.,12,13 resulting in 66,620 unique compounds for the 3T3 series. According to the threshold stablished of EC50 value of ≤10 μM,11 62,613 compounds were labeled as noncytotoxic, and 4,007 records were considered cytotoxic for the 3T3. In the HEK data set, a total of 64,094 records were analyzed, with 6,141 compounds labeled as cytotoxic.

To tackle potential data unbalancing that might introduce bias into the classification models, we strategically applied the NearMiss v.3 under sampling method14 executed on Imbalanced-learn package (https://imbalanced-learn.org), setting the sampling strategy as 0.2 and number of near neighbors to 50. This method enabled to get compounds in the majority class (noncytotoxic) with the minimum distance from minority class examples (cytotoxic) maintaining a balanced proportion between cytotoxic and noncytotoxic samples. By adopting this approach, our primary objective was to establish a more equitable and representative data set, thereby enhancing the effectiveness of our classification model training process. The entire processed data is available in Supporting Information.

## Section: CYTO-SAFE › QSAR Modeling

Classification QSAR models were generated and validated in accordance with the established standards and principles of QSAR modeling.15,16 The molecules were converted into a binary language, based on Extended Connectivity Fingerprints17 with radius 2 (ECPF4) and 1024 bits, using the open-source library RDKit.18 ECFP was chosen to capture detailed atomic environments without relying on predefined features. Light Gradient Boosting machine learning algorithm (LGBM)19 was executed in Python 3.10. The data set was stratified split into training (80%) and external (20%) sets. The external set was held out entirely during hyperparameter optimization to ensure unbiased evaluation. Bayesian optimization was conducted using the scikit-optimize, with 100 iterations and 10-fold cross-validation, optimized by balanced accuracy. Class weights were applied to handle class imbalance in the data set. The selected hyperparameters for the best models are provided in the Supporting Information. For all models, we calculated the following metrics on the external set: Balanced Accuracy (BACC), Matthew’s correlation coefficient (MCC), Precision, Recall, F1 score, and plotted the confusion matrix.

## Section: CYTO-SAFE › Y-Randomization

We performed 50 rounds of Y-randomization to assess the robustness and validity of our predictive models. Y-randomization involves shuffling the dependent variable (Y; cytotoxicity outcomes) while keeping the independent variables (X; molecular fingerprints) intact.

## Section: CYTO-SAFE › Deployment

The Cyto-Safe web application was deployed on a cloud-based platform, utilizing a Flask backend and a Jinja2 template-driven frontend to ensure scalability and responsive user interfaces. Machine learning models were then integrated within the Flask framework to facilitate both individual and batch predictions of up to ten compounds via CSV or SDF file inputs. The application incorporates the Ketcher molecular editor (version 2.10.0; EPAM), an open-source web-based chemical structure editor, to provide an intuitive interface for drawing and editing chemical structures, enhancing user experience and data accuracy. Prediction results can be exported as spreadsheets for detailed analysis or as web-based reports for immediate review.

## Section: CYTO-SAFE › Explainable AI (XAI)

In this study, we employed an Explainable AI (XAI) framework to interpret our model’s binary classification predictions regarding the cytotoxicity of compounds in 3T3 and HEK-293 cell lines. We used the methodology proposed by Riniker and Landrum20 that systematically removes bits in the molecular fingerprints that correspond to specific atoms or functional groups and assess how these changes influenced the model’s predictions. We normalized these contributions and visualized them using similarity maps and heatmaps analogous to topographical representations.

In these visualizations, structural fragments predicted to increase toxicity were highlighted in red, while those predicted to decrease toxicity were highlighted in green. This approach allowed us to identify key structural features affecting the model’s decisions, providing deeper insights into the patterns and potential biases related to the predicted outcome.

## Section: Results and Discussion

General scheme of usage, outcome and XAI of Cyto-Safe web app.

Explainable AI (XAI) molecular diagrams illustrating the model’s predictions for Doxorubicin on the 3T3 (A) and HEK-293 (B) models, and for Ibuprofen on the 3T3 (C) and HEK-293 (D) models. Red contoured regions highlight areas with a strong positive influence on predicted cytotoxicity, whereas green contoured regions indicate a strong positive influence on predicted nontoxicity. The intensity of the contour colors reflects the magnitude of their influence, with darker shades representing a greater impact on the model’s predictions.

## Section: Results and Discussion › Modeling

The under-sampling technique was applied to the majority class (noncytotoxic) using two different proportions: 1:1 and 1:5, relative to the minority class, cytotoxic. As a result, the balanced 3T3 data set comprised 8,014 records for the 1:1 ratio and 24,042 for the 1:5 ratio. For the HEK 293 balanced data sets, the corresponding records were 12,282 and 36,846, respectively.

Further analysis was conducted using clustering to identify groups of structurally similar compounds that exhibit contrasting outcomes (cytotoxic versus noncytotoxic), with the goal of simulating potential activity cliffs within the training set. The results revealed that only 11.8% of the clusters from the 3T3 data set and 13.2% from the HEK293 data set contained compounds with differing outcomes. These findings indicate a high level of data reliability while also highlighting the challenges that the algorithm must navigate to learn effectively from the training set (see Supporting Information - Supplementary Methods and Results).

Following training, all models were evaluated on the test set. The models exhibited satisfactory performance across both under-sampling proportion ratios, indicating their proficiency in distinguishing between cytotoxic and noncytotoxic compounds. Notably, the models demonstrated robust generalization capabilities by accurately classifying samples not encountered during the training phase.

When comparing overall metrics, the models trained with the 1:5 ratio showed a slight improvement over those using the 1:1 ratio. This was particularly evident in the Matthews Correlation Coefficient (MCC), where the average values increased from 0.61 to 0.86, underscoring the reliability and informativeness of the predictions. Sensitivity (Se) also improved significantly, with average values rising from 0.65 to 0.83, indicating that the models retained their ability to correctly identify cytotoxic compounds despite the increased under-sampling. These results, detailed in Table 1, support the decision to adopt the 1:5 ratio in Cyto-Safe’s back-end prediction algorithm.

The t-SNE plots for each balanced approach (see Supporting Information) reflect the statistical improvements observed with a 1:5 ratio compared to both the 1:1 ratio and the unbalanced set. Unlike the 1:1 ratio, which excludes highly similar compounds and risks misleading predictions, the 1:5 ratio better captures the chemical space of the original unbalanced data set.

Moreover, we applied the Y-randomization method to determine if the correlations identified by the model between molecular fragments and cytotoxic effects are genuine or simply artifacts of random associations. As a result of the 50 rounds on each data set, we observed an average ACC of 0.5 for both data sets and MCC of 0.02 and 0.01 for 3T3 and HEK 293, respectively, confirming the robustness of the models.

## Section: Results and Discussion › Usability

As mentioned previously, users can easily draw a molecule for testing or upload a batch of molecules for prediction using a CSV or SDF file, with a limit of ten SMILES per request. The results are displayed in a list format for each model (3T3 and HEK 293), indicating whether each molecule is predicted to be toxic or nontoxic. Additionally, the predicted probabilities (representing the model’s confidence) are provided as percentages, calculated using the predict_proba method from the LightGBM library. A dedicated button also allows users to initiate Explainable Artificial Intelligence (XAI) analysis (Figure 1).

Furthermore, in accordance with the best practices established by the Organization for Economic Co-operation and Development (OECD),16 we have defined the applicability domain of the model’s predictions to ensure their reliability. The threshold was set at 0.09, corresponding to the fifth percentile of the Tanimoto similarity distribution among compounds in the training set.21 This relatively low threshold reflects the high structural diversity within the training set. A similarity distribution analysis is provided in Figure S3 (Supporting Information). The information regarding whether the tested compound is within or outside the applicability domain is available on the prediction results page, helping users understand the limitations of the model’s outputs.

General scheme of usage, outcome and XAI of Cyto-Safe web app.

## Section: Results and Discussion › Explainable AI (XAI) with Molecular Diagrams and Heatmaps

Cyto-Safe 1.0 is equipped with explainable AI molecular diagrams and heatmaps to help users better understand the model’s output. The molecular diagram displays the molecule contoured in either red or green, where red represents a strong influence on the model’s prediction of “cytotoxic” and green indicates a strong influence on the prediction of “non-cytotoxic.” As a case study, we evaluated the structures of two established drugs: Doxorubicin, a well-known chemotherapeutic agent with a cytotoxic mechanism of action, and Ibuprofen, a widely used nonsteroidal anti-inflammatory drug. Importantly, neither of these molecules was included in the training sets for the models.

Both models classified Doxorubicin as “cytotoxic,” as anticipated, and the molecular diagram reinforced this classification by coloring almost the entire molecule in red in both predictions. In contrast, Ibuprofen was classified as “non-cytotoxic,” with its molecular diagram predominantly highlighted in green, indicating the model’s strong confidence in this prediction (Figure 2). This concordance between the molecular diagrams and the known pharmacological profiles of these compounds underscores the robustness and interpretability of the models.

The atom influence is further illustrated in heatmaps provided in Figures S4–S7 (Supporting Information). These heatmaps employ the same color coding, with red contours indicating atoms that have a strong influence on the model’s prediction of cytotoxicity and green contours representing atoms that have strong influence on the prediction of noncytotoxicity. The intensity of the color contours reflects the strength of the influence, providing users with a detailed understanding of the factors affecting the model’s predictions at both the fragment and atom levels.

The XAI feature of Cyto-Safe is essential for understanding the underlying mechanisms of both models’ predictions. By offering molecular diagrams and atom-wise heatmaps, it identifies specific molecular regions that contribute to either “cytotoxic” or “non-cytotoxic” outcomes. This capability allows users to analyze structural fragments influencing toxicity, facilitating applications in drug design, safety assessments, and compound optimization.

Explainable AI (XAI) molecular diagrams illustrating the model’s predictions for Doxorubicin on the 3T3 (A) and HEK-293 (B) models, and for Ibuprofen on the 3T3 (C) and HEK-293 (D) models. Red contoured regions highlight areas with a strong positive influence on predicted cytotoxicity, whereas green contoured regions indicate a strong positive influence on predicted nontoxicity. The intensity of the contour colors reflects the magnitude of their influence, with darker shades representing a greater impact on the model’s predictions.

## Section: Results and Discussion › Limitations

It is important to mention that the Cyto-Safe 1.0, developed to predict cytotoxicity using data from 3T3 and HEK 293 cell lines with the CellTiter-Glo assay, has limitations related to data set characteristics and generalizability. The reliance on only two cell lines - 3T3 (derived from mouse fibroblasts) and HEK 293 (from human embryonic kidney cells) - restricts the model’s applicability to other biological contexts, as these cell lines may not accurately reflect the behaviors of a broader range of cell types. Furthermore, variations in cytotoxicity responses among different cell types - including differences between permanent cell lines and primary cells - underscore the necessity of considering cell type-specific nuances when interpreting cytotoxicity data.22

In addition to the cell line limitations, the specificity of the CellTiter-Glo assay complicates the model’s predictions. Different cytotoxicity assays, such as Lactate Dehydrogenase (LDH) release and MTT reduction, may detect varying aspects of cell viability, leading to divergent toxicological profiles. Additionally, variability in experimental conditions - such as cell density, culture medium, and incubation durations - further impacts reproducibility and the model’s reliability across different settings.23 The model’s training data are confined to specific incubation times, limiting its applicability for different exposure durations. To enhance the model’s robustness and generalizability, it would be necessary to incorporate a more diverse range of data sets, expanding beyond the current parameters under which it was developed.24 Until such advancements are made, users should approach the model’s predictions with a clear understanding of these constraints.

## Section: Results and Discussion › Comparative Analysis of QSAR Models for Cytotoxicity Prediction

Numerous QSAR models have been developed to predict cytotoxicity, each offering distinct strengths and facing particular challenges. Langdon et al.25 employed Bayesian models to achieve cross-assay predictivity; however, the reliance on heterogeneous assay data introduces variability, potentially affecting the consistency and reliability of predictions, and their models lack an interpretability feature.

ProTox 3.026 excels in providing multiend point toxicity predictions by leveraging molecular similarity and machine learning. Its computational efficiency makes it suitable for large-scale screening. However, the model operates as a black box, limiting interpretability and hindering its application in guiding molecular modifications. Yin et al.27 addressed the challenge of imbalanced data sets by implementing ensemble learning methods, which deliver strong predictive performance. Despite this, these models are not openly available to the community.

Other notable contributions include the work by Liu et al.,28 which focused on predicting microglial cytotoxicity using machine learning models integrated with feature selection and Shapley Additive Explanations. This method provided detailed substructure-level insights, enabling a deeper understanding of toxicological mechanisms. However, its requirement for local installation and computational skills limits its accessibility to users without a strong technical background, and it is limited by only predicting microglial cytotoxicity.

Sun et al.29 constructed predictive models based on multiple cell lines using support vector machines (SVMs). While these models achieved high predictive accuracy, they lack an explainable AI feature. Webel et al.30 explored the use of deep learning to identify cytotoxic substructures, offering mechanistic insights via Deep Taylor Decomposition. Although their work is promising, it remains exploratory and does not provide a readily available tool for broader use.

Cyto-Safe offers a distinctive approach by integrating prediction accuracy with interpretability and accessibility. Its web-based interface eliminates the need for installations, allowing users from diverse backgrounds to easily conduct predictive analyses. Moreover, Cyto-Safe incorporates Explainable AI (XAI), which generates atom-level heatmaps that elucidate the structural features contributing to toxicity predictions. This transparency not only enhances user confidence but also provides valuable guidance for structural optimization. By supporting multiple data input formats, Cyto-Safe ensures a streamlined experience, catering to both expert and nonexpert users.

In summary, Cyto-Safe bridges the gap between advanced predictive capabilities and practical usability, offering a comprehensive solution for cytotoxicity prediction while addressing the interpretability and accessibility limitations of existing models.

## Section: Conclusions

The Cyto-Safe web application demonstrates substantial efficacy in the binary classification of compounds based on cytotoxicity assessments in 3T3 and HEK 293 cells. Cyto-Safe is distinguished by its user-friendly interface, requiring no programming expertise, and its readiness for immediate deployment. Additionally, it offers transparent explanations of prediction outcomes, representing a significant advancement in the accessibility and usability of cytotoxicity assessment tools. The ongoing development of Cyto-Safe will include the expansion of predictive capabilities to encompass additional cell lines as new, high-quality data becomes available.

However, it is important to recognize the limitations of the model’s predictive capabilities, as they are influenced by the specific experimental conditions used during training. The reliance on 3T3 and HEK 293 cell lines, along with defined incubation times, restricts the model’s generalizability to other cell lines, assays, and exposure durations. To improve its robustness and generalizability, the model should be expanded to include a broader range of data sets, cell lines, assays, and incubation times.

In conclusion, Cyto-Safe is a valuable resource for both the scientific community and industry, facilitating the toxicity evaluation of drug candidates. The tool is freely accessible at http://insightai.labmol.com.br/, enabling users to leverage its capabilities to optimize drug development processes.


---

# Deep learning for low-data drug discovery: Hurdles and opportunities

- **Authors:** Derek van Tilborg, Helena Brinkmann, Emanuele Criscuolo, Luke Rossen, Rıza Özçelik, Francesca Grisoni
- **Issuer:** Current opinion in structural biology
- **Type:** Scientific article
- **Published:** 2024-04-25
- **Language:** en
- **DOI:** 10.1016/j.sbi.2024.102818
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38669740/
- **Licence:** CC-BY

## Section: Abstract

Deep learning is becoming increasingly relevant in drug discovery, from de novo design to protein structure prediction and synthesis planning. However, it is often challenged by the small data regimes typical of certain drug discovery tasks. In such scenarios, deep learning approaches-which are notoriously 'data-hungry'-might fail to live up to their promise. Developing novel approaches to leverage the power of deep learning in low-data scenarios is sparking great attention, and future developments are expected to propel the field further. This mini-review provides an overview of recent low-data-learning approaches in drug discovery, analyzing their hurdles and advantages. Finally, we venture to provide a forecast of future research directions in low-data learning for drug discovery.


---

# Deep-PK: deep learning for small molecule pharmacokinetic and toxicity prediction

- **Authors:** Yoochan Myung, Alex G. C. de Sá, David Benjamin Ascher
- **Issuer:** Nucleic Acids Research
- **Type:** Scientific article
- **Published:** 2024-04-10
- **DOI:** 10.1093/nar/gkae254
- **Source:** https://doi.org/10.1093/nar/gkae254
- **Licence:** CC-BY

## Section: Abstract

AbstractEvaluating pharmacokinetic properties of small molecules is considered a key feature in most drug development and high-throughput screening processes. Generally, pharmacokinetics, which represent the fate of drugs in the human body, are described from four perspectives: absorption, distribution, metabolism and excretion—all of which are closely related to a fifth perspective, toxicity (ADMET). Since obtaining ADMET data from in vitro, in vivo or pre-clinical stages is time consuming and expensive, many efforts have been made to predict ADMET properties via computational approaches. However, the majority of available methods are limited in their ability to provide pharmacokinetics and toxicity for diverse targets, ensure good overall accuracy, and offer ease of use, interpretability and extensibility for further optimizations. Here, we introduce Deep-PK, a deep learning-based pharmacokinetic and toxicity prediction, analysis and optimization platform. We applied graph neural networks and graph-based signatures as a graph-level feature to yield the best predictive performance across 73 endpoints, including 64 ADMET and 9 general properties. With these powerful models, Deep-PK supports molecular optimization and interpretation, aiding users in optimizing and understanding pharmacokinetics and toxicity for given input molecules. The Deep-PK is freely available at https://biosig.lab.uq.edu.au/deeppk/.

## Section: Introduction

Drug discovery is a costly, lengthy and uncertain problem (1–7). Usually, the process of proposing a novel drug, from pre-clinical testing to approval, takes 12–15 years (5,8), on average, and the cost exceeds $2.5 billion (5,9,10). Most of the mapped hardness of this process emerges from the stringent multiple phases defined by regulatory agencies, which need to certify both the safety and potency of the new compounds during pre-clinical and clinical trials before their respective approval (11,12). In these phases, an inherent issue in drug discovery is the high attrition rate, where 80–90% of projects are discontinued before even getting tested in humans (5), and almost 95% of the drugs entering human trials fail (4,5,13). Along the same lines (14), estimates suggest that only 1 out of 5000–10 000 discovered compounds reaches the U.S. Food and Drug Administration (FDA)’s review phase (15).

Evaluating, understanding and optimizing pharmacokinetic and toxicity properties under the umbrella of ADMET (absorption, distribution, metabolism, elimination and toxicity) categories have become essential for reducing attrition rates in later phases of drug research and development (3,16–21). Over 80% of newly proposed drugs fail during development stages because of inadequate ADMET properties (22). It is estimated that success rates could increase significantly if ADMET properties were properly set at pre-clinical and clinical stages (23–26).

Both in vivo and in vitro assessments of small molecules have become important strategies for the initial selection or identification of chemical leads (27). Although being precise and useful in screening small molecules, reducing the overall number of molecules likely to present issues on pharmacokinetic and toxicity properties, in vivo and in vitro ADMET studies are expensive, inefficient and time consuming (in terms of human resources, equipment and laboratory operations) to assess the ADMET properties on the ever-growing number of developed compounds (25,28–30), besides the efforts on automation to tackle the drug screening bottleneck.

Under these circumstances, computational (in silico) approaches are a great alternative for pre-screening the high number of compounds being proposed on a day-to-day basis (25,30–35). Furthermore, in vitro or in vivo analyses are only possible after the molecule has already been synthesized (36), not being feasible to test them a priori. Hence, in silico ADMET evaluation is advantageous in terms of meeting the high compound throughput, allowing prioritization of compound libraries.

Several methods and tools have been proposed to promote ADMET evaluation, including SwissADME (34), ADMETlab (25,30), pkCSM (32), Interpretable-ADMET (35) and toxCSM (33). In spite of the computational effort, all these tools have major issues with integrating other important tasks apart from the predictive analysis, such as optimization and predictive molecular interpretation. In addition, the majority of the currently proposed tools do not consider a proper set of ADMET endpoints nor open their used experimental data. Unavailability and lack of scalability are also common drawbacks of current ADMET tools and methods. In summary, they are not able to accurately and correctly guide drug development research at scale.

We introduce Deep-PK, an advanced web-based tool designed to address the challenges and issues associated with small molecule pharmacokinetics and toxicity. Deep-PK stands out for its interpretability, accuracy and robustness, offering a comprehensive solution for the prediction, optimization, analysis and interpretation of these crucial profiles. It depends on the robustness of graph neural networks (GNNs) to build a set of 73 robust ADMET models. With predictive, optimization and interpretation features, Deep-PK yields a trustworthy platform for the development of safer, less toxic and highly bioavailable drugs.

## Section: Materials and methods

Deep-PK pipeline. In the data collection and curation steps, publicly available datasets were gathered and curated to eliminate redundancy, resolve label conflicts and ensure consistency in endpoint label units. These curated datasets were then utilized for preparing benchmark and Deep-PK datasets (Supplementary Table S1). In addition to the default node/edge features provided by Chemprop, our approach incorporated 449 graph-level features in the D-MPNN (directed message passing neural network) learning process. Hyperparameter optimization was carried out using Bayesian optimization with 3-fold cross-validation. Deep-PK provides predictions for 73 pharmacokinetic and toxicity endpoints, along with detailed information on corresponding molecules accessible through the analysis page. Users can explore optimization strategies for a query molecule through the optimization step, which includes 100 derivatives and predictions of ADMET and general properties.

## Section: Materials and methods › Data preparation

Data collection and curation. In Deep-PK, small molecule datasets on 73 endpoints were employed to train, (cross-)validate and test the deep learning models, including 49 and 24 that represent binary classification and regression tasks, respectively. These datasets correspond to 8 absorption, 5 distribution, 13 metabolism, 3 excretion and 35 toxicity experimental assays. In addition, 9 datasets involving general and complementary physicochemical properties were also used to assist in the characterization of small molecules (Supplementary Table S1). We collected the experimental ADMET data from four pharmacokinetic prediction methods, namely ADMETlab 2.0 (25), Interpretable-ADMET (35), toxCSM (33) and pkCSM (32).

Given the high level of heterogeneity among the small molecules and their respective ADMET targets, we proceeded with preprocessing steps to guarantee the validity and quality of the data. As shown in Figure 1, the first step involved converting all SMILES (simplified molecular-input line-entry system), which represent the small molecules, in their canonical form. Molecular sanitization using RDKit version 2022.9.3 (37) was also performed and included standardizing up to seven non-standard valence states, kekulizing aromatic rings, removing molecular weights ≥2000 and adding explicit hydrogens. Any molecules that failed at the canonization and sanitization steps were discarded from our acquired data.

The experimental labels were rigorously verified in the preprocessing pipeline of Deep-PK. SMILES with discrepancies such as different categorical labels, units or a variation of 20% in label values (for regression tasks) were identified and discarded from the dataset utilized to acquire ADMET experimental data for Deep-PK. The details of curated datasets are shown in Supplementary Table S1.

Training, validation and test datasets. We conducted a comprehensive assessment of the Deep-PK pipeline’s robustness and scalability through two distinct approaches. Initially, we utilized datasets from other tools, incorporating their training, validation and test split information. Subsequently, we aggregated all data points for each endpoint from various databases, creating what we refer to as the Deep-PK dataset.

To evaluate our deep learning pipeline, we specifically focused on the endpoints provided by ADMETlab 2.0 and toxCSM, as we consider them state of the art given their respective predictive performance for pharmacokinetic and toxicity prediction. The number of data points may vary between the original dataset and the curated version due to the standardization process. In summary, we assessed the Deep-PK pipeline on 53 and 36 endpoints for the ADMETlab 2.0 and toxCSM platforms, respectively.

For the Deep-PK pipeline models, the curated datasets underwent a random split into training, validation and test datasets at a ratio of 8:1:1 after merging across all available databases and standardization. Consequently, Deep-PK encompasses 73 endpoints, involving both 49 classification and 24 regression tasks. All datasets are available for download at https://biosig.lab.uq.edu.au/deeppk/data.

Analysis of molecular properties. Using a radar plot, we added an indication of whether users’ query molecules fall within the range of certain FDA-approved drugs’ ADMET range. This range is based on 329 FDA-approved drugs and their predicted ADMET values (see Supplementary Figure S8).

Prediction confidence. The reliability of models is pivotal in assessing their credibility, and this is often gauged through prediction probabilities, particularly in the context of classification tasks (38). While this measure is valuable, it may not comprehensively address the coverage of chemical space bridging the training data and query molecules.

In pursuit of a more nuanced understanding of confidence, Deep-PK goes beyond mere prediction probabilities. For both classification and regression tasks, our model assesses whether the query molecule falls within the 95% range of training molecular weight. Additionally, in regression tasks, the model checks whether the predicted values align with the 95% range of training labels. This extended scrutiny offers a more detailed perspective on the model’s confidence, accounting for both the molecular weight and predicted values, thereby providing a richer evaluation of model reliability across various dimensions of chemical space.

Deep-PK pipeline. In the data collection and curation steps, publicly available datasets were gathered and curated to eliminate redundancy, resolve label conflicts and ensure consistency in endpoint label units. These curated datasets were then utilized for preparing benchmark and Deep-PK datasets (Supplementary Table S1). In addition to the default node/edge features provided by Chemprop, our approach incorporated 449 graph-level features in the D-MPNN (directed message passing neural network) learning process. Hyperparameter optimization was carried out using Bayesian optimization with 3-fold cross-validation. Deep-PK provides predictions for 73 pharmacokinetic and toxicity endpoints, along with detailed information on corresponding molecules accessible through the analysis page. Users can explore optimization strategies for a query molecule through the optimization step, which includes 100 derivatives and predictions of ADMET and general properties.

## Section: Materials and methods › Deep learning

Graph neural networks. The core framework of Deep-PK relies on the D-MPNN of Chemprop introduced by Yang et al. (39). D-MPNN facilitates information propagation through directed edges, enabling the transmission of crucial information with a specific directionality between nodes. This unique feature empowers D-MPNN to enhance the aggregation of molecular representations by finely controlling the flow of information.

During the training phase, our pipeline employed Matthew’s correlation coefficient (MCC) for classification tasks and R2 (coefficient of determination) for regression tasks as loss functions. This selection was made to optimize the model’s performance across different tasks. To mitigate batch effects and reduce the risk of obtaining inflated performance values, we implemented an ensemble method, 3-fold cross-validation, which averages and calculates the standard deviation of performance metrics across three models, ensuring a comprehensive and consistent assessment of performance. This approach enhances the robustness of our model evaluations by providing a more reliable measure of predictive accuracy.

Feature engineering. In addition to the initial 8 atom (node) features and 4 bond (edge) features adopted from Chemprop, our approach incorporates 216 graph-based signatures (32,40), 37 toxicophore counts (41) and 196 molecular descriptors extracted from RDKit, except 4 descriptors such as ‘MaxAbsPartialCharge’, ‘MaxPartialCharge’, ‘MinAbsPartialCharge’ and ‘MinPartialCharge’, which returned a not-a-number value on several SMILES, as additional molecular (graph) level features. To ensure the efficiency and relevance of the features, we applied a variance threshold of 0.0 to eliminate any non-relevant and non-additive information (42).

Hyperparameter optimization. To efficiently search for all 12 individual hyperparameter spaces from the Chemprop pipeline, we employed a Bayesian optimization method with 500 randomly initialized runs and another 500 values for posterior optimizations on the following parameters: the number of message passing iterations (depth), the dropout probability (dropout), activation function, batch size, aggregation, the hidden size of neural network layers, initial learning rate, maximum learning rate, final learning rate, warm-up epochs, the number of feed-forward layers and aggregation normalization. In total, we ran 160 000 optimization runs for 73 Deep-PK, 53 ADMETlab 2.0 and 36 toxCSM endpoints individually.

GNN interpretability. The concept of explainability in GNNs has been known to be useful for identifying key parts (subgraphs) of prediction. We use this substructure highlighting of Chemprop to provide ideas like what sites should be kept, changed or removed from queries in terms of each endpoint and across those that shared the same explainability (Supplementary Figures S9 and S10).

Optimization. The optimization of Deep-PK generates up to 100 samples from a query molecule by adding, replacing or removing substructures using the MultI-constraint MOlecule SAmpling (MIMOSA) method (43). We implemented a pre-trained model for optimizing the quantitative estimate of drug-likeness (QED) (44), which is one of the key features of drug discovery.

## Section: Web server

Deep-PK was developed using Bootstrap 3.3.7 and Flask 1.0.2 and hosted on an Apache 2 Ubuntu server. This web server is freely available at https://biosig.lab.uq.edu.au/deeppk.

## Section: Web server › Input

Deep-PK can be used to assess the pharmacokinetic and toxicity properties of small molecules based on ADMET and, also, general properties. As shown in Supplementary Figure S1, Deep-PK accepts four types of inputs: (i) a single SMILES string; (ii) a SMILES file containing a set of small molecular compounds (up to 2000 molecules); (iii) a structural data file (SDF) covering a list of molecular structures (up to 2000 molecules); and (iv) a single molecular drawing, where its respective SMILES is retrieved from the drawn molecule structure. These are the most standard formats in small molecule research, commonly used in their respective web servers. Example files and a help page to guide users are provided at https://biosig.lab.uq.edu.au/deeppk/prediction and https://biosig.lab.uq.edu.au/deeppk/help, respectively. Users can choose which ADMET prediction mode they want to make their compound analysis on, including running everything all at once.

## Section: Web server › Output

The web server encompassing Deep-PK stresses its four main prediction outputs: (i) the prediction results page, where the pharmacokinetic, toxicity and general small molecule properties are displayed after all selected models have their outcomes completed (Supplementary Figure S2); (ii) the focus page, where the predictions of each molecule are better detailed and explained with confidence values and interpretations based on the literature (Supplementary Figure S3); (iii) the analysis page, where each molecule that had their ADMET properties predicted can be further analysed in terms of general properties, drug-likeness and predictive substructure importance (Supplementary Figures S4–S10); and (iv) the optimization page, where the given query molecule is optimized, aiming to improve the pharmacokinetic and toxicity properties, which are of interest to the target user or researcher (Supplementary Figure S11). Whereas the results for the prediction and optimization pages can be downloaded in a CSV (comma-separated value) file, the results of the analysis page are retrieved in a ZIP file.

## Section: Web server › Application programming interface

The Deep-PK integrates an application programming interface (API) to facilitate the development, validation and testing of cheminformatics and drug discovery analytical pipeline. Each submission in Deep-PK’s API has a unique string identifier, which can be used to retrieve the predictive results after the web server processing. It is worth noting that these results are also available through the web server prediction results page. Deep-PK’s API allows the use of SDFs, SMILES files and SMILES strings. When the predictions are completed, Deep-PK outputs only standard tabular results in a JavaScript object notation format. The documentation (in both Python and Curl languages) and examples of how to use Deep-PK’s API are available at https://biosig.lab.uq.edu.au/deeppk/api_docs.

## Section: Web server › Processing times

Deep-PK has been proposed to serve as a scalable platform for predicting a diverse range of pharmacokinetic and toxicity properties of small molecules. While assessing Deep-PK’s capabilities, we estimated that it takes up to 15 min to predict all 73 ADMET properties for a single molecule after the prediction processing work starts—i.e. after the respective web server job is released from the queue to be processed. Furthermore, the processing time for optimizing a single molecule and providing the predictions for the resultant 100 optimized molecules is estimated to be 20 min after being released from the optimization queue. Finally, Deep-PK takes up to 55 min to analyse the characteristics of each molecule, considering this is the first job to be processed in the analysis queue. The small molecule analysis includes the substructural explanations per endpoint, which we consider as the current processing bottleneck for Deep-PK. Future work involves improving the efficiency of the molecule’s explanation component.

## Section: Validation

The performance of Deep-PK models/pipelines was thoroughly compared with available tools. Since those tools were trained and tested on different datasets that are difficult to obtain, the metrics, MCC and R2 for classification and regression tasks, for each approach were collected from their original papers. To simplify and enhance visualization, the 73 results were categorized into six types of target predictions: absorption, distribution, metabolism, excretion, toxicity and property. These predictions were further divided into two task types: classification and regression.

## Section: Validation › Benchmarking across available tools

ADMETlab 2.0. The comprehensive evaluation of the Deep-PK pipeline (Figure 1), encompassing feature extraction to hyperparameter optimization, was compared with ADMETlab 2.0, a cutting-edge pharmacokinetic and toxicity prediction tool. The assessment covered 53 endpoints, comprising 40 classification and 13 regression tasks, providing a thorough examination of the model’s performance across diverse targets.

To simplify the presentation of results, both MCC and R2 metrics, ranging from 0 to 1 for classification and regression tasks, were merged in Supplementary Figure S12. Notably, Deep-PK exhibited enhanced performance (the performance increase is >0) across 46 endpoints, showcasing its highest performance gap of 0.43 on ‘NR-A’, while demonstrating comparatively lower performance on 5 endpoints with the lowest performance gap of −0.082 (MCC) from ‘oral bioavailability 30%’ (see Supplementary Figure S12).

Analysing the average performance across each category, Deep-PK showed the most notable improvement in metabolism achieving an average performance increase of +0.105 across 10 metabolism endpoints (see Supplementary Table S2). Adopting a categorization strategy where performance changes within ±0.1 are considered no improvement, those exceeding 0.1 are deemed reasonable improvement and surpassing 0.2 are considered significant improvement, Deep-PK achieved significant improvement in 4 models, reasonable improvement in 17 models and maintained stability in 32 models with Δ ±0.1. This nuanced breakdown provides a nuanced understanding of the Deep-PK model’s performance across various pharmacokinetic endpoints.

toxCSM. In the assessment of 36 toxCSM toxicity profiles (Supplementary Figure S13), Deep-PK demonstrated enhanced performance across 30 endpoints, notably exhibiting a substantial improvement in MCC (0.39) for ‘NR-ER’—a reasonable enhancement comparable to the earlier ADMETlab 2.0 benchmark (MCC improvement of 0.13). The overall performance averages, encompassing MCC and R2, were 0.58 for toxCSM and 0.71 for Deep-PK.

By employing a performance delta (Δ) classification, where ±0.1 signifies no/weak improvement, >0.1 and <0.2 indicates reasonable improvement and ≥0.2 denotes significant improvement, Deep-PK achieved 7 significant improvements, 10 reasonable improvements and 19 instances where no/weak improvement was observed (see Supplementary Table S3).

## Section: Validation › Performance on Deep-PK datasets

As we confirmed that the Deep-PK pipeline is powerful enough to improve the performance on most pharmacokinetic, toxicity and general property endpoints, we applied the same workflow on the Deep-PK datasets, which were merged and curated across four databases.

The performance of Deep-PK on this curated dataset was subsequently compared with other available tools (see Supplementary Table S4 and Supplementary Figures S14 and S15), albeit without employing identical training and test datasets. It is important to note that such comparisons may not be directly equitable. Nevertheless, they provide valuable insights into the performance enhancements facilitated by our novel approach and the integration of new datasets.

By comparing Deep-PK with other available methods (maximum available methods versus Deep-PK), we observed significant improvements in 6 instances (up to an MCC increase of +0.43) on ‘renal excretion (OCT2)’, alongside reasonable enhancements in 15 cases (MCC increase of +0.1 or greater) and weaker improvements across 38 endpoints. Consistent with previous benchmark tests, the Deep-PK pipeline demonstrated a significant performance boost in the excretion and metabolism category, achieving an average MCC increase of +0.10 and +0.07 across 13 metabolism and 3 excretion endpoints, respectively.

## Section: Discussion

The prediction of pharmacokinetic and toxicity properties is a key step during the drug screening and lead optimization processes. As more data and machine learning algorithms are available, more accurate predictions have been available (25,32–35). Due to the nature of the difficulty of collecting data, many tools have not been thoroughly benchmarked or did not include their predictors in a single platform for better usability. Although GNN has empowered the field of pharmacokinetic and toxicity predictions with its benefit of featurizing from the molecule itself giving the state-of-the-art performance (25,35), the lack of performance comparison across different approaches has been a limit for using or comparing each other.

We anticipate that Deep-PK’s predictive models, which are anchored in the chemical landscape illustrated in Supplementary Figure S16, possess a degree of generalizability that should translate into robust performance when applied to novel molecules. Our analysis through principal component analysis, utilizing both MACCS keys (Supplementary Figure S16A) and Morgan fingerprints (Supplementary Figure S16B), demonstrates that the structural diversity of 2.3 million compounds from ChEMBL (ChEMBLdb 33) is well represented, even with a dataset size 20 times smaller than Deep-PK. Remarkably, the chemical spaces of FDA-approved drugs (DrugBank) fall within the coverage of Deep-PK, underscoring the potential utility of our models for targeting FDA approval pathways.

However, it is crucial to acknowledge that the accuracy of predictions may be constrained by the inherent limitations of available assay data, particularly when users submit compounds that are markedly different from those in the training dataset. While our focus does not extend to ‘zero-shot learning’, we expect a certain level of similarity between user queries and the datasets used to train, validate and test Deep-PK models. Moreover, to bolster confidence in our predictions, Deep-PK furnishes additional confidence values for each outcome (Supplementary Figure S3).

By integrating molecular properties as graph-level features, Deep-PK significantly enhanced prediction performance across two benchmark datasets (i.e. ADMETlab 2.0 and toxCSM), notably achieving improvements of >0.43 and 0.39 in MCC values for NR-AR and NR-ER, respectively. These advancements underscore Deep-PK’s potential as a robust screening platform for nuclear hormone receptors, signifying its potential utility in identifying endocrine-disrupting chemicals, which are pivotal in various fields and types of drugs.

Additionally, it is noteworthy that assessing the variation of model performance across 3-fold cross-validations, which maintain identical hyperparameter configurations but undergo dataset shuffling with different random seeds, can be crucial in gauging the reliability of deep learning models. For example, Supplementary Figure S17 illustrates significant performance fluctuations observed during 3-fold cross-validations of the Cyp1a2 substrate, particularly when models exhibit lower performance. This statistical insight can instill greater confidence in the models, especially when their performance is naturally constrained from achieving higher levels of accuracy. We have confirmed that Deep-PK models demonstrate consistent performance across all 73 endpoints, further enhancing confidence in their reliability (Supplementary Table S4).

However, we observed some performance degradation using Deep-PK datasets, particularly on four endpoints (Supplementary Table S4), where the performance change (Δ) ranged from −0.15 to −0.58. The possible main factor behind this performance drop is data corruption, as evidenced by the contrast in performance. For example, while Deep-PK achieved improved performance on Marine Tox (fathead minnow) with MCC values of 0.767 and 0.601 on ADMETlab 2.0 and toxCSM datasets, respectively, it experienced a significant drop to an MCC of 0.16. This suggests a possible data corruption issue in the process of merging the two datasets. Consequently, we opted to select the best-performing model across three versions of our datasets.

It is crucial to distinguish between model credibility and performance, as they represent distinct facets. While performance confidence often focuses on metrics like classification probability, this approach has inherent limitations, particularly regarding its applicability to classification tasks exclusively. However, for reliable predictions, it is imperative that query molecules inhabit similar chemical spaces and label ranges to the training data. To address this, Deep-PK effectively incorporates additional confidence tags, such as ranges of molecular weights and labels (Supplementary Figure S3), empowering users to interpret prediction results with greater certainty.

Furthermore, GNNs offer a unique advantage by encapsulating molecular features at node and edge levels, facilitating information propagation across different layers. Leveraging graph-level features enables Deep-PK to identify key molecular regions influencing predictions, shedding light on critical insights. Notably, Deep-PK not only highlights the most influential subgraphs within a query molecule (Supplementary Figure S9) but also identifies common subgraphs among categories (Supplementary Figure S10). This capability proves invaluable, particularly in multifaceted categories like metabolism and toxicity, guiding targeted lead optimization efforts. Additionally, Deep-PK provides an indication of whether users’ query molecules fall within the range of certain properties, particularly regression properties, such as FDA-approved drugs’ ADMET range. This range is based on 329 FDA-approved drugs and their predicted ADMET values (see Supplementary Figure S8).

The goal of drug discovery optimization is to enhance molecules based on ADMET endpoints. To further enhance molecules, Deep-PK introduces an optimization protocol that modifies substructures, bridging a gap in pharmacokinetic prediction platforms that typically focus solely on value prediction. Using the MIMOSA library, Deep-PK generates 100 new molecules from a query molecule with an improved QED. These molecules are then evaluated for pharmacokinetic and toxicity profiles, highlighting any changes in endpoints resulting from the optimization process. While Deep-PK’s optimization function generates novel molecules with the potential for improved ADMET properties, it is crucial to acknowledge that molecule generation primarily relies on log P and QED. Consequently, the outcomes of optimization may not consistently reflect enhanced ADMET characteristics. Nevertheless, the optimized molecules typically show heightened QED values and maintain compatibility across various chemical spaces, attributable to the comprehensive dataset utilized in their training.

In summary, Deep-PK emerges as an invaluable screening and optimization platform for the drug discovery process, offering deep analysis based on state-of-the-art performing GNN models and rapidly optimizing new molecules tailored for drug candidates. By doing so, it significantly reduces costs and time associated with unnecessary in vitro or in vivo pre-clinical tests, while also mitigating potential risks inherent in these tests.


---

# DigFrag as a digital fragmentation method used for artificial intelligence-based drug design

- **Authors:** Ruoqi Yang, Hao Zhou, Fan Wang, Guangfu Yang
- **Issuer:** Communications chemistry
- **Type:** Scientific article
- **Published:** 2024-11-11
- **Language:** en
- **DOI:** 10.1038/s42004-024-01346-5
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39528759/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractFragment-Based Drug Design (FBDD) plays a pivotal role in the field of drug discovery and development. The construction of high-quality fragment libraries is a critical step in FBDD. Conventional fragmentation approaches often rely on rigid rules and chemical intuition, limiting their adaptability to diverse molecular structures. The rapid development of Artificial Intelligence (AI) technology offers a transformative opportunity to rethink traditional methods. Here, we present DigFrag, a digital fragmentation method that highlights important substructures by focusing locally within the molecular graph. In addition, we feed the fragments segmented by machine intelligence and human expertise into the deep generative model to compare the preference for data from different sources. Experimental results show that the structural diversity of fragments segmented by DigFrag is higher, and more desirable compounds are generated based on these fragments. These results also demonstrate that data generated based on AI methods may be more suitable for AI models. Moreover, a user-friendly platform called MolFrag (https://dpai.ccnu.edu.cn/MolFrag/) is developed based on various fragmentation techniques to support molecular segmentation.Subject terms: Virtual screening, Cheminformatics, Computational chemistry

## Section: Introduction

Fragment-based drug design (FBDD) is the process of screening for favorable fragments and combining them to create drug molecules1,2. Compared to traditional high-throughput screening methods, FBDD allows the exploration of a much broader chemical space and the discovery of active compounds with a higher hit rate3. A high-quality fragment library is a prerequisite for FBDD. Typically, the segmentation of a molecule in accordance with predefined guidelines stands as a highly effective means of obtaining these structural fragments, and is of paramount importance in the field of FBDD4. However, it is noteworthy that few innovative studies on fragmentation methods have been reported. Conventional fragmentation methods, exemplified by the likes of RECAP5 and BRICS6, predominantly hinge on the principles of retrosynthesis, where a set of rules govern the breaking of chemical bonds, often emphasizing the selective cleavage of acyclic bonds. As eloquently elucidated by Diao et al., this restriction has its rationale, but it greatly reduces the novelty of the obtained fragments, especially for macrocyclic compounds7,8. Furthermore, these methods do not allow a reasonable selection of fragment size. To elaborate, the diminution of fragment size to an extreme extent may inadvertently disrupt the pharmacophores, while an excessively large fragment may not efficiently extract smaller substituents9.

Over the past decade, artificial intelligence (AI) technologies have achieved great success in many fields. With the increasing abundance of biomedical data, many AI-driven predictive models have been introduced into the field of drug discovery and development, including convolutional neural networks (CNNs)10, recurrent neural networks (RNNs)11, and graph neural networks (GNNs)12. In particular, GNNs consider the input molecules as graphs with attributes, and obtain graph embeddings through the three steps of message passing, aggregation, and updating13. Studies have shown that the attention mechanism serves to improve both the efficiency and accuracy of the model by directing its focus towards feature information that is more relevant to the given task14,15. Combining attention mechanisms with GNNs can better reveal the relative importance of structural fragments within a compound.

Typically, chemists with extensive expertise segment molecules based on chemical rules. In contrast, machine intelligence-oriented perspective, while lacking domain knowledge, provide a distinctive paradigm by segmenting molecules based on mathematical logic (i.e., statistics). Through a comparative analysis of these fragmentation methods, our investigation illuminates that AI-based models segments unique fragments that are feasible in the virtual world but may not be applicable in the real world. This discrepancy between reality and virtuality underscores the intrinsic advantage of AI-based methods, as they enable the exploration of uncharted territories and overcome the limitations of traditional methods. Consequently, the potential of AI to transcend the boundaries of established chemical paradigms becomes manifest, opening frontiers in the field of molecular segmentation.

On this basis, we propose DigFrag, a digital fragmentation method based on the graph attention mechanism, which gets rid of the constraints of traditional chemical rules and segments drug/pesticide molecules with attention weights (i.e., contribution to the prediction task) oriented to ultimately obtain the drug/pesticide-like fragments from the perspective of machine intelligence rather than human expertise. Comparison results show that the structural diversity of the fragments segmented by DigFrag is higher. In addition, the application of these fragments to deep generative models yields desirable compounds, highlighting the potential of DigFrag in FBDD. The scheme of this work is depicted in Fig. 1. We believe that DigFrag is a more applicable fragmentation method for AI drug discovery.

A Flowchart of molecular fragmentation using the DigFrag method. B Framework of actor-critic model applied to a fragmented molecule. C Establishment of an online platform to facilitate researchers.

## Section: Results

Average properties of drug fragments segmented by the four methods (BRICS, RECAP, MacFrag and DigFrag)

Average properties of pesticide fragments segmented by the four methods (BRICS, RECAP, MacFrag and DigFrag)

A Similarity cutoff = 0.2. B Similarity cutoff = 0.4. C Similarity cutoff = 0.6. D Similarity cutoff = 0.8. Each type of fragment was obtained by the four methods (BRICS, RECAP, MacFarg and DigFrag), respectively.

Performance evaluation of different metrics for the generated drug molecules using the four fragment-based deep generative models

Performance evaluation of different metrics for the generated pesticide molecules using the four fragment-based deep generative models

A, C Distributions of Quantitative Estimation of Drug-likeness (QED) for the generated drug molecules and pesticide molecules. B, D Distributions of Synthetic Accessibility (SA) for the generated drug molecules and pesticide molecules.

Four desirable molecules are shown in green, yellow, blue and pink stick form and yellow dashed lines are hydrogen bonds.

Four desirable molecules are shown in green, yellow, blue and pink stick form and yellow dashed lines are hydrogen bonds.

A Different fragmentation methods are available to users to segment the uploaded molecules. If users have no data, MolFrag provides FDA-approved drugs and commercial pesticides. B In the jobs page, users can view the fragment information obtained after segmentation of the molecules, including physicochemical property, drug/pesticide-like evaluation and synthetic accessibility.

## Section: Results › Comparison of the property distributions of segmented fragments

Prior to comparison, we trained the models to segment drug/pesticide fragments. The results of the five-fold cross-validation are presented in Supplementary Table 1. It can be seen that these models demonstrated excellent and robust performance across the three key metrics, with accuracy, area under the curve (AUC), and Matthews correlation coefficient (MCC) exceeding 0.90, 0.96, and 0.80, respectively.

Next, we conducted an in-depth evaluation of the fragments obtained by the proposed method (DigFrag), the conventional methods (RECAP5 and BRICS6), and the latest method (MacFrag8), focusing on the property distributions as a critical metric of comparison. As shown in Table 1 and Supplementary Fig. 1, for drug fragments, the DigFrag fragments were much closer to the BRICS fragments in terms of property distributions. For example, the differences in molecular weight and the number of hydrogen bond acceptors between the two groups of fragments were not significant. Interestingly, we found that the DigFrag fragments had a significantly higher number of rotatable bonds compared to the BRICS fragments, which may be attributed to their unique cleavage of cyclic bonds. However, for pesticide fragments, the properties of the DigFrag fragments were distributed in lower regions (Table 2 and Supplementary Fig. 2). Taking molecular weight as an example, the average molecular weight of DigFrag fragments was 137.07, signifying a substantial reduction in comparison with the other three fragments. It should be noted that all properties of the DigFrag fragments showed a similar trend, whether they were drugs or pesticides. In addition, we calculated the number of fragments obtained following the segmentation of each drug/pesticide molecule by the four methods. As shown in Supplementary Fig. 3, none of these methods, except MacFrag, segmented the molecule into more than 20 fragments. In terms of distributions, DigFrag displayed greater similarity to BRICS, and both methods tended to segment smaller fragments.

Average properties of drug fragments segmented by the four methods (BRICS, RECAP, MacFrag and DigFrag)

Average properties of pesticide fragments segmented by the four methods (BRICS, RECAP, MacFrag and DigFrag)

## Section: Results › Comparison of the structural diversity of segmented fragments

We then performed a rigorous analysis of the four methods, with a primary focus on the structural diversity of the segmented fragments. As shown in Supplementary Table 2, our findings demonstrated a remarkable disparity. Specifically, for both drugs and pesticides, the number of duplicates between the fragments segmented by the DigFrag method and the other three methods was low (9.97–21.37% for drugs and 8.94–15.20% for pesticides). In contrast, the fragments segmented by the MacFrag method almost covered the BRICS fragments (96.42% for drugs and 99.05% for pesticides) and the RECAP fragments (76.59% for drugs and 76.31% for pesticides). This suggests that the MacFrag method is only an extension of the conventional methods, while the proposed DigFrag method is able to obtain more unique fragments. In addition, we counted the occurrence numbers of each fragment in the four fragmentation methods and visualized their spatial distribution using the t-distributed Stochastic Neighbor Embedding (t-SNE) algorithm. As illustrated in Supplementary Figs. 4–5, over 75% of the drug/pesticide fragments occurred in only one method. The proportion of drug/pesticide fragments shared by two methods (mainly MacFrag) was approximately 20%, while less than 5% of the remaining fragments occurred in three or four methods. It is noteworthy that despite the small number of fragments shared by the four methods, these had a more dispersed distribution in chemical space compared to the fragments shared by the three methods.

To provide a more comprehensive insight into the assessment of structural diversity, we employed the fragment cluster ratio as a quantitative measure, which provides a more intuitive reflection of the overall structural diversity within the fragment sets. As shown in Fig. 2 and Supplementary Tables 3–4, the DigFrag method consistently yielded higher fragment cluster ratios than other methods. In particular, for the most commonly used similarity thresholds (0.4 and 0.6), the fragments segmented by the DigFrag method exhibited greater structural diversity.

A Similarity cutoff = 0.2. B Similarity cutoff = 0.4. C Similarity cutoff = 0.6. D Similarity cutoff = 0.8. Each type of fragment was obtained by the four methods (BRICS, RECAP, MacFarg and DigFrag), respectively.

## Section: Results › Comparison of the qualities of generated molecules

Subsequently, we conducted a comparative analysis of generative models utilizing distinct sets of fragments on the MOSES benchmarking platform16. As shown in Tables 3–4, the drug molecules generated by the MacFrag-based model achieved optimal results in terms of uniqueness and diversity, but the Filters score was significantly lower than that of the other models, which suggests that these compounds are unsatisfactory in terms of safety. In contrast, the Filters score of the drug molecules generated by the DigFrag-based model was 0.828, indicating the improved safety of compounds modified by digital fragments compared to other fragments. We speculate that this observed superiority may be attributed to the inherent capacity of deep learning models to incorporate considerations of toxicity risk, stability, and other pertinent factors during the fragmentation process, which is not possible with the other three methods. Similarly, except for a slightly higher proportion of duplications, the pesticide molecules generated by the DigFrag-based model achieved superior performance in terms of SMILES validity, novelty, scaffold diversity, and structure alerts. Moreover, an examination of the average Quantitative Estimation of Drug-likeness (QED)17 and Synthetic Accessibility (SA)18 revealed that drug/pesticide molecules generated by the DigFrag-based model outperformed those generated by the other models, as illustrated in Fig. 3. To quantitatively compare the similarity between the property distributions of the generated molecules and the MOSES dataset, the Wasserstein-1 distance provided by the platform was utilized. As shown in Supplementary Tables 5–6, the drug/pesticide molecules generated by the DigFrag model exhibited the highest similarity in terms of three property distributions (molecular weight, QED, and SA). Taken together, these results demonstrate that FBDD employing DigFrag fragments yields molecules of higher quality. Furthermore, the findings suggest a preference within AI-based models for AI-sourced data, reinforcing the potential advantages of leveraging AI in molecular design.

Performance evaluation of different metrics for the generated drug molecules using the four fragment-based deep generative models

Performance evaluation of different metrics for the generated pesticide molecules using the four fragment-based deep generative models

A, C Distributions of Quantitative Estimation of Drug-likeness (QED) for the generated drug molecules and pesticide molecules. B, D Distributions of Synthetic Accessibility (SA) for the generated drug molecules and pesticide molecules.

## Section: Results › Binding affinity calculation of generated molecules to specific targets

Considering that the DeepFMPO architecture does not incorporate information about the target during the optimization of molecular structures, we performed molecular docking to assess the binding strength of the modified drug/pesticide molecules to the dopamine receptor D2 (DRD2)/4-hydroxyphenylpyruvate dioxygenase (HPPD). As anticipated, marginal disparities in binding affinity were observed between the drug/pesticide molecules generated by the four methods. Specifically, the binding free energy ranges of the generated compounds were −9.16 to −9.36 Kcal/mol (DRD2) and −8.37 to −8.53 Kcal/mol (HPPD), respectively (Supplementary Fig. 6). It is noteworthy that, despite the lack of a pronounced advantage for the drug/pesticide molecules generated by the DigFrag method, they manifested an acceptable level of binding to the corresponding targets, indicating the preservation of desired properties and high affinities.

## Section: Results › Binding mode analysis of selected molecules to specific targets

Through the application of refined filters, we identified 24 desirable drug molecules and 20 desirable pesticide molecules that satisfy QED values greater than 0.75, SA values less than 3, and binding free energies less than the positive drug Domperidone (−10.7 Kcal/mol)19/positive pesticide Mesotrione (−8.4 Kcal/mol)20. The chemical structures of these selected molecules are presented in Supplementary Figs. 7–8. Subsequently, an in-depth analysis of the interaction between several desirable drug/pesticide molecules and the corresponding targets was performed. As shown in Figs. 4–5, all drug ligands were effectively docked into the active pocket of DRD2 and formed hydrogen bonds with amino acid residues SER-193, TYR-416, THR-119, VAL-115, TRP-413, and GLU-95. Similarly, all pesticide ligands were stably bound to HPPD through hydrogen bonding interactions with amino acid residues SER-65, SER328, ASP-211, ASP-387, TYR-88, TYR-103, and LEU-78. Intriguingly, the generated compounds exhibited a distinct binding mode compared to the positive drug, suggesting a potential pharmacological mechanism that warrants further exploration in future investigations.

Four desirable molecules are shown in green, yellow, blue and pink stick form and yellow dashed lines are hydrogen bonds.

Four desirable molecules are shown in green, yellow, blue and pink stick form and yellow dashed lines are hydrogen bonds.

## Section: Results › Web server construction and application

Although several fragmentation methods have been reported, no easy-to-use web server is available. Therefore, an innovative platform called MolFrag (https://dpai.ccnu.edu.cn/MolFrag/) was constructed that seamlessly combines four molecular fragmentation approaches, ensuring accessibility to researchers with varying levels of expertise (Fig. 6). We believe that the application of MolFrag streamlines the process of molecular segmentation, making it an invaluable resource for the scientific community.

A Different fragmentation methods are available to users to segment the uploaded molecules. If users have no data, MolFrag provides FDA-approved drugs and commercial pesticides. B In the jobs page, users can view the fragment information obtained after segmentation of the molecules, including physicochemical property, drug/pesticide-like evaluation and synthetic accessibility.

## Section: Discussion

In recent years, the field of drug discovery and development has been profoundly revolutionized by advances in AI technology10–12. In this work, we introduced DigFrag, an intuitive fragmentation method that segments molecular structures based on AI-driven models, thereby circumventing the constraints inherent in traditional bond-breaking rules. We comprehensively compared the fragments obtained by machine intelligence with those obtained by human expertise. The results demonstrate the superior efficacy of DigFrag in the segmentation of diverse molecular fragments. Furthermore, we fed two initial sets of compounds with the four sets of drug/pesticide fragments into an existing deep generative model. The outcomes of this experiment exhibited the propensity of the DigFrag-derived model to generate molecules characterized by desired properties, thereby substantiating that AI-based models may be more compatible with AI-sourced data.

When we review conventional fragmentation methods, it becomes evident that they are limited in certain contexts. Chemists have successfully refined these methods through extensive experience and domain knowledge. However, in the evolving scientific environment, we are faced with increasingly complex molecular systems. Therefore, we want to explore how we can leverage the power of AI to drive the evolution of molecular fragmentation methods. In addition, we focus not only on the limitations of traditional methods, but also on the differences in data adaptability between machine intelligence and human expertise.

In the FBDD study, we integrated the fragments segmented by the four methods (BRICS, RECAP, MacFrag and DigFrag) into the DeepFMPO framework. To our surprise, AI-based models appeared to be more effective in utilizing the data derived from AI-based methods, and the generated molecules exhibited remarkable excellence in most of the evaluation metrics. Moreover, conventional fragmentation methods tended to ignore target-related information, while DigFrag was able to incorporate this information, which facilitated the segmentation of the same molecular entities into distinct fragments, thereby leading to more personalized molecular design.

However, it is imperative to acknowledge that there is discernible room for improvement within the proposed method. Firstly, an important direction for future research lies in conducting a comprehensive investigation to explore the underlying reasons why data from AI-based methods exhibit increased compatibility with AI-based models. Secondly, recognizing the limitations associated with the two-dimensional graph, which inherently neglects the geometric space of compounds, we aspire to segment molecules based on the three-dimensional graph. This endeavor is expected to yield richer conformational information about the fragments. Furthermore, since the development of fragment-based deep generative models is still in its infancy, we are committed to developing more deep learning frameworks for specific targets, thus expanding the practical application of this method.

Overall, our findings demonstrate that data generated based on AI methods may be more applicable to AI models. We strongly believe that this idea establishes a versatile research paradigm with far-reaching implications in various scientific domains (e.g., materials). For future work, we will strive to extend this idea to a broader range of subtasks, thereby generating more expansive data available for AI-based model exploitation.

## Section: Methods › Dataset curation

The modeling dataset utilized in this study was sourced from our self-constructed database called PADFrag21. This database primarily contains 1652 United States Food and Drug Administration (FDA)-approved drugs cataloged in DrugBank and 1259 commercial pesticides listed in Alan Wood. To improve data consistency, structurally non-standard compounds were systematically excluded. The dataset was then partitioned into distinct subsets for the purposes of training, validation, and testing in an 8:1:1 ratio.

## Section: Methods › AI-based fragmentation method › Construction of molecular graph

In the field of drug discovery and development, GNN-based architectures have been shown to achieve excellent predictive performance for various subtasks12,22. The molecular graph, serving as the input representation of GNNs, is defined as G = (V, E), where V stands for nodes (atoms) and E stands for connecting edges (chemical bonds). In this work, the featurization of these elements was executed using the AttentiveFPAtomFeaturizer and AttentiveFPBondFeaturizer modules of the open-source toolkit DGL-LifeSci23 (Supplementary Table 7).

## Section: Methods › AI-based fragmentation method › Model architecture

In this study, we employed the AttentiveFP framework introduced by Xiong et al. to capture the structural information of molecules24. This architecture represents a feature extraction network based on the graph attention mechanism. Specifically, the original molecular graph is initially fed into a series of attention layers to obtain individual atomic embeddings. Subsequently, these embeddings are combined into a unified vector, commonly referred to as a super node. Finally, the entire molecular embedding is obtained through multiple attention layers. It is noteworthy that the attention layer consists of two essential components: the aggregation module (Eqs. 1–3) based on the attention mechanism and the update module (Eqs. 4–5) based on the gated recurrent unit (GRU).

where hv and hu represent the vector of node v and the neighbor node u, and W is a trainable weight matrix.

where k represent iteration number, and M is the message function.

## Section: Methods › AI-based fragmentation method › Segmentation of molecules

Considering the latent relationship between structural fragments and drug/pesticide-likeness, DigFrag was used to leverage the graph attention mechanism to segment the molecular graph into subgraphs of different sizes (i.e., structural fragments). Consecutively, the fragments with relatively diminished relevance were filtered out by setting an attention weight threshold, while the fragments closely related to the drug/pesticide-likeness were retained. Moreover, the conventional fragmentation method (BRICS and RECAP) was implemented in RDKit, and the latest fragmentation method (MacFrag) was implemented through the source code released by the authors.

## Section: Methods › Comparative analysis of the fragments obtained by the four methods

In the present study, we conducted a comparative assessment of segmented fragments from two aspects. At the structural level, we generated the corresponding Morgan fingerprint for each fragment using the GetMorganFingerprintAsBitVect module of RDKit. For a more rigorous quantitative evaluation, we executed Butina clustering based on the Tanimoto Coefficient25 for distinct groups of fragments using the BulkTanimotoSimilarity and ClusterData modules of RDKit and then calculated the fragment cluster ratio, which is denoted as the ratio of fragment clusters to the total number of fragments. Higher values of this metric indicate greater diversity in the structural landscape. At the property level, we used the open-source software PaDEL-Descriptor26 to calculate several attributes related to the drug/pesticide-likeness rules, including molecular weight, LogP, topological polar surface area, number of hydrogen bond donors, number of hydrogen bond acceptors, number of rotatable bonds27,28. It should be noted that the calculation of fingerprints and attributes did not consider the breaking position of the fragments, mainly due to the fact that these representations are not relevant to the broken bond information.

## Section: Methods › Fragment-based molecular generation

To further elucidate the influence of digital and traditional fragments on fragment-based deep generative models, we undertook an investigation utilizing the DeepFMPO29 architecture developed by Ståhl et al. with a specific focus on its application in de novo drug design. DeepFMPO is an actor-critic reinforcement learning model that acquires the ability to generate compounds with desired properties by replacing fragments within a compound. Therefore, the generation of molecules using DeepFMPO requires a balanced binary tree library and an initial set of lead molecules. In this study, the former are the fragments segmented by different methods, and the latter are the molecules collected from the ChEMBL database30 that did not fulfill the sweet spot criteria (561 molecules for DRD2 and 221 molecules for HPPD). The model architecture used a bidirectional long short-term memory (LSTM) network, with the number of neurons in the hidden layer being 128, 64, and 32, respectively. The learning rate and batch size were set to 1e-4 and 512, respectively. Model training was executed until 4000 epochs were reached, after which all molecules generated in the last 100 epochs were compiled and a random selection of 1000 molecules was sampled as representatives for subsequent analysis. Performance evaluation of each model was conducted on the MOSES benchmarking platform16.

## Section: Methods › Molecular docking of the generated molecules

Docking studies were performed to assess the protein-ligand binding affinity of representative molecules with DRD2 (drug) and HPPD (pesticide). The three-dimensional structures of the targets were obtained from the Protein Data Bank database31 (ID: 6CM432 and 5YWG33) and subsequently subjected to dehydration, hydrogenation, and charge calculation using AutoDockTools software. The three-dimensional structures of representative drug/pesticide molecules were constructed using ChemOffice software34. Binding free energy calculations were performed using Autodock Vina software35. Furthermore, the visualization of protein-ligand interactions was achieved through the utilization of PyMOL software36.

## Section: Supplementary information

Supplementary Information

Description of Additional Supplementary Files

Supplementary Data 1

## Section: Acknowledgements

This work is supported by the National Key Research and Development Program of China (2023YFD1700500) and the National Natural Science Foundation of China (No. 21837001).

## Section: Author contributions

F.W. and G.Y. conceived the project. R.Y. and H.Z. performed the computational experiments. F.W. and R.Y. collected and analyzed the data. R.Y. wrote the manuscript. F.W. and G.Y. provided evaluation and suggestions.

## Section: Peer review › Peer review information

Communications Chemistry thanks the anonymous reviewers for their contribution to the peer review of this work.

## Section: Data availability

The data required to reproduce our results are available at 10.5281/zenodo.13997755. The numerical source data of main figures are available in Supplementary Data 1. All other data are available from the corresponding authors upon reasonable request.

## Section: Code availability

The source code implemented in this study is available at https://github.com/yang1rq/MolFrag.

## Section: Competing interests

The authors declare no competing interests.

## Section: Contributor Information

Fan Wang, Email: fwang@ccnu.edu.cn.

Guangfu Yang, Email: gfyang@ccnu.edu.cn.

## Section: Supplementary information

The online version contains supplementary material available at 10.1038/s42004-024-01346-5.

## Section: Associated Data

Supplementary Information

Description of Additional Supplementary Files

Supplementary Data 1

## Section: Associated Data › Supplementary Materials

Supplementary Information

Description of Additional Supplementary Files

Supplementary Data 1

## Section: Associated Data › Data Availability Statement

The data required to reproduce our results are available at 10.5281/zenodo.13997755. The numerical source data of main figures are available in Supplementary Data 1. All other data are available from the corresponding authors upon reasonable request.

The source code implemented in this study is available at https://github.com/yang1rq/MolFrag.


---

# Does artificial intelligence need companionship to assist in drug discovery? The Kirsten rat sarcoma virus study

- **Authors:** Mourad Stitou, John M Koomen, Denis J Imbody, Yi Liao, Andrii Monastyrskyi, Uwe Rix, Derek R Duckett, Eric B Haura, Aleksandra Karolak
- **Issuer:** BJR artificial intelligence
- **Type:** Scientific article
- **Published:** 2024-03-04
- **Language:** en
- **DOI:** 10.1093/bjrai/ubae001
- **Source:** https://pubmed.ncbi.nlm.nih.gov/42064400/
- **Licence:** CC-BY

## Section: Abstract

AbstractIn this Opinion article, we confront the role of artificial intelligence (AI) in targeting and understanding resistance to targeted therapy using the most frequently mutated oncoprotein family in human cancer, rat sarcoma virus guanosine triphosphate hydrolases (RAS GTPases), here Kirsten RAS (KRAS), as an example. Aberrant regulation of the active GTP-bound state of KRAS is associated with tumourigenesis, aggressive disease, and poor prognosis. KRAS mutations (eg, G12C, G12D, G12V, G13D, inter al.) are drivers of numerous cancer types, including non-small cell lung, colorectal, and pancreatic cancers. These mutations have shown to play a significant role in cell behaviour and response to treatment. Since its discovery in the 1980s, it has been recognized that over-expression of KRAS and other RAS family members induces resistance to radiotherapy. Moreover, over the years preclinical and clinical studies showed that tumours with KRAS mutations exhibit different treatment sensitivities compared to tumours with wild-type KRAS.Keywords: AI, drug discovery, fragment-based drug discovery, acquired resistance

## Section: The conventional wisdom of undruggable KRAS

Until this decade, KRAS was considered undruggable.1,2 The featureless character of KRAS at the molecular level including smooth and spherical shape and lack of evident binding sites or pockets stalled many research initiatives. KRAS acts as guanine diphosphate/triphosphate GDP/GTP switch responsible for signal transduction between activated receptors on the membrane and cellular components.3 GTP binding induces conformational change that triggers KRAS activation, while KRAS mutations lock the mutant in its active GTP-bound state.4 Therefore, higher cellular concentrations of GTP over GDP, higher (picomolar) affinity of KRAS towards GTP, and altered off-rates of KRAS mutants towards GTP increased the ‘drugging challenge’.3–5

## Section: The promising prospects

With the development of KRAS G12C small molecule irreversible inhibitors, overcoming these challenges became a reality.6 In 2021, the Food and Drug Administration (FDA) approved AMG510 (sotorasib),7 an allele-specific covalent inhibitor of the KRAS G12C mutant. MRTX849 (adagrasib, approved in 20228) displayed clinical responses across multiple tumour types and showed promising activity against cancers harbouring this KRAS mutation. Unfortunately, tumours with KRAS mutations eventually develop resistance to monotherapy following either ‘on-target’ or ‘off-target’ resistance mechanisms. The ‘on-target’ resistance is characterized by secondary KRAS mutations affecting binding of the inhibitor, while other isoforms of KRAS or MAPK signalling pathway members become activated in the ‘off-target’ resistance.4 Several KRAS secondary mutations might interfere with key protein-drug interactions (eg, Y96D, Y96C) and trigger resistance to KRAS G12C inhibitors.1,9 Even though a distinct KRAS G12C active-state inhibitor, RM-018, demonstrated the ability to overcome resistance by targeting KRAS G12C/Y96D double mutation in the binding sites10 (other tricomplex inhibitors targeting KRAS G12C are now in clinical trials11), such development of novel mutations following treatment or radiotherapy presents an even more formidable challenge.

To address the challenges posed by resistance to first-generation KRAS monotherapy by acquired KRAS mutations, researchers have been actively exploring various possibilities and therapies that could advance KRAS targeting either through development of optimized drugs or radiation. Current leading strategies to sensitize tumours to radiation and enhancement of treatment efficacy focus on combined therapies targeting signalling pathways of mutated KRAS;12 however, it remains unclear whether the combination therapies will work in patients.

## Section: Call for cross-disciplinary collaborations

In our opinion, understanding the mechanisms and dynamics of specific KRAS mutations is the key to (i) guide treatment decisions in chemotherapy, targeted therapy, and radiation oncology, (ii) predict secondary mutational processes that may appear, and (iii) develop strategies to overcome the resulting drug resistance. However, no progress can be made without cross-disciplinary collaborative initiatives that integrate various scientific perspectives, including structural biology, functional genomics, and pharmacology. Despite constraints of limited data and bottlenecks of high-throughput screening (HTS)13 (eg, target validation, candidate optimization, and constraints in experimental testing), recent artificial intelligence (AI)-based studies present promising opportunities to transform drug discovery14 with several examples reaching clinical testing (NCT05154240 and published studies15,16). AI techniques can learn and self-correct, improving their performance with each new dataset. As AI technologies gain experience, the quality of the data used becomes crucial, adhering to the principle of ‘garbage in, garbage out' and the paradox of acquiring large sample size versus high-quality data.16 This challenge impacts their ability to enhance accuracy and making them powerful tools to analyse data to evaluate complex clinical scenarios, like secondary resistance to KRAS inhibitors in patients’ tumours.

Artificial intelligence-guided drug discovery may encounter failures due to various reasons, including the lack of sufficient high-quality data and the black-box nature of certain AI models (especially observed for neural network architectures of multiple hidden layers, high dimensionality of the features, and utilization of nonlinear functions), hindering interpretability or understanding of their predictions, and limiting their acceptance in critical decision-making processes. To overcome these challenges, researchers should prioritize building comprehensive databases and repositories to capture emerging mutations and therapeutic responses. Data sharing initiatives and open-access repositories could create a vast and accessible pool of data to fuel AI-guided drug discovery. Additionally, development of specialized AI models capable of handling the complexities of drug-protein interactions and the complex pathways is essential. AI architectures, such as graph-based models, show potential to better interpret complex biological data and analyse complex biological processes that could address drug resistance. Furthermore, to be successful, drug discovery requires integration of AI model strengths with experimental HTS data. In our opinion, by verifying AI-guided predictions through experiments and iteratively improving AI techniques based on experimental feedback, researchers can further optimize and automate drug discovery. Overall, through interdisciplinary collaboration, innovative methodologies, and an emphasis on interpretability and validation, AI can become an invaluable tool in drug discovery.17

In conjunction with experimental efforts, genomic analyses, histologic evaluations, and molecular simulations, AI holds tremendous promise in overcoming drug resistance in KRAS mutant cancers. Here, we provide our perspective on top key strategies incorporating AI, which can create successful novel therapeutic strategies:

## Section: Potential of human and machine intelligence

In summary, AI can serve as a bridge, facilitating interdisciplinary research by integrating expertise from medicinal chemistry, molecular and computational biology, bioinformatics, and pharmacology.22,23 The synergy of these fields, combined with AI-driven analyses, allows for a comprehensive understanding of resistance mechanisms and the development of effective therapeutic strategies and translation to the clinic.16 The collaborative efforts between AI, other computational, and experimental research are crucial for translating these discoveries into clinical applications and advancing personalized medicine approaches for patients in need.24 Further identification of specific biomarkers associated with KRAS mutations may help predict mutations and tumour response to therapy, enabling clinicians to select the most effective treatment strategy. We believe that only through collaborative efforts and communication across disciplines we can unlock the full potential of human and machine intelligence against oncogenic mutations, leading to personalized and effective treatments for patients with resistant tumours.

## Section: Contributor Information

Mourad Stitou, Department of Machine Learning, Moffitt Cancer Center, Tampa, FL 33612, United States.

John M Koomen, Department of Molecular Oncology, Moffitt Cancer Center, Tampa, FL 33612, United States.

Denis J Imbody, Department of Thoracic Oncology, Moffitt Cancer Center, Tampa, FL 33612, United States.

Yi Liao, Department of Drug Discovery, Moffitt Cancer Center, Tampa, FL 33612, United States.

Andrii Monastyrskyi, Department of Drug Discovery, Moffitt Cancer Center, Tampa, FL 33612, United States.

Uwe Rix, Department of Drug Discovery, Moffitt Cancer Center, Tampa, FL 33612, United States.

Derek R Duckett, Department of Drug Discovery, Moffitt Cancer Center, Tampa, FL 33612, United States.

Eric B Haura, Department of Thoracic Oncology, Moffitt Cancer Center, Tampa, FL 33612, United States.

Aleksandra Karolak, Department of Machine Learning, Moffitt Cancer Center, Tampa, FL 33612, United States.

## Section: Funding

None declared.

## Section: Conflicts of interest

None declared.


---

# Drug Discovery in the Age of Artificial Intelligence: Transformative Target-Based Approaches

- **Authors:** Akshata Yashwant Patne, Sai Madhav Dhulipala, William Lawless, Satya Prakash, Shyam S Mohapatra, Subhra Mohapatra
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2024-11-14
- **Language:** en
- **DOI:** 10.3390/ijms252212233
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39596300/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe complexities inherent in drug development are multi-faceted and often hamper accuracy, speed and efficiency, thereby limiting success. This review explores how recent developments in machine learning (ML) are significantly impacting target-based drug discovery, particularly in small-molecule approaches. The Simplified Molecular Input Line Entry System (SMILES), which translates a chemical compound’s three-dimensional structure into a string of symbols, is now widely used in drug design, mining, and repurposing. Utilizing ML and natural language processing techniques, SMILES has revolutionized lead identification, high-throughput screening and virtual screening. ML models enhance the accuracy of predicting binding affinity and selectivity, reducing the need for extensive experimental screening. Additionally, deep learning, with its strengths in analyzing spatial and sequential data through convolutional neural networks (CNNs) and recurrent neural networks (RNNs), shows promise for virtual screening, target identification, and de novo drug design. Fragment-based approaches also benefit from ML algorithms and techniques like generative adversarial networks (GANs), which predict fragment properties and binding affinities, aiding in hit selection and design optimization. Structure-based drug design, which relies on high-resolution protein structures, leverages ML models for accurate predictions of binding interactions. While challenges such as interpretability and data quality remain, ML’s transformative impact accelerates target-based drug discovery, increasing efficiency and innovation. Its potential to deliver new and improved treatments for various diseases is significant.Keywords: drug discovery, graph neural networks, random forests, general adversarial networks, target-based approaches, phenotypic approaches

## Section: 1. Introduction

For centuries, the quest to discover life-saving medications has been a relentless pursuit fraught with challenges and uncertainties. The intricate journey from identifying a disease target to delivering a safe and effective drug remains a marathon, often hampered by limited speed, efficiency, and success. However, recent advancements in artificial intelligence (AI) have ignited a spark of hope, injecting a transformative force into the drug discovery landscape.

The complexities that are inherent in drug development are multi-faceted. Targets, often intricate proteins or enzymes, may harbor hidden mechanisms or allosteric sites, making intervention difficult. The vast chemical space, with an astronomical number of potential molecules, poses a daunting challenge when it comes to identifying the right drug candidate. Ensuring drug safety, efficacy, and affordability also requires navigating regulatory hurdles. These unmet needs have fueled the search for innovative solutions, and AI has emerged as a powerful tool to revolutionize the drug discovery process.

Numerous reviews have explored the potential of AI in drug discovery, focusing on specific aspects like virtual screening, target identification, or deep learning applications. While valuable, these reviews often lack a comprehensive overview encompassing the diverse range of AI-driven approaches within target-based and phenotypic strategies.

This review aims to bridge this gap by offering a holistic perspective on the transformative impact of AI in drug discovery. We delve into the intricacies of target-based approaches, exploring advancements in small-molecule, fragment-based, and structure-based methods. We then shed light on the potential of phenotypic approaches, leveraging AI to analyze cell-based assays and genetic screens. Beyond these specific strategies, we examine the broader contributions of AI in drug repurposing, computational predictions, and personalized medicine.

## Section: 2. Methods

Machine learning (ML) is an emerging field derived from AI, an idea that began with Alan Turing in the 1940s and has accompanied the computer revolution over the last four decades. The discovery of carbon nanomaterials, including carbon nanotubes and graphene, in 2004 provided impetus for early AI algorithms for the game of checkers, facial image recognition, and self-driving cars [1]. In short, ML encompasses the study and training of various types of algorithms that use input from datasets to predict an output independently [2]. Through several trials, a user improves the set of algorithms, known as a model, to make more accurate predictions [3]. The intricate complexities of disease targets and the vast chemical landscape have long burdened the relentless pursuit of effective medications. Traditional target-based approaches, while revolutionizing drug discovery, have also faced limitations. High-throughput screening (HTS) offered rapid lead identification, but false positives and neglect of drug-like properties hampered progress. Fragment-based and structure-based approaches and virtual screening (VS) provided finesse, but challenges remained. Fortunately, the dawn of AI involving ML and deep learning approaches has ignited a transformative era, empowering each approach with unprecedented capabilities.

In the context of ML, the field can be broadly categorized into supervised and unsupervised learning. Supervised learning involves training algorithms on labeled data to predict new, unseen data, while unsupervised learning identifies patterns and structures within unlabeled data. Common examples of supervised learning tasks include classification and regression, while clustering and dimensionality reduction are typical unsupervised learning tasks, as shown in Figure 1.

Example of algorithms and classifiers in ML models [4,5].

Example of algorithms and classifiers in ML models for small molecule-based approach drug discovery [9].

A select list of SVM models and applications.

Example of algorithms and classifiers in ML models for a fragment-based approach to drug discovery [24].

Example of Algorithms and Classifiers in ML Models for Structure-Based Approach Drug Discovery [46].

Examples of ML’s role in drug discovery by increasing the speed and efficacy of bioinformatics.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA)

The traditional workhorse of target-based drug discovery was HTS. This approach initially involved physical testing of vast libraries of small molecules against specific biological targets, like proteins or enzymes, to identify potential lead candidates. These physical assays were later automated by machine pipetting and computer tracking, which increased speed and validation while reducing labor and material costs. While HTS revolutionized drug discovery by accelerating lead identification, it faced significant limitations. Many screened compounds often resulted into higher false-positive rates, requiring further validation and optimization. Additionally, HTS predominantly focused on ligand binding without considering crucial aspects like drug-like properties, pharmacokinetics, and toxicity, potentially leading to failures later in development [6].

These limitations were addressed with the development of computational-based VS methods, which precede experimental verification. VS is performed on thousands or even millions of compounds to create a top-ranking small-molecule interaction derived from physics-based computational calculations that measure predicted binding free energy. Analysis can be performed as either a structure-based drug design, which employs the biomolecular structure, or as a ligand-based design, which does not require a structure. VS also faces several challenges, such as the need for user knowledge about the binding target structure to avoid high computational costs, increase binding accuracy, and avoid erroneous assumptions. The computational cost in terms of both time and machine investment can be high, and calculations based on poorly established coordinates for binding pockets or overly large binding pockets can increase the computational time exponentially.

ML solves several problems associated with traditional VS and can augment structure- and ligand-based drug design with remarkable accuracy. ML incorporates training data into an analytical method and utilizes a separate set of validation data that assess a given model’s prediction accuracy and precision, determining the best possible ML model for a specific demand. Figure 2 elaborates on the small molecule-based approaches divided into supervised and unsupervised learning and various models, methods, input, and output using ML.

Recent advancements in ML have ignited a transformative era in target-based drug discovery [7]. ML models, empowered with vast datasets of chemical and biological information developed originally for VS, can predict small molecules’ potential binding affinity and selectivity with remarkable accuracy without any initial physical assay, dramatically reducing the number of compounds that require experimental validation. Furthermore, generative models can design novel small molecules with desirable properties, expanding the search space for promising lead candidates [8].

Example of algorithms and classifiers in ML models for small molecule-based approach drug discovery [9].

A select list of SVM models and applications.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.1. SMA-Supervised Learning

Supervised learning algorithms leverage established knowledge (also called test data) to make predictions. In supervised methods, we can use a controlled approach with large datasets to develop confidence in known relationships or work on meta-relationships to identify leads from big datasets. Some prominent examples used in the small-molecule approach are listed below.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.2. SMA-Support Vector Machines (SVMs)

This model finds the optimal hyperplane, a decision boundary used to maximize the margin between different data points, which helps filter the noise of the data and increase prediction accuracy. Interdependent training sets—including random, closely related, highly active, and boundary molecules—can be used to improve small molecule-binding predictions. The project stage at which ML models are applied dictates the choice of training set. Some of the examples of SVM models and their applications are shown in Table 1. One study investigated the difference between active and passive training methods and showed that the iterative selection of the model improved hit prediction accuracy by 29% for the thrombin dataset. This study also observed the advantages of exploitation using only the highest positive scores over exploration near a decision boundary for fewer data points, and the near equal efficiency of both when there are more data points [10]. Meanwhile, some studies used SVMs for predicting and scoring optimal docking poses. These studies showed predictions of consistent RMSD values (>0.9) and low prediction error (0.25), indicating high predictivity with minimal overfitting [11]. Studies working with novel protein targets without known 3D structures trained the vector machine models on 2D fingerprints of the chemical structure of a protein sequence. They utilized the linear combination method to yield a significant improvement in the prediction of compound activity compared to homology modeling-based predictions, as evidenced by the recovery rates of the projections. SVMs built using the linear combination method showed a 50% improvement in recovery rates for all target molecules [12].

A select list of SVM models and applications.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.3. Random Forests (RFs)

In this model, random subsets of data are organized as nodes, and these subsets are used to “grow” the tree. A prediction is made by aggregating all these trees. These models have proven to be very efficient with docking pose predictions [15]. The Matthews Correlation Coefficient (MCC) has been used to evaluate prediction model performance by considering true and false positives and negatives [16]. Higher MCC values, indicating better predictions, were achieved, with models reaching MCC values of 0.8 within 2000 to 3000 iterations and 0.6 within 3000 iterations. RF implementations combine the output of decision trees to handle classification and regression problems, predicting IC50 values of drug interactions and demonstrating statistical significance in two-tailed t-tests [17]. RDKit generates 2D depictions in PDBe CCDUtils, aiding RF regression to predict drug sensitivity with high accuracy [18]. These examples show the relevance and advantage of RF methods, which, even with minimal parameter tuning, demonstrate faster learning and balanced selection strategies when dealing with high-scale multivariate data.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.4. Convolutional Neural Networks (CNNs)

These models were designed to use image data. They use some layers to extract features from images and some layers to reduce dimensionality. Then, all layers are combined to make the final predictions. These models work best in applications with minimal feature engineering and image data. They have been used in studies to analyze graphs built upon preliminary sequential data or fingerprints [19]. In pharmacokinetics, the Area Under the Curve (AUC) refers to the definite integral of the concentration of a drug in blood serum as a function of time, serving as an essential predictor of drug bioavailability. One study explored CNN architectures for classifying ligands of cannabinoid receptors, achieving impressive results with AUC values ranging from 0.693 to 0.944 across different datasets, with the LeNet-5 architecture consistently outperforming others, as demonstrated by AUC scores peaking at 0.942 for AtomPair fingerprints on the CB1 test set [20]. Another study predicts electrostatic potential (ESP) surfaces for proteins and ligands using graph-convolutional deep neural network (DNN) models. ESP maps account for the overall strength of adjacent charges to a given point within a molecule and can predict molecular interactions with target residues within binding pockets. Trained against density functional theory (DFT) ESP surfaces, the ligand deep neural network fingerprint (DNN-fp) model outperforms AM1-BCC, providing fast, high-quality predictions that correlate strongly with experimental molecular properties, enabling interactive drug design [21]. Currently, the biggest challenges associated with supervised learning methods are the requirement of larger datasets and the possibility of bias in parameter selection in various approaches.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.5. SMA-Unsupervised Learning

Unsupervised learning algorithms can draw patterns within data without predetermined labels. This makes them particularly valuable for exploring novel chemical spaces and identifying promising lead candidates for targets without known actives. However, unsupervised learning can also contribute significantly to targets with known binders. In contrast to supervised methods, these frameworks require a smaller database and are more suitable for establishing new relationships and hidden patterns between parameters.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.5. SMA-Unsupervised Learning

Clustering is suitable for identifying patterns by grouping similar data naturally without drastically affecting the data size [22]. This method is particularly useful when dealing with incomplete input data, such as parts of input sequences or sections of structural fingerprint ensembles, where parts of the dataset are unavailable [23]. There are three prominent frameworks for clustering models: K-means, bisecting k-means, and Ward’s algorithm. K-means has been applied in deep clustering methods for proteins with no known active agents. By identifying leads for target proteins based on similarity and structure–activity relationships, k-means has shown impressive accuracy in predicting potential targets [24]. For example, in some applications, clusters have successfully predicted the binding affinity of protein–ligand interactions, making it a valuable tool in drug discovery. Bisecting k-means improves upon traditional k-means by recursively splitting lower-level clusters into subclusters [25]. This approach is particularly effective for irregular datasets, outperforming randomized k-means initialization by detecting significant motif patterns. For instance, bisecting k-means has been used to identify rare but important structural motifs in protein–ligand binding sites, improving the precision of lead identification over standard k-means methods. Ward’s method, which is commonly employed for quantitative variables when binary variables do not exist, minimizes variance within clusters. It excels in applications with consistent compound families, eventually form a single cluster. Ward’s method has been utilized to implement the Székely–Rizzo clustering approach to determine compound structures based on 2D fingerprints [26]. This has been instrumental in grouping compounds with similar chemical properties, and aiding the design of novel compounds in drug discovery.

## Section: 2. Methods › 2.1. Small Molecule-Based Approach (SMA) › 2.1.5. SMA-Unsupervised Learning

These models use an encoder to compresses the input data and a decoder to reconstructs new data from the compressed data. They have a high prediction accuracy, particularly when dealing with large datasets [27]. For example, TensorFlow-based autoencoders have improved predictions and overall accuracy in the context of the breast cancer gene GL50, spurring the development of comprehensive datasets for other ML models used in drug discovery [28].

Another study utilizes SMILES structures from the CHEMBL database to prepare a low-dimensional latent space representation and generate topographic maps. These maps could be used to prepare a compound library with insights into accessibility based on potential synthesis process complexity and latent descriptors. Data-driven latent vectors provided a much better representation of the compounds due to flexibility with input data, bringing nuance to the library [29].

One study displayed a direct advantage of unsupervised methods during pre-training, as demonstrated by very high prediction accuracy when a restricted Boltzmann machine-based implementation of a deep belief network built on key fingerprints from the molecular access system (MACCS) [30].

However, the source of those hidden relationships from the above-mentioned unsupervised models can be difficult to deduce, as they are built upon themselves with low-dimensionality input data. This can lead some fundamental supervised methods to outperform the unsupervised methods downstream.

## Section: 2. Methods › 2.2. Fragment-Based Approach (FA)

The fragment-based approach differs from the small-molecule approach by utilizing partial segments of pre-established structures. This is more useful for understanding structure–activity relationship studies [22]. The smaller fragments simplify the optimization of lead compounds, exponentially expediting the drug discovery process by eliminating the need to calculate all chemical interactions using various methods, as described in Figure 3 [23].

AI plays a similar role to the previous approach in advancing fragment-based drug discovery, contributing to various tasks crucial for optimizing lead compounds. The ML algorithms utilized in this context are significantly different, with projects using AI in a fragment-based approach have a broader-range of parameter selection—Such as binding affinity, energy, or entropy.

Example of algorithms and classifiers in ML models for a fragment-based approach to drug discovery [24].

## Section: 2. Methods › 2.2. Fragment-Based Approach (FA) › 2.2.1. FA-Supervised Learning

These algorithms have been used to analyze the relationship between fragment data and binding pocket interactions by predicting fragment structure based on the SMILES format sequence or by including characteristics like chemical properties [25]. One study factored in the free energy of the fragments to predict docking poses [26]. This technique has been used to form a shrinkage logistic regression model to predict the fragment interaction [31]. Some frameworks of neural networks have been modeled based on the Monte Carlo dropout method, trained mostly on the binding affinity and binding energy of different compounds to estimate uncertainty and improve predictability. One study employed molecular dynamics (MD) simulations to predict the free energies of 15,000 small molecules transferred between water and cyclohexane using a 3D-CNN. The results demonstrate the prediction of 2.5–5 KJ/Mol, aligning with experimental models [32].

## Section: 2. Methods › 2.2. Fragment-Based Approach (FA) › 2.2.2. FA-Support Vector Machines (SVMs)

As stated in Shahab et al.’s study which predicted binding pockets and fragment properties, SVMs can classify and analyze large datasets of fragments to identify those with specific characteristics relevant to drug development. For instance, they have been used to predict the binding modes of kinase inhibitors based on X-ray structures as templates and have proved to be a reliable method for building large libraries [33]. It is important to note that SVMs were suggested to be more suitable for downstream validation or precision predictions of structures over preliminary fingerprint-based predictions until selectivity parameters like IC50 were utilized during training, yielding 92% prediction accuracy [34].

## Section: 2. Methods › 2.2. Fragment-Based Approach (FA) › 2.2.3. Reinforcement Learning

Reinforcement learning is more suitable for iterative scoring in training stages of the model; the greater the number of iterations, the better the model’s scoring performance and results [35]. One recent study utilized molecular graph transformers based on compounds from CHMEBL and LIGAND databases [36]. The researchers iteratively reinforced the model with scoring based on interactive parameters of small fragments, such as drugs’ similarities to and affinity towards their study target protein A2AAR, to generate structures using the SMILES format, with an exploitation-focused approach [37]. These models could generate fragments that were highly compatible with A2AAR [38]. Another study explored structural characteristics like fragment length, branching, and bond flexibility. This study focused on the scoring strategy based completely on the raw potential of fragments. The scoring for this model focused more on exploration. The generated fragment libraries have a range just as vast as the input libraries [39]. Thus, this approach would be more advantageous for compound synthesis than the case-/disease-specific transformer application.

## Section: 2. Methods › 2.2. Fragment-Based Approach (FA) › 2.2.4. FA-Unsupervised Learning

Studies show high prediction accuracy for the construction of molecular fingerprints based on two Word2vec models (with skip-gram (SG) and continuous bag of words (CBOW) implementation), developing t-distributed stochastic neighbor embedding (t-SNE) plots and QSAR modeling [40]. Specifically, kinase inhibitors and anti-HIV compounds showed sensitivity of 77% and specificity of 87% for distributed fingerprints, with sensitivity of 67% and specificity of 91% for fragment fingerprints [41]. The clustering approach shines in these studies, achieving high-accuracy predictions despite the lack of labeled data [39]. It shows a demonstrable advantage over conventional QSAR modeling approaches using supervised models like CNNs. It might also be better than other unsupervised approaches like autoencoders due to their efficiency in capturing complex relationships without encoding or decoding, which might be more relevant to the small-molecule approach [40].

## Section: 2. Methods › 2.3. Structure-Based Approach (SA)

The structure-based approach leverages high-resolution protein structures, allowing scientists to design ligands with exquisite specificity. Recent advancements in ML are further empowering this technique, particularly with regard to challenging targets for which crystal structures are elusive; some of the relevant techniques are mentioned in Figure 4 [42]. Predictions based on previous templates from various databases using homology modeling [43], threading [44], or ab initio [45] prediction of folding confirmations have proved to be intuitive applications for ML in a structure-based approach.

Example of Algorithms and Classifiers in ML Models for Structure-Based Approach Drug Discovery [46].

## Section: 2. Methods › 2.3. Structure-Based Approach (SA) › 2.3.1. SA-Supervised Learning

The ProteinGAN model, trained on a diverse dataset of 16,706 unique sequences of bacterial malate dehydrogenase enzymes, yielded significant predictive outcomes. It achieved a median sequence identity of 61.3% for natural sequences and identified 119 novel structural motifs [47]. Another study used GAN with spectral normalization to achieve tight backbone distribution of the sequences and stability [48]. GANs significantly increased the accuracy of protein folding predictions, helping researchers identify binding pocket more accurately and select suitable ligands for compounds that bind with kinase and dopamine receptors [49].

## Section: 2. Methods › 2.3. Structure-Based Approach (SA) › 2.3.2. SA-Support Vector Machines

The SWISS-MODEL uses multiple sequence alignments, interface geometry, and residue entropy distribution to identify templates that maximize high-quality estimates based on inter-chain contact scores [50]. The model uses Monte Carlo sampling with Pro-Mod3 [51], which employs a library of parameters for energy minimization. Each developed model is scored based on its evolutionary significance [52]. SVMs can find optimal decision boundaries in high-dimensional feature spaces (here, interface conservation and geometric properties), effectively separating suitable templates from unsuitable ones.

## Section: 2. Methods › 2.3. Structure-Based Approach (SA) › 2.3.3. Structure Networks

Sequence alignment Networks have been used to establish evolutionary relationships, and an encoding module is trained based on previous structures to predict contacts in amino acids and, as a result, their folding pattern [53]. These networks are particularly useful here, as they can identify long-range dependencies [54], so they can identify amino acid interactions by using the attention mechanism [55] with local alignments when electron densities and ion spheres are factored into the implementation of these models’ parallel processing. The attention modules showed a Pearson coefficient of 0.78 with precision scores for all targets, demonstrating their relevance to larger and more complex databases without the high data requirements of GANs or feature engineering required by SVMs.

## Section: 2. Methods › 2.3. Structure-Based Approach (SA) › 2.3.4. SA-Unsupervised Learning

Some projects, like Omegafold, which applies PLMs based mostly on unaligned and unlabeled sequences [56], use residue pairs to create embeddings [57]. These embeddings are refined by geometric consistency, mostly to improve distance predictions [58]. One study used the harmonic mean of true positives and recall to observe the class distributions (F1 score) of predictions of molecular function, biological process, and cellular component-specific relation with the sequence using two protein language models: K-sep and SeqVec. Both models performed well in terms of molecular function prediction, with F1 scores of 916 and 914, respectively [59]. This approach is significantly different from that of Alphafold2, where predictions depend less on comparative parameters like evolutionary significance or deviation and more on spontaneous metadata derived directly from the sequence, outperforming Alphafold2 when model training data do not extend beyond the sequence [60].

## Section: 2. Methods › 2.3. Structure-Based Approach (SA) › 2.3.4. SA-Unsupervised Learning

In a novel decoy selection-based clustering model, computer-developed decoys are used to organize decoys and original structures to identify noise. This is implemented using a k-means framework in which decoy region identification receives greater focus than the folding confirmation selection, which makes this type of model very flexible as it can be used as a refinement method for structures predicted by other models [61].

## Section: 2. Methods › 2.4. Examples of ML Affecting Bioinformatics Drug Discovery

ML has significantly advanced the field of bioinformatics, a major facet of bio-nanotechnology involving the interaction of nanomaterials with biological systems comprising DNA, RNA, proteins, and metabolism, by enabling the analysis of complex biological data in previously impossible ways. Some key areas where machine learning has had a substantial impact include the fields of genomics, proteomics, transcriptomics, systems biology, and drug discovery. Some examples of ML’s contributions to bioinformatics are shown in Table 2.

ML algorithms can analyze vast amounts of genomic data to identify patterns and mutations associated with diseases. This helps further our understanding of genetic predispositions and assists with the development personalized medicine [71]. Additionally, ML techniques help us to analyze RNA sequencing data to understand gene expression patterns, which is vital for studying how genes are regulated and how they respond to different conditions [72]. By integrating data from various biological sources, ML aids in complex modeling scenarios.

Traditional methods of protein network analysis can be time-consuming and computationally intensive. ML algorithms can process large datasets more quickly, helping us understand the behavior of biological systems under different conditions [73]. By analyzing protein structures and functions, ML aids in the prediction of protein interactions and functions, which is crucial for drug discovery and understanding cellular processes [74]. This efficiency makes it feasible to analyze complex networks on a larger scale [75]. Further, ML can model the dynamic behavior of protein networks under different conditions, such as changes in the environment or disease states, helping us understand how protein interactions change over time [76]. These advancements have accelerated research and enhanced our understanding of cellular processes, leading to potential breakthroughs in drug discovery and personalized medicine.

ML algorithms have been used to reconstruct metabolic networks by integrating various types of omics data (e.g., genomics, transcriptomics, and proteomics). ML has significantly improved the efficiency of protein network analyses in several ways. First, ML models can predict interactions between proteins by analyzing large datasets of known interactions, aiding in the construction of more accurate and comprehensive protein interaction networks [77]. Second, by analyzing patterns in protein sequences and structures, ML can predict the functions of unknown proteins, aiding in the annotation of protein networks [78]. Additionally, ML algorithms can integrate various types of biological data (e.g., genomic, transcriptomic, and proteomic data) to reconstruct protein interaction networks, providing a more holistic view of cellular processes [79]. Thus, ML models can predict how different compounds will interact with biological targets, speeding up the drug discovery process and reducing costs [80]. These advancements have not only accelerated research but have also opened new avenues for personalized medicine, making treatments more effective and tailored to individual patients.

Despite the progress made in bioinformatics, applying ML to biology comes with several challenges. First and foremost, biological systems are incredibly complex and dynamic [81] making it difficult to create accurate models that can predict biological behavior. Successful ML application requires high-quality, annotated datasets that are essential for training ML models. However, biological data often contain noise, missing values, and inconsistencies, which can hinder a model’s performance. Additionally, the effective application of ML in biology requires expertise in both fields. Bridging the gap between computational scientists and biologists can be challenging due to differences in terminology, methodologies, and objectives [82]. Furthermore, biological datasets can be enormous, requiring significant computational resources for processing and analysis. Ensuring that ML models can handle these large datasets is a major challenge [83]. Another challenge is that many ML models, especially deep learning models, are often seen as “black boxes”. Understanding how these models make predictions is crucial for gaining biological insights and ensuring trust in the results. Finally, handling sensitive biological and medical data raises ethical and privacy issues. Ensuring data security and patient confidentiality is paramount [84]. Despite these challenges, the potential benefits of applying ML to biology are immense, driving ongoing research and innovation in this exciting field.

Examples of ML’s role in drug discovery by increasing the speed and efficacy of bioinformatics.

## Section: 3. Conclusions

The integration of ML into target-based drug discovery represents a monumental leap in the pharmaceutical industry. By enhancing traditional methods such as HTS and VS, ML models have significantly improved the prediction accuracy of binding affinities and selectivity, thereby reducing the need for extensive experimental screening. The application of deep learning techniques, such as CNNs and RNNs, shows great promise in virtual screening, target identification, and de novo drug design. Additionally, fragment-based and structure-based approaches have benefited from ML algorithms that predict fragment properties and binding affinities with remarkable precision.

The advent of GANs and other advanced techniques has further empowered researchers to explore and expand the chemical space, enabling the discovery of novel molecules with desired properties. Despite challenges such as interpretability and data quality, the transformative impact of ML is undeniable, accelerating the drug discovery process and fostering innovation.

Given the widespread use of computational algorithms in predicting experimental protein structures and the increasing reliance on virtual screening for lead selection, it is conceivable that the efficiency of computational methods will eventually rival or surpass traditional experimental methods in terms of resolution and accuracy. This could potentially address the limitations inherent in each of these approaches.

In summary, the application of ML in target-based drug discovery is paving the way for more efficient and effective identification of therapeutic candidates and significantly improves upon methods traditionally established by HTS and VS. As ML models continue to evolve, they have the potential to revolutionize the development of new and improved treatments for various diseases, enhancing patient outcomes and advancing medicine.

## Section: Acknowledgments

Figures in this article were created using BioRender (BioRender.com).

## Section: Abbreviations

AI—Artificial intelligence; CNNs—Convolutional neural networks; DL—Deep learning; FA—Fragment-based approach; GANs—Generative adversarial networks; HTS—High-throughput screening; ML—Machine learning; MCC—Matthews Correlation Coefficient; PLMS—Protein language models; RF—Random Forest; RNNs—Recurrent neural networks; VS—Virtual screening; SMILES—Simplified molecular-input line-entry system; ASCII—Sequences that describe the structure of a compound; SMA—Small molecule-based approach; SA—Structure-based approach; SVMs—Support Vector Machines.

## Section: Author Contributions

Conceptualization, A.Y.P., S.M. and S.S.M.; Writing—Original draft preparation, A.Y.P. and S.M.D.; writing—Review and editing, S.M., W.L., S.S.M. and A.Y.P.; visualization, A.Y.P., S.M., S.S.M. and S.P.; funding acquisition, S.M. and S.S.M. All authors have read and agreed to the published version of the manuscript.

## Section: Data Availability Statement

All other data generated or analyzed during this study are included in this published article.

## Section: Conflicts of Interest

The authors declare no conflict of interest.

## Section: Funding Statement

This research was funded by the US Dept. of Veterans Affairs Research Career Scientist (RCS) awards IK6BX004212 to S.M., and IK6BX006032 to S.S.M. The views expressed in this article are those of the authors and do not necessarily reflect the position or policy of the Department of Veterans Affairs, or the United States government.

## Section: Associated Data › Data Availability Statement

All other data generated or analyzed during this study are included in this published article.


---

# Drug Repositioning via Graph Neural Networks: Identifying Novel JAK2 Inhibitors from FDA-Approved Drugs through Molecular Docking and Biological Validation

- **Authors:** Muhammad Yasir, Jinyoung Park, Eun-Taek Han, Won Sun Park, Jin-Hee Han, Wanjoo Chun
- **Issuer:** Molecules (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2024-03-19
- **Language:** en
- **DOI:** 10.3390/molecules29061363
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38542998/
- **Licence:** CC-BY

## Section: Abstract

The increasing utilization of artificial intelligence algorithms in drug development has proven to be highly efficient and effective. One area where deep learning-based approaches have made significant contributions is in drug repositioning, enabling the identification of new therapeutic applications for existing drugs. In the present study, a trained deep-learning model was employed to screen a library of FDA-approved drugs to discover novel inhibitors targeting JAK2. To accomplish this, reference datasets containing active and decoy compounds specific to JAK2 were obtained from the DUD-E database. RDKit, a cheminformatic toolkit, was utilized to extract molecular features from the compounds. The DeepChem framework’s GraphConvMol, based on graph convolutional network models, was applied to build a predictive model using the DUD-E datasets. Subsequently, the trained deep-learning model was used to predict the JAK2 inhibitory potential of FDA-approved drugs. Based on these predictions, ribociclib, topiroxostat, amodiaquine, and gefitinib were identified as potential JAK2 inhibitors. Notably, several known JAK2 inhibitors demonstrated high potential according to the prediction results, validating the reliability of our prediction model. To further validate these findings and confirm their JAK2 inhibitory activity, molecular docking experiments were conducted using tofacitinib—an FDA-approved drug for JAK2 inhibition. Experimental validation successfully confirmed our computational analysis results by demonstrating that these novel drugs exhibited comparable inhibitory activity against JAK2 compared to tofacitinib. In conclusion, our study highlights how deep learning models can significantly enhance virtual screening efforts in drug discovery by efficiently identifying potential candidates for specific targets such as JAK2. These newly discovered drugs hold promises as novel JAK2 inhibitors deserving further exploration and investigation.

## Section: 1. Introduction

Drug repositioning involves identifying novel therapeutic uses for medications that have previously gained approval for different medical purposes [1]. It can notably accelerate the drug development process, enhance the utility of established drugs, and reveal novel treatments for ailments lacking effective remedies [2]. Accordingly, drug repurposing is becoming an increasingly important area of research in drug development. Computer-aided drug design (CADD) has become an essential tool in the domain of drug discovery and development [3]. Utilizing computational algorithms and software, CADD enables efficient screening of large compound libraries, offering a faster and more cost-effective alternative to traditional experimental approaches [4]. A primary strength of CADD is its capacity to swiftly assess a large number of compounds, minimizing the extensive laboratory testing in traditional experimental studies, which can be time consuming and expensive [5].

Artificial intelligence is rapidly expanding and possesses significant promise in transforming the drug development process [6]. Deep learning (DL), a subset of artificial intelligence, enables its models to assimilate data and formulate predictions or decisions without explicit programming [7]. DL plays a pivotal role in drug development by analyzing vast datasets encompassing genetic and clinical data. This analysis aids in discovering new drug targets, predicting drug effectiveness with accuracy, and fine-tuning drugs [8,9]. One of its primary advantages is the capability to analyze large and complex datasets [10]. Whereas traditional data analysis methods, like manual examination and statistical techniques, can be labor intensive and time consuming, DL models offer swift and adept data analysis, discerning patterns and forecasting outcomes, which in turn fast-tracks the drug development process [11]. An additional strength of DL in drug development is its capability to predict the potency and toxicity of compounds [12]. By analyzing extensive datasets, DL models can discern trends suggesting drug effectiveness and potential toxicity, enabling the prediction of these attributes before the synthesis and laboratory evaluation. Therefore, integrating DL within CADD can markedly improve the speed, efficiency, and success of the drug discovery, making it significant in drug discovery and development.

Janus kinases (JAKs) belong to a family of non-receptor tyrosine kinases crucial for cellular signaling, especially within the immune system [13,14,15]. Disruption in JAK function is associated with various inflammatory disorders, such as rheumatoid arthritis, psoriasis, and inflammatory bowel disease [16,17]. Four main members constitute the JAK family: JAK1, JAK2, JAK3, and TYK2 [18]. Each has unique traits and distinct cellular roles. Specifically, JAK1 is associated with signaling via the interferon-α receptor, while JAK3 primarily operates through the common gamma chain receptor [19,20,21]. JAK2, however, interfaces with a multitude of cytokines, including erythropoietin, thrombopoietin, and interleukin-6 [14,22], positioning it with a more expansive signaling capability compared to JAK1 and JAK3. Notably, JAK2’s involvement has been identified in conditions like polycythemia vera, essential thrombocythemia, and myelofibrosis [23]. While certain JAK1 and JAK3 mutations are reported in acute lymphoblastic leukemia [24], JAK2’s role appears more central in the onset of diverse diseases [25,26,27]. Given this context, our study focuses on the development of novel JAK2 inhibitors. In this study, we employed a graph neural network algorithm to train on datasets containing active and decoy JAK2 inhibitors. Subsequently, we screened an FDA-approved drug library to identify potential JAK2 inhibitors for drug repurposing. We further assessed the selected compounds using molecular docking techniques and their biological activity was validated using a JAK2 kinase assay kit to discover novel JAK2 inhibitors.

## Section: 2. Results and Discussions

The process of integrating deep-learning, molecular docking, and experimental evaluation for drug repurposing of novel JAK2 inhibitors is illustrated in Figure 1. The process comprised seven distinct phases: (1) data acquisition and preparation from the DUD-E database, (2) configuration of the graph convolutional network model, (3) training and evaluation of the deep learning model, (4) predictive assessment of FDA-approved drugs, (5) molecular docking for the top-predicted drugs, (6) experimental validation of potential candidates through JAK2 kinase assay, and (7) analysis of results to confirm the validity of repurposing FDA-approved drugs as novel JAK2 inhibitors.

## Section: 2. Results and Discussions › 2.1. JAK2 Active and Decoy Datasets and Its Preprocessing Using RDKit

The DUD-E (Database of Useful Decoys: Enhanced) database is an open-access database that hosts benchmark sets of protein–ligand complexes. It encompasses a set of experimentally confirmed active compounds, their affinities against diverse targets, and associated decoys that are confirmed not to bind with the target. Though these decoys share similar physicochemical properties with the active compounds, their two-dimensional topology differ [28]. The DUD-E database has frequently served as a benchmark for the creation and evaluation of computational docking techniques [29,30]. The JAK2 dataset in the DUD-E database (https://dude.docking.org/targets/JAK2) (accessed on 15 January 2024) features 107 active compounds, curated from an initial set of 246 compounds, paired with 6500 decoy compounds. Figure 2A provides illustrative images of the structures of both active and decoy compounds, with labels in the legend to distinguish them. To evaluate the physicochemical distinctions between active and decoy compounds, we used RDKit (Version 2023.09.6), a free chemoinformatics software toolkit, to calculate their molecular attributes. Upon comparison, we observed minimal variations in the distribution patterns of molecular features such as weight, LogP, the number of hydrogen bond donors/acceptors, topological polar surface area (TPSA), and number of rotatable bonds (Figure 2B).

## Section: 2. Results and Discussions › 2.2. Deep-Learning Model Setup, Training, and Evaluation

DeepChem is an open-source Python library designed for deep learning applications within drug discovery and cheminformatics. It offers a comprehensive suite of tools for managing molecular data and harnessing various deep learning techniques for tasks like molecular attribute forecasting, virtual ligand screening, and molecule optimization [31,32]. In this research, we employed the GraphConvMol model from DeepChem to discern differences between active and decoy compounds within the JAK2 dataset. This model, an integral part of the DeepChem suite, uses a form of graph convolutional neural network to process molecular graphs, turning them into fixed-size representation vectors. Each atom is denoted as a node, and covalent bonds become edges in this molecular graph. The algorithm involves a series of message-passing phases, during which each atom communicates its unique features to adjacent atoms. After collecting messages from neighboring atoms, the data are synthesized to update the current atom’s attributes. The final representation of the molecule is formulated by combining the individual atom representations and further refining them through feed-forward neural networks. As GraphConvMol facilitates the end-to-end learning of molecular structures, it stands as a robust asset in cheminformatics endeavors, specifically in predicting molecular properties and drug discovery [33,34]. The JAK2 dataset was split into training, validation, and test sets at a ratio of 8:1:1, and then subjected to the GraphConvMol model using cross-validation with a fold of 5. To assess the model’s performance, the AUC (Area Under the Curve) of the ROC (Receiver Operating Characteristic) curve was computed for the training, validation, and test datasets. The ROC curve, generated from a five-fold cross-validation on the training dataset, illustrated a True Positive Rate (TPR) value of 1 at an exceptionally low False Positive Rate (FPR) with an AUC value of 0.992 (Figure 3A). This suggests that the GraphConvMol model exhibits high sensitivity in identifying positive instances while effectively minimizing false positives.

To evaluate the performance of GraphConvMol on DUD-E datasets, metrics such as precision, recall, F1 score, sensitivity, accuracy, and specificity were calculated across training, validation, and test datasets (Table 1). The training dataset showed reliable performances, with only 2 out of 94 positive instances misclassified as negative (recall: 0.98). In the validation dataset, there was one false positive out of 652 negatives (precision: 0.83) and 3 false negatives out of 8 instances (recall: 0.63). The lower performance metrics in the validation dataset may be due to the limited number of active compounds. However, the model demonstrated optimal performance in the test dataset, achieving a score of 1 in all metrics (Table 1).

Due to the disproportionate number of decoys relative to active compounds in the dataset, the Matthews correlation coefficient (MCC) was utilized to assess the performance of the GraphConvMol model. This metric is particularly effective for datasets with such imbalances. The averaged MCC values from five-fold cross-validation processes were 0.96 for the training set and 0.76 for the validation set. A perfect prediction accuracy is indicated by an MCC of 1, highlighting that those scores of 0.96 and 0.76 demonstrate the model’s robustness and dependability. It is generally expected for the MCC value of the test set to surpass that of the validation set since the model, after being trained on the training set, is then tested on the novel and unencountered data of the validation set. Furthermore, the variation in MCC values observed across the five-fold cross-validation suggests that the model is not overly fitted to the training data.

## Section: 2. Results and Discussions › 2.3. Prediction of JAK2 Inhibitory Potential from FDA-Approved Drugs

Repositioning FDA-approved drugs offers distinct advantages. Given that these drugs have already undergone rigorous pre-clinical and clinical evaluations for safety, dosage, and pharmacokinetics, their repositioning often means shorter development periods, reduced costs, and a higher probability of success. The trained model, utilizing the GraphConvMol algorithm from DeepChem, processed SMILES strings of FDA-approved drugs to assess their potential for JAK2 inhibitory activity. Predictions on JAK2 inhibitory capability for these drugs spanned a range from 0 (inactive) to 1 (highly active). While a majority of the compounds were deemed inactive, a small subset was identified as potential actives (Figure 4A). Figure 4B presents structures of select compounds that were predicted to have high activity, with labels showcasing their anticipated values.

Noticeably, several of top-ranked compounds such as ruxolitinib, baricitinib, tofacitinib, and upadacitinib (listed in Table 2) are well-known JAK2 inhibitors. This strongly indicates the high robustness and reliability of the present model. From the set of drugs highly predicted by the GraphConvMol model, we selected several candidates for further evaluation regarding their potential JAK2 inhibitory actions through molecular docking and experimental assessment. Gefitinib, a tyrosine kinase inhibitor used in acute lymphoblastic leukemia [35], ribociclib, a CDK kinase inhibitor employed in the treatment of metastatic breast cancer [36], amodiaquine, an inhibitor of heme polymerase inhibitor used for malaria [37], and topiroxostat, an inhibitor of xanthine oxide used for gout [38], were among the chosen drugs. These drugs have not been previously reported to be associated with JAK2 inhibition.

## Section: 2. Results and Discussions › 2.4. Structural Analysis of the JAK2 Protein

A non-receptor tyrosine kinase JAK2 belongs to the Janus kinase family and has been linked to signaling by the single chain receptors (Epo-R, Tpo-R, GH-R, and PRL-R), the GM-CSF receptor family’s (IL-3R, IL-5R, and GM-CSF-R), and the type II cytokine receptor family’s (interferon receptor) [39]. It was constructed by 311 amino acids forming a single chain (PDBID 3JY9). Loops, α-helices, and β-sheets are present in the overall structure of JAK2 (Figure 4). Furthermore, a VADAR 1.8 structural assessment demonstrated that JAK2 was constructed by 40% α-helices, 22% β-sheets, 37% coils, and 23% turns. Moreover, the Ramachandran plots analysis revealed that 95.1% of amino acids occur in the favored region, while 98.6% of residues were in the allowed zone of dihedral angles phi (φ) and psi (ψ) (Figure 5B).

## Section: 2. Results and Discussions › 2.5. The Binding Pocket Analysis

Along with its structure and position inside a protein, a binding pocket’s function is influenced by the group of amino acid residues that surround it [40]. Using the Discovery Studio ligand interaction method, the binding pocket residues of JAK2 were obtained from the interaction of JAK2 and co-crystalized ligand and mentioned as Leu14, Gly15, Val22, Ala39, Leu142, Glu57, Val70, Met88, Tyr90, Leu91, Gly152, and Asp153. Therefore, the co-crystalized ligand was chosen by the current selection approach to define the CDocker binding sphere. Furthermore, the binding sphere was subjected to contraction to limit it to the accurate position respective to our selected binding pocket residues. The binding sphere values were X = 12, Y = 13, Z = 2.6, and the radius value was fixed as 7.8 to study the interaction of selected compounds in the active region of JAK2 (Figure 6A,B).

## Section: 2. Results and Discussions › 2.6. Molecular Docking Analysis

The top 20 screened compounds were docked against JAK2. The docked complexes were evaluated and examined independently and scored based on the minimal docking energy and interaction energy values. The Discovery Studio CDocker module forecasts two types of energy values (CDocker energy and CDocker interaction energy). The terms CDocker energy and CDocker interaction energy are used to describe the energy involved in the various interactions between the ligand and the receptor. CDocker energy displays the overall docking energy based on the 3D structural and physiochemical features of the ligand and protein, whereas the strength and nature of each individual contact between the ligand and the receptor are revealed by CDocker interaction energy. It calculates how much the overall binding strength is affected by intermolecular forces such Van der Waals forces, electrostatic interactions, and hydrogen bonds [41,42,43]. The top 20 docking results concerning the CDocker interaction energy score were depicted in Table 3. Therefore, ribociclib demonstrate the lowest interaction energy values. Moreover, the gefitinib and amodiaquine came up in the top 10 docked compounds, although they exhibit a high CDocker interaction energy as compared to ribociclib, they exhibit a lower interaction energy than the reference compound tofacitinib (gefitinib, amodiaquine, and tofacitinib manifest −50.6 kcal/mol, −44.4 kcal/mol, and −40.0 kcal/mol, respectively). Topiroxostat comparatively revealed a high interaction energy (−28.8 kcal/mol) compared to the reference compound.

## Section: 2. Results and Discussions › 2.7. Binding Interaction Analysis against JAK2

The top 20 screened compounds that were docked against the JAK2 protein were further analyzed by Discovery studio and UCSF Chimera to examine and confirm the binding interaction of ligands with the active site amino acid residues of JAK2.

Ribociclib compounds, which manifest the lowest interaction energy molecular docking energy, manifest the strongest interaction against JAK2 (Figure 7). The ribociclib-JAK2 docked complex expressed eight hydrogen bonds which include the residues Glu57, Asp153, Glu89, Leu91, Leu14, and Asp98. Two oxygen atoms of ribociclib form hydrogen bonds against Glu57 and Asp153 with a bond length of 2.28 Å and 1.93 Å, respectively. Another two oxygen atoms of ligand exhibit two hydrogen bonds with the same Asp98 with a bonding distance of 2.49 Å and 2.05 Å. Moreover, the other two oxygen atoms also formed two hydrogen bonds with the same Leu14 with a bonding distance of 2.97 Å and 2.71 Å. Another solo oxygen atom of ribociclib revealed a hydrogen bond with Glu89 with a bond length of 2.48 Å. Furthermore, a nitrogen atom of ligand expresses a hydrogen bond against Leu91 with a bonding distance of 2.30 Å.

The ligand–protein docking analysis of Amodiaquine showed that the ligand binds within the active region of the target protein as shown in Figure 7. The Amodiaquine-Jak2 docked complex exhibits three hydrogen bonds and one halogen bond. A halogen bond is formed when there is evidence of a net attractive interaction between an electrophilic region associated with a halogen atom in one chemical entity and a nucleophilic region in another or the same molecular entity [44]. The hydrogen atom of Amodiaquine formed a hydrogen bond with Arg139 with a bonding distance of 2.97 Å. Additionally, two other hydrogen atoms of ligand formed hydrogen bonds with Leu91 and Leu14 with bond lengths of 2.16 Å and 2.03 Å, respectively. Furthermore, the chlorine atom of ligand formed a halogen bond with Phe19 with a bonding distance of 3.17 Å. Topiroxostat was confined in the active binding pocket of the JAK2 protein and formed three hydrogen bonds with active region amino acid residues (Figure 7). The topiroxostat-JAK2 docked complex showed a hydrogen atom of formed hydrogen bonds with Leu91 with a bond length of 2.67 Å. Furthermore, a nitrogen atom of topiroxostat also formed a hydrogen bond with Leu91 with a bond length of 2.42 Å. Moreover, another hydrogen atom of ligand formed a hydrogen bond with Phe19 with a bonding distance of 2.78 Å.

The ligand–protein docking analysis of tofacitinib showed that ligands become docked within the active region of the target protein, as shown in Figure 7. The tofacitinib-JAK2 docked complex forms three hydrogen bonds which include the residues Lue91 and Arg139. The oxygen atom of tofacitinib forms a hydrogen bond against Leu91 with a bond length of 2.64 Å. Furthermore, the nitrogen atom of the ligand also forms a hydrogen bond with Leu91 with a bonding distance of 2.35 Å. Moreover, the oxygen atom of ligand exhibits a hydrogen bond against Arg139 with a bonding distance of 2.78 Å. The gefitinib compound also manifests high interactions following ribociclib. The ribociclib-JAK2 docked complex exhibit six hydrogen bonds (Figure 7). The oxygen atom of ligand formed a hydrogen bond with Asp154 with bond length of 2.12 Å. An oxygen atom of ligand revealed two hydrogen bonds with the same Asp153 with bond length of 2.32 Å and 2.75 Å. Moreover, the other two oxygen atoms of gefitinib showed two hydrogen atoms with the same Leu91 with the bond length of 2.68 Å and 2.33 Å. Furthermore, an oxygen atom of ligand revealed a hydrogen bond against Leu14 with a bonding distance of 2.52 Å.

These interactions strongly suggest that the predicted drugs block the active region of JAK2 by hindering with the active region amino acid residues.

## Section: 2. Results and Discussions › 2.8. Experimental Validation

JAK2 inhibitory activity of highly predicted drugs and tofacitinib, a reference drug, was experimentally evaluated using a JAK2 kinase assay kit. Both tofacitinib and the other drugs exhibited significant inhibition of the JAK2 enzymatic activity at 25 nM. This concentration is consistent with the previously documented IC50 values for the inhibitory activity of tofacitinib against JAK2 [45]. Remarkably, each of the test drugs demonstrated significant JAK2 inhibition, with their effectiveness closely paralleling that of tofacitinib (Figure 8). This suggests that these drugs hold promise as potential novel JAK2 inhibitors.

## Section: 2. Results and Discussions › 2.9. Structural Evaluation and Similarity Comparison

To evaluate the structural similarity among the top-ranked drugs, the Tanimoto similarity measure in RDKit was utilized. Tofacitinib and several top-ranked drugs in JAK2 inhibitory potential prediction exhibit structural characteristics. Each of these drugs incorporates one or more heterocyclic rings along with aromatic moieties (Figure 9). Further, these compounds possess diverse substituents attached to their primary scaffolds, which likely influence their interactions with JAK2 proteins. However, despite these structural motifs, an assessment using the Tanimoto similarity coefficient showed that their overall structural similarity was not notably high (Table 4). In general, while no exact threshold exists for defining similarity, a Tanimoto similarity value below 0.5 is often regarded as indicative of dissimilarity in a range from 0 to 1. On this scale, a value of 0 denotes no similarity at all, and a value of 1 represents complete similarity.

While the top-ranked drugs exhibited limited overall similarity to tofacitinib, it is still possible that these drugs share specific structural features. To explore this, the Maximum Common Substructure (MCS) algorithm in RDKit was applied. Tofacitinib and the four top-ranked drugs were analyzed using the MCS algorithm in RDKit with the threshold of 0.5. This analysis grouped tofacitinib, ribociclib, and gefitinib together, with their common substructures highlighted in red color (Figure 10A). This result implies that factors other than the structural motif, such as the spatial arrangement of specific conformations, might contribute to the inhibitory activity on JAK2 protein. Furthermore, similarity maps using fingerprints in RDKit were employed to illustrate whether the top-ranked drugs possessed the structural motif of tofacitinib (Figure 10B). The similarity maps of the top-ranked drugs revealed the presence of structural motif of tofacitinib in their chemical structures. These findings from the MCS and similarity map findings provide valuable information to guide further optimization of the selected compounds.

The highly predicted compounds, including tofacitinib, ribociclib, topiroxostat, amodiaquine, and gefitinib, are characterized by their LogP, solubility, gastrointestinal (GI) absorption, blood–brain barrier (BBB) permeation, CYP2D6 inhibition, and Lipinski violation (Table 5). Notably, tofacitinib exhibits moderate lipophilicity and solubility with high GI absorption but lacks BBB permeation. Ribociclib and topiroxostat, despite their high GI absorption, demonstrate contrasting BBB permeation abilities, with ribociclib showing the potential inhibition of CYP2D6. Amodiaquine and gefitinib, with high lipophilicity, solubility, and GI absorption, showcase BBB permeation and CYP2D6 inhibition. These data provide a comprehensive overview of the ADME profiles, aiding in the assessment of these compounds’ potential suitability for drug development.

## Section: 3. Methodology › 3.1. JAK2 Datasets and FDA-Approved Drug Library

JAK2 active and decoy datasets were obtained from the DUD-E website (https://dude.docking.org/) (accessed on 15 January 2024). The active dataset contained 107 compounds, while the decoy dataset had 6500 compounds. All molecules were expressed as canonicalized SMILES strings with DUD-E ID and ChEMBL ID numbers. Compounds were labeled as active and decoy in legend. The FDA-approved drug library was downloaded from the website of Selleck Chemicals (https://www.selleckchem.com) (accessed on 16 January 2024). FDA-approved drug molecules, totaling 3105 in number, were represented in SDF (structure-data file) format and transformed into SMILES strings using RDKit.

## Section: 3. Methodology › 3.2. Molecular Descriptor Generation Using RDKit

Molecular descriptors for the compounds were generated using RDKit. RDKit is an open-source, high-performance cheminformatics and machine learning toolkit written in Python (https://www.rdkit.org) (accessed on 20 January 2024). The toolkit offers features for calculating molecular descriptors, producing chemical attributes, and visualizing chemical data.

## Section: 3. Methodology › 3.3. Deep Learning Architecture

The JAK2 active and decoy datasets were split for training, validation, and test sets in 8:1:1 ratio. The GraphConvMol model from DeepChem (https://deepchem.io/models) (accessed on 22 January 2024) was employed as the deep learning algorithm. The GraphConvMol, being a graph convolutional neural network, adeptly processes graph-structured inputs like molecular graphs. A concise overview of its architecture is as follows: Initially, the molecular structures are transformed into graphs where atoms represent nodes and bonds acting as edges. Following this, several graph convolutional layers are employed to derive hierarchical features from these molecular graphs. These layers are equipped with adaptable parameters that have varying weights, fine-tuning the model’s learning to precisely grasp the nuances of molecular structures. During the training phase, the model refines its performance by minimizing a loss function in relation to the input molecular datasets. This optimization adjusts the convolutional layers’ weights through backpropagation. Ultimately, the model seeks to predict specific attributes of molecules, such as solubility, bioactivity, and potential toxicity, grounded on their structures.

## Section: 3. Methodology › 3.4. JAK2 Structure Retrieval

The X-ray structure of human JAK2 protein (PDB ID: 3JY9 with 2.10Å resolution) was obtained from the Protein Data Bank (PDB) (https://www.rcsb.org) (accessed on 25 January 2024), and minimized Discovery studio and UCSF Chimera [46,47]. The JAK2 protein, made up of helices, sheets, coils, and turns, was subjected to further analysis like quantitative protein structural analysis using the online freely accessible server VADAR 1.8 (http://vadar.wishartlab.com/) (accessed on 25 January 2024). Additionally, Discovery Studio was employed to analyze and compute the Ramachandran graphs [46].

## Section: 3. Methodology › 3.5. Prediction of Active Binding Site

The interacting site in the protein’s holo-structure most likely determines the binding pocket of the protein where the active ligand binds [48]. The JAK2 X-ray structure was retrieved from PDB (PDB ID: 3JY9). The co-crystalized ligand was selected and the binding sphere was constructed by the current selection technique in the binding site window of Discovery Studio to define the active pocket. The interacting amino acids were chosen by the ligand interaction approach of Discovery Studio for the accuracy of the binding site generation. Consequently, the binding sphere was contracted to become restricted to our selected amino acids.

## Section: 3. Methodology › 3.6. Molecular Docking

Molecular docking is the most commonly used method for the evaluation of the interactions and conformations of ligands against the target proteins [49]. It anticipates the association strength or binding compatibility between ligand and protein based on preferred orientation by using scoring algorithms [40,50]. The waters and the ligand molecule were removed from the receptor and the hydrogens were added by Discovery Studio’s protein preparation module, prior to docking. The ligand preparations were also carried out for reference and candidate compounds, tautomerization was carried out, ionization was changed, and bad valences were fixed by Discovery Studio’s ligand preparation module. Furthermore, the conformation prediction was to the top 10. Therefore, the Discovery Studio’s CDocker module was employed to perform molecular docking of the screened ligands against JAK2 with the default orientation and conformation. The lowest CDocker interaction energy values (in kcal/mol) were utilized to estimate the best-docked complexes.

## Section: 3. Methodology › 3.7. Binding Interaction Analysis

The 3D graphical evaluations were carried for the docked complexes using UCSF Chimera 1.10.1 [47] and Discovery Studio to study the interactions of screened drugs against JAK2 protein.

## Section: 3. Methodology › 3.8. JAK2 Kinase Inhibitory Activity Assay

Tofacitinib, topiroxostat, and gefitinib were obtained from Sigma (St. Louis, MO, USA), and ribociclib and amodiaquine were obtained from Selleck Chemicals (Houston, TX, USA). The compounds were dissolved in DMSO. JAK2 kinase activity was measured using the JAK2 Assay Kit from BPS Bioscience (#79520, San Diego, CA, USA) following the manufacturer’s instructions. The reactions were incubated at 30 degrees Celsius for 45 min. Then, 50 µL of the Kinase-Glo MAX reagent (Promega, Madison, WI, USA, #V6071) was added and covered the plate with aluminum foil, and incubated at room temperature for 15 min. Finally, luminescence measurements of the ATP product were obtained using a microplate spectrophotometer (Molecular Devices, San Jose, CA, USA). All assays were performed in triplicate.

## Section: 3. Methodology › 3.9. Statistical Analysis

All values shown in the figures were expressed as the mean ± SD obtained from at least three independent experiments. Statistical significance was analyzed by two-tailed Student’s t-test. Data with values of p < 0.05 were considered as statistically significant.

## Section: 4. Conclusions

As the landscape of drug development evolves, becoming more intricate and expensive, it is imperative to leverage cutting-edge techniques that streamline the process. The integration of artificial intelligence into this process offers a fast-track approach to pinpointing potential candidate compounds that might be the next therapeutic breakthroughs. The research outlined in this study underscores the compelling advantages of such a strategy and its efficiency in drug discovery. This study innovates drug discovery by integrating graph convolutional networks (GCN) with molecular docking, surpassing traditional methods. GCN captures complex three-dimensional molecular structures, enhancing predictive accuracy for binding affinities. Combined with molecular docking, it offers a more comprehensive screening, efficiently identifying potential drug candidates. It marks a significant step forward in drug screening, potentially applicable to a wide range of molecular targets. By deploying the graph neural network algorithm within the DeepChem library’s deep learning module, we identified compounds that efficiently fit the active region of the target JAK2, effectively obstructing its active site at a computational level. Several of the top predicted drugs are recognized JAK2 inhibitors, attesting to the solidity of our methodology. Additionally, several compounds, including ribociclib, amodiaquine, topiroxostat, and gefitinib, previously not linked with JAK2 inhibition, exhibited a promising JAK2 inhibitory potential. Experimental validation confirmed the deep learning and molecular docking results. As a result, we propose these compounds as prospective novel JAK2 inhibitors. In conclusion, a deep learning-centric approach to drug repositioning emerges as a pivotal strategy in advancing drug discovery, not just for JAK2 inhibitors but for a broad spectrum of therapeutic targets.

## Section: 5. Limitations

In this study, the datasets were primarily derived from FDA-approved drugs and the DUD-E database. While these sources are valuable, they may not fully represent the extensive diversity of molecular structures, which could impact the generalizability of our model. Consequently, the performance of our model might vary when applied to datasets with different chemical spaces, potentially limiting its broader applicability. Future research directions will focus on incorporating a wider range of chemical libraries to enhance dataset diversity. Additionally, we plan to explore advanced computational algorithms to address potential biases in the data and improve the robustness of our model. These steps are crucial for adapting our methodology to other protein targets and assessing its utility across diverse therapeutic areas.


---

# Eco-Technological Evaluation of Natural Phytochemicals Potential Drug Molecules Against Main Protease: A Machine Learning Algorithm

- **Authors:** Silambarasan Tamil Selvan, Mukesh Kumar Dharmalingam Jothinathan
- **Issuer:** Cureus
- **Type:** Scientific article
- **Published:** 2024-03-28
- **Language:** en
- **DOI:** 10.7759/cureus.57151
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38681365/
- **Licence:** CC-BY

## Section: Abstract

AbstractIntroduction: The global viral pandemic has rapidly spread, leading to many individuals experiencing the infection. Coronaviruses (CoVs) are among many viral families that infect different types of mammals. They can spread to humans and cause gastrointestinal, neurological, and respiratory problems. The present investigation has discovered flavonoid compounds as promising molecular agents with potential antiviral activity against virus proteins, specifically main protease (Mpro).Methodology: A comprehensive in silico screening of natural compounds derived from medicinal plants was performed in the present study. It included parameter assessments such as drug-likeness, pharmacokinetics, molecular docking, toxicity evaluations, bioavailability assessments, and molecular target exploration. In this systematic approach, the primary objective was to identify potential lead compounds. These phytochemicals were investigated as drug candidates to provide a detailed understanding of their molecular properties.Results: The Mpro binding energy values were -10.637, -12.752, -7.813, -15.732, -6.449, -5.578, -8.037, and -8.52 kcal/mol for isoquercetin, narirutin, myricetin, hesperidin, silibinin, baicalein, taxifolin, and petunidin. Molecular simulations were conducted on two flavonoid compounds - hesperidin and narirutin - stable over 100 nanoseconds in the Coronavirus protein.Conclusions: The computational study we conducted is promising, but to validate the action of these compounds, further experimental studies are needed, with a critical component of the research being the conduct of in vitro and in vivo experiments.Keywords: free energy binding, toxicity, density functional theory, molecular simulation, molecular docking, flavonoids, main protease, coronavirus

## Section: Introduction

Coronaviruses (CoVs) are among many viral families that infect different types of mammals. They can spread to humans and cause gastrointestinal, neurological, and respiratory problems. Before this, two pandemic epidemics caused by the Middle East respiratory syndrome CoV (MERS-CoV) and SARS-CoV-2 seriously infected the human population [1]. Similar to SARS-CoV-2, which is currently responsible for deadly viral pneumonia and raising concerns about global health [2,3], the CoV has enormous viral RNA genomes and is characterized by positive-sense, single-stranded RNA viruses. The main protease (Mpro), a widely recognized CoV protein, has been identified as a potential therapeutic target. Mpro plays a crucial role in transcribing viral RNA, leading to the synthesis of polyproteins. Mpro, a widely recognized CoV protein, has been identified as a potential therapeutic target [4,5].

The South Indian medicinal plants contain various potential bioactive compounds, viz., flavonoids, polyphenols, therphiniods, phenolic acids, anthocyanins, and tannins [6-8]. The medicinal plant-derived bioactive compounds have demonstrated various pharmacological and biological activities, including anti-proliferative, anti-inflammatory, anti-atherogenic, anti-allergic, antimicrobial, immunomodulatory, and antiviral properties for human health [9,10]. They are also nontoxic, natural compounds that are friendly to the environment.

This study focused on identifying potential natural bioactive drug molecules from medicinal plant-derived flavonoid compounds. Compounds were used to investigate the suppression of corona viral protease and replication receptors, viz., Mpro protein using molecular docking, silicon toxicity, binding free energy calculations, molecular dynamics simulation, and density functional theory (DFT) analysis. The study opens further avenues for the development of functionally improved drug molecules.

## Section: Materials and methods

Selection of ligand and preparation

The eight flavonoid ligand compounds were selected from various medicinal plants and the flavonoid compounds selected, viz., taxifolin, narirutin, hesperidin, baicalein, isoquercetin, myricetin, petunidin, and silibinin. The compound structures were derived from the PubChem database. The ligands were prepared and screened against the predicted CoV. The Mpro structure used Maestro v11 (Schrödinger, JSS University, Ooty) software. The design was developed with the Schrödinger protein preparation wizard. Protein optimization was performed at a neutral pH, and then the building structure with optimized liquid simulated force field potentials for all atoms was reduced. A 10 x 10 Å to 10 Å receptor grid was generated with Glide v7.1 (Schrödinger, New York, NY) in the Mpro-defined retention site residuals. The ligand was modified for chemical accuracy (protonation), stereochemical variations, ionization, neutral pH 7.0 ± 2.0, and energy using LigPrep modules [11].

Evaluation of silicon toxicity

The Swiss ADME online software was used to analyze the toxicity of the chosen flavonoid compounds, and the cytotoxicity, immunogenicity, hepatotoxicity, mutagenicity, and carcinogenicity toxicity parameters were evaluated. In this study, animal models were analyzed to identify the hazardous dose and reduce the number of models tested on animals [11].

Drug molecules and protein interaction analysis

The Maestro v11 software (Schrödinger, version 11) was used to do a molecular docking study of the active sites of the CoV Mpro protein with ligands. The polar H-atoms and Gasteiger charges were added to the protein amino acid atoms, and the appropriate protonation forms were assigned to the crystal Mpro protein structure. The protein structure's water (H2O) molecules were eliminated, and the protein's ligand and receptor bins (-0.28 to 0.55), outline bins (-0.22 to 0.44), and ligand and receptor sphere (1.3 to 1.55) were fixed. For Mpros, the outside of active sites remained unaltered, while partially active sites were kept flexible for the docking process. The compounds' competency docking score and binding hit were assessed and reported [11,12].

Molecular dynamics (MD) simulations

The Desmond v. 4.2 software program (Schrödinger, JSS University) examined the MD simulation evaluation to confirm prospective flavonoid compounds' ligand-receptor binding energy, interactions, and stability behavior. Explicit MD simulations were analyzed to run 100 ns MD simulations and neutralize water molecules. Ions were chosen to form solvating complexes. Energy minimization and periodic boundary conditions with an acceptable 1,000 kJ/mol/nm value were utilized. The outcomes of MD simulations of protein-ligand complexes were examined and documented [11].

Analysis of DFT

Gaussian 09W software (Schrödinger, JSS University) was used to analyze the interactions between receivers and ligands in electronic structures were examined using DFT. The most occupied homo molecular orbital and the least occupied lowest unoccupied molecular orbital (LUMO), electron affinity, and electrophilicity indicator are the estimated parameters used to describe the electronic and structural characteristics of the five best-hit compounds. According to the study, molecular electrostatic possible surfaces (MEPs) were calculated using population analysis calculations and depicted using Gauss View 5.0. These parameters account for the magnitude of the ligand interactions at the binding site of CoV Mpro [11].

Analysis of binding free energy calculation

In the prime MMGBSA (molecular mechanics with generalized Born and surface area solvation) approach, the free energy binding of the ligand and protein was calculated. This method was used to show and guess the correlated free energy of binding (ΔGbind ) for each group of ligand molecules to the protein. The docking poses were made as small as possible using the OPLS-AA2005 force field, and the Generalized Born/Surface Area (GB/SA) continuum solvent approach was utilized to determine the free energy of binding for the ligands. The MMGBSA model and Surface Generalized Born (SGB) design used Desmond software to perform the simulation analysis [13].

## Section: Results

Selection and preparation of ligands

The eight flavonoid ligand compounds were selected from different medicinal plants. The molecular docking was analyzed for the chosen flavonoid ligands. The selected ligands were obtained in SDF format, and their two-dimensional (2D) structures were generated from the PubChem database. The ligand compound files in SDF format were converted to protein database (PDB) format using Discovery Studio software. The isoquercetin, followed by narirutin and myricetin, effectively interacted with the CoV Mpro protein. The Mpro demonstrated particularly efficient binding to the hesperidin flavonoid, followed by narirutin, isoquercetin, taxifolin, and petunidin.

Evaluation of silicon toxicity

The chosen flavonoid compounds were subjected to analysis using the SWISS-ADME database to enable the prediction of their toxicity. The findings of the absorbent analysis (A), which provided a summary of the ADME prediction, indicated that taxifolin, narirutin, hesperidin, baicalein, isoquercetin, myricetin, petunidin, and silibinin were predicted to exhibit high permeability (Table 1). The expression of low absorption in human intestinal absorption (HIA) value was less than 30%. The results indicated that the human gut's absorption of all flavonoid compounds was extensively investigated. Medications and other chemical substances that entered the body were eliminated by a transmembrane glycoprotein known as P-glycoprotein, which is involved in ATP binding [14,15]. The results of the study indicated that taxifolin, hesperidin, isoquercetin, myricetin, silibinin, and narirutin, which are nonsubstrate inhibitors of P-glycoprotein, exhibited either substrate or inhibitory properties toward P-glycoprotein. In the distribution (D) study, it was expected that the BBB permeability, with a logBBB value greater than 0.3, would have a high capacity to cross the blood-brain barrier [16]. All the flavonoids in this study were predicted to be BBB-permeable. CYP2D6 and CYP3A4 were the two crucial cytochrome P450 (CYP) liver enzyme subtypes in the metabolism (M) study [17]. The results demonstrated that taxifolin, narirutin, hesperidin, isoquercetin, myricetin, petunidin, and flavonoids did not support CYP2D6. Baicalein and silibinin were the only compounds that supported CYP2D6 and CYP3A4. These findings suggested that the liver might metabolize these flavonoids. The hepatocytes' basolateral membranes facilitate the absorption of drugs such as atorvastatin and metformin by using organic cation transporter 1 (OCT1), organic anion-carrying polypeptide 1B1 (OATP1B1), and organic cation transporter 1B3 (OATP1B3).

Molecular docking studies

In the molecular docking experiments, the active residues in the binding cavity of proteins and ligand interactions were investigated for their known binding affinities. By adjusting the grid size to 3 Å, the active residues in the binding pocket of the protein (Mpro) were identified concerning the ligands. The docking score was considered to predict better interactions [18]. The flavonoids are listed in Table 2 based on the docking score. Based on the binding energy, the ranges for the eight individual flavonoids tested against Mpro were -3 to -15 kcal/mol, respectively. Isoquercetin had the highest docking score (-11.68 kcal/mol) against the Mpro complex out of all the examined compounds. Isoquercetin exhibited six bonds, including five hydrogen bonds (THR6854, CYS7007, and SER7074) and one pi-pi stacking (TRP6987) to the active residues (Figure 1; Table 2). Hesperidin (-15.73 kcal/mol) had the highest docking score for the Mpro, followed by narirutin and isoquercetin. Hesperidin and active residues of the major protease were shown to have about five active interactions. The Glu166 residue was a crucial amino acid implicated in the dimerization of Mpro and the development of the substrate binding pocket, and HIS41, GLU166, GLN189, and ARG188 residues were said to operate as active sites for the ligand binding site.

MD simulations

The highest docked complexes (isoquercetin and narirutin) received 100 ns of MD simulations. The findings of the MD simulations demonstrated that the ligand binds steadily to the active site residues Mpro. Figure 2 displays the root-mean-square deviations (RMSDs) of the backbone atoms of the Mpro and associated ligands. The docking experiments based on interactions with residues such as His41, His 164, Glu166, Asp187, Thr190, and Gln192 demonstrated minor RMSD variations in the MD results of Mpro residues. It suggests that both drugs (isoquercetin and narirutin) were closer to the Mpro active site and had a stronger affinity. Similar to this, the MD findings revealed low RMSD variations in Mpro residues in connection with docking residues such as Asn6853, Thr6854, Thr6856, Trp6987, and Cys7007 [19].

Analysis of DFT

The DFT calculations in the gas phase were performed using the B3LYP-311 G (d,p) method. A molecule with a higher HOMO value has a more potent electron donor, whereas one with a lower HOMO value has a weaker electron acceptor. Additionally, intermolecular charge transfer and molecular bioactivity have been significantly impacted by the smaller energy gap between LUMO and HOMO energies. Therefore, a significant energy difference in the hit molecules harms the electron's transition from HOMO to LUMO. It eventually contributes to the Mpro inhibitor's low affinity. The following electronic band gap values were obtained: 0.20525 a.u. for isoquercitrin, 0.13454 a.u. for silibinin, 0.13994 a.u. for baicalein, 0.12717 a.u. for taxifolin, 0.05562 a.u. for petunidin, 0.17683 a.u. for narirutin, 0.1287 a.u. for myricetin, and 0.13768 a.u. for hesperidin (Figure 3). The cloud density of the HOMO and LUMO boundary orbital states was established in the red and green regions, respectively. Recent studies have demonstrated that frontier molecular orbitals must be considered when examining organized activity relations [20].

Analysis of binding free energy (MMPBSA)

The interaction-binding free energy (MMPBSA) between the Mpro protein and flavonoid compounds was calculated using Desmond software. Additionally, per-residue energy decomposition (MMGBSA) was analyzed from the MD simulations. The binding free energy for individual components, namely, H-bond, coulomb, and Van der Waals forces, was calculated using the Desmond software tool (MMPBSA/MMGBSA). Table 3 shows that these values were attributed to energy bonding with flavonoid compounds and CoV proteins. The Gibbs binding free energy for the interaction between flavonoid compounds and Mpro proteins was recorded as -32.13 kcal/mol for narirutin and -36.37 kcal/mol for isoquercetin [21-23].

RMSD, root mean square deviation

## Section: Discussion

The medicinal plant-derived bioactive compounds have demonstrated a variety of pharmacological and biological activities, including antiproliferative, anti-inflammatory, antiatherogenic, antiallergic, antimicrobial, immunomodulatory, and antiviral properties for human health [9,10]. They are also nontoxic, natural compounds that are friendly to the environment. Flavonoid chemicals from medicinal plants have been shown to have antiviral action against the H1N1, Ebola, influenza, and dengue viruses [10]. One of the crucial novel therapeutic strategies for viral infections and an inhibitor of viral proteases is flavonoid chemicals found in natural medicinal plants [11]. The benefits of flavonoids include being active even at low medication concentrations, being highly accessible to nature, being varied, and having no or very few negative effects. The main resource for discovering and developing a large number of new potential antiviral medicines are natural medicinal herbs that modulate flavonoids [12,13]. The group of phenyl benzopyrones, known as flavonoids, has a low molecular weight and many pharmacological effects, such as anti-inflammatory, antiviral, and antioxidant activities [14,15]. Flavonoids inhibit the release of viral particles from being executed, which disrupts viral replication. Their effectiveness in reducing viral amplification in the human body [16,17]. The process of medication excretion is subject to the effect of two key factors, namely, the hydrophilicity and molecular weight of the medicine [24,25].

As reported by Jain et al. [26], 10 natural flavonoid compounds were analyzed for docking scores with the spike protein of SARS-CoV-2 virus, including apigenin at -7.8 kcal/mol, chrysin at −8.1 kcal/mol, fisetin at -8.3 kcal/mol, galangin at -8.2 kcal/mol, hesperetin at -7.7 kcal/mol, luteolin at -8.0 kcal/mol, morin at -8.1 kcal/mol, naringin at -9.8 kcal/mol, quercetin at -8.2 kcal/mol, rutin at- 9.2 kcal/mol, and dexamethasone at -7.9 kcal/mol. Molecular simulation analysis was conducted on 10 flavonoid compounds, and their stability was determined at 0.2 to 0.4 ns.

Imran et al. [27] investigated the flavonoid compounds' activity against SARS-CoV-2 Mpro protein and docking score, namely, -9.9 kcal/mol of amentoflavone, -8.0 kcal/mol of kaempferol, -8.0 kcal/mol of baicalein, -7.6 kcal/mol of catechin, -8.2 kcal/mol of naringin, -7.7 kcal/mol of naringenin, -7.8 kcal/mol of galangin, -8.1 kcal/mol of kuwanon C, -8.0 kcal/mol of morin, -8.3 kcal/mol of morusin, -8.3 kcal/mol of scutellarein, -8.2 kcal/mol of wogonin, -8.3 kcal/mol of apigenin, and -8.0 kcal/mol of fisetin, respectively.

The primary transporters responsible for the elimination of cationic medications into the urine are organic cation transporters (OCTs) and multi-drug- and toxin-extrude proteins (MATEs) [4]. The findings of this study indicate that the flavonoids examined in this study are not expected to hinder the activity of MATE-1, OCT-1, and OCT-2. This suggests that the flavonoids have a safe disposal profile. The findings from the experiment on toxicity (T) indicated that all quinolones have induced ocular corrosion and carcinogenicity. In their study, Imran et al. [26] showed that amentoflavone, kaempferol, baicalein, catechin, naringin, naringenin, galangin, kuwanon C, morin, morusin, scutellarein, wogonin, apigenin, and fisetin flavonoids had good intestinal absorption, with absorption rates between 96% and 98%. The low absorption rate of the molecules is correlated with their high molecular weight. Ninety-seven percent of the high-molecular-weight amentoflavone compound was absorbed in the intestine. According to our test, flavonoids are solubilized in water between -1 and -5, with the aqueous solubility of flavonoids ranging from 3.78 to 2.77, which is moderate to high. Finally, the results of the prediction analysis revealed that the ADMET properties of flavonoids closely resemble those of established anti-CoV and anti-SARS-CoV-2 drugs. It provides evidence to consider the repurposing of specific pharmaceuticals for the therapeutic management of CoV. Flavonoids have been observed to inhibit the function of drug transporters, leading to a decrease in the efficacy of pharmaceutical substances, thereby giving rise to drug-drug interactions that hold therapeutic significance [26,27]. Thus, this study investigated the effects of taxifolin, narirutin, hesperidin, baicalein, isoquercetin, myricetin, petunidin, and silibinin. The outcome demonstrated that all the chosen flavonoids seemed to be OATP1B1-OATP1B3 inhibitors.

According to Imran et al. [26], Mpro complexes with Amentoflavone and morusin were simulated for 100 ns with the stability and fluctuation of the receptor-ligand complexes analyzed during simulations, and a backbone RMSD was used to calculate the resulting trajectory. Throughout the entire simulation, the protein-ligand complex remained stable. During the first 10 ns, a few fluctuations in protein were seen, but then it remained stable for 90 ns. Between Thr24 and Leu50, Asn142 and Cys145, His163 and Thr169, and Val186 to Gln192, 27 ligand contacts were observed with residues in proteins. In addition to hydrogen bonds, these residues also formed ionic bonds, hydrogen bonds, hydrophobic bonds, and water bridges. The active residues of ligands are in hydrophobic interaction with the polar-forming ligands, resulting in ligand stability.

Limitations and future recommendations

This study marks a promising start for developing plant-based antiviral compounds; however, inherent limitations must be acknowledged. A predictive model and a computational analysis were used to obtain the results of our study. Consequently, experimental validation is crucial since it provides concrete evidence of a compound's safety and effectiveness.

## Section: Conclusions

The COVID-19 Mpro complex proteins were docked with eight compounds. Mpro showed high docking scores on hesperidin, narirutin, and isoquercetin. This study evaluated essential antiviral action from plant-mediated flavonoid compounds. These flavonoids could be used as antiviral medications to control the CoV. As a result, plant flavonoid derivatives may shortly produce a fresh development in synthesizing natural drugs and various biological applications

## Section: Acknowledgments

The authors would like to thank the Centre for Global Health Research, Saveetha Medical College and Hospitals, Saveetha Institute of Medical and Technical Sciences (SIMATS), Saveetha University, Chennai, Tamil Nadu, India.


---

# Edridge Green Lecture 2022-demystifying clinical trials and regulatory approvals in drug development

- **Authors:** Victor Chong
- **Issuer:** Eye (London, England)
- **Type:** Scientific article
- **Published:** 2024-12-05
- **Language:** en
- **DOI:** 10.1038/s41433-024-03520-4
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39639153/
- **Licence:** CC-BY

## Section: Abstract

AbstractThis article provides a comprehensive overview of clinical trial design and regulatory pathways essential for drug development, specifically in the context of retinal diseases. Key concepts include trial structure, efficacy and safety endpoints, and regulatory expectations from agencies like the FDA. It delves into recent regulatory advancements, such as the inclusion of low-luminance vision as a secondary endpoint and analyses case studies from age-related macular degeneration (AMD) trials. Approvals for key retinal drugs, such as ranibizumab and aflibercept, treatments for AMD and diabetic macular oedema, are discussed highlighting criteria like the 15-letter gain/loss in visual acuity as approvable/clinical meaningful efficacy endpoints. Insights into geographic atrophy (GA) and diabetic retinopathy trials showcase the evolving landscape, where anatomical endpoints and new drugs bring fresh challenges and opportunities. It also emphasizes the importance of academic-industry collaboration, citing instances of gene therapy development and innovative endpoint measures like the Multi-Luminance Mobility Test for retinal dystrophies. The overarching aim of this lecture was to demystify the process that spans the design of clinical trials to regulatory approval of drugs so that clinicians understand these complexities. In particular, it is important to understand the reasons behind selection of trial design, inclusion and exclusion criteria, primary and secondary efficacy endpoints and safety endpoints. Since this lecture, there have been important changes in this field including new guidance from the Food and Drug Administration (FDA) as well as lessons learnt from recent drug approvals that are included in this manuscript.Subject terms: Predictive markers, Outcomes research

## Section: Understanding the rules of engagement with the FDA and similar regulatory agencies

For a drug to be approved by the FDA or other regulatory agencies, the pivotal study must define a primary efficacy endpoint which shows a clinically meaningful benefit in a well-controlled study with adequate statistical power. In a common disease, two parallel studies are planned, which are usually similar in design. The primary endpoints and/ or the comparator used in the trials can be slightly different but to gain approval, the results from both studies need to be positive.

## Section: Wet AMD trials

In retina, only a handful of endpoints have been used for drug approval [1]. The most commonly used is the change of best corrected visual acuity (BCVA). It can be the proportion of patients with a 15-letter gain or prevention of a 15-letter loss in the treated group vs the control group. For instance, ranibizumab was approved for neovascular age-related macular degeneration (nAMD) based on the proportion of eyes that lost less than 15 letters. In the ranibizumab group, 91–98%, met this endpoint compared with 60–66% of the control group over 12 months [2].

For diabetic macular oedema (DMO), the endpoint was the proportion of eyes that gained 15 letters. For the ranibizumab arms, 34–45% achieved this endpoint as compared to 12–18% in the control groups over 2 years [3]. The reason that 15 letters was chosen is that this change is considered clinically meaningful and also not likely to occur due to measuring errors. A study in Moorfields showed that a patient can have a six to seven letters difference in BCVA ETDRS score on the same day by different certified visual acuity assessors [4]. This should not be confused with the often-reported mean visual gains of about 10 letters improvement in patients treated with anti-VEGF in wet AMD and more often in DMO patients. These are easier to understand but were not used as approvable primary endpoints until recently. The aflibercept approval for DMO was based on non-inferiority of the proportion of eyes that did not lose more than 15 letters compared to ranibizumab, which was achieved by about 95% in both aflibercept and ranibizumab groups [5].

The concept of non-inferiority for comparing treatment with different anti-VEGF agents for wet AMD using mean BCVA changes from baseline was probably first introduced in the CATT study [6] and also adopted in the IVAN study [7]. The statistical concept of non-inferiority came from the generic and biosimilar world where equivalence has to be proven to the originator drug. It is beyond the scope of this paper to discuss the principle in detail, but non-inferiority using mean change from baseline in BCVA letter score has only been used in the most recent approvals, of brolucizumab, faricimab and aflibercept high dose. In a recent FDA draft guidance on neovascular AMD development, a 4.5 letter margin was set against on label ranibizumab or aflibercept [8].

It is important to understand that if superiority study design is to be used in the future, it might be insufficient to show statistical significance of superiority alone, there is also a need for the change to be clinical meaningful. For the FDA, that would be 15 letters of BCVA. In other words, if “mean change from baseline” is used, the study drug has to be 15 letters superior to the comparator. The alternative would be to have a statistically significant proportion of patients with 15 letters loss or gain. In wet AMD, if the new drug is to be compared with the current standard of care (aflibercept 2 mg being the most common anti-VEGF comparator), it would be challenging for many patients to have 15 letters loss on aflibercept 2 mg, so it would be likely that the sponsor (drug company) would go for an endpoint of 15 letter gain. However, to achieve 15 letters gain, further considerations need to incorporated to the eligibility criteria. For example, it would be challenging to achieve 15-letter gain if the baseline vision is good, so the inclusion criteria need to be restricted to only allowing patients with poorer baseline vision that have a better chance to obtain a 15-letter gain. Nonetheless, there are caveats in this assumption as patients with poorer baseline vision might also have irreversible structural changes such as fibrosis that would not permit a gain in BCVA.

However, the FDA has clarified that the new drugs do not need to be compared against the standard of care. In fact, a new drug could be compared to no treatment, sham or a much lower dose of the new drug (which is practically non-effective). In wet AMD, that would be difficult as vision loss is rapid and probably not reversible after a period of no treatment. Furthermore, the study period for wet AMD for approval is usually at least 9 months, so abstaining from treatment in this potentially blinding condition would raise ethical issues in conducting such a study. There are ways to get around this, by adding rescue therapy. Rescue therapy means if the patient has lost significant amounts of vision, the investigator can then treat the patient with standard of care (an approved anti-VEGF agent). However, this leads to variations, as the amount of vision loss that is acceptable to one investigator could be very different from another. In addition, if the primary endpoint is the proportion of patients with 15 letters loss, then the data could be messy when different investigators apply rescue treatment to patients at varying levels of vision loss before a 15-letter loss occurs.

It is also acceptable for BCVA to be measured in different light conditions. Recently, low luminance VA (LLVA) has been studied and considered at least as a secondary endpoint. LLVA is the BCVA after refraction with a 2+ neutral density filter placed in front of the patient’s eye. In general, LLVA is lower than BCVA, and the difference between BCVA and LLVA is called the low luminance deficit (LLD). The importance of LLD is not clear but there are some data to suggest that it has a potential in the prediction of treatment outcomes [9]. Therefore, if a drug developer believes that their drug can improve LLVA without improving BCVA, the FDA appears to be willing to accept that as the primary efficacy endpoint, providing the difference in outcome between the trial arms is 15 or more letters.

In addition to efficacy requirements, the FDA has also provided safety guidance for wet AMD trials. This being that at least 300 patients with safety data should have been treated to the primary endpoint (usually more than 9 months) at the intended marketed dose or higher. This means that the sample size needs to consider drop-outs to obtain a final sample of at least 300. This safety data does not include patients who were treated with a lower dose in the study. In addition, there should be “enough” patients treated for 2 years, the exact number is not given. This explains why there are parallel Phase 3 clinical trials on an intervention that report primary outcomes at 9–12 months. At least one of these two studies has to continue for 2 years and have a final sample size of 300 patients. This guidance is limited to small molecules and biologics. The rules for gene therapy are also different, and the duration of safety data collection is likely to be much longer.

## Section: Geographic atrophy

In 2022, at the time of this lecture, two anti-complement trials were undergoing regulatory approval [10]. At that time, the FDA had agreed in principle to the use of differences in the slope of the mean rate of GA lesion growth as an approved endpoint. At the time of writing this manuscript in September 2024, anti-C3 had been approved by the FDA, but not by the European Medicines Agency (EMA). It is also interesting that both anti-C3 and anti-C5 were given a label of ‘geographic atrophy’ despite the anti-C3 trials including both foveal and non-foveal involving lesions whilst in the anti-C5 trials, only non-foveal involving lesions were included. This has significant implications for future GA study designs. Foveal involving lesions have less opportunity for visual change, so only including non-foveal lesions in a study means a better chance of showing functional / vision benefit (i.e. less visual loss over time). Based on the anti-C3 trials, the treatment benefit of anti-C3 appears to be higher in non-foveal involving lesions, partly explained by the slower growth rate of foveal involving lesions.

In drug development, being the first in class and particularly the first ever treatment for a condition, is very challenging. However, compounds that are considered to be followers have the advantage of learning from the lead molecule. It is not uncommon that the third molecule in the class ends up being the market leader, an example being aflibercept, the third anti-VEGF approved for retinal vascular diseases.

## Section: Diabetic retinopathy

Diabetic retinopathy (DR) is another retinal condition with an FDA-approved anatomical endpoint. The diabetic retinopathy severity scale (DRSS) score [11] was used for approval of intravitreal (IVT) anti-VEGF injections for the treatment of DR by the FDA. The proportion of eyes with a 2 or more step improvement of DRSS score was used for the approval of ranibizumab [12] and aflibercept [13]. It was somewhat surprising that faricimab did not receive approval for DR based on their DMO study. One interpretation is that there is no agreed non-inferiority margin accepted by the FDA for DRSS, and faricimab did not show superiority to a control group but rather showed similarity to aflibercept in their pivotal DMO studies [14]. Similarity does not equate to non-inferiority. Recently, a company suggested that for an oral compound, a person level (combining the scoring of 2 eyes) 3 step DRSS score deterioration can also be accepted by FDA. This unsurprising as this was already used by an oral Protein Kinase C inhibitor (ruboxistaurin) some years ago [15]. Currently, anti-VEGF agents are not approved for DR in Europe other than ranibizumab for proliferative diabetic retinopathy (PDR). The exact reason for this decision is not clear. The PDR approval might have been based on data from DRCR.net Protocol S [16], which showed some improvement of visual function. For DR in general, regulatory authorities in Europe might be looking for different endpoints rather than a 2 steps DRSS improvement.

Returning to the discussion on study design, although ranibizumab and aflibercept are approved for diabetic retinopathy in the US, for a new drug, the sponsor can conduct a superiority study against no treatment or sham treatment or placebo. This is more acceptable to the community as despite ranibizumab and aflibercept being approved for this condition, in real-life, their use for this indication is low. Therefore, the standard of care for this condition is still observation despite the approval of these anti-VEGF agents. It would not be an issue in countries that have not approved their use for diabetic retinopathy.

It is also important to understand that the new drug does not need to be better than historic efficacy data of ranibizumab or aflibercept. It has to be statistically significantly and clinical meaningfully better than the comparator (sham treatment or placebo). Clinically meaningful has been established by ranibizumab and aflibercept but the definition of the minimum level of efficacy based on DRSS score that would be acceptable is unclear.

Other considerations such as the invasiveness of the treatment or the adverse event rate of the treatment may also need to be taken into account. For instance, gene therapy given through one single suprachoroidal injection might be different from another intravitreal drug given every 8 weeks. Similarly, oral therapy may have different endpoints. Although oral compounds might appear attractive to ophthalmologists, effective oral compounds often have significant risks of systemic adverse events. Finally, the convenience of oral treatment for patients also needs to be compared to repeated intravitreal injections, which although relatively safe, have a large treatment burden for both patients and the health care system. Topical therapy such as eyedrops could potentially provide a good solution and ophthalmologists look forward to such advancements in retinal diseases.

## Section: Masking to eliminate bias

It is common practice in almost all clinical trials for oral or topical treatments to use a placebo. However, for intravitreal development, it is considered unethical to perform an intravitreal injection with a placebo or saline. Recently, the FDA stated [17] that an intravitreal sham injection is not generally considered good enough for masking as the agency believes patients can tell the difference between an intravitreal injection and a sham injection. The exact reason for this decision is unknown as intravitreal sham injections have been standard for most intravitreal retinal drug approval studies including the most recent approvals of faricimab and high-dose aflibercept 8 mg. It is probably true that patients might have some visual disturbance when the drug is injected into the eye.

In subretinal gene therapy, there is no masking as it is unethical to perform surgery without injecting the gene. Similarly, when injecting intravitreal small molecules within bioerodible or bioresorbable implants, the patients can potentially see the implant or experience floaters. It is challenging to understand the issue of masking in these cases. It will be interesting to see how regulatory agencies handle these approvals when the time comes.

## Section: Uveitis

The approval of intravitreal dexamethasone implants for uveitis was based on the percent of patients reaching a vitreous haze score of 0 (i.e. no inflammation) [18]. At week 8 this was 47% vs 12% in the control group. In addition, the percentage of patients achieving a BCVA improvement of 15 letters from baseline was 43% vs 7% in the control group. The FDA, in general, accepts 2 steps reduction of vitreous haze score, so theoretically from score 3 to score 1. However, it might be difficult to recruit a lot of patients with vitreous haze score more than grade 2. In recent communication, the FDA was willing to accept patients achieving a reduction of vitreous haze score to 0, if all included patients have a vitreous haze score of at least 1.5. The study endpoint is week 8 but addition safety data is likely to be needed.

## Section: MacTel and EZ loss

Using anatomical endpoints for drug approval is gaining more traction. Encapsulated cell therapy producing CNTF implant (NT-501), in two Phase 3 studies, has demonstrated the rate of change of ellipsoid zone (EZ) loss as the primary endpoint in macular telangiectasia (MacTel) Type 2 [19]. At the time of writing, it is not yet approved by the FDA. Nonetheless, if it were to be approved, this would mean another anatomical endpoint could potentially be used for other retinal diseases when the central vision or BCVA might not be affected until late in the disease process. There is a suggestion that EZ loss might be acceptable for intermediate AMD.

In addition, the FDA had suggested that the onset of nAMD or GA can be potentially used as an approvable endpoint, but so far this approach has yet to be tried. The main reason is probably the relatively low event rate. On average, the conversion to nAMD of the fellow eye of patients with unilateral nAMD is about 10% per year [20]. The rate of conversion to GA is even lower. Nonetheless, using OCT and AI, we might be able to improve the prediction. However, if the accuracy of prediction is improved, it remains to be seen whether eyes with high conversion rates are eyes that might be too advanced for treatment or too rare to find. For instance, Lad and colleagues [21], identified one subgroup of GA with a 75% risk of converting to GA in 1 year but this group comprises only 1% of the study population. When we consider that this study used images from participants in the AREDS2 study [22], which only included patients with large drusen and/or pigmentary changes, the proportion of these patients in the whole population with intermediate AMD population is likely to be even lower.

## Section: Collaboration between academia and industry is critical

Lastly, collaboration between academia and industry is important to take novel interventions through the approval process to translation to clinical practice. As an example, Nightstar was born out of academics and was bought by Biogen for 810 million US dollars. It was a time of triumph, however, both programs subsequently failed the pivotal study despite showing positive trends on secondary endpoints. This resulted in Biogen deprioritising Ophthalmology and the development of those assets were terminated [23]. So why would a promising research project such as this fail to get to patients?

The first gene therapy in the history of the FDA was for a retinal inherited disease (RPE65 mutation). The approval of this gene therapy for RPE65 mutation-associated retinal dystrophy was based on the multi-luminance mobility testing (MLMT) score change from baseline to year 1 as an endpoint [24]. The MLMT [25] was designed to measure changes in functional vision, as assessed by the ability of a subject to navigate a course accurately and at a reasonable pace at different levels of environmental illumination. The MLMT was assessed using both eyes and each eye separately at one or more of seven levels of illumination, ranging from 400 lux (corresponding to a brightly lit office) to 1 lux (corresponding to a moonless summer night). Each light level was assigned a score code ranging from 0 to 6. A higher score indicated that a subject was able to pass the MLMT at a lower light level. A score of −1 was assigned to subjects who could not pass MLMT at a light level of 400 lux. The MLMT of each subject was videotaped and assessed by independent graders. The MLMT score was determined by the lowest light level at which the subject was able to pass the MLMT. The MLMT score change was defined as the difference between the score at baseline and the score at Year 1. A positive MLMT score change from baseline to Year 1 visit indicated that the subject was able to complete the MLMT at a lower light level [26]. This is a combination of assessing improvements in visual acuity and visual field in different light intensity allowing a clinically meaningful benefit to be demonstrated in a controlled but pseudo-real-life activity.

However, in the Biogen/Nightstar study, the retinal sensitivity improvement using microperimetry was chosen as the primary efficacy endpoint, which is much more difficult to demonstrate, in particular, the level of gain needed by the agency (7 dB on average and in at least pre-defined 5 points). It is therefore important to understand both the regulatory requirements as well as the ability to achieve a primary endpoint within the time frame of the study period (which is usually one or 2 years).

Functional endpoints are often difficult to demonstrate, particularly in patients with highly variable vision and/or using a test such as microperimetry, which are challenging to perform consistently.

## Section: Acknowledgements

My mentors, Prof Alan Bird, Prof Phil Luthert, and Prof Sue Lightman in Moorfields and UCL; Prof Ed Stone in Iowa city; Prof Greg Hageman in Iowa City and Salt Lake City; Liz Pearce, my wife.

## Section: Author contributions

VC conceived, designed and wrote the manuscript.

## Section: Competing interests

Johnson and Johnson Stock Options Holder. Clearside Biomedical, employee, stock owner and stock option holder.


---

# Elucidating the role of artificial intelligence in drug development from the perspective of drug-target interactions

- **Authors:** Boyang Wang, Tingyu Zhang, Qingyuan Liu, Chayanis Sutcharitchan, Ziyi Zhou, Dingfan Zhang, Shao Li
- **Issuer:** Journal of pharmaceutical analysis
- **Type:** Scientific article
- **Published:** 2024-11-14
- **Language:** en
- **DOI:** 10.1016/j.jpha.2024.101144
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40099205/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Drug development remains a critical issue in the field of biomedicine. With the rapid advancement of information technologies such as artificial intelligence (AI) and the advent of the big data era, AI-assisted drug development has become a new trend, particularly in predicting drug-target associations. To address the challenge of drug-target prediction, AI-driven models have emerged as powerful tools, offering innovative solutions by effectively extracting features from complex biological data, accurately modeling molecular interactions, and precisely predicting potential drug-target outcomes. Traditional machine learning (ML), network-based, and advanced deep learning architectures such as convolutional neural networks (CNNs), graph convolutional networks (GCNs), and transformers play a pivotal role. This review systematically compiles and evaluates AI algorithms for drug- and drug combination-target predictions, highlighting their theoretical frameworks, strengths, and limitations. CNNs effectively identify spatial patterns and molecular features critical for drug-target interactions. GCNs provide deep insights into molecular interactions via relational data, whereas transformers increase prediction accuracy by capturing complex dependencies within biological sequences. Network-based models offer a systematic perspective by integrating diverse data sources, and traditional ML efficiently handles large datasets to improve overall predictive accuracy. Collectively, these AI-driven methods are transforming drug-target predictions and advancing the development of personalized therapy. This review summarizes the application of AI in drug development, particularly in drug-target prediction, and offers recommendations on models and algorithms for researchers engaged in biomedical research. It also provides typical cases to better illustrate how AI can further accelerate development in the fields of biomedicine and drug discovery.

## Section: Introduction

The drug development process is a complex and multifaceted journey that spans several stages, including discovery, preclinical testing, clinical trials, and regulatory approval [1,2]. This endeavor, characterized by high costs and a significant time investment, is driven by the urgent need to address a myriad of diseases and health conditions [[3], [4], [5]]. Despite advances in technology and a greater understanding of biological systems, the success rate of bringing a new drug to market remains low, with only a small fraction of compounds progressing through the entire pipeline. In recent years, there has been a surge of innovative approaches, such as high-throughput screening, computational drug design, and the integration of artificial intelligence (AI), which have the potential to revolutionize the landscape of drug development. However, the industry still faces considerable challenges, including high attrition rates in clinical trials, regulatory hurdles, and the need for substantial financial resources. Addressing these challenges is crucial for accelerating the development of effective and safe therapeutics, ultimately improving global health outcomes.

In recent years, AI has emerged as a transformative force in biomedical research, particularly in drug development, which has historically faced significant challenges in both efficiency and effectiveness. Traditional drug discovery methods, such as high-throughput screening and the one-drug-one-target paradigm, often struggle with the complexity of biological systems and the multifactorial nature of diseases. These methods are time-consuming, costly, and frequently result in high attrition rates during clinical trials, highlighting a critical need for more innovative approaches. The introduction of AI offers a compelling solution to these challenges by providing powerful algorithms capable of analyzing and interpreting complex biological data with unprecedented speed and accuracy [[6], [7], [8]]. The capacity of AI to process vast amounts of information has opened new avenues for understanding intricate biological processes and disease mechanisms, providing insights that were previously unattainable [[9], [10], [11]]. By leveraging machine learning (ML) and deep learning techniques, AI can identify patterns and relationships within large datasets, predict potential drug-target interactions, and optimize drug design, thus significantly reducing the time and cost associated with traditional drug discovery [12,13]. This ability to process vast amounts of information has rapidly and accurately provided new approaches for understanding intricate biological processes and disease mechanisms [14,15]. This technological advancement is not just an improvement but represents a paradigm shift in how we approach drug development. Simultaneously, network pharmacology has gained prominence as a complementary approach to AI in drug discovery. Network pharmacology focuses on the complex interactions within biological networks and offers a holistic framework for studying the interconnectedness between genes, proteins, and metabolic pathways [[16], [17], [18]]. This approach emphasizes the importance of systems-level insights, which are critical for understanding complex diseases and developing multitargeted therapies. By integrating AI and network pharmacology, researchers can overcome traditional barriers, generate comprehensive models of biological systems, uncover novel biomarkers, and gain deeper insights into the molecular underpinnings of health and disease. This integration not only represents a significant shift toward a more interconnected and predictive understanding of biology but also lays the groundwork for future scientific breakthroughs, potentially transforming the landscape of drug development.

The integration of AI and network pharmacology into drug development is transforming the landscape of therapeutic discovery and design [[19], [20], [21]]. AI-driven tools are being utilized to streamline various stages of drug development, from the identification of novel drug targets to the optimization of lead compounds [[22], [23], [24]]. ML and deep learning algorithms can sift through extensive biological data to predict potential drug candidates and their interactions with biological targets, significantly reducing the time and cost associated with traditional drug discovery methods [2,25,26]. On the other hand, network pharmacology [[27], [28], [29]] offers a systems-level perspective by mapping out the complex interactions within biological networks, enabling researchers to identify multitarget strategies and potential side effects early in the development process. This holistic approach is particularly valuable in addressing multifactorial diseases such as cancer and neurodegenerative disorders, where traditional single-target therapies often fall short. By leveraging the predictive power of AI and providing comprehensive insights into network pharmacology, researchers can develop more effective and safer drugs, ultimately accelerating the transition from bench to bedside. The synergy of these technologies holds great promise for the future of personalized medicine, offering tailored therapeutic solutions on the basis of the intricate biological profiles of individual patients.

A key application of AI and network pharmacology in drug development is the prediction of drug-target interactions [19,30,31], which is crucial for identifying potential therapeutic targets and understanding drug mechanisms. AI algorithms, particularly deep learning and ML models, can analyze large-scale biological and chemical data to predict which molecules are likely to interact with specific targets. This capability accelerates the identification of promising drug candidates and reduces the reliance on traditional high-throughput screening methods, which are often time-consuming and costly. Network pharmacology complements this approach by providing a comprehensive view of the biological networks involved in disease processes, highlighting potential multitarget interactions and off-target effects [32,33]. By integrating AI’s predictive power with the systems-level insights of network pharmacology, researchers can more accurately pinpoint viable drug targets and anticipate possible side effects, addressing the longstanding challenges of inefficiency and unpredictability in drug development. This synergy not only enhances the efficiency of the drug discovery process by reducing time and cost but also presents new strategies for tackling complex diseases through multi-targeted strategies. Ultimately, this integration contributes to the development of more effective, safer, and personalized medical treatments, representing a crucial advancement in the pursuit of precision medicine.

## Section: Association-based drug target prediction

Association-based drug target prediction plays a pivotal role in AI-driven drug development [34]. By leveraging advanced ML algorithms and large-scale biological data, this approach identifies potential drug targets through the analysis of complex biological networks and associations between drugs, targets, and diseases (Fig. 1). This method enhances our understanding of drug mechanisms and facilitates the discovery of novel therapeutic targets. In the realm of AI drug development, association-based predictions provide a robust framework for identifying key interactions, streamlining the drug discovery process, and ultimately contributing to the development of more effective and targeted therapies.Fig. 1End-to-end prediction and application in artificial intelligence (AI)-assisted drug development, guiding drug target discovery, drug-disease relationship prediction, drug repurposing, and drug optimization. 1D: one-dimensional; SMILES: simplified molecular input line entry system; ML: machine learning; CNN: convolutional neural network; GNN: graph neural network; Add: addition; Norm: normalization.Fig. 1

End-to-end prediction and application in artificial intelligence (AI)-assisted drug development, guiding drug target discovery, drug-disease relationship prediction, drug repurposing, and drug optimization. 1D: one-dimensional; SMILES: simplified molecular input line entry system; ML: machine learning; CNN: convolutional neural network; GNN: graph neural network; Add: addition; Norm: normalization.

Studies for drug-target prediction.

## Section: Association-based drug target prediction › Biological network-based association algorithms for drug target prediction

Network pharmacology aims to elucidate the mechanisms of drugs and their complex combinations by leveraging biological networks from the perspectives of systems biology and systems medicine. Network target [[6], [7], [8]] is a theory originating from network pharmacology and has been widely used in traditional Chinese medicine (TCM) research [20,35]. Algorithms based on network pharmacology have inherent advantages in solving zero-sample and few-sample problems by utilizing network information such as biomolecular networks (Table 1) [36–41]. In the early stage of “network target”, methods composed of statistics and similarities in features made great improvements in the prediction of disease‒gene associations and drug-target associations. As a pioneering algorithm in “network target”, the correlating protein interaction network and phenotype network to predict disease genes (CIPHER) [36] has achieved great performance in few-shot or zero-shot gene-phenotype predictions. The core idea of this algorithm is to take already known phenotype-phenotype networks, phenotype-gene networks, and protein-protein networks as inputs, use a regression model to construct associations at both the macro- and micro-levels, and establish similarity associations between query phenotypes, reference phenotypes, and genes via known associations as bridges. This method is particularly advantageous for predicting genetically uncharacterized phenotypes. On the basis of CIPHER, CIPHER-like algorithms in different research areas have been gradually developed. For drug‒gene association prediction, DrugCIPHER [37] takes already known drug-drug networks, drug‒gene networks, and protein-protein networks as inputs and was proposed to construct unknown associations between compounds and genes via a regression model, thereby enabling high-precision prediction of drug targets across the entire genome.Table 1Studies for drug-target prediction.Table 1TypeModelNameInputRefs.Association-basedNetwork-basedCIPHERPhenotype-phenotype, phenotype-gene, and protein-protein networks[36]DrugCIPHERDrug-drug, drug-target, and protein-protein networks[37]–Drug-target, disease-gene, and protein-protein networks[38]–Drug-target, protein-protein networks, and gene expression data[39]DREAMwalkDrug-gene-disease network[40]DTINetDrug-related network[41]CNN and GCN-basedDLEPSGene expression profile and compound structure[42]DEEPScreenCompound structure image[43]3D-KINEssenceProtein 3D-structure and compound descriptor[44]GCN-DTIDrug-target network[45]GADTIDrug-target network[46]DrugAICompound structure, compound-target network, and protein sequence[47]GLIMTissue-cell-molecule network[48]Transformer-basedMolTransDrug descriptor and protein sequence[49]MRBDTADrug descriptor and protein sequence[50]MDCT-DTAProtein sequence and compound graph structure[51]TDGraphDTAProtein sequence and compound graph structure[52]BERT-GCNDrug descriptor, protein sequence, and drug-target network[53]GeneformerSingle-cell transcriptomes[54]Molecular collision-basedML-based–Protein 3D-structure and compound descriptor[[55], [56], [57]]CNN-basedDeepBindBCProtein 3D-structure and compound descriptor[58]–Protein 3D-structure and compound descriptor[59]KDEEPProtein 3D-structure and compound 3D-structure[60]–Protein 3D-structure and compound 3D-structure[61]–3D protein-ligand and complexes-structure[62]GCN-based–Protein 3D-structure and compound graph structure[63]PIGNetProtein graph structure and compound graph structure[64]Transformer-basedViTScoreProtein 3D-structure and compound 3D-structure[65]ETDockProtein graph structure and compound graph structure[66]–3D point clouds of protein-ligand complexes[67]MT-DTAProtein sequence and compound descriptor[68]−: model without name. CIPHER: correlating protein interaction network and phenotype network to predict disease genes; DTINet: drug target interaction (DTI)Net; CNN: convolutional neural network; GCN: graph convolutional network; DLEPS: deep learning-based efficacy prediction system; 3D: three-dimensional; GADTI: graph autoencoder approach for DTI prediction; GLIM: graph local infoMax; MRBDTA: molecule representation block-based drug-target binding affinity (DTA) prediction; MDCT: multi-scale diffusion and interactive learning with CNN-transformers; BERT-GCN: bidirectional encoder representations from transformers-GCN; ML: machine learning; MT-DTA: mutual transformer-DTA.

There are also several network pharmacology algorithms that focus on the attributes of nodes in biological networks. On one hand, many methods for estimating distances in biological networks have been promoted. By quantifying the network proximity of disease genes and drug targets within the human protein-protein interactome, Cheng et al. [38] identify hundreds of new drug-disease associations for over 900 U.S. Food and Drug Administration (U.S. FDA)-approved drugs. The researchers selected four network-predicted associations to test their causal relationships using extensive healthcare databases containing data from over 220 million patients, applying state-of-the-art pharmacoepidemiologic analyses and propensity score matching. Kong et al. [39] introduced a ML framework designed to identify robust predictive biomarkers for anticancer drug responses, leveraging network-based analyses of pharmacogenomic data derived from three-dimensional (3D) organoid culture models. The framework first filters out pathways most closely related to drug response by calculating the distances between pathways and drug targets. Next, the gene expression data of these pathways are used as features input into the ML model to predict the drug half-maximal drug inhibitory concentration (IC50). Pathways with a high predictive performance are potential drug response biomarkers. The framework aims to overcome the limitations of current ML methods, which often fail to identify translational biomarkers from preclinical models.

On the other hand, random walk-based methods have also been developed to predict drug-target associations. Bang et al. [40] proposed DREAMwalk, an innovative algorithm designed for computational drug repurposing by leveraging high-throughput biomedical knowledge graphs. Traditional approaches face challenges due to the dominance of genes and the relatively small number of drug and disease entities, leading to less effective representations. DREAMwalk addresses these issues by employing a “semantic multilayer guilt-by-association” approach, which is based on the principle that “similar genes share similar functions” at the drug–gene–disease level. The algorithm uses a teleport-guided random walk method, where drugs and diseases are mapped into a unified embedding space via a heterogeneous skip-gram model. The final output, which represents drug‒disease association probabilities, is predicted via an XGBoost classifier and leads to more accurate predictions of drug‒disease associations. Luo et al. [41] proposed drug target interaction (DTI)Net, a computational pipeline designed to predict novel drug-target interactions. It constructs a heterogeneous network that integrates diverse types of drug-related information. The core of DTINet involves learning a low-dimensional vector representation of features, which accurately captures the topological properties of individual nodes within the heterogeneous network. Predictions are then made on the basis of these representations via a vector space projection scheme.

Studies for drug-target prediction.

## Section: Association-based drug target prediction › Convolutional neural network (CNN)- and graph convolutional network (GCN)-based association algorithms for drug target prediction

With the development of AI and multiomics technologies, high-dimensional data suitable for constructing deep learning models have accumulated. Deep learning algorithms, such as CNNs and GCNs, were subsequently promoted to solve many problems in this field, such as mechanism revealing and drug development (Table 1) [[42], [43], [44], [45], [46], [47], [48]].

Compared with network-based approaches, drug-target prediction algorithms based on drug and protein structures operate on the basis of the intrinsic properties of these molecules. These methods typically follow a process of feature extraction followed by prediction. Common techniques in this category include methods based on CNNs. Zhu et al. [42] proposed deep learning-based efficacy prediction system (DLEPS), which uses 1D-CNNs and gene expression profiles for predicting drug efficacy. The method first encodes chemical structures via the simplified molecular input line entry system (SMILES) and divides them into grammar trees, which are then encoded into a high-dimensional latent space through a 1D-CNN. The latent vector then passes through a five-layer dense network for the prediction of chemically induced transcriptional profiles of 978 landmark genes, facilitating drug repurposing and discovery across a wide range of diseases, particularly those lacking well-defined targets. Rifaioglu et al. [43] proposed a system called DEEPScreen, which uses a 2D-CNN for predicting drug targets. Unlike traditional methods that rely on descriptors, DEEPScreen employs 2D structural images of compounds as input data. This image-based representation captures complex features of the compounds, naturally reflects their molecular states, and significantly enhances the prediction accuracy. Another method, 3D-KINEssence [44], uses a 3D-CNN to predict the potency and target profile of kinase inhibitors. The approach involves training the 3D-CNN on the biomolecular structures of kinases, allowing the model to learn essential structural features that distinguish individual kinases. The learned 3D fingerprints encapsulate these unique features and are combined with molecular Morgan fingerprints of kinase inhibitors to predict the potency and target profile of kinase inhibitors.

GCNs can perform exceptionally well in network-based prediction tasks. By continuously aggregating neighboring nodes, GCNs can capture information at different scales around each node. In the drug-target network, this allows GCNs to not only focus on the direct interactions between drugs and targets but also consider other indirect associations. Zhao et al. [45] proposed GCN-DTI, a combination approach including a GCN and deep neural networks (DNNs). The method first involves constructing a drug-protein pair (DPP) network in which nodes represent drug-protein pairs and edges represent their interactions. The GCN is then used to extract features from each DPP on the basis of the network topology, capturing both the structural information of the network and the intrinsic properties of the drugs and proteins involved. These features, comprising the combined characteristics of drugs and proteins, are input into a DNN, which classifies each DPP as a true or false interaction. Another GCN model, graph autoencoder approach for DTI prediction (GADTI) [46], predicts drug-target interactions by constructing a heterogeneous network that integrates multiple drug- and target-related datasets. The model then uses a graph autoencoder with an encoder consisting of a GCN and a random walk with a restart model to generate node embeddings. The decoder, DistMult, is a matrix factorization model that reconstructs the original network from the embeddings. By reconstructing the connections in a heterogeneous graph, potential drug-target interactions can be predicted.

As a representative deep learning algorithm for drug-gene association predictions, DrugAI [47] is a multiview deep learning model designed to understand the mechanisms of candidate drugs, particularly with a focus on activating and inhibiting interactions between drugs and their targets. It integrates multimodal information, including compound structure information extracted by a GCN, compound similarity networks, and multidimensional representations of targets extracted by a CNN, to achieve directed prediction of drug-target associations. Another algorithm that integrates multimodal information, graph local infoMax (GLIM) [48], is designed to systematically uncover associations among multilevel biological elements, including disease phenotypes, tissues, cell types, and molecules; this addresses the challenges posed by their heterogeneity and incompleteness. GLIM operates within a human multilevel network (HMLN), which incorporates multiple tissues and cell types in addition to molecular networks. By embedding the features of the HMLN through the GCN and contrastive learning, the GLIM algorithm can systematically mine potential relationships between these elements.

## Section: Association-based drug target prediction › Transformer-based association algorithms for drug target prediction

The transformer model is a state-of-the-art deep learning architecture primarily used for natural language processing tasks (Table 1) [[49], [50], [51], [52], [53], [54]]. It leverages a self-attention mechanism to weigh the influence of different parts of the input data, allowing it to capture complex relationships and dependencies more effectively than traditional sequence models such as recurrent neural networks (RNNs) or long short-term memory networks (LSTMs). By adopting the transformer model, the significance between molecular structures can be better incorporated in the drug-target interaction prediction task. For example, Huang et al. [49] proposed MolTrans, a transformer-based method for drug-target interaction prediction. This method decomposes molecular sequences into substructures, which identify and merge frequent subsequences to generate high-quality, interpretable substructures. These substructures are then embedded through an augmented transformer module that captures the complex chemical relationships among them via self-attention mechanisms. Finally, the interaction prediction module pairs drug and protein substructures, applying a CNN to model higher-order interactions and predict the likelihood of drug-target interactions. Similarly, the molecule representation block-based drug-target binding affinity (DTA) prediction (MRBDTA) model [50] predicts DTA by first encoding the original protein fast-alignment search tool for amino acid sequences (FASTA) and drug SMILES sequences into embedding spaces and adding positional information. The molecule representation block, which improves the transformer encoder and introduces skip connections, extracts features from these encoded sequences. Finally, the interaction learning module integrates the features extracted from proteins and drugs and predicts their binding affinities via fully connected layers and a linear layer. Zhu et al. [51] proposed the multi-scale diffusion and interactive learning with CNN-transformer (MDCT)-DTA model, which improves DTA prediction by integrating multiscale graph diffusion convolution and CNN-transformer networks. The model processes protein sequences with CNNs to extract local features, followed by a transformer to capture global relationships. Simultaneously, drug molecules, represented as SMILES strings, are converted into molecular graphs and processed to extract structural features. After these features are obtained, a local interlayer interaction mechanism refines them to facilitate the exchange of information between drug and protein features. Finally, the combined data are fed into a fully connected layer for affinity prediction, allowing the model to accurately capture the intricate interactions between drugs and their targets. Another TDGraphDTA model proposed by Zhu et al. [52] predicts drug-target affinity by integrating multiscale information interactions and graph optimizations to achieve superior accuracy and interpretability. The model begins by preprocessing protein sequences into graph representations and drug molecules into SMILES-encoded molecular graphs. It then employs multilevel cascaded CNNs to extract both global and local features from protein sequences, while a diffusion-based graph optimization block enhances the drug molecular graphs by capturing intricate relationships between nodes. A cross-attention mechanism within the multi-scale interaction block further integrates features from both drug and protein inputs, effectively capturing contextual information between molecular substructures. These optimized features are then combined and processed through fully connected layers to predict DTA.

In recent years, with advancements in computational power and data availability, large language models (LLMs) have demonstrated exceptional performance in various areas, including content comprehension and reasoning. They have also been applied in the discovery of drug and disease targets. Lennox et al. [53] presented a novel approach for predicting DTA by combining pretrained bidirectional encoder representations from transformers (BERT) models and GCNs. Specifically, they used a pretrained BERT model to encode protein sequences and a pretrained RoBERTa model to encode drug SMILES strings, generating robust representations for each drug and protein. These representations are then fed into a GCN, which models the interactions between the drugs and proteins. Theodoris et al. [54] proposed Geneformer, a context-aware, attention-based deep learning model pretrained on ∼30 million single-cell transcriptomes. This model uses a self-supervised masked learning objective to learn gene network dynamics and is fine-tuned for various tasks, including drug-target interaction prediction. Geneformer excels in predicting dosage-sensitive genes and identifying candidate therapeutic targets, significantly enhancing drug discovery by modeling gene deletions and activations in specific cellular contexts. Its ability to perform accurate predictions with limited data demonstrates its potential in uncovering novel drug targets and optimizing therapeutic strategies.

## Section: Molecular collision-based drug target prediction

On the basis of principles of molecular interactions, drug target prediction models focus primarily on identifying ligands that can activate or inhibit specific proteins. By predicting the interactions between drugs and their targets, these models help elucidate the mechanisms of action at the molecular level. Leveraging computational techniques, they efficiently identify promising drug candidates and provide insights into their molecular effects.

## Section: Molecular collision-based drug target prediction › ML-based molecular collision algorithms for drug target prediction

In traditional ML approaches for predicting drug targets, there are two main methodologies (Table 1) [[55], [56], [57]]. The first approach involves the use of molecular docking results as inputs for ML models to predict the efficacy of potential ligands. For example, Marchetti et al. [55] integrated molecular dynamics simulations, molecular docking, and ML to predict the functional effects of allosteric ligands on the heat shock protein 90 (HSP90) protein. First, representative protein conformations are generated from simulations. Next, a library of ligands is docked to these structures. Finally, ML algorithms, specifically support vector machines, classify the ligands as activators or inhibitors based on features extracted from the docking results, achieving highly balanced accuracy in distinguishing the functional categories. The second approach involves prescreening ligands based on their molecular features via ML models and then employing molecular docking methods to refine and predict their interactions with the target protein. Salimi et al. [56] proposed a method to identify potential vascular endothelial growth factor receptor 2 (VEGFR2) kinase inhibitors. The method begins by gathering data from chemical databases and computing molecular descriptors. A random forest classifier is used to screen compounds with high prediction probabilities, followed by similarity screening to known inhibitors. The selected compounds are then subjected to molecular docking and molecular dynamics simulations to evaluate their binding affinity and to assess the stability of the ligand-protein complexes, respectively. Finally, adsorption, distribution, metabolism, excretion, and toxicity (ADMET) properties are predicted to confirm favorable pharmacokinetic profiles and low toxicity. Similarly, Yasir et al. [57] employed a multistep approach to identify potential Janus kinase 2 (JAK2) inhibitors. Initially, a reference dataset of known JAK2 inhibitors is gathered, and molecular descriptors are generated via RDKit tools. Next, a random forest regression model is constructed using Scikit-learn to predict the pIC50 values of a large chemical library. The compounds with high prediction scores are then subjected to molecular docking to evaluate their binding affinities. Subsequently, molecular dynamics simulations are used to assess the stability of the ligand-protein complexes. Finally, ADMET properties are predicted, and selected compounds are experimentally validated for their JAK2 inhibitory activity.

## Section: Molecular collision-based drug target prediction › CNN- and GCN-based molecular collision algorithms for drug target prediction

Models based on CNNs and GCNs have advantages in expanding the receptive field, preserving structural information, and extracting more meaningful data (Table 1) [[58], [59], [60], [61], [62], [63], [64]]. DeepBindBC [58] is a deep learning method for identifying native-like protein-ligand complexes through a virtual screening. The approach begins by collecting binding structures, removing complexes with rare atom types, and generating potential negative data by cross-docking nonnative ligands. Using these data, a ResNet (2D-CNN)-based model is constructed. Input data are generated by encoding the atomic types with one-hot encoding and calculating the Euclidean distances between atomic pairs. The ResNet model is trained on these structured data to distinguish binding interactions from nonbinding interactions. By using DeepBindBC, Zhang et al. [59] proposed a multistep approach that combines deep learning and molecular dynamics simulations to identify novel inhibitors of the cancer drug target tumor necrosis factor alpha (TNF-α)-induced protein-8 like2 (TIPE2). Initially, the TIPE2 protein structure is modeled, and a large chemical library is prepared. A deep learning-based dense fully connected neural network (DFCNN) was developed to predict protein-ligand binding probabilities. Preliminary screening is conducted with this DFCNN. Structural-based screening by DeepBindBC is followed, which incorporates physicochemical and spatial information. High-potential candidates are then subjected to molecular docking and stability assessments through molecular dynamics simulations. Finally, the binding affinities of the selected candidates are experimentally validated. For the 3D-CNN model, Jiménez et al. [60] proposed KDEEP to predict protein-ligand binding affinity. The approach represents protein and ligand atoms in a 3D grid, capturing their physicochemical properties as voxel features. A simplified SqueezeNet architecture is employed for the 3D-CNN, which processes these voxelized representations to learn complex interaction patterns. Other methods, such as those proposed by Ragoza et al. [61] and Stepniewska-Dziubinska et al. [62], also use a similar 3D-CNN approach for drug-target prediction.

GCN models can better preserve spatial structural information in molecular collision models. By combining CNN and GCN models, Jones et al. [63] predicted protein-ligand binding affinity by integrating deep learning models with structural analysis. After essential atomic features such as element type, hybridization state, and structural properties are extracted, two main models are built: a 3D-CNN and a spatial graph CNN (SG-CNN). The 3D-CNN captures 3D atomic features and interactions via voxel grid representations, thereby learning spatial information without predefined pairwise interactions. The SG-CNN, on the other hand, models both covalent and noncovalent interactions explicitly via graph-based representations, leveraging adjacency matrices to define atomic neighborhoods. After independent training, these models are combined in the prediction module via mid-level and late fusion techniques, which harness their complementary strengths, leading to increased prediction accuracy and computational efficiency. Another GCN model is PIGNet [64], a physics-informed deep learning model. PIGNet leverages a neural network graph to represent protein-ligand complexes as molecular graphs, incorporating node features and adjacency matrices to capture covalent and intermolecular interactions. The model uses physics-based equations parameterized by neural networks to calculate interaction energies, thereby embedding the underlying physics of protein-ligand binding into the learning process. Data augmentation strategies, including generating random binding poses, are employed to increase the diversity of the training set, improving the model’s generalizability. Compared with traditional methods and previous deep learning models, the performance of PIGNet shows superior docking and screening powers.

## Section: Molecular collision-based drug target prediction › Transformer-based molecular collision algorithms for drug target prediction

By utilizing transformer models (Table 1) [[65], [66], [67], [68]], Guo et al. [65] proposed ViTScore, a novel method for predicting protein-ligand docking poses via a vision transformer (ViT). ViTScore voxelizes the protein-ligand interaction pocket into a 3D grid, where each voxel encodes the occupancy of atoms on the basis of their physicochemical properties. This voxelized representation is then processed by a ViT model, which processes the 3D grid through a series of transformer blocks. These blocks leverage self-attention mechanisms to capture intricate spatial and energetic patterns between atoms, enabling the ViTScore to distinguish between near-native and nonnative docking poses effectively. Another transformer method, ETDock [66], uses an equivariant transformer for predicting protein-ligand docking poses by integrating atomic-level and graph-level features through a feature processing module and a TAMformer module. The ligand is represented as a molecular graph, with node embeddings learned via a graph isomorphism network (GIN), whereas protein embeddings are obtained via geometric vector perception (GVP). These features are fused via a learnable outer product to capture protein-ligand interactions. The TAMformer module, consisting of triangle, attention, and message layers, processes these features to predict a protein-ligand distance matrix and iteratively refines the ligand pose, significantly enhancing docking accuracy by enforcing geometric constraints and improving information exchange. From the perspective of 3D point clouds, Wang et al. [67] proposed a method that involves generating 3D point clouds, with each point representing an atom’s coordinates, van der Waals radius, atomic weight, and source. These data are then processed by PointTransformer, a model that incorporates hierarchical spatial structures and self-attention mechanisms to predict binding affinity. This approach allows the model to accurately predict binding affinity by preserving the original geometric information of the protein-ligand complex. Zhu et al. [68] proposed the mutual transformer (MT)-DTA model, which innovatively combines a CNN and transformer-based molecular sequence encoded with a self-attention mechanism; this combination leads to accurate and consistent drug-target affinity predictions. The model first uses CNN and transformer blocks to effectively encode drug and protein sequences, capturing both local and global molecular features. In addition, it introduces a self-attention mechanism to simulate detailed interactions between these sequences, addressing the need to capture complex intermolecular relationships. Finally, these interaction features are fed into a fully connected network to accurately predict drug-target affinity.

## Section: Drug combination target prediction

Drug combination target prediction is also a crucial component of AI-driven drug development [69,70]. This approach uses advanced computational models to identify synergistic interactions between multiple drugs and their targets. By analyzing large datasets and leveraging ML algorithms, drug combination target prediction helps uncover complex biological interactions that single-drug treatments may miss (Fig. 2). This method not only aids in understanding the combined effects of drugs but also enhances the efficacy and safety profiles of therapeutic regimens. In the context of AI drug development, predicting drug combination targets has accelerated the discovery of novel, more effective treatment strategies, paving the way for personalized and precision medicine.Fig. 2This comprehensive diagram illustrates the multifaceted approach to artificial intelligence (AI)-driven drug combination development, focusing on the integration of various methodologies for target discovery, drug repurposing, understanding mechanisms of traditional Chinese medicine (TCM), new combination therapies, and new drug development. CNN: convolutional neural network; Add: addition; Norm: normalization; C: contextual representation; T: tokens (Toks) of the input sentences; E: embedding representations; BERT: bidirectional encoder representations from transformers; CLS: classification Tok; SEP: separator Tok; Trm: transformer block; GPT: generative pre-trained transformer.Fig. 2

This comprehensive diagram illustrates the multifaceted approach to artificial intelligence (AI)-driven drug combination development, focusing on the integration of various methodologies for target discovery, drug repurposing, understanding mechanisms of traditional Chinese medicine (TCM), new combination therapies, and new drug development. CNN: convolutional neural network; Add: addition; Norm: normalization; C: contextual representation; T: tokens (Toks) of the input sentences; E: embedding representations; BERT: bidirectional encoder representations from transformers; CLS: classification Tok; SEP: separator Tok; Trm: transformer block; GPT: generative pre-trained transformer.

Studies for drug combination-target prediction.

## Section: Drug combination target prediction › Biological network-based algorithms for drug combination target prediction

Modern medicine has gradually transformed from “one drug, one target” to “multiple drugs, multiple targets”. Therefore, developing algorithms for predicting the efficacy and mechanism of drug combinations is crucial for drug development (Table 2) [[71], [72], [73], [74], [75], [76], [77], [78]]. Network pharmacology is suitable for predictions related to drug combinations owing to its hypothesis on biological networks. Li et al. [71] introduced a virtual screening paradigm based on “network target”, which is different from the traditional “single target” concept. The proposed algorithm, termed network target-based identification of multicomponent synergy (NIMS), is designed to prioritize synergistic agent combinations in a high-throughput manner. Candidate agents labeled as “n” are used as inputs for NIMS and can be translated into network interactions among molecular entities such as targets or responsive gene products within the network pharmacology theory. The model then computes the synergy scores between a specified agent and every candidate agent and ranks the effective agent pairs. In biological networks, nodes representing biomolecules might play different roles with different functions. Identifying communities or modules in a biological network could help determine the synergistic relationships among drug combinations and thus increase the accuracy of the prediction of drug combinations. From a network perspective, Li et al. [72] developed the distance-based mutual information model (DMIM) to identify significant relationships among herbs in various herbal formulae. DMIM combines mutual information entropy with “between-herb-distance” to score herb interactions and construct an herb network. The effectiveness of the model has been validated on a case study of the Liu-Wei-Di-Huang formula. The comCIPHER [73] algorithm introduces a novel representation of drug-gene-disease relationships called a “comodule”, which characterizes closely related drugs, diseases, and genes. The method begins by defining a network-based gene closeness profile to establish connections between drugs and diseases. A Bayesian partition method was subsequently developed to identify these drug-gene-disease comodules on the basis of gene closeness data. Finally, the comodules established through comCIPHER can be used for new drug applications.Table 2Studies for drug combination-target prediction.Table 2ModelNameInputRefs.Biological network-basedNIMSAgent and candidate agents[71]DMIMCandidate herbal formulae and herb pairs[72]comCIPHERProtein interaction, drugs and their targets, drug-disease associations, and chemical-drug associations[73]–Drug A, drug B, disease, and protein[74]SRWRTCM[75]–Protein-metabolite network[76]MatchMakerGene expression profile and drug chemical structure[77]SynPathyDrug feature based on pathway, chemical structure, and cell line feature[78]CNN and GCN-basedCNN-DDIDrug categories, targets, pathways, and enzymes[85]CNN-SiamChemical substructures, targets, and enzymes[86]–Patient records[87]DRSPRINGChemical structure, genetic interactions, drug-target information, and gene expression profiles of cell lines[88]MK-GNNMedical records (diagnosis, treatment procedure, medications, and drug network)[89]GCN-BMPCanonical SMILES strings[90]Transformer-basedSynergyXDrug substructure and multiomics cell features[91]SynergyGTNSMILES and cell-line gene expression profiles[92]DeepPSEPolypharmacy side effects, mono side effects information, and drug-protein interactions[93]MDF-SA-DDISubstructures, targets, and enzymes[94]LaGATKnowledge graph[95]EGFIEach sentence has a pair of drugs with an annotated relation (advise, effect, mechanism, int, and negative)[96]CancerGPTDrug pair synergy data[97]−: model without name. NIMS: network target-based identification of multicomponent synergy; DMIM: distance-based mutual information model; CIPHER: correlating protein interaction network and phenotype network to predict disease genes; SRWR: signed random walk with restart; TCM: traditional Chinese medicine; CNN: convolutional neural network; GCN: graph convolutional network; DDI: drug–drug interaction; DRSPRING: drug synergy prediction by integrated GCN; MK: medical-knowledge-based; GNN: graph neural network; BMP: bond-aware message propagation; SMILES: simplified molecular input line entry system; MDF: multi-source drug fusion, multi-source feature fusion; SA: self-attention; LaGAT: link-aware graph attention; EGFI: extraction and generation with fusion of enriched entity and sentence information; int: DDIs are provided without any information.

Many algorithms based on the attributes of biological networks for drug combinations have also been developed. Cheng et al. [74] proposed a network-based methodology to identify clinically effective drug combinations for treating complex diseases, addressing the challenge of combinatorial explosion due to numerous drug pairs and dosage combinations. The methodology quantifies the network-based relationships between drug targets and disease-related proteins within the human protein-protein interactome. Their analysis revealed six distinct classes of drug-drug-disease combinations. Among these classes, only one is correlated with therapeutic effects: when the targets of both drugs hit the disease module but target separate neighborhoods. In addition, to understand the molecular mechanisms of herbal medicines used in TCM for treating complex diseases, a novel computational systems pharmacology approach was proposed by Zhao et al. [75]. This approach includes transcriptome profiling, data collection, statistical analysis, network algorithms, bioinformatics analysis, and pharmacological validation. Central to this method is the network algorithm called signed random walk with restart (SRWR), which simulates the propagation of drug effects on networks. SRWR identifies proteins as either positively or negatively regulated (activated or inhibited) by drugs within human signaling networks. Casas et al. [76] proposed a mechanism-based disease definition within the framework of network pharmacology. This method begins by identifying a primary causal target and extends to a secondary target via guilt-by-association analysis. Predictions have been validated and explored for synergy through in vitro and in vivo mouse models. MatchMaker [77], a deep learning framework for drug combination prediction, consists of two drug-specific networks and a synergy prediction network. Drug-specific networks are designed to extract the hidden biological information between drug chemical structures and cell line gene expression profiles so that the prediction network can precisely predict and present novel drug combinations. Tang and Gottlieb [78] proposed a biological network-based deep learning model named SynPathy, which utilizes pathway-level drug features and cell line molecular data as inputs to suggest potential strategies for drug combination therapy. By testing the DrugComb benchmark, SynPathy performs better than existing methods do and provides explainable pathways for synergy prediction.

The numerous applications of network pharmacology methods in drug discovery demonstrate the potential of AI to address specific challenges. For example, do Valle et al. [79] developed a network medicine framework to understand how polyphenols influence health by analyzing interactions between polyphenol protein targets and disease-associated proteins. Their study revealed that these targets cluster in specific regions of the human interactome, with their proximity to disease proteins predicative of known therapeutic effects, which highlights AI’s ability to integrate complex biological data and predict therapeutic outcomes that traditional methods might miss [79]. In addition, in complex drug combinations or TCM fields, network target theory and techniques have also been applied in drug development and repositioning [80,81]. For example, AI revealed that Weifuchun and Moluodan, both of which are used for treating chronic atrophic gastritis, have distinct mechanisms of action: Weifuchun primarily modulates immune responses, whereas Moluodan affects lipid metabolism [82,83]. These findings underscore the role of AI in refining therapeutic strategies. Additionally, in biomarker prediction, AI combines network analysis with clinical trials and animal studies to identify key biological modules regulated by the Yiqi Tongqiao pill. This analysis revealed pathways related to immune regulation, epithelial barrier disorders, and cell adhesion, centered on biomarkers such as interleukin 4 (IL-4), interferon gamma (IFN-γ), TNF-α, and IL-13 [84], and demonstrated AI’s capacity to predict clinically relevant biomarkers and guide therapeutic development.

Studies for drug combination-target prediction.

## Section: Drug combination target prediction › CNN- and GCN-based association algorithms for drug combination target prediction

Unlike most network-based pharmacological approaches, some studies utilize advanced deep learning methods to extract drug-related features and apply these features to tasks such as combination drug therapies, drug synergy score predictions, and IC50 predictions for drug combinations. CNNs and GCNs are commonly used to extract both the global and local features of drugs, demonstrating their strengths, particularly in drug-drug interaction (DDI) prediction tasks (Table 2) [[85], [86], [87], [88], [89], [90]].

The CNN-DDI method [85] incorporates multiple drug-related features, such as drug categories, targets, pathways, and enzymes, and then uses a CNN to extract features for DDI prediction. The fusion of diverse features of this method and the use of the Jaccard similarity have been validated to improve the prediction ability in the drug-drug-interaction events predicted by a multimodal deep learning framework (DDIMDL) task. The CNN-Siam model [86], which employs a Siamese network architecture, is recognized for its effective prediction of DDIs via multimodal drug data. This model leverages twin convolutional networks and sophisticated optimization algorithms, achieving significant accuracy improvements over the state-of-the-art methods. Although many studies have focused mainly on drug synergistic effects or the prediction of DDIs, Küçükosmanoglu et al. [87] proposed an innovative method for analyzing adverse events in combination therapies by using real-world data from the U.S. FDA’s reporting system. By employing a CNN autoencoder to visualize complex adverse event patterns from millions of patient records, this research provided novel insights into the predominantly additive nature of drug interactions. This approach not only enhances understanding but also supports safer implementation of combination therapies in clinical settings, marking a significant advancement in predictive health care analytics.

In addition to network pharmacology methods, research on drug combination prediction also encompasses numerous studies leveraging GCNs. These studies employ GCNs to extract structural features of compounds and network-related features of drugs, which include associations among drugs, cells, genes, and pathways. By utilizing GCNs, these approaches can effectively capture the intricate relationships and interactions within biological networks, thereby enhancing the accuracy and comprehensiveness of drug combination predictions. By incorporating a GCN to integrate chemical structures, genetic interactions, and drug-target information, a deep-learning model called drug synergy prediction by integrated GCN (DRSPRING) [88] was established to predict drug synergy effects by innovatively utilizing pharmacogenomic profiles alongside molecular properties. The model has demonstrated good performance on the DrugComb database and can be extended to arbitrary drug pairs and cell lines. The medical-knowledge-based (MK)-GNN model [89] effectively integrates patient representations derived from historical medical records with essential medical knowledge, including prior knowledge and medication knowledge, to enhance medication combination prediction (MCP). Finally, the researchers performed a case study to show the application value of the MK-GNN. In addition to research on drug combinations, GCNs are also suitable for predicting DDIs. The GCN-BMP method [90] for predicting DDIs uses GCNs with a focus on bond-aware message propagation. Unlike several methods that consider various drug-related features that may cause noise, this model addresses this limitation by employing an end-to-end graph representation learning technique and achieves superior performance.

## Section: Drug combination target prediction › Transformer-based association algorithms for drug combination target prediction

While CNNs/GCNs have significantly advanced research, such as DDI prediction, the field of drug combination research is looking toward more sophisticated models, such as transformers (Table 2) [[91], [92], [93], [94], [95], [96], [97]].

SynergyX [91] has emerged as a groundbreaking tool in the domain of antitumor drug synergy prediction. This model is trained on features of drug substructures and multiomics data and uses a multimodality mutual attention network to capture information on intricate biological interactions, which excels in DrugComb task testing. The SynergyGTN [92] model represents a significant advancement in predicting synergistic drug combinations for cancer treatment. By leveraging graph transformer networks and integrating comprehensive drug and cell line features, SynergyGTN achieves notable improvements, with a receiver operating characteristic curve improvement of 5% over the state-of-the-art methods in terms of five-fold cross-validation. DeepPSE [93] presents a novel deep learning method to predict polypharmacy side effects by integrating multiple neural network types and a transformer encoder block for feature extraction. The model then applies feed-forward layers to predict polypharmacy side effects of drug pairs. Transformers also play an important role in the field of DDI prediction. The multi-source drug fusion, multi-source feature fusion (MDF)-self-attention (SA)-DDI model [94] introduces a sophisticated approach for predicting DDI events by employing a combination of multisource drug fusion and feature fusion with a transformer self-attention mechanism. This method distinguishes itself by not only predicting whether drugs interact but also detailing the nature of those interactions, providing a deeper understanding of drug interaction mechanisms. LaGAT [95] introduces a novel approach for DDI prediction by utilizing a link-aware graph attention mechanism that customizes attention pathways on the basis of different drug pair links. This method enhances the model’s ability to capture meaningful semantic relationships between drugs, leading to improved performance and interpretability over both traditional and contemporary models.

The emergence of large-scale deep learning models has revolutionized various fields, including pharmacology. Following the development of BERT, the advent of generative pretrained transformers (GPTs) and other LLMs has significantly propelled research in drug combination studies. These models, which leverage vast textual descriptions, offer novel insights and methodologies for predicting effective drug synergies, thus enhancing the potential for breakthroughs in personalized drug and treatment strategies. Huang et al. [96] proposed an innovative approach using the extraction and generation with fusion of enriched entity and sentence information (EGFI) model, which integrates BioBERT and BioGPT-2 to enhance DDI extraction from the biomedical literature. This framework significantly improves DDI prediction by fusing enriched entity and sentence information, demonstrating its utility in identifying unrecorded drug interactions and potential novel relationships and providing a valuable tool for biomedical research. Li et al. [97] explored a novel application of LLMs to predict drug pair synergy in rare cancerous tissue with limited data. Leveraging the advanced capabilities of LLMs for few-shot learning, the study demonstrates that CancerGPT, a model tailored for this specific task, significantly enhances prediction accuracy compared with traditional data-driven models, especially in contexts where data are scarce. This approach opens new avenues for the use of AI in personalized medicine and highlights the potential of LLMs in biomedical applications.

## Section: Conclusion

Drug-target interactions are crucial in AI-assisted drug development. By leveraging advanced deep learning techniques such as CNNs, GCNs, and transformers, along with network-based models and traditional ML methods, these approaches have significantly improved prediction accuracy and broadened the generalization capabilities of models. These advancements are particularly useful for identifying single drug-target interactions and understanding the complex dynamics of drug combination‒target interactions. As a result, they accelerate the drug discovery process and contribute to the development of more effective and personalized therapies. The significance of these advancements lies in their ability to process and learn from vast amounts of biological data, overcoming the limitations of traditional methods that often struggle with the complexity of molecular interactions. For example, CNNs excel at identifying spatial patterns and structural features of molecules, which are critical for predicting potential drug-target interactions. GCNs offer a detailed representation of molecular structures and their related data, providing a comprehensive understanding of how individual drugs interact with specific targets. Owing to their powerful attention mechanisms, transformers further increase prediction accuracy by capturing intricate dependencies within biological sequences. Network-based models add to this predictive framework by offering a systems-level perspective, integrating various data sources to reveal complex biological interactions. Traditional ML techniques complement these approaches by efficiently handling large datasets and extracting relevant features, thereby increasing overall predictive accuracy and reliability.

Predicting drug combination-target interactions presents additional challenges owing to the increased complexity of multidrug interactions. Deep learning methods, such as CNNs, GCNs, and transformers, have shown promise in addressing these challenges by modeling the combined effects of multiple drugs on biological targets. GCNs, in particular, excel at representing and analyzing the relational data inherent in drug combinations, providing insights into synergistic and antagonistic effects. The ability of transformers to handle complex sequential data is instrumental in predicting the outcomes of drug combinations on specific targets. Network-based models offer a holistic approach, which is crucial for understanding the broader implications of drug combinations within biological systems, enabling the identification of multitarget strategies and potential side effects. The integration of molecular collision models further enhances these predictions by simulating the physical interactions between drug combinations and targets, offering detailed insights into binding affinities and specificities.

However, the application of AI in drug development is not without its limitations. Despite the promise shown by these techniques, challenges remain in ensuring the interpretability of AI models, especially when dealing with the complex nature of biological systems. The “black-box” nature of deep learning models can obscure the mechanistic understanding of how predictions are made, which is critical for regulatory approval and clinical adoption. Additionally, the quality and diversity of the training data significantly influence the performance of AI models. Biases in the data can lead to inaccurate predictions, potentially resulting in serious implications for drug development. In the context of drug combination-target interactions, this increased complexity presents additional challenges. While deep learning methods such as GCNs and transformers have shown promise in modeling the combined effects of multiple drugs, the potential for unforeseen interactions and side effects remains a significant concern. Moreover, the ability of these models to predict synergistic and antagonistic effects is still limited by the availability of comprehensive training datasets that capture the full range of possible drug interactions.

Despite these challenges, the integration of deep learning, network-based models, and traditional ML provides a robust framework for advancing drug discovery. These approaches not only accelerate the identification of promising drug candidates but also have the potential to revolutionize the development of personalized therapies. As these technologies continue to evolve, their impact on drug development is likely to grow, offering new possibilities for the treatment of complex diseases. However, addressing current limitations, such as improving model interpretability, enhancing data quality, and ensuring the ethical use of AI, will be essential to fully comprehend the potential of AI in drug development and clinical applications.

## Section: CRediT authorship contribution statement

Boyang Wang: Writing – review & editing, Writing – original draft, Visualization, Data curation. Tingyu Zhang: Writing – original draft, Visualization, Data curation. Qingyuan Liu: Writing – original draft, Visualization, Data curation. Chayanis Sutcharitchan: Writing – original draft, Data curation. Ziyi Zhou: Writing – original draft, Data curation. Dingfan Zhang: Data curation. Shao Li: Writing – review & editing, Project administration, Conceptualization.

## Section: Declaration of competing interest

The authors declare that there are no conflicts of interest.


---

# Enhancing drug discovery and patient care through advanced analytics with the power of NLP and machine learning in pharmaceutical data interpretation

- **Authors:** Nagalakshmi R, Surbhi Bhatia Khan, Ananthoju Vijay Kumar, Mahesh T R, Mohammad Alojail, Saurabh Raj Sangwan, Mo Saraee
- **Issuer:** SLAS technology
- **Type:** Scientific article
- **Published:** 2024-12-24
- **Language:** en
- **DOI:** 10.1016/j.slast.2024.100238
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39722407/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

This study delves into the transformative potential of Machine Learning (ML) and Natural Language Processing (NLP) within the pharmaceutical industry, spotlighting their significant impact on enhancing medical research methodologies and optimizing healthcare service delivery. Utilizing a vast dataset sourced from a well-established online pharmacy, this research employs sophisticated ML algorithms and cutting-edge NLP techniques to critically analyze medical descriptions and optimize recommendation systems for drug prescriptions and patient care management. Key technological integrations include BERT embeddings, which provide nuanced contextual understanding of complex medical texts, and cosine similarity measures coupled with TF-IDF vectorization to significantly enhance the precision and reliability of text-based medical recommendations. By meticulously adjusting the cosine similarity thresholds from 0.2 to 0.5, our tailored models have consistently achieved a remarkable accuracy rate of 97 %, illustrating their effectiveness in predicting suitable medical treatments and interventions. These results not only highlight the revolutionary capabilities of NLP and ML in harnessing data-driven insights for healthcare but also lay a robust groundwork for future advancements in personalized medicine and bespoke treatment pathways. Comprehensive analysis demonstrates the scalability and adaptability of these technologies in real-world healthcare settings, potentially leading to substantial improvements in patient outcomes and operational efficiencies within the healthcare system.


---

# Ethical and regulatory challenges of large language models in medicine

- **Authors:** Jasmine Chiat Ling Ong, Shelley Yin-Hsi Chang, Wasswa William, Atul J Butte, Nigam H Shah, Lita Sui Tjien Chew, Nan Liu, Finale Doshi-Velez, Wei Lu, Julian Savulescu, Daniel Shu Wei Ting
- **Issuer:** The Lancet. Digital health
- **Type:** Scientific article
- **Published:** 2024-04-23
- **Language:** en
- **DOI:** 10.1016/s2589-7500(24)00061-x
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38658283/
- **Licence:** CC-BY-NC

## Section: Abstract

With the rapid growth of interest in and use of large language models (LLMs) across various industries, we are facing some crucial and profound ethical concerns, especially in the medical field. The unique technical architecture and purported emergent abilities of LLMs differentiate them substantially from other artificial intelligence (AI) models and natural language processing techniques used, necessitating a nuanced understanding of LLM ethics. In this Viewpoint, we highlight ethical concerns stemming from the perspectives of users, developers, and regulators, notably focusing on data privacy and rights of use, data provenance, intellectual property contamination, and broad applications and plasticity of LLMs. A comprehensive framework and mitigating strategies will be imperative for the responsible integration of LLMs into medical practice, ensuring alignment with ethical principles and safeguarding against potential societal risks.


---

# Ethical and social reflections on the proposed European Health Data Space

- **Authors:** Ciara Staunton, Mahsa Shabani, Deborah Mascalzoni, Signe Mežinska, Santa Slokenberga
- **Issuer:** European journal of human genetics : EJHG
- **Type:** Scientific article
- **Published:** 2024-02-14
- **Language:** en
- **DOI:** 10.1038/s41431-024-01543-9
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38355959/
- **Licence:** CC-BY

## Page 1 (Section: Ethical and social reflections on the proposed European Health DataSpace)

REVIEW ARTICLE
OPEN
Ethical and social reﬂections on the proposed European Health
Data Space
Ciara Staunton
1,2✉, Mahsa Shabani
3, Deborah Mascalzoni
1,4, Signe Mežinska
5 and Santa Slokenberga6
© The Author(s) 2024
The COVID-19 pandemic demonstrated the beneﬁts of international data sharing. Data sharing enabled the health care policy
makers to make decisions based on real-time data, it enabled the tracking of the virus, and importantly it enabled the development
of vaccines that were crucial to mitigating the impact of the virus. This data sharing is not the norm as data sharing needs to
navigate complex ethical and legal rules, and in particular, the fragmented application of the General Data Protection
Regulation (GDPR). The introduction of the draft regulation for a European Health Data Space (EHDS) in May 2022 seeks to address
some of these legal issues. If passed, it will create an obligation to share electronic health data for certain secondary purposes.
While there is a clear need to address the legal complexities involved with data sharing, it is critical that any proposed reforms are
in line with ethical principles and the expectations of the data subjects. In this paper we offer a critique of the EHDS and offer some
recommendations for this evolving regulatory space.
European Journal of Human Genetics (2024) 32:498–505; https://doi.org/10.1038/s41431-024-01543-9
INTRODUCTION
As we emerge from the COVID-19 pandemic, the beneﬁts of
global data sharing to address a global pandemic are evident.
Data sharing enabled health care policy makers to make decisions
based on real-time data, it enabled the tracking of the virus, and
importantly it enabled the development of vaccines that were
crucial to mitigating the impact of the virus. This could only have
been achieved through local, national, and crucially international
data sharing. This global data sharing, however, was the exception
and not the norm. Efforts to share data for research are
challenging due to legal and ethical issues that include privacy,
personal data protection, consent, risk of discrimination and
stigmatization [1–3]. In recent years, researchers have cited the
General Data Protection Regulation (GDPR) as hampering the
sharing of personal data for research [4]. This is in part due to the
fragmented implementation of the GDPR across the European
Union (EU) Member States and lack of clarity in legal bases for
secondary uses of data [5, 6].
In May 2022, the draft regulation for the European Health Data
Space (EHDS) was published. As part of the European Commis-
sion’s plans to build a strong European Health Union and to realize
the potential that data holds for the economy [7], the draft
regulation is proposing one legal framework to facilitate access to
electronic health data across all Member States for eight speciﬁed
purposes that, as described in Recital 1 “would beneﬁt society
such as research, innovation, policy-making, patient safety,
personalized medicine, ofﬁcial statistics or regulatory activities”.
The aim is that this will address some of the elements of the GDPR
that are perceived to hamper data sharing [4]. The ambition is that
enabling access to data will improve research, policy making, and
innovation, leaving the EU and Member States better able to
respond to health crises and future pandemics, improve treatment
and care, and increase the competitiveness of the EU, amongst
other purposes.
A framework that facilitates data sharing is without a doubt
needed. Such a framework must provide for data sharing through
processes that respect the preferences and values of participants,
have oversight mechanisms in place, and processes to ensure the
equitable beneﬁts arising from such data sharing. This data
sharing framework also needs to account for the multitude of risks
that arise in the secondary use of data. This may be due to the
risks associated with the type of data itself (e.g., there are greater
risks associated with the use of genetic data), but also risks
associated with data use (e.g., data can discriminate certain
groups or populations based on prevalence of a condition or if
they have certain characteristics that correlates with unhealthy
conditions). Concerns such as stigmatization, discrimination,
exploitation, and other data driven harms are often contextual
depending on the use, including the entity using that data, and a
framework on data sharing must have processes in place to
account for these concerns.
The EHDS is a real opportunity to introduce such a framework. A
legally sound and ethically robust data sharing process for
secondary use should result in a social licence for the secondary
use of data [8]. A social licence refers to the fulﬁlling expectations
of society in certain activities that go beyond the requirements set
out in formal regulation [8, 9]. In the context of the secondary use
of data, this would require not only compliance with the
applicable laws, but also ensuring that the use of this data is in
line with the expectations of society. However, from the draft
Received: 28 March 2023 Revised: 8 November 2023 Accepted: 15 January 2024
Published online: 14 February 2024
1Institute for Biomedicine, Eurac Research, Bolzano, Italy. 2School of Law, University of Kwazulunatal, Durban, South Africa. 3Faculty of Law and Criminology, Ghent University,
Gent, Belgium. 4Department of Public Health and Caring Science, Uppsala University, CRB, P.O. Box 256, 751 05 Uppsala, Sweden. 5Institute of Clinical and Preventive Medicine,
University of Latvia, Riga, Latvia. 6Faculty of Law, Uppsala University, Uppsala, Sweden. ✉email: Ciara.staunton@eurac.edu
www.nature.com/ejhg
1234567890();,:

## Page 2 (Section: Ethical oversight and the secondary use of data under the relevant ethics guidelines and theGDPR)

EHDS text, it does not appear that sufﬁcient consideration has
been given to the ethical, legal and social issues (ELSI) that must
be addressed in data sharing [1, 10–14]. The secondary use
framework is a data access regime put forward by the European
Commission that is anchored in the GDPR model and the right to
data protection. Data protection is critical but only one issue to be
considered in data sharing. Other factors, speciﬁcally the right to
autonomy, a right that in the context of data driven methods
relates to the right to decide over what will be done with ones’
own data, and the need to guard against discrimination and
stigmatization that can occur on a group level must be
considered, in addition to the potential beneﬁts that can accrue
in beneﬁt sharing.
Changes to the draft EHDS text that are to be proposed by the
European Parliament in the legislative process address to some
degree issues related to the right to autonomy (e.g., the proposed
inclusion of an opt-out provision for those who do not wish their
data to be shared in certain contexts), but do not address the
wider ELSI concerns in this domain. At this time, there is a
potential for improvements to the text and the purpose of this
paper is to offer some critiques and propose solutions. In this
paper, when discussing the draft EHDS, we refer to the draft text
and the proposed amendments, unless otherwise stated. We ﬁrst
brieﬂy discuss the current ethical processes in the secondary use
of data and the changes brought about by the introduction of the
GDPR. Second, we set out the EHDS and the proposed framework
on the secondary use of electronic health data. We then turn to
critically reﬂect on the proposed framework demonstrating the
problems in three areas: risks to natural persons, restriction of
right to autonomy, the lack of ELSI informed approach to two new
proposed processes. We conclude by offering proposals on how a
revised regulation can enable an ethical approach to the
secondary use of data under the EHDS.
ETHICAL OVERSIGHT AND THE SECONDARY USE OF DATA
UNDER THE RELEVANT ETHICS GUIDELINES AND THE GDPR
Research ethics is an important mechanism to balance the
protection of the rights of research participants with the public
value of science for society. Informed consent is a critical
component of the ethical conduct of human subject research,
but equally so is research ethics committee (REC) oversight. The
REC provides an independent review to help ensure that research
is scientiﬁcally and ethically sound with a fair balance between the
risks to the participants and the beneﬁt to society [15]. Informed
consent and independent ethical review continue to be followed
in the context of interventional research, but the development of
data driven research methods has brought about changes to
some of the procedures and governance of research ethics, as
they have emerged from the Nuremberg Code, the Declaration of
Helsinki, and the Belmont Report [16–18]. The reason for this
change is that the risk to individual in data driven research is
different. Interventional research carries physical risk, but the risks
in the use of data for research relate to personal autonomy,
privacy, and data protection. Beyond the individual, there is a risk
that the use of data can lead to group level discrimination and
stigmatization, due to the presence of certain conditions but also
the correlation of characteristics with certain behavior [19, 20].
Data, however, can be collected, stored, used, and re-used with
minimal physical risk to participants. Due to this minimal physical
risk to participants, there have been changes in some of our long-
standing ethical rules, particularly in relation to informed consent.
These new research avenues have also identiﬁed new ethical
challenges such as the return of results and incidental ﬁndings
[21–27].
In the context of data driven research methods, we have seen a
push to move from a paradigm that gives speciﬁc informed
consent to one study, to broad consent that provides consent to
certain unspeciﬁed research [28]. Due to concerns that broad
consent is not informed consent, tiered consent that provides
participants with a range of consenting preferences, and dynamic
consent which uses information technology to facilitate consent
to projects, change, and up-date their consenting preferences
have emerged as potential new forms of consent for data
intensive research [11, 23, 29, 30]. In most cases, consent alone is
insufﬁcient to protect participants and new governance models
have emerged. For example, data access committees (DACs), are
mechanisms through which data access requests are considered
and can
balance the competing rights and interests of the
participants, the data holder, and the interests of science
[13, 31, 32]. In light of these new ethical challenges and
governance processes, new guidance has been developed for
data intensive research methods, such as the Declaration of Taipei
which evolved from the Declaration of Helsinki [33].
Perhaps the most signiﬁcant change in the regulation of data
intensive research methods, has been the introduction of the
GDPR. Introduced to harmonize rules and principles on the
protection of personal data across the EU, key principles must now
be met in the processing of personal data and data subjects have
certain rights in the processing of their personal data. In
recognition of the importance of scientiﬁc research, the GDPR
provides for certain exceptions or derogations for research [5].
While often the primary concern in the regulation of data
intensive research methods, the GDPR is not a research regulatory
instrument. Recital 33 makes reference to “recognized ethical
standards for scientiﬁc research” in the context of consent, but
beyond this, the GDPR does not take account of or integrate other
ethical norms, standards and practices. The purpose of GDPR is
the protection and free movement of personal data thus the GDPR
does not account for the other ethical concerns and challenges
that need to be addressed in data intensive research.
When collecting data from individuals for the ﬁrst time for
research, the principles of research ethics require REC approval
and informed consent. Under the GDPR, data subjects have the
right to be informed about aspects of the use of their data,
including the purposes for which the data can be used. This right
ensures transparency and provides data subjects with the right to
object to the use of their data in research. This is not always
the case for the secondary use of data. Due to derogations
provided for research under the GDPR, the right to information
can be derogated from if the personal data is not collected directly
from the participant. If a participant is not aware that their data is
being processed for research, they are not able to exercise their
right to object, leaving a participant with a limited ability to
exercise their autonomous choice in what their data will be used
for [34].
Despite the legal acceptability of the derogation of the right to
information, there is considerable ELSI work that has looked at
participants perspectives on the use of their data in research.
While participants are often motivated by altruism to give their
data for research and this should continue to be encouraged, they
often have clear preferences on the use of their data and concerns
that must be considered and addressed when their data is used
for research [19, 35]. In other contexts, stigmatization and
discrimination has emerged as concerns, particularly in the use
of genetic and other health related data [19]. Thus it is important
that there are checks in place to guard against data harms. It is for
this reason that some of us have called for an integrated ethics
approach to the interpretation and application of the GDPR for
research by which we mean the safeguards required under Article
89 when personal data is being processed for research should be
informed by safeguards required as part of the ethical conduct of
research [36]. This could ensure that the primary and secondary
use of personal data in research follows current ethical practices
and principles of human rights that go beyond just data
protection concerns in data intensive research methods.
C. Staunton et al.
499
European Journal of Human Genetics (2024) 32:498 – 505

## Page 3 (Section: Accessing electronic health data for secondary purposes under theEHDS)

ACCESSING ELECTRONIC HEALTH DATA FOR SECONDARY
PURPOSES UNDER THE EHDS
In part response to the fragmented implementation of the GDPR,
the proposed EHDS is seeking to create a legal obligation on data
holders to share electronic health data for secondary purposes if
certain conditions are met. Slokenberga has comprehensively
detailed the process for accessing electronic health data for
secondary purposes, but key elements are worth noting [37].
Any natural or legal person can apply for access to the
electronic health data (called a “data user”) from a data holder
(“any natural or legal person, which is an entity or a body in the
health or care sector, or performing research in relation to these
sectors”). Electronic health data is broadly deﬁned and includes
electronic health records, genetic data, and population-based
health data. Most of the data that is available to be accessed, will
by and large, be data that has been collected in the context of
clinical care or research. The data user can use this data for one of
the currently eight proposed secondary uses under Article 34(1)
that includes public health activities in the public interest,
scientiﬁc research related to the health or care sector, training
and testing of AI, providing personalized care, amongst others.
There are currently two proposed avenues for accessing
electronic health data. If access is sought from one data holder
from one Member State, access can be applied directly to the data
holder themselves under Article 49. For all other cases, access is
decided by a Health Data Access Body (HDAB), a new entity to be
established in each Member State. Under Article 36(1), a Member
State may establish one or more new public sector bodies to fulﬁll
the role, or rely on either an existing public sector bodies or an
internal services of public sector bodies.
The many duties of the HDAB include approving data access
applications, issuing data permits, process electronic health data for
secondary purpose, including the collection, combination, prepara-
tion and disclosure of those data for secondary use on the basis of a
data permit, and making public a national dataset catalog (Article
37). The HDAB must cooperate with bodies that includes supervisory
authorities under the GDPR, and other stakeholders, including
patient organizations, representatives from natural persons, health
professionals, researchers, and ethical committees, where applicable
in accordance with EU and national law.
An access application should include a detailed explanation of
the purpose of the data use; description of the requested data; a
justiﬁcation why anonymous data would not sufﬁce if access to
pseudonymized data is sought; (undeﬁned) safeguards to prevent
unauthorized use and protect the rights and interests of the data
holder and natural persons; estimated time period data is
required; details on a secure processing environment. If personal
data is requested, the applicant must describe how they comply
with the GDPR and information on any ethical aspects that are
applicable. Article 44 also makes it clear the importance of the
principle of data minimization and purpose limitation in the
HDAB’s assessment.
The HDAB must make an assessment within two months of
receiving an application, extendable by two months for complex
applications. If the criteria are met, the HDAB requests the data
from the data holder. The HDAB makes the data available to the
data user through a secure processing environment within two
months. A data permit is then issued to the data holder specifying
the terms and conditions of the data use.
CRITICAL REFLECTION OF THE EHDS AND THE PROPOSED
AMENDMENTS THROUGH AN ETHICAL LENS
The draft EHDS should enable the sharing of electronic health data
for secondary purposes. Our concern is that the current proposed
process would result in incursions on some of our ethical
principles in research. Speciﬁcally we highlight four concerns:
under the proposed EHDS data protection is the principle data
harm that is considered; the special regime for research under the
GDPR would apply to all stated purposes for secondary use under
the EHDS; the proposed new process is a further erosion of the
right to autonomy; and some of the purposed new processes
need to be supported by ethical oversight and guidance before
they are implemented.
ASSUMPTION THAT DATA PROTECTION IS THE ONLY
CONCERN IN SECONDARY USE OF DATA
The proposed EHDS is seeking to drive forward and streamline the
data sharing agenda within Europe. It creates an obligation to
share electronic health data, and Article 43 gives the HDABs the
power to issue ﬁnes and penalties if data is not shared.
A reading of the EHDS would lead one to assume that data
protection is the only concern in the secondary use of data. It
establishes that, as a rule, the data should be released in an
anonymized format unless pseudonymized data are necessary for
the stated purpose. For pseudonymized data, the code key
remains with the HDAB, and, as provided for in Article 44(3), any
attempt by the data user to attempt reidentiﬁcation “shall be
subject to appropriate penalties”. In its application the data user
must also describe safeguards to protect (amongst others) the
rights and interests of the natural person (Article 45(2)(f)), without
any consideration of what these rights are. Considering the tenor
of the proposed regulation, it is most likely that this will be
interpreted to mean rights and interests as they relate to data
protection.
The European Data Protection Board (EDPB) and the European
Data Protection Supervisor (EDPS) have issued a joint opinion
critiquing the proposed regulation and demonstrating where, in
their view, it does not conform the GDPR requirements [38]. We
echo many of these critiques and do not restate them here.
However, even if these critiques are addressed, they would not
account for the inherent assumption throughout the proposed
regulation that data protection is the only concern. Even if data is
anonymized, the data can be misused, used beyond what an
individual consented to or reasonably expected the data to be
used for, and lead to group discrimination and stigmatization.
REC approval is one such mechanism that can guard against
data misuse and other potential risks. It is for this reason that the
Declaration of Taipei, the CIOMS guidelines and other ethical
guidance, as well as some jurisdictions in Europe (e.g, Sweden)
require REC review for the secondary use of data. The EHDS leaves
the requirement of ethical assessment to Member States. Thus
while the EHDS will introduce a harmonized legal framework that
will streamline the legal process, but there is no such harmoniza-
tion
of
ethical
processes
in
the
secondary
use
of
data.
Fragmentation will continue until both legal and ethical processes
are harmonized across Member States.
Second, there is a duty on the data user only to assess the
ethical aspects. If the data user is applying from a jurisdiction that
is different to that of the data holder, differing ethical rules may
apply. The data holder may be bound by ethical rules that restrict
the sharing of the data without ethical review, but the EHDS does
not provide an avenue for the data holder to object to the sharing
of data on ethical grounds. For example, if a population biobank
has obtained the consent of its participants to use the data for
speciﬁed research purposes only, will they be forced to share the
data for other purposes without going back to its population to
recontact as per the consent? Without clarity, it is likely that this
will create complex questions regarding the different ethical rules
in each jurisdiction.
Third, ethical approval is generally only required where data is
being accessed for research purposes. Thus, for data use that does
not fall under research regulatory frameworks, national research
ethics frameworks will not apply and no other avenue for
potential oversight of these other potential data harms. Yet the
C. Staunton et al.
500
European Journal of Human Genetics (2024) 32:498 – 505

## Page 4 (Section: Disproportionate extension of special research regime to other secondary purposes)

concerns on the secondary use of data apply irrespective of
whether the data is to be used for research, training and
development of AI or other secondary purposes. This leaves us
with a gap on how these ethical issues on data use should be
addressed for data use outside of research going forward.
DISPROPORTIONATE EXTENSION OF SPECIAL RESEARCH
REGIME TO OTHER SECONDARY PURPOSES
The GDPR has provided for certain derogations for research,
including derogation from the right to information. Without this
right, data subjects will be unaware that their data is being
processed and thus unable to exercise their other rights. However
due to the importance of scientiﬁc research in society, a
derogation to this right (and the associated downstream impact
on other rights) is considered proportionate if the processing of
the personal data is for research.
Under Article 38 of the proposed EHDS, the derogation to the
right to information now applies to all proposed secondary
purposes. Derogating from rights under the GDPR research regime
can only be acceptable if certain conditions are met, determined on
a case-by-case assessment. Under the proposed EHDS this deroga-
tion is now autonomatic [5]. The use of the data outside of research
does not have any such protections in place such as REC oversight,
nor is the derogation of the right to information to the seven other
purposes balanced with any other standards or safeguards. While
we welcome that Articles 38 and 39 mandate the Health Data
Access Bodies to make available certain information to the public,
this information is on a general level only and in no way remedies
this wide extension of the derogation of right to information. Any
extension of the erosion of data subjects’ rights must be justiﬁed
with other mechanisms in place to ensure that the rights and
interests of data subjects continue to be safeguarded.
CONSENT, AUTONOMY, TRUST, AND SOCIAL JUSTICE
Consent is one of a number of lawful bases for the processing of
personal
data
and
sensitive data
under
the
GDPR.
Some
jurisdictions, such as Italy, have taken a restrictive approach to
the implementation of the GDPR for research and require consent
as the lawful basis for processing of genetic data for research. In
other countries consent may not be mandated as the lawful basis
of the processing of data, but required as part of the national
ethical rules [39].
The draft EHDS is seeking to address this fragmented approach to
the requirement of consent as a lawful basis and under Article 33(5)
if consent is required by national law, “health data access bodies
shall rely on the obligations laid down in this Chapter to provide
access to electronic health data”. In the explanatory memorandum,
this is justiﬁed on the basis that it is replacing it with “with a trusted
governance and at lower costs than relying on consent”.
An appropriate consent process is an ongoing challenge for the
data driven research community. Risks relate to privacy, stigma-
tization, and discrimination, but the potential use of data,
particularly genetic data, impacts the individual, their family,
community, and wider population from which the individual
comes from. There is also a risk if appropriate governance
processes are not put in place and data cannot be reused.
Governance processes also need to account for beneﬁt, particu-
larly ensuring equity of beneﬁt.
New governance models, particularly models that are premised
on participatory governance, have been proposed. Prainsack’s
model of solidarity is advocating for governance models whereby
there are equitable harms and beneﬁts across society and we
share our data on this premise [20, 40–42]. Data trusts have been
proposed whereby data subjects give their data to be managed by
data trustees. The trustees are then responsible for stewarding the
data for the beneﬁt of others, known as the beneﬁciaries [43, 44].
While the beneﬁt may not be for the data subjects themselves
(and so would speak to data driven research methods), the data
subjects decide on their involvement in the data trust and that
there is ongoing stakeholder and public engagement [45]. Other
proposed governance models include data commons and data
cooperatives [46–48]. The legal framework proposed under the
EHDS is thus somewhat similar to these proposals in that it is
seeking to enable the secondary use of data. There are two
notable differences: ﬁrst, as discussed, the measures under the
EHDS focus exclusively on the individual data protection concerns,
and second is the treatment of consent under the EHDS.
Despite changes to the process of consent, consent remains a
fundamental requirement in research ethics and in these other
proposed models, the data subject does have a role in deciding on
whether their data is to be part of the data trust (for example). Our
concern is that in the original proposed text, the Commission is
considering the current model of informed consent only, a model
that is indeed burdensome, costly, and challenging to continu-
ously go back and ask for consent. Broad consent and tiered
consent while suitable options, do require re-consent if the
purpose is beyond that what is speciﬁed in the consent, a process
that may frustrate the data users as the technology and potential
data use constantly changes. What is needed is a consent that is
not static but can change in accordance with the data subject’s
preferences and also potential data uses. What is not needed are
legal frameworks that provide access to data without consent.
The UK and Australia are examples where there was a public
push back to schemes that sought to share data without the
consent of the patients [8]. Such proposed schemes failed for
several reasons including poor public engagement, but they serve
as a stark reminder that a social licence and public acceptance to
access data for research cannot be assumed simply by having a
legal framework in place. The EHDS is undoubtedly introducing
new governance process for the secondary use of electronic
health data. Public trust is also critical, but legal legitimacy alone
does not automatically equate to trusted governance [49–51].
Lessons must be learned from the ELSI work in this domain to
consider how it can become a trusted governance. Empirical
research has demonstrated the importance of ongoing informa-
tion about data use, and that individuals have preference on how
their data will be used, preferences that must be respected.
This is of particular importance when one considers that under
the proposed EHDS, data can be used for purposes that the
individual did not consent, nor would have expected their data to
be used. Once passed, a general information campaign should
alert patients that their electronic health record may be used for
secondary purposes. However, at the time that they provided their
data, a patient is unlikely to have expected that their data
collected as part of their individual electronic health record will be
used for the development and training of AI, for example. Equally
participants who have donated their data to a biobank, will expect
that their data will only be used in accordance with that consent.
Undoubtedly, they would not expect that their data will be used
for purposes other than research. The EDPB/EDPS Joint Opinion on
the EHDS has pointed out that this provision on consent is
incompatible if consent has been the ground for the lawful
processing of data under the GDPR. However, this issue extends
beyond a conﬂict of laws situation as it could impact trust. Indeed,
we would have concerns about the impact this could have on
participant trust in biobank research if a biobank, for example, is
obliged to share data for secondary purposes that go beyond the
participants’ consent. The reputational damage and loss of trusted
position that likely have in their community could be untold.
The draft Report from the European Parliament raises this point
and draft amendment 13 recommends that patients can opt-out
to the secondary use of their electronic health data and to inform
them of this possibility to opt-out. This is expanded further in draft
amendment 84 that states:
C. Staunton et al.
501
European Journal of Human Genetics (2024) 32:498 – 505

## Page 5 (Section: EHDS and the return of results)

“Natural persons that are subjects to secondary use of health
data shall have the right to decline the processing of their health
data. Health data access bodies shall provide for an accessible and
easily
understandable
opt-out
mechanism,
whereby
natural
persons must be offered the possibility to explicitly express their
wish not to have all or part of their personal electronic health data
processed for some or all secondary use purposes. In situation
where natural persons explicitly express their wish to use opt-out
mechanism to data holders, data holders shall direct natural
persons to the health data access bodies.”
We endorse this position sketched out by the European
Parliament. This opt-out mechanism, if embedded in an appro-
priate thick information process [52] would provide a more equal
balance between providing access to electronic health data for
secondary purposes while also providing individuals with control
over their electronic health data. It will also ensure that patients
are empowered to have control over their electronic health data,
which is one of the aims of the EHDS.
To realize this amendment, however, conversations now need
to turn to how to manage this opt-out process. A system that
facilitates communication with individuals to describe the purpose
for which access to their data will be used and enable a response
will be required. As an opt-out system is being envisaged, a
dynamic interface that enables the provision of information to
data subjects on data use and a process to enable them to actively
opt-out will need to be developed. As this must be developed, we
would also call for consideration to extend this provision beyond
opt-out only to enable the selection of an opt-in process also for
those who would wish to have to opt-in only i.e., the default that
their data not be used unless they actively consent to the use of
their data for the proposed purpose if they so wish. Let us pause
to consider that for one moment. There have been discussions
and considerations on whether citizens have an ethical duty to
share their health information for research without consent
[12, 53]. There have also been calls for solidarity (understood in
this context as a wiliness to share data for the beneﬁt of others) to
underpin the governance of data driven research [40, 50].
However to realize solidarity-based approaches, the beneﬁts and
costs of the access to and use of data should be borne collectively.
Under the draft EHDS, the focus is on access to the data only, with
no consideration of access to the down-stream beneﬁts in
possible outputs of the use of the data. Can we really guarantee
that any downstream beneﬁts will be equally shared amongst
citizens? Leaving the issue of beneﬁt to one side, there is research
demonstrating concerns about commercial bodies having access
to data [35, 54, 55]. While we recongise the important role of
industry in the development of therapeutics and treatments,
citizens’ concerns must be adequately accounted for. Citizens who
have concerns on data sharing may be frustrated that they
constantly must opt-out of a system that they do not want to opt-
in to, except in limited circumstances. If we are designing a system
that provides for opt-out, it can also facilitate opt-in. The system
could give citizens the possibility to select opt-in, opt-out, or
indeed indicate that they are happy to share their data for any
purposes that has been approved by the new governance process.
Increasingly there are examples of the application of dynamic
consent and e-consent being integrated into research [23, 56].
Critiques of dynamic consent have raised concerns that there would
be many withdrawals leading to high drop-out rates, that the system
would be difﬁcult to manage, particularly for those who are not
digitally literate, or that the system is not scalable. Dynamic consent
does require investment in the setting up of the system, both in
terms of infrastructure and personnel. It also requires expertize in
participant engagement and communication. This is a system,
however, that will need to be built to support and manage the opt-
out and can be adapted to support an opt-in. As to the concerns
that it will lead to high dropout rates, this has not transpired in the
experience of two of the authors of this paper in the practical
application of dynamic consent in a population biobank [11].
Furthermore, high dropout rates would be more likely due to
concerns around the data use or system and not the consent
process. The solution to managing high drop out rates is not an
erosion of the choice, but an unpacking of why there are such rates
and identifying solutions to address those concerns. Participants will
also need to be informed about their responsibilities for keeping
their contact information up to date so that they can opt out or opt
in (depending on their preferences). They should also be informed
about the importance of the use of their data and the risks for
development and innovation if their data is not use. In this way,
discussions on consent, autonomy, opt-in, and opt-out, can be
presented in the context of the role of their data in wider society.
It is worth noting that although the Parliament’s draft proposal
addresses the issue of the right to autonomy of the individual, it is
not clear whether Article 33(5) also applies when consent is required
as part of national ethical requirements (as distinct from when
consent is the lawful basis of processing). If the ethical assessment
that may be required (depending on Member State law) as part of
the secondary use of data requires the use of the data to be in line
with consent, can this override the EHDS provisions on consent?
Once again there is uncertainty in the interplay between national
ethical rules and proposals under the EHDS.
EHDS AND THE RETURN OF RESULTS
In addition to creating an obligation to share data, the draft EHDS
introduces the possibility of return of results to individuals for data
that is not anonymous. Article 46(12) provides that a condition of
the data permit is that data users are to inform the HDAB of
“clinically signiﬁcant ﬁndings that may inﬂuence the health status
of the natural persons whose data are included in the dataset”. We
very much welcome this proposal as returning results to
individuals that arise in the secondary use of their data signiﬁes
respect to the participant and enables the individual to be more
fully informed about their health. However, this provision as
currently framed in the EHDS is in its infancy and we currently see
two major issues that needs to be addressed.
First, there is emerging ethical consensus that clinically
signiﬁcant and actionable research results should be returned to
participants, although there is not always clear consensus on what
clinically signiﬁcant results means in research ﬁelds such as
genetics and genomics and for various age groups. Under the
current proposal, the decision on whether to return will rest with
the HDAB alone. It is generally accepted that the return of results
should be in line with the preferences of the participants [27]. Yet,
under the current proposal, there is no role for the individual in
the decision making process on what and when to return. The
data user must share the results to the HDAB, and it is this body
that will decide on whether results shall be returned. This brings
the danger that differences in approach will arise between health
data access bodies and whether individuals obtain clinically
relevant information could depend on the relevant HDAB.
Second, for those health data access bodies who decide to
require the return of such data, this is a process that is fraught
with ethical complexities and is not as simple as just informing the
individual [26, 27, 57]. Numerous guidelines from research bodies
and consortia have attempted to ethically manage this process
and they generally centre on key principles that respects the
autonomy of the participant and their right to know or not to
know in a clear and transparent process. They may have
preferences on the type of ﬁndings to be returned, but there is
no place here for the individuals autonomous preference. It is
critical that the person returning the results has the necessary
training and skills to understand, communicate, and explain the
results and their impact. This is a process that should be included
in the ﬁnal EHDS, but it is critical that it is supported by ethical
best practice.
C. Staunton et al.
502
European Journal of Human Genetics (2024) 32:498 – 505

## Page 6 (Section: Recommendations on the way forward: enabling an ethical approach to the secondary use ofdata)

RECOMMENDATIONS ON THE WAY FORWARD: ENABLING AN
ETHICAL APPROACH TO THE SECONDARY USE OF DATA
We very much welcome the move towards furthering data sharing.
Data sharing for certain secondary purposes will likely have an
important role in protecting and promoting a healthy population.
However, it must be done in a manner that understands and actively
works to maintain the social licence and public trust in the
secondary use of data. This is particularly critical in the context of the
EHDS as the electronic health data that it is anticipated will be
shared come from areas traditionally vested in high levels of trust:
healthcare and scientiﬁc research. Any system that creates a legal
obligation to share data must be crafted in a way that does not risk
undermining trust. Loss of trust can have far-reaching implications
for medical care, deterring people from disclosing important
information. Loss of trust in scientiﬁc research risks impairing
willingness to participate in research, ultimately negatively affect
scientiﬁc research, and risks upending one of the stated purposes of
the EHDS. Currently there is insufﬁcient regard to individual rights
and interests, beyond some data protection considerations, but the
proposals do not also consider the risks beyond the individual. It
must be remembered that while data sharing may be beneﬁcial and
bring about public beneﬁt in the form of therapies or new
treatments, data can also be used to stigmatize and discriminate
[19]. Furthermore, simply because a beneﬁt is available it does not
follow necessarily that there is a fair distribution of beneﬁts resulting
from access to data. Data sharing during the COVID pandemic did
indeed lead to the quick development of vaccines, but the reality is
that once the vaccines were developed economic interests and not
need or public beneﬁt determined access [58–61].
We argue that the framework on the secondary use of data
proposed under the EHDS is contingent on an ethically sound
approach that protects the rights of participants and has oversight
mechanisms in place to mitigate against data harms beyond data
protection. Such an approach would ensure that public trust is
maintained. To achieve this, there is ﬁrst the need to shift the power
asymmetry. Under the initial proposal, the power asymmetry
between the data subject and those deciding on their data access
has widened to the point that the individual has no power. There is
scope to change this by incorporating some of the Parliament’s draft
recommendations. Processes and ultimately technical infrastructure
are needed to support the Parliament’s draft proposals and the
solution may be found in Chapter III. Chapter III is seeking to build a
system of interoperable electronic health records system. This will be
transformative and enable individuals to exercise more control over
their health data, but it currently applies to primary use (i.e.,
healthcare) only. There is a real opportunity now to incorporate the
secondary use of data as part of this system and develop an
interactive and dynamic infrastructure. Such a system can enable
individuals to express their consenting preferences, change them,
and withdraw. It can also ensure transparency and enable
individuals to be informed, thus preserving their right to information
and ability to exercise their other rights.
Second, Article 36(3) and Article 37(2)(c) provides that health
data access bodies should cooperate with stakeholders that
includes patient organizations, researchers, and ethics committees
in the exercise of their tasks, but the level of cooperation or
engagement is unclear. We argue that this should be a
requirement to involve patient representatives and ethics experts
in the composition of health data access bodies. This can ensure
that there is ethical oversight and reﬂection as part of the process
and would also be a more participatory form of governance.
Health data access bodies should also have the power to mandate
when they consider it necessary to seek REC approval as part of a
data access request process.
Third, a revised draft needs to account for the additional ELSI
concerns that go beyond data protection and re-identiﬁability in
the secondary use of data and consider how these concerns can
be addressed in the secondary use of data. Importantly the right
to autonomy, guarding against discrimination and stigmatization
for the individual as well as the risks to others in the use of data.
Equally if it is introducing a proposal on the return of results, this
should be developed in line with emerging ethical consensus on
how these results should be returned.
Finally, the reality of the proposals needs to be fully understood.
One legal framework for the secondary use of electronic health
data will bring some clarity, but differences in ethical rules remain
at a Member State level. Currently it is unclear what will occur
when the proposals under the EHDS and national ethical rules are
in conﬂict. Guidance on how to navigate these issues will be
needed, otherwise confusion could result in a deadlock in
accessing data, and the EHDS may not be operationalizable.
Changes to resolve these issues are needed to make the dream of
the EHDS a reality. In its revision we call for a legal framework that
enables access to data for secondary use in a manner that balances
the rights and interests of all stakeholders. An appropriate consent
process is only one element in this governance framework, but it is a
process that must be maintained.
REFERENCES
1. Hallinan D. Broad consent under the GDPR: an optimistic perspective on a bright
future. Life Sci Soc Policy. 2020;16:1.
2. Shabani M, Marelli L. Re-identiﬁability of genomic data and the GDPR: assessing
the re-identiﬁability of genomic data in light of the EU general data protection
regulation. EMBO Rep. 2019;20:e48316.
3. Chawinga WD, Zinn S. Global perspectives of research data sharing: a systematic
literature review. Libr Inf Sci Res. 2019;41:109–22.
4. Peloquin D, DiMaio M, Bierer B, Barnes M. Disruptive and avoidable: GDPR
challenges to secondary research uses of data. Eur J Hum Genet. 2020; http://
www.nature.com/articles/s41431-020-0596-x.
5. Staunton C, Slokenberga S, Mascalzoni D. The GDPR and the research exemption:
considerations on the necessary safeguards for research biobanks. Eur J Hum
Genet. 2019;27:1159–67.
6. Slokenberga S, Tzortzatou O, Reichel J. GDPR and biobanking - individual rights,
public interest and research regulation across Europe [Internet]. Springer. 2020.
https://www.springer.com/gp/book/9783030493875.
7. A European Strategy for data | Shaping Europe’s digital future. 2023. Available
from: https://digital-strategy.ec.europa.eu/en/policies/strategy-data.
8. Carter P, Laurie GT, Dixon-Woods M. The social licence for research: why care.
Data ran into trouble. J Med Ethics. 2015;41:404–9.
9. Muller SHA, Kalkman S, van Thiel GJMW, Mostert M, van Delden JJM. The social
licence for data-intensive health research: towards co-creation, public value and
trust. BMC Med Ethics. 2021;22:110.
10. Budin-Ljøsne I, Teare HJA, Kaye J, Beck S, Bentzen HB, Caenazzo L, et al. Dynamic
consent: a potential solution to some of the challenges of modern biomedical
research. BMC Med Ethics. 2017;18:4.
11. Mascalzoni D, Melotti R, Pattaro C, Pramstaller PP, Gögele M, De Grandi A, et al.
Ten years of dynamic consent in the CHRIS study: informed consent as a dynamic
process. Eur J Hum Genet. 2022;30:1391–7.
12. Ballantyne A. Adjusting the focus: a public health ethics approach to data
research. Bioethics. 2019;33:357–66.
13. Cheah PY, Piasecki J. Data access committees. BMC Med Ethics. 2020;21:12.
14. Staunton C, Tindana P, Hendricks M, Moodley K. Rules of engagement: per-
spectives on stakeholder engagement for genomic biobanking research in South
Africa. BMC Med Ethics. 2018;19:13.
15. Emanuel EJ, Wendler D, Grady C. What makes clinical research ethical? JAMA.
2000;283:2701–11.
16. Shuster E. Fifty years later: the signiﬁcance of the Nuremberg code. N Engl J Med.
1997;337:1436–40.
17. HHS.gov. The Belmont Report. 2010. Available from: https://www.hhs.gov/ohrp/
regulations-and-policy/belmont-report/index.html.
18. WMA - The World Medical Association-Declaration of Helsinki. 2023. Available
from: https://www.wma.net/what-we-do/medical-ethics/declaration-of-helsinki/.
19. Forzano F, Genuardi M, Moreau Y, European Society of Human Genetics. ESHG
warns against misuses of genetic tests and biobanks for discrimination purposes.
Eur J Hum Genet EJHG. 2021;8984-896.
20. Prainsack B, El-Sayed S, Forgó N, Szoszkiewicz Ł, Baumer P. Data solidarity: a
blueprint for governing health futures. Lancet Digit Health. 2022;4:e773–4.
21. Sheehan M. Can broad consent be informed consent? Public Health Ethics.
2011;4:226–35.
C. Staunton et al.
503
European Journal of Human Genetics (2024) 32:498 – 505

## Page 7 (Section: Author contributions)

22. Wendler D. Broad versus blanket consent for research with human biological
samples. Hastings Cent Rep. 2013;43:3–4.
23. Biasiotto R, Pramstaller PP, Mascalzoni D. The dynamic consent of the Coopera-
tive Health Research in South Tyrol (CHRIS) study: broad aim within speciﬁc
oversight and communication. BioLaw J. 2021;21:277–87.
24. Johnson SB, Slade I, Giubilini A, Graham M. Rethinking the ethical principles of
genomic medicine services. Eur J Hum Genet. 2020;28:147–54.
25. Caulﬁeld T, McGuire AL, Cho M, Buchanan JA, Burgess MM, Danilczyk U, et al.
Research ethics recommendations for whole-genome research: consensus
statement. PLoS Biol. 2008;6:e73.
26. Fiallos K, Applegate C, Mathews DJ, Bollinger J, Bergner AL, James CA. Choices for
return of primary and secondary genomic research results of 790 members of
families with Mendelian disease. Eur J Hum Genet EJHG. 2017;25:530–7.
27. Staunton C, Kösters M, Pramstaller PP, Mascalzoni D. Return of research results
(RoRR) to the healthy CHRIS cohort: designing a policy with the participants. J
Community Genet. 2021;12:577–92.
28. Tindana P, de Vries J. Broad consent for genomic research and biobanking:
perspectives from low- and middle-income countries. Annu Rev Genomics Hum
Genet. 2016;17:375–93.
29. Kaye J, Whitley EA, Lund D, Morrison M, Teare H, Melham K. Dynamic consent: a
patient interface for twenty-ﬁrst century research networks. Eur J Hum Genet.
2015;23:141–6.
30. Nembaware V, Johnston K, Diallo AA, Kotze MJ, Matimba A, Moodley K, et al. A
framework for tiered informed consent for health genomic research in Africa. Nat
Genet. 2019;51:1566–71.
31. Shabani M, Borry P. “You want the right amount of oversight”: interviews with
data access committee members and experts on genomic data access. Genet
Med. 2016;18:892–7.
32. Shabani M, Knoppers BM, Borry P. From the principles of genomic data sharing to
the practices of data access committees. EMBO Mol Med. 2015;7:507–9.
33. WMA - The World Medical Association-WMA Declaration of Taipei on Ethical
Considerations regarding Health Databases and Biobanks. 2023. Available from:
https://www.wma.net/policies-post/wma-declaration-of-taipei-on-ethical-
considerations-regarding-health-databases-and-biobanks/.
34. Staunton C individual rights in biobank research under the GDPR. In: Slokenberga
S, Tzortzatou O, Reichel J, editors. GDPR and biobanking: individual rights, public
interest and research regulation across Europe. Cham: Springer International
Publishing. 2022. 91–104. (Law, Governance and Technology Series). https://
doi.org/10.1007/978-3-030-49388-2_6.
35. Middleton A, Milne R, Almarri MA, Anwer S, Atutornu J, Baranova EE, et al. Global
public perceptions of genomic data sharing: what shapes the willingness to
donate DNA and health data? Am J Hum Genet. 2020;107:743–52.
36. Staunton C, Slokenberga S, Parziale A, Mascalzoni D. Appropriate safeguards and
Article 89 of the GDPR: considerations for biobank, databank and genetic research.
Front Genet. 2022;13. https://www.frontiersin.org/article/10.3389/fgene.2022.719317.
37. Slokenberga S. Scientiﬁc research regime 2.0? Transformations of the research
regime and the protection of the data subject that the proposed EHDS regulation
promises to bring along. Technol Regul. 2022;2022:135–47.
38. EDPB-EDPS Joint Opinion on the Proposal for a Regulation on the European
Health Data Space | European Data Protection Supervisor. 2022. Available from:
https://edps.europa.eu/data-protection/our-work/publications/edps-edpb-joint-
opinions/european-health-data-space
39. Assessment of the EU Member States’ rules on health data in the light of GDPR.
2023. Available from: https://health.ec.europa.eu/publications/assessment-eu-
member-states-rules-health-data-light-gdpr_en.
40. Prainsack B, Buyx A. A solidarity-based approach to the governance of research
biobanks. Med Law Rev. 2013;21:71–91.
41. Prainsack B. The “We” in the “Me”: solidarity and health care in the era of per-
sonalized medicine. Sci Technol Hum Values. 2018;43:21–44.
42. Prainsack B, Buyx A. Solidarity in biomedicine and beyond. Cambridge: Cam-
bridge
University
Press.
2021.
Cambridge
Bioethics
and
Law.
https://
www.cambridge.org/core/books/solidarity-in-biomedicine-and-beyond/
067DC974D204F6EDE679816213433456.
43. Delacroix S, Lawrence ND. Bottom-up data trusts: disturbing the ‘one size ﬁts all’
approach to data governance. Int Data Priv Law. 2019;9:236–52.
44. Milne R, Sorbie A, Dixon-Woods M. What can data trusts for health research learn
from participatory governance in biobanks? J Med Ethics. 2022;48:323–8.
45. Paprica PA, Sutherland E, Smith A, Brudno M, Cartagena RG, Crichlow M, et al.
Essential requirements for establishing and operating data trusts: practical gui-
dance co-developed by representatives from ﬁfteen Canadian organizations and
initiatives. Int J Popul Data Sci. 2020;5:1353.
46. Cook-Deegan R, Ankeny RA, Maxson Jones K. Sharing data to build a medical
information commons: from Bermuda to the global alliance. Annu Rev Genomics
Hum Genet. 2017;18:389–415.
47. Deverka PA, Majumder MA, Villanueva AG, Anderson M, Bakker AC, Bardill J, et al.
Creating a data resource: what will it take to build a medical information com-
mons? Genome Med. 2017;9:84.
48. van Roessel I, Reumann M, Brand A. Potentials and challenges of the health data
cooperative model. Public Health Genomics. 2018;20:321–31.
49. Hawkins AK, O’Doherty K. Biobank governance: a lesson in trust. N Genet Soc.
2010;29:311–27.
50. Horn R, Kerasidou A. Sharing whilst caring: solidarity and public trust in a data-
driven healthcare system. BMC Med Ethics. 2020;21:110.
51. Tindana P, Molyneux S, Bull S, Parker M. ‘It is an entrustment’: broad consent for
genomic research and biobanks in Sub-Saharan Africa. Dev World Bioeth.
2019;19:9–17.
52. Giesbertz NAA, Bredenoord AL, van Delden JJM. A thick opt-out is often sufﬁ-
cient. Am J Bioeth. 2013;13:44–6.
53. Ballantyne A, Schaefer GO. Consent and the ethical duty to participate in health
data research. J Med Ethics. 2018;44:392–6.
54. Trinidad SB, Fullerton SM, Bares JM, Jarvik GP, Larson EB, Burke W. Genomic
research and wide data sharing: views of prospective participants. Genet Med.
2010;12:486–95.
55. Kalkman S, van Delden J, Banerjee A, Tyl B, Mostert M, van Thiel G. Patients’ and
public views and attitudes towards the sharing of health data for research: a
narrative review of the empirical evidence. J Med Ethics. 2022;48:3–13.
56. Teare HJA, Prictor M, Kaye J. Reﬂections on dynamic consent in biomedical
research: the story so far. Eur J Hum Genet. 2021;29:649–56.
57. Knoppers BM, Zawati MH, Sénécal K. Return of genetic testing results in the era of
whole-genome sequencing. Nat Rev Genet. 2015;16:553–9.
58. Staff TPFC. Bill of Health. Taking data sharing seriously: public interest and solidarity
as principles for an international pandemic treaty. 2021. Available from: https://
blog.petrieﬂom.law.harvard.edu/2021/12/20/taking-data-sharing-seriously-public-
interest-and-solidarity-as-principles-for-an-international-pandemic-treaty/.
59. McMahon A. Patents, access to health and COVID-19 – The role of compulsory
and government-use licensing in Ireland. North Irel Leg Q. 2020;71:331–58.
60. McMahon A. Global equitable access to vaccines, medicines and diagnostics for
COVID-19: the role of patents as private governance. J Med Ethics. 2021;47:142–8.
61. Zohny H. Journal of Medical Ethics blog. Solidarity, trust and the governance of
data sharing during a public health emergency. 2021. Available from: https://
blogs.bmj.com/medical-ethics/2021/05/12/solidarity-trust-and-the-governance-
of-data-sharing-during-a-public-health-emergency/.
AUTHOR CONTRIBUTIONS
CS, DM, SS conceptualized the paper. CS, SS developed the texts in the paper. SS, MS,
DM provided comments and edits on all drafts of the paper. All authors approved the
ﬁnal paper.
FUNDING
CS & DM are funded by the Innovative Medicines Initiative (IMI) – FACILITATE project,
grant agreement No 101034366. Work on this article was supported by the U.S.
National Institute of Mental Health and the U.S. National Institutes of Health (award
number U01MH127690) under the Harnessing Data Science for Health Discovery and
Innovation in Africa (DS-I Africa) program. The content of this article is solely the
author’s responsibility and does not necessarily represent the ofﬁcial views of the U.S.
National Institute of Mental Health or the U.S. National Institutes of Health. SS is
funded by the Marianne and Marcus Wallenberg Foundation, project “AI and
Automated Systems and the Right to Health – Revisiting Law Accounting for the
Exploitation of Users Preferences and Values”. The authors thank the Department of
Innovation, Research and University of the Autonomous Province of Bozen/Bolzano
for covering the Open Access publication costs.
COMPETING INTERESTS
The authors declare no competing interests.
ADDITIONAL INFORMATION
Correspondence and requests for materials should be addressed to Ciara Staunton.
Reprints and permission information is available at http://www.nature.com/
reprints
Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims
in published maps and institutional afﬁliations.
C. Staunton et al.
504
European Journal of Human Genetics (2024) 32:498 – 505

## Page 8 (Section: Author contributions)

Open Access This article is licensed under a Creative Commons
Attribution 4.0 International License, which permits use, sharing,
adaptation, distribution and reproduction in any medium or format, as long as you give
appropriate credit to the original author(s) and the source, provide a link to the Creative
Commons licence, and indicate if changes were made. The images or other third party
material in this article are included in the article’s Creative Commons licence, unless
indicated otherwise in a credit line to the material. If material is not included in the
article’s Creative Commons licence and your intended use is not permitted by statutory
regulation or exceeds the permitted use, you will need to obtain permission directly
from
the
copyright
holder.
To
view
a
copy
of
this
licence,
visit
http://
creativecommons.org/licenses/by/4.0/.
© The Author(s) 2024
C. Staunton et al.
505
European Journal of Human Genetics (2024) 32:498 – 505


---

# Evaluating and Enhancing Large Language Models' Performance in Domain-Specific Medicine: Development and Usability Study With DocOA

- **Authors:** Xi Chen, Li Wang, MingKe You, WeiZhi Liu, Yu Fu, Jie Xu, Shaoting Zhang, Gang Chen, Kang Li, Jian Li
- **Issuer:** Journal of medical Internet research
- **Type:** Scientific article
- **Published:** 2024-07-22
- **Language:** en
- **DOI:** 10.2196/58158
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38833165/
- **Licence:** CC-BY

## Section: Abstract

BackgroundThe efficacy of large language models (LLMs) in domain-specific medicine, particularly for managing complex diseases such as osteoarthritis (OA), remains largely unexplored.ObjectiveThis study focused on evaluating and enhancing the clinical capabilities and explainability of LLMs in specific domains, using OA management as a case study.MethodsA domain-specific benchmark framework was developed to evaluate LLMs across a spectrum from domain-specific knowledge to clinical applications in real-world clinical scenarios. DocOA, a specialized LLM designed for OA management integrating retrieval-augmented generation and instructional prompts, was developed. It can identify the clinical evidence upon which its answers are based through retrieval-augmented generation, thereby demonstrating the explainability of those answers. The study compared the performance of GPT-3.5, GPT-4, and a specialized assistant, DocOA, using objective and human evaluations.ResultsResults showed that general LLMs such as GPT-3.5 and GPT-4 were less effective in the specialized domain of OA management, particularly in providing personalized treatment recommendations. However, DocOA showed significant improvements.ConclusionsThis study introduces a novel benchmark framework that assesses the domain-specific abilities of LLMs in multiple aspects, highlights the limitations of generalized LLMs in clinical contexts, and demonstrates the potential of tailored approaches for developing domain-specific medical LLMs.

## Section: Introduction

The rapid development of large language models (LLMs) has shown promising potential in the medical field, as demonstrated by their ability to pass the United States Medical Licensing Examination and diagnose clinical conditions [1-3]. The promising performance of LLMs in the general medical field warrants further research and exploration of their clinical performance in domain-specific medical scenarios [4,5].

Osteoarthritis (OA) is one of the most prevalent and debilitating diseases that causes pain, disability, and loss of function [6]. The global prevalence of OA is approximately 7.6% (595 million people) as of 2020 [7]. The management of OA requires complex strategies that encompass a variety of pharmacological treatments, lifestyle alterations, rehabilitation, and surgical interventions across multiple disciplines. Effective management of this condition necessitates the integration of extensive evidence-based medical data and the consideration of individual circumstances [6].

Although some LLMs have achieved commendable results in general medical question-answer (QA) tasks, substantial limitations persist in their clinical capability, particularly in complex and multifaceted diseases such as OA [8]. However, the data sets used to train LLMs are predominantly composed of general medical knowledge and lack in-depth, domain-specific content. Existing research indicates that current training data and benchmarking methodologies may be inadequate for LLMs to acquire the necessary domain-specific knowledge and clinical capabilities [4].

Additionally, LLMs may lack the ability to translate their knowledge into clinical proficiency. Despite possessing sound knowledge about certain diseases, effectively applying this knowledge to disease diagnosis remains challenging for LLMs [9]. This observation highlights the need to train and evaluate LLMs using data sets that are more closely aligned with clinical applications, thereby bridging the gap between theoretical knowledge and practical clinical usage.

To address these challenges, we proposed to build a data set that focuses on specific medical diseases, which should encompass updated evidence-based medical knowledge capable of providing both physicians and patients with expert disease-related information. In addition, real-world cases featuring patient information and treatment decisions encountered in clinical practice should be included. This repository can serve as a benchmark for testing the performance of LLMs in specific medical domains, such as OA management.

Moreover, despite the fact that LLMs have demonstrated impressive capabilities, their internal mechanisms remain unclear. This lack of transparency poses unnecessary risks to downstream applications [10], which is particularly crucial in the medical field and constitutes a significant ethical consideration [11]. Retrieval-augmented generation (RAG) offers a solution for explainability, as the RAG technique enables large models to identify the source of their answers when responding to questions. RAG is an AI framework that improves LLMs by integrating relevant information from external knowledge bases, thus enhancing the accuracy and reliability of the model's responses while also providing efficient and cost-effective access to updated external data [12]. Therefore, the integration of RAG and prompt engineering could enable the model to assimilate external knowledge bases and adhere to instructions to respond in a predetermined manner.

In general, we propose a data set framework that encompasses updated evidence-based medical knowledge, and real-world cases may effectively examine the capabilities of LLMs in clinical practice. The integration of RAG and prompt engineering may allow trained LLMs such as GPT-4 to acquire domain-specific abilities. Moreover, the management of OA serves as an ideal example in terms of its clinical significance and data volume on this research topic. Therefore, this study aimed to curate a data set for OA management, evaluate knowledge of updated evidence-based medicine for LLMs and their capabilities in clinical scenarios, and adopt RAG and instruction prompts to enhance these capabilities.

## Section: Methods

Study flow diagram. GIQA: guideline-item question-answer; MOQA: management options question-answer; QA: question-answer; real-case QA; TSQA: treatment strategy QA.

Workflow.

## Section: Methods › Overview

This study curated an OA management data set based on clinical guidelines and real-world cases. A benchmark was developed to evaluate the clinical knowledge and capabilities of LLMs for OA management. DocOA was built with instruction prompts and RAG and was tested along with other LLMs. Figure 1 illustrates the flow diagram of the study.

Study flow diagram. GIQA: guideline-item question-answer; MOQA: management options question-answer; QA: question-answer; real-case QA; TSQA: treatment strategy QA.

## Section: Methods › Data Set

This data set was developed based on key clinical guidelines and real-world patients. After the panel discussion, 6 well-acknowledged guidelines and data from 80 real-world patients were selected that included various aspects of OA management. The following guidelines were included: American Academy of Orthopedic Surgeons management of OA of the knee (Nonarthroplasty) [13]; NICE (National Institute for Health and Care Excellence) guideline for OA in over 16s [14]; Osteoarthritis Research Society International (OARSI) guidelines for the nonsurgical management of knee, hip, and polyarticular OA [15]; Royal Australian College of General Practitioners Guideline for the management of knee and hip OA [16]; American College of Rheumatology/Arthritis Foundation (ACR) Guideline for the Management of Osteoarthritis of the Hand, Hip, and Knee [17]; European League Against Rheumatism (EULAR) recommendations for the nonpharmacological core management of hip and knee OA [18]. Between April 1, 2023, and October 1, 2023, a total of 80 patients diagnosed with OA and who had received OA management at our hospital were randomly selected. The patient information, including age, sex, height, weight, BMI, laterality of knee involvement, medical history, level of pain, mechanical symptoms, physical examination results, and radiographic findings, was retrieved. All identifiable information was concealed to maintain confidentiality.

The OA benchmark aims to test the clinical capabilities of LLMs at 4 levels within the context of evidence-based medicine, ranging from domain-specific knowledge to clinical capabilities. The benchmark assesses the performance of LLMs pertaining to OA knowledge, summarizing the knowledge to formulate recommendations for specific management options, providing tailored management options for different patient populations, and formulating personalized management plans for real-world cases.

## Section: Methods › Assistant With RAG and Instruction Prompting

DocOA, a specialized assistant, was developed based on the GPT-4-1106-preview model, which integrates instruction prompts and RAG to enhance performance. The instruction prompt emphasized its role in providing evidence-based medical insights and personalized management programs guided by evidence-based medicine. The DocOA strictly adheres to facts, avoids speculation, and clearly states its limitations. Moreover, it maintains a professional and informative tone suitable for medical discussions.

RAG has been used to respond to various OA-related queries. The RAG integrates a model's language generation capabilities with a retrieval system, enabling access to specific information from external sources [19]. Of the several RAG techniques and data structures tested, the retrieval function from OpenAI was adopted, and the most optimal data structure was selected and converted into the JSON format for optimal retrieval accuracy. In response to OA-related queries, the RAG enables the assistant to dynamically pull relevant data from the external data set as it generates responses. The workflow of the assistant is illustrated in Figure 2.

The assistant block details the core of the DocOA system, using a base model of GPT-4-1106-preview. The description within the block serves as an instruction prompt that outlines the system's role. The assistant’s functionality includes a retrieval tool that accesses external data set.

The system receives input from thread blocks in the form of questions about OA management and requests evaluation. This includes user messages with specific queries regarding OA treatment and detailed instructions for the system to follow.

The execution command then triggers the processing of input data through the DocOA system. Through RAG, DocOA incorporates external information from the knowledge database and follows the instructions to generate the final output. Simultaneously, based on instructional prompts, DocOA is capable of providing final outputs tailored to the user, whether they are patients or professional doctors, in the corresponding style.

Workflow.

## Section: Methods › Models Testing

DocOA and the 2 base models, GPT-3.5 and GPT-4, were tested against the OA benchmark. Each question was presented 5 times to each model to assess the robustness of its performance. Additionally, the zero-shot chain of thoughts prompt technique was tested for GPT-3.5 and GPT-4 to determine whether it outperformed the input-output technique.

Evaluation of LLMs’ Performance

## Section: Methods › Objective Evaluation

The model-generated responses were compared with predefined correct answers for each subset of the benchmark. An answer was considered accurate if LLM provided correct knowledge (recommendation status and recommendation strength) about the treatment option and predicted the correct treatment recommendation (treatment appropriateness) for a specific patient profile or individual patient.

The human evaluation framework is an effective approach for identifying the gap between LLMs and clinical experts [3]. In this study, human evaluation was performed by both physicians and patients. A total of 80 items from the OA benchmark were randomly selected for a detailed human evaluation framework.

A panel of 5 experienced physicians evaluated the outputs from LLMs. The sequence of answers was randomized and the generating models were anonymized to ensure that the evaluation was conducted without any knowledge of the model that generated them. Specifically, each evaluator independently assessed the sampled responses. All sampled responses were compiled into an Excel (Microsoft Corp) spreadsheet. The model labels corresponding to the responses were concealed. The evaluation metrics were established based on a previous study with modifications [3]. The physician assessed the quality of the responses in the following domains: inaccurate content, relevance, hallucinations, missing content, likelihood of possible harm, extent of possible harm, and possibility of bias. The ability of LLM to achieve correct comprehension, retrieval, and reasoning was assessed using the method described in a previous study [20]. Patient evaluation was conducted by assessing the user intent fulfillment and helpfulness of the content. The detailed descriptions of each human evaluation metric are provided in Multimedia Appendix 1.

## Section: Methods › Statistical Analysis

All statistical analyses were performed using the SPSS 25.0 software (IBM Corp) and GraphPad Prism (version 8; GraphPad Software). Discontinuous data are expressed as incidence and rate and analyzed using the chi-square test for differences. A P value less than .05 indicated statistical significance.

## Section: Methods › Ethical Considerations

Real-case QA (RCQA) includes treatment recommendations for 80 real cases. The study have obtained approval from the Medical Ethics Committee of Sichuan University (approval number: 2023; review number 2277). Participants were informed that the study would need to use relevant data including clinical symptoms, imaging reports and physical examination data, but they would not receive any intervention measures and their personal identifiable information was anonymized. This study does not involve compensation.

## Section: Results

Results of objective evaluation. (A) Accuracy of each model against each subset of benchmark. (B) Inaccuracy analysis for DocOA due to wrong answer and failure to access external data. GIQA: guideline item question-answer (QA); MOQA: management option QA; TSQA: treatment strategy QA; RCQA: real-case QA.

Accuracy of each model against the osteoarthritis benchmark.

Accuracy of different prompt techniques against the osteoarthritis benchmark.

Results of human evaluation for LLMs’ comprehension, retrieval, and reasoning ability. (A) Evidence of correct comprehension. (B) Evidence of correct retrieval. (C) Evidence of correct reasoning.

Results of human evaluation by patients. (A) Patient intent fulfillment. (B) Patient helpfulness.

## Section: Results › OA Benchmark

The benchmark comprised 4 subsets of QA evaluations designed to test the performance of LLMs across a spectrum ranging from domain-specific knowledge to practical capability. Guideline-item QA (GIQA), which was developed based on specific items extracted from the clinical guidelines, evaluates the LLMs’ knowledge of these well-established standards. The GIQA comprised 337 items. Management options QA (MOQA) included summarized recommendations for specific treatments from the included clinical guidelines. The MOQA, which comprised 145 items, evaluated LLMs’ knowledge of specific treatment options as well as their ability to summarize medical evidence. Treatment strategy QA (TSQA), which included treatment recommendations for different patient populations, provided treatment recommendations based on the patient’s age, clinical presentation, and other factors. The TSQA, which comprised 216 items, evaluated the capability of LLMs to derive treatment recommendations for specific patient types. RCQA included treatment recommendations for 80 real-world patients. The RCQA, which comprised 80 items, evaluated LLMs’ capability in formulating treatment recommendations in a more complicated scenario in which individual information is provided, mirroring real-world clinical decision-making. This data set is available on GitHub [21]. Examples of each QA type are shown in Multimedia Appendix 2.

## Section: Results › Objective Evaluation

The accuracy of GPT-3.5 in GIQA, MOQA, TSQA, and RCQA was 0.26, 0.22, 0.01, and 0.03, respectively. The accuracy of GPT-4 in GIQA, MOQA, TSQA, and RCQA was 0.38, 0.30, 0.07, and 0.01, respectively. The accuracy of DocOA in GIQA, MOQA, TSQA, and RCQA was 0.92, 0.87, 0.88, and 0.72, respectively. The accuracy of each model against the benchmark is presented in Table 1 and Figure 3A. As shown in Figure 3A, the degree of accuracy significantly decreased: GIQA˃MOQA˃TSQA˃RCQA. As shown in Figure 3B, DocOA reported 111 failures in accessing the external data set, which accounted for 12.4% of the inaccurate answers generated.

Zero-shot chain of thoughts prompt techniques were adopted for GPT-3.5 and GPT-4. Compared with the input-output prompt technique, no significant improvements in model performance were observed. The results are summarized in Table 2.

Results of objective evaluation. (A) Accuracy of each model against each subset of benchmark. (B) Inaccuracy analysis for DocOA due to wrong answer and failure to access external data. GIQA: guideline item question-answer (QA); MOQA: management option QA; TSQA: treatment strategy QA; RCQA: real-case QA.

Accuracy of each model against the osteoarthritis benchmark.

Accuracy of different prompt techniques against the osteoarthritis benchmark.

## Section: Results › Human Evaluation Results

From each of the GIQA, MOQA, TSQA, and RCQA, 20 items were randomly selected along with the corresponding responses generated by each model. A total of 1200 outputs were evaluated by physicians and patients. The results of the human evaluations of GPT-3.5, GPT-4, and DocOA revealed distinct outcomes across several aspects. A few examples have been selected and summarized in Multimedia Appendix 3, demonstrating how to apply the human evaluation framework to assess sampled responses.

Multimedia Appendix 4 shows the human evaluation results for the models’ output. The rate of inaccuracy was the highest for GPT-3.5 (57%, n=1200), followed by GPT-4 and DocOA at 50% (n=1200) and 19.3% (n=1200), respectively. All the models achieved high relevance and infrequently produced hallucinatory content in their responses. GPT-3.5 had a higher proportion of responses with missing content (22%, n=1200) than GPT-4 (16.4%, n=1200) or DocOA (16.5%, n=1200). GPT-3.5 presented a higher likelihood of generating harmful content (20%, n=1200) than GPT-4 (11.3%, n=1200) and DocOA (8.3%, n=1200). Moreover, GPT-3.5 was associated with a higher risk of causing severe harm (10.5%, n=1200) than GPT-4 (5.5%, n=1200) and DocOA (3.5%, n=1200). The likelihoods of potentially biased content were 13.3% (n=1200), 9.5% (n=1200), and 2.8% (n=1200) for GPT-3.5, GPT-4, and DocOA, respectively. The results of the human evaluation for each subset benchmark are listed in Multimedia Appendices 5-7. The results showed a substantial decrease in performance in terms of inaccurate content and missing content (GIQA˃MOQA˃TSQA˃RCQA).

Figure 4 shows the results of the LLMs’ ability to assess correct comprehension, correct retrieval, and correct reasoning. Regarding the correct comprehension of the question, the response rate of DocOA was 91% (n=1200), followed by GPT-4 (86%, n=1200) and GPT-3.5 (82.5%, n=1200). DocOA was able to correctly recall and present complete, relevant information in 65.8% (n=1200) of the responses, followed by GPT-4 (14.3%, n=1200) and GPT-3.5 (12.0%, n=1200). In terms of subset evaluation, the results showed comparable performance in comprehension and reasoning among the different models, whereas a substantial performance decrease was found in correct retrieval across GIQA, MOQA, TSQA, and RCQA.

The results of patient evaluations are shown in Figure 5. DocOA achieved a success rate of 71.3% in fulfilling patient intention, with GPT-4 at 39.8% (n=1200) and GPT-3.5 at 36.5% (n=1200). Of the responses generated by DocOA, 75.8% (n=1200) were considered to be at least somewhat helpful, compared to 47% (n=1200) for GPT-3.5 and 47.75% (n=1200) for GPT-4. For GPT-3.5 and GPT-4, the subset evaluation showed a substantial decrease in intent fulfillment and helpfulness as the tasks shifted from domain-specific knowledge to personalized treatment recommendations.

Results of human evaluation for LLMs’ comprehension, retrieval, and reasoning ability. (A) Evidence of correct comprehension. (B) Evidence of correct retrieval. (C) Evidence of correct reasoning.

Results of human evaluation by patients. (A) Patient intent fulfillment. (B) Patient helpfulness.

## Section: Discussion

This study introduced a benchmark framework to assess the performance of LLMs in specific medical domains. Using OA as a case study, this framework is the first to evaluate LLMs across a spectrum, from domain-specific knowledge to clinical applications in specific disease management. The incorporation of human evaluation provides multiple dimensions of assessment that are of considerable interest to clinical practitioners and patients, making it an essential tool for evaluating the clinical capabilities of LLMs.

The study found that the integration of RAG and instructional prompts substantially improved the domain-specific capabilities and explainability of general-purpose LLMs without additional training. By contrast, general-purpose models such as GPT-3.5 and GPT-4 exhibit unsatisfactory performance when benchmarked against OA management. Additionally, both models demonstrated a marked decline in performance as tasks shifted from domain-specific knowledge to personalized treatment recommendations. Overall, the findings of this study demonstrate a cost-effective method for evaluating and enhancing the capabilities of LLMs in specialized medical fields.

Examples of clinical practice. (A) How DocOA provides exercise guidance for patients with OA. (B) How DocOA provides doctors with clinical evidence for exercise guidance in OA, as well as the clinical evidence the answer is based on.

## Section: Discussion › Domain-Specific Medical Benchmark

Although benchmarks targeting general medical knowledge have been previously developed [22-24], recent research has suggested that these benchmarks are only preliminary indicators of medical knowledge. The absence of tailored benchmarks in specific domains remains a potential challenge for evaluating the clinical effectiveness of LLMs [4,25]. Therefore, we developed a domain-specific benchmark focused on disease management for OA, which was selected for its prevalence, substantial disease burden, and complexity of its management strategies [6,7]. This benchmark was designed to test the domain-specific knowledge and clinical capabilities of LLMs. The benchmark comprised 4 parts, each testing the ability of LLMs at different levels, including the ability to provide evidence-based knowledge, summarizing knowledge to formulate recommendations, providing management recommendations for different patient populations, and formulating personalized management plans for real-world patients. The benchmark was constructed based on established clinical guidelines and real-world patient information. Clinical guidelines offer comprehensive reviews of updated evidence and expert opinions, making them reliable sources of domain-specific medical knowledge. Through panel discussions involving physicians and data scientists, the questions were designed in a hybrid format, integrating both definitive and interpretative elements. Using this benchmark, we confirmed that general-purpose LLMs exhibit suboptimal performance in specialized domains. A significant performance gap was observed between domain-specific knowledge and clinical proficiency. This highlights the challenges faced by general-purpose LLMs in effectively applying specialized knowledge to clinical scenarios.

## Section: Discussion › Human Evaluation Framework

Human evaluation is a crucial component in assessing the medical capabilities of LLMs and offers a multidimensional assessment of their clinical capabilities. In this study, the human evaluation framework was modified based on a previous study, and hallucinations and relevance were added as additional criteria [3,4]. The evaluation criteria included accuracy, relevance, hallucinations, omissions, potential harm, and biased content. Moreover, the performance of LLMs in question comprehension, information retrieval, and medical reasoning was evaluated, as these are crucial abilities in tailoring patient-specific treatment. Patient evaluations primarily determine how responses address the user’s intent and helpfulness. Although previous studies indicate a notable gap between objective benchmarking and human evaluation, our findings reveal a smaller discrepancy [3]. This could be attributed to the different knowledge domains and designs of the QA structure in this benchmark. The results of our study suggest that the GPT-3.5, GPT-4, and DocOA performed well in terms of hallucinations, comprehension, reasoning, and relevance. DocOA outperformed the other models in terms of accurate information, correct retrieval, and helpfulness as perceived by patients. This indicates that although generalized models are proficient in some areas, they remain inadequate in delivering the qualified responses required in a clinical context.

## Section: Discussion › Augmenting LLM With Domain-Specific Ability

Several techniques are available for developing medical LLMs, which primarily include integrating domain-specific knowledge during the training phase through techniques such as reinforcement learning with human feedback [26-28]. However, in this study, we focused on enhancing already-trained LLMs, such as GPT-4, by using a suite of techniques, including RAG and instruction-based prompts. Similar methodologies have been applied to the development of specialized LLMs for chemical domains [29].

This approach was adopted for the following reasons: first, augmenting an existing model such as GPT-4 is more cost-effective than training a new model from scratch; second, advanced general-purpose models have been trained on diverse data sets, providing a broad base of general knowledge that can be beneficial for understanding and contextualizing domain-specific information; third, techniques such as RAG and specialized prompting offer the convenience of being adjustable and refined over time, enabling easy adaptability to new evidence in the fast-evolving field of medicine.

Among these reasons, the role of RAG in this study needs to be emphasized. Explainability has always been a problem to be addressed in the application of LLMs, and it is also one of the ethical considerations in their application in the medical field. RAG enables the model to identify the source on which the generated answer was based, which significantly improves the explainability of the model. In this study, the knowledge base was structured in a way that allows RAG to identify the clinical evidence that the answer was based on. When DocOA generates an OA-relevant answer, it identifies the evidence on which the answer is based and makes it clear for professionals to evaluate the rationale and accuracy of its response. In general, provided with reliable and professional sources, RAG significantly improved the explainability and accuracy of LLMs in medical care.

Our results demonstrated that GPT-4 can effectively acquire domain-specific knowledge and clinical capabilities in the management of OA through a combination of approaches, including RAG and instruction prompts. This strategy can also be applied cost-effectively to other medical domains.

Nonetheless, the efficacy of the RAG is contingent upon factors such as the size and quality of the data, retrieval techniques used, and the underlying architecture of the LLM in use [30]. The evaluation results showed that DocOA was able to correctly understand the clinical question and avoid hallucinations. The fundamental reason for the errors stems from the inherent limitations of the RAG technology, where the retrieved information may sometimes be incomplete or may not adequately address the question.

In RAG, the query process is the key determinant of the information retrieved from the external knowledge base. In the query process, text is converted into an array of floating points. The entire array corresponds to a point in an n-dimensional space, which is known as the text vector, also referred to as an embedding [31,32]. The distance between vectors, which corresponds to semantic similarity, can be calculated. Therefore, by calculating semantic similarity, the query process retrieves the information from the external knowledge base that is considered most relevant to the query posted by the LLM. However, this process is sometimes uncertain because the most appropriate answer does not necessarily yield the highest similarity score. For example, in GIQA, the question is, “Is Walking aids, assistive technology and adaptations at home and at work recommended for Physical Treatment of Knee osteoarthritis according to 2013 EULAR recommendations for the nonpharmacological core management of hip and knee osteoarthritis?” For this question, out of the 5 responses generated by LLM, 4 incorrectly state “recommend” when the correct answer should be “may be used.” The error occurred because only a portion of the information was retrieved. However, neither the complete information nor the key information, which contains the answer, was retrieved. More specifically, if the retrieved information was “The frequent use of assistive technology and the high satisfaction rates with its use indicate that walking aids, assistive technology, and adaptations are important and useful for people with hip or knee OA.” The model might be misled to generate the incorrect answer.

Generally, enhancing the effectiveness of RAG is an ongoing effort in the field of computer science, and the effectiveness of RAG is likely to keep increasing with the rapid development of LLMs and RAG technologies.

## Section: Discussion › The Potential Value of DocOA in Future Clinical Practice

DocOA has shown promising potential in clinical practice due to its proficient OA management knowledge and the ability to explain its answer. Previous studies have shown general-purpose LLMs to be limited in medical specialties such as nephrology, ophthalmology, and OA. The versatile and unverified training data could contain misleading medical information, which led to inaccurate answers. On the other hand, DocOA has shown good results in providing evidence-based OA management knowledge and formulating personalized treatment plans. To adopt DocOA in clinical practice, it is designed to answer patient queries and doctor queries differently, as shown in Figure 6. When generating answers for medical professionals, it is able to generate answers based on selected high-quality clinical evidence and accurately identify the corresponding references, thus providing explainable and evidence-based answers.

Examples of clinical practice. (A) How DocOA provides exercise guidance for patients with OA. (B) How DocOA provides doctors with clinical evidence for exercise guidance in OA, as well as the clinical evidence the answer is based on.

## Section: Discussion › Limitations

This study has several potential limitations that need to be addressed. First, OA management is highly complex, and our current data set remains limited and requires continuous supplementation and updating. Therefore, establishing specialized groups dedicated to building and updating these LLM databases is imperative for diverse medical applications. Second, our reliance on English sources could restrict the applicability and inclusivity of our findings across different linguistic and cultural contexts. Third, although there have been human evaluations of clinical case data, the augmented model has not yet been tested in a real-world clinical setting. These limitations highlight the necessity for ongoing development and a comprehensive, multidimensional approach for evaluating LLMs in the medical field.

## Section: Discussion › Conclusions

In this study, we introduce a novel benchmark framework designed to evaluate the capabilities of LLMs in specific medical domains, with OA serving as a case study. This framework assesses LLMs in terms of medical knowledge, evidence summarization, and clinical capabilities. Through a combination of objective measures and human evaluations, we identified the limitations of generalized LLMs in clinical contexts. Furthermore, our study demonstrated that DocOA, which integrates RAG and instructional prompts, significantly improves both the domain-specific performance and the explainability of LLMs. This approach is a potentially cost-effective strategy for developing domain-specific medical LLMs.


---

# Evaluating Molecular Complexity with Open-Source Machine Learning Approaches to Predict Process Mass Intensity

- **Authors:** Nicole Tin, Mandeep Chauhan, Kennedy Agwamba, Yibai Sun, Astrid Parsons, Philippa Payne, Remus Osan
- **Issuer:** ACS omega
- **Type:** Scientific article
- **Published:** 2024-06-24
- **Language:** en
- **DOI:** 10.1021/acsomega.4c02427
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38973894/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThe application of green chemistry is critical for cultivating environmental responsibility and sustainable practices in pharmaceutical manufacturing. Process mass intensity (PMI) is a key metric that quantifies the resource efficiency of a manufacturing process, but determining what constitutes a successful PMI of a specific molecule is challenging. A recent approach correlated molecular features to a crowdsourced definition of molecular complexity to determine PMI targets. While recent machine learning tools show promise in predicting molecular complexity, a more extensive application could significantly optimize manufacturing processes. To this end, we refine and expand upon the SMART-PMI tool by Sheridan et al. to create an open-source model and application. Our solution emphasizes explainability and parsimony to facilitate a nuanced understanding of prediction and ensure informed decision-making. The resulting model uses four descriptors—the heteroatom count, stereocenter count, unique topological torsion, and connectivity index chi4n—to compute molecular complexity with a comparable 82.6% predictive accuracy and 0.349 RMSE. We develop a corresponding app that takes in structured data files (SDF) to rapidly quantify molecular complexity and provide a PMI target that can be used to drive process development activities. By integrating machine learning explainability and open-source accessibility, we provide flexible tools to advance the field of green chemistry and sustainable pharmaceutical manufacturing.

## Section: Introduction › Process Mass Intensity

Process mass intensity (PMI) is a key metric for measuring the efficiency of chemical processes, as benchmarked by the ACS Green Chemistry Institute Pharmaceutical Roundtable.1 As drug candidates advance throughout the drug development lifecycle, PMI calculations are often used to capture progress toward more sustainable manufacturing and to drive further development.

PMI for a given synthesis is calculated as

Forecasting what constitutes a “successful” PMI for the manufacturing process for a given molecule is an unresolved industry challenge. In the absence of a “target” PMI, it is challenging for chemists to gauge if the resource efficiency of the process is on target, exceeding expectations, or in need of additional optimization. The comparison of the PMI of a process under development to an ambitious target PMI will help drive the incorporation of green chemistry and deliver sustainable manufacturing processes.

Despite not having a precise theoretical way to predict this feature, its estimates are extremely important in decision-making and process sustainability evaluation. Recently, it has been shown that a “target” PMI can be set for a given molecule through the molecular weight (mw) and the calculation of its estimated molecular complexity (c).2 This is given by

The two variables, overall PMI and molecular complexity, share a positive linear correlation, where it is generally known that complex molecules have worse resource efficiency. Thus, the complexity of an active pharmaceutical ingredient (API) has far-reaching implications in terms of the challenges and efficiency of its manufacturing.

## Section: Introduction › Molecular Complexity

Molecular complexity is commonly agreed to be an attribute intrinsic to a molecule that can affect chemical, material, and biological processes such as synthetic ease3−8 and sustainability.9,10 Generally the term refers to the intricacy and interactions in the internal structure of a molecule, however, the multidimensional nature of molecules represent a challenge to creating one summary metric of complexity.

Creating a definition of molecular complexity is a multidisciplinary problem, with applications and solutions coming from domains in math, physics, chemistry, and biology. While many solutions exist, none have been universally adopted.11 Molecules are naturally viewed as graphs; approaches in graph theory analyze topology to develop graph invariants, such as the Zagreb or Weiner Indices, that can determine the structural properties of molecules.12 Information theoretic measures, such as Shannon entropy, are also widely used in complexity science to capture diversity or degree of uniformity.13−16

In pharmaceutical chemistry, linear combinations of factors have been used as a proxy for complexity. Those factors usually include molecular weight and counts of attributes, such as stereocenters, rings, and functional groups.3,5,10,17 Increases in computational power and advances in AI/ML have enabled researchers to develop data-driven approaches that can model these complex intuitions. A pivotal method by Sheridan et al. proposed one such model based on crowdsourced votes on a diverse set of molecules.18 From the votes of 386 chemists, they found that the notion of complexity is independent of the chemistry subfield (i.e., process, analytical, medicinal, computational, etc.). A different approach focused on creating a model that is time dependent, asserting that complexity changes over time with respect to the available synthetic technology.19

There is a gap between the former theoretical and latter data-driven approaches to complexity. Theoretical models like those developed by Bertz, Bonchev, and Proudfoot use our inherent understanding of graphs or information theory to create explicit and transparent solutions.13−15,20 The need for similar transparency in data-driven models is increasingly being recognized, with suggested standards for AI/ML in pharmaceutical development emerging recently from the FDA.21 There is a need for data-driven algorithms to be secure, reliable, and interpretable; when used in decision-making, the model should be informative of the mechanisms that drive the nature of prediction.22−24 Most powerful methods in machine learning are not interpretable, still some are more interpretable than others. Posthoc “explainable” wrapper methods have been developed to approximate the learned mechanisms under the black box. Reducing the input dimension space can also dramatically increase understanding while also improving learning.

## Section: Introduction › Molecular Descriptors

Experimental and theoretical molecular descriptors have been used to capture information about a molecule related to its biological or physical properties.25,26 Representing a molecule as a vector of descriptors, rather than as a graph or raw fingerprint, allows for a clear interpretation of the weighing schemes of contributing factors.

Zero-dimensional (0D) descriptors are easily observed features of a molecule derived from the chemical formula. They include molecular weight or number of heteroatoms and ring types.

One-dimensional (1D) descriptors encode attributes or substructures into a binary or hashed vector, known as a fingerprint. Unlike human fingerprints, however, this representation is not unique and can instead represent several molecules.

Two-dimensional (2D) descriptors use the molecular graph (topology) as a representation or as an input to a computation that yields a value. Some 2D descriptors, like the Weiner Index, also align with experimental measures.27

Three-dimensional (3D) descriptors capture geometric or topographical information. One such descriptor is the polar surface area (PSA) that uses the 3D molecular conformation to evaluate the surface area of polar atoms.28,29 Since these are inherently sensitive to the conformation of the molecule, they are less common but are powerful measures containing higher information content.

Overall, using these descriptors to understand the factors that define molecular complexity can improve decision-making and understanding for goal-setting PMI.

## Section: Introduction › Open SMART-PMI

In this paper, we evaluate the SMART-PMI and compound complexity tools developed by Sherer and Sheridan and adapt them for wider community use in support of green chemistry and process development acceleration.9,18 The importance of making open-source tools to support computational green chemistry’s framework cannot be overstated, as it benefits the broader community by publicizing previous advancements, encourages embracing uniform standards in the pharmaceutical industry, and facilitates the development of cost-efficient and flexible solutions.

Here, we relate machine learning principles to the retro-application of molecular complexity and make this knowledge open source alongside the source code. While we are not the first to model molecular complexity, we have initiated open-source collaboration and added interpretability to build upon the foundations of this important model. We show that the most successful algorithms, namely, random forest models, can succinctly model molecular complexity and can provide clear explainability to the user. The resulting models have different levels of complexity, with the simplest one using only four descriptors.

## Section: Methods › Background

The code for SMART-PMI reported by Sheridan et al. is publicly available on their GitHub repository (https://github.com/Merck/compoundcomplexity/).9 The crowdsourced information for compound complexity published by Sherer et al. includes 1775 nonproprietary drug-like molecules in the Supporting Information.18 The votes on compound complexity from chemists range from 1 to 5, with 1 representing the simplest and 5 indicating a highly complex compound. The votes are summarized by the average score per molecule, denoted as mean complexity. The reported metrics for their random forest model had an 88% R2 and RMSE of 0.27, while the standard deviation of votes agreement was 0.75. A four-term linear model was also shown as a simpler alternative, though with an 80% CV-R2. As the random forest model is the focal point of both papers and has higher performance, we use it as the primary point of comparison. There were two primary complications in using this model. 186 of their 207 descriptors are sourced from the licensed Molecular Operating Environment (MOE) software, and the compound complexity package was written in several languages including Perl, which has waning influence in the field. The dataset and model were a pivotal step forward in understanding the makeup of molecular complexity.

## Section: Methods › Data Preparation

RDKit and Mordred are free and open-source cheminformatics libraries written in Python that enable easy calculation of many 0D–3D descriptors.30,31 Inputs require the simplified molecular-input line-entry (SMILES) ASCII string representation, which can be transformed from a molecule’s SDF file. RDKit and Mordred were used to generate a set of over 1500 initial descriptors. Throughout this work, the terms “descriptor” and “feature” are used synonymously.

Of the annotated 1775 molecules from Sheridan et al., 44 (2.5%) were unable to be sanitized by RDKit due to inconsistent valence electrons and were excluded from preprocessing and training. Of these molecules, 39/44 came from the MDL Drug Data Report (MDDR) database. This dataset was split into a 70:30 training and test set, and the model would be evaluated with 5-fold cross-validation. To reduce collinearity and improve model performance, features were pruned through several preprocessing steps. Mordred uses a specialized error object encoding; thus, any descriptor that comprised largely of the latter was removed. All of the above steps were performed on the entire dataset to capture the largest set of descriptors that would be unable to be performed on an incoming molecule. Then, to prevent leakage, where information from the hold-out dataset is used in training the model, the following preprocessing involving statistics of interest was only performed on the training set. The resulting statistics derived from the training set are later applied to transformations on the test set and future molecules. Each feature was scaled using min-max normalization. Normalization is a standard procedure for preparing ML inputs but is also crucial for comparing coefficients across models. Features with low information content (defined as variance) less than 10–5 were removed. Post-processing, the dataset consisted of 1196 descriptors.

## Section: Methods › Model Selection

Several architectures were tested to find the optimal algorithm for learning complexity (y) from a set of descriptors (X). In accordance with the original SMART-PMI paper, linear and ensemble methods were tested. Spatial methods and neural networks were additionally evaluated. Each model takes a different approach to learning the behavior of mean complexity, and each comes with trade-offs. While it is important to find a well-performing model, model simplicity is highly valued, as it is paramount to understanding the mechanisms driving prediction. A further discussion of the models and trade-offs can be found in the Supporting Information.

## Section: Methods › Feature Selection

To refine the model and reduce dimensionality, embedded and wrapper methods were used to select features. The methods used are complementary to each other and paint a picture of how features contribute to prediction. Toward the aim of understanding the modeling behavior and the contributing factors, we selected descriptors as chosen by high-performing models and their feature importance rankings.

Machine learning models typically optimize coefficients for each descriptor, which can be scrutinized to determine feature importance. Random forest measures a feature’s mean decrease in impurity (MDI), which is an implicit method the model uses to evaluate its importance. Permutation importance calculates the decrease in model performance when a feature is randomized and is helpful as it can be computed across models.

Another method, SHAP (Shapley additive explanations), is widely employed to add interpretability to a model.32,33 Features are analyzed as players within a game, where the features compete to influence prediction. SHAP is then able to allocate the contributions of each feature toward the predicted value for a particular instance. SHAP values can be aggregated across all instances to create average absolute scores for each feature. We can compare model coefficients and SHAP rankings to identify consensus important descriptors and eliminate features with little to no effect on modeled complexity.

## Section: Methods › Interaction Terms

Introducing interaction between terms is another way of modeling nonlinearity. Without interaction terms, independent variables could be interpreted as having a unique effect on the dependent variable, each with its own contribution. As we have a mix of physiochemical and topographical attributes, we would expect that the effect of one descriptor varies for different values of another descriptor. To maintain low computation times, we did not consider all possible interaction terms. Rather, we focus on product and quadratic terms that were generated for features filtered through selection.

## Section: Methods › Model Evaluation

It is expected that labeling molecules at the extreme ends of complexity would be the most difficult for the model, as the surveyed values of Sheridan et al.’s mean complexity follow a right-tailed normal distribution, and so there are the fewest ratings of 1, 4, 4.5, and 5 (Figure S1). Thus, negative root mean square error (denoted as −RMSE) was targeted as the primary metric when comparing models and methods, which gives sensitivity to large errors. We take the negative RMSE to standardize interpretation, where higher values indicate better fit, and the maximum theoretical value is 0. For comparing standard linear goodness-of-fit, the coefficient of determination R2 is used. However, R2 increases with the number of dimensions in the model, which is an important consideration in our modeling. Accordingly, adjusted R2 was additionally considered as it corrects for the number of dimensions in the model, where R2 increases accordingly. R2 is given by

where ŷ is the predicted value and adjusted R2 is

Fivefold cross-validation was further applied to each metric to generalize model performance.

## Section: Results

In summary, we focus on the evaluation of the three models: our replication of the benchmark model and feature set by Sheridan et al. (MK-207); the initial model using the full set of open-source descriptors (GS-1196); a parsimonious model using only four open-source descriptors (GS-04) (Figure 1). The model’s naming convention is described by the developer and the number of features used. Each of the three models is high performing, with an average squared prediction error that is lower than the chemists’ vote variability (0.75). Still, each model comes with unique advantages and trade-offs, and each informs our understanding in different ways. The initial model is used to rank the full set of features specifically by their contribution to the predicted y variable, mean complexity. To improve accuracy and simplicity, additional interaction terms are generated for those top features and are used in evaluating a suite of models. The final parsimonious model has comparable error to the high-performing baseline and uses only four molecular descriptors.

The benchmark random forest model shared by Sheridan et al. was replicated using attributes generated from Merck’s Compound Complexity repository and a temporary MOE software license. In a Python environment and hyperparameter tuning, we were only able to achieve cross-validated R2 scores around 84%, as opposed to the 88% reported. While differences could be attributed to the former factors, hyperparameters such as the optimization function for node splitting, in conjunction with cross-validation, should be sufficient for reproducing results. Under the given environment, the accuracy of the model appears very similar, accounting for random deviation.

Test set predictions vs true mean complexity for the random forest model trained on each of the three datasets. (a) Our replication of the benchmark model and feature set by Sheridan et al. (MK-207), (b) the initial model using the full set of open-source descriptors (GS-1196), and (c) a parsimonious model using only four open-source descriptors (GS-04). The underlying contour plot represents the kernel density estimate, where the darkness of the rings increases with the density of points.

Coverage of feature sets. (a) Bar chart of open-source features that have over 94% correlation coefficient with an original descriptor. Several original descriptors can be summarized by an open-source feature. (b) Histogram of the original descriptors from Sheridan et al. Each bar measures the maximum correlation of an original descriptor with any open-source descriptor. (c) Histogram measuring the maximum correlation coefficients of an open-source descriptor to any original descriptor. The new set of open-source descriptors represents a larger search space that is largely independent of the original set.

Ranking feature importance. (a) Mean decrease in impurity (MDI) across random forest trees. MDI is measured with the Gini index or the homogeneity of the resulting nodes and leaves created by a split at a specific feature. (b) Distribution of values contributing to SHAP feature importance values. The list is sorted by average absolute SHAP value, with the highest contributing feature at the top. The distribution of feature values is shown next to each, with colors showing the relationship between feature-instance value and the individual SHAP value.

Principal component analysis. (a) Full training dataset for the left figure and (b) top 15 features in the right figure. The first three axes explain (a) 47% and (b) 90% of the total variance, respectively.

Comparison of model error. (a) Cumulative density functions for absolute error of each model. 80% of predictions are under 0.35 for MK-207 and 0.42 for GS-04. (b) Corresponding probability densities for the error of each model. The area of each curve integrates to 1, and so the y-axis represents the probability density of the error rate.

Architecture diagram of the browser and command line applications.

## Section: Results › Feature Selection and Model Initialization

Once the new feature space was established and processed, we measured the correlation between descriptors in each of the previous and open-source spaces to evaluate similarities. Of the original 207 descriptors, 51 have a correlation coefficient of over 94% with a new open-source descriptor (Figure 2a). These include licensed descriptors deemed important in the work by Sheridan (Figure S2). Further, many of these highly correlated features map to the same open-source descriptors, where the 51 original descriptors can be represented by 20 open-source descriptors, as shown in Figure 2a. The larger set of open-source descriptors brings more variance and measurements, while also representing features important for the original model.

To select meaningful descriptors and initialize model tuning, we trained a random forest model tuned with grid search. For the training set of 1384 molecules and 1196 descriptors with 5-fold cross-validation, the R2 stabilizes around 78% with an −RMSE = −0.39. Random forest significantly outperformed other models, despite high dimensionality and limited feature selection, which served as a useful baseline. SHAP values were calculated for each instance-descriptor value and aggregated to summarize each descriptor’s average absolute score.

The SHAP summary plot illustrates a feature’s potential to raise or lower the predicted complexity (Figure 3a). The chiral and stereocenter counts, which are similar descriptors, have a similar influence on the model. Low values (or counts) of these measures influence a low prediction, whereas very high counts increase the predicted value. The summary plot is especially helpful in allocating (the estimated) predictive power to each contributing feature’s distribution. The most important descriptors calculated by random forests’ implicit MDI are shown in Figure 3b. Few features meaningfully contribute to predicted complexity, and the same features stand out from both metrics of importance, indicating that the optimal model for molecular complexity would be relatively consistent. While permutation importance shows a different ranking, the high dimension of the input dataset obscures significant decreases in accuracy (Figure S3).

While it is important to note that these methods are inherently model-dependent, the results were similar across several iterations of the model initialization phase, and SHAP shows a direct relationship of a descriptor to molecular complexity. The highest ranked 13 of 17 features are in agreement (spearman ρ = 0.65). Furthermore, all descriptors selected in this stage show a correlation of above 50% to mean complexity (Figure S4a). Very few other features have a clear significant impact on the model, indicating that a parsimonious model is reasonable. These contributors, a combination of physiochemical, topological, and graph descriptors, align with the historical approaches taken by both mathematicians and domain experts. Since descriptor effects may be magnified in their interaction with another feature, the highest 15 SHAP-ranked features are selected for further modeling.

To visualize the variance captured by the descriptors present in the dataset, we plot the first three principal components of the normalized training set and color each instance by its associated mean complexity. We use this plot to screen for linear and clustering modeling options and to determine the amount of noise contributed by extra features. Once the feature set is reduced to the top 15, we can see the selected features contain a large amount of variation associated with molecular complexity. The total explained variance improves from 47% (Figure 4a) to 90% (Figure 4b).

Coverage of feature sets. (a) Bar chart of open-source features that have over 94% correlation coefficient with an original descriptor. Several original descriptors can be summarized by an open-source feature. (b) Histogram of the original descriptors from Sheridan et al. Each bar measures the maximum correlation of an original descriptor with any open-source descriptor. (c) Histogram measuring the maximum correlation coefficients of an open-source descriptor to any original descriptor. The new set of open-source descriptors represents a larger search space that is largely independent of the original set.

Ranking feature importance. (a) Mean decrease in impurity (MDI) across random forest trees. MDI is measured with the Gini index or the homogeneity of the resulting nodes and leaves created by a split at a specific feature. (b) Distribution of values contributing to SHAP feature importance values. The list is sorted by average absolute SHAP value, with the highest contributing feature at the top. The distribution of feature values is shown next to each, with colors showing the relationship between feature-instance value and the individual SHAP value.

Principal component analysis. (a) Full training dataset for the left figure and (b) top 15 features in the right figure. The first three axes explain (a) 47% and (b) 90% of the total variance, respectively.

## Section: Results › Model Selection

In summary, for each dataset, we trained five algorithms, including partial least-squares, k-nearest neighbors, support vector machine, multilayer perceptron, and random forest. This was done for each of the three open-source datasets: the full descriptor set, the set of top descriptors, and interaction terms generated from the latter. Inputs were normalized before training for all models except for the random forest, where it is not necessary beyond comparing coefficients. The cross-validated performance metrics are listed in Table 1.

Reducing the descriptor set increased model performance across the board, though this is hardly surprising. The high R2 and the negative adjusted R2 in the models trained on the full feature set suggest that many predictors do not significantly contribute toward prediction. For the latter two training sets, the R2 and Adj-R2 are comparable, showing a reasonable ratio between the R2 and the number of predictors. Interaction terms from the top feature set, however, decreased model performance in PLS and SVM. This might suggest that the nonlinearities are of a different nature than the product and quadratic terms evaluated here. For the reduced feature sets, the neural network and k-NN matched the random forest algorithm’s performance. However, since random forest models possess more interpretability, explainability, and model robustness, we continue to use them as the model of choice.

## Section: Results › Parsimonious Model

Our work shows that a parsimonious ML model of complexity is possible. Using the four highest-ranked descriptors, two physiochemical 0D and two topological 2D descriptors, a random forest model can predict molecular complexity with MSE = −0.349 and R2 = 82.7% (Table 2). This model, GS-04, has a comparable error to the licensed MSD-207 model and improves significantly on GS-1196 while reducing the number of descriptors (Figure 5a). However, MK-207 still has a lower incidence of errors larger than ±1 as compared to the GS models (Figure 5b). The physiochemical descriptors included the number of stereocenters and the number of heteroatoms (nonhydrogen or noncarbon atoms). Unique topological torsion was the foremost ranked feature in every model and seed used. Topological torsion was developed by Nilakantan et al., to be a short-range descriptor, capturing information about the number of substructures containing unique atomic types, nonhydrogen branches, and pi electron pairs.34 The unique topological torsion then refers to the number of unique fragments within a molecule. The last descriptor, chi4n, is a structural descriptor derived from a set of connectivity indexes developed by Hall and Kier.35 The several Chi Index variants capture increasing information about the connectivity of bonds or atoms. While chi4n was used here, other chi indices were also effective. Cross-validated performance using other chi indices in its place differed by a few decimal places.

Comparison of model error. (a) Cumulative density functions for absolute error of each model. 80% of predictions are under 0.35 for MK-207 and 0.42 for GS-04. (b) Corresponding probability densities for the error of each model. The area of each curve integrates to 1, and so the y-axis represents the probability density of the error rate.

## Section: Results › App Development

Two applications were developed to make the final model accessible to both scientists and modelers. The architecture is summarized in Figure 6. For rapid estimates of molecular complexity and Open SMART-PMI, a user-friendly online application requires only the molecule’s SDF file. The resulting outputs also include the values of each descriptor factored into the model. The application uses a one-time installation and can subsequently be run locally and therefore does not track molecule entries or results. We have also created a package and command line application (CLI) in Python for model experimentation, allowing for changes in training data, simplified model retraining, and predictions. Like the web app, the CLI can be locally installed by the user and is stateless to prioritize user privacy. We encourage users to augment the model and explore diverse datasets to continue understanding molecular complexity. All materials, including the model and associated apps, can be found at https://github.com/Gilead-IT-GCDM-PDM/Open-SMART-PMI. Programmed entirely in Python, the standard for many cheminformatics and machine learning tools, open-source accessibility is at the forefront of our approach.

In this work, we have made three primary improvements: adding explainability to the search over a large descriptor space, reducing the number of descriptors while maintaining performance, and making the model open source in the language of choice for developers.

Architecture diagram of the browser and command line applications.

## Section: Discussion

While our findings contribute to refining the calculation of molecular complexity for SMART-PMI, the remaining challenges and directions merit discussion. Future progress involves addressing biases in modeling, exploring the efficacy of linear models, leveraging graph networks, and refining PMI estimates for broader industry applications, particularly in multistep processes. Future research in these directions will undoubtedly contribute to the landscape of molecular informatics.

Our effort to select descriptors postmodel training was done cautiously, as the described approach may introduce bias and artificially inflate goodness-of-fit. While our evaluation encompassed both selected and rejected descriptors, mean complexity, and model building, we acknowledge the inherent bias of data-driven models toward the training set. Despite the diversity of the training set, this study is relevant mainly to pharmaceutical contexts, and more work could be done to connect molecular complexity across domains.

Surprisingly, introducing nonlinearity with interaction terms did not improve predictions and, in some cases, may have done the opposite. This observation suggests the viability of linear models, and that the complexity of molecular structures may be effectively captured in a simpler computation. Unique topological torsion and a chirality measure were similarly used in Sheridan et al.’s four-term linear model of mean complexity with an 80% CV-R2. Given the subjectivity inherent in mean complexity as an average of chemists’ assessment, it is not expected for model predictions to be 100% accurate. While they note that mean complexity is a nonlinear variable, this further suggests that a regression model may still yet be able to achieve better fit and low error, enabling a better understanding of the physical implications of molecular complexity.

For this application, where the molecule is represented as a set of molecular descriptors, the multilayer perceptron had comparable performance to the selected interpretable model and thus presented no discernible advantage. In similar use cases with complex relationships between numeric input and output variables, deep learning remains a powerful option with the potential to capture complicated data trends. However, large amounts of training data are typically necessary, which can be an obstacle for chemistry tasks. For more complex tasks, more powerful algorithms are often necessary. Graph networks, which can use a graph-structured compound as input, are also being explored for tasks such as chemical structure prediction and may translate well to understanding molecular complexity. This, coupled with an explaining layer, could also be powerful in identifying molecular features. However, while explainability approaches like Grad-CAM output annotated molecule mappings, it may be difficult to discern long-range topological patterns. More research is currently being done to explore the viability and interpretability of these models.36,37 Overall, deep learning remains an attractive option for continuing future work.

To increase the usage and accuracy of PMI targets for widespread adoption in industry, more can be done to advance the utility and ease of tracking the PMI of a manufacturing process back to the simplest raw material building blocks. This can be especially challenging in early development where estimates must be made for the PMI of outsourced materials, such as simple starting materials. It may be possible to apply the same model for starting materials and estimate overall PMI as a linear combination of outsourced and in-house materials. Vendors could be further encouraged to track and share the process mass intensity of their materials.

## Section: Conclusions

Sustainability is paramount in manufacturing processes. Process chemists throughout the industry are working toward this goal by aiming to reduce the raw materials needed for processing and the waste produced as a byproduct of this process. Molecular complexity is one of the main indicators of the resource efficiency of a process, but without a clear definition, it is difficult to create good estimators for this parameter. Machine learning tools have recently emerged as a viable method to assist experts with decisions in complicated domains. While these tools have had success, more is needed in terms of explaining the basis of the decisions or predictions generated by complex models.

We have used an existing approach to evaluate molecular complexity and generated an open-source model with emphasis on robustness, simplicity, and interpretability. While our tool builds on the original compound complexity and SMART-PMI papers, we have made improvements in terms of interpretability and developed a new model as an open-source tool available to the larger community. We have focused on an open-source approach to develop a cost-effective tool for both internal and external use, as having these kinds of tools available for use to the larger community fosters rapid evaluation and selection of best solutions toward setting common standards.

## Section: Acknowledgments

We are grateful to Chris Foti, Victor Rucker, Jeremy Zhang, Mehul Chhatrapati, and Peter Huang for supporting this project. We kindly thank Kevin Chu for the discussion regarding linear models as well as Shikhar Mohan and Wei-Ting Liu for their thoughtful guidance and feedback.

## Section: Data Availability Statement

The Open SMART-PMI package, including the code, stored models, and applications, can be found online at https://github.com/Gilead-IT-GCDM-PDM/Open-SMART-PMI.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsomega.4c02427.

## Section: Author Present Address

∇ Department of Biology, Stanford University, Stanford, California 94305–6104, United States

## Section: Author Contributions

# P.P. and R.O. contributed equally to this work.

## Section: Text

The authors declare no competing financial interest.

## Section: Supplementary Material

ao4c02427_si_001.pdf

## Section: Associated Data

ao4c02427_si_001.pdf

## Section: Associated Data › Supplementary Materials

ao4c02427_si_001.pdf

## Section: Associated Data › Data Availability Statement

The Open SMART-PMI package, including the code, stored models, and applications, can be found online at https://github.com/Gilead-IT-GCDM-PDM/Open-SMART-PMI.


---

# Evaluating the use of large language models to provide clinical recommendations in the Emergency Department

- **Authors:** Christopher Y K Williams, Brenda Y Miao, Aaron E Kornblith, Atul J Butte
- **Issuer:** Nature communications
- **Type:** Scientific article
- **Published:** 2024-10-08
- **Language:** en
- **DOI:** 10.1038/s41467-024-52415-1
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39379357/
- **Licence:** CC-BY

## Section: Abstract

The release of GPT-4 and other large language models (LLMs) has the potential to transform healthcare. However, existing research evaluating LLM performance on real-world clinical notes is limited. Here, we conduct a highly-powered study to determine whether LLMs can provide clinical recommendations for three tasks (admission status, radiological investigation(s) request status, and antibiotic prescription status) using clinical notes from the Emergency Department. We randomly selected 10,000 Emergency Department visits to evaluate the accuracy of zero-shot, GPT-3.5-turbo- and GPT-4-turbo-generated clinical recommendations across four different prompting strategies. We found that both GPT-4-turbo and GPT-3.5-turbo performed poorly compared to a resident physician, with accuracy scores 8% and 24%, respectively, lower than physician on average. Both LLMs tended to be overly cautious in its recommendations, with high sensitivity at the cost of specificity. Our findings demonstrate that, while early evaluations of the clinical use of LLMs are promising, LLM performance must be significantly improved before their deployment as decision support systems for clinical recommendations and other complex tasks.

## Section: Introduction

Since its November 2022 launch, the Chat Generative Pre-Trained Transformer (ChatGPT; GPT-3.5-turbo) has captured widespread public attention, with media reports suggesting over 100 million monthly active users just 2 months after launch1. Along with its successor, GPT-4, these large language models (LLMs) use a chat-based interface to respond to complex queries and solve problems2,3. Although trained as general-purpose models, researchers have begun evaluating the performance of GPT-3.5-turbo and GPT-4 on clinically relevant tasks. For instance, GPT-3.5-turbo was found to provide largely appropriate responses when asked to give simple cardiovascular disease prevention recommendations4. Meanwhile, GPT-3.5-turbo responses to patients’ health questions on a public social media forum were both preferred, and rated as having higher empathy, compared to physician responses5.

While there are a growing number of studies that explore the uses of the GPT models across a range of clinical tasks, the majority do not use real-world clinical notes. They instead apply these models to answer questions from medical examinations such as the USMLE, solve publicly available clinical diagnostic challenges such as the New England Journal of Medicine (NEJM) clinicopathologic conferences, or evaluate performance on existing clinical benchmarks3,6–9. This is due to the challenges associated with disclosing protected health information (PHI) with LLM providers such as OpenAI in a Health Insurance Portability and Accountability Act (HIPAA) compliant manner, where business associate agreements must be in place to allow secure processing of PHI content10. This is a notable hurdle given the inherent differences between curated medical datasets, such as the USMLE question bank, and real-world clinical notes. In addition, this issue is particularly problematic when you consider that the GPT models have likely been trained on data obtained from open sources on the Internet and, therefore, their evaluation of existing publicly available benchmarks or tasks may be confounded by data leakage11.

As the availability and accessibility of these models increase, it is now critically important to better understand the potential uses and limitations of LLMs applied to actual clinical notes. In our previous work, we showed that GPT-4 could accurately identify the higher acuity patient in pairs of Emergency Department patients when provided only the clinical histories12. This performance was seen despite a lack of additional training or fine-tuning, known as zero-shot learning13. Elsewhere, Kanjee and colleagues evaluated the diagnostic ability of GPT-4 across 70 cases from the NEJM clinicopathologic conferences, obtaining a correct diagnosis in its differential in 64% of cases and as its top diagnosis in 39%7. However, the ability of these general-purpose LLMs to assimilate clinical information from de-identified clinical notes and return clinical recommendations is still unclear.

In this study, we sought to evaluate the zero-shot performance of GPT-3.5-turbo and GPT-4-turbo when prompted to provide clinical recommendations for patients evaluated in the Emergency Department. We focus on three recommendations in particular: (1) Should the patient be admitted to hospital; (2) Should the patient have radiological investigations requested; and (3) Should the patient receive antibiotics? These are important considerations for Emergency Medicine providers in determining clinical direction, managing staffing and resources, and designating bed utilisation. We first evaluate performance on balanced (i.e., equal numbers of positive and negative outcomes) datasets to examine the sensitivity and specificity of GPT recommendations before determining overall model accuracy on an unbalanced dataset that reflects real-world distributions of patients presenting to the Emergency Department.

## Section: Results

From a total of 251,401 adult Emergency Department visits, we first created balanced samples of 10,000 ED visits for each of the three tasks (Fig. 1). Using only the information provided in the Presenting History and Physical Examination sections of patients’ first ED physician note, we queried GPT-3.5-turbo and GPT-4-turbo to determine whether (1) the patient should be admitted to hospital, (2) the patient requires radiological investigation(s), and (3) the patient requires antibiotics, comparing the output to the ground-truth outcome extracted from the electronic health record.Fig. 1Patient flowchart.Flowchart of included Emergency Department visits and construction of both balanced (n = 10,000 samples) and unbalanced (n = 1000 samples reflecting the real-world distribution of patients presenting to the Emergency Department) datasets for the following outcomes: (1) admission status, (2) radiological investigation(s) status, and (3) antibiotic prescription status.

Across all three clinical recommendation tasks, overall GPT-3.5-turbo performance was poor (Table 1a). The initial prompt of ‘Please return whether the patient should be admitted to hospital/requires radiological investigation/requires antibiotics’ (Prompt A, see Supplementary Information) led to high sensitivity and low specificity performance. For this prompt, GPT-3.5-turbo recommendations had a high true positive rate but a similarly high false positive rate, with GPT-3.5-turbo recommending admission/radiological investigation/antibiotic prescription for the majority of cases. Altering the prompt to ‘only suggest … if absolutely required’ (Prompt B) only marginally improved specificity. The greatest performance was achieved by removing restrictions on the verbosity of GPT-3.5-turbo response (Prompt C) and adding the ‘Let’s think step by step’ chain-of-thought prompting (Prompt D). These prompts generated the highest specificity in GPT-3.5-turbo recommendations with limited effect on sensitivity. On the evaluation of GPT-4-turbo performance, there were similar sensitivity and specificity scores for the Admission status task compared to the GPT-3.5-turbo model. In contrast, across both Radiology investigation request status and Antibiotic prescription status tasks, GPT-4-turbo demonstrated marked improvement in specificity at the expense of sensitivity (Table 1b).Table 1(a) GPT-3.5-turbo performance and (b) GPT-4-turbo performance across four iterations of prompt engineering (Prompt A-D) evaluated on a balanced n = 10,000 sample for three clinical recommendation tasks: (1) should the patient be admitted to hospital; (2) does the patient require radiological investigation; and (3) does the patient require antibioticsTaskTrue positives, n (%)False positives, n (%)True negatives, n (%)False negatives, n (%)Sensitivity (95% CIa)Specificity (95% CIa)a) GPT-3.5-turbo1) Admission statusPrompt A4994 (49.9)4639 (46.4)361 (3.6)6 (0.1)1.00 (1.00–1.00)0.07 (0.07–0.08)Prompt B4904 (49.0)3527 (35.3)1473 (14.7)96 (1)0.98 (0.98–0.98)0.29 (0.28–0.31)Prompt C4683 (46.8)3255 (32.6)1745 (17.5)317 (3.2)0.94 (0.93–0.94)0.35 (0.34–0.36)Prompt D4617 (46.2)3165 (31.7)1835 (18.4)383 (3.8)0.92 (0.92–0.93)0.37 (0.35–0.38)2) Radiological investigation(s) request statusPrompt A4922 (49.2)4361 (43.6)639 (6.4)78 (0.8)0.98 (0.98–0.99)0.13 (0.12–0.14)Prompt B4805 (48.1)3906 (39.1)1094 (10.9)195 (2)0.96 (0.96–0.97)0.22 (0.21–0.23)Prompt C4792 (47.9)3855 (38.6)1145 (11.5)208 (2.1)0.96 (0.95–0.96)0.23 (0.22–0.24)Prompt D4819 (48.2)3991 (39.9)1009 (10.1)181 (1.8)0.96 (0.96–0.97)0.20 (0.19–0.21)3) Antibiotic prescription statusPrompt A4812 (48.1)3955 (39.6)1045 (10.5)188 (1.9)0.96 (0.96–0.97)0.21 (0.20–0.22)Prompt B4690 (46.9)3687 (36.9)1313 (13.1)310 (3.1)0.94 (0.93–0.95)0.26 (0.25–0.28)Prompt C4658 (46.6)3639 (36.4)1361 (13.6)342 (3.4)0.93 (0.92–0.94)0.27 (0.26–0.29)Prompt D4544 (45.4)3379 (33.8)1621 (16.2)456 (4.6)0.91 (0.90–0.92)0.32 (0.31–0.34)b) GPT-4-turbo1) Admission statusPrompt A4986 (49.9)3778 (37.8)1222 (12.2)14 (0.1)1.00 (1.00–1.00)0.24 (0.23–0.26)Prompt B4908 (49.1)2982 (29.8)2018 (20.2)92 (0.9)0.98 (0.98–0.99)0.40 (0.39–0.42)Prompt C4889 (48.9)2925 (29.3)2075 (20.8)111 (1.1)0.98 (0.97–0.98)0.42 (0.40–0.43)Prompt D4925 (49.3)3147 (31.5)1853 (18.5)75 (0.8)0.98 (0.98–0.99)0.37 (0.36–0.38)2) Radiological investigation(s) request statusPrompt A4508 (45.1)2707 (27.1)2293 (22.9)492 (4.9)0.90 (0.89–0.91)0.46 (0.44–0.47)Prompt B4006 (40.1)1867 (18.7)3133 (31.3)994 (9.9)0.8 (0.79–0.81)0.63 (0.61–0.64)Prompt C3796 (38)1653 (16.5)3347 (33.5)1204 (12)0.76 (0.75–0.77)0.67 (0.66–0.68)Prompt D4107 (41.1)2016 (20.2)2984 (29.8)893 (8.9)0.82 (0.81–0.83)0.60 (0.58–0.61)3) Antibiotic prescription statusPrompt A3149 (31.5)675 (6.8)4325 (43.3)1851 (18.5)0.63 (0.62–0.64)0.86 (0.86–0.87)Prompt B2711 (27.1)482 (4.8)4518 (45.2)2289 (22.9)0.54 (0.53–0.56)0.90 (0.90–0.91)Prompt C2505 (25.1)428 (4.3)4572 (45.7)2495 (25)0.50 (0.49–0.52)0.91 (0.91–0.92)Prompt D2584 (25.8)452 (4.5)4548 (45.5)2416 (24.2)0.52 (0.50–0.53)0.91 (0.90–0.92)For each task and metric, the best performing scores are highlighted in bold.a95% confidence intervals (CIs) calculated by bootstrapping.

To compare this performance with that of a resident physician, for each of the three tasks, we took a balanced n = 200 subsample (Fig. 1) for manual annotation and compared performance between physician and machine across the four prompt iterations (Table 2). Notably, physician sensitivity was below that of GPT-3.5-turbo responses, whereas specificity was significantly higher (Table 2a). There were similar findings when comparing GPT-4-turbo performance to physician, except for the Antibiotic prescription status task where GPT-4-turbo specificity surpassed that of the physician, but had worse sensitivity (Table 2b).Table 2Comparison of physician performance with (a) GPT-3.5-turbo performance and (b) GPT-4-turbo performance across four iterations of prompt engineering [Prompt A-D] evaluated on a balanced n = 200 subsample for three clinical recommendation tasks: (1) should the patient be admitted to hospital; (2) does the patient require radiological investigation; and (3) does the patient require antibioticsTaskTrue positives, n (%)False positives, n (%)True negatives, n (%)False Negatives, n (%)Sensitivity (95% CIa)Specificity (95% CIa)a) GPT-3.5-turbo1) Admission statusPhysician73 (36.5)26 (13)74 (37)27 (13.5)0.73 (0.64–0.81)0.74 (0.66–0.82)Prompt A100 (50)93 (46.5)7 (3.5)0 (0)1 (1–1)0.07 (0.03–0.13)Prompt B98 (49)67 (33.5)33 (16.5)2 (1)0.98 (0.95–1.00)0.33 (0.24–0.43)Prompt C95 (47.5)61 (30.5)39 (19.5)5 (2.5)0.95 (0.90–0.99)0.39 (0.30–0.49)Prompt D93 (46.5)60 (30)40 (20)7 (3.5)0.93 (0.87–0.97)0.40 (0.31–0.50)2) Radiological investigation(s) request statusPhysician76 (38)21 (10.5)79 (39.5)24 (12)0.76 (0.67–0.84)0.79 (0.70–0.87)Prompt A96 (48)91 (45.5)9 (4.5)4 (2)0.96 (0.92–0.99)0.09 (0.04–0.15)Prompt B93 (46.5)83 (41.5)17 (8.5)7 (3.5)0.93 (0.87–0.98)0.17 (0.09–0.24)Prompt C95 (47.5)83 (41.5)17 (8.5)5 (2.5)0.95 (0.90–0.99)0.17 (0.10–0.24)Prompt D95 (47.5)84 (42)16 (8)5 (2.5)0.95 (0.90–0.99)0.16 (0.09–0.24)3) Antibiotic prescription statusPhysician64 (32)22 (11)78 (39)36 (18)0.64 (0.55–0.73)0.78 (0.70–0.86)Prompt A93 (46.5)74 (37)26 (13)7 (3.5)0.93 (0.88–0.97)0.26 (0.18–0.35)Prompt B91 (45.5)71 (35.5)29 (14.5)9 (4.5)0.91 (0.85–0.96)0.29 (0.20–0.39)Prompt C92 (46)68 (34)32 (16)8 (4)0.92 (0.87–0.97)0.32 (0.23–0.42)Prompt D89 (44.5)63 (31.5)37 (18.5)11 (5.5)0.89 (0.83–0.95)0.37 (0.27–0.47)b) GPT-4-turbo1) Admission statusPhysician73 (36.5)26 (13)74 (37)27 (13.5)0.73 (0.64–0.81)0.74 (0.66–0.82)Prompt A100 (50)78 (39)22 (11)0 (0)1 (1–1)0.22 (0.14–0.31)Prompt B96 (48)59 (29.5)41 (20.5)4 (2)0.96 (0.92–0.99)0.41 (0.32–0.51)Prompt C94 (47)56 (28)44 (22)6 (3)0.94 (0.89–0.99)0.44 (0.34–0.54)Prompt D99 (49.5)67 (33.5)33 (16.5)1 (0.5)0.99 (0.97–1)0.33 (0.24–0.42)2) Radiological investigation(s) request statusPhysician76 (38)21 (10.5)79 (39.5)24 (12)0.76 (0.67–0.84)0.79 (0.70–0.87)Prompt A88 (44)61 (30.5)39 (19.5)12 (6)0.88 (0.82–0.94)0.39 (0.29–0.48)Prompt B79 (39.5)37 (18.5)63 (31.5)21 (10.5)0.79 (0.71–0.86)0.63 (0.53–0.72)Prompt C76 (38)35 (17.5)65 (32.5)24 (12)0.76 (0.67–0.84)0.65 (0.56–0.75)Prompt D76 (38)43 (21.5)57 (28.5)24 (12)0.76 (0.67–0.84)0.57 (0.47–0.67)3) Antibiotic prescription statusPhysician64 (32)22 (11)78 (39)36 (18)0.64 (0.55–0.73)0.78 (0.70–0.86)Prompt A51 (25.5)7 (3.5)93 (46.5)49 (24.5)0.51 (0.41–0.6)0.93 (0.88–0.98)Prompt B44 (22)5 (2.5)95 (47.5)56 (28)0.44 (0.34–0.54)0.95 (0.90–0.99)Prompt C39 (19.5)5 (2.5)95 (47.5)61 (30.5)0.39 (0.30–0.49)0.95 (0.90–0.99)Prompt D41 (20.5)5 (2.5)95 (47.5)59 (29.5)0.41 (0.32–0.51)0.95 (0.90–0.99)For each task and metric, the best performing scores are highlighted in bold.a95% confidence intervals (CIs) calculated by bootstrapping.*Physicians were provided the same prompt text as in Prompt A.

We next sought to test the performance of the LLMs in a more representative setting using an unbalanced, n = 1000 sample of ED visits that reflects the real-world distribution of admission, radiological investigation, and antibiotic prescription rates at our institution (Table 3). We found that the accuracy of resident physician recommendations, when evaluated against the ground-truth outcomes extracted from the electronic health record, was significantly higher than GPT-3.5-turbo recommendations: 0.83 for physician vs [range of accuracy scores across Prompts A-D: 0.29–0.53], 0.79 vs [range of accuracy scores across Prompts A-D: 0.68–0.71] and 0.78 vs [range of accuracy scores across Prompts A-D: 0.35–0.43] for admission, radiological investigation, and antibiotic prescription tasks, respectively (Fig. 2; Table 3a). GPT-4-turbo accuracy was higher than that of its predecessor for every task across each of the prompts used (Fig. 2; Table 3b). However, GPT-4-turbo performance remained inferior to the physician for both Admission status ([range of accuracy scores across Prompts A-D: 0.43–0.58] vs physician accuracy of 0.83) and Radiological investigation(s) request status ([accuracy = 0.74 across Prompts A-D] vs physician accuracy of 0.79) tasks. For the Antibiotic prescription status task, GPT-4-turbo performance surpassed the physician (GPT-4-turbo accuracy of 0.83 vs physician accuracy of 0.78).Table 3Comparison of physician performance with (a) GPT-3.5-turbo performance and (b) GPT-4-turbo performance across four iterations of prompt engineering [Prompt A-D] evaluated on an unbalanced n = 1000 sample reflective of the real-world distribution of clinical recommendations among patients presenting to ED, for the following three clinical recommendation tasks: (1) should the patient be admitted to hospital; (2) does the patient require radiological investigation; and (3) does the patient require antibioticsTaskTrue positives, n (%)False positives, n (%)True negatives, n (%)False Negatives, n (%)Sensitivity (95% CI)Specificity (95% CIa)Accuracy (95% CIa)a) GPT-3.5-turbo1) Admission statusPhysician151 (15.1)79 (7.9)683 (68.3)87 (8.7)0.63 (0.57–0.69)0.90 (0.88–0.92)0.83 (0.81–0.86)Prompt A237 (23.7)714 (71.4)48 (4.8)1 (0.1)1.00 (0.99–1.00)0.06 (0.05–0.08)0.29 (0.26–0.31)Prompt B234 (23.4)514 (51.4)248 (24.8)4 (0.4)0.98 (0.97–1)0.33 (0.29–0.36)0.48 (0.45–0.51)Prompt C232 (23.2)475 (47.5)287 (28.7)6 (0.6)0.98 (0.95–0.99)0.38 (0.34–0.41)0.52 (0.49–0.55)Prompt D226 (22.6)463 (46.3)299 (29.9)12 (1.2)0.95 (0.92–0.98)0.39 (0.36–0.43)0.53 (0.50–0.56)2) Radiological investigation(s) request statusPhysician527 (52.7)109 (10.9)261 (26.1)103 (10.3)0.84 (0.81–0.86)0.70 (0.66–0.75)0.79 (0.76–0.82)Prompt A619 (61.9)314 (31.4)56 (5.6)11 (1.1)0.98 (0.97–0.99)0.15 (0.11–0.19)0.67 (0.65–0.70)Prompt B604 (60.4)274 (27.4)96 (9.6)26 (2.6)0.96 (0.94–0.97)0.26 (0.21–0.31)0.70 (0.67–0.73)Prompt C604 (60.4)268 (26.8)102 (10.2)26 (2.6)0.96 (0.94–0.97)0.28 (0.23–0.32)0.71 (0.68–0.74)Prompt D608 (60.8)276 (27.6)94 (9.4)22 (2.2)0.97 (0.95–0.98)0.25 (0.21–0.30)0.70 (0.67–0.73)3) Antibiotic prescription statusPhysician96 (9.6)142 (14.2)686 (68.6)76 (7.6)0.56 (0.48–0.63)0.83 (0.80–0.85)0.78 (0.76–0.81)Prompt A162 (16.2)642 (64.2)186 (18.6)10 (1.0)0.94 (0.90–0.97)0.22 (0.20–0.25)0.35 (0.32–0.38)Prompt B159 (15.9)594 (59.4)234 (23.4)13 (1.3)0.92 (0.88–0.96)0.28 (0.25–0.31)0.39 (0.36–0.42)Prompt C158 (15.8)596 (59.6)232 (23.2)14 (1.4)0.92 (0.87–0.96)0.28 (0.25–0.31)0.39 (0.36–0.42)Prompt D155 (15.5)552 (55.2)276 (27.6)17 (1.7)0.90 (0.85–0.94)0.33 (0.30–0.37)0.43 (0.40–0.46)b) GPT-4-turbo1) Admission statusPhysician151 (15.1)79 (7.9)683 (68.3)87 (8.7)0.63 (0.57–0.69)0.90 (0.88–0.92)0.83 (0.81–0.86)Prompt A237 (23.7)568 (56.8)194 (19.4)1 (0.1)1.00 (0.99–1.00)0.25 (0.23–0.29)0.43 (0.40–0.46)Prompt B233 (23.3)447 (44.7)315 (31.5)5 (0.5)0.98 (0.96–1.00)0.41 (0.38–0.45)0.55 (0.52–0.58)Prompt C232 (23.2)417 (41.7)345 (34.5)6 (0.6)0.98 (0.95–1.00)0.45 (0.42–0.49)0.58 (0.55–0.61)Prompt D233 (23.3)460 (46.0)302 (30.2)5 (0.5)0.98 (0.96–1.00)0.40 (0.36–0.43)0.54 (0.50–0.57)2) Radiological investigation(s) request statusPhysician527 (52.7)109 (10.9)261 (26.1)103 (10.3)0.84 (0.81–0.86)0.70 (0.66–0.75)0.79 (0.76–0.82)Prompt A562 (56.2)188 (18.8)182 (18.2)68 (6.8)0.89 (0.87–0.92)0.49 (0.44–0.54)0.74 (0.72–0.77)Prompt B503 (50.3)128 (12.8)242 (24.2)127 (12.7)0.80 (0.77–0.83)0.65 (0.60–0.70)0.74 (0.72–0.77)Prompt C481 (48.1)112 (11.2)258 (25.8)149 (14.9)0.76 (0.73–0.80)0.70 (0.65–0.74)0.74 (0.71–0.77)Prompt D521 (52.1)147 (14.7)223 (22.3)109 (10.9)0.83 (0.80–0.85)0.60 (0.55–0.65)0.74 (0.72–0.77)3) Antibiotic prescription statusPhysician96 (9.6)142 (14.2)686 (68.6)76 (7.6)0.56 (0.48–0.63)0.83 (0.80–0.85)0.78 (0.76–0.81)Prompt A106 (10.6)117 (11.7)711 (71.1)66 (6.6)0.62 (0.54–0.69)0.86 (0.84–0.88)0.82 (0.79–0.84)Prompt B95 (9.5)92 (9.2)736 (73.6)77 (7.7)0.55 (0.48–0.63)0.89 (0.87–0.91)0.83 (0.81–0.86)Prompt C82 (8.2)78 (7.8)750 (75)90 (9.0)0.48 (0.40–0.55)0.91 (0.89–0.93)0.83 (0.81–0.86)Prompt D86 (8.6)82 (8.2)746 (74.6)86 (8.6)0.50 (0.43–0.58)0.90 (0.88–0.92)0.83 (0.81–0.86)For each task and metric, the best performing scores are highlighted in bold.a95% confidence intervals (CIs) calculated by bootstrapping.Fig. 2LLM performance: unbalanced n = 1000 sample.Evaluation of physician and A GPT-3.5-turbo or B GPT-4-turbo accuracy across four iterations of prompt engineering [Prompt A-D] evaluated on an unbalanced n = 1000 sample reflective of the real-world distribution of clinical recommendations among patients presenting to ED, for the following three clinical recommendation tasks: (1) Should the patient be admitted to hospital; (2) Does the patient require radiological investigation; and (3) Does the patient require antibiotics. Source data are provided as a Source Data file.

Lastly, in our sensitivity analyses conducted on a balanced, n = 200 subsample for each task, results were largely similar regardless of the written order of labels in the original prompt (e.g., ‘0: Patient should not be admitted to hospital. 1: Patient should be admitted to hospital.’ Vs ‘1: Patient should be admitted to hospital. 0: Patient should not be admitted to hospital.’) (Tables S4 and S5).

Flowchart of included Emergency Department visits and construction of both balanced (n = 10,000 samples) and unbalanced (n = 1000 samples reflecting the real-world distribution of patients presenting to the Emergency Department) datasets for the following outcomes: (1) admission status, (2) radiological investigation(s) status, and (3) antibiotic prescription status.

(a) GPT-3.5-turbo performance and (b) GPT-4-turbo performance across four iterations of prompt engineering (Prompt A-D) evaluated on a balanced n = 10,000 sample for three clinical recommendation tasks: (1) should the patient be admitted to hospital; (2) does the patient require radiological investigation; and (3) does the patient require antibiotics

Comparison of physician performance with (a) GPT-3.5-turbo performance and (b) GPT-4-turbo performance across four iterations of prompt engineering [Prompt A-D] evaluated on a balanced n = 200 subsample for three clinical recommendation tasks: (1) should the patient be admitted to hospital; (2) does the patient require radiological investigation; and (3) does the patient require antibiotics

Comparison of physician performance with (a) GPT-3.5-turbo performance and (b) GPT-4-turbo performance across four iterations of prompt engineering [Prompt A-D] evaluated on an unbalanced n = 1000 sample reflective of the real-world distribution of clinical recommendations among patients presenting to ED, for the following three clinical recommendation tasks: (1) should the patient be admitted to hospital; (2) does the patient require radiological investigation; and (3) does the patient require antibiotics

Evaluation of physician and A GPT-3.5-turbo or B GPT-4-turbo accuracy across four iterations of prompt engineering [Prompt A-D] evaluated on an unbalanced n = 1000 sample reflective of the real-world distribution of clinical recommendations among patients presenting to ED, for the following three clinical recommendation tasks: (1) Should the patient be admitted to hospital; (2) Does the patient require radiological investigation; and (3) Does the patient require antibiotics. Source data are provided as a Source Data file.

## Section: Discussion

This study represents an early, highly-powered evaluation of the potential uses and limitations of LLMs for generating clinical recommendations based on real-world clinical text. Across three different clinical recommendation tasks, we found that GPT-3.5-turbo performed poorly, with high sensitivity but low specificity across tasks. GPT-4-turbo performed better than its predecessor, especially when predicting the need for antibiotics for a patient in the Emergency Department. Model performance was marginally improved with iterations of prompt engineering, including the addition of zero-shot chain-of-thought prompting14. On the evaluation of an unbalanced sample reflective of the real-world distribution of clinical recommendations, the overall performance of both GPT-4-turbo and GPT-3.5-turbo was significantly worse than that of a resident physician, with 8% and 24% lower accuracy, respectively, when averaged across tasks. However, there were notable differences in GPT-4-turbo performance across tasks, with 25% lower accuracy compared to physicians for Admission status (‘Should the patient be admitted to hospital?’) and 4% lower accuracy for Radiological investigation(s) request status (‘Should the patient have radiological investigations requested?’), compared with 5% greater accuracy for Antibiotic prescription status (‘Should the patient receive antibiotics?’).

Our results suggest that LLMs are overly cautious in their clinical recommendations—both models exhibit a tendency to recommend intervention and this leads to a notable number of false positive suggestions. Such a finding is problematic given the need to both prioritise hospital resource availability and reduce overall healthcare costs15,16. This is also true at the patient level, where there is an increasing appreciation that excessive investigation and/or treatment may cause patients harm16. It is unclear, however, what is the best balance of sensitivity/specificity to strive for amongst clinical LLMs—it is likely that this balance will differ based on the particular task. The increase in LLM specificity, at the expense of sensitivity, across our iterations of prompt engineering suggests that improvements could be made bespoke to the task, though the extent to which prompt engineering alone may improve performance is unclear.

Across all three tasks, overall performance remained notably below that of a human physician. This may reflect the inherent complexity of clinical decision making, where clinical recommendations may be influenced not only by the patient’s intrinsic clinical status, but also by patient preference, current resource availability and other external factors, such as social determinants of health and resources available at home.

Before LLMs can be integrated into the clinical environment, it is important to fully understand both their capabilities and limitations. Otherwise, there is a risk of unintended harmful consequences, especially if models have been deployed at scale17,18. Current research deploying LLMs, particularly the current state-of-the-art GPT models, on real-world clinical text is limited. Recent work from our group has demonstrated the accurate performance of GPT-4 in assessing patient clinical acuity in the Emergency Department, identifying reasons for contraceptive switching, and extracting detailed oncologic history and treatment plans from medical oncology notes12,19,20. Elsewhere, GPT-3.5-turbo has been used to convert radiology reports into plain language, to classify whether statements of clinical recommendations in scientific literature constitute health advice, and to accurately classify five diseases from discharge summaries in the MIMIC-III dataset21–23. Much of the current literature focuses on the strengths of LLMs such as GPT-3.5-turbo and GPT-43,9,12,19,20. However, it is equally important to identify areas of medicine in which LLMs do not perform well. For example, in one evaluation of GPT-4’s ability to diagnose dementia from a set of structured features, GPT-4 did not surpass the performance of traditional AI tools, while fewer than 20% of GPT-3.5-turbo and GPT-4 responses submitted to a clinical informatics consult service were found to be concordant with existing reports24,25. Similarly, GPT-4 has been shown to produce largely accurate discharge summaries in the Emergency Department, but these summaries were liable to hallucination and omission of clinically relevant information26. While early signs of the utility of LLMs in medicine are promising, our findings suggest that there remains significant room for improvement, especially in more challenging tasks such as complex clinical decision-making.

This study has several limitations. First, it is possible that, for each task, not all the information which led to the real-life clinical recommendation extracted from the electronic health record was present in the Presenting History and Physical Examination sections of the ED physician note. For instance, radiological investigations requested following the Emergency Medicine physician review may lead to unexpected and/or incidental findings which were not detected during the initial review and may warrant admission or antibiotic prescription. However, even with this limitation, physician classification performance remained at a very respectable 78–83% accuracy across the three tasks, suggesting it is challenging, but not impossible, to make accurate clinical recommendations based on the available clinical text. Second, while the actual outcomes of ED patients were used as the ground-truth labels in this study, it is possible that this may not reflect the best-practice care which patients should have received, nor does it reflect a standard of care that would be given across institutions. Given the nuances of real-world clinical decision-making and the variation in clinical practice across countries, it is imperative that LLMs are evaluated across different settings to ensure representative performance. Third, we only trialled three iterations of prompt engineering, in addition to our initial prompt, and this was done in a zero-shot manner. Further attempts to refine the provided prompt, or incorporate few-shot examples for in-context learning, may improve model performance13,27–29. Last, an evaluation of the performance of other natural language processing models, such as a fine-tuned BioClinicalBERT model or bag-of-word-based and other simpler techniques, has not been performed30. It is possible that these more traditional NLP models, which are typically trained or fine-tuned on a large training set of data, may outperform the zero-shot performance of GPT-like LLMs22.

## Section: Methods

The UCSF Information Commons contains de-identified structured clinical data as well as de-identified clinical text notes, de-identified and externally certified as previously described31. The UCSF Institutional Review Board determined that this use of the de-identified data within the UCSF Information Commons environment is not human participants’ research and, therefore, was exempt from further approval and informed consent.

We identified all adult visits to the University of California San Francisco (UCSF) Emergency Department (ED) from 2012 to 2023 with an ED Physician note present within Information Commons (Fig. 1). Regular expressions were used to extract the Presenting History (consisting of ‘Chief Complaint’, ‘History of Presenting Illness’ and ‘Review of Systems’) and Physical Examination sections from each note (Supplementary Information).

We sought to evaluate GPT-3.5-turbo and GPT-4-turbo performance on three binary clinical recommendation tasks, corresponding to the following outcomes: (1) Admission status—whether the patient should be admitted from ED to the hospital. (2) Radiological investigation(s) request status—whether an X-ray, US scan, CT scan, or MRI scan should be requested during the ED visit. (3) Antibiotic prescription status—whether antibiotics should be ordered during the ED visit.

For each of the three outcomes, we randomly selected a balanced sample of 10,000 ED visits to evaluate LLM performance (Fig. 1). Using its secure, HIPAA-compliant Application Programming Interface (API) through Microsoft Azure, we provided GPT-3.5-turbo (model = ‘gpt-3.5-turbo-0301’, role = ‘user’, temperature = 0; all other settings at default values) and GPT-4-turbo (model = ‘gpt-4-turbo-128k-1106’, role = ‘user’, temperature = 0; all other settings at default values) with only the Presenting History and Physical Examination sections of the ED Physician’s note for each ED visit and queried it to determine if (1) the patient should be admitted to hospital, (2) the patient requires radiological investigation, and (3) the patient should be prescribed antibiotics. LLM performance was evaluated against the ground-truth outcome extracted from the electronic health record. Separately, a resident physician with 2 years of postgraduate general medicine training labelled a balanced n = 200 subsample for each of the three tasks to allow a comparison of human and machine performance. In a similar manner to the LLMs, the physician reviewer was provided with the Presenting History and Physical Examination sections of the ED Physician’s note for each ED visit and asked to use their clinical judgement to decide if the patient should be admitted to the hospital, requires radiological investigation, or should be prescribed antibiotics.

We subsequently experimented with three iterations of prompt engineering (Table S1, Supplementary Information) to test if modifications to the initial prompt could improve LLM performance. Chain-of-thought (CoT) prompting is a method found to improve the ability of LLMs to perform complex reasoning by decomposing multi-step problems into a series of intermediate steps27. This can be done in a zero-shot manner (zero-shot-CoT), with LLMs shown to be decent zero-shot reasoners by adding a simple prompt, ‘Let’s think step by step’ to facilitate step-by-step reasoning before answering each question14. Alternatively, few-shot chain-of-thought prompting can be used, with additional examples of prompt and answer pairs either manually (manual CoT) or computationally (e.g., auto-CoT) provided and concatenated with the prompt of interest27,28. Current understanding of the impact of zero-shot-CoT, manual CoT, and auto-CoT prompt engineering techniques applied to clinical text is limited. In this work, we sought to focus on zero-shot-CoT and investigate the effect of adding ‘Let’s think step by step’ to the prompt on model performance.

Our initial prompt (Prompt A) simply asked the LLM to return whether the patient should be e.g., admitted to the hospital, without any additional explanation. We additionally attempted to engineer prompts to (a) reduce the high false positive rate of LLM recommendations (Prompt B) and (b) examine whether zero-shot chain-of-thought prompting could improve LLM performance (Prompts C and D). Attempting to reduce the high LLM false positive rate, Prompt B was constructed by adding an additional sentence to Prompt A: ‘Only suggest *clinical recommendation* if absolutely required’. This modification was kept for Prompts C and D, which were constructed to examine chain-of-thought prompting. Because chain-of-thought prompting is most effective when the LLM provides reasoning in its output, we removed the instruction ‘Please do not return any additional explanation’ from Prompts C and D, and added the chain-of-thought prompt ‘Let’s think step by step’ to Prompt D, increasing GPT-3.5-turbo but not GPT-4-turbo response verbosity (Table S2, Supplementary Information). Prompt C, therefore, served as a baseline for comparison of LLM performance when it is permitted to return additional explanation (in addition to its outcome recommendation), allowing comparisons with both Prompt A (where no additional explanations were allowed in the prompt) and Prompt D (where the effect of chain-of-thought prompting was examined).

To evaluate the performance of both LLMs in a real-world setting, we constructed a random, unbalanced sample of 1000 ED visits where the distribution of patient outcomes (i.e., admission status, radiological investigation(s) request status, and antibiotic prescription status) mirrored the distributions of patients presenting to ED from our main cohort. The Presenting History and Physical Examination sections of the ED Physician’s note for each ED visit were again passed to the API in an identical manner to the balanced datasets, while a resident physician was provided with these same sections and asked to manually label the entire sample to allow human vs machine comparison. In addition, an attending emergency medicine physician independently classified 10% of this subsample, with 79% concordance and comparable accuracy between reviewers (Table S3, Supplementary Information).

## Section: Methods › Sensitivity analysis

Due to the stochastic nature of LLMs, it is possible that the order of labels reported in the original prompt may affect the subsequent labels returned. To test this, we conducted a sensitivity analysis on a balanced n = 200 subsample for each outcome where the positive outcome was referenced before the negative outcome in the initial prompt (e.g., ‘1: Patient should be admitted to hospital’ precedes ‘0: Patient should not be admitted to hospital’ in the GPT-3.5-turbo prompt).

## Section: Methods › Statistical analysis

To assess model performance for the unbalanced datasets, the following evaluation metrics were calculated: true positive rate, true negative rate, false positive rate, false negative rate, sensitivity and specificity. Classification accuracy was calculated in addition to the aforementioned evaluation metrics utilised for the balanced datasets to provide a summative evaluation metric for this real-world simulated task. 95% confidence intervals were calculated by bootstrapping 1000 times, with replacement. All analyses were conducted in Python, version 3.11.

## Section: Methods › Reporting summary

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article.

## Section: Supplementary information

Supplementary Information Reporting Summary Peer Review File

Supplementary Information

Reporting Summary

Peer Review File

## Section: Source data

Source data

Source data


---

# Evaluation Framework of Large Language Models in Medical Documentation: Development and Usability Study

- **Authors:** Junhyuk Seo, Dasol Choi, Taerim Kim, Won Chul Cha, Minha Kim, Haanju Yoo, Namkee Oh, YongJin Yi, Kye Hwa Lee, Edward Choi
- **Issuer:** Journal of medical Internet research
- **Type:** Scientific article
- **Published:** 2024-11-20
- **Language:** en
- **DOI:** 10.2196/58329
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39566044/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundThe advancement of large language models (LLMs) offers significant opportunities for health care, particularly in the generation of medical documentation. However, challenges related to ensuring the accuracy and reliability of LLM outputs, coupled with the absence of established quality standards, have raised concerns about their clinical application.ObjectiveThis study aimed to develop and validate an evaluation framework for assessing the accuracy and clinical applicability of LLM-generated emergency department (ED) records, aiming to enhance artificial intelligence integration in health care documentation.MethodsWe organized the Healthcare Prompt-a-thon, a competitive event designed to explore the capabilities of LLMs in generating accurate medical records. The event involved 52 participants who generated 33 initial ED records using HyperCLOVA X, a Korean-specialized LLM. We applied a dual evaluation approach. First, clinical evaluation: 4 medical professionals evaluated the records using a 5-point Likert scale across 5 criteria—appropriateness, accuracy, structure/format, conciseness, and clinical validity. Second, quantitative evaluation: We developed a framework to categorize and count errors in the LLM outputs, identifying 7 key error types. Statistical methods, including Pearson correlation and intraclass correlation coefficients (ICC), were used to assess consistency and agreement among evaluators.ResultsThe clinical evaluation demonstrated strong interrater reliability, with ICC values ranging from 0.653 to 0.887 (P<.001), and a test-retest reliability Pearson correlation coefficient of 0.776 (P<.001). Quantitative analysis revealed that invalid generation errors were the most common, constituting 35.38% of total errors, while structural malformation errors had the most significant negative impact on the clinical evaluation score (Pearson r=–0.654; P<.001). A strong negative correlation was found between the number of quantitative errors and clinical evaluation scores (Pearson r=–0.633; P<.001), indicating that higher error rates corresponded to lower clinical acceptability.ConclusionsOur research provides robust support for the reliability and clinical acceptability of the proposed evaluation framework. It underscores the framework’s potential to mitigate clinical burdens and foster the responsible integration of artificial intelligence technologies in health care, suggesting a promising direction for future research and practical applications in the field.Keywords: large language models, health care documentation, clinical evaluation, emergency department, artificial intelligence, medical record accuracy

## Section: Introduction

Large language models (LLMs) have experienced rapid advancement in recent years, significantly influencing various domains, including health care. This remarkable development is supported by their increasingly sophisticated capabilities in understanding and generating human-like text [1], as seen in models like GPT-4 and its successors [2]. From creative writing and complex problem-solving to multilingual translation and personalized communication, LLMs are reshaping the landscape of numerous industries, transcending the traditional boundaries of the capabilities of artificial intelligence (AI).

Especially, LLMs have shown remarkable capabilities in the health care sector, beginning with their impressive grasp of medical knowledge. This is highlighted by their successful performance on challenging exams, such as the USMLE (United States Medical Licensing Examination), demonstrating their proficiency in medical concepts [3,4]. Moving beyond theoretical knowledge, LLMs are now being applied to practical tasks, including the creation of detailed medical documents, which indicates their potential for direct applications in clinical settings [5-7]. The significant potential of LLMs is further underscored by their applications, which range from augmenting clinical decision-making to providing personalized patient care [8]. Their ability to process vast amounts of medical literature and patient data suggests a transformative impact on both medical research and practice [9,10]. Moreover, the continuous improvement in the performance and accuracy of these models points to a promising future in enhancing health care delivery and patient outcomes.

However, despite these advancements, the integration of LLMs into clinical practice faces significant challenges. Concerns regarding the accuracy of generated content, particularly in scenarios involving hallucinations or fabrications [6,11,12], pose substantial risks in the high-stakes environment of health care. This issue goes beyond just the limitations of the LLM models themselves; it is significantly compounded by the absence of objective and reliable standards for evaluating the generated content. The lack of clear criteria on what constitutes good output or an effective prompt and the direction for necessary improvements lead to uncertainty in their practical application. In medical settings, where precise and accurate information is vital, this absence of clear standards for prompt efficacy and output evaluation poses significant hurdles to their practical implementation, hindering the reliable and safe integration of LLMs into clinical practices.

Our research focuses on 2 primary goals. First, we aim to establish a framework for evaluating the outputs of LLMs in medical records. This includes identifying and quantifying errors and benchmarking these against expert opinions. Second, our study seeks to assess whether the outcomes produced by LLMs are clinically acceptable and reliable, examining their potential to support clinical decision-making processes. By achieving these objectives, we strive to enable the safe and effective integration of LLMs into health care, thereby enhancing patient care and clinical operations.

## Section: Methods

Prompt collection flow.

Process flow for generating initial emergency department (ED) records. The flow begins with inputting patient data (triage record, consultation transcript, and physical examination), followed by a “prompting” phase to create the initial ED record. The output is evaluated through “clinical evaluation” and “quantitative evaluation” for comprehensive assessment.

Description of our combined criteria for evaluating prompt outputs: clinical evaluation criteria and quantitative evaluation criteria.

Specific examples of each quantitative evaluation error type.

## Section: Methods › Data Collection Process

Prompt collection flow.

Process flow for generating initial emergency department (ED) records. The flow begins with inputting patient data (triage record, consultation transcript, and physical examination), followed by a “prompting” phase to create the initial ED record. The output is evaluated through “clinical evaluation” and “quantitative evaluation” for comprehensive assessment.

## Section: Methods › Data Collection Process › Overview

To evaluate the potential of LLMs in health care, particularly in generating patient records, we organized the Healthcare Prompt-a-thon. This event was specifically designed to gather prompts and their outputs from participants interested in health care–focused generative LLMs. In this section, we discuss the process of the prompt collection, encompassing its organization, task creation, implementation of the competition, and the application of LLM technology. This comprehensive approach ensures a thorough understanding of how the event was structured and executed, as well as how the LLM technology was applied in this context.

## Section: Methods › Data Collection Process › Overall Information of the Healthcare Prompt-a-Thon

The Healthcare Prompt-a-thon, organized by the Korea Society of Artificial Intelligence in Medicine under the generative model research group and hosted by Samsung Medical Center with sponsorship from NAVER Cloud, aimed to explore the potential of LLMs in health care. The event registration, which was open from October 20 to November 17, 2023, through Social Network Services and internal hospital web networks, attracted participants interested in the application of generative models in health care documentation.

On November 17, 2023, at 115 Ilwon-ro, Gangnam-gu, Seoul, a total of 52 participants (comprising 20 solo and 16 duo teams) attended the event. These teams, made up of both solo and duo participants, contributed 33 prompts for evaluation. The prompt collection flow of the event is depicted in Figure 1.

The majority of participants were from health care organizations, medical centers, and universities, with a significant representation of researchers, master’s students, and doctors, including radiologists. This diverse demographic underscored the health care focus and interdisciplinary nature of the event.

Prompt collection flow.

## Section: Methods › Data Collection Process › Task Development

The development of the tasks for the Healthcare Prompt-a-thon involved a collaborative effort spanning 2 months, engaging a diverse team of 5 professionals including an emergency medicine physician, transplant surgery physician, critical care nurse, engineer, and linguist. This team diligently created a new dataset, structuring it according to standard hospital dataset formats to ensure its relevance and applicability in a clinical setting. Although the data were simulated, they were carefully designed to mirror plausible scenarios in health care, leveraging the extensive expertise of the medical professionals on the team.

The competition comprised 3 main categories of tasks: creating initial emergency department (ED) records, comparing prescriptions, and generating discharge records. However, the primary focus of our study, as well as the evaluation process, was centered on the creation of initial ED records. For this main task, participants used detailed case scenarios provided to them to develop prompts. These prompts were designed to generate initial ED records based on various inputs, including prescreening notes, transcripts of dialogues between doctors and patients, and physical examination data. The process and nature of these tasks are illustrated in Figure 2.

To guide the participants, 2 example patient cases were provided, complete with input datasets and ideal responses for an initial consultation. These examples served as benchmarks for the participants, aiding in the development of their prompts. The evaluation of these prompts was carried out using a specially curated, unreleased patient dataset, enabling an objective assessment of their effectiveness in simulating real-world medical scenarios. The complexity and organization of these cases went beyond typical medical records, making them exemplary for both input and output in the competition. More detailed information about the patient cases can be found in Multimedia Appendix 1.

Process flow for generating initial emergency department (ED) records. The flow begins with inputting patient data (triage record, consultation transcript, and physical examination), followed by a “prompting” phase to create the initial ED record. The output is evaluated through “clinical evaluation” and “quantitative evaluation” for comprehensive assessment.

## Section: Methods › Data Collection Process › Competition Process

The Healthcare Prompt-a-thon was structured to maximize participant engagement and creativity. One week prior to the event, participants received a set of practice problems and descriptions of medical records to familiarize themselves with the tasks. On the day of the event, we unveiled the actual examples to be used in the competition.

At the outset of the event, we provided detailed explanations of the 3 main tasks: creating initial ED records, comparing prescriptions, and generating discharge records. Following this, participants were introduced to the LLM platform, along with a comprehensive tutorial on its use and strategies for effective prompt creation. This training was crucial in equipping participants with the necessary skills to navigate the LLM platform and create high-quality prompts.

The task execution phase spanned approximately 5 hours, from 10:00 AM to 3:00 PM, during which participants worked on generating the required outputs. Following the completion of the event, participants submitted their prompts through a Google Form. Each participant’s prompts were submitted once to the LLM for evaluation. This approach was chosen to streamline the competition process and ensure consistency in the evaluation of outputs. These prompts were then executed in real time, and the generated results were used as the basis for evaluation. The evaluation of these prompts was conducted in the subsequent 1.5 hours. The judging panel, consisting of experts in relevant fields, assessed the submissions based on predefined criteria. The event culminated in an award ceremony, where the top 3 teams were recognized for their outstanding prompts and innovative solutions.

## Section: Methods › Data Collection Process › Using LLM in Our Process

Among various LLMs available for our study, we selected HyperCLOVA X developed by NAVER Corporation [13]. This decision was informed by HyperCLOVA X’s specialized capabilities in processing the Korean language, an essential requirement for our project’s focus on health care documentation in Korea.

HyperCLOVA X is a Korean-specialized LLM intricately designed to efficiently process and understand the complexities of the Korean language. It builds upon the strengths of its predecessor, CLOVA, with significant enhancements in language processing and generation, having been trained on an extensive database of over 560 billion Korean tokens. These improvements are evident in its outstanding proficiency in understanding and generating Korean text [14]. The integration of HyperCLOVA X with Clova Studio, a user-friendly graphical user interface [15], facilitates intuitive in-context interactions and lowers technical barriers for users, making it an ideal choice for real-time applications in health care settings [16-18].

## Section: Methods › Evaluation Methodology

Description of our combined criteria for evaluating prompt outputs: clinical evaluation criteria and quantitative evaluation criteria.

Specific examples of each quantitative evaluation error type.

## Section: Methods › Evaluation Methodology › Overview

To comprehensively evaluate the initial ED records generated through prompts, we used 2 distinct evaluation methodologies: (1) clinical evaluation by medical experts and (2) quantitative evaluation for objectively assessing errors in the generation process. The development of these evaluation criteria was a collaborative effort involving 3 experts, including an emergency medicine professor, a critical care nurse, and a linguist.

The process of developing the evaluation criteria involved several key steps to ensure their effectiveness and relevance. Initially, we conducted an extensive literature review to gather existing standards and best practices for medical documentation, including guidelines from reputable medical organizations and previous research on AI applications in health care. One notable reference was the Physician Documentation Quality Instrument (PDQI-9), which provides a comprehensive framework for evaluating the quality of medical records [19,20]. However, given the broad scope and time-consuming nature of the PDQI-9, we simplified the criteria to make them more practical for real-time evaluation by our assessors.

Next, the initial framework was presented to the panel of experts, who engaged in several rounds of discussions to refine the criteria. These discussions were crucial for integrating diverse perspectives and ensuring that all critical aspects of medical documentation were covered. Experts emphasized the importance of detailed subcriteria for specific areas such as the presence of hallucinations, missing information, and clinical reasoning. This feedback led to further refinement of the criteria.

To ensure the effectiveness and relevance of our evaluation criteria, a preliminary trial was conducted 2 weeks prior to the main event. This trial involved 10 randomly selected volunteers who engaged in solving prompt problems and generating outputs. The outcomes of this preliminary phase were instrumental in providing practical insights and feedback, which were crucial for refining and enhancing the evaluation criteria to be used in the competition. This process helped ensure that our evaluation criteria were both rigorous and aligned with real-world scenarios, thereby enhancing the validity of our study’s findings.

## Section: Methods › Evaluation Methodology › Clinical Evaluation

For the clinical evaluation, we established criteria relevant to assessing the quality of medical record outputs, including appropriateness, accuracy, structure/format, conciseness, and clinical validity. These criteria were meticulously developed to cover key aspects of clinical documentation and are detailed in Table 1. Each element was evaluated using a 5-point Likert scale, where higher scores indicate a stronger presence of the evaluated quality attribute.

The evaluation was conducted by a panel of 4 medical experts, consisting of 3 physicians and a surgeon, all of whom are bioinformatics researchers. The evaluations were carried out in 2 phases: a collective assessment during the Healthcare Prompt-a-thon and subsequent independent evaluations to ensure thoroughness and mitigate bias. To minimize potential memory effects and learning bias from the first evaluation phase, a washout period of 1 month was observed before conducting the retest evaluations. Additionally, a consistency analysis was performed to gauge the uniformity of judgments across the panel of medical experts. The outcomes of both the test-retest evaluations and the consistency analysis are elaborated in the results section.

Description of our combined criteria for evaluating prompt outputs: clinical evaluation criteria and quantitative evaluation criteria.

## Section: Methods › Evaluation Methodology › Quantitative Evaluation

In addition to clinical evaluation criteria, we introduce a novel quantitative evaluation framework specifically designed for assessing LLM outputs in health care. This framework’s establishment was driven by a thorough review of the generated outputs, during which we identified recurring error patterns and grouped them into distinct categories. Consequently, errors in LLM-generated medical records have been categorized into 7 types: invalid generation error, nongeneration error, information error, prompt echoing error, structural malformation error, contents misplacement error, and typo error. These categories were formed based on the frequency and nature of errors observed in our comprehensive review of the LLM outputs. Detailed definitions of these error types are presented in Table 1.

Furthermore, specific examples of each error type are provided in Table 2. These examples illustrate the practical implications of the identified errors and provide insight into the types of inaccuracies that occurred in the LLM-generated medical records.

To facilitate a structured and detailed evaluation, we categorized the essential components of the initial ED records into 11 distinct items: chief complaint, vital signs, present illness, past history, personal and social history, system inquiry, physical examination, problem list, differential diagnosis, diagnosis plan, and treatment plan. We then counted the presence and frequency of errors in each item.

The results of this quantitative error analysis serve as the foundation for a comprehensive comparison between quantitative and clinical evaluations. This comparison includes both the overall correlation and a detailed analysis of individual evaluation criteria.

By adopting this dual evaluation approach, we gained a comprehensive understanding of the strengths and weaknesses of LLMs in health care from a quantitative standpoint, while also exploring the relationship between clinical and quantitative evaluations.

Specific examples of each quantitative evaluation error type.

## Section: Methods › Ethical Considerations

During the application process for the Healthcare Prompt-a-thon, all participants were informed that their outputs might be used for research purposes and could potentially be made public. Explicit consent was obtained from each participant, ensuring that they were fully aware of the intended use of their data. While personal information was collected solely for the purpose of managing the event, it was not used for research and was securely discarded after the event concluded. No personal identifying information was collected for the research, and all data used in the study were anonymized to protect participants’ privacy and confidentiality. As a token of appreciation for their participation, the top 3 teams were recognized and awarded special prizes (equivalent to US$613, US$110, and US$70). The research was conducted in compliance with ethical standards, and the institutional review board of Samsung Medical Center approved the study protocol (institutional review board 2023-12-018-001).

## Section: Methods › Statistical Analysis Methods

Statistical analyses of the evaluation results were conducted using the Python programming language (Python Software Foundation) along with libraries such as SciPy, Pandas, and Pingouin. The specific versions of these programs used in our analysis were Python 3.10, Pandas 1.5.3, SciPy 1.11.4, and Pingouin 0.5.4.

## Section: Methods › Clinical Evaluation Methods

For the clinical evaluation, we used a 2-phase approach consisting of an initial assessment during the event followed by a retest evaluation. Our key statistical tool in this phase was the Pearson correlation coefficient. This coefficient measured the consistency of scores between the initial test and the retest, offering a quantifiable measure of reliability in the evaluators’ judgments.

In addition, we applied the intraclass correlation coefficient (ICC), specifically the ICC(3,k) model, to assess the consistency among different experts in the panel. The ICC was instrumental in evaluating the level of agreement among raters, ensuring the robustness of our evaluation criteria across diverse expert opinions [20]. The F statistics associated with the ICC further reinforced the reliability of these evaluations.

## Section: Methods › Quantitative Evaluation Methods

Quantitative Evaluation Methods involved categorizing and counting various error types, such as invalid generation error, typo error, and structural malformation error, among others. Our approach was to first analyze the frequency of these errors and then assess their impact on the clinical validity of the LLM outputs.

To understand the relationship between error types and clinical evaluation scores, we used the Pearson correlation coefficient. We also calculated P values for each error type and category to ascertain the statistical significance of their correlations with clinical evaluation scores, considering a P value less than .001 as indicative of a significant correlation.

Additionally, we extended our analysis to encompass different categories of clinical information, such as chief complaint, vital signs, present illness, and so forth. This allowed us to delve deeper into understanding which aspects of the LLM outputs were most pivotal for clinical accuracy and relevance.

## Section: Results

Statistical results of clinical evaluation (n=33).

Pearson correlation analysis showing the test-retest reliability of clinical evaluation criteria with a correlation coefficient of 0.776.

Intraclass correlation coefficient (ICC) of the clinical evaluation (n=33, ICC3k).

Correlation between error types and clinical evaluation.

Correlation between category-specific errors and clinical evaluation.

## Section: Results › Result of Clinical Evaluation

Statistical results of clinical evaluation (n=33).

Pearson correlation analysis showing the test-retest reliability of clinical evaluation criteria with a correlation coefficient of 0.776.

Intraclass correlation coefficient (ICC) of the clinical evaluation (n=33, ICC3k).

## Section: Results › Result of Clinical Evaluation › Overall Statistical Analysis

Table 3 presents the mean and SD for each criterion of the clinical evaluation, offering a more robust summary of central tendency and variability. In the initial test, the highest mean score was noted for structure/format at 3.30 (SD 0.99), indicating a strong organizational aspect in the responses. Conversely, accuracy had the lowest mean score at 2.61, highlighting a critical area for improvement, with an SD of 0.63 suggesting a tighter cluster of responses around the mean.

Upon retesting, improvements were notable across the board, with structure/format again achieving the highest mean score at 3.43 and showing a decrease in SD to 0.67, reflecting more consistent evaluations. Conciseness also showed significant progress, moving to a mean of 3.23 with a reduced SD of 0.62, indicating a narrower spread of evaluations. The overall score saw an increase from a mean of 14.89 in the initial test to 15.57 in the retest, with the SD narrowing from 3.96 to 2.84, demonstrating a general improvement in the evaluation criteria across participants.

Statistical results of clinical evaluation (n=33).

## Section: Results › Result of Clinical Evaluation › Test-Retest Reliability Analysis

Our test-retest reliability analysis [21] method involved 2 distinct testing phases. To quantitatively determine the reliability of our evaluations, we calculated the Pearson correlation coefficient between the average scores of the 2 evaluation sessions. The results, illustrated in Figure 3, show a Pearson correlation coefficient of 0.776, as reported in Table 3. This coefficient indicates a moderate positive correlation, suggesting a reasonable level of agreement among evaluators across both testing sessions. Notably, the clinical validity criterion exhibited the highest correlation, indicating strong consistency in this area, whereas the structure criterion showed a relatively lower correlation, highlighting potential variability in this aspect of the evaluation.

The statistical significance of this correlation was established with a P value less than .001, confirming that the observed consistency in the evaluation scores was not due to random chance.

Pearson correlation analysis showing the test-retest reliability of clinical evaluation criteria with a correlation coefficient of 0.776.

## Section: Results › Result of Clinical Evaluation › Consistency Among Panel

To ensure the robustness of our clinical evaluation criteria, external validation was performed by a diverse panel of domain experts. ICC, particularly using the ICC(3,k) model, provide a measure of the reliability or consistency of measurements made by multiple observers measuring the same quantity [22]. As summarized in Table 4, all items demonstrated strong ICC, when using ICC(3,k) model, with values ranging from 0.653 to 0.887. These ICC values indicate a high level of agreement among raters, with Clinical Validity showing the highest consistency (ICC=0.887). The F statistics, ranging from 2.883 to 8.826 for different criteria, further substantiate the reliability of the evaluations, suggesting high agreement consistency among the evaluators. Additionally, the 95% CI for each criterion reinforce the precision of these assessments. Importantly, all ICC values were statistically significant (P<.001), underscoring the overall consistency and reliability of the assessment across the various criteria evaluated.

Intraclass correlation coefficient (ICC) of the clinical evaluation (n=33, ICC3k).

## Section: Results › Comparing Clinical and Quantitative Evaluations

Correlation between error types and clinical evaluation.

Correlation between category-specific errors and clinical evaluation.

## Section: Results › Comparing Clinical and Quantitative Evaluations › Quantitative Error Analysis

In the quantitative evaluation of the LLM’s output, we analyzed the frequency of different types of errors. Invalid generation error was the most common error type, constituting approximately 35.38% (75/212) of the total errors. This indicates a significant area where the LLM may need refinement. On the other hand, typo error was found to be the least frequent, accounting for only about 0.47% (1/212) of the errors, suggesting a relatively minor issue in the context of the overall error landscape. Other notable error types included structural malformation error (29.25%, 62/212) and nongeneration error (14.62%, 31/212).

## Section: Results › Comparing Clinical and Quantitative Evaluations › Overall Correlation Between Quantitative and Clinical Evaluations

In addition to the detailed error-type analysis, we examined the overall correlation between the comprehensive quantitative evaluation of participant outputs and their clinical evaluation scores. We found a negative correlation of –0.633 (P<.001) between the quantitative and clinical evaluations. This indicates that higher error rates in LLM outputs, as identified in the quantitative analysis, correspond to lower clinical evaluation scores, underscoring the importance of accuracy in LLM-generated text for clinical relevance.

## Section: Results › Comparing Clinical and Quantitative Evaluations › Detailed Correlation Analysis

Our analysis of the correlation between error types in the LLM output and clinical evaluation scores (referenced in Table 5) highlighted significant differences in their impact on clinical validity. Notably, structural malformation error showed the strongest negative correlation (Pearson r=–0.654) among different error types, indicating its substantial effect on clinical assessment. This error type, involving incorrect structure or categorization of content, is crucial for the clinical applicability of LLM outputs. Other error types, such as invalid generation error and nongeneration error, exhibited varying degrees of correlation. In contrast, errors like typo error and prompt echoing error had lower correlations, suggesting a lesser impact on clinical validity.

Additionally, our examination, based on the data in Table 6, revealed that errors in certain categories showed a more pronounced correlation with clinical evaluation scores than others. Notably, categories such as differential diagnosis, diagnosis plan, and treatment plan exhibited strong negative correlations with clinical evaluation scores (Pearson r values around –0.698). This suggests that inaccuracies or errors in these critical areas greatly diminish the clinical relevance and reliability of the LLM outputs. In contrast, categories like chief complaint and vital signs exhibited lower negative correlation.

Correlation between error types and clinical evaluation.

Correlation between category-specific errors and clinical evaluation.

## Section: Discussion › Principal Findings

This study introduces and validates a comprehensive framework for assessing the efficacy of language model applications in emergency medical documentation, effectively bridging the gap between cutting-edge AI technologies and their application in critical health care scenarios. Through this discussion, we explore the implications of our findings, focusing on the insights gained from both clinical and quantitative evaluations of language model outputs. Our analysis underscores the framework’s reliability and clinical pertinence, supported by rigorous analyses that include test-retest reliability, consistency across expert evaluations, and the impact of different types of errors on the utility of the generated documents. Integrating statistical data with expert opinions, we identify the strengths of language models in emergency medical documentation and pinpoint areas needing improvement, emphasizing the framework’s contribution to enhancing AI applications in health care.

## Section: Discussion › Interpreting the Results of Clinical Evaluation

Upon examining the statistical data from the clinical evaluation, it is notable that the highest median score in both the initial test and upon retesting was seen in structure/format. This indicates that, on average, the LLM outputs were acceptable in terms of organizing and formatting information consistent with the requirements of medical documentation. On the other hand, accuracy presented the lowest median score, pinpointing a significant area for improvement. The lower scores in accuracy imply that the LLM outputs occasionally included errors or inaccuracies in the medical information provided, underscoring the need for further refinement of LLMs to ensure the reliability of generated content.

From the perspective of test-retest analysis, the Pearson correlation coefficient of the overall score confirms that a consistent and reliable evaluation was conducted by the experts, affirming the utility of our framework. Moreover, all 5 criteria—appropriateness, accuracy, structure/format, conciseness, and clinical validity—exhibited correlation coefficients exceeding the P value of .60. This demonstrates that our framework is consistent and reliable even across all clinical evaluation criteria. Notably, clinical validity reached the highest correlation coefficient. Given that clinical validation is the most critical element in evaluating medical records, this result signifies that our evaluation is trustworthy and valuable in a clinical context.

Furthermore, the uniformly high ICC results, which measure the agreement level among different evaluators on the same measure, indicate a high level of agreement. Clinical validity, in particular, demonstrated the greatest consistency across the panel. This clarity illustrates that our framework can facilitate consistent clinical evaluations from the perspective of various experts. Appropriateness and structure/format also scored highly, indicating minimal variation in their assessment among the evaluators. These observations, supported by significant F statistics and narrow CI, emphasize the assessments’ reliability and precision.

## Section: Discussion › Comparing Clinical and Quantitative Evaluations

In the process of comparing clinical and quantitative evaluations, a significant relationship was revealed between the number of errors in LLM outputs and their clinical evaluations. This relationship manifested as a negative impact on the overall correlation between quantitative evaluations and clinical scores. This finding suggests that errors identified through quantitative analysis are aligned with clinical assessments, reinforcing the validity of the LLM outputs.

Among the various types of quantitative errors, structural malformation error had the most significant influence on clinical evaluation. This underscores the critical importance of accurate structure and format within medical records, where the presence of unnecessary items or the omission of necessary ones can significantly undermine the document’s utility. Such errors disrupt the logical flow and completeness of medical records, making them less useful in clinical settings. Despite invalid generation error being the most frequently observed type, its impact on clinical evaluation was less pronounced. This could be due to the evaluators’ tendency to overlook certain errors that commonly occur in clinical settings, such as incorrectly labeling unexamined items as “None” rather than “Unknown.”

Further analysis of category-specific errors revealed that specific categories within the initial ED records, such as differential diagnosis, diagnosis plan, and treatment plan, were most critical to clinical evaluators. These categories, pivotal for clinical decision-making, demonstrated a strong correlation with clinical evaluations, underscoring the significant impact of inaccuracies in these critical reasoning areas on clinical relevance. This reflects the inherent value clinicians place on deep clinical reasoning within medical records.

Conversely, categories like system inquiry and personal and social history, despite being areas where errors were frequently found, showed lesser impact on clinical evaluation. This may be attributed to the prevalence of similar errors in human-generated records, leading to a more forgiving attitude from evaluators. Notably, instances of mislabeling unexamined items as “None”—a type of invalid generation error previously discussed—within these categories were often overlooked.

This nuanced analysis highlights the differential weighting of error types by expert evaluators, demonstrating that while quantitative error analysis is essential for identifying and categorizing errors, the subjective judgment of medical professionals remains indispensable. The evaluators’ prioritization underscores the critical role of clinical reasoning in assessing the relevance and acceptability of LLM outputs, illustrating the complex interplay between objective error identification and subjective clinical judgment in determining the utility of AI-generated medical documentation.

## Section: Discussion › Integrating Automated Quantitative Assessments With Clinical Expertise

One area for future development involves integrating automated quantitative evaluations with the nuanced understanding of clinicians. Our study highlights the importance of balancing objective error analysis with subjective clinical judgment. Future research could explore creating systems that automate the quantitative evaluation process while incorporating clinician input to refine these assessments. This integration would aim to harness the strengths of both AI and human expertise, ensuring more accurate and clinically relevant LLM outputs in health care settings.

Future development should focus on integrating automated quantitative evaluations with clinicians’ nuanced understanding. Automated systems, such as machine learning algorithms, could classify error types and correlate these with clinical expert assessments. This would balance the objective error analysis with subjective clinical judgment, reducing cognitive load on clinicians while ensuring the accuracy and clinical relevance of LLM outputs. Further research could explore refining these systems to improve the applicability of LLM-generated documents in health care settings, thereby enhancing their effective integration into real-world medical documentation.

## Section: Discussion › Limitations

Our study, while providing significant insights into the application of LLMs in health care, faced certain limitations. The lack of detailed personal data, such as age and gender, from participant profiles limits our understanding of the sample’s diversity and the generalizability of our findings. Additionally, the exclusive use of HyperCLOVA X for generating and evaluating prompts restricts our insights to a single LLM. This presents a limitation in understanding how different LLMs might perform in similar tasks, which is an important aspect for future explorations.

Furthermore, we did not investigate the reproducibility of LLM outputs. The absence of tests to determine whether repeated applications of the same prompts would yield consistent results under varied conditions leaves a gap in understanding the reliability of LLM-generated content in clinical settings. Additionally, our study’s focus on initial records from the ED narrows its scope. Future studies should broaden the research to include a wider range of medical records and clinical departments.

Finally, while the PDQI-9 could have provided a more comprehensive evaluation, we simplified our criteria due to time constraints and the cognitive load of the competitive setting. This simplification was necessary for practical use by assessors, but it highlights an area for future enhancement in evaluating LLM applications in health care documentation.

## Section: Discussion › Conclusion

Our study introduces a novel and robust framework for evaluating LLMs in health care, particularly focusing on initial ED records. During the Healthcare Prompt-a-thon, we used LLMs and combined clinical insights with quantitative analysis. This approach revealed a strong relationship between the prevalence of quantitative errors and the overall quality of clinical outcomes, underscoring the effectiveness and reliability of our framework in assessing clinical utility.

Moreover, the results validate the clinical acceptability of our framework, suggesting that LLMs, when accurately assessed and used, can be integrated into clinical practice. This advancement opens avenues for LLMs in health care, aligning AI innovations with the critical demands of patient safety and care quality. Future research should focus on refining this framework, further enhancing the practicality and adoption of LLMs in health care environments.

## Section: Acknowledgments

This research was supported by a grant of the Korea Health Technology R&D Project through the Korea Health Industry Development Institute (KHIDI), funded by the Ministry of Health & Welfare, Republic of Korea (grant HI22C0452). We are deeply grateful to the Korea Society of Artificial Intelligence in Medicine and its generative model research group for organizing the Healthcare Prompt-a-thon, and to Samsung Medical Center for hosting this meaningful event. We convey our special thanks to NAVER Cloud for their sponsorship and support. Our appreciation also extends to all participants of the Healthcare Prompt-a-thon for their invaluable input.


---

# Evaluation of an Affinity-Enhanced Anti-SARS-CoV2 Nanobody Design Workflow Using Machine Learning and Molecular Dynamics

- **Authors:** Zsolt Fazekas, Dóra Nagy-Fazekas, Boglárka Mária Shilling-Tóth, Péter Ecsédi, Pál Stráner, László Nyitray, András Perczel
- **Issuer:** Journal of chemical information and modeling
- **Type:** Scientific article
- **Published:** 2024-10-02
- **Language:** en
- **DOI:** 10.1021/acs.jcim.4c01023
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39356775/
- **Licence:** CC-BY

## Section: Abstract

In silico optimization of protein binding has received a great deal of attention in the recent years. Since in silico prefiltering of strong binders is fast and cheap compared to in vitro library screening methods, the advent of powerful hardware and advanced machine learning algorithms has made this strategy more accessible and preferred. These advances have already impacted the global response to pandemic threats. In this study, we proposed and tested a workflow for designing nanobodies targeting the SARS-CoV-2 spike protein receptor binding domain (S-RBD) using machine learning techniques complemented by molecular dynamics simulations. We evaluated the feasibility of this workflow using a test set of 3 different nanobodies and 2 different S-RBD variants, from in silico design and bacterial expression to binding assays of the designed nanobody mutants. We successfully designed nanobodies that were subsequently tested against both the wild-type (Wuhan type) and the delta variant S-RBD and found 2 of them to be stronger binders compared to the wild-type nanobody. We use this case study to describe both the strengths and weaknesses of this in silico assisted nanobody design strategy.

## Section: Introduction

The severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2) pandemic that began in 2019, has become one of the most significant global health crises in the recent history. The virus responsible for the pandemic causes the coronavirus disease 2019 (COVID-19), with symptoms varying greatly between unobservable- (asymptomatic), mild- (e.g., fever, cough, loss of smell), and severe illness (low SpO2, respiratory failure, organ dysfunction).1 The outbreak spread rapidly around the world, often accompanied by bacterial coinfections,2 resulting in a devastating loss of life. As the disease became more widespread, research into prevention and treatment options intensified. Although vaccines were developed by several companies (e.g., Johnson & Johnson, Moderna, Pfizer, Novavax),3 the treatment of those already infected with severe symptoms relied on intensive hospital care, often with the help of invasive mechanical ventilation.4

To mitigate the effects of the virus, interest in SARS-CoV-2 antibodies and antibody mimetics has increased, leading to the development of countless alternatives that are collected and organized in the Coronavirus Antibody Database.5 Protein-based treatments have the advantage over small-molecule options that they are highly specific, cause fewer side effects and are better tolerated. Furthermore, the FDA also favors protein therapeutics with faster approval times.6 Viral surface accessibility limits the possible target proteins for SARS-CoV-2 variants to the small set of spike, membrane, and envelope proteins and explains why the majority of antibodies bind to the most easily accessible spike receptor binding domain (S-RBD). This domain is located on the “tip” of the homotrimeric spike protein and is responsible for the binding to the human angiotensin converting enzyme 2 (ACE2) in the initiating step of host cell invasion. The S-RBD fluctuates between up- (or open-) and down- (or closed-) conformers,7,8 allowing it to contact its ACE2 partner in the open conformation, and to partially evade an immune response in its closed form.

Nanobodies, also called single-chain antibodies, are a class of engineered proteins that combine the specific partner recognition ability of antibodies with a small and simple, single-domain structure. A subclass of nanobodies, called VHH fragments, are engineered from heavy chain-only camelid antibodies through the omission of the constant domains. The simplicity and strong binding ability of VHHs make them excellent agents for anti-SARS-CoV-2 development. Several S-RBD targeting nanobodies have been successfully developed, such as H11-H4,9 SR4,10 MR17,10 Nb20,11 Nb6,12 and ab8.13 Furthermore, the VHH-72 nanobody that was developed against SARS-CoV-1, was found to be cross-reactive against SARS-CoV-2,14 albeit with reduced affinity. We have previously introduced a protocol for the Escherichia coli-based bacterial expression of both nanobodies and the S-RBD of SARS-CoV-2, using a fusion construct containing a periplasmic translocator protein called Ecotin.15 Using this approach allows the efficient production of large quantities of recombinant S-RBD proteins. In light of this, we envisioned an in vitro SARS-CoV-2 S-RBD targeting nanobody optimization platform, where production of both the S-RBD variants and the nanobody mutants are performed by bacterial expression.

To limit the expression to potentially optimized binders, in silico methods can be used to filter out irrelevant variants from the high-dimensional mutation space. An important descriptor of anti- and nanobodies is the Gibbs free energy change associated with binding to its antigen partner per mole (ΔG). Stronger binding means more negative values, and a ΔG above the 0 kcal/mol threshold indicates that the equilibrium is shifted toward the monomers. While ΔG assesses the binding strength of two proteins, ΔΔG = ΔGmut – ΔGWT is used to assess the quantitative effects of mutation(s). ΔΔG describes the stabilizing/destabilizing effect of the change from a wild-type (WT) protein to its mutant variant (mut). In vitro techniques to measure these values include biolayer interferometry (BLI), surface plasmon resonance (SPR), isothermal titration calorimetry (ITC), or nuclear magnetic resonance (NMR) spectroscopy. One of the challenges in computational biochemistry is to accurately predict ΔG and ΔΔG without the need for such techniques. A computationally inexpensive approach to approximating ΔΔG is to use the WT complex structure along with the mutation queries as inputs to machine learning (ML) models. This led to the development of algorithms such as iSEE,16 mCSM-PPI2,17 mCSM-AB2,18 TopNetTree,19 MutaBind2,20 SAAMBE-3D,21 GeoPPI.22 A detailed review can be found in the reference.23 Although these methods are fast and easy to use, they are not fail-safe for every target.

Another, more classical approach is to use molecular dynamics (MD) simulations for the same purpose. Such simulations aim to reproduce in silico the allowed conformers of a protein (or protein complex). The result of these simulations are trajectories, a series of time-correlated protein states (or “frames”). In the case of MD, thermodynamic integration, free energy perturbation, or umbrella sampling provide the most accurate estimates of ΔΔG. Despite the accuracy of these methods, they are rarely used techniques due to their high computational cost. Instead, end point methods are often used, such as the molecular mechanics with Poisson–Boltzmann and surface area solvation method (MM/PBSA) and generalized Born and surface area solvation method (MM/GBSA).24 Although less accurate, end-point methods require less computational time and resources. As their names suggest, they consider only the end-states of the system (e.g., uncomplexed and complexed states). The approximated Gibbs free energy change is either calculated from one (only the complex is simulated), two (the complex and one partner are simulated), or three (the complex and both partners are simulated) MD trajectories, depending on the desired accuracy (3 > 2 > 1) and precision (3 < 2 < 1).

In this work, we aim to investigate the applicability of a ML and MM/GBSA workflow for the design of novel, specific anti-S-RBD nanobodies (Figure 1). Nanobody constructs were generated against both the WT, i.e., Wuhan, and the Delta B.1.617.2 variants. We used the consensus of three different ML methods, namely mCSM-PPI2, MutaBind2 and SAAMBE-3D, to prefilter mutations in the case of nanobodies H11-H4, Nb20, and ab8. These predictors were selected due to their high reported accuracy (based on correlation and error), availability, ease of use, and different model selection approaches (extra trees, random forest, and XGBoost, respectively). Mutations with the best consensus scores were then subjected to MD simulations and MM/GBSA calculations, in order to further validate their binding promoting effects and to understand the mechanism behind these effects at the molecular level. Finally, mutations were selected for expression in E. coli and their affinity to the two S-RBDs was measured using biolayer interferometry (BLI). The proposed workflow could support and/or partially replace time-consuming and costly methods in the future, such as immunization or phage display.

Workflow diagram for the tested ML and MD approaches. The upper track illustrates the structure preprocessing steps (which result in the PDB files inputted into the three ML models), the mutation list selection by the mCSM-PPI2 Web server’s “interface analysis” function, the ML runs, and the prediction list postprocessing steps. The bottom track shows the MD simulation and trajectory analysis steps, namely the MM/GBSA calculations and the RING residue–residue interaction detection.

## Section: Materials and Methods › ML Predictions, MD Simulations, and MM/GBSA Calculations

Structures with PDB IDs of 6ZBP (H11-H4), 7JVB (Nb20), 7MJI (ab8), and 6ZDH (full spike protein) were downloaded from www.rcsb.org. To alleviate any differences between the nanobody/S-RBD complexes, such as chain breaks and conformational differences far from the interface, a single S-RBD model was created using residues 333–529 of the 6ZDH structure and was used to replace the complexing S-RBD within the nanobody complexes. The 6ZDH S-RBD was aligned with each of the S-RBDs within the complex structures using PyMol25 and then substituted for the original. Then, the Optimize command of FoldX26 was used to repair side chains and remove van der Waals collisions, followed by a steepest descent energy minimization step with the GROMACS 2021.4 software.27 The convergence criteria for the minimization were a maximum force of 50 kJ × mol–1 × nm–1 and a maximum number of steps of 11,000.

Mutations to these initial structures were also introduced using FoldX with the BuildModel protocol. First, the delta variant S-RBD structures were generated. Two subvariants were investigated, subvariant Δ1 (B.1.617.2) with mutations L452R, T478 K and subvariant Δ2 (B.1.617.2+K417N) with an additional mutation of K417N.28 After introducing these mutations, the structures were energy minimized again.

In silico site saturation mutagenesis (SSM) studies were then performed on the nanobodies in search of ΔΔG values using three freely available machine learning Web servers: mCSM-PPI2,17 SAAMBE-3D,21 and MutaBind2.20 Interface residues were determined by mCSM-PPI2 using the Interface Analysis option and then custom Python scripts were used to convert the mCSM-PPI2 output format into SAAMBE-3D and MutaBind2 input formats. After collecting all SSM results, which are mutation-ΔΔG pair lists for each initial structure (WT S-RBD, Δ1 and Δ2 complexes), nanobody mutation ΔΔG values were merged. Lists (L) from the different Web servers were first standardized by subtracting the median ΔΔG from each value, and then dividing the difference by the median absolute deviation (MAD), resulting in the so-called z-scoresThese z-scores were then simply averaged to get the consensus z-scoreThis procedure is similar to the prediction-unifying technique described previously.29 Nanobody mutations were then ranked by their consensus z-scores, resulting in the list from which mutations were selected.

MD simulations were carried out using GROMACS. Complexes were solvated using the tip4p water model,30 while sodium and chloride ions were added to electrostatically neutralize the system (final concentration of NaCl is 0.15 M). The AMBER-ff99SBildnp-star31 force field was used for all runs. The following steps were used to equilibrate the proteins: first, a steepest descent integrator with position restraints of 1000, 500, 100 and then 0 kJ × mol–1 × nm–2 and a maximal force tolerance of 50 kJ × mol–1 × nm–2 was used. Next, an NVT equilibration was performed using the leapfrog integrator for 50,000 steps with a step size of 2 fs with positional restraints of 1000, 500, 100, and 0 kJ × mol–1 × nm–2 at 310 K. Finally, an unconstrained NPT step was followed to allow the introduction of pressure. Complexes were simulated for total simulation times between 331 and 1000 ns.

After centralizing the resulting trajectories, the gmx_MMPBSA software32 was used to perform single-trajectory MM/GBSA calculations. The trajectories were analyzed from 50 ns to their ends with an interval of 100 ps. The leaprc.ff99SBildn force field was used with GB-OBC1 Generalized Born Method33 and 0.15 M salt concentration. No entropy calculations were performed, generating ΔΔH output values.

## Section: Materials and Methods › Construction of Expression Plasmids

Cloning was carried out similarly as in previous studies.15 First, a modified pMAL plasmid was generated by complementing the original vector with a thrombin cleavable N-terminal Ecotin-His6 tag, a method that has been shown to facilitate nanobody expression in bacterial systems. A pET-32b derived multiple cloning site was introduced to facilitate restriction cloning of nanobody constructs. Next, the genes of each target mutant nanobody were synthesized as a double-stranded gene fragment (minigene) (IDT) and were ligated into the vector (BamHI-XhoI restriction enzyme pair was used). See SText1–8 for further details.

DH5α competent cells (Subcloning Efficiency DH5α competent cells ThermoFisher, cat. No. 18265017) were used for plasmid cloning procedures and transformed by heat shock transformation, following the manufacturer’s instructions. Transformed cells were then selected on LB agar containing ampicillin (AMP) at a concentration of 100 μg/L.

## Section: Materials and Methods › Nanobody Expression and Purification

Similarly, ecotin fusion proteins were overexpressed in E. coli Shuffle-T7 cells, as described in the reference.15 Cells were grown overnight at 37 °C on LB agar plates containing AMP (100 μg/mL). Single colonies were transformed to 50 mL LB (100 μg/mL AMP) and were incubated for 3 h at 37 °C with shaking at 180 rpm. For protein production, these precultures were inoculated (100-fold) into 2YT medium containing 2 g/L glucose, and cells were grown at 37 °C until the absorbance of the medium at 600 nm reached 0.8 (OD600). Cells were induced by adding 0.5 mM isopropyl β-d-1-thiogalactopyranoside (IPTG). Expressions were carried out overnight (∼12 h) at 30 °C. Cultures were harvested by centrifugation (4500 g for 10 min at 4 °C). The pelleted cells were resuspended in 50 mL buffer A (300 mM NaCl, 50 mM Na2HPO4, pH = 8.0) per L of medium and cells were disrupted by ultrasonication. After centrifugation (23,000g, 20 min, 4 ° C) the supernatants were collected and applied to a 5 mL HisTrap column at a flow rate of 0.8 mL/min. After binding, the column was washed with buffer A. Elutions were performed with an isocratic gradient using an elution buffer (buffer A complemented with 250 mM imidazole) at a flow rate of 4 mL/min.

The collected fractions were pooled and dialyzed in 4 L PBS. After dialysis, the fusion protein was cleaved by thrombin protease (0.01 μL/μg) overnight. The constructs were applied to Ni2+ column again, but this time the flow-through fractions were collected. The samples were then concentrated using a 10 kDa ultrafiltration device and were further purified with size exclusion chromatography (Superdex 75 10/300 GL column) (SFigure 1–6). The fractions from the different purification steps were analyzed by SDS-PAGE to determine the correct molecular weight (SFigure 7–8). Protein samples dissolved in PBS were stored at −80 °C until further use. Expression yields are indicated in STable1.

## Section: Materials and Methods › RBD Domain Expression and Purification

The His-tagged Spike RBD variants were expressed in Chinese Hamster Ovary (CHO) Express cells in the ExpiCHO expression system for 12 days at 34 °C by 8% CO2 containing CO2 thermostat according to the manufacturer’s instructions. Corresponding DNA sequence data can be read in SText1–2. The expressed protein was deposited into the ExpiCHO cell medium, which was collected and purified by using Ni2+ immobilized metal affinity chromatography (Ni-IMAC by HisTrap Cytiva column, Product no:10316910) using the FPLC Akta Pure 2 system. After purification the sample was then dialyzed in PBS buffer (ExpiCHO Expression System User Guide, Pub. No. MAN0014337 Rev. D.0).

## Section: Materials and Methods › Biolayer Interferometry Measurements

The S-RBD/nanobody interactions were measured on Anti-Penta-His biosensor tips managed by an Octet K2 (Sartorius) system. Proteins were dialyzed in PBS to minimize signal errors caused by the buffer difference. Note that 0.02% Tween-20 was also used here to prevent aspecific associations of molecules. Sensors were loaded with a 5 μM S-RBD solution. Associations were followed by adding nanobodies at different concentrations. A solution of 10 mM glycine at a pH of 2.5 was used to regenerate the sensor tips after each measurement. The association and dissociation curves were analyzed using the Octet System software and visualized with Python scripts using the Matplotlib34 package.

## Section: Results and Discussion

(A) Box-and-whiskers plots for the predicted ΔΔG values using different ML methods collected for all three nanobodies and S-RBD variants. The middle line indicates the median of the dataset, boxes extend from the lower to the upper quartile, and the whiskers indicate the data range. Outliers are indicated by partially opaque dots. (B) Kernel density estimation of the predicted ΔΔG values resulting from the different ML methods.

Cross-scatter plots between the results of the different predictors to visualize predictor correlations.

Interfacial residues colored according to their average absolute consensus z-scores on nanobodies H11-H4, Nb20, and ab8, shown in panels (A) (B), and (C), respectively. The color scale ranges from blue, indicating a low average absolute z-score, through purple, up to red, indicating a high average absolute z-score.

Binding of the H11-H4 H100Y mutant nanobody to (A) Spike protein S-RBD wild-type variant and (B) S-RBD Δ1 variant at different concentrations. The measurements are characterized by fast association and fast dissociation kinetics relative to the WT H11-H4 nanobody.

Binding of the ab8 E127W mutant nanobody to (A) WT S-RBD and (B) Δ1 S-RBD variant at different concentrations. The measurements are characterized by fast association and fast dissociation kinetics.

## Section: Results and Discussion › Application of ML Methods

In the first step of our study, mCSM-PPI2, SAAMBE-3D and MutaBind2 were used to perform in silico site saturation mutagenesis (SSM) to scan all mutations on the S-RBD/nanobody interaction surface. The distribution of the predicted mutant ΔΔG values was analyzed (Figure 2) using statistical analysis techniques. 77.5, 91.8, and 84.9% of the mutation data points are predicted to be complex destabilizing, according to the mCSM-PPI2, SAAMBE-3D and MutaBind2 protocols, respectively (Figure 2A and Table 1). To assess the correlation between the results generated by these different predictors, Spearman correlation coefficients (SpR) were calculated between the predicted ΔΔG values. The correlation between SAAMBE-3D and mCSM-PPI2 was found to be the highest (SpR = 0.584), while other pairs showed lower values (SAAMBE-3D and MutaBind2: SpR = 0.226, mCSM-PPI2 and MutaBind2: SpR = 0.352, Figure 3). These correlation measurements are important to show the degree of independence between the components of the ML ensemble. Ensembles containing excessively correlated methods would introduce unwanted biases into the predictions.

Another aspect we tested is how well the mutation types separate the data points into stabilizing and destabilizing mutations. Residues were grouped according to their chemical nature: (1) F, W, Y, H were considered aromatic, (2) R, H, K, D, E, S, T, N, Q were considered hydrophilic/nonpolar, (3) R, K were considered positively charged and (4) D, E were considered negatively charged. In addition, a group containing only G and a group containing only P were also considered. After selecting an appropriate group, the mutation types [x to y] and [y to x] were separated, where x is part of the selected group and y is not. From this point on, the nomenclature “out of group mutations” is used for the [x to y] cases and “into-group mutations” is used for the [y to x] cases. To assess the mutation type discriminative power of the predicted ΔΔG values, ROC-AUC values were calculated based on the true and false out of group mutation rates at different ΔΔG thresholds (Table 2 and SFigures 9–10). Kernel density estimates for the out of group and into-group mutations were also plotted for easy visual inspection of the ΔΔG distributions (SFigures 11–12).

Groups for which the mutation types achieve good separation are groups for which the AUC value is either close to 1 or 0, i.e., far away from 0.5. This analysis shows how these groups affect the ΔΔG prediction result. Consensus results indicate that mutation of a nonaromatic residue to an aromatic one is generally predicted to be beneficial for the binding of the selected nanobodies to any S-RBD variant, while mutation of a nonproline residue to a proline disrupts the nanobody-antigen complex. Predictors can also vary widely in this regard; in the case of “into-glycine” mutations SAAMBE-3D shows a large separation (favoring out of glycine mutations as binding-promoting), while MutaBind2 shows no separation for this group. We would argue that these biases, especially the one concerning the aromatic residues, are important aspects of these ML methods during the nanobody design process.

Additional analysis regarding the agreement between the ML methods (SText9, STable2) and the effects of the Δ1 or Δ2 subvariant mutations (SText10, STable3, SFigure 13) can be found in the Supporting Information file.

As a final analysis of the behavior of the predictor algorithms, we looked at the consensus z-scores of each mutation (see the Materials and Methods section for technical details) and ordered them increasingly (Table 3). Table 3 served as a template for selecting the appropriate nanobody mutations for MD analysis and subsequent bacterial expression and BLI measurements. To visualize the importance of the nanobody sites, we calculated the average absolute z-score for each site, i.e., the average of the absolute z-scores of the 19 different mutations for each specific interface amino acid. These averages were stored in pdb files and used to color the resulting structure (Figure 4). In the H11-H4 vs WT S-RBD complex the H11-H4 sites R52, Y101 and Y104 have the highest average absolute z-score, meaning that mutations at these sites are expected to have large effects on nanobody binding. R52 is in a salt bridge with the S-RBD site E484 and also forms a pi-cation stacking interaction with F490. It also stabilizes the position of the nanobody loop between H100-L106 through an H-bond with S103. Y101 and Y104 both participate in hydrophobic interactions, the former one with the S-RBD residue Y449, the latter one with L455, F456, Y489 and Q493. In Nb20 sites R31, A51 and Y104 are highlighted with the highest z-scores. R31 is, again, a key residue forming a salt bridge with E484 and a pi-cation interaction with F490, similar to R52 in H11-H4. A51 is part of a small hydrophobic core additionally formed by A29 and Y449. As seen in STable2, mutation of this alanine to larger hydrophobic residues is predicted to be favorable, expanding this hydrophobic interaction network. Interestingly, Y104 does not participate in any major interaction with the S-RBD, except for a possible H-bond with E484, but rather fills a cavity formed between the two proteins. Mutations of Y104 to smaller residues, such as E, T, P or A, result in unfavorable predicted ΔΔG values. Finally, in nanobody ab8, sites W68, R71, and Y73 appear to be most sensitive to mutations. These residues are close to each other at the interface, in proximity with the critical S-RBD residue E484, presumably all responsible for its stabilization.

(A) Box-and-whiskers plots for the predicted ΔΔG values using different ML methods collected for all three nanobodies and S-RBD variants. The middle line indicates the median of the dataset, boxes extend from the lower to the upper quartile, and the whiskers indicate the data range. Outliers are indicated by partially opaque dots. (B) Kernel density estimation of the predicted ΔΔG values resulting from the different ML methods.

Cross-scatter plots between the results of the different predictors to visualize predictor correlations.

Interfacial residues colored according to their average absolute consensus z-scores on nanobodies H11-H4, Nb20, and ab8, shown in panels (A) (B), and (C), respectively. The color scale ranges from blue, indicating a low average absolute z-score, through purple, up to red, indicating a high average absolute z-score.

## Section: Results and Discussion › MD Simulations, RING Analysis, and MM/GBSA Calculations

We selected 11 interesting H11-H4, Nb20 and ab8 mutants from Table 3 for MD simulations and subsequent MM/GBSA ΔΔH calculations. In addition, simulations were performed for the H11-H4 double mutant V102Y, L106W in complex with the WT S-RBD and the mutant Y104D, which was predicted to be highly disruptive to complex formation. Analyses were performed for both WT S-RBD and Δ1 S-RBD complexes. Additionally, in order to select mutants for MM/GBSA analysis, we extracted additional information from the MD runs in the form of RMSD and clustering calculations. Table 4 summarizes the results of the MM/GBSA and clustering analysis runs. SFigure 14–19 show the RMSD time evolution of the complexes and the cluster centers as protein ensembles. Since the Kd value of the WT Nb20 is very low, suggesting a highly optimized interface with little room for improvement, we focused our efforts on the H11-H4 and ab8 nanobodies, where the high computational demand of MD would be a worthwhile investment.

To determine the qualitative cause of the quantitative binding differences, we subjected the best binding mutant and the WT nanobody complexes to RING analysis.35,36 Comparing the WT H11-H4/WT S-RBD complex with the L106W mutant H11-H4/WT S-RBD complex, the resulting ΔΔH is −4.36 kcal/mol. Changes in the average count of interactions per frame are from 10.7 to 11.9 for van der Waals (VdW) interactions, from 8.0 to 9.1 for H-bonds, and from 4.1 to 4.8 for pi-pi stacking interactions. Interface residue–residue interaction networks can be seen on SFigures 20 and 21, which show high similarity. We examined the behavior of the residues at this mutation site. L106 and W106 both interact with E484, although these interactions are transient and backbone-mediated H-bonds, mostly independent of the side chains. W106 forms an additional VdW interaction with G485. Inspection of the cluster center structures shows that the introduction of the bulky tryptophan facilitates an intrachain edge-to-face interaction with Y59, a residue which does not interact strongly with the L106 at the WT site.

When the Δ1 S-RBD protein is considered in complex with H11-H4, the nanobody mutation L106F results in the largest increase in binding affinity, with a ΔΔH of −7.07 kcal/mol. In fact, this is the largest negative ΔΔH of all the complexes studied. This large change is also reflected in the average number of interactions: the average number of VdW interactions per frame increases from 11.4 to 12.5, for H-bonds this change is from 9.5 to 10.4, pi–pi stacking interactions increase in number from 3.8 to 4.7, and salt bridges increase from 1.2 to 1.4, when the L106F mutation is introduced. Site 106 has little or no direct interaction with the S-RBD. In case of the WT complex, L106 forms a weak H-bond through its backbone with E484 (see SFigures 22 and 23). In the mutant complex F106 forms hydrophobic interactions with the aliphatic side of the E484 glutamic acid. This is due to the conformational constraint of F106 imposed by the presence of Y59 on the same chain.

Switching from the WT Nb20/WT S-RBD complex to the A51W Nb20/WT S-RBD complex results in a calculated ΔΔH of −1.03 kcal/mol. As expected, such a small improvement in binding affinity is not reflected in the average interaction counts of the different secondary chemical bonds: VdW counts are 14.1 and 14.8, H-bond counts change from 8.5 to 8.3, and salt bridge counts are 0.5 and 0.7 for the WT nanobody and A51W mutant nanobody complexes, respectively. In this case, however, the introduction of W51 can be easily spotted on the interaction network diagram (SFigures 24 and 25). Instead of a single A51-Y449 interaction, W51 forms interactions with Y449, L452, Q493 and S494. This means that while A51 forms an average of 0.53 interactions per frame, W51, due to its size, is able to form 2.33 interactions. Although most of these interactions are VdW contacts, the tryptophan is large enough to reach the backbone oxygen of Y449 and form an interfacial H-bond with its Hε1 hydrogen atom.

In the case of the ab8/WT S-RBD complex, the E127W proved to be the best nanobody mutation with the lowest calculated ΔΔH of −5.57 kcal/mol. Interestingly, in this case, the average number of the different interaction types is not significantly different between the two complexes. The average number of VdW interactions increases from 16.0 to 17.5, for the H-bonds this negligible change is from 14.8 to 14.9, while for pi-pi stacking interactions this number decreases from 1.9 to 1.7. In addition, the two interaction networks seen on SFigures 26 and 27 are also very similar. Neither L106, nor W106 appear in these networks. Looking at the first few cluster centers, it can be seen that L106 and W106 both face the solvent bulk, pointing away from the S-RBD. Thus, according to the simulations, the effect of this mutation acts indirectly on the nanobody/S-RBD interface, via allosteric or solvation effects.

For the ab8/Δ1 S-RBD complex, the S79Y mutation was the most favorable. The corresponding ΔΔH value is −0.31 kcal/mol, much lower than for the proposed changes for the ab8/WT S-RBD complex. The S79Y mutation causes an increase in the average number of VdW interactions from 17.4 to 18.2, a decrease in H-bonds from 15.4 to 14.4, and a slight increase in the average number of pi-pi stacking interactions from 1.7 to 1.8. Similar to several previous cases, the interaction profile of the WT and S79Y nanobody Δ1 S-RBD complexes is almost identical (SFigures 28 and 29). However, in contrast to that seen in case of the ab8/WT S-RBD complex, S79 forms a strong H-bond with the critical S-RBD residue E484, which is lost when Y79 is introduced, forming only relatively weak van der Waals contacts with E484. Although homochain interactions are not indicated on the networks, in the cluster center structures Y79 is close to the hydrophobic nanobody residues W68 and P82, suggesting intrachain interactions as the rationale for this type of mutation choice.

## Section: Results and Discussion › Production and Purification of Mutant Nanobodies

We aimed to compare the in vitro binding strength of the in silico proposed mutant nanobody versions to the WT and Δ1 S-RBD variants with the binding strength of the previously tested WT nanobodies.15 After expression, the size and purity of the nanobodies were validated by SDS-PAGE (SFigures 7–8). The expression yields are summarized in STable1.

The production of two of the mutants (ab8 S79Y and ab8 L129F, see STable1) proved unsuccessful even after several attempts. In these cases, while Ni-IMAC purification of the target protein fused to ecotin was still successful (SFigures 8 and 6), the target protein precipitated during cleavage of the fusion construct, indicating that the nanobody itself is unstable in solution. The ML based techniques used here mostly favored the mutations from small to medium sized residues (e.g., S, E, L, H, etc.) to larger aromatic residues (Y, W, F). It has been previously reported that aromatic residues are indeed more abundant at protein–protein interfaces.37 This can be attributed to the tendency of large hydrophobic residues (such as those residues with aromatic side chains) to bury themselves and displace water from the interface. Although this mechanism favors the formation of interfaces, it also destabilizes proteins in their monomeric form. In addition to reducing the solubility of the protein, these changes can lead to monomer misfolding or even the formation of homomultimeric aggregates. We hypothesize that the failure to purify the ab8 mutants S79Y and L129F is due to these reasons.

All other mutants were successfully produced and purified. (SFigures 7 and 1–5) We can observe that the production yield of the H11-H4 nanobody is low compared to the yield of the ab8 mutant. This is a characteristic of the H11-H4 nanobody, as we have already observed with the WT nanobodies as well.15 However, the amount of material required for further protein–protein binding assays was successfully obtained.

## Section: Results and Discussion › Biolayer Interferometry Measurements of the Mutant Nanobodies

After the expression of the selected mutant variants, we performed a BLI binding assay between the nanobody mutants and both the wild-type and the Δ1 variant S-RBD. First, the complex formation of the WT H11-H4 nanobody and its four mutants (V102Y, L106W, H100Y, L106F) with the two S-RBD variants was measured.

Analyzing the nature and kinetics of the binding and comparing them with their WT counterparts, all the mutants show faster association to the S-RBD, as well as faster dissociation (Figure 5A and SFigure 30–32). This means that the binding partners can easily find each other, leading to the hypothesis that the nanobody binding interface has become more available to the S-RBD. However, the fast release of the nanobody from the complex indicates that the resulting interface is weaker, suggesting suboptimal residue–residue interactions. Comparing the Kd constants in the summary, it can be seen that none of these mutants can produce better binding values than that of the WT (Table 5).

These mutant nanobodies were also tested with the Δ1 S-RBD variant. However, the resulting binding was very weak in most of the cases (Figure 5B and in SFigures 30–32/B). For two of the mutants, namely the L106F and H100Y, the dissociation values were better than in the case of the wild-type nanobody, but only in the case of H100Y was it sufficient to obtain a better Kd value and a better binding result.

H11-H4 showed strong binding to both the wild-type and Δ1 S-RBD protein, making it difficult to design better mutants. As expected, the binding to the WT S-RBD was not improved, while the Δ1 S-RBD mutants mostly showed worse binding. This may be due to the bias of the predictors toward aromatic substitutions that we noted earlier. At certain interface sites, the introduction of bulky lipophilic residues may help complex formation, but steric clashes may also disrupt these already well designed interfaces, increasing the Kd value.

In the case of the E127W mutant ab8 nanobody, regardless of which S-RBD variant is the partner, the binding curves are well behaved and show similar binding kinetics. Both association and dissociation are fast. At the same concentrations, the binding curve is similar to that of the WT ab8/WT S-RBD, but in the case of the Δ1 S-RBD, the binding curve shows much stronger binding due to extremely fast association (Figure 6). Numerical data for these kinetic analyses are shown in Table 6.

Binding of the H11-H4 H100Y mutant nanobody to (A) Spike protein S-RBD wild-type variant and (B) S-RBD Δ1 variant at different concentrations. The measurements are characterized by fast association and fast dissociation kinetics relative to the WT H11-H4 nanobody.

Binding of the ab8 E127W mutant nanobody to (A) WT S-RBD and (B) Δ1 S-RBD variant at different concentrations. The measurements are characterized by fast association and fast dissociation kinetics.

## Section: Conclusions

The rational design of antibody mimetics is a nontrivial task, meaning that direct exploration of the mutation space by in vitro experimental means is usually very expensive and time-consuming. This design pattern can be complemented by in silico studies, which promise to narrow down the mutation options to be tested, lowering research costs and accelerating the development of potent binders. Here, we proposed and analyzed a possible in silico coupled in vitro nanobody design workflow against two SARS-CoV-2 S-RBD variants.

By testing our proposed nanobody design workflow, we were able to identify the strengths and weaknesses of the current state of in silico assisted nanobody design. Our three-step pipeline consisted of: (1) ML-assisted selection of nanobody mutants against two SARS-CoV-2 S-RBD variants, (2) MD- and MM/GBSA-assisted prefiltering of ML-suggested mutants, and (3) expression of nanobody mutants and their BLI measurements as an experimental filtering and validation method. We considered three different nanobodies, namely H11-H4, Nb20, and ab8, as well as two different variants of the S-RBD. We analyzed the behavior of three ML methods: mCSM-PPI2, MutaBind2 and SAAMBE-3D. We showed how their predictions are distributed, how these methods correlate with each other, as well as how these methods prefer different mutation types, such as the mutation of a nonaromatic residue to an aromatic one. The consensus z-scores of the mutations were used to map the importance of the mutations at the nanobody/S-RBD interface. The interactions of the most important sites were also analyzed.

We further analyzed the nanobody mutants proposed by ML using MD and MM/GBSA. It is evident from the collected data that the order determined by the consensus z-score is not necessarily in agreement with the order determined by the ΔΔH values from the MM/GBSA runs. One possible explanation for this is that our MM/GBSA runs ignored the entropic effects. (The calculations either failed or the variance of the ΔΔG values became unacceptable when we tried to include the entropic contribution using the proposed techniques (quasi-harmonic approximation, interaction entropy, or C2 entropy38) (data not shown)). However, a much more likely explanation for the discrepancy is the use of single-trajectory MM/GBSA approximations (which was unfortunately necessary to achieve satisfactory accuracy), the low sampling rate of the full conformational space (even after 1 μs of simulation), and the low accuracy of ML methods in the case of these protein complexes.

Finally, we also identified an important weakness in the optimization process: ML methods do not optimize for protein stability, but only for successful binding. This may explain the failure to express two ab8 mutants (S79Y and L129F), as their separation and purification from the fusion partner ecotin remained unresolved. Nevertheless, we successfully synthesized five different nanobody mutants and showed that H11-H4 H100Y indeed binds to the Δ1 S-RBD more strongly than its WT counterpart, and that E127W ab8 binds to both S-RBD variants with higher affinity than the WT.

Further refinements to the proposed workflow could potentially lead to more accurate in silico affinity predictions. Including more than three ML methods based on several diverse techniques would result in more trustworthy ensemble predictions. Since these methods work on the WT protein structure, a short conformational search prior to the ML runs could provide several different input conformations, yielding a distribution of ΔΔG predictions rather than a single value. This could also be achieved with a direct feedback loop between the ML runs and the MD runs. We also pointed out the lack of stability prediction steps in the workflow, which turned out to be an important missing filter. Finally, more accurate ΔΔH or ΔΔG predictions could also be extracted from the MD runs, either by including the entropy calculations into the MM/GBSA protocol, or by using alchemical methods (e.g., thermodynamic integration, free energy perturbation, or umbrella sampling).


---

# Evolution of Drug Development and Regulatory Affairs: The Demonstrated Power of Artificial Intelligence

- **Authors:** Linda Nene, Brian Thabile Flepisi, Sarel Jacobus Brand, Charlise Basson, Marissa Balmith
- **Issuer:** Clinical therapeutics
- **Type:** Scientific article
- **Published:** 2024-07-08
- **Language:** en
- **DOI:** 10.1016/j.clinthera.2024.05.012
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38981791/
- **Licence:** CC-BY-NC

## Section: Abstract

Artificial intelligence (AI) refers to technology capable of mimicking human cognitive functions and has important applications across all sectors and industries, including drug development. This has considerable implications for the regulation of drug development processes, as it is expected to transform both the way drugs are brought to market and the systems through which this process is controlled. There is currently insufficient evidence in published literature of the real-world applications of AI. Therefore, this narrative review investigated, collated, and elucidated the applications of AI in drug development and its regulatory processes. A narrative review was conducted to ascertain the role of AI in streamlining drug development and regulatory processes. The findings of this review revealed that machine learning or deep learning, natural language processing, and robotic process automation were favored applications of AI. Each of them had considerable implications on the operations they were intended to support. Overall, the AI tools facilitated access and provided manageability of information for decision-making across the drug development lifecycle. However, the findings also indicate that additional work is required by regulatory authorities to set out appropriate guidance on applications of the technology, which has critical implications for safety, regulatory process workflow and product development costs. AI has adequately proven its utility in drug development, prompting further investigations into the translational value of its utility based on cost and time saved for the delivery of essential drugs.
