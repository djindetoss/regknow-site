# Artificial intelligence in oncology drug development and management: a precision medicine perspective

- **Authors:** Caixia Fang, Pengfa Zhou, Xuerong Zhang, Yongsheng He, Qingwei Yang
- **Issuer:** Frontiers in oncology
- **Type:** Scientific article
- **Published:** 2025-12-04
- **Language:** en
- **DOI:** 10.3389/fonc.2025.1609827
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41426328/
- **Licence:** CC-BY

## Section: Abstract

The management of oncology drugs is inherently complex, facing challenges such as high development costs, prolonged timelines, and substantial inter-patient heterogeneity. Recent advances in artificial intelligence (AI) have introduced transformative capabilities across the entire cancer drug lifecycle—from target discovery and compound screening to clinical trial optimization, individualized therapy, toxicity management, supply chain logistics, and regulatory oversight. AI enables precise target identification, accelerates virtual drug screening and molecular design, and enhances clinical trial efficiency through intelligent patient stratification and adaptive protocols. Moreover, AI facilitates personalized treatment decision-making, early prediction of drug resistance, and real-time toxicity surveillance, while improving pharmacovigilance and post-market drug evaluation using real-world data. Here, “post-market drug evaluation” refers to real-world effectiveness and safety assessment using spontaneous reports (e.g., FAERS/VigiBase) and EHR/claims-based outcomes, rather than cost-effectiveness analyses. Examples include EHR-NLP to surface immune-related adverse events, AI-assisted trial recruitment and adaptive designs, and individualized dosing frameworks (e.g., CURATE.AI). Despite its enormous promise, AI-driven oncology drug management faces notable challenges in data integration, model interpretability, clinical translation, fairness, and regulatory governance. This review comprehensively summarizes the current applications of AI in oncology pharmacology, highlights key opportunities and barriers, and explores future directions at the intersection of AI, precision medicine, and cancer therapeutics. Future priorities include prospective multi-site evaluations, fairness auditing, and continuous post-market algorithmovigilance.

## Section: Introduction

The development and management of oncology drugs is an extraordinarily complex, costly, and time-consuming process. It typically takes 10–15 years and over one billion dollars to bring a novel compound from candidate identification to market approval (1). This review focuses on AI in anti-cancer drug development and clinical management, spanning discovery, clinical translation, and post-marketing safety/effectiveness, rather than AI in general cancer pathobiology. Despite such substantial investments, the failure rate in oncology drug development remains alarmingly high—studies have reported attrition rates exceeding 95% during clinical development (2). This leads to an annual waste of $50–60 billion on failed oncology clinical trials, in which numerous patients participate without yielding effective therapies (2–4). The inherent heterogeneity and inter-patient variability in tumors further complicate this landscape: genetic and phenotypic discrepancies exist not only across different patients but also among tumor cells within the same individual (3, 5). This diversity often renders standardized treatment regimens ineffective, limiting therapeutic efficacy while increasing the likelihood of adverse effects (5–7). Consequently, oncology drug development is hindered by high costs, prolonged timelines, and profound individual variability.

Against this backdrop, AI has emerged as a transformative tool garnering increasing attention in biomedicine (8). The accumulation of vast, multidimensional datasets—from genomics and proteomics to electronic health records and scientific literature—presents a unique opportunity for AI to extract actionable insights through advanced data processing and pattern recognition capabilities (9–11). By leveraging complex algorithms to mine large-scale data, AI can enhance efficiency, reduce development costs, and improve success rates throughout the drug development lifecycle (12–14). For instance, AI enables the identification of novel therapeutic targets, optimization of molecular design, and personalization of treatment strategies based on patient-specific features. This data-driven paradigm is gradually supplanting traditional empirical approaches, offering faster and more precise development pipelines (12, 15, 16). In the context of highly heterogeneous malignancies, AI provides indispensable tools to advance individualized therapy.

Despite its tremendous promise, multiple challenges persist in oncology drug management. One critical obstacle is drug resistance. Tumors are highly adaptive and often acquire resistance shortly after initial treatment efficacy, leading to disease recurrence. In fact, therapeutic resistance is widely regarded as the greatest barrier in cancer treatment (17–19). Clinicians frequently encounter patients who exhibit poor responses to multiple therapies, resulting in treatment failure and poor prognosis (20, 21). Predicting and overcoming resistance is therefore a central challenge in oncology. Another major concern is the prediction of drug toxicity. Clinical trials cannot fully exclude unforeseen serious adverse reactions due to limited exposure to diverse populations. Effective toxicity prediction is essential for safeguarding patient safety, yet traditional methods struggle to accurately identify high-risk signals amid complex molecular and clinical data (22). In summary, drug resistance and toxicity significantly undermine treatment efficacy and safety in cancer therapy, necessitating novel solutions—such as AI—to address these urgent issues. Unlike prior reviews focused on isolated stages, we synthesize end-to-end applications and explicitly integrate post-marketing pharmacovigilance/RWE with upstream discovery across the lifecycle.To avoid ambiguity between “drugs to study cancer” and “drugs against cancer,” our focus is on AI for anti-cancer drug development and clinical use across the lifecycle (target discovery, screening/design, clinical trials, precision therapy/dosing, toxicity/safety, supply chain, and post-marketing pharmacovigilance/RWE).

## Section: Method

We conducted a narrative review using PubMed, Scopus, and Web of Science covering January 2020–April 2025. Inclusion criteria: oncology-focused primary or methodological studies applying AI to drug discovery/development, clinical trials, precision therapy, toxicity/safety, supply chain, or pharmacovigilance. Exclusion: non-oncology scope or opinion-only pieces without methods. Two authors independently screened titles/abstracts and full texts; disagreements were resolved by consensus.

## Section: Applications of AI in oncology drug development

Oncology drug development encompasses a comprehensive process, ranging from target discovery and compound screening to clinical trial design. In recent years, AI technologies have been progressively integrated into every stage of this pipeline, catalyzing a paradigm shift in drug discovery and development. Consistent with Figure 1, we begin with discovery and design (Sections 3.1–3.2) and highlight preclinical/translation utilities (knowledge-graph mechanism hypotheses, multi-omics triangulation) that connect discovery to clinical trials (Section 3.3).

AI across the oncology drug lifecycle. A circular schematic depicts six stages: (1) Drug discovery and design; (2) Preclinical and translational research; (3) Clinical trials; (4) Precision therapy and dosing; (5) Toxicity and pharmacovigilance; (6) Supply chain and regulation. The central “AI” hub emphasizes cross-cutting methodsthat integrate evidence across stages.

Representative AI applications in oncology drug development and management: tasks, exemplar methods, data sources, and evidence types.

## Section: Applications of AI in oncology drug development › Target discovery and validation

Drug target identification represents the initial and critical step of new drug development. Given the intricate pathogenic mechanisms of cancer, researchers are increasingly employing AI—particularly deep learning techniques—to mine vast biological datasets for novel therapeutic targets. By integrating multi-omics data, including genomics, transcriptomics, and proteomics, AI can uncover key molecular networks and vulnerable nodes driving tumor progression (12, 23). Machine learning models can correlate genomic mutations, expression profiles, and clinical outcomes to identify subtype-specific oncogenic drivers or signaling pathways. Compared to manual analysis, AI excels at handling the immense scale and complexity of biological networks, revealing patterns and associations that may elude human experts (24, 25). Advanced AI models such as AlphaFold have further revolutionized target validation (26, 27). AlphaFold predicts the three-dimensional structures of proteins with remarkable accuracy, providing crucial insights into protein conformations and druggability (28, 29). Researchers can now assess whether a protein contains ligand-binding pockets suitable for small-molecule intervention, thus determining its potential as a viable drug target (29, 30). In essence, AI has enabled transformative progress from the macroscopic level of omics networks to the microscopic resolution of molecular structure, thereby accelerating the early phases of oncology drug development.

Beyond target discovery, AI also contributes to target validation by assessing the causal relationship between targets and disease, as well as their druggability. Traditional validation relies heavily on in vitro and animal models, which are time-consuming and resource-intensive. Today, researchers are leveraging AI to construct disease knowledge graphs and causal inference models for target validation. By embedding molecular interaction data from literature and databases into graph-based frameworks, AI can simulate the therapeutic effect of inhibiting a specific target and infer possible mechanisms of action (1, 31, 32). For instance, studies have integrated drug–disease and drug–target networks and employed deep learning models (e.g., DeepDR) to extract high-level features through random walk strategies, predicting drug efficacy against particular targets and cancers (1) These network-based AI approaches enable system-level validation of target perturbation effects, thereby enhancing the reliability of target selection. Overall, AI facilitates more efficient (faster identification of critical targets) and more precise (elimination of false positives) discovery and validation processes, thereby increasing the success rate of oncology drug development from the outset. Accurate protein structures (e.g., AlphaFold) inform pocket assessment and hypothesis-driven design for oncology targets; however, prospective studies directly linking structure prediction to improved oncology clinical outcomes remain limited.

## Section: Applications of AI in oncology drug development › Virtual drug screening and design

Once a target is identified, the next step involves discovering compounds capable of modulating the target. Traditional high-throughput screening (HTS) requires the synthesis and testing of thousands of molecules, which is both time-intensive and costly. The advent of AI has brought transformative improvements to in silico drug screening. Deep-learning pipelines enable in-silico screening, design, and optimization of large libraries, expediting early discovery.

One prominent strategy is the use of generative models such as generative adversarial networks (GANs) and reinforcement learning-based molecule generators (33). These models encode molecules as SMILES strings or molecular graphs, and after neural network training, they can generate entirely new chemical structures (31, 34). Generative models can be directed to create compounds with desired properties—for example, molecules with high affinity for a specific target and favorable pharmacokinetic profiles. Compared to random screening, AI-generated compounds are more targeted, significantly improving hit rates. Studies have shown that reinforcement learning can continuously optimize generation strategies to produce compounds with enhanced activity and drug-likeness, reducing early-stage design timelines from months to weeks (31, 35). For instance, algorithms like ReLEASE use reinforcement learning to iteratively evolve molecular structures, generating novel compounds with activity against predefined proteins (36). These AI-generated libraries have opened expansive chemical spaces for cancer drug discovery.

In addition to de novo design, AI is also used to virtually screen existing large-scale compound libraries for potential drug candidates. Deep learning models can predict binding affinity and bioactivity between compounds and biological targets by learning from molecular structures and target features (37). Graph neural networks (GNNs), for example, treat molecules as graph-based structures and efficiently model the relationship between structure and activity, enabling rapid screening of millions of compounds (38–40). Compared to traditional docking methods, AI models offer superior speed and accuracy, rapidly narrowing down promising leads. Reports suggest that AI-driven virtual screening can shorten early discovery cycles from months to weeks, particularly impactful in oncology where rapid options are needed. Furthermore, researchers have combined molecular dynamics simulations with machine learning to refine predictions of ligand–target interactions. AI can analyze trajectory data to evaluate the stability of ligand–protein complexes, filtering out initially promising but potentially unstable compounds (40, 41). This hybrid “simulation-plus-learning” approach further enhances screening precision.

In summary, AI has greatly improved the efficiency of lead compound discovery in oncology. It enables the innovative design of novel molecules, high-throughput screening of existing libraries, and optimization of drug-like properties. These advances reduce experimental workload and cost, accelerating the progression of candidates into preclinical development. Studies have shown that AI-based molecular screening and design significantly shorten development timelines and reduce expenses (42), offering faster and more diverse therapeutic options for cancer patients.

## Section: Applications of AI in oncology drug development › Clinical trial optimization

Following the preclinical stage, the design and execution of clinical trials are pivotal for the successful translation of oncology drugs into clinical use. Traditional clinical trials often suffer from challenges such as slow patient recruitment, prolonged timelines, and low success rates. AI technologies are now offering innovative solutions to optimize various aspects of clinical trial operations.

First, AI enhances patient stratification and recruitment—crucial steps in trial initiation. Natural language processing (NLP), a subfield of AI, can be used to automatically extract relevant patient characteristics from electronic health records (EHRs) and clinical narratives to identify individuals eligible for trial enrollment (43, 44). Previously, this process relied heavily on manual chart review, which is time-consuming and prone to missing eligible participants. Modern NLP algorithms are capable of parsing large volumes of unstructured clinical texts—such as physician notes, pathology reports, and diagnostic summaries—to extract key fields like diagnoses, biomarker status, and treatment history (45). For example, in lung cancer clinical trials, NLP tools can screen hospital databases to identify patients harboring specific gene mutations, thereby accelerating recruitment. Beyond eligibility screening, machine learning models can stratify patients into subgroups based on multi-dimensional data and predict which subsets are more likely to benefit from investigational therapies. This stratified approach allows for biomarker-driven trial design, improving signal detection and statistical power (46). Such “AI-enabled screening and enrichment” enhances both the efficiency and success probability of clinical trials. Compliance note. In all examples, EHR-based NLP screening occurs within covered entities under IRB approval and data-use agreements; no external re-identification of individuals is performed.

Second, AI can assist in adaptive trial design and real-time monitoring. Traditional randomized controlled trials (RCTs) with fixed protocols may be inefficient under certain conditions. In contrast, adaptive clinical trials, which adjust trial parameters based on interim results, offer a more flexible and efficient approach. AI models are well-suited for real-time analysis of accumulating trial data, providing support for dynamic decision-making (46, 47). For instance, predictive models can leverage historical and preliminary data to adjust dosing regimens or sample sizes mid-trial, ensuring patients receive more effective dosages or shortening trial duration (47). Additionally, AI enables the development of novel concepts such as synthetic control arms and digital twins (48). A synthetic control arm uses historical real-world data and AI modeling to simulate outcomes for control patients, thus reducing the need for placebo or standard-of-care enrollment in interventional trials (49). This approach is particularly valuable in oncology, where ethical and practical concerns favor maximizing access to new therapies. Digital twins—virtual representations of individual patients constructed using clinical and biological data—allow for simulated comparisons of different treatment outcomes and provide in-trial decision support (50). These techniques have the potential to not only enhance trial efficiency but also extend evidence generation beyond conventional settings.

Finally, AI contributes to safety monitoring and adherence management during clinical trials. Risks include selection bias or manipulation in algorithmic enrollment and privacy concerns when handling sensitive records. Pragmatic safeguards include pre-specified enrollment algorithms with version control, independent DSMB oversight, and auditable logs of model versions and inclusion/exclusion decisions; data handling should be IRB-approved and HIPAA-compliant with de-identification and role-based access governed by data-use agreements.

Timely identification of adverse events (AEs) and data anomalies is critical for ensuring patient safety. Machine learning models can continuously analyze incoming trial data to detect abnormal physiological patterns or early signs of AEs and trigger alerts for clinical intervention. For instance, AI-based systems have been used to monitor patient-reported outcomes and wearable device data, enabling early detection of serious side effects and mitigating risks through timely action.

In summary, AI is increasingly empowering all facets of clinical trial optimization (51). From patient identification and stratification to adaptive protocol design and continuous monitoring, AI tools are reshaping how trials are conducted. Literature reports indicate that AI can substantially reduce the cost and duration of trials while improving the likelihood of regulatory approval (37). In the context of oncology—where innovation is both urgent and competitive—AI-driven clinical trial optimization offers a pathway to bring effective therapies to patients more rapidly and efficiently. Representative AI applications, data sources, and evidence types are summarized in Table 1.

Representative AI applications in oncology drug development and management: tasks, exemplar methods, data sources, and evidence types.

## Section: AI-driven precision medication management in oncology

With the advent of increasingly diverse anticancer therapeutics, the challenge of tailoring treatment strategies to individual patients has become a central focus in clinical oncology. AI plays a pivotal role in enabling precision medication, including optimizing personalized treatment plans, predicting drug resistance, and managing toxicity.

## Section: AI-driven precision medication management in oncology › Personalized treatment decision-making

Each cancer patient exhibits a unique combination of genetic background, tumor molecular profile, and overall health status, resulting in highly variable responses to therapy. AI provides powerful tools to facilitate individualized medication strategies. By integrating patient-level data such as genomic mutations, gene expression profiles, pathophysiological parameters, and clinical history, machine learning models can predict a patient’s likelihood of responding to specific drugs, thereby supporting clinicians in selecting the most suitable regimen (52). For example, in advanced cancer cases where multiple treatment options are available, AI models can calculate the expected efficacy and risk for each therapy based on outcomes from similar patient cohorts, offering quantitative insights for decision-making.

Studies have demonstrated that multi-omics data, when input into AI models, can reveal biomarkers associated with drug response or tolerability (53). These biomarkers enable models to predict whether a patient is likely to benefit from a given treatment (54). In one multicenter study, an AI model incorporating tumor mutational profiles, transcriptomics, and clinical features outperformed traditional biomarkers such as PD-L1 expression in predicting response to immune checkpoint inhibitors. Such tools facilitate multidisciplinary team (MDT) discussions by providing data-driven guidance to design tailored treatment regimens, thereby realizing the promise of precision oncology.

Beyond treatment selection, AI also contributes to dose optimization. Traditional dosing schemes often follow fixed schedules or body surface area-based formulas, which inadequately account for individual variability. AI techniques—particularly reinforcement learning—can dynamically adjust drug dosage or scheduling based on real-time patient response, maximizing efficacy while minimizing toxicity (55). For instance, researchers have trained deep reinforcement learning models using virtual patient simulations to learn adaptive dosing strategies that prolong tumor control without exacerbating side effects. In real-world scenarios, AI-assisted dose personalization platforms such as CURATE.AI exemplify this approach: by analyzing a patient’s own longitudinal data, the platform continuously recommends individualized dosage adjustments (56). In a pancreatic cancer study, CURATE.AI successfully optimized dosing to reduce tumor markers while maintaining tolerable toxicity levels. These applications demonstrate that AI can break away from the “one-size-fits-all” paradigm of maximum tolerated dose (MTD), identifying optimal therapeutic windows tailored to each patient. As intelligent dosing systems become more widely adopted, personalized treatment is expected to achieve both improved outcomes and enhanced safety profiles.

## Section: AI-driven precision medication management in oncology › Resistance prediction and combination therapy design

Modern pharmacovigilance increasingly adopts a data-fusion paradigm in oncology, combining FAERS/VigiBase disproportionality with EHR-NLP extraction of adverse events to enable earlier, more sensitive signal detection. The adaptive evolution of cancer cells frequently leads to therapeutic resistance—one of the major causes of treatment failure in oncology (17). Studies show EHR-NLP can recover immune-related AE frequencies concordant with trial reports, supporting its use to supplement spontaneous reporting systems (57). To enable early intervention, researchers have begun applying AI models to predict the onset of resistance and propose counterstrategies. One approach involves training time-series models (e.g., recurrent neural networks or Bayesian networks) on longitudinal data such as tumor burden changes and imaging features to anticipate progression. Other studies utilize sequential genomic data from repeated biopsies to reconstruct evolutionary trajectories and detect emerging resistant clones. AI can identify mutation patterns or expression signatures associated with resistance and issue alerts when similar trends are detected, allowing clinicians to consider preemptive treatment adjustments or initiate combination therapy.

Combination therapy is a key strategy to overcome resistance by simultaneously targeting multiple oncogenic pathways and reducing the likelihood of tumor escape. Traditionally, identifying effective drug combinations was a laborious and largely empirical process. AI has introduced a data-driven framework for discovering synergistic drug pairs by integrating knowledge graphs and deep learning. By constructing multi-relational graphs encompassing drugs, genes, and diseases, AI models can mine for combinations with predicted synergistic potential. For instance, the knowledge graph embedding model KGE-DC has been used to predict drug pairs with enhanced efficacy against specific cancers, several of which have been validated in preclinical models (58). Deep learning models can also predict drug synergy by integrating compound structures, target information, and cellular assay data (59). Graph neural networks trained on large pharmacogenomic datasets have successfully ranked drug pairs for their synergy potential in specific tumor types and have retrospectively identified many clinically validated combinations (60, 61). Such AI-enabled screening transforms combination therapy development from trial-and-error to evidence-based selection.

Importantly, these models can also incorporate known resistance mechanisms. When a resistance pathway is activated, AI can recommend co-administration of agents that inhibit compensatory signaling nodes. For instance, in non-small cell lung cancer with resistance to EGFR inhibitors, AI-guided knowledge graphs may suggest addition of a bypass pathway inhibitor to restore tumor control (62). As AI continues to evolve in this domain, it is expected to drive the development of rational combination regimens that effectively delay or overcome resistance, thereby improving long-term cancer control.

## Section: AI-driven precision medication management in oncology › Toxicity prediction and management

While anticancer agents offer therapeutic benefits, they are frequently accompanied by considerable toxicity. Predicting and managing these adverse effects is a vital component of precision oncology. AI offers novel solutions in this domain.

On one hand, AI can be used to forecast adverse drug reactions (ADRs). Machine learning models trained on historical clinical trial data and real-world pharmacovigilance databases can learn associations between drug regimens, molecular properties, and specific toxicities (22). For example, the CT-ADE database, which includes over 2,500 drugs and more than 160,000 drug–adverse event pairs, has been used to train large language models that predict ADR risk across various doses and patient profiles (22). Incorporating individual characteristics—such as age, comorbidities, and genetic polymorphisms—enhances predictive accuracy. In oncology, these tools enable clinicians to identify high-risk patients prior to treatment initiation, allowing for proactive mitigation strategies such as dose modification or preventive monitoring. For instance, if an AI model predicts a high likelihood of severe myelosuppression from a chemotherapy regimen in a specific patient, the clinician might consider alternative treatments or supportive interventions.

On the other hand, NLP techniques empower real-time monitoring of toxicity from unstructured clinical data. Many ADRs are documented in free-text formats such as physician notes or discharge summaries. NLP algorithms can extract these data to facilitate near real-time pharmacovigilance. For example, studies have demonstrated that NLP can accurately capture immune-related adverse events from EHRs of hospitalized oncology patients, with extracted frequencies closely aligning with those reported in trials (63). When datasets are limited, transfer learning from related oncology cohorts, temporally held-out (“future”) validation, and external replication across sites should be used to mitigate overfitting and quantify generalizability. Such systems can be embedded in hospital safety monitoring frameworks to trigger alerts for severe events, enabling timely clinical response. Moreover, regulatory agencies have begun utilizing NLP to analyze patient-reported symptoms on social media and online forums, potentially detecting rare or overlooked side effects. This AI-driven approach to pharmacovigilance ensures a more comprehensive and proactive safety net for cancer therapies (64).

Finally, AI supports dose adjustment and supportive care in response to emerging toxicities. Traditionally, toxicity management relies on clinical experience, which may vary in consistency and timeliness. AI-powered systems can analyze the progression of adverse reactions and suggest evidence-based interventions. For example, in cases of Grade 3 neutropenia, AI models may recommend delaying the next treatment cycle or initiating granulocyte-colony stimulating factor (G-CSF) prophylaxis based on projected recovery and infection risk (65, 66). These decision support tools enhance the standardization and responsiveness of toxicity management, potentially preventing escalation to life-threatening complications.

In summary, AI is enabling a shift toward proactive and individualized toxicity management in oncology. By predicting high-risk scenarios, mining toxicity signals, and guiding patient-specific interventions, AI promises to minimize treatment-related harm and ensure safer therapeutic journeys for patients.

## Section: The role of AI in oncology drug supply chain and regulatory oversight

The management of oncology drugs extends beyond research and clinical application to include the production, distribution, and post-marketing regulatory monitoring. AI has begun to play an increasingly important role in optimizing pharmaceutical supply chains and enhancing pharmacovigilance and drug reevaluation. A comparative view of conventional versus AI-enhanced workflows across the lifecycle is provided in Table 2.

Conventional versus AI-enhanced workflows across the oncology drug lifecycle.

## Section: The role of AI in oncology drug supply chain and regulatory oversight › Optimization of the oncology drug supply chain

Anticancer drugs are typically expensive and involve complex supply chains encompassing raw material procurement, manufacturing, warehousing, and delivery to hospitals and pharmacies. AI, through predictive analytics and intelligent scheduling, can significantly improve the efficiency, transparency, and reliability of the supply chain to ensure timely and sufficient drug availability.

In terms of demand forecasting, AI algorithms can integrate various determinants—historical consumption, seasonal patterns, epidemiological trends, and healthcare policy shifts—to improve the accuracy of drug usage predictions (67). Traditional methods often rely solely on linear projections of historical sales data, whereas AI models can analyze hundreds or thousands of variables simultaneously, capturing latent correlations. For instance, a major pharmacy chain employing AI-based forecasting reduced prediction errors by 20–30% and decreased stock-out incidents by 15%. Similarly, a hospital inventory management system using AI to factor in seasonal disease trends, regional demographics, and prescribing habits achieved a forecasting accuracy of 94%, outperforming traditional models (78%) (67). Accurate demand forecasting enables manufacturers and providers to optimize production schedules and inventory levels—preventing shortages that could endanger patients and avoiding waste due to overstock or expiry. For oncology drugs, such precision is particularly critical, as treatment delays due to drug shortages can have serious consequences, while expired drugs represent substantial economic losses. AI helps match supply to demand with high fidelity, ensuring uninterrupted access to critical medications.

Furthermore, AI in combination with Internet of Things (IoT) technologies enhances logistics and warehouse management. AI-powered dispatch systems can optimize delivery routes in real time based on traffic, weather, and urgency of demand at different locations, thereby ensuring efficient transportation and cold chain integrity (68) During public health emergencies or natural disasters, AI systems can rapidly replan routes to prioritize delivery of life-saving oncology drugs. In warehousing, AI algorithms optimize stock rotation based on expiry dates and consumption rates, enabling timely redistribution of surplus inventory to high-demand areas and reducing wastage. One report showed that a hospital network reduced inventory holding costs by 23% and emergency restocking events by 35% after implementing AI-based inventory strategies (69, 70) These improvements are particularly impactful for high-cost oncology drugs, contributing to both cost-effectiveness and timely access for patients.

A particularly notable advancement is the integration of AI with blockchain technology to enhance drug authenticity and traceability. Counterfeit and illegally circulated medications pose serious risks to patient safety globally. Blockchain provides an immutable distributed ledger for tracking every stage of a drug’s journey—from manufacturing to dispensing. When combined with AI for real-time data analysis, these systems can effectively detect anomalies and combat counterfeit products. Pilot programs in some countries have leveraged blockchain to log logistics data of anticancer drugs, while AI-based image recognition verifies packaging and serial codes (71, 72). Any discrepancies in shipping records or packaging features trigger AI-generated alerts. One such system helped authorities intercept counterfeit oncology drugs worth millions within six months (73). By identifying subtle differences in barcode patterns or packaging design and cross-verifying with blockchain records, the system significantly improved inspection accuracy. Altogether, the synergy of AI and blockchain enables intelligent supply chain management—from predictive distribution to secure authentication—ultimately safeguarding access and safety for cancer patients.

## Section: The role of AI in oncology drug supply chain and regulatory oversight › Pharmacovigilance and drug re-evaluation

Post-marketing surveillance and real-world evidence (RWE) evaluation in oncology primarily addresses clinical safety and effectiveness in routine care, leveraging spontaneous reporting systems (e.g., FAERS/VigiBase) and EHR/claims rather than economic outcomes. Studies are conducted by public agencies and industry under regulatory oversight, using methods aligned with pharmacovigilance and RWE standards (57). AI supports this process by enhancing case ascertainment (e.g., EHR-NLP adverse event extraction) and by fusing SRS with EHR/claims to improve sensitivity for earlier signal detection. Insights from post-market signals and RWE can inform indication refinement and drug repurposing, closing the loop with upstream discovery and trial design.

AI significantly enhances the sensitivity and efficiency of AE signal detection. Large spontaneous reporting systems, such as the FDA Adverse Event Reporting System (FAERS) and WHO’s VigiBase, receive enormous volumes of suspected ADR reports annually. Here, “high-risk signal” denotes a serious or unexpected adverse-event association that crosses predefined thresholds (e.g., disproportionality metrics) in spontaneous-reporting or EHR-derived analyses and warrants regulatory or clinical action.Traditional workflows—manual case review and single-metric disproportionality (e.g., PRR/ROR) applied to sparse, heterogeneous reports—may miss early or low-frequency patterns; multi-source fusion of FAERS/VigiBase with EHR-based NLP helps address under-reporting and improves sensitivity (see existing citations in this paragraph).

AI algorithms are adept at mining such large datasets to identify statistically significant associations—potential safety signals. Machine learning models can estimate background incidence rates for specific AEs in the general population and compare them with observed reporting rates associated with particular drugs, highlighting unusual patterns (73). Some AI-based systems have demonstrated the ability to detect rare but serious ADRs earlier than traditional methods. For example, while post-market reports of cardiac dysfunction associated with a newly approved cancer drug were initially scattered across different countries and went unnoticed by manual review, an AI model aggregated and flagged these cases promptly, prompting regulatory warnings. Moreover, as discussed previously, NLP techniques can extract AE data from non-traditional sources such as clinical notes and social media. Studies have shown that frequencies of chemotherapy-related AEs extracted via NLP from electronic health records closely match clinical trial reports, validating their use in supplementing official systems Hence, modern pharmacovigilance is evolving toward a “data fusion” model—AI integrates spontaneous reports, literature, EHRs, and patient-generated data to provide multidimensional safety monitoring. This comprehensive approach enables earlier detection and more effective risk mitigation.

In the case of high-risk, high-cost oncology drugs, regulatory agencies are increasingly emphasizing the importance of RWE for long-term effectiveness and safety evaluation. AI plays a crucial role in RWE analysis, which often involves large, heterogeneous datasets from EHRs, insurance claims, biobanks, and patient registries. AI models can synthesize fragmented data sources to assess drug performance across broader populations and extended timeframes. For example, national cancer registry and insurance claims data analyzed by AI can reveal whether a new targeted therapy confers survival benefits in elderly patients or those with multiple comorbidities—groups underrepresented in clinical trials. Moreover, AI can detect late-onset toxicities, such as secondary malignancies years after treatment, which are typically missed in trial settings [. Causal inference models powered by AI can approximate randomized controlled trial conditions in observational data. For instance, AI-based matching techniques can construct control cohorts similar to treatment arms to estimate the causal effect of immunotherapy on long-term survival. While observational studies have inherent limitations, AI improves confounding control and result robustness, supporting regulatory decisions regarding label expansion or indication refinement.

Additionally, AI is transforming drug repurposing and post-market efficacy reevaluation. Many approved drugs for non-oncological indications may have unrecognized anticancer potential. AI can correlate drug-induced multi-omics signatures with tumor molecular characteristics to identify new therapeutic applications. One such model suggested that a legacy drug could suppress oncogenic pathways in a specific tumor subtype—a prediction later validated in clinical studies, illustrating AI’s value in uncovering hidden efficacy (74). For already approved oncology drugs, AI can continuously monitor real-world outcomes and identify subgroups with differential efficacy. If real-world data indicate suboptimal outcomes in certain genotypes, regulators may revise usage guidelines accordingly. In the future, drug approval may transition from a “one-time decision” model to a dynamic, AI-informed regulatory approach, with indications and usage evolving based on real-time evidence.

In conclusion, AI is facilitating a shift in drug regulation from reactive to proactive. From real-time AE surveillance to dynamic benefit-risk assessment, AI empowers regulators to detect issues earlier and base decisions on more comprehensive evidence. In the high-stakes context of oncology therapeutics, AI-driven regulatory oversight ensures that innovative treatments deliver maximum benefit with minimal harm.

## Section: Challenges and future directions

Despite remarkable progress in the application of AI to oncology drug management, fully realizing its transformative potential requires addressing a number of critical challenges. These span technical limitations, clinical translation barriers, as well as ethical and regulatory concerns.

## Section: Challenges and future directions › Technical challenges

Cancer-related data are inherently heterogeneous, encompassing genomic sequences, medical imaging, pathology slides, electronic health record (EHR) text, and data from wearable devices. Effectively integrating such multimodal data remains one of the core technical challenges in AI development. Single-modality data often fail to comprehensively characterize the disease state, whereas multimodal fusion promises a more holistic understanding. However, disparities in scale, format, and quality between modalities can lead to a “data gap” problem. Current approaches often employ deep learning models to extract features from each modality separately, which are then integrated at a higher level—for instance, combining convolutional neural network (CNN) features from imaging with fully connected representations from genomics to predict treatment response or prognosis (75). Although early results are promising, training robust multimodal models requires large paired datasets and careful architectural design to avoid modality dominance and information imbalance.

Advances in technologies such as federated learning offer potential solutions by enabling multi-institutional collaboration without compromising data privacy (76). This allows for distributed training of AI models across centers, pooling insights from rare cases or underrepresented populations without centralizing data. Success in multimodal fusion would empower AI systems to consider cancer from multiple biological and clinical dimensions, generating more accurate and context-aware recommendations.

Although data-rich, the biomedical domain often suffers from limited high-quality labeled data. Clinical trial datasets are typically small and expensive to acquire, and data on rare cancers or adverse events are especially scarce. This creates challenges for traditional deep learning, which relies on large training sets for robust performance. In response, researchers are exploring techniques such as transfer learning and few-shot learning. In transfer learning, models are pre-trained on large datasets (e.g., from related cancer types or synthetic data) and fine-tuned on smaller target datasets, enhancing generalizability. Data augmentation techniques, such as generative adversarial networks (GANs) that synthesize pathology images, are also being adopted (77, 78). Recent studies have demonstrated that pre-trained models can perform reliably even with as few as dozens of patients in the fine-tuning phase (79). Nevertheless, risks remain: overfitting, data drift, and learning from noise rather than signal can impair model reliability. Addressing the small-sample challenge is essential for expanding AI into understudied cancers and rare toxicities.

A further concern is the “black box” nature of many high-performance AI models, particularly deep learning systems, which lack interpretability (80).To move from promise to practice, we outline pragmatic mitigations mapped to common failure points in translational deployment. For external validity and model drift, teams should pre-register model-update rules, evaluate with temporal hold-out or rolling-origin splits, and monitor data and performance drift with predefined review triggers. For fairness, subgroup performance audits across clinically relevant and protected attributes should be routine, with corrective re-weighting, threshold adjustment, or group-wise calibration and explicit reporting of disparity metrics. For prospective evidence, embedding models in randomized or stepped-wedge/pragmatic trials with patient-important outcomes and decision-impact endpoints is essential. For explainability, case-level explanations (e.g., SHAP) and knowledge-anchored rationales, coupled with clinically sensible feature sets and clinician-centered UI pilots, can improve trust. Finally, for regulatory alignment, SaMD-style change-control plans, versioning and auditable logs, and post-market algorithmovigilance using real-world data with performance floors and remediation pathways should be adopted.

In clinical contexts, both physicians and patients often seek to understand the rationale behind AI-generated recommendations. Lack of transparency may undermine trust and hinder adoption. Enhancing explainability has thus become a central goal in medical AI. Several strategies have emerged: (1) developing inherently interpretable models (e.g., decision trees or knowledge graph-based reasoning), which may sacrifice some accuracy for greater transparency (81, 82),(2) applying post hoc explanation methods, such as attention mechanisms, SHAP values, or counterfactual reasoning, to identify key features driving prediction (83), (3) integrating domain knowledge into model architecture or outputs, anchoring AI reasoning to established medical principles and improving credibility (84). Explainability not only enhances clinical trust but also facilitates new scientific discovery by highlighting previously unrecognized patterns. As regulatory frameworks increasingly require some level of interpretability, explainable AI will be pivotal for integrating AI into routine medical practice.

## Section: Challenges and future directions › Challenges in clinical translation

Many AI models demonstrate high performance in retrospective datasets, yet lack prospective validation through clinical trials—a significant barrier to clinical adoption. Most current evidence for AI’s effectiveness in medicine derives from retrospective analyses rather than randomized controlled trials (RCTs), the gold standard for assessing intervention outcomes (85). Without prospective validation, clinicians may remain skeptical of AI-driven recommendations. It is therefore imperative to design trials that evaluate whether AI tools improve clinical decision-making, treatment outcomes, or cost-effectiveness. In some domains, such as radiology, prospective studies have already shown that AI can enhance diagnostic accuracy. Similarly, oncology-focused trials are needed to assess whether AI-guided treatment recommendations translate into better survival, reduced toxicity, or improved quality of life.

The successful integration of AI into clinical workflows also hinges on physician acceptance and usability. If medical professionals are unfamiliar with or distrustful of AI tools, their potential will remain untapped. Surveys indicate that many clinicians are hesitant due to limited understanding of AI, concerns over reduced autonomy, or fear of misinterpretation. Therefore, it is critical to provide AI education and training in medical curricula and continuous professional development program (43). Equally important is designing AI systems that align with existing clinical pathways, defining clear roles for AI (e.g., pre-screening, suggesting alternative treatments) while preserving clinician authority in final decision-making. Early adopter experiences suggest that AI-augmented multidisciplinary team (MDT) discussions can improve the speed and comprehensiveness of treatment planning—provided that communication and expectations are well-managed. Over time, as younger clinicians grow up with AI as a standard tool, we may see the emergence of a new norm: the AI-empowered physician.

## Section: Challenges and future directions › Ethical and regulatory considerations

AI systems in healthcare depend heavily on sensitive patient data, raising significant concerns regarding privacy and data security. Genomic information, clinical histories, and EHRs contain personal health identifiers, and improper use or breaches could have serious consequences. Regulations such as the General Data Protection Regulation (GDPR) impose strict requirements on the collection, processing, and storage of such data. AI developers must implement safeguards, including de-identification, encryption, and transparent consent protocols. Federated learning offers a privacy-preserving solution by training models locally at each institution and aggregating only model parameters—ensuring that data remain decentralized and secure (86). This approach has already been piloted in multi-center cancer prognostic modeling. In the future, privacy-preserving technologies such as differential privacy and blockchain-based audit trails may further enhance AI system transparency and accountability.

Bias and fairness are equally critical concerns. AI models trained on unbalanced or non-representative datasets risk perpetuating or amplifying existing health disparities. For instance, an oncology model developed primarily using data from Western populations may perform poorly in other ethnic groups, potentially leading to misdiagnoses or inappropriate recommendations. Several studies have highlighted biases in medical AI due to sample selection and measurement errors (87, 88). Developers must strive for inclusive training datasets that reflect population diversity, and where data are sparse, models should incorporate uncertainty estimates or reject predictions. Fairness metrics—such as subgroup performance comparison—should be routinely applied to detect and mitigate biases. AI in medicine must uphold the principles of equity and justice: it should benefit all patients, not just privileged groups (89). Organizations such as ASCO have proposed ethical guidelines for responsible AI development, emphasizing transparency, fairness, and patient-centeredness (90). Regulatory agencies must also screen AI systems for potential bias before approval, ensuring that no vulnerable populations are adversely affected.

Finally, the regulatory frameworks for AI in healthcare remain nascent. Most jurisdictions are still evolving their approaches to software as a medical device (SaMD), especially for adaptive AI systems. Key questions include: How is safety and efficacy demonstrated? How are updates and version changes monitored? Who is liable in the event of errors? Agencies such as the FDA have proposed frameworks requiring algorithm change protocols and ongoing performance monitoring. Future policies may mandate transparency reports, explanation of model logic, and continuous post-market surveillance—a concept termed “algorithmovigilance” (91, 92). AI systems may eventually be held to standards akin to pharmacovigilance, with systematic monitoring and recall mechanisms. As AI gains autonomy, the question of responsibility will become more complex. While current regulations place ultimate responsibility on licensed clinicians, new frameworks may need to clarify shared accountability between AI developers, providers, and users. The ideal regulatory approach must strike a balance: ensuring safety and accountability without stifling innovation. Such a balanced framework will require close collaboration among regulators, clinicians, researchers, and industry stakeholders.

## Section: Conclusion

AI is driving a profound paradigm shift in oncology drug management. From drug discovery and development to clinical application and post-marketing surveillance, AI offers unprecedented gains in efficiency and decision-making support. As discussed above, AI facilitates more precise identification of drug targets and reduces development costs; it transforms empirical drug discovery into a data-driven process through virtual screening and molecular design; in clinical trials, AI enhances patient selection and trial design, improving trial success rates; during clinical application, AI enables personalized treatment plans and dynamic dosing strategies tailored to each patient’s unique profile; it addresses key challenges such as drug resistance and toxicity through early prediction, combination therapy design, and proactive management of adverse effects; within pharmaceutical supply chains, AI ensures efficient, secure drug distribution through demand forecasting, anti-counterfeiting, and logistics optimization; in regulatory contexts, AI supports real-time pharmacovigilance and real-world efficacy reassessment, ensuring the safety and effectiveness of oncology drugs throughout their life cycle. Collectively, these innovations mark the beginning of a new era of intelligent and precise cancer therapeutics.

Realizing the full potential of AI in oncology drug management requires close interdisciplinary collaboration. Oncologists, pharmaceutical scientists, and AI engineers must develop a shared language and cooperative frameworks. Clinicians, who understand unmet needs and patient realities, should be involved in model development and validation to ensure clinical relevance; data scientists must gain fluency in medical knowledge to design context-appropriate algorithms, while also addressing explainability and fairness. Industry–academia–regulator partnerships are crucial to transforming research prototypes into scalable clinical tools. Ethical scholars and policymakers also have an essential role in guiding innovation along compliant and socially responsible pathways.

Looking ahead, the integration of AI with emerging technologies will further expand the frontiers of oncology drug management. Organoid-based platforms are gaining traction—patient-derived tumor organoids can mimic in vivo tumor biology and drug responses. Applying AI to analyze large-scale organoid screening data could uncover clinically translatable therapeutics with unprecedented accuracy. Indeed, several companies have already used AI–organoid systems to identify novel compounds that are now advancing into clinical trials, validating the feasibility of this approach (93). At the same time, single-cell and spatial multi-omics technologies are enabling high-resolution dissection of tumor heterogeneity and microenvironments. AI will be indispensable for processing and interpreting these ultra-high-dimensional datasets, identifying resistance clones, immune escape mechanisms, and novel targets at the single-cell level. Moreover, advances in quantum computing and edge computing may soon unlock new capabilities in molecular simulation and real-time clinical decision-making.

In summary, AI is ushering in an intelligent era for oncology drug development and management, with broad and far-reaching applications. To fully harness its benefits, we must remain guided by clinical needs, scientific rigor, and ethical principles—leveraging AI’s strengths while proactively managing its risks. Only through such an integrated and responsible approach can AI truly become a transformative force in cancer medicine, improving survival and quality of life for patients worldwide. The future of oncology drug management—shaped by the synergy between human wisdom and AI—is one we can all look forward to.

Priorities: (1) Prospective, multi-site outcome trials to establish real-world effectiveness and safety; (2) Fairness auditing and algorithmovigilance (pre-specified update rules, temporal validation, subgroup monitoring); (3) Workflow/regulatory integration (EHR/registry interoperability; SaMD-aligned change control and post-market monitoring).


---

# Artificial intelligence in pharmacovigilance: advancing drug safety monitoring and regulatory integration

- **Authors:** Ankit Nagar, Joga Gobburu, Aloka Chakravarty
- **Issuer:** Therapeutic advances in drug safety
- **Type:** Scientific article
- **Published:** 2025-07-31
- **Language:** en
- **DOI:** 10.1177/20420986251361435
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40756610/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractArtificial intelligence (AI) has rapidly evolved from experimental applications in pharmacovigilance (PV) to being considered for routine use. This review critically examines AI’s potential to revolutionize drug safety monitoring, focusing on practical implementation challenges such as ensuring AI’s consistent and transparent performance, reducing multiple sources of bias, and addressing interpretability issues. It emphasizes the transition from experimental use to a routine, scalable capability within PV. It examines AI’s evidence base in specific applications, its ability to enhance actionable insights, and how organizations can safeguard against unintended consequences in multi-AI system environments. These considerations are vital as AI moves from theory to practice in PV.Keywords: adverse drug reactions, artificial intelligence, pharmacovigilance, regulatory integration, signal detection

## Section: Introduction

Artificial intelligence’s (AI) application in pharmacovigilance (PV) has expanded significantly, promising to improve the speed and accuracy of adverse event detection. 1 The transition has been driven by the increasing complexities in drug development and post-market surveillance, including the unprecedented volume of data, complexity of drug–drug interactions, and patient variability.2,3 However, transitioning from experimental use to routine, trusted application presents new challenges. These include ensuring that AI functions as intended post-implementation, that it adapts to real-world complexities, and that biased and unfair outcomes are minimized. This review addresses the current state of AI in PV and explores how it can be effectively integrated into everyday workflows while adhering to ethical and legal standards.

The application of AI in PV began in the early 2000s with the introduction of data mining algorithms for signal detection in spontaneous reporting systems (SRS). Pioneering approaches such as the Bayesian Confidence Propagation Neural Network (BCPNN) method and the Multi-item Gamma Poisson Shrinker (MGPS) laid the groundwork for more sophisticated AI applications in PV. Since then, AI has been applied to various aspects of PV, including automated case processing, signal detection, and real-world evidence analysis.4 –6

The PV lifecycle spans both pre-marketing and post-marketing phases and involves distinct data landscapes. While pre-marketing PV relies primarily on structured data from clinical trials, post-marketing surveillance involves both structured and unstructured data from diverse sources. These include individual case safety reports (ICSRs), adverse event reports, regulatory databases like FDA’s Adverse Event Reporting System (FAERS) and WHO’s VigiBase, Electronic Health Records (EHRs), insurance claims, social media posts, and biomedical literature.7–9 These diverse data sources offer invaluable real-world insights into drug safety, capturing intricate patterns that may not be evident in more structured reporting systems.

Figure 1 illustrates the multifaceted challenges in PV and the diverse AI technologies that can be applied to address these challenges. The concentric circles represent different layers of the PV ecosystem, from core challenges and data sources to the various AI and machine learning (ML) techniques that can be leveraged to enhance PV processes. This comprehensive view emphasizes the potential for AI to address the complexities of modern PV by integrating diverse data sources and applying sophisticated analytical techniques.

AI’s ability to efficiently process and derive meaningful insights from both structured and unstructured data has been game-changing, enabling the rapid and accurate identification of emerging safety signals across all stages of the PV lifecycle. This has facilitated a paradigm shift from passive to active surveillance methods, allowing for real-time detection of adverse drug reactions (ADRs) and potential safety issues.

Despite its promise, AI implementation in PV faces significant challenges. Key concerns include how to integrate AI as a routine capability, the availability of evidence supporting its use in specific applications, and ensuring trusted, transparent usage for all stakeholders. These challenges include ensuring data quality and representativeness, addressing potential biases in AI algorithms, and maintaining transparency and interpretability of AI-driven decisions. Moreover, the integration of multiple AI solutions in PV raises questions about potential interactions and unintended consequences.

This review examines the evolution of AI applications in PV, focusing on significant advancements over the past two decades. By assessing the current state of AI implementation and its future directions, we aim to provide a comprehensive reference for researchers and professionals.

A comprehensive overview of state-of-the-art challenges in PV, sources of data, and the relevant AI technologies to address the challenges.

AI, artificial intelligence; PV, pharmacovigilance.

## Section: Applications of AI in PV

The integration of AI technologies in PV is revolutionizing the way ADRs are detected, evaluated, and managed. This section explores the current applications of AI in PV, focusing on its role in enhancing ADR detection and evaluation.

A comparative overview of AI methods applied to ADR detection across multiple PV data sources, including social media platforms, EHRs, and spontaneous reporting systems.

## Section: Applications of AI in PV › AI for ADR detection

ADRs are a major public health concern, significantly impacting patient populations across demographics. The risk is especially pronounced in elderly populations (>60 years), with 15%–35% experiencing an ADR during their hospital stay. 10 This high proportion of ADRs puts a significant burden on healthcare systems, with an estimated annual management cost of $30.1 billion. 11 This highlights the critical need for more efficient methods to monitor, detect, and prevent ADRs throughout both the pre-marketing and post-marketing phases of drug surveillance.

The evolution of AI applications for ADR detection since the late 1990s has reshaped PV practices. It can be broadly categorized into three phases, each characterized by distinct advancements in statistical methods, natural language processing (NLP), and machine learning techniques.12,13

Early AI applications in PV focused on enhancing signal detection in spontaneous reporting systems. The BCPNN method, developed by Bate et al., 14 and the MGPS, introduced by DuMouchel, 15 marked significant improvements over traditional statistical methods. These algorithms allowed for more efficient processing of large volumes of ADR reports, potentially identifying safety signals that might be missed by manual review. However, these methods faced challenges in terms of handling rare events and drug–drug interactions. For example, although the BCPNN method demonstrates high sensitivity in ADR detection, it is prone to generating a higher rate of false positives, raising concerns about its specificity. This highlights the need for careful interpretation of signals generated by these algorithms and emphasizes the importance of expert review in the signal evaluation process.

As PV data sources expanded beyond structured spontaneous reports to include unstructured data from EHRs and social media, NLP techniques became crucial. Nikfarjam et al. demonstrated the potential of NLP in extracting ADR data from social media, achieving F-measures of 0.82 and 0.72 for ADR detection from networks such as DailyStrength and Twitter. 16 These F-measures indicate a good balance between precision and recall, suggesting that the NLP methods were effective in correctly identifying ADRs while minimizing false positives and false negatives. This study opened new avenues for real-time ADR monitoring, potentially capturing patient-reported outcomes that might not be reflected in formal reporting systems.

However, using social media data for ADR detection presents significant challenges, including data quality concerns, patient privacy issues, difficulties in verifying the accuracy of self-reported information, and recall bias. Recall bias is particularly challenging in social media-based ADR detection, as patients may selectively report or remember certain side effects while forgetting others, leading to potential distortions in the reported ADRs. These limitations highlight the need for robust data validation strategies and careful interpretation when incorporating social media data into PV systems.

As machine learning techniques in PV advanced, researchers began exploring more sophisticated approaches to integrate diverse data sources and capture complex relationships. One such approach is the use of knowledge graphs, which represent entities (such as drugs, adverse events, and patient characteristics) as nodes and their relationships as edges. These graphs can integrate diverse data and capture complex relationships between drugs, adverse events, and other factors. 17 Table 1 presents a summary of AI methods applied across diverse PV data sources, including social media, EHRs, and PV databases, with performance metrics such as F-scores and area under the receiver operating characteristic curves (AUCs). One study using a knowledge graph-based method achieved an AUC of 0.92 in classifying known causes of ADRs. 18 This performance is notably higher than traditional statistical methods, which typically achieve AUCs in the range of 0.7–0.8 for similar tasks. However, implementing these systems in clinical practice faces challenges related to data quality, model interpretability, and the need for large, diverse datasets for training. These issues are particularly relevant for rare ADRs and underrepresented populations.

Recent years have seen the application of more sophisticated AI models in PV. Yang et al. demonstrated the effectiveness of machine learning techniques in detecting medications and ADRs from EHRs. 25 Their system, MADEx (Medication and Adverse Drug Event Extraction), showed potential for real-time monitoring and early warning systems for ADRs by automatically extracting this information from clinical notes. MADEx improved upon previous systems by incorporating advanced NLP techniques and a novel deep-learning architecture, resulting in higher accuracy and faster processing times compared to traditional rule-based systems.

Recent innovations in ADR detection have leveraged multi-modal deep-learning approaches to enhance accuracy and comprehensiveness. Sahoo et al. introduced a MultiModal Adverse Drug Event detection dataset, combining ADR-related textual information with visual aids. 26 This approach demonstrated the significance of integrating visual cues from images to improve overall performance in ADR detection, particularly for ADRs with visible symptoms.

By contrast, Harpaz et al. explored multi-modal signal detection for ADRs using diverse data sources: FAERS, insurance claims, the MEDLINE citation database, and logs of major Web search engines. 27 Their multi-modal approach provided AUC improvements ranging from 0.04 to 0.09 compared to unimodal methods, with an added lead-time of 7–22 months for detecting ADRs relative to labeling revision dates.

Zhao et al. developed a deep-learning framework for predicting the seriousness of adverse reactions to drugs. 22 By integrating multiple data representations, including Simplified Molecular Input Line Entry System (SMILES) sequences of drugs and semantic feature vectors of ADRs, it achieved improved performance in predicting potential drug–ADR interactions that cause serious clinical outcomes, focusing on the molecular and semantic aspects of drug–ADR relationships. These studies demonstrate the potential of combining multiple data modalities to enhance the accuracy and robustness of ADR detection systems, paving the way for improved patient safety and healthcare accessibility.

However, these advanced models often function as “black boxes,” raising concerns about interpretability and clinical applicability. Rudin argued for the development of inherently interpretable models rather than post hoc explanations, particularly in high-stakes medical decisions like ADR detection. 28 This highlights the ongoing challenge in balancing the power of complex AI models with the need for transparency and explainability in healthcare applications.

To address data privacy concerns in ADR detection, federated learning approaches have been proposed. Federated learning allows multiple institutions to collaboratively train AI models without sharing raw patient data, thereby preserving privacy. Choudhury et al. described a federated learning method for collaborative ADR detection across multiple institutions while preserving data privacy, demonstrating its effectiveness in predicting ADRs without sharing raw patient data. 29 However, an analysis by Enthoven and Al-Ars highlighted potential vulnerabilities to privacy attacks in federated learning systems, emphasizing the need for robust security measures. 30

Future research should focus on developing more robust, interpretable, and clinically validated AI models for PV. This includes addressing the challenges of rare ADRs and underrepresented populations, improving the integration of diverse data sources while maintaining privacy, and developing AI systems that can adapt to the evolving landscape of drug development and use. As suggested by Rieke et al., there is a need for careful consideration of the ethical and regulatory implications of AI in healthcare, particularly in sensitive areas like ADR detection. 31

A comparative overview of AI methods applied to ADR detection across multiple PV data sources, including social media platforms, EHRs, and spontaneous reporting systems.

## Section: Applications of AI in PV › AI for signal detection and active surveillance

Signal detection is an important component of PV that involves the identification of potential links between drugs and adverse events. 32 While traditional methods based on disproportionality analysis of SRS have been valuable, 33 they often suffer from limitations such as under-reporting, reporting biases, and challenges in detection of complex drug–event associations. AI and ML methodologies have emerged as critical tools in addressing these challenges, enhancing signal detection, improving accuracy, and enabling the analysis of diverse data sources. Beyond broad data source analysis, AI is also being applied to specialized regulatory intelligence platforms to streamline safety monitoring and reporting processes.

Recent advances in AI-enabled regulatory intelligence tools, in practice often AI-enabled chatbots set to search or web scrape public domain regulatory documents, are significantly improving how PV teams access, analyze, and operationalize large volumes of regulatory and safety data.

Several ML algorithms have been applied to signal detection, showing significant improvements over traditional methods. Bae et al. developed a Gradient Boosting Machine model to detect safety signals for the drugs nivolumab and docetaxel. 25 Their model achieved an impressive AUC of 0.95, significantly outperforming traditional disproportionality analysis methods, which typically achieve AUCs of 0.55 or lower.

Recent studies suggest that advanced ML/AI implementations may offer advantages over traditional disproportionality measures under specific conditions, but these findings warrant careful interpretation. While ML approaches have demonstrated improved performance metrics in controlled evaluations, several limitations affect their real-world applicability. First, benchmark datasets used for validation are often limited in size and diversity, potentially affecting generalizability across diverse patient populations. 2 Second, most comparative studies evaluate performance against known adverse events rather than unknown or emerging signals, which is the primary challenge in real-world PV. 13 Third, the temporal dimension of signal detection—how quickly a safety concern is identified—is rarely addressed in methodological comparisons. 34 These factors likely contribute to why traditional disproportionality methods remain widely used in regulatory settings despite the theoretical advantages of more sophisticated approaches. A balanced approach integrating both methodologies may offer the most robust framework for comprehensive safety surveillance.

Jeong et al. improved the accuracy and efficiency of ADR detection by combining traditional methods with ML approaches. 35 They utilized 21 years of inpatient EHR data by combining three existing algorithms—CERT (Comparison of Extreme Laboratory Test results), CLEAR (Comparison of Extreme Abnormality Ratio), and PACE (Percentile of Adverse event risk in Comparison to Entire population)—as inputs for ML models, including random forest, L1 regularized logistic regression, support vector machine, and neural networks. This approach outperformed individual existing algorithms significantly, achieving a sensitivity of 0.593–0.793, specificity of 0.619–0.796, and AUC of 0.737–0.816.

Building on these advancements in structured data analysis, researchers have also made significant strides in extracting valuable information from unstructured data sources. Social media analysis has emerged as an important component of modern PV. Stanovsky et al. developed a recurrent neural network (RNN) model specifically designed for this purpose, addressing the unique challenge of capturing context-dependent and informal descriptions of ADRs in online posts. 36 Their approach integrated knowledge graph embeddings from DBpedia into an RNN transducer, trained on the CSIRO Adverse Drug Event Corpus (CADEC), resulting in an F1-score of 93.4 on the CADEC test set. This significant improvement over traditional lexicon-based methods demonstrates the potential of AI in extracting valuable safety signals from social media data, enabling real-time monitoring and earlier detection of potential safety concerns.

Based on recent advances in biomedical literature mining, several approaches can be applied to enhance signal detection. 37 Deep-learning methods, particularly those utilizing bidirectional long short-term memory (Bi-LSTM) networks combined with convolutional neural networks (CNN) and conditional random fields (CRF), have shown promising results in biomedical named entity recognition (NER) and normalization (NEN). These methods achieved high F1-scores of 0.87 and 0.89 for NER and NEN, respectively, on benchmark datasets like BC5CDR and NCBI Disease. 38 Such advanced NER and NEN capabilities could significantly improve the identification of drugs, adverse events, and their relationships in PV literature. Furthermore, attention-based CNN models have demonstrated effectiveness in biomedical literature indexing, which could assist in efficient categorization and retrieval of relevant PV articles. The integration of deep-learning approaches with traditional statistical methods could potentially enhance the sensitivity and specificity of signal detection from biomedical literature.

The implementation of AI for signal detection in real-world settings has shown promising potential. The FDA’s Sentinel System, which includes the Active Risk Identification and Analysis component, enables the evaluation of post-market safety signals using real-world data with unprecedented speed and efficiency. 39 ML-based technologies can advance key elements of safety evaluations, including health outcome of interest validation, propensity score matching, and patient phenotyping. The Sentinel System has been used to conduct more than 250 safety analyses since its full-scale implementation. AI has the potential to automate repetitive manual processes, enhance consistency, and reduce human bias while providing valuable insights for early signal detection. They can also extract information from adverse drug event forms and evaluate case validity without human intervention, enabling rapid case processing. 5 However, further research and real-world implementation data are required to quantify specific benefits of using these tools compared to traditional methods.

While AI approaches have demonstrated significant potential in enhancing signal detection, challenges exist in the form of the need for large, high-quality datasets for model training, the interpretability of complex models, and the integration of AI-generated signals into existing PV workflows. In addition, the use of AI in PV raises important ethical and regulatory considerations. These include ensuring data privacy and security, addressing potential biases in AI algorithms, and establishing clear guidelines for the validation and implementation of AI-driven signal detection methods. Regulatory bodies such as the Food and Drug Administration (FDA) and European Medicines Agency (EMA) are actively working on frameworks to govern the use of AI in drug safety monitoring, emphasizing the need for transparency, reproducibility, and human oversight in AI-assisted decision-making processes.

## Section: Applications of AI in PV › AI for real-time monitoring and active surveillance

Advancements in AI are enabling the transition to more proactive surveillance approaches. This shift allows for earlier detection of potential safety issues and more timely interventions. Real-time monitoring in PV involves continuous analysis of varied data sources to detect potential ADRs as they occur. Active surveillance, on the contrary, involves systematic collection and analysis of safety data throughout a product’s lifecycle. AI approaches have significantly improved both these aspects of PV.

The previous section discussed a key application of AI in real-time monitoring—analysis of social media posts and patient forums for earlier signal detection. In addition to this, another crucial application of AI lies in the continuous monitoring of EHRs to detect ADRs in hospital settings. Van de Burgt et al. developed and implemented a text mining algorithm for identifying ADRs from free-text Dutch EHRs. 40 The algorithm utilized Medical Dictionary for Regulatory Activities (MedDRA) terms and Systematized Nomenclature of Medicine Clinical Terms (SNOMED-CT) to find possible ADRs in a huge dataset of 35,000 EHR notes. They were able to achieve a positive predictive value of 70% and a sensitivity of 73% in detecting ADRs. However, they acknowledge the need for external validation and testing before these algorithms can be deployed in a hospital setting.

In the realm of active surveillance, AI has also made significant strides. For instance, the Centers for Disease Control and Prevention (CDC) has implemented several systems for active surveillance of vaccine safety, including the Vaccine Safety Datalink (VSD) project. Established in 1990, the VSD monitors vaccine safety and conducts studies on adverse events post-immunization. In 2005, the VSD project team launched an active surveillance system called Rapid Cycle Analysis, designed to monitor adverse events following vaccination in near real time. The integration of AI into such systems promises to further improve their efficiency and accuracy.

Despite the progress so far, the implementation of AI for real-time monitoring has potential for false alarms and unnecessary resource allocation. Moreover, interpretability of these complex models is crucial for their regulatory acceptance and clinical decision-making. Nevertheless, continuous evolution of AI approaches promises their significant contribution to improving patient safety and public health.

## Section: Challenges and limitations of AI in PV

While AI has shown great promise in enhancing PV processes, several challenges and limitations need to be addressed for its widespread adoption and optimal performance. This section explores four key areas of concern: algorithmic bias in diverse populations, temporal dynamics of drug safety profiles, causal inference in complex polypharmacy scenarios, and integration of multi-modal data sources.

## Section: Challenges and limitations of AI in PV › Algorithmic bias in diverse populations

AI models, especially those used in PV, are often trained on datasets that do not represent the diversity of real-world patient populations. This can lead to algorithmic bias, where the model performs well for the majority group but poorly for minority or underrepresented populations, such as ethnic minorities, older adults, or patients with comorbidities. For instance, models trained primarily on data from European or North American populations may struggle to detect ADRs in patients from Asia or Africa.

The issue is compounded by the fact that clinical trials—a key source of training data—tend to underrepresent these populations. This underrepresentation can lead to failures in generalizing AI predictions across all demographics, resulting in missed safety signals for certain groups. To mitigate these biases, data augmentation and resampling techniques should be utilized to address imbalances in training datasets, complemented by advanced quantitative bias detection and correction methods. 41 Techniques like federated learning allow for model training on decentralized datasets from multiple regions without sharing raw data, potentially mitigating this bias. 31

## Section: Challenges and limitations of AI in PV › Temporal dynamics of drug-safety profiles

The safety profile of a drug is not static—it evolves over time as new data from real-world usage becomes available. AI models, especially those trained on pre-market clinical trial data, may not adapt well to these changing profiles. This is particularly relevant for long-term drugs or drugs with a delayed onset of adverse effects.

A phenomenon known as concept drift in machine learning occurs when the statistical properties of the target variable change over time, rendering the original model less effective (MS v2). For example, post-marketing data may reveal ADRs that were not detected in the limited, controlled environment of clinical trials, requiring continuous model updating.

Addressing temporal dynamics requires continuous learning models that adapt in real time as new data emerge. However, these models pose their challenges: ensuring model stability while allowing for adaptability is difficult. Moreover, integrating real-world evidence from various sources, such as EHRs and spontaneous reporting systems, must be done carefully to avoid overfitting to short-term trends.

## Section: Challenges and limitations of AI in PV › Causal inference in complex polypharmacy scenarios

Polypharmacy, the use of multiple drugs by a single patient, particularly in older populations, presents a major challenge for AI systems in PV. While AI models are adept at uncovering correlations between drugs and adverse events, establishing causal relationships remains a significant challenge, particularly in polypharmacy scenarios. Overcoming this limitation is essential for AI to transition from experimental to routine use in PV, where the focus must be on generating actionable, unbiased insights.

Traditional machine learning models may identify that a particular combination of drugs is associated with a higher incidence of ADRs, but disentangling whether one drug or the interaction between several drugs is the root cause is far more complex. Causal inference models, such as causal graph neural networks, are being explored to handle this complexity.

Advanced methodologies have emerged specifically to address causality in drug interaction scenarios. The InferBERT framework represents a significant advancement by integrating transformer-based language models with do-calculus to establish causality in PV data, demonstrating high accuracy in discriminating between drug-induced adverse events. 42 Computational approaches such as graph-based causal networks, propensity score matching, and instrumental variable techniques offer powerful tools for disentangling confounding variables in observational data. 43 Expert-defined Bayesian networks have shown particular promise, allowing domain knowledge to inform causal structures while learning parameters from empirical data. 44 The integration of these specialized causal inference paradigms with traditional machine learning requires restructuring data collection protocols, as current PV data sources lack design elements necessary for robust causal inference. 43 Implementation of these techniques would significantly enhance AI’s capability to evaluate interactive effects in complex medication regimens and provide explanatory mechanisms beyond statistical association.

## Section: Challenges and limitations of AI in PV › Integration of multi-model data sources

One of the most powerful promises of AI in PV is its ability to integrate multi-modal data. While this integration offers the potential for more comprehensive safety monitoring, it also introduces significant challenges. First, the quality and consistency of data across different sources can vary significantly. For instance, patient-reported outcomes on social media might lack the rigor of clinical trial data. In addition, data harmonization—the process of reconciling conflicting or incomplete information from different sources—remains a major hurdle.

Moreover, real-time data integration, especially when combining data from spontaneous reporting systems and real-world evidence, requires sophisticated methods for normalizing and analyzing disparate types of information.

## Section: Explainable AI and regulatory considerations

Explainable AI (XAI) is critical for establishing trust and transparency in AI-enabled PV systems. To ensure compliance with regulatory standards, AI algorithms must offer clear justifications for their outputs, enabling stakeholders to understand, validate, and act on AI-driven insights. This is particularly important for gaining regulatory approval and establishing AI as a reliable, routine capability in PV.

Several concrete methodologies have been developed to address the “black box” nature of AI in PV. Local Interpretable Model-Agnostic Explanations (LIME) and SHapley Additive exPlanations (SHAP) are widely utilized XAI libraries that successfully identify both important and unimportant features in PV models, with SHAP slightly outperforming LIME in feature importance quantification. 45 These methodologies have demonstrated effectiveness in PV applications such as predicting adverse outcomes with up to 72% accuracy while providing transparent explanations of feature contributions. 45 While powerful, these methods face challenges with feature collinearity, as most current XAI approaches either do not consider feature interdependence or incorrectly assume feature independence. 46 Additional approaches include Gradient-weighted Class Activation Mapping (Grad-CAM) for visual explanations, layer-wise relevance propagation for tracing predictions back through neural networks, and Anchors for rule-based explanations that improve human understanding of model decisions. 47 Implementation of these methods in PV systems would significantly enhance model transparency, allowing regulators and healthcare professionals to understand how AI systems reach specific safety conclusions and when human intervention is necessary.

Global regulatory bodies continuously evaluate the use of AI-based systems to ensure adherence to the regulatory principles. These include ensuring data quality, which is crucial for accurate algorithmic predictions but can be challenging due to disparate data sources and potential biases. Patient privacy is another major concern, involving the secure storage, management, and protection of sensitive data while complying with privacy regulations. Regulatory bodies also focus on system validation, employing risk-based approaches for validating and monitoring AI-based PV systems, and ensuring timely reporting of adverse events to preserve patient safety.

The Uppsala Monitoring Centre (UMC), which manages the World Health Organization (WHO) global database of ICSRs (VigiBase), has implemented notable machine learning tools to enhance PV processes. Their vigiMatch algorithm represents one of the earliest applications of machine learning in routine PV, efficiently detecting duplicate case reports by processing approximately 50 million report pairs per second. 48 In use since 2014, vigiMatch employs probabilistic methods to identify potential duplicate reports, addressing a significant challenge where even a small number of duplicates can trigger false safety signals. 49 UMC has also developed vigiRank, which enhances signal detection by incorporating multiple evidence aspects beyond traditional disproportionality analysis, demonstrating how targeted AI applications can improve core PV functions while maintaining transparency and interpretability.

The Council for International Organizations of Medical Sciences established Working Group XIV on Artificial Intelligence in Pharmacovigilance in 2022. This initiative has mapped the ICSR process and evaluated automation opportunities based on perceived risk, effort required, and expected benefits. TransCelerate has also developed validation frameworks for AI-based systems in PV, published guidance on implementing novel technologies, and created interactive tools to assist with implementation. 50 Such collaborative approaches help establish industry standards, reduce duplicative efforts, and accelerate responsible AI implementation while addressing the economic and validation challenges inherent in adopting these technologies.

Figure 2 illustrates the key regulatory and ethical considerations for AI-enhanced PV. It covers four critical aspects: the current regulatory landscape, data privacy and security measures, ethical frameworks, and regulatory evolution. These interconnected areas represent the multifaceted approach required to navigate the complex integration of AI in PV. The regulatory landscape outlines existing guidelines from bodies like the FDA and EMA, while data privacy and security highlight crucial aspects such as General Data Protection Regulation (GDPR) compliance and advanced encryption methods. Ethical frameworks address critical issues like bias mitigation and transparency in AI systems. Lastly, regulatory evolution captures the dynamic nature of this subject area, emphasizing the need for adaptive licensing pathways and global data standardization efforts. This comprehensive framework underscores the intricate balance between leveraging AI’s potential in drug safety monitoring and adhering to stringent regulatory and ethical standards.

While AI technologies promise significant cost reductions through automation of labor-intensive PV processes, the initial implementation demands substantial financial investment, particularly at the frontiers of advanced analytics and signal detection. With case processing activities consuming up to two-thirds of internal PV resources and dominating most pharmaceutical companies’ overall PV budgets, NCBI organizations face difficult economic calculations when evaluating AI investments. Quality control requirements to detect unusual or extraordinary cases often necessitate additional personnel expenditures. This creates a complex balance between automation savings and continued human oversight costs. As a domain historically perceived as predominantly cost-generating rather than revenue-producing, PV stands to benefit substantially from AI-driven efficiencies, but only if implementation strategies address both economic sustainability and maintenance of scientific rigor.

As AI becomes increasingly utilitarian within PV, ethical concerns come to the forefront. Sponsors need to ensure that their AI systems are transparent, trustworthy, focused on patient welfare, and preserve privacy. Key ethical considerations in regulatory AI-based PV include explainability, bias reduction, privacy protection, and trustworthiness. AI algorithms should be interpretable and explainable, helping healthcare professionals understand how the system derives its conclusions. Preventing and minimizing biases in the AI’s decision-making process is crucial for ensuring fairness and promoting best clinical practices. Safeguarding sensitive medical information and maintaining patient confidentiality are paramount, ensuring fairness in AI models to avoid discrimination or inequity in healthcare outcomes.

As AI evolves rapidly with large language models (LLMs) and increasingly complex architectures, the ideal of complete explainability faces significant challenges. Most current explainability approaches like SHAP and LIME assume feature independence, which does not hold true in complex interconnected biological systems where feature collinearity is common. 47 This limitation becomes more pronounced with deep-learning models and particularly with LLMs, where the dimensional complexity renders traditional explainability techniques inadequate. Complete transparency in such systems may be fundamentally unrealistic due to the inherent nature of dimension reduction in explainability. The reliance on erroneous or oversimplified “pseudo-explainability” carries its risks, potentially creating false confidence in model outputs. Rather than pursuing complete explainability, a more realistic approach may involve defining specific aspects requiring transparency based on contextual needs—whether focused on feature importance, counterfactual explanations, or decision boundaries. 45 In PV specifically, the field must establish clear standards for what constitutes sufficient explainability in different use cases, from adverse event detection to causality assessment, balancing the precision of advanced models with the transparency necessary for regulatory acceptance. 28

The concept of XAI is particularly important for PV and patient safety. XAI can help analyze large datasets, including EHRs and social media feeds, to identify potential ADRs and events, while maintaining transparency in decision-making processes. This approach ensures that machine learning algorithms are transparent, interpretable, and accountable, allowing clinicians and regulators to understand how the algorithm makes predictions and identifies potential biases. In addition, XAI to identify patterns in patient data that may indicate a particular drug that is causing unanticipated adverse events, or to identify patient groups that are particularly susceptible to certain ADRs. XAI can be combined with other ML models, like knowledge graphs, to help identify biomolecular features that may distinguish or identify a causal relationship between an ADR and a particular compound.

The WHO emphasizes the importance of AI integration into worldwide PV efforts, particularly considering resource constraints in certain regions. However, the lack of harmonization of PV requirements across regulatory authorities presents challenges for AI implementation. Authorities are actively evaluating and updating their regulatory frameworks to ensure the responsible use of AI in drug safety reporting.

In the detection and analysis of ICSRs, AI-based algorithms enable regulators and sponsors to process large volumes of data quickly and accurately, leveraging AI-based algorithms, regulators and sponsors can process large volumes of data quickly and accurately to extract relevant information from ICSRs, such as adverse events, drug dosage, patient demographics, and medical history. This automation can lead to faster processing of ICSRs, increased identification of safety signals, and better support for regulatory compliance. This enhanced decision-making capability leads to improved patient safety and more targeted drug development.

AI and ML technologies are shaping the entire value chain in PV, from data collection through information extraction, analytics, insights, and regulatory reporting to actionable intelligence. AI helps identify, classify, and prioritize relevant information from disparate sources, such as EHRs, medical literature, and social media, contributing to a more efficient and robust data collection process. AI-powered algorithms detect potential safety signals hidden within vast amounts of data, enabling PV experts to identify and assess emerging risks earlier and more accurately than traditional methods. In addition, AI continually updates its models as new data become available, further improving the detection and analysis of drug safety. AI supports human-in-the-loop decision-making by providing insights and predictions based on patterns and trends in the data, while helping maintain compliance with evolving regulations and reporting requirements through automated tasks and real-time monitoring of data quality and completeness.

Despite the fast development of technology, several challenges remain. The performance of AI models is heavily dependent on the quality and quantity of data available, particularly in resource-limited settings. Considering the heterogeneity of data sources, robust AI models capable of integrating various types of data while ensuring accurate and reliable outputs are needed. The acceptance of AI systems among PV professionals continues to depend on addressing these fundamental challenges.

Regulatory and ethical considerations for AI-enhanced PV, highlighting current guidelines and expected course of evolution.

AI, artificial intelligence; EAMS, Early Access to Medicines Scheme; EMA, European Medicines Agency; FDA, Food and Drug Administration; GDPR, General Data Protection Regulation; HIPAA, Health Insurance Portability and Accountability Act; ICH, International Council for Harmonization; MHRA, Medicines and Healthcare products Regulatory Agency; NDA, New Drug Application; PMDA, Pharmaceuticals and Medical Devices Agency; PV, pharmacovigilance; WHO, World Health Organization.

## Section: Future directions and emerging trends

As AI continues to contribute toward making PV processes rapid and efficient, there are specific steps required to be completed in the future for building reliable and robust AI-integrated PV systems.

Federated learning approaches have gained substantial interest as a way of leveraging varied datasets while maintaining data privacy and security. 51 This allows AI models to be trained across multiple decentralized devices or servers holding local data samples, without exchanging them. In PV, this could enable collaborative learning across healthcare organizations, pharmaceutical companies, and regulatory bodies, enhancing signal detection without violating data protection regulations.

Regulatory authorities face an interpretability challenge due to “black box” nature of AI models. This calls for the need to develop XAI models that provide transparent reasoning for their predictions, to facilitate regulatory acceptance as well as clinical decision-making. Future PV systems may incorporate XAI methods such as LIME or SHAP to provide interpretable insights into ADR predictions. 45

While still in very early stages, quantum computing holds promise for solving complex computational problems in PV when coupled with AI. 52 Quantum algorithms could potentially analyze huge combinatorial spaces of drug–drug interactions and genomic variations, resulting in more precise and personalized ADR predictions. The integration of genomic data with traditional PV data sources is an emerging direction where pharmacogenomic information will also be utilized for training future AI models to predict individual-level vulnerabilities to specific ADRs.

To improve the reliability and traceability of PV data, scientists are exploring secure, transparent systems for recording and analyzing ADRs and safety signals. Blockchain technology is one such potential solution that creates a secure, shared record of information that remains unaltered without detection. 53 This can make ADR and safety signal detection more reliable. It will also assist different organizations to work together openly.

As PV systems expand globally, there is a growing demand for AI systems that can process and analyze safety information across multiple languages. Future NLP models may leverage methods like zero-shot learning and multilingual transformers to enable more effective cross-language ADR detection and signal evaluation.

Proactive safety assessments can be enhanced by developing and implementing AI models coupled with in silico trials and virtual patient simulations. These systems could simulate drug effects across diverse patient populations, potentially identifying safety issues before they manifest in real-world scenarios.

Due to continuously evolving safety profiles of drugs with time, it is also critical to have continuously learning AI models that can automatically update with the incorporation of new safety data, ensuring that ADR predictions remain in present and are accurate across the entire lifecycle of the drug. In addition to safety profiles, the changing environmental factors and lifestyles should also be incorporated into the models by considering data gathered from wearable devices, environmental sensors, and dietary logs to provide a more comprehensive understanding of ADR risks.

Aforementioned directions promise to enhance the efficiency, accuracy, and scope of PV processes. However, their successful implementation will require continued collaboration between AI scientists, PV experts, regulatory organizations, and healthcare providers to ensure responsible deployment of these technologies in the interest of patient safety.

Future directions must focus on improving the quality and standardization of datasets, advancing NLP techniques for better interpretation of clinical narratives, and developing XAI models. Regulatory frameworks should evolve to support AI deployment in PV, ensuring the establishment of best practices for AI implementation and the creation of large-scale, publicly available training datasets. Going beyond correlation-based approaches by integrating causal inference techniques will allow for a more accurate understanding of the relationship between drugs and ADRs. The integration of AI and big data in PV has the potential to transform drug safety monitoring, addressing many of the challenges posed by increasing data complexity and the need for real-time analysis. As these technologies continue to evolve, they promise to make PV more efficient, accurate, and comprehensive, thereby improving patient safety. Human oversight will still be required to validate AI findings, but ongoing efforts to improve the robustness of AI systems will reduce dependency on manual interventions and scale the use of AI in PV.

## Section: Conclusion

As AI continues to evolve from experimental stages to routine application in PV, its ability to integrate into everyday workflows hinges on overcoming significant challenges related to data quality, interpretability, and bias mitigation. A holistic approach involving regulatory alignment, transparency, and ongoing validation is crucial to ensure AI systems in PV not only perform as expected but also adapt to the ever-changing landscape of drug safety. Addressing these concerns will pave the way for AI’s broader acceptance and trusted use in PV.

## Section: Contributor Information

Ankit Nagar, University of Maryland Baltimore, Rm S41020 N Pine St, Baltimore, MD 21201, USA.

Joga Gobburu, Department of Practice, Science, and Health Outcomes Research, School of Pharmacy, University of Maryland, Baltimore, MD, USA.

Aloka Chakravarty, Pfizer Inc., New York, NY, USA.


---

# Artificial Intelligence in Small-Molecule Drug Discovery: A Critical Review of Methods, Applications, and Real-World Outcomes

- **Authors:** Sarfaraz K Niazi
- **Issuer:** Pharmaceuticals (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2025-08-26
- **Language:** en
- **DOI:** 10.3390/ph18091271
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41011141/
- **Licence:** CC-BY

## Section: Abstract

AbstractArtificial intelligence (AI) is emerging as a valuable complementary tool in small-molecule drug discovery, augmenting traditional methodologies rather than replacing them. This review examines the evolution of AI from early rule-based systems to advanced deep learning, generative models, diffusion models, and autonomous agentic AI systems, highlighting their applications in target identification, hit discovery, lead optimization, and safety prediction. We present both successes and failures to provide a balanced perspective. Notable achievements include baricitinib (BenevolentAI/Eli Lilly, an existing drug repurposed through AI-assisted analysis for COVID-19 and rheumatoid arthritis), halicin (MIT, preclinical antibiotic), DSP-1181 (Exscientia, discontinued after Phase I), and ISM001-055/rentosertib (Insilico Medicine, positive Phase IIa results). However, several AI-assisted compounds have also faced challenges in clinical development. DSP-1181 was discontinued after Phase I, despite a favorable safety profile, highlighting that the acceleration of discovery timelines by AI does not guarantee clinical success. Despite progress, challenges such as data quality, model interpretability, regulatory hurdles, and ethical concerns persist. We provide practical insights for integrating AI into drug discovery workflows, emphasizing hybrid human-AI approaches and the emergence of agentic AI systems that can autonomously navigate discovery pipelines. A critical evaluation of current limitations and future opportunities reveals that while AI offers significant potential as a complementary technology, realistic expectations and careful implementation are crucial for delivering innovative therapeutics.Keywords: artificial intelligence, drug discovery, machine learning, deep learning, molecular design, ADMET prediction, virtual screening, diffusion models, agentic AI, foundation models

## Section: 1. Introduction

The pharmaceutical industry is experiencing a significant transformation through the integration of artificial intelligence (AI) with traditional drug discovery methodologies. This evolution represents not a replacement of established approaches but rather the development of complementary tools that augment human expertise and computational chemistry methods that have been refined over decades [1,2]. Recent developments underscore this complementary nature: Insilico Medicine’s TNIK inhibitor, INS018_055, created using generative AI in conjunction with traditional medicinal chemistry approaches, progressed from target discovery to Phase II clinical trials in approximately 18 months, demonstrating how AI can accelerate specific aspects of drug development when integrated with conventional methods [3]. This achievement, alongside the growing pipeline of AI-assisted molecules entering clinical trials, signals an evolution in pharmaceutical research where artificial intelligence approaches work alongside established methodologies to address specific challenges in the discovery process [4].

It is crucial to acknowledge that AI represents an additional tool in the drug discovery toolkit rather than a paradigm shift that renders traditional methods obsolete. The success of AI applications depends heavily on the quality of training data, the expertise of medicinal chemists interpreting results, and the robustness of experimental validation—all elements rooted in traditional drug discovery practices. While AI can process vast chemical spaces and identify patterns beyond human capability, it cannot replace the intuition, creativity, and contextual understanding that experienced drug discovery scientists bring to the process.

The transformation extends to regulatory agencies, with the FDA now utilizing AI systems to support the review of drug applications while maintaining traditional review processes [5]. The FDA published a draft guidance in 2025 titled “Considerations for the Use of Artificial Intelligence to Support Regulatory Decision Making for Drug and Biological Products,” informed by over 500 submissions with AI components from 2016 to 2023. The agency’s integration of AI/ML technologies reflects a recognition that these tools can enhance rather than replace traditional regulatory science [6]. As highlighted in a recent Nature Machine Intelligence perspective, this draft guidance establishes a risk-based credibility assessment framework for AI applications that complements existing regulatory frameworks [7].

The convergence of computational power, sophisticated algorithms, and vast biomedical datasets has created opportunities to address specific challenges in pharmaceutical development, where traditional approaches face mounting costs exceeding $2.6 billion per approved drug and development timelines stretching 10–15 years [8]. However, as noted in Nature Machine Intelligence, while deep learning shows promise for drug discovery, including advanced image analysis and molecular property prediction, it requires careful validation. It should be viewed as complementary to established methods rather than a replacement [9]. The dual-use potential of these technologies also raises important ethical considerations, as AI technologies for drug discovery could be misused for de novo design of biochemical weapons [10].

The application of AI in molecular biosimilarity assessment demonstrates how these technologies can enhance rather than replace traditional analytical methods in pharmaceutical development [11]. The success of AI-assisted drug repurposing, such as baricitinib identified through AI analysis for COVID-19 treatment, and the advancement of AI-designed molecules like rentosertib through clinical trials, validates the potential of these approaches when integrated adequately with traditional drug discovery processes. As we evaluate this technological integration, it is essential to maintain realistic expectations about AI’s role as a powerful tool that complements, rather than replaces, the established foundations of pharmaceutical research and development.

## Section: 1. Introduction › Small Molecules in the Context of AI-Assisted Discovery

Small molecules represent the largest class of approved therapeutics, comprising approximately 90% of all marketed drugs [12]. These compounds offer distinct advantages, including oral bioavailability, tissue penetration, and well-established manufacturing processes. The traditional drug discovery paradigm, while successful in delivering thousands of approved medicines, faces mounting pressures from increasing research and development costs, declining productivity, and stringent regulatory requirements. The pharmaceutical industry’s productivity challenges, often referred to as “Eroom’s Law,” describe the observation that drug discovery efficiency has declined over the past decades, with the number of new drugs approved per billion dollars spent on research halving approximately every nine years [13].

The complexity of modern drug discovery encompasses multiple interconnected challenges. Target validation requires a comprehensive understanding of disease biology and the mechanism of action [14]. Hit identification from millions of potential compounds demands efficient screening strategies [15]. Lead optimization involves simultaneous improvement of multiple properties, including potency, selectivity, pharmacokinetics, and safety [16]. Each stage is characterized by high attrition rates, with only 1 in 5000 discovered compounds ultimately reaching market approval [17]. The traditional drug discovery process costs over $2.6 billion per approved drug and requires 10–15 years from initial discovery to market approval [8].

Artificial intelligence has emerged as a complementary technology that addresses specific challenges by leveraging computational power to process vast chemical spaces, predict molecular properties, and guide experimental design [18,19,20]. Unlike traditional computational approaches that rely on mechanistic models, AI systems can learn complex patterns from large datasets and make predictions for novel chemical entities. However, AI’s effectiveness is limited by data biases and generalizability issues, as highlighted in recent meta-analyses that show variable performance across datasets [21].

Generative AI, a subset of artificial intelligence that creates new content rather than simply analyzing existing data, has become particularly valuable as a tool in drug discovery by enabling the de novo design of novel molecular structures to complement traditional medicinal chemistry approaches [22,23]. Graph Neural Networks (GNNs) represent another crucial advancement, specifically designed to process molecular structures represented as mathematical graphs, where atoms serve as nodes and bonds as edges [24,25]. Convolutional Neural Networks (CNNs), initially developed for image processing, have been adapted for molecular property prediction by treating chemical structures as images or 3D objects [26,27].

The integration of AI into drug discovery workflows has accelerated significantly in recent years, driven by advances in deep learning [28], increased data availability [29], and improvements in computational infrastructure. Key advances in deep generative models [30,31], diffusion models [32], active learning strategies [33], multi-objective optimization [34], and agentic AI systems [35] have demonstrated significant potential to enhance pharmaceutical research and development when used in conjunction with traditional methods. However, critical evaluations reveal limitations in out-of-distribution performance and the need for careful validation.

## Section: 2. Historical Evolution of Computational Small-Molecule Discovery

The application of computational methods to small-molecule drug discovery has evolved through distinct phases, each building upon previous advances while establishing parallel tracks of development rather than linear progression. Early efforts in the 1960s focused on developing quantitative structure-activity relationship (QSAR) models that correlated molecular descriptors with biological activity [36]. These linear models, while limited in scope, established the fundamental principle that molecular structure determines biological function and can be predicted computationally. However, QSAR’s assumptions of linearity often fail in complex biological systems, leading to poor predictions for novel scaffolds [37].

The 1980s witnessed the emergence of structure-based drug design, enabled by advances in computational chemistry and molecular modeling [38]. The development of the DOCK program by Kuntz and colleagues at UCSF represented a seminal achievement, enabling the first systematic approaches to molecular docking [39]. This period also witnessed significant advances in molecular dynamics simulations and force field development, with programs such as AMBER and CHARMM providing tools to model protein-ligand interactions with increasing accuracy. These developments enabled researchers to predict how small molecules interact with biological targets, revolutionizing the rational design of inhibitors. Simultaneously, combinatorial chemistry approaches enabled the synthesis of large compound libraries, creating new opportunities for high-throughput screening campaigns [40].

A significant development during this period was the emergence of pharmacophore-based drug design, which provided an indirect approach to drug discovery when target structures were unavailable. Pharmacophore modeling enabled researchers to define the essential features required for biological activity based on known active compounds, allowing for virtual screening without requiring detailed structural information about the target [41]. This approach proved particularly valuable for targets where obtaining crystallographic structures was complex.

The 1990s marked the transition toward knowledge-based systems and expert systems that encoded medicinal chemistry expertise into rule-based algorithms. These systems, exemplified by programs such as LHASA (Logic and Heuristics Applied to Synthetic Analysis), aimed to automate retrosynthetic planning and predict synthetic feasibility, thereby supporting drug discovery by helping chemists plan efficient synthetic routes to target molecules [42,43]. While LHASA was not directly used for drug design, it played a crucial supporting role in making drug discovery more efficient by predicting the synthetic accessibility of proposed compounds.

The machine learning era (2000s–2015) introduced data-driven approaches that could learn patterns from experimental data without explicit programming. Support vector machines, random forests, and early neural networks began to complement traditional QSAR models, offering improved accuracy and the ability to handle non-linear relationships [44,45]. Importantly, these methods did not replace traditional approaches but rather provided additional tools that could be used in conjunction with structure-based design, pharmacophore modeling, and molecular dynamics simulations. The pharmaceutical industry began generating larger datasets through high-throughput screening, creating opportunities for more sophisticated modeling approaches [46]. Yet, these models often suffered from overfitting and limited interpretability.

The deep learning revolution (2015–2020) fundamentally expanded the computational toolkit available to drug discovery scientists. Deep neural networks demonstrated superior performance in molecular property prediction [47], chemical synthesis planning [30], and drug-target interaction modeling. The development of specialized architectures for molecular data, including graph neural networks [48,49] and molecular transformers [50], has enabled AI systems to learn directly from chemical structure representations. Companies like Atomwise (2012), BenevolentAI (2013), Exscientia (2012), and Insilico Medicine (2014) pioneered the commercial application of deep learning to drug discovery, achieving notable successes [51]. However, critics note that many “successes” are retrospective, with prospective validation rarer [21].

The coexistence and integration of multiple computational approaches characterize the current era (2020-present). Foundation models, diffusion models, and agentic AI systems work alongside traditional molecular dynamics, docking, and QSAR methods. Rather than representing a linear evolution where newer methods replace older ones, the field has developed into a rich ecosystem where different approaches are selected based on the specific problem, available data, and project constraints [35,52]. This timeline illustrates how computational power, algorithm sophistication, and data availability have created an increasingly diverse toolkit for small-molecule discovery rather than a single dominant methodology [13,20] (Figure 1).

Evolution of Computational Drug Discovery: Parallel Development of Traditional and AI Methods. The timeline illustrates how AI approaches have evolved alongside and complemented traditional computational methods, rather than replacing them. Conventional methods (shown in the blue track) continue to be refined and utilized, while AI methods (shown in the green track) offer additional capabilities. Arrows indicate points of integration and mutual enhancement between the two approaches.

## Section: 3. Core Applications of AI in Small-Molecule Discovery

AI-Enhanced Virtual Screening Workflow and Performance Comparison. The figure shows the corrected workflow with proper labeling of ligand-based screening (top pathway) and structure-based screening (bottom pathway), demonstrating how AI methods enhance both approaches.

Comparison of Traditional vs. AI-Enhanced Virtual Screening Methods for Small Molecules.

Generative AI Architectures for Small-Molecule Design. The figure shows different generative model architectures (VAEs, GANs, RNNs/Transformers, and Diffusion Models) with their respective performance metrics: Novelty (60–95%), Validity (85–99%), Uniqueness (80–95%).

AI-Based ADMET Prediction Model Performance for Small Molecules.

## Section: 3. Core Applications of AI in Small-Molecule Discovery › 3.1. Target Identification and Validation

Target identification represents the earliest stage of drug discovery, where researchers seek to identify biological molecules whose modulation by small molecules can produce therapeutic benefits. Traditional approaches rely on literature review, genetic studies, and phenotypic screening, often requiring years of investigation [14]. AI has enhanced this process by enabling systematic analysis of multi-omics datasets, including genomics, transcriptomics, and metabolomics data to identify targets amenable to small-molecule intervention [53]. However, AI models can perpetuate biases in omics data, such as underrepresentation of non-Western populations, leading to inequitable target selection [54].

Natural language processing (NLP) technologies have proven particularly valuable for target identification by mining the vast biomedical literature. Modern NLP systems can process millions of scientific papers, patents, and clinical reports to identify novel target-disease associations, small-molecule drug repurposing opportunities, and biomarker candidates [55]. IBM Watson for Drug Discovery and similar platforms have demonstrated the ability to generate testable hypotheses by analyzing unstructured text data and identifying hidden connections between genes, diseases, and small-molecule compounds [56]. A critical evaluation reveals that NLP accuracy varies, with false positives resulting from the use of ambiguous language.

Graph-based machine learning approaches have shown promise in target identification by modeling complex biological networks. These methods can integrate metabolic pathways and gene regulatory networks to predict novel therapeutic targets suitable for small-molecule intervention [57]. Knowledge graphs that combine structured databases with literature-derived relationships enable systematic exploration of the target space and identification of previously unexplored therapeutic opportunities for small-molecule drugs [58].

## Section: 3. Core Applications of AI in Small-Molecule Discovery › 3.2. Hit Discovery and Virtual Screening

Hit discovery involves identifying small-molecule compounds that demonstrate measurable activity against a validated target, typically through high-throughput screening of compound libraries containing hundreds of thousands to millions of molecules. Virtual screening has emerged as a cost-effective complement to experimental screening, using computational methods to prioritize small molecules for synthesis and testing [59].

Traditional virtual screening approaches for small molecules can be broadly categorized into ligand-based and structure-based methods. Ligand-based virtual screening relies on known active small-molecule compounds to identify structurally similar molecules using similarity metrics and pharmacophore models [37]. Structure-based approaches utilize three-dimensional target structures to predict the binding affinity of small molecules through molecular docking and scoring functions [60].

AI has significantly enhanced both approaches through improved scoring functions, better conformational sampling, and integration of multiple data sources. Deep learning models trained on small-molecule-target binding data have shown competitive performance compared to traditional scoring functions in virtual screening campaigns. However, results vary significantly depending on the specific target and dataset [61,62]. Graph neural networks (GNNs) that operate directly on molecular graphs have shown promise, achieving strong performance in predicting small-molecule binding affinities while providing interpretable results [63]. GNNs process molecular structures as mathematical graphs where atoms are represented as nodes and chemical bonds as edges, enabling the model to learn directly from the topology and chemistry of molecules without requiring manual feature engineering [64]. However, GNNs can struggle with large molecules or rare atom types, as per benchmark studies [65].

Ensemble methods combine predictions from multiple models to improve accuracy and reliability, often outperforming individual algorithms by leveraging the strengths of different approaches while mitigating their weaknesses [66]. In drug discovery, ensemble approaches typically integrate structure-based docking scores, ligand-based similarity measures, and machine learning predictions to create more robust screening workflows.

Recent developments in diffusion models have shown remarkable capabilities in molecular generation and optimization, representing a significant advancement in the field [32]. Diffusion models generate new molecular structures through a denoising process, starting from random noise and gradually refining the structure according to learned chemical patterns and desired properties. While promising, diffusion models require substantial computational resources and may generate invalid structures without proper constraints (Figure 2) (Table 1).

AI-Enhanced Virtual Screening Workflow and Performance Comparison. The figure shows the corrected workflow with proper labeling of ligand-based screening (top pathway) and structure-based screening (bottom pathway), demonstrating how AI methods enhance both approaches.

Comparison of Traditional vs. AI-Enhanced Virtual Screening Methods for Small Molecules.

## Section: 3. Core Applications of AI in Small-Molecule Discovery › 3.3. Lead Optimization

Lead optimization represents one of the most challenging aspects of small-molecule drug discovery, requiring simultaneous improvement of multiple molecular properties, including potency, selectivity, pharmacokinetics, and safety profiles. Traditional medicinal chemistry approaches rely on iterative design-make-test cycles guided by structure-activity relationships and expert knowledge [69]. This process is time-consuming and resource-intensive, often requiring synthesis and testing of hundreds of small-molecule analogs to achieve desired property profiles.

AI has enhanced lead optimization using multi-objective optimization algorithms, which can navigate complex property landscapes more efficiently than traditional approaches. Reinforcement learning methods have shown promise in treating small-molecule optimization as a sequential decision-making problem, where chemical modifications are selected to maximize a reward function that encodes the desired properties [70,71]. These approaches can simultaneously optimize multiple objectives while maintaining chemical validity and synthetic accessibility. However, reinforcement learning can be sample-inefficient and prone to local optima, as critiqued in [31].

Predictive modeling of absorption, distribution, metabolism, excretion, and toxicity (ADMET) properties has become increasingly sophisticated with the application of deep learning methods. Modern ADMET prediction models achieve accuracy levels that enable confident decision-making in small-molecule lead optimization campaigns [72]. Transfer learning approaches have proven particularly valuable for rare endpoints where limited training data is available, leveraging knowledge from related tasks to improve prediction accuracy [73]. However, the limitations of transfer learning must be acknowledged, particularly the risk of negative transfer when applied to highly specific tasks or narrow therapeutic areas where the source and target domains differ substantially [74]. For example, models trained on general solubility data may underperform on macrocyclic compounds.

The relationship between Hit Discovery (Section 3.2), Lead Optimization (Section 3.3), and De Novo Design (Section 3.4) is interconnected: hit discovery identifies initial active compounds, lead optimization refines these hits into drug-like molecules, and de novo design can be applied at both stages to generate novel chemical matter. Recent work on generative models for lead optimization demonstrates how AI approaches span multiple stages of the discovery pipeline [75].

## Section: 3. Core Applications of AI in Small-Molecule Discovery › 3.4. De Novo Small-Molecule Design

De novo molecular design represents an ambitious goal of AI-driven small-molecule drug discovery: the generation of novel chemical structures with desired properties that do not currently exist in existing chemical databases. This capability addresses the fundamental limitation of traditional screening approaches, which are constrained by the finite size of available small-molecule compound libraries [76].

Generative models have emerged as the primary AI approach for de novo small-molecule design, with several architectures showing promise, each with distinct advantages and limitations. Variational autoencoders (VAEs) are probabilistic generative models that learn to encode molecular structures into a continuous latent space and decode them back into molecular representations, allowing for smooth interpolation between known compounds and the generation of novel small-molecule structures [77,78]. VAEs provide reasonable control over generated properties but may suffer from posterior collapse and limited diversity.

Generative adversarial networks (GANs) consist of two competing neural networks: a generator that creates new molecular structures and a discriminator that attempts to distinguish between generated molecules and real training data [22,79]. GANs can generate high-quality samples but are challenging to train and may suffer from mode collapse, where the generator produces limited diversity in outputs.

Recurrent neural networks (RNNs) and Long Short-Term Memory (LSTM) networks treat molecular generation as a sequence modeling problem, learning to generate valid SMILES (Simplified Molecular Input Line Entry System) strings that represent small-molecule chemical structures [30,80]. Transformer models represent an advancement over RNNs, utilizing attention mechanisms to capture long-range dependencies in molecular sequences more effectively [50,81]. These approaches have demonstrated the ability to generate millions of novel drug-like small molecules while maintaining synthetic accessibility and incorporating property constraints.

Diffusion models represent a significant recent advancement in de novo molecular design, offering a fundamentally different approach to molecular generation [32]. These models operate through an iterative denoising process, beginning with random noise and gradually transforming it into valid molecular structures. The process involves two phases: a forward diffusion process that progressively adds noise to molecular data, and a reverse denoising process that learns to reconstruct molecules from noise. Diffusion models have demonstrated several advantages over earlier generative approaches:

Recent work has demonstrated that diffusion models can achieve state-of-the-art performance in generating molecules with specific properties while maintaining drug-likeness and synthetic accessibility [82]. These models are increasingly being adopted for structure-based drug design, enabling the generation of molecules that fit specific protein binding sites with high accuracy.

Active learning strategies optimize the selection of compounds for experimental testing by iteratively updating models based on new experimental data, focusing resources on the most informative experiments [83]. Multi-objective optimization techniques enable the simultaneous optimization of multiple molecular properties, such as potency, selectivity, and drug-likeness, using algorithms like the Non-dominated Sorting Genetic Algorithm (NSGA-II) and Pareto optimization [84].

Recent advances in molecular generation have focused on incorporating synthetic accessibility and retrosynthetic feasibility into the design of small molecules. Models that jointly optimize molecular properties and synthetic routes ensure that generated small-molecule compounds can be efficiently synthesized in practice [85]. The integration of automated synthesis platforms with generative design creates closed-loop systems that can rapidly iterate between small-molecule design and testing [86]. Critically, while these systems show promise, real-world applications often require human oversight to address ethical concerns, such as the generation of potentially harmful compounds (Figure 3).

Generative AI Architectures for Small-Molecule Design. The figure shows different generative model architectures (VAEs, GANs, RNNs/Transformers, and Diffusion Models) with their respective performance metrics: Novelty (60–95%), Validity (85–99%), Uniqueness (80–95%).

## Section: 3. Core Applications of AI in Small-Molecule Discovery › 3.5. Prediction of Small-Molecule Pharmacokinetics and Toxicity

Accurate prediction of pharmacokinetic and toxicological properties remains one of the most critical applications of AI in small-molecule drug discovery, as poor ADMET properties account for a significant proportion of late-stage failures [87]. Traditional QSAR models for small-molecule ADMET prediction have been limited by their reliance on predefined molecular descriptors and linear relationships, often failing to capture the complex mechanisms underlying pharmacokinetic and toxicological phenomena.

Deep neural networks have demonstrated superior performance in small-molecule ADMET prediction by learning optimal molecular representations directly from chemical structure [47,88]. These models can capture non-linear structure-property relationships and handle diverse chemical scaffolds more effectively than traditional approaches. Graph neural networks have shown promise by operating directly on molecular graphs, preserving crucial structural information that may be lost in descriptor-based approaches [67].

Multi-task learning approaches have proven valuable for small-molecule ADMET prediction by leveraging shared information across related endpoints. Models trained simultaneously on multiple pharmacokinetic parameters can achieve better performance than single-task models, particularly for endpoints with limited training data [68]. Transfer learning from large-scale chemical datasets has further improved prediction accuracy for specialized small-molecule ADMET endpoints.

Explainable AI (XAI) methods have become increasingly crucial in small-molecule ADMET prediction, providing mechanistic insights and building confidence in model predictions [89,90]. Attention mechanisms in neural networks can highlight molecular substructures responsible for predicted properties, enabling medicinal chemists to understand and act on model predictions [67,91]. SHAP (SHapley Additive exPlanations) values and similar interpretability methods provide quantitative measures of feature importance that can guide small-molecule optimization strategies [92]. These approaches help address the “black box” problem of deep learning models by making their decision-making processes more transparent and trustworthy (Table 2).

AI-Based ADMET Prediction Model Performance for Small Molecules.

## Section: 4. AI-Discovered and AI-Assisted Small-Molecule Development: Success Stories and Lessons Learned

The practical impact of AI in small-molecule drug discovery is increasingly demonstrated through real-world applications, ranging from approved drugs to compounds advancing through clinical trials. It is essential to distinguish between AI-discovered compounds (those designed de novo by AI systems), AI-assisted compounds (where AI tools have significantly contributed to the optimization of molecules), and AI-assisted repurposing (where AI identified new uses for existing drugs). These examples illustrate both the potential and limitations of AI technologies in pharmaceutical development.

AI-Discovered, AI-Assisted, and AI-Repurposed Small Molecules in Clinical Development.

## Section: 4. AI-Discovered and AI-Assisted Small-Molecule Development: Success Stories and Lessons Learned › 4.1. AI-Assisted Drug Repurposing: Baricitinib

Baricitinib represents a significant success in AI-assisted drug repurposing rather than de novo AI drug discovery. Initially developed by Incyte and licensed to Eli Lilly as a JAK inhibitor for rheumatoid arthritis, baricitinib was later identified by BenevolentAI through the analysis of biomedical literature and drug-target interaction networks using AI as a potential COVID-19 therapeutic, based on its anti-inflammatory and antiviral properties [100]. The AI system analyzed the mechanism of viral entry and identified that baricitinib’s inhibition of AAK1 could potentially reduce viral endocytosis. This prediction was subsequently validated in clinical trials, leading to emergency use authorization. It is important to note that baricitinib was already an approved drug, and AI’s contribution was identifying a new therapeutic application rather than designing the molecule itself. Additional clinical validation was provided by the ACTT-2 trial, which demonstrated improved recovery times when baricitinib was combined with remdesivir [101].

## Section: 4. AI-Discovered and AI-Assisted Small-Molecule Development: Success Stories and Lessons Learned › 4.2. AI-Discovered Clinical Candidates

Halicin represents one of the most celebrated early successes of AI-driven drug discovery. Discovered by researchers at MIT using deep learning models trained on diverse molecular databases, halicin demonstrated potent antibiotic activity against drug-resistant bacteria, including Acinetobacter baumannii and Mycobacterium tuberculosis [102]. The compound was identified through virtual screening of the Drug Repurposing Hub, highlighting the potential of AI for identifying molecules with entirely novel mechanisms of action. Halicin’s discovery marked a significant achievement in antibiotic research, demonstrating that AI can identify compounds with mechanisms distinct from those of existing antibiotics.

DSP-1181 (Exscientia) became one of the first AI-designed small-molecule drugs to enter human clinical trials in 2020, specifically for the treatment of obsessive-compulsive disorder [103]. The compound targets the 5-HT2A receptor and was designed in approximately 12 months compared to typical timelines of 4–6 years for traditional discovery programs. Phase I trials were completed with favorable safety profiles; however, development was discontinued by 2022 with no progression to Phase II as of August 2025.

ISM001-055 (Insilico Medicine) for idiopathic pulmonary fibrosis represents a significant milestone, as it is one of the first AI-discovered small molecules to reach Phase II clinical trials [104]. The compound was identified using Insilico’s integrated AI platform that combines target identification, molecular generation, and synthetic route planning. The discovery process, from target identification to preclinical candidate selection, was completed in approximately 18 months at a cost of less than $2.6 million. As of August 2025, Phase IIa results are positive, showing safety, tolerability, favorable pharmacokinetics, and an improvement in lung function by 98 mL in FVC, with plans for global trial expansion. The drug is now renamed rentosertib.

## Section: 4. AI-Discovered and AI-Assisted Small-Molecule Development: Success Stories and Lessons Learned › 4.3. Clinical Development Challenges and Lessons Learned

The field has experienced notable challenges that provide essential insights into the current limitations of AI in drug discovery. While AI can accelerate the discovery and optimization phases, clinical success depends on many factors beyond initial compound design. The discontinuation of DSP-1181 after Phase I, despite demonstrating a favorable safety profile, illustrates that accelerated discovery timelines do not guarantee clinical progression [103]. The reasons for discontinuation often involve complex factors, including efficacy endpoints, competitive landscape, and strategic business decisions, rather than issues with the AI-designed molecule itself.

A comprehensive analysis of AI-discovered and AI-assisted compounds reveals that, while these molecules are entering clinical trials at an increasing rate, their progression rates through clinical development remain like those of traditionally discovered compounds [105]. This finding suggests that AI’s primary benefit may lie in accelerating the preclinical discovery phase rather than fundamentally changing the probability of clinical success. The limited number of AI-designed compounds that have completed clinical development makes it premature to draw definitive conclusions about their overall success rates compared to traditional methods (Table 3).

Essential lessons from early AI drug discovery efforts include:

AI-Discovered, AI-Assisted, and AI-Repurposed Small Molecules in Clinical Development.

## Section: 5. Practical Case Studies

The following case studies illustrate the successful implementation of AI technologies in real-world small-molecule drug discovery programs, demonstrating both the potential and practical considerations of these approaches. These examples are based on documented approaches and methodologies commonly used in the pharmaceutical industry [115,116,117]. We critically evaluate their generalizability and potential biases.

## Section: 5. Practical Case Studies › 5.1. Scaffold Hopping Using Reinforcement Learning for Small-Molecule Kinase Inhibitor Discovery

A major pharmaceutical company faced the challenge of identifying novel small-molecule kinase inhibitors that avoided existing patent landscapes while maintaining potency against their target of interest. Traditional approaches based on literature scaffolds were constrained by extensive intellectual property coverage, which limited opportunities for discovering novel small-molecule chemical matter.

The research team implemented a reinforcement learning approach using the REINVENT algorithm [70], which was trained to generate novel small molecules that optimize multiple objectives simultaneously. The reward function incorporated predicted kinase activity, drug-likeness properties, and patent landscape analysis using a proprietary freedom-to-operate scoring system. The model was initialized with a pre-trained generative model and fine-tuned using policy gradient methods to bias generation toward the desired property profile.

Over the course of six months of iterative optimization, the AI system generated approximately 10,000 novel small-molecule compounds, which were then subjected to further computational analysis. Synthetic accessibility filtering using the SCScore algorithm [118] reduced this set to 200 compounds suitable for synthesis. Experimental validation confirmed activity for 45 small-molecule compounds (22.5% hit rate), with the top three compounds showing IC50 values below 100 nM and favorable selectivity profiles. Importantly, patent analysis confirmed that all active compounds represented novel small-molecule chemical matter with clear freedom to operate.

This case study demonstrates the practical value of AI in addressing real-world constraints beyond simple property optimization, including intellectual property considerations and synthetic feasibility for small-molecule discovery. The integration of multiple scoring functions and constraints in the reward function proved critical for generating actionable results [115]. However, the approach may be biased toward known kinase chemotypes if pre-training data is not diverse.

## Section: 5. Practical Case Studies › 5.2. Multi-Objective Optimization in Small-Molecule Lead Refinement Using Active Learning

A biotechnology company developing treatments for neurodegenerative diseases faced the challenge of optimizing a promising small-molecule lead compound that suffered from poor brain penetration and metabolic instability. Traditional medicinal chemistry approaches had made limited progress after 18 months of optimization, with improvements in one property typically accompanied by deterioration in others.

The team implemented an active learning strategy using Gaussian process models to predict multiple small-molecule ADMET properties simultaneously, including brain-to-plasma ratio, metabolic stability, and aqueous solubility. The acquisition function balanced exploration of novel chemical space with exploitation of promising regions, using expected improvement with multiple objectives. Uncertainty quantification enabled confident identification of compounds most likely to advance the program.

Initial model training used 150 synthesized analogs from previous medicinal chemistry efforts. The active learning system recommended 25 small-molecule compounds for synthesis in the first iteration, selected to maximize information gain across all property dimensions. Experimental testing confirmed predictions within acceptable error ranges for 80% of compounds. Three successive rounds of active learning, each involving 20–25 new compounds, identified a lead compound with 10-fold improved brain penetration and 5-fold improved metabolic stability compared to the starting point.

The key success factors included careful experimental design to ensure data quality, robust model validation procedures, and close collaboration between computational and medicinal chemistry teams. The active learning approach reduced the number of synthesis cycles required from an estimated 8–10 to 4 cycles, saving approximately 12 months of development time [116]. Notably, this success was achieved in a well-studied area; however, applicability to rare diseases with sparse data remains limited.

## Section: 5. Practical Case Studies › 5.3. AI-Enhanced High-Throughput Screening Triage for Antiviral Small-Molecule Discovery

During the COVID-19 pandemic, an academic-industry collaboration screened a 100,000-compound library against SARS-CoV-2 viral replication, yielding approximately 2500 small-molecule compounds that showed greater than 50% inhibition at primary screening concentrations. Traditional triage approaches based on chemical similarity and simple property filters were insufficient to prioritize this enormous hit set for follow-up studies within the urgent timeline constraints.

The team implemented a Bayesian neural network approach to predict the quality of small-molecule hits and the likelihood of successful optimization. The model was trained on historical antiviral screening data from related coronavirus targets, incorporating molecular descriptors, predicted ADMET properties, and target-specific features. Uncertainty quantification enabled the identification of high-confidence predictions and prioritization of experimental validation efforts.

The AI model ranked the 2500 primary screening hits, with experimental validation focused on the top 200 small-molecule compounds predicted to have the highest potential for optimization. This subset demonstrated a 5-fold enrichment in confirmed antiviral activity compared to random sampling, with 35% of the tested compounds showing activity in dose-response studies. The approach identified 12 distinct chemical scaffolds suitable for lead optimization, compared to 3–4 scaffolds that would have been identified through traditional clustering approaches.

Subsequent lead optimization efforts validated the AI predictions, with small-molecule compounds ranked highly by the model showing superior profiles in terms of potency, selectivity, and drug-like properties. Two compounds identified through this process advanced to preclinical development studies within 8 months of initial screening, compared to typical timelines of 18–24 months for traditional approaches [117]. However, the model’s reliance on historical data may have missed novel mechanisms due to a distribution shift.

## Section: 6. Emerging Trends and Transformative Technologies › 6.1. Foundation Models and Self-Supervised Learning

The emergence of foundation models and self-supervised learning represents one of the most significant developments in AI-driven small-molecule drug discovery. These approaches are closely interconnected, as foundation models are typically developed through self-supervised pre-training on large-scale molecular datasets, followed by fine-tuning for specific applications [52].

Foundation models are large-scale models pre-trained on millions of small-molecule compounds and their associated data, which can be fine-tuned for specific applications with minimal additional training data. ChemBERTa, MoleculeNet, and similar foundation models have demonstrated remarkable performance across diverse molecular property prediction tasks, often achieving state-of-the-art results with limited domain-specific training. These models enable transfer learning across different therapeutic areas and molecular targets, potentially reducing the data requirements that have historically limited AI applications in specialized domains.

Self-supervised learning approaches enable models to learn meaningful representations from unlabeled chemical data, which is particularly valuable given the relative scarcity of high-quality labeled data in drug discovery compared to other AI domains [119]. Masked language modeling approaches adapted for molecular SMILES strings have demonstrated the ability to learn rich chemical representations that transfer effectively to downstream small-molecule prediction tasks. Contrastive learning methods that learn molecular representations by comparing similar and dissimilar small-molecule compounds have achieved impressive results in predicting molecular properties and modeling drug-target interactions.

The relationship between foundation models and self-supervised learning is synergistic: self-supervised pre-training enables the development of foundation models that can capture fundamental chemical principles and structure-property relationships, which then generalize across diverse small-molecule applications. Early examples include MegaMolBART, which achieved strong performance on small-molecule optimization tasks after pre-training on 1.1 billion SMILES strings [120].

## Section: 6. Emerging Trends and Transformative Technologies › 6.2. Computational Sustainability and Energy Considerations

The environmental and economic costs of training large-scale AI models have become increasingly important considerations in drug discovery applications. Training state-of-the-art foundation models can consume substantial computational resources, with carbon footprints comparable to those of major industrial processes [121]. The energy requirements for training large transformer models can reach hundreds of MWh, raising important questions about the sustainability of AI-driven drug discovery at scale.

Several approaches are being developed to address these concerns. Model compression and knowledge distillation techniques can reduce the computational requirements of deployed models by 10- to 100-fold while maintaining much of their predictive performance [122]. Efficient architectures such as MobileBERT and DistilBERT demonstrate that smaller models can achieve competitive performance on many tasks. Green AI initiatives are promoting the development of more energy-efficient algorithms and the use of renewable energy sources for model training [123].

Cloud-based platforms are increasingly offering carbon-neutral computing options, and distributed training approaches can leverage renewable energy sources more effectively. The pharmaceutical industry is beginning to incorporate sustainability metrics into AI project evaluation, balancing model performance against environmental impact and computational costs.

## Section: 6. Emerging Trends and Transformative Technologies › 6.3. Quantum Machine Learning and Molecular Simulation

Quantum machine learning represents an emerging frontier with potential applications in small-molecule simulation and drug discovery, though practical implementations remain limited by current hardware constraints. Quantum algorithms for molecular property prediction and optimization may offer computational advantages for certain classes of problems, particularly those involving quantum mechanical effects that are difficult to simulate classically [124].

Current quantum computers are limited by their small qubit counts, short coherence times, and high error rates, which restrict their practical applications to small molecular systems. However, hybrid classical-quantum algorithms are being developed that could provide near-term advantages. Variational Quantum Eigensolver (VQE) algorithms have shown promise in calculating molecular ground state energies for small systems, potentially enabling more accurate predictions of small-molecule-target interactions [125].

Quantum machine learning algorithms for molecular property prediction are being explored, with potential advantages in feature spaces that grow exponentially with system size. Quantum kernel methods and quantum neural networks may offer computational speedups for specific molecular learning tasks, though demonstrated advantages over classical methods remain limited to specific problem classes [126].

The timeline for practical quantum advantages in drug discovery remains uncertain, with conservative estimates suggesting that it will take 10–20 years before quantum computers can outperform classical methods for realistic molecular systems. However, continued advances in quantum hardware and algorithm development may accelerate this timeline.

## Section: 6. Emerging Trends and Transformative Technologies › 6.4. Agentic AI and Autonomous Discovery Systems

Agentic AI systems represent a paradigm shift toward autonomous drug discovery platforms that can independently navigate multiple aspects of the discovery pipeline with varying degrees of human oversight [35]. These systems combine multiple AI capabilities, including natural language processing, generative modeling, and decision-making algorithms, to autonomously propose experiments, interpret results, and iteratively refine hypotheses.

Recent developments in agentic AI for drug discovery include systems that can:

The integration of agentic AI with automated synthesis and testing platforms is creating increasingly autonomous discovery loops. Examples include:

Early implementations have demonstrated the ability to identify and optimize small-molecule lead compounds with reduced human intervention. However, complete autonomy remains a long-term goal rather than a current reality. Key challenges include:

Ensuring robust decision-making under uncertainty

Current agentic AI systems in drug discovery typically operate with human oversight at critical decision points, representing a hybrid approach that leverages both machine efficiency and human judgment.

## Section: 6. Emerging Trends and Transformative Technologies › 6.5. Automated Synthesis and Closed-Loop Discovery

The integration of AI with automated synthesis platforms is creating closed-loop discovery systems that can rapidly iterate between small-molecule design and testing. Companies like Strateos, Emerald Cloud Lab, and academic initiatives are developing robotic synthesis platforms that can execute AI-designed synthetic routes with minimal human intervention [86]. These systems enable rapid experimental validation of AI predictions and continuous model improvement through active learning.

Closed-loop systems integrate small-molecule generation, synthetic route planning, automated synthesis, and biological testing into unified workflows. Early implementations have demonstrated the potential to identify and optimize small-molecule lead compounds in significantly reduced timeframes. However, the extent of timeline reduction varies considerably based on the specific application and system maturity.

## Section: 6. Emerging Trends and Transformative Technologies › 6.6. Data Standardization and Collaborative Initiatives

The success of AI in drug discovery depends critically on the availability of high-quality, standardized datasets. Several significant initiatives are addressing data standardization and sharing challenges:

The FAIR Data Principles (Findable, Accessible, Interoperable, and Reusable) are being adopted by pharmaceutical companies and research institutions to enhance data quality and sharing [127]. These principles provide guidelines for enhancing the value of research data for AI applications while maintaining appropriate confidentiality protections.

Pre-competitive Consortia such as MELLODDY (Machine Learning Ledger Orchestration for Drug Discovery) enable pharmaceutical companies to collaborate on AI model development while keeping proprietary data secure through federated learning approaches [128]. These initiatives demonstrate that competitive organizations can collaborate effectively on fundamental AI infrastructure.

Open Targets Platform provides integrated access to disease-target associations and has become a critical resource for AI-driven target identification [129]. Similar open science initiatives are expanding the availability of high-quality datasets for predicting small-molecule properties and modeling drug-target interactions.

Therapeutic Data Commons (TDC) represents a community-driven effort to create standardized benchmarks and datasets for AI in drug discovery, addressing the critical need for consistent evaluation protocols [130]. These efforts are essential for enabling fair comparison of different AI approaches and identifying genuine advances in the field.

## Section: 7. Challenges and Limitations

Despite significant progress, several fundamental challenges continue to limit the widespread adoption and effectiveness of AI in small-molecule drug discovery. Data quality represents perhaps the most critical limitation, as AI models are only as good as the data used to train them [131]. Pharmaceutical datasets often suffer from systematic biases, missing data, and inconsistent experimental protocols that can lead to poor model generalization. The prevalence of activity cliffs, where structurally similar compounds exhibit dramatically different activities, poses challenges for AI models that assume smooth structure-activity relationships [37].

Model interpretability remains a significant concern, particularly for regulatory applications where understanding the basis of AI predictions is crucial for safety assessment [89]. While explainable AI methods have made progress in providing post-hoc explanations for model predictions, truly interpretable models that provide mechanistic insights remain elusive. The “black box” nature of many deep learning models creates challenges for medicinal chemists who need to understand and trust AI recommendations.

Generalizability across chemical space represents another fundamental challenge, as AI models often perform poorly on compounds that differ significantly from their training data [132]. This limitation is particularly problematic for novel scaffolds and emerging therapeutic areas where limited training data is available. Domain adaptation and transfer learning approaches have shown promise but require careful validation to ensure reliability, and the risk of negative transfer must be carefully managed.

Regulatory acceptance of AI-designed drugs continues to evolve, as current regulatory frameworks were developed for traditional drug discovery approaches [133]. While regulatory agencies have begun developing guidance for AI applications in drug development, questions remain about the level of evidence required to support AI-based design decisions and the validation requirements for computational models used in regulatory submissions.

Ethical considerations, including bias in AI models that could exacerbate health disparities (e.g., underperformance in datasets for underrepresented ethnic groups), must be addressed [54]. The author’s advisory roles may influence perspectives, but all claims are evidence-based (Table 4).

Significant Challenges in AI-Driven Small-Molecule Discovery with Mitigation Strategies.

## Section: 8. Regulatory Evolution and Validation Frameworks

The regulatory landscape for AI in drug discovery is rapidly evolving, with agencies worldwide developing new frameworks to address the unique challenges posed by AI-assisted drug development. The FDA’s Model-Informed Drug Development (MIDD) framework provides a pathway for incorporating computational models into regulatory submissions. Recent initiatives, such as the FDA’s AI Pilot Program, are exploring specific applications of AI in the field of drug development [136].

The European Medicines Agency (EMA) has established the Innovation Task Force (ITF) to provide guidance on novel methodologies, including the application of AI in drug discovery. The ITF offers scientific guidance for developers of AI-based drug discovery platforms, helping establish acceptable evidence standards for regulatory submissions [144]. Recent EMA guidance documents have begun to address the use of AI in pharmacovigilance and benefit-risk assessment, providing precedents for broader AI applications.

Digital twins and virtual clinical trials represent emerging regulatory concepts that have the potential to revolutionize the clinical development process. These approaches use AI models to simulate patient populations and predict clinical outcomes, potentially enabling more efficient study designs and patient stratification strategies [145]. The FDA’s Digital Health Center of Excellence is actively working on guidance for these technologies.

Model validation requirements are becoming increasingly standardized, with emphasis on:

International harmonization efforts, including work by the International Council for Harmonisation (ICH), are developing global standards for AI applications in drug development, though consensus on many issues remains in development.

## Section: 9. Outlook and Transformative Potential

The future of AI in small-molecule drug discovery is likely to be characterized by increasingly integrated and autonomous systems that combine human expertise with machine intelligence. Fully automated drug discovery platforms represent an aspirational vision, where AI systems can navigate substantial portions of the discovery pipeline from target identification to preclinical candidate selection [146]. While complete automation remains a long-term goal, intermediate levels of automation are already being implemented successfully in specific applications.

## Section: 9. Outlook and Transformative Potential › 9.1. Human-AI Collaboration Paradigms

Human-AI collaboration will likely define the near-term future of small-molecule drug discovery, with AI systems augmenting rather than replacing human expertise. Successful implementations leverage the complementary strengths of human creativity and intuition with AI’s ability to process large datasets and explore vast chemical spaces [147]. Interactive AI systems that can engage in dialogue with researchers and explain their reasoning are becoming increasingly important for building trust and enabling effective collaboration.

The most promising collaboration models involve AI systems that can propose hypotheses, design experiments, and interpret results while working closely with human researchers who provide domain expertise, quality control, and strategic direction. These hybrid approaches have demonstrated superior performance compared to either human-only or AI-only approaches in several small-molecule discovery applications.

## Section: 9. Outlook and Transformative Potential › 9.2. Standardization and Benchmarking Initiatives

Standardization and benchmarking represent critical needs for the field, as the lack of consistent evaluation protocols has hindered progress and adoption [88]. Community-driven initiatives to develop standardized datasets, evaluation metrics, and benchmark problems are essential for enabling fair comparison of different approaches and identifying genuine advances. The Therapeutic Data Commons (TDC), MoleculeNet, and similar initiatives are making progress toward comprehensive benchmarking platforms [130].

Open-source software platforms and shared computational resources are democratizing access to AI technologies, thereby accelerating innovation. Projects like DeepChem, RDKit, and OpenEye are creating accessible tools that enable researchers without extensive computational expertise to apply AI methods to their small-molecule research problems [68].

## Section: 9. Outlook and Transformative Potential › 9.3. Timeline Transformation and Future Projections

Recent advances in AI technologies suggest the potential for significant reductions in small-molecule drug discovery timelines, though the extent of these improvements varies considerably across applications and therapeutic areas. The combination of foundation models, automated synthesis, agentic AI systems, and integrated AI platforms may enable more efficient discovery programs.

Conservative estimates suggest that AI integration could reduce overall timelines for small-molecule drug discovery by 30–50% in specific applications. At the same time, more optimistic projections envision greater reductions for therapeutic areas or compound classes. The COVID-19 pandemic demonstrated the potential for accelerated discovery, with AI-assisted programs identifying small-molecule clinical candidates in compressed timeframes compared to traditional approaches.

Key factors that may contribute to timeline acceleration include:

However, it is essential to note that clinical development timelines, regulatory review processes, and manufacturing scale-up represent significant bottlenecks that may limit the overall impact of AI on drug development timelines. The most important potential for timeline reduction may be in the preclinical discovery phases, where AI can have the most direct impact.

## Section: 10. Practical Implementation Guidelines

Organizations seeking to implement AI technologies in their small-molecule drug discovery workflows should follow a systematic approach that begins with clearly defined objectives and success criteria. Successful AI implementation requires careful attention to data infrastructure, model validation, team building, and organizational change management.

## Section: 10. Practical Implementation Guidelines › 10.1. Strategic Planning and Readiness Assessment

Organizations should start by conducting a comprehensive assessment of their current capabilities, data assets, and strategic objectives. This includes evaluating existing datasets for quality and completeness, assessing computational infrastructure requirements, and identifying specific use cases where AI can provide the most significant value. Return on investment calculations should consider both direct cost savings and indirect benefits such as reduced attrition rates and accelerated timelines.

## Section: 10. Practical Implementation Guidelines › 10.2. Data Infrastructure and Quality Management

Establishing robust data management systems is a prerequisite to successful AI implementation. Organizations should:

## Section: 10. Practical Implementation Guidelines › 10.3. Technology Selection and Integration

Specific use cases and data availability should drive the choice of AI methods:

Plan for scalability and future expansion

## Section: 11. Conclusions

Artificial intelligence has emerged as a valuable complementary technology in small-molecule drug discovery, offering significant opportunities to enhance specific aspects of the discovery process when integrated adequately with traditional methodologies. From early rule-based systems to modern foundation models, diffusion models, and agentic AI systems, the evolution of AI technologies has progressively expanded the toolkit available to drug discovery scientists. Current applications span the entire discovery pipeline, from target identification through lead optimization, with demonstrated successes including baricitinib (AI-assisted repurposing), DSP-1181, halicin, ISM001-055/rentosertib, and numerous other small-molecule compounds advancing through clinical development.

The distinction between AI-discovered compounds (de novo design), AI-assisted optimization, and AI-enabled repurposing is crucial for understanding the current state of the field. While AI has shown success in accelerating specific tasks such as virtual screening, property prediction, and molecular generation, it remains most effective when used in conjunction with human expertise and traditional drug discovery methods. The case studies presented illustrate that significant value can be realized when AI technologies are thoughtfully implemented with clear objectives, appropriate validation, and recognition of their limitations.

The practical implementation of AI in small-molecule drug discovery requires careful attention to data quality, model validation, and integration with existing workflows. Successful organizations are those that view AI as an augmentation of human expertise rather than a replacement, fostering collaborative environments where computational and experimental teams work together to leverage the complementary strengths of human creativity and machine intelligence. The challenges of data quality, model interpretability, and generalizability remain significant and require continued research and development.

Recent advances in foundation models, diffusion models, agentic AI systems, automated synthesis platforms, and integrated AI workflows suggest substantial potential for enhancing efficiency in small-molecule drug discovery. Conservative estimates suggest a 30–50% reduction in timeline for specific preclinical applications, although clinical development timelines remain essentially unchanged. The COVID-19 pandemic demonstrated the potential for accelerated discovery when appropriate resources and incentives are aligned, with AI playing a supporting role in identifying repurposing opportunities.

Looking forward, the field continues to evolve rapidly with emerging trends including quantum machine learning, multi-modal AI approaches, and closed-loop discovery systems. The integration of automated synthesis platforms and increasingly sophisticated agentic AI systems may further expand the capabilities and accessibility of AI-enhanced small-molecule discovery. However, fundamental challenges remain in data quality, model interpretability, generalizability, regulatory acceptance, computational sustainability, and ethics that will require continued collaborative efforts across the scientific community.

The successful realization of AI’s potential in small-molecule drug discovery will require coordinated efforts across multiple stakeholders. Industry, academia, and regulatory agencies must collaborate to develop appropriate standards, validation procedures, and regulatory frameworks that ensure the safety and efficacy of AI-assisted drug development. Educational initiatives that train the next generation of researchers in interdisciplinary approaches combining computational and experimental expertise will be crucial for sustaining progress. Most importantly, the field must maintain focus on the goal of delivering better medicines to patients more efficiently.

As AI technologies continue to mature and demonstrate value in real-world applications, their adoption in small-molecule drug discovery will likely accelerate. Organizations that begin developing AI capabilities now, while carefully attending to the implementation challenges and best practices outlined in this review, will be better positioned to realize the benefits of these technologies. The future of small-molecule drug discovery will increasingly be characterized by the seamless integration of human expertise and artificial intelligence, working together as complementary tools to address the most challenging problems in medicine and ultimately improve human health through more efficient, effective, and innovative therapeutic development.

## Section: Conflicts of Interest

The author serves as an advisor to the US FDA, EMA, MHRA, the US Senate, the White House, and several heads of sovereign states; he is also a developer of novel pharmaceutical products. These roles inform the review but do not bias the evidence-based analysis.

## Section: Funding Statement

This research received no external funding.


---

# Artificial Intelligence-Led Whole Coronary Artery OCT Analysis; Validation and Identification of Drug Efficacy and Higher-Risk Plaques

- **Authors:** Benn Jessney, Xu Chen, Sophie Gu, Yuan Huang, Martin Goddard, Adam Brown, Daniel Obaid, Michael Mahmoudi, Hector M Garcia Garcia, Stephen P Hoole, Lorenz Räber, Francesco Prati, Carola-Bibiane Schönlieb, Michael Roberts, Martin Bennett
- **Issuer:** Circulation. Cardiovascular imaging
- **Type:** Scientific article
- **Published:** 2025-09-25
- **Language:** en
- **DOI:** 10.1161/circimaging.125.018133
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40995622/
- **Licence:** CC-BY

## Section: Abstract

AbstractBACKGROUND:Intracoronary optical coherence tomography (OCT) can identify changes following drug/device treatment and high-risk plaques, but analysis requires expert clinician or core laboratory interpretation, while artifacts and limited sampling markedly impair reproducibility. Assistive technologies such as artificial intelligence-based analysis may therefore aid both detailed OCT interpretation and patient management. We determined if artificial intelligence-based OCT analysis (AutoOCT) can rapidly process, optimize, and analyze OCT images, and identify plaque composition changes that predict drug success/failure and high-risk plaques.METHODS:AutoOCT deep learning artificial intelligence modules were designed to correct segmentation errors from poor-quality or artifact-containing OCT images, identify tissue/plaque composition, classify plaque types, measure multiple parameters including lumen area, lipid and calcium arcs, and fibrous cap thickness, and output segmented images and clinically useful parameters. Model development used 36 212 frames (127 whole pullbacks, 106 patients). Internal validation of tissue and plaque classification and measurements used ex vivo OCT pullbacks from autopsy arteries, while external validation for plaque stabilization and identifying high-risk plaques used core laboratory analysis of IBIS-4 (Integrated Biomarkers and Imaging Study-4) high-intensity statin (83 patients) and CLIMA (Relationship Between Coronary Plaque Morphology of Left Anterior Descending Artery and Long-Term Clinical Outcome Study; 62 patients) studies, respectively.RESULTS:AutoOCT recovered images containing common artifacts with measurements and tissue and plaque classification accuracy of 83% versus histology, equivalent to expert clinician readers. AutoOCT replicated core laboratory plaque composition changes after high-intensity statin, including reduced lesion lipid arc (13.3° versus 12.5°) and increased minimum fibrous cap thickness (18.9 µm versus 24.4 µm). AutoOCT also identified high-risk plaque features leading to patient events including minimal lumen area <3.5 mm2, Lipid arc >180°, and fibrous cap thickness <75 µm, similar to the CLIMA core laboratory.CONCLUSIONS:AutoOCT-based analysis of whole coronary artery OCT identifies tissue and plaque types and measures features correlating with plaque stabilization and high-risk plaques. Artificial intelligence-based OCT analysis may augment clinician or core laboratory analysis of intracoronary OCT images for trials of drug/device efficacy and identifying high-risk lesions.Keywords: artificial intelligence, biomarkers, deep learning, lipids, self-help devices

## Section: Text

Intracoronary optical coherence tomography (OCT) can identify high-risk plaques and is a widely used surrogate efficacy marker for drug/device studies. For example, fibrous cap thickness (FCT) <75 µm, minimum lumen area <3.5mm2, lipid arc >180°, and presence of macrophages, calcific nodules, neovascularization, and cholesterol crystals1–6 are associated with major adverse coronary events (MACE). Many of these features change with drug/device therapy, including drugs that reduce patient events with minimal changes in plaque volume,7–13 suggesting plaque stabilization.

However, real-world OCT pullbacks are rich data sets containing hundreds of images and tens-of-thousands of candidate measurements/artery. Consequently, detailed OCT analysis for clinical trials currently requires time-consuming offline manual frame selection and measurement in specialized core laboratories. Furthermore, inter- and intraobserver variability for particular tissues, measurements, and plaque types is suboptimal,14–16 and even between core laboratories.17 Such variability may contribute to the low event rates observed for high-risk OCT features (<3% individually and 3.7% in combination5) with positive predictive values of only 20% to 30%,18–20 and limit the ability of OCT to identify high-risk plaques in real-time. A fully automated, time-efficient OCT analysis system could improve OCT reproducibility, and several systems have been described.21–26 However, many systems are still limited by the high frequency of artifacts and the similarity of artifact to disease,27 and their validation, generalizability, and accuracy on whole OCT pullbacks in real-world clinical scenarios are unclear.28 For example, many models used small or highly selected training data sets (eg, excluding frames containing stents or artifacts) and frequently lack either histopathologic validation or external validation against core laboratories using large-scale clinical trial data to substantiate model performance.

We designed and tested artificial intelligence-based OCT analysis (AutoOCT), a deep learning artificial intelligence (AI)-based intracoronary OCT analysis system to overcome these limitations and provide rapid, fully automatic, user-independent plaque characterization and measurements. AutoOCT could be a very valuable tool for trials of antiatherosclerosis drugs and identification of higher-risk plaques.

## Section: Methods › Study Population

Because of the sensitive nature of the data collected, data access requests from qualified researchers trained in human subject confidentiality protocols may be sent to the senior author. The postmortem study was approved by the Cambridgeshire 3 Research Ethics Committee (07/H0306/123) and all relatives provided informed consent. The IBIS-4 (Integrated Biomarkers and Imaging Study-4) and CLIMA (Relationship Between Coronary Plaque Morphology of Left Anterior Descending Artery and Long-Term Clinical Outcome Study) studies were approved by the institutional review boards of all participating centers and all patients provided written informed consent.

To develop AutoOCT, we annotated 36 212 OCT frames from 127 complete OCT pullbacks from 106 unselected patients with coronary artery disease from 3 UK cardiothoracic centers. All patients provided informed consent, and all pullbacks were included for analysis with no exclusion criteria. Internal histopathologic validation used a coregistered OCT/histology data set from 13 postmortem patients with written consent from relatives.29 External validation used all 83 patients from the Integrated Biomarker Imaging Study-4 OCT arm (IBIS-4, REGISTRATION: URL: https://www.clinicaltrials.gov; Unique identifier: NCT00962416)7 and 31 MACE and 31 control patients from the CLIMA study (NCT02883088).5 All pullbacks were acquired with frequency-domain C7-XR or OPTIS systems (Abbott Vascular, Santa Clara, CA) using a nonocclusive technique.

## Section: Methods › Deep Learning Model Development and Training

AutoOCT was developed in Python (3.8) with training facilitated using the Cambridge University high performance computing cluster. Segmentation masks for different artery structures and plaque components were extracted using a DeepLabv3+ convolutional neural network architecture. The model was trained with annotated frames in axial cross-sections after grayscale conversion, with a (512, 512) spatial size. Data were split at a patient level ensuring that OCT images could not be utilized in both testing and validation, and consecutive frames could not be used in both training and validation sets. Data were randomly divided into training, testing and validation sets in a 14:1:1 patient-level ratio, respectively, strictly avoiding data repetition. Hybrid Dice (similarity between 2 segmentations, ranging from 0 to 1, where 1 indicates 2 segmentations are identical, and 0 indicating no overlap) and cross entropy loss were utilized for training with adaptive moment estimation as the optimizer. A custom-designed data loader was used to overcome class imbalances and data preprocessed and optimized to remove artifacts before use in training. Extensive ablation studies with the validation data set (n=10 pullbacks, 10 patients) aided best model architecture selection. For plaque classification, an additional AI-based module utilizing an EfficientNet architecture was developed from 14 028 IBIS-4 OCT frames (83 patients) and divided with a patient-level stratification into training (7904 frames, 52 patients), validation (2878 frames, 14 patients), and testing (3246 frames, 17 patients) sets. Images were converted to polar orientation around the lumen center and resized to a spatial resolution of (512, 512) before training with a comprehensive augmentation pipeline to enhance model generalization, including random horizontal rolling, flips, color jittering, and grayscale conversion. For classification, we utilized a 2-step system first categorizing vessel segments as: (1) low risk (normal vessel, adaptive intimal thickening, pathological intimal thickening), or (2) higher-risk (fibrocalcific plaque, thick cap fibroatheroma [ThCFA], and thin cap fibroatheroma [TCFA]), with more detailed classification of higher-risk plaques based on measurement of plaque components (eg, FCTmin). The adaptive moment estimation optimizer was used for training, a learning rate-scheduler to mitigate over-fitting, and a custom imbalanced data set sampler to address class imbalance.

## Section: Methods › Data Annotation and Plaque Definitions

OCT pullbacks were exported in DICOM (Digital Imaging and Communications in Medicine) format for offline analysis. Manual segmentation of frames was performed using the Medical Imaging Interaction Toolkit (v2021.10) software. All ground-truth annotation was performed in axial cross-sections by an experienced intravascular imaging specialist following accepted plaque definitions.6 All frames were labeled, regardless of classification, data quality, or presence of imaging artifacts, but excluding frames within guide catheters or stents which were noted using binary labels. Lumen contours, and the external elastic lamina were defined, with structures in-between classified as guidewire shadow, bifurcations, or as plaque components. Normal vessel and fibrous tissue were annotated as 1 structure, but each plaque component was annotated separately. AutoOCT definitions of different plaque morphologies are described in the Supplemental Material.

## Section: Methods › Measurements and Statistical Analysis

Continuous variables are summarized as median (interquartile range) or were stated as mean±SD and categorical variables as counts (percentage). Agreement between measurements (manual or AutoOCT) or with histology measurements was compared using intraclass correlation coefficients (ICCs) for absolute agreement and Bland-Altman plots comparing mean against difference in measurements. Plaque classification accuracy was assessed by diagnostic performance with Wald-type asymptotic tests of noninferiority. P values were reported for exploratory purposes for model performance against clinical studies, without any claims of significance. Paired Student t-, Wilcoxon signed-rank-, and χ2 tests were applied when appropriate. Two-sided P values are reported throughout adopting 0.05 as the significance threshold, excepting Wald-type asymptotic tests of noninferiority30 with continuity correction for sample size for which 0.025 was adopted. The noninferiority margin was set at 0.1. Analyses were performed using SPSS 28.0.0 (SPSS, Inc, IBM Computing).

To ensure robustness and reproducibility of the methods described, AutoOCT and this article were scored against the Checklist for Artificial Intelligence in Medical Imaging31 and the Consensus-based Recommendations for Machine-learning-based Science32 checklists. Both are provided in the Supplemental Material.

## Section: Results

Study structure: training, internal, and external validation. Artificial intelligence-based OCT analysis (AutoOCT) was trained with annotated optical coherence tomography (OCT) frames from 127 complete pullbacks from unselected patients from 3 UK cardiothoracic centers. The model was tested on a holdout group of 2534 frames, and AutoOCT performance internally validated on OCT frames from ex vivo OCT pullbacks co-registered with histology from postmortem arteries. AutoOCT performance was externally validated by comparison with findings from 2 large clinical trials, the IBIS-4 (Integrated Biomarker Imaging Study-4) trial that examined 13 m treatment with high dose rosuvastatin, and the CLIMA (Relationship Between Coronary Plaque Morphology of Left Anterior Descending Artery and Long Term Clinical Outcome Study) study that identified higher-risk plaque features leading to major adverse cardiovascular events (MACE).

Deep learning model outline and artifact correction. A, Input axial optical coherence tomography (OCT) frames were preprocessed before undergoing parallel processing. Catheter and stent locations were first classified with frame locations outputted. Plaque components were then segmented in either polar transform or Cartesian images. B, Before plaque component segmentation, images underwent correction of the effects of artifacts on the vessel wall using masking, polar transform, histogram matching, and retransform. Measurements were made of segmented plaque components with outputted data comprising clinically useful measurements and reconstructed, labeled OCT-images.

Plaque segmentation before and after artifact correction. Examples of plaque segmentation in frames containing optical coherence tomography (OCT) artifacts. From left to right, the raw OCT image, ground truth/manual annotations, artificial intelligence-based OCT analysis (AutoOCT) raw prediction before optimization, and final prediction after optimization are shown, respectively. (1) Gas bubble artifact; (2) Macrophage dots causing signal drop-out; (3) Plaque rupture with resulting signal drop-out. Arrows denote artifacts, outlined areas denote segmentation errors.

Histological, AutoOCT, and Expert Reader OCT Features for Each Plaque Subtype

Artificial intelligence-based OCT analysis (AutoOCT) performance in high-risk lesions. Left to right, Plaque components for higher-risk plaque-types measured on histology sections, coregistered optical coherence tomography (OCT) frames by AutoOCT, and expert OCT reader, and attention map output from the plaque classification system. Lipid and calcium arcs are labeled in yellow and blue respectively as degrees, and fibrous cap thickness (FCT) by red line in microns. TCFA indicates thin cap fibroatheroma; and ThCFA, thick cap fibroatheroma.

Accuracy of AutoOCT and Expert Reader Plaque Classification Compared With Histology

Artificial intelligence-based OCT analysis (AutoOCT) validation of drug effects against core laboratory. A and B, Bland-Altman plots of mean (x axis) and difference (y axis) with histograms of mean (top) and difference (right) for measurements of lipid arc (n=1218; A) and minimum fibrous cap thickness (FCT; n=1384; B). C and D, Example fibroatheroma lesions that show regression of thin cap fibroatheroma (TCFA; C) or progression of thick cap fibroatheroma (ThCFA; D) after statin therapy. Fibrous caps are outlined in red. E and F, Graphs for minimum FCT at baseline and follow-up for individual fibroatheromas (E) or mean FCT (F) for TCFA and ThCFA (n=31).

Validation of artificial intelligence-based OCT analysis (AutoOCT) to detect higher-risk plaque features against core laboratory. Upper: Vulnerable plaque features determined by core laboratory (left) and AutoOCT (right). Lower: AutoOCT diagnostic performance for each plaque characteristic compared with the core laboratory. FCT indicates fibrous cap thickness; MLA, minimum lumen area; NPV, negative predictive value; and PPV, positive predictive value.

## Section: Results › Study Population Characteristics

Overall, 366 pullbacks from 297 patients were analyzed, representing 58 840 OCT frames. Separate data sets were used for training (106 patients, 127 whole pullbacks, 36 212 frames from unselected patients from 3 UK centers), histopathologic validation (13 patients, 24 whole pullbacks, 6480 frames), and external validation (145 patients, 236 pullbacks, 16 148 frames) from IBIS-4 (83 patients) and CLIMA (62 patients) studies (Figure 1). Autopsy donors were aged 47 to 85 years, 71.4% male, and died from cardiovascular or noncardiovascular causes (Table S1). Full IBIS-4 and CLIMA patient characteristics are described in their respective publications.5,7

Study structure: training, internal, and external validation. Artificial intelligence-based OCT analysis (AutoOCT) was trained with annotated optical coherence tomography (OCT) frames from 127 complete pullbacks from unselected patients from 3 UK cardiothoracic centers. The model was tested on a holdout group of 2534 frames, and AutoOCT performance internally validated on OCT frames from ex vivo OCT pullbacks co-registered with histology from postmortem arteries. AutoOCT performance was externally validated by comparison with findings from 2 large clinical trials, the IBIS-4 (Integrated Biomarker Imaging Study-4) trial that examined 13 m treatment with high dose rosuvastatin, and the CLIMA (Relationship Between Coronary Plaque Morphology of Left Anterior Descending Artery and Long Term Clinical Outcome Study) study that identified higher-risk plaque features leading to major adverse cardiovascular events (MACE).

## Section: Results › Model Performance

AutoOCT was designed with sequential modules to detect the guide catheter or stents, segment artery or imaging components (lumen, external elastic lamina, guidewire shadow), correct the effect of common artifacts on the underlying vessel wall, and then segment and measure individual plaque components (Figure 2A). AutoOCT performed very well on testing data for whole pullback artery and imaging components (Dice: Lumen 0.99, external elastic lamina 0.99, Guidewire shadow 0.96), and both guide catheter and stents (Table S2), indicating that segmentation and recognition of these components closely replicated ground truth. A novel optimization technique based on histogram matching (Figure 2B and Supplemental Material) was used to remove the effects of artifacts on the underlying vessel wall and improve segmentation accuracy in complex plaque morphologies such as rupture (Figure 3). Good performance (Dice 0.8 or above) was subsequently achieved for whole-pullback plaque composition on testing data (Dice: Lipid 0.84, Calcium 0.85, Fibrous cap 0.80; Table S2) and measurements correlated excellently (ICCa 0.7 or above) with ground-truth (lipid arc ICCa, 0.94 [95% CI, 0.91–0.97], calcium arc 0.88 [95% CI, 0.79–0.95]). Consistency of plaque classification performance was undertaken, checking between the internal validation, internal testing, and external holdout cohorts33 to identify drift in model predictions and optimal operating points (Figure S1). AutoOCT analysis of a full pullback comprising 271 to 540 axial frames of 512×512 pixels took ≈180 to 300s.

Deep learning model outline and artifact correction. A, Input axial optical coherence tomography (OCT) frames were preprocessed before undergoing parallel processing. Catheter and stent locations were first classified with frame locations outputted. Plaque components were then segmented in either polar transform or Cartesian images. B, Before plaque component segmentation, images underwent correction of the effects of artifacts on the vessel wall using masking, polar transform, histogram matching, and retransform. Measurements were made of segmented plaque components with outputted data comprising clinically useful measurements and reconstructed, labeled OCT-images.

Plaque segmentation before and after artifact correction. Examples of plaque segmentation in frames containing optical coherence tomography (OCT) artifacts. From left to right, the raw OCT image, ground truth/manual annotations, artificial intelligence-based OCT analysis (AutoOCT) raw prediction before optimization, and final prediction after optimization are shown, respectively. (1) Gas bubble artifact; (2) Macrophage dots causing signal drop-out; (3) Plaque rupture with resulting signal drop-out. Arrows denote artifacts, outlined areas denote segmentation errors.

## Section: Results › AutoOCT Validation Against Histopathology and Expert Reader

AutoOCT was next validated using ex vivo OCT pullbacks obtained under physiological pressures with matched histopathology.29 128 unique OCT frames were co-registered with corresponding histological sections and lesions classified histologically by an expert cardiovascular pathologist (M.G.) as normal vessel (n=3, 2.3%), adaptive intimal thickening (n=19, 14.8%), pathological intimal thickening (n=29, 22.7%), fibrocalcific (n=8, 6.3%), and fibroatheroma (n=69, 53.9%). 22 (17.2%) fibroatheromas were TCFA (FCT<75 µm, median FCT 58.3 µm [50.0–65.8]) and 47 were ThCFA (median FCT 113.3 µm [85.0–140.0]).

We compared plaque component measurements from AutoOCT with histology and an expert interventional cardiologist reader (SH), focusing on higher-risk lesions (Table 1). Overall AutoOCT measurements showed excellent correlation with expert reader (ICCa, 0.86 [95% CI, 0.84–0.88]; P<0.001). AutoOCT-derived measurements were generally similar to histology, and particularly for lipid arc (181.8° (122.9–248.7) versus 156.9° (118.4–222.8), P=0.945) and in AutoOCT-defined TCFA (Minimum FCT [FCTmin] 48.0 µm [40.0–60.3] versus 58.3 µm [50.0–65.8], P=0.674; Table 1; Figure 4). Expert-defined FCTmin was slightly higher than histology in ThCFAs (145.0 [99.0–233.0] versus 113.3 [85.0–140.0]) but not in TCFAs (50.0 [32.3–52.5] versus 58.3 [50.0–65.8]), and for combined TCFAs and ThCFAs. FCTmin was similar for AutoOCT versus histology: P=0.451, expert versus histology: P=0.417, or AutoOCT versus expert: P=0.757). AutoOCT was able to identify histologically defined lower- (normal vessel, adaptive intimal thickening, pathological intimal thickening) or higher-risk (Fibrocalcific, ThCFA, TCFA) plaque-types with a similar accuracy to an expert OCT reader (83% versus 84%). Refining higher-risk plaque classification using plaque component measurements (Supplemental Material), demonstrated overall diagnostic accuracy of AutoOCT of 70% to 91% for different lesions, and 78.1% for TCFA, and noninferior to an expert OCT reader (P<0.025 for all plaque-types; Table 2).

Histological, AutoOCT, and Expert Reader OCT Features for Each Plaque Subtype

Artificial intelligence-based OCT analysis (AutoOCT) performance in high-risk lesions. Left to right, Plaque components for higher-risk plaque-types measured on histology sections, coregistered optical coherence tomography (OCT) frames by AutoOCT, and expert OCT reader, and attention map output from the plaque classification system. Lipid and calcium arcs are labeled in yellow and blue respectively as degrees, and fibrous cap thickness (FCT) by red line in microns. TCFA indicates thin cap fibroatheroma; and ThCFA, thick cap fibroatheroma.

Accuracy of AutoOCT and Expert Reader Plaque Classification Compared With Histology

## Section: Results › AutoOCT External Validation Against Core Laboratory: Drug Efficacy

Although AutoOCT performed well on selected images matched with histology, AI-based OCT studies in clinically relevant scenarios and real trial data are limited. We therefore undertook external validation against external core laboratories using frame-based comparison from 2 clinical trials. The IBIS-4 OCT substudy showed that 13 m of high-intensity statin treatment increased FCTmin, reduced lipid arc, and 5.8% of lesions and 69.2% TCFA regressed to more stable plaque phenotypes. Of all 83 patients (153 arteries), 27 patients (31 arteries) had ThCFA or TCFA at both time points. AutoOCT lipid arc measurements demonstrated good correlation with core laboratory measurements (ICCa, 0.75 [95% CI, 0.68–0.80]; P<0.001) with clinically acceptable average differences 18.3±58.8° (P<0.001) and 93.6% (1140/1218) measurements within 95% CI (Figure 4A). AutoOCT FCTmin also correlated well with core laboratory measurements (ICCa, 0.66 [95% CI, 0.62–0.70]; P<0.001), with a nonsignificant and subpixel-level average difference (3.1±94.6 µm [P=0.241]), and 93.7% (1297/1384) measurements within 95% CI (Figure 4B). Both whole-vessel AutoOCT FCTmin and lipid arc showed a similar increase or decrease respectively to core laboratory analysis (FCT 62.9±28.4 µm to 81.8±33.4 µm, P<0.001 versus 64.88±19.89 µm to 87.88±38.08 µm, P=0.008; lipid arc 63.1±21.7° to 49.8±20.3°, P<0.001 versus 55.94±31.04° to 43.46±3.48°, P=0.013; Figure 5C and 5D; Table S3).

IBIS-4 also reported changes in plaque types with drug treatment, so we compared AutoOCT-based classification against core laboratory definitions. Changes in AutoOCT lesion mean FCTmin was similar to the core laboratory (76.7±36.1 µm to 83.0±35.3 µm versus 74.0±32.3 µm to 94.2±39.9 µm), mostly driven by TCFA (Figure 5E). AutoOCT increased FCTmin occurred in 82.0% TCFA (92.3% by core laboratory) compared with 58.3% of ThCFA (52.2% by core laboratory; Figure 5F), suggesting that high-intensity statin treatment increases FCTmin mostly in TCFA.

Artificial intelligence-based OCT analysis (AutoOCT) validation of drug effects against core laboratory. A and B, Bland-Altman plots of mean (x axis) and difference (y axis) with histograms of mean (top) and difference (right) for measurements of lipid arc (n=1218; A) and minimum fibrous cap thickness (FCT; n=1384; B). C and D, Example fibroatheroma lesions that show regression of thin cap fibroatheroma (TCFA; C) or progression of thick cap fibroatheroma (ThCFA; D) after statin therapy. Fibrous caps are outlined in red. E and F, Graphs for minimum FCT at baseline and follow-up for individual fibroatheromas (E) or mean FCT (F) for TCFA and ThCFA (n=31).

## Section: Results › AutoOCT External Validation Against Core Laboratory: High-Risk Plaque Features

The CLIMA study5 of untreated proximal left anterior descending arteries showed that minimum lumen area <3.5 mm2, FCT <75 µm, and lipid arc >180° on OCT were associated with 1-year MACE (composite end point of cardiac death and target segment myocardial infarction. We studied 62 participants (31 MACE and 31 controls), with similar patient and lesion features (Supplemental Material, Table S4). AutoOCT showed that more MACE patients had minimum lumen area <3.5 mm2 (38.7% versus 19.4%; P<0.001), FCT <75 µm (29.0% versus 12.9%; P<0.001), and maximum lipid arc >180° (54.8% versus 41.9%; P<0.001), similar to core laboratory analysis of our subset (Table S5). Although the sensitivity and specificity of different OCT criteria to predict MACE varied, AutoOCT and core laboratory positive predictive value, negative predictive value, and diagnostic accuracy of each variable were similar (Figure 6 and Table S6), suggesting that AutoOCT can identify features of plaque vulnerability.

Validation of artificial intelligence-based OCT analysis (AutoOCT) to detect higher-risk plaque features against core laboratory. Upper: Vulnerable plaque features determined by core laboratory (left) and AutoOCT (right). Lower: AutoOCT diagnostic performance for each plaque characteristic compared with the core laboratory. FCT indicates fibrous cap thickness; MLA, minimum lumen area; NPV, negative predictive value; and PPV, positive predictive value.

## Section: Discussion

We designed and tested a modular deep learning AI-based image analysis system for intracoronary OCT, including correction of segmentation errors induced by common artifacts and both internal and external validation to detect and measure multiple markers of disease progression/regression and higher-risk plaques. Importantly, AutoOCT was trained using whole pullbacks from unselected patients, representative of real-world clinical practice, and not only perfect, artifact-free images with classical architecture features and known measurements. Our key findings are (1) AutoOCT could recover images containing common artifacts; (2) AutoOCT-derived plaque classification correlated well with histology; (3) AutoOCT-derived identification and measurement of higher-risk features such as FCT and lipid arc were comparable to histopathology, correlated well with an expert reader, and accurately identified TCFA; (4) AutoOCT replicated core laboratory findings consistent with plaque stabilization after high-intensity statins and features of plaque vulnerability that predict MACE, including minimum lumen area <3.5 mm2, FCT <75 µm, and lipid arc >180°.

Despite reported success of deep-learning models for intracoronary OCT imaging, many models are trained and tested with small, curated data sets with limited disease diversity and highly selected frames that exclude common artifacts from stents, poor image quality, thrombus, plaque rupture, dissection, and bifurcations that may not represent real-world algorithm performance.26 In contrast, AutoOCT was trained with whole unselected pullbacks (average 285 frames/patient), which is crucial for generalizability and real-world application, and used preprocessing to mitigate effects of artifacts, optimize poor-quality images, and allow analysis of all available data. Many studies report identification of lumen or individual plaque components rather than the overall plaque phenotype through collating multiple features.26,28 In contrast, AutoOCT derives binary segmentations for tissues followed by a measurement pipeline which combines labels, allowing multiple tissue types to be identified and measured to identify lower versus higher-risk plaques (adaptive intimal thickening and pathological intimal thickening versus TCFA, ThCFA, and fibrocalcific). Finally, many studies lack validation against histopathology, and most lack validation against core laboratory analyses of individual frames. We used a well-curated database of real-world clinical OCT pullbacks from 3 centers for training, a separate data set for internal validation, and externally validated AutoOCT against core laboratory analysis of 2 large-scale landmark clinical trials. While improvements continue, the current algorithm replicated core laboratory performance.

Our study demonstrates that AI-based OCT analysis may aid drug and device development, and trial design and analysis for natural history studies. For example, increased FCT, reduced lipid arc, TCFA regression, and reduced ThCFA progression can represent a signature of a drug/device likely to reduce MACE. AutoOCT of coregistered baseline and follow-up images showed accurate and reproducible vessel and frame-based analysis of these features, and gave similar results to the IBIS-4 study core laboratory. AutoOCT may therefore allow fast, automated identification of features of drug efficacy and changes in plaque morphology in small numbers of patients over short time-frames.

Histopathology and multiple imaging studies have identified the substrate underlying many MACE.1,5,34–38 However, studies to identify features predictive of MACE show a high prevalence of vulnerable plaque features but low positive predictive values18–20 and require large patient numbers often studied for 3 to 5 years. Furthermore, study analysis is labor-intensive, time-consuming, and requires expert interpretation. AutoOCT had a frame-level accuracy to detect TCFA of 78.1% ex vivo and FCT negative predictive value of >97% for MACE in vivo. While AutoOCT positive predictive value for MACE was low and similar to core laboratory analysis in vivo, AutoOCT positive predictive value for detecting TCFA ex vivo was 33.4%, representing noninferior performance compared with an expert-reader. While AI-based OCT analysis may not replace core laboratories, whole vessel and frame-based analysis in minutes/pullback may greatly speed up the analysis process.

## Section: Discussion › Limitations

Our study has some limitations. We used all frames for training, regardless of patient characteristics, image quality, presence of artifacts, or plaque phenotype. Having no exclusion criteria increases sensitivity, but reduces specificity to detect plaque components. In addition, all OCT data utilized was generated using Abbott systems and formal validation of our findings on other manufacturers’ images is ongoing. Importantly, our model was trained with data representative of real-world clinical practice, and all data utilized has been provided by researchers undertaking independent studies or clinical work. In addition, all data was used to validate AutoOCT to avoid selection bias and create an OCT system trained and tested representative of real-world OCT data. We have also demonstrated generalizability on 3 independent data sets, and showed similar measurements to core laboratories, with metrics within the published variability for OCT analysis.15,16,39,40 Second, our postmortem study examined frames from 13 OCT pullbacks and findings should be validated in larger data sets; however, 128 OCT frames with 128 ROI were coregistered with histology from the entire pullback rather than just specific plaque types, suggesting a robust applicability to clinical OCT. In addition, the validation of OCT measurements against histopathology is limited by very different resolutions, nonuniform shrinkage, and tissue destruction, particularly affecting measurements such as FCTmin of small structures, although every effort was made to mitigate modality differences through perfusion fixation of specimens. Coregistration between OCT and histology is also challenging, and small longitudinal mismatches may also influence correlations. However, an experienced imaging specialist (B.J.) performed all coregistration blinded to plaque classification. Similarly, our study utilized a single expert OCT reader and expert cardiovascular pathologist. However, all analysis was performed blinded and while other groups have utilized multiple readers or pathologists, even specialized core laboratories with multiple readers differ in opinion both internally and with other core laboratories.14–17 Third, although preprocessing can correct segmentations due to most imaging artifacts, it cannot restore some artifacts that mimic TCFA including tangential signal dropout.27 However, we report similar positive predictive value and overall diagnostic accuracy for TCFA compared with an expert reader. Fourthly, several analysis errors are due to technical limitations of OCT, such as light shielding in dense fibrocalcific plaque and similarity between tissues. These issues may explain both differences between AutoOCT and expert analysis for lipid and FCT, but are shared by both human and AI-based systems (Figure S2). Fifth, while the current version of AutoOCT can identify stent location, length and size, at present the model is not trained to measure features such as edge dissection and malposition. Finally, although our subset of CLIMA patients was similar to the entire cohort, the absolute prognostic value of each AutoOCT-defined parameter will require analysis of the whole 1003 patients over full follow-up. In addition, although both IBIS-4 and CLIMA are prospective studies comparing baseline imaging and outcomes, our analysis was retrospective and further prospective studies utilizing prespecified AutoOCT-defined higher-risk features at baseline would be informative.

## Section: Discussion › Conclusions

We developed and validated a highly generalizable deep learning AI-based model utilizing real-world clinical data for automatic coronary OCT plaque characterization. Our model utilized image preprocessing to correct segmentation errors and optimize poor-quality OCT images containing artifacts and may thus reduce subjectivity and increase reproducibility in image interpretation. AutoOCT demonstrated the small changes in plaque composition seen with pharmacotherapy and identified features of plaque vulnerability, illustrating its potential in research and real-time plaque classification and identification of higher-risk lesions to inform patient management.

## Section: Article Information › Sources of Funding

Supported by British Heart Foundation Grants PG/18/14/33562, RG13/14/30314, RE/24/130011, TA/F/20/210001 (London), Academy of Medical Sciences Starter Grants for Clinical Lecturers (REF: SGL030\1012), Innovate UK Advancing Precision Medicine 10069871, National Institutes of Health, R01 HL150608, EPSRC Cambridge Maths in Healthcare (Nr. EP/N014588/1) and Cambridge NIHR Biomedical Research Centres.

## Section: Article Information › Disclosures

Dr Hoole has been an advisor to Abbott Vascular and holds share options in Octiocor. Dr Räber received research grants to the institution by Abbott, Biotronik, Boston Scientific, Infraredx, Sanofi, Regeneron and consultation/speaker fees by Abbott, Biotronik, Gentuity, Medtronic, Novo Nordisk, and Occlutec. Dr Prati is a consultant for Abbott, Amgen, and Novo Nordisk; and has received speaker fees/honoraria from Sanofi. Drs. Roberts and Bennett are founders of Octiocor, Ltd. The other authors report no conflicts.

## Section: Article Information › Supplemental Material

Supplemental Methods

Figures S1–S2

Tables S1–S6

Reference 41

## Section: Contributor Information

Benn Jessney, Email: bj315@medschl.cam.ac.uk.

Xu Chen, Email: xc345@medschl.cam.ac.uk.

Sophie Gu, Email: zg217@medschl.cam.ac.uk.

Yuan Huang, Email: yh288@cam.ac.uk.

Martin Goddard, Email: martin.goddard1@nhs.net.

Adam Brown, Email: adam.brown@monashhealth.org.

Michael Mahmoudi, Email: mr808@cam.ac.uk.

Stephen P. Hoole, Email: s.hoole@nhs.net.

Lorenz Räber, Email: lorenz.raeber@insel.ch.

Francesco Prati, Email: fprati@hsangiovanni.roma.it.

Michael Roberts, Email: mr808@cam.ac.uk.


---

# Artificial intelligence revolution in drug discovery: A paradigm shift in pharmaceutical innovation

- **Authors:** Somayah J Jarallah, Fahad A Almughem, Nada K Alhumaid, Nojoud Al Fayez, Ibrahim Alradwan, Khulud A Alsulami, Essam A Tawfik, Abdullah A Alshehri
- **Issuer:** International journal of pharmaceutics
- **Type:** Scientific article
- **Published:** 2025-05-30
- **Language:** en
- **DOI:** 10.1016/j.ijpharm.2025.125789
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40451590/
- **Licence:** CC-BY

## Section: Abstract

Integrating artificial intelligence (AI) into drug discovery has revolutionized pharmaceutical innovation, addressing the challenges of traditional methods that are costly, time-consuming, and suffer from high failure rates. By utilizing machine learning (ML), deep learning (DL), and natural language processing (NLP), AI enhances various stages of drug development, including target identification, lead optimization, de novo drug design, and drug repurposing. AI tools, such as AlphaFold for protein structure prediction and AtomNet for structure-based drug design, have significantly accelerated the discovery process, improved efficiency and reduced costs. Success stories like Insilico Medicine's AI-designed molecule for idiopathic pulmonary fibrosis and BenevolentAI's identification of baricitinib for COVID-19 highlight AI's transformative potential. Additionally, AI enables the exploration of vast chemical spaces, optimization of clinical trials, and the identification of novel therapeutic targets, paving the way for precision medicine. However, challenges such as limited data accessibility, integration of diverse datasets, interpretability of AI models, and ethical concerns remain critical hurdles. Overcoming these limitations through enhanced algorithms, standardized databases, and interdisciplinary collaboration is essential. Overall, AI continues to reshape drug discovery, reducing timelines, increasing success rates, and driving the development of innovative and accessible therapies for unmet medical needs.


---

# Benchmarking the Structure-Based Virtual Screening Performance of Wild-Type and Resistant PfDHFR Using Docking and Machine Learning Re-Scoring

- **Authors:** Menna S Hany, Nermin S Ahmed, Frank M Boeckler, Tamer M Ibrahim
- **Issuer:** Drug design, development and therapy
- **Type:** Scientific article
- **Published:** 2025-08-15
- **Language:** en
- **DOI:** 10.2147/dddt.s537065
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40837276/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractPurposeMalaria, caused by the parasite Plasmodium falciparum, remains a critical health challenge. Its enzyme Dihydrofolate Reductase (PfDHFR) is vital for the parasite’s survival and a key target for antimalarial drugs. Mutations in PfDHFR are primary cause of drug resistance in malaria parasites, particularly to antifolate drugs, like pyrimethamine. Herein, a comprehensive structure-based virtual screening (SBVS) benchmarking analysis of three generic docking tools against both wild-type (WT) and quadruple-mutant (Q) PfDHFR variants were investigated. Furthermore, re-scoring of the docking outcome via two popular pretrained machine learning scoring functions (ML SFs) were explored. The study provides valuable recommendations into enhancing the SBVS performance against both the WT and the resistant Q PfDHFR variants.MethodsThree generic docking tools (AutoDock Vina, PLANTS, and FRED) were evaluated using the DEKOIS 2.0 benchmark set against both WT and Q PfDHFR variants. Furthermore, we analyzed the re-scoring performance of two pretrained ML SFs, namely CNN-Score and RF-Score-VS v2. In depth analysis of the screening performance and enrichment behavior using pROC-AUC, pROC-Chemotype plots and EF 1% were deliberated.ResultsOverall, eighteen docking and re-scoring outcomes for both variants were conducted. For the WT PfDHFR, PLANTS demonstrated the best enrichment when combined with CNN re-scoring reflecting an EF 1% value of 28. Re-scoring with RF and CNN significantly improved AutoDock Vina’s screening performance from worse-than-random to better-than-random. For the Q variant, FRED exhibited the best enrichment when combined with the CNN re-scoring scheme, exhibiting the maximum value of EF 1% (ie, EF 1% = 31). pROC-Chemotype plots analysis revealed that these re-scoring combinations effectively retrieved diverse and high-affinity actives at early enrichment.ConclusionThe findings demonstrate that re-scoring with CNN-Score consistently augments the SBVS performance and enriches diverse and high-affinity binders for both PfDHFR variants, offering important endorsements for improving malaria drug discovery, especially against the highly resistant Q variant.Keywords: DEKOIS 2.0, MLSFs, docking, malaria

## Section: Introduction

The number of cases of malaria remains dramatic and estimates for the year 2023 indicated 263 million cases which is a significant rise compared to previous years. Similarly, the higher cases reported during this period can be explained by the COVID-19 outbreak and other factors such as the changes in environmental features.1 Plasmodium falciparum is a type of protozoan parasite that causes malaria in humans and it is the most dangerous species among the genus Plasmodium.2 It causes a vast majority of severe and most life-threatening malaria cases.2

The enzyme Dihydrofolate Reductase-Thymidylate Synthase in Plasmodium falciparum (PfDHFR-TS) is very crucial in the lifecycle of the parasite.2 This bifunctional enzyme plays a critical role in the parasite’s reproduction as part of the folate pathway as it is involved in an integral pathway for making purines and pyrimidines, which are the building blocks of RNA and DNA. It catalyzes the reduction of dihydrofolate to tetrahydrofolate using nicotinamide adenine dinucleotide phosphate (NADPH) as its cofactor, while TS (thymidylate synthase) converts deoxyuridine monophosphate (dUMP) to deoxythymidine monophosphate (dTMP) using tetrahydrofolate.3 This makes it a very attractive target in the development of antimalarial drugs. For instance, proguanil and pyrimethamine are among the drugs used in the treatment and prevention of malaria as PfDHFR inhibitors.4 Mutations of the PfDHFR binding site, especially the quadruple-mutant (Q) PfDHFR variant (N51I/C59R/S108N/I164L) represent a common resistance mechanism which can alter the efficacy of the drug-DHFR interactions by making therapies impossible.5 In sequence, this represents a major problem in the control of malaria, reaffirming the need for alternative approaches to the development of therapies and drugs that act at different stages of the life cycle of the pathogen.4,6

In the context of SBVS, benchmarking serves as an assessment method to evaluate the performance of docking tools.7–9 Benchmark datasets typically include bioactive molecules and structurally similar inactive molecules, referred to as “decoys”, for a specific protein target.7–9 The effectiveness of a docking tool in SBVS is determined by its ability to prioritize known bioactive molecules over decoys.7–9 Consequently, benchmarking is a crucial approach for identifying optimal virtual screening pipelines that enhance predictive accuracy.10–13

Recent studies have reported the application of the DEKOIS 2.0 benchmark set to rigorously evaluate and elucidate the SBVS performance across a wide array of clinically relevant targets that extend beyond the original sets of 81 protein targets encompassed by the standard DEKOIS 2.0 collection.7,10–13 Notably, an in-depth benchmarking analysis was conducted against the fascin protein, a target of interest in cancer therapy.11 Additionally, a cross-benchmarking study utilized the SARS-CoV papain-like protease (PLpro) benchmark set against SARS-CoV-2 PLpro, dedicated to COVID-19 research.13 Similarly, cross-benchmarking investigations evaluated the SARS-CoV-2 RNA-dependent RNA polymerase (RdRp) palm subdomain using the DEKOIS 2.0 benchmark set originally generated for the hepatitis C virus (HCV) NS5B palm subdomain, owing to the high sequence homology between these two proteins.12 Furthermore, in response to emerging COVID-19 resistant variants, comprehensive benchmarking analyses have been carried out for both the wild-type and Omicron SARS-CoV-2 main protease (Mpro), utilizing newly compiled DEKOIS 2.0 benchmark sets specific to each protein.10 However, in the context of benchmarking, the dual focus on both wild-type (WT) and drug-resistant Q variants of PfDHFR remain underrepresented in the literature, and enhanced efforts are essential to combat malaria resistance.

Recently, with the emergence of machine learning scoring functions (ML SFs),14 numerous studies have shown that these methods significantly outperform traditional scoring functions in predicting binding affinities for protein-ligand complexes based on their X-ray crystal structures. Consequently, ML SFs are now considered the leading approach for this docking application.14,15 For instance, an ML SF designed for virtual screening, known as “RF-Score-VS”,16 which is based on a random forest algorithm, has achieved an average hit rate that is more than three times higher than that of the classical scoring function DOCK3.717 at the top 1% of ranked molecules. Similar improvements have been noted with convolutional neural network-based scoring functions, eg, CNN-Score18 which showed hit rates three times greater than those of traditional scoring functions like Smina/Vina19 at the top 1%.

While classical docking tools and ML SFs have shown promise in drug discovery, their combined use for complex and clinically relevant targets, like PfDHFR, is still a less explored but a very promising area in literature. Traditional docking methods often struggle to accurately predict binding strengths for different chemical structures or in case of binding site mutations due to resistance. Using ML re-scoring can help refining the initial docking poses and better distinguish between active compounds and decoys.20

Our current benchmarking study conducted this combined strategy to both WT and Q PfDHFR (as depicted in Figure 1). By evaluating this integrated workflow, we aim to create a solid framework for speeding up the discovery of new antimalarial agents that can work better against resistant PfDHFR strains. To achieve this, a diverse and potent dataset of non-covalent, non-peptidomimetic inhibitors was compiled from literature and BindingDB to create a high-quality DEKOIS 2.0 benchmark set for both variants. The study evaluated the performance of three docking tools—AutoDock Vina,21 FRED,22 and PLANTS23—using protein structures of both PfDHFR variants to identify the most suitable tool for virtual screening against these targets. Additionally, the ligand poses generated by these docking tools were re-scored using two ML SFs, RF-Score-VS v2 and CNN-Score, resulting in eighteen combined docking and scoring outcomes for both variants. The screening performance analysis and the chemotype enrichment behavior provided valuable insights to enhance the success rate of virtual screening in malaria drug discovery.

The logical flow of the study.

## Section: Methods › Preparation of the Data Sets › Preparation of Protein Structures

Crystal structures (PDB ID. 6A2M) and (PDB ID. 6KP2) for PfDHFR for WT and Q structures, respectively, were downloaded from the Protein Data Bank (PDB). Protein preparation was carried out using “Make Receptor” (version 4.3.2.0) GUI of OpenEye at default settings due to its broader applicability in VS campaigns. The water molecules, unnecessary ions, redundant chains, crystallization molecules (if any) were removed. Hydrogen atoms were added and optimized. After preparation, the protein structures were saved as OEDU file and converted to PDB file format for the docking steps afterwards.

## Section: Methods › Preparation of the Data Sets › Preparation of Small Molecules of DEKOIS 2.0 Benchmark Set

The DEKOIS 2.0 protocol was employed on the collected and curated 40 bioactive molecules for each WT and Q PfDHFR to create 1200 challenging decoys (1:30 ratio) for both variants.7 After that, preparation of all molecules was performed using Omega24 to generate multiple conformations for each ligand for FRED25 docking, while a single conformer per ligand was retained for subsequent docking in both PLANTS and AutoDock Vina. The prepared compounds were saved as SDF files which were transformed and split into PDBQT files using OpenBabel26 for AutoDock Vina27 docking experiments. For PLANTS28 docking experiments, the SDF files were converted into mol2 files, and the types of correct atoms were performed using SPORES29 software.

## Section: Methods › Benchmarking › Docking Experiments

For AutoDock Vina (1.5.7 version)27 docking, the protein files were converted to PDBQT files via prepare_receptor4.py script from the MGLTools package (version 1.5.7).30 The dimensions of the docking grid box for WT PfDHFR (PDB ID: 6A2M) were 21.33Å × 25.00Å × 19.00Å, and for the Q PfDHFR (PDB ID: 6KP2) were 21.00Å × 21.33Å × 19.00Å with a 1 Å grid spacing to ensure that all docked compound geometries were covered. The docking method’s search efficiency was retained at its default setting.

Regarding docking via PLANTS (1.2 version),28 the SDF files were converted into mol2 format and the correct atom types were set via SPORES software. “ChemPLP”, was the employed scoring function with selecting “screen” mode. Within 5 Å of the co-crystal ligand coordinates, the binding site was identified.28

For FRED docking22 (OEDocking v4.1.1.0) was used at default settings. MakeReceptor GUI of OpenEye was utilized to describe the binding site as a search box in the vicinity of the co-crystal ligand with dimensions for WT PfDHFR (PDB ID: 6A2M) 21.33Å × 25.00Å × 19.00Å, and Q PfDHFR (PDB ID: 6KP2) were 21.00Å × 21.33Å × 19.00Å with a 1 Å grid spacing. These nearly identical dimensions of grid boxes for both variants are due to high level of conservation in the binding site’s shape and size for both WT and Q PfDHFR proteins.

## Section: Methods › Benchmarking › pROC and pROC-Chemotype Calculations

The score-based docking rank was employed in the calculation of pROC-AUC (semi-logarithmic receiver operating characteristic area under the curve) utilizing the KNIME “R-Snippet” component according to the following equation:31,32

Di is the decoy fraction that is ordered higher than the bioactive that was detected, and n is the bioactives number where i corresponds to the rank’s bioactive number.

The “pROC-Chemotype” plot is an automated tool that integrates ligand chemotype and scaffold characteristics with potency classifications, allowing for their simultaneous visualization within pROC profiles generated from docking or re-scoring workflows.31 Generation of the “pROC-Chemotype” plot can be accomplished using a specific KNIME node as reported and provided in its original study.31 The docking scores are represented as fitness values (fitness = docking score multiplied by −1) to illustrate the bioactive distributions.

The enrichment factor (EF) was calculated using the following formula to evaluate the docking tool’s capacity to identify true positives from the active set in the score-ordered list as opposed to the random collection:31,32

## Section: Methods › Benchmarking › Re-Scoring ML SFs

The docking outcome from AutoDock Vina, FRED and PLANTS were re-scored by the pretrained ML SFs of CNN-Score and RF-Score-VS v2.33 The CNN-Score (v1.0.1) is a deep learning framework for molecular docking.18 It consists of an ensemble of five CNN models, each featuring a deep learning architecture with 7 to 20 hidden layers, which strikes a balance between pose prediction quality, VS performance, and execution time.18,33 These models were trained using data from two primary sources: true active compounds and property-matched decoys derived from the DUD-E dataset,34 as well as experimental data obtained from the PDBbind database.18,33 It uses the gnina function of GNINA v1.0.35 The output of the “CNNScore” by the SF for each docked pose is used for re-scoring.35

RF-Score-VS v2 is a pretrained scoring function built using the Random Forest algorithm.15 It is trained on the complete DUD-E dataset, which includes over 15,000 active molecules and approximately 900,000 property-matched decoys across 102 targets, all successfully docked to their respective DUD-E targets.15,16

The docked poses were simultaneously re-scored using RF-Score-VS and converted into SDF files, and relevant fields were extracted for pROC-AUC and EF 1% calculations.

Nevertheless, both CNN-Score and RF-Score-VS were trained on DUD-E datasets, which, despite its extensive use, contains decoys designed to be physically dissimilar from actives but may not fully represent the chemical space of true non-binders.34 This can lead to optimistic performance estimates when evaluated on similar benchmark sets. Furthermore, both models have been independently validated on external diverse datasets beyond DUD-E to assess their generalization capability. Nonetheless, performance can be influenced by such biases. Within the context of our study, these pretrained models were employed as established scoring functions to provide comparative insights rather than as definitive predictors. Therefore, we acknowledge these limitations to ensure balanced interpretation and address generalizability questions of our study.

## Section: Results

Structural illustration of PfDHFR-TS. (A) WT PfDHFR-TS dimeric assembly (PDB ID: 6A2M). The TS domain is shown in yellow, the junction region in green, and the DHFR domain in grey. The DHFR domain is complexed with nicotinamide adenine dinucleotide phosphate (NADPH), colored in blue, and the co-crystal binder in red. (B) Superposition of WT PfDHFR (PDB ID: 6A2M) in grey and Q PfDHFR (PDB ID: 6KP2) in magenta. The key resistance-associated mutations—C59R, N51I, S108N, and I164L—are highlighted in sphere representation to emphasize their spatial positions within the protein structures.

pROC plots illustrating the screening performance of AutoDock Vina, FRED and PLANTS. The left panel is for the WT PfDHFR (PDB ID: 6A2M). The right panel is for Q PfDHFR (PDB ID: 6KP2).

pROC-Chemotype plot for the benchmarking using FRED against WT PfDHFR. (A) The pROC-Chemotype plot where the docking information matches the chemotype described by the cluster number and the bioactivity information. (B) Box plot of the fitness vs chemotype clusters.

pROC-Chemotype plot for the benchmarking using FRED against Q PfDHFR. (A) The pROC-Chemotype plot where the docking information matches the chemotype described by the cluster number and the bioactivity information. (B) Box plot of the fitness vs chemotype clusters.

The screening performance and early enrichment behavior of the three docking tools and the re-scoring outcome via the ML SFs of CNN-Score and RF-Score-VS (A) The screening performance is depicted as pROC-AUC, while in (B) the early enrichment behavior is depicted as EF 1%.

pROC-Chemotype plots for CNN-Score re-scoring performance. (A) Re-scoring of PLANTS docking against WT PfDHFR. (B) Re-scoring of FRED docking against Q PfDHFR.

## Section: Results › Selection of PfDHFR Bioactive Molecules

As an initial step, all available PfDHFR inhibitors for the WT, and the Q variant were collected from the literature and BindingDB, then the bioactive molecules were manually curated. Many compounds were reported to be in a nanomolar range of activity. Therefore, we decided to include them all, and only exclude the ones with no determined affinity/activity or the ones having Ki values >260 nM. We also excluded all stereo-active molecules that exist as R/S. This ended up collecting 93 bioactive molecules for the WT and 56 actives for Q variant. Then we clustered the actives using DataWarrior software36 where the structure similarity falls below 0.6 based on Tanimoto similarity index. Consequently, 40 actives per WT, and 40 actives per Q variant were selected to represent the chemotype diversity. The compiled actives represent 12 chemical scaffolds in the WT (Table S1, in the Supplementary Material - SM) and 8 chemical scaffolds in the Q variant (PDB ID: 6KP2) (Table S2 in SM). This diversity would reflect the available chemical space for malarial PfDHFR inhibition and provide unbiased insights into the screening performance of the docking tools. The Ki values range from 0.011 nM to 1.17 nM for the WT, and from 0.04 nM to 254 nM for the Q variant. For decoys generation, the bioactive molecules were subjected to the DEKOIS 2.0 protocol8 which creates 30 structurally related decoys per compound. Eventually, we compiled a challenging decoy set of 1200 compounds for each WT and Q variant. The whole set of bioactives and decoys was used to assess the performance of the three docking tools investigated and the re-scoring employing two ML SFs.

## Section: Results › Selection of Representative PDB Structure(s) for PfDHFR

The PfDHFR-TS polypeptide is usually in a dimeric assembly containing 608 amino acids, with the 231 first amino acids being the residues of the PfDHFR domain. In addition, it consists of 89 residues known as the junction region, while the remaining 288 residues form the TS domain 3 (Figure 2). The active site of the PfDHFR domain is lined with the amino acids Asp54, Ile164, Ile14, Phe116, and Phe58. These residues are often involved in the binding of small molecules.5

In the study, we downloaded all PfDHFR structures with resolution better than 2Å from the Protein Data Bank (PDB). We focused especially on the PfDHFR structures co-crystallized with ligands in their binding site to account for the structural changes occurring during the ligand-protein binding.37 We did not observe major differences in the binding site conformations between the PfDHFR structures. Consequently, based on our analysis, we selected (PDB ID: 6A2M) as a WT PfDHFR structure,38 and (PDB ID: 6KP2) as a Q variant (N51I/C59R/S108N/I164L).5

Structural illustration of PfDHFR-TS. (A) WT PfDHFR-TS dimeric assembly (PDB ID: 6A2M). The TS domain is shown in yellow, the junction region in green, and the DHFR domain in grey. The DHFR domain is complexed with nicotinamide adenine dinucleotide phosphate (NADPH), colored in blue, and the co-crystal binder in red. (B) Superposition of WT PfDHFR (PDB ID: 6A2M) in grey and Q PfDHFR (PDB ID: 6KP2) in magenta. The key resistance-associated mutations—C59R, N51I, S108N, and I164L—are highlighted in sphere representation to emphasize their spatial positions within the protein structures.

## Section: Results › Benchmarking

pROC plots illustrating the screening performance of AutoDock Vina, FRED and PLANTS. The left panel is for the WT PfDHFR (PDB ID: 6A2M). The right panel is for Q PfDHFR (PDB ID: 6KP2).

pROC-Chemotype plot for the benchmarking using FRED against WT PfDHFR. (A) The pROC-Chemotype plot where the docking information matches the chemotype described by the cluster number and the bioactivity information. (B) Box plot of the fitness vs chemotype clusters.

pROC-Chemotype plot for the benchmarking using FRED against Q PfDHFR. (A) The pROC-Chemotype plot where the docking information matches the chemotype described by the cluster number and the bioactivity information. (B) Box plot of the fitness vs chemotype clusters.

The screening performance and early enrichment behavior of the three docking tools and the re-scoring outcome via the ML SFs of CNN-Score and RF-Score-VS (A) The screening performance is depicted as pROC-AUC, while in (B) the early enrichment behavior is depicted as EF 1%.

pROC-Chemotype plots for CNN-Score re-scoring performance. (A) Re-scoring of PLANTS docking against WT PfDHFR. (B) Re-scoring of FRED docking against Q PfDHFR.

## Section: Results › Benchmarking › Generic Docking Tools

One of the aims of this study is to evaluate the performance of diverse docking via benchmarking, eg, AutoDock Vina,21 PLANTS,23 and FRED.22 These docking tools represent different architectures in the development of their optimization/search algorithms and scoring functions. For instance, AutoDock Vina (1.5.7 version)21 is based on the Broyden–Fletcher–Goldfarb–Shanno (BFGS) method for local optimization and uses its own Vina scoring function, while PLANTS (1.2 version)23 employs the Protein-Ligand ANT System algorithm and PLANTSCHEMPLP scoring function. While FRED (v4.1.1.0)22 Developed by OpenEye Scientific Software, uses chemgauss4 which is the default scoring function, it is a Gaussian-based function that evaluates the fit of the ligand in the binding pocket. Afterward, we investigate whether re-scoring with ML SFs, such as, RF-Score-VS and CNN-Score, will outperform the classical scoring functions or not.

The benchmarking results against WT PfDHFR (PDB ID: 6A2M), and Q PfDHFR variant (PDB ID: 6KP2) revealed that PLANTS and FRED showed better-than-random performance in both structures using the pROC-AUC metric,32 ie, pROC-AUC value >0.43, compared to AutoDock Vina. Higher pROC-AUC reflects higher actives recognition at the early enrichment compared to the decoys. Interestingly, FRED showed the best screening performance against both structures. The WT structure yielded pROC-AUC values of 0.85 for FRED compared to 0.33 (worse-than-random) for AutoDock Vina, and 0.75 for PLANTS, as shown in Figure 3. The poor performance of AutoDock Vina in this case reflects the target-specific nature of its virtual screening performance. This fact is augmented by various benchmarking studies where AutoDock Vina exhibited pROC-AUC values >0.43 with DEKOIS 2.0 benchmark data sets against other protein targets.7,10–13 In addition, the Q structure yielded pROC-AUC values of 1.65 for FRED compared to 0.60 and 1.07 for AutoDock Vina and PLANTS, respectively (Figure 3).

To provide an in-depth analysis, we examined the chemotype/scaffold enrichment with the “pROC-Chemotype”31 Plot for the best-performing tool (FRED docking) against both WT and Q PfDHFR mutant variants.

The pROC-Chemotype plot for WT displayed that FRED could not retrieve any active molecule at the early enrichment (eg, library cutoff 1%), as shown in (Figure 4). In fact, the first active molecule recognized is at docking rank of 16 onwards, reflecting library cutoff of 1.3%. Therefore, re-scoring approaches are highly recommended to improve the screening performance (details in the re-scoring section). As seen in Figure 4, the bioactivity data are symbolized by the level of activity (LOA) extending from 10−6 to 10−11 for the active molecules for WT PfDHFR, reported as Ki as a type of data (TOD). The Box plot chart (Figure 4) demonstrates the docking fitness distribution of the bioactive molecules. A scaffold represented by cluster 2 molecules lies in a superior region of fitness (ie, fitness >13), while the docking scores of actives vary from −13.34 (best score) to – 8.72 (worst score) and are presented as fitness values of 13.34 to 8.72.

For the Q mutant PfDHFR, the pROC-Chemotype plot exhibited that FRED is able recognize high-affinity binders at early enrichment, as seen in (Figure 5). The bioactivity data of the collected actives in the plot are symbolized by the level of activity (LOA) extending from 10−7 to 10−11 and reported as Ki as a type of data (TOD). Like in Figure 4, the Box plot chart in (Figure 5) demonstrates the docking fitness distribution. A scaffold represented by cluster 1 molecules lies in a superior region of fitness (ie, fitness >13) among fitness values of 13.07 to 8.13 of the bioactive molecules. Interestingly, an EF 1% = 10 indicates a promising predictive power of FRED since it can recognize active molecules 10 times more than the random performance at early enrichment (eg, library cutoff 1%). The first two ranked active molecules with docking ranks 3 and 8 (Figure 5) have bioactivity ranks 35 and 16 reflecting Ki values of 5.40 nM and 1.16 nM, respectively. This highlights the ability of FRED to enrich high-affinity binders at the early enrichment.

pROC plots illustrating the screening performance of AutoDock Vina, FRED and PLANTS. The left panel is for the WT PfDHFR (PDB ID: 6A2M). The right panel is for Q PfDHFR (PDB ID: 6KP2).

pROC-Chemotype plot for the benchmarking using FRED against WT PfDHFR. (A) The pROC-Chemotype plot where the docking information matches the chemotype described by the cluster number and the bioactivity information. (B) Box plot of the fitness vs chemotype clusters.

pROC-Chemotype plot for the benchmarking using FRED against Q PfDHFR. (A) The pROC-Chemotype plot where the docking information matches the chemotype described by the cluster number and the bioactivity information. (B) Box plot of the fitness vs chemotype clusters.

## Section: Results › Benchmarking › Re-Scoring via ML SFs

The Bar chart in Figure 6A shows the re-scoring impact of RF-Score-VS and CNN-Score as pretrained ML SFs on the three docking tools. Generally, the screening performance is improved in all cases when employing CNN re-scoring for all docking tools for both WT and Q variants. Likewise, the screening performance is enhanced when recruiting RF re-scoring for all cases, except for a slight deterioration in performance for the FRED docking on the Q variant.

Regarding the re-scoring performance for the WT PfDHFR, the best performance is observed for the combination of PLANTS docking with CNN and RF re-scoring, with pROC-AUC values of 1.85 and 1.38, respectively. Both re-scoring schemes were able to enhance the performance of all generic docking tools (FRED, PLANTS, and AutoDock Vina), as shown in Figure 6A. Interestingly, the RF and CNN re-scoring were able to dramatically improve the screening performance of AutoDock Vina from worse-than-random (pROC-AUC <0.43) into better-than-random performance, with pROC-AUC values of 0.98 and 1.19 for CNN and RF, respectively.

For the Q mutant PfDHFR, it is remarkable that the CNN re-scoring scheme produced the best performance when combined with any of the three generic docking tools as shown in (Figure 6A). Its performance reaches pROC-AUC values of 1.82, 1.86, and 1.78 when combined with FRED, PLANTS, and AutoDock Vina, respectively.

Collectively, for the WT PfDHFR structure, PLANTS with CNN re-scoring shows the highest pROC-AUC, indicating a strong performance. Likewise, for the Q mutant structure, all the three tools profited from the CNN re-scoring intensely, with PLANTS and FRED showing nearly identical high scores, slightly outperforming AutoDock Vina. Re-scoring with CNN benefits the screening performance across FRED and PLANTS docking tools in all protein types while re-scoring with RF improved the docking with AutoDock Vina, especially in for the WT structure. This recommends the re-scoring procedure with ML SFs post-docking re-scoring for enhancing the screening performance in VS against PfDHFR. This improvement can be attributed to the target-specific performance of docking and post-docking re-scoring in VS. Evaluating the screening enrichment at a 1% library cutoff (EF1%) for the WT PfDHFR indicates that the docking with PLANTS combined with a re-scoring with CNN is the best scoring scheme, as demonstrated in (Figure 6B). This aligns with the overall screening performance highlighted with pROC-AUC, in Figure 6A. The EF1% value of PLANTS combined with CNN re-scoring is 28.41 which is superior to FRED and AutoDock Vina combined with RF or CNN, as shown in (Figure 6B).

For the enrichment performance of the Q PfDHFR, as observed from the overall screening performance pROC-AUC values, CNN re-scoring enhanced the enrichment when combined with any of the three docking tools, as shown in Figure 6B. It is worth mentioning that the best EF1% value is observed for the docking with FRED combined with a re-scoring with CNN (EF1% = 31.02). This enrichment slightly outperforms the EF1% values of PLANTS and AutoDock Vina combined with CNN, as seen in Figure 6B. Nonetheless, the re-scoring with RF fails to enrich actives for FRED and PLANTS at this enrichment threshold, while a good enrichment can be observed with AutoDock Vina (Figure 6B).

Visualizing the best re-scoring combinations the CNN re-scoring for WT PfDHFR via pROC-Chemotype plots (Figure 7A), revealed that CNN re-scoring was able to enrich the most potent active compound (Bioactivity rank = 1, Ki = 0.04 nM) as the best-ranked docking pose, highlighting its superior predictive capability in ranking highly bioactive compounds, ultimately in early enrichment. This result suggests the model’s efficiency in correlating docking scores with actual biological activity, ensuring reliable prioritization of high affinity candidates. Similarly, the pROC-Chemotype plot for CNN re-scoring of FRED for Q PfDHFR exhibited potent and diverse clusters of active molecules as shown in Figure 7B, with no decoys detected at all at 1% library cutoff, reflected with a maximum value of EF 1% (ie EF 1% = 31). Again, this suggests an outstanding performance of CNN re-scoring when prioritizing actives over the challenging decoys at the early enrichment.

Re-scoring with CNN-Score consistently outperforms RF-Score-VS, which can be attributed to the model being trained using convolutional neural networks that effectively capture complex spatial and physicochemical interactions within protein-ligand complexes.18 Besides, it automatically learns the key features of protein–ligand interactions that correlate with binding.18 This enables CNN-Score to generate richer and more hierarchical representations compared to the more traditional ensemble-based methods employed by RF.16,18 However, it is important to note that the superior performance of CNN-Score in re-scoring can also be influenced by target-specific factors. Therefore, broader conclusions regarding its generalizability require further validation across a large and diverse set of targets.

The screening performance and early enrichment behavior of the three docking tools and the re-scoring outcome via the ML SFs of CNN-Score and RF-Score-VS (A) The screening performance is depicted as pROC-AUC, while in (B) the early enrichment behavior is depicted as EF 1%.

pROC-Chemotype plots for CNN-Score re-scoring performance. (A) Re-scoring of PLANTS docking against WT PfDHFR. (B) Re-scoring of FRED docking against Q PfDHFR.

## Section: Conclusion

The parasite’s PfDHFR enzyme—a critical folate pathway component for DNA synthesis—remains a key antimalarial target despite widespread resistance to drugs like pyrimethamine caused by PfDHFR mutations. Mutations, especially in the Q PfDHFR variant, have caused widespread resistance to key antimalarial drugs like pyrimethamine. This makes these treatments ineffective in many areas. The growing drug resistance presents a serious threat to global efforts to control and eliminate malaria. We urgently need to focus on finding new strategies for developing new antimalarial agents that can bypass these resistance mechanisms. As part of these strategies, this study assessed virtual screening approaches for identifying PfDHFR inhibitors against both WT and drug-resistant Q variants. Three docking tools (AutoDock Vina, FRED and PLANTS) were evaluated using the DEKOIS 2.0 benchmark set, and re-scored utilizing two ML SFs via pretrained models of CNN-Score and RF-Score-VS

The results highlight that PLANTS combined with CNN re-scoring achieved the highest early enrichment (EF1% = 28) for the WT PfDHFR. Moreover, the performance of AutoDock Vina was improved from sub-random to better-than-random performance after both RF-Score-VS and CNN-Score re-scoring. It is important to emphasize that enhanced performance of ML re-scoring may be affected by target-specific variables. Consequently, broader conclusions about its generalizability warrant additional validation using a large and diverse range of targets. For the Q PfDHFR, the combination of FRED docking with CNN re-scoring showed superior enrichment with a maximum EF 1% value (ie, EF1% = 31), outperforming other combinations. Furthermore, examining the chemotype behavior, pROC-Chemotype plots confirmed that re-scoring methods enhanced early retrieval of diverse and high-affinity binders for both variants. Importantly, this study offers a practical guideline for virtual screening campaigns aimed at targeting a resistant Q variant of PfDHFR, recommending the use of FRED docking as a preliminary step followed by re-scoring with CNN-Score.

Moreover, these results demonstrate that ML-based re-scoring can significantly boost virtual screening efficacy for antimalarial drug discovery, particularly against resistant strains. Importantly, this study offers a practical guideline for virtual screening campaigns aimed at targeting a resistant Q variant of PfDHFR, recommending the use of FRED docking as a preliminary step followed by re-scoring with CNN-Score. The approach addresses challenges posed by PfDHFR mutations that undermine traditional antifolate therapies, offering a pathway to identify next-generation inhibitors less prone to resistance.

The WT and Q PfDHFR DEKOIS 2.0 sets will be made available on www.dekois.com.

## Section: Acknowledgments

TMI acknowledges the Alexander von Humboldt Foundation for partially supporting this project via the Return Fellowship Program. The authors gratefully acknowledge the support of OpenEye Scientific Software Inc. for offering a free academic license.

## Section: Abbreviations

SBVS, structure-based virtual screening; PfDHFR, Plasmodium falciparum Dihydrofolate Reductase; NADPH, nicotinamide adenine dinucleotide phosphate; dUMP, Deoxyuridine monophosphate; dTMP, deoxythymidine monophosphate; pROC-AUC, semi-logarithmic receiver operating characteristic area under the curve; EF, enrichment factor; FRED, Fast Rigid Exhaustive Docking; PLANTS, Protein-Ligand ANT System; OEDU, OpenEye Digital Unit; PDB, Protein Data Bank.

## Section: Disclosure

The authors report no conflicts of interest in this work.


---

# Benefit-Risk Reporting for FDA-Cleared Artificial Intelligence-Enabled Medical Devices

- **Authors:** John C Lin, Bhav Jain, Jay M Iyer, Ishan Rola, Anusha R Srinivasan, Chaerim Kang, Heta Patel, Ravi B Parikh
- **Issuer:** JAMA health forum
- **Type:** Scientific article
- **Published:** 2025-09-05
- **Language:** en
- **DOI:** 10.1001/jamahealthforum.2025.3351
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41004181/
- **Licence:** CC-BY

## Section: Abstract

Key PointsQuestionHow comprehensively are efficacy, safety, and risk assessments reported for artificial intelligence (AI)/machine learning (ML)−enabled devices cleared by the US Food and Drug Administration (FDA)?FindingsThis cross-sectional study of 691 FDA-cleared AI/ML devices found that key elements were frequently unreported, including study design (323 devices [46.7%]), training sample size (385 [53.3%]), and demographic representation (660 [95.5%]), with only 6 devices (1.6%) reporting data from randomized clinical trials, and 3 (<1%) reporting patient outcomes. Premarket safety assessments were documented for 195 devices (28.2%) and postmarket adverse events, including 1 death, were reported for 36 devices (5.2%).MeaningThese findings indicate that standardized efficacy, safety, and risk assessment reporting remains inadequate for FDA-cleared AI/ML devices, underscoring the need for dedicated regulatory pathways and robust postmarket surveillance to ensure patient safety.

## Section: Introduction

Medical devices enabled by artificial intelligence (AI) and machine learning (ML) are increasingly available for diagnosis and management in clinical areas including cancer, cardiology, and neurology.1,2 Both the US Food and Drug Administration (FDA) and European Union (EU) grant authorization or European Conformity marks, respectively, to allow marketing of medical devices,3 including AI/ML devices.4 As of August 7, 2024, a total of 950 AI/ML devices have been granted clearance or approval by the FDA for clinical use, with 108 and 107 cleared in 2023 and 2024, respectively.5

The FDA and EU classify medical devices, including AI/ML devices, according to risk.6 In the US, the FDA uses 3 clearance pathways for devices. (1) De novo premarket review is intended for new low- to moderate-risk (classes I or II) devices not previously classified. (2) The 510(k) clearance is intended for devices demonstrating substantial equivalence to a legally marketed predicate device.7 However, the 510(k) process has limitations because it does not require independent clinical evidence for every new device, relying instead on comparisons to predicate devices, which may themselves have been cleared without rigorous clinical testing, potentially allowing incremental risks to accumulate over generations of devices.7 (3) The Premarket Approval (PMA) pathway is the most stringent and is typically required for devices posing a substantial risk of injury or illness (class III). Most AI/ML devices are designated class II (moderate) risk and are regulated through the 510(k) pathway, which has fewer safety reporting and postmarket surveillance requirements than the PMA pathway.7,8 Additionally, one-third of AI/ML devices cleared through the 510(k) pathway originate from non-AI/ML devices.9

Unlike standards for pharmaceutical agents, there do not exist predefined standards for efficacy, safety, and risk reporting of AI/ML devices prior to or after clearance or certification.7 In particular, the FDA and EU have recognized safety and risk assessment as important regulatory priorities for AI/ML.10,11 In January 2025, the US White House issued an executive order to repeal AI policies seen as barriers to innovation, particularly a prior executive order that introduced transparency requirements for AI/ML companies, although there were no immediate impacts on AI/ML medical devices.12 By contrast, the EU Parliament passed the Artificial Intelligence Act10 in March 2024 that included safety requirements that companies must meet for AI/ML models.

To our knowledge, there has not yet been a comprehensive analysis of both pre- and postmarket benefit-risk reporting for AI/ML devices cleared by the FDA as of July 2023. Through analyzing FDA decision summaries, device labels, adverse events, and recalls, we aimed to describe benefit-risk reports, including efficacy, safety, and bias assessments, submitted by manufacturers to the FDA and to analyze postmarket surveillance of adverse events and recalls.

## Section: Methods

The University of Pennsylvania Institutional Review Board determined that this study was exempt from review due to it being nonhuman subjects research; informed consent was likewise waived. This study followed the Strengthening the Reporting of Observational Studies in Epidemiology (STROBE) reporting guideline.

## Section: Methods › Data Collection and Selection Criteria

We used a publicly available FDA website to identify all AI/ML devices cleared by the FDA between September 29, 1995, and July 27, 2023.5 The website regularly updates lists of AI/ML-enabled clearances that meet the FDA definition of medical device, including SaMD (software as a medical device) and relevant clinical decision-making software. Devices were determined to incorporate AI/ML based on information provided in market authorization summaries. We linked this FDA list to the FDA 510(k), De Novo, and PMA databases between July 2023 and January 2024, obtaining decision summaries that present the scientific evidence that served as the basis for the regulatory decision as well as data on clearance dates, reviewer specialty, company, risk classification, and clearance pathway.13 We also linked devices to adverse events and device recalls using device identification codes, including 510(k), De Novo, and PMA numbers, through the FDA Manufacturer and User Facility Device Experience (MAUDE) database and the Medical Device Recalls database on November 3, 2024.14,15

## Section: Methods › Data Abstraction

Three investigators (J.C.L., B.J., and R.B.P.) developed a codebook for device summaries encompassing data on study design, efficacy, data availability, safety reporting, and bias assessment. Six members of the research team (J.C.L., B.J., I.R., C.K., A.R.S., and H.P.) extracted data from device summaries from July 2023 to January 2024. We also analyzed the published evidence base, adverse events, and recalls for FDA-cleared devices. Disagreements were mediated by discussion between all investigators and the principal investigator (R.B.P.) at regular meetings.

## Section: Methods › Data Abstraction › Premarket Variables

To evaluate study design and efficacy, we classified whether retrospective or prospective data were cited in summary documents and classified the study design for data reporting as comparative, cross-sectional, case-control, cohort, software validation and verification, or randomized clinical trial (definitions are available in eTable 1 in Supplement 1).16,17 We identified whether decision documents mentioned statistical and clinical metrics of efficacy. Statistical metrics included positive predictive value, negative predictive value, sensitivity, specificity, area under the curve (AUC), accuracy, and calibration. Clinical metrics included patient outcomes (eg, survival), efficiency (eg, time to intervention), and cost (eg, cost-benefit analysis).

To assess data availability, we reviewed decision summaries to identify whether primary data supporting clearance were made available online. To evaluate the availability of related peer-reviewed publications, we searched MEDLINE and Web of Science using unique device names, manufacturer names, and/or institutions noted for each device. As many as 3 searches were attempted for each device. Investigators evaluated whether publications pertained to the AI/ML device and analyzed its performance.

To assess safety reporting, we ascertained from decision summaries whether manufacturers reported devices adhering to internationally recognized safety standards for electrical technologies (ie, American National Standards Institute [ANSI], International Electrotechnical Commission [IEC], Association for the Advancement of Medical Instrumentation [AAMI], National Electrical Manufacturers Association [NEMA], or International Organization for Standardization [ISO]).13 Then, standards organizations were classified as electrical/software, medical, or general based on areas of specialty. For health and safety risks, we searched decision summaries for any listed error or harm associated with the device, including algorithm errors, user errors, physical harm, and/or additional adverse outcomes.

## Section: Methods › Data Abstraction › Postmarket Variables

To assess bias and fairness reporting, we reviewed decision summaries to evaluate whether bias assessments were conducted, specifically whether performance was reported separately for subgroups defined by race and/or ethnicity, gender or sex, age, or other factors. We also analyzed the number of reported adverse events using MAUDE and classified the reason(s) for recalls using the Medical Device Recalls database as software and hardware issues, physical and patient-related harms, or other device malfunctions.

## Section: Methods › Statistical Analysis

First, we summarized frequencies of relevant outcomes. Given the FDA 2021 recommendations for improving transparency and safety and bias monitoring, we compared characteristics of AI/ML devices cleared before and after 2021 to identify temporal trends using χ2 tests; P < .05 were considered statistically significant. Data analysis was performed from October to November 2024, using Stata, version 18.0 (StataCorp). Our analytic dataset is available online (Supplement 3).

## Section: Results

We identified 691 medical devices cleared and listed as AI/ML devices by the FDA (Supplement 2). Characteristics of the included devices are described in Table 1. Devices were classified by the FDA as risk class II (moderate to high risk; 691 [100%]) and were cleared through the 510(k) (668 [96.7%]), De Novo (n = 20 [2.9%]), or PMA (n = 3 [<1%]) pathways.

The medical devices analyzed were classified under 17 unique medical specialty panels. Of these specialties, radiology comprised the most devices (n = 531 [76.9%]), followed by cardiovascular medicine (n = 70 [10.1%]), neurology (n = 20 [2.9%]), hematology (n = 15 [2.2%]), and gastroenterology-urology (n = 11 [1.6%]).

ANSI indicates American National Standards Institute; IEC, International Electrotechnical Commission; NEMA, National Electrical Manufacturers Association; ISO, International Organization for Standardization.

## Section: Results › Reporting of Study Design, Data Availability, and Efficacy

In total, 323 device summaries (46.7%) did not report study design. For the 368 devices (53.3%) that reported study design (eFigure 1 in Supplement 1), the most common design was comparative (n = 149 [40.5%]), followed by cross-sectional (n = 95 [25.8%]), case-control (n = 63 [17.1%]), cohort (n = 55 [15.0%]), and randomized clinical trial (n = 6 [1.6%]).

Most device summaries did not report timing of data collection (n = 386 [55.9%]), number of site locations (n = 564 [81.6%]), or sample sizes (n = 368 [53.3%]). Among 305 devices (44.1%) that reported timing of data collection, the most common was retrospective (n = 252 [82.6%]), followed by prospective (n = 49 [16.1%]) or both (n = 4 [1.3%]) (eFigure 2 in Supplement 1). There was little variability in the number of site locations included in AI/ML device assessments (median [IQR], 4 [2-7]). The median (IQR) sample size was 300 (135-700), although this ranged from 5 to 374 160 participants. Of the 31 devices (4.5%) that reported the demographic characteristics, the study population of 13 devices (41.9%) comprised less than 20% participants of racial or ethnic minority groups; 9 (29.0%) between 20% and 50%; and 9 (29.0%) more than 50%.

Most devices (612 [88.6%]) did not make data from testing or validation available online and were not associated with a peer-reviewed research publication (419 [60.6%]). Among the 272 devices (39.4%) associated with peer-reviewed research, 160 (58.8%) were associated with 1 or 2 publications, while 24 (8.8%) were associated with 10 or more publications.

Few device summaries provided most statistical or clinical outcomes, including sensitivity (166 [24.0%]), specificity (152 [22.0%]), positive predictive value (PPV; 43 [6.2%]), negative predictive value (NPV; 36 [5.2%]), AUC (43 [6.2%]), or accuracy (33 [4.8%]). Few reported efficiency (5 [<1%]) or patient outcomes, such as vital signs and overall survival (n = 3 [<1%]).

## Section: Results › Reporting of Safety, Risks, and Adverse Events

Manufacturers did not report the results of a safety assessment for 496 devices (71.8%) or bias assessment for 631 devices (91.3%) and did not report adherence to international safety standards for 347 devices (50.2%) (Figure). Examples of safety assessments are described in Table 2. For devices reporting compliance with safety standards, the most common standards were electrical or software (300 [43.4%]) followed by medical (182 [26.3%]). Common standards organizations included IEC (293 [42.4%]), ISO (252 [36.5%]), NEMA (153 [22.1%]), and ANSI (123 [17.8%]). Only 42 (6.1%) devices reported potential risks to health (Table 3), such as physical harm (17 [2.5%]), algorithmic errors (29 [4.2%]), and user errors (30 [4.3%]). There was an association between approval pathway (510[k], De Novo, PMA) and reporting of safety assessments (510[k], 486 of 668 [72.8%]; De Novo, 9 of 20 [45.0%]; and PM, 1 of 3 [33.3%]; P = .008), but not reporting of bias assessments or adverse events. In total, 489 adverse events were reported to the FDA for 36 devices (5.2%) , including 458 malfunctions, 30 injuries, and 1 death.

ANSI indicates American National Standards Institute; IEC, International Electrotechnical Commission; NEMA, National Electrical Manufacturers Association; ISO, International Organization for Standardization.

## Section: Results › Device Recalls

Forty devices (5.8%) were recalled 113 times in total for reasons including software or hardware issues, physical harm to patients, or other device malfunctions (Table 4). Most recalls (85 [75.2%]) were due to software issues, such as delays in starting hardware and patient management, improper dosing of medications, and imaging scans being lost or sent to multiple patients. Some (26 [23.0%]) recalls were due to physical- or patient-related harms (eg, excessive noise that could cause hearing loss). Devices with adverse events were more likely to be recalled than those without adverse events (14 of 36 [38.9%] vs 26 of 655 [4.0%]; P < .001).

## Section: Results › Temporal Trends

Relative to FDA devices cleared before 2021, devices cleared during or after 2021 were more likely to publish data online (72 of 254 [28.4%] vs 7 of 437 [1.6%]; P < .001); evaluate demographic bias (49 of 254 [19.3%] vs 11 of 437 [2.5%]; P < .001); and report study timing (133 of 254 [52.4%] vs 172 of 437 [39.4%]; P < .001), efficacy (91 of 254 [35.8%] vs 104 of 437 [23.8%]; P < .001) and clinical (28 of 254 [11.0%] vs 5 of 437 [1.1%]; P < .001) outcomes. However, devices approved during or after 2021 were less likely to be associated with a peer-reviewed publication (81 of 254 [31.9%] vs 191 of 437 [43.7%]; P = .002), report safety assessment results (34 of 254 [13.4%] vs 161 of 437 [36.8%]; P < .001), and have adverse events (5 of 254 [2.0%] vs 31 of 437 [7.1%]; P = .003) than those approved before 2021. No differences were identified in reported study design (observational vs controlled), study timing (prospective vs retrospective), adherence to international standards, reporting of health risks, or recalls (eTable 2 in Supplement 1). Devices cleared through the 510(k) pathway before 2021 were marginally more likely to report safety and bias assessments. However, this relationship was not evident for devices approved through the same pathway during or after 2021 (eTable 2 in Supplement 1).

## Section: Discussion

In this cross-sectional study of all FDA-cleared AI/ML devices from September 1995 to July 2023, a large proportion of decision summaries—intended to contain data supporting clearance—lacked information regarding study design, timing, efficacy, clinical outcomes, safety assessment, adherence to safety standards, demographic characteristics, bias assessment, and data availability. Most cleared devices did not have a study design or timing included in the clearance summary or in a peer-reviewed publication. Additionally, for the few devices that did report study design and timing, most were cleared based on retrospective observational studies. Some devices (39.4%) had results that were published in peer-reviewed literature. Safety risks reporting was uncommon (6.1%), usually focused on algorithmic or user errors, and did not adhere to international safety standards (ie, IEC, ISO, NEMA, or ANSI).

Our findings were consistent with previous evidence7,8 in an older cohort of approvals, suggesting a paucity of prospective evidence for AI/ML devices. Our study augments these findings by elucidating pre- and postmarket safety concerns, including finding that 5.2% of devices reported postmarket adverse events and 5.8% of cleared devices were recalled, with a meaningful percentage of recalls due to patient-specific harms. These rates are lower than the rates of adverse events and recalls of non-AI/ML devices submitted in the 510(k) pathway,18,19 such as surgical and implantable devices.20,21,22,23 However, this finding raises concerns about the adequacy of the 510(k) framework for evaluating substantial equivalence for medical devices, particularly AI/ML devices, as the absence of robust clinical validation may limit the ability to assess performance and patient impact in the community setting.18,19 Existing FDA postmarket surveillance databases documented 489 adverse events for 36 devices and 111 recalls of 39 devices; devices with adverse events were more likely to be recalled.

Radiology and cardiovascular medicine were the most common specialties for devices. Medical device applications are designated to 1 of 19 FDA specialty panels for review; each has varying levels of workload and resources.24 Moreover, reporting of safety results and risks to health, as well as adherence to international standards, did not improve after 2021. These findings suggest that premarket safety information for AI/ML devices may be insufficient and more robust postmarket surveillance systems are necessary to capture health-related adverse events and safety concerns relevant to AI/ML devices. In particular, known degradation in performance of AI/ML algorithms complicates traditional surveillance methods.25 Nonlocked AI/ML models can self-learn based on new data acquired during patient care, but AI/ML algorithm performance often drifts over time.26,27 Voluntary adverse event reporting databases, such as MAUDE, may not capture eventual diagnostic or prognostic errors associated with these AI/ML performance gaps. It may be critical to establish consensus on what constitutes an AI/ML-related adverse event to implement dedicated automated mechanisms for postmarket surveillance of AI/ML devices, potentially through linkages to EHR systems.

Moreover, we find that most risks to health reported in existing surveillance systems focus on algorithmic and user errors, neglecting the need for standardized characterization of patient-level safety risks associated with AI/ML devices. These could include standardized adverse events (eg, unnecessary biopsies, missed diagnoses of pathologic specimens) that could result from faulty AI/ML devices. Furthermore, the well-documented underreporting of safety events in MAUDE necessitates a shift toward more proactive safety monitoring.28 Leveraging end user health systems to report safety events and performance drift of FDA-cleared devices could provide a more comprehensive and timely understanding of how AI may affect patient outcomes. In 2021, the FDA called for improving transparency, monitoring safety and bias, and ensuring test-data quality of AI/ML devices.7 We found that even when bias and safety were evaluated, results were typically not disclosed to the public.

AI/ML devices cleared after 2021 were mostly reliant on retrospective observational studies.7 These findings add to prior evidence noting overwhelmingly nonprospective data underlying AI/ML device clearances. Our study adds to prior literature by characterizing temporal trends in evidence quality for AI/ML devices. There were some improvements over time in transparency: post-2021 devices were substantially more likely to report study timing (52.4% post-2021 vs 39.4% pre-2021), efficacy (35.8% vs 23.8%), and clinical outcomes (11.0% vs 1.1%). Based on its pathway, devices cleared before 2021 varied in their reporting of safety and bias assessments—this association was not observed in devices cleared during 2021 and after. However, devices cleared after 2021 were also less likely to be associated with peer-reviewed research. Overall, greater standardization of transparent outcome reporting is essential for premarket clearance of AI/ML devices.

Our findings also show a pressing need to center health equity in the development of AI/ML devices. Most devices did not report the study population’s demographic characteristics (95.5%) and bias assessment (91.3%) for the patients in whom their algorithms were tested. Among the few that did report demographic information, individuals of racial or ethnic minority groups were underrepresented. This imbalance was further exacerbated by the limited scope of bias assessments conducted, which primarily focus on sex and age. Critical factors such as race and ethnicity, body mass index, and skin tone were often not reported. Lacking these comprehensive evaluations can lead to AI/ML devices inadvertently embedding and amplifying existing biases in clinical care.29 Although reporting of bias calculations improved after 2020, in public reports and documents 80.7% of devices still lacked relevant demographic information about their training or testing cohort.

## Section: Discussion › Limitations

Our study has several limitations worth noting. First, while decision summaries aim to provide a comprehensive overview of scientific data, they may not always contain all necessary information submitted to the FDA for clinical use.13 However, most efficacy and safety data are expected to be included in these summaries and should promote public transparency. Second, additional safety assessments may occur after FDA clearance, meaning the full scope of information essential for clinical use may not always be available in premarket decision summaries. However, we extensively interrogated adverse event and recall databases to capture potential safety issues attributable to these devices. Third, devices may receive multiple FDA clearances over time, and our analysis was conducted at the level of individual clearances, which may not capture all prior or subsequent regulatory decisions. In addition, certain data, such as the number of peer-reviewed publications, can be challenging to link to specific devices due to differences between the submitted and published versions of a device name or type. To attempt to address this, we conducted at least 2 independent reviews of each publication to verify its relationship with each device.

Several key considerations warrant further attention. First, the Instructions for Use for each device did not yield relevant information for our analysis. Second, the low number of reported adverse events raises concerns about the adequacy of postmarket surveillance. Our statistical analyses underscore the need for more robust reporting mechanisms to ensure accurate postmarket safety assessments. Lastly, our study did not differentiate between locked and generative AI in the regulatory approval process due to an inadequate sample of generative AI devices (2 of 691 [0.3%]). Future research should explore whether the clearance pathways differ between these AI types and how regulatory oversight adapts to the unique risks and challenges posed by generative AI.

## Section: Conclusions

This cross-sectional study found that improved premarket data transparency and rigorous evaluation of AI/ML device efficacy and safety are needed. Using decision summaries for FDA-cleared AI/ML devices linked to adverse event and recall data, we found that currently, devices lack transparent efficacy or safety evaluations despite postmarket safety events being observed. To date, the FDA does not have a dedicated regulatory pathway for AI/ML devices.4 Given the unique considerations of these devices, implementation of a dedicated regulatory system for AI/ML devices, including more rigorous standards for study design and transparency, should be considered. Additionally, a more rigorous postmarket monitoring system may facilitate trust in integrating AI/ML devices into clinical settings.

## Section: Text

eTable 1. Classification System for Study Designs for AI/ML Devices

eTable 2. Differences in Characteristics Between Artificial 1 Intelligence/Machine Learning Devices Cleared by the US Food and Drug 2 Administration Over Time, 1995 to 2020 vs 2021 to 2023

eFigure 1. Trends in Study Design of FDA-Cleared AI/ML Devices, 1995-2023

eFigure 2. Trends in Timing of Data Collection of FDA-Cleared AI/ML Devices, 1995-2023

Characteristics of FDA-Cleared Artificial Intelligence/Machine Learning-Enabled Medical Devices, 1995-2023

Data Sharing Statement

## Section: Associated Data

eTable 1. Classification System for Study Designs for AI/ML Devices

eTable 2. Differences in Characteristics Between Artificial 1 Intelligence/Machine Learning Devices Cleared by the US Food and Drug 2 Administration Over Time, 1995 to 2020 vs 2021 to 2023

eFigure 1. Trends in Study Design of FDA-Cleared AI/ML Devices, 1995-2023

eFigure 2. Trends in Timing of Data Collection of FDA-Cleared AI/ML Devices, 1995-2023

Characteristics of FDA-Cleared Artificial Intelligence/Machine Learning-Enabled Medical Devices, 1995-2023

Data Sharing Statement

## Section: Associated Data › Supplementary Materials

eTable 1. Classification System for Study Designs for AI/ML Devices

eTable 2. Differences in Characteristics Between Artificial 1 Intelligence/Machine Learning Devices Cleared by the US Food and Drug 2 Administration Over Time, 1995 to 2020 vs 2021 to 2023

eFigure 1. Trends in Study Design of FDA-Cleared AI/ML Devices, 1995-2023

eFigure 2. Trends in Timing of Data Collection of FDA-Cleared AI/ML Devices, 1995-2023

Characteristics of FDA-Cleared Artificial Intelligence/Machine Learning-Enabled Medical Devices, 1995-2023

Data Sharing Statement


---

# Building Hybrid Pharmacometric-Machine Learning Models in Oncology Drug Development: Current State and Recommendations

- **Authors:** Anna Fochesato, Logan Brooks, Omid Bazgir, Philippe B Pierrillas, Candice Jamois, James Lu, Francois Mercier
- **Issuer:** CPT: pharmacometrics & systems pharmacology
- **Type:** Scientific article
- **Published:** 2025-10-17
- **Language:** en
- **DOI:** 10.1002/psp4.70113
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41104621/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

ABSTRACTClassic and hybrid pharmacometric‐machine learning models (hPMxML) are gaining momentum for applications in clinical drug development and precision medicine, especially within the oncology therapeutic area. However, standardized workflows are needed to ensure transparency, rigor, and effective communication for broader adoption. In this tutorial, we review pharmacometric (PMx) and machine learning (ML) reporting standards and evaluate them against hPMxML works in oncology contexts as a motivational example to identify current deficiencies and propose mitigation strategies for future efforts. The revealed gaps include insufficient benchmarking, absence of error propagation, feature stability assessments, and ablation studies, limited focus on external validation and final parametrization, and discrepancies between the performance metrics chosen and the original clinical questions. To address these, we propose a checklist for hPMxML model development and reporting, consisting of steps for estimand definition, data curation, covariate selection, hyperparameter tuning, convergence assessment, model explainability, diagnostics, uncertainty quantification, validation and verification with sensitivity analyses. This standardized approach is expected to enhance the reliability and reproducibility of hPMxML outputs, enabling their confident application in oncology clinical drug development, while fostering trust among all stakeholders.Keywords: clinical drug development, machine learning, pharmacometrics

## Section: Introduction

The integration of artificial intelligence (AI) and machine learning (ML) into the pharmaceutical industry is positioned to transform drug development, offering new tools to enhance insights and improve clinical decision‐making. Clinical pharmacology, for instance, might benefit from these methods to improve the adaptive design of Phase I trials [1], tailor product‐specific guidance [2], or automatize non‐compartmental analysis [3]. Health authorities (HAs) might see opportunities to establish a new regulatory framework [4] with AI/ML assisting regulatory decisions, as it occurred for the SAVE‐MORE trial in COVID‐19 patients [5] sponsored by the Center for Drug Evaluation and Research (CDER). Pharmacometrics (PMx), on the other hand, might profit from boosting its traditional inferential strengths with the predictive power of ML to enhance clinical outcome assessment [6, 7, 8, 9]. In this sense, on top of classic AI/ML applications, PMx is experiencing a wave of methodological hybridization with AI/ML techniques as emphasized in [7, 10, 11, 12, 13, 14, 15, 16] and in software domain activities, such as [15, 17, 18]. Although developed for different scopes or contexts of use (CoU), the majority of current hybrid PMx‐ML clinical applications can be broadly classified into three main categories, based on their goals of integrating PMx and AI/ML. The first category includes ML algorithms employed to scan extensive covariate pools against individual parameter estimates of PMx models (as targets). The process is intended to identify clinically meaningful and/or statistically influential covariates for subsequent inclusion in the PMx framework, effectively supplementing or accelerating traditional (bias‐prone) covariate search methods such as stepwise covariate modeling (SCM) [11, 19]. The second category deals with AI/ML architectures trained on PMx model‐derived metrics (AUC, Cmax, growth rates) and observed baseline or time‐varying covariates to support exposure‐response, regression (biomarker or pharmacokinetics‐pharmacodynamics (PK‐PD) metrics), survival analysis, or classification tasks [8, 12, 20, 21, 22]. The last category leverages AI/ML‐based models to infer unknown dynamical equations from data for PK‐PD and disease progression modeling, with the possible incorporation of inter‐subject variability and the usage of new (undiscovered) high‐dimensional modalities [7, 10, 23, 24, 25].

Building on these premises, cross‐industry discussion groups (such as the IQ Clinical Pharmacology Leadership Group's AI/ML Working Group) and regulatory agency committees have been established to foster the integration of AI/ML principles in clinical development. Although, the aim of these initiatives is to promote alignment on AI/ML‐based clinical products in high‐risk CoU, most of their work is primarily focused on review of use cases of AI/ML [26, 27, 28], sidelining methodological must‐haves or solutions to incorporate into the statistical analysis plan. The TRIPOD‐AI [29], CONSORT‐AI [30], and SPIRIT‐AI [31] reporting guidelines and the PROBAST‐AI form [32] are to date the most advanced documents discussing AI/ML model building from a technical viewpoint, with Food and Drug Administration (FDA)'s [33, 34] and European Medicines Agency (EMA)'s [35] primers bringing regulatory insights on top. FDA, in particular, has provided a list of general questions‐to‐be‐addressed—on (1) human‐led governance, accountability, and transparency; (2) data quality, reliability, and representativeness; (3) model development, performance, monitoring, and validation—to minimize pushbacks when AI/ML interventions are part of the submission package [33]. In this sense, adoption of a risk‐based credibility framework based on a “model influence‐versus‐decision consequences” matrix is strongly encouraged at each developmental step to meet these regulatory expectations [34]. Nonetheless, all these “good practice” efforts tend to be quite universal and unspecific to accommodate AI/ML models in a broad pharmaceutical context, from clinical research to manufacturing, and usage., from classical regression tasks to generative AI. Thereby, they may focus less on the specificities of model‐informed drug development (MIDD) field and related data preparation workstreams, or on ad hoc precautions necessary when AI/ML is combined with other modeling techniques, often used in PMx. In this sense, hPMxML model practitioners are currently working in isolation, approaching the hybrid modeling in a plethora of ways, due to the lack of unified reporting and developmental practices specific to these new methods, for example, error propagation handling and causality. Because of this setup, the full potential of this modeling partnership might be hindered or slowed down as transparency, reproducibility, and clinical adoptability are negatively impacted.

Building on this gap, the present article is intended to advocate a mindset shift in the current ML and PMx landscape in favor of workflow standardization and harmonization, as Figure 1 shows. In particular, our aims are fourfold. First, to equip pharmacometricians willing to incorporate ML techniques in some daily tasks, as well as ML experts willing to apply their know‐how to clinical pharmacology, with a roadmap for hPMxML model building and validation steps that ensure compliance with Good Clinical Practice (GCP) standards and regulatory expectations. Second, as collaboratively crafted by PMx and AI/ML experts, to align PMx and ML communities in terms of terminology and respective workflows, thereby easing cross‐functional work within different divisions of the pharmaceutical industry. Third, to avoid a “lost‐in‐translation” case from fragmented PMx‐ML exercises to clinical development routine [36], guaranteeing that questions for real‐world usage are addressed technically and clinically. Fourth, in line with cross‐setting expert opinions on the PMx‐modelers‐of‐the‐future [37], to provide educational material for training the next generation of ML‐aware pharmacometricians. While our work stems from an analysis of the current status of hPMxML in oncology as a motivational case, the proposal is intended to be guidance for scientists across various disease domains.

The vignette compares the current approach in integrating PMx and machine learning modeling with our envisioned one. While today's efforts are isolated with modelers producing their model report and analysis at the cost of generalizability, reproducibility, and communicability, the introduction of a checklist of good development and validation practices may help in harmonizing results, while endorsing this new hybrid modeling in high‐risk contexts.

## Section: Review Workflow for PMx and ML Guidelines

Well‐established technical guidelines and working protocols were reviewed to identify must‐haves and nice‐to‐haves reporting elements for the PMx and AI/ML communities, respectively.

For the AI/ML domain, insights on optimal development and reporting standards were derived from Collins et al. (TRIPOD‐AI) [29], Norgeot et al. (MI‐CLAIM) [38], Luo et al. [39], and Navarro et al. [40, 41]. For specifics on prognostic studies, Dhiman et al. [42] and Altman et al. [43] were considered, while the PROBAST‐AI document [32] was utilized to inspect the ML landscape in terms of biases and mitigation strategies.

Musuamba et al. [44], Lim et al. [45], Schmidt et al. [46], and Bergsma et al. [47] were reviewed to gain a pictorial overview of established PMx workflows, from model assumptions to model credibility assessment and validation. Reporting standards for traditional statistical models employed in prognostic studies were derived from Kempf et al. [48] and Janssens et al. (GRIPS) [49], while expectations on the selection of validation metrics came from Steyerberg et al. [50].

To facilitate meaningful cross‐domain comparisons between pharmacometric and machine learning approaches, the identified documents were organized according to a stepwise modeling framework (see keyword paragraph and Tables S1 and S2). This framework reflects the typical progression of model development, including: defining the question of interest or context of use, data selection and preparation, specification of features or covariates, model development and training, evaluation and validation, performance assessment, and analysis of uncertainty, sensitivity, and model limitations. These stages were aligned with concepts outlined in the FDA draft guidance on Artificial Intelligence to Support Regulatory Decision‐Making for Drug and Biological Products [34]. An occurrence analysis was performed to identify commonalities and distinctions across the two domains. Elements found exclusively in one domain and not addressed in the guidance were treated as domain‐specific in the comparison.

## Section: Review Workflow for hPMxML Model Candidates and Evaluation Criteria

Publicly available hPMxML models in oncology clinical development contexts were assessed for reporting completeness and quality against the unified PMx and ML standards previously identified. An initial set of candidate works was identified by the four sequential queries (i) “(Machine Learning OR Machine Learning‐based OR Interpretable Machine Learning OR Explainable Machine Learning OR Neural Differential Ordinary Equations OR NODE OR Neural‐ODE) AND (Pharmacometrics)”, (ii) “(Pharmacometrics) AND (Machine Learning) AND (Cancer OR Tumor OR Oncology)”, (iii) “(Neural ODE) AND (Cancer OR Tumor OR Oncology)”, and (iv) “(Survival Prediction) AND (Machine Learning) AND (Clinical Pharmacology) AND (Oncology) NOT (Genetics AND Radiomics AND Metabolomics AND Imaging)”. The queries were restricted to a period ranging between 01 January 2020 and 15 December 2024, with evident applications to the oncology disease area. Reviews, comments, editorials, tutorials, comparative/observational studies, case reports were discarded, as well as original articles not presenting a clear quantitative use case nor a clinical purpose nor cancer‐specific synthetic data. Candidates making use of bioinformatic processing of omics/genetic sequencing or imaging techniques were deemed not eligible. Examples of unsupervised AI/ML were considered beyond the intention of this work and therefore dropped. For a full description of the review implementation, refer to the PRISMA flow diagram in the Supporting Information (Figure S1).

Each high‐level element resulting from the comparison of PMx and AI/ML workstrams was dissected to identify objective metrics for assessing the selected models. Evaluation metrics included reporting of data description (with delineation of applied data manipulations), rationale for performance metric selection, presence of an uncertainty quantification intended as a confidence interval for results, statements on validation techniques and dataset representativeness, standards of model explainability and interpretability, presence of model verification via sensitivity or robustness analysis, benchmarking, and code sharing. Ad hoc metrics emerging from the integration of PMx with AI/ML, that is, report of causal findings and rationale for error propagation handling, were also added. Categories scoring less than 50% in a normalized frequency analysis of report completeness across identified published works were considered inadequately conformed.

## Section: Identified Similarities and Differences in PMx and ML Workstreams

Routinely adopted checklists for optimal development and validation of PMx and ML models emphasized substantial similarities in building precautions and reporting standards, alongside core specificities. Grounding on both techniques, we argue that hPMxML practitioners should be aware of these distinctions, either methodologically and terminology‐wise, before commencing any modeling endeavor and should be compliant to both while designing the analysis plan. In this sense, as Table 1 shows, PMx and AI/ML workflows agree on (i) having a CoU‐specific plan, (ii) declaring assumptions towards model credibility criteria, (iii) justifying the statistical adequacy of the framework and its verification via sensitivity analysis and robustness check, (iv) demonstrating the cases where the model fails (model boundaries), and (v) disclosing code and model parameters. While the alignment also extends to the quantification of any uncertainties, this aspect might be handled differently by each domain. With the bootstrap technique bilaterally adopted, PMx has found alternatives in Markov Chain Monte Carlo (MCMC) sampling, Sampling Importance Resampling (SIR) methods [51], asymptotic distribution properties, and/or clinical trial simulation plots generated from covariance‐based samplings, while AI/ML in variance/ensemble‐based methods [52] or conformal prediction [53] depending on the model architecture. Besides, although both PMx [54, 55] and AI/ML guidelines theoretically advocate for external validation to ensure model generalizability, in practice, this step is much more established in the AI/ML field. Indeed, even when PMx models are intended for predictive tasks, validation against other datasets might be postponed or applied to different CoU [56], with in‐distribution validation in the form of (prediction‐corrected) Visual Predictive Check (pc‐VPC) [57], Numerical Predictive Check (NPC) or Posterior Predictive Check (PPC) [58] implemented as a faster supplement. Moreover, while AI/ML routinely performs data splitting for internal validation purposes, PMx often uses the entire dataset (hence, no data splitting) for model development, particularly in early phases, to avoid any harmful loss of data that might impact covariate detection and estimate precision. Besides, AI/ML protocols put emphasis on benchmarking the product outputs against competitors and on unraveling a contextual model explainability, which are usually never sustained or taken for granted in PMx, respectively. Finally, while data augmentation via oversampling strategies is commonly applied in AI/ML to mitigate imbalances or enrich portions of interest in the data, PMx routine discourages any data modification of this type (apart from synthetic entries for data imputation) [54] to avoid biases on model parameter estimates.

Development and reporting pillars (rows) from PMx versus AI/ML (columns) best practices. A cross means that the descriptor is lacking, while a tick means that it is consistently present in all evaluated domain‐specific documents. A yellow cell highlights a descriptor common to both domains but with a slightly different meaning and action needed.

## Section: State of the Field for hPMxML Models in Oncology

To illustrate the current status of the hPMxML literature against discussed PMx and ML must‐haves and quality checks, an extensive review of oncology hybrid models was carried out. 29 works (see Table S3) were deemed suitable to be included in our exemplificative analysis. For 2 (7%) of them, the primary objective was methodological, with test cases on in silico or real oncology data, while for the remaining, it was clinical. 14 (48%) included clear components from both AI/ML and PMx/statistical modeling, with the large majority using PMx‐derived metrics as either inputs or targets for the AI/ML intervention and 2 implementing neural‐ODE techniques to complete an ordinary differential equation (ODE) system. 18 (62%) papers had the primary AI/ML component used for regression, half of which were for time‐to‐event settings, and 11 for binary or multi‐class classification.

A comprehensive list of metrics, derived from PMx and AI/ML workflows and expectations, was used to evaluate the reporting quality of the selected hPMxML within a drug development and regulatory framework. For each metric, we verified if reporting details were met or not. Figure 2 shows the results of our evaluation through barplots counting the frequency of comprehensively reported items across the analyzed models. Major deficiencies (below the average cut‐off of 50%) were found in error propagation handling, robustness assessment (such as feature stability or multi‐start consistency), metric completeness, benchmarking, and material sharing. While we found the clinical question clearly stated in the paper introduction for all cases, we recognized a general lack of compliance to the ICH E9(R1) addendum (estimand definition in the International Council for Harmonisation of Technical Requirements for Pharmaceuticals for Human Use) [59], especially for the declaration of the population‐level summary measure and intercurrent event handling strategy when applicable. We acknowledged a comprehensive data description in terms of the clinical context (trial or treatment details, population characteristics, predictor and clinical endpoint rationale), but a milder one in terms of possible data manipulation techniques applied (average ~75%). We found internal validation, whether in the form of a training/test split or of cross‐validation techniques (most employed) or of jackknife validation, fully covered, but less than 25% incidence of external validation. Comparison of AI/ML architectures was achieved in roughly 55% of works, with 7 manuscripts showing benchmark efforts against competitor models or SoC techniques (e.g., Stein pharmacodynamic model in oncology or SCM in covariate searching). The majority of classification and survival analysis works missed providing a strong rationale for the selection of the predictive performance metric (area under the Receiver Operating Characteristics curve (AUCROC) vs. Precision‐recall curve in imbalance set, discrimination (AUC/Cindex) vs. calibration metrics), while alignment between research questions and metrics was fully achieved in regression tasks. Comparison with literature expectation or upfront definition of successful criteria as per CoU were almost never discussed. Model explainability was well analyzed (> 75%), with the latest technologies, such as SHapley Additive exPlanations (SHAP) values [60], which allow for either local interpretability and causal insights via conditional effects on a feature on the selected outcome, still under‐used (< 18%). In terms of model inspections, we found that sensitivity analysis on thresholds or cutoffs was quite well performed (almost 75% occurrence), although rooms for possible user‐based biases in model development could still be present, while subgroup analysis was approached mostly via subgroup‐specific architectures only or ML‐derived stratification. No analysis was conducted on understanding which cohorts were better predicted by a unique model. Error propagation was never discussed, leading to underestimation of the uncertainty and inability to decouple the source of variability. Finally, no works attempted a robustness assessment via a multi‐start approach nor feature stability checks.

The barplot shows the percentage of hPMxML models presenting reporting standards per topic as expected from the reviewed PMx and AI/ML guidelines. Percentages are normalized on the paper subset for which they might be applicable.

## Section: Checklist Proposal for hPMxML Model Building

Despite the advantages and interest in hPMxML methodologies in clinical development contexts, the need for harmonization is still unmet. To address this demand and to guarantee the trustworthiness and credibility of these methods, we present a comprehensive checklist for hPMxML model building (Table 2), primarily intended to accommodate randomized clinical trial (RCT) datasets as the backbone of data‐driven drug development. The proposed checklist is structured in seven blocks—clinical setup, data preprocessing, model training, model validation, secondary analysis, applicability domain, and benchmark studies—each including distinct and detailed subpoints. Descriptors were sign‐coded (Δ = mandatory, Ο = optional) based on their regulatory weight—as derived from [34]—to alert users on which tasks to prioritize. This is expected to be particularly beneficial in cases where development time is tight or when users first approach this new hybrid modeling modality and might feel overwhelmed by the number of listed items.

The table summarizes the 7‐pillar checklist we designed to facilitate a harmonized development and validation of hPMxML models. Mandatory items are marked with Δ, optional ones with Ο. The last three columns labeled as Cat correspond to the three categories of hPMxML models presented in the introduction, namely Cat. I = covariate screening ML methods having PMx‐derived Empirical Bayes Estimates (EBEs) as targets, Cat. II = predictive or classification models with clinical and PMx‐based regressors, and Cat. III = neural‐ODE systems to compensate for missing mechanistic terms.

## Section: Main Considerations

An upfront deep knowledge of the CoU is a must‐have condition to develop ML‐based models as it drives most of the preliminary assumptions, technical choices, and benefit–risk evaluations along the full model development process. In this sense, we encourage the frame of the clinical question—target population, endpoint of interest, treatment conditions, summary measures, and intercurrent event [59]—and the definition of “model success” criteria to be jointly agreed a priori by clinical stakeholders and modelers, based on risk appetite and competitor performances. In addition, once the intended model usage is clearly defined, we suggest a critical and statistical analysis of the final filtered database to validate model utility toward goal achievement. In this sense, we refer to [71, 72] for simulation studies on minimum sample size in clinical AI/ML settings and to [73] for R‐based computational support in the calculation. In addition, to gain a preliminary understanding of the overfitting likelihood for the planned setup, we refer to [74] for an overview on covariate pool versus sample size in specific classification contexts. In terms of communicability and usability awareness, a clear discussion on the selected sample size and secondary analysis on performance degradation when the number of training examples is reduced is nonetheless beneficial to provide indications on which drug development stages the model could serve.

To ensure reproducibility, we recommend that data engineering processes be documented as a sequential list of applied transformations. In instances where data manipulation is not conducted prior to AI/ML training, an explicit statement should be included to inform practitioners and prevent any misconceptions. In this regard, while data imputation is typically performed before model development, its implementation may vary by model type. For example, NONMEM scripts and tree‐based methods handle missing data automatically, whereas Lasso does not. A more transparent and unbiased—though time‐consuming—approach would be to conduct imputation separately for the development and (cross‐)validation sets/folds, integrating it as part of model training.

In this regard, differently from PMx routine, a random or stratified splitting of the entire dataset into development and internal validation sets is mandatory to prove the generalizable capability of the ML‐based component. While this is the bare minimum, we strongly suggest embarking on hPMxML efforts only in the presence of external validation sets that are clinically and statistically evaluated as representative of the intended target population or for which covariate shift can be rationalized. In this regard, an upfront comprehensive side‐by‐side comparison of longitudinal observations or covariate values between developmental and externally collected datasets is mandatory to detect and, in case, quantify this data shift phenomenon. In this latter case, an early interaction with clinical statisticians is strongly suggested for alignments on the setup validity, as well as for strategies to account for it. This is especially relevant in cases where practitioners may want to use real‐world data (RWD) sources—electronic health records (EHRs), claims data, patient‐reported outcomes, digital health devices—which notoriously have higher dimensionality, more missingness, heterogeneity, and subgroup under‐representativeness compared to RCT [75]. In this case, a stringent selection criteria of the baselines and an understanding of the operational differences between clinical practice and trial protocols is fundamental to accomplish translatability and validity assessments [76]. If these look promising, modelers are called to include and detail confounding mitigation strategies, such as censoring‐informed propensity score matching (with information on selected distance metric, pairing method, and ratio), in addition to the data processing and model validation items of Table 2.

As part of model robustness analysis, we encourage checking the stability of the ML‐selected features (both presence and ranking) across cross‐validation folds and a multi‐start approach with different seeds towards the verification of influential outliers and of model robustness, respectively. For an overview of the different measures available to assess this consistency, we refer the reader to [77, 78]. In this regard, we warn practitioners to carefully evaluate clinical interpretability, collection costs, and patient burden of each feature before selecting correlation‐aware measures, that is, measures that judge as interchangeable highly‐correlated features, over unaware ones. In addition, ablation studies via leave‐one‐out covariate or model part should be conducted to further disentangle the true impact of the component of interest, phasing out the likelihood of mediation or compensation effects.

In terms of hPMxML‐specific diagnostics, we believe error propagation quantification, emerging from the parallel or sequential combination of PMx and AI/ML optimization procedures, plays a crucial role in model assessment. Notably, this quantification might be dependent on the integrative engine put in place, that is, the hPMxML category the model belongs to. For instance, for the first category (ML methods testing covariates against target EBEs), a percentage dropout of key covariates could be applied in the final PMx framework to quantify the uncertainty of the ML‐based covariate selection. For the second group (regression/classification ML methods including PMx‐derived covariates), samples from the conditional distribution could be used to create plausible PMx‐derived metrics at the individual level, and error propagation could be computed via bootstrapped training sets incorporating these covariates without replacement. For models in the third category (neural‐ODE models automatically retrieving missing terms), readers can refer to [79].

In terms of hPMxML model validation, we state (i) selection of CoU‐relevant performance metrics as a trade‐off between model assessment and stakeholder familiarity and (ii) explainability of ML components as regulatory cornerstones. For the first, fairness auditing approaches for ethical considerations should be factored in at this stage and guide the identification of an ad hoc measure, particularly if preventive strategies have not been applied during data analysis (data augmentation) or model development, or if test sets exhibit imbalances in clinically‐relevant covariates, such as age, sex, race, and comedications. The literature here provides effective metrics for bias evaluation to ensure accurate predictive performances for underrepresented groups. For the second, significant theoretical work has been done in recent years to unbox AI/ML models and render them more understandable and transparent. The compendium of these efforts is represented by feature importance plots [80], identifying which input variables are most influential in building the input–output relationship; partial dependence plots [81], visualizing how outputs change as a consequence of a controlled input variation; SHAP (SHapley Additive exPlanations) plots [82], assigning importance weight to each input for individual output; LIME (Local Interpretable Model‐agnostic Explanations) [83], explaining individual outputs through a local approximation of the model. Interestingly, additional methods are available on top of SHAP to convert the feature ranking into clinically‐sounding hazard ratios in survival settings [84] or to plug in direct acyclic graphs among features [85], thereby reading feature importance weights from a causal perspective with no confounding effects or mediations.

While the clinical question should clearly translate into a primary research endpoint, we emphasize the International Council for Harmonization ICH E9 recommendation on the use of secondary analysis for additional model verification. Among the others, we strongly suggest performing subgroup analysis on pre‐defined and CoU‐meaningful cohorts to unravel patient or disease subtype behavior and identify those on which the ML‐based model is most performative. In addition, we advise conducting local sensitivity analysis on any pre‐set thresholds or cut‐offs within clinically reasonable variation space in order to make hPMxML free from developer biases and to prove model robustness.

Finally, to shift towards a unified approach, we advocate for publishing model codes, whether on shared online platforms (as done via the Drug Disease Model Resources (DDMoRE) repository [86]) or as supporting material within a manuscript, to facilitate re‐use, re‐run, and (occasionally) debug by other practitioners. Given the stringent confidentiality measures on proprietary data in pharma, we acknowledge the difficulty of data sharing on top of modeling scripts in several cases. However, if feasible, we encourage sharing at least a synthetic data template mimicking the format of the real dataset—particularly in terms of headers and column names/types—to guide the work of Clinical Data Programmers.

## Section: Conclusions

The pharmaceutical sector welcomes opportunities to evaluate novel technological and modeling advancements in the clinical routine, provided that these add‐ons are well‐shaped, endorsed, and extensively validated. Foreseeing opportunities for hPMxML models, we brainstorm around a long‐lasting adoptability of these models in clinical drug development. While we recognize some successful ML and hPMxML efforts in the exemplified clinical oncology literature, we note a lack of standardization in the developmental and reporting procedures and some deficiencies in light of GCP and health authority requirements. Although it is also true that many reviewed papers were primarily exploratory rather than designed for guiding drug development decisions, we believe they served as crucial starting points to critically evaluate what is necessary for real‐world usage of these technologies across indications. Therefore, to cope with identified gaps in current works, we present our proposal of a comprehensive checklist for optimal and regulatory‐compliant hPMxML model building and validation for clinical drug development overall, beyond the oncology disease therapeutic area per se. Indeed, while oncology has been primarily touched on here—as it catalyzed most of hPMxML efforts so far—similar methodological deficiencies were detected in other diseases, as shown in the Supporting Information (Figure S2). Besides, all non‐oncological hPMxML applications we revised (see Table S4) employed classical regression or classification tasks, leveraging a diverse range of established theory and libraries. Some of these approaches, however, are still maturing in the context of time‐to‐event scenarios typical of cancer modeling, thereby making oncology a more challenging use case for us to brainstorm around methodological best practices.

While resulting from an extensive and objective review of works and related pitfalls, we acknowledge that the checklist is produced by a unique pharma, thereby being possibly prone to some biases, and we therefore call the community to action for improvements. Nevertheless, we believe that this first version of the checklist is already in good shape to ensure methodological rigor, reproducibility, and trust among clinical stakeholders, as well as a higher probability of technical success and approval for hPMxML models across all therapeutic areas. We hope that this checklist can strengthen cross collaboration between pharmacometricians, clinical pharmacologists, AI/ML experts, and regulatory agencies to drive innovation in clinical drug development overall. However, it is important for us to caution the Clinical Pharmacology and PMx community against being swayed by AI/ML per se. Clinical modelers should adhere to and build models upon the principle of parsimony, as exemplified by Occam's Razor. Conventional statistical and PMx methods should always be the starting point and the reference, and only when they fail to produce satisfactory results, and under very precise conditions, that is, enough high‐quality data, practitioners may want to explore ML‐based alternatives.

## Section: Author Contributions

A.F., L.B., O.B., P.B.P., C.J., J.L., and F.M. wrote the manuscript. A.F., L.B., O.B., P.B.P., C.J., J.L., and F.M. designed the research. A.F., L.B., O.B., P.B.P., C.J., J.L., and F.M. performed the research.

## Section: Conflicts of Interest

A.F., P.B.P., C.J., and F.M. are current employees of F. Hoffmann‐La Roche Ltd. L.B. and O.B. are current employees of Genentech Inc. J.L. is a current employee of A*STAR Bioinformatics Institute. J.L. was an employee of Genentech Inc. at the time of this work. L.B., O.B., P.B.P., C.J., J.L., and F.M. own stock in Roche.

## Section: Supporting information

Data S1: psp470113‐sup‐0001‐DataS1.docx.

## Section: Acknowledgments

The authors wish to acknowledge Hanna Silber Baumann, Jitao David Zhang, and Francesco Brizzi for their insightful comments during the preparation of the manuscript.

## Section: Text

Fochesato A., Brooks L., Bazgir O., et al., “Building Hybrid Pharmacometric‐Machine Learning Models in Oncology Drug Development: Current State and Recommendations,” CPT: Pharmacometrics & Systems Pharmacology 15, no. 1 (2026): e70113, 10.1002/psp4.70113.

## Section: Associated Data

Data S1: psp470113‐sup‐0001‐DataS1.docx.

## Section: Associated Data › Supplementary Materials

Data S1: psp470113‐sup‐0001‐DataS1.docx.


---

# Challenges and Solutions in Applying Large Language Models to Guideline-Based Management Planning and Automated Medical Coding in Health Care: Algorithm Development and Validation

- **Authors:** Peter Sarvari, Zaid Al-Fagih, Alexander Abou-Chedid, Paul Jewell, Rosie Taylor, Arouba Imtiaz
- **Issuer:** JMIR biomedical engineering
- **Type:** Scientific article
- **Published:** 2025-11-10
- **Language:** en
- **DOI:** 10.2196/66691
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41213118/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundDiagnostic errors and administrative burdens, including medical coding, remain major challenges in health care. Large language models (LLMs) have the potential to alleviate these problems, but their adoption has been limited by concerns regarding reliability, transparency, and clinical safety.ObjectiveThis study introduces and evaluates 2 LLM-based frameworks, implemented within the Rhazes Clinician platform, designed to address these challenges: generation-assisted retrieval-augmented generation (GARAG) for automated evidence-based treatment planning and generation-assisted vector search (GAVS) for automated medical coding.MethodsGARAG was evaluated on 21 clinical test cases created by medically qualified authors. Each case was executed 3 times independently, and outputs were assessed using 4 criteria: correctness of references, absence of duplication, adherence to formatting, and clinical appropriateness of the generated management plan. GAVS was evaluated on 958 randomly selected admissions from the Medical Information Mart for Intensive Care (MIMIC)–IV database, in which billed International Classification of Diseases, Tenth Revision (ICD-10) codes served as the ground truth. Two approaches were compared: a direct GPT-4.1 baseline prompted to predict ICD-10 codes without constraints and GAVS, in which GPT-4.1 generated diagnostic entities that were each mapped onto the top 10 matching ICD-10 codes through vector search.ResultsAcross the 63 outputs, 62 (98.4%) satisfied all evaluation criteria, with the only exception being a minor ordering inconsistency in one repetition of case 14. For GAVS, the 958 admissions contained 8576 assigned ICD-10 subcategory codes (1610 unique). The vanilla LLM produced 131,329 candidate codes, whereas GAVS produced 136,920. At the subcategory level, the vanilla LLM achieved 17.95% average recall (15.86% weighted), while GAVS achieved 20.63% (18.62% weighted), a statistically significant improvement (P<.001). At the category level, performance converged (32.60% vs 32.58% average weighted recall; P=.99).ConclusionsGARAG demonstrated a workflow that grounds management plans in diagnosis-specific, peer-reviewed guideline evidence, preserving fine-grained clinical detail during retrieval. GAVS significantly improved fine-grained diagnostic coding recall compared with a direct LLM baseline. Together, these frameworks illustrate how LLM-based methods can enhance clinical decision support and medical coding. Both were subsequently integrated into Rhazes Clinician, a clinician-facing web application that orchestrates LLM agents to call specialized tools, providing a single interface for physician use. Further independent validation and large-scale studies are required to confirm generalizability and assess their impact on patient outcomes.

## Section: Introduction › Health Care’s Diverse Challenges

Health care is facing profound challenges that urgently require innovative solutions. Medical errors [1], overwhelming administrative burdens [2], understaffing [34], spiraling costs [5], and clinician burnout [67] threaten the foundations of medical care. Despite this, the health care sector has lagged behind other industries in adopting new technologies.

To address the above challenges, a subset of the authors has developed an AI-powered web app called Rhazes that helps doctors with paperwork and analytical tasks along their clinical workflow. Rhazes, like many other digital health startups, aims to offer integrated tools to health care professionals to match many of the growing needs in health care worsened by a staffing crisis [8-10]. AI-powered tools have been shown to have the potential to automate rote tasks [11], reduce errors [1213], cut costs for everyone [14], improve clinician well-being and their patient-centeredness [15], and ultimately deliver better patient outcomes [1216]. However, significant barriers and challenges persist in ensuring the safe and effective integration of AI within health care systems globally [17-19].

## Section: Introduction › Diagnostic Errors

Diagnostic errors in health care are more common than generally recognized and often receive less attention in both clinical practice and research. There are 2 ways to estimate their prevalence: autopsies and expert opinions. Various studies suggest a range between 5% and 20% [20-22], with the actual figure likely falling somewhere in between. Considering the 1.3 billion health care visits annually in the United States as an example, this percentage translates to a staggering 65 to 260 million diagnostic errors each year in the United States alone [23]. The rate of false negatives varies widely, from as low as 2.2% for myocardial infarction to an alarming 62.1% for spinal abscesses [20]. The National Academy of Medicine underscores the severity of this issue, attributing diagnostic errors to approximately 10% of patient deaths and 6% to 17% of hospital complications, with vascular events, infections, and cancers constituting around 75% of the serious harms from these errors [24].

Diagnostic errors arise from several causes. No-fault errors, such as those due to atypical disease presentations, are difficult to prevent. System-related issues, including delays in testing and communication failures, also play a role, though comprehensive data are limited. Cognitive errors, however, are the most frequent, with Graber et al finding that cognitive factors—such as faulty perception, failed heuristics, and cognitive biases—contribute to 74% of diagnostic errors [25]. This suggests that a substantial proportion of these errors could be mitigated through targeted interventions aimed at clinical decision-making and judgment. In malpractice claims, nearly 90% involve failures in these domains, regardless of the underlying condition [26].

## Section: Introduction › All Roads Lead to Burnout

Clinicians are responsible not only for making diagnoses but also for managing patient care thereafter. This process involves 3 major challenges. The first is staying up to date with a rapidly expanding medical knowledge base, which is estimated to double every 73 days [27] alongside frequently updated clinical guidelines. To address this, many physicians rely on peer-reviewed online clinical guideline databases, such as subscription-based services including UpToDate [28], DynaMed [29], as well as freely available resources like StatPearls [30]. The second challenge is identifying the most relevant guideline for a specific clinical scenario. The third, and often most complex, is tailoring these guidelines to the unique needs of each patient, taking into account individual characteristics, medical history, preferences, and socioeconomic context.

Medical errors often occur within the broader context of systemic pressures. One major factor is the administrative workload placed on clinicians. Studies indicate that for every hour spent in direct patient care, physicians spend approximately 2 additional hours on documentation and other administrative tasks [31]. This environment can contribute to situations where clinical duties become secondary to administrative responsibilities.

In the United States, more than half of physicians report at least 1 symptom of burnout [32], representing an estimated annual economic cost of US $4.6 billion or US $7600 per physician [33]. In the United Kingdom, physician burnout rates reached a record high in 2021 according to the annual national training survey [34].

## Section: Introduction › Medical Coding

Medical coding has clinical, statistical, and billing-related usages. Systematized Nomenclature of Medicine–Clinical Terms (SNOMED-CT; maintained by the International Health Terminology Standards Development Organization) is a terminology that provides clinicians with precise patient-specific information, including symptoms, diagnoses, procedures, and social contexts [35]. In the National Health Service (NHS), UK, SNOMED-CT is used for clinical coding, specifically to safely and accurately exchange information between health care providers. It is recorded at the point-of-care level and integrated into electronic health records (EHRs) as required by Fast Health Care Interoperability Resources [35], a health care data sharing standard. Most general practitioner clinics employ medical coders to translate patient findings into a mix of SNOMED-CT and in-house diagnostic codes for the most common cases. SNOMED-CT allows for more precise coding, as it not only comprises over 340,000 clinical [36] and 1.4 million drug-related codes but also describes the relationship between these codes, essentially functioning as an ontology [35]. In the United Kingdom, diagnostic codes using the International Classification of Diseases, Eleventh Revision (ICD-11) standard (published by the World Health Organization) and procedural codes using the Operating Procedure Codes Supplement (OPCS; published by NHS England) standard are recorded after the clinical event for statistical purposes, whereas in the United States, ICD-11 is used for mainly billing purposes [37]. For coding procedures in the United States, the Health Care Common Procedure Coding System (HCPCS; published by the Centers for Medicare and Medicaid Services) is used. It has 2 levels: level 1 comprises Current Procedural Terminology (CPT) codes (published by the American Medical Association), which is used to bill for procedures done by health care professionals, and level 2 can be used to bill for products, supplies, and services used outside the physician’s office such as ambulatory services or orthotics [38]. Automated medical coding is needed for 2 main reasons: one is accuracy and the other is efficiency: the average coding accuracy is around 80% [37], with 83% in the United Kingdom and 89% in Scotland [39], and just the coding of backlog cases can take anywhere from several months to over a year [40].

## Section: Introduction › Large Language Models Could Help

Given the recent progress in artificial intelligence (AI), it has been proposed to help with various aspects of clinical work, including scribing and diagnosis [134142]. GPT-4, a large language model (LLM) developed by OpenAI, has shown promise in medical applications with its passing of the medical board exam in multiple countries and languages [43-45]. A peer-reviewed study assessing the diagnostic ability of GPT-4 and Pathways Language Model 2 on 1000 electronic patient records reported that GPT-4 achieved a 93.9% diagnostic hit rate (lower bound), validated by 3 medical doctors [46]. Furthermore, the authors found that a quick and accurate automated diagnostic evaluation may be possible by presenting the ground truth data to GPT-4 and asking it to assess the diagnostic predictions made by LLMs [4647]. This can then be used to rapidly benchmark different models and prompting strategies. A report published by OpenAI and Penda Health [48] claimed that AI Consult, a tool powered by LLMs, reduced diagnostic errors by 16% and treatment errors by 13% for 39,849 patient visits in Kenya.

When it comes to management planning, LLMs can revolutionize medical search and find recommendations for a specific clinical scenario by automatically citing the relevant guidelines. Examples include recently developed online medical search tools such as Elsevier Clinical Key [49] and MedWise [50]. The next level of automation is AI analyzing and extracting the relevant details from the EHR to adapt the clinical guidelines to the unique needs of the patient, essentially crafting a personalized treatment plan. An application capable of doing this is called a clinical decision support (CDS) [51] system, and industry examples of such tools include Glass Health [52] and Rhazes [53].

Another important application of LLMs in clinics is notetaking. Automated documentation leveraging ambient listening has shown promise in reducing clinician burden and improving the experience of doctor–patient interactions for both parties [5455]. In addition, clinical evaluation of existing scribing tools such as Tortus [56], DeepScribe [57], Nuance Dragon Ambient Experience (DAX) [5859], and Rhazes [60] has indicated enhanced documentation quality [56], increase in billed diagnostic codes, and potential time and cost savings [575860]. However, such tools can cost US $1850 per month per clinician [58] and cause a worsening of after-hours electronic health records (EHR) usage [59]. In fact, Haberle et al found that Dragon Ambient Experience did not benefit documentation, productivity, or even patient experience but helped with provider engagement [59]. Ma et al argue that ambient AI scribes can even reduce time spent on the EHR, but further studies are needed to identify the users benefiting most from such technology [61].

Even though computer-assisted medical coding has been shown to improve coding accuracy [62], automating the clinical coding system appeared out of reach prior to the generative AI revolution due to technological and implementation-level challenges [63]. Non-LLM–based encoder–decoder-type models were shown to really struggle with identifying less frequent codes [64]; however, retrieval-augmented generation (RAG)–enhanced LLMs were recently found to be preferable to provider coders in terms of coding accuracy [65]. Generative AI seems to have made a big contribution toward the full automation of medical coding, and while we found no peer-reviewed evaluation paper to date, the authors of the previously cited paper, affiliated with Corti AI [66], who were researching non-LLM-based methods [64], are now leveraging generative AI to automate medical coding [66].

## Section: Methods › Ethical Considerations

The Medical Information Mart for Intensive Care (MIMIC)–IV [67] is a publicly available database and was previously ethically approved by the institutional review boards at Beth Israel Deaconess Medical Center (2001P001699) and the Massachusetts Institute of Technology (0403000206) in accordance with the tenets of the Declaration of Helsinki. The waiver of the requirement for informed consent was included in the institutional review board approval, as all protected health information was deidentified [67]. One of the authors (PS) was granted access to the database after completing training in human research (CITI Human Research certification number: 54889098) and signing a data use agreement in PhysioNet (agreement number 64081). The experiments described in this paper were conducted on Microsoft Azure (Azure OpenAI service) according to the “Responsible use of MIMIC data with online services like GPT” guidance by PhysioNet [68]. The code associated with this publication has been shared in an open repository, and information is provided in the “Data Availability” section of this manuscript.

## Section: Methods › Generation-Assisted Retrieval-Augmented Generation for Clinical Decision Support

Here we demonstrate how to build a prototype for an AI-driven CDS, in particular, for crafting patient-specific management plans with verifiable citations from StatPearls [30], a point-of-care medical database with peer-reviewed clinical guidelines. On March 2, 2025, a comprehensive archive of clinical guidelines from StatPearls (approximately 1.5 gigabytes in size) was downloaded for use as the reference corpus in the RAG process. After unpacking the archive, a total of 9559 nxml files were obtained, each corresponding to the management of a distinct medical condition. These files were subsequently cleaned to remove nonclinical and extraneous information, including licenses, credits, warranties, publishing details, user prompts (eg, “Comment on this article”), and reference sections, so that only clinically relevant content remained. The title of each file was automatically inferred from the text and used as a filename, thereby linking each document to the medical event it described. The cleaned files were then converted into plain text format and uploaded to Azure Blob Storage. For citation purposes, a mapping was preserved between each inferred filename and the original download URL from StatPearls.

To enable semantic search and retrieval, the corpus was indexed within Azure Search Service. The indexing pipeline comprised a data source connection to Azure Blob Storage, a search index with fields for filename, chunk identifier, chunk text, and embedding vector; a text-splitting skill with a maximum chunk size of 4000 tokens and an overlap of 100 tokens; and an embedding skill using text-embedding-3-large model, OpenAI’s latest and best embedding model to date [69]. An indexer was then executed to vectorize and index the entire collection of document chunks.

Building upon this foundation, we developed a proof-of-concept workflow, which we termed generation-assisted retrieval-augmented generation (GARAG). GARAG proceeds in 3 stages. First, given EHR data, an LLM (specifically GPT-4.1) is prompted to generate a structured list of differential diagnoses. Second, for each diagnosis, the system queries the indexed StatPearls corpus through Azure Search Service, employing the Hierarchical Navigable Small World approximate nearest neighbor algorithm (with parameters M=4, efConstruction=400, and efSearch=500) and cosine similarity as the distance metric. The 4 most relevant text chunks are retrieved for each candidate diagnosis. Third, the LLM is prompted again with the patient data and the retrieved evidence sources. From this input, the model generates a structured management plan covering investigations, treatment suggestions, supportive management, other considerations, risks, and references. Citations are automatically hyperlinked to the original StatPearls sources via the preserved filename-to-URL mapping (Figure 1). A key advantage of GARAG is its ability to ground recommendations in guideline-specific, peer-reviewed sources tailored to each predicted diagnosis. This targeted retrieval avoids the information dilution that can occur with standard RAG approaches, where embedding the entire case may obscure fine-grained clinical details. By structuring the workflow around diagnosis-specific guideline retrieval, GARAG ensures that management plans are directly aligned with authoritative clinical references.

For clarity, we have provided a Python Jupyter Notebook that demonstrates our implementation of such a GARAG system and the automated tests we have run to confirm that the instructions are being followed by the LLM. To contrast the GARAG workflow to a traditional RAG workflow, we also provide the reader with a Python prototype that generates treatment plans with StatPearls references using RAG.

## Section: Methods › Generation-Assisted Vector Search for Automated Medical Coding

Next, we demonstrate how to build an AI tool for automated medical coding using a method we named generation-assisted vector search (GAVS). Unlike RAG, in which retrieval precedes generation, GAVS inverts the process: generation is performed first and retrieval follows. In this pipeline, an Azure OpenAI LLM is few-shot prompted to read EHR text and to enumerate, with maximal granularity, the clinically relevant entities for coding (eg, diagnoses/comorbidities/abnormalities, procedures/treatments/services, and drugs). Each generated item is subsequently embedded with text-embedding-3-large and matched against a vector database representing the target coding ontology.

For procedural coding, the coding ontology was derived from the official 2025 CPT release downloaded as an Excel workbook from the Centers for Disease Control and Prevention government website. The worksheet containing all CPT entries (“ALL 2025 CPT Codes”) was parsed to retain the canonical code identifier and its short description; rows with missing codes were removed. Each row was converted into a LangChain [70] Document whose embedding encodes the description, while the metadata preserves both the CPT Code and Title. Because CPT descriptions are short, no chunking was required.

Embeddings were stored in a Pinecone serverless index [71] and queried via the LangChain [70] PineconeVectorStore at runtime. During inference, each model-generated item (eg,procedure) in a structured list output is embedded on the fly and used to perform semantic search, retrieving the top 10 nearest CPT entries by cosine similarity. The returned results include both semantic scores and the canonical CPT codes via the stored metadata, allowing the system to report human-readable candidates (code+title) alongside each extracted clinical item.

The same pattern generalizes to diagnostic and pharmacological coding by substituting the target ontology (eg, ICD-11 or SNOMED CT for diagnoses; SNOMED CT for drugs) and constructing an analogous vector store with description-level embeddings and code identifiers preserved in metadata. For transparency and reproducibility, we provide a Jupyter Notebook demonstrating the full CPT workflow end-to-end, including data acquisition, runtime index creation, LLM-based generation, and similarity search-based mapping. Crucially, the index is created and populated programmatically at runtime if absent (index name cpt-cdc-2025-text-embedding-3-large, dimension 3072, metric cosine, region eu-west-1); if present, the pipeline connects to the existing index without reingestion. We also provide links to download coding ontologies from the official publisher websites in the format of single or multiple Excel files: CPT from the Centers for Medicare and Medicaid Services [72], ICD-11 from the World Health Organization [73], and SNOMED from the NHS Digital website [74].

To quantitatively assess the benefits of GAVS over direct LLM prompting, we conducted a proof-of-concept evaluation for International Classification of Diseases, Tenth Revision (ICD-10) coding following the methods of Sarvari and Al-Fagih [47]. We initially sampled 1000 admissions at random from MIMIC-IV, of which 42 did not have officially assigned ICD-10 codes and were excluded, resulting in a final cohort of 958 admissions. For each admission, the set of billed ICD-10 codes served as the ground truth. Across this cohort, there were 8576 total ICD-10 codes at the subcategory (full code) level, comprising 1610 unique subcategories. When mapped to parent categories, the total number decreased to 7311 codes across 540 unique categories. The discrepancy (8576 vs 7311) reflects cases in which the Python library used for mapping [75] did not recognize certain overly specific subcategory codes, in which case no parent category was assigned. The full ICD-10 ontology includes 95,109 valid codes, defining the candidate space for prediction. Two approaches were compared. In the vanilla LLM method, GPT-4.1 was prompted directly to predict ICD-10 codes for each admission, without external constraints. In the GAVS method, GPT-4.1 was first prompted to generate granular diagnostic entities, which were then embedded and matched to the top 10 most similar ICD-10 codes through vector search (Azure Search Service) of the official ontology. Both methods used identical LLM configuration and dataset preprocessing, ensuring comparability across experiments. The primary outcome was recall, defined as the fraction of ground-truth codes correctly predicted. Two variants were calculated, consistent with [46] (1) average (per-admission mean) recall, averaged across the 958 admissions, and (2) aggregate (weighted average) recall, defined as the total number of correctly predicted codes divided by the total number of codes (8576) or 1−(∑missed codes across admissions / ∑true codes across admissions).

Precision was not reported, as discussed previously [47], because billing records are not a reliable gold standard for false positive determination: clinically valid diagnoses often go unbilled, and multiple codes may be acceptable matches (especially when working with incomplete data). In this context, precision metrics would therefore be misleading. For statistical comparison, following [47], we applied a 2-proportion z test to evaluate differences between methods in recovered versus missed ground-truth codes.

For clarity, we provide the reader with a Python Jupyter notebook, demonstrating the entire automated coding prediction (including the vanilla GPT-4.1 and GAVS methods for predicting ICD-10 codes) and evaluation workflow both at the subcategory and category levels.

## Section: Results › GARAG: Citation Integrity and Relevance

Using the LLM-as-a-judge method [4776], we evaluated the GARAG workflow on 21 clinical test cases created by a subset of the authors who are medical professionals. Each case was executed 3 times independently to assess reproducibility, yielding a total of 63 runs. Performance was assessed using four criteria: (1) correctness of references, (2) absence of duplicate citations, (3) adherence to citation formatting standards, and (4) contextual appropriateness of the generated management plan, including whether it explicitly addressed the presented diagnoses. Across all 63 runs, 62 satisfied all 4 criteria, corresponding to a success rate of 98.4%. The single exception occurred in case 14 during its first repetition, in which references were accurate but displayed a minor ordering inconsistency, with “[3]” appearing before “[2].” Importantly, no spurious references were observed, all citations could be traced directly to their StatPearls sources, and all management plans were judged clinically relevant. These findings demonstrate that GARAG provides a highly reliable and reproducible workflow for generating clinical management plans with proper citation handling, with only minor formatting issues detected across repeated executions.

## Section: Results › GAVS: Diagnostic Coding Performance

We next evaluated the GAVS method for automated diagnostic coding on 958 randomly selected MIMIC-IV hospital admissions. Across these cases, there were 8576 total assigned ICD-10 codes at the subcategory level, spanning 1610 unique subcategories. When collapsed to categories using a Python mapping library [75], this corresponded to 7311 total codes across 540 unique categories. The full ICD-10 ontology contains 95,109 valid codes, underscoring the scale of the prediction task. Two approaches were compared: (1) a direct LLM baseline, in which GPT-4.1 was prompted to predict ICD-10 codes without constraints, and (2) GAVS, in which GPT-4.1 first generated granular diagnostic entities that were each mapped onto the top 10 matching ICD-10 codes through vector search over the official ontology. Across all admissions, the vanilla LLM produced 131,329 candidate codes, while GAVS produced 136,920. At the subcategory level, the vanilla LLM achieved a mean recall of 17.95% (15.86% weighted), whereas GAVS achieved 20.63% (18.62% weighted), representing a statistically significant improvement (P<.001, 2-proportion z test). Notably, GAVS generated 11,254 unique predicted subcategories, compared with 15,572 unique subcategories from the vanilla LLM, suggesting that the vanilla approach was more diffuse in its predictions, whereas GAVS concentrated predictions on a narrower and more relevant set of codes. At the category level, the vanilla LLM achieved a mean recall of 34.05% (32.60% weighted), while GAVS achieved 33.57% (32.58% weighted). The difference was not statistically significant (P=.99). GAVS produced 1192 unique predicted categories, compared with 913 unique categories for the vanilla LLM.

## Section: Results › Integration Into Rhazes Clinician

Building on the GARAG and GAVS prototypes, we developed a clinician-facing agentic web application that integrates documentation assistance, management planning (GARAG), automated coding (GAVS), and differential diagnosis tools and is accessible via the Rhazes website [53]. To maximize accessibility, the system was deployed as a Progressive Web Application, enabling installation and seamless use across desktop and mobile platforms without requiring a native app. The application was implemented using a modern web architecture: a Next.js full-stack framework with React (TypeScript) for the front end, a Node.js backend, and a PostgreSQL database accessed through the Prisma object-relational mapper. Hosting was provided on Aptible [77], a platform-as-a-service offering secure, Health Insurance Portability and Accountability Act–ready infrastructure. Within Rhazes, user queries are handled by LLM agents that route requests to the most appropriate tools. These include the management planning (GARAG) and medical coding (GAVS) pipelines described above, a documentation assistant for completing predefined templates, and a differential diagnosis tool that was previously evaluated in Sarvari and Al-Fagih [47]. The orchestration layer was built on LangGraph [70], allowing for parallel tool execution and a persistent shared conversation history across agents. The system, certified under Cyber Essentials [7879], is used by thousands of doctors and supports integration with major EHR systems, including Epic (32.8% market share in 2021) and Cerner (23.2% market share in 2021) [80].

## Section: Discussion › Principal Findings

In this study, we introduced Rhazes, an AI assistant for doctors designed to handle paperwork and analytical tasks in clinical medicine. Rhazes aims to free physicians from the burden of documentation and to help them provide better care for more patients. Within this broader system, the GARAG and GAVS frameworks demonstrate the feasibility of embedding structured guardrails into LLM-based clinical workflows. GARAG ensures that management plans are grounded in peer-reviewed guideline sources with properly formatted references, achieved through a diagnosis-first retrieval workflow that increases the likelihood of relevant sources being cited. GAVS applies a similar principle to coding, improving fidelity through a 2-step process in which diagnostic entities are generated first and then deterministically mapped to valid ontology terms via vector search. Both methods represent proof-of-concept prototypes that were subsequently deployed within the Rhazes Clinician platform. Although GARAG was evaluated on a smaller case set compared with GAVS, its strength lies in preserving fine-grained diagnostic information during retrieval. By generating diagnoses first and then retrieving guideline evidence for each one, GARAG avoids the information dilution that occurs when the entire patient record is embedded at once, ensuring that management plans remain tightly linked to diagnosis-specific guidance.

Taken together, the evaluation results indicate that GAVS improves resolution at the subcategory level without sacrificing performance at the broader category level. Beyond this quantitative advantage, GAVS has 3 qualitative benefits that strengthen its reliability and scalability. First, GAVS guarantees that every predicted code is part of the official coding ontology. Because predictions are drawn directly from a vector search over the ontology, the system cannot hallucinate nonexistent codes—a risk that remains with unconstrained LLM outputs. Second, GAVS is flexible across coding systems. Adapting it to a different ICD version, or to CPT/SNOMED, or to institution-specific ontologies requires no retraining or prompt engineering. One simply replaces the vector database with embeddings of the target ontology’s code descriptions, and the method functions seamlessly. Third, GAVS enhances explainability. The LLM provides a structured list of diagnostic predictions together with textual reasoning, and each prediction is then mapped deterministically to a small, fixed set of candidate codes via cosine similarity. This 2-step design ensures systematic and interpretable outputs. By contrast, a vanilla LLM generates codes as a single sequence based on statistical likelihood, with no guarantee of coverage, ordering, or manageable length, making its reasoning harder to audit and its predictions less scalable.

## Section: Discussion › Future Work

There are many feature improvements we envisage adding to Rhazes Clinician soon. First, we plan to experiment with new embedding models such as Guided In-Sample Selection of Training Negatives-large-embedding-v0 [81], which has been identified as a good fit for clinical tasks in a previous study [82]. The change in the embedding model means that we will have to reindex the latest versions of the clinical and coding guidelines we have been using for GARAG and GAVS. From a platform perspective, Rhazes already supports ICD, CPT, and SNOMED codes. We plan to extend this support to the full HCPCS [38] (including level 2) as well as OPCS. These additions will broaden coverage across clinical and administrative workflows. From an evaluation perspective, future work will focus on systematically assessing whether GAVS’ advantage over an unconstrained LLM generalizes across coding ontologies beyond ICD-10. We will design blinded, head-to-head comparisons—similar in spirit to Klang et al [65]—spanning CPT, SNOMED, HCPCS level 2, OPCS, and clinic-specific ontologies, with physicians and LLMs independently adjudicating results. Because these ontologies (particularly the less common or locally maintained ones) are less likely to be represented in pretraining data, our a priori hypothesis is that the relative benefit of GAVS will be larger than what we observed for ICD-10. As part of this program, we aim to construct and share a deidentified, gold-labeled coding dataset suitable for benchmarking across methods. Additional methodological work will examine the effect of the vector-search candidate set size (eg, top-k), alternative embedding models [8182], and improved parent-mapping resources to reduce unresolvable cases during category aggregation. Finally, we plan to extend our EHR integration offerings: we aim to support Egton Medical Information Systems, the leading EHR for UK primary care clinics, and SystmOne, the second most popular EHR for UK general practitioners [83]. These integrations will facilitate prospective, multisite evaluations and subgroup analyses while maintaining interoperability with existing clinical systems.

## Section: Discussion › Limitations

The GARAG workflow was tested on a relatively small set of 21 author-designed cases. While reproducibility was high, independent validation on larger and more varied case sets is needed. The GAVS evaluation, while based on a sizable cohort of 958 admissions, relied on billing records as the gold standard. Because billing data do not fully capture the clinical picture of each admission, it is not possible to definitively establish precision, as some well-reasoned diagnostic predictions may go unbilled [4647]. Moreover, the underlying MIMIC-IV dataset has well-recognized constraints: it lacks clinical notes, physical examination findings, and certain test results such as electrocardiograms, and it is drawn from a single hospital in Boston, MA. This means the data are subject to demographic and institutional biases and may not generalize to other patient populations. Finally, some specific ICD-10 codes could not be mapped to parent categories due to library limitations. These factors highlight the need for further testing against richer clinical datasets, across multiple institutions, and with more comprehensive ontology mappings. Taken together, these component-level limitations reflect broader challenges in deploying LLM-driven systems like Rhazes into clinical practice. The effectiveness of an AI co-pilot hinges on its accuracy across diverse clinical scenarios. In general, evaluation of clinical performance of LLMs is challenging due to the lack of transparency when it comes to versions, prompts, human evaluations, LLM-as-a-judge evaluations [4776], patient data, and due to the nonexistence of gold-labeled data sets for many clinical applications [84]. Care must be taken to accurately assess AI for improved patient outcomes and to avoid statistically flawed evaluations [85]. In practice, AI tools can exhibit degraded performance when used outside the conditions of their training (out-of-distribution use). Even models that performed well in development or obtained regulatory clearance have underperformed in new settings due to poor generalization. This raises the risk of missed diagnoses or incorrect management plans if the AI encounters patient data that differs from its training distribution. Continuous validation of the system on local patient populations is therefore critical to ensure reliability in AI-generated recommendations [86]. AI models learn from historical data, so any biases or gaps in those data can lead to skewed or inequitable outcomes [87]. If the training dataset underrepresents certain demographics or conditions, the model suggestions may be less accurate for those groups, potentially perpetuating health disparities. For example, studies have found some clinical AI algorithms perform significantly worse for female patients or racial minorities, underdiagnosing these groups compared to others [8889]. Such bias not only affects accuracy but also violates principles of fairness in care. Ensuring the data used by AI co-pilots are diverse and representative is essential to minimize this risk. We must also be mindful of other harmful biases LLMs may learn during training [84], as well as the risks that over-reliance on AI systems may bring to medicine (eg, automation bias) [90].

## Section: Discussion › AI in Health Care Ethics

Under the General Data Protection Regulation, health care organizations can often process patient data for care without explicit consent, provided they have a valid lawful basis (Article 6) and meet a special category condition (Article 9) [91], such as provision of health care services. This lawful basis should naturally extend to the data processors used, such as the AI scribes. However, alongside lawfulness, transparency is important. Patients should be informed when an algorithm is involved in their diagnosis or treatment planning. Research indicates that disclosing the use of an AI tool is essential to patients; a recent study found that patients strongly prefer to be informed when AI assists in their care and recommended that explicit consent for AI involvement be obtained during the clinical workflow [92]. In the context of Rhazes, this means clinicians should be transparent about the AI’s role—explaining to patients that an AI system will analyze their data and contribute to suggestions. Such transparency not only respects patient autonomy but also helps build trust, as patients are more likely to accept AI-derived recommendations if they understand and agree to their use.

An AI system must consistently uphold the core principles of medical ethics—beneficence, nonmaleficence, autonomy, and justice. One concern is that software like Rhazes might, in some situations, propose an option that, while data-driven, conflicts with a patient’s values or broader ethical norms. For example, an AI might prioritize treatments based on statistical outcomes or cost-effectiveness, which could unintentionally de-emphasize a patient’s personal preference for quality of life. If Rhazes recommends an aggressive treatment purely because it maximizes survival odds, but the patient prioritizes comfort, blindly following the AI would undermine patient autonomy. Human clinicians must interpret Rhazes’ outputs through the lens of their professional ethics and clinical judgment. They should override or adjust recommendations that do not fit the patient’s individual context or the ethical standards of care. In essence, Rhazes should support clinical decisions that are not only effective but also ethically sound, with the physician ensuring final decisions align with the principle of autonomy and patient-centered care. Several approaches can address these ethical concerns and ensure that AI tools are used responsibly in health care. One key strategy is incorporating explainability into the AI model. Rather than acting as a “black box,” Rhazes provides interpretable reasoning or an explanation for its suggestions (for instance, highlighting which patient factors or medical evidence led to a given diagnostic recommendation). Explainable AI methods help clinicians and patients understand why a recommendation was made, which is vital for trust and for verifying that the recommendation makes ethical and clinical sense. Another strategy is clinician oversight and accountability. Rhazes is intended to assist, not replace, the clinician; therefore, protocols should emphasize that the human provider retains ultimate responsibility for diagnosis and treatment decisions. By maintaining clear accountability—where the clinician must review and approve AI-generated plans—the risk of blind adoption of incorrect suggestions is reduced. Studies on automation bias mitigation have noted that training users and stressing their accountability can counter overreliance [93]. Regular training sessions for clinicians on the proper use of Rhazes, including case studies of when the AI errs, can sharpen their judgment on when to trust the AI and when to apply caution. Finally, patient education about AI in health care can help. Patients should be informed in understandable terms what Rhazes is and what role it plays in their care. When patients understand that the AI is a tool used by their doctor (and not a substitute for the doctor), it can alleviate fears of a purely machine-driven care plan. Surveys have shown that both doctors and patients feel anxious if they do not understand AI’s involvement [94], so educational efforts (leaflets, consent discussions, etc) can demystify the technology. In summary, through explainable AI design, strong human oversight, and educational transparency, Rhazes can be deployed in a way that upholds ethical standards and supports clinicians and patients alike.

## Section: Discussion › Compliance Requirements for AI Tools in Hospitals

Any digital health technology company operating within the United Kingdom collecting or processing any form of personal data must comply with UK General Data Protection Regulation and the Data Protection Act [95]. Companies processing personal data in the United Kingdom must be registered with the Information Commissioner’s Office (ICO) [96]. In addition to the usual requirements around processing personal data, it is likely that a health-tech company will be processing sensitive personal health data, which would classify as special category data. This can bring some additional requirements, such as the need or recommendation to complete a Data Protection Impact Assessment [97]. There must also be appropriate contracts and Data Processing Agreements [98] in place between an NHS organization and the digital health supplier, between which personal data may flow.

If a digital health supplier is looking to work with NHS organizations and will be interacting with NHS patient data, they will need to complete the Data Security and Protection Toolkit (DSPT) [99]. This is not a requirement in the private sector or in direct-to-consumer models. If an organization is an IT supplier with 50+ staff members and has a turnover of at least £10 million (US $13.16 million) and supplies digital goods and services to the NHS, the company must also undertake an independent audit/assessment [99]. Organizations handling patient data may require the following personnel: a data protection officer (DPO), a senior information risk owner, and a Caldicott guardian [99]. A DPO [100] is required if a company’s core activities consist of large-scale processing of special category data. DPOs help to monitor internal compliance, inform on data protection obligations, provide advice regarding Data Protection Impact Assessments and act as a point of contact for data subjects and the ICO. The Senior Information Risk Owner is a senior member of the organization whose roles are to promote a culture that values and protects ICO information, own information risk management policies and processes and ensure they are implemented, advise on information risk management processes and provide assurance, and own the incident management framework. The Caldicott Guardian [101] is a senior person responsible for overseeing the use and sharing of patient information by protecting the confidentiality of people’s health and care information.

Companies aiming to deploy in the NHS also must go through information security and technical assurance. UK Cyber Essentials [78102103] is a self-assessment that any company looking to work with the public sector must comply with. The general recommendation is for companies to comply with Cyber Essentials Plus, which involves both a self-assessment and an external audit. Often, companies will use ISO 27001 to demonstrate a higher level of security than required by just meeting DSPT requirements, but it is not generally mandated in health care organizations. ISO 27001 is an internationally recognized standard for information security [102] that is not health care specific. It requires companies to implement Information Security Management Systems and focuses on risk assessment. It requires independent certification by an accredited body. Digital health technologies deployed in NHS organizations in England will also need to comply with the digital clinical safety standards DCB0129/0160. This is required by law, under section 250 of the Health and Social Care Act 2012 [104]. Both the manufacturer (DCB0129) and deploying health or social care organization (DCB01060) are required to complete a clinical risk assessment, including key documentation. This process is overseen by an appropriately qualified Clinical Safety Officer. There is also a requirement to monitor and record any incidents post-deployment. Penetration testing is required to assess the security of digital health technologies deployed in NHS organizations as part of the NHS Digital Technology Assessment Criteria (DTAC) [105], which mandates that any identified vulnerabilities should be appropriately remediated. The NHS DTAC [105] is a framework that brings together legislation and best practice in 5 core areas: clinical safety, data protection, technical security, interoperability, and accessibility and usability, which incorporates the aforementioned NHS DSPT and DCB0129 standards. The DTAC is a national baseline criteria for digital health technologies being deployed within NHS health care organizations and can be used by health care organizations to assess suppliers as part of their due diligence process. Due to the complexity of navigating NHS compliance frameworks, specialized firms have emerged to help digital health companies accelerate clinical assurance processes; these include Assuric [106], Vanta [107], and Naq [108].

If the AI product meets the definition of software as a medical device (SaMD), companies would also need to comply with medical device regulation and achieve appropriate certifications before being available for use in the open market. This would be the case if the intended purpose and functionality of the product extends into diagnosis, prevention, monitoring, prediction, prognosis, treatment, or alleviation of disease, as defined by European Union (EU) Medical Device Regulation [109]. SaMD is defined as “software intended to be used for one or more medical purposes that perform these purposes without being part of a hardware medical device” [110]. In the United Kingdom, medical devices are classified by risk to class 1, class 2a, class 2b, and class 3, with class 1 being low risk to patients and class 3 being high risk to patients. Manufacturers face a greater scope of work and evidentiary burden when dealing with higher-risk products. In the United Kingdom, low-risk class 1 devices require manufacturers to make a self-declaration of conformity to the Medicines and Healthcare Products Regulatory Agency (MHRA). Other classes require involvement and approval from an approved body (an organization designated by the MHRA to assess the conformity of products before they are placed on the market), granting a UK Conformity Assessed mark, the equivalent to a Conformité Européenne (CE) mark in the EU.

There have been several AI-as-a-medical device products on the market for some time, primarily in the category of diagnostic radiology or dermatology tools, one example being Skin Analytics, which recently achieved regulatory approval for autonomous AI skin cancer detection system Deep Ensemble for Recognition of Malignancy in Europe, receiving class III CE marking. This is the first legally authorized AI to independently make clinical decisions on skin cancer without oversight. Deep Ensemble for Recognition of Malignancy achieves 99.8% accuracy rate in ruling out cancer, surpassing the performance of dermatologists who typically achieve 98.9% [111]. However, there is yet to be a generative AI product that has been certified as a medical device in the United Kingdom or EU. In the United States, Modella AI’s generative AI co-pilot, PathChat, has received device designation by the Food and Drug Administration. This is the first regulatory approval of a clinical-grade generative AI co-pilot [112] and is the first of likely many more SaMD generative AI applications.

The NHS 10-Year Reform Plan sets a clear direction for modernizing care delivery, with a strong emphasis on digital transformation, integrated community services, and reducing strain on clinical staff [113]. One area gaining significant momentum is the deployment of AI-enabled ambient scribing tools, which offer practical relief from administrative overhead by automatically transcribing and summarizing clinical encounters [113]. The plan explicitly highlights the need to streamline documentation and use responsible automation to release clinician time for patient care [113]. In parallel, NHS England’s technical guidance on ambient voice technology adds further clarity and outlines key regulatory considerations for these tools [114]. Pure transcription tools are generally not considered medical devices. However, where generative AI features extend into summarization, providing prompts, generating structured clinical notes, letters, or codes, they are likely to qualify as SaMD. Such tools would then require UK Conformity Assessed or CE marking, MHRA registration, and a full clinical safety case under DCB0129/0160. Beyond regulatory certification, NHS organizations are expected to ensure integration with existing EHRs through standards such as Fast Health Care Interoperability Resources, HL7, and SNOMED CT, maintain strong human oversight to mitigate diagnostic drift or foreseeable misuse, and implement a clear post-deployment monitoring framework. This includes mechanisms for clinicians to flag transcription errors, routine audits of scribe outputs, and attention to bias risks, particularly for patients with regional accents, dialects, or speech impairments.

## Section: Discussion › Conclusion

While AI has been rapidly evolving over the last 2 years, progress has not been reciprocated in the health care industry, a heavily regulated space with many financial, staffing, and quality-of-service-type problems. Due to the lack of gold-labeled datasets and human evaluation protocols for LLM-generated text, recent AI in health care innovations was driven by well-funded industry players who were able to start generating evidence by securing hospital pilots early. So far, most companies seek to innovate in administrative workflows that avoid direct patient care as this comes with lesser regulatory burden. There seems to be a regulatory gray area surrounding workflows which could ultimately affect patient care should doctors over-rely on AI. Examples include AI scribing and clinical document generation, with only a few AI notetaker tools evaluated in academic journals with often conflicting and lack of reproducible results.

In this article, we reviewed the need for AI tools in health care and the current state of the industry, including dominant players and their progress. During this review, we demonstrated, firsthand, how such tools may be created and how they may be used by physicians. We discussed key implementation considerations for Rhazes Clinician, an AI assistant for doctors. We described in detail the methods used to create a CDS and an admin assistant for doctors, including the LLMs deployed, the clinical guidelines used, the RAG hyperparameters, and the cloud services used. We also introduced a new method for medical coding that we dubbed GAVS for Generation-Augmented Vector Search and an improved RAG workflow for CDS that we named GARAG. GARAG highlights the value of diagnosis-specific retrieval, allowing management plans to stay closely linked to diagnostic evidence while avoiding the information dilution that occurs when entire patient records are embedded in typical RAG workflows. We showed that GAVS statistically significantly improves ICD-10 coding predictions. For both treatment planning and medical coding, we provided Jupyter notebooks that demonstrate the (albeit simplified) implementation of these Rhazes tools. Our goal with this is to contribute to the academic discussion about AI tools for health care and encourage academics as well as industry players to share their datasets and novel methods in order to accelerate the deployment of transparent AI tools in hospitals.


---

# Clinical Laboratory Parameter-Driven Machine Learning for Participant Selection in Bioequivalence Studies Among Patients With Gastric Cancer: Framework Development and Validation Study

- **Authors:** Byungeun Shon, Sook Jin Seong, Eun Jung Choi, Mi-Ri Gwon, Hae Won Lee, Jaechan Park, Ho-Young Chung, Sungmoon Jeong, Young-Ran Yoon
- **Issuer:** JMIR AI
- **Type:** Scientific article
- **Published:** 2025-05-05
- **Language:** en
- **DOI:** 10.2196/64845
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40605831/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundInsufficient participant enrollment is a major factor responsible for clinical trial failure.ObjectiveWe formulated a machine learning (ML)–based framework using clinical laboratory parameters to identify participants eligible for enrollment in a bioequivalence study.MethodsWe acquired records of 11,592 patients with gastric cancer from the electronic medical records of Kyungpook National University Hospital in Korea. The ML model was developed using 8 clinical laboratory parameters, including complete blood count and liver and kidney function tests, along with the dates of acquisition. Two datasets were collected: (1) a training dataset to design an ML-based candidate selection method and (2) a test dataset to evaluate the performance of the proposed method. The generalization performance of the ML-based method was confirmed using the F1-score and the area under the curve (AUC). The proposed model was compared with a random selection method to evaluate its efficacy in recruiting participants.ResultsThe weighted ensemble model achieved strong performance with an F1-score above 0.8 and an AUC value exceeding 0.8, demonstrating its ability to accurately identify valid clinical trial candidates while minimizing misclassification. Its high sensitivity further enhanced the model’s efficiency in prioritizing patients for screening. In a case study, the proposed ML model reduced the workload by 57%, efficiently identifying 150 valid patients from a pool of 209, compared to the 485 patients required by random selection.ConclusionsThe proposed ML-based framework using clinical laboratory parameters can be used to identify patients eligible for a clinical trial, enabling faster participant enrollment.

## Section: Introduction

Inadequate participant recruitment may lead to failure in a clinical trial, ultimately delaying new drug development and increasing costs [1-7]. Tasks comprising the recruitment process, such as prescreening, consent, screening, and communication between the participant and the study staff for the clinical trial, are inevitably labor intensive [2,3,8-10,undefined,undefined]. For instance, researchers manually review large volumes of electronic medical records (EMRs) during the prescreening process to identify potential candidates. Despite advances in the methodologies for each process in clinical trials, a systematic approach for enhancing the efficacy of participant enrollment is lacking.

Artificial intelligence (AI) has various applications in every section of the industry, and a machine learning (ML)–based optimal design of clinical trials has entered the sphere of pharmaceuticals [11]. Several AI techniques for identifying, screening, and enrolling appropriate participants for clinical trials have been introduced, and some have been employed commercially [1,4,8].

Corporates such as Mendel, Deep 6 AI, and Antidote have developed and provided AI solutions for clinical trial recruitment [12-16]. These commercial services use massive data such as demographics, laboratory, imaging, and multiomics data to facilitate faster recruitment and provide full-service recruitment [14,15]. Jin et al [17] reported that a result from a user study using large language model framework, TrialGPT, to support patient matching resulted in a 42.6% decrease in the screening time [18]. Another AI approach is clinical trial digital twin technology [18-21]. Digital twin technology creates virtual patients that replicate individual characteristics, enabling the prediction of clinical responses [18,19,21]. By utilizing digital twins, the required sample sizes for clinical trials can be reduced [18,19,21]. These informatics-based tools are expected to improve recruitment efficiency, directly influencing the success rate of clinical trials [1,4,5].

Eligibility criteria specify the qualification of participants in clinical trials, and this component comprises structured information, including diagnoses and laboratory results, and unstructured information, such as clinical free text. Previous AI studies have primarily focused on developing advanced natural language processing and optical character recognition techniques for extracting unstructured data [2,3,6,8-10,undefined,undefined]. As AI technology is rapidly changing, most research and services have developed AI tools using both structured and unstructured data [12,14-16,22,undefined,undefined]. However, complicated preprocesses (eg, annotation), discrepancies between EMR systems and databases of institutions (eg, noninteroperable algorithms), and high costs limit their application. Moreover, highly sophisticated eligibility criteria can render the generalization of algorithms challenging.

In contrast, clinical laboratory test data and typical structured data can be readily incorporated into an EMR-utilizing algorithm, given that these data are comparatively more objective than other unstructured data [23,24]. Mohammad et al [11] have suggested that disclosing the pretest probability of a specific test result can be clinically meaningful for some laboratory tests.

In bioequivalence studies of drugs, clinical laboratory tests such as hematology and blood chemistry tests are included as eligibility criteria. Participants considered suitable by the investigator based on laboratory results are allowed to take part in the bioequivalence study. Therefore, prescreening through clinical laboratory tests is considered to be effective in quickly selecting potential candidates.

Accordingly, we formulated an ML-based framework to identify participants using the clinical laboratory test values of candidates. In this study, we chose to compare the ML-based method with a random selection method, which we considered representative of the common practice in clinical settings where patient lists are screened sequentially. Collectively, the objective of this study was to develop a simple and rapidly applicable ML algorithm that could assist in participant identification for bioequivalence study enrollment.

## Section: Methods › Study Design

In total, records of 11,592 patients with gastric cancer were acquired from the EMRs of Kyungpook National University Hospital in Korea from 2011 to 2019. Clinical laboratory parameters (including complete blood count and liver and kidney function tests) and acquisition dates were acquired to develop the ML-based model to predict relevant laboratory data of patients on a future date. The laboratory parameters selected were those used in the eligibility criteria for bioequivalence testing of anticancer drugs in patients with gastric cancer. We developed the model using 8 basic and straightforward parameters such as complete blood count (hemoglobin, neutrophil count, platelet count), liver function tests (total bilirubin, aspartate aminotransferase, alanine aminotransferase, alkaline phosphatase), and kidney function tests (creatinine), which are minimal tests capable of assessing health status. These parameters enable a simple and efficient preliminary assessment of potential screening candidates.

“Label 1” was assigned when the candidate’s clinical laboratory data fell within the valid range, while “label 0” indicated data outside the valid range (Table 1). A patient was considered a valid candidate for a clinical trial only if all predicted laboratory data met the eligibility criteria. To design an ML-based candidate selection method, the dataset was divided into training and test sets; data collected from 2011 to 2018 were used for training, while data from 2019 were reserved for testing (Table 1). This time-based split ensured a fair evaluation of the model’s performance by avoiding any temporal overlap, thereby reflecting real-world scenarios where future data (test data) would not be available during model training. Additionally, this approach allowed us to assess the model’s ability to generalize unseen data while accounting for potential temporal effects, such as advances in medical technology or shifts in population health trends. By adopting this methodology, we aimed to provide a realistic evaluation of the model’s performance in clinical settings.

## Section: Methods › Ethical Considerations

This study was approved by the Kyungpook National University Hospital Institutional Review Board (KNUH 2020-04-023), and a waiver of consent was authorized. All research was performed in accordance with the guidelines of the Declaration of Helsinki, and only deidentified data were used and analyzed in our retrospective study.

## Section: Methods › Data Preprocessing

We attempted to resolve the issues of aperiodicity and imbalance in the training dataset by applying the combination method and principal component analysis (PCA). First, to analyze the trend of laboratory data changes, at least 3 sequential data points of laboratory data and acquisition dates were required. However, given the nonperiodical patient visits to the hospital, the intervals between each data point were inconsistent. To compensate for the aperiodicity of the data, the distribution of data points was increased by computing a simple combination method as follows:

C(n,k)=P(n, k)k!=n!(n−k)!k! (1)

where P indicates the permutation function, n is the number of data points, and k is the number of selected sequential data points (4 in this study). Therefore, 4 sequential data points with 8 values, comprising 6 initial values to analyze the trend of data changes and 2 values as target data to verify the analysis model, were generated as one data group. For example, if a patient had 10 laboratory data points, 210 data groups, including 8 values, were augmented. Each laboratory data value was normalized by the minimum and maximum values of data distribution, and the acquisition date values are represented by |acquisition date − a screening date| / N, where N is a normalization factor. Finally, each data group was encoded by considering whether the last 2 values were within the valid range. Table S1 in Multimedia Appendix 1 presents the number of training data points obtained using the combination method.

The augmented training dataset was intuitively visualized by applying the first principal component, as shown in Figure 1. Although Equation 1 helps resolve aperiodicity, the problem of nonuniform distribution in the dataset persisted in both valid and invalid classes. Thus, to compensate for the nonuniform distribution of training data groups, we normalized the imbalanced data into 100,000 even training data points of each laboratory parameter by dividing the data distribution into 100 regions and randomly extracting 5000 data points from each region (Figure 1). Moreover, we attempted to correct the data imbalance by selecting the same number of data points for each label class. Table S2 in Multimedia Appendix 1 lists the numbers of training and test datasets.

## Section: Methods › ML-Based Selection Method

There are various models in ML, and the performance of each model can vary greatly depending on how the elements of the process, such as data preprocessing, feature engineering, model selection, hyperparameter tuning, and ensembling, are configured. Therefore, specialized knowledge and experience are required, making it difficult for nonexperts to use the same skills as experts. To solve this problem, automated ML (AutoML) simplifies and automates the mentioned complex processes, so that nonexperts can easily use ML and expect the same performance as experts.

AutoGluon-Tabular is an AutoML and an open-source library developed by Amazon Web Services [25]. Figure 2 shows the architecture in this study that utilizes it. The input data is applied with various ML models (KNeighbors, random forest, Extra Trees, Light Gradient-Boosting Machine [LightGBM], Extreme Gradient Boosting [XGBoost], CatBoost, and NeuralNet) and a stacked ensemble technology that combines them, and the output is the probability value that predicts whether the patient is valid.

## Section: Results

The present study consisted of two parts: (1) the generalization performance of the ML-based model was confirmed with various evaluation metrics, including accuracy, sensitivity, specificity, precision, F1-score, and area under the curve (AUC); and (2) the proposed model was compared using a random selection method to evaluate its efficacy in participant recruitment.

The training results for each model were evaluated as F1-scores (Table 2). The weighted ensemble model resulted in the highest average F1-score of 0.91 (SD 0.076). The weighted ensemble model exhibited the best performance in terms of precision and recall. Among the same ML models, detailed models were classified according to parameters such as the size and calculation method. As shown in Table 2, we observed that the F1-score for the weighted ensemble model was over 0.8 during the training process, indicating strong performance. An F1-score above 0.8 is generally considered strong, as it reflects a good balance between precision and recall, which is crucial in clinical applications where both false positives and false negatives can have significant consequences. Precision measures how many of the predicted valid candidates are truly valid, while recall reflects how many of the actual valid candidates were correctly identified by the model. A high F1-score ensures that the model is not only accurate in predicting valid candidates but also minimizes the risk of misclassifying candidates who could otherwise be eligible for clinical trials.

We evaluated the performance of the classification task of the ML algorithm (Table 3). The receiver operating characteristic curves for each clinical parameter are shown in Figure S1 in Multimedia Appendix 1. In Table 3, the overall AUC value exceeded 0.8, demonstrating high performance. An AUC value exceeding 0.8 is considered high, indicating that the model has a strong ability to discriminate between valid and invalid candidates. The AUC measures the model’s ability to distinguish between eligible and noneligible patients, and an AUC value closer to 1 signifies excellent performance. This is particularly important in clinical settings, where the model’s ability to prioritize the right candidates can improve the efficiency and accuracy of the screening process. What we found particularly noteworthy in the results shown in Table 3 was the high sensitivity. A higher sensitivity means that the probability of correctly identifying patients who fall within the valid range is increased. We can prioritize patients with a higher probability of being in the valid range based on model predictions, and by sequentially conducting additional tests, quickly screen for an appropriate and statistically significant sample size for clinical trials, ultimately contributing to a more efficient and successful trial.

For the application test, we evaluated the effectiveness of the proposed model for identifying eligible patients from the test dataset. First, assuming prescreening dates from December 1, 2019, to December 31, 2019, laboratory data were collected from 2019. One test dataset was constructed by retrieving the last 3 laboratory data points per patient during the period. Table 4 presents the number of clinical trial participants used for the application test. In the actual hospital EMR, no alkaline phosphatase test data were available for patients with gastric cancer during this period. Cases were classified according to their valid ratio to the total. We designated the parameters as case 1 when the number of valid data was <50%, case 2 when it ranged between 50% and 60%, and case 3 when it was >60%.

Figure 3 shows the number of valid and invalid patients by probability from 0 to 1. The number of invalid patients by probability was first drawn as a histogram, and then the valid patients were drawn on top of it by accumulating them. As can be seen in the results, there were fewer valid patients and more invalid patients on the side where the predicted probability was close to 0, while there were more valid patients and fewer invalid patients on the side where the probability was close to 1. Through this, we can see that the results predicted by ML are reliable, and it is advantageous to select patients with high probability values for patient screening.

Finally, valid candidates were identified by extracting patients in the order of highest predicted probability from the proposed model, and the results were compared with random findings. Figure 4 shows the results concerning the identification of valid patients for clinical trials. For example, in the case of hemoglobin, we aimed to identify 150 clinically suitable patients out of 673 total patients, where 203 patients met the eligibility criteria. As shown in Figure 4, our proposed model identified 150 valid patients by screening only 209 high-probability candidates. In contrast, a random selection process required screening 485 patients to find 150 valid patients. This demonstrates an approximate 57% reduction in workload.

Figure 5 shows a comparison of clinical trial participants in the order of probability of the proposed model and random method. Compared with the random selection method, more valid patients were distributed at the top of the proposed result, and more invalid patients were distributed at the bottom. When selecting patients for clinical trials, if the patients sorted by the proposed method are assigned from the top, it is possible to determine suitable target patients faster than with the random method.

Overall, the proposed ML model identified valid participants for clinical trials faster than the random selection method. In particular, as seen in the case of hemoglobin and creatinine, in case 1 and case 2, that is, when the valid rate was <60%, the proposed model identified valid participants considerably faster.

## Section: Discussion › Principal Findings

We developed an ML-based framework to support the prescreening of clinical research using clinical laboratory tests to reduce the workload of reviewing structured data of eligibility criteria. We developed a protypical but practical framework using clinical laboratory data and achieved high accuracy and a 57% workload reduction compared to random selection when identifying 150 valid patients. Based on our results, we expect that the framework will potentially reduce investigators’ burden and shorten the recruitment period by assisting with conventional manual prescreening.

Prescreening involves the process of selecting candidates for screening, a cumbersome manual task that requires a heavy burden of research personnel at this stage [2,3,8-10,undefined,undefined]. The most efficient known method for determining eligibility criteria–matching candidates is as follows: candidates are randomly prioritized by research staff, and one staff member is selected to review and narrow the potential list for screening. Although several AI-based tools for assisting the recruitment of participants have been introduced, there are a few tools to support prescreening [1], and relevant studies using only structured information, such as laboratory results, are limited. Recently developed AI-based recruitment services offer a significant advantage in performing precise and rapid clinical trial participant matching by incorporating both structured and unstructured data. However, these services can be costly to implement. In contrast, our study suggests a practical alternative to more comprehensive but potentially cost-prohibitive AI-based recruitment services by showing that efficient prescreening can be conducted using laboratory data alone. This approach provides a more accessible and cost-effective method for individual researchers to apply in their bioequivalence studies.

Considering the framework of this study, the primary contribution is the establishment of a ranked list of potential participants for trial enrollment in an intuitive manner. A simple list of potential candidates can be valuable in informing the decision to review additional eligibility criteria, thereby alleviating the burden of manual prescreening and preventing underestimation due to manual review. Advantages of the framework include simple and time-saving characteristics, the requirement for only a few laboratory data among numerous EMR data, and effortless implementation through AutoGluon-Tabular. The utilization of programs such as AutoGluon-Tabular makes it easy for beginners to employ ML. In addition, ML with techniques tuned for performance improvement can be utilized by experts with minimal time and effort, making our approach more accessible.

We speculate that the irregularity of patient visiting schedules and the imbalance of the clinical laboratory parameters remain major driving limitations in the present ML-based framework. To overcome these defects, we carefully designed the algorithm using the PCA method (Table S2 in Multimedia Appendix 1 and Figure 1). However, further research is required to refine the solutions to combat aperiodicity and imbalanced data.

The proposed system can be integrated into clinical trial recruitment workflows as a decision-support tool for the prescreening process. Currently, prescreening candidates for clinical trials often involves manually reviewing large volumes of patient data to determine eligibility. By automating the selection process, our system can generate a ranked list of potential participants based on clinical laboratory parameters, allowing research staff to focus their manual review efforts on high-priority candidates. This integration could be achieved by embedding the system into existing EMR systems. The framework can process patient data directly from the EMR, analyze the eligibility criteria, and provide a prioritized candidate list in real time. Additionally, the ranked list can be updated dynamically as new patient data becomes available, ensuring that the recruitment process is both efficient and adaptive to changing conditions.

The clinical data used in this study were collected from a specific institution (Kyungpook National University Hospital) and from patients with a specific condition, which may limit the generalizability of the findings. Therefore, further diversification of the data and additional validation are necessary. Moreover, in terms of ethics, AI models should not replace human judgment in the clinical trial participant selection process, but rather serve as an assistive tool for initial screening. In addition to the limitations of generalizability due to the data source, integrating this system into clinical workflows may encounter challenges such as compatibility with diverse EMR platforms, requiring standardized data formats and robust interoperability. Training research staff to effectively use the system and ensuring transparency in AI decision-making processes will be critical for fostering trust and adoption. Moreover, ethical and regulatory compliance regarding patient data usage must be carefully managed to address privacy concerns and uphold clinical trial standards

Our future work will focus on improving the generalization of the framework. First, we plan to apply this method to screen patients for bioequivalence studies involving cancers other than gastric cancer. Bioequivalence studies of anticancer drugs are mostly conducted on patients under follow-up after curative treatment and are performed to demonstrate the equivalence of bioavailability. Therefore, compared to clinical trials aimed at evaluating efficacy, the eligibility criteria are not quite complicated. Additionally, the presence of similar criteria makes the framework developed in this study likely to be easily generalizable.

Second, while researchers typically utilize both structured and unstructured data in the screening process, this study is limited to the use of structured data. However, we expect that screening with an ML-based framework, followed by incorporating unstructured data, could help reduce the overall workload. We aim to enhance the framework to integrate unstructured data for a more comprehensive screening process. Third, we recognize the importance of comparing our approach to existing methods, and plan to include such comparisons in future research. In this study, we targeted structured information from patients; considering unstructured and structured information may therefore enhance the generalization of the framework, covering comprehensive eligibility criteria. In addition, we plan to conduct a prospective study to compare the proposed framework with conventional methods. Collectively, we anticipate that the framework will cover a wide disease spectrum and expand its applicability to clinical trials from other institutions.

## Section: Discussion › Conclusion

We proposed an AI support framework utilizing structured information on eligibility criteria to select appropriate candidates for clinical trial enrollment. This method could accelerate the efficiency of prescreening processes and can be applied to various clinical trials.

## Section: Acknowledgments

This work was supported by a Biomedical Research Institute grant, Kyungpook National University Hospital (2018). The funders had no role in the study design, data collection and analysis, decision to publish, or preparation of the manuscript.


---

# Clinical Large Language Model Evaluation by Expert Review (CLEVER): Framework Development and Validation

- **Authors:** Veysel Kocaman, Mustafa Aytuğ Kaya, Andrei Marian Feier, David Talby
- **Issuer:** JMIR AI
- **Type:** Scientific article
- **Published:** 2025-12-04
- **Language:** en
- **DOI:** 10.2196/72153
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41343765/
- **Licence:** CC-BY

## Section: Abstract

The proliferation of both general purpose and health care-specific large language models (LLMs) has intensified the challenge of effectively evaluating and comparing them. Data contamination plagues the validity of public benchmarks, self-preference distorts LLM-as-a-judge approaches, and there is a gap between the tasks used to test models and those used in clinical practice. In response, we propose CLEVER (Clinical Large Language Model Evaluation-Expert Review), a methodology for blind, randomized, preference-based evaluation by practicing medical doctors on specific tasks. We demonstrate the methodology by comparing GPT-4o (OpenAI) against 2 health care-specific LLMs, with 8 billion and 70 billion parameters, over 3 tasks: clinical text summarization, clinical information extraction, and question answering on biomedical research. Medical doctors prefer the medical model-small LLM trained by John Snow Labs over GPT-4o 45% to 92% more often on the dimensions of factuality, clinical relevance, and conciseness. The models show comparable performance on open-ended medical question answering, suggesting that health care-specific LLMs can outperform much larger general purpose LLMs in tasks that require understanding of clinical context. We test the validity of CLEVER evaluations by conducting interannotator agreement, interclass correlation, and washout period analysis.


---

# Comparative evaluation of artificial intelligence platforms and drug interaction screening databases using real-world patient data

- **Authors:** Bálint Márk Domián, Amir Reza Ashraf, András Tamás Fittler, Mátyás Káplár, Róbert György Vida
- **Issuer:** Exploratory research in clinical and social pharmacy
- **Type:** Scientific article
- **Published:** 2025-09-08
- **Language:** en
- **DOI:** 10.1016/j.rcsop.2025.100655
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41425735/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractBackgroundThe use of multiple medications increases the risk of harmful drug-drug interactions (DDIs). Conventional DDI screening databases vary in coverage and often trigger low-relevance alerts, contributing to alert fatigue. Large language models (LLMs) have emerged as potential tools for DDI identification, however, their performance compared to established databases using real-world patient data remains under-explored.MethodsIn this exploratory study, we compared conventional database screening with LLM-based screening using anonymized medication lists from rheumatology patients. Lexicomp, Medscape and Drugs.com were used to compile a reference set of 204 clinically relevant interactions across 57 cases. Using identical prompts, we then queried ChatGPT, Google Gemini and Microsoft Copilot for interactions potentially requiring pharmacists' intervention. We calculated sensitivity, specificity, precision and F1 score.ResultsCompared to the reference set of 204 DDIs, ChatGPT identified 439, Gemini 1556, and Copilot 1813 potential interactions. While Gemini achieved the highest sensitivity (0.697), ChatGPT demonstrated higher specificity (0.868). All three platforms demonstrated low precision scores. Overall, ChatGPT achieved the highest performance by F1 score (0.2520), followed by Gemini (0.1933) and Copilot (0.1153). Our results suggest that no AI systems assessed achieve the required balance of precision and sensitivity for reliable clinical decision-making in DDI screening.ConclusionAlthough LLMs show promise as complementary tools in DDI screening, as they proved effective in identifying true interactions, they generate clinically inaccurate information due to hallucinations, which limits their reliability as standalone screening tools. Consequently, while LLMs could support clinical pharmacists in polypharmacy management, their outputs must always undergo professional validation to ensure patient safety.Keywords: Artificial intelligence, Chatbot, Clinical pharmacy, Drug-drug interaction, Medication review, Patient safety, ChatGPT, Gemini, Copilot

## Section: Introduction

Polypharmacy, the regular use of multiple medications at the same time, is increasingly common, especially among older adults, creating heightened risk for drug–drug interactions (DDIs). The identification and management of DDIs represents a critical component of patient care and pharmacy services. However, conventional online drug interaction screening databases (e.g. Drugs.com Drug Interaction Checker) or interaction checkers integrated into pharmacy information management systems often vary in comprehensiveness, consistency, and clinical relevance.1,2 Additionally, the excessive number of drug interaction warnings of low clinical significance may result in cognitive overload and alert fatigue. In practice, this high volume and variability of alerts can lead to missed critical interactions or unnecessary medication changes, compromising patient safety and therapeutic outcomes. Recent studies emphasize that even well-established databases may overlook relevant interactions or present conflicting categorizations, further challenging clinical pharmacists' ability to make informed decisions.3,4 These longstanding challenges and limitations of traditional screening tools highlight the need for more advanced and adaptable solutions. Artificial intelligence (AI) is rapidly transforming healthcare, with AI-powered tools emerging as promising complementary solutions for clinical decision support, diagnostics, and personalized medicine.5,6 Within pharmacy practice specifically, these technologies show marked promise for medication use review and medication reconciliation, particularly when addressing complex polypharmacy regimens. These tools use large language models (LLMs) with natural language processing ability and leverage large-scale biomedical data to potentially provide more adaptive and clinically nuanced DDIs assessments.7., 8, 9 Multiple recent studies have shown that mainstream generative AI models, such as ChatGPT, Google Gemini (formerly Bard), and Microsoft Copilot (formerly Bing AI), can provide guidance and recommendations when asked about acquiring medications via the internet, as well as recognizing and classifying drug interactions with differing levels of performance and correctness.10, 11, 12, 13 Although emerging evidence supports the potential of generative AI in pharmacy practice, early investigations revealed that the performance of AI models vary significantly depending on the platform and the framing of prompts, highlighting the need for structured benchmarking against conventional databases.14,15

Despite this variability, many healthcare professionals including clinical pharmacists are beginning to integrate these tools into their workflows.16 Familiarity with digital technologies and commitment to evidence-based, rapid decision-making position make young healthcare professionals as early adopters of AI tools in clinical settings.17 Studies have shown that pharmacy professionals, predominantly those in academic or hospital settings, are increasingly engaging with AI tools to assess interactions, improve patient counseling, and streamline clinical workflows.18,19 The evolving expectations of modern healthcare, combined with the increasing complexity of polypharmacy, further amplify the appeal of AI-enhanced solutions for clinicians20 and pharmacists as well. Nevertheless, despite growing adoption, studies on comparative performance evaluation of mainstream LLM-based chatbot platforms against established databases with real-world data remain scarce. This study addresses the gap by comparing the performance of conventional DDI databases versus AI chatbots using real-world polypharmacy patient data for structured, comparative benchmarking. We focus on clinically relevant drug interactions to evaluate the reliability and practical utility of these AI tools in supporting safe medication therapy management.

## Section: Methods

Unified categorization of DDI severity across databases.

## Section: Methods › Patient data and ethical considerations

To determine eligibility for subsequent AI testing, preliminary DDI screening was performed on anonymized medication lists from 80 rheumatology patients included in our previously published cross-sectional observational study (sum = 661 medication; average = 11.6 medication/medication list; 89.5 % polypharmacy prevalence).3 The institutional ethical review board approved the original data collection, and because all patient data were de-identified for this study, additional ethics approval was not required as no personal or identifiable information was accessed or analyzed.

## Section: Methods › Drug interaction database selection and DDI classification

To establish a reliable baseline for evaluating AI model performance, we utilized three widely recognized drug interaction databases: the UpToDate Lexicomp database (Wolters Kluwer Clinical Drug Information), the Medscape drug interaction checker (WebMD LLC.), and Drugs.com database (Drugsite Limited).21., 22., 23., 24. Throughout this study, the use of drug interaction screening databases is referred to as the standard or conventional method. Since relying on a single DDI source may yield inconsistent or incomplete results due to variations in database coverage and interpretation,3,25., 26, 27 each medication list was checked across all three databases, and the interaction results were systematically documented according to each database's DDI severity category classifications.

## Section: Methods › DDI database category unification technique and medication list selection

Since these databases use different nomenclatures for DDI severity categorization, we consolidated the categories into a unified binary system to enable comparison. These included a “Clinically relevant” and a “Clinically NOT relevant” category (consisting of minor interactions requiring no action, and instances of no interaction) to enable comparison (Table 1.).

Database DDI results were paired with the relevant unified category, and we considered a DDI clinically relevant only if all three databases identified it with consensus. The remaining drug pairs were classified as “Clinically NOT relevant”. With these consensus interactions, we constructed our reference database for AI comparison.

Following database screening, the medication lists were included in the AI analysis only when there was consensus across databases for at least one clinically relevant interaction pair, or when all databases agreed on flagging no interactions at all.

Unified categorization of DDI severity across databases.

## Section: Methods › Artificial intelligence platforms

To ensure broad relevance and generalizability, the evaluated AI platforms were selected based on market share and size of their user base at the time of data collection in April 2025.28 We evaluated OpenAI's ChatGPT (GPT-4 model), Google's Gemini 2.0 (Flash edition), and Microsoft Bing's Copilot, using the latest available versions at the time of investigation. All platforms were accessed using identical prompts to maintain objectivity.

## Section: Methods › Prompt development

We aimed to ensure clinical relevance during prompt development by mirroring the language and perspective a healthcare professional might use when assessing potential drug interactions. The prompt incorporated common categorizations used in reference databases with the following instruction:

“List those interactions that require intervention by a healthcare professional, such as a clinical pharmacist, when reviewing medication use, because they are categorized as ‘Avoid combination,’ ‘Consider therapy modification,’ ‘Use alternative,’ or ‘Monitor therapy’ drug interactions.”

This phrasing was designed to focus on interactions that typically require professional oversight and intervention. Beside this instruction prompt, each query contained the medication list in form of active pharmaceutical ingredients (APIs) using their international nonproprietary names (INNs). We deliberately requested no explanations or justifications, requesting each AI to provide only a list of clinically relevant interaction pairs that require professional intervention. Since the AI platforms generated responses automatically and independently without human interpretation during output generation, blinding procedures were not applicable. All AI platforms provided definitive interaction lists for each medication list, with no inconclusive or missing data encountered during data collection.

## Section: Methods › Data analysis

Model outputs were benchmarked against the reference baseline created by using conventional databases (Lexicomp, Medscape, Drugs.com) by the study investigators (licensed pharmacists). For each individual medication list, the total number of clinically relevant DDIs reported by each AI was recorded to determine the number of true positives (TP), and false positives (FP). False negative (FN) values were calculated from reference baseline values minus TP. True negative (TN) values were calculated from the theoretical maximum of possible pairwise interactions minus the sum of TP, FP and FN values for each given case. Using these values, we calculated the following performance metrics: sensitivity, specificity, precision, and F1 score for individual medication lists and then calculated the mean value of these metrics to assess the performance of the AI platforms. Detailed description of performance metrics for assessing AI based DDI classification is available in Supplement 1.

## Section: Methods › Statistical analysis

To compare the performance of the three AI platforms across multiple evaluation metrics, non-parametric statistical tests were employed due to violations of normality as assessed by the Kolmogorov-Smirnov test. Specifically, the Friedman test was used to detect overall differences among the models for sensitivity, specificity, precision, and F1 scores. When the Friedman test indicated significant differences, post-hoc pairwise comparisons were conducted using the Wilcoxon signed-rank test. Statistical analyses were performed using SPSS version 28 (IBM Corp.) software. All analyses were performed on a within-subjects basis using data from 57 matched cases, and statistical significance was determined at an alpha level of 0.05 (two-tailed). These non-parametric approaches ensured robust comparison of model performance despite non-normal distribution characteristics in the data.

## Section: Methods › Reporting guideline compliance

This study was designed and reported following the Standards for Reporting Diagnostic Accuracy Studies (STARD 2015) guidelines to ensure transparent and comprehensive reporting. Since the STARD-AI is currently under development and not yet finalized,29 STARD 2015 represents the most appropriate available framework for evaluating AI-based drug-drug interaction screening.30 For this purpose, the artificial intelligence platforms (ChatGPT, Gemini, and Microsoft Copilot) served as the evaluated index tests, while our drug-drug interaction classification dataset derived from conventional screening databases (Lexicomp, Medscape, and Drugs.com) served as the reference standard.

## Section: Results

The number of DDIs and their categorization identified with the conventional method.

Mean diagnostic performance metrics and comparative analysis of all AI platforms.

Radar graph visualizing the mean performance metrics of AI platforms.

## Section: Results › Identification of all DDIs using the conventional method

The UpToDate Lexicomp database reported 554 interactions, classified as follows: 14 labeled “Avoid combination”, 102 as “Consider therapy modification”, 347 as “Monitor therapy”, and 91 as “No action needed”. The Medscape drug interaction checker yielded 740 DDIs, comprising of 77 “Serious-Use alternative”, 450 “Monitor closely”, and 213 “Minor” interactions. The Drugs.com interaction checker identified 835 DDIs, including 168 “Major”, 598 “Moderate”, and 69 “Minor” interactions. We identified a total of 2129 DDI signals across the three conventional drug interaction screening databases, for all potential DDI severity categories and including duplicates. The number of DDIs identified with different categories and as a total number are shown in Table 2. Collectively, the conventional databases flagged 1756 clinically relevant DDIs that require professional intervention.

The number of DDIs and their categorization identified with the conventional method.

## Section: Results › Identification of clinically relevant DDIs and medication lists

There were substantial discrepancies among the three databases regarding the nomenclature and classification of DDIs. As described in the Methods section, we unified the interaction categories and identified DDIs that were consistently classified in the’Clinically relevant’ unified category across all three sources. After applying our unified categorization and matching process, we identified 204 DDIs classified as clinically relevant across 57 medication lists (reference standard). In case of the remaining 23 medication lists there was not a single drug-drug interaction with a consensus in the categorization of clinical relevance among the three selected conventional databases.

## Section: Results › Identification of clinically relevant DDIs using AI platforms

Using the 57 individual medication lists, we then assessed the drug interaction screening capabilities of the three AI platforms against our reference standard. The AI platforms collectively flagged a total of 3808 DDI signals that require intervention. ChatGPT flagged the fewest clinically relevant DDIs, with 439 interactions requiring intervention. Gemini flagged 1556, while Microsoft Copilot reported the highest number, flagging 1813 interactions.

## Section: Results › Performance evaluation of AI platforms

Besides the comparison of the number of clinically relevant DDI alerts in the different databases and platforms, we aimed to compare the performance of ChatGPT, Gemini and Copilot against the reference standard. Previous studies typically compared AI platforms to interaction databases based on drug-drug interaction pairs, not real-world medication lists (Supplement 2.). We calculated sensitivity, specificity, precision, and F1 score, along with the mean value of these metrics, to assess how effectively each AI platform identifies clinically relevant drug-drug interactions.

The Friedman test revealed significant differences among the models across all performance metrics (sensitivity, specificity, precision, F1 score), demonstrating that the models differ substantially in both individual and combined aspects of performance (p < 0.001). The results of performance evaluations are summarized in Table 3 and Fig. 1.

Assessment of performance evaluation (Table 3.) metrics and pairwise comparisons using the Wilcoxon signed-rank test revealed distinct strengths, limitations, and performance trade-off patterns across the three AI platforms, with potential implications for DDI screening clinical decision-making. For sensitivity, Gemini achieved the highest mean score (M = 0.6966), significantly outperforming both Copilot (M = 0.5863, p = 0.021) and ChatGPT (M = 0.4683, p < 0.001). This finding indicates that Gemini demonstrates superior capability in detecting actual drug interactions, correctly identifying approximately 20 % more clinically relevant DDIs than ChatGPT. ChatGPT demonstrated superior specificity (M = 0.8683), with significantly fewer false positives relative to true negatives than both Gemini (M = 0.5995, p < 0.001) and Copilot (M = 0.4295, p < 0.001). This high specificity indicates that ChatGPT correctly identifies approximately 87 % of non-interacting drug pairs as safe, compared with 60 % for Gemini and 43 % for Copilot. However, the dataset is highly imbalanced in the context of DDI screening, with an extreme number of true negative drug pairs and a relatively high number of false positive signals. Therefore, relying solely on specificity as a unique performance metric can be misleading, as it may overestimate the practical utility of the model. Although ChatGPT again outperformed the others (M = 0.1937) in terms of precision score, significantly exceeding Gemini (M = 0.1297, p = 0.002) and Copilot (M = 0.0738, p < 0.001), all three platforms demonstrated notably low precision scores, indicating that the majority of flagged interactions were false positives. For example, the 19 % precision of ChatGPT means that only approximately 1 in 5 warnings represents a true interaction, whereas Copilot's 7 % precision translates to approximately 13 false alarms for every detected DDI. This generally high false positive rate of AI platforms could lead to unnecessary alerts and clinical interventions. The F1 score balances both detection capability and warning accuracy. ChatGPT achieved the highest overall performance by F1 score (M = 0.2520), followed by Gemini (M = 0.1933, p = 0.015) and Copilot (M = 0.1153, p < 0.001). Our study results indicate suboptimal overall performance across all platforms and suggest that none of the evaluated AI systems achieve the balanced precision-sensitivity performance necessary for reliable clinical decision support in drug interaction screening. Such low F1 scores reflect the inherent challenge of the highly imbalanced nature of drug interaction detection, where clinically relevant interactions represent a small fraction of all possible drug combinations.

Mean diagnostic performance metrics and comparative analysis of all AI platforms.

Radar graph visualizing the mean performance metrics of AI platforms.

## Section: Discussion

The potential impact of AI in healthcare is significant, especially in the area of clinical decision support, patient safety, DDI identification and prediction, and pharmacovigilance.31 The ability of AI-based solutions to analyze large, complex datasets, and detect patterns that humans might overlook is a key advantage for the assessment of DDIs.8,32,33

Our study builds upon this emerging evidence by systematically evaluating performance metrics across LLMs using real-world patient medication lists rather than isolated drug pairs and hypothetical patient profiles, which is a more clinically relevant approach that gives a better representation of real-world performance of these mainstream AI chatbots.

Our results show that while these chatbots can identify drug interactions in patients taking multiple medications, their performance varies widely with profound clinical implications. The higher sensitivity of Gemini makes it more suitable for safety-critical screening where missing interactions could have severe consequences, though its lower specificity may overwhelm clinicians with false alerts. Conversely, precision and F1 scores were uniformly poor across all AI platforms, indicating that current mainstream AI platforms are not yet ready, nor highly reliable for drug interaction screening in clinical practice. In particular, much higher precision is essential to minimize false positives, prevent alert fatigue and maintain clinical workflow efficiency.

Comparing studies on AI chatbot performance specific to DDI detection is challenging due to heterogeneous methods and outcome measurement.31 Seventeen such studies have been published over the last few years, highlighting a growing but still limited body of research in this area.4,8, 9, 10, 11, 12,14,15,18, 19, 20.,34, 35, 36, 37, 38, 39. These publications consistently demonstrate that the accuracy of LLMs can vary significantly. While some studies have shown that AI platforms can identify most interactions, they also generate a considerable number of false positives. For instance, Sicard et al. found that ChatGPT and Claude achieved approximately 99 % sensitivity for known adverse drug reaction-associated DDIs, yet their specificity remained low (between 0.64 and 0.68), leading to frequent misclassification of negative controls as interactions.39 Similarly, a 2024 study showed that ChatGPT-4.0 outperformed ChatGPT-3.5 in terms of overall accuracy but still exhibited low sensitivity. These findings, summarized in the Supplementary material (Table S1), underscore the need for further optimization of AI models before they can reliably support clinical pharmacy decision-making.10,11

It is important to note that the use of real medication lists, standardized drug pairs, or fixed drug pairs can affect the results. Radha Krishnan et al.'s 2024 study found that ChatGPT 3.5 exhibited a sensitivity of 24 % or less when given real patient profiles.10 In our study, ChatGPT demonstrated a sensitivity of 47 % when evaluating 57 real patient medication regimens, which is notably lower than the 91.5 % observed with professional curated lists.4 Other studies have also found higher sensitivity on simple benchmarks than on clinical profiles (see Supplementary File 2).

However, AI platform performance varied not only in complex scenarios with multiple medications, but also when assessing controlled drug-pairs. Al-Ashwal et al. (2023) found that ChatGPT 3.5 achieved an accuracy of only 47 %, compared to 79 % for Bing/Copilot. Meanwhile, Aksoyalp and Erdoğan (2024) reported sensitivities and specificities of 91 % and 97 % respectively, for ChatGPT 3.5 on 78 clopidogrel-specific DDIs. Overall, the literature echoes the cautious tone of our study. Currently, no LLM matches the performance of clinical DDI screenings, even when sensitivity is adequate, precision remains poor and hallucinations occur. These limitations are largely due to the fact that LLMs and AI chatbots were not specifically designed and trained for healthcare applications. They were trained to acquire general reasoning abilities based on publicly available data, which means they lack curated, context-specific knowledgebase required for reliable clinical decision-making.6,40,41 Furthermore, these models can introduce new errors through hallucinations. A striking example from Bischof et al. analysis occurred when ChatGPT falsely classified a magnesium supplement as an antacid, leading it to incorrectly conclude it affects the absorption of the immunosuppressant mycophenolate mofetil. Similar to some databases, LLMs can also struggle with APIs and drug classes, incorrectly attributing the specific characteristics of a single drug (e.g., a specific statin) to its entire therapeutic drug class.15 These examples again highlight the need for professional oversight over AI tools used in clinical context.39,42, 43, 44

DDIs are a well-recognized cause of adverse drug events and analyzing them has become increasingly complex. This complexity is due to the vast number of available drugs and supplements, the rise of specialty medications (like targeted therapies and monoclonal antibodies, orphan drugs), the growing prevalence of polypharmacy and multimorbidity in an ageing population,45 and the inherent limitations of current screening tools.46 Previously we found that Drugs.com performed better for targeted therapy drug-drug interactions, while UptoDate Lexicomp identified more drug-supplement interactions.3,25., 26, 27 Other key limitations of conventional DDI screening include incomplete coverage of all commercially available health products and their APIs, ineffective handling of synonyms, and lack of visualizing features for interaction networks to identify core medicines that could be substituted to non-interacting alternatives, thereby preventing severe complications during polypharmacy.3,47,48

While LLM-based chatbots like ChatGPT show potential to enhance decision-making processes by overcoming some of the barriers existing in nowadays DDIs screening (e.g. nomenclature issues, product availability issues, etc.), and even offering user-friendly explanations or simplifying complex interactions, significant risks remain. Our findings support this caution. The lack of continuous, real-time updates and formal clinical validation means that over-reliance on AI chatbots without pharmacist consultation can lead to serious drug related problems, especially when evaluating complex cases or scenarios.4,7,10,18

## Section: Discussion › Strengths and limitations

Our research has several strengths, including the use of real-world patient data and a large sample size to represent clinical practice. By selecting multiple AI platforms and focusing objectively on clinically relevant potential DDIs, our study contributes to previous literature in this field. However, several limitations must be acknowledged. We did not include data on the effects of potential DDIs on patients and did not perform a holistic assessment of the standardized medication lists. We did not perform supplement-drug interaction screening, as our methodology required potential DDIs to be present in multiple databases, a criterion that conventional drug interaction screening databases often fail to meet. The generalizability of our results is limited by specific cases and the choice of LLMs. As drug interaction literature and AI technologies evolve rapidly, our cross-sectional study provides only a snapshot of LLM performance at the time of investigation.

## Section: Conclusion

LLMs show significant promise as complementary tools for DDI screening, particularly in managing varying drug nomenclature and synonyms, areas where traditional standard database screening platforms often struggle. Our findings demonstrate that LLMs are effective at identifying true drug interactions, however, several limitations prevent their adoption in everyday clinical application for screening potential. Most importantly, LLMs frequently generate clinically inaccurate information due to hallucinations, which could create patient safety risks. Additionally, AI chatbots may fail to identify clinically relevant potential DDIs, resulting in critical errors and inconsistencies in the outcomes. Moreover, the use of AI with patient information requires careful consideration of data ethics, patient privacy, and management of inaccurate and hallucinatory responses.10,42, 43, 44 Evaluating the performance of LLMs as DDI tools remains challenging when studies use inconsistent methods and metrics, leading to methodological and interpretation biases. To improve comparability, we recommend using real-world medication-use data, interactions verified by multiple sources, standardized severity categories, and balanced metrics like the F1 score that account for both sensitivity and precision. Further research with standardized methodologies and comparable outcome metrics is needed to validate AI chatbots in controlled clinical settings to establish appropriate frameworks for using these technologies for polypharmacy management. Until these validations are achieved, mainstream AI platforms should be considered only as novel experimental tools that require supervision and fact-checking using established standard databases and cannot replace the clinical judgment of pharmacists and healthcare professionals.

## Section: CRediT authorship contribution statement

Bálint Márk Domián: Conceptualization, Data curation, Formal analysis, Investigation, Methodology, Validation, Visualization, Writing – original draft, Writing – review & editing. Amir Reza Ashraf: Conceptualization, Methodology, Writing – original draft, Writing – review & editing. András Tamás Fittler: Conceptualization, Funding acquisition, Methodology, Writing – original draft, Writing – review & editing. Mátyás Káplár: Methodology. Róbert György Vida: Conceptualization, Data curation, Formal analysis, Investigation, Methodology, Project administration, Supervision, Validation, Visualization, Writing – original draft, Writing – review & editing.

## Section: Ethical compliance

Not applicable/Not required for this study. All information collected from this study was from the public domain and the study did not involve any interaction with users.

## Section: Funding

The research was supported by the Hungarian Scientific Research Fund (grant NKFI-ID 143684).

## Section: Declaration of competing interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## Section: Acknowledgments

This research was conducted to evaluate responses generated by various large language models. Accordingly, this article and its supplementary files contain responses and content generated by these models. The authors have used Trinka AI (Enago) for minor language editing purposes (grammar, spelling, wording). Trinka AI did not modify the manuscript's scientific content or interpret the study's data, analyses, or conclusions. All authors reviewed and approved the final manuscript. Authors reports no conflict of interest associated with this manuscript.

## Section: Supplementary data

Supplementary material 1

Supplementary material 2

## Section: Data availability

The datasets generated or analyzed during this study are available from the corresponding author upon reasonable request.

## Section: Associated Data

Supplementary material 1

Supplementary material 2

## Section: Associated Data › Supplementary Materials

Supplementary material 1

Supplementary material 2

## Section: Associated Data › Data Availability Statement

The datasets generated or analyzed during this study are available from the corresponding author upon reasonable request.


---

# Comparison of Artificial Intelligence Models and Human Experts in Managing Dyslipidemia: Assessment of Adherence to Clinical Guidelines

- **Authors:** Mete Ucdal, Karya Yurtsever, Pinar Yildiz, Aysen Akalin, Kadir Ugur Mert, Gulay S Guven
- **Issuer:** Cureus
- **Type:** Scientific article
- **Published:** 2025-08-31
- **Language:** en
- **DOI:** 10.7759/cureus.91363
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40904968/
- **Licence:** CC-BY

## Section: Abstract

AbstractObjectiveThe objective of this study is to compare guideline adherence between artificial intelligence (AI) models (Claude-3 (Anthropic, San Francisco, CA), DeepSeek-V2 (DeepSeek, Hangzhou, China), GPT-4 (OpenAI, San Francisco, CA)) and human experts in dyslipidemia management using standardized clinical scenarios based on 2019 European Society of Cardiology (ESC)/European Atherosclerosis Society (EAS) and 2021 ESC prevention guidelines. The study employed a comprehensive evaluation framework to capture the holistic nature of dyslipidemia management across multiple interconnected domains.MethodsThirty fictitious but clinically representative cases were developed by lipid specialists across five domains: cardiovascular risk assessment, lipid management, lifestyle modifications, pharmacotherapy, and special populations. This broad scope was deliberately chosen to evaluate the full complexity of integrated cardiovascular risk management as it occurs in clinical practice. Cases included all variables required for objective guideline application. AI models and clinicians (professors, specialists, residents) provided management recommendations. A blinded assessment paradigm was employed to minimize potential evaluation bias, with evaluators scoring responses using alphanumeric coding to prevent source identification bias. Responses were assessed using standardized rubrics (0-3 scales) for four equally-weighted parameters: accuracy (guideline concordance), comprehensiveness (clinical coverage), applicability (implementation feasibility), and efficacy (simulated low-density lipoprotein cholesterol (LDL-C) target attainment). Composite scores were calculated by summing all parameters (maximum 12 points).ResultsCorrect response rates were 91% for AI, 72% for professors, 50% for specialists, and 21-32% for residents. Composite scores (mean ± SD/12) were 10.3 ± 1.0 for AI, 8.1-9.2 for professors, 7.4 ± 1.5 for specialists, and 5.2-6.2 for residents. AI excelled in literal guideline application while professors considered contextual factors (frailty, life expectancy). Professors primarily erred in LDL-C targets (using <100 vs. <55 mg/dL), while AI in nuanced risk stratification. Simulated outcomes showed LDL-C target attainment of 83% with AI, 64% with professors, and 92% with a combined approach.ConclusionAI demonstrated superior guideline adherence in standardized scenarios but may miss contextual clinical factors. The hybrid AI-human approach optimized outcomes, suggesting that augmented intelligence represents the most promising implementation strategy. Limitations include simulated cases (n = 30), potential performance bias favoring literal interpretation, and lack of real-world complexity. Prospective clinical validation is warranted.Keywords: artificial intelligence, cardiovascular risk assessment, clinical guidelines, dyslipidemia, lipid management

## Section: Introduction

Cardiovascular diseases remain the leading cause of death worldwide, with dyslipidemia being a major modifiable risk factor. Evidence-based management of lipid disorders is critical for both the primary and secondary prevention of atherosclerotic cardiovascular disease (ASCVD). Over the past decade, clinical guidelines have evolved substantially in their recommendations for cardiovascular risk stratification and lipid-lowering strategies. The 2019 European Society of Cardiology (ESC) and European Atherosclerosis Society (EAS) Guidelines for the Management of Dyslipidemias introduced key paradigm shifts in risk assessment and therapeutic targets, which were further refined in the 2021 ESC Guidelines on Cardiovascular Disease Prevention in Clinical Practice [1,2].

These guidelines provide comprehensive frameworks to assist clinicians in assessing cardiovascular risk, setting appropriate lipid targets, and implementing therapeutic interventions. However, the growing complexity of recommendations, coupled with the increasing volume of clinical data, has made consistent application in daily practice challenging. Studies have demonstrated significant variability in guideline adherence across clinical settings and levels of expertise, from junior residents (PGY-1) to full professors, which may potentially impact patient outcomes [3].

At the same time, artificial intelligence (AI) technologies have emerged as potentially transformative tools in healthcare delivery. In particular, large language models (LLMs) have demonstrated remarkable capabilities in processing and synthesizing vast amounts of medical information, offering promise as clinical decision-support systems. These models could assist clinicians by delivering evidence-based recommendations, standardizing care approaches, and reducing cognitive load in complex decision-making processes [4].

This study addresses a critical gap in the literature: while prior research has evaluated AI performance on isolated medical tasks, no study to date has conducted a structured, domain-specific comparison of multiple AI models and clinicians across the full spectrum of dyslipidemia management using standardized clinical cases. To represent the current state of medical AI capabilities, we selected three state-of-the-art models: GPT-4 (OpenAI, San Francisco, CA), widely adopted in clinical research; Claude-3 (Anthropic, San Francisco, CA), noted for its advanced reasoning abilities; and DeepSeek-V2 (DeepSeek, Hangzhou, China), an open-source alternative.

Dyslipidemia management offers an ideal domain for such comparative assessment due to its algorithmic framework, quantitative parameters, and clearly defined outcome measures. We acknowledge key methodological considerations that may influence AI-human comparisons, including the potential advantage of AI in precise guideline recall versus the strength of human experts in contextual clinical reasoning, as well as the possibility that AI training data may already encompass the evaluated guidelines. Nonetheless, the clinical implications warrant investigation: improved adherence to guidelines could translate into substantial reductions in cardiovascular events, as every 1 mmol/L decrease in low-density lipoprotein cholesterol (LDL-C) has been associated with an approximate 22% relative risk reduction in major vascular events [5-6].

Accordingly, this study aims to systematically evaluate the performance of these three AI models in managing standardized dyslipidemia cases, benchmarked against clinicians at different levels of expertise (junior residents, senior residents, board-certified specialists, and professors in cardiology, internal medicine, and endocrinology). Guideline adherence will be assessed across five key domains of the 2019 ESC/EAS and 2021 ESC guidelines: cardiovascular risk assessment, lipid management, non-pharmacological interventions, pharmacological treatment, and management in special populations. Through this comparative analysis, we seek to clarify both the capabilities and limitations of AI tools in supporting evidence-based dyslipidemia management, with the ultimate goal of understanding how these technologies might enhance clinical decision-making and improve patient outcomes.

## Section: Materials and methods

Study design

A controlled comparative evaluation protocol was employed to assess and compare the clinical reasoning capabilities of AI models with those of human clinical experts in the management of dyslipidemia. To minimize potential evaluation bias and ensure objective comparison between AI-generated and clinician-generated recommendations, a comprehensive blinded assessment paradigm was implemented using alphanumeric coding. This methodological framework was designed to capture the multidimensional nature of dyslipidemia management in real-world clinical practice, recognizing that effective patient care requires the simultaneous evaluation of multiple interrelated clinical domains.

Development and validation of clinical case scenarios

Case Development Process

Thirty hypothetical yet clinically representative case scenarios were developed by a panel of three lipid specialists, each with over 10 years of clinical experience in dyslipidemia management at the Preventive Cardiology Unit of our institution. Case development followed a structured three-stage process. Initially, each specialist independently drafted 10-12 cases reflecting typical scenarios from their practice. This was followed by collective review and refinement sessions to ensure adequate diversity across age groups, cardiovascular risk categories, and levels of clinical complexity. Final validation confirmed that each case contained all clinical information necessary for guideline-based decision-making. The complete case set comprised 140 sub-questions (mean 4.7 per case; range 3-6), designed to comprehensively evaluate distinct aspects of dyslipidemia management.

Case Validation

Validation employed a Delphi consensus methodology involving three independent experts - a general internist, a cardiologist, and an endocrinologist - who had no role in subsequent study phases. Through iterative review rounds, the panel confirmed that each case incorporated all variables required for the objective application of ESC guidelines. These included complete demographic data, comprehensive cardiovascular risk factors, full lipid profiles (total cholesterol, LDL-C, HDL-C, triglycerides, non-HDL-C, and apolipoprotein B when clinically indicated), as well as cardiovascular disease status, renal function parameters, liver enzyme levels, and documentation of all concomitant medications.

Case Stratification

To ensure balanced distribution across clinical domains, stratified randomization was performed using the SPSS v27.0 (IBM SPSS Statistics for Windows, IBM Corp., Armonk, NY) Random Case Generator module. Each of the five domains contained six cases: two of low complexity, two of moderate complexity, and two of high complexity. Clinical complexity was operationally defined by three criteria: (i) number of comorbidities (0-1 = low, 2-3 = moderate, >3 = high); (ii) presence of clinically significant drug-drug interactions requiring therapeutic adjustments; and (iii) need for personalized treatment approaches beyond standard guideline recommendations.

Clinical Domains

The 30 cases were systematically distributed into five domains:

Cardiovascular risk assessment (six cases): SCORE2 for patients <70 years, SCORE2-OP for ≥70 years, advanced imaging for subclinical atherosclerosis, and clinical diagnosis of familial hypercholesterolemia.

Lipid and lipoprotein management (six cases): LDL-C treatment targets, non-HDL-C optimization, apolipoprotein B analysis, and management of severe hypertriglyceridemia.

Lifestyle modification interventions (six cases): Mediterranean diet adherence, physical activity targeting ≥150 minutes/week of moderate intensity, structured smoking cessation programs, and weight management with 5-10% reduction goals.

Pharmacological treatment strategies (six cases): statin selection and intensity optimization, combination therapy, and positioning of PCSK9 inhibitors.

Special patient populations (six cases): patients with diabetes, chronic kidney disease (stages 3-5), post-acute coronary syndrome, frailty in older adults, and hepatic dysfunction.

Study participants

Human Participants

Six clinicians representing varying levels of expertise participated. The cardiology professor had >15 years of preventive cardiology experience and a substantial publication record in lipid management. The internal medicine professor had >15 years of clinical practice and served as director of the institutional lipid clinic. The endocrinology professor had >15 years of experience, particularly in diabetic dyslipidemia. The internal medicine specialist was a board-certified physician with five to 10 years of post-residency experience. The senior resident (PGY-3) was in the final year of internal medicine training, while the junior resident (PGY-1) was in the first year.

AI Models

Three state-of-the-art AI models were selected to represent current capabilities in medical reasoning. Claude-3 Opus (version 2024.01) was included for its advanced reasoning capacity and nuanced handling of complex medical scenarios. GPT-4 (version 0613) was chosen for its widespread adoption and demonstrated performance in clinical reasoning tasks. DeepSeek-V2 (7-billion parameter, version 2.0) was included as an open-source alternative for comparison with proprietary models. All participants, human and AI alike, evaluated the complete set of 30 cases. AI models were queried in January 2024 using standardized prompts under default settings (temperature = 0.7), without explicit reference to guidelines, in order to evaluate intrinsic reasoning capabilities.

Evaluation framework

Blinding Protocol

To ensure impartial evaluation, a comprehensive blinding protocol was implemented. All responses, whether from AI models or human clinicians, were anonymized and assigned alphanumeric codes ranging from A1-A30 to I1-I30. Formatting and structural features were standardized to prevent identification based on writing style. Evaluators were entirely independent of the six clinician participants, and they were not informed of the distribution or proportion of AI versus human responses. The response-source key was securely stored and revealed only after all scoring was completed and the database was locked.

Evaluation Panel

The independent evaluation panel comprised four senior physicians who had no involvement in response generation. Three professors, one each in cardiology, internal medicine, and endocrinology, all with >15 years of experience, served as primary raters. A fourth professor functioned as supervisory evaluator, ensuring strict adherence to protocol, resolving scoring uncertainties, and maintaining methodological consistency.

Evaluation Criteria

A standardized checklist, based on the 2019 ESC/EAS Dyslipidemia Guidelines and the 2021 ESC Prevention Guidelines, was developed. Correct answers for all 140 sub-questions were pre-defined by consensus among three independent cardiologists uninvolved in response generation or evaluation.

LDL-C targets: <55 mg/dL for very high risk, <70 mg/dL for high risk, and <100 mg/dL for moderate risk.

Risk assessment: Appropriate use of SCORE2 (<70 years) and SCORE2-OP (≥70 years).

Statin therapy: Mandatory high-intensity treatment for very high-risk patients.

Therapeutic sequencing: Maximally tolerated statin → add 10 mg ezetimibe → PCSK9 inhibitor if required.

Special populations: Adjustments for chronic kidney disease, elderly patients, and pregnancy-related contraindications.

Scoring Domains

Each response was evaluated across four domains (0-3 scale each, maximum score = 12): Guideline Adherence Accuracy (0-3); Clinical Comprehensiveness (0-3); Practical Applicability (0-3); and Communication Effectiveness (0-3) [5-6].

Composite Scores

Composite scores were calculated by summing domain scores (range: 0-12). Responses were classified as follows: good: ≥10 points (≥83% of maximum); acceptable: 6-9 points (50-75%); and poor: ≤5 points (≤42%), representing critical errors with potential implications for patient safety.

Statistical analysis

Primary Analyses

Primary comparisons were conducted using one-way ANOVA. Significant ANOVA findings were followed by post-hoc testing: Tukey’s Honestly Significant Difference (HSD) was employed for pairwise comparisons, while Bonferroni correction was applied for non-ANOVA comparisons. Two-way repeated measures ANOVA was used to analyze domain × group interactions, examining how performance varied across clinical domains. Categorical variables (e.g., error types, response completion rates) were analyzed with chi-square tests.

Correlation and Advanced Analyses

Spearman’s rank correlation assessed associations between clinical experience and performance metrics. Pearson correlation was applied for continuous variables (e.g., years since graduation vs. performance), and point-biserial correlation for dichotomous-continuous relationships. Advanced analyses included ROC curve comparisons using the DeLong method, Levene’s test for homogeneity of variance, coefficient of variation for within-group consistency, and intraclass correlation coefficients (ICC) (2,1) for inter-rater reliability.

Reliability and Quality Control

Intra-rater reliability was assessed by re-evaluating 25% (35/140) of responses after two weeks. Cohen’s κ was 0.78 (95% CI: 0.69-0.87), indicating substantial agreement.

Multiple Comparison Adjustments

Given the number of statistical tests, appropriate corrections were applied. Bonferroni adjustment was used for planned comparisons, while exploratory analyses applied the Benjamini-Hochberg false discovery rate (q = 0.05). After correction across 45 comparisons, the critical p-value was 0.028.

Power Analysis and Software

Post-hoc power analysis (G*Power v3.1, Heinrich-Heine-Universität Düsseldorf, Düsseldorf, Germany) confirmed that the study achieved 0.82 power to detect large effect sizes (d > 0.8) between AI and human groups at α = 0.05. Power was limited (0.45) for medium effect sizes among human subgroups. Analyses were conducted using SPSS v27.0, with R v4.2.0 (R Foundation for Statistical Computing, Vienna, Austria) for advanced procedures. Effect sizes were reported as Cohen’s d (continuous) or Cramér’s V (categorical).

Sample Size Justification

The 30-case sample (six per domain) was determined primarily by practical considerations, including time constraints, resource availability, and participant workload. Although no formal a priori power calculation was performed, post-hoc analyses confirmed sufficient power to detect large effects. Limited power for medium effects among human subgroups is acknowledged as a limitation, warranting larger-scale validation in future research.

Supplementary Materials

To ensure transparency and reproducibility, extensive supplementary materials were prepared. Appendix A contains all 30 clinical cases with 140 associated questions, identically presented to all participants. Appendix B provides the detailed scoring rubric, specific criteria for each scoring level, and sample responses representing different quality categories.

## Section: Results

Dataset characteristics and response volume

The study evaluated 30 clinical dyslipidemia case scenarios containing a total of 140 sub-questions with a mean of 4.7 questions per case (range: 3-6). Nine participants evaluated this completely identical set, yielding 1,260 potential responses for comparative analysis. Actual responses totaled 1,120 due to differential completion rates among human participants. Post-hoc power analysis using G*Power 3.1 confirmed adequate statistical power of 0.82 for detecting large effect sizes (Cohen's d > 0.8) between AI and human groups at α = 0.05, though power was limited to 0.45 for detecting medium effect sizes between human subgroups.

Response completion rates and quality assessment

Response completion rates demonstrated a clear gradient corresponding to clinical experience levels, as detailed in Table 1. Among AI models, Claude-3 Opus achieved the highest completion rate at 139 out of 140 questions (99.3%), followed by GPT-4 with 138 out of 140 (98.6%), and DeepSeek-V2 with 137 out of 140 (97.9%). Human participants showed progressively lower completion rates correlating inversely with experience level. The cardiology professor completed 129 out of 140 questions (92.1%), while the internal medicine professor completed 109 (77.9%) and the endocrinology professor completed 112 (80.0%). The internal medicine specialist achieved 99 completions (70.7%), whereas residents showed markedly lower rates, with the senior resident completing 70 questions (50.0%) and the junior resident completing only 56 questions (40.0%) (Figure 1).

Statistical analysis of the data presented in Table 1 using one-way ANOVA revealed highly significant differences between groups (F(8,1251) = 23.8, p < 0.001). Bonferroni post-hoc comparisons confirmed that AI models significantly outperformed all human groups (p < 0.01), professors outperformed residents (p < 0.001), and specialists performed better than residents (p < 0.05). The effect sizes were substantial, with Cohen's d values of 2.14 for AI versus professors, 3.42 for AI versus specialists, and 4.78 for AI versus residents.

Correlation analyses

Spearman's rank correlation analysis revealed a strong positive association between experience level and correct responses (ρ = 0.84, p < 0.001). Pearson correlation demonstrated that case complexity was positively correlated with blank responses (r = 0.72, p < 0.001), while years since training showed a negative correlation with current guideline adherence among professors (r = -0.52, p < 0.05).

Assessment of guideline compliance

Table 2 presents the comprehensive response distribution across all participant groups. AI models achieved guideline compliance in 382 out of 420 responses (91.0%), significantly exceeding all human groups. Among professors, the cardiology professor achieved the highest accuracy with 115 out of 140 correct responses (82.1%), followed by the internal medicine professor with 96 correct (68.6%) and the endocrinology professor with 92 correct (65.7%). The specialist, senior resident, and junior resident showed progressively lower accuracy rates of 50.0%, 32.1%, and 21.4%, respectively.

Chi-square tests confirmed significant differences between AI models and all human groups (all p-values < 0.001 as shown in Table 2), with the magnitude of difference increasing as the experience level decreased.

Domain-specific performance analysis

Two-way repeated measures ANOVA revealed significant main effects for both Group (F(8,1251) = 89.4, p < 0.001) and Domain (F(4,5004) = 12.3, p < 0.001), with a significant Domain × Group interaction (F(32,5004) = 4.32, p < 0.001). Table 3 presents the individual AI model performance across different clinical domains, revealing specific strengths and weaknesses of each model.

As shown in Table 3, pairwise t-tests with Bonferroni adjustment confirmed that Claude-3 significantly outperformed DeepSeek-V2 in Risk Assessment (p < 0.001) and Special Populations (p = 0.002) domains.

Professor comparisons

Following significant one-way ANOVA results (F(2,347) = 12.4, p < 0.001), Tukey HSD post-hoc analysis revealed that the cardiology professor significantly outperformed both the internal medicine professor (mean difference = 0.8, p = 0.003) and the endocrinology professor (mean difference = 1.1, p < 0.001). No significant difference was found between the internal medicine and endocrinology professors (p = 0.42). Table 4 presents the comprehensive domain-specific performance across all participant groups.

The data in Table 4 demonstrate that while AI models generally outperformed human participants across most domains, the communication clarity domain showed convergence between AI and professors, with no significant difference detected (p = 0.31).

Variance and consistency analyses

Levene's test revealed significant variance heterogeneity between groups (F(8,1251) = 24.7, p < 0.001). Coefficient of variation analysis demonstrated that AI models showed the highest consistency (5.3%), with individual model values of 4.1% for Claude-3, 5.2% for GPT-4, and 6.5% for DeepSeek-V2. Professors showed moderate variability (14.2%), with the cardiology professor demonstrating the lowest variation (11.3%) compared to internal medicine (15.4%) and endocrinology professors (15.9%). The specialist showed 18.7% variation, while residents demonstrated the highest variability at 28.4%.

Error pattern analysis

Chi-square analysis of error patterns revealed significant differences in error type distribution across participant groups (χ² = 48.7, df = 12, p < 0.001, Cramér's V = 0.31). Table 5 presents the detailed breakdown of error types, showing that professors predominantly made wrong LDL-C target errors (58.3%), while residents primarily made risk miscalculation errors (58.8%).

The error pattern analysis presented in Table 5 reveals fundamental differences in the types of mistakes made by different expertise levels, with experienced clinicians more likely to use outdated LDL-C targets while less experienced participants struggled with risk calculations.

Analysis of error types revealed distinct patterns across participant groups (χ² = 48.7, df = 12, p < 0.001). Among 25 errors made by AI models, 14 (56.0%) involved risk miscalculation, with eight specifically occurring in elderly female patients where SCORE2-OP was incorrectly applied. Human error patterns varied by experience: professors (n = 48 errors) predominantly selected incorrect LDL-C targets (28 errors, 58.3%), using outdated thresholds rather than current <55 mg/dL for very high-risk patients. Residents (n = 51 errors) primarily made risk calculation errors (30 errors, 58.8%), while specialists (n = 30 errors) showed mixed patterns with 60% wrong targets and 20% risk miscalculations. These systematic differences in error types across experience levels suggest opportunities for targeted educational interventions.

Receiver operating characteristic (ROC) analysis

ROC curve analysis demonstrated excellent discriminatory power of the composite scoring system with an overall AUC of 0.93 (95% CI: 0.91-0.95). Figure 2 illustrates the ROC curves for all participants, showing clear separation between AI models and human participants.

Multiple comparison corrections

After applying Bonferroni correction for 45 planned comparisons (adjusted α = 0.0011), all major group differences remained statistically significant. The Benjamini-Hochberg False Discovery Rate (FDR) correction with q = 0.05 yielded a critical p-value of 0.028, and all reported significant findings exceeded this threshold, confirming the robustness of the results.

Clinical impact simulation

To assess real-world implications, a simulation was conducted using recommendations for 12 very high-risk patients. AI-generated recommendations achieved an 83% target LDL-C attainment rate (<55 mg/dL), substantially higher than cardiology professors (64%), other professors (50-52%), specialists (43%), and residents (25-27%).

Of particular clinical significance, a combined workflow incorporating AI-generated draft recommendations with professor supervision yielded a simulated target attainment rate of 92%, exceeding the performance of any single respondent group and approaching the ideal clinical target of >90% guideline adherence.

One-way ANOVA (F = 23.8, p < 0.001); Bonferroni post-hoc analysis confirmed AI models significantly outperformed all human participant groups (p < 0.01).

HSD: Honestly Significant Difference

## Section: Discussion

Principal findings

The present study provides a comprehensive assessment of how AI models perform compared to human clinicians in managing dyslipidemia according to established clinical guidelines. Our findings demonstrate that AI models achieved significantly higher guideline compliance (91% correct responses) compared to professor-level clinicians (72%), specialists (50%), and residents (21-32%). However, this apparent superiority must be interpreted with extreme caution, as it likely reflects fundamental methodological limitations rather than genuine clinical reasoning superiority. Most critically, AI models may have encountered the 2019 ESC/EAS guidelines during their training phase, providing them with perfect recall of guideline content, while human participants were required to rely solely on memory without access to decision support tools routinely used in clinical practice.

Performance patterns and contributing factors

The observed performance differences between AI and human clinicians primarily reflect differential access to guideline information rather than superiority in clinical reasoning capabilities. While AI systems had guideline content embedded within their training data, enabling instantaneous recall, human clinicians in our study were denied access to the ESC/EAS guideline apps, SCORE2 risk calculators, and reference materials that are standard in contemporary practice [7]. This methodological choice created an artificial disadvantage that fundamentally misrepresents real-world clinical decision-making, where physicians regularly consult multiple decision support resources when managing complex cases.

Furthermore, our assessment format using structured written cases with predetermined "correct" answers inherently favored AI's algorithmic processing while disadvantaging human clinicians who excel at integrating subtle contextual cues, non-verbal information, and implicit knowledge. The theoretical cases were not pre-tested for ecological validity, potentially resulting in scenarios with clear-cut parameters and unambiguous decision points that favor algorithmic processing over the ambiguity and complexity characteristic of real-world encounters. Antiperovitch et al. demonstrated that LLMs consistently outperform clinicians in recalling specific guideline details, but this advantage in memorization should not be conflated with superior clinical judgment [8].

Our finding that professor-level clinicians most commonly erred in LDL-C target selection, often using older thresholds, may actually reflect thoughtful clinical judgment rather than knowledge deficits [9]. These apparent "errors" could represent appropriate consideration of patient-specific factors such as frailty, life expectancy, polypharmacy risks, and quality of life-nuanced decisions that our scoring system, by prioritizing strict guideline concordance, failed to recognize as potentially superior clinical reasoning.

The experience gradient observed among human participants, while consistent with previous findings by Johnson et al. [10] showing adherence rates of 67% for specialists versus 42% for generalists, must be contextualized within our study's limitations. The apparent performance gap might narrow or reverse in actual practice settings where dynamic patient interactions, evolving clinical information, and individualized risk-benefit assessments predominate [10].

Furthermore, Khosravi et al. in their meta-analysis of individual participant data demonstrated that risk-based treatment strategies require complex integration of multiple patient factors beyond simple threshold application, a nuanced approach where experienced clinicians outperformed algorithmic decision-making in 73% of cases requiring individualized care [11]. This finding aligns with Bittencourt et al., who showed that coronary artery calcium testing among statin candidates revealed discordances between guideline-based recommendations and personalized risk assessment in 38% of patients, situations where expert clinical judgment proved superior to strict algorithmic application [12].

Critical analysis of AI limitations and communication convergence

While AI models achieved high overall compliance rates, our error pattern analysis revealed concerning systematic weaknesses. The finding that 56% of AI errors involved risk miscalculation, particularly in elderly female patients, highlights the potential for systematic biases that could disproportionately affect vulnerable populations. These misclassifications underscore the critical need for mandatory human oversight, especially in high-risk subgroups where algorithmic errors could lead to inappropriate treatment intensification or undertreatment.

The convergence in communication clarity scores between AI and professors suggests that AI has reached current technological limits in replicating nuanced clinical communication, consistent with observations by Doraiswamy et al. [13]. While AI can generate grammatically correct responses, it lacks the contextual awareness and emotional intelligence necessary for truly patient-centered communication, particularly in sensitive discussions involving shared decision-making or complex trade-offs between treatment benefits and quality of life.

Current LLMs suffer from well-documented limitations, including "hallucination" (generating plausible but false information), overfitting to training patterns, and the inability to recognize their own knowledge boundaries. Of particular concern is their tendency to generate confident recommendations even when uncertain, potentially misleading clinicians who may defer to seemingly authoritative AI outputs.

Clinical implications and implementation challenges

The clinical impact simulation suggesting higher LDL-C target attainment with AI recommendations must be interpreted cautiously, given our study's methodological limitations. While Mach et al. demonstrated that each 1 mmol/L reduction in LDL-C correlates with a 22% reduction in major vascular events, translating our simulated findings to real-world outcomes requires consideration of multiple implementation barriers [14]. Similarly, Mortazavi et al. showed that although machine learning methods improved the prediction of heart failure readmissions compared with logistic regression, the overall gains in discrimination were modest, underscoring the gap between algorithmic performance and meaningful clinical impact [15]. The recent AHA/ACC/Multisociety Cholesterol Management Guideline update by Grundy et al. explicitly emphasizes that 'clinical judgment remains paramount in applying these recommendations to individual patients,' acknowledging that guidelines provide a framework but cannot replace the contextual decision-making that characterizes expert clinical care [16].

The finding that hybrid AI-professor workflows achieved 92% target attainment, while promising, faces substantial practical challenges. Workflow integration presents formidable obstacles, including increased time per patient encounter, potential for alert fatigue, unclear liability attribution when AI recommendations prove incorrect, and absence of appropriate reimbursement models. Critical legal and ethical considerations remain unaddressed, including requirements for informed consent when AI influences clinical decisions and regulatory frameworks for AI-involved adverse outcomes. These barriers, similar to those identified by Chanda et al. in dermatology, require systematic evaluation through prospective implementation studies before clinical adoption can be recommended [17].

Risk of over-reliance and clinical de-skilling

A critical concern inadequately addressed in current AI implementation discussions is the potential for automation bias - the tendency to uncritically accept computer-generated recommendations. As suggested by Singh et al.'s [18] framework for guideline implementation, dependence on AI for guideline interpretation could lead to atrophy of independent clinical reasoning skills, potentially creating clinicians unable to practice effectively when AI systems fail or encounter novel situations. Educational curricula must evolve to ensure clinicians maintain direct engagement with primary literature and practice independent decision-making alongside AI use [18].

Furthermore, both AI systems and human clinicians face distinct challenges in staying current with evolving guidelines. While AI models require periodic retraining involving significant computational resources and regulatory approval, the static models tested in our study cannot autonomously update when guidelines change. Human clinicians can immediately incorporate new evidence, though they may struggle with consistent implementation.

Methodological reflections and study limitations

Our evaluation framework, by prioritizing guideline concordance and structured responses, inherently favored algorithmic approaches while potentially penalizing adaptive, context-sensitive reasoning that characterizes clinical expertise [19]. Equal weighting of our four evaluation domains may not reflect their relative importance in actual practice, where the optimal balance between guideline adherence and individualized care varies by clinical context.

Several additional limitations warrant emphasis. First, we failed to account for real-world factors affecting human performance, including clinician fatigue, time constraints in busy clinical settings, and interruptions during decision-making. Human participants completed assessments under idealized conditions with unlimited time, likely overestimating real-world performance. Second, as Zhao et al. demonstrated in their comprehensive survey of evolving large language models, our assessment of only three AI models at a specific time point provides merely a snapshot of rapidly advancing technology [20]. Third, we did not assess crucial aspects of clinical care, including shared decision-making, rapport-building, and adaptation to patient values and preferences, which Wegner et al. identified as essential for optimal outcomes [21].

The lack of case pre-testing may have resulted in scenarios inadvertently structured to favor algorithmic processing rather than reflecting the ambiguity characteristic of real-world encounters. Our single-institution setting with academic physicians limits generalizability to community practice, where most dyslipidemia management occurs.

Future directions and research priorities

Future research must move beyond simple performance comparisons to examine the complex sociotechnical dynamics of AI integration. As championed by Topol, priorities should include (1) conducting randomized controlled trials to compare patient outcomes between AI-assisted and standard care-focusing on guideline target achievement and cardiovascular events; (2) evaluating AI performance in underrepresented populations where training data may be limited; (3) developing uncertainty quantification mechanisms to allow AI systems to express confidence levels; and (4) assessing AI’s capacity to adapt to patient values by incorporating preference-sensitive decision points [22,23].

Following recommendations by Aranda Rubio et al., targeted refinement of AI models should address specific error patterns identified in our study, most notably risk miscalculation in elderly patients, by incorporating strategies to mitigate age-related bias and ensure equitable performance across all age groups [24]. Research should examine optimal human-AI collaboration structures that maximize synergistic benefits while maintaining human agency and clinical expertise [21].

## Section: Conclusions

AI models demonstrated higher guideline concordance (91% vs. 72% for professors) and superior simulated LDL-C target attainment (83% vs. 66%) compared to human clinicians in standardized case scenarios. However, these findings derive from simulated data and may not translate directly into real-world practice, where patient interactions, contextual factors, and system-level constraints strongly influence decision-making. The observed “optimal performance” reflects strict guideline recall rather than comprehensive clinical outcomes such as patient satisfaction, quality of life, or event reduction.

Before clinical adoption, critical barriers - including liability attribution, ethical oversight, and safeguards against automation bias - must be addressed. Most importantly, AI should augment rather than replace clinical reasoning to prevent de-skilling. While hybrid AI-human workflows showed promising simulated results (92% target attainment), prospective validation in diverse, real-world populations is essential. Until such evidence exists, our findings should be interpreted as proof-of-concept that highlights the potential of AI as a supportive decision tool, not as a substitute for expert clinical care.

## Section: Appendices

Appendix A: Clinical case scenarios

Domain A. Cardiovascular Risk Assessment

Case 1. 65-year-old Male with Exertional Chest Pain

History: Civil engineer, 2-month history of exertional substernal chest pain (pressure-like, 5-10 minutes, relieved by rest) and palpitations. 35 pack-year smoker, hypertension ×3 years (on ramipril 5 mg/day, poor adherence). Father MI at 65, mother hypertensive. Poor diet (fast food), sedentary, weight gain +17 kg in 5 years. Physical Exam: Height 175 cm, weight 82 kg (BMI 27), waist 96 cm, BP 165/90 mmHg, HR 78 bpm. Normal cardiac/lung exam, pulses intact. Labs: TC 290, LDL-C 170, HDL-C 38, TG 185, FBG 105, HbA1c 5.9%, creatinine 0.9, AST 28, ALT 35. ECG: Normal sinus rhythm.

Questions:

How would you calculate cardiovascular risk?

According to the chosen risk chart, what is the risk category?

What lipid treatment and target would you recommend?

Case 2. 62-year-old Female with Carotid Plaques

History: Retired teacher, progressive neck pain ×6 months. Never smoked, no chronic disease. Menopause at 50, no HRT. FHx: uncle MI at 55. Physically active, Mediterranean diet. Exam: Height 165 cm, weight 65 kg (BMI 24), BP 125/75. Cervical tenderness, no carotid bruit, neuro exam normal. Labs: TC 240, LDL-C 165, HDL-C 55, TG 100, FBG 92. Imaging: Carotid Doppler-bilateral plaques (R 30%, L 25%), no hemodynamically significant stenosis.

Questions:

How do incidental carotid plaques affect CV risk classification?

In subclinical atherosclerosis, what is the risk category and LDL-C goal?

What is the appropriate treatment approach?

Case 3. 48-year-old Male with Strong Family History

History: Asymptomatic, attending pre-employment screening. Runs regularly, vegetarian ×10 years. FHx: father MI at 50, mother T2DM at 65. Exam: Height 178 cm, weight 80 kg (BMI 25), BP 130/80. Normal exam. Labs: TC 280, LDL-C 198, HDL-C 45, TG 150.

Questions:

How should familial hypercholesterolemia be evaluated in this patient?

Which diagnostic criteria (e.g., DLCN) apply, and what is his score?

What further testing and therapy are indicated?

Case 4. 50-year-old Male with Coronary Calcium Score 340

History: Bank executive, ex-smoker (15 pack-years, quit 5 yrs), no symptoms, sedentary, FHx: father stroke at 68. Exam: Height 175 cm, weight 80 kg (BMI 26), BP 125/75. Labs: TC 210, LDL-C 135, HDL-C 42, TG 165. Imaging: CAC 340 AU, stress test negative.

Questions:

What is the significance of CAC 340 in an asymptomatic patient?

How does CAC influence CV risk classification?

What is the risk category, LDL-C target, and therapy?

Case 5. 59-year-old Female with CKD

History: HTN ×8 yrs, CKD ×3 yrs (eGFR 45). On perindopril, amlodipine, furosemide. TAH-BSO 15 yrs ago. Exam: Height 160 cm, weight 76 kg (BMI 30), BP 150/90, +1 edema. Labs: TC 210, LDL-C 130, HDL-C 48, TG 160, creatinine 1.8, eGFR 45, proteinuria. Echo: EF 60%, concentric LVH.

Questions:

What is the risk category for CKD stage 3 (eGFR 45)?

What should the LDL-C target be, and how should statins be adjusted?

What are the effects of statins on renal function?

Case 6. 65-year-old Male Post-CABG with Muscle Symptoms

History: 3-vessel CAD → CABG 1 yr ago. On atorvastatin 40, ASA, metoprolol, ramipril. T2DM ×15 yrs. Quit smoking 20 yrs ago. Calf pain ×2 mo. Exam: Height 172 cm, weight 83 kg (BMI 28), BP 130/75. Sternotomy scar, calf tenderness. Labs: TC 155, LDL-C 85, HDL-C 40, TG 150, HbA1c 6.8%, CK 280 (N <200). ECG: Sinus rhythm, Q waves inferior. Echo: EF 50%, inferior wall hypokinesia.

Questions:

How should SAMS be evaluated in a post-CABG diabetic patient?

Is CK 280 U/L clinically significant?

Is treatment modification required?

How should SAMS be managed?

Domain B. Lipid and Lipoprotein Management

Case 7. 40-year-old Female with Severe Hypercholesterolemia

History: 40-year-old woman referred after very high cholesterol detected. No active cardiovascular complaints, occasional palpitations. No smoking/alcohol. Reports healthy diet and regular walking. FHx: father MI at 42, died at 45 of cardiac cause; grandmother MI at 50; sister with hypercholesterolemia. Two children; hyperlipidemia noted post-partum but untreated.

Exam: Height 165 cm, weight 62 kg (BMI 23), BP 120/70, HR 76. No tendon xanthomas, xanthelasma, or corneal arcus. Labs: TC 320, LDL-C 240, HDL-C 55, TG 125, FBG 90, HbA1c 5.4, TSH 2.5, AST 25, ALT 22, CK 110. Therapy Course: Rosuvastatin 40 mg started → LDL-C reduced to 160. Ezetimibe added → LDL-C 130. Imaging: Echo normal. Carotid US: increased IMT for age, no plaque.

Questions:

What is the likely diagnosis?

How should she be assessed for familial hypercholesterolemia?

What is her LDL-C target?

What therapy is indicated if statin + ezetimibe are insufficient?

Does she meet criteria for PCSK9 inhibitors? Should genetic testing be performed?

Case 8. 58-year-old Male with Diabetes and Prior MI

History: 12-year T2DM, diabetic nephropathy ×5 yrs, HTN ×10 yrs, NSTEMI 3 yrs ago → stent RCA. Current meds: insulin glargine, aspart, metformin, empagliflozin, ramipril, ASA, atorvastatin 20. Reports poor adherence to diet/exercise, walks dog only. Neuropathy symptoms ×3 mo.

Exam: Height 170 cm, weight 90 kg (BMI 31), waist 104 cm, BP 135/85, mild edema, neuropathy on monofilament. Labs: TC 195, LDL-C 120, HDL-C 35, TG 200, Non-HDL-C 160, ApoB 130, FBG 146, HbA1c 7.5, creatinine 1.9, eGFR 35, urine albumin/Cr ratio 500 mg/g. Imaging: ECG-old Q waves inferior. Echo-EF 55%, inferior hypokinesia, LVH.

Questions:

What is his CV risk category?

What should be the LDL-C, Non-HDL-C, and ApoB targets?

What is the clinical significance of ApoB measurement here?

What must be considered in statin use with renal impairment?

How should statin choice/dosing be adjusted in CKD?

Case 9. 70-year-old Female with Peripheral Artery Disease

History: PAD diagnosed 2 yrs ago (bilateral femoral stenosis 60-70%). HTN ×10 yrs, T2DM ×5 yrs. Current therapy: rosuvastatin 40, ASA, cilostazol, metformin, perindopril. Non-smoker. Limited walking distance (100-150 m, claudication).

Exam: Height 160 cm, weight 66 (BMI 26), BP 140/80. Peripheral pulses weak, capillary refill delayed. Labs: TC 170, LDL-C 95, HDL-C 45, TG 150, HbA1c 6.5, eGFR 58, Lp(a) 210 (N<30). Imaging: ABI R 0.75, L 0.72. Doppler: bilateral femoral stenosis 60-70%. ECG: Non-specific ST-T changes. Echo: EF 60%, mild diastolic dysfunction.

Questions:

What is her CV risk category?

With LDL-C 95 on high-intensity statin, has she met targets?

What is the significance of elevated Lp(a)?

What treatment adjustments are needed?

Does she qualify for PCSK9 inhibitors?

Case 10. 45-year-old Male with Metabolic Syndrome

History: Financial consultant, sedentary lifestyle, gained 15 kg in 5 yrs. Waist ↑, BMI 29. Works long hours, poor diet (fast food). Occasional alcohol, non-smoker. Family hx: mother diabetes. Complains of fatigue, poor sleep.

Exam: Height 175 cm, weight 89 (BMI 29), waist 102 cm, BP 135/85. Suspected hepatomegaly. Labs: TC 200, LDL-C 110, HDL-C 32, TG 350, OGTT 2h 165, HbA1c 6.1, insulin 25, HOMA-IR 6.9, AST 45, ALT 70. Imaging: US-grade 2 steatosis. ECG: Normal.

Questions:

How should dyslipidemia be managed in metabolic syndrome?

What is his CV risk category?

How should hypertriglyceridemia and low HDL-C be treated?

Is statin therapy safe in MASLD?

Beyond lifestyle changes, what drugs are options?

Indications for fibrates/omega-3?

Case 11. 52-year-old Male with STEMI

History: Presented with severe chest pain ×2h. ST-elevation anterior MI, underwent primary PCI (LAD stent). Smoker ×25 yrs, poor diet. FHx: father MI at 58. Exam: Height 178, weight 92 (BMI 29). Hypotensive (90/60), tachycardic 110. Labs: Troponin I 10.5, CK-MB 35, TC 230, LDL-C 150, HDL-C 35, TG 225, HbA1c 6.3. ECG: ST elevation V1-V4. Echo: EF 45%, severe anterior/apical hypokinesia.

Questions:

Should lipid-lowering therapy be started acutely?

Which statin and dose?

What is the LDL-C goal?

How should follow-up be structured?

When to consider combination therapy post-ACS?

Case 12. 61-year-old Female with Elevated LFTs on Statin

History: HTN ×10 yrs, hypothyroidism ×5 yrs. On valsartan, levothyroxine, and atorvastatin 20 started 6 months ago. Adherent. Now with fatigue, nausea. 35-pack-year smoker. FHx: sister MI at 55. Exam: Height 162, weight 70 (BMI 26.7), BP 135/85. Mild RUQ tenderness. Labs (baseline): TC 260, LDL-C 180, HDL-C 45, TG 175, AST 25, ALT 30. Labs (after 3 mo statin): TC 180, LDL-C 110, HDL-C 48, TG 110, AST 120, ALT 150, GGT 70. ECG: Normal. Echo: EF 60%, LVH.

Questions:

How should statin-related liver enzyme elevations be managed?

How should LFTs be monitored during statin therapy?

If ALT >3× ULN, what is the approach?

Should statin be stopped, dose reduced, or changed?

Domain C. Lifestyle Modifications

Case 13. 50-year-old Postmenopausal Woman with Obesity and Dyslipidemia

History: 50-year-old female, menopausal ×1 year with 8 kg weight gain. Reports hot flashes, insomnia, occasional palpitations. Profession: lawyer, high stress, poor diet (excess carbs), no regular exercise. FHx: father underwent CABG at 70, mother diabetic. No smoking/alcohol.

Exam: Height 162 cm, weight 81 kg (BMI 31, obese), waist 92, hip 105, BP 130/80, HR 84. Labs: TC 235, LDL-C 145, HDL-C 50, TG 180, FBG 100, HbA1c 5.8, OGTT 135, insulin 15, HOMA-IR 3.7, TSH 3.5. Imaging: ECG nonspecific ST-T changes. Echo normal.

Questions:

What is her CV risk category?

What lifestyle interventions are recommended?

How does diet modification affect lipid parameters?

How do Mediterranean & DASH diets influence lipid profile?

What is the expected effect of weight loss on dyslipidemia?

How long should lifestyle changes be tried before drugs?

Case 14. 57-year-old Male with Hypertension, Dyslipidemia, Smoking, and MASH

History: 57-year-old businessman, sedentary lifestyle, 35-pack-year smoker, daily alcohol intake, highly stressful job. Complaints: exertional dyspnea, fatigue. FHx: father MI at 65.

Exam: Height 175, weight 92 (BMI 30), waist 106, BP 150/95. Heart: S4, 2/6 systolic murmur. Lungs: basal crackles. Abdomen: hepatomegaly 2-3 cm below costal margin. Labs: TC 240, LDL-C 160, HDL-C 35, TG 225, HbA1c 6.0, ALT 65, AST 50, GGT 85. Imaging: US-grade 2 steatosis. ECG-LVH. Echo-EF 55%, LVH, grade 1 diastolic dysfunction.

Questions:

How to calculate his CV risk?

What are the effects of smoking on lipid profile and CV risk?

What strategies should be used for smoking cessation?

After quitting, how soon do lipid benefits occur?

What is the role of alcohol restriction in MASH?

After how long of lifestyle modification should pharmacologic therapy be considered?

Case 15. 63-year-old Male with Hypertension, Dyslipidemia, and Poor Diet

History: Retired teacher with hypertension ×10 yrs. Sedentary, diet rich in refined carbs, red meat, pastries, little fruit/vegetables. FHx: brother MI at 67, mother died of stroke at 78. Never smoked, rare alcohol.

Exam: Height 172, weight 83 (BMI 28), waist 100, BP 140/85. Heart: 2/6 systolic murmur. Labs: TC 250, LDL-C 170, HDL-C 40, TG 200, HbA1c 6.0. Imaging: ECG-LVH. Echo-EF 60%, LVH, grade 1 diastolic dysfunction, mild aortic sclerosis.

Questions:

What is his CV risk category?

How should diet be modified (fats, cholesterol, carbs, fiber)?

What are expected benefits of Mediterranean diet?

Are lifestyle changes sufficient or is drug therapy needed?

Case 16. 38-year-old Female with FHx of Premature CAD, Hyperlipidemia, and Statin Hesitancy

History: Banker, no active symptoms, FHx: father MI at 49, died at 52; mother stented at 45. Vegetarian diet, pilates ×2/week. Hypothyroidism ×3 yrs (on levothyroxine). Refuses statins due to fear of side effects.

Exam: Height 168, weight 63 (BMI 22), waist 78, BP 120/75. Labs: TC 245, LDL-C 165, HDL-C 52, TG 140, HbA1c 5.3. Imaging: ECG normal. Echo EF 65%. Carotid US-normal IMT, no plaque.

Questions:

What is the efficacy and limitation of lifestyle interventions here?

How much LDL-C reduction is expected with lifestyle alone?

What is the evidence for nutraceuticals (plant sterols, red yeast rice)?

How should clinical approach be structured given her statin refusal?

Case 17. 47-year-old Male with Hypertriglyceridemic Acute Pancreatitis

History: 47-year-old restaurateur admitted with severe epigastric pain radiating to back. Labs: lipase 1200, amylase 800, TG 980. Alcohol intake daily, fast-food diet, weight gain. FHx: father hypercholesterolemia.

Exam: Height 180, weight 95 (BMI 29), waist 104, BP 145/90, HR 100, T 37.8°C. Abdomen: epigastric tenderness, no peritonism. Labs: TC 310, HDL-C 35, TG 980, HbA1c 6.5, ALT 120, AST 85, CRP 65. Imaging: CT-edematous pancreatitis, peripancreatic fluid, no necrosis.

Questions:

How should hypertriglyceridemic pancreatitis be managed acutely?

Which therapies rapidly reduce triglycerides?

What is the long-term lipid management strategy after recovery?

What is the role of omega-3 and fibrates in TG lowering?

Do statins reduce TG significantly?

What lifestyle modifications are required?

Domain D. Pharmacological Therapy

Case 18. 68-year-old Male with Statin-Associated Muscle Symptoms

History: 68-year-old male, stable angina, PCI with stent 5 years ago. Hypertension ×20 yrs, T2DM ×10 yrs. On atorvastatin 20 mg, aspirin, metoprolol, perindopril, metformin. Complains of diffuse muscle pain (thighs, calves) for 2 months, worsening with exertion. Stopped statin 2 weeks ago → partial improvement. Former smoker, no alcohol. Exam: Height 170 cm, weight 78 (BMI 27), BP 135/80, HR 65. Mild muscle tenderness in thighs. Labs: On statin: LDL-C 95, CK 220 (N<200). After statin stopped: LDL-C 115, CK 180. Imaging: ECG sinus 65, echo EF 55% with mild inferior hypokinesia.

Questions:

What should be the alternative pharmacological approach in statin intolerance?

How should statin-associated muscle symptoms (SAMS) be defined and managed?

What is the management if muscle symptoms occur without significant CK elevation?

Which alternative lipid-lowering drugs/combinations can be used to reach LDL-C targets?

Case 19. 60-year-old Female with Diabetes, Stroke, and Persistent LDL Elevation

History: 15-year T2DM, HTN ×10 yrs, ischemic stroke ×5 yrs ago. On rosuvastatin 20, ezetimibe 10, aspirin, clopidogrel, metformin, dapagliflozin, perindopril. Despite max statin + ezetimibe, LDL-C remains above target. Limited exercise due to osteoarthritis. Exam: Height 158, weight 75 (BMI 30), BP 145/85. Labs: TC 180, LDL-C 90, HDL-C 42, TG 240, Non-HDL-C 138, ApoB 100, HbA1c 7.8. Imaging: Carotid Doppler-bilateral plaques 30-40%. Echo EF 60%.

Questions:

What is her CV risk category and how would you calculate it?

What are her target LDL-C, Non-HDL-C, and ApoB values?

Does she meet criteria for PCSK9 inhibitor therapy?

What is the mechanism, efficacy, and indication of PCSK9 inhibitors?

Case 20. 72-year-old Male with Ischemic Stroke and Statin Refusal

History: Ischemic stroke 2 months ago, residual left-sided weakness. HTN ×20 yrs, prostate cancer (post-prostatectomy), no statin use due to fear of side effects (memory, diabetes). 40 pack-year smoker, quit after stroke. On telmisartan, HCT, aspirin, clopidogrel. Exam: Height 175, weight 80 (BMI 26), BP 145/90. Mild hemiparesis. Labs: TC 255, LDL-C 170, HDL-C 42, TG 215, HbA1c 5.9. Imaging: Brain MRI-subacute infarct. Carotid Doppler-60% R ICA stenosis. Echo EF 60%.

Questions:

What is his CV risk and LDL-C target?

What is the role of statins in secondary prevention after stroke?

Should high- or moderate-intensity statins be chosen?

How effective and safe are statins in elderly patients?

How should physicians address patient reluctance/refusal of statins?

Case 21. 54-year-old Postmenopausal Woman with Mixed Dyslipidemia

History: Menopause 3 yrs ago, HTN ×10 yrs, hypothyroidism ×5 yrs. Complaints: atypical chest pain, palpitations. No smoking, rare alcohol. On levothyroxine, valsartan. FHx: mother MI at 65. Exam: Height 162, weight 75 (BMI 28.6), BP 140/85. Labs: TC 265, LDL-C 145, HDL-C 40, TG 280, HbA1c 5.8. Imaging: Stress test negative. Echo EF 65%.

Questions:

What is her CV risk category?

What are treatment goals in combined dyslipidemia?

What is the efficacy and risk of statin-fibrate combination therapy?

Which statin-fibrate combinations are safer?

What are the roles of statins, fibrates, and omega-3 fatty acids?

What is the importance of lifestyle modification in this case?

Case 22. 49-year-old Male with Severe Hypercholesterolemia

History: Engineer, asymptomatic, FHx: father MI at 45, brother stent at 47. Diet poor, irregular lifestyle. No smoking, occasional alcohol. Exam: Height 180, weight 85 (BMI 26), BP 130/80. No xanthomas or corneal arcus. Labs: TC 310, LDL-C 230, HDL-C 45, TG 175, Lp(a) 40 (N<30). Imaging: ECG normal, echo EF 65%. Carotid US-IMT 0.9 mm, no plaque.

Questions:

How should FH be evaluated with LDL >190 mg/dL?

According to DLCN criteria, what is the FH probability?

What is the treatment approach in primary hypercholesterolemia?

How should drug choice, titration, and follow-up be structured?

Is genetic testing indicated? Should family screening be performed?

Case 23. 64-year-old Male with Statin-Induced Hepatotoxicity

History: CAD with stents ×3 yrs ago, HTN ×10 yrs, DM ×5 yrs. On rosuvastatin 10 mg, but LFT elevation noted, dose reduced to 5 mg. Persistent enzyme rise. No alcohol. Exam: Height 172, weight 82 (BMI 27.7), BP 135/80. Labs: On 10 mg: LDL-C 110, AST 85, ALT 120. On 5 mg: LDL-C 125, AST 100, ALT 150. US: hepatosteatosis grade 1-2. Imaging: ECG-T wave inversions. Echo EF 55%, mild anterior hypokinesia.

Questions:

How should statin-induced liver enzyme elevation be managed?

How is statin-related hepatotoxicity defined, classified, and treated?

What is the management when ALT >3× ULN?

Should statin be stopped, reduced, or switched?

What are alternative lipid-lowering options?

Domain E. Special Patient Groups

Case 24. 62-year-old Female with Diabetic Dyslipidemia and Target Organ Damage

History: 15-year history of type 2 diabetes mellitus with complications: retinopathy, nephropathy (microalbuminuria), and neuropathy. Hypertension ×10 yrs. On insulin glargine, insulin lispro, metformin, amlodipine, irbesartan. No smoking or alcohol. FHx: mother died at 70 from diabetes and CVD, father alive with CVD. Exam: Height 160 cm, weight 80 (BMI 31.2), waist 98 cm, BP 150/90, HR 84. 1+ edema in legs, neuropathy signs. Labs: TC 220, LDL-C 130, HDL-C 38, TG 260, HbA1c 8.2, eGFR 58, microalbuminuria 150 mg/g. Imaging: Echo EF 60% with concentric LVH, mild MR/AR. Carotid plaques 30-40%.

Questions:

How would you classify her CV risk given multiple target organ damage and 3 risk factors?

What are lipid targets and treatment approach in diabetic dyslipidemia?

Which statin and dose should be used initially?

When should combination therapy be considered?

How should triglycerides and HDL be managed in diabetic dyslipidemia?

Case 25. 70-year-old Male on Hemodialysis with Multimorbidity

History: T2DM ×20 yrs, HTN ×15 yrs, CKD ×5 yrs, on hemodialysis ×2 yrs. Prior NSTEMI and CABG ×3 yrs ago. Medications: aspirin, metoprolol, amlodipine, epoetin, phosphate binders, calcitriol. No smoking or alcohol. Exam: Height 170 cm, weight 65 (BMI 22.5), BP 120/70, HR 68. Sternotomy scar, AV fistula, 2+ leg edema. Labs: TC 200, LDL-C 125, HDL-C 35, TG 200, Cr 6.8, eGFR <15, PTH 480, Alb 3.4. Imaging: Echo EF 50%, LVH, inferior hypokinesia, moderate MR.

Questions:

Is statin therapy indicated in end-stage renal disease on hemodialysis?

What is the efficacy and safety of statins in CKD?

Do statins reduce CV events/mortality in dialysis patients?

Which statins can be used without dose adjustment in renal failure?

What drug interactions should be considered in dialysis patients?

Case 26. 58-year-old Male with Acute Coronary Syndrome and Dyslipidemia

History: Presents with chest pain ×2 hrs, diagnosed with NSTEMI. HTN ×10 yrs, T2DM ×5 yrs but nonadherent. Smoker ×25 yrs. Family history positive. On telmisartan, metformin irregularly. Exam: Height 175, weight 88 (BMI 28.7), BP 160/95, HR 95. S3 gallop, basal rales. Labs: Troponin I 8.5, CK-MB 28, TC 235, LDL-C 155, HDL-C 38, TG 210, HbA1c 8.5. Imaging: ECG ST depression V1-V4. Echo EF 45%, anterior wall hypokinesia. Angiography: LAD 90%, Cx 70%, RCA 50% → PCI with stents.

Questions:

What is the optimal early lipid-lowering therapy in ACS?

When should high-intensity statin be started and at what dose?

What are LDL-C goals post-ACS?

When should PCSK9 inhibitors be considered in ACS patients?

How should lipid profile be monitored after ACS?

Case 27. 52-year-old Female with Chronic Liver Disease and Dyslipidemia

History: Chronic hepatitis C → Child-Pugh A cirrhosis. Antiviral therapy completed, viral load negative. HTN ×10 yrs. On olmesartan. Occasional abdominal discomfort. No smoking or alcohol. FHx: mother MI at 68. Exam: Height 165, weight 70 (BMI 25.7), BP 130/80, HR 78. Mild hepatomegaly, no ascites. Labs: TC 220, LDL-C 140, HDL-C 45, TG 175, AST 55, ALT 65, ALP 110, GGT 90, Bilirubin 1.8, Albumin 3.6, INR 1.3, Plt 120k. Imaging: Abdominal US + Fibroscan consistent with cirrhosis (LS 16 kPa). Echo: EF 60%, mild MR.

Questions:

How should dyslipidemia be treated in patients with chronic liver disease?

Is statin therapy safe in compensated cirrhosis?

What are contraindications for statins in liver disease?

Which statins are safer in cirrhosis?

How should liver function be monitored during therapy?

What are non-statin lipid-lowering options in cirrhosis?

Case 28. 75-year-old Female with Stroke, CKD, and CAD

History: Prior ischemic stroke ×2 yrs ago, HTN ×25 yrs, T2DM ×15 yrs, CKD stage 3b, CAD with PCI ×5 yrs ago. Medications: aspirin, clopidogrel, ramipril, amlodipine, metoprolol, furosemide, metformin, insulin, levothyroxine, alendronate. No smoking or alcohol. Exam: Height 160, weight 62 (BMI 24.2), BP 145/85, HR 64. Residual mild right-hand weakness, 1+ edema. Labs: TC 210, LDL-C 135, HDL-C 40, TG 175, HbA1c 7.2, eGFR 45. Imaging: ECG bradycardia, LVH. Echo EF 55%, lateral hypokinesia, moderate MR. Carotid plaques 30-40%.

Questions:

What is her CV risk category given advanced age + multiple comorbidities?

What should her LDL-C target be?

How should lipid therapy be managed in elderly high-risk patients?

What is known about statin efficacy/safety in >75 yrs?

What drug-drug interactions should be considered in polypharmacy?

How should dose adjustment be done with CKD?

Case 29. 67-year-old Male Post-PCI on High-Intensity Statin

History: UA 3 months ago → PCI with stents in LAD and Cx. HTN ×10 yrs, T2DM ×5 yrs. On aspirin, ticagrelor, rosuvastatin 40, bisoprolol, perindopril, metformin. No smoking/alcohol. Exam: Height 170, weight 75 (BMI 26), BP 125/75, HR 62. Labs: TC 125, LDL-C 68, HDL-C 42, TG 120, HbA1c 6.5. Imaging: ECG old T wave inversions. Echo EF 55%, mild hypokinesia.

Questions:

Does LDL-C 68 mg/dL meet current very-high-risk targets?

What are LDL-C goals in very high-risk secondary prevention?

Should statin intensity be reduced if LDL <70?

What is the recommended duration of statin therapy in secondary prevention?

How should lipid follow-up be structured post-PCI?

Case 30. 55-year-old Male with HIV on ART and Dyslipidemia

History: HIV ×8 yrs, on ART with protease inhibitors (ritonavir, atazanavir) + integrase inhibitor (raltegravir). Hypertension ×5 yrs. No CVD. On losartan. Smoker ×15 yrs. No alcohol. Has lipodystrophy (facial lipoatrophy, central fat accumulation). Exam: Height 172, weight 78 (BMI 26.4), waist 94, BP 135/85, HR 80. Labs: TC 240, LDL-C 150, HDL-C 35, TG 250, HbA1c 5.9, HIV RNA undetectable, CD4 550. Imaging: ECG and echo normal.

Questions:

How should dyslipidemia be managed in HIV patients on ART?

What are ART-related effects on lipid profile?

Which statins are safe with protease inhibitors?

How should CV risk be assessed in HIV patients?

Are LDL-C targets different in this population?

Which statin and dose would be appropriate?

Appendix B: Standardized evaluation checklist and scoring rubrics

Section 1: Response Correctness Criteria

LDL-C Target Values (2019 ESC/EAS Guidelines)

Very High Risk: <55 mg/dL and ≥50% reduction from baseline

High Risk: <70 mg/dL and ≥50% reduction from baseline

Moderate Risk: <100 mg/dL

Low Risk: <115 mg/dL

Risk Assessment Tools

Age <70 years: SCORE2

Age ≥70 years: SCORE2-OP

Diabetes: SCORE2-Diabetes

Risk Categories

Very High Risk

Documented ASCVD

SCORE2/SCORE2-OP ≥10%

Diabetes with target organ damage or ≥3 major risk factors

eGFR <30 mL/min/1.73 m²

High Risk

SCORE2/SCORE2-OP 5-9.9%

Markedly elevated single risk factor (TC >310 mg/dL or LDL-C >190 mg/dL)

Diabetes without target organ damage, duration ≥10 years

eGFR 30-59 mL/min/1.73 m²

Section 2: Domain-Specific Scoring Rubrics

Domain 1: Guideline Compliance Accuracy (0-3 points)

3 (High Adherence): Correct risk category, appropriate LDL-C target, evidence-based therapeutic sequence, correct dosing

2 (Partial Compliance): Minor deviations, correct risk assessment but suboptimal targets, appropriate drugs but incorrect dosing

1 (Poor Compliance): Major deviations, incorrect stratification, inappropriate choices

0 (Critical Errors): Completely incorrect, risk of harm, fundamental misunderstanding

Domain 2: Clinical Comprehensiveness (0-3 points)

3 (Comprehensive): All relevant factors addressed, comorbidities/interactions considered, lifestyle advice included, patient-specific adjustments

2 (Adequate): Major aspects covered, minor omissions, some comorbidity consideration

1 (Incomplete): Important factors overlooked, limited patient context, missing key management steps

0 (Inadequate): No consideration of critical issues, oversimplified approach

Domain 3: Practical Implementation (0-3 points)

3 (Directly Applicable): Clear, actionable, with follow-up plan, considers resources, realistic timeline

2 (Mostly Applicable): Practical overall, needs small modifications, adequate follow-up

1 (Limited Applicability): Requires significant modification, unclear steps, weak guidance

0 (Impractical): Unrealistic, no implementation pathway

Domain 4: Communication Effectiveness (0-3 points)

3 (Optimal): Clear, logical, proper terminology, complete explanations, patient-centered when needed

2 (Good): Generally clear, minor structural issues, explanations adequate

1 (Suboptimal): Unclear/confusing, poorly organized, incomplete explanations

0 (Poor): Incomprehensible, contradictory, missing key information

Section 3: Composite Score Interpretation

Good Response: ≥10/12 points (≥83%)

Acceptable Response: 6-9/12 points (50-75%)

Critical Errors: ≤5/12 points (≤42%)

Section 4: Error Classification

Wrong LDL-C Target: Outdated or incorrect thresholds used

Risk Miscalculation: SCORE2/SCORE2-OP applied incorrectly

Wrong Drug Sequence: Skipping statin → ezetimibe → PCSK9i sequence

Dose Errors: Inappropriate statin intensity or dosing

Special Population Errors: Not adjusting for CKD, elderly, pregnancy, HIV therapy

Section 5: Expected Responses by Case Type

Very High-Risk Patients

LDL-C target: <55 mg/dL

High-intensity statin (atorvastatin 40-80 mg or rosuvastatin 20-40 mg)

Add ezetimibe if target unmet

Consider PCSK9 inhibitor if still above target

High-Risk Patients

LDL-C target: <70 mg/dL

High-intensity statin preferred

Combination therapy as needed

Special Populations

CKD: Dose adjustment for statins with renal clearance

Elderly >75 years: Start low, titrate, monitor

Pregnancy: Statins contraindicated

HIV on ART: Avoid simvastatin with protease inhibitors

Section 6: Standardized Prompts for AI Models

"Please provide comprehensive dyslipidemia management recommendations for the following clinical case, including cardiovascular risk assessment and category, specific lipid targets, lifestyle modification recommendations, pharmacological therapy selection and dosing, follow-up and monitoring plan. Base your recommendations on current ESC/EAS guidelines."


---

# Computational drug design in the artificial intelligence era: A systematic review of molecular representations, generative architectures, and performance assessment

- **Authors:** Karim Abbasi, Parvin Razzaghi, Ali Gharizadeh, Amin Ghareyazi, Abbas Dehnad, Hamid R Rabiee, Mohammad R K Mofrad
- **Issuer:** Pharmacological reviews
- **Type:** Scientific article
- **Published:** 2025-10-10
- **Language:** en
- **DOI:** 10.1016/j.pharmr.2025.100095
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41389438/
- **Licence:** CC-BY

## Section: Abstract

Generative drug design has emerged as a transformative approach in pharmaceutical research, leveraging deep learning models to create novel molecules with targeted properties. This systematic review analyzes the current landscape of computational approaches across 3 critical dimensions: molecular representation strategies (1-dimensional, 2-dimensional, and 3-dimensional), generative architectural frameworks (including variational autoencoders, generative adversarial networks, reinforcement learning systems, and diffusion models), and evaluation methodologies. We provide a comprehensive categorization of these approaches, critically assessing their relative advantages and limitations. Additionally, we examine the datasets driving development in this field and the metrics employed to evaluate model performance. Through structured analysis of these interconnected components, we identify significant research gaps and propose promising future directions for advancing artificial intelligence-driven drug discovery. This review offers researchers a unified framework for understanding the complex interplay between representation choices, generative mechanisms, and evaluation paradigms in computational drug design. SIGNIFICANCE STATEMENT: This review provides a unique framework for generative drug design by categorizing methods first by drug representation and then by generative model type. This novel taxonomy clarifies which models are best suited for specific molecular data types, offering practical guidance for researchers. We also critically discuss the advantages, disadvantages, key datasets, and evaluation metrics, delivering a comprehensive and actionable resource for the field.


---

# Computational toxicology in drug discovery: applications of artificial intelligence in ADMET and toxicity prediction

- **Authors:** Jiangyan Zhang, Haolin Li, Yuncong Zhang, Junyang Huang, Liping Ren, Chuantao Zhang, Quan Zou, Yang Zhang
- **Issuer:** Briefings in bioinformatics
- **Type:** Scientific article
- **Published:** 2025-08-31
- **Language:** en
- **DOI:** 10.1093/bib/bbaf533
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41052279/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractToxicity risk assessment plays a crucial role in determining the clinical success and market potential of drug candidates. Traditional animal-based testing is costly, time-consuming, and ethically controversial, which has led to the rapid development of computational toxicology. This review surveys over 20 ADMET prediction platforms, categorizing them into rule/statistical-based methods, machine learning (ML) methods, and graph-based methods. We also summarize major toxicological databases into four types: chemical toxicity, environmental toxicology, alternative toxicology, and biological toxin databases, highlighting their roles in model training and validation. Furthermore, we review recent advancements in ML and artificial intelligence (AI) applied to toxicity prediction, covering acute toxicity, organ-specific toxicities, and carcinogenicity. The field is transitioning from single-endpoint predictions to multi-endpoint joint modeling, incorporating multimodal features. We also explore the application of generative modeling techniques and interpretability frameworks to improve the accuracy and credibility of predictions. Additionally, we discuss the use of network toxicology in evaluating the safety of traditional Chinese medicines (TCMs) and the potential of large language models (LLMs) in literature mining, knowledge integration, and molecular toxicity prediction. Finally, we address current challenges, including data quality, model interpretability, and causal inference, and propose future directions such as multi-omics integration, interpretable AI models, and domain-specific LLMs, aiming to provide more efficient and precise technical support for preclinical toxicity assessments in drug development.

## Section: Introduction

Drug discovery and development constitute a complex system engineering endeavor that integrates scientific rigor, economic viability, and societal implications, where the primary challenge is balancing therapeutic efficacy and safety thresholds of candidate compounds [1]. It has been reported that ~30% of preclinical candidate compounds (PCCs) fail due to toxicity issues, making adverse toxicological reactions the leading cause of drug withdrawal from the market [2, 3]. This reality underscores the strategic importance of toxicity assessment within the drug development pipeline. Toxicological evaluation serves as a pivotal link between fundamental research and clinical translation, significantly influencing not only development timelines and cost control but also public health safety and optimal allocation of healthcare resources [4]. Consequently, establishing efficient, accurate toxicity prediction methodologies has emerged as a global technological imperative in innovative drug discovery.

Traditional toxicity assessment paradigms rely heavily on in vivo animal experiments, typically employing sequential toxicity tests (acute, subacute, and chronic toxicity assays) to characterize the risk profiles of candidate compounds [5]. This approach has extensive historical data, but it no longer meets modern ethical and efficiency standards. On one hand, animal experiments are hindered by uncertainties in cross-species extrapolation, protracted testing durations (typically 6–24 months), and extremely high costs per compound (often exceeding millions of dollars) [6]. On the other hand, the widespread adoption of the “3Rs principle” (replacement, reduction, and refinement) places significant ethical pressure on traditional animal-based methodologies [7]. These conflicting demands have spurred the rapid emergence of computational toxicology, which integrates quantum chemical calculations, molecular dynamics simulations, machine learning (ML) algorithms, and multi-omics datasets to develop mechanism-based predictive models, thereby shifting from an “experience-driven” to a “data-driven” evaluation paradigm [8–11].

The theoretical advances underpinning computational toxicology have arisen from a deeper understanding of the multiscale mechanisms driving toxicological effects. Modern toxicological research has elucidated that drug toxicity is essentially an emergent property stemming from multiscale interactions between small molecules and biological systems: at the molecular level, metabolic activation, covalent modifications, and off-target interactions serve as initial triggers of toxicity; at the cellular level, mitochondrial dysfunction, oxidative stress, and aberrant activation of cell-death pathways amplify toxic phenotypes; and at the systemic level, disruptions of inter-organ metabolic networks and disturbances in the immune microenvironment ultimately manifest as clinically observable pathological outcomes [12, 13]. This hierarchical progression of toxic mechanisms necessitates predictive models with comprehensive, multidimensional information integration capabilities.

Currently, computational methods such as quantitative structure–activity relationship (QSAR), molecular docking, and systems toxicology have achieved significant predictive accuracy in critical toxicity evaluations, including hepatotoxicity and cardiotoxicity. Under conditions of sufficient data availability, their predictive performance has approached or even surpassed that of traditional animal-based assays [14–16]. Meanwhile, the rapid advancement of artificial intelligence (AI) technologies has further enhanced the predictive capabilities of computational toxicology [17]. Deep learning algorithms, notably graph neural networks (GNNs), can automatically extract molecular structural features and identify latent relationships between molecular structures and toxicity profiles [18, 19]. Furthermore, transformer architectures effectively integrate multimodal data, including chemical structure, genomic perturbations, and pathological phenotypes into end-to-end predictive pipelines, significantly improving model generalization [20]. Concurrently, the collaborative evolution of large-scale toxicity databases and cloud computing platforms has made virtual screening of millions of compounds feasible, improving screening efficiency by two to three orders of magnitude relative to traditional experimental approaches [21].

Despite these notable advances, computational toxicology continues to face substantial challenges. Current toxicity datasets often exhibit uneven data quality, limited model interpretability, and insufficient coverage, particularly when predicting novel or structurally complex multitarget compounds, leading to suboptimal predictive accuracy [22]. To address these bottlenecks, increasing research efforts have adopted multilayered, multidimensional integrated approaches, combining experimental data with network pharmacology and systems biology to construct more accurate and comprehensive toxicity prediction frameworks. Additionally, integrating predictive tools deeply with clinical drug data is essential to accurately identify potential toxicity risks during early drug discovery stages, thus providing reliable decision-making support for subsequent clinical development [23–25].

Given these considerations, this review systematically examines recent advancements in bioinformatics methods and technologies for drug toxicity research, focusing on applications of ML/AI methods. We begin by introducing the ADMET (absorption, distribution, metabolism, excretion, and toxicity) prediction system and prevalent computational platforms. Subsequently, we discuss key features and application scenarios of existing toxicology databases, critically analyzing the strengths and limitations of various toxicity task prediction algorithms. Furthermore, we provide an overview of network toxicology and its applications in assessing the safety of complex therapeutics, such as traditional Chinese medicine (TCM) formulations, and outline emerging potentials of large language models (LLMs) in toxicological research. Collectively, this review aims to provide theoretical and practical guidance for toxicity assessments in drug discovery and to inform the design of preclinical research and early-stage clinical trials.

## Section: Artificial intelligence in ADMET research

The five parts of ADMET and their related endpoints.

The basic framework of ADMET prediction platforms.

Overview of ADMET Prediction Platforms

Classification of computational modeling approaches in ADMET prediction platform: rule/statistics based methods, ML based methods, and graph-based methods.

## Section: Artificial intelligence in ADMET research › Framework of ADMET prediction methods

Adverse pharmacokinetic properties pose a significant threat to human health and environmental safety, representing one of the leading causes of drug development failure. ~40% of preclinical candidate drugs fail due to insufficient ADMET profiles, while nearly 30% of marketed drugs are withdrawn due to unforeseen toxic reactions [26]. Early integration of ADMET factors into the evaluation of new chemical entities has been shown to significantly reduce attrition rates in drug discovery [27]. Therefore, it is crucial to predict and optimize the ADMET properties of candidate compounds in advance. ADMET evaluation encompasses the absorption, distribution, metabolism, excretion, and toxicity of drugs, providing a comprehensive assessment of their in vivo behavior and predicting their clinical efficacy and safety (Fig. 1).

Toxicity is a critical component of drug safety assessment, with potential adverse effects including neurotoxicity, organ toxicity, genotoxicity, carcinogenicity, and more [28]. Acute toxicity is typically assessed through in vivo metrics such as LD50 (median lethal dose) and in vitro endpoints like IGC50 (half-maximal inhibitory concentration). Hepatotoxicity, nephrotoxicity, and cardiotoxicity are common drug-induced toxicities. Hepatic damage is generally characterized by elevated alanine aminotransferase (ALT), aspartate aminotransferase (AST), and bilirubin levels, while nephrotoxicity can be detected in clinical or preclinical settings via serum creatinine and blood urea nitrogen measurements. Cardiotoxicity is associated with hERG channel inhibition, potentially leading to fatal arrhythmias [28]. Therefore, comprehensive toxicological evaluation integrating both in vitro and in vivo endpoints is essential for ensuring drug safety and minimizing clinical adverse reactions.

With the continuous advancements in ML/AI technologies, numerous ADMET prediction platforms based on these approaches have emerged. These platforms significantly enhance the efficiency of drug discovery and development, offering several key advantages. Firstly, they can rapidly process extensive datasets of chemical compounds, such as their molecular structures and physicochemical properties, substantially reducing experimental costs and time. Secondly, AI models can leverage large-scale historical ADMET data from previous experiments to deliver more accurate predictions. Lastly, these platforms facilitate drug performance analysis from multiple perspectives by simulating various physiological conditions and environmental factors, thereby enabling researchers to make more scientifically informed decisions.

The fundamental framework of an ADMET prediction platform constitutes a multilayered system encompassing the complete workflow from data input and model training to predictive output (Fig. 2). This framework uses robust computational methods, big data, and multidimensional information to improve prediction accuracy and reliability. Specifically, the ADMET prediction platform typically comprises the following critical components:

Input component: the input component forms the foundation for the platform’s operation. It requires comprehensive chemical structural data and related molecular information, including molecular formulas, molecular weights, and molecular structures. Additionally, extensive ADMET experimental data, such as drug bioavailability, hepatic metabolic stability, and clearance rates, must be integrated. Experimental datasets are not limited to static data but also encompass reaction data under various conditions (e.g. different pH levels, physiological states). Moreover, literature-derived data is indispensable, enabling researchers to enrich the platform’s databases with previously published datasets and experimental outcomes, thereby ensuring the reliability and generalizability of platform predictions.

Tools/methods component: this component is the core of the platform and consists of two main submodules:

Physicochemical property calculation module: utilizing chemoinformatics software packages such as RDKit and Scopy, this module computes basic physicochemical properties of chemical compounds, including molecular weight, pKa, log P, TPSA, and hydrogen bond acceptors/donors. These fundamental physicochemical properties provide preliminary predictive information for various ADMET characteristics, such as drug absorption, distribution, and metabolism. The calculated results typically serve as foundational features for ML models.

ML/AI prediction module: based on substantial experimental data and computational chemical information, ML algorithms (e.g. support vector machines (SVMs), random forests (RFs), neural networks, gradient boosting trees) are applied to predict various ADMET properties. These models can be classified into regression and classification types, depending on specific prediction tasks. Regression models predict continuous ADMET parameters, such as in vivo drug t1/2 (half-life), VDss (volume of distribution at steady state), CL (clearance), and MRT (mean residence time). In contrast, classification models predict discrete ADMET indicators, such as in vitro BBB (blood–brain barrier) permeability assays and in vitro HLM (human liver microsome) stability metrics. These classification models identify potential risks and features by training on extensive datasets that encompass both in vitro and in vivo data. Furthermore, ML/AI models continuously improve prediction performance through techniques like feature selection and hyperparameter optimization, ensuring the platform’s adaptability across different drug types and both in vitro and in vivo ADMET characteristics.

Output component: the output component represents the final form of the platform’s predictions, generally referred to as “endpoints” indicating the predictive values or classification results corresponding to each ADMET characteristic. The number and type of these endpoints vary among platforms. However, comprehensive ADMET prediction platforms can evaluate over 100 different endpoints, encompassing both in vitro properties (such as HLM stability and PPB) and in vivo pharmacokinetic parameters (such as bioavailability (F), half-life (t1/2), and renal clearance (CLr)). These results are presented through intuitive data visualization and reporting tools, enabling researchers to swiftly acquire both in vitro and in vivo drug ADMET characteristics to support informed decision-making. The platform outputs extend beyond single predictive values and incorporate physicochemical properties with predictive outcomes to offer deeper analyses, such as directions for drug optimization, potential side effects, and optimal routes of administration [29]. Additionally, some platforms facilitate comparisons between candidate drugs and other compounds, assisting developers in drug screening and optimization processes [30].

In summary, the fundamental architecture of ADMET prediction platforms constitutes an integrated and intelligent system providing robust support for drug research and development through efficient data input, precise computational tools, and powerful ML algorithms. These platforms not only enhance development efficiency and reduce experimental costs but also accurately predict drug safety and efficacy in early development stages, thereby establishing a solid scientific foundation for successful new drug discovery.

The five parts of ADMET and their related endpoints.

The basic framework of ADMET prediction platforms.

## Section: Artificial intelligence in ADMET research › Overview of ADMET prediction platforms

Nowadays, numerous computational tools have been developed to predict various ADMET-related properties, ranging from broad-spectrum platforms to tools specialized in specific aspects (Table 1 and Supplementary Table 1). Broad-spectrum platforms, such as admetSAR 3.0 [31], ADMETlab 3.0 [32], vNN-ADMET [33], and ADMETboost [34], provide comprehensive coverage across all five ADMET dimensions. By integrating multiple predictive models, these platforms offer systematic assessments of compounds in terms of ADMET. In contrast, platforms like Swiss ADME [30], FAF-Drugs4.0 [35], and ADMET-AI [36] focus specifically on pharmacokinetic properties, emphasizing predictions related to absorption, distribution, metabolism, and excretion. Additionally, certain platforms concentrate solely on toxicity prediction; e.g. ProTox 3.0 [37] and VenomPred 2.0 [38] are tailored for evaluating toxicity endpoints such as hepatotoxicity, carcinogenicity, and mutagenicity. Furthermore, tools like CypRules [39], BioTransformer 3.0 [40], XenoSite [41], SOMP [42], and SMARTCyp 3.0 [43] specifically address interactions with cytochrome P450 enzymes (CYPs), playing critical roles in drug metabolism studies.

According to the computational methodologies employed, existing ADMET prediction platforms can generally be classified into three categories: rule/statistical based methods, ML based methods, and graph-based methods (Fig. 3). Next, let’s briefly examine each category’s unique characteristics and their applications in ADMET prediction.

Overview of ADMET Prediction Platforms

Classification of computational modeling approaches in ADMET prediction platform: rule/statistics based methods, ML based methods, and graph-based methods.

## Section: Artificial intelligence in ADMET research › Overview of ADMET prediction platforms › Rule-based/statistical methods

Rule-based and statistical methods represent an earlier paradigm of ADMET prediction. These methods stand out due to their high computational efficiency and interpretability. They typically leverage chemical rule databases, experimental data, and statistical inference to perform rapid pharmacokinetic evaluations. For example, SMARTCyp 3.0 [43] and CypRules [39] specialize in predicting cytochrome P450 metabolism sites by combining chemical heuristics with quantum chemical computations, enabling quick identification of potential metabolism sites within a molecule [44]. Swiss ADME [30], as a comprehensive prediction tool, integrates physicochemical property calculations (e.g. log P, TPSA), drug-likeness rules (Lipinski, Veber rules), and structural toxicity alerts (such as PAINS), supplemented with SVM-optimized key endpoints (log S, blood–brain barrier permeability, P-gp substrate specificity), providing an intuitive and comprehensive ADMET evaluation for early-stage drug screening. The FAF-Drugs platform [35], currently in version 4.0, employs an approach that calculates physicochemical descriptors for input molecules, followed by preliminary screening based on predefined thresholds and rules (e.g. Lipinski’s rules). Subsequently, it uses SMARTS pattern matching to identify potentially toxic or undesirable structures, relying entirely on expert-driven methodologies rather than ML algorithms. Its notable strengths include simplicity, efficiency, ease of customization, and scalability for large-scale screening efforts. Additionally, probabilistic acm-pproaches have been explored; for instance, the SOMP [42] tool generates all possible Sites of Labeled Atoms (SoLAs) from the 2D molecular structure and characterizes them using LMNA descriptors based on molecular neighborhoods. It then applies a Bayesian probabilistic model to rank and predict likely metabolic sites, effectively utilizing early-stage structural information. However, these rule-based/statistical methods inherently depend heavily on established chemical rules and experimental data, often exhibiting limited predictive capability when encountering novel or structurally complex compounds.

## Section: Artificial intelligence in ADMET research › Overview of ADMET prediction platforms › Machine learning-based methods

ML-based methods leverage chemical descriptors and algorithms such as RF, SVM, k-Nearest Neighbors (k-NN), and Gradient Boosting Trees (GBT) to predict ADMET properties [45–48]. The primary strength of these approaches lies in their ability to discern complex patterns within large datasets, making them well-suited for handling diverse chemical spaces and structurally intricate molecules [49]. For example, vNN-ADMET [33] utilizes a variant of the k-NN approach, variable Nearest Neighbor (vNN) for pharmacokinetic predictions. ADMETboost [34] employs XGBoost, a gradient boosting tree-based ensemble algorithm optimized for structured data handling. Some platforms adopt combined or hybrid approaches tailored to specific prediction tasks; ProTox 3.0 [37], specialized in toxicity prediction, uses eight data-sampling methods alongside RF and deep neural networks (DNNs) to predict up to 61 distinct toxicity endpoints, including hepatotoxicity, carcinogenicity, and mutagenicity. AquaticTox [50], the first tool dedicated specifically to aquatic toxicity predictions, employs a stacked ensemble methodology comprising six ML models [RF, AdaBoost, Gradient Boosting, SVM, Fully Connected Networks (FCNs), and Graph Convolutional Neural Networks (GCNNs)]. VenomPred 2.0 [38] predicts multiple toxicity endpoints by combining three different chemical fingerprints (Morgan, RDKit, PubChem) with four distinct algorithms (RF, SVM, k-NN, Multilayer Perceptron (MLP)). Despite their substantial predictive capabilities, these ML methods are strongly reliant on high-quality training data, inadequate or biased training datasets may significantly impair performance. Furthermore, some models, particularly deep learning approaches, often lack interpretability regarding their underlying chemical rationale.

## Section: Artificial intelligence in ADMET research › Overview of ADMET prediction platforms › Graph-based methods

Graph-based computational methods represent a cutting-edge development in the ADMET prediction domain, characterized by their superior ability to deeply analyze molecular graph structures. By aggregating neighborhood information to update node representations, these deep learning models effectively capture complex relationships and structural features within molecules. Their primary advantage is superior performance in predicting complex molecular properties compared to traditional methods. For instance, pkCSM [51] introduced in 2015, represents molecules as molecular graphs, extracting interatomic distance and topological features using Graph-Based Signatures, subsequently leveraging these features for ML-based predictions of pharmacokinetic and toxicological properties. This approach offers significant flexibility and interpretability without relying on predefined structural fragments, providing a robust and accurate method for ADMET prediction.

With the proliferation of GNNs, several recent platforms have adopted these methodologies. ADMET-AI [36], e.g. applies the Chemprop-RDKit GNN model, representing molecules as graphs and learning atomic-level features through message-passing neural networks, which are further enriched with physicochemical properties calculated by RDKit. This approach has demonstrated outstanding performance across 41 ADMET datasets. Similarly, Interpretable-ADMET [52] employs GCNN and Graph Attention Networks (GATs), incorporating Grad-CAM to explain predictions by identifying molecular substructures most contributing to specific ADMET properties, thus achieving both accuracy and interpretability. Recent research efforts, such as HelixADMET [53], have begun leveraging self-supervised pretraining strategies for GNN models on large compound datasets, transferring the learned knowledge to specific ADMET prediction tasks, resulting in robust and scalable prediction systems. ADMETlab 3.0 [32] combines multitask Deep Message Passing Neural Networks (DMPNNs, a GNN variant) with molecular descriptors, first pretraining the model to obtain general molecular features, then fine-tuning for multiple ADMET tasks, significantly expanding its applicability and performance. AdmetSAR 3.0 [31] also incorporates pretrained GNN models to extract molecular features, subsequently fine-tuning for specific ADMET properties, achieving notable performance in chemical exploration, prediction, and optimization tasks. Nevertheless, these graph-based methods have notable computational complexities, particularly when dealing with large datasets, potentially requiring extensive computational resources during training and inference. Moreover, GNN-based methods typically necessitate substantial training datasets to reach optimal performance; insufficient data can lead to overfitting or degraded predictive accuracy.

In the drug discovery process, various ADMET prediction tools exhibit certain complementarity due to their differences in functional emphasis, algorithmic architectures, and coverage of prediction endpoints. For early-stage compound screening and preliminary evaluation of multiparameter ADMET properties, integrated platforms such as ADMETlab 3.0 [32], admetSAR 3.0 [31], and Deep-PK [58] offer certain advantages. These platforms generally cover multiple endpoints, including physicochemical properties, pharmacokinetic characteristics, and toxicity, thereby supporting large-scale systematic virtual screening. If the research focuses on toxicity assessment, tools such as ProTox 3.0 [37] (for general chemical toxicity) or VenomPred2.0 [38] (for peptide toxins) may be considered, as they often provide predictive models tailored to specific toxicity endpoints. For studies emphasizing prediction accuracy and model interpretability, tools based on ML algorithms such as GNNs, e.g. ADMETboost [34] and interpretable-ADMET [52] show promising potential. They not only deliver prediction results but also offer certain interpretative insights through methods like uncertainty estimation and atom contribution visualization. Furthermore, for specific subproblems in ADMET research, such as predicting compound metabolic pathways, BioTransformer 3.0 [40] may be more applicable, while SMARTCyp3.0 [43] could be considered for identifying CYP metabolic sites.

In summary, when selecting ADMET prediction tools, it is advisable to align the choice with specific research needs: integrated platforms are often used for high-throughput preliminary screening, specialized tools are more suitable for in-depth analysis of specific endpoints, and advanced algorithmic tools hold certain value in scenarios requiring higher prediction accuracy, robustness, and mechanistic interpretation.

## Section: Artificial intelligence in toxicological research

Four types of toxin databases: chemical toxicity databases, environmental toxicology databases, alternative toxicology databases, and biological toxin databases.

List of chemical toxicity databases

List of Environmental Toxicology Databases

List of Alternative Toxicology Databases

List of Biological Toxin Databases

Workflow for AI/machine learning–based drug toxicity prediction.

Methods for different Toxicity Prediction Tasks

## Section: Artificial intelligence in toxicological research › Toxicological databases

Toxicological databases represent fundamental platforms for integrating, storing, and disseminating toxicity-related information, which are indispensable for chemical safety assessment and drug discovery. Toxins are substances capable of causing cellular damage or diseases following exposure via inhalation, ingestion, or dermal contact. Their toxicity arises from complex interactions between their chemical structures and biological systems [59]. Efficient and systematic management of toxicological data not only provides timely and accurate risk assessment tools for researchers and regulatory authorities but also significantly reduces clinical trial failures and developmental costs [60]. According to data content and application context, toxicological databases can be classified into four major categories: chemical toxicity databases, environmental toxicology databases, alternative toxicology databases, and biological toxin databases. The classification scheme is illustrated in Fig. 4, and each category’s main features and representative platforms are detailed below.

Four types of toxin databases: chemical toxicity databases, environmental toxicology databases, alternative toxicology databases, and biological toxin databases.

List of chemical toxicity databases

List of Environmental Toxicology Databases

List of Alternative Toxicology Databases

List of Biological Toxin Databases

## Section: Artificial intelligence in toxicological research › Toxicological databases › Chemical toxicity databases

Chemical toxicity databases focus on elucidating the potential health hazards of various chemical compounds, especially pharmaceuticals, by aggregating multidimensional data such as cytotoxicity, hepatotoxicity, nephrotoxicity, teratogenicity, carcinogenicity, genotoxicity, and reproductive toxicity. These resources provide scientific support for early-stage risk assessment in drug development, enabling research teams to promptly identify safety issues, guide molecular optimization, dose selection, and inform clinical strategies. Representative databases and their key characteristics are summarized in Table 2. PubChem [61], ChEMBL [62], TOXRIC [63], DrugBank [64], SuperToxic [65], and CompTox Chemicals Dashboard [66] are comprehensive chemical toxicity databases. Specifically, PubChem [61], maintained by the National Library of Medicine (NLM) under the U.S. National Institutes of Health (NIH), consolidates chemical data from over 750 sources and freely disseminates them publicly. ChemIDplus [67], HSDB [68], and CCRIS, originally sub-databases of TOXNET, have now been integrated into PubChem. Among these, HSDB includes toxicological information of ~5600 chemicals, covering pharmacological properties, environmental fate, emergency handling, and occupational health data, and is widely utilized globally. ChEMBL [62], an open-source bioactivity database maintained by the European Bioinformatics Institute (EBI), part of the European Molecular Biology Laboratory (EMBL), provides extensive compound data tailored toward drug discovery and chemical biology research. Developed by the U.S. Environmental Protection Agency (EPA), the CompTox Chemicals Dashboard [66] collates extensive physicochemical, toxicity, and exposure data for numerous chemical substances, serving as a vital tool for environmental health research. TOXRIC [63] contains standardized toxicological attributes, molecular representations, practical benchmarks, and intuitive visualization interfaces for diverse chemical substances. SuperToxic [65] offers a comprehensive collection of toxic substances from diverse sources (animals, plants, synthetic origins, and etc.), enabling detailed investigations into correlations between their chemical, functional, and structural properties. DrugBank [64], another comprehensive resource, integrates extensive chemical, pharmacological, pharmacokinetic, side effect, and toxicological data widely utilized across drug research and toxicological studies. Specialized toxicity databases such as DILIrank [69], DILIst [70], LTKB [71], hERGCentral [72], and LCDB [73] focus specifically on hepatotoxicity, cardiotoxicity, or carcinogenicity. For instance, DILIrank [69], DILIst [70], and LTKB [71] provide critical insights into mechanisms and targets of drug-induced liver injury (DILI). The hERGCentral [72] database delivers extensive information on drug interactions with the hERG potassium channel, pivotal for cardiac toxicity assessment, while LCDB [73] provides robust carcinogenicity data from long-term experiments involving 1726 chemicals and 7745 experimental records.

List of chemical toxicity databases

## Section: Artificial intelligence in toxicological research › Toxicological databases › Environmental toxicology databases

Environmental toxicology databases comprehensively document chemical behavior in environmental matrices (e.g. water, soil, and atmosphere) and their potential impacts on ecosystems. Beyond recording acute and chronic toxicity effects on diverse organisms (algae, benthic organisms, fish, and birds), these databases include parameters like environmental persistence, bioaccumulation, and transformation, thus serving as foundational tools for ecological risk assessments, pollution control strategies, and ecosystem conservation. In drug discovery contexts, these databases facilitate environmental risk evaluation of candidate drugs and their metabolites, promote green chemistry design, and inform postmarketing environmental risk management. Representative databases are listed in Table 3. The ECOTOX database [81], comprising decades of published ecological toxicological test data, elucidates cumulative distribution patterns of species, chemicals, and biological effects, supporting ecological risk assessment and ecosystem management decisions. Additionally, TOXNET [82] is extensively employed in environmental health research. EnviroTox [83] enables users to explore ecotoxicity patterns based on modes of action, analyze organism-specific sensitivities within chemical groups, and assess relative taxonomic sensitivity. Databases like AquaticTox [50] specialize in aquatic organism toxicity data, providing critical insights into pollution impacts on aquatic ecosystems. Collectively, these databases not only advance the understanding of environmental pollutants but also encourage public engagement in environmental protection, laying a solid foundation for ongoing environmental toxicological research.

List of Environmental Toxicology Databases

## Section: Artificial intelligence in toxicological research › Toxicological databases › Alternative toxicology databases

As ethical and animal welfare concerns increasingly constrain traditional animal-based toxicity testing, alternative toxicology databases have emerged as valuable resources leveraging in vitro high-throughput screening (HTS), high-content imaging, computational toxicology models, and multi-omics techniques. These databases typically integrate genomic, transcriptomic, metabolomic, and proteomic data with systems biology and ML approaches, thereby offering efficient, reproducible, and scalable solutions for chemical toxicity assessments. Early-stage drug development benefits from rapid screening and optimization of candidate molecules based on cell viability, gene expression profiles, and receptor activation data, dramatically reducing animal experimentation, associated costs, and timelines [85]. Key platforms are summarized in Table 4. The Tox21 initiative [86], jointly spearheaded by the U.S. EPA, National Toxicology Program (NTP), and NIH, utilizes high-throughput methodologies to drive toxicity assessments towards mechanism-based approaches. Tox21 compiles and publicly shares extensive in vitro screening data involving thousands of compounds tested across multiple biological pathways, including nuclear receptor signaling and cellular stress responses, providing invaluable resources for understanding chemical-biological interactions. Similarly, Open TG-GATEs [87] stores comprehensive toxicogenomic profiles for 170 compounds across various dosages and time points from in vivo (rats) and in vitro (rat and human primary hepatocytes) studies. ToxicoDB [88] integrates toxicogenomic data from Open TG-GATEs [87], DrugMatrix [89] and EMEXP2458 [90], facilitating queries and analyses of gene expression and signaling pathway perturbations induced by potential toxicants. The Comparative Toxicogenomics Database (CTD) [91] further enhances understanding of human health by integrating chemical, genetic, disease, and exposure information. These resources accelerate the transition from traditional animal-based studies toward more efficient and precise in vitro and computational toxicology methods, enhancing both environmental and public health protection.

List of Alternative Toxicology Databases

## Section: Artificial intelligence in toxicological research › Toxicological databases › Biological toxin databases

Biological toxin databases (Table 5) specialize in collecting, annotating, and analyzing natural toxins derived from animals, plants, and microorganisms, playing a critical role in elucidating their toxicological mechanisms, pharmacological potential, and biodefense applications. These natural toxins exhibit distinctive bioactivities such as antihypertensive, analgesic, and antimicrobial effects, and some have transitioned into clinical or preclinical development [92] databases such as ToxinDB [93], the first comprehensive biological toxin database encompassing over 4836 toxins and associated molecular descriptors and ADMET properties, provide platforms for predicting toxin metabolites and developing detoxification enzymes. TPPT [94] catalogs 1586 plant toxins with ecological toxicological significance, providing extensive biological and chemical information, alongside computational property estimates. MycoCentral [95], with 904 mycotoxins and metabolites, integrates data on biosynthetic pathways, physicochemical properties, ADME predictions, and QSAR-derived medicinal chemistry parameters. ATDB [96] unifies structural and annotation data for animal toxins, standardizing functional annotations through a novel toxin ontology system. BioTD [92], the most comprehensive open-source biological toxin database to date, provides extensive annotations, sequence data, mutagenesis information, and biological activities derived from over 5220 publications and patents, spanning more than 900 species, underpinning toxin-based drug design and mechanistic studies.

List of Biological Toxin Databases

## Section: Artificial intelligence in toxicological research › Methodological workflow for drug toxicity prediction

In recent years, ML has garnered significant attention in the realm of computational drug toxicity prediction, establishing itself as a cutting-edge technique for toxicity assessment using computational models [23]. With the continuous expansion of large-scale toxicological databases and improvements in data quality, the predictive efficacy of ML models has seen substantial enhancement [101, 102]. The typical workflow for ML-driven drug toxicity prediction can be summarized into five core stages (Fig. 5) [3]:

(1) Data collection: integration of heterogeneous datasets from multiple sources, including molecular structural data (SMILES, InChI), in vitro assay outcomes (e.g. hERG inhibition activity, cytotoxicity), in vivo toxicological endpoints (e.g. LD50 values, organ pathological phenotypes), and clinical adverse drug reaction reports.

(2) Data preprocessing: this stage encompasses molecular feature engineering, such as generating molecular fingerprints (ECFP4, MACCS) and calculating physicochemical descriptors, data cleaning (removal of duplicate compounds and balancing positive/negative samples), and dimensionality reduction techniques like principal component analysis (PCA) and t-distributed stochastic neighbor embedding (t-SNE) [103]. For sparse datasets, methods such as transfer learning and generative adversarial networks (GANs) can be utilized to generate synthetic data to mitigate data insufficiency [104].

(3) Model construction and training: traditional ML methodologies mainly include RF and SVM, whereas deep learning models, such as graph convolutional networks (GCNs) and Transformers, have emerged prominently due to their capability for automatic hierarchical feature extraction [105, 106]. For instance, DNNs can simultaneously predict multiple toxicity endpoints through multitask learning frameworks, and GNNs effectively capture inter-atomic interactions via molecular graph representations [107].

(4) Model evaluation: common metrics for model evaluation include accuracy, area under the ROC curve (AUC), and the F1-score for classification tasks. In continuous regression tasks, commonly used evaluation metrics include mean absolute error (MAE), root mean square error (RMSE), and the coefficient of determination (R2). Cross-validation methods (e.g. 10-fold cross-validation) and external testing datasets are employed to assess generalizability. Interpretability techniques (e.g. SHAP and LIME) are often applied to identify key toxicity-related features, thus enhancing model transparency and credibility [108, 109]. In addition to understanding the model’s decision-making mechanism, practical applications also require attention to the model’s confidence scores, which quantify the model’s certainty in its individual predictions. This is particularly important in high-stakes decision-making scenarios that demand high reliability, such as medical diagnosis and autonomous driving. Common methods for generating confidence scores include probability-based approaches (e.g. leveraging the inherent probabilities from models like Logistic Regression, though these often require calibration via Platt Scaling or Isotonic Regression to be reliable), Bayesian methods for uncertainty quantification, specific ensemble learning techniques like Deep Ensembles which measure disagreement among multiple models to estimate certainty, uncertainty estimation techniques like Monte Carlo Dropout [110], as well as distance-based methods that assess the similarity of a new input to the training data. These techniques can be integrated into the decision-making process to ensure that predictions with low confidence are flagged for further human review or other appropriate safety measures, thereby enhancing the transparency and trustworthiness of the model [111].

(5) Algorithm Application: The resultant predictions can guide drug design, facilitate early-stage toxicity screening, and support regulatory decision-making processes. Specifically: (i) They guide drug design by allowing medicinal chemists to prioritize or deprioritize specific compound series based on predicted ADMET profiles, thus focusing synthesis efforts on leads with higher probabilities of success. (ii) They facilitate early-stage toxicity screening by serving as a rapid, cost-effective virtual triage tool, highlighting high-risk molecules for in vitro or in vivo experimental validation and reducing the reliance on animal testing in initial phases. (iii) They support regulatory decision-making by providing supplementary, evidence-based data that can be used to assess compound risk, potentially informing the design of further necessary clinical trials or contributing to the weight of evidence in a regulatory submission.

Workflow for AI/machine learning–based drug toxicity prediction.

## Section: Artificial intelligence in toxicological research › ML/AI applications across diverse toxicity prediction tasks

In recent years, the landscape of toxicity prediction has evolved significantly, encompassing a broad spectrum of endpoints, from acute toxicity to multi-organ damage, as well as chronic effects like carcinogenicity and genotoxicity [2, 3]. Acute toxicity assessments focus on immediate, life-threatening effects resulting from short-term, high-dose exposures. Organ-specific models delve into cardiotoxicity (e.g. in vitro hERG channel blockade assays), hepatotoxicity (DILI), nephrotoxicity (tubular damage), and neurotoxicity. Carcinogenicity studies consider both in vivo tumor induction and in vitro genotoxic endpoints, while genotoxicity analyses target molecular mechanisms such as mutagenesis, chromosomal aberrations, and DNA damage [2, 3].

This review highlights recent cutting-edge developments and representative achievements applying ML to predict these diverse toxicity endpoints, particularly acute toxicity, cardiotoxicity, hepatotoxicity, nephrotoxicity, and carcinogenicity, as well as innovative case studies from Tox21 challenges (see Table 6). It aims to provide a comprehensive overview of how methods such as multitask learning, GNNs, and generative models are shaping the future of toxicity screening.

Methods for different Toxicity Prediction Tasks

## Section: Artificial intelligence in toxicological research › ML/AI applications across diverse toxicity prediction tasks › Cardiotoxicity

In cardiotoxicity prediction, hERG, Cav1.2, and Nav1.5 are three key targets typically measured through in vitro assays. Historically, due to limited bioactivity data for the latter two targets, most research concentrated on hERG channel blockade prediction. In 2016, Wang et al. [112] combined naïve Bayes (NB) with SVM, selecting optimal pharmacophore subsets via recursive partitioning (RP), and integrated multiple pharmacophore features through ensemble learning, developing classification models with high accuracy. Their SVM model demonstrated excellent external test performance, elucidating complex hERG blocker interactions. In 2019, Cai et al. [113] introduced deephERG, a multitask DNN-based model trained on 7889 structurally diverse compounds, achieving highly accurate predictions by simultaneously learning chemical features and hERG inhibitory activity. In 2020, Ryu et al. [114] proposed DeepHIT, an end-to-end deep learning approach that transforms molecules into extended connectivity fingerprints (ECFP4) and graph representations, extracting global and local toxicological features using GCNs, optimized via binary cross-entropy loss. This approach effectively predicted hERG toxicity without traditional reliance on manual feature engineering. With accumulating data, researchers have extended their predictions to joint modeling of hERG, Nav1.5, and Cav1.2 channels. Issar et al. [115] developed CToxPred, systematically evaluating fingerprints, descriptors, and graph-based numerical representations within a deep-learning framework, significantly improving multitarget predictive capabilities. Additionally, Kyro et al. [116] developed CardioGenAI, which combines autoregressive Transformer generative models and discriminative deep-learning models. In a case study involving the high-affinity hERG inhibitor pimozide, their method generated candidate drug fluspirilene with over 700-fold reduction in hERG affinity, while preserving therapeutic activity. Collectively, current ML- and deep learning-based cardiotoxicity prediction methods have evolved from single-target models to comprehensive, multitarget, multifeature assessment systems, substantially enhancing prediction accuracy and generalizability. Future advancements in high-quality cross-target activity data and model interpretability techniques will drive cardiotoxicity prediction towards greater automation and precision. In practice, traditional ML approaches (e.g. SVM, ensemble learning) remain robust and interpretable for single-target predictions with limited data, whereas deep learning models (e.g. GCNs, Transformers) are more advantageous in multitarget modeling and large-scale compound screening due to their ability to capture complex molecular features.

## Section: Artificial intelligence in toxicological research › ML/AI applications across diverse toxicity prediction tasks › Hepatotoxicity

Prediction of drug-induced hepatotoxicity remains a critical bottleneck in drug development. Traditional serum biomarkers such as ALT and AST, which are measured in vivo, have limited sensitivity and specificity for detecting liver injury. Furthermore, discrepancies between in vitro assays and the complex in vivo metabolic environment, coupled with species-specific differences that limit the translational value of animal models, contribute significantly to the clinical failure of numerous drug candidates due to liver toxicity. Recent advancements in ML have markedly improved predictive accuracy by integrating multidimensional datasets. For instance, StackDILI [117] employs stacked ensemble learning to merge chemical structure and bioactivity data, effectively reducing bias inherent to single algorithms. InterDILI [118] combines permutation feature importance and attention mechanisms, achieving high prediction accuracy while identifying critical structural alerts, such as aniline derivatives, thereby providing explicit guidance for drug design. Additionally, pDILI_v1 [119] utilizes probabilistic modeling to analyze extensive drug-adverse reaction datasets, enabling automated extraction, and quantification of liver toxicity risk from unstructured text data. Notably, DILIPredictor [120] integrates nine toxicity endpoints, including mitochondrial toxicity and bile acid transporter inhibition, along with chemical structure, pharmacokinetic parameters, and surrogate toxicity data. Using a RF model, it delivers superior predictive performance, discriminates cross-species toxicities, and captures mechanisms far exceeding those of single-target models.

With the accumulation of toxicogenomics data, research has progressively shifted toward mechanism-based analyses rooted in gene expression and pathway perturbations. Jin et al. [121] proposed an entropy weight method (EWM) to quantify gene expression dispersion, facilitating the evaluation of pathway disruptions. This approach, combined with ML, effectively identifies key toxic pathways—such as ferroptosis during acetaminophen-induced liver injury—thus bridging predictive modeling with underlying biological processes. Moreover, in the realm of generative AI applications, the Tox-GAN model [122] leverages GANs to simulate drug-induced transcriptomic profiles, overcoming the limitations posed by limited experimental data availability. This innovative approach generates virtual toxicogenomic data, enabling the prediction of pathway activation patterns for unknown compounds, and thereby offering an efficient strategy for early-stage hepatotoxicity screening. Collectively, these advances are transitioning hepatotoxicity prediction from traditional single-marker assessments toward integrative mechanism-driven models that combine chemical structure, genomic signatures, and multi-omics data. Such efforts promise to accelerate the development of safer therapeutics and reduce toxicity-related clinical attrition. For practical applications, ensemble learning remains a reliable choice for integrating heterogeneous data sources, whereas mechanism-driven models leveraging toxicogenomics and generative approaches are particularly recommended when exploring novel compounds or elucidating underlying biological pathways.

## Section: Artificial intelligence in toxicological research › ML/AI applications across diverse toxicity prediction tasks › Nephrotoxicity

Nephrotoxicity is typically assessed in vivo by measuring blood urea nitrogen and serum creatinine. However, similar to hepatotoxicity, predicting nephrotoxicity faces two major challenges: the limited translatability of findings from animal models to humans, and the suboptimal specificity and accuracy of available biomarkers. Research in nephrotoxicity prediction has been comparatively less abundant compared to cardiotoxicity and hepatotoxicity studies. Shi et al. [123] compiled a real-world dataset comprising 565 compounds (287 nephrotoxic drugs and 278 non-nephrotoxic drugs). They developed predictive models utilizing five conventional ML methods (e.g. RF, Extreme Gradient Boosting (XGBoost)) and five deep learning algorithms, such as convolutional neural fingerprint networks (CNFNs). An ensemble of the top three individual models was further employed as a consensus predictor. Additionally, the study identified 87 structural alerts based on Klekota–Roth fingerprints (KRFP), calculating substructure frequency (f-score) and positivity rates. Among these alerts, 16 exhibited specificity for nephrotoxic drugs, offering mechanistic insights through structural signatures. Gong et al. [124] constructed a dataset consisting of 777 drugs, including 125 TCM components. They employed nine molecular fingerprints (e.g. Atom Pair, MACCS) combined with eight ML algorithms, generating a total of 72 classification models. Through 10-fold cross-validation and external validation, an optimal model, SVM combined with CDK graph fingerprints—demonstrated robust generalizability for both TCM-derived and chemically synthesized drugs. Following OECD guidelines, the applicability domain was rigorously evaluated, and SARpy and information-gain methods identified eight potential nephrotoxicity-related structural alerts, including fluorinated benzene rings and polyamine derivatives, thus providing critical structural warnings for drug safety considerations.

Mazumdar et al. [125] integrated deep learning and traditional ML methods, employing eight types of molecular fingerprints and RDKit descriptors to build 27 ML models and one DNN. Their DNN achieved optimal performance in five-fold cross-validation, whereas an Extra-tree model showed an accuracy of 82.1% on an independent test set. Innovatively, the study applied association rule mining, identifying 10 high-frequency substructures within nephrotoxic compounds, such as benzimidazole derivatives and fluorinated substituents, revealing that structural cooperativity significantly influences nephrotoxicity. Nguyen-Vo et al. [126] prioritized data quality optimization through meticulous data cleaning and class balancing, generating a dataset containing 604 positive and 228 negative samples. Utilizing eight algorithms (e.g. Extremely Randomized Trees (ERT), XGBoost) and three molecular representations (Mol2vec embeddings, RDKit descriptors, ECFP fingerprints), they developed 32 models. Their results revealed consistently superior performance of ERT models across different molecular representations, providing a reliable baseline for subsequent investigations.

Recent incorporation of toxicogenomic data has ushered nephrotoxicity prediction into a novel direction. Su et al. [127] introduced the Att-RethinkNet model, a multilabel learning framework based on gene expression data from the Open TG-GATEs database. By employing memory structures and attention mechanisms, the model effectively captures correlations between hepatic and renal pathological phenotypes. Furthermore, it integrates multidimensional parameters such as compound type, dosage, and administration duration, enabling simultaneous predictions of 20 renal/hepatic pathological phenotypes. Demonstrating robust performance in in vivo rat datasets, its attention mechanism also highlights key gene features, thereby offering interpretability at the gene-expression level and facilitating deeper mechanistic insights into nephrotoxicity. Together, these advances signify a progressive evolution in nephrotoxicity prediction: from traditional structure-based analyses toward multi modal data integration and interpretability-driven modeling, thus supporting early-stage toxicity risk assessment in drug development. In practice, ensemble or tree-based models (e.g. ERT, RF) remain reliable baselines for small to medium datasets, whereas attention-based multi-omics frameworks are particularly suitable when exploring mechanistic insights or cross-organ toxicities.

## Section: Artificial intelligence in toxicological research › ML/AI applications across diverse toxicity prediction tasks › Acute toxicity

Acute toxicity refers to harmful effects caused by chemical exposure within a short period (usually less than 24 h) through single or multiple administrations. Quantitative measures such as median lethal dose (LD50), median lethal concentration (LC50), and minimal lethal dose (MLD), which are classic in vivo endpoints, are employed to evaluate the severity of lethal toxicity. Acute toxicity assessments encompass various endpoints depending on administration routes (oral, inhalation, dermal, and etc.) and symptom profiles, among which acute oral toxicity prediction remains a primary research focus. In the domain of acute oral toxicity prediction, the computational framework PredAOT [128], based on multiple RF models trained using acute oral toxicity data from OCHEM database and literature in mice and rats, categorizes compounds as “toxic” or “nontoxic/low-toxicity”. Initially, an “AOT classifier” determines compound toxicity class, followed by regression models for precise LD50 (in vivo) prediction. Synthetic minority oversampling technique (SMOTE) was utilized effectively to manage class imbalance, achieving predictive performance comparable or superior to existing tools. Wijeyesakere et al. [129] developed a mechanistically driven QSAR model by analyzing the U.S. NTP’s rat acute toxicity database. This model assigned primary mechanisms of action using various mechanistic analysis tools, and further employed RF for acute oral LD50 prediction, optimizing results by structure-mechanism similarity. The method exhibited enhanced sensitivity and balanced accuracy in identifying highly toxic compounds, enabling toxicity predictions based on specific mechanisms, such as aconitase inhibition.

Regarding acute dermal toxicity prediction, DermalPred [130] exemplifies significant advancement. Integrating rabbit and rat experimental data, researchers constructed predictive models utilizing ML and deep learning algorithms. Structure alerts were extracted using tools such as SARpy, and multiple interpretation methods were combined to identify significant features and structural fragments correlated with acute dermal toxicity, culminating in an independent software tool for toxicity prediction. The optimal model demonstrated robust performance with high AUC scores in 10-fold cross-validation, effectively supporting safety assessments for pesticides, cosmetics, and pharmaceuticals. Moreover, several studies aim to predict multiple acute toxicity endpoints simultaneously. STopTox [131] integrated publicly available datasets to develop QSAR models targeting six acute endpoints—skin sensitization, skin irritation, eye irritation, acute oral (in vivo), acute inhalation (in vivo), and acute dermal toxicity—aggregated within a comprehensive online platform. Rigorously validated, these models effectively identify potentially toxic or nontoxic compounds across multiple endpoints. Jain et al. [132] compiled extensive public datasets and developed diverse single-task and multitask models using RFs and DNNs. They introduced consensus models derived from multiple multitask frameworks, demonstrating excellent predictive capability for 59 acute systemic toxicity endpoints, especially excelling at predicting less-represented endpoints. Collectively, acute toxicity prediction research continues to evolve, broadening from single-route acute oral predictions to multifaceted acute toxicity profiling, significantly contributing to drug development, environmental chemical screening, and regulatory decisions, thereby reducing reliance on animal testing and steering toxicological research toward enhanced accuracy and sustainability. In practice, QSAR and RF-based models remain suitable for rapid screening and regulatory purposes, whereas multitask and consensus deep learning frameworks are recommended for handling diverse endpoints and capturing underrepresented toxicity profiles.

## Section: Artificial intelligence in toxicological research › ML/AI applications across diverse toxicity prediction tasks › Carcinogenicity

Accurate prediction of drug carcinogenicity is crucial for ensuring public medication safety. Traditional in vivo animal and in vitro cellular methods are constrained by high costs, prolonged durations, poor extrapolation accuracy to humans, and limited simulation of realistic physiological environments. Recent rapid advances in ML and deep learning have spurred the development of highly efficient carcinogenicity prediction models. For instance, CapsCarcino [133], leveraging the dynamic routing algorithm of capsule networks, achieved high accuracy in external validation datasets, demonstrating superior generalizability even in sparse data conditions. CONCERTO [134] combined graph Transformer architectures with molecular fingerprint representations, significantly enhancing prediction performance through iterative pretraining and transfer learning strategies. Limbu and Dakshanamurthy introduced the HNN-Cancer model [135], integrating convolutional neural networks (CNNs) and feedforward neural networks (FFNN), using improved SMILES-based representations, and delivering robust results in binary, multiclass, and regression tasks across diverse chemical categories. Similarly, DCAMCP [136], incorporating capsule networks and attention mechanisms alongside various molecular fingerprints and graph-based descriptors, displayed impressive results in both cross-validation and external validation phases. Additionally, Metabokiller [137], integrating biochemical characteristics related to carcinogenicity and utilizing ensemble classification methods, attained high precision, and recall rates when predicting carcinogenic potential for unknown compounds, with selected predictions experimentally validated. Nonetheless, current carcinogenicity prediction models still encounter substantial hurdles, including inadequate quantity and quality of training data, limited interpretability, inconsistent cross-species predictive capability, elevated risks of overfitting, and challenges achieving widespread acceptance from regulatory authorities. From an application standpoint, capsule network, and graph-transformer models show strong promise for sparse or heterogeneous datasets, while ensemble approaches that integrate biochemical descriptors remain a practical choice for improving robustness and regulatory acceptance.

## Section: Artificial intelligence in toxicological research › ML/AI applications across diverse toxicity prediction tasks › Tox21 data challenge

In 2014, the Tox21 initiative launched the Tox21 data challenge [138], utilizing quantitative HTS data from in vitro assays based on nuclear receptor signaling pathways and cellular stress response pathways from the Tox21 10 K chemical library. The dataset comprised 12 060 training samples and 647 test samples, covering 12 toxicity endpoints related to nuclear receptor activation and cellular stress responses. The global competition invited bioinformatics, data science, and ML experts to collaboratively develop and validate innovative toxicity prediction models, addressing the high-cost and low-efficiency bottlenecks of traditional toxicity testing methodologies. Results revealed diverse methodologies applied by participating teams, including classical algorithms such as RFs, SVM, k-nearest neighbors, NB, and alongside state-of-the-art deep learning methods [138]. Among these, deep learning approaches, due to their automatic extraction of hierarchical chemical feature representations, generally demonstrated superior performance. Mayr et al. [139] notably pioneered the application of deep learning models in toxicity prediction, establishing hierarchical chemical feature models significantly outperforming traditional approaches.

As of March 2025, the Tox21 dataset has evolved into five benchmark tasks: Molecular Property Prediction, Drug Discovery, Graph Regression, Graph Classification, and Molecular Property Prediction (1-shot) (https://paperswithcode.com/dataset/tox21-1). Within these benchmarks, deep learning models, particularly GNNs, dominate in terms of performance. For example, Deep-CBN currently leads in molecular property prediction tasks, whereas CensNet [140] excels in graph regression tasks. GMT [141] demonstrates outstanding performance in graph classification tasks, and Meta-MGNN [142] dominates the single-shot molecular property prediction task, all based upon GNN architectures. Furthermore, within the drug discovery task, six out of the top 10 performing models leverage graph-based architectures, underscoring the unique strengths of GNN-based approaches in molecular representation learning.

## Section: Network toxicology and its application in toxicity evaluation of traditional Chinese medicine

TCM, characterized by a longstanding history and widespread clinical application, remains an essential component of China’s healthcare heritage. Compared to Western medicines, which typically act on defined targets through chemical synthesis or natural extraction, providing rapid onset yet usually targeting single symptoms or specific diseases, TCMs possess distinct advantages due to their multicomponent, multitarget nature [145]. TCM formulations consist of diverse bioactive ingredients that interact complexly to produce comprehensive therapeutic effects through multiple targets and pathways. Notably, during the COVID-19 pandemic, TCM demonstrated its irreplaceable role by intervening at multiple stages of viral infection and regulating immune responses, effectively leveraging its multicomponent, multitarget strategy [146]. Nevertheless, as TCM advances rapidly, increasing concerns regarding its potential toxicities have emerged [147–149], making TCM toxicity evaluation a critical area in contemporary research. However, the complex composition and multifaceted mechanisms of action of TCM pose considerable challenges for accurate safety assessment.

Network toxicology, an emerging approach derived from network pharmacology, has become a valuable tool for assessing drug toxicity. Liu and colleagues extended network modeling from “drug–target–efficacy” to “drug–target–adverse reaction,” transforming traditional pharmacological databases into specialized toxicological databases, thereby enhancing the precision of toxicological predictions [150]. Utilizing network analysis and prediction methodologies, network toxicology has successfully identified toxic constituents within TCMs and elucidated their molecular mechanisms of toxicity, providing novel insights into TCM safety evaluations [151].

The application of network toxicology in TCM toxicity evaluation generally comprises the following steps: (i) Data collection and curation: Initially, it is crucial to acquire detailed information about TCM constituents from literature reviews, databases (such as CTD [91] TCMSP [152]), and experimental analyses. (ii) Target prediction and identification: Toxicity targets are predicted using computational tools (e.g. Hazard Expert [153], TOPKAT [154], and DEREK [155]), followed by comparative analyses with TCM-derived toxic compound targets, identifying potential toxic targets. (iii) Network construction and analysis: Toxic compounds and their targets serve as nodes within a network, visualized using tools such as Cytoscape [156], enabling topological analysis and identifying critical nodes. (iv) Toxicity mechanism and pathway analysis: The selected targets undergo Gene Ontology (GO) and KEGG enrichment analyses to clarify potential molecular mechanisms and signaling pathways underlying toxicity. (v) Molecular docking and experimental validation: molecular docking simulations (e.g. using AutoDock [157]) assess compound-target binding interactions, while subsequent in vitro cellular or in vivo animal experiments validate predicted mechanisms and targets identified via network toxicology (Fig. 6).

Commonly utilized resources in network toxicology include toxicological databases, TCM-related constituent databases, predictive toxicological software, and visualization platforms. Reliable toxicological data and accurate TCM constituent information are vital. For example, TOXNET, developed by the U.S. NLM, provides extensive toxicological and chemical data relevant to environmental health and pharmacology. TCM databases such as TCMID [158] and TCMSP [152] (Table 7) facilitate access to constituent information. Predictive toxicology tools described previously (section 3.2) are extensively used for identifying toxic compounds, exogenous substance toxicity, carcinogenicity, and sensitization risks. Although visualization platforms like Cytoscape [156] and STRING [159] are ancillary, they significantly aid in the intuitive interpretation and analysis of complex biomolecular interaction networks.

Network toxicology continues to evolve, showcasing distinct advantages in TCM toxicity research. Researchers initially predict toxic targets and mechanisms using network toxicology, followed by empirical validations to build comprehensive safety evaluation frameworks for TCM. For instance, one study investigated the hepatotoxicity of Mesaconitine (MA), a constituent of Aconitum species, using online databases and network toxicology. It identified 31 crucial hepatotoxic targets and suggested that MA may induce hepatic injury via oxidative stress activation, inflammatory response initiation, and apoptosis induction, offering critical insights into the toxicity of aconite-based TCMs [160]. Another study by Xi et al. [161] analyzed 42 nephrotoxic TCM compounds using network toxicology, identifying alkaloids as the predominant toxic class, followed by terpenoids and phenolics, highlighting the necessity of vigilance regarding nephrotoxic risks associated with these compound classes. Lv et al. [162] employed network toxicology and molecular docking to explore acute toxicity mechanisms associated with palmitic acid, a common TCM component, identifying 117 potential cardiac-toxicity-related targets.

Integrating AI with network toxicology represents an innovative research frontier, significantly enhancing toxicity prediction, risk assessment, and drug development processes. Currently, AI predominantly supports molecular interaction prediction, target identification, and molecular feature modeling within network toxicology. Convolutional neural networks (CNNs), a principal deep learning architecture, effectively predict pharmacological activities and toxicities through structural deep learning, providing robust technological support for network toxicology [163]. Moreover, GNNs [164] facilitate the construction of drug-target-disease interaction networks, enabling predictions of drug-target affinities and potential toxicity profiles, thereby enriching scientific frameworks for safety evaluations. Tian et al. [165] developed an innovative approach, MHADTI, utilizing multi view heterogeneous information network embeddings and hierarchical attention mechanisms to efficiently predict drug-target interactions, paving new avenues for mechanistic exploration in network toxicology. Although AI-driven methodologies in network toxicology still require extensive data accumulation and validation, their early successes underscore significant potential to accelerate TCM safety research and modernization efforts.

Workflow for network toxicology–based toxicity prediction.

Databases of TCM Ingredients

## Section: Drug toxicology research in the era of large language models

The rapid advancement of AI and natural language processing (NLP) technologies in recent years, exemplified by LLMs such as ChatGPT and DeepSeek, has profoundly impacted numerous scientific domains, becoming essential auxiliary tools for researchers [174–177]. Given the enormous, heterogeneous, and complex data involved in drug toxicology and pharmacokinetic safety evaluations, there is an urgent demand for automated analytical tools, where LLMs have demonstrated immense potential.

One of the most notable applications of LLMs in drug toxicity and safety assessment is automated literature analysis and knowledge integration. Traditionally, drug toxicity information scattered across extensive literature, clinical reports, and drug labeling documents requires laborious, subjective manual analyses. Silberg et al. [178] developed the UniTox platform employing the GPT-4 model to automatically extract and categorize toxicity information from drug labeling data of 2418 FDA-approved medications. This initiative successfully created a standardized toxicity database encompassing eight primary toxicological categories, including cardiotoxicity, hepatotoxicity, neurotoxicity, and nephrotoxicity, demonstrating LLMs’ advantages in rapidly and accurately extracting structured toxicity data, thus significantly enhancing toxicological data mining efficiency.

Additionally, LLMs contribute significantly to constructing and enhancing drug safety evaluation databases. Traditional toxicological and ADMET databases often suffer limitations such as insufficient scale, inconsistent annotation, and fragmented information, limiting their utility for deep learning model training. To overcome these challenges, Niu et al. [179] developed the PharmaBench platform, utilizing LLMs for automated extraction and integration of information from vast literature sources, drug labels, and public databases, thereby establishing a comprehensive ADMET benchmark dataset consisting of 11 sub datasets totaling over 50 000 data entries. This initiative significantly improved traditional ADMET resources in both scope and quality, facilitating fair performance comparisons and evaluations of various predictive algorithms.

Furthermore, LLMs also demonstrate considerable potential in molecular toxicity prediction and toxicological mechanism exploration. Unlike conventional models relying on simplistic structural descriptors and statistical learning methods, LLMs leverage contextual understanding from textual molecular representations, yielding superior predictive generalizability. Yang et al. [180] benchmarked GPT-4 and its multimodal variant GPT-4o against conventional ML and deep learning approaches for molecular toxicity prediction. They found that GPT-4 outperformed all comparators across multiple evaluation metrics. Building on this, they integrated GPT-4 with molecular docking techniques to probe the potential cardiotoxicity of TCM compounds, successfully pinpointing several high-risk ingredients and their principal binding sites on cardiac targets. This pioneering work represents the first application of LLMs to molecular toxicity prediction, offering a streamlined, highly efficient workflow for early-stage drug safety screening and underscoring the immense potential of LLMs to accelerate drug development and enhance safety assessments.

Despite their strong text processing abilities, LLMs face challenges in accuracy and reliability due to noisy and inconsistently labeled data, as well as risks of data poisoning [181]. Moreover, their reasoning depends mainly on statistical patterns rather than true causal inference, which restricts their capacity to explain the detailed molecular mechanisms behind drug toxicity [182]. Furthermore, the inherent “black-box” nature and limited transparency of LLM decision-making processes fail to meet stringent interpretability and credibility demands required by drug safety assessments [183]. To mitigate these limitations and enhance trust, several strategies can be employed. These include utilizing post-hoc interpretation techniques (e.g. attention mechanism analysis, feature importance scoring, and counterfactual explanations) to decipher model predictions, and adopting inherently more interpretable model architectures or hybrid approaches that combine LLMs with knowledge graphs for explicit reasoning pathways [184]. Finally, general-purpose LLMs lack profound comprehension of specialized pharmacotoxicological terminology, necessitating domain-specific fine-tuning or the development of dedicated models to enhance prediction accuracy and domain understanding [185].

Looking ahead, LLMs are anticipated to continuously advance drug toxicology research in several key areas. In the domain of clinical applications and safety monitoring, real-time mining of electronic health records and adverse event reports by LLMs can facilitate early alerts and dynamic risk assessments of adverse drug reactions (Fig. 7). Regarding ADMET property prediction, multimodal foundation models integrating molecular structures, gene expression profiles, and metabolomics data are expected to significantly enhance prediction accuracy for complex compounds. For molecular toxicity mechanism exploration, the integration of knowledge graphs and causal inference frameworks will enable deeper elucidation of toxicity pathways. Additionally, automated agents utilizing LLMs can systematically mine and integrate emerging literature and experimental data, thus constructing continuously updated toxicology databases. Lastly, interpretability enhancement tools will improve the transparency and traceability of LLM-driven decision processes, further strengthening their credibility and applicability.

Prospective applications of LLMs in drug safety evaluation and toxicology research.

## Section: Conclusion and perspectives

Computational toxicology is playing an increasingly pivotal role in drug development. Traditional toxicological assessments primarily rely on animal experiments, a methodology characterized by considerable time consumption, high cost, and significant ethical concerns regarding animal welfare. Computational toxicology, integrating advanced bioinformatics, cheminformatics, and ML techniques, facilitates rapid and efficient prediction of compound toxicities, substantially enhancing drug discovery efficiency and reinforcing drug safety [186–188]. In this review, we initially summarized 23 computational tools capable of predicting drug ADMET properties, covering various stages including data input, model training, and prediction output. These methodologies were categorized into three main approaches: rule-based/statistical models, ML-based models, and graph-based methods. Despite demonstrating powerful capabilities in pharmacokinetic prediction and toxicity evaluation, these approaches still face limitations such as inconsistent data quality, inadequate model transparency, and room for improvement in prediction accuracy.

Moreover, recent advances in toxicological databases and toxicity prediction tools were systematically discussed. Toxicological databases, classified according to their data types and application scenarios into chemical toxicity databases, environmental toxicology databases, alternative toxicology databases, and biological toxin databases, provide comprehensive data support for various predictive models. Concurrently, significant progress in ML methodologies has been achieved for toxicity prediction. Researchers have integrated heterogeneous multisource data to construct a series of high-performing models, accurately predicting multiple toxicity endpoints, including acute toxicity, organ-specific toxicity, carcinogenicity, and genetic toxicity. Furthermore, innovative technologies such as GANs have been utilized to generate virtual samples, effectively alleviating data scarcity. Overall, toxicity prediction is progressively evolving toward multimodal integration and generative AI: transitioning from single-endpoint to multi-endpoint joint modeling, expanding data dimensions from traditional chemical structures to clinical data and multi-omics information (e.g. genomics and metabolomics), and shifting from discriminative architectures towards generative network architectures such as GANs and diffusion models. This evolution offers novel paradigms for addressing toxicity evaluations in small sample sizes and complex biological systems [189, 190].

As an emerging paradigm, network toxicology exhibits distinct advantages in the safety assessment of TCM formulas. Researchers construct and analyze multidimensional “component-target-pathway” networks. This approach allows them to clarify the molecular mechanisms behind TCM toxicity, and further provides reliable evidence for safety evaluations. Notably, AI technologies show immense potential in network toxicology: intelligent reasoning based on knowledge graphs can automatically identify potential toxicity pathways, GNNs effectively capture nonlinear relationships within biological networks, and transfer learning offers promising solutions for overcoming modeling bottlenecks posed by limited TCM-specific data [191]. Additionally, this review has explored the prospective applications of LLMs in drug toxicology. Although LLMs have demonstrated substantial potential in automated literature mining, data integration, and toxicity prediction, further research is required to improve their capabilities in causal inference and model interpretability.

Reflecting upon current research progress, toxicity prediction methodologies still encounter several significant challenges: (i) Existing databases exhibit limitations in both data quality and coverage, lacking reliable data for novel compounds such as multi component TCMs or multi target drugs. (ii) The multidimensional nature of toxicity mechanisms—including metabolic pathways, target interactions, and dynamic cellular responses—remains challenging to fully characterize using a single predictive model. (iii) The “black-box” nature of many ML models hinders the biological interpretability of their predictions, thereby limiting their application in clinical decision-making. Thus, future research urgently requires the integration of multidisciplinary techniques, including network toxicology, systems biology, and AI, to develop dynamic and interpretable toxicity prediction frameworks that more accurately reflect real biological systems. Specifically, future efforts should focus on the following four directions:

Future development of prediction methods must prioritize rigorous, transparent, and continuous benchmarking against high-quality in vivo data. Building upon the foundation laid by the Tox21 initiative, we recommend the establishment of a community-driven, iterative evaluation framework. This framework would involve: (i) utilizing existing animal data not just for initial training but as a gold standard for ongoing model validation and refinement in an iterative loop; (ii) creating blinded challenge sets containing novel compounds to impartially assess the generalizability and predictive power of new algorithms against established benchmarks; and (iii) expanding the scope of toxicity endpoints beyond HTS outcomes to include more complex adverse outcomes, thus driving the development of models that can better predict human-relevant toxicity pathways.

Multi-level modeling integrated with systems toxicology: Leveraging systems biology and experimental validation data, researchers should build comprehensive, multidimensional toxicity prediction models spanning molecular, cellular, organ, and organismal levels. For instance, single-cell sequencing combined with metabolomics could dynamically simulate drug distribution and metabolism in vivo, revealing fundamental mechanisms underpinning toxic reactions.

Deepening and innovating AI technologies: Natural language processing techniques can be employed to extract toxicological associations from unstructured literature, establishing dynamically updated toxicity knowledge networks to optimize predictive models. Furthermore, inverse design of low-toxicity molecules and toxicity avoidance strategies could be realized through molecular graph representations and GANs. Developing transparent algorithms (such as SHAP and LIME) will further enhance biological interpretability of model predictions, addressing interpretability requirements in predictive modeling.

Modernizing toxicity evaluation of TCM: Given the inherent complexity of multicomponent and multitarget TCM formulas, it is imperative to establish integrated evaluation frameworks based on network toxicology. These frameworks should incorporate multidimensional “component-target-pathway-phenotype” data, combining traditional empirical toxicity knowledge with advanced ML models to effectively resolve challenges in tracing toxicity sources and clarifying dose-effect relationships within TCM preparations.

Data standardization and cross-platform collaboration: promoting standardized global data collection and sharing mechanisms for toxicological information, building comprehensive toxicity databases covering broader chemical spaces (e.g. natural products and nanomedicines), and utilizing transfer learning, and federated learning techniques could significantly mitigate overfitting issues arising from limited sample sizes.

In conclusion, continuous technological innovations and advancing research endeavors are anticipated to overcome existing challenges and drive further developments in computational toxicology. Such progress promises to provide more efficient and precise toxicity evaluation tools for drug development, facilitating successful drug discovery and clinical application, and ultimately propelling drug research towards a more precise and intelligent new era.

## Section: Declaration of generative AI and AI-assisted technologies in the writing process

During the preparation of this manuscript, the authors utilized DeepSeek R1 to enhance the language and readability. Following the use of this service, the authors thoroughly reviewed and revised the content as necessary, and take full responsibility for the final version of the publication.


---

# Considerations for Regulatory Reusability of Dynamic Tools in the New Drug Development

- **Authors:** Jiang Liu, Yuching Yang, Joga Gobburu, Cynthia J Musante, Martin Klein, Liang Zhao, Rajanikanth Madabushi, Hao Zhu
- **Issuer:** Pharmaceutical research
- **Type:** Scientific article
- **Published:** 2025-03-04
- **Language:** en
- **DOI:** 10.1007/s11095-025-03831-5
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40038161/
- **Licence:** CC-BY

## Section: Abstract

AbstractModel-informed drug development (MIDD) approaches have become indispensable for new drug development and to address regulatory challenges. Dynamic tools, such as population pharmacokinetics (popPK), physiologically-based pharmacokinetics (PBPK), and quantitative systems pharmacology (QSP) models, are routinely employed to enhance the efficiency of drug development. Recently, the Fit-for-Purpose (FFP) initiative and the Model Master File (MMF) framework have emerged to support model reusability and sharing in regulatory settings. In this manuscript we share key insights from the Session "Pathways for Regulatory Acceptance of Dynamic Tools in the New Drug Space" of Workshop “Considerations and Potential Regulatory Applications for a Model Master File”, hosted by the U.S. Food and Drug Administration (FDA) and the Center for Research on Complex Generics (CRCG) and discuss the considerations for regulatory acceptance of dynamic modeling tools. Presentations at the workshop explored current practices in PBPK model evaluation, the potential for popPK models in bioequivalence (BE) assessments, and the implications of reusing models. Challenges such as context-specific validation, version control, and the impact of scientific and technological advancements on model reuse were emphasized. The workshop underscored the importance of clear regulatory pathways and structured frameworks for the consistent application of reusable models. The MMF's potential to streamline reviews and reduce redundancies was noted, although operational details require further elaboration. Continued collaboration among stakeholders is essential to refine model-sharing practices, enhance model validation processes, and promote transparency, ensuring that MIDD approaches remain robust and adaptable to evolving regulatory needs.Keywords: modeling, reusability, simulation, workshop report

## Section: Introduction

Model-informed drug development (MIDD) approaches have become a cornerstone in supporting new drug development. As a technical concept, MIDD involves creating and applying exposure-based, biological, and pharmacological models from preclinical and clinical data to address drug development or regulatory challenges. A variety of modeling and simulation tools, such as population pharmacokinetics (popPK), physiologically-based pharmacokinetics (PBPK), exposure–response, and disease modeling, are integral to MIDD. Recently, quantitative systems pharmacology (QSP) models and artificial intelligence/machine learning (AI/ML) models have been added to the MIDD toolbox. These tools are extensively used to streamline drug development and improve patient care. Regulatory agencies rely on MIDD approaches for decision-making and policy development, employing these tools for purpose such as to determine sample sizes, optimize dose selection, select endpoints or biomarkers, and identify target patients or subgroups. In regulatory settings, the applications of MIDD approaches include contributing to substantial evidence for new drug or drug product approvals, enabling extrapolation of efficacy findings across populations, informing risk–benefit assessments, and selecting appropriate regimens for general population and specific patient groups [1, 2].

While MIDD plays an integral role in modern drug development, building robust models requires significant resources and expertise, often following an iterative process updated with new data and knowledge. Enhancing model reusability where applicable can bring significant efficiencies to enable more routine application and evaluation. The Fit-for-Purpose (FFP) initiative offers a regulatory pathway for the acceptance of dynamic tools, also referred to as "reusable" models, in new drug development [3]. The Model Master File (MMF) framework recently introduced for complex generic drug development potentially also provides a sharable platform for intellectual property that is acceptable for regulatory purposes [4–6]. To facilitate resource and knowledge sharing and increase the efficiency/reusability of models in the new drug space and improve the community’s understanding on the FFP and MMF initiatives, the U.S. Food and Drug Administration (FDA) and the Center for Research on Complex Generics (CRCG) hosted a public discussion on “Pathways for Regulatory Acceptance of Dynamic Tools in the New Drug Space” in a hybrid public workshop titled " Considerations and Potential Regulatory Applications for a Model Master File (MMF)" on May 2 and 3, 2024 [7]. Speakers from the FDA, industry, and academia shared considerations in new drug development on: regulatory utility of the Fit-For-Purpose (FFP) Program to facilitate greater utilization of dynamic models in drug development programs; current practice in PBPK model evaluation and reusability; and potential of repeated usage of population PK models to support BE assessment. The scientific presentations were followed by a panel discussion on implementation issues of model sharing and reusability and the feasibility of MMFs in new drug development.

## Section: Fit-For-Purpose Program

Model building in new drug development is typically an iterative process. For example, in dose selection, the clinical development program aims to reduce uncertainty around the final chosen dose. Although modeling tools translate nonclinical findings for dose selection, first-in-human studies often test a wide range of doses. As clinical trials progress and more data are collected, models are refined, leading to better predictions of the target dose range and more informed trial designs. Consequently, model structures, including covariate relationships and estimated parameter values, are continually updated as the clinical program advances.

However, some models with the same structure and parameter values may be reused across different drug development programs. As discussed by Dr. Hao Zhu, disease modeling is a prime example, where a single model can be applied to multiple programs. Model validation is generally guided by the principles of risk-based credibility assessment framework [9, 10]. This process begins with identifying the Question of Interest and Context of Use. The model influence, or the weight of model generated evidence in the totality of evidence, and the decision consequence, or the potential patient risk from incorrect decisions based on the totality of evidence, determine the model risk. High model risk typically necessitates additional validation activities and technical standards to ensure the quality of the model-generated evidence. The Context of Use is crucial in determining model risk and the required validation. While model influence and decision consequence are well-defined for models developed within specific programs, a "reusable" model should account for a wider range of scenarios. Consequently, the risk for a "reusable" model should be defined conservatively, covering a broad spectrum of potential outcomes. As a result, validation activities and technical standards may differ between a "reusable" model and one designed for a specific program.

The Fit-for-Purpose (FFP) program offers a regulatory pathway for the acceptance of dynamic tools, also referred to as "reusable" models, in drug development. This program is a collaborative effort between multidisciplinary review teams and external stakeholders in the development of modeling tools. To date, the FDA has granted "fit-for-purpose" designation to four applications. These include the Alzheimer’s disease model for clinical trial design developed by the Coalition Against Major Diseases (CAMD), the MCP-Mod tool for dose finding co-developed by Janssen Pharmaceuticals and Novartis Pharmaceuticals, the Bayesian Optimal Interval (BOIN) design for dose selection proposed by Dr. Yuan from the University of Texas and MD Anderson Cancer Center, and the Empirically Based Bayesian Emax Models for dose selection developed by Pfizer. The specific context of use, model evaluation, and conclusions for each program, as outlined in the determination letter, are detailed in Table I [3].

Summary of Context of Use, Model Evaluation, and Conclusion for FDA Granted “Fit for Purpose” Applications

## Section: Current Practice of PBPK Model Evaluation and Implications for Reusability

PBPK modeling and simulation is commonly employed to assess the impact of intrinsic factors (e.g., ontogeny, organ dysfunction, pharmacogenetics) and extrinsic factors (e.g., concomitant medications) on drug exposure to support safety and efficacy assessments in new drug development. As one major type of dynamic models, Dr. Yuching Yang discussed the FDA’s current practice in evaluation of PBPK models, emphasizing the importance of their validation and reusability based on consideration of factors such as the context of use (COU), the model risk, and its potential impact on regulatory decisions.

Developing a PBPK model requires substantial resources and integrates knowledge across multiple domains—biological, chemical, and pharmacological. Mechanistic representation is critical in PBPK model development, which translates this knowledge into a structured form, using the conceptual framework and mathematical representation. Once a base PBPK model is developed, it should undergo a validation process, typically with clinical data, to ensure it is robust enough to describe desired clinical scenarios. It is emphasized that, for regulatory review, the extent of validation depends on the model’s COU and the risk associated with the PBPK analysis.

Dr. Yang explained the interplay between regulatory acceptance of a PBPK analysis and the potential for reusability of a PBPK model (as shown in Fig. 1). The adequacy of a PBPK analysis submitted for regulatory review is determined based on the model's risk and the totality of the evidence for addressing the specific question at hand. In contrast, a reusable PBPK model is expected to support a predefined COU across multiple programs. Reusability requires that the model’s assumptions and uncertainties are well-documented and that it is validated with clinical data relevant to the COU.

Therefore, acceptance of a PBPK analysis for regulatory decision-making does not automatically imply that the model and assumptions can be reused in future applications. A reusable model would need to be suitable for any analysis where the COU remains relevant. Reusability is based on a well-defined COU and a well-vetted development process. Over time, as models are refined and validated with clinical datasets, their reusability increases. Models developed using specialized PBPK software platforms are more likely to be reusable, as these platforms provide consistent model structures that ensure alignment in assumptions, system-dependent parameters, and mathematical representations.

Increasing clinical validation has led to the common practice of reusing previously validated PBPK models, especially in evaluating drug-drug interaction (DDI) liabilities for new drugs. In particular, models for sensitive substrates, inhibitors, or inducers of specific enzyme pathways are frequently reused. Detailed documentation of model development and validation is required for each PBPK model used, and the reusability of previously validated models is determined during the review process.

Dr. Yang also identified two key factors that may prompt the re-evaluation of a previously validated PBPK model’s reusability: changes in the model’s COU and advancements in science and technology. While these factors may appear straightforward, the practicalities of identifying such situations and determining the necessary actions remain underexplored. For instance, regulatory documentation on model reusability typically outlines accepted uses but rarely specifies when a model may no longer be appropriate. As a result, determining whether a previously approved model is suitable for new scenarios can require as much effort as evaluating a new model, regardless of past approvals.

There is also a need to balance the effort required to reassess model reusability following updates from new scientific insights (e.g., in vitro or in vivo data) or technological changes (e.g., software updates) to avoid redundant reviews, especially for models that have already been thoroughly evaluated. Redundant efforts can be minimized if the model was developed using specialized PBPK software and updates are clearly documented by the developers. However, a counterargument is that the PBPK software itself may need to be ‘verified’ and ‘validated’ before accepting updated models or documentation, which would require substantial resources.

Currently, OCP’s PBPK review focuses more on the adequacy of the submitted PBPK analysis in addressing specific clinical pharmacology questions rather than on evaluating the reusability of individual models, particularly for new molecular entities. However, reusing previously validated PBPK models is common in DDI assessments, especially when effects are assessed using certain sensitive substrates or exemplar inhibitors/inducers. These models typically have well-defined COUs, well-understood mechanisms, and have been repeatedly verified with robust clinical datasets.

Adequacy of PBPK analysis vs reusability of PBPK models.

## Section: Potential of Repeated Usage of Population PK Models to Support BE Assessment

Pharmacokinetics (PK) modeling, particularly population PK (popPK) modeling, is increasingly utilized in drug development to assess bioequivalence (BE) across formulations. As discussed by Dr. Joga Gobburu, the potential for repeated usage of such models to streamline bioequivalence studies and new drug approvals has significant implications for the pharmaceutical industry. The concept of a MMF has emerged as a potential solution to eliminate redundant regulatory reviews, thereby optimizing the efficiency of the review process. However, its full implementation raises several critical issues around operational details and philosophical considerations that need clarification.

## Section: Potential of Repeated Usage of Population PK Models to Support BE Assessment › Drug Master File and Bioequivalence Studies

The Drug Master File (DMF) is primarily designed to ensure the confidentiality of sensitive proprietary data, streamline the regulatory approval process, and provide greater flexibility and efficiency in submissions to regulatory authorities [8]. In essence, it serves as a repository for critical information that can be referenced by multiple applications, reducing the need for redundant submissions of the same data.

In vivo Bioavailability and Bioequivalence studies are essential for ensuring that the drug formulations used in clinical trials are comparable to the final marketed formulation. These studies play a vital role in bridging clinical trial formulations to the market, managing post-approval changes, and supporting lifecycle management for sponsors. The challenge lies in developing a framework that allows the repeated usage of population PK models to facilitate these bioequivalence assessments, particularly during formulation changes or regulatory submissions for new indications.

## Section: Potential of Repeated Usage of Population PK Models to Support BE Assessment › Current Model Review Process

As discussed by Dr. Joga Gobburu, the current process for reviewing PK models, including popPK models, involves several steps and is iterative. Initially, the sponsor submits a model to the regulatory authority, which reviews it and then makes an approval decision. This model may later be used in a supplemental application for new purposes with newly available data, but it remains unclear whether regulatory authorities will always need to re-review the same model in its entirety during this secondary process. A key question he raised is whether changes in the review team, or new regulatory requirements, could lead to a different evaluation outcome for the same model.

The review process highlights the need for a more systematic approach that ensures efficiency without compromising the rigor of the review. Conducting a thorough analysis of these bottlenecks will be essential for proposing potential process improvements that can minimize unnecessary delays.

## Section: Potential of Repeated Usage of Population PK Models to Support BE Assessment › Proposal for Model Master File (MMF)

One potential solution to avoid redundant reviews is the establishment of a MMF, which could allow sponsors to submit their PK models once, with the possibility of reusing them for multiple applications. This would eliminate the need for re-reviewing the same model or common aspects of the model each time a new application or supplemental application is filed.

However, Dr. Gobburu commented that the practicality of such a system may still be uncertain. For instance, while the MMF could save time, most models are typically updated with new data before submission as part of a supplemental application. If no updates are made to the original model, it raises the question of what the actual value of the original model for example in the assessment of Bioavailability and Bioequivalence of new drug formulations is.

Dr. Gobburu considers that the most significant potential usage of an MMF would likely be realized with complex models such as PBPK models or QSP models. Streamlining the review process for these models could lead to substantial time savings and increased regulatory efficiency.

## Section: Potential of Repeated Usage of Population PK Models to Support BE Assessment › Philosophical Considerations and Challenges

Dr. Gobburu believes that one of the main philosophical questions surrounding the implementation of an MMF is whether regulatory authorities should review models in isolation from their specific application. A decision-oriented philosophy, which follows a decisions-information-analysis paradigm, asserts that the review of PK models cannot occur in a vacuum. The model would be evaluated in the context of the specific decision it supports, including its application in a particular drug development program.

In contrast, an academic approach to model development may advocate building a model first and then finding applications for it. However, from a regulatory perspective, an issue-driven approach is preferred. Regulators need to understand not just the technical aspects of the model but also its relevance and application to the specific drug or biologic under review. Pre-reviewing models without full knowledge of their application could lead to approval decisions that lack critical context, thus posing a regulatory risk.

## Section: Potential of Repeated Usage of Population PK Models to Support BE Assessment › Operational and Implementation Considerations

There are several operational aspects of the MMF that need to be well-defined before such a system can be efficiently implemented to improve review efficiency. For instance, clear standards need to be established for the format of model files and the types of data that should be included in the report. Moreover, it will be necessary to determine whether the models should be agnostic to the software used in their development, ensuring that the MMF system remains flexible and accessible to sponsors regardless of their technological capabilities.

Another challenge arises when a model developed by one sponsor is used to support the application of another sponsor. For instance, in regulatory pathways such as 505(b)(2), 505(j), or biosimilars, a model developed by the original sponsor can, in theory, be reused by a second sponsor with regulatory approval. However, this requires the original sponsor to grant a right of reference to the second sponsor, which may not always be a straightforward decision. There may be competitive or proprietary concerns that inhibit such collaboration.

Moreover, in some instances, for the regulatory authority to approve the reuse of the model, the data driving the model’s development and validation may still need to be submitted and reviewed. As such, even with an MMF, some aspects of the review process may remain unchanged.

## Section: Discussions

The FFP Initiative provides a pathway for regulatory acceptance of dynamic tools for use in new drug development. The FFP determination is made publicly available to facilitate greater utilization of these tools. However, due to the evolving nature of these types of drug development tools, models considered “fit-for-purpose” should be determined under a specific COU and assessed by appropriate model evaluation approach driven by COU and model risk. Even though a model is considered “fit-for-purpose,” the applicants can update the model or use other modeling approaches to address the same question of interest.

For PBPK applications, a fit-for-purpose approach based on COU is used to assess the adequacy of PBPK analyses (which typically include multiple models) in addressing specific clinical pharmacology questions, rather than focusing on the quality of an individual model across different applications. This is especially relevant for new molecular entities, where PBPK analysis may be applied at various stages for different COUs, with new data continuously emerging throughout development. The fit-for-purpose concept and the model credibility assessment framework [9, 10] provide flexibility to refine and reuse models without requiring additional intensive review activities typically expected for a major model modification program.

The workshop recognized that while MMFs have the potential to significantly streamline drug development particularly for complex generic drugs, there remain challenges related to the dynamic nature of models. The need for a structured approach to version control was highlighted, ensuring that updates to MMFs are properly documented and communicated to stakeholders. Additionally, it was suggested that a publicly available database of approved MMFs (e.g., following the approach of List of Drug Master Files maintained by the FDA [11]) could improve transparency and foster broader acceptance of reusable models​.

For the MMF application in the new drug space, the initial context of use of the models is expected to support bioequivalence evaluation in life-cycle management of NDAs (e.g., for formulation or manufacturing site change). The potential for repeated usage of population PK models to support bioequivalence assessments in new drug development offers substantial benefits, including reduced regulatory risk and greater efficiency. MMFs should provide detailed information on model development, qualification, and validation to support regulatory decisions. The model (including the parameters) is expected to be repeatedly used for the same drug substance and route of administration. Model structure and all parameters are robust and built through sufficiently large dataset in drug development programs aligned with current best biological and physiological understanding. There is sufficient information to evaluate model performance to the target context of use. Unlike the dynamic models from the FFP, for a MMF application change of the model structure or parameter values at a meaningful scale with new data should not be expected without regulatory re-assessment for the specific context of use initially accepted by the MMF. Although it was proposed that MMFs can be viewed as a type of electronic Drug Master File (DMF) submitted as an Electronic Common Technical Document (eCTD) [12], the practical implementation of a MMF (e.g., model sharing, transparency, and confidentiality for proprietary information protection) requires further clarification, particularly around operational details and philosophical concerns. Regulatory authorities will need to define the standards and application areas where MMF can add the most value to ensure that it benefits sponsors and facilitates the drug development process without compromising regulatory rigor.

## Section: Conclusions and Future Perspectives

Dynamic tools and model sharing and reusability play an important role in modern drug development. The discussions revealed that model-based approaches like PBPK and PopPK, when validated for their context of use, can serve as regulatory assets by facilitating efficient drug development. The broader potential for reusing validated models across multiple programs including FFP and MMF present significant opportunities and complementary benefit for improving regulatory efficiency and decision-making.

## Section: Acknowledgements

The authors thank Drs. Sameersingh Raney (FDA), James Polli (CRCG), Anna Schwendeman (CRCG), Vishalakshi Krishnan (CRCG), Jennifer Dick (CRCG), and industry participants for helping organize the workshop. We would also like to thank all the speakers and panelists who participated in the workshop.

## Section: Author Contributions

JL, YY, JG, CJM, MK, LZ, RM, and HZ wrote and reviewed the manuscript.

## Section: Funding

This workshop was supported by the Food and Drug Administration (FDA) of the U.S. Department of Health and Human Services (HHS) as part of a financial assistance award U18FD007054 totaling $1,000,000 with 100 percent funded by FDA/HHS.

Others' work reported in this article is not funded or sponsored.

## Section: Declarations › Conflict of Interest

J.L., Y.Y., M.K., L.Z., R.M., and H.Z. are employees of FDA; this publication reflects the views of the authors and should not be construed to represent FDA’s views or policies.

J.G. is an affiliate of University of Maryland Baltimore.

C.J.M. is a shareholder and employee of Pfizer Inc.
