# Japan's Perspective on Facilitating Drug Development Through Asian Cooperation in Multi-Regional Clinical Trials: Insights From Regulatory Research

- **Authors:** Masahiro Tohkin, Yoshiro Saito, Yoshiaki Uyama
- **Issuer:** Clinical and translational science
- **Type:** Scientific article
- **Published:** 2025-09-01
- **Language:** en
- **DOI:** 10.1111/cts.70347
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40922702/
- **Licence:** CC-BY-NC

## Section: Abstract

ABSTRACTMulti‐regional clinical trials (MRCTs) have recently become a popular strategy for novel drug development, contributing to the early access to novel medicines in participating regions by enhancing development efficiency. To further facilitate MRCTs in Asia, the Japanese government has financially supported research activities in Japan for over 15 years that have studied the effect of ethnic factors on drug responses and identified practical challenges in conducting MRCTs in Asia. This mini‐review highlights these research outcomes and related articles and presents our perspective on the current situation and future direction of MRCTs to explore opportunities for more collaboration between Japan and other East Asian/South‐East Asian countries to facilitate drug development.

## Section: Introduction

The significance of multi‐regional clinical trials (MRCTs) has been recognized to increase drug development efficiency and decrease drug lag in Japan [1, 2]. Recently, drug development has focused more on Asia owing to the rapid economic growth and increased medical needs in the region [3]. However, factors such as ethnic differences and varying medical circumstances across regions, including Asia, should be considered when planning and designing MRCTs [4] as indicated in the harmonized guideline by International Conference on Harmonization of technical requirements for registration of pharmaceuticals for human use (ICH), “General principles for planning and design of multi‐regional clinical trials (ICH‐E17).”

To facilitate MRCTs with the participation of Japan and other Asian countries, the Ministry of Health, Labour, and Welfare of Japan (MHLW) and the Japan Agency for Medical Research and Development (AMED) have financially supported research activities in Japan for over 15 years that have studied the effect of ethnic factors on drug responses and identified practical challenges in conducting MRCTs in Asia. Outcomes from these research activities related to the development strategies of MRCTs in Asia have been published as research articles [5, 6, 7]. Other articles focused on ethnic factors that affect drug efficacy and safety in MRCTs have also been published [8, 9, 10, 11, 12]. Primarily based on the outcomes of these research activities, this mini‐review introduces the findings and related articles and presents our perspective on the current situation and future direction of MRCTs to explore opportunities for more collaboration between Japan and other East Asian/South‐East Asian countries to facilitate drug development.

## Section: Ethnic Similarities and Differences Among Asian Populations

The effect of ethnic factors on the clinical pharmacokinetics (PK) of a drug is a major consideration when planning MRCTs. In this context, PK studies by Hasunuma et al. highlighted the significance of experimental conditions in accurately assessing the ethnic sensitivities in drug PK profiles across populations. The PK parameters of ethnically sensitive drugs—such as moxifloxacin, simvastatin, and meloxicam—did not differ among East Asian populations under strictly controlled experimental conditions [8]. Additionally, Kuorse et al. identified few differences in common PK‐related gene polymorphisms among Japanese, Korean, and Chinese populations, except for human lymphocyte antigen alleles crucial for cutaneous adverse drug reactions [9]. Genetic similarities among Asian populations [13, 14] and no distinct differences in the drug exposure and recommended doses in East Asian countries have been previously reported [15]. Moreover, Sai et al. compared the efficacy of two drugs, asenapine, a schizophrenia drug, and tadalafil, a dysuria drug for benign prostatic hyperplasia, using MRCT data from Japan, Korea, and Taiwan and concluded that no significant population/regional efficacy differences were found for the two drugs among the three regions. Effect modifiers, such as pretreatment drug status or concurrent diseases, were common among countries [10]. Other studies by Tohkin et al. including systematic reviews or meta‐analyses of relevant MRCT data, also demonstrated no differences in efficacy among Asian populations in certain drug categories, dipeptidyl peptidase‐4 inhibitors (anti‐diabetic), warfarin, and direct oral anticoagulants [11, 12]. On the other hand, significant differences in efficacy were observed between Asian and non‐Asian populations in these drugs [10, 11, 12]. A review by Ramamoorthy et al. indicated that approximately one‐fifth of new drugs approved in the past 6 years demonstrated differences in exposure and/or response across racial/ethnic groups, translating to population‐specific prescribing recommendations in a few cases [16]. Overall, these studies suggested that insight about ethnic differences in drug responses between the Asian and other regions as outlined in the ICH‐E5 guideline, “Ethnic factors in the acceptability of foreign clinical data”, are critical for implementing MRCTs, including those in Asian region. These differences are attributed not only to the genetic factor but also to regional‐specific issues such as differences in common foods/drinks, common diseases/treatments, clinical trial implementation systems, medical practices, and regulatory environments among different regions.

## Section: Situation of MRCTs Conducted in Asia

Asano et al. assessed the current status of Asian MRCT and factors that affect the drug development process in Asian MRCT, such as therapeutic areas, main metabolic enzymes, approval status in the industrial countries/regions, development strategies, influencing drug development strategies in Asian MRCT and in general MRCT for drug approval in Japan. Then, they demonstrated a significant increase in the use of MRCTs for drug approval in Japan, with a dramatic expansion in participating regions/countries, such as the USA, EU, and Japan, and other Asian countries, including China, South Korea, Taiwan, Singapore, Thailand, Malaysia, and Indonesia [5]. They also suggested that region‐specific diseases in Asia, intrinsic and extrinsic ethnic differences between Japanese/Asian and Caucasian populations, and the status of the drugs' development in the United States or the European Union all affected the drug development process in Asian MRCT [5]. Aoi et al. assessed characteristics of MRCTs for drugs approved in Japan, especially those with South‐East Asia and East Asia participation. They then clarified that South‐East Asia has participated in various types of MRCTs in terms of total numbers of subjects and participating countries, in addition to Japan. However, the number of South‐East Asia‐participated MRCTs was lower in large‐size MRCTs than in middle‐ and small‐size MRCTs. Furthermore, separate clinical trials in South‐East Asia countries alone for the same indications as the MRCTs without South‐East Asia were very few. From these observations, they indicated that South‐East Asia has lower participation in MRCTs with participation of Japan, suggesting further opportunities for collaboration among Asian countries [6].

## Section: Future MRCTs, Including Japan and Other Asian Countries

The outcomes of these articles offer significant insights into assessing the ethnic similarities and differences among Asian populations. For example, the systematic review analysis of DPP‐4 inhibitors suggested that a stratification of patients across regions using a biomarker related to efficacy may make it easier to demonstrate consistency of efficacy across regions and facilitate the analysis of effectiveness in MRCTs, including the Asian population [11]. Another example was a clinical PK study using the unified study protocol in four regions. This study suggested that the unified protocol may also help analyze the ethnic factor in PK studies more accurately for some drugs [8]. Although the scope of these studies was limited, the results suggested that an early exploratory study examining the impacts of ethnic factors was useful for planning and conducting a confirmatory clinical study, including East/South‐East Asian populations [8, 9, 10, 11, 12]. This may encourage industries to include these Asian populations in MRCTs. However, further studies are required to understand better how ethnic factors affect drug responses in these populations because certain geographic locations in Asia may underestimate the genetic diversity within them [17]. For example, Chinese, Malay, and Indian populations are living in Singapore and Malaysia, and the Indian population was known to be close to the Caucasian population in terms of frequencies of genetic polymorphisms on some drug metabolizing enzymes such as CYP2C9, UGT1A1, and NAT2 [9]. Therefore, more careful considerations may be necessary when including South‐East Asia in MRCTs because of the more diverse genetic backgrounds of populations. In addition, data on Asian populations can be enriched by jointly conducting an MRCT in Japan, East Asia, and South‐East Asian countries because the number of Asian subjects in MRCTs is significantly higher when including these regions [6]. The inclusion of countries from East Asia and South‐East Asia in MRCTs will substantially contribute to the accumulation of scientific data on ethnic factors affecting drug responses in Asian populations under a unified protocol.

Collaborative training in Asia on MRCTs, based on the E17 guideline of ICH, will enhance the understanding of the significance of considering the similarities and differences in ethnic factors in drug responses across different populations [7]. Recent efforts for regulatory convergence in Asia, in which numerous regulatory agencies from Japan, Singapore, China, Chinese Taipei, Indonesia, and Malaysia participate through the ICH, will facilitate cooperation and collaboration in Asia. The Asia Training Center for Pharmaceuticals and Medical Devices Regulatory Affairs of the Pharmaceuticals and Medical Devices Agency of Japan plays a crucial role in fostering international collaboration among regulatory agencies in Asia [18].

Although operational challenges in implementing the ICH‐E17 guidelines still exist [19], sharing scientific data on ethnic factors in Asian populations will result in the proper implementation of the E17 guidelines, including the pooling strategy. A recent report on the practical consideration of ethnic factors in comparing Asian populations with other populations for a phase III MRCT [20] may serve as a good example of applying the E17 guidelines in planning and designing an MRCT that includes Asian populations. Another option is to include Japan and other East Asian countries earlier in drug development, especially in the design of phase II/Proof of Concept studies. This option offers the advantage of generating data on ethnic similarities in PK, safety, and efficacy in the target patient population as valuable prior knowledge ahead of phase III MRCT design [21, 22].

The recent guideline published by the MHLW announced that phase I Japanese PK assessment ahead of such Japan‐inclusive MRCTs is not obligatory for Japan to join MRCTs [23]. However, assessing Japanese PK properties using clinical PK data in a phase II or later study is important to consider a proper dosage, even if a phase I study of the Japanese population has not been done according to that guideline. PK data of other Asian populations are also useful for planning an MRCT including the Asian population more appropriately.

Evaluating ethnic susceptibility and confirming that drugs are unlikely to be affected by ethnic factors will promote the implementation of first‐in‐human (FIH) studies in Asian countries such as Japan, and may contribute to efficient drug development. The ethnic susceptibility could be assessed based on the evaluation of PK characteristics predicted from nonclinical studies and gene polymorphism distribution, as well as the characteristics of somatic gene mutations found in tumors [24].

Strengthening Asian cooperation and collaboration will accelerate research to understand ethnic factors in drug responses better and result in efficient drug development, benefiting Asia and other regions.

## Section: Disclosure

The views expressed herein are the result of independent work and do not necessarily represent the views and findings of the Pharmaceuticals and Medical Devices Agency.

## Section: Conflicts of Interest

The authors declare no conflicts of interest.


---

# Large Language Model-Enhanced Drug Repositioning Knowledge Extraction via Long Chain-of-Thought: Development and Evaluation Study

- **Authors:** Hongyu Kang, Jiao Li, Li Hou, Xiaowei Xu, Si Zheng, Qin Li
- **Issuer:** JMIR medical informatics
- **Type:** Scientific article
- **Published:** 2025-10-07
- **Language:** en
- **DOI:** 10.2196/77837
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41056561/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundDrug repositioning is a pivotal strategy in pharmaceutical research, offering accelerated and cost-effective therapeutic discovery. However, biomedical information relevant to drug repositioning is often complex, dispersed, and underutilized due to limitations in traditional extraction methods, such as reliance on annotated data and poor generalizability. Large language models (LLMs) show promise but face challenges such as hallucinations and interpretability issues.ObjectiveThis study proposed long chain-of-thought for drug repositioning knowledge extraction (LCoDR-KE), a lightweight and domain-specific framework to enhance LLMs’ accuracy and adaptability in extracting structured biomedical knowledge for drug repositioning.MethodsA domain-specific schema defined 11 entities (eg, drug, disease) and 18 relationships (eg, treats, is biomarker of). Following the established schema architecture, we constructed automatic annotation based on 10,000 PubMed abstracts via chain-of-thought prompt engineering. A total of 1000 expert-validated abstracts were curated into a drug repositioning corpus, a high-quality specialized corpus, while the remaining entries were allocated for model training purposes. Then, the proposed LCoDR-KE framework combined supervised fine-tuning of the Qwen2.5-7B-Instruct model with reinforcement learning and dual-reward mechanisms. Performance was evaluated against state-of-the-art models (eg, conditional random fields, Bidirectional Encoder Representations From Transformers, BioBERT, Qwen2.5, DeepSeek-R1, OpenBioLLM-70B, and model variants) using precision, recall, and F1-score. In addition, the convergence of the training method was assessed by analyzing performance progression across iteration steps.ResultsLCoDR-KE achieved an entity F1 of 81.46% (eg, drug 95.83%, disease 90.52%) and triplet F1 of 69.04%, outperforming traditional models and rivaling larger LLMs (DeepSeek-R1: entity F1=84.64%, triplet F1=69.02%). Ablation studies confirmed the contributions of supervised fine-tuning (8.61% and 20.70% F1 drop if removed) and reinforcement learning (6.09% and 14.09% F1 drop if removed). The training process demonstrated stable convergence, validated through iterative performance monitoring. Qualitative analysis of the model’s chain-of-thought outputs showed that LCoDR-KE performed structured and schema-aware reasoning by validating entity types, rejecting incompatible relations, enforcing constraints, and generating compliant JSON. Error analysis revealed 4 main types of mistakes and challenges for further improvement.ConclusionsLCoDR-KE enhances LLMs’ domain-specific adaptability for drug repositioning by offering an open-source drug repositioning corpus and a long chain-of-thought framework based on a lightweight LLM model. This framework supports drug discovery and knowledge reasoning while providing scalable, interpretable solutions applicable to broader biomedical knowledge extraction tasks.

## Section: Introduction

Drug repositioning, also known as drug repurposing, has emerged as a pivotal strategy in pharmaceutical research, enabling the discovery of novel therapies for existing drugs [1]. This approach significantly facilitates the drug development process, shortens the required time, and reduces the cost [2]. However, biomedical information relevant to drug repositioning is often complex and dispersed across various sources [3], such as literature, clinical trials, and databases. These valuable resources remain underutilized because of the challenges associated with knowledge extraction [45]. Extracting knowledge from biomedical literature, such as entities, relationships, and structured triplets, can facilitate drug repositioning research by uncovering hidden connections between drugs and diseases [6]. Recent studies have demonstrated the effectiveness of knowledge extraction in supporting knowledge discovery in drug repositioning. For example, Bang et al [7] developed a semantic multilayer guilt-by-association approach to extract drug-disease associations from large-scale biomedical corpora, while Huang et al [8] leveraged TxGNN, a graph foundation model for zero-shot drug repurposing, to identify therapeutic candidates even for diseases with limited treatment options or no existing drugs. These advancements underscore the importance of automated knowledge extraction in identifying potential drug candidates for the treatment of complex, multifactorial diseases.

Traditional knowledge extraction methods have evolved from manual annotation and rule-based techniques to machine learning and deep learning approaches. Early methodologies relied heavily on expert-curated databases and handcrafted rules, which lacked scalability while being precise [910]. Machine learning models, such as conditional random fields (CRF), introduced statistical learning to automate entity recognition and relationship extraction [11-13]. More recently, deep learning models, including BERT and transformer-based architecture, have achieved remarkable performance in biomedical natural language processing tasks. For example, domain-specific language models, such as BioBERT [14], PubMedBERT (trained on biomedical literature) [15], ClinicalBERT (trained on the MIMIC-III dataset) [16], and PharmBERT (trained on prescription drug labeling) [17], have been further developed. Despite their success, these methods still have several limitations. They often require extensive labeled datasets for training, which are costly and labor-intensive to obtain. Furthermore, deep learning models demonstrate limited generalizability across diverse biomedical domains [18] and often overlook implicit knowledge that extends beyond surface-level textual patterns [19]. As a result, refining extraction methodologies to achieve greater adaptability and performance continues to be an important focus in drug repositioning studies.

Large language models (LLMs) have emerged as a promising solution for biomedical knowledge extraction, demonstrating superior performance across various natural language processing tasks. Models such as ChatGPT (OpenAI) [20], LlaMA (Meta) [21], GLM (Tsinghua) [22], Qwen (AlibabaCloud) [23], and Deepseek [24] have been extensively used in biomedical text mining because of their advanced semantic comprehension and text generation capacities. By leveraging key methodologies, including pretraining [25], prompt engineering [26], and domain-specific fine-tuning [27], these models demonstrate improved accuracy and adaptability for specialized tasks [28], such as named entity recognition [29] and association prediction [30]. Xie et al [31] developed Me-LLaMA through continual pretraining and instruction tuning of LLaMA2 models and outperformed existing open medical LLMs on 6 text analysis tasks. Hao et al [26] developed and evaluated MedScaleNER, a task-oriented prompt framework, advancing the application of LLMs and prompt engineering for specialized named entity recognition tasks in Chinese medical literature. Recent advances such as BioGPT [32] and OpenBioLLM-70B [33] have demonstrated the potential of large-scale generative pretrained transformers in enhancing biomedical text generation and domain-specific knowledge mining. Focusing on a more specific biomedical task, Yuan et al [34] introduced BioFocal-DDI, a framework combining BioGPT for data augmentation, BioBERT, and BiLSTM for contextual and sequential feature extraction to optimize drug-drug interaction extraction.

Compared to traditional methods, LLMs demonstrate superior knowledge extraction capabilities, including better generalization, reduced reliance on annotated data, and stronger contextual comprehension. Nevertheless, persistent challenges [3536], including model hallucination, output accuracy, interpretability, and high computational demands, must be addressed. For drug repositioning applications, these issues can be mitigated through gold-standard corpus validation, careful prompt engineering, and chain-of-thought (CoT) [37] methodologies. Chen et al [38] leveraged retrieval‐augmented generation combined with instruction prompting to build LLMs specialized for osteoarthritis diagnosis and treatment Q&A, providing reliable clinical decision support to health care professionals.

While LLMs demonstrate promise in biomedical knowledge extraction, challenges persist in domain-specific adaptability, particularly in drug repositioning, where sparse annotated data, semantic ambiguity, and cross-sentence dependencies hinder accurate knowledge inference [3940]. To address these limitations, we proposed long chain-of-thought (LCoT) for drug repositioning knowledge extraction (LCoDR-KE), a lightweight framework that combined LCoT prompting, supervised fine-tuning (SFT), and reinforcement learning (RL). To enhance the performance of knowledge extraction, our approach also introduced a dual-level reward mechanism to guide knowledge extraction and a high-quality drug repositioning corpus (DrugReC), meticulously curated from biomedical publications in PubMed. Through comparative and ablation studies, we validated the framework’s superiority over traditional models and its competitive performance against state-of-the-art LLMs, offering a scalable, interpretable solution for accelerating drug discovery and biomedical knowledge inference.

## Section: Methods › Overview

The workflow of the proposed LCoDR-KE is illustrated in Figure 1 and consisted of 4 main stages: drug repositioning schema design, data preparation and gold standard annotation, implementation of LCoT framework, and in-depth evaluation.

## Section: Methods › Drug Repositioning Schema Design

We developed a multidimensional knowledge model by conducting in-depth analyses of drug mechanisms [41-43] while precisely defining core entity dimensions and their relationships. We conducted comprehensive analyses of drug labels, literature, and multiple biomedical databases (including DrugBank, CTD, PharmGKB, and DisGeNET) to establish foundational knowledge. In addition, this multidimensional knowledge framework was subsequently refined and validated through expert consultation, incorporating specialized domain knowledge from pharmacology, bioinformatics, clinical medicine, and computational biology.

## Section: Methods › Data Preparation

A total of 10,000 PubMed abstracts were extracted using a 4-step filtering strategy to ensure quality and domain relevance:

This rigorous selection process (detailed in a PRISMA [Preferred Reporting Items for Systematic Reviews and Meta-Analyses] flow diagram in Multimedia Appendix 1) ensured the inclusion of the latest high-quality research articles relevant to pharmacological mechanism and repurposing strategies.

## Section: Methods › Data Annotation With CoT-Prompt Engineering

Owing to the lack of annotated datasets for drug repositioning knowledge extraction, we constructed an annotated corpus from 1000 PubMed abstracts mentioned earlier. The prompt was evaluated on DeepSeek-R1 [45] via CoT [46], which required LLMs to generate coherent intermediate reasoning steps leading to a final answer [47].

We summarized the execution steps and proposed a task-specific prompt as follows and outlined them in Multimedia Appendix 2.

To ensure the quality of the DrugReC, we manually reviewed the standard results from 1000 abstracts as well. A total of 3 annotators in pharmacology, clinical medicine, and bioinformatics were recruited, with 2 conducting cross-review and the third senior expert adjudicating conflicting or ambiguous cases. The corpus was subsequently partitioned into a training set (n=800) for RL algorithm development and a test set (n=200) to evaluate model generalizability. The remaining 9000 abstracts were used as training data for SFT.

## Section: Methods › Long Chain-of-Thought › LLM Deployment

The Qwen2.5-7B-Instruct model [48], developed by Alibaba Cloud, represented a significant advancement in the Qwen series of LLMs, specifically optimized for semantic comprehension and complex task processing. This 7-billion-parameter transformer-based architecture demonstrated exceptional performance in specialized applications, including knowledge extraction [49] and conversational interaction [50] scenarios. Meanwhile, an extended context window of 128,000 tokens facilitated precise capture of fine-grained semantic features within textual data.

For the Qwen2.5-7B-Instruct setup, we used temperature sampling with the parameter of 0.02. A lower temperature parameter can limit the model to make excessive creative jumps, thus ensuring accurate and consistent outputs. Meanwhile, we set the max_token parameter to 16,384 while leaving all other hyperparameters at their default values. The used hyperparameters during model training included a training batch size of 8, a learning rate of 1e−6, a cutoff length of 16,384, and a gradient accumulation step of 1. The model was trained on the Wuwen Xinqiong platform. Training the 7B model with 8× NVIDIA A100 40GB GPUs took approximately 40 hours, with a total cost of approximately 1000 RMB (US $140.47).

## Section: Methods › Long Chain-of-Thought › Cold-Start SFT

To address the output incoherence and unstable reasoning patterns caused by directly initializing RL [51] in foundation LLMs, we implemented cold-start SFT [52] with CoT data from 9000 PubMed literature as mentioned earlier. These domain-specific annotated triplets were used to optimize model parameters under a supervised learning framework, enabling the model to progressively acquire human-aligned reasoning patterns. This phase implemented multistep reasoning paths and strict output formats, significantly enhancing the model’s complex problem decomposition capacity and intermediate step interpretability. In brief, the approach of cold-start SFT provided stable initialization for subsequent RL stages.

## Section: Methods › Long Chain-of-Thought › RL Algorithm

To reduce the training costs associated with RL, we used GRPO to further optimize reasoning paths through self-iteration in an unannotated environment [53]. Specifically, GRPO generated multiple candidate outputs {o1,o2,…oG} from the old policy πθold and then optimized the policy model πθ by maximizing the following objective:

and the advantage Ai was defined as follows:

where ri was the raw reward for the ith answer and μgroup and σgroup represented the mean and SD, respectively, of rewards within the candidate outputs. The group-wise contrastive mechanism mitigated absolute reward scale bias while encouraging high-quality reasoning.

For the task of drug repositioning knowledge extraction, this optimization process facilitated complex cognitive mechanisms based on a high-performance RL training framework, EasyR1 [54], leading to enhancement of task-specific reasoning performance.

## Section: Methods › Long Chain-of-Thought › Reward Modeling

Subsequently, we proposed a novel dual-reward mechanism specifically for drug repositioning knowledge extraction to guide model self-evolution. This mechanism integrates 2 complementary reward types: (1) an accuracy reward targeting factual correctness in entity and triplet extraction and (2) a structural format reward focusing on the integrity and interpretability of the model’s reasoning process through structured tag compliance.

## Section: Methods › Accuracy Reward Mechanism

This mechanism established a multidimensional evaluation that compares model outputs with annotated references. Dynamic scoring rules for entity recognition and triplet extraction are presented in Table 1.

According to these scoring rules, the accuracy reward was as follows:

where Sentity was accuracy reward of entity recognition, Stripletwas accuracy reward of triplet extraction, and Srare was reward of rare entity or relationship. This hierarchical award mechanism effectively balanced comprehensiveness and granularity in drug repositioning knowledge extraction.

## Section: Methods › Structural Format Reward

To enhance the model’s step-by-step reasoning, we also introduced an XML tag–guided mechanism (Table 2) that enforced structured output. It was required to encapsulate complete reasoning processes within “<think>……</think>” tags and nested <step> tags, enabling multilevel logical decomposition.

According to these scoring rules, the structural format reward was as follows:

where Stag was format reward of tag integrity and Slength was format reward of thinking length. This approach ensured machine-parsable outputs while enhancing the interpretability of inference pathways.

## Section: Methods › In-Depth Evaluation and Comparison

To comprehensively assess the performance of LCoDR-KE, we conducted an in-depth analysis.

First, comparative experiments were conducted to benchmark LCoDR-KE against traditional machine learning models (eg, CRF), general-purpose pretrained models (BERT), domain-specific biomedical models (BioBERT), and state-of-the-art LLMs, including ChatGPT-4, Llama3, QIANWEN, and variants with different parameter scales. These comparative analyses served to validate the effectiveness of our proposed model against established benchmarks, thereby highlighting its superior performance in addressing specialized biomedical knowledge extraction problems.

Second, ablative experiments were designed to evaluate the individual contributions of the key technological advancements, including high-quality data-driven prompt engineering and LCoT reasoning mechanism. By removing or substituting these modules, the study quantified their independent contributions and synergistic effects on task performance.

Finally, we conducted an error analysis by manually reviewing 100 randomly selected abstracts from the model outputs to identify common types of mistakes and areas for future algorithmic improvements.

Meanwhile, we used precision, recall, and F1-score for model evaluations. Precision quantifies the proportion of correct identifications among all model predictions, reflecting the reliability of positive results. Recall evaluates the coverage for true positive instances, indicating the comprehensiveness of knowledge extraction. The F1-score, as the harmonic mean of precision and recall, provides a balanced assessment that mitigates the impact of omissions and false extraction, thereby offering a comprehensive evaluation. For rigorous validation, we compared model outputs against manually annotated corpus using exact string matching, which ensured high quality of model performance.

## Section: Methods › Ethical Considerations

This study did not involve human participants or animal experiments. All data used in the research, including biomedical literature and structured databases, were publicly available and deidentified before analysis. Therefore, ethics approval was not required in accordance with institutional and international research ethics policies.

## Section: Results › Knowledge Representation for Drug Repositioning

Drug repositioning schema (summarized in Multimedia Appendix 3) encompassed 11 entity categories, including core entities (drug, disease, and target) along with extended dimensions, such as side effect, gene, biomarker, symptom, complication, anatomical structure, clinical examination, and treatment. Furthermore, 18 relationship categories were defined in detail to comprehensively characterize semantic features among multilevel entities, such as “treat...,” “is target of,” “is side_effect of,” “is biomarker of.” This framework substantially enhanced semantic representation capabilities and facilitated the discovery of latent associations in drug repositioning research.

## Section: Results › Statistics of DrugReC

Via defined prompt engineering and manual review, we constructed a high-quality DrugReC, specially for drug repurposing text mining. This corpus, annotated from 1000 PubMed abstracts, contained 11 entity types and 18 relationship types closely related to drug repositioning. After the concordance test and revision, a total of 9329 entities and 4879 triplets consisted of this standard dataset (presented in Table 3). Among the entity types, disease (19.10%) and drug (15.80%) were the most frequently represented, followed by anatomy (13.62%), test (10.32%), and biomarker (10.26%). Less prevalent but critical categories included complication, target, treatment, symptom, gene, and side effect. Regarding knowledge triplets, is_examination_for (18.16%), treat (17.20%), and is_biomarker_of (17.16%) together accounted for more than half of all triplets, emphasizing the corpus’s focus on clinically relevant associations. This distribution reflected DrugReC’s design to support comprehensive text mining efforts in drug repositioning by capturing key therapeutic and diagnostic linkages. We have made this corpus publicly available on GitHub with Apache License version 2.0, providing a high-quality data foundation to advance biomedical informatics mining.

Then, this dataset was randomly divided at the document level into training (80%) and test (20%) subsets, with detailed statistical characteristics of both partitions provided in Tables3 4.

## Section: Results › Knowledge Extraction With Different Types

LCoDR-KE achieved an overall F1 score of 81.46%. High performance was observed for the most frequent entity types, including drug (F1=95.83%) and disease (F1=90.52%), likely due to their distinct semantic boundaries and abundant contextual representations. Mid-range performance was observed for anatomy (82.38%) and test (82.11%), while categories such as gene (74.70%), complication (73.93%), and biomarker (72.03%) showed moderate degradation. The lowest entity F1 scores occurred for target (64.05%) and treatment (67.21%), not solely due to lower frequency but likely due to greater semantic ambiguity and overlapping usage with other types. Performances are detailed in Table 5.

Triplet extraction yielded an overall F1 score of 70.39% (Table 6). The model excelled on treat relations (F1=84.47%) and is_target_of (74.73%), which may benefit from clearer syntactic patterns. In contrast, performance declined for is_biomarker_of (57.69%) and increases_expression_of (50.00%), reflecting both data sparsity and higher contextual variability.

Performance differences can largely be attributed to variations in data distribution, semantic complexity, and context dependency, rather than entity or relation frequency alone. These findings suggested that targeted data augmentation, finer-grained annotation, or context-aware modeling strategies may further improve performance across challenging categories.

## Section: Results › Performance Comparisons › Performance Comparison With State-of-the-Art Models

To evaluate the performance, we compared our LCoDR-KE model with several state-of-the-art models, including CRF (machine learning model), BERT (general-purpose pretrained language model), BioBERT (domain-specific biomedical model), and LLMs, including DeepSeek-R1, QIANWEN, and variants with varying parameter scales. These LLMs were evaluated under a 5-shot setting, consistent with the configuration used for our LCoDR-KE model. This ensured a fair comparison under equivalent prompt-based conditions. Detailed hyperparameter settings for each model are provided in Multimedia Appendix 4.

The comparative evaluation against state‐of‐the‐art baselines (Table 7) demonstrated that LCoDR-KE delivered substantial advances in both entity and triplet extraction. Classical sequence learners, such as CRF, scored poorly (entity F1=29.18%; triplet F1=14.51%), while general‐purpose pretrained models (eg, BERT, BioBERT) achieved modest gains (entity F1≈37%; triplet F1≈30%). The Qwen2.5-7B variant improved entity extraction (F1=53.16%) but remained weak on triplets (F1=18.04%). In contrast, LCoDR-KE-0.5B reached 62.67% entity F1 and 35.05% triplet F1, and the 7B model further advanced to 81.46% and 69.04%.

Notably, at 7B parameters, LCoDR-KE approached DeepSeek-R1’s entity F1 (81.46% vs 84.64%) and marginally exceeded its triplet F1 (69.04% vs 69.02%). Although LCoDR-KE did not surpass DeepSeek-R1, it reached a similar level of effectiveness under a smaller parameter scale (7B vs 671B).

We further evaluated the OpenBioLLM-70B, which achieved an entity F1 of 59.66% (precision: 56.63%; recall: 63.04%) and a triplet F1 of 16.52% (precision: 13.92%; recall: 20.31%). In contrast, our LCoDR-KE-7B model achieved notably higher performance with 81.46% (precision: 83.37%; recall: 79.64%) in entity extraction (21.8 percentage points increase) and 69.04% (precision: 72.43%; recall: 65.96%) in triplet extraction (52.5 percentage points increase).

## Section: Results › Performance Comparisons › Impact of Model Scale on Extraction Performance

Across the LCoDR-KE series (Figure 2), increasing model capacity from 0.5B to 1.5B, 3B, and 7B yielded consistent performance improvements, with entity F1 rising from 62.67% to 72.91%, 74.57%, and 81.46%, triplet F1 rising from 35.05% to 48.34%, 51.83%, and 69.04%, respectively. These gains suggested that larger models better capture the complex contextual dependencies required for accurate biomedical knowledge extraction.

## Section: Results › Performance Comparisons › Ablation Studies

To evaluate the contributions of different components within the LCoDR-KE model, we conducted ablation studies to examine the impact of strongly SFT and the LCoT model on knowledge extraction outcomes for drug repositioning. We removed the 2 components of the LCoDR-KE model to observe changes in performance.

As presented in Table 8, the ablation studies demonstrated significant performance degradation when removing either SFT or GRPO module. Removing GRPO reduced F1-scores by 6.09% for entity extraction and 14.09% for triplet extraction, indicating that GRPO substantially enhances knowledge extraction. In comparison, removing SFT caused sharper declines in precision (8.61% for entities and 20.70% for triplets), underscoring the critical role of task‐specific supervision in adapting pretrained representations. Together, these results demonstrated that both components contribute synergistically to the model’s knowledge extraction capabilities, with GRPO enhancing reasoning and SFT improving supervised alignment. Meanwhile, the absence of SFT caused more pronounced degradation in both entity and triplet extraction, indicating its broader influence on model performance (Figure 3).

## Section: Results › Performance Comparisons › External Benchmark Evaluation

To further assess generalizability beyond our in-domain DrugReC corpus, we evaluated LCoDR-KE directly on the widely used BC5CDR benchmark, which comprises 500 PubMed abstracts manually annotated for chemical (drug) and disease entities and their binary associations. OpenBioLLM-70B achieved entity F1 of 47.39% and relation F1 of 25.52%, while DeepSeek-R1 scored 60.93% and 38.33%, respectively. Without additional fine-tuning, LCoDR-KE obtained an entity F1 of 59.17% (precision: 85.92%; recall: 45.12%) and a triplet F1 of 35.16% (precision: 33.84%; recall: 36.59%), closely matching DeepSeek-R1 and substantially outperforming OpenBioLLM-70B. Thus, our method demonstrated generalizability beyond in-domain abstracts, achieving robust performance on external biomedical corpora such as BC5CDR.

## Section: Results › Effect of K-Shot Examples on Model Performance

To evaluate the impact of prompt on corpus generating, we conducted a small-scale experiment comparing 0- to 5-shot prompting settings. As shown in Figure 4, k-shot prompting consistently outperformed the 0-shot baseline in both entity and triplet extraction. Entity F1 rose from 80.01 (0 shot) to 82.63 (5 shots), while triplet F1 increased from 67.16 to 70.48. Performance steadily improved as the number of examples increased, particularly between 1 shot and 3 shots. Notably, the model achieved stable and high performance in the 3- to 5-shot range, suggesting that moderate prompt context enhances annotation quality.

## Section: Results › Reward Parameter Optimization

To optimize the reward function for knowledge extraction and structured reasoning, we used a progressive tuning strategy through multiple rounds of controlled experiments. The reward formulation includes a hierarchical accuracy component where the coefficients for entity recognition (α), triplet extraction (β), and rare entity/relation enhancement (γ) satisfy the constraint α + β + γ = 1. Given the high computational cost of jointly searching in a 3D space, we adopted a 2-stage approach. We first optimized α and β under the constraint α + β = 1 to balance entity- and relation-level performance. Once optimal base weights were identified, we introduced γ by gradually adjusting the proportion of reward allocated to rare cases. Subsequently, we adjusted the weights associated with structured reasoning, namely tag integrity (δ) and reasoning length (ε), to ensure syntactic validity and controlled verbosity in the model’s output. Finally, we calibrated the overall balance between accuracy-related rewards and format-related rewards by modifying the global weight of accuracy reward and format reward parameters.

In addition, we introduced 2 top-level coefficients (ie, accuracy reward weight and format reward weight) to control the relative contribution of accuracy-based and format-based rewards in the overall objective. These weights were jointly tuned to ensure a trade-off between extraction performance and output structure quality.

Throughout the process, evaluation was based on both entity and relation F1-scores, as well as the structural completeness of generated outputs (Multimedia Appendix 5). The final parameter configuration, with α=.45, β=.45, γ=0.1, δ=0.7, ε=0.3, accuracy reward=0.5, and format reward=0.5, demonstrated optimal performance in terms of extraction accuracy, robustness, and output interpretability and was therefore adopted in subsequent experiments.

## Section: Results › Interpretable CoT Reasoning Patterns

To evaluate whether the model engaged in structured reasoning, we examined its CoT outputs during knowledge extraction. We gave an example (Table 9) to demonstrate that the model performed structured, schema-aware reasoning beyond pattern matching. It explicitly validated entity types, rejected schema-incompatible relations, and enforced output constraints, ultimately generating a compliant JSON structure. The complete example of CoT is summarized in Multimedia Appendix 6.

## Section: Results › Step of Training Iterations

We also monitored the performance across 30 training iterations (from 100 to 3000 steps) using F1 metrics (Figure 5) and showed a steady and stable improvement in Entity F1, which reached a peak of 81.46% at the level of 1700. Notably, Entity F1 remained consistently high beyond 2000 iterations without significant decline, indicating robust and stable convergence in the entity recognition task. Triplet F1 reached its highest value of 69.34% at step 1500 and exhibited a slight decrease in subsequent iterations; however, it consistently stayed above 65%, suggesting that the model maintained a strong baseline for triplet extraction. This relatively stable performance postpeak indicated the potential for further optimization with continued training or minor adjustments. Overall, these results demonstrated the effectiveness and stability of the training approach, particularly for entity recognition while also highlighting a promising and resilient trajectory for triplet extraction performance. Detailed performances across training iterations are provided in Multimedia Appendix 7.

## Section: Results › Error Analysis

We conducted an error analysis by manually reviewing 100 randomly selected sentences from the model outputs to identify common types of mistakes and areas for improvement.

## Section: Results › Error Analysis › Error Examples

The errors were classified into 4 main types of entity extraction (ie, incorrect extraction, incorrect type, boundary errors, and missing entities) and 2 main types of triplet extraction (incorrect entity type and cross-sentence errors), with examples summarized in Table 10.

## Section: Results › Error Analysis › Error Statistics

We further quantified the frequency of each error type to assess their impact and guide future improvement strategies.

For entity extraction:

For triplet extraction:

To further investigate the model’s behavior on entity classification, we constructed a confusion matrix (Multimedia Appendix 8) based on entity predictions. The results (Figure 6) showed strong diagonal dominance, indicating high accuracy across most entity types. However, misclassifications persist among semantically similar categories. Specifically, the biomarker was confused with the target (2 cases) and gene (1 case), while gene was misclassified as the target twice. In addition, 1 side effect instance was incorrectly labeled as a complication. These errors reflected the model’s difficulty in distinguishing biologically related concepts with overlapping semantics. In contrast, core categories, such as drug and disease, were classified with perfect accuracy.

## Section: Results › Error Analysis › Comparisons Between LCoDR-KE and DeepSeek-R1

Meanwhile, LCoDR-KE demonstrated comparable performance with DeepSeek-R1. Specifically, LCoDR-KE surpassed DeepSeek-R1 in the categories of incorrect type (6 vs 8), missing entity (6 vs 7), and incorrect entity type (5 vs 6). This advantage can be attributed to our meticulous definition of entities and relations for the drug repurposing task, as well as the provision of accurate examples during model training. Conversely, LCoDRKE performed slightly worse in the Incorrect Extraction (10 vs 8) and CrossSentence Error (8 vs 7) categories, indicating that its complex contextual understanding and reasoning capabilities warrant further improvement.

## Section: Discussion › Principal Findings

In this study, we introduced LCoDR-KE, a novel framework for drug repositioning knowledge extraction that significantly enhanced the adaptive learning capabilities of LLMs.

The effectiveness of our approach stemmed from 2 key innovations.

Collectively, these innovations contributed to the improved performance of LCoDR-KE in extracting drug repositioning knowledge.

Compared to pretraining approaches specifically designed for biomedical tasks, LCoDR-KE offered several advantages. Traditional methods typically required extensive domain adaptation, large annotated corpora, or multiple rounds of fine-tuning to achieve competitive performance [55]. In contrast, LCoDR-KE achieved performance optimization with a relatively small training dataset—comprising only 1000 literature abstracts—thereby significantly reducing the human and time costs associated with domain-specific annotation. Furthermore, LCoT decomposed semantic understanding into explicit and traceable reasoning steps. This approach mitigated hallucinations and enhanced model transparency, addressing 2 major challenges in the application of LLMs. Our ablation study further substantiated these findings.

Moreover, performance comparisons demonstrated that LCoDR-KE based on the Qwen-2.5-7B model matched the performance of the 671B -parameter DeepSeek-R1 in drug repurposing knowledge extraction. Specifically, F1-scores achieved 81.46% versus 84.64% for entity extraction and 69.04% versus 69.02% for triplet extraction. This advance significantly narrowed the gap between large-scale models and resource-constrained environments, making it a practical solution for research institutes and hospital information centers with modest computing capabilities.

In addition to performance gains, LCoDR-KE enhanced model interpretability through CoT prompting. By generating intermediate reasoning steps, such as entity justification, schema validation, and relation filtering, the model made its decision process more transparent and traceable. This structured reasoning not only aided error diagnosis but also aligned model behavior with domain knowledge constraints, offering a more controllable and explainable framework for biomedical knowledge extraction.

Our expanded error analysis provided a more nuanced understanding of model behavior in biomedical knowledge extraction. By categorizing common error types, quantifying their frequency, and visualizing entity-level confusion patterns, we identified key challenges such as semantic ambiguity, long-range dependencies, and data sparsity. These insights not only explained performance bottlenecks but also informed future improvements, such as targeted data augmentation and schema-aware prompt refinement to reduce ambiguity and improve generalization.

LCoDR-KE demonstrated strong performance in low-resource settings through its schema design, cold-start SFT, and RL with a reward mechanism. It provides an efficient and feasible solution for biomedical knowledge extraction under resource-constrained conditions. In clinical research settings, LCoDR-KE could be deployed to mine structured knowledge from trial protocols, real-world evidence, or adverse event reports, assisting clinicians in therapeutic decision-making and safety monitoring. In early-stage drug development, it can support target identification and biomarker discovery by extracting mechanistic insights from scientific literature. Its lightweight design makes it particularly well suited for integration into domain-specific platforms where computational resources and labeled data are limited. Moreover, its task-specific schema could be readily tailored by redefining entities and relations, thereby accommodating new domains, languages, and even alternative LLM backbones. Its flexibility allowed LCoDR-KE to extend beyond drug repositioning to a broad range of biomedical knowledge extraction tasks.

## Section: Discussion › Limitations

Despite the promising results, our study has some limitations. First, we limited the task to drug repositioning in this study. In the future, we will include other biomedical knowledge extraction tasks, such as gene–disease association identification and drug–drug interaction detection, thereby expanding its application value in diverse scenarios. Second, the model’s balance between reasoning depth and computational efficiency remains suboptimal, particularly when processing intricate biomedical contexts requiring multistep logical inferences. Future optimizations will focus on lightweight architectural improvements.

## Section: Discussion › Conclusions

This study introduced LCoDR-KE, a framework that enhanced LLMs’ domain-specific adaptability for drug repositioning by integrating long-chain reasoning and RL. We constructed a publicly available DrugReC and a lightweight knowledge extraction model, offering critical resources for accelerating drug discovery and knowledge inference. The framework balances accuracy, interpretability, and computational efficiency, validated through stable training convergence and competitive performance against state-of-the-art models. Overall, LCoDR-KE not only advances drug repositioning research but also provides a scalable, transferable methodology applicable to diverse biomedical knowledge extraction tasks, knowledge reasoning, and even decision support, bridging gaps in low-resource, specialized domains.


---

# Large language model processing capabilities of ChatGPT 4.0 to generate molecular tumor board recommendations-a critical evaluation on real world data

- **Authors:** Maximilian Schmutz, Sebastian Sommer, Julia Sander, David Graumann, Johannes Raffler, Iñaki Soto-Rey, Seyedmostafa Sheikhalishahi, Lisa Schmidt, Leonhard Paul Unkelbach, Levent Ortak, Tina Schaller, Sebastian Dintner, Kathrin Hildebrand, Michaela Kuhlen, Frank Jordan, Martin Trepel, Christian Hinske, Rainer Claus
- **Issuer:** The oncologist
- **Type:** Scientific article
- **Published:** 2025-10-01
- **Language:** en
- **DOI:** 10.1093/oncolo/oyaf293
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40973166/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundLarge language models (LLMs) like ChatGPT 4.0 hold promise for enhancing clinical decision-making in precision oncology, particularly within molecular tumor boards (MTBs). This study assesses ChatGPT 4.0’s performance in generating therapy recommendations for complex real-world cancer cases compared to expert human MTB (hMTB) teams.MethodsWe retrospectively analyzed 20 anonymized MTB cases from the Comprehensive Cancer Center Augsburg (CCCA), covering breast cancer (n = 3), glioblastoma (n = 3), colorectal cancer (n = 2), and rare tumors. ChatGPT 4.0 recommendations were evaluated against hMTB outputs using metrics including recommendation type (therapeutic/diagnostic), information density (IDM), consistency, quality (level of evidence [LoE]), and efficiency. Each case was prompted thrice to evaluate variability (Fleiss’ Kappa).ResultsChatGPT 4.0 generated more therapeutic recommendations per case than hMTB (median 3 vs 1, P = .005), with comparable diagnostic suggestions (median 1 vs 2, P = .501). Therapeutic scope from ChatGPT 4.0 included off-label and clinical trial options. IDM scores indicated similar content depth between ChatGPT 4.0 (median 0.67) and hMTB (median 0.75; P = .084). Moderate consistency was observed across replicate runs (median Fleiss’ Kappa = 0.51). ChatGPT 4.0 occasionally utilized lower-level or preclinical evidence more frequently (P = .0019). Efficiency favored ChatGPT 4.0 significantly (median 15.2 vs 34.7 minutes; P < .001).ConclusionIncorporating ChatGPT 4.0 into MTB workflows enhances efficiency and provides relevant recommendations, especially in guideline-supported cases. However, variability in evidence prioritization highlights the need for ongoing human oversight. A hybrid approach, integrating human expertise with LLM support, may optimize precision oncology decision-making.Keywords: precision oncology, molecular tumor board, variant annotation, artificial intelligence, ChatGPT 4.0, large language models

## Section: Introduction

Precision oncology tailors cancer treatments to individual tumor profiles by identifying specific molecular alterations that guide targeted therapy.1–3 However, the growing array of diagnostic tools—such as comprehensive genomic profiling and exome or genome sequencing—makes clinical annotation and evidence interpretation increasingly complex.4,5 Beyond molecular findings, patient context and preferences also influence therapeutic decisions.3 To address this complexity, Molecular Tumor Boards (MTBs) integrate multidisciplinary expertise, including oncology, pathology, genetics, and bioinformatics.6 Yet, the lack of universal standards for evaluating molecular data and recommending treatments results in significant variability among MTBs,7,8 driven partly by disparate data availability and interpretations.9 Multiple systems propose levels of evidence (LoE) for genetic aberrations, but consensus remains elusive.10,11

Recent advances in large language models (LLMs) like ChatGPT have sparked interest in their potential to streamline MTB workflows.12 These models can generate detailed, contextually relevant text and respond to complex queries, surpassing traditional search engines in certain scenarios.13,14 In principle, LLMs could assist MTBs by analyzing molecular data, identifying actionable mutations, and furnishing high-level summaries. Early studies suggest that AI chatbots sometimes match or exceed physicians in the quality and empathy of medical responses.15 Nonetheless, human expertise is indispensable for handling multidimensional clinical data and nuanced decision-making, as shown by recent research indicating that expert oversight remains critical in complex cases.16 Integrating LLMs into MTBs, thus, poses both opportunities for enhanced efficiency and risks if inaccuracies or misinterpretations occur, underscoring the need for careful assessment of model outputs.

This study explores how ChatGPT and similar LLMs might aid MTBs in annotating and interpreting post-last-line therapy biomarkers. We evaluate the reliability, quality, and efficiency of LLM-derived recommendations and discuss how these models could support—and not replace—expert judgment. As the demand for personalized care expands amid constrained ­clinical resources, leveraging LLMs may help optimize decision-making and advance precision oncology by improving access to comprehensive, evidence-based insights.

## Section: Patients and methods

Analytical strategy: ChatGPT 4.0 and human oncological experts from the molecular tumor board (hMTB) generated recommendations for standard cases as baseline feasibility and for 20 anonymized patient cases from the molecular tumor board. Recommendations were then evaluated by 2 independent human reviewers focusing on type of recommendation, information density, consistency of information, quality of information and process efficiency. LLM, large language model.

## Section: Patients and methods › Molecular tumor board at the Comprehensive Cancer Center Augsburg

The Molecular Tumor Board (MTB) at the Comprehensive Cancer Center Augsburg (CCCA) was established in 2018 to improve treatment outcomes for patients with advanced or rare malignancies lacking standard therapeutic options. The MTB convenes weekly, comprising interdisciplinary experts in oncology, pathology, molecular pathology, human genetics, and bioinformatics. After each discussion, the MTB issues structured therapeutic or diagnostic recommendations, together with an evidence summary, following the NCT-based levels of evidence (LoE) classification (1A–4A).11 Details are given in Table S1. Recommendations can assist in reimbursement applications and inform patient-specific treatment strategies.

## Section: Patients and methods › Patient selection and data

For this study, real, sequential MTB cases from June to August 2021 were included to match the ChatGPT 4.0 knowledge cutoff date in September 2021. Among these, 20 consecutive cases displayed at least one confirmed genetic aberration. All patients provided consent for anonymized, retrospective use of their data. No further ethics approval was required per Bavarian Hospital Act (BayKrG Art. 27 Para. 4). Patient demographics (eg, age, comorbidities) were not included, as therapy decisions primarily depended on tumor biology and prior treatments, and final therapeutic recommendations were at the discretion of the treating physician. Molecular profiling used multigene NGS panels (eg, AmpliSeq for Illumina Cancer HotSpot Panel v2), identifying SNVs, CNVs, or fusions. Immunohistochemistry was conducted if relevant (eg, for antibody-drug conjugates).

## Section: Patients and methods › Prompt engineering strategy

Clinical patient summaries and pathology reports were used to manually extract relevant data for hMTB case discussions. The same data was provided to the LLM via inclusion into a standardized prompt in the English language (Table S2). Extracted data are condensed into a summarized report form, on which the hMTB case discussion and preparation are based on. No other sources were integrated for the actual case discussion.

ChatGPT was informed that all outputs were for educational case discussions, not direct clinical use, prior to running the prompts. Each case was prompted in triplicates, and answers were copied to capture the variability between answers. It was noted to have misinterpretation or omission of critical information triggers a re-prompt with identical content by highlighting the omission or misinterpretation to the system, if necessary. An exemplary prompt is shown for case 18, which showed the highest Kappa Fleiss value as internally most consistent triplicate, alongside the first iteration of the corresponding answer. The complete transcript can be found in Table S3 alongside all other triplicate transcripts.

Prompts for querying a ChatGPT 4.0 were systematically structured to simulate multidisciplinary molecular tumor board (MTB) discussions. Each prompt positioned the LLM as a hematologist/oncologist collaborating with specialists in pathology, molecular pathology, human genetics, and pediatric oncology. Technical terminology was used. Detailed clinical context was provided, including disease diagnosis, UICC stage, histopathological features, comprehensive immunohistochemical (IHC) profiles (eg, TPS, CPS, ICS, ER, PR, HER2/neu, Ki-67, HPV status), microsatellite stability status (MSS/MSI), and specific molecular genetic alterations identified through targeted sequencing (AmpliSeq Focus Panel, AmpliSeq BRCA Panel; Illumina). A detailed therapeutic history was also included, outlining previous surgical, chemotherapeutic, targeted, immunotherapeutic, and radiotherapeutic interventions. No interpretation of the potential resistance mechanism was provided. Prompt length was uniform throughout cases (median words used = 149, range = 125-180). Context window limitations were not reached for any case.

The LLM was tasked to recommend subsequent therapeutic options, explicitly requesting both drug classes and specific agents, supported by relevant clinical trials or guidelines or any evidence available. Additionally, it was asked to suggest any necessary further diagnostic tests. Responses were structured in tabular form with clear citations of evidence sources, emphasizing precision medicine principles and evidence-based recommendations.

Given the patient’s presentation and genetic profile, the potential therapeutic options are considered accordingly. However, it should be noted that molecularly targeted treatments are not currently the standard of care for stage IIIC rectal cancer, although there are ongoing trials. Please ensure that the following suggestions are taken in the context of available local guidelines and consider the benefit-risk ratio for the patient.

Here is a summary table:

In addition to the above, you should consider the general health status and comorbidities of the patient, the potential side effects of the treatments, as well as the patient’s preferences.

Sources:

Montagut C, Dalmases A, Bellosillo B, et al. Identification of a mutation in the extracellular domain of the Epidermal Growth Factor Receptor conferring cetuximab resistance in colorectal cancer. Nat Med. 2012;18:221-223.

Lin JJ, Riely GJ, Shaw AT. Targeting ALK: Precision medicine takes on drug resistance. Cancer Discov. 2017;7:137-155.

Vainchenker W, Leroy E, Gilles L, Marty C, Plo I, Constantinescu SN. JAK inhibitors for the treatment of myeloproliferative neoplasms and other disorders. F1000­Research. 2018;7:82.

Guideline recommendations for immunohistochemical testing of estrogen and progesterone receptors in breast cancer. Arch Pathol Lab Med. 2010;134:907-922.

Samstein RM, Lee CH, Shoushtari AN, et al. Tumor mutational load predicts survival after immunotherapy across multiple cancer types. Nat Genet. 2019;51:202-206.

Taube JM, Klein A, Brahmer JR, et al. Association of PD-1, PD-1 ligands, and other features of the tumor immune microenvironment with response to anti–PD-1 therapy. Clin Cancer Res. 2014;20:5064-5074.

## Section: Patients and methods › Analytical strategy

For the analysis of ChatGPT’s performance, a multilayer analytical strategy was developed. Figure 1 gives an overview of the analysis pipeline. Five key metrics were used. Prior to case analysis, ChatGPT 4.0’s standard-of-care recommendations were assessed for correctness against published NCCN guidelines (2021) in 3 established cancer types (colorectal, lung, breast).17–19

Analytical strategy: ChatGPT 4.0 and human oncological experts from the molecular tumor board (hMTB) generated recommendations for standard cases as baseline feasibility and for 20 anonymized patient cases from the molecular tumor board. Recommendations were then evaluated by 2 independent human reviewers focusing on type of recommendation, information density, consistency of information, quality of information and process efficiency. LLM, large language model.

## Section: Patients and methods › Performance metrics and statistical analysis

Five key performance metrics were defined for evaluating ChatGPT’s recommendations for the MTB cases. Information density and quality were evaluated by the 2 independent experts:

Details on patients and methods are given in “Supplementary Patients and Methods” (see Supplemental Text for details on MTB eligibility criteria, prompt structure, data handling, and complete case transcripts).

## Section: Results

(A) Illustrates the distribution of recommendations across the cases. The top panel of the figure represents the recommendations made by human experts, while the bottom panel shows the averaged recommendations from the GPT model. Therapeutic recommendations are depicted in orange, and diagnostic recommendations are depicted in red. Error bars in the GPT panel indicate the standard deviation across the triplicates. Statistical analysis was conducted by performing the Wilcoxon signed-rank test on the therapeutic and diagnostic recommendations separately. (B) Shows the Bland-Altman Plots both for therapeutic and diagnostic recommendations. Orange dots represent a single case, with its position on the plot showing both the mean of the GPT and expert recommendations on the x-axis and the difference between them on the y-axis. The central red dashed line represents the mean difference (bias) between the 2 methods, while the black dashed lines indicate the 95% limits of agreement, calculated as the mean difference ±1.96 times the standard deviation of the differences.

The line plot shows IDM scores assigned by 2 independent reviewers for MTB recommendations generated by GPT-4.0 (with each reviewer evaluating 3 sets of recommendations [triplicates]) (A) and by a human expert group across 20 cases (B). A Wilcoxon signed-rank test revealed no statistically significant differences between the overall depth of information provided by GPT-4.0 and the human expert group (P = .546). IDM, information density metric; MTB, molecular tumor board.

(A) Bar chart displaying Fleiss’ Kappa values for each clinical case, indicating the level of agreement between different GPT-4.0 accounts in assigning therapy recommendations across replications. (B) Boxplot summarizing the distribution of Fleiss’ Kappa values across all cases, highlighting the overall moderate agreement with a mean Kappa value of 0.51.

Comparison of Levels of Evidence (LoE) Assigned to Therapy Recommendations by ChatGPT 4.0 and Human Experts. (A) Bar plots showing the distribution of Levels of Evidence (LoE) for therapy recommendations generated by GPT 4.0 across 3 replicates and by human experts. LoEs range from 1A (strongest evidence) to 4 (weakest evidence). The plots compare the frequency of each LoE category assigned by 2 independent reviewers for GPT 4.0 and human expert recommendations. (B) Average differences in Levels of Evidence (LoE) scores between GPT 4.0-generated therapeutic recommendations and human molecular tumor board (hMTB) recommendations across 20 cases. Bars represent the mean difference in LoE scores, with positive values indicating higher scores assigned by GPT. Error bars denote the standard deviation across 3 replicates. Cases marked with “data incompl.” indicate insufficient data for more than one replicate or missing data for the hMTB group for both reviewers.

Temporal benchmarking of LLM performance in MTB recommendations. Information Density Metric (IDM) scores for 4 representative cases (Case 2, Case 9, Case 18, and Case 19) across 4 ChatGPT model versions: GPT-4.0 (baseline), GPT-4o (August 2024), GPT-4o (August 2025), and GPT-4o with Deep Research mode (August 2025). Cases were selected to reflect a spectrum of complexity, initial performance, and reviewer concordance. Bars represent mean IDM scores from triplicate outputs per model version. Temporal progression shows reduced performance for GPT-4o (Aug 2024) compared to baseline, followed by marked improvement in GPT-4o (Aug 2025) and Deep Research outputs, the latter providing textually rich, evidence-cited recommendations. LLM, large language model; MTB, molecular tumor board.

Time required for preparing MTB cases. Boxplot comparing the time required (in minutes) to prepare MTB (molecular tumor board) cases using a ChatGPT-assisted approach vs human experts. The plot shows that the ChatGPT-assisted approach required significantly less time than the human experts, with the distribution of times displayed for both groups. The P-value of less than .001 indicates a significant difference in preparation time between the 2 methods.

## Section: Results › Characterization of the molecular tumor board cohort at the Comprehensive Cancer Center Augsburg

Twenty consecutive MTB cases from June to August 2021 at the Comprehensive Cancer Center Augsburg (CCCA) were retrospectively analyzed. Patients (n = 20) had an equal sex distribution and a median age of 56 years (IQR 42-76; range: 32-78)). Tumor entities varied, with breast, colorectal, or CNS/brain neoplasia being most frequent (3 cases each, 15%) (Table S5). In 80% of cases, targeted genetic analyses used the AmpliSeq Focus Panel (Illumina), while 20% used the AmpliSeq BRCA Panel. One patient additionally underwent POLE mutation analysis by digital droplet PCR.

Overall, 39 single-nucleotide variants (SNVs) were identified (median 2 per patient, range 1-9), along with 6 copy-number variations (CNVs), including one 1p19q deletion and 5 amplifications (copy number 5-10) ( Figure S1A). The most commonly affected gene was PIK3CA. Selected immunohistochemical stains, including PD-L1 (TPS/CPS/ICS), HER2/neu, and hormone receptor status (AR, ER, PR), were also performed (Figure S1B).

To assess the representativeness of our cohort, we compared patient characteristics and mutational features with those reported by Höfflin et al.21 a national landmark MTB study conducted at a German comprehensive cancer center (n = 488), as well as with data from the AACR Project GENIE Consortium (18.0-public dataset), a large international collection of cancer genomic and clinical data.21–23

Despite the smaller sample size in our study (n = 20), we observed a similar median age (56 vs 54 years in Höfflin et al.) and balanced sex distribution (50/50% vs 47/53%) (Table S6). Common tumor entities such as bowel (lower and upper GI tract), CNS, and breast cancer were represented in both cohorts but were not represented similarly. This reflected our focus on sequential real-world cohorting. In addition, our cohort also included rarer entities such as CUP, ovary, and skin cancer, reflecting the heterogeneity typical of MTB practice.

Genomic alterations such as PIK3CA, BRCA2, KRAS, and BRAF were among the most frequently observed in both our cohort and the comparator cohorts, demonstrating biological overlap. This is further reflected in our mutational distribution plot (Figure S2), which mirrors the heterogeneity reported in larger-scale MTB studies. Using ESCAT Tier IIB or better as a threshold for actionability, 10 out of 20 cases (50%) harbored at least one targetable alteration. No case contained more than 2 such alterations. (Full annotations are provided in Table S7).

We further compared the most frequent genomic alterations (Table S8) across the 3 cohorts. Several recurrent alterations, including PIK3CA, BRCA2, KRAS, and BRAF, were consistently observed in our cohort and both comparator datasets, indicating a similar underlying molecular landscape despite differences in sample size, case mix, and sequencing platforms.

## Section: Results › ChatGPT 4.0 correctly interprets standard guideline cases and provides correct inline therapy recommendations

To test ChatGPT’s basic ability to generate guideline-based treatment recommendations, 3 common stage IV cancers with internationally established standards—colorectal cancer (CRC), non-small cell lung cancer (NSCLC), and breast cancer (BC)—were presented. ChatGPT 4.0 accurately summarized case details and provided correct first-to-last-line therapeutic recommendations in accordance with 2021 NCCN guidelines (Table S9). All outputs (prompted 3 times per case) consistently matched guideline-concordant management without hallucinated information, indicating high reproducibility in standardized clinical scenarios.

## Section: Results › Quantity and type of recommendation differ significantly between ChatGPT 4.0 and the hMTB regarding therapeutic but not diagnostic recommendations

Quantitative comparisons of ChatGPT 4.0’s triplicate outputs and the human MTB (hMTB) revealed significant differences in the number of therapeutic recommendations (P = .005) but not diagnostic recommendations (P = .501) (Figure 2A). ChatGPT 4.0 tended to propose more therapeutic options (median of medians 3, range 1-6) than the hMTB (median 1, range 0-3), whereas the hMTB often suggested more diagnostic measures (median 2, range 0-4) compared to ChatGPT (median of medians 1, range 0-4).

A Bland-Altman plot (Figure 2B) of therapeutic recommendations showed a small, consistent difference of about one additional option proposed by ChatGPT. All but one data point fell within the 95% limits of agreement, though the overall spread suggested greater variation in ChatGPT’s recommendations. For diagnostic recommendations, the mean difference was near zero.

Representative examples include case 3 (KRAS-mutant metastatic CRC post 6 lines of therapy) and case 15 (glioblastoma with hypermethylated MGMT promoter and multiple amplifications). In case 3, the hMTB gave more diagnostic recommendations, while ChatGPT offered no diagnostic but more therapeutic options. In case 15, ChatGPT again proposed multiple therapeutic approaches, whereas the hMTB gave none. Overall, ChatGPT’s diagnostic scope overlapped substantially with human experts, but it consistently produced more therapeutic ideas.

(A) Illustrates the distribution of recommendations across the cases. The top panel of the figure represents the recommendations made by human experts, while the bottom panel shows the averaged recommendations from the GPT model. Therapeutic recommendations are depicted in orange, and diagnostic recommendations are depicted in red. Error bars in the GPT panel indicate the standard deviation across the triplicates. Statistical analysis was conducted by performing the Wilcoxon signed-rank test on the therapeutic and diagnostic recommendations separately. (B) Shows the Bland-Altman Plots both for therapeutic and diagnostic recommendations. Orange dots represent a single case, with its position on the plot showing both the mean of the GPT and expert recommendations on the x-axis and the difference between them on the y-axis. The central red dashed line represents the mean difference (bias) between the 2 methods, while the black dashed lines indicate the 95% limits of agreement, calculated as the mean difference ±1.96 times the standard deviation of the differences.

## Section: Results › Information depth does not significantly differ between ChatGPT 4.0 and the hMTB

To evaluate content depth, an Information Depth Metric (IDM) was developed and applied by 2 independent reviewers, who scored each recommendation set from ChatGPT 4.0 and the hMTB (Figure 3A). ChatGPT’s IDM scores ranged from 0.25 to 0.89 (median 0.67) for reviewer 1 and 0.125 to 0.89 (median 0.67) for reviewer 2, showing moderate variability across triplicates and reviewers. The hMTB’s IDM scores ranged from 0.5 to 0.86 (median 0.75) for reviewer 1 and 0.5 to 0.8 (median 0.67) for reviewer 2 (Figure 3B). Although the hMTB showed slightly broader variability, neither group’s scores were statistically superior (P = .084), suggesting comparable overall depth of information on a case-by-case basis.

Inter-reviewer agreement was generally higher for ChatGPT than for the hMTB, with Pearson correlation coefficients of 0.799 (P = .001) vs 0.256 (P = .277), respectively (Figure S3A). A correlation matrix of all reviewer pairs indicated moderate to strong positive correlations for ChatGPT outputs and moderate correlations for the hMTB (Figure S3B).

The line plot shows IDM scores assigned by 2 independent reviewers for MTB recommendations generated by GPT-4.0 (with each reviewer evaluating 3 sets of recommendations [triplicates]) (A) and by a human expert group across 20 cases (B). A Wilcoxon signed-rank test revealed no statistically significant differences between the overall depth of information provided by GPT-4.0 and the human expert group (P = .546). IDM, information density metric; MTB, molecular tumor board.

## Section: Results › Role-associated inter-rater reliability across accounts results in moderate agreement

Triplicate ChatGPT recommendations for each patient were evaluated for consistency using Fleiss’ kappa (Figure 4). The median Fleiss’ kappa was 0.51 (range 0.12-1.0), indicating moderate agreement overall. Outliers in the lowest quartile (Q1 < 0.36) included cases 3, 5, 12, 17, and 19, primarily due to inconsistencies in therapeutic guidance, such as whether to use specific targeted agents or to enroll patients in clinical trials.

To complement the quantitative assessment of ChatGPT’s internal consistency, we performed a qualitative analysis of variability across triplicate outputs for each case. We classified recurring variability patterns into key categories: (i) introduction of novel drug classes, (ii) omission of previously suggested drug classes, (iii) evidence overreach, (iv) hallucinations, (v) expansion of diagnostic suggestions (eg, NGS, rebiopsy), (vi) clinical trial recommendations, and (vii) suggestions for best supportive care. The most frequent features observed included the consistent introduction of novel drug classes (in 18 of 20 cases), omission of prior recommendations (in 5 cases), and trial enrollment suggestions (in 13 cases). A detailed breakdown per case is provided in Figure S4 (including definitions in Table S11).

(A) Bar chart displaying Fleiss’ Kappa values for each clinical case, indicating the level of agreement between different GPT-4.0 accounts in assigning therapy recommendations across replications. (B) Boxplot summarizing the distribution of Fleiss’ Kappa values across all cases, highlighting the overall moderate agreement with a mean Kappa value of 0.51.

## Section: Results › Comparison of LoE of therapy recommendations reveals differences between ChatGPT 4.0 and human expert-derived recommendations

The quality of ChatGPT 4.0’s therapeutic recommendations was further assessed by assigning a LoE rating from 1A (highest) to 4 (lowest) ( Table S1). Both ChatGPT and the hMTB frequently received 1A or moderate-evidence (eg, 2B) ratings (Figure 5A). 1A was the most common for both approaches, with 2B a frequent second. However, ChatGPT occasionally generated lower-level (3 or 4) recommendations—absent or very rare in the hMTB group.

When LoE ratings were compared on a case-by-case basis (ChatGPT average minus hMTB average), divergence emerged in some cases, with the Wilcoxon signed-rank test (P = .0019) suggesting a systematic difference between the 2 groups (Figure 5B).

For Reviewer 1, the mean fraction of low-LoE recommendations per case was 15%, with a median of 0% (range um of 0%-60%). In total, 15% of cases (3 out of 20) contained more than one low-LoE recommendation. For Reviewer 2, the mean was 6%, with a median of 0% (range 0%-82%), again with 15% of cases showing multiple low-LoE outputs. The hMTB completely refrained from giving recommendations with a low-LoE level.

Low-level evidence (LoE 3 or 4) recommendations occurred in a minority of cases, with the highest fractions observed in case 11 (carcinoma of unknown primary), case 13 (esophageal squamous cell carcinoma), and case 15 (glioblastoma). These cases were characterized by a higher number of genetic alterations, including co-occurring amplifications and mutations with varying degrees of clinical annotation.

Comparison of Levels of Evidence (LoE) Assigned to Therapy Recommendations by ChatGPT 4.0 and Human Experts. (A) Bar plots showing the distribution of Levels of Evidence (LoE) for therapy recommendations generated by GPT 4.0 across 3 replicates and by human experts. LoEs range from 1A (strongest evidence) to 4 (weakest evidence). The plots compare the frequency of each LoE category assigned by 2 independent reviewers for GPT 4.0 and human expert recommendations. (B) Average differences in Levels of Evidence (LoE) scores between GPT 4.0-generated therapeutic recommendations and human molecular tumor board (hMTB) recommendations across 20 cases. Bars represent the mean difference in LoE scores, with positive values indicating higher scores assigned by GPT. Error bars denote the standard deviation across 3 replicates. Cases marked with “data incompl.” indicate insufficient data for more than one replicate or missing data for the hMTB group for both reviewers.

## Section: Results › Temporal benchmarking of LLM performance across model versions

To assess whether large language model performance in MTB recommendation tasks improves over time, we re-evaluated 4 representative cases (MTB002, MTB009, MTB018, MTB019) using 3 distinct versions of ChatGPT: GPT-4o (August 2024), GPT-4o (August 2025), and GPT-4o with Deep Research mode (August 2025) and compared results to our baseline ChatGPT 4.0 analysis. Case selection was based on initial IDM scores, LoE variability, and complexity profile:

All models were queried using the original prompt, with the exception of the Deep Research mode, which allowed us to obtain follow-up clarifications (minor, eg, ECOG status or comorbidities). IDM scores for August 2024 GPT-4o ranged from 0.33 to 0.67 (mean: 0.5), with multiple triplicates showing inconsistent or lower-quality therapeutic suggestions. In contrast, both August 2025 models demonstrated increased IDM scores and higher concordance across triplicates (range 0.86-0.89, mean 0.88 (4o-2025) and range 0.67-0.88, mean 0.8 (Deep Research-2025) (Figure 6). Notably, no LoE 3-4 recommendations were identified in the GPT-4o Deep Research outputs. Moreover, Deep Research responses always included study context and rationale—features absent in previous outputs. Sturdy citations were correctly assigned in all 4o-versions.

Temporal benchmarking of LLM performance in MTB recommendations. Information Density Metric (IDM) scores for 4 representative cases (Case 2, Case 9, Case 18, and Case 19) across 4 ChatGPT model versions: GPT-4.0 (baseline), GPT-4o (August 2024), GPT-4o (August 2025), and GPT-4o with Deep Research mode (August 2025). Cases were selected to reflect a spectrum of complexity, initial performance, and reviewer concordance. Bars represent mean IDM scores from triplicate outputs per model version. Temporal progression shows reduced performance for GPT-4o (Aug 2024) compared to baseline, followed by marked improvement in GPT-4o (Aug 2025) and Deep Research outputs, the latter providing textually rich, evidence-cited recommendations. LLM, large language model; MTB, molecular tumor board.

## Section: Results › Efficiency of ChatGPT vs human experts

Finally, the time from receiving patient data to final MTB recommendation was significantly shorter for ChatGPT 4.0 than for the hMTB (P < .001). On average, ChatGPT took a median of 15.2 minutes per case (range 11.0-22.7; IQR 5.2). In contrast, the hMTB required a median of 34.7 minutes per case (range 22.0-48.5; IQR 13.6) (Figure 7). These findings indicate a notable efficiency advantage for the LLM-assisted approach relative to a traditional human-only review.

Time required for preparing MTB cases. Boxplot comparing the time required (in minutes) to prepare MTB (molecular tumor board) cases using a ChatGPT-assisted approach vs human experts. The plot shows that the ChatGPT-assisted approach required significantly less time than the human experts, with the distribution of times displayed for both groups. The P-value of less than .001 indicates a significant difference in preparation time between the 2 methods.

## Section: Discussion

This study provides a systematic evaluation of ChatGPT 4.0 on real-world oncology cases in a Molecular Tumor Board (MTB) setting, focusing on 5 core metrics: recommendation type, information depth, inter-rater consistency, level of evidence (LoE), and efficiency. We assessed 20 anonymized cases in triplicate, comparing ChatGPT 4.0’s performance to that of a conventional human MTB (hMTB). For select cases, we moreover evaluated more modern iterations of ChatGPT (4o in August 2024 and August 2025 as well as deep research in August 2025). The analysis, taking into account the evolution of the GPT-4.0 and GPT-4o models, highlights the dynamics of LLM performance in supporting clinical decisions. Our findings demonstrate a measurable drift in output quality over time, including improved information density, stronger evidence basis, and clearer rationales for treatment suggestions. These improvements appear not only quantitative but qualitative—suggesting that evolving model architectures (eg, GPT-4o) and features (eg, Deep Research) may enhance the reliability of LLMs in high-stakes domains such as precision oncology.

This approach—which we refer to as LLM evolution mapping—offers an important complementary angle to traditional cross-sectional benchmarking studies. It allows stakeholders to monitor progress, detect regression (performance drift), and assess readiness for clinical integration. While we limited our analysis to OpenAI models in this study, future work could apply the same framework to compare other systems (eg, Gemini, Claude, MedPaLM), especially if standard prompts and evaluation metrics can be adopted across LLM platforms. Our findings offer insights into both the promise and limitations of large language models (LLMs) in complex medical decision-making, particularly in precision oncology.

Precision oncology relies on increasingly detailed molecular analyses to guide therapeutic recommendations. While sophisticated diagnostic tests (eg, NGS panels, WES, or WGS) generate voluminous data, clinicians must parse an ever-evolving evidence base spanning preclinical research, clinical trials, and retrospective studies. Human MTBs generally do this through a time-intensive and highly manual process, which is difficult to scale. LLMs, including ChatGPT, could substantially improve workflow efficiency by synthesizing relevant information, screening potential therapeutic avenues, and providing preliminary analysis, thus freeing experts to focus on nuanced decision-making.

For 3 benchmark cancers—colorectal, breast, and non-small cell lung—ChatGPT 4.0 accurately reproduced internationally recognized treatment guidelines without hallucinations. This outcome stands in contrast to evaluations of previous model versions (eg, ChatGPT 3.5, with a ∼70% overlap in breast cancer recommendations24), illustrating the rapid evolution of LLM capabilities.

Diagnostic recommendations largely matched those of the hMTB, suggesting that ChatGPT can effectively process established diagnostic protocols. In contrast, it produced a significantly higher number of therapeutic suggestions. These extra therapeutic options often incorporated preclinical or lower LoE findings, potentially reflecting the model’s broad data ingestion. Although this overabundance may uncover emerging therapies, it risks diverting clinical focus toward less validated interventions—underscoring the importance of expert oversight.

Next, we introduced the Information Density Metric (IDM) to evaluate the balance between correct and incorrect proposals, aiming to capture the greater “information load” that LLMs can offer in gray-zone cases beyond existing guidelines. ChatGPT’s IDM was comparable to that of the hMTB but exhibited slightly higher variability, likely due to its tendency to propose multiple off-label approaches. The IDM effectively penalizes incorrect suggestions while rewarding meaningful correct ones, though small datasets or large numbers of valid options can skew results. Another study comparing 4 LLMs found that while they identified certain crucial therapies, they also diverged substantially from expert recommendations, sometimes in beneficial ways.16 Our findings mirror that duality as ChatGPT can yield unique insights, yet not all suggestions carry robust clinical evidence. A limitation of the current Information Depth Metric (IDM) lies in its equal weighting of all incorrect recommendations. Clinically, distinguishing minor inaccuracies from harmful misinformation is essential to properly quantify AI performance risk. We propose a severity-weighted scoring system for future studies that categorizes incorrect outputs into 3 classes with proportional penalties to better reflect their clinical impact. These include: (1) nonsevere recommendations, which encompass irrelevant or borderline suggestions such as minor imprecisions or therapeutically plausible off-label treatments commonly accepted in molecular tumor board (MTB) practice; (2) medium-severe recommendations, which represent off-label suggestions that, while not currently standard, remain plausible based on molecular rationale or emerging evidence but require cautious interpretation; and (3) severe recommendations, which are contraindicated or potentially harmful suggestions that could negatively impact patient safety or clinical outcomes, such as therapies lacking biological rationale or those contraindicated by tumor biology or patient condition. This graduated approach acknowledges the nuanced nature of MTB decision-making, where many off-label therapies form part of routine but appropriate practice. Incorporating severity-weighted scoring in future evaluations will facilitate more clinically relevant benchmarking of AI-assisted decision support, enabling distinction between minor imprecisions and potentially dangerous errors.

Analyzing Fleiss’ Kappa across triplicate outputs, we observed a median value of 0.51, denoting moderate agreement. Complex, heavily pretreated cases—often involving variants deemed “undruggable” or lacking robust clinical data—drove the greatest variability. Such discrepancies may indicate the model’s uncertainty when authoritative sources are sparse or contradictory. Deviating replicates might be indicative of a forced recommendation where the model had no good answer. Moreover, a stable recommendation repeated throughout all replicates does not inherently indicate correctness, as ChatGPT might consistently propose an inappropriate therapy, as shown above.

LoE offers a critical measure of recommendation quality, highlighting the hierarchy of evidence—ranging from high-level clinical data (eg, prospective trials) to less substantiated or preclinical studies. Both ChatGPT and the hMTB relied heavily on well-established evidence (1A, 2B). However, ChatGPT demonstrated a higher tendency to assign or reference lower LoEs (3 or 4), suggesting that it occasionally elevated less validated treatments to near-equal footing with standard-of-care interventions. While this approach can spot emerging options, it also raises concerns that a generalized LLM might misjudge ambiguous findings. For clinically challenging cases—eg, KRAS- or BRCA1-mutated tumors after multiple therapy lines—ChatGPT often diverged from the hMTB, likely reflecting the model’s broader ingestion of unvalidated data or clinical trials still lacking regulatory approval.

To assess the circumstances under which ChatGPT overreached by suggesting low-evidence or off-label therapies, we analyzed the subset of cases where recommendations were flagged with low levels of evidence (LoE 3 or 4). Specifically, cases 11 (CUP), 13 (esophageal carcinoma), and 15 (glioblastoma) demonstrated the highest fractions of low-LoE suggestions.

In all 3 cases, several converging factors were evident, such as high genomic complexity with multiple co-occurring variants as well as amplifications, especially rare amplifications in glioblastoma. Moreover, tumor entities with few or no standard targeted therapies, including CUP and glioblastoma were part of this subset. An extrapolation to therapeutic classes is not yet guideline-anchored for the specific mutation-tumor combination (eg, PARP inhibitors in BRCA2-mutant esophageal SCC, or RAF inhibitors in GBM).

These examples underscore the model’s tendency to fill clinical gaps with exploratory or preclinical rationales, especially in rare, therapy-refractory, or genomically complex situations. Reviewer disagreement in LoE scoring (see above) further suggests that some overreach occurred in borderline scenarios where clinical evidence is evolving.

Interestingly, while both reviewers flagged these tendencies, the degree of LoE downgrading varied, with Reviewer 1 identifying a higher proportion of low-evidence suggestions than Reviewer 2. We interpret this divergence not as inconsistency, but as a realistic reflection of clinical variability in molecular tumor board (MTB) assessments. Even among experienced experts, the classification of evidence—especially in genomically complex or poorly characterized cases—can be influenced by local experience, interpretation of emerging data, and the perceived plausibility of therapeutic hypotheses. This underscores the importance of incorporating structured evidence scoring, transparency mechanisms (eg, citation tagging), and interactive oversight into future LLM-assisted clinical workflows to ensure safe and interpretable deployment.

A pivotal discovery was ChatGPT’s ability to generate recommendations in significantly less time than the hMTB (15.2 vs 34.7 minutes on average). This aligns with our premise that LLMs can expedite certain aspects of the MTB workflow. However, preparing prompts, verifying outputs, and reformatting erroneous suggestions still demand expert vigilance. Consequently, the net benefit depends on how effectively clinicians integrate ChatGPT’s analysis into their decision-making pipeline, minimizing the overhead of verifying dubious recommendations. In this study, the measurement of elapsed time for generating recommendations with ChatGPT and the human molecular tumor board (hMTB) commenced from the point at which all requisite clinical data were fully collated and available for processing. For ChatGPT, this included the time to prepare and format the patient’s clinical details into a standardized prompt. For the hMTB, timing began once case summaries and relevant information were manually prepared for expert consideration. This design ensured that timing reflected the active recommendation generation phase exclusively, excluding subsequent multidisciplinary panel discussions, which are integral and common to both workflows.

While our results demonstrate that ChatGPT produced recommendations more rapidly than the hMTB in terms of raw generation time, this metric underestimates the overall clinical workflow cost. Expertise is required to critically validate, interpret, and amend AI-generated outputs before safe application, imposing cognitive and temporal burdens not captured by raw processing time alone. Furthermore, clinical decision-making incorporates patient safety considerations that necessitate expert oversight beyond recommendation drafting.

Therefore, clinical efficiency should be conceptualized as a multidimensional construct, encompassing not only time to generate outputs but also expert validation effort, cognitive load, and safety governance. Future investigations should develop frameworks that integrate these factors to fully elucidate the impact of LLMs on molecular tumor board workflows and precision oncology practice.

Although ChatGPT 4.0 can streamline certain tasks, it does not replace expert teams. Notably, the higher volume of recommended therapies—some with low LoE—illustrates areas where LLM-derived advice conflicts with conventional clinical reasoning. This tension underscores that while LLMs perform well at spotting patterns or referencing multiple sources, they can lack the nuanced risk–benefit calculus that experienced oncologists apply. In standard or guideline-driven cases, ChatGPT’s track record was strong, but more complex, rare, or heavily pretreated cases exposed its shortcomings.

Several limitations must be critically acknowledged. First, we used a limited gene panel that may not reflect current next-generation sequencing practices, which often involve hundreds of genes or whole-exome analysis. Second, ChatGPT 4.0 was evaluated with a knowledge cutoff of September 2021, excluding newly published guidelines or trial outcomes. Third, experts themselves sometimes rely on data unavailable to the LLM, such as proprietary publications, restricting direct comparability. Finally, systematically assessing newer LLMs becomes increasingly difficult when it is unclear what data or publications are integrated into their training. The use of a focused gene panel inherently limits the genomic scope of our analysis. While this reflects common clinical practice during our study period, it leaves out the vast complexity that whole-exome sequencing (WES) or whole-genome sequencing (WGS) would introduce. A typical WES can yield 25 000 to 50 000 variants (and WGS ∼3 million) per patient, resulting in 10 to 20 variants after filtering. This breadth of data is higher in comparison to the variants reported in our cohort. An LLM like ChatGPT will most likely exhibit different behavior and limitations. More variants, especially when generated by WES might lack clear clinical significance or prior documentation, which could confuse the model’s analysis or lead it to prioritize spurious associations. The model might struggle to identify the truly impactful mutations and moreover struggle in prioritization and combination of findings. This increases the risk of hallucinations or irrelevant recommendations as the LLM attempts to connect disparate findings. In a WES/WGS scenario, even after filtering, the final set of candidate variants might comprise between 5 and 15 variants which is already at a scale where the mechanisms described might already be in place. In practice, current LLMs are constrained by input length and might need to omit or summarize data; thus, an expanded genomic input could dilute the focus and accuracy of its outputs. We acknowledge that ChatGPT’s performance may degrade or change unpredictably with larger, more complex mutational profiles, and future work should explore strategies for handling increased input complexity and breadth (eg, intelligent variant filtering or tiered analysis) to mitigate information overload. Fundamentally, rigorous evaluation of LLM behavior on WES/WGS and higher dimensional data is needed, as performance observed on small panels may not directly extrapolate to genome-scale inputs. Future studies should test these models in expanded genomic contexts to identify new failure modes and adaptation requirements.

To evaluate clinical relevance and molecular complexity, all actionable genomic alterations were annotated according to the ESMO Scale for Clinical Actionability of Molecular Targets (ESCAT).25 Tier assignments followed peer-reviewed ESCAT definitions and incorporated evidence current to 2024, including tumor-specific data from regulatory approvals, clinical guidelines, curated knowledge bases (eg, OncoKB), and peer-reviewed literature. For example, PIK3CA mutations were classified as Tier IIIA in colorectal cancer, reflecting limited evidence, but as Tier IIB in ovarian cancer, supported by early-phase trial data suggesting clinical benefit (Tables S7 and S10).

Applying a threshold of ESCAT Tier IIB or higher 50% of cases in our cohort harbored at least one targetable alteration, with no case containing more than 2 such alterations. This distribution reflects a realistic spectrum of actionability and molecular complexity, consistent with real-world MTB populations, and underscores the relevance of this cohort for evaluating decision-support interventions such as large language models.

A key strength of this study is the consecutive inclusion of patient cases, designed to mirror real-world practice and avoid selection bias. By doing so, our cohort captures the typical distribution of tumor entities encountered in routine MTB workflows at our institution. However, we benchmarked our pilot cohort against Höfflin et al. (2021; n = 488) and AACR Project GENIE v18.0-public (n = 250 363; Pugh et al., 2022). Median age at genomic testing (56 years) closely matched Höfflin (54 years) and was slightly younger than GENIE (61 years; range <1 to >89). Sex distribution was balanced (50% female), consistent with both reference datasets (47% and 52%).

Our case mix reflected routine MTB practice, spanning common cancers (breast, colorectal, CNS) and rarer entities (CUP, ovarian, skin), paralleling Höfflin’s series. In contrast, GENIE mirrored the broader oncology landscape, with proportionally more prostate and lung cancers. MTB cohorts are characteristically enriched for genomically complex or therapy-refractory cases; however, such rare and molecularly complex tumors represent a minority rather than the majority of cases, as seen in our cohort and in external datasets.

Recurrent alterations in PIK3CA, BRCA2, KRAS, and BRAF were shared across all 3 datasets, indicating that despite its smaller size, our cohort captures a comparable molecular landscape. Differences in mutation frequencies likely reflect variation in sample size, sequencing platforms, and tumor distribution.

Consecutive enrollment minimized selection bias, and harmonized DNPM criteria ensured alignment with national precision oncology practices. While limited sample size constrains subgroup analyses—particularly for rare tumors—a focused evaluation of large language model (LLM) performance in these subgroups will require larger, dedicated cohorts. Rather than benchmarking institutional outcomes, this study provides an exploratory assessment of LLM integration into real-world MTB decision-making.

Clinical information extracted from original German MTB case documents was manually translated and formatted into standardized English prompts for ChatGPT 4.0. This approach guaranteed consistent input data, while human experts reviewed the original German content. English was selected as the prompt language because GPT models are predominantly trained on English datasets, with better accuracy and coherence in this language.26,27 Instruction-tuned language models trained primarily in English can transfer capabilities to other languages but with some degradation in factual accuracy and fluency when used in less represented languages or mixed-language prompts. By maintaining a single-language prompt, we aimed to minimize linguistic variability. Investigating the effects of native-language or multilingual prompting on LLM recommendation quality remains an important area for future study.

Another notable limitation of this study is the reliance on recommendations from a single institutional MTB at the CCCA. While this reflects standard clinical practice and ensures consistency in data collection and expert review, it inherently limits the generalizability of the findings. Furthermore, no formal inter-institutional benchmarking or blinded grading of hMTB recommendations was conducted, and we did not assess inter-rater reliability across different expert teams. This limits direct comparison to the observed internal variability of ChatGPT outputs (median Fleiss’ κ = 0.51). Notably, prior work by Rieke et al. demonstrated that considerable variability can also occur between independent MTBs when reviewing identical virtual oncology cases, highlighting that interpretive divergence is an intrinsic feature of precision oncology practice, even among human experts.28

To address these important aspects, a multi-institutional benchmarking initiative is currently underway within the Bavarian Cancer Research Center (BZKF). In this ring trial, all MTBs from the university hospitals in Bavaria independently review and provide recommendations for pseudonymized, real-world oncology cases. These recommendations are then systematically compared, offering a valuable dataset for assessing inter-MTB concordance and expert consensus. While this study is not yet published, it is expected to provide a standardized reference and blueprint for future evaluations of both human and LLM-generated outputs.

Our present study should therefore be considered complementary to this effort, with its focus on assessing the feasibility, consistency, and quality of ChatGPT 4.0 in generating MTB recommendations. Future research should integrate findings from such benchmark initiatives to enable blinded, multi-institutional comparisons and to contextualize LLM performance not only against guideline standards, but also within the realistic variability observed among expert tumor boards.

Another limitation of our study is that ChatGPT’s therapeutic recommendations were generated on a per-variant basis without explicit prioritization among multiple actionable alterations. Our prompting strategy elicited separate, variant-specific responses rather than integrated, ranked treatment plans. Therefore, the model’s ability to differentiate or prioritize competing therapeutic options remains unclear. Evaluating such prioritization is clinically important, as precision oncology frequently requires balancing multiple actionable targets. Future investigations should specifically address how language models can integrate complex molecular data to produce hierarchically ordered treatment recommendations, reflecting real-world clinical decision-making priorities.

Increasing LLM reliability may involve incorporating domain-specific data, retrieval augmentation, or fine-tuning with carefully curated clinical datasets.24,29 Hybrid models that combine foundation-level understanding with specialized medical modules could achieve more precise evidence prioritization while preserving the flexible reasoning capabilities of large models. For instance, the RECTIFIER trial used GPT-4.0 with advanced natural language processing for eligibility screening in heart failure, surpassing traditional methods in both speed and accuracy.30 Comparable approaches in oncology may accelerate patient eligibility checks for clinical trials, reduce manual annotation, and provide more transparent reasoning.

Still, transparency in AI-generated outputs remains a major challenge. Clinicians require insight into how models produce specific suggestions or LoE assignments, especially where key references or evidence bases are lacking. Opaque “black-box” behaviors erode trust in AI-driven recommendations, particularly when suggestions deviate from established norms. An equally important concern for clinical deployment is the explainability of an LLM’s recommendation. Unlike traditional algorithms that might offer clear decision rules, LLMs operate as black boxes, leaving clinicians wondering why a particular suggestion was made. Lack of transparency is a known barrier to trust, and clinicians are understandably hesitant to act on recommendations they cannot validate. To increase clinician confidence and ensure safe use, future iterations of systems like ChatGPT should incorporate mechanisms for visible reasoning and evidence tracking. One promising approach is citation-enabled output, where the LLM’s response is augmented with references to guidelines, textbooks, or peer-reviewed studies supporting each claim. For example, an LLM-generated diagnostic suggestion could be accompanied by a citation to relevant medical literature and even a note linking it to the patient’s specific data points. In our approach, we asked for citation-backed outputs which were linked to correct source citations, as assessed by single lookups in every case. Such evidence tagging allows clinicians to verify facts more easily and see the basis of the LLM’s conclusion, turning the model’s black-boxed reasoning into a more transparent, auditable process. Additionally, integrating a form of confidence scoring for each recommendation could further enhance transparency. If the model communicated uncertainty, trust could be modulated accordingly, allowing for signaling of confidence or unreliability of answers.

In the future, combining these features—grounding responses in citations, highlighting supporting evidence, and indicating confidence levels—may significantly improve the explainability of LLMs. Especially with the advent of reasoning or “deep research” model functionalities, these tools can already be envisioned.31 Ultimately, enhancing transparency ∂through these mechanisms is critical for building the trust required for clinical use of AI models, and we envision that future clinical LLMs will operate in a “glass box” mode, where every recommendation comes with an audit trail of why it was made and how strongly the model supports it. This will be essential to ensure that generative AI systems can be safely integrated into genomic medicine and other high-stakes healthcare workflows.

The integration of LLMs into clinical workflows also raises important ethical, legal, and regulatory considerations. Patient data privacy, model accountability, and potential medico-legal liability are all relevant concerns—particularly if AI-generated recommendations are acted upon without human verification. Responsible deployment of such tools will require rigorous oversight, transparent audit trails, and regulatory frameworks that ensure human oversight remains central to clinical decision-making. Future systems should be designed to support traceability of outputs, confidence scoring, and evidence attribution. Deployment of frameworks must evolve beyond raw performance metrics. First, auditability and traceability are essential: every model output should be logged, timestamped, and versioned to support regulatory compliance and retrospective validation. Second, AI tools should function within hybrid clinician workflows, where expert users validate or reject suggestions and generate feedback for system improvement. Additionally, mechanisms for continuous model updating, linked to current guidelines and clinical trial registries, are critical to maintaining relevance in a rapidly evolving field.

Institutional oversight will also be key. We envision LLMs being evaluated and credentialed like other clinical decision support systems, with appropriate governance, documentation, and user training. Finally, AI systems must be adapted to local contexts—factoring in trial access and institutional protocols—and tested in blinded, multi-institutional benchmarking efforts to ensure broad generalizability and safety.

Our results suggest that ChatGPT 4.0—and potentially other advanced LLMs—could serve as a first-pass screening or triage tool, flagging putative therapeutic leads. The hMTB would then validate these recommendations, applying real-world considerations like drug accessibility, patient tolerance, comorbidities, and cost-effectiveness. This hybrid model leverages AI’s speed in scanning voluminous data while safeguarding clinical rigor through human expertise. Similar paradigms have already proved successful in other medical domains, from chronic hepatitis C management to kidney disease.32–34

However, a major consideration is whether adding LLM-based suggestions introduces additional complexity or fosters genuine efficiency. In certain cases, the hMTB’s thorough knowledge might render ChatGPT input redundant. Effective implementation, thus, demands well-defined processes: establishing thresholds for reviewing AI-proposed therapies, clarifying how to address “off-label” or low-evidence recommendations, and developing standardized prompts and data inputs.

## Section: Conclusion

ChatGPT 4.0, though not specifically trained in medical contexts, shows considerable promise for generating therapy recommendations in precision oncology. In standard guideline-driven settings, it closely aligns with expert judgments, offering a rapid synthesis of common therapeutic interventions. In more complex scenarios, ChatGPT broadens the scope of possible treatments, yet it may rely on lower-level evidence. While this can uncover options human experts might overlook, it also underscores the model’s limitations in applying real-world clinical priorities.

Our findings reinforce the value of a hybrid approach that combines the strengths of AI—efficiency, rapid data integration, and comprehensive recall—with the critical judgment and contextual understanding that seasoned oncology experts offer. As LLMs evolve, the goal is to move from a disruptive technology to a transparent, interpretable, and fully integrated component of MTB workflows. Ongoing work should examine how best to incorporate current data sources, maintain transparent reasoning, and balance the need for speed against the ethical and clinical responsibilities inherent in cancer care.

## Section: Acknowledgments

The open access publication of this article was supported by the DFG-sponsored Open Access Fund of the University of Augsburg. The open access publication of this article was supported by the University of Augsburg. We also thank Sabrina Kepp for her valuable assistance during the project, particularly in coordinating multiple iterations of the prompting process.

## Section: Contributor Information

Maximilian Schmutz, Department of Hematology and Oncology, Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany; Department of Data Management and Clinical Decision Support, Faculty of Medicine, University of Augsburg, Augsburg 86356, Germany; Bavarian Cancer Research Center (BZKF), Erlangen 91054, Germany.

Sebastian Sommer, Department of Hematology and Oncology, Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany.

Julia Sander, Department of Data Management and Clinical Decision Support, Faculty of Medicine, University of Augsburg, Augsburg 86356, Germany.

David Graumann, Department of Hematology and Oncology, Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany.

Johannes Raffler, Department of Data Management and Clinical Decision Support, Faculty of Medicine, University of Augsburg, Augsburg 86356, Germany; Bavarian Cancer Research Center (BZKF), Erlangen 91054, Germany.

Iñaki Soto-Rey, Department of Data Management and Clinical Decision Support, Faculty of Medicine, University of Augsburg, Augsburg 86356, Germany; Bavarian Cancer Research Center (BZKF), Erlangen 91054, Germany.

Seyedmostafa Sheikhalishahi, Department of Data Management and Clinical Decision Support, Faculty of Medicine, University of Augsburg, Augsburg 86356, Germany.

Lisa Schmidt, Faculty of Medicine, University of Augsburg, Augsburg 86195, Germany.

Leonhard Paul Unkelbach, Faculty of Medicine, University of Augsburg, Augsburg 86195, Germany.

Levent Ortak, Faculty of Medicine, University of Augsburg, Augsburg 86195, Germany.

Tina Schaller, General Pathology and Molecular Diagnostics, Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany.

Sebastian Dintner, General Pathology and Molecular Diagnostics, Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany.

Kathrin Hildebrand, General Pathology and Molecular Diagnostics, Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany.

Michaela Kuhlen, Pediatrics and Adolescent Medicine, Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany.

Frank Jordan, Department of Hematology and Oncology, Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany.

Martin Trepel, Department of Hematology and Oncology, Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany; Bavarian Cancer Research Center (BZKF), Erlangen 91054, Germany; Comprehensive Cancer Center Augsburg (CCCA), Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany.

Christian Hinske, Department of Data Management and Clinical Decision Support, Faculty of Medicine, University of Augsburg, Augsburg 86356, Germany.

Rainer Claus, Department of Hematology and Oncology, Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany; Bavarian Cancer Research Center (BZKF), Erlangen 91054, Germany; General Pathology and Molecular Diagnostics, Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany; Comprehensive Cancer Center Augsburg (CCCA), Faculty of Medicine, University of Augsburg, Augsburg 86156, Germany.

## Section: Author contributions

Maximilian Schmutz (Conceptualization, Data curation, Formal analysis, Investigation, Methodology, Project administration, Resources, Software, Supervision, Validation, Visualization, Writing—original draft, Writing—review & editing), Sebastian Sommer (Conceptualization, Data curation, Formal analysis), Julia Sander (Conceptualization, Methodology, Writing—review & editing), David Graumann (Formal analysis, Investigation, Visualization, Writing—original draft, Writing—review & editing), Johannes Raffler (Writing—review & editing), Inaki Soto-Rey (Writing—review & editing), Seyedmostafa Sheikhalishahi (Conceptualization, Methodology, Resources, Writing—review & editing), Lisa Schmidt (Data curation, Investigation, Methodology, Resources, Writing—review & editing), Leonhard Paul Unkelbach (Data curation, Investigation, Methodology, Resources, Writing—review & editing), Levent Ortak (Data curation, Investigation, Methodology, Resources, Writing—review & editing), Tina Schaller (Data curation, Resources, Writing—review & editing), Sebastian Dintner (Resources, Writing—review & editing), Kathrin Hildebrand (Resources, Writing—review & editing), Michaela Kuhlen (Methodology, Resources, Supervision, Writing—review & editing), Frank Jordan (Supervision), Martin Trepel (Resources, Supervision, Writing—review & editing), Christian Hinske (Resources, Supervision, Writing—review & editing), and Rainer Claus (Conceptualization, Investigation, Methodology, Project administration, Resources, Supervision, Writing—review & editing)

## Section: Supplementary material

Supplementary material is available at The Oncologist online.

## Section: Funding

This research received no external funding.

## Section: Conflicts of interest

The authors have no conflicts of interest to declare.

## Section: Data availability

The data underlying this article will be shared on reasonable request to the corresponding author.

## Section: Associated Data › Data Availability Statement

The data underlying this article will be shared on reasonable request to the corresponding author.


---

# Large Language Models and Their Applications in Drug Discovery and Development: A Primer

- **Authors:** James Lu, Keunwoo Choi, Maksim Eremeev, Jogarao Gobburu, Srijib Goswami, Qi Liu, Gary Mo, Cynthia J Musante, Mohamed H Shahin
- **Issuer:** Clinical and translational science
- **Type:** Scientific article
- **Published:** 2025-04-01
- **Language:** en
- **DOI:** 10.1111/cts.70205
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40208836/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

ABSTRACTLarge language models (LLMs) have emerged as powerful tools in many fields, including clinical pharmacology and translational medicine. This paper aims to provide a comprehensive primer on the applications of LLMs to these disciplines. We will explore the fundamental concepts of LLMs, their potential applications in drug discovery and development processes ranging from facilitating target identification to aiding preclinical research and clinical trial analysis, and practical use cases such as assisting with medical writing and accelerating analytical workflows in quantitative clinical pharmacology. By the end of this paper, clinical pharmacologists and translational scientists will have a clearer understanding of how to leverage LLMs to enhance their research and development efforts.

## Section: Introduction

The advent of artificial intelligence (AI) has ushered in a new era of innovation across various fields, including drug discovery and development [1, 2, 3]. Large language models (LLMs), such as GPT‐4, have demonstrated remarkable capabilities in processing and generating human‐like text and programming codes, offering unprecedented opportunities to enhance several aspects of the drug discovery and development processes [4].

Prior reviews have underscored the importance of Natural Language Processing (NLP) in Model Informed Drug Development (MIDD) [5] and pharmacology [6]. They highlighted NLP's role in enhancing drug discovery, clinical trials, and pharmacovigilance through functionalities like named entity recognition and relation extraction.

Since the release of ChatGPT, there has been a rapid increase in both the number of LLMs [7, 8] and their uptake in the biomedical domains [9]. In [10], Peter Lee et al. highlight the transformative impact of GPT‐4 on healthcare, including diagnostics, personalized treatment, and medical research. It discusses practical applications and ethical considerations, showcasing AI's potential to revolutionize patient care. Due to the anticipation that LLMs would permeate every area of health care, a thorough tutorial was developed to help the biomedical informatics community harness them effectively [11].

Recent studies have further illustrated applications and limitations of LLMs in pharmacometrics. Shin et al. [12] evaluated the capabilities of ChatGPT and Gemini LLMs in generating NONMEM code, finding that while these models can efficiently create initial coding templates, the output often contains errors requiring expert revision. Cloesmeijer et al. [13] further explored the capability of LLMs in supporting model simulations and R‐Shiny implementation. These efforts offer a glimpse into a promising future where LLMs could significantly assist with pharmacometrics tasks, albeit with the need for human oversight.

This primer offers clinical pharmacologists (CP) and translational scientists (TS) insights for leveraging LLMs to enhance their research and development workflows and lists helpful resources for implementing LLM‐based technologies effectively. CP and TS have distinct needs that include gathering and integrating information from multiple sources, often across several disciplines. Furthermore, given their use of clinical data, CP and TS professionals must be mindful of ethical and privacy considerations in the usage of LLMs. In this primer, we examine the category of general‐purpose LLMs trained on human textual language [4]; specialized LLMs that are trained on specific scientific languages (such as gene and protein sequences) are not the primary focus of this primer. By providing fundamental concepts, application areas (as shown in Figure 1), concrete use cases as well as links to useful tools (see Supporting Information), we aim to bridge the gap between AI advancements and their practical utility in drug discovery and development. Furthermore, it addresses the challenges and limitations associated with LLMs, providing a balanced perspective on their potential and areas for future improvement. Through these discussions, we hope to empower CP and TS to leverage the full potential of LLMs in their work.

Potential applications of LLMs in drug discovery and development. LLMs, large language models; PD, pharmacodynamics; PK, pharmacokinetics; RWD, real‐world data.

## Section: Fundamentals of Large Language Models

A schematic representation of how input text is tokenized and fed to the LLM to generate the next word. LLM, large language model.

Glossary of terms.

Different ways of using LLMs for various tasks.

An illustration of the components of a prompt, which helps the LLM to give the user desired output.

## Section: Fundamentals of Large Language Models › What Are Large Language Models?

An LLM is a type of deep neural network that has been trained on massive amounts of text data, designed to comprehend, generate, and respond to human‐like text [14]. The “large” in LLMs refers both to the model size as reflected by the number of trainable weights as well as the immense size of the data set on which it has been trained on. LLMs are an example of a Foundation Model [15], as they are large‐scale models that have been pre‐trained and serve as a versatile base for a variety of downstream tasks. They are trained to take in a sequence of words from a text and predict the next word. It turns out that the task of next‐word prediction [16] compels the LLM to learn the relationship between words within texts and derive comprehension of the context. Through the self‐supervised learning process of next‐word prediction, LLMs have emerged with remarkable capabilities to understand and generate human‐like text in a way that was unexpected to many researchers [14].

## Section: Fundamentals of Large Language Models › Key Terminologies and Concepts

Tokenization is a crucial first step in preparing text data for training LLMs—which entails splitting the text into the chosen basic units, tokens—that the LLMs process. Depending on the tokenization scheme chosen, the resulting tokens can be words, subwords, or even individual characters. Next, these tokens are converted from strings to integers to produce token IDs via the use of a vocabulary, mapping each unique token to a unique integer. The token IDs are subsequently converted into embedding vectors (further explained below), which are then fed into the LLM. See Figure 2 for a schematic representation of the above‐described process.

Based on the transformer model [17], which utilizes the attention mechanism, LLMs process the input text data much more efficiently and effectively than the recurrent neural networks (RNNs) [18]. Unlike RNNs, which process text sequentially, transformers leverage the attention mechanism to consider all input tokens simultaneously, thus enabling parallel processing and capturing long‐range dependencies within the text. This attention mechanism assigns weights to different parts of the input sequence, allowing the model to focus on the most relevant words for a given task.

A key component in understanding transformers is the concept of embeddings. Embeddings are dense vector representations of tokens in a fixed‐dimensional space [16]. These vectors capture semantic relationships: for example, words with similar meanings will have similar embeddings, facilitating the model's ability to generalize and make predictions based on learned associations [16]. To handle the sequential nature of language data, transformers also incorporate positional encoding [17], which is achieved by adding a unique, position‐specific vector to each token's embedding. This allows the model to differentiate between tokens based on their position in the sequence, thus preserving the syntactic and semantic structure of the input text. Together, embeddings and positional encoding enable the transformer's ability to comprehend intricate relationships between words.

Context size, also referred to as the context window, is a commonly mentioned concept in the use of LLMs. It dictates the amount of preceding text the model can consider when generating the next token. A larger context size gives the LLM access to more extensive relevant information, such as a whole document relevant to the query, resulting in potentially better comprehension of the relevant material and enabling it to produce more accurate responses. The context size for LLMs ranges from ~8 K for Llama3, ~128 K tokens for GPT‐4, to ~200 K tokens for Claude by Anthropic, to around 1 million tokens for Gemini 1.5 Pro from Google; see [19] for a comparison across commonly used LLMs.

To summarize the inner workings of the LLMs: the input tokens are passed in, their embeddings computed, which together with their positional encoding are taken through transformer blocks, resulting in the logits that are used for deriving the next token's probabilities [14]. To convert the computed logits to the predicted token probabilities, temperature scaling is applied before passing in a softmax layer [14], which ensures that the probabilities of the next token are appropriately normalized to sum up to 1. Note that the temperature scaling is an important parameter in the generation of text by LLMs, impacting the diversity and creativity of the generated content [14]. This method introduces a probabilistic selection process in the next token generation task, allowing for control between either more varied and potentially innovative outputs when the temperature is high (close to 1), or more predictable and potentially conventional outputs when the temperature is low (close to 0).

Finally, Reinforcement Learning from Human Feedback (RLHF) is a technique designed to align LLMs with human intentions by incorporating direct human feedback into the training process [20]. This method involves three key steps: first, the model undergoes supervised fine‐tuning using a data set of human‐provided demonstrations to illustrate desired behaviors. Subsequently, a reward model is trained to predict human preferences by having human evaluators rank various model outputs based on their alignment with user instructions. Finally, the LLM is fine‐tuned further using reinforcement learning algorithms, where the reward model's scores act as the reward signal. This iterative process helps the model generate responses that are better aligned with the human intent, thereby increasing the impact of LLMs in applications.

For a glossary of commonly used terms associated with LLMs, please refer to Table 1.

A schematic representation of how input text is tokenized and fed to the LLM to generate the next word. LLM, large language model.

Glossary of terms.

## Section: Fundamentals of Large Language Models › Prompt Engineering

Since LLMs have been primarily trained for next word prediction [14], optimizing them for specific tasks relies on effective prompt engineering. By carefully designing the input prompts given to these models, users can guide the LLMs to generate more accurate and relevant outputs by providing the appropriate context.

LLMs are versatile in their functionality, and zero‐shot learning [21, 22] refers to the capability to generalize to entirely new tasks without having encountered any specific examples beforehand.

In comparison, few‐shot learning [23] refers to the ability of LLMs to learn from a few examples the user provides as part of the input prompt [14]. Chain‐of‐Thought (CoT) prompting [24] refers to the approach whereby instead of expecting the LLMs to provide the desired output from just the input, they are also requested to provide the intermediate steps in reaching the output. This is analogous to how humans typically break a larger problem into smaller subparts, each of which may involve logical deductions, and the result of each intermediate step is used in the subsequent one. As shown in [24], as the LLMs increase in size, more reasoning capabilities can be unlocked with CoT, and hence increase its benefits in applications. For examples of prompting approaches mentioned, refer to Table 2. An illustration of the key components of a prompt is shown in Figure 3.

Different ways of using LLMs for various tasks.

An illustration of the components of a prompt, which helps the LLM to give the user desired output.

## Section: Fundamentals of Large Language Models › Improving Accuracy and Relevance

In scientific applications, the accuracy and relevance of information generated by LLMs are crucial for making advancements in research and informing decision‐making. However, it is well known that LLMs can often confabulate (or hallucinate) information [11] if they are not grounded on facts and/or data relevant to the application area of interest. Thus, methods to further improve the accuracy and provide citations for the generated information are crucial to build confidence and trust in LLM applications.

Retrieval‐augmented generation (RAG) [25] is a widely used approach that combines two powerful techniques: retrieval and generation. First, information pertinent to the application of interest, such as documents (e.g., scientific papers, manuals, model codes, etc.), is collected and preprocessed by splitting it into smaller chunks, such as paragraphs, which are subsequently converted to embeddings (i.e., numeric vector representations) and stored in a vector database that the LLM can utilize. When a user query is received by the LLM, it is converted to the same embedding space, and a similarity search is performed within the vector database to identify the most relevant information. The original query is then augmented with the retrieved information as additional context, which is then passed to the LLM to generate the response. It has been shown [26] that RAG can significantly enhance the accuracy of LLMs as compared to CoT prompting.

Fine‐tuning a pretrained LLM on domain‐specific data to adapt it to a specific task is another way to improve performance [14]. In the context of chemical text mining, it has been shown that fine‐tuning can improve the model's performance substantially as compared to prompting [27].

In the context of using LLM for medical question answering, instruction fine‐tuning on the PaLM2 model gave rise to the Med‐PaLM 2 that demonstrated substantial improvement in performance on multiple benchmarks [28]. While offering performance improvements, fine‐tuning over a large set of model parameters can entail a high computational burden [11]. Hence, parameter‐efficient fine tuning (PEFT) methods such as low‐rank adaptation (LoRA) [14, 29, 30] limit model weights that are updated in the training process to lie within a smaller dimensional subspace of the complete weight parameter space, thereby reducing the computational resources required. In addition, the model weight updates obtained from the LoRA training process can be saved separately from the original model weights, thereby reducing the storage requirements and enabling the storage of multiple versions of an LLM, each customized to a particular data set [14].

## Section: Applications of Large Language Models in Drug Discovery and Development

In this section, we explore five key applications of LLMs schematically illustrated in Figure 1, each discussed within its subsection.

## Section: Applications of Large Language Models in Drug Discovery and Development › Therapeutics‐Focused Large Language Models

The availability and widespread use of LLMs have inspired many researchers to explore applications in their workflow. The prevalence of errors and misinformation from general application LLMs, such as ChatGPT, has highlighted the need for domain‐specific, next‐generation LLMs for biomedical research [31]. The ability of LLMs to process natural language and work with unstructured data to provide native language responses allows application in various processes in drug discovery and development.

Liang et al. developed a tool called DrugChat [32], which consists of a graph neural network (GNN), LLM, and an adaptor. DrugChat uses a molecular graph of a compound as input, predicts various characteristics, and allows users to prompt various questions, particularly about physical and chemical properties, but can also expand into questions related to later stages of drug development.

The development of domain‐specific LLMs for biomedical research is not only being led by biotech and pharmaceutical companies. Google recently developed Tx‐LLM [33], a generalist model trained on a wide variety of tasks. The developers envision the tool as an end‐to‐end therapeutic development solution, spanning from early‐stage (e.g., target discovery) to late‐stage development (e.g., clinical trial approval strategy). In their initial report, the developers demonstrated the tool's ability to identify genes associated with type 2 diabetes, predict binding affinities of candidate molecules for the target protein, predict potential toxicities of candidate molecules, and assess the probability of clinical trial approval.

## Section: Applications of Large Language Models in Drug Discovery and Development › Drug Discovery

As reviewed in [34], LLMs can facilitate target identification by mining biomedical literature to unveil connections between targets, genes, and diseases.

There are significant opportunities for implementing LLM in early discovery. AI has been widely explored for quantitative structure–activity relationship (QSAR) optimization, with many efforts using machine learning (ML) and deep learning (DL) to understand complex relationships—a good fit given the nature of the discipline. There are opportunities for LLM to streamline QSAR efforts. NLP has been successfully implemented to process QSAR data into vectors that are compatible with various ML and DL algorithms [35]. Although these NLP techniques were not LLM based, incorporating LLMs for this application may further expand the compatibility of source data. The ability of LLM to work with different data structures, including unstructured data, allows for the aggregation of a wide range of source data, enabling more complex analyses.

LLM can also be applied to compound synthesis. The advancements in robotic automation, which are already controlled by computer algorithms, offer opportunities for LLMs to be involved in the design and execution of bench experiments. Boiko et al. [36] presented a multi‐LLM‐based intelligent agent capable of automating the design, planning, and performance of complex scientific experiments, such as compound synthesis. The system is capable of performing web searches, document searches, writing and executing code, and manipulating robotic experimental platforms. The end‐to‐end automation opportunity with LLM can extend to other processes that utilize autonomous infrastructures.

Finally, LLMs are increasingly used in target safety assessments across industries like pharmaceuticals and chemicals. These models analyze vast amounts of data, including research papers and safety reports, to predict risks associated with specific targets. In drug development, LLMs help identify toxicological risks by correlating molecular structures with safety profiles. They also assist in assessing environmental hazards by interpreting regulatory guidelines and historical data.

## Section: Applications of Large Language Models in Drug Discovery and Development › Preclinical Research

Toxicology has seen significant advancements with the integration of AI, particularly through the use of ML and DL to predict toxicological signals. However, one of the main limitations of these approaches is the availability of compatible data. LLMs offer rapid and efficient processing of data from various sources, which is immensely valuable for the thorough and accurate curation of preclinical and clinical safety data.

Silberg et al. [37] demonstrated that LLMs could generate accurate and comprehensive summaries of toxicological findings from drug labels, leading to the development of UniTox [37], a database that spans numerous types of toxicities and is likely the largest human database covering almost all approved medications. The summaries produced by LLMs were validated against established toxicology databases, such as DICTrank and DILIrank, showing good concordance. Additional validation by clinicians showed that the toxicities annotated by LLMs were in high degree of agreement with assessments made by human experts. The ability to quickly and thoroughly assess safety profiles of compounds allows for databases like UniTox to be continuously updated with minimal human effort. Although the validation results were impressive, there are still misalignments that necessitate the need for human supervision and review of LLM outputs.

The potential opportunity of using LLM for data interpretation to circumvent human bias can also be implemented in the preclinical space. Berce et al. [38] described the use of LLM in generating clinical score sheets that are used to assess animal health and behavior during animal studies to minimize animal distress during study conduct. Different LLMs were evaluated [38] to generate clinical score sheets for a mouse model of inflammatory bowel disease. Although the LLMs evaluated performed well, there were instances of hallucinations and the generation of incorrect or irrelevant information, which emphasizes the need for human review. Such findings led the authors to advocate that LLMs should only be used for generating the initial draft, while human input is still needed to complete the final report.

The use of LLMs for complete automation is also being explored for complex analyses such as pharmacokinetics and pharmacodynamics (PKPD) modeling of preclinical data. As previously discussed, Shin et al. [12] demonstrated that ChatGPT and Gemini can generate content to support the use of NONMEM for PKPD analysis. Although NONMEM is most notably used for clinical PKPD modeling, it is frequently employed for modeling preclinical data gathered from animal studies. The authors showed that the LLMs were able to generate training materials for NONMEM, providing an overview of NONMEM code structure, and generating code for NONMEM analyses using simple lay language prompts. While the generated code was not fully reproducible and contained errors that required correction by an experienced user, LLMs offer an efficient option for creating initial coding templates for PKPD analyses. This capability has the potential to significantly reduce the time required for PKPD scientists in both the preclinical and clinical space.

## Section: Applications of Large Language Models in Drug Discovery and Development › Clinical Trials and Real‐World Data

A recent perspective [30] highlights the transformative potential of LLMs in leveraging real‐world data (RWD). For instance, LLMs can be used in data curation pipelines using templated prompts, thereby enabling the extraction of relevant information without the need for task‐specific fine tuning. This reduces data‐wrangling efforts and ultimately enhances the generation of real‐world evidence from RWD [30].

LLMs have also demonstrated their potential in forecasting patient trajectories. Makarov et al. [39] introduce the Digital Twin—Generative Pretrained Transformer (DT‐GPT) model, which combines an existing LLM together with rich electronic health record (EHR) data to create digital twins of patients. The DT‐GPT model effectively addresses common challenges in RWD such as missingness, noise, and limited sample sizes. It was shown to outperform a number of ML methods in forecasting clinical variables. This work exemplifies the transformative potential of LLMs in the modeling and simulation of data from both clinical trials and real‐world settings.

## Section: Applications of Large Language Models in Drug Discovery and Development › Literature Review › Evidence Generation

LLMs hold significant potential for transforming how clinical evidence is gathered and assessed. These models provide new methods for extracting, analyzing, and interpreting data from various medical and scientific fields, thereby making the process of evidence generation faster and more comprehensive [40]. One of the most valuable applications of LLMs is their ability to automate literature searches. Typically, researchers carrying out systematic reviews or meta‐analyses must manually sift through vast amounts of published studies, which is time‐consuming. However, with tools like GPT‐4, this process can be significantly expedited. These models can quickly find relevant studies, summarize key points, and highlight important trends, often completing in just a few hours [41]. For instance, Luo et al. [42] showed how LLMs can speed up the early stages of systematic reviews by automating tasks like screening and data extraction. Similarly, LLM‐like TrialMind [43] have shown they can pull key data from clinical studies with impressive accuracy, pulling from large databases like PubMed. In the domain of pharmacokinetics (PK), the extraction of PK parameters from across literature from PubMed demonstrates promising results [44]. Such technology is particularly helpful in fields where new studies are being published constantly, such as oncology and cardiology, where staying up‐to‐date is critical.

Beyond just searching the literature, LLMs hold the promise of bringing efficiency by turning unstructured data into more usable formats. Many clinical reports, especially in areas like radiology, are written in free text, making it difficult to retrieve specific pieces of information. LLMs can identify relevant details—like patient demographics, outcomes, or treatment protocols—from these reports and convert them into structured data ready for analysis [45, 46]. For example, Reichenpfader et al. [47] show how LLMs are being used to extract clinical data from radiology reports, solving the challenge of dealing with free‐text documentation. These models are also being used to pull information from clinical trial reports, significantly speeding up the data extraction phase of meta‐analyses [48]. Another major advantage of LLMs is their ability to continuously update evidence as new studies are published [42]. Instead of waiting months for updates, these models can incorporate new findings in real‐time, ensuring that reviews and meta‐analyses stay relevant. This is a significant improvement over traditional methods, where the lag time between data collection and publication can render reviews outdated almost immediately. LLMs provide a way to keep systematic reviews current and accurate as the science evolves.

## Section: Applications of Large Language Models in Drug Discovery and Development › Literature Review › Application in Model‐Based Meta‐Analysis (MBMA)

One of the significant challenges in model‐based meta‐analysis (MBMA) is harmonizing data across studies that may use different terminologies, outcomes, and measurement scales. LLMs can assist in this process by identifying synonyms or related terms across studies and standardizing the data for integration into a meta‐analysis. For example, if one study reports outcomes as “odds ratios” and another as “risk ratios,” LLMs can standardize these measures to enable their inclusion in a pooled analysis. Additionally, LLMs can help with more complex tasks like imputing missing data or transforming noncomparable datasets into a format that can be analyzed together. This is particularly useful in MBMA, where integrating data from different types of clinical studies (e.g., RCTs and observational studies) is critical for making robust predictions [2].

LLMs can also enhance predictive modeling efforts within MBMA. These models can work through large data sets to identify patterns and predict future endpoints and patient outcomes, such as drug efficacy or safety across different populations. For instance, LLMs can help develop dose–response models by analyzing data from multiple clinical trials and observational studies, providing insights into optimal dosing strategies or identifying populations at risk of adverse events [49]. In [50], the authors applied GPT‐4 to conduct network meta‐analysis (NMA) in four case studies. Using API calls, relevant information was extracted from publications. Subsequently, R code was generated to perform NMA, and based on the results, reports summarizing the results were produced [50]. The LLM demonstrated over 99% accuracy in data extraction across all case studies and generated R scripts that could be executed end‐to‐end without human intervention. While the LLM was not always consistent, the study highlighted the potential for LLMs to significantly reduce the time involved in NMAs, suggesting that with further refinement, such technologies demonstrate promise in health technology assessments (HTAs).

Additionally, the integration of LLMs into quantitative modeling frameworks, such as pharmacometrics or systems pharmacology, allows researchers to incorporate data from diverse sources into predictive models. This leads to more accurate predictions for clinical trial outcomes or drug development processes [2]. Furthermore, MBMA requires the development of complex statistical models, which can be time‐consuming and prone to error. LLMs can assist by automating parts of the model‐building process. For example, LLMs can suggest appropriate covariates or interaction terms based on the data, reducing the need for manual trial‐and‐error model development. LLMs can also be used to generate code for statistical or PK/PD modeling software, further streamlining the model development process.

## Section: Use Cases

In this section, we present three specific case studies that demonstrate the use of LLMs.

## Section: Use Cases › Case Study 1: LLM Tool for Biomedical Queries

Cutting‐edge text embedding models based on LLMs have the potential to significantly enhance the process of identifying relevant academic papers and experimental results in response to biomedical queries, such as safety assessments, biomarker discovery, and mechanism of action studies. The vast amount of literature in this field, including over 37 million academic articles on PubMed [51], makes it challenging to quickly locate pertinent information. Researchers in biopharma are often overwhelmed by this sheer volume of data, hindering their ability to efficiently find and utilize critical findings. Advanced search mechanisms powered by LLMs can be invaluable in this context. For example, the NV‐embed model [52] has recently achieved state‐of‐the‐art performance [53] on the MTEB benchmark [54].

Fine‐tuning LLMs for document embedding tasks can improve performance, especially when dealing with highly specialized text data, tabular data, or slide decks. Even on academic articles, which are in text form, various techniques are required for the best performance. As these articles are often lengthy (e.g., over thousands of words), it is necessary to split a document into multiple text chunks. However, while a chunk would represent detailed information, it may miss high‐level information such as paper titles or keywords, necessitating additional steps to include these elements for effective retrieval.

Despite their potential, several challenges are associated with using LLMs for biomedical literature searches. One significant challenge is the potential absence of required information. In some cases, the answer to a specific query might not exist within the available literature. Another challenge is the rapidly evolving nature of biomedical research, where information that is accurate today may become outdated tomorrow. This necessitates continuous updates and retraining of the models to ensure they remain current.

From a technical perspective, developing effective retrieval systems poses several challenges. One primary issue is the reliance on embedding similarity between the query and the retrieved text. Traditional training methods for embedding models are not ideally suited for this use case, as embeddings for questions and answers can differ significantly. While training adjustments can help improve the alignment, a fundamental issue remains: if the answer to a query does not exist, or if the model does not know what the answer should look like, effective retrieval becomes problematic. Another technical challenge is ensuring that the model can handle the vast and diverse range of biomedical topics, including specialized terminologies and concepts.

This requires extensive training on diverse and comprehensive data sets to enhance the model's robustness and accuracy.

Despite these challenges, the future of LLMs in biomedical research is promising. As these models improve in their reasoning abilities, they could potentially handle more complex tasks such as hypothesis generation by integrating multiple experimental observations. This would significantly enhance research capabilities beyond simple search functions, assisting researchers in formulating new hypotheses, designing experiments, and even predicting potential outcomes based on existing data.

In conclusion, while there are several challenges associated with using LLMs for biomedical literature searches, their potential benefits are substantial. By addressing the technical and domain‐specific challenges, LLMs can transform the way researchers access and utilize biomedical information, ultimately accelerating the pace of discovery and development in the field.

## Section: Use Cases › Case Study 2: LLM for Regulatory Intelligence and Medical Writing

In the pharmaceutical industry, regulatory intelligence and medical writing are two critical challenges that demand substantial time and expertise, yet often rely on labor‐intensive processes. The vast and complex regulatory landscape requires professionals to gather, interpret, and apply data from numerous sources with differing formats and large volumes, posing significant barriers to efficiency and accuracy. NLP, ML, and Generative AI (Gen‐AI) solutions, when crafted by seasoned regulatory experts, offer a transformative answer to these challenges by automating data extraction, standardizing diverse formats, and providing targeted insights for more precise, data‐driven decisions.

## Section: Use Cases › Case Study 2: LLM for Regulatory Intelligence and Medical Writing › Regulatory Intelligence Challenges and RIA as a Solution

Regulatory intelligence is pivotal for maintaining compliance and optimizing drug development strategies. It traditionally involves navigating and curating information from sources such as the FDA, EMA, and other global agencies. Manual efforts to stay updated on regulatory changes and analyze competitive landscapes are time‐consuming and prone to error. The Regulatory Intelligence Assistant (RIA) [55], an AI‐powered tool designed by regulatory professionals, addresses these limitations by automating data collection and summarization, gathering information from diverse regulatory sources and streamlining it for immediate use. RIA's automation capabilities extend to repetitive tasks like regulatory submissions, document generation, and correspondence tracking, significantly enhancing operational efficiency and freeing professionals to focus on strategic decision‐making.

One of RIA's core strengths is its smart alert system, which notifies regulatory teams of relevant guideline updates. Rather than sifting through vast amounts of information, professionals receive curated alerts that streamline regulatory monitoring. Additionally, RIA delivers real‐time regulatory updates, curating information based on specific therapeutic areas, agencies, or development phases, enabling regulatory teams to receive actionable insights tailored to their immediate needs. RIA's cross‐regional consistency checks help ensure that information from multiple regions is harmonized, making global registrations smoother and reducing the risk of errors.

RIA's competitive intelligence capabilities further amplify its value by enabling smarter clinical development strategies. By tracking competitor pipelines and analyzing clinical trial data, RIA provides a clear view of market trends, opportunities for differentiation, and gaps in the competitive landscape. With predictive analytics, RIA can identify regulatory precedents, simulate possible outcomes, and even forecast review timelines, helping teams strategically allocate resources and mitigate risks proactively.

## Section: Use Cases › Case Study 2: LLM for Regulatory Intelligence and Medical Writing › Automating Medical Writing With REGAIN

Medical writing is another area where AI is revolutionizing pharmaceutical processes. Generating complex, data‐intensive documents, such as clinical study reports, regulatory submission dossiers, and safety summaries, has traditionally required significant time and manual effort. AI‐driven tools, such as REGAIN, particularly those leveraging NLP and ML, streamline this process by automatically extracting essential information from clinical databases and research literature, summarizing findings, and generating structured, compliant documentation.

With REGAIN, medical writers can produce high‐quality reports and submissions more quickly and accurately. Automation reduces time spent on laborious data entry and proofreading, allowing writers to focus on strategic insights and the narrative development that contextualizes the data. This AI‐enhanced workflow not only increases output efficiency but also ensures compliance across regions by standardizing content according to regulatory guidelines.

## Section: Use Cases › Case Study 3: Apollo‐AI Advances Quantitative Clinical Pharmacology Through Intelligent Agent Frameworks

In the evolving landscape of clinical pharmacology, the integration of AI has the potential to accelerate the analytical workflows of quantitative clinical pharmacologists (QCP) and translational scientists (TS). Currently under development, Apollo‐AI [56] is a software system designed to augment the analytical capabilities of QCP and TS professionals by streamlining PK and PD analysis and code generation during drug development. These tasks include data cleaning and merging—such as handling missing values and integrating data from multiple sources—conducting exploratory data analysis, and performing a range of PK/PD analyses, from basic noncompartmental analysis (NCA) to advanced population pharmacokinetic and pharmacodynamic modeling.

The Apollo‐AI system aims to overcome some of the typical limitations of LLM‐based tools by leveraging its agent‐based architecture and a “fit for purpose” user interface. With built‐in human oversight, it aims to mitigate issues like hallucinations while delivering domain‐specific functionality tailored to the unique needs of clinical pharmacology.

The system's architecture is built on foundational principles designed to enhance user experience through a structured, agent‐based approach. Each agent has a clearly defined role, operating within a specific scope to focus efficiently on assigned tasks. The UI is purpose‐built for the complex workflows typical in QCP and TS analyses, going beyond generic chat‐based interfaces. Instead, Apollo‐AI provides a comprehensive, end‐to‐end analysis platform that integrates essential features like data visualization, workflow management, code editing, and report generation. This specialized interface allows users to iteratively develop, refine, and manage complex analysis projects (e.g., developing a PK model, running an NCA) with the support of dedicated agents. A key strength of Apollo‐AI's infrastructure is its secure backend, ensuring data protection and regulatory compliance. This allows clinical pharmacologists to confidently handle sensitive patient data and proprietary research findings while maintaining strict confidentiality.

Apollo‐AI integrates a team of specialized AI agents to streamline and enhance the analytical workflows for QCP and TS. Key agents—the Conversational Agent, Planning Agent, Task Agents, and Global Agent—work together to ensure both precision and efficiency in PK/PD analyses.

The Conversational Agent is the primary user interface, converting natural language inputs into actionable tasks. For instance, when a data analyst requests to model drug concentration levels, the Conversational Agent may interpret this as a PK modeling workflow, verify with the end user before assigning it to the Planning Agent. The Planning Agent then builds a comprehensive methodological plan, detailing data sources, variable selection criteria, and analytical methods to align with study objectives and user needs. Task Agents handle the execution, performing functions like code generation, running analyses on clinical trial datasets, and summarizing results. They may also manage preparatory tasks like data cleaning and outlier detection. The Global Agent oversees coordination among all agents, delivering context‐specific feedback throughout the process. This structured, agent‐based framework keeps human experts actively engaged, preserving a human‐in‐the‐loop approach that safeguards analytical integrity and scientific rigor.

Finally, a crucial component of Apollo‐AI is the Agent‐Computer Interface (ACI), which enables smooth collaboration among the AI agents by offering an environment like the IDEs used by software engineers. Through the ACI, agents can efficiently access and manage code repositories, data sets, and analytical scripts, reducing errors and boosting overall system performance.

By automating repetitive and time‐consuming tasks, Apollo‐AI has the potential to increase workflow efficiency while maintaining high accuracy through continuous human oversight. This collaboration between AI agents and human users ensures that analyses are both efficient and robust. As Apollo‐AI continues to develop, it has the potential to improve analytical workflows, enabling researchers to receive real‐time insights from their data.

## Section: Challenges and Limitations

One of the main limitations with LLMs is their tendency to hallucinate (also known as confabulate), producing incorrect information, particularly when addressing complex questions. This becomes a serious concern when accuracy is paramount, such as in evidence generation. For instance, Gwon et al. [57] found that while LLMs like ChatGPT can successfully identify relevant studies, they also generate a fair amount of irrelevant or even fabricated references. Hence, while LLMs can speed up the process of gathering evidence, human oversight is still needed to ensure everything is accurate.

Another limitation is that while LLMs excel at processing natural language, they often struggle with complex medical concepts, especially when it involves interpreting numerical data or making fine‐tuned clinical judgments. For instance, LLMs can readily extract qualitative data from clinical studies, but they might not do as well when dealing with quantitative results such as effect sizes or p values, which are essential in applications such as MBMA [58]. This underscores the necessity for human experts to validate the LLM‐generated outputs to ensure their accuracy and relevance.

Ethical and transparency issues also pose significant challenges when using LLMs. A major concern is the risk of bias in the data that is used to train these models. If the training data are biased, LLMs could perpetuate these biases in their outputs, leading to skewed or inaccurate conclusions. With respect to transparency, the “black box” nature of LLMs makes it hard to understand how they reach certain decisions, which complicates efforts to validate their results or obtain regulatory approval for their use in clinical settings [59]. Data privacy and security is another concern: it is essential to ensure that regulations are followed and risks are mitigated [60].

## Section: Conclusion and Future Directions

Applications of LLMs are rapidly emerging across every facet of drug discovery and development. The examples discussed in this primer (including links to resources provided in Table S1 of the Supporting Information) represent a broad spectrum of applications, and as LLMs become more mainstream, it is anticipated that even more innovative uses will emerge. These tools have demonstrated substantial promise and have yielded encouraging validation results. However, given the critical nature of efforts in drug development, it is imperative that LLMs are used primarily for initial drafts (such as generating analysis codes, results, and reports), while human review remains essential. Despite their limitations, effectively incorporating LLMs into the workflow offers significant potential to save time and effort [61].

We envision that human scientists can collaborate with LLMs at three different levels: as a tool, assistant, or partner [2], presenting many opportunities. One significant initial benefit is for LLMs to save time and mental effort on routine tasks, thereby allowing human scientists to focus more of their cognitive resources on scientific interpretation and other complex tasks that require higher mental capacity. While applications of LLMs face challenges and limitations, ongoing efforts to scale up model sizes and incorporate reasoning capabilities, along with future technological advancements, may help mitigate or overcome these issues.

The text understanding, reasoning, and generation capabilities of existing LLMs pave the way for future capabilities of AI. In particular, by fine‐tuning LLMs to domain knowledge followed by instruction tuning, LLM‐based AI agents can be constructed to accomplish specific tasks in biomedical research [62]. By combining single AI agents that are focused on subtasks, multi‐agent AI systems could lay the groundwork for the aspirational “AI scientists” that can be used to empower biomedical research [62]. In conclusion, the advent of LLMs unlocks unprecedented opportunities for human‐machine collaboration [2, 62], heralding a new era of innovation that is just beginning to unfold.

## Section: Conflicts of Interest

All authors were employees and additionally may be shareholders of their respective companies at the time of writing.

## Section: Disclaimer

The contents are those of the author(s) and do not necessarily represent the official views of, nor an endorsement, by FDA/HHS or the U.S. Government. As Associate Editors for Clinical and Translational Science, Qi Liu and Mohamed Shahin were not involved in the review or decision process for this paper.

## Section: Supporting information

Data S1.


---

# Large language models for drug discovery and development

- **Authors:** Yizhen Zheng, Huan Yee Koh, Jiaxin Ju, Madeleine Yang, Lauren T May, Geoffrey I Webb, Li Li, Shirui Pan, George Church
- **Issuer:** Patterns (New York, N.Y.)
- **Type:** Scientific article
- **Published:** 2025-09-02
- **Language:** en
- **DOI:** 10.1016/j.patter.2025.101346
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41142906/
- **Licence:** CC-BY

## Section: Abstract

SummaryThe integration of large language models (LLMs) into the drug discovery and development field marks a significant paradigm shift, offering novel methodologies for understanding disease mechanisms, facilitating de novo drug discovery, and optimizing clinical trial processes. This review highlights the expanding role of LLMs in revolutionizing various stages of the drug development pipeline. We investigate how these advanced computational models can uncover target-disease linkage, interpret complex biomedical data, enhance drug molecule design, predict drug efficacy and safety profiles, and facilitate clinical trial processes. In this paper, we aim to provide a comprehensive overview for researchers and practitioners in computational biology, pharmacology, and AI4Science by offering insights into the potential transformative impact of LLMs on drug discovery and development.Keywords: large language models, drug discovery, drug development

## Section: Introduction

The pursuit of new drugs to research and develop is a long-term commitment that typically takes 10–15 years and costs over $2 billion in order to bring a new drug to a patient.1 This procedure is traditionally divided into three stages: understanding the disease and selecting a treatment target, developing targeted therapies, and testing their effectiveness in clinical trials. Each phase is time consuming and resource intensive due to the complexity of biological systems and the extensive review required. While this process is essential to minimize harm and ensure that only safe and effective therapies that have been proven to improve and extend human life are introduced, its duration can delay patient access to promising treatments. Consequently, there are extraordinary dividends to be reaped by introducing efficiency and expanding the capabilities of current practices.

Artificial intelligence (AI) tools have become essential for accelerating drug discovery and development. Among them, large language models (LLMs), also referred to as pretrained language models, are distinguished by their capacity to interpret scientific language and perform critical tasks in the drug discovery process. For example, Geneformer,2 which was pretrained on 30 million single-cell transcriptomes, aids in disease modeling and has successfully identified therapeutic targets for cardiomyopathy through in silico deletion. Researchers have demonstrated that LLMs such as Chemcrow3 and Coscientist4 have the potential to automate chemistry experiments, particularly in directed synthesis and chemical reaction prediction. Other models, including LLM4SD,5 can directly analyze raw experimental data to perform scientific synthesis, inference, and hypothesis generation, aligning with human expert analysis. Med-PaLM,6 a large-scale LLM incorporating clinical knowledge, has even surpassed human experts on United States Medical Licensing Examination (USMLE)-style medical questions, illustrating the potential of LLMs to reduce the burden of clinical-trial tasks.

Advances in LLMs have the potential to transform the drug discovery pipeline, enabling highly automated applications across all three stages (Figure 1). In the initial stage, LLMs may assist in clarifying disease mechanisms and identifying potential targets.2,7,8 By performing functional genomics analysis, they can pinpoint genes with desirable characteristics for drug targeting, drawing on experimental data and gene-related literature. LLMs may also uncover new insights into biochemistry and pharmacology through literature review. In the drug discovery phase, LLMs may automate chemistry experiments, control robotic systems, and suggest novel molecules through interactive platforms for compound generation and editing.4 During clinical trials, LLMs may streamline patient matching9 and trial design10 by analyzing profiles and requirements, while early research suggests they may predict trial outcomes11,12 by analyzing historical data.

In this paper, we first provide background information on LLMs and explore two paradigms of applying LLMs to drug discovery and development (see Box 1): specialized models trained on scientific language and general-purpose models trained on broader textual data. We further categorize existing approaches into three methodological classes (see Box 1): language model (LM)-based (≤100 million parameters), LLM-based (>100 million parameters), and hybrid-LM/LLM models.

We then discuss how these paradigms may be applied in the canonical stages of the drug pipeline—understanding disease mechanisms, drug discovery, and clinical trials—each illustrated in Figures 2, 3, and 4. On the left side of each figure, we outline the core processes within each stage, while on the right, we highlight the downstream applications to which LLMs can potentially contribute (e.g., hypothesis generation, virtual screening, patient cohort stratification).

These figures illustrate drug discovery and development pipeline stages, understanding disease mechanisms (Figure 2), drug discovery (Figure 3), and clinical trials (Figure 4), as well as a maturity assessment of two representative LLM paradigms (i.e., specialized LLMs and general LLMs) across downstream tasks in the three stages to gauge their current capabilities and limitations. The maturity levels for each downstream task are displayed on the right part of each figure, immediately adjacent to the title of each downstream task category. Specifically, we employ a four-level maturity model for a clear, systematic evaluation.

Finally, we conclude with a discussion of future directions, addressing ethical concerns (privacy, fairness, bias) and technical challenges (hallucinations, interpretability) critical for making LLMs trusted, efficient tools in drug discovery and patient care.

Overall, we aim to address three key questions for researchers and practitioners looking to leverage LLMs to enhance the drug discovery and development pipeline:

Large language models shaping the future landscape of drug discovery and development

In the past, drug discovery relied on labor-intensive manual processes, demanding significant human effort and resources. Nowadays, advances in biotechnology, AI, and in silico tools have reduced these burdens, though full automation remains limited, especially in clinical trials where design and participant matching still depend on human expertise. In the future, the continued development of large language models (LLMs) is expected to drive a highly automated drug discovery pipeline, accelerating breakthroughs and efficiency.

Main paradigms and types of LLMs in drug discovery and development

(A) The two main paradigms of language models. Specialized models decode scientific languages for targeted tasks, while general-purpose models act as conversational assistants trained on diverse text sources.

(B) Three types of LLM methods include LM-based, LLM-based, and hybrid-based methods.

Understanding disease mechanisms

The left part of the figure depicts the process of understanding disease mechanisms, which involves clinical data collection, target-disease linkage analysis, and target validation. Clinical data collection gathers patient data and identifies patient subgroups using multi-omics data, while target-disease linkage analysis explores the relationship between targets and diseases. Target validation includes safety, feasibility, mechanisms of action, and modality selection. The right part shows how LLMs assist in these tasks, including genomics and RNA analysis, pathway analysis, target profiling, and strategic profiling. Maturity levels for each task category are displayed immediately beside its title.

Drug discovery

The left part of the figure illustrates the processes involved in drug discovery. The right part of the figure highlights the tasks that LLMs can perform to facilitate these processes. Maturity levels for each task category are displayed immediately beside its title.

Clinical trials

The left part of the figure illustrates the processes involved in clinical trials. Clinical trials consist of four phases: phase 1, phase 2, phase 3, and phase 4. The right part of the figure highlights the tasks that LLMs can perform to facilitate these processes. Maturity levels for each task category are displayed immediately beside its title.

## Section: Understanding disease mechanisms

Understanding disease mechanisms is a critical first step in drug discovery, with the primary goal of identifying a suitable protein target for potential drugs. This process involves three main stages (Figure 3): clinical data collection, target-disease linkage analysis, and target validation. The overview of LLM tools for the understanding disease mechanisms step is summarized in Table 1. In the first stage, clinical data collection involves gathering patient data and categorizing individuals into subgroups, enabling the integration of clinical and multi-omics data to improve understanding of disease variations and potential differences in disease mechanisms across patient groups.28 The target-disease linkage phase establishes connections between potential protein targets and specific diseases through pathway analysis,29 gene expression profiling, and experimental techniques like CRISPR-Cas930 and in vivo disease modeling.

Target validation is an ongoing, iterative process that does not have a fixed starting point.31 This cycle includes assessing the mechanism of action, selecting the most appropriate therapeutic modality, and evaluating safety and feasibility. The safety and feasibility assessment involves examining the potential organismal impact, druggability of the target, and the practicality of assays for feasibility.32 This flexible approach ensures that targets are continuously evaluated for viability and safety before advancing further in the drug development pipeline.

Overview of the “understanding disease mechanism” stage

## Section: Understanding disease mechanisms › Genomics analysis

As shown in Figure 3, genomic analysis underpins the early phases of disease mechanism investigation, specifically the clinical data collection and target-disease linkage phases. Decades of genome-wide association studies (GWASs) have identified key genomic regions linked to various diseases, advancing genomic analysis for disease understanding and target discovery.33 Integrating genetic associations into drug discovery has the potential to increase the success rate of clinical targets.34 In the clinical data collection phase, genomic data are used to classify patient subgroups by identifying shared variants and molecular traits. In the target-disease linkage phase, specific variants and regulatory elements provide mechanistic insight into how these subtypes may drive disease.

Recent advances in nucleotide-specific LLMs, such as DNA-BERT,22 Nucleotide Transformer,35 and HyenaDNA,36 have enabled scalable interpretation of genomic information by leveraging structural parallels between genomic sequences and human language. Building on the idea that DNA follows language-like patterns, genetic variant analysis uses LLMs to identify functional alterations—such as SNPs or insertions or deletions (indels)—that may drive disease phenotypes. By applying masked language modeling to nucleotide sequences, these LLMs22,35 learn to recognize patterns associated with functionally significant variants, including SNPs, insertions, and deletions.37 DNA-BERT22 and Nucleotide Transformer35 can detect conserved motifs and prioritize variants that may contribute to disease, informing the identification of subtype-specific drivers. Nucleotide Transformer has been applied in the classification of SARS-CoV-2 variants38 and the study of viral evolution.39 The recently developed HyenaDNA model36 enables long-range variant modeling across sequences of up to 1 million tokens, overcoming quadratic attention limitations in earlier models. Similarly, Evo40 incorporates deep signal processing to predict variant functionality at single-nucleotide resolution across whole genomes. In parallel with DNA modeling, RNA-focused LLMs have enhanced the functional analysis of RNA structure and expression regulation, relevant to both subtyping and mechanistic modeling. RNA-FM,41 trained on over 23.7 million RNA sequences, enables precise secondary structure prediction. RiNALMo42 and RNAErnie43 improve generalization across unseen RNA families. Collectively, these models form the foundation for understanding how sequence-level variation underlies disease phenotypes.

A further application of nucleotide LLMs is in predicting genomic regions of regulatory interest, such as promoter regions, transcription factor (TF) binding sites, and splice sites—key elements involved in gene regulation and often disrupted in disease. Specialized nucleotide LLMs, fine-tuned on large datasets and domain-specific knowledge, have shown improved performance in predicting such regions compared to previous methods.35,38 These capabilities support both disease modeling and candidate target evaluation during the target-disease linkage stage. Similarly, epigenetic marks, including DNA methylation and histone modifications, regulate gene expression without altering the DNA sequence and play a key role in disease and therapy. Accurately predicting these marks is essential for understanding their impact on gene expression and disease. The Evo model,40 leveraging deep signal processing, achieves single-nucleotide resolution over long genomic sequences, improving regulatory element prediction. Additionally, RNA-specific LLMs, such as RNAErnie43 and RiNALMo,42 enhance RNA regulatory region and splice site prediction, demonstrating strong generalization to unseen RNA families. Nucleotide LLMs have also been fine-tuned to predict individual histone modifications, such as H3K14ac, H3K36me3, and H3K4me1, in an effort to address the challenges posed by the complexity and variability of epigenetic marks.38

Although current nucleotide LLMs detect functional variants and regulatory elements, future models should integrate multi-omic and spatial context to achieve tissue specificity, enable causal inference and the generative design of regulatory sequences, provide interpretable motif insights, and support real-time clinical variant annotation.

## Section: Understanding disease mechanisms › Genomics analysis › Maturity assessment

Specialized LLMs have recently been developed to encode nucleotide sequences22,35 for applications such as genetic variant analysis.38 However, they remain in the early stages, requiring further validation. Similarly, general LLMs, still nascent, show potential but need improvement in tasks like explaining evolutionary processes or designing DNA sequences,44 highlighting the ongoing evolution and future promise of the field.

## Section: Understanding disease mechanisms › Transcriptomics analysis

In the disease mechanism framework (Figure 3), transcriptomic data is essential for both clinical data collection and target-disease linkage, as it captures cell-type-specific gene expression changes that define disease states. Transcriptomics—focused on quantifying RNA expression across tissues—has benefited from advances in single-cell and high-throughput sequencing technologies, yielding datasets that detail cellular behaviors at unprecedented resolution. However, data for rare diseases or inaccessible tissues are often sparse, limiting robust model development.45 To address this, specialized gene LLMs, such as Geneformer,2 use techniques like “rank value encoding” to map single-cell transcriptomes into ranked gene sequences, normalizing expression levels across tissues. This enables consistent comparison of gene expression patterns across conditions, supporting patient stratification and functional profiling. Models like Geneformer,2 scGPT,8 scMulan,7 and scFoundation46 excel in analyzing sparse data, modeling gene networks, and understanding complex interactions beyond simple cell-level annotations. In addition, literature-trained models such as PWAS47 offer a complementary route to target-disease linkage by associating genes and diseases based on publication data, capturing early therapeutic signals even before experimental validation.

A key challenge in transcriptomic analysis is accurate mRNA expression analysis in low-sample or noisy contexts. In contrast, specialized models like Geneformer2 leverage pretraining on transcriptomic data to efficiently adapt to specific disease contexts. Geneformer demonstrates superior performance in gene network analysis with minimal data, as evidenced by its ability to distinguish key factors in the NOTCH1-dependent network from just 884 endothelial cells from healthy versus dilated aortas, outperforming methods that relied on a dataset of approximately 30,000 cells.2 Similarly, scGPT,8 a pre-trained transformer model for single-cell multi-omics analysis, can generate meaningful cell-type clusters in a zero-shot manner, without additional fine-tuning. These capabilities are critical for clinical subtyping in the clinical data collection step, where high-resolution cell-type differences can delineate patient groups. Complementing these approaches, GeneCompass48 enhances cross-species transcriptomic analysis by integrating regulatory networks and prior biological knowledge, significantly improving gene expression predictions and functional annotation. Moreover, scBERT49 and CellPLM50 further refine single-cell RNA analysis by capturing intricate gene-gene and cell-cell interactions, addressing challenges related to batch effects and cell state characterization.

Gene network analysis is essential for uncovering disease mechanisms and informing target validation by characterizing regulatory relationships between genes. However, uncovering regulatory elements that modulate these networks is challenging, particularly for rare diseases or conditions involving clinically inaccessible tissues.2,8 To address this challenge, Geneformer2 applies a deep learning approach that identifies directional relationships between genes by learning which genes influence or are influenced by others through observed expression patterns. This process automatically constructs gene networks by mapping gene interactions. Geneformer also employs in silico deletion, a computational technique that simulates the removal of individual genes to evaluate their functional importance within the network. In contrast, scGPT8 constructs gene networks through computational embeddings that capture gene similarity based on co-expression and functional patterns. These network representations facilitate the identification of key regulatory nodes and potential therapeutic targets. Expanding on these capabilities, GeneCompass48 integrates cross-species transcriptomic data, enabling the identification of conserved patterns in gene regulation, while CellPLM50 explicitly models cell-cell interactions to improve network inference. Additionally, scBERT49 refines gene network analysis by leveraging large-scale single-cell RNA-seq data to learn more generalizable and interpretable representations of gene interactions.

Though current transcriptomic LLMs can identify cell types, infer gene networks, and predict expression from sparse data, future models should integrate spatial and proteomic context to map cell-cell interactions, capture temporal trajectories and lineage dynamics, enable causal inference and in silico perturbation design, provide interpretable gene-level attributions to guide hypothesis testing, and generalize to rare or cross-species cell states for broader applicability.

## Section: Understanding disease mechanisms › Transcriptomics analysis › Maturity assessment

Specialized LLMs, such as Geneformer,2 have made significant strides in gene network analysis, successfully distinguishing between normal and cardiomyopathic cardiomyocytes. This enabled the identification of key genes linked to hypertrophic and dilated cardiomyopathy, with targets like ADCY5 and SRPK3 validated through experimental induced pluripotent stem cell (iPSC)-derived cardiac microtissues with Titin truncating mutations.2 Thus, specialized LLMs have advanced in transcriptomic data analysis and disease mechanism deciphering. In contrast, general LLMs are still in the nascent stage for transcriptomic analysis, with ongoing research exploring tasks like automating cell type analysis51 and data analysis via code generation.44

## Section: Understanding disease mechanisms › Protein target analysis

In the final stage of disease mechanism modeling (Figure 3), protein-level analysis plays a critical role in target validation, assessing the structure, function, and druggability of candidate proteins. Protein sequences are often the most readily available information about a candidate target and serve as the foundation for functional inference and therapeutic assessment. Specialized LLMs are particularly valuable in this context, as they can provide extensive analyses, including evolutionary conservation, functional annotation, protein folding, and binding-site prediction. These models can extract relevant information from sequence data alone, enabling the characterization of biological traits and functions even in the absence of experimental data, such as 3D protein structures.

One foundational application is evolutionary conservation. Models such as ESM52 exploit the statistical regularities in protein sequences shaped by evolution, allowing them to infer biologically meaningful constraints. Mutations that enhance an organism’s fitness are more likely to be selected by evolutionary forces, leading to unique sequence signatures.53 These sequence patterns reflect conserved functional sites, and LLMs trained with masked amino acids can predict mutation tolerance, revealing which residues are essential for structure or function. Research has shown the efficacy of this approach, as demonstrated by the ESM language model’s ability to accurately predict mutational effects across various proteins without additional training.54 Earlier work, such as UniRep,55 demonstrated how deep sequence-based representation learning enables efficient exploration of evolutionary fitness landscapes, improving stability and functional annotation predictions. Expanding on this, Ankh56 introduces an optimized transformer model that balances model size and efficiency, outperforming existing models in evolutionary conservation analysis. Additionally, xTrimoPGLM57 extends large-scale protein modeling by integrating bidirectional autoencoding and autoregressive training to improve both structure prediction and mutation effect analysis. GLM2,58 leveraging metagenomic diversity, enhances functional representation learning, aiding in evolutionary insights at the protein level. Moreover, ProstT559 advances conservation analysis by integrating protein sequence and structure into a unified representation, refining predictions of functional residues and evolutionary constraints. These conservation-focused models are critical for assessing whether a candidate target is robust to mutation and functionally central, which are key criteria for validating its relevance in therapeutic development.

Closely linked to conservation analysis is protein folding, a fundamental task in structure-based target validation. Since function often depends on three-dimensional conformation, structure prediction from sequence is essential for understanding target accessibility, binding interfaces, and interaction specificity. LLMs trained on protein sequence data can capture these evolutionary trends, as demonstrated by ESM,52 which accurately decodes protein structure from sequence data. By generating pairwise interaction maps (attention matrices) between amino acid positions, these models can predict amino acid contacts with remarkable precision, suggesting that structural information can be inferred directly from sequence data, consistent with Anfinsen’s dogma.60 Building on this foundation, AlphaFold261 has revolutionized protein structure prediction, achieving atom-level accuracy even in the absence of known homologous structures. AlphaFold2’s Evoformer component, similar to the multiple sequence alignment (MSA)-Transformer approach, uses masked sequence data from MSAs to incorporate evolutionary information and predict protein structures with near-experimental accuracy.62 This approach has been extended to biomolecular interactions in RosettaFold,63 enabling the modeling of complex assemblies such as protein-protein and protein-DNA/RNA complexes.64 More recently, AlphaFold365 has significantly enhanced biomolecular interaction modeling by incorporating small molecules, ions, and modified residues, achieving state-of-the-art accuracy in protein-ligand and protein-nucleic acid interactions. In parallel, RGN2’s ProtBERT66 encodes protein sequences and predicts structure without relying on MSAs, even outperforming AlphaFold261 in predicting the structure of orphan proteins lacking sequence homologs.66 These models facilitate a comprehensive and systematic evaluation of candidate targets’ structural features, thereby informing druggability assessments and interaction modeling, which are critical elements of target validation.

To support target validation, another essential application is functional annotation, which assigns biological meaning to protein sequences by predicting their roles in cellular processes. This task is particularly important for novel or poorly characterized proteins emerging from high-throughput studies. Early LLMs trained on protein sequences25,52,67 demonstrated the capacity to capture meaningful sequence patterns, structural motifs, and evolutionary signals. These models generate embeddings that represent proteins in a way that preserves functional and structural similarities. This capability has been integrated into tools such as NetGO 3.0,68 which combine LLM-based embeddings with network information to predict protein functions across various species, thereby reducing dependence on labor-intensive experimental assays. For instance, PRECOGx69 used ESM52 to analyze G protein-coupled receptor (GPCR) sequences, revealing that interaction mechanisms of protein variants are driven by alternative splicing. These insights help identify mechanisms of dysfunction and support the prioritization of variant-bearing targets. Advances in LLMs have also led to ProteinChat,70 an interactive platform for exploring protein sequences, with recent studies highlighting GPT-4’s expertise in protein understanding.44 While protein language models were previously limited, the release of ESM225 and ESM3,71 with 15 billion and 98 billion parameters, respectively, has significantly improved the modeling of sequence-structure-function relationships. ESMFold,25 based on the ESM framework, has shown remarkable precision in predicting protein structures, achieving accuracy comparable to AlphaFold2 using only a single input sequence rather than MSAs, thereby enhancing efficiency and accessibility. These models advance the field of functional annotation by enabling high-resolution, structure-aware predictions, even in the absence of experimentally determined structural data.

Ultimately, determining the druggability of a protein target—its capacity to bind small molecules or biologics—constitutes a central aspect of the target validation process. Protein-based LLMs have shown success in predicting protein-protein interactions,72 which are essential for identifying target proteins and designing biologic drugs. Notably, DockGPT,73 an innovative protein docking method, excels in handling conformational flexibility and binding-site information, offering high accuracy in antibody-antigen complex predictions and co-designing antibody sequences targeting specific epitopes. Additionally, RosettaFold All-Atom64 has enhanced protein-ligand interaction modeling by incorporating various ligands, including small molecules, metal ions, and nucleic acids, allowing for highly accurate predictions of protein-ligand complexes. These models identify binding sites and predict the effects of mutations on binding affinity, which are essential for detecting viable drug-binding pockets. Their predictive capacity streamlines drug candidate screening and design, linking sequence-based target nomination with interaction-based validation.

Though current protein LLMs can infer evolutionary constraints, predict structures, and annotate functions, future models should integrate conformational dynamics and post-translational modifications to capture protein ensembles, enable de novo design of enzymes, biologics, and small-molecule binders, predict allosteric and cryptic sites, incorporate high-resolution proteomics and cellular context for interaction kinetics, and extract interpretable functional motifs.

## Section: Understanding disease mechanisms › Protein target analysis › Maturity assessment

Specialized LLMs, such as AlphaFold261 and AlphaFold3,65 have made significant strides in protein target analysis, with applications in structure-based drug discovery and vaccine development.74 AlphaFold’s success includes the rapid development of a first-in-class hit molecule for CDK20 within 30 days and the synthesis of only seven compounds.75 Additionally, ESM,52 a protein language model, has been developed to analyze GPCR proteins and identify compounds with subnanomolar affinity.69,76 In contrast, general LLMs like GPT-413 are still in the nascent stage for protein target analysis, with models like ProteinChat70 showing potential in labeling protein structures but lacking extensive real-world validation. Thus, while progress has been made, the field remains in development.

## Section: Understanding disease mechanisms › Disease pathway analysis

Pathway analysis serves as a critical step in the target-disease linkage process, enabling researchers to connect candidate genes or variants to broader biological functions and disease pathways. Gene regulatory network analysis is a crucial tool in pathway analysis for deciphering complex disease pathways, with general LLMs offering significant advantages. Unlike specialized models limited to sequence data, general-purpose LLMs incorporate vast scientific literature and structured databases, allowing them to reason across diverse biological contexts.13,16 Their interactive capabilities enable deeper engagement with complex data,13,77 facilitating the exploration of scientific findings. For instance, a recent study demonstrated the effectiveness of general LLMs like GPT-4 in analyzing blood transcriptional modules related to erythroid cells, where the models automatically generated gene network codes, summarized candidate genes, created reports, and fact-checked against the literature.78 This illustrates how LLMs can assist in pathway assembly, candidate gene prioritization, and hypothesis generation—core tasks in connecting molecular evidence to disease phenotypes. Moreover, by grounding predictions in existing knowledge, these models reduce false positives and increase the interpretability of pathway relationships. As a result, general LLMs are emerging as powerful tools that complement omics-based analyses with dynamic, literature-aware insights, enhancing the interpretability and actionability of disease pathways.

Though current LLMs aid pathway assembly and gene prioritization, future models should support dynamic, cell-type-specific pathway modeling and enable causal inference. They should also link pathway insights directly to clinical outcomes and therapies.

## Section: Understanding disease mechanisms › Disease pathway analysis › Maturity assessment

Specialized LLMs have advanced significantly in disease pathway analysis, particularly in genomics, transcriptomics, and protein target analysis. A notable breakthrough is Geneformer,2 a transcriptomic LLM used for gene network analysis, which has been experimentally validated and demonstrates the potential of these models in dissecting disease pathways. Similarly, general LLMs have made strides in this area, with Insilico Medicine integrating ChatGPT into its PandaOmics platform for disease pathway analysis.79 However, while these tools show promise, their widespread adoption is still in progress.

## Section: Understanding disease mechanisms › Assistance

As illustrated in Figure 3, general-purpose LLMs serve as a cross-cutting assistant throughout the disease mechanism pipeline, from clinical data collection to target validation. Because the investigation of disease mechanisms spans multiple domains—from genomics to pharmacology—general-purpose LLMs, with their interactive reasoning and multimodal input handling, provide versatile support across research stages.16 These models excel in information retrieval, offering fast, accurate responses and tailored explanations, while also organizing large datasets to enhance workflow and productivity.77

At early stages, LLMs can assist in variant interpretation, generate pathway hypotheses, and recommend relevant literature. As analysis progresses, they can synthesize cross-modal findings such as transcriptomic and structural data, support interactive query refinement, and identify inconsistencies in candidate targets. By integrating with search engines, recent LLMs provide real-time access to scientific data, facilitating hypothesis generation and validation. Their ability to translate technical content into domain-adapted summaries improves cross-disciplinary communication, helping bridge gaps between computational scientists, biologists, and clinicians. As such, LLMs do not replace domain expertise but enhance it, accelerating the iteration cycle between data, interpretation, and decision-making.

## Section: Understanding disease mechanisms › Assistance › Maturity assessment

General LLMs have reached a mature stage, significantly aiding disease mechanism research by mining and synthesizing vast scientific and medical literature.44,78,79 Their ability to create and interpret knowledge graphs79 is key in mapping gene networks and understanding gene-disease relationships.23 Furthermore, these models simplify complex medical and genetic concepts,77 enhancing both accessibility and communication in the medical field.

## Section: Drug discovery

The drug discovery process consists of several key steps as depicted in Figure 4: hit identification, hit to lead, lead optimization, and preclinical development. The overview of LLM tools for the drug discovery step is summarized in Table 2. It begins with “hit identification,” where compounds with potential therapeutic effects are identified, followed by “hit to lead,” which refines the selection to the most promising candidates. In “lead optimization,” the efficacy, stability, and safety of the lead compound are enhanced. Finally, “preclinical development” involves testing the optimized compound in animal models to assess its suitability for human trials. This survey will first outline the tasks associated with each step and then explore how LLMs can be integrated to advance the drug discovery process.

Overview of methods in the “drug discovery” stage

## Section: Drug discovery › Chemistry

As shown in Figure 4, the drug discovery pipeline begins with the design and synthesis of novel compounds, particularly small molecules, which proceed through stages such as hit identification and lead optimization. Chemistry forms the bedrock of this early-stage process, enabling the creation of candidate molecules and the execution of critical synthesis experiments. With the integration of automated laboratories, traditional medicinal chemistry has evolved to incorporate robotic systems that can conduct complex chemical reactions and high-throughput screening. After synthesis, compounds are evaluated for activity and selectivity using pharmacological assays. LLMs are increasingly central to this transformation, serving as intelligent interfaces between human researchers and automated systems. They can generate machine-readable protocols from natural language descriptions,3,4 helping bridge the gap between experimental intent and execution. They also support synthesis design by recommending retrosynthetic pathways and predicting reaction outcomes. This integration enhances experimental throughput and decision-making efficiency in early drug development.

One key application is chemistry robotics, where LLMs convert natural language commands into code for laboratory automation platforms. General LLMs such as GPT-413 and CodeLlama,80 trained on extensive code datasets, are well-suited for generating these plans. A notable example is CLARify,81 which leverages GPT-382 to generate task plans in a specialized chemistry description language (XDL) based on user instructions. These plans are then executed using PDDLStream solvers, achieving higher accuracy than baseline systems like SynthReader.83 Additionally, GPT-4 has been used to generate Python scripts for controlling the OT-II liquid handling robot,84 achieving 95% success within five iterations. These advances illustrate how LLMs act as intermediaries between researchers and robotic instruments, supporting the automation of synthesis procedures illustrated in the “chemistry” section of Figure 4. An emerging area of AI research involves using LLMs as autonomous agents to create and execute scientific experiments. For example, Coscientist4 demonstrated how LLMs could use web search engines and vector search to gather synthesis information and generate multi-instrument systems code, successfully performing complex reactions like Suzuki and Sonogashira cross-coupling.

LLMs also contribute to retrosynthetic planning and reaction prediction, which are essential for mapping efficient routes from commercially available precursors to target compounds. Recently, general-purpose LLMs like Chemcrow3 and Coscientist4 have advanced this field. Chemcrow3 integrates a broad array of tools, including SMILES conversion, patent checking, and reaction classification, employing a four-step framework—thinking, acting, providing inputs, and analyzing results—to improve LLM performance, surpassing GPT-4 in synthesis planning tasks. Additionally, a study85 demonstrated that a fine-tuned GPT-3 model outperformed traditional machine learning models in low-data chemistry tasks, highlighting LLMs’ potential to advance chemical research with minimal fine-tuning, even when not initially trained on chemical data. By supporting chemical planning and prediction as illustrated in the “chemistry” panel of Figure 4, LLMs are streamlining the path from molecular design to compound generation, making them indispensable tools in modern drug discovery.

Though current LLMs may assist in translating protocols into robotic code, planning retrosynthetic routes, and predicting reaction outcomes, future models should aim to integrate real-time sensor and processing data for adaptive reaction optimization and propose novel catalysts and scaffolds. They should also enable end-to-end autonomous synthesis planning that accounts for safety, cost, and sustainability.

## Section: Drug discovery › Chemistry › Maturity assessment

While specialized LLMs in chemistry experiments remain in their early stages, general LLMs have advanced considerably. These models are now used in complex chemistry experiments, demonstrating superior performance over specialized LLMs in tasks like retrosynthetic planning and reaction prediction due to their tool use capabilities, such as reading scientific literature and assisting in molecular synthesis.3,4 In real-world settings, general LLMs have shown effectiveness in synthesizing molecules and controlling robotic arms.4,81 Despite these advances, their widespread deployment in industries, such as pharmaceuticals, remains limited, indicating the need for further research and development to fully leverage general LLMs in chemistry experiments.

## Section: Drug discovery › In silico simulation

As depicted in Figure 4, in silico simulation forms a core part of the computational pipeline in drug discovery, enabling the generation and evaluation of molecular structures before physical synthesis. These simulations typically involve three main tasks: de novo molecule generation, de novo protein generation, and protein-ligand interaction prediction.

De novo molecule generation refers to the in silico design of novel molecular structures with potential therapeutic activity, typically classified as either unconstrained or constrained based on design constraints. Unconstrained generation explores the broader chemical space of the training set, while constrained generation focuses on molecules that satisfy specific drug-like properties such as target affinity, selectivity, absorption, distribution, metabolism, and excretion (ADME) characteristics, and synthesizability.27 These two approaches are essential for both exploring novel chemical scaffolds and optimizing lead candidates. Early constrained approaches used pharmacophoric features,86 but more recent models such as MolGPT87 have adopted reinforcement and curriculum learning to meet multiple design constraints. General-purpose LLMs like MolT588 and GPT-413 usually tackle constrained molecule generation, with MolT5 using self-supervised learning to pretrain on large text and molecular datasets. However, these models generally perform less effectively than specialized models. Multimodal approaches, such as GIT-Mol,89 further enhance general LLM capabilities by integrating graph, image, and text data, significantly improving constrained molecule generation tasks. Additionally, Lingo3DMol90 introduces a pocket-based 3D molecule generation method that combines language models with geometric deep learning, enabling more precise molecular design by incorporating spatial binding constraints. Complementing these approaches, Evo,40 a genomic foundation model, extends sequence-based generative design across molecular and genome scales, demonstrating zero-shot function prediction and multimodal synthesis of DNA, RNA, and protein molecules, which may support molecular design and functional optimization in drug discovery.

De novo protein generation involves designing protein sequences from scratch, either to explore the protein space in an unconstrained manner91,92,93 or to achieve specific functional objectives in a constrained manner.94,95 Unconstrained generation, using specialized LLMs like ProtGPT291 and ProGen,96 has demonstrated success in generating novel sequences that resemble natural proteins, while also exploring uncharted protein space. Constrained generation, aiming to create proteins with specific functions or within protein families, leverages models like ProGen96 and PoET,97 which ensure that new sequences maintain the structural integrity of the targeted family. In drug discovery, LLMs support the design of protein binders through inverse folding techniques, contributing to the early stages of the pipeline illustrated in Figure 4, particularly during hit identification and lead optimization. RFDiffusionAA64 generates highly specific binding pockets by leveraging structural knowledge from models like RoseTTAFold. Recent work with PocketGen98 has further improved pocket-based protein generation by incorporating graph transformers and sequence refinement modules, enabling the design of high-affinity binding sites with enhanced structural consistency.

General-purpose LLMs have also emerged as effective tools in protein design. ProteinDT,99 for instance, integrates textual descriptions into protein design and achieves high accuracy in generating de novo proteins guided by text. Moreover, the ESM protein language model52 has been employed to design both unconstrained and constrained proteins, achieving a 67% success rate in creating functional proteins. In therapeutic applications, de novo designed proteins have been successfully used to neutralize lethal snake venom toxins,100 highlighting the potential of AI-driven protein design in developing novel therapeutics. These advances correspond to the assistance and in silico simulation tasks shown on the right side of Figure 4, where LLMs enable protein optimization, molecular property prediction, and knowledge-driven design. Building on this progress, newer models such as ESM371 further improve the accuracy of complex structure prediction and functional protein design. Nonetheless, a key open question remains whether LLMs trained on natural sequences can reliably generalize to the design of unnatural proteins.

Protein-ligand interaction prediction is central to drug discovery, as understanding how drugs (ligands) bind to protein targets informs both screening and lead optimization. In silico techniques such as molecular docking and predictive machine learning models have significantly accelerated early-stage development efforts. LLMs are now increasingly employed in this context, both as the backbone of specialized systems and as components within broader predictive frameworks. These applications highlight the potential of LLMs to enhance the efficiency and effectiveness of drug discovery workflows.

Protein-specific LLMs combined with molecular fingerprints have been used for high-throughput virtual screening, identifying binders with sub-nanomolar affinity.76 They are also embedded in broader predictive pipelines to support tasks such as docking and binding affinity estimation.101,102,103 PSICHIC,20 for example, demonstrates that learning directly from protein sequences and ligand SMILES can surpass structure-based approaches in predicting interactions. PSICHIC can also identify protein residues and ligand atoms involved in binding, highlighting how LLMs can infer key interaction features from sequence-level data alone. General-purpose models such as Galactica16 extend these capabilities by predicting docking scores using broader scientific context. As LLMs increasingly integrate molecular and domain-level knowledge, they offer a path toward more scalable and precise modeling of protein-ligand interactions in drug development.

Though current models are promising for de novo molecule generation and binding prediction, future research should aim to enable jointly optimizing molecular design with synthetic feasibility, integrating multi-scale dynamics, and capturing conformational changes and solvent effects.

## Section: Drug discovery › In silico simulation › Maturity assessment

Specialized LLMs are increasingly applied in industry, with tools being used for protein-protein complex prediction, and expanding to protein-ligand interactions and nucleic acids. In Silico Medicine has developed Chemistry42,104 which utilizes specialized LLMs to identify discoidin domain receptor 1 (DDR1) kinase inhibitors and generate novel molecular structures with optimized properties, validated through in vitro and in vivo studies. Similarly, IBM’s Molformer105 shows promise in generating molecules for SARS-CoV-2 inhibition and antimicrobial peptides.106 In contrast, general LLMs are still primarily confined to in silico environments, facing challenges in scientific understanding and quantitative analysis. For instance, GPT-444 struggles with interpreting SMILES strings and lacks the precision needed for tasks like binding affinity prediction, leading to suboptimal performance in simulations.

## Section: Drug discovery › ADMET prediction

As shown in Figure 4, ADMET prediction—covering absorption, distribution, metabolism, excretion, and toxicity—is a critical step during the hit to lead and lead optimization stages, helping to eliminate compounds with suboptimal pharmacokinetic or toxicological profiles. By accurately forecasting these properties in silico, researchers can reduce costly late-stage failures and prioritize compounds with favorable biological characteristics. ADMET property prediction draws from multiple scientific domains, including physiology, physical chemistry, biophysics, and quantum mechanics. Recent developments in LLMs have significantly enhanced predictive capabilities in this area by learning patterns from large-scale molecular and textual datasets.

Specialized LLMs are typically trained on molecular representations such as SMILES strings and optimized for tasks like property classification and toxicity assessment. Transformer-based architectures such as Molformer105 have established new performance benchmarks in molecular property prediction, although their training requires considerable computational resources. In parallel, general-purpose LLMs have also shown promise when adapted or augmented for ADMET-related tasks. Models like LLM4SD5 and Galactica16 can enhance traditional machine learning workflows or be fine-tuned to directly perform ADMET predictions. Additionally, pre-trained models that combine molecular and textual inputs, such as GIT-Mol89 and MolT5,88 have demonstrated versatility across molecular property tasks. GPT-4, despite being trained on general text data, has also been used to interpret and predict molecular behaviors, although its performance depends heavily on careful prompt engineering and post-processing. The diversity of strategies, ranging from molecular-specific fine-tuning to multimodal integration, illustrates the expanding role of LLMs in predictive toxicology, pharmacokinetics, and physicochemical profiling.

Despite significant advances, key challenges remain for next-generation ADMET models. Future systems should aim to generalize robustly to novel chemical scaffolds beyond training data distributions, reducing dependence on resource-intensive fine-tuning. Enhanced interpretability frameworks are crucial to elucidate the structural and mechanistic drivers behind predictions, moving beyond black-box outputs.

## Section: Drug discovery › ADMET prediction › Maturity assessment

Maturity assessment provides a cloud-based platform for real-time molecular screening and efficient prediction of molecular properties. In an advanced stage, LLM4SD5 utilizes general-purpose LLMs like Galactica16 to extract meaningful hypotheses from ADMET data. These hypotheses have outperformed traditional methods, such as random forests, and are validated by pharmacologists to ensure their relevance and effectiveness.

## Section: Drug discovery › Lead optimization

Lead optimization involves modifying a drug candidate’s molecular structure or protein sequence to improve its potency, safety, and stability. Traditionally, this process relies on the knowledge and experience of chemists or biologists, but it is time consuming and often requires multiple attempts to achieve the desired outcome. LLMs assist by analyzing large datasets to predict how structural changes affect molecular properties, thereby guiding decision-making and reducing the number of experimental iterations.

Molecular optimization modifies a compound’s structure to improve efficacy, stability, and safety, with two primary approaches: uncontrolled and controlled optimization. In uncontrolled optimization, functional groups are modified while preserving the core scaffold, using model-guided strategies to enhance desired properties. In controlled optimization, users specify molecular segments for more precise modifications. Specialized LLMs have been developed to effectively support both uncontrolled and controlled molecular optimization strategies. For uncontrolled optimization, models like Reinvent 427 use reinforcement learning to modify properties while maintaining scaffold integrity. In controlled optimization, models use matched molecular pair analysis, and C5T5107 improves performance by training on property-specific tokens rather than. Explicit molecular pairs. Prompt-MolOpt108 further advances molecular optimization by leveraging prompt-based embeddings to improve multiproperty optimization, excelling even in data-scarce settings through causal generalization. Multimol109 has recently been introduced for multi-objective molecular optimization, achieving significant improvements over baseline methods. General-purpose LLMs such as MoleculeSTM110 and ChatDrug111 incorporate human feedback to refine molecular design. MoleculeSTM uses multimodal learning to generate structures from textual descriptions, while ChatDrug refines workflows through iterative feedback. Although GPT-413 demonstrates some capacity for structure innovation, its lack of iterative refinement limits its utility in fully automated pipelines.

Protein optimization, similar to molecular optimization, involves modifying protein structures to enhance functionality and safety, often requiring labor-intensive iterative adjustments by biochemists. LLMs contribute to this process by predicting the effects of structural modifications on protein properties, thereby streamlining early design decisions. In antibody drug development, for example, LLMs help improve antigen binding, reduce immunogenicity, enhance stability, and prevent issues such as polyspecificity.112,113,114 Optimization strategies can be broadly categorized as uncontrolled or controlled, each benefiting from LLM support. In uncontrolled optimization, models like ESM52 suggest evolutionarily viable mutations to enhance protein fitness across families,115 as demonstrated in immunoglobulin G (IgG) antibody affinity improvements with minimal testing. In controlled optimization, techniques such as protein hallucination and inpainting94 refine sequences while preserving backbone structure.116 Additionally, ProteinDT,99 a general-purpose LLM, optimizes protein sequences using prompts containing specific property information, employing latent interpolation to align text and protein representations. These advances show that LLMs can effectively optimize protein structure, stability, and binding, offering a novel approach to feature-specific protein engineering.

Though existing methods show promise, future optimization models should better navigate complex multi-objective trade-offs (e.g., potency vs. safety) and reduce reliance on extensive training data. They should integrate a deeper biological context for physiologically relevant predictions, and anticipate downstream effects beyond immediate targets.

## Section: Drug discovery › Lead optimization › Maturity assessment

Specialized LLMs for lead optimization have been validated through real-world experiments. For instance, Moret et al. (2023)117 developed chemical language models that identified a new phosphatidylinositol 3-kinase (PI3K) γ ligand with sub-micromolar activity, while Hie et al. (2023)115 enhanced the affinity of seven antibodies against Ebola and SARS-CoV-2 through a language-model-guided process. In contrast, general LLMs are still in the early stages, with in silico testing only. The main challenge for general LLMs in lead optimization is the need for a deep understanding of scientific language.

## Section: Drug discovery › Assistance

In the early stages of drug discovery, including the “understanding disease mechanisms” phase, researchers rely on diverse resources such as compound libraries, scientific publications, and patent data to inform target selection and therapeutic strategy. To access and integrate this information, general-purpose LLMs are increasingly employed in information retrieval workflows, combining web search and knowledge extraction to gather relevant data from literature, compound databases, and intellectual property sources. Models such as Galactica16 and GPT-413 further support researchers by clarifying complex scientific concepts and enhancing domain-specific understanding, thereby improving early-stage decision-making.

## Section: Drug discovery › Assistance › Maturity assessment

General LLMs have reached an advanced stage in information retrieval and explanation for drug discovery. Some biotech companies are exploring ChatGPT plug-ins for searching medical answers in company documents,79 while GPT-4 enhances drug discovery through its coding capabilities, assisting in tasks like data downloading and preprocessing.44

## Section: Clinical trials

As the final stage of drug development, clinical trials evaluate a candidate compound across four sequential phases to assess its safety, efficacy, and long-term effects, as illustrated in Figure 5. The overview of LLM tools for the clinical trials step is summarized in Table 3. Phase 1 tests the compound’s safety and tolerability in a small group of healthy volunteers. Phase 2 evaluates its efficacy and side effects in a larger patient group. Phase 3 compares the new treatment with existing ones in a larger patient population to identify differences. Phase 4, conducted after regulatory approval, monitors the compound’s performance under real-world conditions to detect long-term or rare adverse effects. As shown on the right side of Figure 5, LLMs can support this pipeline through various tasks, including clinical-trial prediction and planning, patient-trial matching, and outcome reporting, thereby enhancing decision-making throughout the clinical validation process.

Overview of methods in the “clinical trials” stage

## Section: Clinical trials › Clinical practice

In clinical trials, practitioners are responsible for four key tasks: International Classification of Diseases (ICD) coding, patient-trial matching, outcome prediction, and trial planning. Each of these requires substantial domain expertise and involves analyzing complex datasets such as electronic health records (EHRs), eligibility criteria (ECs), trial protocols, and clinical outcomes. General-purpose LLMs offer promising capabilities to streamline these processes by efficiently extracting, integrating, and generating information across large-scale clinical documents.

ICD coding, a foundational but labor-intensive aspect of clinical documentation, requires precise assignment of diagnostic codes to patient records. LLMs have been used to streamline this process by analyzing large volumes of EHR data and predicting the most appropriate codes, enabling practitioners to make more informed decisions. Recent approaches to automated ICD coding have evolved from traditional long short-term memory (LSTM)-based118,119 architectures to transformer-driven models. For example, BERT-XML,120 integrates BERT pretraining with multi-label attention for more accurate code prediction, while PLM-ICD121 adapts domain-specific models such as BioBERT,24 fine-tuning them for ICD coding and using segment pooling to improve efficiency and accuracy.

Patient-trial matching has traditionally relied on manual review of electronic health records (EHRs) and eligibility criteria (ECs) by physicians and data analysts, a process that is both time consuming and error prone. Recent studies have explored the use of general-purpose LLMs to streamline this task. For instance, Med-monoT5122 has been fine-tuned for medical passage ranking, and den Hamer et al. (2023)123 employed InstructGPT124 to assist physicians in eligibility determination. These models help reduce clinical workload and improve matching precision, although human oversight remains necessary due to potential misinterpretation of ambiguous criteria. TrialGPT9 advances this line of work by generating trial rankings accompanied by detailed justifications, but its occasional inaccuracies highlight the importance of cautious integration into clinical workflows.

Clinical trial planning and prediction are increasingly supported by the integration of LLMs, which support key tasks such as trial retrieval, eligibility criteria design, site selection, and outcome forecasting. Med-monoT5122 has been adapted for medical passage ranking to improve the retrieval of relevant trials. CliniDigest125 integrates GPT-3.5 to enhance context-aware retrieval across trial documents. AutoTrial, using a two-stage GPT-2 training process, generates eligibility criteria by learning patterns from historical trials, reducing manual workload. Trial site selection has also been addressed through models such as FRAMM,126 which incorporate multimodal data for optimized matching and represent an early step toward LLM-driven planning. In addition, outcome prediction has been improved using LLM-based models such as HINT,10 SPOT,11 and MediTab,12 which outperform traditional baselines in clinical forecasting tasks.

Document writing in clinical settings, including discharge summaries, clinical notes, and radiology reports, has traditionally been labor intensive, but recent advances in LLMs are enabling automation across these domains. For discharge summaries, Patel et al. (2023)127 demonstrated ChatGPT’s potential for automatic generation, while Shing et al. (2021)128 employed an extractive-abstractive summarization pipeline to enhance coherence. In orthopedic documentation, Transformer-based approaches have shown higher accuracy than recurrent neural networks in generating clinical narratives.129 For randomized controlled trial (RCT) reports, RobotReviewer130 automatically extracts and summarizes key information. Recent multimodal LLMs, including MedViLL131 and Med-PaLM2,132 align visual and textual inputs to generate clinically coherent radiology reports, demonstrating the potential of language models in high-stakes diagnostic documentation.

Though existing methods improve efficiency, future clinical LLMs should aim to achieve near-perfect reliability for high-stakes decisions, seamlessly integrate multimodal data (imaging, genomics, real-world EHRs), and provide auditable rationales that align with clinical reasoning.

## Section: Clinical trials › Clinical practice › Maturity assessment

In clinical trial practice, tasks such as ICD coding, patient-trial matching, and clinical trial planning are still in the early stages of general LLM implementation. Despite limited real-world testing, the rapid development of these models, especially in processing medical knowledge, suggests a promising future for their application.6

## Section: Clinical trials › Patient results

Patient outcome prediction involves forecasting future clinical events using EHRs, a process increasingly supported by language models that encode clinical data to aid informed decision-making across hospital- and disease-related tasks. Hospital-related prediction tasks focus on short-term clinical events. Models such as NYUTron,133 fine-tuned on clinical notes, predict mortality, comorbidity, and hospital readmission. MediTab12 integrates diverse medical data types to improve forecasting of clinical deterioration. In contrast, disease-related tasks target long-term health outcomes, such as diagnosis, morbidity, and disease progression. MMedLlama3134 extends these approaches to multilingual settings by training on diverse medical corpora. MUSK135 combines pathology images and clinical text to improve prognosis and immunotherapy response prediction, while BiomedGPT136 generalizes across biomedical domains to model disease trajectories and treatment outcomes through multimodal learning. Despite these advances, LLMs face ongoing limitations in clinical decision accuracy and alignment with diagnostic guidelines,137 indicating the need for further refinement before widespread adoption.

Though existing methods advance predictive capabilities, future models must achieve clinical-grade reliability for critical decisions, integrate longitudinal real-world data (e.g., wearables and social determinants of health) for personalized trajectories, and provide interpretable rationales aligned with medical reasoning.

## Section: Clinical trials › Patient results › Maturity assessment

LLMs show promise in predicting patient outcomes, aiding in diagnosis, and prognoses. General LLMs excel at handling unstructured data from electronic medical records. For example, NYUTriton133 integrates with the NYU Langone Health System to predict in-hospital mortality, estimate comorbidity indices, and predict 30-day readmissions. Similarly, Google’s Med-PaLM2132 achieved 86.5% accuracy in medical question-answering tasks, surpassing the medical passing score, and is being tested with select client groups, including VHC Health and Mayo Clinic.

## Section: Clinical trials › Assistance

General-purpose LLMs such as GPT-413 and Med-PaLM2132 play an increasing role in clinical trial support by simplifying medical content, facilitating trial-related literature retrieval, and assisting in pharmacovigilance. These models are effective in translating complex medical knowledge into patient-friendly language,15 thereby improving trial comprehension and engagement. Clinicians benefit from LLMs’ advanced information retrieval capabilities, enabling efficient literature searches and eligibility assessments. In pharmacovigilance, LLMs contribute by identifying drug-drug interactions16,23 and generating analytic code to support data processing,13 thus improving workflow efficiency.

## Section: Clinical trials › Assistance › Maturity assessment

General LLMs have advanced in clinical assistance, supporting physicians and staff in tasks like document writing. For instance, Webster et al. (2023)138 demonstrated their effectiveness in generating clinical notes, managing chronic condition check-ins, and summarizing patient issues. Oracle’s Clinical Digital Assistant, which handles administrative tasks via voice commands, and Google’s MedPalm2, used for information retrieval and knowledge explanation in real-world settings,132 further highlight the growing capabilities of these models in clinical practice.

## Section: Future directions

LLMs have yielded impressive early successes across the drug-discovery pipeline; progress, however, remains uneven, and key limitations persist, as shown in our maturity assessment. To clarify both the challenges and the opportunities ahead, each subsection below follows a gap-first, solution-next structure: we first identify the main limitation, then propose research directions and dataset initiatives to close the gap and realize the full potential of LLMs in drug development.

## Section: Future directions › Integrating biological insights

Improving LLMs’ scientific understanding is crucial for their application in drug discovery, requiring them to grasp specialized terminologies such as SMILES and IUPAC nomenclature for molecular generation and editing. Models like GPT-4, however, have shown limitations in understanding SMILES strings.44 They must likewise parse EHR terminology to match trial participants. Nevertheless, effective benchmarking, a crucial first step in guiding LLM development, is hindered by the scarcity of medical question answering (QA) datasets that capture real-world tasks. Priorities include stronger biochemical explanations and DNA/RNA secondary structure reasoning. To this end, high-throughput assays such as SHAPE139 and DMS140 are providing grounding data. Advances in statistical mechanics, such as metadynamics,141 quantum mechanics, and molecular mechanics,142 are enhancing drug discovery predictions, though integration into LLMs has been slow due to interdisciplinary gaps and data compatibility challenges. With increased collaboration and improved computational resources, these techniques are expected to further enhance LLMs’ role in drug discovery.

Recent trends frame general-purpose LLMs as tool users: they orchestrate specialized software as human experts do, invoking external molecular dynamics analysis libraries, graph-neural encoders, or quantum packages on demand. Large-scale biological data, such as multi-nanosecond trajectories, do not need to be passed verbatim. Instead, they stream through summarization models that compress atomic motions into token-efficient latent representations (e.g., principal component projections, time-averaged contact maps, or learned spatiotemporal embeddings) before entering the LLM’s context window. While molecular dynamics trajectories exemplify this approach, the same compression and retrieval strategy applies to other voluminous datasets, including cryo-EM images, longitudinal single-cell profiles, or spatial omics atlases. Streaming memory Transformers and retrieval-augmented generation (RAG) then enable the LLM to recall arbitrary data slices without catastrophic forgetting. Such hybrid pipelines automate large-scale simulation analysis and reveal emergent biophysical patterns at wafer-scale throughput.

## Section: Future directions › Addressing ethical, privacy concerns, fairness, and misuse with LLMs

LLM-driven drug discovery faces ethical challenges: accountability, privacy, fairness, and misuse. As these models shape decisions, assigning responsibility for success or failure becomes complex. Their opaque logic and rapid evolution require updated regulation and clear ethical guidelines.

Privacy is a major concern, especially with the potential for unintended data leakage. Because LLMs can memorize training data, they may reveal sensitive multi-omics profiles. Adversaries can extract such fragments, underscoring the need for stronger safeguards. Misuse is another threat; models such as MegaSyn2 can be repurposed for harm,143 so regulation must block dangerous applications without stifling progress.

Fairness remains critical. Underrepresented diseases or populations in training data can lead to biased predictions that harm marginalized patients; models trained on well-studied cohorts often underperform elsewhere.

Moreover, several influential LLMs are commercial products whose weights, update cadence, and in-context training data remain opaque. License terms can restrict downstream publication or model sharing, and silent weight updates complicate scientific reproducibility. Future studies should include “model provenance” statements, analogous to data availability sections, to ensure transparency and reproducibility.144 Because LLM outputs arrive in fluent prose, users are prone to automation bias and may over-trust hallucinated answers compared to outputs from symbolic frameworks. Accordingly, similar to the EU AI Act,145 we advocate a graduated autonomy framework: low-stakes tasks (e.g., literature triage) may be fully automated; moderate-stakes tasks (e.g., hit triage) require human verification and audit logs; and high-stakes or clinical decisions demand formal uncertainty estimates, counterfactual explanations, and regulatory oversight.146 In the latter two cases, mandatory human-in-the-loop checkpoints are required before any clinical deployment.

While LLMs hold significant potential for advancing drug discovery, responsible development must prioritize addressing these ethical concerns to maximize benefits and minimize risks.

## Section: Future directions › Addressing hallucination

The growing use of LLMs in drug discovery presents significant challenges, particularly their tendency to “hallucinate,” producing irrelevant or incorrect responses. These errors can mislead research, wasting resources or steering efforts in unproductive directions, such as identifying incorrect biological targets or generating invalid molecular structures. In clinical settings, hallucinations may result in life-threatening implications, especially in diagnosis or data interpretation. While some biotech companies are using LLMs to interact with biological knowledge graphs to identify drug targets,79 these hallucinations remain a major risk. To mitigate this, strategies such as knowledge editing, parameter tuning, and plugin integration can improve factual accuracy. Grounding LLMs in retrieval-augmented generation (RAG) with external documents enhances the relevance of their outputs, while fine-tuning on debiased datasets helps reduce shortcuts and spurious correlations. Techniques like chain of thoughts prompting ensure the outputs are grounded in factual information, and refining decoding algorithms, such as factuality enhanced decoding, improves alignment with actual data, increasing the reliability of LLM-driven drug discovery.

## Section: Future directions › Improving data analysis

LLMs are increasingly applied in drug discovery to process and analyze large datasets, including numerical and spatiotemporal data, essential for understanding disease mechanisms and predicting molecular properties. While LLMs excel in text generation, they struggle with quantitative tasks like arithmetic,13 often producing incorrect answers due to limitations in standard tokenization methods that fail to capture the unique properties of numerical data. Recent approaches, such as digit-by-digit encoding, aim to improve numerical representation,147 but tasks like interpolation and extrapolation remain challenging.

Ultra-large virtual screening (ULVS), filtering 108 to 109 molecules, poses a related bottleneck. Autoregressive LLM scoring is typically one to three orders of magnitude slower than GPU-optimized docking, shape hashing, or graph-kernel filters. Practical pipelines can therefore adopt a cascaded approach: fast physics- or graph-based filters cull the chemical space to a few million candidates; an LLM then re-ranks this subset, leveraging its learned priors, synthesis constraints, and reasoning over assay metadata. Alternatively, each molecule can be pre-encoded into compact latent fingerprints, learned by graph autoencoders or efficient SMILES language models, and stored in a vector database; the LLM accesses these representations using RAG, thereby avoiding inefficient token-by-token inference over the entire compound library. This hybrid design amortizes computational cost while injecting biochemical intuition that purely geometric methods lack.

Additionally, LLMs struggle with spatiotemporal data, which is crucial for modeling dynamic molecular interactions. While they handle static text effectively, they face difficulties managing multidimensional, temporal data in areas such as molecular dynamics simulations and spatiotemporal transcriptomics. Improving LLMs’ spatiotemporal and multi-modal capabilities through hybrid approaches could enhance drug discovery by enabling autonomous analysis of molecular behaviors over time, thereby accelerating drug candidate identification and uncovering hidden molecular pathways.

## Section: Future directions › Multimodal-hybrid LLM ecosystems

Future progress will hinge on large language model ecosystems that are both multimodal and hybrid. Next-generation multimodal LLMs (MLLMs) will natively ingest and reason over the heterogeneous evidence base of drug discovery, including chemical graphs, protein structures, microscopy images, electronic health records, and the scientific literature, allowing experimentalists to query complex, cross-domain questions in natural language or code.16 At the same time, these systems must blend the complementary strengths of general-purpose and specialized models. General LLMs4,5 provide broad world knowledge, conversational interfaces, and chain-of-thought reasoning that help scientists frame hypotheses and interpret results. Specialized LLMs,20,25,96 fine-tuned on curated biochemical corpora, deliver high-fidelity predictions for niche tasks such as binding-mode rationalization, QSAR, or protein-ligand docking. A tightly coupled workflow could transform laboratory practice: for example, specialized models can execute domain-specific analyses and pass structured outputs back to a general LLM as an “orchestrator” for synthesis, explanation, and next-step planning.148 Such multimodal-hybrid architectures promise richer mechanistic insight, faster iteration cycles, and more reliable decision-making across the entire drug-discovery pipeline.

## Section: Future directions › Open datasets and benchmarking needs

Continued progress in AI-enabled drug discovery requires a concerted community effort to develop domain-specific benchmarks comparable to those in the general LLM field. Benchmarks such as OpenAI’s HumanEval149 for code generation and the MMLU150 benchmark for multitask language understanding have provided standardized, rapid evaluation frameworks that drive model improvements. In contrast, scientific applications still often rely on ad hoc case studies, limiting our ability to make fair comparisons or measure true progress. Recent initiatives such as ChemBench,151 a framework for evaluating chemical knowledge and reasoning across more than 2,700 question-answer pairs against human experts, demonstrate the power of structured, richly annotated benchmarks for the sciences. Similarly, large-scale BioNLP152 benchmarks for the systematic evaluation of four LLMs on twelve biomedical natural language processing (NLP) tasks offer critical insights and practical guidelines for deploying LLMs in biomedical language processing.

Future benchmarking resources in drug discovery should capture the field’s inherent multimodality by integrating chemical graphs, three-dimensional structures, high-content imaging, omics readouts, temporally resolved simulations, and mechanistic annotations. Equally important are curated synthesis corpora with atom-level provenance and cost-sustainability metadata, as well as integrative clinical knowledge graphs linking trial protocols to molecular endpoints and real-world outcomes. Publishing these assets under permissive licenses and maintaining them through community-driven crowdsourcing will establish transparent evaluation standards, seed continual pre-training, and foster the safe, reproducible deployment of large language models across the drug-discovery pipeline.

## Section: Acknowledgments

We thank members of the Church lab for their critical reading of the manuscript and helpful discussions, including Rohit Arora, Xavier Portillo, Esther Mintzer, Juseong Lee, Katelyn Buehring, Asaf Ashkenazy Titelman, Chun-Ting Wu, Yu Wang, and Zhengkuan Tang. This work was funded by the LEO Foundation (LF-OC-20-000420), a grant from the American Academy of Dermatology (AAD), and the Wyss Validation Fund. S.P. is supported by the ARC Future Fellowship (no. FT210100097) and ARC DP240101547. L.T.M. and G.I.W.’s research into artificial intelligence applications for drug discovery is supported by a National Health and Medical Research Council (NHMRC) of Australia Ideas grant (APP2013629). L.T.M.’s research is also supported by the National Heart Foundation of Australia (grant no. 101857), the National Health and Medical Research Council (NHMRC) of Australia, and the Department of Health and Aged Care through the Medical Research Future Fund (MRFF) Stem Cell Therapies Mission (grant no. MRF2015957).

## Section: Author contributions

L.L., S.P., and G.C. co-supervised the project. Y.Z., H.Y.K., and J.J. conceptualized and designed the survey framework. Y.Z., H.Y.K., and J.J. conducted the literature review and analysis. Y.Z., H.Y.K., and J.J. prepared the figures and tables. M.Y. and L.T.M. provided domain expertise and contributed to the critical evaluation of surveyed methods. G.I.W. provided methodological insights. Y.Z., H.Y.K., J.J., and M.Y. drafted the manuscript. All authors reviewed, edited, and approved the final manuscript.

## Section: Declaration of interests

G.C. has patents and interests in AI and biotech: Lila and Glotta Tech. Complete details of all relationships for G.C. can be found at http://arep.med.harvard.edu/gmc/tech.html.

## Section: Declaration of generative AI and AI-assisted technologies in the writing process

The authors used OpenAI’s ChatGPT for proofreading, grammar checks, and stylistic edits. All core ideas, analyses, and writing were devised and authored by the research team, who take full responsibility for the manuscript’s content.

## Section: Contributor Information

Li Li, Email: li_li@hms.harvard.edu.

Shirui Pan, Email: s.pan@griffith.edu.au.

George Church, Email: gchurch@genetics.med.harvard.edu.


---

# Letter to the Editor: "Development and validation of a deep learning ultrasound radiomics model for predicting drug resistance in lymph node tuberculosis a multicenter study"

- **Authors:** Shuyi Liu, Xuewei Wu, Rui Zhang
- **Issuer:** International journal of surgery (London, England)
- **Type:** Scientific article
- **Published:** 2025-07-23
- **Language:** en
- **DOI:** 10.1097/js9.0000000000003118
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40705514/
- **Licence:** CC-BY-NC

## Section: Text

To the Editor,

We have read with great interest the article by Zhang et al[1]. Their study successfully demonstrates the potential of an ensemble machine learning (AdaBoost) ultrasound radiomics model to predict drug resistance in lymph node tuberculosis (LNTB) across multiple centers. The reported high diagnostic efficacy and the resulting clinical net benefit shown in the decision curve analysis represent a significant advancement toward non-invasive diagnostic strategies. However, we wish to offer comments on several methodological aspects that are vital for ensuring the clinical translatability and robustness of such models.

First, we are concerned about the risk of model overfitting, which is strongly suggested by the study’s results. The authors report that 161 features were used to train a model on a cohort of only 163 patients. This high feature-to-sample ratio creates an over-parameterized model that is highly susceptible to learning spurious correlations and noise from the training data, rather than robust biological patterns. This concern is amplified by the considerable drop in AUC from the training set (0.998) to the internal (0.798) and external validation cohorts (0.831–0.846). To quantify this concern, we performed a sample size calculation using the pmsampsize package in R[2]. Assuming an optimistic C-statistic of 0.80 and an outcome prevalence of 0.40 (approximating the 64/163 drug-resistant cases), the minimum sample size required to develop a stable model with 161 predictors is estimated to be 4899 participants. While developing a high-performance model is a primary goal, it is crucial that the dataset be sufficiently large to robustly support the number of predictors included, thereby preventing overfitting and ensuring generalizability[3]. A more aggressive feature selection process aiming for a parsimonious model is essential to improve generalizability.

Second, in a multicenter study, proactively addressing batch effects is crucial. Variations in ultrasound systems, acquisition parameters, and operator-dependent techniques across centers can introduce significant data heterogeneity. To ensure a model learns true biological signals over technical artifacts, we recommend first assessing the magnitude of these effects using tools like BEEx[4], followed by the application of a harmonization method, such as ComBat, to the radiomic data before model training[5]. This directly improves model robustness and its reliability across diverse clinical settings.

Finally, we note two points regarding the model’s clinical application and performance assessment. A key detail—the model’s optimal cut-off value determined from the training set—was not reported. For rigorous validation, this cut-off should be fixed and applied unchanged to all test sets to mimic real-world practice and prevent optimistic bias. Furthermore, while we commend the authors for providing calibration plots, the visual agreement appears suboptimal. To provide a quantitative measure of calibration, reporting the p-value from a formal statistical test, such as the Hosmer-Lemeshow (HL) goodness-of-fit test or the Spiegelhalter Z-test, would be highly informative.

In conclusion, the study by Zhang et al. is an important contribution to the non-invasive diagnosis of drug-resistant LNTB. Our comments are intended to foster discussion and highlight methodological considerations that could help future research in this field produce models with even greater clinical translatability and robustness.


---

# Leveraging Artificial Intelligence and Machine Learning for Characterizing Protein Corona, Nanobiological Interactions, and Advancing Drug Discovery

- **Authors:** Turkan Kopac
- **Issuer:** Bioengineering (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2025-03-18
- **Language:** en
- **DOI:** 10.3390/bioengineering12030312
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40150776/
- **Licence:** CC-BY

## Section: Abstract

Proteins are essential for all living organisms, playing key roles in biochemical reactions, structural support, signal transduction, and gene regulation. Their importance in biomedical research is highlighted by their role as drug targets in various diseases. The interactions between proteins and nanoparticles (NPs), including the protein corona’s formation, significantly affect NP behavior, biodistribution, cellular uptake, and toxicity. Comprehending these interactions is pivotal for advancing the design of NPs to augment their efficacy and safety in biomedical applications. While traditional nanomedicine design relies heavily on experimental work, the use of data science and machine learning (ML) is on the rise to predict the synthesis and behavior of nanomaterials (NMs). Nanoinformatics combines computational simulations with laboratory studies, assessing risks and revealing complex nanobio interactions. Recent advancements in artificial intelligence (AI) and ML are enhancing the characterization of the protein corona and improving drug discovery. This review discusses the advantages and limitations of these approaches and stresses the importance of comprehensive datasets for better model accuracy. Future developments may include advanced deep-learning models and multimodal data integration to enhance protein function prediction. Overall, systematic research and advanced computational tools are vital for improving therapeutic outcomes and ensuring the safe use of NMs in medicine.

## Section: 1. Introduction › 1.1. Understanding Protein Functions

Proteins are essential macromolecules vital for the survival and functioning of all living organisms. They perform numerous critical roles, including participating in biochemical reactions, providing structural integrity to cells and tissues, facilitating communication within and between cells, and regulating gene expression. Proteins are involved in a variety of functions, such as offering structural support, enabling biochemical reactions, managing gene expression, and facilitating signal transduction. The diverse functions of proteins in various biological processes underscore their importance in maintaining cellular balance and promoting overall health in organisms [1,2,3]. Proteins can catalyze chemical reactions, driving billions of biochemical processes, and often form larger macromolecular complexes. The structures and functional roles of proteins remain a significant focus of ongoing research [1,2]. Understanding the functions of proteins is a critical step in comprehending biological systems and influencing biological processes, which are essential in biomedical research and the development of biotechnologies. Moreover, proteins frequently serve as targets in drug discovery [4,5,6,7,8,9] because of their involvement in various diseases. Gaining insights into protein functions can aid in the development of targeted therapies [10].

The traditional methods employed to experimentally examine the structures of protein complexes include electron microscopy, X-ray crystallography, Raman spectroscopy, and NMR spectroscopy. The functions of these proteins can be assessed through techniques such as enzymatic analysis and biochemical assays [10,11,12,13]. However, these experimental approaches for elucidating protein function are often costly, time-consuming, and effortful, and they can only be employed for a restricted number of proteins. Consequently, given the current pace of structure determination, it may take a minimum of twenty years to obtain a comprehensive library of protein complex structures. Thus, the ability to predict protein functions computationally is essential for addressing the need for functional information on the majority of proteins, presenting a significant challenge within the field of bioinformatics [10]. At present, many protein sequences, totaling hundreds of millions, have been produced as a result of various genome and transcriptome sequencing initiatives. Nonetheless, the protein functions of less than 1% of these sequences have been confirmed through experimental data. This reveals a notable disparity between the identified protein sequences and their corresponding functions. As a result, it is essential to develop sophisticated computational techniques capable of reliably predicting protein functions, akin to the advancements achieved in deep learning (DL) for protein structure prediction and determination [10,14,15,16,17,18]. This situation emphasizes the pressing need to develop effective computational techniques capable of reliably predicting the structures of protein complexes, particularly when the structures of homologous proteins are unavailable [19].

## Section: 1. Introduction › 1.2. Exploring Nanobio Interactions: The Essential Role of Nanoinformatics

Proteins seldom function independently of the densely packed environment of a cell [20]. Their biological activities are closely tied to the partners with whom they interact [21]. Proteins have the ability to interact with various molecules. These interaction partners include ions, small organic compounds, membrane lipids, nucleic acids, small peptides, and other proteins, leading to the formation of both homo and heterocomplexes. Within the densely packed environment of the cell, proteins have evolved to achieve and sustain the efficiency and binding specificity essential for their function. The structural characteristics at the binding interfaces largely determine the physical interactions among proteins [1,2,22,23,24,25,26]. Research has shown that the binding interfaces in distinct protein complexes are highly similar. The structural characteristics of various binding interfaces can be effectively captured through AI. ML approaches hold significant potential for discovering and predicting the conformations of previously uncharacterized protein–protein interactions (PPIs) [19].

NMs have rapidly advanced across various disciplines; however, much of the research on NMs and nanotechnology relies on expensive experimental methods or complex calculations, such as the density functional theory (DFT) [27]. The properties of NPs—including shape, size, and surface chemistry—play a crucial role in determining their functions [28,29,30]. For NPs to be effectively utilized in theranostics, they must be engineered with precisely controlled characteristics, which requires the use of multiple reagents and interconnected experimental conditions [31,32,33]. Currently, nanomedicine research tends to focus on a limited range of NMs. As the demand for NMs to address biomedical challenges increases, the discovery of new materials has become a key area of interest within nanomedicine research. Scientists are actively investigating innovative material entities to broaden the options for nanoformulations that can address complex delivery challenges, such as stability in both physical and biological contexts, the immune response, and clearance by the reticuloendothelial system. Centralized platforms that offer guidance for nanoformulations could significantly accelerate research initiatives [34]. Carbon-based NMs, including graphene, carbon nanotubes (CNTs), and fullerenes, have garnered considerable attention because of their remarkable properties and potential applications across various fields, particularly in biomedicine. Comprehending how they interact with plasma proteins is essential for evaluating their cytotoxicity and biocompatibility with biological systems [12,35,36] and their prospective use in biomedical applications. Blood plasma proteins are generally categorized into three main groups: albumins, globulins, and fibrinogen, with albumins being the most prevalent [37].

The protein corona is a layer of biomolecules, primarily composed of proteins, that form around NPs when they enter a biological environment. This layer emerges as a result of protein adsorption onto the NP surface. The formation of the protein corona significantly influences the behavior, biodistribution, cellular uptake, and toxicity of NPs within biological systems [12,38,39,40,41,42,43]. Understanding the protein corona is essential for the development of effective NP-based drug delivery systems and other biomedical applications. The key factors that influence protein corona formation include the following (Table 1): NP characteristics, the physicochemical properties of the NPs, the environmental conditions, the protein binding affinities, the duration of NP exposure to the biological environment, the Vroman effect, and the protein concentration. These factors collectively determine the nature, composition, and biological implications of the protein corona surrounding NPs. The protein corona affects NP behavior in several significant ways, as shown in Figure 1 [12], which depicts the mechanisms and implications of this effect.

Understanding the effects of protein adsorption on NP surfaces is essential for optimizing their design and application in biomedical fields. The interaction between proteins and NP surfaces significantly impacts several critical factors, including surface properties, stability, biocompatibility, cellular uptake, circulation time, targeting efficiency, functionality, and toxicity (Table 2). Therefore, a thorough comprehension of protein adsorption dynamics is vital for advancing the efficacy of NPs in various biomedical domains. Numerous studies have focused on characterizing protein adsorption properties across a variety of surfaces [26,30,43,44,45,46,47,48]. Among these surfaces, carbon nanotubes (CNTs) have garnered considerable attention because of their unique physicochemical properties and promising applications in biomedicine [49,50,51,52]. Research indicates that the adsorption of bovine serum albumin (BSA) is markedly influenced by several parameters, including pH, temperature, and the intrinsic surface characteristics of the materials [49,53,54]. It has been demonstrated that surface modifications can considerably affect both the adsorption behavior and the conformation of adsorbed proteins [55]. For example, BSA adsorption on multiwalled carbon nanotubes (MWCNTs) tends to increase with increasing temperature and adsorbent dosage, whereas pH has the opposite effect. Notably, the adsorption capacity is greater at lower pH values, suggesting the dominance of strong electrostatic interactions between BSA and the MWCNTs [49]. Similarly, BSA adsorption on doublewalled carbon nanotubes (DWCNTs) exhibited optimal capacity at pH 4 and 40 °C, characterized by electrostatic attractions between positively charged protein molecules and negatively charged CNT surfaces [52]. These findings exemplify the significant diversity of interactions between NPs and proteins, emphasizing the necessity for comprehending these interactions to enhance NP design and functionality in biomedical applications. The versatility of CNTs in adsorbing various proteins offers considerable potential for applications in drug delivery, biosensing, and other biomedical fields. A comprehensive understanding of the factors influencing protein adsorption—such as pH, temperature, and surface functionalization—is crucial for optimizing the performance of CNTs in these applications.

The design of nanomedicines often relies on trial and error, necessitating extensive benchwork to optimize formulations and properties. To expedite progress, data science and ML are increasingly leveraged to predict the synthesis and biological behavior of NMs. Nanoinformatics has emerged as a significant area within nanobiotechnology, playing a significant role in revealing complex molecular interactions at the nanobio interface. This field aids in risk assessment related to NMs and offers new insights into their theranostic potential. It incorporates computational simulations to complement laboratory studies and enhance the understanding of NMs and their biological interactions. Computational simulations can predict the behavior and properties of NMs, which helps in designing experiments and interpreting experimental data. This complementary approach allows for a more comprehensive assessment of risks and the revelation of complex nanobio interactions, ultimately accelerating the development of safe and effective nanomedicines. As scientific disciplines become more data-driven, nanoinformatics integrates computer science, information technology, nanotechnology, and medicine to facilitate the discovery of NMs. The focus lies in informatics techniques for analyzing the structural and physicochemical properties of NMs, thereby accelerating their clinical application [34,37,56,57]. Nevertheless, effective data curation methods are essential for managing large datasets and often operating independently from AI applications. This disconnect leads to the use of small datasets with limited translational value. Moreover, the lack of standardized reporting metrics hinders comparability, and access to centralized databases remains a challenge for many researchers [34].

AI approaches, such as ML and DL, have the potential to significantly accelerate the development of NM preparation protocols and facilitate the discovery of new NMs by predicting nanobio interactions. DL models enhance protein function prediction by integrating multiple data modalities, such as sequences, structures, and interactions, for a holistic understanding of protein roles. These models leverage evolutionary information to improve accuracy and can be fine-tuned for specific prediction tasks using large language models for proteins (LLMPs). Advanced neural architectures, such as convolutional and recurrent networks, capture complex patterns, while few-shot and zero-shot learning enhances predictions for rare or novel proteins. Additionally, attention mechanisms and explainable AI improve interpretability, providing valuable insights. These advancements promise greater accuracy and reliability in protein function predictions. Nevertheless, their efficiency is presently limited by the absence of appropriate nanodescriptors and labeling techniques [58,59,60,61,62]. While biological data have improved, and powerful ML tools are now available for tasks such as bioimage analysis and protein structure prediction [2,63], several challenges persist. These include knowledge gaps, the need for better interpretability of ML algorithms, limited database accuracy, and difficulties in nanopattern recognition, all of which adversely affect NM research [27]. AI is profoundly transforming various industries, particularly bioinformatics, which focuses on the analysis of biological data through sophisticated methods and tools. Recent advancements in AI have enhanced the computational techniques for predicting interactions between proteins and DNA/RNA, marking a transition from traditional ML approaches to more advanced DL methodologies [64].

This review outlines recent advancements in ML and DL methodologies used for protein corona characterization, nanobio interactions, nanomedicine development, drug discovery processes, and protein–protein interactions. It critically evaluates the advantages and limitations of these approaches, their diverse applications across various fields, and potential future trends in this rapidly evolving domain. The paper provides a comprehensive examination of recent advancements in AI and ML techniques applied to different aspects of nanobiotechnology and drug discovery. The novelty of this paper lies in its systematic exploration of how AI and ML can be utilized to

Overall, the paper underscores the transformative potential of AI and ML in various scientific and medical fields while acknowledging ongoing challenges and the necessity for continued progress and collaboration.

## Section: 2. Evaluating the Literature on the Application of AI and ML Techniques for Characterizing Protein Corona, Nanobio Interactions, Nanomedicines and Drug Discovery, and Protein–Protein Interactions

In the present evaluation, the literature studies conducted have been systematically categorized into four primary domains: protein corona characterization, nanobio interactions, nanomedicines and drug discovery, as well as protein–protein interactions. A comprehensive evaluation of these studies was performed, and the key findings from this analysis are summarized in Table 3.

## Section: 2. Evaluating the Literature on the Application of AI and ML Techniques for Characterizing Protein Corona, Nanobio Interactions, Nanomedicines and Drug Discovery, and Protein–Protein Interactions › 2.1. Protein Corona Characterization

The protein corona plays a crucial role in modulating the behavior and functionality of NPs in biological environments. It also significantly impacts the interactions between NPs and cancer cells, influencing their therapeutic efficacy and biodistribution. Once NPs are introduced into physiological fluids, their surface properties undergo notable alterations. This “identity change” impacts their biochemical and physical characteristics, affecting cell targeting, systemic circulation, cellular uptake, and biocompatibility. Research has demonstrated that the behavior of the protein corona varies between positively charged and negatively charged NPs. Positively charged NPs attract more proteins due to electrostatic interactions, resulting in a thicker and more complex protein corona. This enhanced protein corona can improve the NPs’ ability to bind to negatively charged cancer cells, as it may reveal positively charged regions that facilitate strong electrostatic interactions. Conversely, negatively charged NPs form a distinct protein corona composition, often resulting in less effective binding to cancer cells. The protein corona on negatively charged NPs tends to be less complex and may not expose regions capable of strong interactions with the negatively charged surfaces of cancer cells. Understanding these dynamics is essential for the design of NPs intended for cancer therapy and diagnostics. Researchers can optimize NP interactions with cancer cells by manipulating surface charge and protein corona composition, thereby enhancing the targeting efficiency and therapeutic outcomes. This knowledge is instrumental in developing more effective NP-based systems for the sensitive detection and treatment of cancer cells in clinical settings [79,80,81,82].

Singh et al. [65] proposed a ML model to explore the influence of NM properties on cellular interactions and presented cell and nuclear shapes (CSI and NAF) as nanotoxicity markers. The study revealed that variations in epithelial cell shape are influenced by NM physicochemical properties, such as size, shape, concentration, diffusivity, zeta potential, and polydispersity, which affect intracellular uptake. They used optical methods to create nanodescriptors for analyzing cell–NM interactions, successfully predicting phenotypic markers across five NM classes. Research has highlighted how factors such as crystallinity, density, and electrical properties affect interactions and demonstrated that shape anisotropy impacts the CSI and NAF when spherical gold NPs are used as models. Ultimately, these findings suggest that NM-induced shape changes in cells may lead to epigenetic modifications and affect proliferation, emphasizing the need to consider NM properties in toxicity assessments. Fu et al. [66] highlighted the use of ML to predict the RPA of multiple proteins in the protein corona, which is important for biomedicine. Their study employed various algorithms for predicting protein adsorption to NPs and RPA values through classification and regression tasks. They utilized SHAP analysis to identify performance differences among models and reported that features such as “NP without modification” and “Incubation protein source” significantly affect RPA prediction, providing insights for protein corona design. However, they noted the challenge of modeling individual proteins separately and suggested that future research could integrate protein features for better model generalization. Overall, these findings emphasize the potential of ML in predicting the RPA of multiple proteins on the protein corona, providing valuable insights into the development of NPs for biomedicine.

William et al. [67] studied how AI can analyze protein interactions with ENMs to address potential toxicity risks. They used an AI model called the polypeptide chemical reaction optimized resistant logistic regression model (PCRO-RLRM), which enhanced protein composition predictions through Z score normalization and the position-specific scoring matrix (PSSM). The model achieved an accuracy of 96.57%, with sensitivity of 94.5% and specificity of 98.03%. These findings highlight the need for further research on protein interactions with ENMs and suggest that future studies should explore real-time interactions and integrate multiomics for deeper insights. Boadu et al. [10] reviewed DL methods for protein function prediction, highlighting advancements and challenges. They categorized these methods into four types: sequence-based, structure-based, interaction-based, and integrative methods, noting that structure and interaction methods often incorporate sequence data. The authors discussed the data sources, evaluation metrics, and critical assessment of protein function annotation (CAFA) benchmarks used to aid method development. They emphasized few-shot learning for predicting rarely annotated protein functions and outlined 30 DL methods. Additionally, they suggested developing LLMPs to address ongoing challenges. This review emphasizes the promise of DL and AI in advancing protein function prediction while calling for continued research.

## Section: 2. Evaluating the Literature on the Application of AI and ML Techniques for Characterizing Protein Corona, Nanobio Interactions, Nanomedicines and Drug Discovery, and Protein–Protein Interactions › 2.2. Nanobio Interactions

Bai et al. [69] emphasized the importance of systematically exploring nanobio interactions, as many studies alter NP properties in non-systematic ways, limiting the understanding of their biological effects. Data-driven methods, such as ML, could aid in predicting these interactions and reducing the need for animal testing. Effective experimental design, along with automated synthesis and characterization, is essential for developing trustworthy models. Most investigations focus on individual property variations, neglecting the combined effects of multiple NP properties, which are often critical. Variations in preparation methods and experimental conditions further complicate comparisons across studies. Thus, more systematic research is necessary to deepen our knowledge of and accelerate the development of reliable predictive models. The complexity of nanobio interactions exceeds that of small-molecule interactions, and despite the need for faster synthesis and testing nearly a decade ago, progress has been slow, with traditional methods such as protein NMR not applicable to NPs. Yan et al. [59] utilized convolutional neural networks to predict nanobio interactions from nanostructure images, creating a novel annotation method inspired by facial recognition technology. This approach eliminates complex nanodescriptor calculations and allows accurate predictions of the physicochemical properties (logP, zeta potential) and biological activities (cellular uptake, protein adsorption) of 147 unique NPs, including platinum, palladium, and gold. The models demonstrated high accuracy, with R2 values exceeding 0.68 for both external and cross-validation predictions, and provided explainability through class activation maps, enhancing DL efficiency for NM design.

Hirano and Kameda [68] studied the aromaphilicity indices of amino acids and their interactions with carbon NMs, which are essential for understanding protein adsorption and bioavailability in biological systems. They introduced the “aromaphilicity index”, which measures the affinity of 20 proteinogenic amino acids for aromatic carbon surfaces, and validated it via molecular dynamics (MD) simulations. This index strongly correlated with the experimental data and effectively predicted protein binding affinities for aromatic NMs, such as CNTs and graphene. The binding free energies for amino acids were calculated via an uncapped model, which differs from previous capped approaches. The aromaphilicity index, which shows unique trends but strong correlations with the experimental results, aids in predicting protein stability and positions on aromatic surfaces, which govern the formation of the protein adsorption layer, encompassing the development of the protein corona. This tool enhances the understanding of protein interactions and potential NM applications. Jia et al. [27] emphasized that ML greatly improves the design and discovery of NMs, streamlining research compared with traditional methods that often involve costly experiments or complex calculations. ML reduces labor and time in material testing and enables high-throughput screening, making it a valuable tool for NM research. However, challenges persist in translating NMs from the laboratory to industry, including knowledge gaps and the need for better interpretability of ML algorithms. The review addresses key aspects, such as structure design, properties, and interactions with biological systems, while noting issues such as inadequate databases and algorithm accuracy that require attention for future NM development.

Rao et al. [62] examined nanotheranostic design via ML to address the limitations of traditional diagnostics and therapies. Despite advancements, challenges such as lengthy NP synthesis, incomplete understanding of nanobio interactions, and regulatory hurdles persist. ML enhances NP synthesis, uncovers new materials, and offers insights into nanobio interactions. Deep neural networks (DNNs) aid in the development of diagnostic tools, improve detection accuracy, and optimize drug delivery. While ML shows promise, further work is needed to navigate nanotechnology complexities. Collaboration across scientific disciplines is essential to leverage ML for improved clinical outcomes. Panigrahi et al. [37] examined the role of nanoinformatics in understanding the interactions between blood plasma proteins and carbon-based NMs for biomedical applications. Despite the significant growth of carbon-based NMs in biomedicine over the last thirty years, challenges remain in translating laboratory findings to clinical use owing to a limited understanding of the bio–nano interface. Key challenges include the complex interactions of NM properties (shape, size, surface chemistry) with biomolecules. The development of NMs that effectively target biological sites while minimizing interactions with proteins and lipids is difficult. However, computational methods and AI techniques, such as predictive modeling and DL, show promise for enhancing drug retention and biocompatibility. Recent studies have emphasized the importance of computational simulations in understanding these interactions, positioning nanoinformatics as a vital field in nanobiotechnology for risk assessment and exploring the theranostic potential of NMs.

## Section: 2. Evaluating the Literature on the Application of AI and ML Techniques for Characterizing Protein Corona, Nanobio Interactions, Nanomedicines and Drug Discovery, and Protein–Protein Interactions › 2.3. Nanomedicines and Drug Discovery

Chen et al. [34] reviewed how integrating data curation with ML can enhance nanomedicine development, which has relied heavily on trial and error. As data science has increased in importance, recent efforts have focused on predicting the synthesis and biological behaviors of NMs through advanced analytics. ML algorithms can analyze large datasets to forecast material properties and efficacy in nanomedicine. However, collaboration between data curation and analytics is often lacking, with both fields progressing independently. This review stresses the need for cooperation between AI developers and nanoinformaticians to increase the clinical applicability of nanomedicine. This study also highlights the potential of ML for creating innovative nanomedicines and characterizing their biological interactions while addressing a significant challenge: the limited availability of diverse data for effective algorithm training. Figure 2 illustrates the curation workflow for nanomedicine data and data analysis. Figure 3 shows the enhancement of nanomedicine efficacy via the use of ML platforms for predictive biodistribution.

Gupta et al. [72] explored the role of AI and DL in drug discovery, highlighting the transition from ML to DL and the impact of big data. They reviewed how AI integrates with traditional chemistry to enhance various stages of drug development, including screening, toxicity assessment, drug dosage effectiveness and efficacy, drug release and monitoring, drug repositioning, drug–target interactions, and polypharmacology. Overall, advancements in AI and DL offer significant opportunities for improving rational drug design and discovery, benefiting humanity. The advancements and applications of AI in healthcare and pharmaceuticals are prominently illustrated in Figure 4.

Dhakal et al. [6] reviewed the role of AI in predicting protein–ligand interactions, highlighting its importance in drug discovery. They provided an overview of proteins, ligands, and relevant databases and analyzed various ML approaches for predicting protein–ligand binding sites, ligand-binding affinities, and binding poses. The authors emphasized the potential for improved prediction accuracy by integrating diverse physicochemical properties and DL techniques, suggesting a multitask approach to unify these traditional separate tasks to increase drug discovery efforts. Scott-Fordsmand and Amorim [71] reviewed the use of ML to increase the sustainability of NMs in environmental risk assessment (ERA). They noted that while ML can improve data gathering, exposure assessment, hazard identification, and risk characterization, its application and standards are insufficient. Emphasis is needed on data quality and addressing historical biases to prevent errors. The review also noted that the advantages of ML over traditional methods are often overstated, and comprehensive integration of ML at all ERA levels is lacking. Understanding material descriptors for smart NMs is essential, as different factors may influence various risks, such as size for cellular uptake and surface charge for environmental fate.

Wang et al. [70] reviewed the barriers to the systemic delivery of NPs, highlighting the importance of effective in vivo delivery for successful nanomedicine. They introduced the concept of “NP blood removal pathways” (NBRP), which encompass various cell-dependent and cell-independent blood clearance mechanisms. This review emphasizes NP design and biological modulation strategies to increase delivery by reducing NBRP interactions, noting that surface chemistry is a critical factor. Combinatory biological-PEG surface modifications increased blood circulation by approximately 418% and decreased liver accumulation by up to 47%. Strategies to overcome biological barriers are categorized into those that modify NP characteristics and those that alter the biological environment. A better understanding of NP–NBRP interactions can lead to safer and more efficient nanomedicines. The review also identifies opportunities for improvement, such as standardizing design and reporting, utilizing central data repositories, and applying meta-analysis and ML in future nanomedicine development. Nguyen et al. [73] reviewed how AI enhances G-protein-coupled receptor (GPCR) drug discovery, supporting stages from understanding GPCR functions to identifying ligand interactions and predicting clinical responses. They covered key AI concepts, including ML and DP, existing applications, and discussed the benefits and limitations of AI in GPCR drug discovery, expressing optimism about its potential to make drug discovery faster, smarter, and more cost-effective.

## Section: 2. Evaluating the Literature on the Application of AI and ML Techniques for Characterizing Protein Corona, Nanobio Interactions, Nanomedicines and Drug Discovery, and Protein–Protein Interactions › 2.4. Protein–Protein Interactions

The dynamics of PPIs are influenced primarily by the structural characteristics of their binding interfaces [83]. Research has shown that mutations in residues located at the interface of protein complexes can considerably alter their stability, thereby impacting their cellular functions [84]. Consequently, elucidating the structural basis of protein interactions is essential for gaining a deeper understanding of the functions of these molecules [19]. Despite advances in experimental data and computational resources, our understanding of PPI is still limited. The complexity of PPIs, which are influenced by transient aggregates and non-transients, different compartments, and macromolecular condensates, complicates the interpretation of proteomic data. The current models, even those at atomic resolution, often capture only a small fraction of functional interactions in crowded cellular environments. Distinguishing functional from non-functional interaction surfaces remains difficult. While ML and DL show promise in many areas, their application in PPI predictions has limitations, with both shallow and DL methods yielding similar results, indicating insufficient representations of interacting surfaces and varying binding affinities on the basis of cell type and regulation. More high-resolution examples of protein complexes are needed to address these challenges [2].

Jovine [78] explored ML applications in analyzing PPIs, particularly UMOD polymerization. Using advanced neural network models, such as AlphaFold2 and ColabFold, this study achieved near-experimental accuracy in protein structure prediction. It successfully predicted a crucial conformational change in UMOD without training on the polymer structure. By simulating propeptide dissociation due to proteolysis, this research highlights the potential of ML in clarifying complex molecular events and provides insights into egg coat protein assembly and ZP module-containing molecules. Casadio et al. [2] reviewed ML solutions for predicting PPIs, highlighting the role of proteins as “social molecules”. Recent studies have shown that large protein aggregates, or biomolecular condensates, play significant roles in various biological processes. These condensates can be either permanent or time-dependent and are influenced by cellular needs. However, monitoring protein aggregate formation poses challenges, both experimentally and theoretically, especially in predicting functional aggregates. The current research includes mesoscopic networks at the proteome level, protein-binding affinities, and atomic-resolution complexes. While ML algorithms can derive insights from data, they need rigorous benchmarking on blind datasets for validation. Even advanced ML methods, such as DP, require further training on the full range of PPIs. Although PPIs are crucial for processes such as transcription and protein biosynthesis, the transient complexes that form condensates are less understood. A key question is how to differentiate functional PPIs from non-specific aggregates. Our understanding relies on atomic-level complex data from the Protein Data Bank (PDB) and broader analyses of protein complex formation. The role of ML in PPI challenges, available data resources, and predicting PPI networks, 3D aggregates, and PPI sites on structures and sequences are also discussed. Figure 5 provides a schematic representation of the ML techniques employed for predicting PPI sites, utilizing both structural and sequence-based information. Cui et al. [64] reviewed protein–DNA/RNA interactions, focusing on the evolution of computational methods in proteomics from traditional ML to DL, driven by advancements in AI and big data. This review discusses the tools for predicting interactions, their advantages, shortcomings, and applications, along with biological sequence-digitizing strategies and data representation challenges. The authors suggest that future research could integrate various AI approaches, including DL, reinforcement learning, and evolutionary methods. Figure 6 illustrates the advancements in ML algorithms used for analyzing interactions between DNA/RNA and proteins.

Hong et al. [74] introduced PhosPPI, a sequence-based ML approach for predicting the impact of phosphorylation on PPIs. Phosphorylation is vital for cell signaling and can contribute to diseases such as cancer and Alzheimer’s disease. PhosPPI addresses the challenge of experimentally determining these effects and outperforms existing methods, such as Betts, HawkDock, and FoldX, in accuracy. It functions without the need for protein 3D structures, making it more accessible. With strong validation performance, PhosPPI is a valuable tool for biologists and bioinformaticians in studying the role of phosphorylation in PPIs and drug development.

Lee [77] reviews recent advances in DL for PPI analysis, highlighting its transformative role in computational biology. The review covers the literature from the period 2021–2023 and highlights innovative methodologies that are essential for understanding biological systems and therapeutic opportunities. These findings underscore the need for ongoing adaptation in DL applications, providing key insights into how these techniques are transforming PPI predictions and advancing biological research and therapeutic strategies. Ye et al. [75] reviewed advances in ML for predicting peptide/protein–protein interactions (PepPIs/PPIs) via sequence data, emphasizing their role in drug discovery. This paper discusses high-throughput technologies, ML methods for lead peptide discovery, and various databases of peptide ligands and target proteins. It categorizes classical ML and DL approaches, evaluates their advantages and disadvantages, and covers validation protocols and performance metrics. This review highlights the importance of PPIs in biological processes and the need for computational models to enhance predictions, given the limitations of laboratory methods. This study concludes with insights into challenges and future directions to improve bioactive peptide and protein discovery for drug development.

Sousa et al. [76] studied PPIs via a knowledge-graph-based method called KGsim2vec, which generates explainable vector representations by leveraging aspect-oriented semantic similarity. While AI and ML are increasingly applied in biomedical fields, ensuring explainability is essential for scientific discovery. Their approach improves upon typical knowledge graph embeddings by enhancing explainability and predictive performance with ML models, such as decision trees and random forests. They also addressed challenges in knowledge graph representations and introduced an innovative method for evaluating explanation quality, achieving significant results in the prediction of PPIs. Su et al. [19] investigated PP binding interfaces via AI, revealing high similarity among these interfaces in various complexes. They decomposed binding interfaces into interacting fragment pairs and applied a generative model to encode them in a low-dimensional latent space. After training, they generated new fragment conformations, aiding in the assembly of native protein complexes. These findings indicated that the conformational space of these pairs is highly degenerate and can be effectively characterized by AI. By developing a generative autoencoder and clustering samples with a self-organizing map (SOM), they reported that most generated pairs resembled native-like structures, suggesting the potential for predicting unknown PPIs.

## Section: 3. Machine-Learning Training Models and Databases in the Field of Protein Interactions, Drug Discovery, and Bioinformatics

A variety of ML models are employed to predict interactions in GPCR drug discovery, including random forests (RFs), neural networks (NNs), support vector machines (SVMs), and extreme gradient boosting (XGBoost). Table 4 compares these models, highlighting their respective advantages and limitations. Each model has distinct strengths and weaknesses, making them suitable for different problems and datasets. The selection of an appropriate model is contingent upon the specific requirements of the task, such as the size and nature of the dataset, the complexity of the relationships within the data, the need for interpretability, and the computational resources at hand [2,6,10,64,66,67,73,75,77]. On the other hand, hybrid models in ML integrate various algorithms to leverage their unique strengths while minimizing their individual weaknesses, leading to enhanced prediction accuracy and robustness. For instance, combining RF with NN creates a powerful framework that excels in complex prediction tasks. This hybrid approach benefits from the interpretability and stability of RFs alongside the advanced pattern recognition capabilities of NNs. In a typical hybrid model, RFs can be used for feature selection and preprocessing, effectively identifying the most relevant inputs. NNs, on the other hand, excel at extracting high-level features from raw data, allowing the model to learn intricate patterns that might otherwise be overlooked. This two-step process not only takes advantage of deep feature extraction but also enhances the decision making of RFs, leading to improved generalization of unseen data. Moreover, combining different models helps mitigate overfitting, as the ensemble nature of RFs can smooth out the predictions made by NNs, which might overfit training data. Hybrid approaches can significantly reduce the overall error rate by addressing the different error types often produced by individual models. For example, if an NN makes systematic errors in certain areas, an RF may correct those errors, ensuring a more robust prediction. These hybrid strategies are particularly valuable in domains requiring high precision and reliability, such as drug discovery and bioinformatics. By effectively managing complex datasets and minimizing prediction errors, hybrid models provide a solid solution for tackling challenging tasks, resulting in more accurate and trustworthy predictions [2,6,10,64,66,67,73,75,77].

Numerous databases are available for research in AI and ML applications specifically focused on PPIs, peptide–protein interactions (PepPI), and GPCR drug discovery. Some key databases and their applications are shown in Table 5. Understanding the available databases and their applications is essential for researchers engaged in these fields. Utilizing these databases is crucial for acquiring high-quality data, extracting relevant features, and validating predictive models. These databases serve as invaluable resources, supplying the data needed to train and validate ML models and enabling the extraction of pertinent features. They support various aspects of drug discovery, including virtual screening, de novo drug design, and drug repurposing. A thorough understanding of these databases can significantly enhance the efficiency and accuracy of research efforts in this domain. By comprehending the applications of these databases, researchers can develop more precise and robust ML models, thereby advancing our understanding of PPIs. These resources are fundamental for training, validating, and benchmarking ML models, ultimately facilitating the discovery of new interactions and therapeutic targets [2,6,10,62,73,75,77].

## Section: 4. Opportunities, Limitations, and Challenges in the Application of AI and ML Techniques for Characterizing Protein Corona, Nanobio Interactions, Nanomedicines and Drug Discovery, and Protein–Protein Interactions

The opportunities, limitations, and challenges are outlined and discussed in Table 6. They are categorized under the following headings: nanotoxicology and nanomaterial research, protein corona prediction, nanomedicine and drug discovery, protein function prediction, nanobio interactions and nanoinformatics, environmental risk assessment, drug discovery and development, PPIs, explainable AI, and DL for PPI analysis.

The document outlines opportunities for advancing protein function prediction via ML and AI. This highlights the importance of understanding protein–NM interactions, with a focus on protein corona prediction and applications in nanomedicine. The key areas for enhancement include refining ML algorithms for accurate predictions of nanomaterial–cell interactions, utilizing interpretable ML for decision-making processes in protein corona prediction, and developing safer nanoparticles for biosensing and organ targeting. Additionally, it suggests the need to create large LLMPs, leverage high-throughput methods to generate extensive datasets for ML model development, and incorporate AI in exposure assessment and risk characterization. The document also emphasizes the need to integrate omics data to understand disease mechanisms, improve drug discovery processes, and enhance the methods for studying PPIs while ensuring explainability and scalability in AI models. By addressing these opportunities, researchers can advance the understanding and application of nanotechnology, protein interactions, and AI in various fields. Advanced computational tools and physicochemical analyses can enhance the safety assessment of NMs. ML can significantly improve protein function prediction and the understanding of protein coronas. The aromaphilicity index offers a tool for predicting protein–NM interactions. Additionally, ML can revolutionize nanotheranostics, leading to better patient outcomes through improved diagnostic and therapeutic strategies. Overall, these advancements aim to enhance nanobio interactions, improving the efficacy and clinical translation of nanomedicines across biomedicine, environmental science, and consumer products.

The document highlights several challenges and limitations in nanotoxicology and NM research, protein corona prediction, nanomedicine and drug discovery. In nanotoxicology, the complex interactions between NMs and biological systems hinder accurate predictions of behavior and toxicity, compounded by inherent heterogeneity, variability in biological responses, and a lack of understanding of chronic exposure effects. For protein corona prediction, modeling individual proteins limits generalization, whereas complex neural networks may overfit and lack feature fusion during training. In nanomedicine and drug discovery, the challenges include the need for large, high-quality datasets for training ML models, inconsistent reporting metrics, and time-consuming manual data curation. Overfitting of ML models is common due to the complexity of nanomaterials. For protein function prediction, difficulties arise from integrating diverse data modalities, utilizing evolutionary information, and maintaining model scalability, alongside the challenge of curating high-quality datasets. For nanobio interactions and nanoinformatics, comprehending the intricate interactions between NPs and biological systems is hindered by non-systematic studies and a lack of reliable datasets. The transformation of NPs in biological environments adds further complexity. In environmental risk assessment, high-quality data are often incomplete, and ML models can reflect biases and errors from their training data. Their complexity and “black box” nature challenge interpretability and reproducibility, which affects drug discovery and regulatory approval. For PPIs, accurately representing complex protein sequences is challenging. ML models may generate false positives, but the dynamic nature of PPIs complicates analysis. Explainable AI faces obstacles due to the complexity of data in the biomedical domain, and knowledge graphs often lack specific interpretations. While promising, DL models struggle with data harmonization and structural predictions of protein complexes. Addressing these challenges can increase the accuracy and applicability of ML and AI in scientific and medical fields.

## Section: 5. Conclusions

In this review, recent advancements in ML and DL methodologies employed to elucidate protein corona characterization, nanobio interactions, nanomedicine development, drug discovery processes, and PPIs are reviewed. The advantages and limitations inherent in these approaches, their diverse applications across various fields, and prospective future trends that may emerge in this rapidly evolving domain are critically examined. The documents highlight advancements in the use of AI to model and predict PPIs, presenting a promising tool for the field of computational biology. The results underscore the importance of ML in understanding how proteins assemble and suggest potential future applications in the exploration of other complex biological systems. Additionally, they emphasize the transformative impact and potential of AI and ML in drug discovery and development while also acknowledging ongoing challenges and the need for continued progress in this area. These findings provide a comprehensive overview of the challenges and strategies for improving NP delivery in nanomedicine, highlighting the importance of both NP design and biological modulation. This information serves as a valuable resource for researchers, helping them to navigate the latest advancements and methodologies in this rapidly evolving field.

Several key conclusions across various fields involving ML and AI are as follows:Nanotoxicology and nanomaterial research: ML algorithms can effectively predict cell and nuclear shapes and polarity functions as phenotypic markers for diverse categories of NMs, aiding in understanding NM interactions with biological systems. Establishing standardized protocols and interdisciplinary collaboration is crucial for advancing nanotoxicology research.Protein corona prediction: ML models can predict the RPA of multiple proteins on the protein corona, reducing the need for traditional experimental techniques. The key attributes associated with RPA analysis have been identified, providing insights for protein corona design. Future improvements should focus on integrating more comprehensive datasets and advanced ML techniques.Nanomedicine and drug discovery: ML and AI significantly enhance the design and application of NPs in nanomedicine, biosensing, and organ targeting. Combining data from various omics fields can provide a comprehensive understanding of NM interactions. Real-world validation of ML models is essential to ensure their accuracy and reliability in practical applications.Protein function prediction: DL methods have improved protein function prediction, but challenges remain in integrating multiple data modalities and predicting rare or novel functions. Collaboration among the ML, AI, and bioinformatics fields is necessary to develop cutting-edge techniques for predicting protein functions.Nanobio interactions and nanoinformatics: Systematic exploration of the physicochemical properties of NPs and their interactions with biological systems is needed. High-throughput synthesis and testing methods, combined with advanced computational models, can accelerate the comprehension of nanobio interactions. Effective data management and sharing protocols are essential for handling large datasets.Environmental risk assessment: ML can enhance ERA by improving data gathering, exposure assessment, hazard identification, and risk characterization. The development of comprehensive strategies and standard controls for ML in the ERA is crucial for ensuring accuracy and reliability.Drug discovery and development: AI has the potential to greatly reduce both the time and expenses associated with drug discovery by automating and optimizing various stages of the process. AI-driven predictive modeling and simulation can enable virtual testing of drug candidates, accelerating the drug development process. Ethical and regulatory frameworks are needed to promote the ethical application of AI in drug discovery.Protein–protein interactions: ML models can predict PPIs with increased accuracy by integrating multiple data sources and leveraging advanced computational techniques. Moving beyond interaction prediction to understand the functional and contextual relevance of PPIs is a significant advancement. Combining sequence features, docking scoring functions, and protein binding site predictions can increase the accuracy of AI models.Explainable AI: Explainability is crucial for the adoption of ML as a scientific tool, ensuring reliability and interpretability. Ontologies and knowledge graphs can improve the interpretability of ML applications in the biomedical domain. The development of scalable methods to handle large datasets and complex knowledge graphs efficiently is essential.Deep learning for PPI analysis: DL presents a transformative platform for predicting PPIs, significantly advancing our understanding of protein interactions and biological systems. Addressing challenges such as data quality, model interpretability, and the integration of diverse data sources is crucial for further advancements. The application of DL models to interdisciplinary domains, such as drug discovery and personalized medicine, holds significant potential.

Overall, the document emphasizes the transformative potential of ML and AI in various scientific and medical fields while also acknowledging the ongoing challenges and the need for continued progress and collaboration.

## Section: 6. Future Perspectives

The document presents various future directions for advancing the field of nanotoxicology nanomaterial research, protein function prediction, nanomedicine, drug discovery, and PPIs via ML and AI:Nanotoxicology and nanomaterial research: Enhance ML algorithms for better prediction of NM–cell interactions; include diverse cell types and models to study NM effects; standardize the protocols for reporting NM interactions with biological systems; address the need for standardized nanodescriptors in ML models to accurately predict the behavior of NPs; and foster collaboration among material scientists, biologists, toxicologists, and computational experts.Protein corona prediction: Enhance feature representation by extracting additional protein-related features; create generalized models using comprehensive datasets and advanced ML techniques; investigate advanced neural network architectures to prevent overfitting and increase performance; build integrated models for efficient classification and regression; and prioritize interpretable ML methods for better decision-making transparency.Nanomedicine and drug discovery: Combine data from genomics, proteomics, and metabolomics for a comprehensive understanding of NM interactions; optimize computational models such as PCRO-RLRM for enhanced predictive performance; develop advanced DL and AI techniques to integrate diverse input data; use evolutionary data from protein sequences to enhance function prediction; create next-generation LLMPs tailored for multimodal data and function prediction; and foster collaboration among ML, AI, and bioinformatics for innovative protein function prediction methods.Nanobio interactions and nanoinformatics: Explore the physicochemical properties of NPs and their biological interactions; use combinatorial chemistry and high-throughput methods to create diverse datasets; develop computational models to predict NP biological effects; accelerate data generation on nanobio interactions through high-throughput synthesis and testing; and enhance data management and sharing for the effective handling of large datasets.Environmental risk assessment: Develop strategies to implement ML in ERA, focusing on data foundations and methodologies; standardize and validate ML models for accuracy and reliability; integrate ML with the IoT for real-time environmental monitoring; and target complex data areas, such as spatial–temporal analysis and omics.Drug discovery and development: AI will increase the efficiency and accuracy of drug design, leading to the discovery of new therapeutic compounds; it will aid in customized healthcare through the examination of individual patient data for tailored treatments; AI will integrate omics data for a thorough comprehension of disease mechanisms and drug responses; AI-driven predictive modeling and simulations will allow virtual testing of drug candidates, reducing the need for extensive experiments; clinical trials will be optimized through better patient selection, outcome prediction, and real-time monitoring; AI will facilitate drug repurposing by finding new uses for existing medications; quantum computing will significantly advance AI’s role in drug discovery; and it is essential to develop ethical and regulatory frameworks for responsible AI use in this field.Protein–protein interactions: Develop ML algorithms, including DL, to improve PPI prediction accuracy; integrate atomic resolution structures with proteome-wide interaction networks for comprehensive predictions; increase the representation of protein sequences and structures for ML models; improve the computational efficiency of ML models for broader access to advanced techniques; and focus on the functional and contextual relevance of PPIs in various cellular environments.Explainable AI: Developing scalable methods for large datasets and complex knowledge graphs; improving feature extraction and selection from diverse data sources; enhancing model transparency via attention mechanisms and saliency maps; and applying DL models in drug discovery, personalized medicine, and environmental genomics.Deep learning for PPI analysis: Refine fold-and-dock algorithms for better protein pair structure predictions; integrate sequence features, docking scores, and protein binding site predictions into AI models; use advanced computing resources for training AI on larger datasets; and apply AI models in drug discovery to identify targets and design therapies.General future directions: Create centralized databases for data sharing and collaboration; implement real-time monitoring of nanomedicine performance; focus on developing safe, sustainable nanomaterials; conduct in vivo studies to understand protein corona dynamics; use AI and ML to analyze nanobio interaction data; and develop in silico models to predict nanobio interactions.

Addressing future perspectives in ML and AI can significantly enhance their application in scientific and medical fields, particularly in drug discovery and development. Continued progress in AI, along with ethical considerations and collaboration, promises to transform the pharmaceutical industry and improve global health outcomes. The key future directions for ML include strategies for standardizing models, addressing data biases, integrating with the IoT, and fostering interdisciplinary collaboration. These efforts will advance nanomedicine and lead to more personalized treatments. There is also great potential for innovations in nanotheranostics, improving disease diagnosis, imaging, and therapy. Additionally, focusing on the aromaphilicity index and protein corona prediction can enhance our understanding of nanotechnology in the biological and medical sciences. In nanotoxicology, these advancements aim for safer NM applications. Overall, prioritizing multimodal integration and community collaboration is crucial for enhancing protein function prediction and advancing the field of nanomedicine.


---

# Leveraging FDA Labeling Documents and Large Language Model to Enhance Annotation, Profiling, and Classification of Drug Adverse Events with AskFDALabel

- **Authors:** Leihong Wu, Hong Fang, Yanyan Qu, Joshua Xu, Weida Tong
- **Issuer:** Drug safety
- **Type:** Scientific article
- **Published:** 2025-02-20
- **Language:** en
- **DOI:** 10.1007/s40264-025-01520-1
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39979771/
- **Licence:** CC-BY

## Section: Abstract

BackgroundDrug adverse events (AEs) represent a significant public health concern. US Food and Drug Administration (FDA) drug labeling documents are an essential resource for studying drug safety such as assessing a drug’s likelihood to cause certain organ toxicities; however, the manual extraction of AEs is labor-intensive, requires specialized expertise, and is challenging to maintain, due to frequent updates of the labeling documents.ObjectiveTo automate the extraction of AE data from FDA drug labeling documents, we developed a workflow based on AskFDALabel, a large language model (LLM)-powered framework, and its demonstration in drug safety studies.MethodsThis framework incorporates a retrieval-augmented generation (RAG) component based on FDALabel to enhance standard LLM inference. Key steps include (1) selection of a task-specific template, (2) FDALabel database querying, and (3) content preparation for LLM processing. We evaluated the performance of the framework in three benchmark experiments, including drug-induced liver injury (DILI) classification, drug-induced cardiotoxicity (DICT) classification, and AE term recognition.ResultsAskFDALabel achieved F1-scores of 0.978 for DILI, 0.931 for DICT, and 0.911 for AE annotation, outperforming other traditional methods. It also provided cited labeling content and detailed explanations, facilitating manual verification.ConclusionAskFDALabel exhibited high consistency with human AE annotation, particularly in classifying and profiling DILI and DICT. Thus, it can significantly enhance the efficiency and accuracy of AE annotation, with promising potential for advanced AE surveillance and drug safety research.Supplementary InformationThe online version contains supplementary material available at 10.1007/s40264-025-01520-1.

## Section: Key Points

AskFDALabel incorporates term-of-interest (TOI) recognition and retrieval-augmented generation (RAG) for an enhanced drug adverse event (AE) annotation.AE extraction through automation with AskFDALabel is highly consistent with the results from the manual curation by experts.Both drug-induced liver injury and drug-induced cardiotoxicity classification with AskFDALabel achieved a high F1-score above 90%.

## Section: Introduction

Drug adverse events (AEs) are a major cause of death in the United States (US) [1]. Data from the US Food and Drug Administration (FDA) Adverse Events Reporting System (FAERS) reveal that the number of annual AE reported cases associated with “death” has surpassed 70,000 since 2020 [2]. Identifying, profiling, classifying, and monitoring AEs from various drug safety documents, such as drug labeling documents, individual case safety reports (ICSRs), literature, and other data sources, are at the center of current AE research, and are also critical for drug safety review in many regulatory agencies, including the FDA.

FDA drug labeling documents serve as authoritative resources for AE research. These documents, submitted by manufacturer and then approved by the FDA, contain important drug safety information in sections such as “Boxed Warnings,” “Warnings and Precautions,” and “Adverse Reactions.” Due to their comprehensiveness and reliability, these documents are the primary source for researchers and healthcare professionals as a key reference for understanding drugs’ safety profiles [3]. Recently, the FDA National Center for Toxicological Research (NCTR) developed FDALabel [4], a tool widely recognized within and outside the FDA, enabling users to efficiently access and query over 150,000 drug labeling documents.

Over the past decades, FDA drug labeling documents have been used extensively in AE studies. For example, the Side Effect Resource (SIDER) has curated AEs for 1430 marketed medicines, with most sourced from FDA drug labeling documents [5]. Wu et al. systematically analyzed and compared the AE profiles of 1164 drugs by mapping their labeling documents to Medical Dictionary for Regulatory Activities (MedDRA) [6]. Roberts et al. developed a benchmark for AE detection by manually annotating 200 drug labeling documents, which was used for the Adverse Reaction Extraction Challenge at the 2017 Text Analysis Conference (TAC) [7]. Similarly, Bayer et al. manually annotated another 200 drug labeling documents, by focusing on detecting AE terms particularly relevant to FDA reviewers [8].

Additionally, FDA drug labeling documents have been widely used in drug toxicity classification and annotation. For example, during the past two decades, the research team at the NCTR has produced several drug-induced toxicity benchmark datasets by manually reading and analyzing drug labeling documents, such as those for drug-induced liver injury (DILI) [9–11], drug-induced cardiotoxicity (DICT) [12], drug-induced renal injury list (DIRIL) [13], and others, which offer large collections of manually curated drug toxicity annotations. These datasets have spurred numerous artificial intelligence (AI)/machine learning initiatives on drug toxicity prediction [14–18].

Labeling-based AE annotation and profiling by human experts poses three main challenges. First, it typically requires a labor-intensive, time-consuming manual process of extracting and annotating AE data. Frequent updates to labeling documents necessitate regular repetition of this process, making the maintenance of up-to-date AE monitoring an expensive, if not impossible, process. Second, to reduce the cost of this process, some studies applied standardized terminologies like MedDRA for AE extraction, but this often led to missing some critical AEs, as the FDA does not mandate the use of MedDRA terminology in labeling [6, 19]. Last, the manual AE extraction from the labeling documents is expertise-dependent, which could lead to varying results among experts.

Recent advancements in large language models (LLMs) have offered a transformative opportunity to modernize labeling-based AE research. LLMs have the potential to automate and streamline AE term extraction, profiling, and classification. These models can now analyze vast amounts of textual data with high consistency and accuracy, reducing the burden of manual curation and minimizing variation among human experts.

With concerns for security, regulatory agencies such as the FDA have primarily been employing LLMs locally to analyze data. We developed AskFDALabel (version 1) [20], a framework to employ open-source LLMs in a secure environment with a retrieval-augmented generation (RAG) mechanism to enhance the efficiency and effectiveness of drug labeling document analysis for reviewers and research scientists. In the first version, we explored the potential to use locally hosted models (e.g., Llama [21] and Falcon [22]) with RAG to provide more relevant and accurate responses from FDA labeling documents [20]. Additionally, we fine-tuned the employed LLMs using low-rank adaptation (LoRA) and Alpaca strategy [23], which involved automatically generating training content through a larger LLM, such as GPT-3.5.

In this paper, we further improved AskFDALabel as a tool to interface with FDA labeling documents in a study of drug safety. Particularly, we introduced new features in the current AskFDALabel framework (version 2), such as the term-of-interest (TOI) recognition, a database-enhanced RAG process, and special templates. We then outlined the results obtained from three experiments: (1) DILI classification, (2) DICT classification, and (3) drug AE profiling, and evaluate their performance by comparing existing methods, including manual review.

## Section: Material and Method

An example of drug AE profiling contents for raxibacumab generated by AskFDALabel. We matched the generated AE profile with human annotation (ground truth) in two ways: (1) hash tags (##) indicated human-annotated AEs were matched exactly in the AE profiling; (2) dollar tags ($$) indicated human-annotated AEs were matched semantically based on LLM determination. AE adverse event, FDA Food and Drug Administration, LLM large language model

## Section: Material and Method › Datasets › Drug-Induced Liver Injury (DILI) Dataset

We used 287 DILI annotated drugs, retrieved from the original DILI class publication [9]. Among them, 76 drugs were currently labeled as “withdraw” or “discontinued.” Since their drug labeling documents were not searchable in the FDALabel database, they were excluded for this analysis. For the remaining 211 available drugs, we further combined the classifications “most” and “less” DILI concern as DILI positive, where “no” DILI concern is considered as DILI negative. This resulted in 154 DILI-positive and 57 DILI-negative drugs.

## Section: Material and Method › Datasets › Drug-Induced Cardiotoxicity (DICT) Dataset

For DICT analysis, we processed 1184 drugs labeled with DICT concern levels—i.e., most, less, or no DICT concern—from a previous publication [12]. We successfully found and processed the labeling for 1167 of these drugs. As with the DILI classification analysis, we combined the most and less DICT concern groups into a DICT-positive category. This resulted in 829 DICT-positive and 338 DICT-negative drugs.

## Section: Material and Method › Datasets › Drug Adverse Event (AE) Profiling

To evaluate the performance of the generated AE profile from labeling documents, we processed 200 drugs with AE profiles that had been manually annotated by human in the TAC 2017 challenge [24]. In detail, over 26,000 adverse reaction terms (~13,000 unique terms) were manually annotated by human reviewers in TAC, which is around 70 AEs per labeling document. The whole effort took years to complete, with a group of reviewers from the FDA and National Institutes of Health (NIH) [7]. We conducted the analyses based on both section level (which included 476 labeling sections in total) and the whole drug document level (200 drug labels). For the section level analysis, we used the original labeling content provided by the dataset; for the whole drug document level analysis, we only used the drug name, and the most recent labeling document was automatically retrieved by AskFDALabel during the study.

## Section: Material and Method › Term-of-Interest (TOI) Recognition

We implemented a new TOI recognition feature in the AskFDALabel framework by utilizing an LLM. In a previous study, we designed a simple hard-coded approach to let the user manually annotate the key attribute terms inside the query. For example, instead of the query “What are the adverse events reported for abacavir?”, the user can substitute “What are the adverse events reported for abacavir?” Although such an approach will increase users’ preparation time to input their queries, it can largely improve the accuracy and relevance of the RAG process.

In addition to the hard-coded approach, we also used an LLM-based TOI recognition approach to identify and extract key attribute terms. In contrast to regular named entity recognition (NER) approaches to train a model based on a tagging annotator, the LLM-based approach tried to directly recognize TOIs in a generative style. For example, using the input query “What are the adverse events reported for abacavir?”, the LLM is expected to respond “[Drug-Name] Abacavir” with appropriate prompts. The LLM-based NER prompt used in this step is provided in the electronic supplementary material (Online resource 1).

## Section: Material and Method › Retrieval Augmented Generation (RAG) Process

Most, if not all, RAG technologies are based on the idea of semantic similarity or relevance to the input query to fetch relevant information from a large corpus of text. In general, the reference texts will be segmented into smaller text chunks, where vectorization will be performed to digitalize the text into a one-dimensional, numerical vector. Word embedding approaches such as Global Vectors for Word Representation (GloVe), Sentence–Bidirectional Encoder Representations from Transformers (SBERT), and Doc2Vec are applied in this transformation process [25–27].

In this study, we developed a hybrid information retrieval process, named FDALabel-based RAG, by combining an LLM with a regular database search in the RAG process. This approach has the advantages of regular database searching; by using an appropriate database query, the user will not risk a hallucination in the results. In contrast, an LLM model auto-detects keywords mentioned in the user input and then converts it into the database-search query.

For example, in DILI classification, after the user query identifies the drug of interest, a database query will be generated to retrieve labeling documents that meet certain criteria consistent with the guidance during manual reading. Particularly, the drug must be a human prescription drug (preferred) or over-the-counter (OTC) drug. Single-ingredient drugs are preferred over combined drugs in the query. In addition, we used the most recently revised labeling data. For DILI classification, three labeling sections were considered in the RAG process: “Boxed Warnings,” “Warnings and Precautions,” and “Adverse Reactions.”

After the labeling content was retrieved, the next step was to use the LLM to find DILI keywords from the selected labeling sections. The prompt used in this step is provided in Online resource 1 (see the electronic supplementary material). As a result, the model would return any DILI keywords found in these labeling sections.

Finally, we used the exact criteria for DILI classification mentioned in a previous publication [9] to judge the DILI based on the LLM output.

## Section: Material and Method › Special Templates

Special templates are a novel design in the AskFDALabel framework to enable better handling of distinct user requests in one platform. For example, a query such as “What are the adverse events of abacavir?” relies on a single labeling document; whereas another such as “What are the newly added/reported adverse events of tamoxifen in the past five years?” will require information from multiple labeling documents. To cope with common user requests, we implemented several task-specific templates and designed an LLM-enabled module to automatically determine which special template is the best fit for a given query.

In this study, we used the locally hosted model Llama 3.1-70B to determine whether special templates would be used for the given query, and which one(s). We designed a special template for each experiment: (1) for DILI classification, the template was designed to automate the classification scheme to assess DILI [9] based on the labeling description; (2) for DICT classification, the template was designed to classify DICT [12] based on the labeling description; and (3) for drug AE profiling, the template was designed to generate an AE profile of a given drug summarizing all AEs mentioned in its most recent labeling documents. A typical question that fits into the first template is “What are the adverse events reported for abacavir?” The detailed prompts used to determine the appropriate template to use and prompts for these three templates are provided in Online resource 1 (see the electronic supplementary material).

When a special template was selected, the RAG process used different criteria to get the labeling document and return the information required by each template. In DILI classification, it returned “Boxed Warnings,” “Warnings and Precautions,” and “Adverse Reactions” sections since only these three sections are used in DILI classification. For DICT classification, the above three sections plus the “Overdosage” section were considered, due to the different guidance provided by human scientists in previous publications [12]. For AE analysis, the entire labeling document was used in the RAG process.

## Section: Material and Method › The LLM Core of AskFDALabel

In the most recent AskFDALabel framework, we used Llama 3.1-70B [28], the latest released Llama model at the time, as the LLM core for AskFDALabel. It had two major advantages: (1) The Llama3.1 series supported up to 128,000 input tokens, which enabled us to fit the entire labeling document into the input prompt. The previous Llama model used in AskFDALabel supports only 4000 tokens, which forced the segmentation of the labeling document into multiple text chunks. (2) The 70B model proved to be a significant improvement overall in comparison to the previously tested 8B and 13B models.

All the LLM experiments ran on a graphics processing unit (GPU) server with eight H100 80 Gb GPUs. Four of the eight GPUs were utilized for this study to handle the Llama 3.1-70B model. The model was loaded in fp16 format using vLLM [29].

## Section: Material and Method › Exact and Semantic-Based Matching to Evaluate AE Profiling

To better evaluate the performance of drug AE profiling, we introduced two matching algorithms—exact and semantic-based matching. The exact match only counts the ground truth term that appears exactly in the AskFDALabel response. On the other hand, semantic-based matching will also consider terms that have semantically similar terms in the AskFDALabel response. To implement semantic-based matching, an LLM-based approach was applied to define semantically similar terms between the LLM result and the ground truth (i.e., human reviewer annotations). For an example, see Fig. 1, which illustrates the drug AE profiling contents for raxibacumab generated by AskFDALabel. The hash tags (##) indicate exactly matched terms, and the dollar tags ($$) indicate semantically matched terms. For instance, the exact term “infusion-related reaction” is not found in the generated drug AE profile; however, the profile contains “injection site reaction,” a semantically similar term. Therefore, “infusion-related reaction” will be considered as a semantically matched term, but not as an exactly matched term. The detailed prompts used for semantic matching are provided in Online resource 1 (see the electronic supplementary material).Fig. 1An example of drug AE profiling contents for raxibacumab generated by AskFDALabel. We matched the generated AE profile with human annotation (ground truth) in two ways: (1) hash tags (##) indicated human-annotated AEs were matched exactly in the AE profiling; (2) dollar tags ($$) indicated human-annotated AEs were matched semantically based on LLM determination. AE adverse event, FDA Food and Drug Administration, LLM large language model

An example of drug AE profiling contents for raxibacumab generated by AskFDALabel. We matched the generated AE profile with human annotation (ground truth) in two ways: (1) hash tags (##) indicated human-annotated AEs were matched exactly in the AE profiling; (2) dollar tags ($$) indicated human-annotated AEs were matched semantically based on LLM determination. AE adverse event, FDA Food and Drug Administration, LLM large language model

## Section: Result

The AskFDALabel framework for drug AE analysis. This framework introduces a structured, end-to-end pipeline that processes user queries through a series of specialized steps, rather than directly using an LLM. Upon receiving a user query, the framework determines the appropriate template to apply based on the query type. For example, in a DILI classification task (first template in figure), the framework identifies and extracts the drug name, retrieves the most recent labeling document from the FDALabel database, and extracts AE sections, such as “Boxed Warnings,” “Warnings and Precautions,” and “Adverse Reactions.” The LLM then identifies DILI-related keywords from these sections. A post-processing step evaluates the extracted keywords to assess whether the drug poses a DILI risk. The pipeline’s output is then provided to the user. AE adverse event, DILI drug-induced liver injury, FDA Food and Drug Administration, LLM large language model, TOI term-of-interest

Statistical summary of DILI and DICT classification result

Performance on TAC 2017 dataset and drug AE profiling

## Section: Result › AskFDALabel Framework

The overall framework of AskFDALabel is shown in Fig. 2. This framework integrated a RAG component based on FDALabel, enhancing the capabilities of a regular LLM inference pipeline. Key steps in this RAG-based enhancement included (1) template selection, (2) FDALabel database query, and (3) content preparation for LLM inference.Fig. 2The AskFDALabel framework for drug AE analysis. This framework introduces a structured, end-to-end pipeline that processes user queries through a series of specialized steps, rather than directly using an LLM. Upon receiving a user query, the framework determines the appropriate template to apply based on the query type. For example, in a DILI classification task (first template in figure), the framework identifies and extracts the drug name, retrieves the most recent labeling document from the FDALabel database, and extracts AE sections, such as “Boxed Warnings,” “Warnings and Precautions,” and “Adverse Reactions.” The LLM then identifies DILI-related keywords from these sections. A post-processing step evaluates the extracted keywords to assess whether the drug poses a DILI risk. The pipeline’s output is then provided to the user. AE adverse event, DILI drug-induced liver injury, FDA Food and Drug Administration, LLM large language model, TOI term-of-interest

We began the process by identifying the nature of the user query through template selection, which involved determining the focus of the inquiry, (e.g., drug name, AEs, or other entities). Next, we employed a specialized LLM-based inference to select the appropriate processing template. Based on the chosen template, we executed a query on the FDALabel database to retrieve relevant information. Depending on the template requirements, this involved retrieving sections, such as AEs, from a single labeling document, or gathering data from multiple documents. Retrieved information was then organized into a prompt format that the LLM could interpret. If multiple references were gathered, the initial user query (e.g., “What are the adverse events reported for abacavir?”) could be split into sub-queries (e.g., “What adverse events are reported in the Boxed Warnings section for abacavir?”). These sub-queries were processed by the LLM individually, and a final response was compiled from all sub-query outputs.

This integrated framework leveraged FDALabel data to improve the relevance and specificity of responses to user queries, enhancing the standard LLM inference pipeline for applications in AE research and classification tasks such as DILI classification.

The AskFDALabel framework for drug AE analysis. This framework introduces a structured, end-to-end pipeline that processes user queries through a series of specialized steps, rather than directly using an LLM. Upon receiving a user query, the framework determines the appropriate template to apply based on the query type. For example, in a DILI classification task (first template in figure), the framework identifies and extracts the drug name, retrieves the most recent labeling document from the FDALabel database, and extracts AE sections, such as “Boxed Warnings,” “Warnings and Precautions,” and “Adverse Reactions.” The LLM then identifies DILI-related keywords from these sections. A post-processing step evaluates the extracted keywords to assess whether the drug poses a DILI risk. The pipeline’s output is then provided to the user. AE adverse event, DILI drug-induced liver injury, FDA Food and Drug Administration, LLM large language model, TOI term-of-interest

## Section: Result › Large Language Model (LLM)-Based TOI Recognition

LLM-based TOI recognition was implemented in the updated version of FDALabel. To evaluate its performance to identify TOI such as drug names, we evaluated its performance in recognizing a drug name from 2141 unique drug trade names from FDALabel that satisfied the following criteria: (1) human prescription, (2) New Drug Application (NDA), (3) remove Repacker and Relabeler, and (4) Reference Listed Drug (RLD). Additionally, we manually validated the result to make sure the synonyms were also considered as correct. For example, drugs Atelvia and Actonel were identified as “risedronate sodium,” the generic name of these drugs. As a result, 2037 drugs (95.14%) were successfully identified by the LLM search, of which 1848 drug names were exactly used in the database query, and the remaining 189 drugs were identified using a semantically similar name, such as using “risedronate sodium” instead of “Atelvia.” With that said, LLM-based TOI recognition can accurately identify and recognize drug names from the free-text style of user inputs. Therefore, we decided to use the LLM-based TOI recognition in the AskFDALabel framework.

## Section: Result › DILI Classification

AskFDALabel was applied to 211 DILI annotated drugs. As the results show, 153 of 154 DILI-positive drugs (99.4%) and 44 of 57 DILI-negative drugs (77.2%) were labeled consistently between the manual curation and our AskFDALabel output. This result outperformed previous Bidirectional Encoder Representations from Transformers (BERT)- and keyword-based DILI classification results, even without the needs of training a predictive model [19, 30].

Moreover, we investigated the 14 mismatched (i.e., 13 false-positive and 1 false-negative) cases between AskFDALabel and manual curation (Online resource 2; see the electronic supplementary material). These 14 cases were manually verified with the following criteria: (1) the drug labeling document used for the AskFDALabel process is valid, as the name on the labeling document matches the given drug name; (2) DILI-related keywords found by AskFDALabel could be manually found in the given reference; and (3) a review of the labeling document could determine whether the discrepancy between the human and AskFDALabel result is due to a labeling document update since the manual reading.

We found that AskFDALabel responses to seven of 13 false-positive cases could be verified, as their references contained DILI-related terms. Among the seven verified cases, four were due to labeling updates. For example, the labeling document for Desfaral (deferoxamine) did not have any hepatic information in 2008 according to the labeling archive from DailyMed, but its labeling was updated in 2010 to include such information. Similarly, the labeling document for ketamine did not mention DILI-related terms before 2020, but a new subsection titled “Drug-Induced Liver Injury” was added in 2021. Metronidazole’s labeling was updated in 2024 to include hepatic information in the “Adverse Reactions” section, which was not present in its previous labeling. For the other three cases, we found keywords such as “alkaline phosphatase increased” or “elevation in liver function tests” to confirm they could be DILI-positive drugs. Validation notes are provided in Online resource 2.

On the other side, clotrimazole, which was determined to have “no” DILI concern by AskFDALabel but “less” DILI by a human scientist, is the only false-negative case reported in this study. A potential reason for this is the latest labeling documents of clotrimazole used by the AskFDALabel framework are for the topically administered product. After consulting with our DILI experts, they agree that it is better to primarily focus on the product that was taken orally or parenterally. Further investigation is needed to see whether a revision of the special template focusing on oral drugs could further improve performance.

By reconsidering these verified mismatched results as correct, only one false-negative drug and six false-positive drugs remained. The updated F1-score was 0.978 (Table 1). That said, we demonstrated that using AskFDALabel can retrieve results that are accurate and highly consistent with those processed by human reviewers. Also, using the automated process, the current framework is capable of capturing the impact on DILI classification resulting from recent changes in the labeling document. The detailed DILI classification results for all assessed drugs are provided in Online resource 3.Table 1Statistical summary of DILI and DICT classification resultApproachAccuracyRecallPrecisionSpecificityF1-scoreDILI classificationAskFDALabel0.9670.9940.9620.8950.978BERT model [19]0.9271.0000.7840.9000.879Keywords [19]0.8221.0000.5810.7640.735XGBoost [30]0.8390.6510.8560.9410.740DICT classificationAskFDALabel0.9010.9410.9210.8020.931Prev. LLM [20]0.7760.6080.9070.9400.728ChatGPT (3.5) [20]0.7150.9080.6470.5310.756Bold value in each column represents the best performance across all approaches for DILI and DICT classificationBERT Bidirectional Encoder Representations from Transformers, DICT drug-induced cardiotoxicity, DILI drug-induced liver injury, FDA Food and Drug Administration, LLM large language model

Statistical summary of DILI and DICT classification result

## Section: Result › DICT Classification

Similarly, we processed the 1167 DICT drugs, where 780 of 829 DICT-positive drugs (94.1%) and 271 of 338 DICT-negative drugs (80.2%) were correctly classified by AskFDALabel. The statistical measurement is summarized in Table 1. The overall F1-score for DICT classification was 0.931, significantly improving upon results from a previous LLM (Llama 13B) used in AskFDALabel (F1-score = 0.728) and GPT-3.5 (F1-score = 0.756) [20]. This superior performance may be attributed to the use of the newer LLM (Llama 3.1-70B) and the hybrid information retrieval strategy. The complete DICT classification results for all assessed drugs are provided in Online resource 4 (see the electronic supplementary material).

## Section: Result › Drug AE Profiling

In this section, we performed two sub-experiments on the drug AE profiling: (1) We used the original labeling contents provided by the TAC dataset. This enabled us to develop a comparative study for AskFDALabel to compare currently existing approaches within the same dataset. (2) We followed the AskFDALabel framework, using the drug name to retrieve the most recent labeling documents for the AE profiling process. The content of the labeling documents could be updated during the past years and, therefore, may identify newly reported AEs.

Sub-experiment 1 contained 476 data samples, where each sample represented content from one section of the labeling document. To determine the true positives, which were the profiles annotated by both human and LLM, we mapped each line of the AE profiling to human-annotated AEs, and added tags if an AE was matched. Based on the exact match, the recall and F1-score on the section level were 0.825 and 0.827, respectively.

Additionally, we considered semantically similar terms between the AskFDALabel result and the human annotations. As a result, the average semantic-based recall and F1-score for all 476 samples were 0.939 and 0.911, respectively, which were higher than previously reported approaches in the TAC 2017 challenge [7] as well as when using the NER predictive model based on RxBERT [31]. Moreover, our LLM-based approach had another significant advantage in that it did not need to train the NER model with an already annotated dataset.

Next, sub-experiment 2 retrieved the most up-to-date labeling documents based on the drug name. The generated AE profile for each drug was then compared to the true AE profile annotated by reviewers (which was still based on the older version) on the whole labeling level. As a result, 188 drug names were successfully processed and their AE profiles were generated by AskFDALabel. Twelve drugs could not be processed. Some of the drugs, such as “Arcapta” and “Belviq,” had been discontinued since the TAC annotation. Therefore, their labeling information was no longer available in the current FDALabel database.

As summarized in Table 2, the average semantic-based recall for 188 drugs on the whole labeling level was 0.895, and the overall F1-score was 0.859. The decreased performance compared to directly using TAC contents may have been due to the inaccuracy in labeling retrieval. For example, a drug named KIT was incorrectly processed due to its name after examination, but another major reason could be the result of labeling updates during the past decade since the human annotation. In other words, the different AE terms found by AskFDALabel could still be true AEs. For example, “anaphylaxis” was found in the raxibacumab AE profiling by AskFDALabel but not in the TAC 2017 human annotation, due to the label update of raxibacumab on 06/2021; therefore, the annotations by both humans and AskFDALabel were accurate because of the different accessed time of the labeling data. The AE profiling generated by AskFDALabel made it much easier to catch these recent labeling updates related to AE changes.Table 2Performance on TAC 2017 dataset and drug AE profilingApproachesPrecisionRecallF1-scoreSub-experiment 1:TAC originallabelingAskFDALabel—exact0.8580.8250.827AskFDALabel—semantic0.9060.9390.911TAC 2017—SOTA [7]0.8510.8530.852RxBERT [31]0.8930.8850.889Sub-experiment 2:most up-to-date labelingExact—up to 1024 tokens output0.7580.7690.753Semantic—up to 1024 tokens output0.8400.8950.859Semantic—up to 4096 tokens output0.8480.9040.870AE adverse event, FDA Food and Drug Administration, TAC Text Analysis Conference, SOTA State-Of-The-Art

Moreover, we investigated the impact of output length on the final performance for drug name only (Table 2). In this study, the output length was set to 1024 tokens per section by default. Although this output length met most of the requirements during our experiment, it was not enough for a few labeling documents that could contain hundreds of AE terms in one section. Therefore, we further increased the output length to 4096, with everything else unchanged. As a result, performance increased slightly compared to that of the 1024 output length, although longer output length also increase the processing time from 160 min to 180 min, for processing 200 drugs. Note that the increase of maximum output would not affect most of the queries since their outputs did not reach the token limits.

In all, we demonstrated that AskFDALabel also generated high-quality AE profiling for a given drug. The detailed AE profiling report of the 188 drugs supporting the above analysis is provided in Online resource 5 (see the electronic supplementary material).

Performance on TAC 2017 dataset and drug AE profiling

## Section: Discussion › Improved RAG with Hybrid Information Retrieval

One important feature of AskFDALabel is the utilization of hybrid information retrieval, which combined database query with LLM inference to find the most relevant references for the user query.

Database query has been widely used in past decades and is still the main approach for most information retrieval tasks. While database query has several advantages, the most important, if not the only one, for regulatory tasks is authenticity. In other words, database query will exactly return the record that has been stored in the knowledgebase, whereas semantic similarity search may lead to similar but not exactly matching results. Thus, database query helps eliminate a major concern related to applying generative LLMs into the regulatory settings.

In AskFDALabel, we combined database query with an LLM by breaking down the whole information retrieval process of regular RAG into several steps. In some steps, such as template selection, entity recognition used an LLM to take advantage of its flexibility. For other steps such as labeling document retrieval, we decided to use a more conservative approach such as database query instead of a semantic similarity search, to ensure the retrieved reference would be relevant to the query, particularly when we knew the query was under a specific template.

In this study, we demonstrated that using such a hybrid information retrieval approach can provide promising result in all three tasks, which further indicated that combining an LLM with conventional technologies instead of relying on it alone could provide better and more explainable outcomes.

## Section: Discussion › Enhancing Regulatory Science with Modularized and Customizable Templates

In this study, we presented FDALabel-based RAG, which restricted the reference used in the LLM inference solely to the specific labeling documents instead of using the full scope of the LLM’s inherent knowledge. For example, we did not expect AskFDALabel to process such tasks as “rephrase my proposal,” or “suggest a travel plan for my weekend,” but only to focus on labeling document review and analysis.

Moreover, the AskFDALabel framework is designed to “plug-and-play” the foundation LLMs, like Llama 3.1-70B. One advantage of this strategy was the ability to directly benefit from the features introduced in the newer models, such as the increased token size newly introduced in Llama 3.1.

Along with directly using the foundation model, developing a fine-tuned LLM for such a specific task will be an option for future exploration. To do that, a large corpus of documents must be collected to train/fine-tune domain-specific LLMs, in addition to the demanding requirement of massive hardware resources. Currently, externally hosted LLMs such as ChatGPT from OpenAI and Gemini from Google are not allowed for use in regulatory research and review at the agency. When policy changes, they will be explored and compared with Llama in terms of efficiency, cost, and performance gain for the AskFDALabel framework.

## Section: Discussion › Integrating Human Expertise into the LLM Framework

In general, the manual reviewing process for labeling analysis can be divided into two steps. First, a strategy or protocol needs to be developed for the specific task. For example, for DILI classification, the reviewer needs to define which labeling section needs to be reviewed, the weight of different keywords in each section, and the severity level of DILI. After developing the strategy, the second step for reviewers is to undertake a labor-intensive process, such as manual document comparison or exhaustive database searches, to gather necessary information required for this task. Such processes might entail, for example, manually reading the labeling document and identifying and extracting all DILI-relevant keywords from section texts. This step is also prone to human errors or inconsistencies.

That said, AskFDALabel is designed to automate the second step, to augment the reviewers’ analytical capabilities. Our current experiments demonstrated that with appropriate templates and prompts, AskFDALabel can generate highly consistent and reproducible results for human reviewers, which will largely reduce the manual effort involved in implementing the designed annotation strategy in the second step. Particularly, the output of AskFDALabel can provide information beyond the final answer, such as, which labeling document (i.e., its set-id) was referred to, or which DILI-related keywords were found and used to determine the DILI classes. This additional information can help reviewers more efficiently check and validate the AskFDALabel output, and increases the reliability and trustworthiness of applying AskFDALabel to their daily tasks.

## Section: Discussion › Limitations and Future Directions

Our approach used fixed structured query language (SQL) queries to retrieve labeling documents by drug name, ensuring stability and data consistency. However, this static method limits adaptability for specific user inputs, such as routes of administration or dosage forms. Future work may incorporate LLMs to dynamically generate SQL queries from user prompts, though testing is required to confirm reliability.

Additionally, fine-tuning LLMs with domain-specific data is expected to enhance their performance in addressing regulatory-specific queries, but care must be taken to balance improvements with computational costs and potential risks of overfitting to narrow datasets.

While this study used only public drug labeling documents, AskFDALabel’s framework is adaptable for secure, non-public data, enabling comparisons across historical and bioequivalent documents. These promising results suggest broader potential for applying AI to confidential regulatory documents, such as safety reports and training materials, advancing AI’s role in regulatory science.

## Section: Conclusion

AskFDALabel could be a game-changer since it has shown not only high accuracy and consistency, but also a capability to handle an ever-growing volume of data with a scalable and automated approach. Moreover, by providing additional explanations and cited references along with its answers, it can enhance the reliability of the automated process, making it easier for human reviewers to verify and trust the AI outputs. In all, we demonstrated that the generative AI could enhance the efficacy and effectiveness of drug safety research, particularly with, but possibly not limited to, drug labeling documents.

In conclusion, the integration of advanced natural language processing (NLP) techniques and LLM-powered systems like AskFDALabel represents a significant leap forward in the field of AE research and drug safety. By automating the labor-intensive processes of AE annotation, profiling, and classification, AskFDALabel not only enhances efficiency but also improves the accuracy and consistency of data extraction from FDA drug labeling documents. This innovation has the potential to transform regulatory practices and advance the understanding of AE annotation, profiling, monitoring, and drug toxicity classification, ultimately contributing to the safe and effective use of drugs for better patient outcomes. The evaluation of AskFDALabel across multiple benchmark datasets demonstrates its effectiveness, marking a promising step toward more reliable and scalable solutions in pharmacovigilance and drug safety research.

## Section: Supplementary Information

Below is the link to the electronic supplementary material.Supplementary file1 (PDF 164 KB)Supplementary file2 (XLSX 14 KB)Supplementary file3 (XLSX 35 KB)Supplementary file4 (XLSX 132 KB)Supplementary file5 (XLSX 374 KB)

Supplementary file1 (PDF 164 KB)

Supplementary file2 (XLSX 14 KB)

Supplementary file3 (XLSX 35 KB)

Supplementary file4 (XLSX 132 KB)

Supplementary file5 (XLSX 374 KB)


---

# Leveraging machine learning models in evaluating ADMET properties for drug discovery and development

- **Authors:** Magesh Venkataraman, Gopi Chand Rao, Jeevan Karthik Madavareddi, Srinivas Rao Maddi
- **Issuer:** ADMET & DMPK
- **Type:** Scientific article
- **Published:** 2025-06-07
- **Language:** en
- **DOI:** 10.5599/admet.2772
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40585410/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackground and purposeThe evaluation of ADMET properties remains a critical bottleneck in drug discovery and development, contributing significantly to the high attrition rate of drug candidates. Traditional experimental approaches are often time-consuming, cost-intensive, and limited in scalability. This review aims to investigate how recent advances in machine learning (ML) models are revolutionizing ADMET prediction by enhancing accuracy, reducing experimental burden, and accelerating decision-making during early-stage drug development.Experimental approachThis article systematically examines the current landscape of ML applications in ADMET prediction, including the types of algorithms employed, common molecular descriptors and datasets used, and model development workflows. It also explores public databases, model evaluation metrics, and regulatory considerations relevant to computational toxicology. Emphasis is placed on supervised and deep learning techniques, model validation strategies, and the challenges of data imbalance and model interpretability.Key resultsML-based models have demonstrated significant promise in predicting key ADMET endpoints, outperforming some traditional quantitative structure - activity relationship (QSAR) models. These approaches provide rapid, cost-effective, and reproducible alternatives that integrate seamlessly with existing drug discovery pipelines. Case studies discussed in this review illustrate the successful deployment of ML models for solubility, permeability, metabolism, and toxicity predictions.ConclusionMachine learning has emerged as a transformative tool in ADMET prediction, offering new opportunities for early risk assessment and compound prioritization. While challenges such as data quality, algorithm transparency, and regulatory acceptance persist, continued integration of ML with experimental pharmacology holds the potential to substantially improve drug development efficiency and reduce late-stage failures.Keywords: ADMET prediction, AI/ML, pharmacokinetics, computational toxicology, molecular descriptors

## Section: Introduction

The typical timeframe for drug discovery and development of a new drug spans from 10 to 15 years of rigorous research and testing [1]. The sheer volume of potential drug candidates renders traditional wet lab experiments impractical. However, advancements in data science over the past decade, coupled with enhanced computational capabilities, have paved the way for in silico methodologies for screening extensive drug libraries. This preliminary step, preceding preclinical studies, significantly reduces costs and expands the scope of drug discovery efforts [2]. Machine learning (ML) is a method of data analysis involving the of new algorithms and models capable of interpreting a multitude of data. Within this framework, ML techniques have emerged as pivotal tools in the pharmaceutical drug discovery and development field [3]. Recent progress in ML algorithms, coupled with the accessibility of extensive proprietary and public absorption, distribution, metabolism, excretion and toxicity (ADMET) datasets, has sparked enthusiasm among academic and pharmaceutical science circles in predicting pharmacokinetic and physicochemical endpoints in early drug discovery [4].

It has been widely recognized that ADMET should be evaluated as early as possible [5]. Figure 1 illustrates the schematic representation of the ADME process for orally administered drugs, illustrating key pharmacokinetic phases including absorption in the gastrointestinal tract, metabolism in the liver, distribution via systemic circulation, and excretion through renal clearance. In silico ADME-Toxicity (ADME-Tox) evaluation models have been developed as an additional tool to assist medicinal chemists in the design and optimization of leads [6]. The majority of the problems arising during the process of drug discovery include unfavourable ADMET properties, which have been known to be a major cause of failure of the potential molecules in the drug development pipeline, contributing to large consumption of time, capital and human resources [7].

This has increased the interest in the early-stage prediction of ADMET properties of drug candidates so that the success rate of a compound reaching the later stages of drug development can be enhanced. ML has been effectively utilized to develop models and prediction tools for ADMET properties. Apart from property predictions, ML has also contributed to early phases of drug discovery, like de novo designing of chemical compounds and peptides [8]. Moreover, companies involved in clinical research have ascertained that revising the research strategies by introducing ML-based techniques has resulted in greater success rates in both preclinical and clinical trials [9]. After high-throughput screening, the chosen compounds, often referred to as hit compounds, are analysed for their biological activity via in vitro studies. The most potent compounds obtained from in vitro activity data are developed into lead compounds through a lead optimization process [10]. During the lead optimization phase, the compounds are modified to improve their bioavailability, solubility, partition coefficient, and stability as these factors can have a direct impact on the drug's therapeutic efficacy and potency [11]. The molecules with optimized ADMET properties are then further evaluated for their effectiveness using suitable animal models [12].

The optimized compounds are tested in human subjects in order to validate and confirm the potency, therapeutic efficacy, ADMET and possible adverse drug reactions through a four-step process called clinical trials, in which each step is carried out in a varying number of human subjects in a randomized control manner [13].

This review mainly focuses on the ML-based tools used in ADMET properties. We have given a general introduction to the drug discovery process, Machine learning and DL techniques, followed by specific examples and discussion on various ML and artificial intelligence (AI) based tools for drug development. We also pointed out some notable success stories in the use of AI and ML in ADMET.

This figure depicts the absorption, distribution, metabolism, and excretion (ADME) process for drugs administered orally. When a tablet or capsule is ingested, it disintegrates in the gastrointestinal (GI) tract, releasing drug molecules. These molecules either dissolve for absorption or remain in a precipitated state, eventually being excreted. Absorbed drug molecules must cross the gut wall, where they may be transported back into the intestinal lumen or metabolized by enzymes. Those that successfully traverse the gut barrier enter the liver via the portal circulation. The liver plays a crucial role in drug metabolism, utilizing phase I (modification) and phase II (conjugation) enzymatic reactions to increase the hydrophilicity of xenobiotics, facilitating their elimination through the kidneys. Drugs that escape metabolism enter systemic circulation, though a portion binds to plasma proteins, limiting their bioavailability. Only the free, unbound drug and its metabolites can reach target cells and interact with biomolecules to exert therapeutic effects. Meanwhile, some drug molecules are rapidly cleared by the kidneys. The drug’s efficacy is determined by its ability to reach and maintain an optimal concentration at the site of action while navigating these physiological processes (Courtesy:NIH Bioart; Bioicons).

## Section: 2. Fundamentals of machine learning in drug discovery

Commonly used AI/ML algorithms for developing ADMET prediction models

The diagram illustrates the stepwise workflow for generating a machine learning model, starting from raw data collection to model evaluation. Initially, raw data, which can include both labeled and unlabeled datasets, undergoes preprocessing and structuring. This iterative step ensures data quality before proceeding further. Once the data is refined, it is split into training and test sets, commonly in an 80:20 ratio of the total volume of the data. The 80 % training data is then subjected to various machine learning algorithms, including supervised, unsupervised, reinforcement learning, and deep learning approaches. Through an iterative process, the best-performing candidate model is selected. The chosen candidate model is further refined through hyperparameter optimization and feature selection, leading to the final optimized model. This model is then validated using cross-validation techniques such as 5-fold cross-validation to ensure robustness. Following validation, the model is tested using the 20 % test dataset. The predicted outcomes (y-values) are analysed, and the model's performance is evaluated using classification and regression metrics, ensuring its reliability and accuracy for real-world applications (Courtesy: Bioicons; Flaticon).

A list of databases that contain pharmacokinetic data for machine learning analyses

List of software packages for the calculation of Molecular descriptors

## Section: 2. Fundamentals of machine learning in drug discovery › 2.1. Basics of machine learning models

ML starts with obtaining a suitable dataset, often from publicly available sources, and has become increasingly prominent in ADMET prediction, offering valuable tools for drug development and toxicity [14]. ML methods are generally divided into supervised and unsupervised approaches. In supervised learning, models are trained using labelled data to make predictions, such as predicting properties like pharmacokinetic (PK) properties, based on input attributes like chemical descriptors of new compounds. On the other hand, unsupervised learning aims to find patterns, structures, or relationships within a dataset without using labelled or predefined outputs. Its goal is to uncover inherent structures and insights, which are sometimes missed in supervised learning approaches because they rely on pre-defined answers [3] Common ML algorithms used in this field include supervised methods such as support vector machines, random forests, decision trees, and neural networks, as well as unsupervised approaches like Kohonen's self-organizing maps [15] (Figure 2). These methods can be applied to various types of input data, ranging from chemical structural descriptors to transcriptome analysis, enhancing prediction accuracy [16]. The selection of appropriate ML techniques depends on the characteristics of available data and the specific ADMET property being predicted [15]. The development of a robust machine learning model for ADMET predictions begins with raw data collection, which includes both labelled and unlabelled datasets. This data undergoes preprocessing, ensuring quality and consistency before being split into training and testing datasets. Various ML algorithms, such as supervised, unsupervised, and deep learning approaches, are then applied to the training data to develop predictive models. To enhance model accuracy and generalizability, feature selection and hyperparameter optimization are performed, followed by cross-validation techniques like k-fold validation. Finally, the optimized model is tested using an independent dataset to evaluate its performance based on classification and regression metrics. Figure 3 illustrates the stepwise workflow for generating an ML model, detailing each phase from data preprocessing to model evaluation.

Commonly used AI/ML algorithms for developing ADMET prediction models

The diagram illustrates the stepwise workflow for generating a machine learning model, starting from raw data collection to model evaluation. Initially, raw data, which can include both labeled and unlabeled datasets, undergoes preprocessing and structuring. This iterative step ensures data quality before proceeding further. Once the data is refined, it is split into training and test sets, commonly in an 80:20 ratio of the total volume of the data. The 80 % training data is then subjected to various machine learning algorithms, including supervised, unsupervised, reinforcement learning, and deep learning approaches. Through an iterative process, the best-performing candidate model is selected. The chosen candidate model is further refined through hyperparameter optimization and feature selection, leading to the final optimized model. This model is then validated using cross-validation techniques such as 5-fold cross-validation to ensure robustness. Following validation, the model is tested using the 20 % test dataset. The predicted outcomes (y-values) are analysed, and the model's performance is evaluated using classification and regression metrics, ensuring its reliability and accuracy for real-world applications (Courtesy: Bioicons; Flaticon).

## Section: 2. Fundamentals of machine learning in drug discovery › 2.2. Data requirements and preprocessing

The standard ML methodology starts with obtaining a suitable dataset, often from publicly available repositories tailored for drug discovery. The quality of data is crucial for successful ML tasks, as it directly impacts model performance. Various databases provide pharmacokinetic and physicochemical properties, enabling robust model training and validation [4]. A comprehensive list of such databases is presented in Table 1. Data preprocessing, including cleaning, normalization, and feature selection, is essential for improving data quality and reducing irrelevant or redundant information [17]. Feature quality, such as relevant, informative, and predictive a specific feature is within a dataset has been shown to be more important than feature quantity, with models trained on non-redundant data achieving higher accuracy (>80 %) compared to those trained on all features [18]. When dealing with imbalanced datasets, combining feature selection and data sampling techniques can significantly improve software defect prediction performance. Empirical results suggest that feature selection based on sampled data outperforms feature selection based on original data [19]. These findings highlight the importance of carefully considering data quality, feature selection, and handling of imbalanced datasets in ML tasks to achieve optimal model performance.

A list of databases that contain pharmacokinetic data for machine learning analyses

## Section: 2. Fundamentals of machine learning in drug discovery › 2.3. Feature engineering in ADME-tox prediction

Feature engineering plays a crucial role in improving ADMET prediction accuracy. Traditional approaches rely on fixed fingerprint, i.e. an efficient and quick means of portraying fixed-length data, ignoring the internal substructures within representations of molecules [30]. However, recent advancements involve learning task-specific features by representing molecules as graphs, where atoms are nodes and bonds are edges. Graph convolutions applied to these explicit molecular representations have achieved unprecedented accuracy in ADMET property prediction [31]. Feature selection methods can help determine relevant properties for specific classification or regression tasks, alleviating the need for time-consuming experimental assessments [32]. Filter methods are employed during the pre-processing stage to select features from the dataset without relying on any specific machine learning algorithm. These methods swiftly identify and eliminate duplicated, correlated, and redundant features, making them highly efficient in computational terms [33]. They excel at isolating individual features for evaluation, which proves beneficial when features operate independently. However, they fall short in addressing multicollinearity, as they do not mitigate the interdependencies between features. Despite their speed and cost-effectiveness, filter methods may not capture the potential performance enhancements achievable through feature combinations [34]. In a study by Ahmed and Ramakrishnan [35], correlation-based feature selection (CFS), a type of filter method to identify fundamental molecular descriptors for predicting oral bioavailability. Out of 247 physicochemical descriptors from 2279 molecules, 47 were found to be major contributors to oral bioavailability, as confirmed by the logistic algorithm with a predictive accuracy exceeding 71 %.

Wrapper methods, also known as greedy algorithms, iteratively train the algorithm using subsets of features. These methods dynamically add and remove features based on insights gained during previous model training iterations [36]. Unlike filter methods, wrapper methods offer an optimal feature set for model training, leading to superior accuracy. However, their computational demands are higher compared to filter methods due to the iterative nature of the process [33].

In embedded methods, the feature selection algorithm is integrated into the learning algorithm, possessing inherent feature selection capabilities. The models combine filtering and wrapping techniques to optimize feature selection. Initially, these models utilize a filter-based approach to reduce the feature space dimensionality. Subsequently, the best subset of features identified through the filter-based step is incorporated using a wrapper technique [37]. Embedded methods combine the strengths of filter and wrapper techniques while mitigating their respective drawbacks. They inherit the speed of filter methods while surpassing them in accuracy [38].

## Section: 2. Fundamentals of machine learning in drug discovery › 2.4. Molecular descriptors

Molecular descriptors (MD) are crucial components in in-silico research, serving as numerical representations that accurately convey the structural and physicochemical attributes of compounds based on their 1D, 2D, or 3D structures [39]. Various software tools are available for the calculation of molecular descriptors, facilitating the extraction of relevant features for predictive modelling. Table 2 provides a comprehensive list of software packages commonly used in cheminformatics and computational drug discovery for descriptor generation. These programs offer a wide array of over 5000 descriptors, encompassing constitutional descriptors as well as more intricate 2D and 3D descriptors that capture various geometric, connectivity, and physicochemical properties [40]. The choice of molecular representation determines whether a molecule is described using experimental descriptors or theoretical descriptors. Experimental descriptors encompass all measurements obtained through experiments, such as the octanol-water partition coefficient, molar refractivity, polarizability, and various other physicochemical properties obtained through specific experimental procedures [41]. Conversely, theoretical molecular descriptors span 0D, 1D, 2D, 3D and 4D molecular descriptors, which are derived from defined chemoinformatic algorithms applied to a clear molecular representation [42]

The 0D molecular descriptors are straightforward and convenient to compute and interpret because they don't require structural information or connectivity between atoms. They are independent of molecular conformation and optimization [43]. While they offer limited information content, they still play a vital role in modelling various physicochemical properties or contributing to more complex models [44]. Descriptors that compute information from fractions of a molecule fall into the 1D molecular descriptors category, often represented as fingerprints - binary vectors where 1 indicates a substructure's presence and 0 its absence [45]. Similar to 0D descriptors, they're straightforward to calculate, interpretable, and conformation-independent [46]. Two-dimensional descriptors describe properties computable from 2D molecular representations, relying on graph theory and maintaining theoretical properties through isomorphism. They're sensitive to molecular characteristics like size, shape, and chemical information [46]. They're divided into structural-topological indices, encoding adjacency and distance, and topochemical indices, quantifying topology and atomic properties [47]. Three-dimensional descriptors relate to the 3D representation of molecules, incorporating molecular conformations, bond distances, angles, and dihedral angles to describe stereochemical properties [39]. Popular types include pharmacophore representations, characterizing steric and electronic features crucial for interactions with biological targets [48]. Grid-based descriptors, also called 4D, introduce a fourth dimension to capture interactions between molecules, their conformations, and biological receptor active sites. By considering ligand conformational variation and interactions within binding pockets, they aim to enhance quantitative structure-activity relationship (QSAR) model reliability [49].

List of software packages for the calculation of Molecular descriptors

## Section: 3. Machine learning applications in predicting ADME properties

Summary of machine learning-based models for absorption prediction

Summary of machine learning-based models for distribution prediction

Summary of machine learning-based models for metabolism prediction

Summary of machine learning-based models for excretion prediction

## Section: 3. Machine learning applications in predicting ADME properties › 3.1. Absorption prediction

Machine learning models have shown promise in predicting intestinal absorption and permeability of compounds. Various approaches have been employed, including artificial neural networks for oligopep-tides [50], support vector machines for general compounds [51], and ensemble methods combining support vector machines (SVM), random forest (RF), and gradient boosting for natural products [52] (A summary of machine learning-based models for absorption prediction is presented in Table 3.). These models have demonstrated high predictive accuracy, with support vector machines achieving up to 91.54 % accuracy [51]. Computational models based on molecular descriptors, such as polar surface area, have also been developed to predict intestinal permeability [53]. These in silico methods offer quick and cost-effective alternatives to experimental techniques like Caco-2 cell assays.

The ability to predict intestinal absorption and permeability can significantly aid in drug development by facilitating the selection of promising candidates and potentially reducing attrition rates in clinical trials [52]. Bei et al. [59] developed an XGBoost model to predict the subcutaneous absorption rate constant of monoclonal antibodies using only their primary sequence. Kamiya et al. [60] used machine learning to estimate key physiologically based pharmacokinetic model parameters, including absorption rate constants, for 212 diverse chemicals. Karalis [61] applied machine learning techniques to identify the maximum plasma concentration (Cmax) / time to reach Cmax (Tmax) ratio as a potentially superior metric for absorption rate in bioequivalence studies. Kumar et al. [62] implemented a graph convolutional neural network model to predict 18 early ADME properties across an enterprise-wide drug discovery pipeline. An integrated strategy combining multiple machine learning models and physiologically-based pharmacokinetic models achieved promising results in predicting human oral bioavailability directly from chemical structure [63]. Artificial Neural Networks outperformed support vector machines in predicting food effects on bioavailability, with key factors including octanol water partition coefficient, hydrogen bond donors, topological polar surface area, and dose [64]. Graph Neural Networks with transfer learning have also shown potential in predicting oral bioavailability, outperforming previous studies by automatically extracting important features from molecular structures [65]. These studies demonstrate the potential of machine learning to enhance the prediction of absorption kinetics and other pharmacokinetic parameters, potentially accelerating drug development processes.

Summary of machine learning-based models for absorption prediction

## Section: 3. Machine learning applications in predicting ADME properties › 3.2. Distribution prediction

This summary examines models for predicting drug distribution in the body, focusing on blood-brain barrier (BBB) penetration and volume of distribution. Physiologically-based pharmacokinetic (PBPK) models are commonly used to predict tissue: plasma partition coefficients and volume of distribution [66]. Key factors affecting BBB penetration include permeability-surface area product (PS), unbound fraction in plasma (fu, plasma), and brain tissue (fu, brain) [67] (see Table 4 for an overview of machine learning-based models for distribution prediction). In vivo methods, such as brain microdialysis and in situ brain perfusion, are valuable for assessing brain drug distribution [68].

A simple two-descriptor model using molecular volume and polar surface area has been proposed for predicting BBB penetration [67]. Overall, current methods predict drug volume of distribution with an average 2-fold error [66]. Rapid brain equilibration requires high BBB permeability and low brain tissue binding [67], highlighting the importance of considering multiple drug design and selection factors. Iwata et al. [76] developed ML models for total body clearance and steady-state volume of distribution (Vd using imputed nonclinical data, achieving accuracies comparable to animal scale-up models. Parrott et al. [77] integrated ML-predicted properties into physiologically-based pharmacokinetic (PBPK) models for highly lipophilic compounds, showing promising results for Vd predictions. Antontsev et al. [71] demonstrated a hybrid approach combining ML optimization with mechanistic modelling to predict tissue-plasma partition coefficients accurately. Mulpuru and Mishra [78] developed an AutoML model for predicting plasma unbound fraction, achieving a coefficient of determination of 0.85. Cao et al. [79] created a model to classify Polyfluorinated alkyl substances (PFAS) binding fractions in plasma, with 92 % accuracy. Riedl et al. [80] introduced a descriptor-free deep learning model using bidirectional encoder representations from transformers (BERT) for predicting plasma unbound fraction, offering flexibility and minimal domain expertise requirements. These studies demonstrate the potential of machine learning in predicting drug binding and distribution properties.

Summary of machine learning-based models for distribution prediction

## Section: 3. Machine learning applications in predicting ADME properties › 3.3. Metabolism prediction

Machine learning techniques have shown promising results in predicting drug metabolism and interactions related to cytochrome P450 (CYP) enzymes. Various approaches, including k-nearest neighbours, decision trees, random forests, artificial neural networks, and support vector machines, have been employed to classify CYP activities and predict interactions with high accuracy [81] (For a structured overview of ML models in drug metabolism, see Table 5). Machine learning has also been applied to model relationships between chemical structure and metabolic fate, addressing complex endpoints such as metabolic stability and in vivo clearance [82].

Recent advancements have led to the development of consensus models for predicting metabolic drug-drug interactions (DDIs) related to five important CYP450 isozymes (CYP1A2, 2C9, 2C19, 2D6, 3A4), achieving high accuracy and robustness in both internal and external validations [86]. These in silico methods have become valuable tools in drug discovery and development, offering efficient alternatives to time-consuming and costly experimental assessments. Mamada et al. [87] developed a novel combination model using DeepSnap-Deep Learning and conventional ML, achieving high accuracy in predicting rat clearance. Keefer et al. [88] compared ML and mechanistic in vitro-in vivo extrapolation (IVIVE) models, finding that ML IVIVE models performed comparably or better than mechanistic counterparts for human intrinsic clearance prediction. Rodríguez-Pérez et al. [89] introduced a multitask graph neural network architecture for multispecies intrinsic clearance prediction, approaching experimental variability in performance. Andrews-Morger et al. [90] explored ML strategies to improve rat clearance predictions for physiologically based pharmacokinetic modelling, demonstrating enhanced accuracy compared to standard in vitro bottom-up approaches. These studies highlight the potential of ML models in improving clearance predictions across species, contributing to more efficient drug discovery and development processes.

Summary of machine learning-based models for metabolism prediction

## Section: 3. Machine learning applications in predicting ADME properties › 3.4. Excretion prediction

Machine learning models have emerged as powerful tools for predicting drug metabolism and excretion in early drug discovery and development [91]. Researchers have developed in-silico prediction systems for renal excretion and clearance, incorporating factors such as the fraction unbound in plasma to improve accuracy [92]. ML models for pharmacokinetic (PK) prediction complement established approaches like IVIVE and PBPK models [93]. Ongoing research focuses on improving model accuracy, addressing limitations, and integrating ML approaches into drug discovery workflows to enhance efficiency and clinical success rates [93]. Recent studies have explored machine learning approaches for predicting pharmacokinetic parameters, including clearance (CL), elimination rate constant (ke), and half-life (t½) (Table 6 outlines key machine learning models developed for predicting drug excretion parameters). Seal et al. [94] created PKSmart, an open-source model for predicting human PK parameters, including volume of distribution at steady-state (VDss), CL, and t½, using molecular fingerprints and animal PK data. Fan et al. [95] focused on predicting drug half-life using ensemble and consensus machine learning methods, with XGBoost outperforming other individual models and a consensus model further enhancing prediction performance. These studies demonstrate the potential of machine learning approaches in improving the accuracy and efficiency of PK parameter prediction in drug discovery and development.

Summary of machine learning-based models for excretion prediction

## Section: 4. Machine learning approaches in toxicity prediction

Summary of machine learning-based models for toxicity prediction

## Section: 4. Machine learning approaches in toxicity prediction › 4.1. In silico toxicity models

Machine learning models have become increasingly popular for predicting various toxicity endpoints, including hepatotoxicity, nephrotoxicity, cardiotoxicity, and genotoxicity [102]. Various ML models for predicting drug toxicity are summarized in Table 7. These models utilize physicochemical properties and in vitro assays to predict drug-induced liver injuries (DILI), which are major causes of drug attrition [103]. Support vector machines and random forests are among the most commonly used algorithms for toxicity prediction [104]. Khan et al. [104] developed an ensemble model integrating ML and deep learning algorithms, achieving 80.26% accuracy in predicting hepatotoxicity. Ancuceanu et al. [105] used the DILIrank dataset to create 78 models, which were then stacked for improved performance. Lu et al. [106] focused on predicting hepatotoxicity of drug metabolites using an ensemble approach based on support vector machines, achieving 78.47 % balanced accuracy. For specific drugs like colistin, machine learning models using electronic health records have been developed to predict nephrotoxicity, identifying key risk factors and dose thresholds [107].

A radiomics-based ML model for predicting radiotherapy-induced cardiotoxicity in breast cancer patients demonstrated high performance, with AUC up to 97 % when combining dosimetric, demographic, clinical, and imaging features [114]. Another study introduced cardioToxCSM, a web-based tool that predicts six types of cardiac toxicity outcomes for small molecules, achieving AUC values up to 0.898 [115]. The MultiFlow® DNA damage assay (MFA), which measures four mechanistic markers at two time points, has been combined with ML to enhance genotoxicity assessment and predict the mode of action of DNA-damaging agents [116]. Recent studies have achieved high accuracies in predicting genotoxicity, with models reaching up to 95 % accuracy on training data and 92 % on external test sets [116]. These studies demonstrate the potential of ML in toxicity prediction. The availability of large toxicology databases has facilitated the development of more accurate models [117]. However, challenges remain, such as the need for benchmarking datasets due to inconsistencies in toxicity assignments across different sources [102]. Despite these challenges, computational toxicology has made significant progress over the past decade, with machine learning models showing promise in predicting various toxicity endpoints and potentially reducing the need for costly and time-consuming in vivo studies [102].

Summary of machine learning-based models for toxicity prediction

## Section: 4. Machine learning approaches in toxicity prediction › 4.2. Adverse drug reactions

Machine learning approaches have shown promising potential in predicting toxicological properties and adverse drug reactions (ADRs) of pharmaceutical agents [118]. Recent advancements include the development of AI models for precise prediction of compound off-target interactions, which can be used to differentiate drugs and classify compound toxicity [102]. The MAESTER framework integrates diverse features to predict tissue-specific adverse events with high accuracy, sensitivity, and specificity [119]. Similarly, the Off-targetP ML framework uses deep learning and automated machine learning to predict off-target panel activities directly from compound structures, aiding in drug design and discovery [120]. These computational methods offer efficient, low-cost tools for early assessment of compound safety and toxicity, potentially reducing costly failures in drug development and identifying toxic [102].

## Section: 4. Machine learning approaches in toxicity prediction › 4.3. Machine learning for predicting dose-dependent toxicity

Machine learning is revolutionizing toxicology by enhancing predictive capabilities across various dosing ranges and improving safety assessments. ML models can analyse large datasets to predict drug toxicity, environmental hazards, and off-target effects, offering more efficient and accurate risk evaluations [121-123-87]. These models can be applied early in drug discovery to identify potential safety liabilities and filter out problematic compounds [117]. The integration of ML with DNA-encoded libraries (DELs) shows promise for modelling binding to off-targets and improving predictive toxicology [123]. Various toxic endpoints, including acute oral toxicity, hepatotoxicity, and cardiotoxicity, can be predicted using ML methods, although performance varies depending on the dataset and chemical space covered [117]. Despite challenges, ML in toxicology offers significant potential for enhancing risk assessment, determining clinical toxicities, and detecting harmful side effects of medications [121].

## Section: 5. Overview of common machine learning techniques in ADME-Tox prediction

ML is a method of data analysis involving the development of new algorithms and models capable of interpreting a multitude of data [14]. The algorithms used in recent years have successively improved their performance with the increase in both the quantitative and qualitative aspects of data available for learning [124]. Figure 2 illustrates commonly used AI/ML algorithms for developing ADMET prediction models. ML is considered one of the best options available when applied to solve problems for which a big amount of data and various variables are available to the individual, but a model or formula relating these various variables amongst themselves, along with the expected result, is not known [3,4]. However, when drug discovery moved into an era of a large amount of data, ML approaches evolved into DL approaches, which are more powerful and efficient in dealing with the massive amounts of data generated from modern drug discovery approaches [125]. DL is a subset of ML based on artificial neural networks that use multiple layers to progressively extract higher-level features from raw input. Due to its ability to learn from data and the environment, DL and neural network (NN), also known as artificial neural networks (ANN) named after its artificial representation of the working of a human nervous system, have become one of the most successful techniques in various AI research areas [126].

Different types of machine learning models with varying degrees of complexity can predict molecular properties, such as similarity-based models, linear models, kernel-based models, Bayesian models, tree-based models, and neural networks.

## Section: 5. Overview of common machine learning techniques in ADME-Tox prediction › 5.1. Traditional machine learning approaches › 5.1.1. Random forest

Random forest (RF) is widely used for ADMET due to its ability to handle high-dimensional data and complex, non-linear relationships. Random forest is an ensemble learning method that utilizes multiple decision trees to make predictions. It operates by constructing a multitude of decision trees during training and outputting the mode of the classes (classification) or the mean prediction (regression) of the individual trees [127]. RF introduces randomness both in the selection of data points used to build each tree and in the selection of features used at each split point. This randomness helps to decorrelate the trees, making the ensemble more robust and less prone to overfitting [128]. It has been used to predict toxicity endpoints [109], metabolic stability [84], and solubility [129]. RF has emerged as a powerful machine learning technique for predicting absorption, distribution, metabolism, excretion, and toxicity (ADMET) properties of compounds. RF models have been successfully applied to classify toxicity datasets [130] and predict maximum recommended daily pharmaceutical doses [131]. These models utilize substructure fingerprints as descriptors, which encode the presence or absence of specific molecular substructures. RF's ability to identify important substructure features provides insights into structure-toxicity relationships [130]. The predictive performance of RF models can be further improved through rigorous model selection processes, as demonstrated in the Tox21 Challenge [132]. RF has also been employed in computational studies to evaluate ADMET properties of natural products, such as Papua red fruit flavonoids, aiding in the assessment of their potential as bioactive compounds in functional foods [133]. These applications highlight RF's versatility and effectiveness in ADMET prediction and toxicity evaluation.

## Section: 5. Overview of common machine learning techniques in ADME-Tox prediction › 5.1. Traditional machine learning approaches › 5.1.2. Support vector machines

Support vector machines (SVMs) are effective for binary classification tasks in ADMET modelling, especially for toxicology studies (like classifying compounds as toxic or non-toxic). SVMs have emerged as a powerful tool in predicting ADMET properties in drug discovery. It works by finding the optimal hyperplane that best separates different classes or predicts the continuous target variable by maximizing the margin between the classes [121]. SVMs can handle both linear and nonlinear data by using appropriate kernel functions. SVM can be extended to handle nonlinear data by mapping the input features into a higher-dimensional space using a kernel function [134]. The kernel function computes the dot product between the feature vectors in the higher-dimensional space without explicitly transforming the data. Common kernel functions include linear, polynomial, radial basis function (RBF), and sigmoid kernels, which allow SVM to capture complex nonlinear relationships in the data. SVMs, along with other machine learning techniques like Random Forests and Decision Trees, have become dominant methods in predictive toxicology due to their ability to handle complex datasets [121]. Studies have shown that SVMs can accurately classify compounds based on human intestinal absorption, using molecular descriptors such as topological polar surface area and predicted octanol-water distribution coefficient. SVMs have demonstrated competitive performance compared to other state-of-the-art techniques in pharmaceutical classification tasks [135]. However, challenges remain in fully integrating predictive ADMET modelling into drug discovery processes, and there is a need for larger, high-quality datasets and improved molecular descriptors to fully realize the potential of machine learning techniques in this field [136].

## Section: 5. Overview of common machine learning techniques in ADME-Tox prediction › 5.1. Traditional machine learning approaches › 5.1.3. K-nearest neighbours

The k-nearest neighbours (k-NN) algorithm has shown promise in predicting various aspects of absorption, distribution, metabolism, excretion, and toxicity (ADMET) properties of chemicals. K-nearest neighbour is a simple and intuitive supervised learning method used for classification and regression tasks. It operates on the principle that objects (e.g. data points) with similar characteristics are often found near each other in the feature space. The k-NN algorithm classifies or predicts the label of a new data point by considering the labels of its k-nearest neighbours, where k is a user-defined parameter [137]. Studies have demonstrated its effectiveness in predicting sub-chronic oral toxicity in rats [138], acute contact toxicity of pesticides in honeybees [139], and chronic toxicity based on acute toxicity data [140]. These k-NN models have achieved reasonnable accuracy, with external validation results ranging from 65 to 77 % for different endpoints. The approach has been valuable in prioritizing chemical safety assessments and potentially reducing animal testing [139]. Incorporating ADMET screening earlier in the drug discovery process has become crucial for identifying poorly behaved compounds and improving the success rate of new chemical entities reaching the market. These computational models can play a significant role in predicting toxicity and supporting future risk assessments.

## Section: 5. Overview of common machine learning techniques in ADME-Tox prediction › 5.1. Traditional machine learning approaches › 5.1.4. Gradient boosting machines and extreme gradient boosting

Recent studies have demonstrated the effectiveness of gradient boosting algorithms in predicting Absorption, Distribution, Metabolism, Excretion, and Toxicity (ADMET) properties of drug compounds. Tian et al. [141] developed ADMET boost, a web server utilizing extreme gradient boosting (XGBoost) for accurate ADMET prediction, achieving top rankings in multiple benchmark tasks. An et al. [142] compared various machine learning models, including XGBoost and light gradient boosting machines (LGBM), for predicting estrogen receptor alpha (ERα) bioactivity and ADMET properties, finding high accuracy and robustness in their approach. Li et al. [143] applied LGBM to predict ADMET properties of anti-breast cancer compounds, reporting superior performance compared to other algorithms. These studies highlight the potential of gradient boosting techniques in drug discovery and development, offering accurate predictions of crucial pharmacokinetic and toxicological properties. The integration of such models into web-based tools further enhances their accessibility and utility in the biopharmaceutical field.

## Section: 5. Overview of common machine learning techniques in ADME-Tox prediction › 5.2. Deep learning approaches › 5.2.1. Fully Connected neural networks

Fully connected neural networks (FCNNs) and other artificial neural network architectures have shown significant potential in predicting ADMET properties of chemical compounds. These models can achieve high accuracy in predicting various toxicological parameters, with some studies reporting accuracies between 74 and 98% [144]. FCNNs have demonstrated superior performance in multitask learning approaches, improving predictive quality for properties like human metabolic stability [145]. Neural networks outperform traditional methods in predicting several ADMET properties, including acute toxicity, carcinogenicity, and hepatic clearance [144]. The application of neural networks in ADMET prediction allows for early consideration of these properties in drug development, potentially reducing late-stage failures and improving pharmaceutical industry efficiency [146]. As artificial intelligence continues to advance, neural networks are expected to play an increasingly important role in toxicology research and drug discovery [147].

## Section: 5. Overview of common machine learning techniques in ADME-Tox prediction › 5.2. Deep learning approaches › 5.2.2. Convolutional neural networks

Convolutional neural networks (CNNs) and other deep learning models have shown promising results in predicting absorption, distribution, metabolism, excretion, and toxicity (ADMET) properties of drug candidates. These models can analyse large datasets to identify relevant features and evaluate hidden trends among multiple ADMET parameters [145]. Deep neural networks have demonstrated superior performance compared to traditional methods in predicting properties such as microsomal stability, passive permeability, and log D [148]. Various ADMET prediction models have been developed and made publicly available, offering rapid assessments of important drug properties like cytotoxicity, mutagenicity, and drug-drug interactions [149]. The integration of ADMET screening earlier in the drug discovery process helps eliminate poorly behaved compounds, reducing costly failures in later stages[5]. As artificial intelligence continues to advance, neural networks are expected to play an increasingly important role in toxicology research and the development of accurate biosensors for toxic substance detection [147].

## Section: 5. Overview of common machine learning techniques in ADME-Tox prediction › 5.2. Deep learning approaches › 5.2.3. Recurrent neural networks and long short-term memory

Recent research has explored the application of recurrent neural networks (RNNs) and long short-term memory (LSTM) models in predicting and analysing ADMET properties of drugs and peptides. Wang et al. [15] demonstrated that LSTM networks can accurately model complex pharmacokinetic-pharmacodynamics relationships . Wenzel et al. [145] developed multitask deep neural networks for predicting multiple ADME-Tox properties simultaneously, showing improved performance over single-task models. González-Díaz [150] reviewed multi-output QSPR models for predicting ADMET processes, including drug-target interactions and nanoparticle toxicity. In the realm of peptide design, Müller et al. [151] utilized LSTM RNNs to generate novel antimicrobial peptide sequences with a higher predicted activity rate compared to randomly sampled sequences. These studies highlight the potential of RNN and LSTM models in drug discovery, ADMET prediction, and peptide design, offering promising tools for pharmaceutical research and development.

## Section: 5. Overview of common machine learning techniques in ADME-Tox prediction › 5.2. Deep learning approaches › 5.2.4. Graph neural networks

Recent advancements in Graph neural networks (GNNs) have significantly improved the prediction of ADMET properties in drug discovery. De Carlo et al. [152] developed an attention-based GNN that processes molecular information from substructures to whole molecules, effectively predicting ADMET properties without relying on molecular descriptors. Aburidi and Marcia [153] introduced an optimal transport-based graph kernel approach that outperformed state-of-the-art GNNs on multiple ADMET datasets. Feinberg et al. [31] demonstrated that graph convolutions applied to explicit molecular representations achieve unprecedented accuracy in ADMET prediction, enabling both interpolation and extrapolation to new chemical spaces. Wenzel et al. [145] explored multitask deep neural networks for ADME-Tox modelling, showing improved performance compared to single-task models and introducing a "response map" visualization technique for interpreting model predictions. These studies collectively highlight the potential of GNNs and deep learning approaches to enhance ADMET property prediction in drug development.

## Section: 5. Overview of common machine learning techniques in ADME-Tox prediction › 5.3. Generative models for ADMET-optimized molecule design › 5.3.1. Variational autoencoders and generative adversarial networks

Variational autoencoders (VAEs) and generative adversarial networks (GANs) are powerful machine learning models with applications in various fields. Adversarial Variational Bayes (AVB) unifies VAEs and GANs, allowing for more expressive inference models [154]. The connection between VAEs, GANs, and minimum Kantorovitch estimators has been explored from an optimal transport perspective [155]. In the field of drug development and toxicology, multi-output QSPR models have been used to predict absorption, distribution, metabolism, excretion and toxicity (ADMET) properties for drugs, pollutants, and nanoparticles [150]. ADME profiling has significantly reduced pharmacokinetic drug failures in clinical trials and has become crucial for safety and toxicity prediction across industries [156]. The integration of ADME information with in vitro results and computer modelling is essential for developing quantitative in vitro to in vivo extrapolations and integrated testing strategies in toxicology [156].

## Section: 5. Overview of common machine learning techniques in ADME-Tox prediction › 5.3. Generative models for ADMET-optimized molecule design › 5.3.2. Reinforcement learning (RL)

Generative AI models combined with reinforcement learning can efficiently design drug candidates with suitable ADMET properties [157]. Quantum-informed molecular representation learning has improved ADMET property prediction, achieving state-of-the-art results in multiple tasks [158]. The REMEDI framework uses reinforcement learning to model bile acid metabolism adaptations in primary sclerosing cholangitis, demonstrating potential for exploring treatments [159]. RL is emerging as a powerful tool in drug discovery and development, offering potential to accelerate and optimize the process. RL algorithms can improve sample efficiency and policy optimization for de novo drug design [160]. These approaches enable simultaneous optimization of molecules for multiple goals through structure-based drug design and high-throughput screening; one such example is where RF has been applied to optimize failed anticancer drugs by considering multiple properties simultaneously, including binding affinity and toxicity profiles [161].

## Section: 6. Recent developments in ADMET modeling › 6.1. Integration of machine learning methods with physiologically-based pharmacokinetic and quantitative structure-activity relationship models

Physiologically-based pharmacokinetic (PBPK) models are mathematical representations of how chemicals enter the body through various routes such as inhalation, ingestion, or dermal exposure. These models describe how much of the chemical enters the bloodstream, its distribution among different tissues, and how the body metabolizes and eliminates it [162]. They incorporate information about the body's anatomy, physiology, and biochemical processes. PBPK models can range from simple versions with few features to complex ones that capture intricate details about chemical movement and fate in the body [163]. However, creating PBPK models for new chemicals is challenging due to their complexity and the numerous parameters involved [163]. To address this, some researchers have proposed an integrated approach that combines a simplified PBPK model with machine learning based quantitative structure-activity relationship (QSAR) models [164]. This integrated approach aims to estimate plasma and tissue concentrations, as well as various pharmacokinetic (PK) parameters, by leveraging databases containing in vivo and in vitro data along with the structural and physicochemical properties of selected compounds. ML models are trained using these databases to predict ADME parameters, which are then incorporated into the PBPK model to simulate time-concentration profiles and calculate PK parameters such as Area under the Curve (AUC) and maximum concentration (Cmax). The performance of the integrated ML-based PBPK model is assessed against in vivo PK data, and if satisfactory, the model can be used to generate simulation data for further refinement and validation [165].

This approach aims to enhance efficiency in drug development and reduce animal testing [166]. A novel computational platform combining ML and PBPK models has demonstrated improved accuracy in predicting pharmacokinetic profiles without experimental data, potentially accelerating early drug discovery [167]. Additionally, adapting PBPK models for ML applications has shown promise in recapitulating summary pharmacokinetic parameters, although limitations in the underlying PBPK models may affect prediction accuracy [169]. Despite challenges such as the need for diverse training data and improved interpretability of ML models, the integration of ML/AI approaches with PBPK modelling is expected to facilitate more efficient and robust ADMET predictions for a wide range of chemicals [165].

## Section: 6. Recent developments in ADMET modeling › 6.2. Generalization › 6.2.1. Multi-task learning

While each ADMET parameter can be studied independently, they are interconnected and influence each other throughout the drug development process. Therefore, ADMET is not a sequential process but rather a holistic approach that considers the interplay between absorption, distribution, metabolism, excretion, and toxicity to predict drug behaviour accurately [14]. Considering this, it would be practical to develop a reliable multitask model that could simultaneously predict multiple ADME endpoints. Despite the advancements made by classical single-task learning in predicting individual ADMET endpoints using abundant labelled data, multi-task learning (MTL) emerges as a promising paradigm, offering a solution that reduces reliance on endpoint labels while simultaneously predicting multiple ADMET endpoints [169]. By leveraging shared information and underlying correlations between different ADMET properties, MTL provides a more comprehensive and efficient framework for predictive modelling in ADMET studies. For example, Wenzel et al. [145] introduced an industrialized approach for optimizing deep neural network (DNN) models to predict ADME-Tox properties, utilizing up to 50,000 compounds from diverse databases. The study highlights the significance of DNN hyperparameters and molecular descriptors in model success, demonstrating the superiority of multitask DNNs in predictive performance across various datasets. For instance, multitask DNNs showed improved predictive quality compared to single-task models, with an increase in R2 from 0.6 to 0.7 for human metabolic stability data in external validation sets. In another study, S. Zhang et al. [170] employ machine learning techniques, including random forest (RF) and artificial neural network (ANN), to develop multi-task (MT) models for predicting tissue-to-blood partition coefficient (Ptb) values across various mammalian tissues. Compared to single-task (ST) models, the MT approach consistently outperforms, with ANN-based MT models exhibiting the highest prediction accuracy, showcasing determination coefficients ranging from 0.704 to 0.886 and low root mean square errors and mean absolute errors across multiple endpoints. The study by Walter et al. [171] investigates multi-task machine learning models for predicting ADME and animal PK endpoints using in-house data of 28 endpoints. It reveals the superior performance of multi-task graph-based neural networks, attributing this success to the influence of endpoints with larger data sets, such as physicochemical endpoints and microsomal clearance.

## Section: 6. Recent developments in ADMET modeling › 6.2. Generalization › 6.2.2. Transfer learning

Developing highly accurate models is essential for swiftly evaluating pharmacokinetic (PK) properties during the drug development process. Traditional models, which rely on a substantial amount of existing domain knowledge and constructing these models is rather time-consuming; thus, with transfer learning, which aims to generalize the knowledge gained from one task to another task to enhance its applicability and decision-making. Leveraging the common features learned from a similar source domain, transfer learning has been demonstrated to be able to develop the models without learning from scratch [172]. Ye et al. [173] introduced an integrated transfer learning and multitask learning approach utilizing three deep neural networks to predict pharmacokinetic parameters. The consensus model, DeepPharm utilized transfer learning from three pre-trained deep neural networks: DeepPharm-BA, DeepPharm-PPBR, and DeepPharm-VDss&HL and achieved the highest accuracies of 27.78, 44.22, 63.33 and 68.39 % in predicting oral bioavailability (BA), plasma protein binding rate (PPBR), apparent VDss and elimination half-life (HL), respectively, outperforming conventional machine learning methods. In a study proposed by Abbasi et al. [174] explores the transfer of knowledge across different physiological and biophysical domains, evaluating its effectiveness in predicting compound activity with limited labelled data. By leveraging source datasets such as Tox21, ToxCast, SIDER, HIV, and BACE, the proposed approach transfers knowledge between related or semi-related tasks, demonstrating improved performance in target tasks. Additionally, the study highlighted the importance of selecting appropriate source datasets and revealed that knowledge transfer between tasks within the same category yields better results compared to tasks from different categories. In another study S. Wang et al. [175] introduced a semi-supervised model named SMILES-BERT for molecular property prediction, utilizing deep learning techniques and a large-scale of unlabelled data. The model utilized an attention mechanism-based Transformer Layer and underwent pre-training via a Masked SMILES Recovery task on the ZINC dataset. This pre-training process significantly improved the model's generalization capability, as evidenced by achieving an exact recovery rate of 82.85 % on the validation dataset. During fine-tuning, the model was trained using various learning rates and optimization strategies, resulting in high prediction performance across three datasets: log P, PM2, and PCBA-686978. SMILES-BERT surpassed state-of-the-art methods, highlighting its ability to effectively leverage unlabelled data and its potential for molecular property prediction tasks with varying dataset sizes and properties. Similarly, X. Li and Fourches [176] introduced MolPMoFiT, an inductive transfer learning method for molecular activity prediction in Quantitative Structure-Activity Relationship (QSAR) modelling. The approach utilized a pre-trained Molecular Structure Prediction Model (MSPM) using one million unlabelled molecules from ChEMBL, fine-tuning it for specific QSAR tasks. This method achieved strong performance across four benchmark datasets (lipophilicity, FreeSolv, HIV, and blood-brain barrier penetration), when compared to state-of-the-art techniques reported in the literature. The approach showcased its potential for improving next-generation QSAR models, particularly for smaller datasets with challenging endpoints.

## Section: 6. Recent developments in ADMET modeling › 6.2. Generalization › 6.2.3. Pretrained models

Recent advancements in machine learning have significantly improved the prediction of absorption, distribution, metabolism, excretion, and toxicity (ADMET) properties in drug discovery. Pretrained models and self-supervised learning approaches have shown promising results in this field. Zhang et al. [177] developed HelixADMET, a system incorporating self-supervised learning that achieved a 4 % improvement over existing ADMET systems. Jung et al. [178] utilized the pretrained ChemBERTa model for ADMET prediction, exploring various architectures. Wenzel et al. [179] demonstrated the effectiveness of multitask deep neural networks in predicting ADME-Tox properties, showing improved performance compared to single-task models. Kumar et al. [62] implemented an enterprise-wide predictive model, gTPP, which outperformed commercial ADME models and automatic model builders. These studies highlight the potential of advanced machine learning techniques, particularly pretrained models and self-supervised learning, in enhancing ADMET property prediction and facilitating early-stage drug development.

## Section: 6. Recent developments in ADMET modeling › 6.3. Interpretable and explainable ADMET models

As artificial intelligence and machine learning models grow in complexity, a significant challenge has surfaced within the field: the absence of transparency and interpretability [180]. While these models demonstrate remarkable predictive capabilities, elucidating the rationale behind their predictions remains difficult. This absence of interpretability can pose challenges for researchers and regulatory authorities in relying on AI and ML-driven predictions, particularly in drug discovery [157]. Moreover, assessing and prioritizing discovered targets or compounds becomes cumbersome without understanding the decision-making process of AI algorithms. In order to foster trust in AI/ML systems, it is imperative that models are transparent and understandable to users thus efforts are being made to enhance the interpretability by embracing explainable artificial intelligence (XAI), which tries to offer clear and intelligible justifications for the predictions made by AI and ML models of machine learning models in ADME studies [181]. Interpretability in AI exposes the inner workings of these systems, allowing for the detection of issues like information leakage, model bias, robustness, and causality [182].

## Section: 6. Recent developments in ADMET modeling › 6.3. Interpretable and explainable ADMET models › 6.3.1. Local interpretable model-agnostic explanations and Shapley additive explanations

Recent research has explored the application of explainable artificial intelligence (XAI) techniques, particularly LIME (Local Interpretable Model-agnostic Explanations) and SHAP (SHapley Additive exPlanations), in interpreting complex machine learning models for medical applications such as Alzheimer's disease detection [183]. The paper introduced LIME, a method designed to provide interpretable explanations for complex machine learning models by approximating their behaviour locally. LIME achieves this by generating local surrogate models around specific instances, enabling users to understand model predictions on individual data points. A novel extension, KG-LIME, has been developed to predict individualized risk of adverse drug events in multiple sclerosis therapy, leveraging knowledge graphs for more interpretable explanations [184]. Another study by Gabbay et al. [185] presents a LIME-based explainable machine learning model for predicting the severity level of COVID-19 diagnosed patients. By employing LIME, the model provides interpretable insights into the factors influencing severity prediction, aiding in understanding and decision-making in COVID-19 management.

Another explainable technique called SHAP (SHapley Additive exPlanations) methodology has emerged as a powerful tool for interpreting machine learning models in ADMET prediction and drug design. SHAP enables the identification and prioritization of molecular features that influence compound activity and potency predictions, regardless of model complexity [186]. This approach has been applied to various ADMET properties, including metabolic stability [187] and general ADME profiles [188]. SHAP analysis can be used to interpret predictions from diverse machine learning algorithms, such as random forests, support vector machines, and deep neural networks [189]. By providing insights into the contribution of specific structural features to model outcomes, SHAP aids in compound optimization and supports experts in drug candidate selection [188]. This interpretability enhances confidence in machine learning applications within pharmaceutical research.

These advancements demonstrate the growing importance of interpretable machine learning models in drug discovery and optimization, offering researchers valuable tools for understanding and improving ADMET predictions.

## Section: 7. Machine learning techniques in clinical trial designs

In silico prediction of absorption, distribution, metabolism, and excretion (ADME) properties, as well as model-informed drug discovery and development (MID3)1 strategies. MID3 includes providing quantitative predictions for aspects such as pharmacokinetics, pharmacodynamics, efficacy and safety end points, and disease progression [190]. By leveraging these models, researchers can optimize dosing strategies, inform clinical trial designs, and obtain robust quantitative assessments regarding drug efficacy and safety. The mainstay of modelling activities for drug development includes an empirical compartmental model built from sparsely sampled PK/PD datasets [191]. In this respect, AI/ML provides new ways for pharmacometricians to think about their models.

There have been a number of approaches proposed in using feed-forward NNs [192] for modelling of PK(/PD) data. However, these did not tackle the more complex problem of extrapolating outside the range of observed data. In fact, the main limitation of such models is that they do not explicitly encode causality relationships among dose, PKs, and PDs and, hence, cannot enable robust predictions of new dosing regimens.

In the 1990s, the availability of biological reagents and liquid chromatography mass spectrometry dramatically reduced the attrition of small-molecule drugs due to PK considerations. Currently, attrition due to poor clinical exposure is rare, with preclinical toxicology, clinical intolerability, or insufficient efficacy being the major sources of attrition [7]. Reagents, such as microsomes, cryopreserved hepatocytes, recombinant drug metabolizing enzymes, and cells overexpressing specific transporters, have enabled drug metabolism and PK departments to generate large quantities of in vitro ADME data over the last 15 to 20 years. These data serve two specific functions: first, in vitro data related to metabolic stability, plasma protein binding, permeability, efflux, and CYP inhibition can be used for the design (i.e. prior to synthesis) of small molecules with superior ADME properties, along with other parameters, such as biochemical and cellular potency and selectivity data; second, archived data can be used to build ML models to predict these properties (In silico optimization).

## Section: 8. Data sources and challenges in machine learning based ADME-Tox prediction › 8.1. Key databases for ADME-Tox data

The development of predictive models for ADME-Tox properties is crucial in drug discovery, but it relies heavily on the availability and quality of data. Several databases and resources have emerged to address this need. Canault et al. [193] proposed an interactive network of databases to facilitate finding relevant ADME-Tox data sources. Ekins and Williams [194] advocated for making preclinical ADME-Tox data freely available on the web, suggesting the expansion of databases like ChemSpider. Pawar et al. [195] conducted a comprehensive review of over 900 databases relevant to in silico toxicology, categorizing them based on various criteria. To assist in compound filtering, Miteva et al. [196] developed FAF-Drugs, an online service that allows users to process their compound collections using simple ADME-Tox filtering rules. These resources collectively aim to improve drug development processes by enhancing access to and utilization of ADME-Tox data.

## Section: 8. Data sources and challenges in machine learning based ADME-Tox prediction › 8.2. Data quality and availability issues

Data quality issues have become increasingly critical in the era of big data, affecting various domains and applications [197]. These issues encompass multiple dimensions, including accuracy, completeness, consistency, and currency [198]. Poor data quality can significantly impact organizational efficiency and decision-making, leading to financial losses and credibility issues [198]. Data cleaning, a crucial process in addressing these problems, is particularly important when integrating heterogeneous data sources and in data warehouse environments [200]. Researchers have proposed various methodologies and techniques to tackle data quality challenges, drawing from fields such as data mining, probability theory, and machine learning [201]. These approaches often involve the use of data quality rules and algorithms for detecting and correcting errors, as well as managing issues like data deduplication and information completeness [198].

## Section: 8. Data sources and challenges in machine learning based ADME-Tox prediction › 8.3. Integration of multi-omics data

Multi-omics data integration is crucial for understanding complex biological systems and improving clinical outcomes. Various strategies have been developed, including early, mixed, intermediate, late, and hierarchical integration approaches [202]. Machine learning algorithms have been applied to multi-omics data to produce diagnostic and classification biomarkers [203]. Tools like OmicsNet use multilayer networks to integrate heterogeneous omics data, facilitating functional analysis, biomarker discovery, and drug response prediction [204]. The integration of multi-omics data has applications in disease subtyping, biomarker prediction, and deriving biological insights [205]. Despite progress in the field, challenges remain in developing computational methods for the proper integration of multi-omics datasets [204]. Researchers have developed numerous software tools and methods to address these challenges and improve clinical outcome predictions [205].

## Section: 8. Data sources and challenges in machine learning based ADME-Tox prediction › 8.4. Privacy and ethical concerns

Privacy and ethical concerns in research and technology adoption have gained significant attention. Key issues include ensuring meaningful user notice, access control, data anonymization, and algorithm validation to prevent harm [206]. The increasing use of technology in learning processes raises concerns about learner tracking, necessitating principles for trust, accountability, and transparency in learning analytics [207]. RFID technology, while promising for data collection, presents challenges for privacy due to its ability to track individual products [208]. Researchers are exploring situations where privacy may not always be optimal, considering the balance between privacy and other competing values in research and design [209]. These studies emphasize the importance of addressing ethical and privacy concerns in various contexts, from social-behavioural research to technological implementations, to ensure responsible data use and protect individuals' rights.

## Section: 9. Case studies of machine learning in ADME-Tox prediction › 9.1. Successful machine learning applications in drug development

Machine learning techniques are increasingly applied across various stages of drug discovery and development to accelerate the process and reduce failure rates [3]. ML approaches have shown promise in target validation, biomarker identification, and digital pathology analysis [3]. Specific applications include SNP discoveries, drug repurposing, virtual screening, lead identification, QSAR modelling, and ADMET analysis [210]. Algorithms such as support vector machines, random forests, and artificial neural networks have demonstrated success in predicting human intestinal absorption and identifying novel compounds for cancer treatment [210]. The Janssen gTPP model, employing graph convolutional neural networks, has shown superior performance in predicting early ADME properties compared to commercial models [62]. However, challenges remain in the interpretability and repeatability of ML-generated results, necessitating systematic data generation and validation of ML approaches [3,4].

## Section: 9. Case studies of machine learning in ADME-Tox prediction › 9.2. Real-world use cases

Machine learning techniques have been increasingly applied to predict ADME-Tox properties of drug candidates, helping to streamline the drug discovery process and reduce costs [211]. These computational methods rely heavily on high-quality experimental data to generate accurate models. Flexible approaches combining multiple technologies, such as Bio-Rad's KnowItAll ADME/Tox system with support vector machine platforms, have shown promise in improving prediction performance and overcoming limitations of individual methods [212]. Despite the potential of in silico approaches, regulatory requirements for ADME and toxicokinetic data vary widely across different chemical frameworks, with some areas having minimal or no requirements [213]. Incorporating ADME/TK information early in toxicity testing can enhance study design, support 4R goals, and ultimately improve risk assessment and characterization of chemical safety [213].

## Section: 9. Case studies of machine learning in ADME-Tox prediction › 9.3. Drug repurposing applications

Drug repurposing, the process of using existing drugs for new indications, has gained attention due to its potential to reduce costs and development time [214]. This approach leverages existing ADMET data to expedite drug development [215]. Chemical structure modifications and nanotechnology applications can improve ADME-Tox properties of drug candidates, enhancing absorption, permeability, distribution, and stability while reducing toxicity [216]. ABC transporters play a crucial role in ADMET, influencing drug resistance and passage through cellular barriers [217]. Various models and assay systems, including in vitro, in vivo, and in silico approaches, can be used to analyze drug interactions with ABC transporters and predict ADMET profiles [217]. These strategies collectively contribute to more efficient drug discovery and development processes, potentially leading to improved therapeutic outcomes.

## Section: 10. Challenges and limitations in machine learning based ADME-Tox prediction › 10.1. Data scarcity and imbalance

Machine learning techniques have been increasingly applied to ADME-Tox prediction, offering promising tools for toxicity screening and compound profiling [211]. However, data scarcity and class imbalance pose significant challenges in developing accurate models. Studies have shown that class imbalance can significantly impact model performance, particularly affecting recall and F1 scores [218]. To address these issues, various strategies have been explored, including resampling methods and transfer learning. Resampling techniques have demonstrated improvements in sensitivity and specificity for nuclear receptor profiling [219]. Additionally, transfer learning approaches have shown success in predicting drug activity and toxicity for targets with insufficient data by leveraging information from data-rich targets [220]. These methods, along with appropriate evaluation metrics and hyperparameter tuning, can enhance the performance of toxicity classification models and improve predictions for understudied targets [221].

## Section: 10. Challenges and limitations in machine learning based ADME-Tox prediction › 10.2. Model interpretability and trustworthiness

Data scarcity and imbalance pose significant challenges for deep learning models, particularly in high-stakes domains [222]. These issues can lead to reduced model performance and trustworthiness. To address data scarcity, various techniques have been proposed, including transfer learning, self-supervised learning, and generative adversarial networks [222]. For imbalanced datasets, interpretable machine learning approaches can help identify class prototypes, sub-concepts, and outlier instances [223]. However, class imbalance can adversely affect the stability of interpretation methods like LIME and SHAP, particularly in credit scoring applications [224]. When evaluating model interpretability and trustworthiness, it's crucial to consider the inductive bias of different algorithms. For instance, in generalized additive models (GAMs), tree-based approaches offer a good balance of sparsity, fidelity, and accuracy, making them potentially more trustworthy [225].

## Section: 10. Challenges and limitations in machine learning based ADME-Tox prediction › 10.3. Generalization across chemical space

Machine learning models in chemistry often face challenges due to data scarcity and imbalance, which can lead to overfitting and poor generalization. Several strategies have been proposed to address these issues. Farthest point sampling in chemical feature spaces can generate well-distributed training datasets, enhancing model performance across various algorithms [226]. Latent space enrichment, combining disparate data sources in joint prediction tasks, improves prediction in data-scarce applications [227]. Similarity-based machine learning enables on-the-fly data selection and model training for specific queries, requiring only a fraction of data to achieve competitive performance [228]. When dealing with class imbalance and data scarcity in toxicity classification models, appropriate resampling algorithms, evaluation metrics, and hyperparameter tuning are crucial for optimal performance [218]. These approaches collectively offer promising solutions to enhance machine learning model performance in chemistry, particularly when faced with limited or imbalanced datasets.

## Section: 10. Challenges and limitations in machine learning based ADME-Tox prediction › 10.4. Model validation and regulatory acceptance

Data scarcity and class imbalance pose significant challenges in developing and validating machine learning models, particularly for safety-critical applications. These issues can affect model performance metrics and potentially invalidate underlying assumptions [229]. Studies have shown that class imbalance significantly impacts recall and F1 scores, while hyperparameter tuning can improve performance on imbalanced datasets [218]. To address data scarcity, various techniques have been proposed, including transfer learning, self-supervised learning, and generative adversarial networks [222]. For regulatory acceptance of models, it is crucial to consider model domain, uncertainty, validity, and predictability [230]. Researchers emphasize the importance of using appropriate evaluation metrics, tuning hyperparameters, and ensuring the trustworthiness of training datasets [222]. These considerations are essential for developing reliable and effective models in fields such as toxicity prediction, aviation, and medical imaging.

## Section: 11. Future directions and innovations › 11.1. Integrating AI with experimental approaches

Recent research highlights the integration of AI with experimental approaches in various fields. AI and ML models can serve as fast surrogates for time-consuming experiments or computational models, enhancing predictive capabilities while reducing data requirements [231]. In molecular design, AI techniques are being combined with experimental validation and chemistry automation, although these efforts are still in early stages [232]. The development of cell therapies is benefiting from AI and ML methods, which can generate predictive models and design rules based on high-throughput screening data [233]. The integration of AI with geography, termed GeoAI, is providing novel approaches for addressing environmental and societal problems [234]. Future directions include the automatic discovery of physical laws, active learning for optimal experiment design, and the integration of multi-fidelity data from various computational models and experimental instruments [231].

## Section: 11. Future directions and innovations › 11.2. Advances in explainable AI

Explainable AI (XAI) is an emerging field aimed at increasing the interpretability and transparency of machine learning models. Recent research highlights the integration of diverse approaches to advance XAI. Experimental psychology methods can contribute to XAI by applying cognitive modelling techniques to artificial black boxes [235]. Formal methods, such as algebraic decision diagrams, can enhance explainability by providing precise characterizations of AI outcomes [236]. The arts offer valuable contributions to address limitations in explainable AI, fostering collaborations between scientists and artists to investigate human-machine entanglements [237]. Current XAI approaches in deep learning encompass various applications, evaluation metrics, and challenges, with ongoing research focusing on improving trust, accountability, and interoperability of complex neural networks [238]. These multidisciplinary efforts aim to create more transparent and understandable AI systems across diverse domains.

## Section: 11. Future directions and innovations › 11.3. Potential of quantum computing and machine learning

Recent research explores the synergies between quantum computing, AI and ML. Quantum computing shows significant potential in revolutionizing drug discovery and development. It offers faster and more accurate molecular characterization through quantum simulation, outperforming classical quantum chemistry methods [239]. Quantum machine learning (QML) algorithms are emerging as strong competitors to classical approaches, particularly in the early stages of drug discovery for identifying novel drug-like molecules [240]. QC's ability to perform complex calculations efficiently could accelerate the drug discovery process, making it more cost-effective and accurate [241]. Recent applications of QC in drug development include protein structure prediction, molecular docking, quantum simulation, and quantitative structure-activity relationship models [242]. While current quantum devices are still susceptible to noise and errors, hybrid quantum-classical approaches and quantum-inspired devices like quantum annealers have demonstrated quantum advantage [242]. Further research and development are needed to fully leverage QC's potential in drug discovery [241].

## Section: 11. Future directions and innovations › 11.4. Regulatory and industry trends

Artificial intelligence is revolutionizing drug discovery and preclinical research by integrating with experimental approaches. AI techniques, such as machine learning and neural networks, are improving the efficiency and effectiveness of drug candidate identification and optimization [243]. The integration of virtual and experimental screening methods, including high-throughput screening and DNA-encoded libraries, is enhancing early-phase drug discovery [243]. AI combined with new experimental technologies is expected to make drug discovery faster, cheaper, and more effective [244]. Additionally, integrated approaches to testing and assessment (IATA) are being developed to replace animal testing in toxicology, incorporating in vitro, in-silico, and in vivo methods [245]. While AI-driven approaches offer significant benefits, challenges remain, such as the need for high-quality databases and addressing regulatory requirements [245].

## Section: 12. Conclusion

The application of artificial intelligence and machine learning in absorption, distribution, metabolism, excretion and toxicity (ADMET) predictions has revolutionized drug discovery and development. Traditional in vitro and in vivo approaches, though essential, are often time-consuming, costly, and sometimes unreliable in predicting human responses. AI and ML-driven computational methods provide a faster, more accurate, and cost-effective alternative by leveraging large-scale datasets and predictive modelling techniques such as deep learning, support vector machines, and ensemble learning.

Molecular descriptors, ranging from 0D to 4D, alongside feature selection methods like filter, wrapper, and embedded techniques, play a crucial role in refining model accuracy and interpretability. These advancements facilitate high-throughput virtual screening, enabling the early identification of drug candidates with favourable pharmacokinetic and toxicity profiles, thereby reducing the likelihood of late-stage failures. Additionally, deep learning architectures have shown significant promise in predicting complex metabolic and toxicity pathways.

However, challenges persist, including data quality, model generalizability, and regulatory acceptance. Standardized datasets, improved interpretability of AI models, and rigorous validation protocols are necessary for broader adoption. Regulatory agencies must establish clear guidelines for integrating AI-driven ADMET predictions into drug development workflows.

Moving forward, integrating AI-driven predictions with experimental validation will be key to optimizing drug development pipelines. By overcoming current limitations and fostering collaboration between computational and experimental research, AI and ML can drive more efficient, precise, and cost-effective drug discovery, ultimately leading to safer and more effective therapeutics.

## Section: Funding Statement

This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit sectors.


---

# LightRAG: Simple and Fast Retrieval-Augmented Generation

- **Authors:** Zirui Guo, Lianghao Xia, Yanhua Yu, Tu Ao, Chao Huang
- **Issuer:** Findings of the Association for Computational Linguistics: EMNLP (Findings of EMNLP)
- **Type:** Scientific article
- **Published:** 2025-01-01
- **Language:** en
- **DOI:** 10.18653/v1/2025.findings-emnlp.568
- **Source:** https://doi.org/10.18653/v1/2025.findings-emnlp.568
- **Licence:** CC-BY

## Page 1

Findings of the Association for Computational Linguistics: EMNLP 2025, pages 10746–10761
November 4-9, 2025 ©2025 Association for Computational Linguistics
LightRAG: Simple and Fast Retrieval-Augmented Generation
Zirui Guo1, Lianghao Xia1, Yanhua Yu2, Tu Ao2, Chao Huang1*
University of Hong Kong1
Beijing University of Posts and Telecommunications2
zrguo101@hku.hk aka_xia@foxmail.com chaohuang75@gmail.com
Abstract
Retrieval-Augmented Generation (RAG) sys-
tems enhance large language models (LLMs)
by integrating external knowledge sources, en-
abling more accurate and contextually relevant
responses tailored to user needs.
However,
existing RAG systems have significant limi-
tations, including reliance on flat data repre-
sentations and inadequate contextual aware-
ness, which can lead to fragmented answers
that fail to capture complex interdependencies.
To address these challenges, we propose Ligh-
tRAG, a novel framework that incorporates
graph structures into text indexing and retrieval
processes. This innovative approach employs a
dual-level retrieval system that enhances com-
prehensive information retrieval from both low-
and high-level knowledge discovery. Addition-
ally, the integration of graph structures with
vector representations facilitates efficient re-
trieval of related entities and their relationships,
significantly improving response times while
maintaining contextual relevance. This capa-
bility is further enhanced by an incremental
update algorithm that ensures the timely inte-
gration of new data, allowing the system to re-
main effective and responsive in rapidly chang-
ing data environments. Extensive experimental
validation demonstrates considerable improve-
ments in retrieval accuracy and efficiency com-
pared to existing approaches. LightRAG is pub-
licly available as an open-source framework at:
https://github.com/HKUDS/LightRAG.
1
Introduction
Retrieval-Augmented Generation (RAG) systems
have been developed to enhance large language
models (LLMs) by integrating external knowledge
sources (Sudhi et al., 2024; Es et al., 2024; Salemi
et al., 2024). This innovative integration allows
LLMs to generate more accurate and contextually
relevant responses, significantly improving their
*Corresponding Author: Chao Huang
utility in real-world applications. By adapting to
specific domain knowledge (Tu et al., 2024), RAG
systems ensure that the information provided is
not only pertinent but also tailored to the user’s
needs. Furthermore, they offer access to up-to-date
information (Zhao et al., 2024), which is crucial in
rapidly evolving fields. Chunking plays a vital role
in facilitating the retrieval-augmented generation
process (Lyu et al., 2024). By breaking down a
large external text corpus into smaller, more man-
ageable segments, chunking significantly enhances
the accuracy of information retrieval. This enables
more targeted similarity searches, ensuring that the
retrieved content is directly relevant to user queries.
However, existing RAG systems have key limi-
tations that hinder their performance. First, many
methods rely on flat data representations, restrict-
ing their ability to understand and retrieve infor-
mation based on intricate relationships between
entities. Second, these systems often lack the con-
textual awareness needed to maintain coherence
across various entities and their interrelations, re-
sulting in responses that may not fully address user
queries. For example, consider a user asking, “How
does the rise of electric vehicles influence urban air
quality and transportation infrastructure?” Existing
RAG methods might retrieve separate documents
on electric vehicles, air pollution, and transporta-
tion challenges but struggle to synthesize them into
a cohesive response. They may fail to explain how
the adoption of electric vehicles can improve air
quality, which in turn could affect public trans-
portation planning. As a result, the answer may
be fragmented and does not adequately capture the
complex inter-dependencies among these topics.
To address these limitations, we propose incor-
porating graph structures into text indexing and
relevant information retrieval. Graphs are particu-
larly effective at representing the interdependencies
among different entities (Rampášek et al., 2022),
which enables a more nuanced understanding of re-
10746

## Page 2

lationships. The integration of graph-based knowl-
edge structures facilitates the synthesis of informa-
tion from multiple sources into coherent and con-
textually rich responses. Despite these advantages,
developing a fast and scalable graph-empowered
RAG system that efficiently handles varying query
volumes is crucial. In this work, we achieve an
effective and efficient RAG system by addressing
three key challenges: i) Comprehensive Infor-
mation Retrieval. Ensuring comprehensive infor-
mation retrieval that captures the full context of
inter-dependent entities from all documents; ii) En-
hanced Retrieval Efficiency. Improving retrieval
efficiency over the graph-based knowledge struc-
tures to significantly reduce response times; iii)
Rapid Adaptation to New Data. Enabling quick
adaptation to new data updates, ensuring the system
remains relevant in dynamic environments.
In response to the outlined challenges, we pro-
pose LightRAG, a model that seamlessly inte-
grates a graph-based text indexing paradigm with
a dual-level retrieval framework. This innovative
approach enhances the system’s capacity to cap-
ture complex inter-dependencies among entities,
resulting in more coherent and contextually rich re-
sponses. LightRAG employs efficient dual-level re-
trieval strategies: low-level retrieval, which focuses
on precise information about specific entities and
their relationships, and high-level retrieval, which
encompasses broader topics and themes. By com-
bining both detailed and conceptual retrieval, Ligh-
tRAG effectively accommodates a diverse range
of quries, ensuring that users receive relevant and
comprehensive responses tailored to their specific
needs. Additionally, by integrating graph struc-
tures with vector representations, our framework
facilitates efficient retrieval of related entities and
relations while enhancing the comprehensiveness
of results through relevant structural information
from the constructed knowledge graph.
In summary, this work’s key contributions are:
• General Aspect. We emphasize the importance
of developing a graph-empowered RAG system
to overcome the limitations of existing methods.
By integrating graph structures into text index-
ing, we can effectively represent complex interde-
pendencies among entities, fostering a nuanced
understanding of relationships and enabling co-
herent, contextually rich responses.
• Methodologies. To enable an efficient and adap-
tive RAG system, we propose LightRAG, which
integrates a dual-level retrieval paradigm with
graph-enhanced text indexing. This approach
captures both low-level and high-level informa-
tion for comprehensive, cost-effective retrieval.
Without the need to rebuild the entire index, Ligh-
tRAG reduces computational costs and acceler-
ates adaptation, while its incremental update al-
gorithm ensures timely integration of new data,
maintaining efficacy in dynamic environments.
• Experimental Findings. Extensive experiments
were conducted to evaluate the effectiveness of
LightRAG in comparison to existing RAG mod-
els. These assessments focused on several key
dimensions, including retrieval accuracy, model
ablation, response efficiency, and adaptability to
new information. The results demonstrated sig-
nificant improvements over baseline methods.
2
Retrieval-Augmented Generation
Retrieval-Augmented Generation (RAG) integrates
user queries with a collection of pertinent doc-
uments sourced from an external knowledge
database, incorporating two essential elements: the
Retrieval Component and the Generation Com-
ponent. 1) The retrieval component is responsi-
ble for fetching relevant documents or information
from the external knowledge database. It identi-
fies and retrieves the most pertinent data based on
the input query. 2) After the retrieval process, the
generation component takes the retrieved informa-
tion and generates coherent, contextually relevant
responses. It leverages powerful LLMs to produce
meaningful outputs. Formally, this RAG frame-
work, denoted as M, can be defined as follows:
M =

G, R = (φ, ψ)

,
M(q; D) = G

q, ψ(q; ˆD)

,
ˆD = φ(D)
(1)
In this framework, G and R represent the genera-
tion module and the retrieval module, respectively,
while q denotes the input query and D refers to
the external database. The retrieval module R in-
cludes two key functionalities: i) Data Indexer
φ(·): which involves building a specific data struc-
ture ˆD based on the external database D. ii) Data
Retriever ψ(·): The relevant documents are ob-
tained by comparing the query against the indexed
data, also denoted as “relevant documents”. By
leveraging the information retrieved through ψ(·)
along with the initial query q, the generative model
10747

## Page 3

G(·) efficiently produces high-quality responses.
This work targets several key points essential for
an efficient and effective RAG system as follows:
• Comprehensive Information Retrieval: The in-
dexing function φ(·) must be adept at extracting
global information, as this is crucial for effective
query answering using LLMs.
• Efficient and Low-Cost Retrieval: The indexed
data structure ˆD must enable rapid and cost-
efficient information retrieval to effectively han-
dle a high volume of user queries.
• Fast Adaptation to Data Changes: The ability
to swiftly and efficiently adjust the data structure
to incorporate new information from the external
knowledge base, is crucial for ensuring that the
system remains current and relevant in an ever-
changing information landscape.
3
The LightRAG Architecture
3.1
Graph-based Text Indexing
Graph-Enhanced Entity and Relationship Ex-
traction. Our LightRAG enhances the retrieval sys-
tem by segmenting documents into smaller, more
manageable pieces. This strategy allows for quick
identification and access to relevant information
without analyzing entire documents.
Next, we
leverage LLMs to identify and extract various enti-
ties (e.g., names, dates, locations, and events) along
with the relationships between them. The informa-
tion collected through this process will be used to
create a comprehensive knowledge graph that high-
lights the connections and insights across the entire
collection of documents. We formally represent
this graph generation module as follows:
ˆD = (ˆV, ˆE) = Dedupe ◦Prof(V, E),
V, E = ∪Di∈D Recog(Di)
(2)
where ˆD represents the resulting knowledge
graphs. To generate this data, we apply three main
processing steps to the raw text documents Di.
These steps utilize a LLM for text analysis and
processing. Details about the prompt templates
and specific settings for this part can be found in
Appendix 9.4.2. The functions used in our graph-
based text indexing paradigm are described as:
• Extracting Entities and Relationships. R(·):
This function prompts a LLM to identify entities
(nodes) and their relationships (edges) within the
text data. For instance, it can extract entities like
"Cardiologists" and "Heart Disease," and rela-
tionships such as "Cardiologists diagnose Heart
Disease" from the text: "Cardiologists assess
symptoms to identify potential heart issues." To
improve efficiency, the raw text D is segmented
into multiple chunks Di.
• LLM Profiling for Key-Value Pair Generation.
P(·): We employ a LLM-empowered profiling
function, P(·), to generate a text key-value pair
(K, V ) for each entity node in V and relation
edge in E. Each index key is a word or short
phrase that enables efficient retrieval, while the
corresponding value is a text paragraph summa-
rizing relevant snippets from external data to aid
in text generation. Entities use their names as the
sole index key, whereas relations may have mul-
tiple keys derived from LLM enhancements that
include global themes from connected entities.
• Deduplication to Optimize Graph Operations.
D(·): Finally, we implement a deduplication
function, D(·), that identifies and merges identi-
cal entities and relations from different segments
of the raw text Di. This process effectively re-
duces the overhead associated with graph opera-
tions on ˆD by minimizing the graph’s size, lead-
ing to more efficient data processing.
Our LightRAG offers two advantages through its
graph-based text indexing paradigm. First, Com-
prehensive Information Understanding.
The
constructed graph enables the extraction of global
information from multi-hop subgraphs, greatly en-
hancing LightRAG’s ability to handle complex
queries that span multiple document chunks. Sec-
ond, Enhanced Retrieval Performance. the key-
value data structures derived from the graph are
optimized for rapid and precise retrieval. This pro-
vides a superior alternative to less accurate em-
bedding matching methods (Gao et al., 2023) and
inefficient chunk traversal techniques (Edge et al.,
2024) commonly used in existing approaches.
Fast Adaptation to Incremental Knowledge
Base. To efficiently adapt to evolving data changes
while ensuring accurate and relevant responses, our
LightRAG incrementally updates the knowledge
base without the need for complete reprocessing of
the entire external database. For a new document
D′, the incremental update algorithm processes it
using the same graph-based indexing steps φ as
10748

## Page 4

Query + LLM
Entity Name:  Beekeeper
Entity Type: PERSON
Description: A Beekeeper is 
an individual who produces ...
Original Chunks ID: xxx
Source: Honey Bee
Target: Industrial agriculture
Keywords: Agriculture ...
Description: Honey Bees are 
negatively impacted ...
Original Chunks ID: xxx
... BEEKEEPER‘s practices involve
the methods and strategies employed
by
beekeepers
to
manage
bee
colonies and ensure their health and
productivity. A Beekeeper is an
individual who produces honey and
other related products, playing a
crucial role in ……
Beekeepers engage in various tasks,
including observing bee behavior,
monitoring
hive
conditions,
preventing
pest
infestations,
and
utilizing techniques to handle bees,
such as using smoke to calm them ...
Original Text
-----Entities-----
"Beekeeper",”A Beekeeper is an
individual who produces honey and
other related products, playing a
crucial role in ......”
-Relationships-
"Beekeeper",“bee","Beekeepers
manage bees but do not develop
individual relationships with them
due to the limited interaction time
with each hive.”
----Contexts----
BEEKEEPER's practices involve the
methods and strategies employed
by beekeepers to manage ……
Graph-based Text Indexing
Dual-level Retrieval Paradigm
Entity & Rel Extraction
Beekeeper
Bees
Observe
Beekeeper
A beekeeper 
is an person 
who…
LLM Profiling
Beekeeper
beekeeper
Deduplication
…
Match
Index Graph 
used for Retrieval
Beekeeper
Honey Bee
…
Formers
Hive
Low-level Keys
Agriculture
Production
Environmental Impact …
High-level Keys
Entities
Relations
Retrieved Content
Figure 1: Overall architecture of the proposed LightRAG framework.
before, resulting in ˆD′ = (ˆV′, ˆE′). Subsequently,
LightRAGcombines the new graph data with the
original by taking the union of the node sets ˆV and
ˆV′, as well as the edge sets ˆE and ˆE′.
Two key objectives guide our approach to fast
adaptation for the incremental knowledge base:
Seamless Integration of New Data. By apply-
ing a consistent methodology to new information,
the incremental update module allows the Ligh-
tRAG to integrate new external databases without
disrupting the existing graph structure. This ap-
proach preserves the integrity of established con-
nections, ensuring that historical data remains ac-
cessible while enriching the graph without conflicts
or redundancies. Reducing Computational Over-
head . By eliminating the need to rebuild the entire
index graph, this method reduces computational
overhead and facilitates the rapid assimilation of
new data. Consequently, LightRAG maintains sys-
tem accuracy, provides current information, and
conserves resources, ensuring users receive timely
updates and enhancing the RAG effectiveness.
3.2
Dual-level Retrieval Paradigm
To retrieve relevant information from both spe-
cific document chunks and their complex inter-
dependencies, our LightRAG proposes generating
query keys at both detailed and abstract levels.
• Specific Queries.
These queries are detail-
oriented and typically reference specific entities
within the graph, requiring precise retrieval of
information associated with particular nodes or
edges. For example, a specific query might be,
“Who wrote ’Pride and Prejudice’?”
• Abstract Queries. In contrast, abstract queries
are more conceptual, encompassing broader top-
ics, summaries, or overarching themes that are
not directly tied to specific entities. An exam-
ple of an abstract query is, “How does artificial
intelligence influence modern education?”
To accommodate diverse query types, the Ligh-
tRAG employs two distinct retrieval strategies
within the dual-level retrieval paradigm. This en-
sures that both specific and abstract inquiries are
addressed effectively, allowing the system to de-
liver relevant responses tailored to user needs.
• Low-Level Retrieval.
This level is primar-
ily focused on retrieving specific entities along
with their associated attributes or relationships.
Queries at this level are detail-oriented and aim
to extract precise information about particular
nodes or edges within the graph.
• High-Level Retrieval.
This level addresses
broader topics and overarching themes. Queries
at this level aggregate information across mul-
tiple related entities and relationships, provid-
ing insights into higher-level concepts and sum-
maries rather than specific details.
Integrating Graph and Vectors for Efficient
Retrieval. By combining graph structures with
vector representations, the model gains a deeper
insight into the interrelationships among entities.
This synergy enables the retrieval algorithm to ef-
fectively utilize both local and global keywords,
streamlining the search process and improving the
relevance of results.
• (i) Query Keyword Extraction. For a given
query q, the retrieval algorithm of LightRAG
begins by extracting both local query keywords
k(l) and global query keywords k(g).
• (ii) Keyword Matching. The algorithm uses an
efficient vector database to match local query key-
words with candidate entities and global query
keywords with relations linked to global keys.
• (iii) Incorporating High-Order Relatedness.
To enhance the query with higher-order relat-
edness, LightRAGfurther gathers neighboring
nodes within the local subgraphs of the retrieved
graph elements. This process involves the set
{vi|vi ∈V ∧(vi ∈Nv ∨vi ∈Ne)}, where Nv
and Ne represent the one-hop neighboring nodes
of the retrieved nodes v and edges e, respectively.
10749

## Page 5

This dual-level retrieval paradigm of LightRAG
not only facilitates efficient retrieval of related enti-
ties and relations through keyword matching, but
also enhances the comprehensiveness of retrieval
results by integrating relevant structural informa-
tion from the constructed knowledge graph.
3.3
Retrieval-Augmented Answer Generation
Utilization of Retrieved Information. Utilizing
the retrieved information ψ(q; ˆD), our LightRAG
employs a general-purpose LLM to generate an-
swers based on the collected data. This data com-
prises concatenated values V from relevant entities
and relations, produced by the profiling function
P(·). It includes names, descriptions of entities and
relations, and excerpts from the original text.
Context Integration and Answer Generation.
By unifying the query with this multi-source text,
the LLM generates informative answers tailored
to the user’s needs, ensuring alignment with the
query’s intent. This approach streamlines the an-
swer generation process by integrating both context
and query into the LLM model, as illustrated in de-
tailed examples (Appendix 9.3).
3.4
Complexity Analysis of LightRAG
In this section, we analyze the complexity of our
proposed LightRAG framework, which can be di-
vided into two main parts. The first part is the
graph-based Index phase. During this phase, we
use the large language model (LLM) to extract en-
tities and relationships from each chunk of text.
As a result, the LLM needs to be called total tokens
chunk size
times. Importantly, there is no additional over-
head involved in this process, making our approach
highly efficient in managing updates to new text.
The second part of the process involves the
graph-based retrieval phase. For each query, we
first utilize the large language model (LLM) to
generate relevant keywords. Similar to current
Retrieval-Augmented Generation (RAG) systems
(Gao et al., 2023, 2022; Chan et al., 2024), our
retrieval mechanism relies on vector-based search.
However, instead of retrieving chunks as in conven-
tional RAG, we concentrate on retrieving entities
and relationships. This approach markedly reduces
retrieval overhead compared to the community-
based traversal method used in GraphRAG.
4
Evaluation
We conduct empirical evaluations on benchmark
data to assess the effectiveness of the proposed
LightRAG framework by addressing the follow-
ing research questions: • (RQ1): How does Ligh-
tRAG compare to existing RAG baseline methods
in terms of generation performance? • (RQ2):
How do dual-level retrieval and graph-based index-
ing enhance the generation quality of LightRAG?
• (RQ3): What are the costs associated with Ligh-
tRAG, as well as its adaptability to data changes?
4.1
Experimental Settings
To evaluate the effectiveness of LightRAG, we con-
ducted experiments on four datasets from the Ultra-
Domain benchmark (Qian et al., 2024), covering
diverse domains such as Agriculture, CS, Legal,
and Mixed. Each dataset ranges from 600,000 to
5,000,000 tokens. We compare LightRAG with
state-of-the-art RAG methods, including Naive
RAG, RQ-RAG, HyDE, and GraphRAG. Using
a robust LLM-based evaluation, we assess perfor-
mance across four dimensions: Comprehensive-
ness, Diversity, Empowerment, and Overall.
Detailed descriptions of datasets, question gener-
ation, and baselines are provided in Appendix 9.1.
4.2
RAG Performance Comparison (RQ1)
We compare LightRAG against each baseline
across various evaluation dimensions and datasets.
The results are presented in Table 1. Based on these
findings, we draw the following conclusions:
Graph-Enhanced RAG Superiority in Large-
Scale Corpora. When handling large token counts
and complex queries requiring comprehensive
dataset understanding, graph-based RAG systems
like LightRAG and GraphRAG consistently out-
perform chunk-based methods such as NaiveRAG,
HyDE, and RQRAG. This performance gap widens
with dataset size—in the largest dataset (Legal),
baseline methods achieve only 20% win rates com-
pared to LightRAG’s dominance. This trend high-
lights the advantages of graph-enhanced RAG sys-
tems in capturing complex semantic dependencies
within large-scale corpora, enabling better knowl-
edge understanding and improved generalization.
Enhancing Response Diversity with Ligh-
tRAG. Compared to various baselines, LightRAG
demonstrates a significant advantage in the Di-
versity metric, particularly within the larger Le-
gal dataset. Its consistent lead in this area under-
scores LightRAG’s effectiveness in generating a
wider range of responses, especially in scenarios
where diverse content is essential. We attribute
10750

## Page 6

Table 1: Win rates (%) of baselines v.s. LightRAG across four datasets and four evaluation dimensions.
Agriculture
CS
Legal
Mix
NaiveRAG
LightRAG
NaiveRAG
LightRAG
NaiveRAG
LightRAG
NaiveRAG
LightRAG
Comprehensiveness
32.4%
67.6%
38.4%
61.6%
16.4%
83.6%
38.8%
61.2%
Diversity
23.6%
76.4%
38.0%
62.0%
13.6%
86.4%
32.4%
67.6%
Empowerment
32.4%
67.6%
38.8%
61.2%
16.4%
83.6%
42.8%
57.2%
Overall
32.4%
67.6%
38.8%
61.2%
15.2%
84.8%
40.0%
60.0%
RQ-RAG
LightRAG
RQ-RAG
LightRAG
RQ-RAG
LightRAG
RQ-RAG
LightRAG
Comprehensiveness
31.6%
68.4%
38.8%
61.2%
15.2%
84.8%
39.2%
60.8%
Diversity
29.2%
70.8%
39.2%
60.8%
11.6%
88.4%
30.8%
69.2%
Empowerment
31.6%
68.4%
36.4%
63.6%
15.2%
84.8%
42.4%
57.6%
Overall
32.4%
67.6%
38.0%
62.0%
14.4%
85.6%
40.0%
60.0%
HyDE
LightRAG
HyDE
LightRAG
HyDE
LightRAG
HyDE
LightRAG
Comprehensiveness
26.0%
74.0%
41.6%
58.4%
26.8%
73.2%
40.4%
59.6%
Diversity
24.0%
76.0%
38.8%
61.2%
20.0%
80.0%
32.4%
67.6%
Empowerment
25.2%
74.8%
40.8%
59.2%
26.0%
74.0%
46.0%
54.0%
Overall
24.8%
75.2%
41.6%
58.4%
26.4%
73.6%
42.4%
57.6%
GraphRAG
LightRAG
GraphRAG
LightRAG
GraphRAG
LightRAG
GraphRAG
LightRAG
Comprehensiveness
45.6%
54.4%
48.4%
51.6%
48.4%
51.6%
50.4%
49.6%
Diversity
22.8%
77.2%
40.8%
59.2%
26.4%
73.6%
36.0%
64.0%
Empowerment
41.2%
58.8%
45.2%
54.8%
43.6%
56.4%
50.8%
49.2%
Overall
45.2%
54.8%
48.0%
52.0%
47.2%
52.8%
50.4%
49.6%
this advantage to LightRAG’s dual-level retrieval
paradigm, which facilitates comprehensive infor-
mation retrieval from both low-level and high-level
dimensions. This approach effectively leverages
graph-based text indexing to consistently capture
the full context in response to queries.
LightRAG’s Superiority over GraphRAG:
While both LightRAG and GraphRAG use
graph-based retrieval mechanisms, LightRAG
consistently outperforms GraphRAG, particu-
larly in larger datasets with complex language
contexts.
In the Agriculture, CS, and Le-
gal datasets—each containing millions of to-
kens—LightRAG shows a clear advantage, sig-
nificantly surpassing GraphRAG and highlighting
its strength in comprehensive information under-
standing within diverse environments. Enhanced
Response Variety: By integrating low-level re-
trieval of specific entities with high-level retrieval
of broader topics, LightRAG boosts response di-
versity. This dual-level mechanism effectively ad-
dresses both detailed and abstract queries, ensuring
a thorough grasp of information. Complex Query
Handling: This approach is especially valuable in
scenarios requiring diverse perspectives. By access-
ing both specific details and overarching themes,
LightRAG adeptly responds to complex queries
involving interconnected topics, providing contex-
tually relevant answers of high quality.
4.3
Ablation Studies (RQ2)
We also conduct ablation studies to evaluate the
impact of our dual-level retrieval paradigm and the
effectiveness of our graph-based text indexing in
LightRAG. The results are presented in Table 2.
Effectiveness
of
Dual-level
Retrieval
Paradigm. We begin by analyzing the effects of
low-level and high-level retrieval paradigms. We
compare two ablated models against LightRAG
across four datasets. Here are our key observations:
• Low-level-only Retrieval: The -High variant
removes high-order retrieval, leading to a sig-
nificant performance decline across nearly all
datasets and metrics. This drop is mainly due to
its emphasis on the specific information, which
focuses excessively on entities and their imme-
diate neighbors. While this approach enables
deeper exploration of directly related entities,
it struggles to gather information for complex
queries that demand comprehensive insights.
• High-level-only Retrieval: The -Low variant pri-
oritizes capturing a broader range of content by
leveraging entity-wise relationships rather than
focusing on specific entities. This approach of-
fers a significant advantage in comprehensive-
ness, allowing it to gather more extensive and
varied information. However, the trade-off is
a reduced depth in examining specific entities,
which can limit its ability to provide highly de-
10751

## Page 7

Table 2: Performance of ablated versions of LightRAG, using NaiveRAG as reference.
Agriculture
CS
Legal
Mix
NaiveRAG
LightRAG
NaiveRAG
LightRAG
NaiveRAG
LightRAG
NaiveRAG
LightRAG
Comprehensiveness
32.4%
67.6%
38.4%
61.6%
16.4%
83.6%
38.8%
61.2%
Diversity
23.6%
76.4%
38.0%
62.0%
13.6%
86.4%
32.4%
67.6%
Empowerment
32.4%
67.6%
38.8%
61.2%
16.4%
83.6%
42.8%
57.2%
Overall
32.4%
67.6%
38.8%
61.2%
15.2%
84.8%
40.0%
60.0%
NaiveRAG
-High
NaiveRAG
-High
NaiveRAG
-High
NaiveRAG
-High
Comprehensiveness
34.8%
65.2%
42.8%
57.2%
23.6%
76.4%
40.4%
59.6%
Diversity
27.2%
72.8%
36.8%
63.2%
16.8%
83.2%
36.0%
64.0%
Empowerment
36.0%
64.0%
42.4%
57.6%
22.8%
77.2%
47.6%
52.4%
Overall
35.2%
64.8%
44.0%
56.0%
22.0%
78.0%
42.4%
57.6%
NaiveRAG
-Low
NaiveRAG
-Low
NaiveRAG
-Low
NaiveRAG
-Low
Comprehensiveness
36.0%
64.0%
43.2%
56.8%
19.2%
80.8%
36.0%
64.0%
Diversity
28.0%
72.0%
39.6%
60.4%
13.6%
86.4%
33.2%
66.8%
Empowerment
34.8%
65.2%
42.8%
57.2%
16.4%
83.6%
35.2%
64.8%
Overall
34.8%
65.2%
43.6%
56.4%
18.8%
81.2%
35.2%
64.8%
NaiveRAG
-Origin
NaiveRAG
-Origin
NaiveRAG
-Origin
NaiveRAG
-Origin
Comprehensiveness
24.8%
75.2%
39.2%
60.8%
16.4%
83.6%
44.4%
55.6%
Diversity
26.4%
73.6%
44.8%
55.2%
14.4%
85.6%
25.6%
74.4%
Empowerment
32.0%
68.0%
43.2%
56.8%
17.2%
82.8%
45.2%
54.8%
Overall
25.6%
74.4%
39.2%
60.8%
15.6%
84.4%
44.4%
55.6%
tailed insights. Consequently, this high-level-
only retrieval method may struggle with tasks
that require precise, detailed answers.
• Hybrid Mode: The hybrid mode, or the full-
version LightRAG, combines the strengths of
both low- and high-level methods. It retrieves a
broader set of relationships while simultaneously
conducting an in-depth exploration of specific
entities. This dual-level approach ensures both
breadth in the retrieval process and depth in the
analysis, providing a comprehensive view of the
data. As a result, LightRAG achieves balanced
performance across multiple dimensions.
Semantic Graph Excels in RAG. We elimi-
nated the use of original text in our retrieval process.
Surprisingly, the resulting variant, -Origin, does not
exhibit significant performance declines. In some
cases, this variant even shows improvements (e.g.
Agriculture, Mix). We attribute this result to the
effective extraction of key information during the
graph-based indexing process, which provides suf-
ficient context to answer queries. Additionally, the
original text often contains irrelevant information
that can introduce noise in the response.
4.4
Cost and Adaptability Analysis (RQ3)
We compare the cost of LightRAG with that of
the top-performing baseline, GraphRAG, from two
key perspectives. First, we examine the number
of tokens and API calls during the indexing and
Table 3: RAG cost comparison on Legal data.
Phase
Retrieval Phase
Incremental Text Update
Model
GraphRAG
Ours
GraphRAG
Ours
Tokens 610 × 1,000 < 100 1,399 × 2 × 5,000
Textract
+Textract
API
610×1,000
Cmax
1
1,399 × 2 + Cextract Cextract
Calls
retrieval processes. Second, we analyze these met-
rics in relation to handling data changes in dynamic
environments. The results on the legal dataset are
presented in Table 3. In this context, Textract repre-
sents the token overhead for entity and relationship
extraction, Cmax denotes the maximum number of
tokens allowed per API call, and Cextract indicates
the number of API calls required for extraction.
In the retrieval phase, GraphRAG generates
1,399 communities, with 610 level-2 communities
actively utilized for retrieval in this experiment.
Each community report averages 1,000 tokens, re-
sulting in a total token consumption of 610,000
tokens (610 communities × 1,000 tokens per com-
munity). Additionally, GraphRAG’s requirement
to traverse each community individually leads to
hundreds of API calls, significantly increasing re-
trieval overhead. In contrast, LightRAG optimizes
this process by using fewer than 100 tokens for
keyword generation and retrieval, requiring only
a single API call for the entire process. This effi-
ciency is achieved through our retrieval mechanism,
which seamlessly integrates graph structures and
vectorized representations for information retrieval,
10752

## Page 8

thereby eliminating the need to process large vol-
umes of information upfront.
In the incremental data update phase, address-
ing dynamic real-world scenarios, both models ex-
hibit similar overhead for entity and relationship
extraction. However, GraphRAG shows significant
inefficiency managing newly added data. When in-
troducing a new dataset matching the legal dataset
size, GraphRAG must dismantle its existing com-
munity structure to incorporate new entities and
relationships, then completely regenerate. This in-
curs substantial token costs of approximately 5,000
tokens per community report. With 1,399 com-
munities, GraphRAG requires around 1,399 × 2 ×
5,000 tokens to reconstruct both original and new
community reports—an exorbitant expense high-
lighting its inefficiency. In contrast, LightRAG
seamlessly integrates newly extracted entities and
relationships into the existing graph without recon-
struction, resulting in significantly lower overhead
during incremental updates and demonstrating su-
perior efficiency and cost-effectiveness.
4.5
Case Study
In addition to the overall evaluation results, we
provided detailed case analyses in Appendix 9.2 to
further illustrate the key findings of this study.
5
Related Work
5.1
Retrieval-Augmented Generation
Retrieval-Augmented Generation (RAG) systems
enhance LLM inputs by retrieving relevant infor-
mation from external sources, grounding responses
in factual, domain-specific knowledge (Ram et al.,
2023; Fan et al., 2024). Current RAG approaches
(Gao et al., 2022, 2023; Chan et al., 2024; Yu et al.,
2024) typically embed queries in a vector space to
find the nearest context vectors. However, many of
these methods rely on fragmented text chunks and
only retrieve the top-k contexts, limiting their abil-
ity to capture comprehensive global information
needed for high-quality responses.
Although recent studies (Edge et al., 2024) have
explored using graph structures for knowledge rep-
resentation, two key limitations persist. First, these
approaches often lack the capability for dynamic
updates and expansions of the knowledge graph,
making it difficult to incorporate new informa-
tion effectively. In contrast, our proposed model,
LightRAG, addresses these challenges by enabling
the RAG system to quickly adapt to new infor-
mation, ensuring the model’s timeliness and accu-
racy. Additionally, existing methods often rely on
brute-force searches for each generated community,
which are inefficient for large-scale queries. Our
LightRAG framework overcomes this limitation by
facilitating rapid retrieval of relevant information
from the graph through our proposed dual-level
retrieval paradigm, significantly enhancing both
retrieval efficiency and response speed.
5.2
Large Language Model for Graphs
Graphs have become a powerful framework for rep-
resenting complex relationships, with applications
across fields. As large language models (LLMs)
evolve, researchers aim to enhance their ability to
interpret graph-structured data. This work falls
into three broad categories: i) GNNs as Prefix
- using GNNs to generate structure-aware tokens
for LLMs, e.g., GraphGPT (Tang et al., 2024) and
LLaGA (Chen et al., 2024). ii) LLMs as Prefix -
leveraging LLMs to process graph data with text,
producing embeddings/labels to refine GNN train-
ing, like GALM (Xie et al., 2023) and OFA (Liu
et al., 2024). iii) LLMs-Graphs Integration -
achieving seamless interaction, using techniques, ,
fusion training, GNN alignment, and LLM-based
agents for direct graph handling, e.g., Grenade (Li
et al., 2023) and Congrat (Brannon et al., 2023).
6
Conclusion
This work introduces an advancement in LLM-
empowered
Retrieval-Augmented
Generation
through the integration of a graph-based indexing
approach that enhances both efficiency and
comprehension in information retrieval. LightRAG
utilizes a comprehensive knowledge graph to
facilitate rapid and relevant document retrieval,
enabling a deeper understanding of complex
queries. Its dual-level retrieval paradigm allows
for the extraction of both specific and abstract
information,
catering to diverse user needs.
Furthermore, LightRAG’s seamless incremental
update capability ensures that the system remains
current and responsive to new information,
thereby maintaining its effectiveness over time.
Overall, LightRAG excels in both efficiency and
effectiveness, significantly improving the speed
and quality of information retrieval and generation
while reducing costs for LLM inference.
10753

## Page 9

7
Limitations
Integrating multi-modal capabilities into Ligh-
tRAG significantly enhances functionality by in-
corporating diverse data types such as text, im-
ages, and audio. This enables richer contextual
understanding and more nuanced responses to
user queries.
Additionally, incorporating time-
awareness ensures the system reflects dynamic
events and evolving contexts, adapting responses
based on temporal relevance. By combining multi-
modal inputs with time-sensitive frameworks, Ligh-
tRAG delivers timely, contextually accurate in-
sights that address complex queries requiring un-
derstanding of current events and interconnections.
8
Acknowledgments
This research was partially supported by the Na-
tional Natural Science Foundation of China under
Grant No. U22B2019.
References
William Brannon, Suyash Fulay, Hang Jiang, Won-
june Kang, Brandon Roy, Jad Kabbara, and Deb
Roy. 2023. Congrat: Self-supervised contrastive pre-
training for joint graph and text embeddings. arXiv
preprint arXiv:2305.14321.
Chi-Min Chan, Chunpu Xu, Ruibin Yuan, Hongyin Luo,
Wei Xue, Yike Guo, and Jie Fu. 2024. Rq-rag: Learn-
ing to refine queries for retrieval augmented genera-
tion. arXiv preprint arXiv:2404.00610.
Runjin Chen, Tong Zhao, AJAY KUMAR JAISWAL,
Neil Shah, and Zhangyang Wang. 2024. Llaga: Large
language and graph assistant. In ICML.
Darren Edge, Ha Trinh, Newman Cheng, Joshua
Bradley, Alex Chao, Apurva Mody, Steven Truitt,
and Jonathan Larson. 2024. From local to global: A
graph rag approach to query-focused summarization.
arXiv preprint arXiv:2404.16130.
Shahul Es, Jithin James, Luis Espinosa Anke, and
Steven Schockaert. 2024. Ragas: Automated evalua-
tion of retrieval augmented generation. In EACL.
Wenqi Fan, Yujuan Ding, Liangbo Ning, Shijie Wang,
Hengyun Li, Dawei Yin, Tat-Seng Chua, and Qing
Li. 2024. A survey on rag meeting llms: Towards
retrieval-augmented large language models. In KDD.
Luyu Gao, Xueguang Ma, Jimmy Lin, and Jamie Callan.
2022. Precise zero-shot dense retrieval without rele-
vance labels. arXiv preprint arXiv:2212.10496.
Yunfan Gao, Yun Xiong, Xinyu Gao, Kangxiang Jia,
Jinliu Pan, Yuxi Bi, Yi Dai, Jiawei Sun, and Haofen
Wang. 2023. Retrieval-augmented generation for
large language models: A survey. arXiv preprint
arXiv:2312.10997.
Yichuan Li, Kaize Ding, and Kyumin Lee. 2023.
Grenade: Graph-centric language model for self-
supervised representation learning on text-attributed
graphs. In EMNLP.
Hao Liu, Jiarui Feng, Lecheng Kong, Ningyue Liang,
Dacheng Tao, Yixin Chen, and Muhan Zhang. 2024.
One for all: Towards training one graph model for all
classification tasks. In ICLR.
Yuanjie Lyu, Zhiyu Li, Simin Niu, Feiyu Xiong,
Bo Tang, Wenjin Wang, Hao Wu, Huanyong Liu,
Tong Xu, and Enhong Chen. 2024.
Crud-rag:
A comprehensive chinese benchmark for retrieval-
augmented generation of large language models.
arXiv preprint arXiv:2401.17043.
Hongjin Qian, Peitian Zhang, Zheng Liu, Kelong Mao,
and Zhicheng Dou. 2024. Memorag: Moving to-
wards next-gen rag via memory-inspired knowledge
discovery. arXiv preprint arXiv:2409.05591.
Ori Ram, Yoav Levine, Itay Dalmedigos, Dor Muhlgay,
Amnon Shashua, Kevin Leyton-Brown, and Yoav
Shoham. 2023. In-context retrieval-augmented lan-
guage models. TACL, 11:1316–1331.
Ladislav Rampášek, Michael Galkin, Vijay Prakash
Dwivedi, Anh Tuan Luu, Guy Wolf, and Dominique
Beaini. 2022. Recipe for a general, powerful, scal-
able graph transformer. NeurIPS, 35:14501–14515.
Alireza Salemi et al. 2024. Evaluating retrieval quality
in retrieval-augmented generation. In SIGIR.
Viju Sudhi, Sinchana Ramakanth Bhat, Max Rudat, et al.
2024. Rag-ex: A generic framework for explaining
retrieval augmented generation. In SIGIR.
Jiabin Tang, Yuhao Yang, Wei Wei, Lei Shi, Lixin Su,
Suqi Cheng, Dawei Yin, and Chao Huang. 2024.
Graphgpt: Graph instruction tuning for large lan-
guage models. In SIGIR.
Shangqing Tu, Yuanchun Wang, Jifan Yu, Yuyang Xie,
Yaran Shi, Xiaozhi Wang, Jing Zhang, Lei Hou, and
Juanzi Li. 2024. R-eval: A unified toolkit for evaluat-
ing domain knowledge of retrieval augmented large
language models. In KDD.
Han Xie, Da Zheng, Jun Ma, Houyu Zhang, Vassilis N
Ioannidis, Xiang Song, Qing Ping, et al. 2023. Graph-
aware language model pre-training on a large graph
corpus can help multiple graph applications. In KDD.
Yue Yu, Wei Ping, Zihan Liu, Boxin Wang, Jiaxuan
You, Chao Zhang, Mohammad Shoeybi, and Bryan
Catanzaro. 2024. Rankrag: Unifying context ranking
with retrieval-augmented generation in llms. arXiv
preprint arXiv:2407.02485.
Penghao Zhao, Hailin Zhang, Qinhan Yu, Zhengren
Wang, Yunteng Geng, Fangcheng Fu, Ling Yang,
Wentao Zhang, and Bin Cui. 2024.
Retrieval-
augmented generation for ai-generated content: A
survey. arXiv preprint arXiv:2402.19473.
10754

## Page 10

9
Appendix
In this section, we elaborate the methodologies and
experimental settings of the LightRAG framework.
It describes the specific steps for extracting enti-
ties and relationships from documents, detailing
how large language models (LLMs) are utilized for
this purpose. The section also specifies the prompt
templates and configurations used in LLM oper-
ations, ensuring clarity in the experimental setup.
Additionally, it outlines the evaluation criteria and
dimensions used to assess the performance of Ligh-
tRAG against baselines from various dimensions.
9.1
Experimental Settings
Table 4: Statistical information of the datasets.
Statistics Agriculture
CS
Legal
Mix
# Docs
12
10
94
61
# Tokens
2,017,886
2,306,535 5,081,069 619,009
Evaluation Datasets. To conduct a compre-
hensive analysis of LightRAG, we selected four
datasets from the UltraDomain benchmark (Qian
et al., 2024). The UltraDomain data is sourced from
428 college textbooks and encompasses 18 distinct
domains, including agriculture, social sciences, and
humanities. Among these domains, we chose the
Agriculture, CS, Legal, and Mix datasets. Each
dataset contains between 600,000 and 5,000,000
tokens, with detailed information provided in Ta-
ble 4. Below is a specific introduction to the four
domains utilized in our experiments:
• Agriculture: This domain focuses on agricul-
tural practices, covering a range of topics includ-
ing beekeeping, hive management, crop produc-
tion, and disease prevention.
• CS: This domain focuses on computer science
and includes key areas of data science and soft-
ware engineering. It particularly highlights ma-
chine learning and big data processing, featuring
content on recommender systems, classification
algorithms, and real-time analytics using Spark.
• Legal: It centers on corporate legal practices,
addressing corporate restructuring, legal agree-
ments, regulatory compliance, and governance,
with a focus on the legal and financial sectors.
• Mixed: This domain presents a rich variety of lit-
erary, biographical, and philosophical texts, span-
ning a broad spectrum of disciplines, including
cultural, historical, and philosophical studies.
Question Generation. To evaluate the effective-
ness of RAG systems for high-level sensemaking
tasks, we consolidate all text content from each
dataset as context and adopt the generation method
outlined in (Edge et al., 2024). Specifically, we
instruct an LLM to generate five RAG users, along
with five tasks for each user. Each generated user is
accompanied by a textual description detailing their
expertise and traits that motivate their question-
raising activities. Each user task is also described,
emphasizing one of the user’s potential intentions
when interacting with RAG systems. For each user-
task pair, the LLM generates five questions that
require an understanding of the entire corpus. In
total, we generate 125 questions for each dataset.
Baselines. Our LightRAG is compared against
the following state-of-the-art methods:
• Naive RAG (Gao et al., 2023): This model serves
as a standard baseline in existing RAG systems.
It segments raw texts into chunks and stores them
in a vector database using text embeddings. For
queries, Naive RAG generates vectorized repre-
sentations to directly retrieve text chunks based
on the highest similarity in their representations,
ensuring efficient and straightforward matching.
• RQ-RAG (Chan et al., 2024): This approach
leverages the LLM to decompose the input query
into multiple sub-queries. These sub-queries are
designed to enhance search accuracy by utilizing
explicit techniques such as rewriting, decomposi-
tion, and disambiguation.
• HyDE (Gao et al., 2022): This method utilizes
the LLM to generate a hypothetical document
based on the input query. This generated docu-
ment is then employed to retrieve relevant text
chunks, which are subsequently used to formu-
late the final answer.
• GraphRAG (Edge et al., 2024): This is a graph-
enhanced RAG system that utilizes an LLM to
extract entities and relationships from the text,
representing them as nodes and edges. It gen-
erates corresponding descriptions for these ele-
ments, aggregates nodes into communities, and
produces a community report to capture global
information. When handling high-level queries,
GraphRAG retrieves more comprehensive infor-
mation by traversing these communities.
Implementation and Evaluation Details. In
our experiments, we utilize the nano vector
database for vector data management and access.
10755

## Page 11

Table 5: Comparison of Document Insertion Times
No. Token Count LightRAG (s) GraphRAG (s)
1
59,870
486
642
2
41,224
418
700
3
73,989
561
953
4
47,502
513
741
5
48,353
453
926
Table 6: Average Query Times
Metric
LightRAG
GraphRAG
Average Query Time (s)
11.2
23.6
For all LLM-based operations in LightRAG, we de-
fault to using GPT-4o-mini. To ensure consistency,
the chunk size is set to 1200 across all datasets.
Additionally, the gleaning parameter is fixed at 1
for both GraphRAG and LightRAG.
Defining ground truth for many RAG queries,
particularly those involving complex high-level se-
mantics, poses significant challenges. To address
this, we build on existing work (Edge et al., 2024)
and adopt an LLM-based multi-dimensional com-
parison method. We employ a robust LLM, specif-
ically GPT-4o-mini, to rank each baseline against
our LightRAG. The evaluation prompt we used is
detailed in Appendix 9.4.4. In total, we utilize four
evaluation dimensions, including:
i) Comprehensiveness: How thoroughly does
the answer address all aspects and details of the
question? ii) Diversity: How varied and rich is
the answer in offering different perspectives and in-
sights related to the question? iii) Empowerment:
How effectively does the answer enable the reader
to understand the topic and make informed judg-
ments? iv) Overall: This dimension assesses the
cumulative performance across the three preceding
criteria to identify the best overall answer.
The LLM directly compares two answers for
each dimension and selects the superior response
for each criterion. After identifying the winning an-
swer for the three dimensions, the LLM combines
the results to determine the overall better answer.
To ensure a fair evaluation and mitigate the poten-
tial bias that could arise from the order in which the
answers are presented in the prompt, we alternate
the placement of each answer. We calculate win
rates accordingly, leading to the final results.
9.2
Time and Space Comparison
To further investigate the scalability and efficiency
of our proposed approach, LightRAG, we con-
Table 7: Final Storage Space Usage
Method
Final Storage Space (MB)
LightRAG
39.5
GraphRAG
286.7
ducted a series of incremental insertion experi-
ments. We introduced five additional documents,
with token counts ranging from 41,224 to 73,989,
into the knowledge base. The results, presented in
Table 5, demonstrate that LightRAG consistently
outperforms the baseline GraphRAG method in
both time and space efficiency. For the document
indexing task, LightRAG exhibits near-linear scala-
bility, with insertion times ranging from 418 to 561
seconds. In contrast, GraphRAG’s insertion times
are significantly higher, ranging from 642 to 953
seconds, indicating a heavier computational over-
head due to its community detection mechanisms.
During the retrieval phase, LightRAG achieves
an average query time of 11.2 seconds, less than
half of GraphRAG’s 23.6 seconds, as summarized
in Table 6.
This performance improvement is
primarily attributed to LightRAG’s lightweight,
keyword-based retrieval approach. Furthermore,
the final storage usage for LightRAG is only
39.5MB, as shown in Table 7, a stark contrast
to GraphRAG’s 286.7MB. This highlights Ligh-
tRAG’s superior efficiency in managing large-scale
data. These results reinforce LightRAG’s advan-
tages in terms of scalability and resource efficiency,
making it a more suitable choice for dynamic sce-
narios involving the ingestion and retrieval of large-
scale knowledge bases.
9.3
Case Example of Retrieval-Augmented
Generation in LightRAG
In Figure 2, we illustrate the retrieve-and-generate
process. When presented with the query, “What
metrics are most informative for evaluating movie
recommendation systems?”, the LLM first extracts
both low-level and high-level keywords. These
keywords guide the dual-level retrieval process on
the generated knowledge graph, targeting relevant
entities and relationships. The retrieved informa-
tion is organized into three components: entities,
relationships, and corresponding text chunks. This
structured data is then fed into the LLM, enabling
it to generate a comprehensive answer to the query.
9.4
Overview of Prompts in LightRAG
9.4.1
Prompts for Graph Generation
The graph construction prompt outlined in Fig-
ure 3 is designed to extract and structure entity-
10756

## Page 12

Figure 2: A retrieval and generation example.
relationship information from a text document
based on specified entity types. The process begins
by identifying entities and categorizing them into
types such as organization, person, location, and
event. It then provides detailed descriptions of their
attributes and activities. Next, the prompt identi-
fies relationships between these entities, offering
explanations, assigning strength scores, and sum-
marizing the relations using high-level keywords.
9.4.2
Prompts for Query Generation
In Figure 4, the query generation prompt outlines
a framework for identifying potential user roles
(e.g., data scientist, finance analyst, and prod-
uct manager) and their objectives for generating
queries based on a specified dataset description.
The prompt explains how to define five distinct
users who would benefit from interacting with the
dataset. For each user, it specifies five key tasks
they would perform while working with the dataset.
Additionally, for each (user, task) combination, five
high-level questions are posed to ensure a thorough
understanding of the dataset.
9.4.3
Prompts for Keyword Extraction
In Figure 5, the prompt describes a method for ex-
tracting keywords from a user’s query, distinguish-
ing between high-level and low-level keywords.
High-level keywords represent broad concepts or
themes, while low-level keywords focus on specific
entities and details. The extracted keywords are re-
turned in JSON format, organized into two fields:
“high_level_keywords” for overarching ideas and
“low_level_keywords” for specific details.
9.4.4
Prompts for RAG Evaluation
The evaluation prompt is illustrated in Figure 6. It
introduces a comprehensive evaluation framework
for comparing two answers to the same question
based on three key criteria: Comprehensiveness,
Diversity, and Empowerment. Its purpose is to
guide the LLM through the process of selecting
the better answer for each criterion, followed by
an overall assessment. For each of the three crite-
ria, the LLM must identify which answer performs
better and provide a rationale for its choice. Ulti-
mately, an overall winner is determined based on
10757

## Page 13

Figure 3: Prompts for Graph Generation
Figure 4: Prompts for Query Generation
performance across all three dimensions, accompa-
nied by a detailed summary that justifies the deci-
sion. The evaluation is structured in JSON format,
ensuring clarity and consistency, and facilitating a
systematic comparison between the two answers.
9.5
Case Study: Comparison between
LightRAG and the Baseline NaiveRAG
To further illustrate LightRAG’s superiority over
baseline models in terms of comprehensiveness,
empowerment, and diversity, we present a case
study comparing LightRAG and NaiveRAG in Ta-
ble 8. This study addresses a question regarding
indigenous perspectives in the context of corpo-
rate mergers. Notably, LightRAG offers a more
in-depth exploration of key themes related to in-
digenous perspectives, such as cultural significance,
collaboration, and legal frameworks, supported
by specific and illustrative examples. In contrast,
while NaiveRAG provides informative responses,
it lacks the depth needed to thoroughly examine
the various dimensions of indigenous ownership
and collaboration. The dual-level retrieval process
employed by LightRAG enables a more compre-
hensive investigation of specific entities and their
interrelationships, facilitating extensive searches
that effectively capture overarching themes and
complexities within the topic.
9.6
Case Study: Comparison between
LightRAG and GraphRAG
To provide a clear comparison between baseline
methods and our LightRAG, we present specific
case examples in Table 9. The table includes re-
sponses to a machine learning question from both
the competitive baseline, GraphRAG, and our Ligh-
tRAG framework. In this instance, LightRAG out-
performs GraphRAG in all evaluation dimensions
10758

## Page 14

Figure 5: Prompts for Keyword Extraction
Figure 6: Prompts for RAG Evaluation
assessed by the LLM judge, including comprehen-
siveness, diversity, empowerment, and overall qual-
ity. Our key observations are as follows:
i) Comprehensiveness.
Notably, LightRAG
covers a broader range of machine learning met-
rics, showcasing its comprehensiveness and ability
to effectively discover relevant information. This
highlights the strength of our graph-based index-
ing paradigm, which excels in precise entity and
relation extraction as well as LLM profiling.
ii) Both Diversity and Empowerment. Further-
more, LightRAG not only offers a more diverse
array of information but also delivers more empow-
ering content. This success is due to LightRAG’s
innovative hierarchical retrieval paradigm. This ap-
proach combines in-depth explorations of related
entities through low-level retrieval to enhance the
empowerment and depth of the responses, along
with broader explorations via high-level retrieval
to improve the diversity of the answers. Together,
they capture a comprehensive global perspective
of the knowledge domain, enabling LightRAG to
provide users with a richer, more empowering, and
more diverse set of information.
10759

## Page 15

Table 8: Case Study: Comparison Between LightRAG and the Baseline NaiveRAG.
Query
How do indigenous perspectives on ownership and collaboration influence corporate mergers in
countries like Canada and Australia?
NaiveRAG
Indigenous perspectives on ownership and collaboration play a significant role in shaping corporate
mergers in countries like Canada and Australia, particularly where resources and land rights
intersect with Indigenous sovereignty and cultural values. These perspectives emphasize community
engagement, respect for traditional land use, and a collaborative approach to resource management,
influencing corporate strategies and outcomes.
. . .
Both nations illustrate that prioritizing Indigenous perspectives leads to more sustainable and
equitable outcomes. Acknowledging Indigenous rights and fostering collaborative relationships can
reduce conflicts and enhance corporate reputations. Ultimately, integrating Indigenous perspectives
is a pathway to better business practices and community relations.
LightRAG
Indigenous Perspectives on Ownership and Collaboration in Corporate Mergers
Indigenous perspectives significantly influence corporate mergers in countries like Canada and
Australia. These views emphasize communal rights to land and resources, spiritual connections to
the environment, and the importance of collaboration over competition.
Cultural Significance of Land Ownership [...]
The Role of Collaboration [...]
Legal and Regulatory Frameworks [...]
Conclusion
Indigenous perspectives shape corporate mergers by emphasizing communal ownership and collab-
orative partnerships. Corporations must adopt respectful, inclusive practices that honor Indigenous
cultural values and rights, paving the way for sustainable, mutually beneficial outcomes.
LLM Decision
Comprehensiveness: "Winner": "Answer 2 (LightRAG)",
"Explanation": "Answer 2 provides a thorough exploration of the indigenous perspectives
by discussing cultural significance, collaboration, and legal frameworks, including specific
examples and detailed insights. In contrast, Answer 1, while informative, lacks the same depth
in analyzing the various dimensions of the indigenous perspectives on ownership and collaboration."
Diversity: "Winner": "Answer 2 (LightRAG)",
"Explanation": "Answer 2 presents a wider array of perspectives, focusing on the communal aspect
of land ownership, spiritual connections, and practical examples of collaboration. It covers more
ground by contrasting Indigenous views with Western notions, whereas Answer 1 primarily focuses
on corporate strategies and outcomes with limited perspective."
Empowerment: "Winner": "Answer 2 (LightRAG)",
"Explanation":
"Answer 2 equips the reader with nuanced understanding and actionable
insights by highlighting the importance of collaboration and the legal frameworks involved. It
empowers corporations by illustrating how adopting an inclusive approach can facilitate better out-
comes. Answer 1, while practical, does not emphasize the moral or ethical implications as strongly."
Overall Winner: "Winner": "Answer 2 (LightRAG)",
"Explanation": "Answer 2 excels overall due to its comprehensive exploration, diversity of perspec-
tives, and empowerment of the reader with actionable insights about indigenous perspectives and
collaboration in corporate mergers. Although Answer 1 is more direct, the depth and breadth of
Answer 2 make it the stronger response."
10760

## Page 16

Table 9: Case Study: Comparison Between LightRAG and the Baseline Method GraphRAG.
Query
Which methods can normalize the feature values for effective machine learning?
GraphRAG
Key Metrics for Evaluating Movie Recommendation Systems: Evaluating the effectiveness
of movie recommendation systems is crucial for ensuring user satisfaction and improving the
overall performance of these systems. Several metrics are widely recognized for their ability to
provide insights into how well a recommendation system performs. Below are the most informative
metrics: 1. Precision [...] 2. Recall [...] 3. F1 Score [...] 4. Mean Average Precision (MAP)
[...] 5. Root Mean Squared Error (RMSE) [...] 6. User Satisfaction Metrics [...] Conclusion:
In summary, metrics such as precision, recall, F1 score, MAP, RMSE, and user satisfaction are
critical for evaluating the performance of movie recommendation systems. Each metric provides
unique insights that can help developers and researchers refine their algorithms and enhance user
experiences. By focusing on these metrics, stakeholders can ensure that their recommendation
systems effectively meet user preferences and expectations.
LightRAG
Key Metrics for Evaluating Movie Recommendation Systems: Evaluating movie recommen-
dation systems involves multiple metrics that assess the effectiveness and accuracy of the recom-
mendations provided to users. Below are some of the most informative metrics commonly used in
this context, derived from the data and concepts surrounding recommendation systems. 1. Mean
Average Precision at K (MAPK) [...] 2. Precision and Recall [...] 3. Root Mean Squared
Error (RMSE) and Mean Squared Error (MSE) [...] 4. Area Under the Curve (AUC) [...] 5.
F-Measure [...] 6. User Engagement Metrics [...] Conclusion: A comprehensive evaluation of
movie recommendation systems employs a range of metrics that capture both the accuracy of the
recommendations and user satisfaction. By effectively leveraging these metrics, system designers
can optimize recommendation engines to deliver more personalized and relevant experiences.
LLM Decision
Comprehensiveness: "Winner": "Answer 2 (LightRAG)",
"Explanation": "Answer 2 provides a broader array of metrics including MAPK, AUC, and
user engagement metrics alongside precision, recall, RMSE, and F-Measure. This gives a fuller
view of how recommendation systems can be evaluated. Answer 1, while detailed, is more
focused on traditional metrics and lacks the inclusion of engagement metrics which are crucial for
understanding user interaction."
Diversity: "Winner": "Answer 2 (LightRAG)",
"Explanation": "Answer 2 not only covers a wide variety of metrics but also includes nuanced
explanations of how some metrics interrelate and differ from one another, like the inclusion of
both RMSE and MSE, as well as the details behind AUC. In contrast, Answer 1 sticks primarily to
standard metrics without much exploration of potential nuances."
Empowerment: "Winner": "Answer 2 (LightRAG)",
"Explanation": "Answer 2 empowers the reader more effectively by detailing how each metric
functions and its importance in evaluating recommendation systems. By providing context such as
the trade-offs between precision and recall and emphasizing user engagement metrics, it enables
readers to make more informed judgments and understand the implications of different metrics.
Answer 1 is more straightforward but lacks the depth of insight regarding why these metrics matter."
Overall Winner: "Winner": "Answer 2 (LightRAG)",
"Explanation": "While Answer 1 is more direct and systematic, Answer 2 excels in comprehen-
siveness, diversity, and empowerment. It provides a richer exploration of the topic, including
insights into user engagement and nuanced differences between metrics. This depth and breadth
make it more informative for readers seeking to thoroughly understand the evaluation of movie
recommendation systems."
10761


---

# Linking machine learning and biophysical structural features in drug discovery

- **Authors:** Armin Ahmadi, Shivangi Gupta, Vineetha Menon, Jerome Baudry
- **Issuer:** Frontiers in molecular biosciences
- **Type:** Scientific article
- **Published:** 2025-01-23
- **Language:** en
- **DOI:** 10.3389/fmolb.2024.1305272
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39917182/
- **Licence:** CC-BY

## Section: Abstract

AbstractIntroductionMachine learning methods were applied to analyze pharmacophore features derived from four protein-binding sites, aiming to identify key features associated with ligand-specific protein conformations.MethodsUsing molecular dynamics simulations, we generated an ensemble of protein conformations to capture the dynamic nature of their binding sites. By leveraging pharmacophore descriptors, the AI/ML framework prioritized features uniquely associated with ligand-selected conformations, enabling a mechanism-driven understanding of binding interactions. This novel approach integrates biophysical insights with machine learning, focusing on pharmacophoric properties such as charge, hydrogen bonding, hydrophobicity, and aromaticity.ResultsResults showed significant enrichment of true positive ligands—improving database enrichment by up to 54-fold compared to random selection—demonstrating the robustness of this approach across diverse proteins.ConclusionUnlike conventional structure-based or ligand-based screening methods, this work emphasizes the role of specific protein conformations in driving ligand binding, making the process highly interpretable and actionable for drug discovery. The key innovation lies in identifying pharmacophore features tied to conformations selected by ligands, offering a predictive framework for optimizing drug candidates. This study illustrates the potential of combining ML and pharmacophoric analysis to develop intuitive and mechanism-driven tools for lead optimization and rational drug design.Keywords: drug discovery, machine learning, pharmacophore, conformational selection, docking, ensemble docking, chemical biology

## Section: 1 Introduction

Contemporary approaches in computational drug discovery and computational chemical biology are mostly centered around protein: ligand predictions and rationalizations, in particular through using docking approaches. Docking is not only used to identify a specific binding mode for a particular ligand in a given protein target, but it is also used, and maybe mostly so nowadays, as a virtual screening tool that will “reduce the size of the chemical haystack” and allow a faster and more economical identification of drug candidate “needles.” There are many approaches, tools, and scales of virtual screening through docking. Our group and the groups of several colleagues and collaborators have experienced success over the last few years in ligand discovery by using more than one structure for the protein targets (Evangelista et al., 2016; Amaro et al., 2018; Evangelista et al., 2019). By success, we mean that the enrichment of a database in actual ligands after docking is significantly increased compared to the enrichment of the database in ligands prior to docking. We and our collaborators have achieved these results by modeling a conformational selection mechanism rather than an induced fit mechanism for ligand binding. In conformational selection, the ligands “select” specific protein conformations to form a protein–ligand combination that is thermodynamically favorable. The key to a successful docking campaign is as follows: like other groups, we mostly have used an ensemble docking method, where multiple protein conformations are generated using MD and used for in multiple-protein conformation docking calculations.

As specified above, this approach has not only proven valuable to vastly increase database enrichment by identifying in retrospect, from known ligands: decoys database, these protein conformations that are indeed massively selected by the proteins’ ligand. Over the last few years, our collaboration has used machine learning approaches to identify the properties that such specific protein conformations may possess that are associated with their selection by ligands (Akondi et al., 2019; Sripriya Akondi et al., 2022; Gupta et al., 2022a; Gupta et al. 2022b; Gupta et al. 2023). This was successful, but the approach used combination protein descriptors that are quite general and, not unlike the case of QSAR for ligand-based discovery, not necessarily easily explainable in terms of physical properties of the protein target’s selected conformations (Gupta et al., 2023).

As stated by the editors in the description of this special issue of Frontiers in Molecular Biosciences, there is a need for “research that utilizes ML protocols/architectures but offers a detailed and comprehensive interpretation of observed phenomena.” This work is the first step toward applying sophisticated machine learning approaches but, instead of processing arcane and obscure protein descriptors occasionally, we have used pharmacophoric descriptions of the protein target’s binding sites in this study (Śledź and Caflisch, 2018). This has the advantage of allowing a direct and straightforward rationalization of the binding site’s features associated with conformation selection, in terms of charges, hydrogen bond potential, hydrophobicity/hydrophilicity, and resonance of the protein environment, which are indeed concepts used to rationalize binding and optimize hits and leads (Leach et al., 2009).

## Section: 2 Methods

The four target proteins that were used in the present study as extensive molecular dynamics trajectories and characterization of the conformation, leading to ligand binding, are available (Evangelista et al., 2019; Gupta et al., 2022a; Gupta et al., 2023).

Target proteins and the PDB crystal structures used in this study.

Number of active and decoy ligands to each protein.

Flowchart illustrating the methodology employed in our study. The process begins with MD trajectory conformations and progresses through several stages, including conformation preparation, pharmacophore generation, and validation of pharmacophore models. AI/ML feature ranking framework integrates various statistical and analytical methods, resulting in a majority voting system to yield a refined set of features.

Details of sets of known ligands/decoys used.

## Section: 2 Methods › 2.1 Molecular dynamics

In this study, we used the molecular dynamics conformations obtained from MD simulations of a previous work in our laboratory, involving our four GPCR structures of interest [adenosine receptor A2A, β2-adrenergic receptor, δ-type opioid receptor, and κ-type opioid receptor, as listed in Table 1] (Evangelista et al., 2019). These structures were downloaded from the RCSB Protein Data Bank (RCSB-PDB) and were optimized by deleting non-native domains and co-crystallized ligands, and building missing loops. The proteins were then placed in a bilayer membrane with a lipid composition of phosphatidylcholine (42%), phosphatidylethanolamine (25%), phosphatidylserine (14%), and cholesterol (19%). Coarse-grained models were used to reduce the systems from approximately 125,000 full atoms to around 14,000 CG particles. Gromacs v5.1.0 software was used for 600-ns MD simulations, and frames were saved every 200 ps, representing 3,000 conformations for each protein. These simulations ran on the MolDyn High-Performance cluster at the UT/ORNL Center for Molecular Biophysics, Oak Ridge, Tennessee, provided the structural basis for our pharmacophore and machine learning analysis, offering insights into the dynamic nature of these proteins’ binding sites. In the current study, we used a set of 3,000 MD conformations for each of the proteins (i.e., 12,000 structures in total for the four proteins used here).

Target proteins and the PDB crystal structures used in this study.

## Section: 2 Methods › 2.2 Conformation preparation

All molecular dynamics conformations were imported in a MOE database (Molecular Operating Environment, Chemical Computing Group Ltd., Montreal, Canada, 2022). These conformations were then superposed on the first MD frame based on heavy atoms of the pocket residues. Atomic partial charges were assigned from the MMFF94x force field, as implemented in MOE.

## Section: 2 Methods › 2.3 Pharmacophore generation

The SiteFinder facility from MOE was used to identify potential active sites in the first conformation of the molecular dynamics trajectories with a focus on the known ligand-binding sites to concentrate on the most functionally significant areas of the proteins. SiteFinder is based on the concept of alpha shapes, which represent a more generalized form of convex hulls (Edelsbrunner and Mücke, 1994).

Pharmacophore feature generation was conducted using the DB-PH4 facility in MOE within a 6.5-Å cutoff from the SiteFinder binding site using the “unified scheme” pharmacophore definitions in MOE: hydrogen bond donor (Don); hydrogen bond acceptor (Acc); cation (Cat); anion (Ani); aromatic center or non-aromatic π-system ring, in which each atom is sp2 hybridized (Aro); and hydrophobic atoms and hydrophobic centers (Hyd).

The default pharmacophore radii sizes are set at 1.2 Å for Acc and Don features, 1.4 Å for aromatic centers, and 1.6 Å for hydrophobic features. Hydrophobic features that are within 1 Å to one another are clustered into a single feature with an increased radius, up to a maximum size of 3 Å. A Boolean “and” is defined for overlapping of “Don & Cat” or “Don & Acc” features. Finally, using the database autoPH4 facility in MOE, the pharmacophore features extracted from all protein MD trajectories are clustered together to create consensus features. These consensus features reflect the frequency with which specific pharmacophore features occur in a particular region of space in the database.

## Section: 2 Methods › 2.4 AI/ML feature ranking framework

The pharmacophores generated were first translated into a binary encoded database by utilizing the available frequency data. Later, it was then subjected to an AI/ML feature ranking framework to identify and choose distinctive pharmacophoric characteristics for each protein. The process of feature selection for developing a predictive model entails reducing the number of input variables. In some cases, limiting the amount of input variables may improve model performance while also cutting modeling computing costs.

The key approach here is to identify the pharmacophore features that are specifically associated with the protein conformations selected by the ligands. These selected conformations were identified and described in our previous work (Evangelista et al., 2019) and used in our previous publications (Gupta et al., 2022a; Gupta et al., 2023) to identify global protein properties correlated with ligand binding. Here, as described above, we are attempting to identify pharmacophore features associated with ligand binding rather than global—and often obscure—protein descriptors.

To do so, we used four different ML feature selection algorithms to identify the key pharmacophore properties and eliminate the redundant properties to maximize the prediction of probable protein-binding conformations while reducing dataset complexity. Analysis of variance (ANOVA), mutual information (MI), recurrence quantification analysis (RQA), and Spearman correlation are the four approaches used to identify pharmacophore features.

The linear association between the various pharmacophore features was determined using ANOVA, and the significant pharmacophore features with the greatest F-values were chosen (Johnson and Synovec, 2002). The F-value is a statistical test used to determine whether the predicted values of a quantitative variable among various pre-defined groups differ from one another. It is determined as the difference between the variances of the sample means and the variances of the individual samples. In our work, the ANOVA technique is applied between each feature and the target vector to obtain the F-value for each feature. The features are then ranked based on their F-value, where the higher the F-value, the more important the feature.

MI (Macedo et al., 2019) is a measure of how much information can be learned about a variable ‘P’ by utilizing a different random variable ‘Q.’ To understand the common information included in all pharmacophore features, the MI value for all pharmacophore descriptors is first calculated. If the MI value is ‘1,’ it is assumed that all the pharmacophore features share the same information, and if it is ‘0,’ it is assumed that none of the features share any common (or special) information, and pharmacophore properties with the greatest MI value were chosen.

In RQA, the measure utilized to rank the pharmacophore properties was entropy, which is the probability distribution of the diagonal line on the RQA plot (Eckmann et al., 1987). It facilitates research on the relationship between the RQA-based entropy measure and the likelihood of discovering probable protein-binding conformations in terms of the time–space evolution of protein conformations. The method contributes to the exploration of the relationship between RQA-based entropy and the likelihood of discovering probable protein-binding conformations.

In the Spearman correlation coefficient (Hauke and Kossowski, 2011), pharmacophore properties are sorted using the absolute value of the correlation coefficient. This approach facilitates the identification of highly correlated pharmacophoric features. The relevant formulas for the four feature selection methods are provided in Supplementary Information.

To identify the important pharmacophore features, a feature ranking score is computed based on the scores obtained from each of the individual methods and the features with the highest ranking score of ‘4’ are retained, indicating that all four ML feature selection approaches identify such a feature as potentially significant for binding.

## Section: 2 Methods › 2.5 Validation of pharmacophore models

The capacity of the pharmacophore models to identify the targets’ ligands in ensemble-based docking was assessed using databases of ligands and decoys.

Number of active and decoy ligands to each protein.

Flowchart illustrating the methodology employed in our study. The process begins with MD trajectory conformations and progresses through several stages, including conformation preparation, pharmacophore generation, and validation of pharmacophore models. AI/ML feature ranking framework integrates various statistical and analytical methods, resulting in a majority voting system to yield a refined set of features.

## Section: 2 Methods › 2.5 Validation of pharmacophore models › 2.5.1 Preparing DUD-E/GDD database—conformation generation

Two widely used publicly accessible datasets were used: i) the Directory of Useful Decoys, Enhanced (DUD-E) (Mysinger et al., 2012) that contains “active” (known ligands) and “decoy” compounds for multiple target receptors including ADORA2 and ADRB2, and ii) the GPCR Decoy Database (GDD) (Gatica and Cavasotto, 2011) that contains “active” and “decoy” molecules for OPRK1 and OPRD1 (Table 2). All active and decoy datasets were included in MOE databases, and their atomic charges were assigned using the MMFF94x force field implemented in MOE. Conformations of “active” and “decoys” were generated using the conformer generation function of the open-source chemistry toolbox Open Babel (O’Boyle et al., 2011). A Python script was developed in-house to process and automate conformer generation, and up to 100 unique conformers for molecules were generated and stored in an MOE database.

Number of active and decoy ligands to each protein.

## Section: 2 Methods › 2.5 Validation of pharmacophore models › 2.5.2 Pharmacophore search and enrichment calculation

The pharmacophoric features identified, as described in Section 2.4, were used to screen the compounds in the compounds’ databases described above. For every compound in the database, the conformation that showed the minimum RMSD between the pharmacophore query features and their respective ligand annotation points was defined as the best match (Lätti et al., 2016). Although every conformation of a molecule was evaluated against the pharmacophore model, only the best matched conformation was retained and stored in an MOE database, ensuring one representative conformation for each compound which passed the pharmacophore filter.

Following the pharmacophore search, the enrichment factor (EF) was calculated to evaluate the effectiveness of the pharmacophore models in differentiating active ligands from decoys. The EF was calculated using the below equation.

## Section: 2 Methods › 2.5 Validation of pharmacophore models › 2.5.3 Docking and enrichment calculation

The molecules that successfully passed the pharmacophore search were subsequently used for docking on their respective target receptors. The potential binding sites from MOE SiteFinder were used as binding sites for docking. The receptor was treated as rigid, and the binding poses were scored initially by London ΔG scoring, followed by a rescoring using GBVI/WSA ΔG (Labute, 2008). For each compound, the five highest ranked poses based on GBVI/WSA ΔG underwent refinement through molecular mechanics minimization, utilizing the MMFF94x force field followed by calculation of the MM-PBSA interaction energy, as implemented in MOE, between the docked compounds and the protein target. Docking was performed with pharmacophore placement constraint, which allows the binding modes: after the docking refinement stage, only the poses that align with the pharmacophore model are retained. Any docked pose that does not match the pharmacophore query is eliminated. Given that some ligands might be discarded during the docking calculations with pharmacophore placement, the EF was recalculated using Equation 1. Docking jobs were executed either on a local machine using 24 CPU cores or Alabama Supercomputer (ASC) using 60 cores.

The flowchart below (Figure 1) illustrates the methodology employed in our study.

Flowchart illustrating the methodology employed in our study. The process begins with MD trajectory conformations and progresses through several stages, including conformation preparation, pharmacophore generation, and validation of pharmacophore models. AI/ML feature ranking framework integrates various statistical and analytical methods, resulting in a majority voting system to yield a refined set of features.

## Section: 2 Methods › 2.6 Control calculations

Our AL-ML workflow was compared with three pharmacophore-based screening: ligand-based pharmacophores, pharmacophore models generated based on a single crystal structure, and models generated using multiple crystal structures. To make a comparison between our AL-ML method and ligand-based pharmacophore screening, the whole DUD-E or GDD/GLL databases were used, and after superposing all ligands on the co-crystallized ligand as the template, the consensus pharmacophore models were generated with the same number of pharmacophore features, as was achieved in the AL-ML workflow. These models were used to filter the databases of conformers to DUD-E for all four proteins. The AI-ML workflow was also compared to standard X-ray structure-based pharmacophore models, and the same method was followed but by using the co crystalized ligand (of PDB crystal structures in Table 1) in order to generate pharmacophore models. Enrichment was also calculated in the same way. Finally, we generated pharmacophore models following the same method proposed in Figure 1, excluding the AI/ML feature ranking, and using all available PDB crystal structures of the target receptors co-crystallized with unique ligands (Table 3). Pharmacophore features were generated on all prepared crystal structures within a 6.5-Å cutoff from the co-crystallized ligands. These features were then clustered to generate consensus features which summarize the pharmacophore features that are common to multiple structures. Pharmacophore features were sorted by their frequency (Equation 1). Final pharmacophore models were constructed by choosing six to eight features, prioritized based on their frequencies, from the top of the sorted feature list. The enrichment calculations in screening of known active ligands versus decoys were performed similarly as explained (Formula 1). No docking calculations were performed.

Details of sets of known ligands/decoys used.

## Section: 3 Results

All pharmacophore features generated for each protein receptor.

Important pharmacophore features selected using the AI/ML framework.

Number of pharmacophore features after applying thresholds of frequencies.

Maximum enrichments in case of each protein.

Enrichment of pharmacophore models.

Comparison between the AI-ML model and ligand-based pharmacophore models.

Comparison between the AI-ML model and X-ray structure-based pharmacophore models.

Selected PH4s from the AI/ML feature ranking framework.

Final pharmacophore models.

Final pharmacophore model of ADRB2.

Examples of the top scoring ligand in the final pharmacophore model.

## Section: 3 Results › 3.1 Pharmacophore models generated using all available MD conformations

After superposition of all 3,000 available conformations from MD trajectories for each of the four proteins of interest, the pharmacophore features generated, as described in Methods, are illustrated in Figure 2.

The number of pharmacophoric features listed in Figure 2 varies between ∼300 and ∼700, indicating that most binding site pharmacophores in a protein trajectory were present in several of the protein conformations. These pharmacophore features were run through the AI/ML workflow described above, and the output features were combined to create the final pharmacophore models, which were then selected for validation through pharmacophore search and docking, as described in Methods.

All pharmacophore features generated for each protein receptor.

## Section: 3 Results › 3.2 AI/ML framework

The number of pharmacophoric features identified as ‘important” for each of the four proteins is given in Table 5, line “no threshold”, i.e., including all pharmacophore features in ML processing.

In addition, we also used fractions of the pharmacophoric features that are not widely represented in the entire trajectory. The rationale behind that is that since the number of protein conformations selected by the ligand is a fraction of the total number of conformations sampled by the protein, the pharmacophore features associated with such conformations may be found less frequent but still passing the ML criteria and defined as ‘important.’ In other words, pharmacophore features found in most of the conformations may not be relevant for binding and may lead to oversampling.

We have, hence, used the ML approaches described above with only pharmacophore features present in up to 5%, 10%, 15%, 20%, or 25% of the total number of pharmacophores. The corresponding number of pharmacophores for each of the four proteins is given in Table 4, and the number of such pharmacophores passing the ML criteria is given in Table 5.

Important pharmacophore features selected using the AI/ML framework.

Number of pharmacophore features after applying thresholds of frequencies.

## Section: 3 Results › 3.3 Pharmacophore search and docking

The pharmacophore features listed in Table 5 were used as a filter for the compound databases, as described in Methods, i.e., with pharmacophore screening only along with pharmacophore-directed docking.

Table 6 shows the maximum enrichment by pharmacophore search achieved from each threshold range, and these results are summarized in Table 7. The overall enrichment varies from one protein to the other from a relatively mediocre 5.2 to a very high 54.3 The cloud of pharmacophoric features shown in Figure 2 is very large, in hundreds. For ADRB2, 6 out of 542 features selected using the AI/ML framework on a dataset with no threshold provided the best results in terms of enrichments, while in case of ADORA2A, limiting the data between a frequency threshold of 1% and 10% provided the highest enrichment. In the case of OPRK1, the best enrichment from the full 697 pharmacophores is found when processing pharmacophores present in up to 25% to achieve the highest enrichment ratio. In some cases, shown with NA in Table 6 below, we could not obtain any enrichment (either 0 actives or 0 compounds passed the pharmacophore filter). In the case of OPRD1, no clear results could be obtained without selecting manually seven pharmacophore features from the “no threshold” 34 features, suggesting a possible imbalance ratio of binding vs. non-binding conformations in the OPRD1 MD trajectory.

The comparison between our AI-ML approach and ligand-based pharmacophore models is summarized in Table 8, which shows a significant improvement in using the AI-ML platform in case of ADORA2A, ADRB2, and OPRK1, while a slight improvement in case of OPRD1 receptors. The comparison between our AI-ML approach and X-ray structure-based pharmacophore models, as shown in Table 9, showed improvement in screening actives versus decoys using our AI-ML workflow. Although in case of ADRB2, we observed a slight decrease in enrichment numbers, although both methods provided significant enrichment.

Additional research is necessary to more effectively and systematically handle the vast amount of available data, eliminate data redundancy and noise, and enhance the enrichment ratios. Potential strategies could include more fine-grained and bins of the number of pharmacophore features processed by ML, or clustering MD conformations prior to their use in this ensemble pharmacophore generation workflow, rather than using the whole MD trajectories, to limit potential data imbalance. The output of AI/ML feature ranking is shown in Table 10 and Figure 3.

In addition, a detailed example of one of these models with top scoring active ligands matching the pharmacophore features is shown in Figures 4, 5.

The advantages of the results shown in Figure 3 are clear: a limited number of pharmacophores, leading to an enrichment of databases in ligands versus decoys, which can be easily interpreted in terms of chemical and structural features. As shown in Figure 3 and Table 10, the number and locations of the pharmacophores are not identical for each of the four proteins. On one hand, this is not unexpected since the GPCR proteins used here have their own set of ligands. However, on the other hand, it is not possible to assertively assess, at this early stage of the research, how many other possible combinations of pharmacophores could be identified.

Maximum enrichments in case of each protein.

Enrichment of pharmacophore models.

Comparison between the AI-ML model and ligand-based pharmacophore models.

Comparison between the AI-ML model and X-ray structure-based pharmacophore models.

Selected PH4s from the AI/ML feature ranking framework.

Final pharmacophore models.

Final pharmacophore model of ADRB2.

Examples of the top scoring ligand in the final pharmacophore model.

## Section: 4 Discussion/conclusion

The work presented here is a first step toward using ML to process an ocean of structural and chemical protein properties to be used in ML in a way that makes the ML analysis easy, intuitive, and actionable for lead optimization. In Gupta et al. (2022a), we used feature scoring to identify unique descriptors that can aid in distinguishing between binding and non-binding protein descriptors, whereas in this work, we use the unique pharmacophores to be better able to identify actives from a dataset that consists of both actives and decoys. The aim of the AI/ML approach is to make the dataset less complex in both situations so that instead of requiring a supercomputer, we can perform all the computations locally. Table 11 shows the comparison of our current results to our previous (Gupta et al., 2022b) findings, where the enrichment ratio values were computed to validate the ML protein conformation selection/prediction framework. The results proposed here show that this is a possible goal that such medicinal chemistry-friendly properties lend themselves well to the kind of ML processing that is usually efficient for purely numerical—and very arcane—“haystacks of numbers.” Yet much more work is needed for 1) identifying the optimum ways to combine the pharmacophores and 2) characterize the specificity of not only the protein conformations selected by their ligands but also how the selected conformations differ between them. The ultimate goal, in fine, will be to identify—if they exist—the structural and chemical features that will lead to ligand binding of the trajectory of a novel protein, about which no or very little binding data are already known. This is a difficult, maybe distant, goal, but the road to success will undoubtedly require significant ML-based data analysis, justifying the efforts the community invests in ML and AI, as illustrated in this special issue of Frontiers in Molecular Biosciences.

Comparison between our current results and previous calculations.

## Section: Acknowledgments

The authors wish to acknowledge the very useful discussions they had with Chris Williams, from Chemical Computing Group in Montreal, Canada, on the pharmacophore generation algorithm in MOE and with Wilfredo Evangelista, from the Universidad Peruana Cayetano Heredia in Lima, Peru, on details of the MD simulation in Evangelista et al. (2019). The authors are very grateful to the editors of this special Frontiers issue for their efforts in making this issue a reality.

## Section: Funding Statement

The author(s) declare that financial support was received for the research, authorship, and/or publication of this article. The authors thank the University of Alabama in Huntsville, in particular the Chan Endowment, for the support of this project.

## Section: Data availability statement

The raw data supporting the conclusions of this article will be made available by the authors, without undue reservation.

## Section: Author contributions

AA: conceptualization, formal analysis, investigation, methodology, validation, and writing–original draft. SG: conceptualization, formal analysis, investigation, methodology, validation, writing–original draft, and project administration. VM: conceptualization, formal analysis, funding acquisition, investigation, methodology, project administration, resources, supervision, validation, and writing–original draft. JB: conceptualization, formal analysis, funding acquisition, investigation, methodology, project administration, resources, supervision, validation, and writing–original draft.

## Section: Conflict of interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Supplementary material

The Supplementary Material for this article can be found online at: https://www.frontiersin.org/articles/10.3389/fmolb.2024.1305272/full#supplementary-material

## Section: Associated Data › Data Availability Statement

The raw data supporting the conclusions of this article will be made available by the authors, without undue reservation.


---

# LLM-Based Multi-Agent Systems for Software Engineering: Literature Review, Vision, and the Road Ahead

- **Authors:** Junda He, Christoph Treude, David Lo
- **Issuer:** ACM Transactions on Software Engineering and Methodology
- **Type:** Scientific article
- **Published:** 2025-01-13
- **Language:** en
- **DOI:** 10.1145/3712003
- **Source:** https://doi.org/10.1145/3712003
- **Licence:** CC-BY

## Page 1 (Section: Abstract)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
JUNDA HE, Singapore Management University, Singapore
CHRISTOPH TREUDE, Singapore Management University, Singapore
DAVID LO, Singapore Management University, Singapore
Integrating Large Language Models (LLMs) into autonomous agents marks a significant shift in the research
landscape by offering cognitive abilities that are competitive with human planning and reasoning. This
paper explores the transformative potential of integrating Large Language Models into Multi-Agent (LMA)
systems for addressing complex challenges in software engineering (SE). By leveraging the collaborative and
specialized abilities of multiple agents, LMA systems enable autonomous problem-solving, improve robustness,
and provide scalable solutions for managing the complexity of real-world software projects. In this paper,
we conduct a systematic review of recent primary studies to map the current landscape of LMA applications
across various stages of the software development lifecycle (SDLC). To illustrate current capabilities and
limitations, we perform two case studies to demonstrate the effectiveness of state-of-the-art LMA frameworks.
Additionally, we identify critical research gaps and propose a comprehensive research agenda focused on
enhancing individual agent capabilities and optimizing agent synergy. Our work outlines a forward-looking
vision for developing fully autonomous, scalable, and trustworthy LMA systems, laying the foundation for the
evolution of Software Engineering 2.0.
CCS Concepts: • Software and its engineering →Software development techniques; Collaboration in
software development.
Additional Key Words and Phrases: Large Language Models, Autonomous Agents, Multi-Agent Systems,
Software Engineering
ACM Reference Format:
Junda He, Christoph Treude, and David Lo. 2025. LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead. 1, 1 (July 2025), 30 pages. https://doi.org/10.1145/nnnnnnn.
nnnnnnn
1
INTRODUCTION
Autonomous agents, defined as intelligent entities that autonomously perform specific tasks through
environmental perception, strategic self-planning, and action execution [6, 36, 98], have emerged
as a rapidly expanding research field since the 1990s [93]. Despite initial advancements, these early
iterations often lack the sophistication of human intelligence [127]. However, the recent advent
of Large Language Models (LLMs) [65] has marked a turning point. This LLM breakthrough has
demonstrated cognitive abilities nearing human levels in planning and reasoning [3, 65], which
aligns with the expectations for autonomous agents. As a result, there is an increased research
Authors’ addresses: Junda He, jundahe@smu.edu.sg, Singapore Management University, 80 Stamford Rd., 178902, Singapore,
Singapore; Christoph Treude, ctreude@smu.edu.sg, Singapore Management University, 80 Stamford Rd., 178902, Singapore,
Singapore; David Lo, davidlo@smu.edu.sg, Singapore Management University, 80 Stamford Rd., 178902, Singapore, Singapore.
Permission to make digital or hard copies of all or part of this work for personal or classroom use is granted without fee
provided that copies are not made or distributed for profit or commercial advantage and that copies bear this notice and
the full citation on the first page. Copyrights for components of this work owned by others than ACM must be honored.
Abstracting with credit is permitted. To copy otherwise, or republish, to post on servers or to redistribute to lists, requires
prior specific permission and/or a fee. Request permissions from permissions@acm.org.
© 2025 Association for Computing Machinery.
XXXX-XXXX/2025/7-ART $15.00
https://doi.org/10.1145/nnnnnnn.nnnnnnn
, Vol. 1, No. 1, Article . Publication date: July 2025.
arXiv:2404.04834v4  [cs.SE]  18 Jul 2025

## Page 2 (Section: Abstract)

2
Junda He, Christoph Treude, and David Lo
interest in integrating LLMs at the core of autonomous agents [90, 134, 148] (for short, we refer to
them as LLM-based agents in this paper).
Nevertheless, the application of singular LLM-based agents encounters limitations, since real-
world problems often span multiple domains, requiring expertise from various fields. In response
to this challenge, developing LLM-Based Multi-Agent (LMA) systems represents a pivotal evolution,
aiming to boost performance via synergistic collaboration. An LMA system harnesses the strengths
of multiple specialized agents, each with unique skills and responsibilities. These agents work in
concert towards a common goal, engaging in collaborative activities like debate and discussion.
These collaborative mechanisms have been proven to be instrumental in encouraging divergent
thinking [80], enhancing factuality and reasoning [32], and ensuring thorough validation [146]. As
a result, LMA systems hold promise in addressing a wide range of complicated real-world scenarios
across various sectors [49, 131, 137], such as software engineering [48, 75, 90, 109].
The study of software engineering (SE) focuses on the entire lifecycle of software systems [63],
including stages like requirements elicitation [39], development [2], and quality assurance [126],
among others. This multifaceted discipline requires a broad spectrum of knowledge and skills to
effectively tackle its inherent challenges in each stage. Integrating LMA systems into software
engineering introduces numerous benefits:
(1) Autonomous Problem-Solving: LMA systems can bring significant autonomy to SE tasks. It
is an intuitive approach to divide high-level requirements into sub-tasks and detailed imple-
mentation, which mirrors agile and iterative methodologies [68] where tasks are broken down
and assigned to specialized teams or individuals. By automating this process, developers are
freed to focus on strategic planning, design thinking, and innovation.
(2) Robustness and Fault Tolerance: LMA systems address robustness issues through cross-
examination in decision-making, akin to code reviews and automated testing frameworks, thus
detecting and correcting faults early in the development process. On their own, LLMs may
produce unreliable outputs, known as hallucination [151, 164], which can lead to bugs or system
failure in software development. However, by employing methods like debating, examining,
or validating responses from multiple agents, LMA systems ensure convergence on a single,
more accurate, and robust solution. This enhances the system’s reliability and aligns with best
practices in software quality assurance.
(3) Scalability to Complex Systems: The growth in complexity of software systems, with increas-
ing lines of code, frameworks, and interdependencies, demands scalable solutions in project
management and development practices. LMA systems offer an effective scaling solution by
incorporating additional agents for new technologies and reallocating tasks among agents based
on evolving project needs. LMA systems ensure that complex projects, which may be over-
whelming for individual developers or traditional teams, can be managed effectively through
distributed intelligence and collaborative agent frameworks.
Existing research has illuminated the critical roles of these collaborative agents in advancing
toward the era of Software Engineering 2.0 [90]. LMA systems are expected to significantly speed up
software development, drive innovation, and transform the current software engineering practices.
This article aims to delve deeper into the roles of LMA systems in shaping the future of software
engineering. It spotlights the current progress, emerging challenges, and the road ahead. We provide
a systematic review of LMA applications in SE, complemented by two case studies that assess
current LMA systems’ capabilities and limitations. From this analysis, we identify key research
gaps and propose a comprehensive agenda structured in two phases: (1) enhancing individual agent
capabilities and (2) optimizing agent collaboration and synergy. This roadmap aims to guide the
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 3 (Section: 2 Preliminary)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
3
development of autonomous, scalable, and trustworthy LMA systems, paving the way for the next
generation of software engineering
To summarize, this study makes the following key contributions:
• We conduct a systematic review of 71 recent primary studies on the application of LMA systems
in software engineering.
• We perform two case studies to illustrate the current capabilities and limitations of LMA systems.
• We identify the key research gaps and propose a structured research agenda that outlines potential
future directions and opportunities to advance LMA systems for software engineering tasks.
2
PRELIMINARY
2.1
Autonomous Agent
An autonomous agent is a computational entity designed for independent and effective operation
in dynamic environments [98]. Its essential attributes are:
• Autonomy: Independently manages its actions and internal state without external controls.
• Perception: Detects the changes in the surrounding environment through sensory mechanisms.
• Intelligence and Goal-Driven: Aims for specific goals using domain-specific knowledge and
problem-solving abilities.
• Social Ability: Can interact with humans or other agents, manages social relationships to
achieve goals.
• Learning Capabilities: Continuously adapts, learns, and integrates new knowledge and experi-
ences.
2.2
LLM-based Autonomous Agent
Formally speaking, an LLM-based agent can be described by the tuple ⟨𝐿,𝑂, 𝑀, 𝑃,𝐴, 𝑅⟩[24], where:
• 𝐿symbolizes the Large Language Model, serving as the agent’s cognitive core. It is equipped
with extensive knowledge, potentially fine-tuned for specific domains, allowing it to make
informed decisions based on observations, feedback, and rewards. Typically, an LLM suited for
this role is trained on vast corpora of diverse textual data and comprises billions of parameters,
such as models like ChatGPT1, Claude2, and Gemini3. These models exhibit strong zero-shot and
few-shot learning capabilities, meaning they can generalize well to new tasks with little to no
additional training. Interaction with the LLM typically occurs through prompts, which guide its
reasoning and responses.
• 𝑂stands for the Objective, the desired outcome or goal the agent aims to achieve. This defines
the agent’s focus, driving its strategic planning and task breakdown.
• 𝑀represents Memory, which holds information on both historical and current states, as well as
feedback from external interactions.
• 𝑃represents Perception, which represents the agent’s ability to sense, interpret, and understand
its surroundings and inputs. This perception can involve processing structured and unstructured
data from various sources such as text, visual inputs, or sensor data. Perception allows the agent
to interpret the environment, transforming raw information into meaningful insights that guide
decision-making and actions.
• 𝐴signifies Action, encompassing the range of executions of the agent, from utilizing tools to
communicating with other agents.
1https://openai.com/chatgpt/
2https://claude.ai/
3https://gemini.google.com/app
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 4 (Section: 2.3 LLM-Based Multi-Agent Systems)

4
Junda He, Christoph Treude, and David Lo
• 𝑅refers to Rethink, a post-action reflective thinking process that evaluates the results and
feedback, along with stored memories. Guided by this insight, the LLM-based agent then takes
subsequent actions.
2.3
LLM-Based Multi-Agent Systems
A multi-agent system is a computational framework composed of multiple interacting intelligent
agents that interact and collaborate to solve complex problems or achieve goals beyond the capability
of any single agent [144]. These agents communicate, coordinate, and share knowledge, often
bringing specialized expertise to address tasks across diverse domains.
With the integration of LLMs, LLM-Based Multi-Agent Systems have emerged. In this paper, we
define that an LMA system comprises two primary components: an orchestration platform and
LLM-based agents.
2.3.1
Orchestration Platform. The orchestration platform serves as the core infrastructure that
manages interactions and information flow among agents. It facilitates coordination, communica-
tion, planning, and learning, ensuring efficient and coherent operation. The orchestration platform
defines various key characteristics:
(1) Coordination Models: Defines how agents interact, such as cooperative (collaborating towards
shared goals) [1], competitive (pursuing individual goals that may conflict) [147], hierarchical
(organized with leader-follower relationships) [166], or mixed models.
(2) Communication Mechanisms: Determines how the information flows between the agents: It
defines the organization of communication channels, including centralized (a central agent
facilitates communication [4]), decentralized (agents communicate directly [22]), or hierar-
chical (information flows through layers of authority [166]). Moreover, it specifies the data
exchanged among agents, often in text form. In software engineering contexts, this may include
code snippets, commit messages [169], forum posts [42–44], bug reports [12], or vulnerability
reports [55].
(3) Planning and Learning Styles: The orchestration platform specifies how planning and learning are
conducted within the multi-agent system. It determines how tasks are allocated and coordinated
among agents. It includes strategies like Centralized Planning, Decentralized Execution (CPDE)
– planning is conducted centrally, but agents execute tasks independently, or Decentralized
Planning, Decentralized Execution (DPDE) – both planning and execution are distributed among
agents.
2.3.2
LLM-Based Agents. Each agent may have unique abilities and specialized roles, enhancing
the system’s ability to handle diverse tasks effectively. Agents can be:
(1) Predefined or Dynamically Generated: Agent profiles can be explicitly predefined [48] or
dynamically generated by LLMs [134], allowing for flexibility and adaptability.
(2) Homogeneous or Heterogeneous: Agents may have identical functions (homogeneous) or
diverse functions and expertise (heterogeneous).
Each LLM-based agent can be represented as a node 𝑣𝑖in a graph 𝐺(𝑉, 𝐸), where edges 𝑒𝑖,𝑗∈𝐸
represent interactions between agents 𝑣𝑖and 𝑣𝑗.
3
LITERATURE REVIEW
In this section, we review recent studies on LMA systems in software engineering, organizing these
applications across various stages of the software development lifecycle, including requirements
engineering, code generation, quality assurance, and software maintenance. We also examine
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 5 (Section: 2.3 LLM-Based Multi-Agent Systems)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
5
studies on LMA systems for end-to-end software development, covering multiple SDLC phases
rather than isolated stages.
Search Strategy: We conduct a keyword-based search on the DBLP publication database [28] to
match paper titles. DBLP is a widely used resource in software engineering surveys [20, 23, 161],
which indexes over 7.5 million publications across 1,800 journals and 6,700 academic conferences
in computer science.
Our search included two sets of keywords: one set targeting LLM-based Multi-Agent Systems
(called [agent words]) and the other focusing on specific software engineering activities (called
[SE words]). Papers may use variations of the same keyword. For example, the term “vulnerability”
may appear as “vulnerable” or “vulnerabilities.” To address this, we use truncated terms like
“vulnerab” to capture all related forms. For LMA systems, we used keywords: “Agent” OR “LLM” OR
“Large Language Model” OR “Collaborat”. To ensure comprehensive coverage of SE activities, we
incorporated phase-specific keywords for each stage of the SDLC into our search queries:
(1) Requirements Engineering: requirement, specification, stakeholder
(2) Code Generation: software, code, coding, program
(3) Quality Assurance: bug, fault, defect, fuzz, test, vulnerab, verificat, validat
(4) Maintenance: debug, repair, review, refactor, patch, maintenanc
We focus on four key phases of the SDLC: requirements engineering, code generation, quality
assurance, and software maintenance. For each phase, the relevant SE keywords are combined
using the OR operator to capture all variations. The final search query for each SDLC phase follows
the format: [agent words] AND [SE words].
Following the guide of previous work [99, 128, 168], we design the following inclusion and
exclusion criteria. In the first phase, we filtered out short papers (exclusion criterion 1) and removed
duplicates (exclusion criterion 2). In the second phase, we manually screened each paper’s venue,
title, and abstract, excluding items such as books, keynote speeches, panel summaries, technical
reports, theses, tool demonstrations, editorials, literature reviews, and surveys (exclusion criteria
3 and 4). In the third phase, we conducted a full-text review to further refine relevant studies.
Following Section 2.3, we exclude papers that do not describe LMA systems (exclusion criterion 5).
Papers that rely solely on LLMs using non-agent-based methods or single-agent approaches are
excluded. Further, we focused on LMA systems powered by LLMs with strong planning capabilities,
such as ChatGPT and LLaMA, excluding models like CodeBERT and GraphCodeBERT. Since the
release of ChatGPT is in November 2022, we limited our review to papers published after this
date (exclusion criterion 6). Furthermore, we excluded papers unrelated to software engineering
(exclusion criterion 7) and those that mention LMA systems only in discussions or as future work,
without presenting experimental results (exclusion criterion 8). After the third phase, we identified
41 primary studies directly relevant to our research focus. The search process is conducted on
November 14th, 2024.
! The paper must be written in English.
! The paper must have an accessible full text.
! The paper must adopt LMA techniques to solve software engineering-related tasks.
% The paper has less than 5 pages.
% Duplicate papers or similar studies authored by the same authors.
% Books, keynote records, panel summaries, technical reports, theses, tool demos papers, editorials
% The paper is a literature review or survey.
% The paper does not utilize LMA systems, e.g., using a single LLM agent.
% The paper is published before November 2022 (the release date of ChatGPT).
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 6 (Section: 3.1 Requirements Engineering)

6
Junda He, Christoph Treude, and David Lo
% The paper does not involve software engineering related tasks.
% The paper lacks experimental results and mentions LMA systems only in future work or discussions.
Snowballing Search To expand our review, we conducted both backward and forward snow-
balling [143] on the relevant papers identified in previous steps. This process involved examining
the references cited by the relevant studies as well as publications that have cited these studies.
We repeated the snowballing process until reaching a transitive closure fixed point, where no new
relevant papers were found, resulting in an additional 30 papers identified.
3.1
Requirements Engineering
Requirements Engineering [91, 129] focuses on defining and managing software system require-
ments. This discipline is divided into several key stages to ensure requirements meet quality
standards and align with stakeholder needs. These stages include elicitation, modeling, specifica-
tion, analysis, and validation [25, 46].
Elicitron [9] is an LMA framework that focuses specifically on the elicitation stage. It utilizes
LLM-based agents to represent a diverse array of simulated users. These agents engage in simulated
product interactions, providing insights into user needs by articulating their actions, observations,
and challenges. MARE [59] is an LMA framework that covers multiple phases of requirements
engineering, including elicitation, modeling, verification, and specification. It employs five distinct
agents, i.e., stakeholder, collector, modeler, checker, and documenter, performing nine actions
to help generate high-quality requirements models and specifications. Sami et al. [115] propose
another LMA framework to generate, evaluate, and prioritize user stories through a collaborative
process involving four agents: product owner, developer, quality assurance (QA), and manager.
The produce owner generates user stories and initiates prioritization. The QA agent assesses story
quality and identifies risks, while the developer prioritizes based on technical feasibility. Finally,
the manager synthesizes these inputs and finalizes prioritization after discussions with all agents
3.2
Code Generation
Code generation [15, 45] has consistently been a longstanding focus of software engineering
research, aiming to automate coding tasks to boost productivity and minimize human error.
A prominent multi-agent setup for code generation typically on role specialization and iterative
feedback loops to optimize collaboration among agents. We summarize the common roles identified
in the literature, including the Orchestrator, Programmer, Reviewer, Tester, and Information Retriever.
The Orchestrator acts as the central coordinator, managing high-level planning and ensuring
smooth task execution across all agents. Its responsibilities include defining high-level strategic
goals, breaking them into actionable sub-tasks, delegating these tasks to the appropriate agents,
monitoring progress, and ensuring that workflows align with overall project objectives [17, 56,
60, 75, 76, 106, 155, 158]. For instance, PairCoder [158] features a Navigator agent that interprets
natural language descriptions to create high-level plans outlining solutions and key implementa-
tion steps. The Driver agent then follows these plans to handle code generation and refinement.
The Self-Organized Agents (SoA) framework [56] employs a hierarchical design, with Mother
agents managing high-level abstractions and delegating subtasks to specialized Child agents. In
CODES [155], the Orchestrator role is performed by the RepoSketcher, which converts high-level
natural language requirements into a repository sketch. This sketch outlines the project structure,
including directories, files, and inter-file dependencies. The RepoSketcher then delegates tasks
to the FileSketcher and SketchFiller, ensuring the efficient and seamless creation of a complete,
functional code repository.
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 7 (Section: 3.3 Software Quality Assurance)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
7
During the implementation phase, the process typically begins with the Programmer, who is
responsible for writing the initial version of the code. Once the initial code is produced, roles
like the Reviewer and Tester step in to evaluate it, providing constructive feedback on quality,
functionality, and adherence to requirements. This feedback initiates an iterative cycle, where the
Programmer refines the code or the Debugger resolves identified issues, ensuring that the final
code meets the desired standards and performs as expected [21, 31, 69, 72, 81, 88, 96, 102, 132].
For example, INTERVENOR [132] pairs a Code Learner with a Code Teacher. The Code Learner
generates the initial code and then compiles it to evaluate its correctness. If issues are identified,
the Code Teacher analyzes the bug reports and the buggy code, subsequently providing repair
instructions to address the errors. Self-repair [102] and TGen [96] refine code by utilizing feedback
obtained from running pre-defined test cases.
When predefined test cases are unavailable, the Tester can generate a variety of test cases, ranging
from common scenarios to edge cases. These tests help uncover subtle issues that might otherwise
go unnoticed and provide actionable feedback to guide subsequent refinement iterations [53, 54, 56,
117].
Some frameworks employ the Information Retriever to gather relevant information to assist
code generation. For instance, Agent4PLC [87] and MapCoder [57] incorporate a Retrieval Agent
tasked with sourcing examples of similar problems and extracting related knowledge. This agent
provides essential contextual information and references tailored to the user’s input, ensuring that
solutions are well-informed and adhere to domain-specific best practices. Similarly, CodexGraph [85]
employs a translation agent to facilitate interaction with graph databases, which are built using
static analysis to extract code symbols and their relationships. By converting user queries into
graph query language, this agent enables precise and structured information retrieval, enhancing
the capability of LLM-based agents to navigate and utilize code repositories effectively.
Agent Forest [77] adopts a different paradigm instead of role specialization. Instead, it utilizes a
sampling-and-voting framework, where multiple agents independently generate candidate outputs.
Each output is then evaluated based on its similarity to the others, with a cumulative similarity
score calculated for each. The output with the highest score—indicating the greatest consensus
among the agents—is selected as the final solution.
3.3
Software Quality Assurance
In this subsection, we review related work on testing, vulnerability detection, bug detection, and
fault localization, with a focus on how LMA systems are being employed to enhance software
quality assurance processes.
Testing. Fuzz4All [149] generates testing input for software systems across multiple programming
languages. In this framework, a distillation agent reduces user input while a generation agent
creates and mutates inputs. AXNav [123] is designed to automate accessibility testing. It interprets
natural language test instructions and executes accessibility tests, such as VoiceOver, on iOS devices.
AXNav includes a planner agent, an action agent, and an evaluation agent. WhiteFox [150] is a
fuzzing framework that tests compiler optimizations. It uses two LLM-based agents: one extracts
requirements from source code, and the other generates test programs. Additionally, LMA systems
are employed for tasks such as penetration testing [29], user acceptance testing [139], and GUI
testing [154].
Vulnerability Detection. GPTLens [51] is an LMA framework for detecting vulnerabilities in
smart contracts. The system includes LLM-based agents acting as auditors, each independently
identifying vulnerabilities. A critic agent then reviews and ranks these vulnerabilities, filtering
out false positives and prioritizing the most critical ones. MuCoLD [94] assigns roles like tester
and developer to evaluate code. Through discussions and iterative assessments, the agents reach
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 8 (Section: 3.4 Software Maintenance)

8
Junda He, Christoph Treude, and David Lo
a consensus on vulnerability classification. Widyasari et al. [142] introduces a cross-validation
technique, where multiple LLM’s answer is validated against each other.
Bug Detection. Intelligent Code Analysis Agent (ICAA) [35] is used for bug detection in static code
analysis. The agents have access to tools like web search, static analysis, and code retrieval tools. A
Report Agent generates bug reports, while a False Positive Pruner Agent refines these reports to
reduce false positives. Additionally, ICAA includes Code-Intention Consistency Checking, which
ensures the code aligns with the developer’s intended functionality by analyzing code comments,
documentation, and variable names.
Fault Localiztion. RCAgent [138] performs root cause analysis in cloud environments by using
LLM-based agents to collect system data, analyze logs, and diagnose issues. AgentFL [110] breaks
down fault localization into three phases. The Comprehension Agent identifies potential fault
areas, the Navigation Agent narrows down the codebase search, and the Confirmation Agent uses
debugging tools to validate the faults.
3.4
Software Maintenance
In this subsection, we explore related work on debugging and code review, highlighting how LMA
systems contribute to automating and improving software maintenance processes.
Debugging. Debugging involves identifying, locating, and resolving software bugs. Several frame-
works, including MASAI [8], MarsCode [86], AutoSD [64], and others [19, 73, 92, 125], follow a
structured process consisting of stages like bug reproduction, fault localization, patch generation,
and validation. Specialized agents are typically responsible for each stage. FixAgent [70] includes a
debugging agent and a program repair agent that work together to iteratively fix code by analyzing
both errors and repairs. The system refines fault localization by incorporating repair feedback. The
agents also articulate their thought processes, improving context-aware debugging. The MASTER
framework [152] employs three specialized agents. The Code Quizzer generates quiz-like questions
from buggy code, the Learner proposes solutions, and the Teacher reviews and refines the Learner’s
responses. AutoCodeOver [165] uses an agent for fault localization via spectrum-based methods,
collaborating with others to refine patches using program representations like abstract syntax trees.
SpecRover [113] extends AutoCodeOver by improving program fixes through iterative searches
and specification analysis based on inferred code intent. ACFIX [160] targets access control vul-
nerabilities in smart contracts, focusing on Role-Based Access Control. It mines common RBAC
patterns from over 344,000 contracts to guide agents in generating patches. DEI [159] resolves
GitHub issues by using a meta-policy to select the best solution, integrating and re-ranking patches
generated by different agents for improved issue resolution. SWE-Search [7] consists of three agents:
the SWE-Agent for adaptive exploration, the Value Agent paired with a Monte Carlo tree search
module for iterative feedback and utility estimation, and the Discriminator Agent for collaborative
decision-making through debate. RepoUnderstander [92] constructs a knowledge graph for a full
software repository and also uses Monte Carlo tree search to assist in understanding complex
dependencies.
Code Review. Rasheed et al. [111] developed an automated code review system that identifies
bugs, detects code smells, and provides optimization suggestions to improve code quality and
support developer education. This system uses four specialized agents focused on code review,
bug detection, code smells, and optimization. Similarly, CodeAgent [124] performs code reviews
with sub-tasks such as vulnerability detection, consistency checking, and format verification. A
supervisory agent, QA-Checker, ensures the relevance and coherence of interactions between
agents during the review process.
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 9 (Section: 3.5 End-to-end Software Development)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
9
Requirements
Design
Maintenance
Development
Testing
Development
Planning
Testing
Review
Sprint
Backlog
Waterfall
Agile
Fig. 1. Multi-Agent Systems in Software Development: Waterfall vs. Agile Models
Test Case Maintenance. Lemner et al. [74] propose two multi-agent architectures to predict
which test cases need maintenance after source code changes. These agents perform tasks including
summarizing code changes, identifying maintenance triggers, and localizing relevant test cases.
3.5
End-to-end Software Development
End-to-end software development encompasses the entire process of creating a software product.
While conventional code generation is often limited to producing isolated components such as
functions, classes, or modules, end-to-end development starts from high-level software requirements
and progresses through design, implementation, testing, and ultimately delivering a fully functional
and ready-to-use product.
In practice, developers and stakeholders typically adopt established software process models to
guide collaboration, such as Agile [26] and Waterfall [105]. Similarly, the design of LMA systems
for end-to-end software development draws inspiration from these software process models. The
development process is organized into distinct phases, such as requirements gathering, software
design, implementation, and testing. Each phase is managed by specialized agents with domain
expertise.
It is important to note that works such as FlowGen [81] and Self-Collaboration [31] emulate
various software process models. However, their experiments focus on generating code segments
rather than delivering fully developed software products. As a result, in this paper, these approaches
are not considered to be designed for true end-to-end software development.
Several works [33, 47, 48, 109, 112, 114, 155, 162] adopt the Waterfall model to automate software
development. The Waterfall model used in these multi-agent methods organizes the software
development process into distinct, sequential phases, where each stage must be completed before
proceeding to the next. The primary phases typically include Requirement Analysis, Architecture
Design, Code Development, Testing, and Maintenance. For instance, in MetaGPT [48], the Product
Manager agent thoroughly analyzes user requirements. The Architect agent then transforms these
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 10 (Section: 4 Case Study)

10
Junda He, Christoph Treude, and David Lo
requirements into detailed system design components. Subsequently, the Engineer implements
the specified classes and functions as outlined in the design. Finally, the Quality Assurance En-
gineer creates and executes test cases to ensure rigorous code quality standards are met. These
approaches emphasize a linear and sequential design process, ensuring structured progression and
clear accountability at each stage.
AgileCoder [101] and AgileGen [163] adopt Agile process models for software development,
emphasizing iterative development by breaking complex tasks into small, manageable increments.
AgileCoder [101] assigns Agile roles such as Product Manager and Scrum Master to facilitate sprint-
based collaboration and development cycles. AgileGen enhances Agile practices with human-AI
collaboration, integrating close user involvement to ensure alignment between requirements and
generated code. A notable feature of AgileGen is its use of the Gherkin language to create testable
requirements, bridging the gap between user needs and code implementation.
While most methods rely on predefined roles and fixed workflows for software development,
a few work [78, 82, 135] investing in dynamic process models. Think-on-Process (ToP) [82] in-
troduces a dynamic process generation framework. Since software development processes can
vary significantly depending on project requirements, ToP moves beyond the limitations of static,
one-size-fits-all workflows to enable more flexible and efficient development practices. Given a
software requirement, this framework leverages LLMs to create tailored process instances based on
their knowledge of software development. These instances act as blueprints to guide the architec-
ture of the LMA system, adapting to the specific and diverse needs of different projects. Similarly,
in MegaAgent [135], agent roles and tasks are not predefined but are generated and planned
dynamically based on project requirements. Both ToP and MegaAgent highlight the shift from
rigid, static workflows to dynamic, adaptive systems. These frameworks promise more efficient,
flexible, and context-aware software development practices, aligning processes with project-specific
requirements and complexities.
Additionally, instead of focusing on the process model, several works [107, 108] explore lever-
aging experiences from past software projects to enhance new software development efforts.
Co-Learning [107] enhances agents’ software development abilities by utilizing insights gathered
from historical communications. This framework fosters cooperative learning between two agent
roles—instructor and assistant—by extracting and applying heuristics from their task execution
histories. Building on this, Qian et al. [108] propose an iterative experience refinement (IER) frame-
work that enables agents to continuously adapt by acquiring, utilizing, and selectively refining
experiences from previous tasks, improving agents’ effectiveness and collaboration in dynamic
software development scenarios.
4
CASE STUDY
To demonstrate the practical effectiveness of LMA systems, we conduct two case studies. Specif-
ically, we utilize the state-of-the-art LMA framework, ChatDev [109], to autonomously develop
two classic games: Snake and Tetris. ChatDev structures the software development process into
three phases: designing, coding, and testing. ChatDev employs specialized roles, including CEO,
CTO, programmer, reviewer, and tester. ChatDev’s agents are powered by GPT-3.5-turbo4. The
temperature setting controls the randomness and creativity of the GPT-3.5’s responses. Following
the original ChatDev setting, we set the temperature of GPT-3.5-turbo as 0.2.
4.1
Snake Game
For the Snake game, we provide the following prompt to ChatDev to generate the game:
4https://platform.openai.com/docs/models/gp#gpt-3-5-turbo
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 11 (Section: 4.2 Tetris Game)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
11
Fig. 2. Screen shots of the Snake Game generated by ChatDev.
Snake Game Prompt
“Design and implement a grid-based snake game displayed on the screen. Initialize the snake
with a defined starting position, length, and direction. Enable continuous movement controlled
by arrow keys. Introduce food that spawns randomly on the grid, ensuring it does not overlap
with the snake. Trigger snake growth when food is consumed, adding a new segment to its
body. Implement a game-over condition for boundary or body collisions, displaying a message
and providing a restart option. Include a scoring system displayed in the user interface, along
with clear instructions. ”
While the first attempt to generate the Snake game was unsuccessful, we resubmitted the same
prompt to ChatDev, and the second attempt successfully produced a playable version. ChatDev also
generated a detailed manual that included information on dependencies, step-by-step instructions
for running the game, and an overview of its features. Figure 2 displays the graphical user interfaces
(GUIs) of the generated Snake game, showing the starting state, in-game state, and game-over state.
The development process was consistently efficient, taking an average of 76 seconds and costing
$0.019. Upon playing the game, we confirmed that it fulfilled all the requirements outlined in the
prompt.
4.2
Tetris Game
We present the following prompt to ChatDev to guide the generation of the Tetris game:
Tetris Game Prompt
“Design and implement a Tetris game. Start with a randomly chosen piece dropping from
the top. Allow players to control the tetromino using arrow keys for movement (left, right,
down) and rotation. Enable automatic downward movement with an adjustable speed. Handle
collisions with the boundaries and existing pieces, locking the tetromino in place when it cannot
move further. Check for complete rows after each placement and remove them. End the game
if new tetrominoes cannot spawn due to a full board, displaying a game over message.”
During development, ChatDev faced challenges in producing functional gameplay across the
first nine attempts. Notice that the same prompt was used for each run. On the tenth attempt,
ChatDev successfully produced a Tetris game that met most of the prompt requirements, as shown
in Figure 3. The figure illustrates the game’s key states: the starting state, in-game states, and
game-over state. However, the game still lacks the core functionality to remove completed rows, as
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 12 (Section: 5 Research Agenda)

12
Junda He, Christoph Treude, and David Lo
Fig. 3. Screen shots of the Tetris Game generated by ChatDev.
demonstrated in the third subplot of Figure 3. Overall, the development process remained efficient,
with an average time of 70 seconds and a cost of $0.020 per attempt.
Summary of Findings. From our case studies, current LMA systems demonstrate strong per-
formance in reasonably complex tasks like developing a Snake game. The generated Snake game
meets all requirements in the prompt within just a few iterations. The process was efficient and
cost-effective, with an average completion time of 76 seconds and a cost of $0.019 per attempt. These
results emphasize the suitability of LMA systems for moderately complex software engineering
tasks. However, when tasked with more complex challenges like developing a Tetris game, ChatDev
successfully generates a playable Tetris game only by the tenth attempt. The game still lacks the
core functionality, i.e., removing completed rows. This highlights the limitations of current LMA
systems in handling more complex tasks that require deeper logical reasoning and abstraction.
Nevertheless, development remains efficient and cost-effective, averaging 70 seconds and $0.020
per run, making the system a promising tool for rapid prototyping.
5
RESEARCH AGENDA
Previous research has laid the groundwork for the exploration of LMA systems in software en-
gineering, yet this domain remains in its nascent stages, with many critical challenges awaiting
resolution. In this section, we outline our perspective on these challenges and suggest research
questions that could advance this burgeoning field. As illustrated in Figure 4, we envision two
phases for the development of LMA systems in software engineering. We discuss each of these
phases below and suggest a series of research questions that could form the basis of future research
projects.
5.1
Phase 1: Enhancing Individual Agent Capabilities
Indeed, the effectiveness of an LMA system is closely linked to the capabilities of its individual
agents. This first phase is dedicated to improving these agents’ skills, with a particular focus on
adaptability and the acquisition of specialized skills in SE. The potential of individual LLM-based
agents in SE is further explored through our initial research questions:
(1) What SE roles are suitable for LLM-based agents to play and how can their abilities be enhanced to
represent these roles?
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 13 (Section: 5 Research Agenda)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
13
Phase 1: Enhancing Individual Agent Capabilities
Phase Two: Optimizing Agent Synergy
Refining Role-Playing 
Capabilities
Designing Robust and 
Adaptable Prompting 
Frameworks
Harmonizing Human-Agent 
Collaboration
Benchmarking Multi-agent 
Systems
Scaling Up for Complex 
Projects
Leveraging Industry 
Principles
Dynamic Adaptation of 
Agents and Resources
Secure and Responsible 
Data Management
Fig. 4. Research Agenda for LLM-Based Multi-Agent Systems in Software Engineering
(2) How to design an effective, flexible, and robust prompting language that enhances LLM-based
agents’ capabilities?
5.1.1
Refining Role-Playing Capabilities in Software Engineering.
The role-playing capabilities of LLM-based agents are pivotal within LMA systems [140]. To
address the complexity of software engineering tasks, we need specialized agents capable of
adopting diverse roles to tackle intricate challenges throughout the software development lifecycle.
Current State. Existing LMA systems, such as ChatDev [109], MetaGPT [48], and AgileCoder [101],
effectively simulate roles like generic software developers and product managers. The agents in
these systems rely on general-purpose LLMs such as ChatGPT. Although LLMs like ChatGPT
exhibit strong programming skills, they still lack the nuanced expertise required in SE [50]. This
limitation hampers their ability to simulate other SE-specific roles. For example, roles involving
vulnerability detection or security auditing require a deep understanding of security protocols,
threat modeling, and the latest vulnerabilities. However, multiple studies have identified deficiencies
in ChatGPT’s ability to accurately detect and repair vulnerabilities [18, 37, 120]. This shortcoming
underscores the need to integrate domain-specific expertise into LLMs to better support specialized
software engineering roles.
Opportunities. To address this limitation, we propose a structured and actionable three-step
approach encompassing the identification, assessment, and enhancement of role-playing abilities,
which are:
Step 1: Identifying and Prioritizing Key SE Roles.
Step 2: Assessing LLM-Based Agents’ Competencies Against Role Requirements.
Step 3: Enhancing Role-Playing Abilities Through Targeted Training.
The first step focuses on identifying key SE roles, prioritizing those with high industry demand
and the potential to substantially boost productivity. This involves:
(1) Market Analysis: To begin, we embark on a comprehensive market analysis. It is crucial to
assess not only the current trends and needs within the SE sector but also to anticipate future
shifts influenced by the integration of LLM-based agents. This analysis involves leveraging
various resources such as market reports, job postings, industry forecasts, and technology
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 14 (Section: 5 Research Agenda)

14
Junda He, Christoph Treude, and David Lo
trend analyses. Platforms like LinkedIn Talent Insights5, Gartner reports6, and Stack Overflow
Developer Surveys7 may also offer valuable data to inform this assessment. The focus should
be on identifying roles that are in high demand and demonstrate rapid growth, especially those
requiring specialized skills not typically found among generalist developers. For example,
machine learning engineers or cloud architects. Additionally, positions where LLM-based
agents could significantly enhance productivity, reduce costs, or accelerate innovation should
be evaluated. A key component of this analysis should be determining whether the market
has already begun shifting away from recruiting humans for tasks that LLM-based agents
can perform, such as routine coding or simple bug fixing. Identifying these trends will help
distinguish between roles that are still in demand and those where LLMs have reduced the
need for human expertise.
(2) Stakeholder Engagement: Engaging comprehensively with a diverse group of stakeholders
is essential. This process validates the findings from the market analysis and ensures that
the selected roles align with real-world needs. It involves consulting industry professionals
who have hands-on experience in the identified roles. This engagement can provide practical
insights and challenges associated with these positions. Collaboration with HR departments
from leading technology companies is also important. It helps gather perspectives on current
hiring trends, skill shortages, and the most sought-after competencies. Additionally, academic
experts and researchers can offer forward-thinking views on emerging technologies and
methodologies. By incorporating feedback from these various sources, the selection of key
roles becomes more robust to reflect both current industry demands and future directions.
(3) Value Addition Modeling: The next crucial step is value addition modeling [100], which
evaluates the potential advantages that LLM-based agents could bring to each prioritized role.
This process involves constructing detailed, data-driven models to analyze key performance
indicators such as efficiency improvements, cost reductions, quality enhancements, and the
acceleration of innovation resulting from the integration of agents. Pilot projects can be
deployed to gather empirical data on these metrics when LLM-based agents are applied
to specific tasks. Important factors to consider include the automation of repetitive tasks,
the augmentation of human capabilities, and the inclusion of new functionalities that were
previously unattainable. It is important to note that the value added by LLM-based agents
can differ significantly across different domains; for example, roles in software development
may prioritize automation, whereas domains like systems architecture might see more value
in LLMs augmenting complex decision-making around resource allocation or performance
optimization, where human expertise and contextual understanding remain essential. By
quantifying these value propositions, organizations can allocate resources more strategically
to roles where LLM-based agents are likely to yield the highest return on investment.
The second step involves understanding the limitations of LLM-based agents relative to the
demands of the identified SE roles:
(1) Competency Mapping: Competency mapping [66] entails developing comprehensive com-
petency frameworks for each specialized role. These frameworks define the essential skills,
knowledge areas, and competencies required, encompassing both technical and soft skills. For
instance, technical skills might encompass proficiency in specific programming languages,
tools, methodologies, and domain-specific knowledge. For a machine learning engineer, this
would include expertise in algorithms, data preprocessing, model training, and tools such
5https://www.linkedin.com/products/linkedin-talent-insights/
6https://www.gartner.com/en/products/special-reports
7https://survey.stackoverflow.co/2024/
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 15 (Section: 5 Research Agenda)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
15
as TensorFlow8 or PyTorch9. Soft skills include skills like problem-solving, critical thinking,
and collaboration. Clearly outlining these competencies creates a benchmark against which
the agents’ abilities can be measured.
(2) Performance Evaluation: The next phase is performance evaluation, which involves designing
or selecting tasks that closely replicate the real-world challenges associated with each role.
These tasks should be practical and scenario-based to accurately gauge the agents’ capabilities.
They should assess a wide range of competencies, from technical execution to critical thinking.
For example, in evaluating a DevOps engineer, the agent might be tasked with automating a
deployment pipeline using tools like Jenkins10 or Docker11, or troubleshooting a continuous
integration failure. Such tasks allow for a thorough assessment of both technical and soft
skills.
(3) Gap Analysis: This step compares the agents’ outputs with the expected outcomes for each
task. Key areas where the agents underperform–such as misunderstanding domain-specific
terminology, neglecting security best practices, or failing to optimize code–are identified and
documented. This analysis emphasizes both the agents’ strengths and weaknesses, offering
valuable insights into recurring patterns of errors or misconceptions.
(4) Expert Consultation and Iterative Refinement: To further refine the evaluation process, expert
consultation and iterative refinement are essential. By engaging with SE professionals who
specialize in the assessed roles, qualitative feedback on the agent’s performance can be
obtained. These experts provide insights into subtle nuances that may not be captured
through quantitative metrics. For instance, while the agent’s code may work, it might not
follow best practices or address scalability. This feedback helps refine evaluation methods,
update competency frameworks, and uncover deeper issues in the agent’s understanding.
The final step involves tailoring the LLM-based agents to effectively represent the identified SE
roles through specialized training and prompt engineering. :
(1) Curating Specialized Training Data: At first, this involves creating training datasets that reflect
the unique requirements of each specific role. A comprehensive corpus should be built from a
variety of sources, including technical documentation such as API guides, technical manuals,
and user guides to provide in-depth knowledge of specific technologies. It is also important to
incorporate academic and industry research papers, case studies, and whitepapers to capture
the latest developments, best practices, and theoretical foundations. Additionally, discussions
from forums and software Q&A sites like Stack Overflow12, Reddit13, and specialized industry
forums can provide practical problem-solving approaches and real-world challenges faced by
professionals.
(2) Fine-tuning the LLM: After preparing the data, the curated datasets are used to fine-tune the
LLM-based agents. Advanced techniques like parameter-efficient fine-tuning (PEFT) [83] are
often employed to optimize both efficiency and accuracy.
(3) Designing Customized Prompts: A key step is designing prompts tailored to improve the agents’
role adaptability. These prompts should clearly define the role, tasks, and goals to ensure the
agent understands the requirements. For instance, in a cybersecurity analyst role, the prompt
should outline specific security protocols, potential vulnerabilities, and compliance standards.
Contextual instructions, including relevant background, constraints, and examples, help the
8https://www.tensorflow.org/
9https://pytorch.org/
10https://www.jenkins.io/
11https://www.docker.com/
12https://stackoverflow.com/
13https://www.reddit.com/
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 16 (Section: 5 Research Agenda)

16
Junda He, Christoph Treude, and David Lo
agent grasp task nuances. Creating a library of effective prompts for various scenarios can
also serve as reusable templates for future tasks.
(4) Continuous Learning and Adaptation: To keep agents aligned with industry developments,
continuous adaptation mechanisms are essential. Training data should be regularly updated,
and models may be retrained to incorporate new technologies, best practices, and trends in
software engineering. Monitoring systems can track agent performance over time, enabling
proactive adjustments and continuous improvement. Additionally, agents should be guided
to consistently reference the latest documentation and standards to ensure their outputs
remain relevant and accurate.
While LMA roles may overlap with traditional software engineering roles, it is important to
recognize that they are not necessarily the same, as LMA roles often involve specialized, collabora-
tive tasks suited for agent-based systems. By systematically identifying key roles, assessing agent
competencies, and enhancing their capabilities through targeted fine-tuning, we aim to significantly
improve the effectiveness of LLM-based agents in specialized SE roles.
5.1.2
Advancing Prompts through Agent-oriented Programming Paradigms.
Effective prompts are crucial for the performance of LLM-based agents. However, creating
such prompts is challenging due to the need for a framework that is versatile, effective, and
robust across diverse scenarios. Natural language, while flexible, often contains ambiguities and
inconsistencies that LLMs may misinterpret. Natural language is inherently designed for human
communication, where human communication relies on shared context and intuition that LLMs
lack. In contrast, LLMs interpret text based on statistical patterns from large datasets, which may
lead to different interpretations than those intended for humans [121, 156]. This highlights the need
for a specialized prompting language designed to augment the cognitive functions of LLM-based
agents and treats LLMs as the primary audience. Such a language can minimize ambiguities and
ensure clear instructions, resulting in more reliable and accurate outputs.
Current State. Multiple prompting frameworks are released to facilitate the usage of LLMs. For
example, DSPy [67] and Vieira [79] enable fully automated generation of prompts. AutoGen [145]
and LangChain [97] support retrieval-augmented generation (RAG) [38] and agent-based workflows.
However, these frameworks are still human-centered. They often prioritize human readability and
developer convenience. As a result, there is a lack of research on a language that treats LLMs as the
primary audience for prompts.
Opportunities. Agent-oriented programming (AOP) [118] offers a promising foundation for this
approach. Similar to how Object-Oriented Programming (OOP) [141] organize objects, AOP treats
agents as fundamental units, focusing on their reasoning, objectives, and interactions. An AOP-
based prompting language could enable the precise expression of complex tasks and constraints,
allowing LLM-based agents to perform their roles with greater efficiency and accuracy. Extending
this concept to Multi-Agent-Oriented Programming (MAOP) [13, 14] allows for the creation of
systems where multiple LLM-based agents can collaborate, communicate, and adapt to evolving
contexts. By explicitly defining agent behaviors, communication patterns, and task hierarchies, we
can reduce ambiguity, mitigate hallucinations, and improve task execution in LMA systems.
Further, such a prompting language must be expressive enough to handle diverse and complex
tasks, yet simple enough for users to easily adopt. Conversely, overly simplified languages may lack
the expressive power needed to represent complex software engineering workflows. A complex
language that introduce a steep learning curve due to their syntax, hinder adoption, especially for
users who require simpler interfaces for prompt creation and modification. Balancing functionality
and usability will be another key research question to its success.
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 17 (Section: 5.2 Phase Two: Optimizing Agent Synergy)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
17
Additionally, this process may involve tailoring prompts specifically for different LLM models
and their versions, as variations in model architectures, training data, and capabilities can affect how
they interpret and respond to prompts. What works effectively for one model may not perform as
well for another, necessitating careful adjustments. Current prompting languages lack mechanisms
to easily adapt prompts across models, requiring manual adjustments and experimentation to
achieve consistent performance.
While AOP-based prompting may not be the final solution, it represents an important step
toward developing an AI-oriented language with grammar tailored specifically for LLMs. This new
approach could further refine communication with LLM-based agents, reducing misinterpretation
and significantly enhancing overall performance.
5.2
Phase Two: Optimizing Agent Synergy
In Phase Two, the spotlight turns towards optimizing agent synergy, underscoring the importance
of collaboration and how to leverage the diverse strengths of individual agents. This phase delves
into both the internal dynamics among agents and the role of external human intervention in
enhancing the efficacy of the LMA system. Key research questions guiding this phase include:
(3) How to best allocate tasks between humans and LLM-based agents?
(4) How can we quantify the impact of agent collaboration on overall task performance and outcome
quality?
(5) How to scale LMA systems for large-scale projects?
(6) What industrial organization mechanisms can be applied to LMA systems?
(7) What strategies allow LMA systems to dynamically adjust their approach?
(8) How to ensure security among private data sharing within LMA systems?
5.2.1
Human-Agent Collaboration.
Optimally distributing tasks between humans and LMA agents to leverage their respective
strengths is essential. Humans bring unparalleled creativity, critical thinking, ethical judgment,
and domain-specific knowledge [95]. In contrast, LLM-based agents excel at rapidly processing
large datasets, performing repetitive tasks with high accuracy, and detecting patterns that might
elude human observers.
Current State. Several LMA systems incorporate human-in-the-loop designs. For instance, AISD [162]
involves human input during requirement analysis and system validation, where users provide
feedback on use cases, system designs, and prototypes. Similarly, MARE [59] leverages human
assessment to refine generated requirements and specifications. Although these works demon-
strate the feasibility of human contributions, key research questions, including optimizing human
roles, enhancing feedback mechanisms, and identifying appropriate intervention points, are still
underexplored.
Opportunity. Developing role-specific guidelines that outline when and how human intervention
should occur is essential. These guidelines should assist in identifying critical decision points where
human judgment is indispensable, such as ethical considerations, conflict resolution, ambiguity
handling, and creative problem-solving. For example, ethical decisions necessitate human oversight
to ensure alignment with societal norms and values, and conflict resolution may require negotiation
skills that LLM-based agents lack.
To facilitate seamless collaboration, designing intuitive user-friendly interfaces and interaction
protocols is essential [133]. Natural language interfaces and adaptive visualization techniques can
make interactions more accessible. These interfaces should efficiently present agent outputs in
a digestible format and collect user feedback, while also managing the cognitive load on human
collaborators. It is important to note that these interfaces may need to be tailored differently for
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 18 (Section: 5.2 Phase Two: Optimizing Agent Synergy)

18
Junda He, Christoph Treude, and David Lo
each human role, as the needs of a project manager, a software developer, and a quality assurance
engineer will vary significantly.
Given the complexity of information generated during the agents’ workflows [60], designing
such interfaces poses challenges. For instance, presenting modifications suggested by an agent at
varying levels of abstraction ensures that each stakeholder can engage with the information at the
right depth. A project manager might focus on the broader implications, such as the high-level
impact on project timelines or deliverables, whereas a developer or architect might drill down into
specific implementation details. Role-specific interfaces will be key to ensuring each stakeholder
can effectively collaborate with the agents and extract the necessary information in a manner
suited to their specific responsibilities.
Additionally, developing predictive models to determine the optimal human-to-agent ratio across
different project types and stages is a fundamental concern. These models must assess factors
such as project complexity, time constraints, project priorities, and the specific capabilities and
limitations of both human participants and LMA agents. By doing so, tasks can be allocated in a
manner that fully harnesses both human ingenuity and agent efficiency throughout the project.
Machine learning techniques could also be leveraged to analyze historical project data to predict
effective collaboration strategies.
5.2.2
Evaluating the LMA systems.
Current State. Numerous complex benchmarks have been proposed to challenge the capabilities
of LLMs in critical aspects of software development, such as code generation [58, 84, 171]. While
these benchmarks have advanced the field by providing measurable metrics for individual tasks,
their focus on isolated problem-solving reveals limitations as software engineering projects become
more complex. Software engineering is inherently collaborative, with key activities like joint
requirements gathering, code integration, and peer reviews playing essential roles in the process.
Current benchmarks often overlook these aspects, failing to assess how well LLMs perform in tasks
that require cooperation and collective decision-making.
Opportunities. There is a growing need for benchmarks that evaluate the cooperative abilities
of LLMs in multi-agent settings, particularly for software engineering tasks. These benchmarks
should simulate real-world collaborative scenarios where LLM agents work together to achieve
common development goals.
Such benchmarks should include tasks where agents must:
(1) Participate in collaborative design: Agents should contribute ideas, propose design solutions,
and converge on a unified architecture that balances trade-offs.
(2) Delegate and coordinate tasks: Effective task division is crucial. Agents should assign respon-
sibilities based on expertise, manage dependencies, and adjust as the project evolves.
(3) Identify conflicts and negotiate: In collaborative settings, disagreements are inevitable. First,
LLMs often struggle to identify conflicts in real time unless explicitly guided to do so [1].
Therefore, agents should be evaluated on their ability to recognize these conflicts—whether
in logic, goals, or execution. Moreover, agents should be tested on their ability to handle
conflicts constructively. This includes proposing compromises, engaging in constructive
negotiation, and ensuring that the team remains aligned with the overarching objectives.
Evaluations should focus on the agents’ capacity to balance competing priorities, mitigate
misunderstandings, and foster consensus, all while maintaining progress toward shared goals.
(4) Integrate components and perform peer reviews: Agents should seamlessly integrate their work,
review each other’s code for quality assurance, and provide constructive feedback.
(5) Proactive Clarification Request : Agents should not assume complete understanding when
uncertainty arises. Instead, they should preemptively ask for additional information or
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 19 (Section: 5.2 Phase Two: Optimizing Agent Synergy)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
19
clarification to avoid potential errors or misunderstandings. Evaluating agents on this ability
ensures they are capable of identifying gaps in their knowledge or instructions and can
actively seek out the necessary context or data to complete tasks effectively.
To develop such benchmarks, we need to create realistic project scenarios that require multi-agent
collaboration over extended periods. These scenarios should reflect common software development
challenges, such as evolving requirements and tight deadlines. Additionally, platforms or sandboxes
must be built to provide controlled environments where collaborative interactions between agents
can be observed and measured. These platforms should establish clear interaction rules, including
languages, formats, and communication channels, to facilitate effective information exchange.
Most importantly, comprehensive metrics must be developed to assess not just the final output,
but also the collaboration process itself. These metrics could measure communication efficiency,
ambiguity resolution, conflict management, adherence to best practices, and overall project success.
5.2.3
Scaling Up for Complex Projects.
As software projects become more complex, a single LLM-based agent may hit its performance
limits. Inspired by the scaling properties of neural models [10], LMA systems can potentially
enhance performance by increasing the number of agents within the system. While adding more
agents can provide some benefits, handling more complex projects introduces challenges that
require more refined solutions.
Current State. Existing LMA systems face significant challenges when scaling up to handle complex
software projects. Our case studies illustrate these limitations clearly. For instance, ChatDev was
unable to autonomously develop a functional Tetris game. In real-world projects with higher
complexity, this limitation becomes even more pronounced.
Opportunities. First, as software projects grow in size and complexity, breaking down high-level
requirements into manageable sub-tasks becomes more difficult. It is not just about handling
more tasks but also managing the intricate interdependencies between them. A hierarchical task
decomposition approach can help, where higher-level agents oversee broader objectives and delegate
specific tasks to lower-level agents. This structure streamlines planning and makes global task
allocation more efficient.
Second, as the number of agents increases, so does the complexity of communication. Coordinat-
ing multiple agents can lead to communication bottlenecks and information overload. Additionally,
large-scale software projects challenge the memory capacity of individual agents, making it harder
to store and process the extensive information required. Efficient communication protocols and mes-
sage prioritization are crucial to mitigating these issues. For instance, agents can use summarized
updates instead of detailed reports, reducing communication overhead and memory usage. From
the outset, the system should be designed with scalability in mind, ensuring that both software and
hardware resources can expand efficiently as the number of agents increases.
Moreover, with more agents comes the risk of inconsistencies and conflicts in the shared infor-
mation. A centralized knowledge repository or shared blackboard system can ensure that all agents
have access to consistent, up-to-date information, acting as a single source of truth and minimizing
the spread of misinformation. Robust error handling mechanisms should also be implemented to
detect and correct issues autonomously before they escalate into significant failures.
Finally, as the number of agents grows, so do the rounds of discussion and decision-making,
which can slow down progress. To avoid this, decision-making hierarchies or consensus algorithms
can streamline the process. For example, only a subset of agents responsible for a specific module
may need to reach a consensus, rather than involving the entire agent network.
5.2.4
Leveraging Industry Principles.
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 20 (Section: 5.2 Phase Two: Optimizing Agent Synergy)

20
Junda He, Christoph Treude, and David Lo
As LLM-based agents can closely mimic human developers in SE tasks, they can greatly benefit
from adopting established industry principles and management strategies. By emulating organi-
zational frameworks used by successful companies, LMA systems can improve their design and
optimization processes. These industrial mechanisms enable LMA systems to remain agile, efficient,
and effective, even as project complexities grow.
Current State. As we described in Section 3, numerous works [5, 48, 101, 109] are designed
using popular process models like the Waterfall and Agile. For example, ChatDev [109] emulates a
traditional Waterfall approach, breaking tasks into distinct phases (e.g., requirement analysis, design,
implementation, testing), with agents dedicated to each phase. AgileCoder [101] incorporates the
Agile methodologies, leveraging iterative development, continuous feedback loops, and collaborative
sprints.
Opportunities. However, current LMA systems often do not leverage more specialized and modern
industry practices, such as Value Stream Mapping, Design Thinking, or Model-Based Systems
Engineering (MBSE). Additionally, frameworks like Domain-Driven Design (DDD), Behavior-Driven
Development (BDD), and Team Topologies remain underutilized. These methodologies emphasize
aligning development with business goals, improving user-centric design, and optimizing team
structures—key components that could further enhance the efficiency, adaptability, and effectiveness
of LMA systems.
Leadership and governance structures from industrial organizations provide valuable insights
for designing LMA systems. Project management tools and practices, essential for coordinating
large development teams, can be applied to LMA systems to enhance their operational efficiency.
Using established project management frameworks, LMA systems can monitor progress, allocate
resources, and manage timelines effectively. Agents can dynamically update task boards, report
milestones, and adjust workloads in real-time based on project data. This not only improves
transparency but also allows for early detection of bottlenecks or delays, ensuring projects stay on
track.
Incorporating design patterns and software architecture best practices further strengthens LMA
systems [70]. By adhering to these principles, agents can produce well-structured, maintainable
code that is scalable and reusable. This reduces technical debt and ensures that the solutions
developed by LMA systems are easier to integrate, maintain, and expand in the future.
5.2.5
Dynamic Adaptation.
In the context of software development, predicting the optimal configuration for LMA systems
at the outset is unrealistic due to the inherent complexity and variability of tasks [71]. The dynamic
nature of software requirements and the unpredictable challenges that arise during development
necessitate systems that can adapt on the fly [88]. For example, a sudden shift in project requirements
or unexpected delays caused by dependencies on external components. Therefore, LMA systems
must be capable of dynamically adjusting their scale, strategies, and structures throughout the
development process.
Current State. Most existing LMA systems [48, 109] operate with static architectures characterized
by fixed agent roles and predefined communication patterns. Recent research efforts [89, 157] have
introduced mechanisms for adaptive agent team selection and task-specific collaboration strategies.
These methods enable the selection of suitable agent team configurations for specific tasks, however,
they still fall short of true dynamic adaptation and lack the capability to adjust to real-time changes.
To the best of our knowledge, no previous work addresses the need for on-the-fly adjustments in
response to evolving project demands.
Opportunities. To minimize redundant work, LMA systems should continuously evaluate exist-
ing solutions [136], identifying reusable elements for new requirements. By learning from each
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 21 (Section: 5.2 Phase Two: Optimizing Agent Synergy)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
21
development cycle, the system can recognize patterns of efficiency and inefficiency, enabling it to
make informed decisions when handling similar tasks in the future or adapting existing solutions
to new requirements.
A key element of dynamic adaptation is the ability to automatically adjust the number of agents
involved in a project [41]. This includes not only scaling the number of agents up or down as needed
but also generating new agents with new specialized roles to meet emerging task requirements,
ensuring both efficiency and responsiveness. Additionally, the system can replicate agents in
existing roles to manage increased workloads. Furthermore, LMA systems can generate new
agents that come equipped with contextual knowledge of the project—such as its history, current
state, and objectives—by accessing shared knowledge bases, project documentation, and recent
communications. This allows new agents to integrate smoothly and contribute effectively right
from the start, reducing onboarding time and minimizing disruptions.
Another key component is the dynamic redefinition of agent roles [61]. As the project evolves,
certain roles may become obsolete while new ones emerge. LMA systems should be capable of
reassigning roles to agents or modifying their responsibilities to better align with current project
needs. This flexibility enhances the system’s ability to adapt to changing requirements and priorities.
Dynamic adaptation also involves the reallocation of memory and computational resources. As
agents are added or removed and tasks shift in complexity, the system must efficiently distribute
resources to where they are most needed. This may include scaling computational power for agents
handling intensive tasks or increasing memory allocation for agents processing large datasets.
Effective resource management ensures that the system operates optimally without unnecessary
strain on infrastructure.
Finally, the uncertainty of the software development process makes it challenging to define
effective termination conditions [119]. Relying solely on predefined criteria may result in infinite
loops or premature task completion. To address this, LMA systems must incorporate real-time
monitoring and feedback loops to continuously evaluate progress. Machine learning techniques
can help predict optimal stopping points by analyzing historical data and current performance
metrics, allowing for informed adjustments to task completion criteria as the project evolves.
5.2.6
Privacy and Partial Information.
In multi-organizational software development projects, data often resides in silos due to privacy
concerns, proprietary restrictions, and regulatory compliance requirements [103]. Each entity may
have its own data governance policies and competitive considerations that limit data sharing. This
fragmentation poses significant challenges in enabling agents to access necessary information
while ensuring that privacy is maintained. Moreover, a lack of transparency in data sources and
processes can exacerbate the risk of privacy violations, which may go unnoticed if data handling
activities are not fully visible to all parties [27].
Current State. The challenge of ensuring privacy while managing partial information has been
extensively studied in the field of computer security. [11, 30]. To the best of our knowledge, existing
research has yet to provide a solution to these challenges for LMA systems in SE.
Opportunities. To address these challenges, robust and fine-grained access control mechanisms
must be implemented across organizational boundaries. It is essential to prevent unauthorized
access while still accommodating the varied data access needs of the system. Traditional models
like Role-Based Access Control (RBAC) [116] and Attribute-Based Access Control (ABAC) [52] may
need to be extended to handle the dynamic nature of multi-agent systems effectively. Establishing
protocols that allow agents to share insights derived from sensitive data, without exposing the
data itself, is critical. Advanced privacy-preserving techniques like Differential Privacy [34], Secure
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 22 (Section: 6 Discussion)

22
Junda He, Christoph Treude, and David Lo
Multi-Party Computation (SMPC) [40], Federated Learning [62], or Homomorphic Encryption [153]
can be leveraged to ensure that agents collaborate without compromising data privacy.
Moreover, compliance with data protection laws such as the General Data Protection Regulation
(GDPR) [130] in the EU and the California Consumer Privacy Act (CCPA) [104] in the U.S. is
crucial. LMA systems should follow privacy-by-design principles, ensuring that data subjects’
rights are upheld, and that data processing activities remain transparent and lawful. This includes
implementing mechanisms for data minimization, consent management, and honoring the right to
be forgotten.
For non-sensitive data, integrated data storage solutions can reduce redundancy, improve data
consistency, and increase efficiency. This can be achieved through distributed databases accessible
to authorized agents, along with data synchronization mechanisms to ensure agents have up-to-date
information in real time. Additionally, using technologies like blockchain [167] and distributed
ledgers [122] can enhance transparency, traceability, and tamper-resistance in recording agent
transactions and data access events, fostering greater trust among collaborating entities.
6
DISCUSSION
6.1
A Comparison with the Mixture of Experts Paradigm
Another paradigm that has recently attracted much attention from both academia and industry is
the Mixture of Experts (MoE) paradigm [16, 170]. MoE organizes an LLM into multiple specialized
components known as “experts." Each expert is designed to focus on specialized tasks. Further, a
gating mechanism is employed to dynamically activate the most relevant subset of experts based
on the input. While MoE is promising, LMA systems offer several distinct advantages:
One limitation of MoE is its high resource consumption. MoE models contain multiple experts
within a single architecture, which makes the total number of parameters rather huge. Furthermore,
training MoE is more resource-intensive and time-consuming than standard LLMs. This is mainly
due to the complex training process for the gating mechanism. Training the gating mechanism
involves optimizing the selection process for the most relevant experts, which adds considerable
overhead.
Since specific experts are dynamically activated based on input, MoE can be viewed as a method
to learn the internal routing of LLMs. However, there is no interaction and communication between
experts in MoE. On the other hand, LMA systems usually are designed to resemble real-world
collaborative workflows. Agents in LMA systems can actively communicate with each other,
exchange information, and iteratively refine the output based on feedback from other agents. More
importantly, LMA systems can also integrate external feedback from tools such as compilers, static
analyzers, or testing frameworks. LMA systems also facilitate seamless and continuous human-
in-the-loop collaboration, enabling human experts to intervene, validate outputs, and provide
guidance at any stage of the process. As a result, we consider LMA systems to be a more appropriate
approach to MoE to address the multifaceted challenges of software engineering.
6.2
Threat to Validity
One potential threat to validity lies in the possibility of inadvertently excluding relevant studies
during the literature search and selection process. To mitigate this risk, we conducted a compre-
hensive search on the DBLP database, ensuring coverage of a broad spectrum of studies, including
preprints. Additionally, we enhanced the search process by combining automated querying with
forward and backward snowballing, aiming to identify and include all pertinent studies.
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 23 (Section: 7 Conclusion and Future Work)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
23
7
CONCLUSION AND FUTURE WORK
This paper explores the evolving role of LMA systems in shaping the future of Software Engineering
2.0 [90]. To support this vision, we first present a systematic review of recent applications of
LMA systems across different stages of the software development lifecycle. Our review highlights
key advancements in areas such as requirements engineering, code generation, software quality
assurance, and maintenance. To further understand the current landscape, we conduct two case
studies that illustrate the practical uses and challenges of LMA systems. Based on these insights, we
propose a structured research agenda aimed at advancing LMA integration in software engineering.
Future work will focus on addressing critical research questions to enhance LMA capabilities and
optimize their synergy with software development processes.
In the immediate term, efforts will be dedicated to enhancing the capabilities of LLM-based agents
in representing specialized SE roles. This will involve creating specialized datasets and pre-training
tasks that mirror the complex realities of SE tasks. Additionally, there will be a focus on formulating
advanced prompting strategies, which can refine the agents’ cognitive functions and decision-
making skills. Looking towards the longer-term objectives, the emphasis will transition towards
optimizing the synergy between agents. The initial step involves examining optimal strategies for
task allocation between humans and LLM-based agents, capitalizing on the unique strengths of
both entities. Further, we need to develop scalable methodologies for LMA systems, which would
enable them to orchestrate and complete large-scale, multifaceted SE projects efficiently. Moreover,
ensuring the privacy and confidentiality of data within LMA systems is also critical. This entails
exploring data management and access control mechanisms to protect sensitive information while
still enabling the essential exchange of insights among project stakeholders. By systematically
exploring these research questions, we aim to drive innovation in LMA systems for software
engineering and create a more cohesive, effective, and flexible LMA-driven development process.
REFERENCES
[1] Sahar Abdelnabi, Amr Gomaa, Sarath Sivaprasad, Lea Schönherr, and Mario Fritz. 2023. Llm-deliberation: Evaluating
llms with interactive multi-agent negotiation games. arXiv preprint arXiv:2309.17234 (2023).
[2] Pekka Abrahamsson, Outi Salo, Jussi Ronkainen, and Juhani Warsta. 2017. Agile software development methods:
Review and analysis. arXiv preprint arXiv:1709.08439 (2017).
[3] Josh Achiam, Steven Adler, Sandhini Agarwal, Lama Ahmad, Ilge Akkaya, Florencia Leoni Aleman, Diogo Almeida,
Janko Altenschmidt, Sam Altman, Shyamal Anadkat, et al. 2023. Gpt-4 technical report. arXiv preprint arXiv:2303.08774
(2023).
[4] Saaket Agashe. 2023. LLM-Coordination: Developing Coordinating Agents with Large Language Models. University of
California, Santa Cruz.
[5] Samar Al-Saqqa, Samer Sawalha, and Hiba AbdelNabi. 2020. Agile software development: Methodologies and trends.
International Journal of Interactive Mobile Technologies 14, 11 (2020).
[6] Stefano V Albrecht and Peter Stone. 2018. Autonomous agents modelling other agents: A comprehensive survey and
open problems. Artificial Intelligence 258 (2018), 66–95.
[7] Antonis Antoniades, Albert Örwall, Kexun Zhang, Yuxi Xie, Anirudh Goyal, and William Wang. 2024. SWE-Search:
Enhancing Software Agents with Monte Carlo Tree Search and Iterative Refinement. arXiv preprint arXiv:2410.20285
(2024).
[8] Daman Arora, Atharv Sonwane, Nalin Wadhwa, Abhav Mehrotra, Saiteja Utpala, Ramakrishna Bairi, Aditya Kanade,
and Nagarajan Natarajan. 2024. MASAI: Modular Architecture for Software-engineering AI Agents. arXiv preprint
arXiv:2406.11638 (2024).
[9] Mohammadmehdi Ataei, Hyunmin Cheong, Daniele Grandi, Ye Wang, Nigel Morris, and Alexander Tessier. 2024.
Elicitron: An LLM Agent-Based Simulation Framework for Design Requirements Elicitation.
arXiv preprint
arXiv:2404.16045 (2024).
[10] Yasaman Bahri, Ethan Dyer, Jared Kaplan, Jaehoon Lee, and Utkarsh Sharma. 2024. Explaining neural scaling laws.
Proceedings of the National Academy of Sciences 121, 27 (2024), e2311878121.
[11] Charles H Bennett, Gilles Brassard, and Jean-Marc Robert. 1988. Privacy amplification by public discussion. SIAM
journal on Computing 17, 2 (1988), 210–229.
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 24 (Section: 7 Conclusion and Future Work)

24
Junda He, Christoph Treude, and David Lo
[12] Nicolas Bettenburg, Sascha Just, Adrian Schröter, Cathrin Weiss, Rahul Premraj, and Thomas Zimmermann. 2008.
What makes a good bug report?. In Proceedings of the 16th ACM SIGSOFT International Symposium on Foundations of
software engineering. 308–318.
[13] Olivier Boissier, Rafael H Bordini, Jomi Hubner, and Alessandro Ricci. 2020. Multi-agent oriented programming:
programming multi-agent systems using JaCaMo. Mit Press.
[14] Rafael H Bordini, Mehdi Dastani, Jürgen Dix, and Amal El Fallah Seghrouchni. 2009. Multi-agent programming.
Springer.
[15] Frank J. Budinsky, Marilyn A. Finnie, John M. Vlissides, and Patsy S. Yu. 1996. Automatic code generation from design
patterns. IBM systems Journal 35, 2 (1996), 151–171.
[16] Weilin Cai, Juyong Jiang, Fan Wang, Jing Tang, Sunghun Kim, and Jiayi Huang. 2024. A survey on mixture of experts.
Authorea Preprints (2024).
[17] Yuzhe Cai, Shaoguang Mao, Wenshan Wu, Zehua Wang, Yaobo Liang, Tao Ge, Chenfei Wu, Wang You, Ting Song,
Yan Xia, et al. 2023. Low-code llm: Visual programming over llms. arXiv preprint arXiv:2304.08103 2 (2023).
[18] Chong Chen, Jianzhong Su, Jiachi Chen, Yanlin Wang, Tingting Bi, Jianxing Yu, Yanli Wang, Xingwei Lin, Ting Chen,
and Zibin Zheng. 2024. When ChatGPT Meets Smart Contract Vulnerability Detection: How Far Are We? ACM Trans.
Softw. Eng. Methodol. (Nov. 2024). https://doi.org/10.1145/3702973 Just Accepted.
[19] Dong Chen, Shaoxin Lin, Muhan Zeng, Daoguang Zan, Jian-Gang Wang, Anton Cheshkov, Jun Sun, Hao Yu, Guo-
liang Dong, Artem Aliev, et al. 2024. CodeR: Issue Resolving with Multi-Agent and Task Graphs. arXiv preprint
arXiv:2406.01304 (2024).
[20] Junjie Chen, Jibesh Patra, Michael Pradel, Yingfei Xiong, Hongyu Zhang, Dan Hao, and Lu Zhang. 2020. A survey of
compiler testing. ACM Computing Surveys (CSUR) 53, 1 (2020), 1–36.
[21] Weize Chen, Yusheng Su, Jingwei Zuo, Cheng Yang, Chenfei Yuan, Chi-Min Chan, Heyang Yu, Yaxi Lu, Yi-Hsin Hung,
Chen Qian, et al. 2023. Agentverse: Facilitating multi-agent collaboration and exploring emergent behaviors. In The
Twelfth International Conference on Learning Representations.
[22] Yongchao Chen, Jacob Arkin, Yang Zhang, Nicholas Roy, and Chuchu Fan. 2023. Scalable multi-robot collaboration
with large language models: Centralized or decentralized systems? arXiv preprint arXiv:2309.15943 (2023).
[23] Zhenpeng Chen, Jie M Zhang, Max Hort, Mark Harman, and Federica Sarro. 2024. Fairness testing: A comprehensive
survey and analysis of trends. ACM Transactions on Software Engineering and Methodology 33, 5 (2024), 1–59.
[24] Yuheng Cheng, Ceyao Zhang, Zhengwen Zhang, Xiangrui Meng, Sirui Hong, Wenhao Li, Zihao Wang, Zekai Wang,
Feng Yin, Junhua Zhao, et al. 2024. Exploring Large Language Model based Intelligent Agents: Definitions, Methods,
and Prospects. arXiv preprint arXiv:2401.03428 (2024).
[25] Michael G Christel and Kyo C Kang. 1992. Issues in requirements elicitation.
[26] David Cohen, Mikael Lindvall, and Patricia Costa. 2004. An introduction to agile methods. Adv. Comput. 62, 03 (2004),
1–66.
[27] Kate Crawford and Jason Schultz. 2014. Big data and due process: Toward a framework to redress predictive privacy
harms. BCL Rev. 55 (2014), 93.
[28] DBLP Computer Science Bibliography. 2024. DBLP: Computer Science Bibliography. https://dblp.org. Accessed:
2024-11-13.
[29] Gelei Deng, Yi Liu, Víctor Mayoral-Vilches, Peng Liu, Yuekang Li, Yuan Xu, Tianwei Zhang, Yang Liu, Martin
Pinzger, and Stefan Rass. 2023. Pentestgpt: An llm-empowered automatic penetration testing tool. arXiv preprint
arXiv:2308.06782 (2023).
[30] Irit Dinur and Kobbi Nissim. 2003. Revealing information while preserving privacy. In Proceedings of the twenty-second
ACM SIGMOD-SIGACT-SIGART symposium on Principles of database systems. 202–210.
[31] Yihong Dong, Xue Jiang, Zhi Jin, and Ge Li. 2023. Self-collaboration Code Generation via ChatGPT. arXiv preprint
arXiv:2304.07590 (2023).
[32] Yilun Du, Shuang Li, Antonio Torralba, Joshua B Tenenbaum, and Igor Mordatch. 2023. Improving factuality and
reasoning in language models through multiagent debate. arXiv preprint arXiv:2305.14325 (2023).
[33] Zhuoyun Du, Chen Qian, Wei Liu, Zihao Xie, Yifei Wang, Yufan Dang, Weize Chen, and Cheng Yang. 2024. Multi-Agent
Software Development through Cross-Team Collaboration. arXiv preprint arXiv:2406.08979 (2024).
[34] Cynthia Dwork. 2006. Differential privacy. In International colloquium on automata, languages, and programming.
Springer, 1–12.
[35] Gang Fan, Xiaoheng Xie, Xunjin Zheng, Yinan Liang, and Peng Di. 2023. Static Code Analysis in the AI Era: An
In-depth Exploration of the Concept, Function, and Potential of Intelligent Code Analysis Agents. arXiv preprint
arXiv:2310.08837 (2023).
[36] Stan Franklin and Art Graesser. 1996. Is it an Agent, or just a Program?: A Taxonomy for Autonomous Agents. In
International workshop on agent theories, architectures, and languages. Springer, 21–35.
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 25 (Section: 7 Conclusion and Future Work)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
25
[37] Michael Fu, Chakkrit Kla Tantithamthavorn, Van Nguyen, and Trung Le. 2023. Chatgpt for vulnerability detection,
classification, and repair: How far are we?. In 2023 30th Asia-Pacific Software Engineering Conference (APSEC). IEEE,
632–636.
[38] Yunfan Gao, Yun Xiong, Xinyu Gao, Kangxiang Jia, Jinliu Pan, Yuxi Bi, Yi Dai, Jiawei Sun, and Haofen Wang. 2023.
Retrieval-augmented generation for large language models: A survey. arXiv preprint arXiv:2312.10997 (2023).
[39] Joseph A Goguen and Charlotte Linde. 1993. Techniques for requirements elicitation. In [1993] Proceedings of the IEEE
International Symposium on Requirements Engineering. IEEE, 152–164.
[40] Oded Goldreich. 1998. Secure multi-party computation. Manuscript. Preliminary version 78, 110 (1998), 1–108.
[41] Taicheng Guo, Xiuying Chen, Yaqi Wang, Ruidi Chang, Shichao Pei, Nitesh V Chawla, Olaf Wiest, and Xiangliang
Zhang. 2024. Large language model based multi-agents: A survey of progress and challenges. arXiv preprint
arXiv:2402.01680 (2024).
[42] Junda He, Bowen Xu, Zhou Yang, DongGyun Han, Chengran Yang, Jiakun Liu, Zhipeng Zhao, and David Lo. 2024.
PTM4Tag+: Tag Recommendation of Stack Overflow Posts with Pre-trained Models. arXiv preprint arXiv:2408.02311
(2024).
[43] Junda He, Bowen Xu, Zhou Yang, DongGyun Han, Chengran Yang, and David Lo. 2022. Ptm4tag: sharpening tag
recommendation of stack overflow posts with pre-trained models. In Proceedings of the 30th IEEE/ACM International
Conference on Program Comprehension. 1–11.
[44] Junda He, Xin Zhou, Bowen Xu, Ting Zhang, Kisub Kim, Zhou Yang, Ferdian Thung, Ivana Clairine Irsan, and David
Lo. 2024. Representation learning for stack overflow posts: How far are we? ACM Transactions on Software Engineering
and Methodology 33, 3 (2024), 1–24.
[45] Jack Herrington. 2003. Code generation in action. Manning Publications Co.
[46] Ann M Hickey and Alan M Davis. 2004. A unified model of requirements elicitation. Journal of management
information systems 20, 4 (2004), 65–84.
[47] Samuel Holt, Max Ruiz Luyten, and Mihaela van der Schaar. 2023. L2mac: Large language model automatic computer
for unbounded code generation. arXiv preprint arXiv:2310.02003 (2023).
[48] Sirui Hong, Xiawu Zheng, Jonathan Chen, Yuheng Cheng, Jinlin Wang, Ceyao Zhang, Zili Wang, Steven Ka Shing
Yau, Zijuan Lin, Liyang Zhou, et al. 2023. Metagpt: Meta programming for multi-agent collaborative framework.
arXiv preprint arXiv:2308.00352 (2023).
[49] John J Horton. 2023. Large language models as simulated economic agents: What can we learn from homo silicus?
Technical Report. National Bureau of Economic Research.
[50] Xinyi Hou, Yanjie Zhao, Yue Liu, Zhou Yang, Kailong Wang, Li Li, Xiapu Luo, David Lo, John Grundy, and Haoyu
Wang. 2024. Large Language Models for Software Engineering: A Systematic Literature Review. ACM Trans. Softw.
Eng. Methodol. 33, 8, Article 220 (Dec. 2024), 79 pages. https://doi.org/10.1145/3695988
[51] Sihao Hu, Tiansheng Huang, Fatih İlhan, Selim Furkan Tekin, and Ling Liu. 2023. Large language model-powered
smart contract vulnerability detection: New perspectives. In 2023 5th IEEE International Conference on Trust, Privacy
and Security in Intelligent Systems and Applications (TPS-ISA). IEEE, 297–306.
[52] Vincent C Hu, D Richard Kuhn, David F Ferraiolo, and Jeffrey Voas. 2015. Attribute-based access control. Computer
48, 2 (2015), 85–88.
[53] Yue Hu, Yuzhu Cai, Yaxin Du, Xinyu Zhu, Xiangrui Liu, Zijie Yu, Yuchen Hou, Shuo Tang, and Siheng Chen. 2024.
Self-Evolving Multi-Agent Collaboration Networks for Software Development. arXiv preprint arXiv:2410.16946 (2024).
[54] Dong Huang, Qingwen Bu, Jie M Zhang, Michael Luck, and Heming Cui. 2023. AgentCoder: Multi-Agent-based Code
Generation with Iterative Testing and Optimisation. arXiv preprint arXiv:2312.13010 (2023).
[55] Nasif Imtiaz, Seaver Thorn, and Laurie Williams. 2021. A comparative study of vulnerability reporting by software
composition analysis tools. In Proceedings of the 15th ACM/IEEE International Symposium on Empirical Software
Engineering and Measurement (ESEM). 1–11.
[56] Yoichi Ishibashi and Yoshimasa Nishimura. 2024. Self-organized agents: A llm multi-agent framework toward ultra
large-scale code generation and optimization. arXiv preprint arXiv:2404.02183 (2024).
[57] Md. Ashraful Islam, Mohammed Eunus Ali, and Md Rizwan Parvez. 2024. MapCoder: Multi-Agent Code Generation for
Competitive Problem Solving. In Proceedings of the 62nd Annual Meeting of the Association for Computational Linguistics
(Volume 1: Long Papers), Lun-Wei Ku, Andre Martins, and Vivek Srikumar (Eds.). Association for Computational
Linguistics, Bangkok, Thailand, 4912–4944. https://aclanthology.org/2024.acl-long.269
[58] Naman Jain, King Han, Alex Gu, Wen-Ding Li, Fanjia Yan, Tianjun Zhang, Sida Wang, Armando Solar-Lezama,
Koushik Sen, and Ion Stoica. 2024. Livecodebench: Holistic and contamination free evaluation of large language
models for code. arXiv preprint arXiv:2403.07974 (2024).
[59] Dongming Jin, Zhi Jin, Xiaohong Chen, and Chunhui Wang. 2024. MARE: Multi-Agents Collaboration Framework
for Requirements Engineering. arXiv preprint arXiv:2405.03256 (2024).
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 26 (Section: 7 Conclusion and Future Work)

26
Junda He, Christoph Treude, and David Lo
[60] Martin Josifoski, Lars Klein, Maxime Peyrard, Nicolas Baldwin, Yifei Li, Saibo Geng, Julian Paul Schnitzler, Yuxing
Yao, Jiheng Wei, Debjit Paul, et al. 2023. Flows: Building blocks of reasoning and collaborating ai. arXiv preprint
arXiv:2308.01285 (2023).
[61] Denis Jouvin and Salima Hassas. 2002. Role delegation as multi-agent oriented dynamic composition. In Proceedings
of Net Object Days (NOD), AgeS workshop, Erfurt, Germany.
[62] Peter Kairouz, H Brendan McMahan, Brendan Avent, Aurélien Bellet, Mehdi Bennis, Arjun Nitin Bhagoji, Kallista
Bonawitz, Zachary Charles, Graham Cormode, Rachel Cummings, et al. 2021. Advances and open problems in
federated learning. Foundations and trends® in machine learning 14, 1–2 (2021), 1–210.
[63] Stephen H Kan. 2003. Metrics and models in software quality engineering. Addison-Wesley Professional.
[64] Sungmin Kang, Bei Chen, Shin Yoo, and Jian-Guang Lou. 2023. Explainable automated debugging via large language
model-driven scientific debugging. arXiv preprint arXiv:2304.02195 (2023).
[65] Enkelejda Kasneci, Kathrin Seßler, Stefan Küchemann, Maria Bannert, Daryna Dementieva, Frank Fischer, Urs Gasser,
Georg Groh, Stephan Günnemann, Eyke Hüllermeier, et al. 2023. ChatGPT for good? On opportunities and challenges
of large language models for education. Learning and individual differences 103 (2023), 102274.
[66] Jaideep Kaur and Vikas Kumar. 2013. Competency mapping: A gap Analysis. International Journal of Education and
Research 1, 1 (2013), 1–9.
[67] Omar Khattab, Arnav Singhvi, Paridhi Maheshwari, Zhiyuan Zhang, Keshav Santhanam, Sri Vardhamanan, Saiful
Haq, Ashutosh Sharma, Thomas T Joshi, Hanna Moazam, et al. 2023. Dspy: Compiling declarative language model
calls into self-improving pipelines. arXiv preprint arXiv:2310.03714 (2023).
[68] Craig Larman. 2004. Agile and iterative development: a manager’s guide. Addison-Wesley Professional.
[69] Hung Le, Yingbo Zhou, Caiming Xiong, Silvio Savarese, and Doyen Sahoo. 2024. INDICT: Code Generation with
Internal Dialogues of Critiques for Both Security and Helpfulness. arXiv preprint arXiv:2407.02518 (2024).
[70] Cheryl Lee, Chunqiu Steven Xia, Jen-tse Huang, Zhouruixin Zhu, Lingming Zhang, and Michael R Lyu. 2024. A
Unified Debugging Approach via LLM-Based Multi-Agent Synergy. arXiv preprint arXiv:2404.17153 (2024).
[71] Dean Leffingwell and Don Widrig. 2000. Managing software requirements: a unified approach. Addison-Wesley
Professional.
[72] Bin Lei, Yuchen Li, and Qiuwu Chen. 2024. AutoCoder: Enhancing Code Large Language Model with\textsc {AIEV-
Instruct}. arXiv preprint arXiv:2405.14906 (2024).
[73] Bin Lei, Yuchen Li, Yiming Zeng, Tao Ren, Yi Luo, Tianyu Shi, Zitian Gao, Zeyu Hu, Weitai Kang, and Qiuwu
Chen. 2024. Infant Agent: A Tool-Integrated, Logic-Driven Agent with Cost-Effective API Usage. arXiv preprint
arXiv:2411.01114 (2024).
[74] Ludvig Lemner, Linnea Wahlgren, Gregory Gay, Nasser Mohammadiha, Jingxiong Liu, and Joakim Wennerberg.
2024. Exploring the Integration of Large Language Models in Industrial Test Maintenance Processes. arXiv preprint
arXiv:2409.06416 (2024).
[75] Guohao Li, Hasan Hammoud, Hani Itani, Dmitrii Khizbullin, and Bernard Ghanem. 2024. Camel: Communicative
agents for" mind" exploration of large language model society. Advances in Neural Information Processing Systems 36
(2024).
[76] Jierui Li, Hung Le, Yinbo Zhou, Caiming Xiong, Silvio Savarese, and Doyen Sahoo. 2024. CodeTree: Agent-guided
Tree Search for Code Generation with Large Language Models. arXiv preprint arXiv:2411.04329 (2024).
[77] Junyou Li, Qin Zhang, Yangbin Yu, Qiang Fu, and Deheng Ye. 2024. More agents is all you need. arXiv preprint
arXiv:2402.05120 (2024).
[78] Yuan Li, Yixuan Zhang, and Lichao Sun. 2023. MetaAgents: Simulating Interactions of Human Behaviors for LLM-based
Task-oriented Coordination via Collaborative Generative Agents (arXiv: 2310.06500). arXiv.
[79] Ziyang Li, Jiani Huang, Jason Liu, Felix Zhu, Eric Zhao, William Dodds, Neelay Velingker, Rajeev Alur, and Mayur
Naik. 2024. Relational Programming with Foundational Models. In Proceedings of the AAAI Conference on Artificial
Intelligence, Vol. 38. 10635–10644.
[80] Tian Liang, Zhiwei He, Wenxiang Jiao, Xing Wang, Yan Wang, Rui Wang, Yujiu Yang, Zhaopeng Tu, and Shuming
Shi. 2023. Encouraging divergent thinking in large language models through multi-agent debate. arXiv preprint
arXiv:2305.19118 (2023).
[81] Feng Lin, Dong Jae Kim, et al. 2024. SOEN-101: Code Generation by Emulating Software Process Models Using Large
Language Model Agents. arXiv preprint arXiv:2403.15852 (2024).
[82] Leilei Lin, Yingming Zhou, Wenlong Chen, and Chen Qian. 2024. Think-on-Process: Dynamic Process Generation for
Collaborative Development of Multi-Agent System. arXiv preprint arXiv:2409.06568 (2024).
[83] Haokun Liu, Derek Tam, Mohammed Muqeeth, Jay Mohta, Tenghao Huang, Mohit Bansal, and Colin A Raffel.
2022. Few-shot parameter-efficient fine-tuning is better and cheaper than in-context learning. Advances in Neural
Information Processing Systems 35 (2022), 1950–1965.
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 27 (Section: 7 Conclusion and Future Work)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
27
[84] Jiawei Liu, Chunqiu Steven Xia, Yuyao Wang, and Lingming Zhang. 2024. Is your code generated by chatgpt really
correct? rigorous evaluation of large language models for code generation. Advances in Neural Information Processing
Systems 36 (2024).
[85] Xiangyan Liu, Bo Lan, Zhiyuan Hu, Yang Liu, Zhicheng Zhang, Wenmeng Zhou, Fei Wang, and Michael Shieh. 2024.
CodexGraph: Bridging Large Language Models and Code Repositories via Code Graph Databases. arXiv preprint
arXiv:2408.03910 (2024).
[86] Yizhou Liu, Pengfei Gao, Xinchen Wang, Chao Peng, and Zhao Zhang. 2024. MarsCode Agent: AI-native Automated
Bug Fixing. arXiv preprint arXiv:2409.00899 (2024).
[87] Zihan Liu, Ruinan Zeng, Dongxia Wang, Gengyun Peng, Jingyi Wang, Qiang Liu, Peiyu Liu, and Wenhai Wang. 2024.
Agents4PLC: Automating Closed-loop PLC Code Generation and Verification in Industrial Control Systems using
LLM-based Agents. arXiv preprint arXiv:2410.14209 (2024).
[88] Zijun Liu, Yanzhe Zhang, Peng Li, Yang Liu, and Diyi Yang. 2023. Dynamic llm-agent network: An llm-agent
collaboration framework with agent team optimization. arXiv preprint arXiv:2310.02170 (2023).
[89] Zijun Liu, Yanzhe Zhang, Peng Li, Yang Liu, and Diyi Yang. 2024. A dynamic LLM-powered agent network for
task-oriented agent collaboration. In First Conference on Language Modeling.
[90] David Lo. 2023. Trustworthy and Synergistic Artificial Intelligence for Software Engineering: Vision and Roadmaps.
arXiv preprint arXiv:2309.04142 (2023).
[91] David Lo. 2024. Requirements Engineering for Trustworthy Human-AI Synergy in Software Engineering 2.0. In 2024
IEEE 32nd International Requirements Engineering Conference (RE). IEEE, 3–4.
[92] Yingwei Ma, Qingping Yang, Rongyu Cao, Binhua Li, Fei Huang, and Yongbin Li. 2024. How to Understand Whole
Software Repository? arXiv preprint arXiv:2406.01422 (2024).
[93] Pattie Maes. 1993. Modeling adaptive autonomous agents. Artificial life 1, 1_2 (1993), 135–162.
[94] Zhenyu Mao, Jialong Li, Munan Li, and Kenji Tei. 2024. Multi-role Consensus through LLMs Discussions for
Vulnerability Detection. arXiv preprint arXiv:2403.14274 (2024).
[95] Lina Markauskaite, Rebecca Marrone, Oleksandra Poquet, Simon Knight, Roberto Martinez-Maldonado, Sarah Howard,
Jo Tondeur, Maarten De Laat, Simon Buckingham Shum, Dragan Gašević, et al. 2022. Rethinking the entwinement
between artificial intelligence and human learning: What capabilities do learners need for a world with AI? Computers
and Education: Artificial Intelligence 3 (2022), 100056.
[96] Noble Saji Mathews and Meiyappan Nagappan. 2024. Test-Driven Development for Code Generation. arXiv preprint
arXiv:2402.13521 (2024).
[97] Vasilios Mavroudis. 2024. LangChain. (2024).
[98] Alfred R Mele. 2001. Autonomous agents: From self-control to autonomy. Oxford University Press, USA.
[99] Timothy Meline. 2006. Selecting studies for systemic review: Inclusion and exclusion criteria. Contemporary issues in
communication science and disorders 33, Spring (2006), 21–27.
[100] Emilia Mendes, Pilar Rodriguez, Vitor Freitas, Simon Baker, and Mohamed Amine Atoui. 2018. Towards improving
decision making and estimating the value of decisions in value-based software engineering: the VALUE framework.
Software Quality Journal 26 (2018), 607–656.
[101] Minh Huynh Nguyen, Thang Phan Chau, Phong X Nguyen, and Nghi DQ Bui. 2024. AgileCoder: Dynamic Collaborative
Agents for Software Development based on Agile Methodology. arXiv preprint arXiv:2406.11912 (2024).
[102] Theo X Olausson, Jeevana Priya Inala, Chenglong Wang, Jianfeng Gao, and Armando Solar-Lezama. 2023. Is Self-Repair
a Silver Bullet for Code Generation?. In The Twelfth International Conference on Learning Representations.
[103] Maria Paasivaara, Sandra Durasiewicz, and Casper Lassenius. 2008. Distributed agile development: Using scrum in a
large project. In 2008 IEEE International Conference on Global Software Engineering. IEEE, 87–95.
[104] Stuart L Pardau. 2018. The california consumer privacy act: Towards a european-style privacy regime in the united
states. J. Tech. L. & Pol’y 23 (2018), 68.
[105] Kai Petersen, Claes Wohlin, and Dejan Baca. 2009. The waterfall model in large-scale development. In Product-Focused
Software Process Improvement: 10th International Conference, PROFES 2009, Oulu, Finland, June 15-17, 2009. Proceedings
10. Springer, 386–400.
[106] Huy Nhat Phan, Tien N Nguyen, Phong X Nguyen, and Nghi DQ Bui. 2024. Hyperagent: Generalist software
engineering agents to solve coding tasks at scale. arXiv preprint arXiv:2409.16299 (2024).
[107] Chen Qian, Yufan Dang, Jiahao Li, Wei Liu, Zihao Xie, YiFei Wang, Weize Chen, Cheng Yang, Xin Cong, Xiaoyin
Che, Zhiyuan Liu, and Maosong Sun. 2024. Experiential Co-Learning of Software-Developing Agents. In Proceedings
of the 62nd Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers), Lun-Wei Ku,
Andre Martins, and Vivek Srikumar (Eds.). Association for Computational Linguistics, Bangkok, Thailand, 5628–5640.
https://aclanthology.org/2024.acl-long.305
[108] Chen Qian, Jiahao Li, Yufan Dang, Wei Liu, YiFei Wang, Zihao Xie, Weize Chen, Cheng Yang, Yingli Zhang, Zhiyuan
Liu, et al. 2024. Iterative Experience Refinement of Software-Developing Agents. arXiv preprint arXiv:2405.04219
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 28 (Section: 7 Conclusion and Future Work)

28
Junda He, Christoph Treude, and David Lo
(2024).
[109] Chen Qian, Wei Liu, Hongzhang Liu, Nuo Chen, Yufan Dang, Jiahao Li, Cheng Yang, Weize Chen, Yusheng Su, Xin
Cong, Juyuan Xu, Dahai Li, Zhiyuan Liu, and Maosong Sun. 2024. ChatDev: Communicative Agents for Software
Development. In Proceedings of the 62nd Annual Meeting of the Association for Computational Linguistics (Volume 1:
Long Papers), Lun-Wei Ku, Andre Martins, and Vivek Srikumar (Eds.). Association for Computational Linguistics,
Bangkok, Thailand, 15174–15186. https://aclanthology.org/2024.acl-long.810
[110] Yihao Qin, Shangwen Wang, Yiling Lou, Jinhao Dong, Kaixin Wang, Xiaoling Li, and Xiaoguang Mao. 2024. AgentFL:
Scaling LLM-based Fault Localization to Project-Level Context. arXiv preprint arXiv:2403.16362 (2024).
[111] Zeeshan Rasheed, Malik Abdul Sami, Muhammad Waseem, Kai-Kristian Kemell, Xiaofeng Wang, Anh Nguyen,
Kari Systä, and Pekka Abrahamsson. 2024. AI-powered Code Review with LLMs: Early Results. arXiv preprint
arXiv:2404.18496 (2024).
[112] Zeeshan Rasheed, Muhammad Waseem, Mika Saari, Kari Systä, and Pekka Abrahamsson. 2024. Codepori: Large scale
model for autonomous software development by using multi-agents. arXiv preprint arXiv:2402.01411 (2024).
[113] Haifeng Ruan, Yuntong Zhang, and Abhik Roychoudhury. 2024. SpecRover: Code Intent Extraction via LLMs. arXiv
preprint arXiv:2408.02232 (2024).
[114] Malik Abdul Sami, Muhammad Waseem, Zeeshan Rasheed, Mika Saari, Kari Systä, and Pekka Abrahamsson. 2024.
Experimenting with Multi-Agent Software Development: Towards a Unified Platform. arXiv preprint arXiv:2406.05381
(2024).
[115] Malik Abdul Sami, Muhammad Waseem, Zheying Zhang, Zeeshan Rasheed, Kari Systä, and Pekka Abrahamsson.
2024. AI based Multiagent Approach for Requirements Elicitation and Analysis. arXiv preprint arXiv:2409.00038
(2024).
[116] Ravi S Sandhu. 1998. Role-based access control. In Advances in computers. Vol. 46. Elsevier, 237–286.
[117] Noah Shinn, Federico Cassano, Ashwin Gopinath, Karthik Narasimhan, and Shunyu Yao. 2024. Reflexion: Language
agents with verbal reinforcement learning. Advances in Neural Information Processing Systems 36 (2024).
[118] Yoav Shoham. 1993. Agent-oriented programming. Artificial intelligence 60, 1 (1993), 51–92.
[119] Preston G Smith and Guy M Merritt. 2020. Proactive risk management: Controlling uncertainty in product development.
productivity press.
[120] Giriprasad Sridhara, Sourav Mazumdar, et al. 2023. Chatgpt: A study on its utility for ubiquitous software engineering
tasks. arXiv preprint arXiv:2305.16837 (2023).
[121] Zhensu Sun, Xiaoning Du, Zhou Yang, Li Li, and David Lo. 2024. AI Coders Are Among Us: Rethinking Programming
Language Grammar Towards Efficient Code Generation. In Proceedings of the 33rd ACM SIGSOFT International
Symposium on Software Testing and Analysis. 1124–1136.
[122] Ali Sunyaev and Ali Sunyaev. 2020. Distributed ledger technology. Internet computing: Principles of distributed systems
and emerging internet-based technologies (2020), 265–299.
[123] Maryam Taeb, Amanda Swearngin, Eldon Schoop, Ruijia Cheng, Yue Jiang, and Jeffrey Nichols. 2024. Axnav: Replaying
accessibility tests from natural language. In Proceedings of the CHI Conference on Human Factors in Computing Systems.
1–16.
[124] Daniel Tang, Zhenghan Chen, Kisub Kim, Yewei Song, Haoye Tian, Saad Ezzini, Yongfeng Huang, and Jacques Klein
Tegawende F Bissyande. 2024. Collaborative agents for software engineering. arXiv preprint arXiv:2402.02172 (2024).
[125] Wei Tao, Yucheng Zhou, Wenqiang Zhang, and Yu Cheng. 2024. MAGIS: LLM-Based Multi-Agent Framework for
GitHub Issue Resolution. arXiv preprint arXiv:2403.17927 (2024).
[126] Jeff Tian. 2005. Software quality engineering: testing, quality assurance, and quantifiable improvement. John Wiley &
Sons.
[127] Rainer Unland. 2015. Software agent systems. In Industrial Agents. Elsevier, 3–22.
[128] Raymon Van Dinter, Bedir Tekinerdogan, and Cagatay Catal. 2021. Automation of systematic literature reviews: A
systematic literature review. Information and Software Technology 136 (2021), 106589.
[129] Axel Van Lamsweerde. 2000. Requirements engineering in the year 00: A research perspective. In Proceedings of the
22nd international conference on Software engineering. 5–19.
[130] Paul Voigt and Axel Von dem Bussche. 2017. The eu general data protection regulation (gdpr). A Practical Guide, 1st
Ed., Cham: Springer International Publishing 10, 3152676 (2017), 10–5555.
[131] Guanzhi Wang, Yuqi Xie, Yunfan Jiang, Ajay Mandlekar, Chaowei Xiao, Yuke Zhu, Linxi Fan, and Anima Anandkumar.
2023. Voyager: An open-ended embodied agent with large language models. arXiv preprint arXiv:2305.16291 (2023).
[132] Hanbin Wang, Zhenghao Liu, Shuo Wang, Ganqu Cui, Ning Ding, Zhiyuan Liu, and Ge Yu. 2024. INTERVENOR:
Prompting the Coding Ability of Large Language Models with the Interactive Chain of Repair. In Findings of the
Association for Computational Linguistics ACL 2024. 2081–2107.
[133] Luyuan Wang, Yongyu Deng, Yiwei Zha, Guodong Mao, Qinmin Wang, Tianchen Min, Wei Chen, and Shoufa
Chen. 2024. MobileAgentBench: An Efficient and User-Friendly Benchmark for Mobile LLM Agents. arXiv preprint
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 29 (Section: 7 Conclusion and Future Work)

LLM-Based Multi-Agent Systems for Software Engineering:
Literature Review, Vision and the Road Ahead
29
arXiv:2406.08184 (2024).
[134] Lei Wang, Chen Ma, Xueyang Feng, Zeyu Zhang, Hao Yang, Jingsen Zhang, Zhiyuan Chen, Jiakai Tang, Xu Chen,
Yankai Lin, et al. 2023. A Survey on Large Language Model based Autonomous Agents. CoRR abs/2308.11432 (2023).
[135] Qian Wang, Tianyu Wang, Qinbin Li, Jingsheng Liang, and Bingsheng He. 2024. MegaAgent: A Practical Framework
for Autonomous Cooperation in Large-Scale LLM Agent Systems. arXiv preprint arXiv:2408.09955 (2024).
[136] Siyuan Wang, Zhuohan Long, Zhihao Fan, Zhongyu Wei, and Xuanjing Huang. 2024. Benchmark Self-Evolving: A
Multi-Agent Framework for Dynamic LLM Evaluation. arXiv preprint arXiv:2402.11443 (2024).
[137] Zihao Wang, Shaofei Cai, Guanzhou Chen, Anji Liu, Xiaojian Ma, and Yitao Liang. 2023. Describe, explain, plan
and select: Interactive planning with large language models enables open-world multi-task agents. arXiv preprint
arXiv:2302.01560 (2023).
[138] Zefan Wang, Zichuan Liu, Yingying Zhang, Aoxiao Zhong, Lunting Fan, Lingfei Wu, and Qingsong Wen. 2023.
RCAgent: Cloud Root Cause Analysis by Autonomous Agents with Tool-Augmented Large Language Models. arXiv
preprint arXiv:2310.16340 (2023).
[139] Zhitao Wang, Wei Wang, Zirao Li, Long Wang, Can Yi, Xinjie Xu, Luyang Cao, Hanjing Su, Shouzhi Chen, and Jun
Zhou. 2024. XUAT-Copilot: Multi-Agent Collaborative System for Automated User Acceptance Testing with Large
Language Model. arXiv preprint arXiv:2401.02705 (2024).
[140] Zekun Moore Wang, Zhongyuan Peng, Haoran Que, Jiaheng Liu, Wangchunshu Zhou, Yuhan Wu, Hongcheng Guo,
Ruitong Gan, Zehao Ni, Man Zhang, et al. 2023. Rolellm: Benchmarking, eliciting, and enhancing role-playing abilities
of large language models. arXiv preprint arXiv:2310.00746 (2023).
[141] Peter Wegner. 1990. Concepts and paradigms of object-oriented programming. ACM Sigplan Oops Messenger 1, 1
(1990), 7–87.
[142] Ratnadira Widyasari, David Lo, and Lizi Liao. 2024. Beyond ChatGPT: Enhancing Software Quality Assurance Tasks
with Diverse LLMs and Validation Techniques. arXiv preprint arXiv:2409.01001 (2024).
[143] Claes Wohlin. 2014. Guidelines for snowballing in systematic literature studies and a replication in software
engineering. In Proceedings of the 18th international conference on evaluation and assessment in software engineering.
1–10.
[144] Michael Wooldridge. 2009. An introduction to multiagent systems. John wiley & sons.
[145] Qingyun Wu, Gagan Bansal, Jieyu Zhang, Yiran Wu, Shaokun Zhang, Erkang Zhu, Beibin Li, Li Jiang, Xiaoyun Zhang,
and Chi Wang. 2023. Autogen: Enabling next-gen llm applications via multi-agent conversation framework. arXiv
preprint arXiv:2308.08155 (2023).
[146] Yiran Wu, Feiran Jia, Shaokun Zhang, Qingyun Wu, Hangyu Li, Erkang Zhu, Yue Wang, Yin Tat Lee, Richard Peng, and
Chi Wang. 2023. An empirical study on challenging math problem solving with gpt-4. arXiv preprint arXiv:2306.01337
(2023).
[147] Zengqing Wu, Shuyuan Zheng, Qianying Liu, Xu Han, Brian Inhyuk Kwon, Makoto Onizuka, Shaojie Tang, Run
Peng, and Chuan Xiao. 2024. Shall We Talk: Exploring Spontaneous Collaborations of Competing LLM Agents. arXiv
preprint arXiv:2402.12327 (2024).
[148] Zhiheng Xi, Wenxiang Chen, Xin Guo, Wei He, Yiwen Ding, Boyang Hong, Ming Zhang, Junzhe Wang, Senjie Jin,
Enyu Zhou, et al. 2023. The rise and potential of large language model based agents: A survey. arXiv preprint
arXiv:2309.07864 (2023).
[149] Chunqiu Steven Xia, Matteo Paltenghi, Jia Le Tian, Michael Pradel, and Lingming Zhang. 2024. Fuzz4all: Universal
fuzzing with large language models. In Proceedings of the IEEE/ACM 46th International Conference on Software
Engineering. 1–13.
[150] Chenyuan Yang, Yinlin Deng, Runyu Lu, Jiayi Yao, Jiawei Liu, Reyhaneh Jabbarvand, and Lingming Zhang. 2023.
White-box compiler fuzzing empowered by large language models. arXiv preprint arXiv:2310.15991 (2023).
[151] Chengran Yang, Jiakun Liu, Bowen Xu, Christoph Treude, Yunbo Lyu, Ming Li, and David Lo. 2023. APIDocBooster:
An Extract-Then-Abstract Framework Leveraging Large Language Models for Augmenting API Documentation.
arXiv preprint arXiv:2312.10934 (2023).
[152] Weiqing Yang, Hanbin Wang, Zhenghao Liu, Xinze Li, Yukun Yan, Shuo Wang, Yu Gu, Minghe Yu, Zhiyuan Liu, and
Ge Yu. 2024. Enhancing the Code Debugging Ability of LLMs via Communicative Agent Based Data Refinement.
arXiv preprint arXiv:2408.05006 (2024).
[153] Xun Yi, Russell Paulet, Elisa Bertino, Xun Yi, Russell Paulet, and Elisa Bertino. 2014. Homomorphic encryption.
Springer.
[154] Juyeon Yoon, Robert Feldt, and Shin Yoo. 2024. Intent-Driven Mobile GUI Testing with Autonomous Large Language
Model Agents. In 2024 IEEE Conference on Software Testing, Verification and Validation (ICST). IEEE, 129–139.
[155] Daoguang Zan, Ailun Yu, Wei Liu, Dong Chen, Bo Shen, Wei Li, Yafen Yao, Yongshun Gong, Xiaolin Chen, Bei Guan,
et al. 2024. CodeS: Natural Language to Code Repository via Multi-Layer Sketch. arXiv preprint arXiv:2403.16443
(2024).
, Vol. 1, No. 1, Article . Publication date: July 2025.

## Page 30 (Section: 7 Conclusion and Future Work)

30
Junda He, Christoph Treude, and David Lo
[156] Zhengran Zeng, Hanzhuo Tan, Haotian Zhang, Jing Li, Yuqun Zhang, and Lingming Zhang. 2022. An extensive
study on pre-trained models for program understanding and generation. In Proceedings of the 31st ACM SIGSOFT
international symposium on software testing and analysis. 39–51.
[157] Guibin Zhang, Yanwei Yue, Xiangguo Sun, Guancheng Wan, Miao Yu, Junfeng Fang, Kun Wang, and Dawei Cheng.
2024. G-designer: Architecting multi-agent communication topologies via graph neural networks. arXiv preprint
arXiv:2410.11782 (2024).
[158] Huan Zhang, Wei Cheng, Yuhan Wu, and Wei Hu. 2024. A Pair Programming Framework for Code Generation via
Multi-Plan Exploration and Feedback-Driven Refinement. arXiv preprint arXiv:2409.05001 (2024).
[159] Kexun Zhang, Weiran Yao, Zuxin Liu, Yihao Feng, Zhiwei Liu, Rithesh Murthy, Tian Lan, Lei Li, Renze Lou, Jiacheng
Xu, et al. 2024. Diversity Empowers Intelligence: Integrating Expertise of Software Engineering Agents. arXiv preprint
arXiv:2408.07060 (2024).
[160] Lyuye Zhang, Kaixuan Li, Kairan Sun, Daoyuan Wu, Ye Liu, Haoye Tian, and Yang Liu. 2024. Acfix: Guiding llms with
mined common rbac practices for context-aware repair of access control vulnerabilities in smart contracts. arXiv
preprint arXiv:2403.06838 (2024).
[161] Li Zhang, Jia-Hao Tian, Jing Jiang, Yi-Jun Liu, Meng-Yuan Pu, and Tao Yue. 2018. Empirical research in software
engineering—a literature survey. Journal of Computer Science and Technology 33 (2018), 876–899.
[162] Simiao Zhang, Jiaping Wang, Guoliang Dong, Jun Sun, Yueling Zhang, and Geguang Pu. 2024. Experimenting a New
Programming Practice with LLMs. arXiv preprint arXiv:2401.01062 (2024).
[163] Sai Zhang, Zhenchang Xing, Ronghui Guo, Fangzhou Xu, Lei Chen, Zhaoyuan Zhang, Xiaowang Zhang, Zhiyong
Feng, and Zhiqiang Zhuang. 2024. Empowering Agile-Based Generative Software Development through Human-AI
Teamwork. arXiv preprint arXiv:2407.15568 (2024).
[164] Yue Zhang, Yafu Li, Leyang Cui, Deng Cai, Lemao Liu, Tingchen Fu, Xinting Huang, Enbo Zhao, Yu Zhang, Yulong
Chen, et al. 2023. Siren’s song in the AI ocean: a survey on hallucination in large language models. arXiv preprint
arXiv:2309.01219 (2023).
[165] Yuntong Zhang, Haifeng Ruan, Zhiyu Fan, and Abhik Roychoudhury. 2024. Autocoderover: Autonomous program
improvement. In Proceedings of the 33rd ACM SIGSOFT International Symposium on Software Testing and Analysis.
1592–1604.
[166] Zhonghan Zhao, Kewei Chen, Dongxu Guo, Wenhao Chai, Tian Ye, Yanting Zhang, and Gaoang Wang. 2024. Hierar-
chical Auto-Organizing System for Open-Ended Multi-Agent Navigation. arXiv preprint arXiv:2403.08282 (2024).
[167] Zibin Zheng, Shaoan Xie, Hong-Ning Dai, Xiangping Chen, and Huaimin Wang. 2018. Blockchain challenges and
opportunities: A survey. International journal of web and grid services 14, 4 (2018), 352–375.
[168] Xin Zhou, Sicong Cao, Xiaobing Sun, and David Lo. 2024. Large Language Model for Vulnerability Detection and
Repair: Literature Review and the Road Ahead. arXiv preprint arXiv:2404.02525 (2024).
[169] Xin Zhou, Bowen Xu, DongGyun Han, Zhou Yang, Junda He, and David Lo. 2023. CCBERT: Self-Supervised Code
Change Representation Learning. In 2023 IEEE International Conference on Software Maintenance and Evolution (ICSME).
IEEE, 182–193.
[170] Tong Zhu, Xiaoye Qu, Daize Dong, Jiacheng Ruan, Jingqi Tong, Conghui He, and Yu Cheng. 2024. Llama-moe:
Building mixture-of-experts from llama with continual pre-training. In Proceedings of the 2024 Conference on Empirical
Methods in Natural Language Processing. 15913–15923.
[171] Terry Yue Zhuo, Minh Chien Vu, Jenny Chim, Han Hu, Wenhao Yu, Ratnadira Widyasari, Imam Nur Bani Yusuf,
Haolan Zhan, Junda He, Indraneil Paul, et al. 2024. Bigcodebench: Benchmarking code generation with diverse
function calls and complex instructions. arXiv preprint arXiv:2406.15877 (2024).
, Vol. 1, No. 1, Article . Publication date: July 2025.


---

# Machine learning-based bioactivity prediction of porphyrin derivatives: molecular descriptors, clustering, and model evaluation

- **Authors:** Tugba Muhlise Okyay, Ibrahim Yilmaz, Macit Koldas
- **Issuer:** Photochemical & photobiological sciences : Official journal of the European Photochemistry Association and the European Society for Photobiology
- **Type:** Scientific article
- **Published:** 2025-05-15
- **Language:** en
- **DOI:** 10.1007/s43630-025-00733-8
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40372610/
- **Licence:** CC-BY

## Section: Abstract

Understanding the relationship between molecular structure and bioactivity is crucial for optimizing porphyrin-based therapeutics. By integrating cheminformatics techniques with machine learning models, our work enables the efficient classification of compounds based on their molecular structures and their growth inhibition capabilities (IC50). A dataset of 317 porphyrin derivatives was compiled, incorporating molecular descriptors and biological activity data. Descriptive statistical analysis was performed to examine compound distribution and key features. Clustering analysis was conducted using hierarchical clustering and fingerprint similarity matrices to classify compounds based on structural similarity. Lipinski's Rule of Five was applied to assess drug-likeness, while Murcko scaffold analysis identified core structural patterns. Tumor response data were analyzed to evaluate therapeutic efficacy. Machine learning models were implemented to predict bioactivity. Descriptive statistics highlighted bioactive compounds, with TMPyP4 and Temaporfin being the most studied. Quantitative estimation of drug-likeness and the number of aliphatic carboxylic acids were identified as the most influential descriptors among others for bioactivity. Hierarchical clustering segmented porphyrins into nine structural groups. The analysis identified 168 pIC50 active compounds, with 31 meeting Lipinski's criteria, and 11 overlapping as both effective and bioavailable. Tumor response analysis revealed three porphyrins achieving 100% response. Logistic Regression emerged as the best-performing model, achieving 83% accuracy, demonstrating robust predictive capabilities. This study successfully characterized porphyrin derivatives, reviewing key molecular features influencing bioactivity and evaluating their therapeutic potential. It highlights the potential of machine learning in predicting the biological activity status of porphyrin derivatives.


---

# Machine Learning-Based Prognostic Signature in Breast Cancer: Regulatory T Cells, Stemness, and Deep Learning for Synergistic Drug Discovery

- **Authors:** Samina Gul, Jianyu Pang, Yongzhi Chen, Qi Qi, Yuheng Tang, Yingjie Sun, Hui Wang, Wenru Tang, Xuhong Zhou
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2025-07-21
- **Language:** en
- **DOI:** 10.3390/ijms26146995
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40725242/
- **Licence:** CC-BY

## Section: Abstract

AbstractRegulatory T cells (Tregs) have multiple roles in the tumor microenvironment (TME), which maintain a balance between autoimmunity and immunosuppression. This research aimed to investigate the interaction between cancer stemness and Regulatory T cells (Tregs) in the breast cancer tumor immune microenvironment. Breast cancer stemness was calculated using one-class logistic regression. Twelve main cell clusters were identified, and the subsequent three subsets of Regulatory T cells with different differentiation states were identified as being closely related to immune regulation and metabolic pathways. A prognostic risk model including MEA1, MTFP1, PASK, PSENEN, PSME2, RCC2, and SH2D2A was generated through the intersection between Regulatory T cell differentiation-related genes and stemness-related genes using LASSO and univariate Cox regression. The patient’s total survival times were predicted and validated with AUC of 0.96 and 0.831 in both training and validation sets, respectively; the immunotherapeutic predication efficacy of prognostic signature was confirmed in four ICI RNA-Seq cohorts. Seven drugs, including Ethinyl Estradiol, Epigallocatechin gallate, Cyclosporine, Gentamicin, Doxorubicin, Ivermectin, and Dronabinol for prognostic signature, were screened through molecular docking and found a synergistic effect among drugs with deep learning. Our prognostic signature potentially paves the way for overcoming immune resistance, and blocking the interaction between cancer stemness and Tregs may be a new approach in the treatment of breast cancer.Keywords: breast cancer, stemness, regulatory T cells, machine learning, deep learning

## Section: 1. Introduction

Breast cancer ranks as the second most common disease on a global scale, according to the World Health Organization (WHO) reports [1]. Every year, women are diagnosed with approximately 268,600 new cases of invasive breast cancer, and about 41,760 women will die from breast cancer, as estimated by the American Cancer Society. Breast cancer is the sixth leading cause of cancer-related deaths among Chinese women, and approximately 11% of all breast cancers worldwide occur in China [1,2,3].

Regulatory T cells (Tregs) are a subset of lymphocytes characterized by the expression of the transcription factor FoxP3, playing a pivotal role in maintaining autoimmune tolerance, exhibiting strong immunosuppressive activity, as well as facilitating the initiation and progression of tumors by suppressing their antitumor immunity [4]. Tregs in the tumor microenvironment can inhibit dendritic cells, B cells, monocytes/macrophages, and other immunocompetent cells through cytotoxicity and cytokine secretion [5,6]. Tregs have been proven to promote the stemness of tumor cells, including those in glioma [7], leukemia [8], and breast cancer [9]. Cancer stem cells (CSCs) are a robust, heterogeneous population and the cellular sources of unlimited growth and recurrence of malignant tumors. Stemness plays a critical role in breast cancer growth, metastasis, and drug resistance [1,10]. The messenger RNA (mRNA) expression-based stemness index (mRNAsi) is used to quantify the unique characteristics of CSCs; Malta et al. developed a scoring system using one-class logistic regression (OCLR) machine learning algorithm as a robust method to quantify the cancer stemness [1,11,12,13]. In the new era of cancer treatment immunotherapies, immune checkpoint inhibitors (ICIs) have provided a paradigm shift and most immune checkpoint molecules are expressed in Tregs [14,15,16,17]. The effect of ICIs on Tregs and their contribution to treatment response remain unclear in breast cancer. We can accurately characterize breast cancer stemness and Regulatory T cells and identify the prognostic risk signature’s genes at a single-cell resolution to investigate better the impact of stemness and Tregs on ICIs. Here in this work, we established the prognostic risk model for breast cancer (BC). Our findings uncovered the potential of a prognostic risk model for predicting the prognosis, ICI outcomes, and immunotherapy effects of BC patients. Finally, the expression of genes in the prognostic risk model was validated using the HPA (Human Protein Atlas) database, and molecular docking and deep learning research were conducted to understand the performance of these genes and ways to improve them.

## Section: 2. Results

Single-cell analysis: Cell clusters and their markers were obtained by reduced-dimensional and clustering. (A) A total of 25 cell clusters were obtained after first-level classification. (B) A total of 12 cell types were obtained by marker gene annotation. (C) Expression levels of marker genes from 25 cell types. (D) A total of 13 cell clusters were identified after the second-level classification of T Regulatory cells. (E) Nine cell types were determined by marker gene annotation.

Mutational analysis of T regulatory cell-related differential genes and pseudotime analysis of Tregs. (A) According to pseudotime analysis (B), Tregs were divided into three differentiation states. (C) Treg-related differential genes in three differentiation states. (D) Top 30% mutation frequency of Treg-related differential genes. (E) Mutation of Treg-related differential genes in three differentiation states. (F–H) GSEA analyzes the three differentiation states of Tregs.

Construction and verification of prognostic risk signature model. (A) Differential genes between high- and low-mRNAsi (stemness index). (B) The intersection between differential genes related to stemness index and Treg-related differential genes. (C,D) Seven TDRGs (T regulatory cell differentiation-related genes) with prognostic characteristics were screened by the LASSO regression algorithm. (E) The risk score, patient status, and mRNA expression heatmap.

Verification of the prognostic risk signature model. (A–D) Survival analysis curve and ROC of training sets. (E–H) Survival analysis curve and ROC of validation sets. (I) Nomogram of prognostic risk signature model. (J) Nomogram calibration curves to predict 1-, 3-, and 5-year survival.

Immune predictive performance and clinical predictive power of the prognostic risk signature. (A) The abundance of 28 immune cells in high- and low-risk groups after grouping the risk score according to the median. (B) Spearman correlation analysis between the abundance of 28 cells and risk score. (C–G) Age, M state, N stage, T stage, and stage distribution of the high-risk and low-risk groups of patients. (H) Univariate regression analysis and (I) multivariate regression analysis of TCGA cohorts (* p < 0.05; ** p < 0.01; *** p < 0.001; **** p < 0.0001).

Expression analysis and Spearman correlation analysis between the abundance of 28 cells and prognostic genes, as well as functional analysis of seven prognostic genes in TCGA cohorts. (A) Expression level of seven prognostic genes in the TCGA cohorts. GSVA after grouping (B) MEAI, (C) MTFP1, (D) PASK, (E) PSENEN, (F) PSME2, (G) RCC2, and (H) SH2D2A into high and low levels. (I–O) Spearman correlation analysis between the abundance of 28 cells and seven prognostic genes. (* p < 0.05; ** p < 0.01; *** p < 0.001; **** p < 0.0001).

Prediction of ICI outcome using prognostic risk model. Kaplan–Meier curves comparing OS between high-risk and low-risk patients after ICI treatments.

Molecular docking results of proteins encoded by prognostic risk genes with small molecular compounds. (A) The docking results of MEAI with Ethinyl Estradiol. (B) The docking results of MTFP1 with epigallocatechin gallate. (C) The docking results of PASK with Cyclosporine. (D) The docking results of PSENEN Gentamicin. (E) The docking results of PSME2 with Doxorubicin. (F) The docking results of RCC2 with Ivermectin. (G) The docking results of SH2D2A with Dronabinol.

Top twenty synergistic effects between two drugs in breast cancer cell lines.

Expression level of mRNA and protein of prognostic risk signature. (A) PASK protein expression level in normal breast tissue (B) and breast cancer tissue. (C) PSENEN expression in normal breast tissue (D) and breast cancer tissue. (E) RCC2 expression in normal breast tissue and (F) in breast cancer tissue.

## Section: 2. Results › 2.1. Identification of Cell Types

All the cells were clustered into 25 clusters by standard procedure (Figure 1A) and further annotated into twelve cell types, including Cancer/Epithelial cells, Macrophages, T cells, Mesenchymal cells, Endothelial cells, B cells, Neutrophils, Natural Killer cells (NK), Fibroblast, Leydig cells, MKI67+Progenitor cells, and Progenitor cells (Figure 1B), and the marker gene expression levels of the twelve cells are shown in Figure 1C, followed by further subgroup clustering of T Regulatory cells into thirteen clusters (Figure 1D), with nine additional subgroups identified by annotation: Regulatory T cells, Naïve CD8+ T cell, CD4+ T cell, T helper cell, Cytotoxic T cell, Exhausted T cell, Natural Killer T cell (NKT), CD4+ cytotoxic T cells and CD8+ T cell (Figure 1E).

Single-cell analysis: Cell clusters and their markers were obtained by reduced-dimensional and clustering. (A) A total of 25 cell clusters were obtained after first-level classification. (B) A total of 12 cell types were obtained by marker gene annotation. (C) Expression levels of marker genes from 25 cell types. (D) A total of 13 cell clusters were identified after the second-level classification of T Regulatory cells. (E) Nine cell types were determined by marker gene annotation.

## Section: 2. Results › 2.2. Different Differentiation Characteristics of Tregs

Next, we used Monocle for pseudotime trajectory analysis of Treg subsets; the results showed that Tregs were divided into three differentiation states (Figure 2A,B). The TRDGs related to the three states of Tregs are shown in (Figure 2C). The mutation rates of TRDGs in the three states were approximately 97%. The top 30 TDRGs of the twelve genes with a mutation rate ≥ 2% (Figure 2D,E) demonstrate that TDRGs are highly mutated and heterogeneous, suggesting that TDRGs play an essential role in Tregs influencing tumor growth and proliferation. The GSEA was performed on three states of Tregs (Figure 2F–H and Figure S1A–C); it was found that state one was significantly upregulated in autoimmune thyroid disease, bladder cancer, asthma, rheumatoid arthritis, and transcriptional mis-regulation in cancer, indicating that state one is mainly related to the development and occurrence of different disease and tumors. State two was upregulated in purine metabolism, mRNA surveillance pathways, and Coronavirus disease and downregulated in apoptosis and Natural killer cell-mediated cytotoxicity. State three is regulated in measles, JAK-STAT signaling pathway, and MAPK signaling pathways, indicating that state three is also related to the growth and development of tumors.

Mutational analysis of T regulatory cell-related differential genes and pseudotime analysis of Tregs. (A) According to pseudotime analysis (B), Tregs were divided into three differentiation states. (C) Treg-related differential genes in three differentiation states. (D) Top 30% mutation frequency of Treg-related differential genes. (E) Mutation of Treg-related differential genes in three differentiation states. (F–H) GSEA analyzes the three differentiation states of Tregs.

## Section: 2. Results › 2.3. Development and Verification of Prognostic Risk Model

We used OCLR algorithm, calculated the stemness index (mRNAsi) for each patient in the BRCA cohort using RNA-seq data, and based on median value, patients were placed into high- and low-mRNAsi groups. “LIMMA” package was utilized to identify differential genes (DEGs) between high- and low-mRNAsi groups (Figure 3A) to construct a prognostic risk model. The TCGA cohort consist of 1217 samples (n = 1217) was split into training set (n = 796) and validation set (n = 421) at an equal ratio of 7:3. In addition, TDGRs and stemness-related DEGs were intersected (Figure 3B) and the intersected genes were used to build a prognostic risk model. Firstly, we identified 26 genes using univariate Cox regression analysis and reduced the number to 7 genes using LASSO regression (Figure 3C,D); then, we used these 7 genes to build a prognosis signature. The prognostic signature formula was as follows: Risk score = −0.049 × Exp (MEA1) − 0.082 × Exp (MTFP1) − 0.143 × Exp (PASK) − 0.0214 × Exp (PSENEN) − 0.132 × Exp (PSME2) − 0.096 × Exp (RCC2) − 0.030 × Exp (SH2D2A). According to the Risk score formula, we counted the risk score of all patients and assigned them to high-risk (n = 398) and low-risk (n = 398) groups using the median risk score. The association between survival and risk score information is exhibited in Figure 3E.

In the training set, 796 samples (n = 796), the patients in the low-risk group (n = 398) had significantly longer overall survival times (p = 0.00022, HR = 3.4, Figure 4A) and the AUC was 0.96 for 1-year, 3-year and 5-year (Figure 4B–D), indicating that the prognostic risk signature has high precision. We used the same method assigned to the validation set (n = 398). The patients in the low-risk group showed longer survival rates (p = 0.05, HR = 3.6, Figure 3E), and the AUC was 0.831 for 1-year, 3-year, and 5-year survival, which indicated that the prognostic risk model has predictive power (Figure 4F–H). Finally, we established a nomogram using the prognostic risk signature (Figure 4I). The calibration curves for 1-year, 3-year, and 5-year survival indicate a high degree of overlap between the actual survival and survival rate predicated by the nomogram (Figure 4J), suggesting that the nomogram has a significant predictive value.

Construction and verification of prognostic risk signature model. (A) Differential genes between high- and low-mRNAsi (stemness index). (B) The intersection between differential genes related to stemness index and Treg-related differential genes. (C,D) Seven TDRGs (T regulatory cell differentiation-related genes) with prognostic characteristics were screened by the LASSO regression algorithm. (E) The risk score, patient status, and mRNA expression heatmap.

Verification of the prognostic risk signature model. (A–D) Survival analysis curve and ROC of training sets. (E–H) Survival analysis curve and ROC of validation sets. (I) Nomogram of prognostic risk signature model. (J) Nomogram calibration curves to predict 1-, 3-, and 5-year survival.

## Section: 2. Results › 2.4. Immune Prediction and Clinical Application of Prognostic Risk Signature

The GSA result found that the content of most immune cells in the low-risk group was higher than that in the high-risk group, indicating that there were fewer immune cells in the tumor microenvironment of the high-risk group. Also, the immune prognosis of the high-risk group was worse (Figure 5A,B); the effect of immunotherapy worsens as the risk score increases and the immune composition decreases. The above results showed that the prognostic risk signature was involved in regulating the immune microenvironment and can be used as an indicator to predict the efficacy of immunotherapy. Then, we investigated the relationship between risk score and clinical characteristics; there were significant statistics among Age, M state, and T stage (Figure 5C–G), which indicated that risk score was related to M state, T stage, and Age. Next, we explored the clinical application of seven prognostic risk signatures in predicting patient outcomes using Cox regression analysis univariate, Cox regression analysis, and multivariate Cox regression analysis to check whether the prognostic risk signature can be independently prognostic. Univariate Cox regression analysis demonstrated that the risk score was significantly associated with prognostic factors (Figure 5H), and multivariate Cox regression analysis showed that risk score was an independent factor for BRCA patients (Figure 5I). These results confirmed that the seven prognostic risk signature has excellent prognostic efficiency.

Immune predictive performance and clinical predictive power of the prognostic risk signature. (A) The abundance of 28 immune cells in high- and low-risk groups after grouping the risk score according to the median. (B) Spearman correlation analysis between the abundance of 28 cells and risk score. (C–G) Age, M state, N stage, T stage, and stage distribution of the high-risk and low-risk groups of patients. (H) Univariate regression analysis and (I) multivariate regression analysis of TCGA cohorts (* p < 0.05; ** p < 0.01; *** p < 0.001; **** p < 0.0001).

## Section: 2. Results › 2.5. Functional Enrichment Analysis of Prognostic Risk Genes Signature

We further explored the prognostic risk genes expression and pathways alteration of the seven prognostic genes expressed at a low and high level in tumor tissues using TCGA BRCA cohort (Figure 6A). Firstly, for MEA1, it was upregulated in tumor tissue, and the results of various pathways including gastric cancer, breast cancer, basal cell carcinoma, and signaling pathways regulating the pluripotency of stem cells (Figure 6B), and MEA1 was negatively correlated with the abundance of most immune cells (Figure 6I), indicating that MEA1 was involved in tumor progression. Similarly, MTFP1 was expressed at a low level in tumor tissue. The results of GSVA showed that MTFP1 upregulated IL-17 signaling pathways, calcium signaling pathways, breast cancer, negative regulation of epithelial cell apoptotic process, negative regulation of endothelial cell apoptotic process, fibrinolysis and signaling pathways regulating pluripotency of stem cells (Figure 6C); MTFP1 showed negative correlation to most immune cells (Figure 6J), indicating that MTFP1 promotes tumor growth and progression. As for PASK, it showed a high expression level in tumor tissue and showed a negative correlation with the abundance of immune cells (Figure 6K); it was found that PASK downregulated defense response and antimicrobial humoral response, with downregulation in defense response to a Gram-positive bacterium (Figure 6D), indicating that high expression of PASK in tumor tissue was not suppressed by immune cells. Furthermore, PSENEN showed increased expression in tumor tissue and showed a negative correlation with the abundance of most immune cells using Spearman correlation analysis (Figure 6L), and central carbon metabolism in cancer and carbohydrate digestion and absorption were increased significantly (Figure 6E), which also proved the role of PSENEN in promoting cancer progression. After the overexpression of PSME2, it was found that it upregulated the IL-17 signaling pathways, chemokines signaling pathways, Corona disease COVID-19, and transcriptional mis-regulation in cancer (Figure 6F), while Spearman correlation analysis showed that they were positively correlated with the abundance of immune cells (Figure 6M), suggesting that it plays a role in various immune and inflammation responses. RCC2 and SHD2A2 both were highly expressed in tumor tissue: RCC2 showed positive as well as negative correlation with the abundance of most immune cells (Figure 6N); it upregulated the tryptophan metabolism, cholesterol metabolism, and signaling pathways regulating pluripotency of stem cells (Figure 6G), implying that RCC2 promotes cancer cell growth and differentiation. After the high expression of SH2DA2, it was found that it upregulates the JAK-STAT signaling pathway, PI3K-Akt signaling, chemokine signaling pathways, IL17 signaling pathways, regulation of Regulatory T cells differentiation, production of interleukin-2 production, and regulation of chronic inflammatory response (Figure 6H), and showed positive correlation with abundance of immune cells (Figure 6O), suggesting that SH2D2A might affect immune function.

Expression analysis and Spearman correlation analysis between the abundance of 28 cells and prognostic genes, as well as functional analysis of seven prognostic genes in TCGA cohorts. (A) Expression level of seven prognostic genes in the TCGA cohorts. GSVA after grouping (B) MEAI, (C) MTFP1, (D) PASK, (E) PSENEN, (F) PSME2, (G) RCC2, and (H) SH2D2A into high and low levels. (I–O) Spearman correlation analysis between the abundance of 28 cells and seven prognostic genes. (* p < 0.05; ** p < 0.01; *** p < 0.001; **** p < 0.0001).

## Section: 2. Results › 2.6. Immunotherapy Outcome Prediction by Prognostic Risk Signature

We collected bulk RNA-seq data and clinical information from 4 ICI cohorts to investigate the predictive value of prognostic risk signature. Pre-treatment samples of 4 ICI cohorts were curated and analyzed. Patients received anti-PD(L)-1 and anti-CTLA-4. To evaluate whether the prognostic risk signature model can predict overall survival, we merged the 4 ICI cohorts into a large cohort consist on 381 samples (n = 381) and randomly selected 149 ICI-treated patient samples into high and low-risk subgroups; the Kaplan–Meier analysis of OS is shown in (Figure 7). High-risk group achieved a significantly longer survival (p value < 0.05).

Prediction of ICI outcome using prognostic risk model. Kaplan–Meier curves comparing OS between high-risk and low-risk patients after ICI treatments.

## Section: 2. Results › 2.7. Molecular Docking of Prognostic Risk Signature Genes

In this work, we used the screening of the CTD database, as well as Autodock molecular docking and drug toxicology studies to identify potential drugs targeting prognostic risk signature genes. We found that Ethinyl Estradiol binds with MEA1 with optimal docking binding energy of −2 (kcal/mol) and downregulated MEA1 mRNA expression (Figure 8A). Estradiol is often used in treating estrogen depletion in women. The results of molecular docking analysis indicated that epigallocatechin gallate tightly binds to MTFP1 with a docking energy of −9.01 (kcal/mol) (Figure 8B) and downregulated the mRNA expression of MTFP1. Epigallocatechin gallate is a polyphenolic compound found in green tea used against neurological diseases, including Alzheimer’s disease, multiple sclerosis, and Parkinson’s disease, and it is also effective against anticancer activities. Cyclosporine actively binds with PASK with an optimal docking energy of −15.399 kcal/mol) (Figure 8C) and downregulated the mRNA expression of PASK. Cyclosporine is a first-line immunosuppressive drug to prevent rejection in transplantation and is also used against different cancer activities. Gentamicin downregulated the mRNA expression of PSENEN and exhibited docking binding energy of −6.54 (kcal/mol) (Figure 8D). Gentamicin is an aminoglycoside antibiotic used in the treatment of infectious diseases and also significantly impacted cancer treatment. Doxorubicin exhibited a high level of docking energy of up to −11.69 (kcal/mol) and downregulated the mRNA expression of PSME2 (Figure 8E). Doxorubicin is a chemotherapy drug that slows cancer cell growth and prevents its repaid division. Ivermectin, with an optimal binding energy of −21.05 (kcal/mol), tightly binds with RCC2 and downregulates its mRNA expression (Figure 8F). Ivermectin is a dihydro derivate of avermectin, which is more efficient against several kinds of parasitic diseases including onchocerciasis and lymphatic filariasis, and also prevents tumor cell growth and metastasis. Finally, in screening for small molecule compounds that downregulated SH2D2A mRNA expression (Figure 8G), Dronabinol exhibited molecular docking energy of −6.44 (kcal/mol). Dronabinol is a synthetic form of THC (Δ-9-tetrahydrocannabinol), also indicated in adults for the treatment of anorexia-associated weight loss in patients with HIV/AIDS. In summary, we have selected seven small molecular compounds suggested to improve the poor prognosis caused by the prognostic risk signature of seven genes, providing new insights into targeted breast cancer therapy.

Molecular docking results of proteins encoded by prognostic risk genes with small molecular compounds. (A) The docking results of MEAI with Ethinyl Estradiol. (B) The docking results of MTFP1 with epigallocatechin gallate. (C) The docking results of PASK with Cyclosporine. (D) The docking results of PSENEN Gentamicin. (E) The docking results of PSME2 with Doxorubicin. (F) The docking results of RCC2 with Ivermectin. (G) The docking results of SH2D2A with Dronabinol.

## Section: 2. Results › 2.8. Prediction of Synergistic Drug Combination by Deep Learning

We trained using data from previous studies, which included 38 drugs and 39 cell lines. According to 6:2:2, the training data is divided into training, verification, and test sets. We optimized drug coding methods and deep learning models from previous studies to be able to predict synergistic values for drug combinations used outside of the training data. Building a deep learning model with TensorFlow, we expected the synergistic effect between the two drugs in the breast cancer cell lines, and the synergistic value was more significant than 0, indicating a synergistic effect; the top twenty synergistic effects are shown in Table 1.

Top twenty synergistic effects between two drugs in breast cancer cell lines.

## Section: 2. Results › 2.9. Elucidate the Expression Levels of mRNA and Protein of Prognostic Risk Signature Genes

To explore the clinical significance of the seven prognostic risk model-related genes, used clinical specimens from the HPA (Human Protein Atlas) database; HPA analysis showed that the protein levels PASK, PSENEN, and RCC2 were shown in Breast cancer tissues compared to normal Breast tissue and MTFP1, PSME2, MEA1, and SH2D2A were not found in database. It was discovered that prognostic risk model-related three genes, including PASK, PSENEN, and RCC2, were upregulated in cancer tissue compared to normal Breast tissue, as shown in (Figure 9A–F).

Expression level of mRNA and protein of prognostic risk signature. (A) PASK protein expression level in normal breast tissue (B) and breast cancer tissue. (C) PSENEN expression in normal breast tissue (D) and breast cancer tissue. (E) RCC2 expression in normal breast tissue and (F) in breast cancer tissue.

## Section: 3. Discussion

The rapid development of scRNA-seq in cancer and the intervention of numerous analytical methods have advanced the understanding of heterogeneous tumors, including breast cancer. Recent studies have demonstrated that the tumor immune microenvironment (TIME) has critical roles in immunotherapy [18]; further investigations of TIME are required to improve immunotherapy. Increasing attention has been focused on the powerful immune effects of Regulatory T cells (Tregs) in the tumor microenvironment (TME) [19]. Several research have reported that the infiltration of Tregs into various tumor tissues promotes cancer progression and supports cancer immune evasion by limiting antitumor immunity [18]. Immune checkpoint inhibitors (ICIs) have provided an epochal shift in the treatment of cancer [20], and most immune checkpoint molecules are expressed in Tregs [21,22]. Still, the effects of ICIs on Tregs and their contributions to treatment responses remain unclear. The involvement of Tregs is a promising anticancer strategy and an effective Treg-targeted therapy. Herein, we investigated TIME in breast cancer by focusing on the mechanism of Tregs and its association with stemness and inverse correlation with ICI outcomes.

This work comprehensively analyzed the TIME in breast cancer by scRNA-seq datasets. After quality control and dimensionality reduction clustering, 25 clusters were identified and further annotated into 12 cell types, with the subgroup clustering of T cells into eight cells and selected Tregs for further study. Further mining the high heterogeneity of Tregs, we identified three distinct differentiation states of Tregs through developmental trajectory analysis. We functionally characterize signatures of differentiation and perform GSEA analysis. We found that this differentiation pattern is intrinsically linked to intra-tumoral immune and metabolic biology, and Treg differentiation-related genes (TRDGs) showed a 97% high mutation rate in different differentiation states, indicating that TDRGs play a critical role in the development and occurrence of tumors. Based on our findings, we established a prognostic risk signature consisting of seven TDRGs (MEA1, MTFP1, PASK, PSENEN, PSME2, RCC2, and SH2D2A), which upregulates JAK-STAT signaling pathway, PI3K-akt signaling, chemokine signaling pathways, IL17 signaling pathways, regulation of Regulatory T cells differentiation, production of interleukin-2 production, regulation of chronic inflammatory response, and transcriptional mis-regulation in cancer. Overall, the risk signature can effectively predict the prognosis and immunotherapy response in breast cancer patients and provide a theoretical basis for formulating individualized treatment for BC patients.

Research has shown that MEA1 plays an essential role in late spermatogenesis, fertilization, and sperm movement [23]. Our studies found that MEA1 negatively correlated with the abundance of most immune cells upregulated in tumor tissue and the results of various pathways, including gastric cancer, breast cancer, basal cell carcinoma, and downregulated translation repressor activity. MTFP1 is involved in developing and occurring oral squamous cell carcinoma; its overexpression-mediated mitochondrial fragmentation and subsequent ROS production promote cancer growth [24]. Our research found that MTFP1 exhibits low expression in tumor tissue. The results of GSVA showed that MTFP1 showed a negative correlation to most immune cells and upregulated IL-17 signaling pathways, calcium signaling pathways, breast cancer, negative regulation of epithelial cell apoptotic process, negative regulation of endothelial cell apoptotic process, and fibrinolysis, indicating that MTFP1 promotes tumor growth and progression. Recent studies have shown that PASK is a potential therapeutic target for metabolic diseases as PASK plays a vital role in energy homeostasis, metabolic regulation, and nutrient sensing [25,26]. In our research, we found PASK showed a high expression level in tumor tissue; it was found that PASK downregulated defense response and antimicrobial humoral response, exhibiting a positive regulation of peptide secretion, and showed a negative correlation with abundance of immune cells, indicating that high expression of PASK in tumor tissue was not killed by immune cells. PSENEN expression was closely correlated with the infiltration of immune cells in different cancer types [27] and significantly associated with TMB, MSI, and tumor stemness index [28], which was confirmed by recent studies. In our work, we found PSENEN showed high expression in tumor tissue and showed a negative correlation with the abundance of most immune cells when using Spearman correlation analysis, and central carbon metabolism in cancer and carbohydrate digestion and absorption was increased significantly, which showed the role of PSENEN in promoting cancer. A recently reported PSME2 Proteasome activator complex subunit 2 was positively correlated with immunomodulators, tumor mutation burden (TMB) levels, tumor-infiltrating immune cells (TIICs), and immune checkpoints in breast cancer tissue [29], and it was also associated with the invasion ability of clear cell renal cell carcinoma by inhibiting BNIP3-mediated autophagy [30].

Our study found that it upregulated the IL-17 signaling pathways and chemokines signaling pathways. Spearman correlation analysis showed that they were positively correlated with an abundance of immune cells, suggesting that they play a role in various immune and inflammation responses. RCC2, highly expressed in tumor tissue, showed positive as well as negative correlations with the abundance of most immune cells; it upregulated the tryptophan metabolism, cholesterol metabolism, and signaling pathways regulating pluripotency of stem cells, implying that RCC2 promotes cancer cell growth and differentiation. Previous research reports showed that the regulator of chromosome condensation 2 (RCC2) is essential for stabilization and transcriptional activation of Sox2 and its overexpression is associated with cell proliferation, migration, and tumor promotion in esophageal cancer [31]. Increased radio resistance and tumor progression in Glioma via activating of transcription DNMT1 [32] play a critical role in tumorigenesis in a range of cancers including lung cancer [33], melanoma [34], gastric cancer [35], ovarian cancer [36], as confirmed by accumulating evidence. Studies have shown that the T cell-specific adopter protein (TSAd) encoded by the SH2DA2 gene necessary for the activation of T cell [37,38] was required for c-Src activation, vascular endothelial growth factor receptor 2 (VEGFR2)/c-Rous sarcoma (c-Src) interaction, and promoted vascular permeability in tumor vessels [39,40]. In our work, we found that it upregulates chemokine signaling pathways, IL17 signaling pathways, regulation of T cell differentiation, production of interleukin-2 production, regulation of chronic inflammatory response, and showed a positive correlation with the abundance of immune cells, suggesting that SH2D2A might affect immune function. Understanding the function of prognostic risk signature genes and their cause of worse prognosis will help to propose a target therapeutic approach. Our stratified analysis revealed that the prognostic risk signature model achieved significantly better survival in the high-risk group compared to low-risk group after treatment with anti-PD(L)-1 and anti-CTLA-4 using bulk RNA-seq data and clinical information from 4 ICI cohorts.

In addition, the protein expression of seven prognostic risk signature model genes was verified in breast cancer using the public HPA database. PASK, PSENEN, and RCC2 were shown in breast cancer tissues compared to normal breast tissue, which were upregulated and had a favorable link with cancer progression. Through comprehensive analysis, this study demonstrates the robust link among Tregs, stemness, and ICI outcomes.

Nowadays, for different disease treatments, the reorientation of drug function is a novel strategy. Therefore, based on this strategy, we performed targeted therapeutic drug screening of prognostic risk signature genes, which modulates the poor prognosis. Our work demonstrated that Ethinyl Estradiol binds with MEA1 and downregulated MEA1 mRNA expression. Estradiol is often used in treating estrogen depletion in women and is an immunomodulator in immune and inflammatory processes [41]. Epigallocatechin gallate is a polyphenolic compound found in green tea used against neurological diseases including Alzheimer’s disease, multiple sclerosis, and Parkinson’s disease [42]; it is also effective against anticancer activities [43], tightly binds to MTFP1, and downregulates the mRNA expression of MTFP1. Cyclosporine actively binds with PASK with high energy and downregulates the mRNA expression of PASK. Cyclosporine is a first-line immunosuppressive drug to prevent rejection in transplantation and is also used against different cancer activities [44,45]. Gentamicin downregulated the mRNA expression of PSENEN. Gentamicin is an aminoglycoside antibiotic used in the treatment of infectious diseases and also greatly impacted cancer treatment [46,47]. Doxorubicin exhibited a high level of docking energy and downregulated the mRNA expression of PSME2. Doxorubicin is a chemotherapy drug that slows cancer cell growth and prevents its rapid division [48]. Ivermectin tightly binds with RCC2 and downregulates its mRNA expression. Ivermectin is a dihydro derivate of avermectin, more efficient against several parasitic diseases, including onchocerciasis and lymphatic filariasis, and prevents tumor cell growth and metastasis [49]. Finally, in screening for small molecule compounds, Dronabinol downregulated SH2D2A mRNA expression. Dronabinol is a synthetic form of THC (Δ-9-tetrahydrocannabinol), also indicated in adults for the treatment of anorexia-associated weight loss in patients with HIV/AIDS [50].

Recent studies have shown deep learning success in drug discovery [51]; combination therapies are more effective in multiple diseases and infections than single doses. To achieve therapeutic solid effects and reduce side effects, synergistic combinations can improve therapeutic efficacy and potency. For example, a study by Quinn et al. discovered that sabutoclax, combined with minocycline, an antibiotic, has previously displayed synergistic effects on the intrinsic apoptotic pathway against cancer. In pancreatic ductal adenocarcinoma, this combination showed selective toxicity and reduced tumor growth in vitro and in vivo [52]. Our work predicated synergistic effects between two drugs (Ethinyl Estradiol and Doxorubicin) in breast cancer cell lines through deep learning.

The novelty of this work lies in the robust link between Tregs, stemness, and ICI outcomes analyzed via scRNA-seq data. For further investigation, discussing prognostic risk signatures’ gene function, drug targeting, and synergistic effect is also a novel strategy in this work, but at the same time, there remain limitations. First, we performed an analysis of the scRNA-seq dataset. Secondly, the combined therapeutic drugs will be the subject of future work at the cellular and animal levels; our results are still in the analytical stage and need to be experimentally validated in future work. Furthermore, based on our prognostic risk signature, we hope to develop a shared network platform that helps in therapeutic prognosis and clinical diagnosis of breast cancer.

## Section: 4. Materials and Methods › 4.1. Data Sources Used for Analysis

The BC (Breast Cancer) scRNA-seq dataset was downloaded from the GEO Database, including GSE176078, which contains 26 samples. scRNA-seq dataset analysis was performed using the Seurat (v4.1.1) in R. To ensure high-quality data, cells were filtered based on the following quality control criteria: cells with fewer than 500 or more than 5000 detected genes (nFeature_RNA), fewer than 200 or more than 35,000 total UMI counts (nCount_RNA), and mitochondrial gene content (percent.mt) greater than or equal to 10% were excluded from downstream analysis. First, the filtered UMI count matrix was log-transformed by executing the NormalizeData() function (scale.factor = 10,000), aiming to reduce differences in total gene counts between cells. Subsequently, FindVariableFeatures() was used to identify highly variable genes (nfeatures = 2000), selecting genes with diverse expression patterns for subsequent analysis. Dimensionality reduction was performed using RunPCA(), followed by FindNeighbors() and FindClusters(resolution = 0.4) to identify cell subtypes. The first 12 principal components were used in the RunUMAP(dims = 1:12) function to visualize the cellular heterogeneity. Finally, the FindAllMarkers() function was applied to identify marker genes for each cluster, with cutoff criteria set to adjusted p-value < 0.05 and absolute log2 fold change > 0.5. SingleR package (v2.0.0) and CellMarker database were used for cell type annotation. Bulk RNA-seq data were obtained from the University of California Santa Cruz (UCSC) Xena database (https://gdc.xenahubs.net), GDC TCGA breast cancer (BRCA) with dataset ID TCGA-BRCA.htseq_counts.tsv, with a total of 1217 samples and converted the RNA-seq Counts to FPKM (fragments per kilobase of transcript per million mapped reads) and normalized by log2.

## Section: 4. Materials and Methods › 4.2. Calculation of Stemness Index (mRNAsi)

Stemness signature was identified via one-class logistic regression (OCLR) machine learning algorithm. We used the stem cell expression profiles (syn2701943) downloaded from the Progenitor Cell Biology Consortium database (https://www.synapse.org), and subsequent Spearman correlation was conducted between stemness hallmark and normalized BC expression matrix to count the stemness index (mRNAsi) of each BC patient by scaling spearman correlation coefficients to be 0–1 accordingly.

## Section: 4. Materials and Methods › 4.3. Different Differentiation States of Tregs

Pseudotime trajectories of Tregs were constructed using the Monocle (v2.22.0). The algorithm uses machine learning techniques to arrange cells into trajectories with branch points based on a specific set of genes as input to place the cells into trajectories with branch points. The results are cell populations in different differentiation states, functional enrichment analysis of cells in different states, and differential analysis performed between branches. The differentially expressed genes were defined as branch-dependent or state-specific genes. These Treg marker genes located in different branch states were defined as Treg differentiation-related genes (TDRGs). Then, the somatic mutation analysis of TDRGs was performed using the maftools (v2.10.05) in R.

## Section: 4. Materials and Methods › 4.4. Prognostic Risk Signature Construction and Validation

We used univariate Cox regression analysis on DEGs obtained from the intersection of stemness DEG and TRDGS to construct the prognostic risk model. The genes of significance were selected, and then LASSO, the least absolute shrinkage and selection operator regression analysis using the R package “glmnet,” was used to determine the meaningful genes in the uni-Cox analysis, which defines a reliable prognostic risk model. Finally, we tested the performance of the prognostic model using a nomogram and the receiver operating characteristic curve (ROC) in R to judge the predictive accuracy of the prognostic risk model. We validated the prognostic risk model’s effectiveness using the survival analysis in R.

## Section: 4. Materials and Methods › 4.5. Immune Infiltration Analysis

To evaluate the relationship between immune infiltration and the prognostic risk model, we used the single-sample Gene Set Enrichment Analysis (ssGSEA) algorithm in R to calculate the degree of immune infiltration of 28 types of immune cells in the TCGA cohort to observe the relationship between the prognostic risk model and immune infiltration.

## Section: 4. Materials and Methods › 4.6. Functional Enrichment Analysis of Prognostic Risk Model Genes

To further explore prognostic genes in the risk model, we defined the top 30% and bottom 30% of patients with prognostic gene expression as overexpression and low-expression groups in the TCGA training cohort. Then, changes in pathway activity were analyzed by gene set variation analysis (GSVA) between the high and low groups.

## Section: 4. Materials and Methods › 4.7. Predictive Model for ICI Response Datasets

We analyzed four ICI RNA-seq cohorts including Hugo 2016 SKCM (n = 28) [53], Braun 2020 RCC (n = 181) [54], Liu 2019 SKCM (n = 121) [55], and Riaz 2017 SKCM (n = 51) [56], combining them to form a large cohort (n = 381). We applied ComBat method to remove the batch effect of different ICI RNA-seq cohorts and randomly selected 149 samples for analysis. The TCGA cohort (n = 1217) was randomly split into two datasets: training dataset (n = 796) was used for the prognostic risk model establishment, and (n = 421) was used as the validation set of the prognostic risk model.

## Section: 4. Materials and Methods › 4.8. Drugs Screening and Docking

We screened seven prognostic genes for targeted drugs based on functional studies of seven prognostic genes of the risk model. We used Autodock (Linux, v4.2) for molecular docking to study small molecule compounds interacting with prognostic genes. Firstly, we used the CTD database (https://ctdbase.org/) to download the catalog of small molecules that interacted with prognostic genes [57] and then used the PubChem database accessed on 20 December 2023 (https://pubchem.ncbi.nlm.nih.gov/) to download the small molecule structures from [58]. Next, the Uniport database (https://www.uniprot.org) was used to download the biological macromolecular structures translated by the prognostic genes [59]. Finally, the small molecule with substantial interaction with the biological macromolecules is determined by the lowest binding energy and is carried out according to the standard docking process. Moreover, PyMol (v2.6, Open-Source) visualizes the results.

## Section: 4. Materials and Methods › 4.9. Anticancer Drug Combination Prediction with Deep Learning

We trained using data from 22,737 (compound, compound, cell line, synergy value) quartets processed in a previous study [60], which included 38 drugs and 39 cell lines. The training data were divided into a training set, validation set, and test set according to 6:2:2. We optimized the previously studied drug coding approach and deep learning model to predict the synergy values for drug combinations used outside the training data. Firstly, by transforming the SMILES structures of 38 drugs into ECFP molecular fingerprints by RDKIT, each drug was encoded by 2048 features with radius = 6. The features of cell lines were encoded by gene expression profiling, and after normalization and filtering, each cell line consisted of 3984 features. Then, we construct the deep learning model by TensorFlow; the model consists of 5 layers of a deep network, act_func = tf.nn.relu, dropout = 0.5, input dropout = 0.2, eta = 0.00001.

## Section: 4. Materials and Methods › 4.10. Detection of Prognostic Gene Expression

The expression levels of seven prognostic genes were compared in breast tumor tissues and normal tissues using clinical samples from the Human Protein Atlas (HPA) database (https://www.proteinatlas.org/), using the “HPAanalyze” R package to retrieve details of the seven prognostic genes from HPA, while hpaXmlGet function was used to download the corresponding XML file for the desired genes [1] and hpaXmlTissueExpr function was used to extract the entire record of every staining available for both antibodies, including clinical data, original images, and staining quantifications.

## Section: 4. Materials and Methods › 4.11. Statistical Analysis

R version 4.1.1 was used for all statistical analyses. The Cox regression analysis was applied to calculate the connection between prognostic gene expression and survival outcomes. The log-rank test was used to calibrate the difference in the survival analysis, with p < 0.05 indicating statistically significant difference, and Spearman Rank Correlation analysis was used to calculate correlations. Python version 3.7 was used for anticancer Drug Combination prediction, and TensorFlow constructed a deep learning model.

## Section: 5. Conclusions

In this work, we provide solid evidence that Tregs and cancer stemness were associated with immunotherapy resistance; we analyzed the breast cancer scRNA-seq data, explored TIME, and characterized three differentiation states and TDRGs of Tregs. We established that the prognostic risk signature includes seven genes from the intersection of TDRGs and cancer stemness-related DEGs. Our prognostic risk signature could be used to predict ICI outcomes and immunotherapeutic efficacy. Lastly, some potential therapeutic drugs and Combination drugs were screened for prognostic risk signature genes, providing a new approach for target therapy.

## Section: Acknowledgments

Thanks to the funders for supporting this work, and to the patients who provided public clinical data for this study.

## Section: Supplementary Materials

The following supporting information can be downloaded at: https://www.mdpi.com/article/10.3390/ijms26146995/s1.

## Section: Author Contributions

W.T. and S.G. designed the study; S.G. performed the data analysis, and wrote and revised the manuscript; J.P. arranged the figures; Y.C., Q.Q., Y.T., Y.S. and H.W. helped to collect the data. Project administration W.T. and X.Z. All authors have read and agreed to the published version of the manuscript.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

All data used in this work are publicly available as described in the methodology section. The web links for publicly available datasets are described in the paper and the code used in this study is available upon request by contacting the corresponding author.

## Section: Conflicts of Interest

The authors declare no conflict of interest.

## Section: Funding Statement

This study was supported by the Kunming University of Science and Technology Medical joint project (grant number KUST-PE2022005Y) and Special fund project for central government leading local science and technology development (202207AB110015).

## Section: Associated Data › Data Availability Statement

All data used in this work are publicly available as described in the methodology section. The web links for publicly available datasets are described in the paper and the code used in this study is available upon request by contacting the corresponding author.


---

# Machine Learning-Based QSAR Screening of Colombian Medicinal Flora for Potential Antiviral Compounds Against Dengue Virus: An In Silico Drug Discovery Approach

- **Authors:** Sergio Andrés Montenegro-Herrera, Anibal Sosa, Isabella Echeverri-Jiménez, Rafael Santiago Castaño-Valencia, Alejandra María Jerez-Valderrama
- **Issuer:** Pharmaceuticals (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2025-12-18
- **Language:** en
- **DOI:** 10.3390/ph18121906
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41471395/
- **Licence:** CC-BY

## Section: Abstract

Background/Objectives: Colombia harbors exceptional plant diversity, comprising over 31,000 formally identified species, of which approximately 6000 are classified as useful plants. Among these, 2567 species possess documented food and medicinal applications, with several traditionally utilized for managing febrile illnesses. Despite the global burden of dengue virus infection affecting millions annually, no specific antiviral therapy has been established. This study aimed to identify potential anti-dengue compounds from Colombian medicinal flora through machine learning-based quantitative structure–activity relationship (QSAR) modeling. Methods: An optimized XGBoost algorithm was developed through Bayesian hyperparameter optimization (Optuna, 50 trials) and trained on 2034 ChEMBL-derived activity records with experimentally validated anti-dengue activity (IC50/EC50). The model incorporated 887 molecular features comprising 43 physicochemical descriptors and 844 ECFP4 fingerprint bits selected via variance-based filtering. IC50 and EC50 endpoints were modeled independently based on their pharmacological distinction and negligible correlation (r = −0.04, p = 0.77). Through a systematic literature review, 2567 Colombian plant species from the Humboldt Institute’s official checklist were evaluated (2501 after removing duplicates and infraspecific taxa), identifying 358 with documented antiviral properties. Phytochemical analysis of 184 characterized species yielded 3267 unique compounds for virtual screening. A dual-endpoint classification strategy categorized compounds into nine activity classes based on combined potency thresholds (Low: pActivity ≤ 5.0, Medium: 5.0 < pActivity ≤ 6.0, High: pActivity > 6.0). Results: The optimized model achieved robust performance (Matthews correlation coefficient: 0.583; ROC-AUC: 0.896), validated through hold-out testing (MCC: 0.576) and Y-randomization (p < 0.01). Virtual screening identified 276 compounds (8.4%) with high predicted potency for both endpoints (“High-High”). Structural novelty analysis revealed that all 276 compounds exhibited Tanimoto similarity < 0.5 to the training set (median: 0.214), representing 145 unique Murcko scaffolds of which 144 (99.3%) were absent from the training data. Application of drug-likeness filtering (QED ≥ 0.5) and applicability domain assessment identified 15 priority candidates. In silico ADMET profiling revealed favorable pharmaceutical properties, with Incartine (pIC50: 6.84, pEC50: 6.13, QED: 0.83), Bilobalide (pIC50: 6.78, pEC50: 6.07, QED: 0.56), and Indican (pIC50: 6.73, pEC50: 6.11, QED: 0.51) exhibiting the highest predicted potencies. Conclusions: This systematic computational screening of Colombian medicinal flora demonstrates the untapped potential of regional biodiversity for anti-dengue drug discovery. The identified candidates, representing structurally novel chemotypes, are prioritized for experimental validation.

## Section: 1. Introduction

Dengue virus (DENV) infection represents one of the most rapidly expanding mosquito-borne diseases globally, with an estimated 390 million infections occurring annually across tropical and subtropical regions [1,2]. Colombia experiences hyperendemic dengue transmission with all four virus serotypes (DENV-1 to DENV-4) co-circulating and generating epidemics every 3–4 years [3]. Year-round transmission occurs due to the country’s equatorial climate, with the 2021 incidence reaching 172.9 cases per 100,000 at-risk population, though some regions reported rates exceeding 400 per 100,000 [4,5]. Approximately half of all cases (51.6%) present with warning signs, and while 2.1% develop severe dengue nationally, this proportion reaches 10% in high-burden regions. Hospital capacity remains strained, with 83% of warning sign cases and 95% of severe cases requiring admission [4]. Documented underreporting suggests these figures underestimate the true disease burden [6]. Despite the recent approval of dengue vaccines, their limited effectiveness and usage restrictions underscore the urgent need for specific antiviral therapeutics [2,7]. Currently, clinical management remains limited to symptomatic supportive care, as no targeted antiviral therapy has been approved for dengue treatment [8,9].

Colombia harbors exceptional plant diversity, with over 31,000 formally identified species, positioning it among the world’s most biodiverse countries. Of these, approximately 6000 are classified as useful plants, including 2567 species with documented food and medicinal applications [10,11]. This botanical wealth has been utilized for centuries by indigenous and rural communities to treat various ailments, with several species traditionally employed in managing febrile illnesses. Traditional medicine employs numerous plant species such as balsamina (Momordica charantia), matarratón (Gliricidia sepium), limoncillo (Cymbopogon citratus), or salvia (Lippia alba) for managing dengue-associated symptoms [12,13]. However, despite this extensive ethnobotanical knowledge, the vast majority of Colombian flora has not undergone systematic scientific evaluation for bioactive compound identification. This gap between traditional knowledge and scientific validation represents a unique opportunity for discovering novel therapeutic agents.

The integration of computational approaches, particularly Quantitative Structure–Activity Relationship (QSAR) modeling combined with machine learning algorithms, has revolutionized drug discovery by enabling rapid biological activity prediction based on chemical structure [14,15]. Recent advances in QSAR methodologies have demonstrated success in identifying flavivirus inhibitors, with models achieving high predictive accuracy for anti-dengue activity subsequently validated through experimental assays [16,17]. Recent applications of integrated computational workflows combining QSAR, molecular docking, and dynamics simulations have further demonstrated the value of multi-method approaches in enzyme inhibitor discovery [18], establishing robust frameworks for virtual screening campaigns. The XGBoost (eXtreme Gradient Boosting) algorithm, developed by Chen and Guestrin [19], has emerged as a leading gradient boosting method particularly suited for handling complex chemical structured datasets with high-dimensional feature spaces and class imbalance in chemoinformatics applications [19,20]. These computational tools offer significant advantages in exploring vast chemical spaces while reducing time and costs associated with traditional drug discovery pipelines [21].

A critical advancement in QSAR-based drug discovery is the implementation of dual-endpoint classification strategies that simultaneously evaluate multiple pharmacological properties. Traditional QSAR models typically predict a single endpoint (e.g., IC50 or EC50 in isolation), potentially overlooking compounds that demonstrate balanced profiles across multiple assay types. For antiviral discovery, this limitation is particularly relevant as biochemical target inhibition (IC50) does not always translate to cellular antiviral efficacy (EC50) due to factors including membrane permeability, intracellular distribution, metabolic stability, and cytotoxicity. Studies have shown that IC50 and EC50 values for anti-dengue compounds exhibit poor correlation (r < 0.1), indicating that these metrics capture distinct pharmacological dimensions [22]. Consequently, integrated approaches that classify compounds based on combined endpoint activities enable more robust prioritization of candidates with genuine therapeutic potential, reducing the attrition rate in subsequent experimental validation phases.

The convergence of ethnopharmacological knowledge with modern computational technologies presents an innovative strategy for pharmaceutical bioprospection. Studies have demonstrated that compounds derived from traditionally used medicinal plants exhibit significantly higher probability of relevant biological activity, with natural products showing increased success rates through clinical trials compared to synthetic compounds [23,24]. Notable examples include artemisinin from Artemisia annua for malaria treatment and vinca alkaloids for cancer therapy, both discovered through ethnopharmacology-guided research [25,26]. In the Colombian context, this integrated and novel approach not only valorizes national biodiversity but also promotes sustainable development models benefiting local communities who safeguard this ancestral knowledge [27].

Despite growing interest in natural products for antiviral discovery, no systematic computational screening of Colombian medicinal flora for anti-dengue compounds has been conducted. This study aimed to perform the first comprehensive virtual screening of phytochemicals from Colombian medicinal plants to identify potential dengue antivirals using machine learning-based QSAR models integrated with comprehensive structure–activity relationship (SAR) analysis. We trained an optimized XGBoost model on 2034 ChEMBL activity records with validated anti-dengue activity (IC50/EC50), achieving robust predictive performance (MCC = 0.583, ROC-AUC = 0.896) after Bayesian hyperparameter optimization. Through a systematic literature review, we identified 358 Colombian plant species with documented antiviral activity, from which 184 species yielded 3267 unique compounds for virtual screening.

Our analysis employed a dual-endpoint classification framework that simultaneously evaluated IC50 and EC50 predicted activities, categorizing compounds into nine activity classes based on combined potency thresholds. This approach identified 276 compounds (8.4%) exhibiting high predicted potency (pActivity > 6) for both endpoints, designated as “High-High” candidates. Structural novelty analysis revealed that all 276 compounds exhibited Tanimoto similarity < 0.5 to the training set, representing 145 unique Murcko scaffolds of which 144 (99.3%) were absent from training data—confirming these as structurally novel chemotypes. Application of drug-likeness filtering (QED ≥ 0.5) and applicability domain assessment identified 15 priority candidates for experimental validation.

The prioritized candidates represent diverse chemical scaffolds including alkaloids, terpenoids, and glycosides. Incartine (pIC50: 6.84, pEC50: 6.13, QED: 0.83) from Hippeastrum puniceum, Bilobalide (pIC50: 6.78, pEC50: 6.07, QED: 0.56) from Ginkgo biloba, and Indican (pIC50: 6.73, pEC50: 6.11, QED: 0.51) from Indigofera suffruticosa exhibited the highest predicted potencies. These findings establish Colombian flora as a rich source of potential anti-dengue therapeutics and provide a methodological framework applicable to other neglected tropical diseases.

## Section: 2. Results › 2.1. QSAR Model Development and Validation › 2.1.1. Dataset Characteristics

The curated ChEMBL dataset comprised 2034 activity records corresponding to 1981 unique molecules with experimentally validated anti-dengue activity. Among these, 53 molecules (2.7%) had both IC50 and EC50 measurements, enabling a direct comparison between assay types. The activity distribution revealed significant class imbalance across potency categories: Low potency (pActivity ≤ 5): 1332 compounds (65.49%), Medium potency (5 < pActivity ≤ 6): 475 compounds (23.35%), and High potency (pActivity > 6): 227 compounds (11.16%) Figure 1a. The dataset contained IC50 measurements for 1339 compounds (65.83%) and EC50 measurements for 695 compounds (34.17%), with significantly different distributions (Mann–Whitney U test, p < 0.0001), necessitating assay type inclusion as a critical feature Figure 1b.

Critical analysis of the 53 molecules with both assay types revealed no correlation between IC50 and EC50 values (r = −0.0415, p = 0.77), with a mean difference of −0.14 ± 1.11 log units Figure 1f. This finding suggests that biochemical inhibition (IC50) and cellular efficacy (EC50) represent distinct pharmacological properties that cannot be reliably extrapolated from one another.

This negligible correlation is consistent with the established pharmacological principle that cellular efficacy (EC50) depends not only on target binding affinity (IC50) but also on intracellular bioavailability, which is influenced by membrane permeability, metabolic stability, efflux transporter activity, and cytotoxicity [28]. This biological distinction justifies independent modeling of both endpoints rather than treating them as interchangeable measures of antiviral potency.

## Section: 2. Results › 2.1. QSAR Model Development and Validation › 2.1.2. Chemical Space Analysis

Structural diversity analysis identified 1131 unique Murcko scaffolds among the training compounds Figure 2B. Key findings included: Scaffold distribution: 828 scaffolds (73.2%) were singletons, indicating substantial chemical diversity; Most prevalent scaffold: An indole-based structure (O=C(c1c[nH]c2ccccc12)C(Nc1ccccc1)c1ccccc1) appeared in 41 compounds with high average pActivity (6.92 ± 0.91); Chemical clustering: Hierarchical clustering using ECFP4 fingerprints revealed 522 distinct chemical clusters, with 27 clusters containing more than 10 compounds.

## Section: 2. Results › 2.1. QSAR Model Development and Validation › 2.1.3. Model Optimization and Performance

Systematic evaluation of multiple machine learning algorithms with various molecular representations yielded XGBoost with the combined Descriptors+ECFP4 representation as the optimal configuration. Bayesian hyperparameter optimization using Optuna (50 trials, TPE sampler) [29] was performed to maximize Matthews Correlation Coefficient through 5-fold stratified cross-validation Table 1.

The optimized XGBoost model incorporated 887 features (43 molecular descriptors and 844 ECFP4 fingerprint bits) filtered by variance threshold (>0.01). Optimal hyperparameters achieved:-n_estimators: 453-max_depth: 15-learning_rate: 0.010-subsample: 0.828-colsample_bytree: 0.914-gamma: 1.534-reg_alpha: 0.016-reg_lambda: 4.734

Final model performance (5-fold stratified cross-validation):-Matthews Correlation Coefficient (MCC): 0.583-Balanced Accuracy: 68.3%-ROC-AUC: 0.896-F1-macro: 0.703-Geometric Mean: 0.665

Hyperparameter importance analysis revealed regularization parameters (reg_alpha: 38.6%, gamma: 33.3%) as most critical for model performance, indicating the importance of controlling overfitting in this high-dimensional feature space.

Feature importance analysis revealed assay type (IC50/EC50) as the most critical feature (importance: 0.0298), followed by PEOE_VSA1 (0.0265), LogP_calculado (0.0174), and molecular shape descriptors (MolMR: 0.0157). These patterns align with known structure–activity relationships for antiviral compounds, where balanced lipophilicity and specific electrostatic distributions facilitate cellular entry and target binding.

While ensemble modeling achieved marginally higher performance (MCC = 0.584), the optimized XGBoost model (MCC = 0.583) was selected as the final model. This decision followed the principle of parsimony, as the 0.1% improvement did not justify the 3-fold increase in computational complexity and reduced interpretability associated with maintaining three separate models. The optimization process improved the baseline XGBoost performance by 1.9%, demonstrating the value of systematic hyperparameter tuning in QSAR modeling.

## Section: 2. Results › 2.2. Virtual Screening of Colombian Medicinal Flora › 2.2.1. Antiviral Plant Identificación

A systematic literature review of the 2501 species remaining after taxonomic curation (see Section 4.3) revealed that 358 species (14.3%) possessed documented antiviral activity, distributed across 107 botanical families. The families with the highest representation of antiviral species were Asteraceae (36 species, 10.1%), Fabaceae (28 species, 7.8%), Lamiaceae (21 species, 5.9%), Solanaceae (12 species, 3.4%), and Malvaceae (11 species, 3.1%). Notably, 174 species (48.6%) lacked phytochemical characterization, highlighting a significant knowledge gap in Colombian biodiversity research. From the 184 species with available chemical data, we compiled a total of 3267 unique compounds.

## Section: 2. Results › 2.2. Virtual Screening of Colombian Medicinal Flora › 2.2.2. Virtual Screening

Virtual screening of 3267 Colombian phytochemicals using the optimized QSAR model identified 276 compounds (8.4%) exhibiting high predicted potency (pActivity > 6.0) for both IC50 and EC50 endpoints, classified as “High-High” in our dual-endpoint framework (Figure 3A). This dual-activity profile is particularly valuable as it indicates compounds likely to demonstrate both biochemical target inhibition (IC50) and cellular antiviral efficacy (EC50), addressing a critical challenge in antiviral drug discovery where these properties often fail to correlate. Comprehensive structure–activity relationship (SAR) analysis of these 276 high-potency compounds revealed remarkable structural diversity.

Structural novelty assessment revealed that all 276 High-High compounds (100%) exhibited Tanimoto similarity < 0.5 to the ChEMBL training dataset (median: 0.214), classifying them as structurally novel chemotypes. Murcko scaffold analysis identified 145 unique scaffolds among these compounds, of which 144 (99.3%) had zero representation in the training dataset, with 101 scaffolds (69.7%) appearing as singletons. This unprecedented scaffold novelty confirms that Colombian biodiversity harbors unique structural motifs not previously explored for anti-dengue activity. Chemical space analysis via principal component analysis (PCA) [30] of ECFP4 fingerprints revealed clear segregation between the novel High-High compounds and the broader compound collection (Figure 3B). The first two principal components captured 72.1% of structural variance (PC1: 51.3%, PC2: 20.8%), with high-potency compounds occupying distinct regions of chemical space.

This spatial segregation validates the structural distinctiveness of novel candidates and suggests they may access alternative binding sites or mechanisms compared to known antivirals. Drug-likeness assessment of the 276 High-High compounds revealed a critical pharmaceutical development challenge: 256 compounds (92.8%) exhibited low QED scores (<0.5), primarily due to violations in molecular weight, hydrogen bond acceptor count, and topological polar surface area (Figure 3C). Only 20 compounds (7.2%) achieved the QED ≥ 0.5 threshold associated with favorable oral bioavailability and pharmaceutical properties.

This low proportion of drug-like high-potency compounds underscores the importance of multi-criteria optimization in natural product drug discovery and highlights the need for structural modifications or prodrug strategies to improve pharmaceutical properties while maintaining antiviral activity. To prioritize candidates for experimental validation, we focused on the 20 compounds combining high predicted potency (pActivity > 6.0 for both endpoints) with favorable drug-likeness (QED ≥ 0.5).

Among these, 15 compounds demonstrated exceptional profiles with QED scores ranging from 0.51 to 0.83, with the top 12 showing strict dual high potency (pActivity > 6.0 for both endpoints) and compounds #13–15 exhibiting borderline IC50 values (5.95–6.02) but maintaining favorable drug-likeness.

This structural diversity suggests multiple potential mechanisms of antiviral action and highlights the chemical richness of Colombian medicinal flora. Descriptor–activity correlation analysis identified molecular properties significantly associated with antiviral potency (Figure 3D). For IC50 activity, modest correlations were observed with aromatic rings (ρ = 0.06), QED (ρ = 0.06) and aliphatic rings (ρ = −0.05), while molecular weight, LogP, and hydrogen bond features showed negligible correlations (|ρ| < 0.04). EC50 activity demonstrated stronger associations, particularly with QED (ρ = 0.14), TPSA (ρ = −0.15), aliphatic rings (ρ = 0.07), aromatic rings (ρ = −0.03), and hydrogen bond donors (ρ = −0.12).

The differential correlation patterns between IC50 and EC50 endpoints reinforce the biological distinction between biochemical target inhibition and cellular antiviral efficacy, validating our dual-endpoint classification strategy. The negative correlation between TPSA and EC50 activity (ρ = −0.15) suggests that moderate polarity may be optimal for cellular penetration, while excessive polar surface area could impair membrane permeability and reduce cellular efficacy despite potential target binding affinity. Conversely, the positive QED-EC50 association (ρ = 0.14) indicates that compounds naturally possessing drug-like features are more likely to demonstrate cellular antiviral efficacy, supporting prioritization of the 20 high-QED candidates for immediate experimental validation. These correlations provide actionable insights for lead optimization: strategic reduction of the polar surface area through modifications such as methylation of hydroxyl groups or removal of sugar moieties could enhance cellular penetration while maintaining antiviral activity.

Table 2: Compounds are ranked by predicted IC50 activity (pIC50). The top 12 candidates exhibit both dual high potency (pActivity > 6.0 for both IC50 and EC50 endpoints) and favorable drug-likeness (QED ≥ 0.5), while compounds #13–15 show high potency for at least one endpoint with borderline activity on the other (5.95 ≤ pIC50 < 6.0) but maintain QED ≥ 0.5. Chemical classes were assigned based on core structural scaffolds. Novelty categories were determined using maximum Tanimoto similarity to the ChEMBL training set compounds (Novel: Tanimoto < 0.5; Training-like: Tanimoto ≥ 0.5). Notably, Lycorine (#13) and Pseudolycorine (#15) exhibit perfect structural similarity (Tanimoto = 1.00) to training set compounds, confirming their presence in ChEMBL with experimentally validated anti-dengue activity and providing internal validation of model predictions. Molecular descriptors include MW (molecular weight), LogP (octanol-water partition coefficient), HBA (hydrogen bond acceptors), HBD (hydrogen bond donors), and TPSA (topological polar surface area). Plant sources represent the primary botanical origin reported in phytochemical databases. pIC50 and pEC50 values represent predicted activities from the optimized XGBoost QSAR model. Applicability domain assessment using dual criteria (leverage threshold h* = 1.308; Tanimoto similarity > 0.3) revealed that 2/15 compounds (Lycorine, Pseudolycorine) fall within both AD criteria, while 5/15 satisfy the Tanimoto similarity criterion.

Applicability domain assessment of the 15 prioritized candidates employed dual criteria following OECD guidelines. Leverage-based analysis (h* = 3p/n = 1.308 with 887 features) identified 2/15 compounds (13.3%) within the AD: Lycorine and Pseudolycorine, both present in the ChEMBL training dataset with experimentally confirmed anti-dengue activity. Tanimoto similarity analysis (threshold > 0.3) identified 5/15 compounds (33.3%) within acceptable structural coverage:

Lycorine (Tc = 1.000), Pseudolycorine (Tc = 1.000), Hippeastrine (Tc = 0.515), Indican (Tc = 0.345), and Incartine (Tc = 0.328). The remaining 10 compounds represent novel chemotypes (Tc < 0.3) warranting experimental confirmation.

## Section: 2. Results › 2.3. Detailed Characterization of Top Priority Candidates

Alkaloid Candidates: Incartine (#1, from Hippeastrum puniceum) emerged as the top candidate with the highest QED score (0.83) among all prioritized compounds, combining exceptional predicted dual-endpoint activity (pIC50: 6.84, pEC50: 6.13) with optimal pharmaceutical properties. This indole alkaloid exhibits structural features associated with broad-spectrum bioactivity, including an aromatic core, moderate molecular weight (MW = 312 Da), and balanced lipophilicity (LogP = 2.1). Notably, Incartine shares no structural similarity with known anti-dengue agents in the training set (Tanimoto < 0.3), suggesting a potentially novel mechanism of action.

Indican (#3, pIC50: 6.73, pEC50: 6.11, QED: 0.51), isolated from Indigofera suffruticosa, represents another promising alkaloid candidate. As a glucoside derivative, Indican demonstrates a favorable balance between hydrophilicity (necessary for aqueous solubility) and lipophilicity (required for membrane permeability), reflected in its moderate QED score. The presence of this compound in a plant traditionally used for treating inflammatory conditions in Colombia provides ethnopharmacological validation of its bioactive potential.

Terpenoid Candidates: Bilobalide (#2, pIC50: 6.78, pEC50: 6.07, QED: 0.56), a sesquiterpene trilactone from Ginkgo biloba, represents a unique chemical class among our candidates. Despite its complex polycyclic structure with multiple lactone groups, Bilobalide achieves moderate drug-likeness through a compact molecular architecture (MW = 326 Da) and strategic distribution of polar functional groups. Ginkgo extracts have demonstrated neuroprotective and anti-inflammatory properties in clinical settings, suggesting Bilobalide may offer dual benefits of antiviral activity and symptom management in dengue infection.

Epicolactone (#4, pIC50: 6.71, pEC50: 6.94, QED: 0.51) and Byzantionoside B (#5, pIC50: 6.65, pEC50: 6.50, QED: 0.54) represent additional terpenoid scaffolds with balanced predicted activities across both endpoints. The structural complexity of these natural products, while challenging from a synthesis perspective, may enable multiple interaction points with viral targets, potentially contributing to their predicted high potency.

Validation Through Training Set Comparison: Importantly, two compounds predicted among our top candidates—Lycorine and Pseudolycorine—exhibited perfect structural similarity (Tanimoto = 1.0) to the training set compounds, confirming their presence in the ChEMBL anti-dengue database with experimentally validated activity [31]. Lycorine (Figure 4, right panel #6) demonstrated exceptional experimental potency (pActivity = 9.62, IC50 = 0.24 nM) in the training set, providing strong validation of our model’s predictive accuracy. The fact that our QSAR model successfully identified these known active compounds among thousands of screening candidates demonstrates robust model calibration and increases confidence in predictions for structurally novel candidates.

The training set references (Figure 5, right panels) include several Amaryllidaceae alkaloids with nanomolar potencies, such as Narciclasine (ChEMBL464432, #1: pActivity 10.82, IC50 = 0.01 nM) and Pancratistatin (#4: pActivity 10.20, IC50 = 0.06 nM) [31]. The structural similarity between these validated compounds and several of our novel candidates (particularly Incartine) suggests that the Amaryllidaceae family represents a rich source of anti-dengue scaffolds worthy of systematic investigation. However, it is noteworthy that many high-potency training compounds exhibited low QED scores (e.g., ChEMBL5188858, #9: QED = 0.22), emphasizing the challenge of combining antiviral potency with optimal pharmaceutical properties—a challenge that our 12 prioritized candidates successfully address.

Structural Diversity and Mechanistic Implications: The chemical diversity among our top 12 candidates—ranging from simple indole alkaloids (Incartine) to complex sesquiterpene lactones (Bilobalide) and glycosylated compounds (Indican, Byzantionoside B)—suggests that these molecules may target different viral proteins or employ distinct mechanisms of action. This structural heterogeneity is advantageous for two reasons: first, it increases the likelihood that at least some candidates will demonstrate experimental activity; second, it provides a diverse starting point for structure-based optimization and combination therapy development. The identification of multiple chemical classes with predicted anti-dengue activity suggests that dengue virus may be vulnerable to intervention at multiple points in its replication cycle, offering opportunities for rational polypharmacology approaches.

## Section: 2. Results › 2.3. Detailed Characterization of Top Priority Candidates › 2.3.1. Structure–Activity Relationships

Chemical space analysis of 3267 QSAR-screened Colombian phytochemicals revealed a structurally diverse collection with distinct activity patterns across the molecular landscape. UMAP projection [32] of Morgan fingerprints identified three major chemical clusters with clear segregation of bioactivity, where compounds with higher predicted pActivity values (>6.0) formed discrete regions within the two-dimensional space, suggesting that structural similarity correlates with antiviral potency. The dataset exhibited substantial chemical diversity, comprising 767 unique Murcko scaffolds (23.5% scaffold-to-compound ratio), with the most prevalent scaffold appearing in 375 compounds (11.5%). Scaffold distribution analysis across potency categories uncovered significant structure–activity trends: notably, Scaffold 2 showed strong enrichment in the low potency category (88.3% of its 341 occurrences), while Scaffolds 4, 5, and 7 demonstrated preferential distribution in the moderate potency range (5.0 < pActivity ≤ 6.0), identifying them as promising templates for lead optimization. The presence of outlier compounds in the UMAP projection, positioned at the periphery of main clusters, suggests the existence of unique chemotypes that may operate through alternative mechanisms or binding modes. This comprehensive mapping of chemical space provides a strategic framework for prioritizing compounds for experimental validation and guides structure-based optimization efforts toward developing effective antiviral agents against dengue virus.

## Section: 2. Results › 2.3. Detailed Characterization of Top Priority Candidates › 2.3.2. Reliability of Predictions

Applicability domain analysis [33] employed dual criteria following OECD guidelines for QSAR validation [34]. Leverage-based assessment using the threshold h* = 3p/n = 1.308 (with p = 887 features and n = 2034 training compounds) revealed that 2/15 prioritized compounds (13.3%) fell within the leverage-based AD. Tanimoto similarity assessment (threshold > 0.3) identified 5/15 compounds (33.3%) within acceptable structural coverage. The observation that most prioritized compounds fell outside the leverage-based AD is scientifically expected for natural products from underexplored chemical space and does not invalidate the predictions, as these compounds represent the novel chemotypes that constitute the primary objective of this bioprospecting study.

Among the 15 prioritized compounds, five satisfied the Tanimoto similarity AD criterion (Tc > 0.3): Lycorine (Tc = 1.000), Pseudolycorine (Tc = 1.000), Hippeastrine (Tc = 0.515), Indican (Tc = 0.345), and Incartine (Tc = 0.328). Lycorine and Pseudolycorine were present in the ChEMBL training set with experimentally confirmed anti-dengue activity, providing internal validation of model performance. The remaining 10 compounds (Tc < 0.3) represent structurally novel chemotypes from underexplored chemical space. Based on AD assessment, we recommend tiered experimental validation: Tier 1 (highest confidence): Lycorine, Pseudolycorine—within both AD criteria; Tier 2 (high confidence): Hippeastrine, Indican, Incartine—within Tanimoto AD; Tier 3 (exploratory): remaining compounds—novel chemotypes requiring experimental confirmation.

Notably, compounds with lower similarity scores (e.g., Bilobalide: Tc = 0.165, Epicolactone: Tc = 0.200) fell outside both AD criteria, reflecting their structural novelty relative to the training set. While predictions for these compounds carry greater uncertainty, their identification as high-potency candidates aligns with the study’s objective of discovering novel anti-dengue scaffolds from Colombian biodiversity. The structural distinctiveness of these compounds suggest that they may operate through mechanisms different from known anti-dengue agents, warranting experimental investigation.

## Section: 2. Results › 2.3. Detailed Characterization of Top Priority Candidates › 2.3.3. In Silico ADMET Profiling of Prioritized Candidates

Distribution assessment revealed that 14 out of 15 candidates (93%) exhibited no blood–brain barrier (BBB) penetration, a particularly favorable safety feature for dengue therapeutics. BBB exclusion minimizes the risk of CNS-related adverse effects, which is especially relevant given dengue’s potential neurological complications including encephalitis and Guillain-Barré syndrome [35]. The single BBB-permeable compound (Dihydrofumariline) warrants additional neurotoxicity screening prior to in vitro validation. P-glycoprotein (P-gp) substrate assessment identified 73% of candidates as potential P-gp substrates, suggesting possible efflux-mediated reduction in intracellular concentrations. While P-gp substrate status represents a potential liability for cellular accumulation, this property does not preclude therapeutic development, as numerous marketed antivirals (e.g., ritonavir, indinavir) successfully navigate P-gp-mediated efflux through appropriate dosing strategies or co-administration with P-gp inhibitors [36].

Metabolic stability assessment through cytochrome P450 (CYP) inhibition profiling revealed generally favorable profiles. The majority of candidates showed minimal CYP inhibition: 87% for CYP1A2, 93% for CYP2C19, 93% for CYP2C9, and 93% for CYP3A4. However, 33% of compounds (5/15) inhibited CYP2D6, with this liability concentrated among Amaryllidaceae alkaloids (Incartine, Lycorine, Hippeastrine, Pseudolycorine, 3-Acetylnerbowdine). This structural class-dependent pattern suggests that CYP2D6 inhibition may be an intrinsic feature of the Amaryllidaceae alkaloid scaffold, potentially necessitating structural optimization or requiring careful management of drug–drug interactions in clinical settings. CYP2D6 mediates the metabolism of approximately 25% of marketed drugs, and its inhibition could affect co-administered medications commonly used in dengue management, including analgesics and antiemetics [37].

Toxicity predictions revealed heterogeneous safety profiles requiring nuanced interpretation. While all 15 compounds tested negative for critical hERG I cardiotoxicity—a key regulatory safety concern and frequent cause of drug development attrition—80% [38] (12/15) flagged positive for AMES mutagenicity and 60% (9/15) for hERG II inhibition. The high AMES positivity rate warrants particular attention, as mutagenicity represents a potential deal-breaker in drug development. However, computational AMES predictions are known to suffer from high false-positive rates [39], particularly for natural products containing polyphenolic, aromatic amine, or nitro functional groups that trigger alerts without genuine mutagenic liability. Experimental validation through standard bacterial reverse mutation assays (Ames test) is therefore essential before dismissing these candidates. The 60% hERG II positivity rate, while concerning, is less critical than hERG I, as hERG II inhibition shows weaker correlation with clinically relevant QT prolongation [40]. Hepatotoxicity predictions were negative for 67% of candidates (10/15), with positive flags again concentrated among alkaloid scaffolds. The oral rat acute toxicity (LD50) values ranged from 2.094 to 2.779 log mol/kg (mean: 2.397 ± 0.231), suggesting acceptable therapeutic windows for most candidates.

Drug-likeness assessment revealed universal compliance with pharmaceutical development criteria. All 15 candidates satisfied Lipinski’s Rule of Five, with zero violations for any compound, and exhibited no pan-assay interference compound (PAINS) alerts, confirming absence of structural features associated with promiscuous or artifactual bioactivity. Synthetic accessibility scores averaged 5.12 ± 0.76 on a 1–10 scale (lower = easier synthesis), indicating moderate synthetic complexity that should not pose insurmountable challenges for medicinal chemistry optimization or scale-up for preclinical studies [41,42].

Integrated ADMET scoring, calculated as the mean favorability across all 17 properties (scaled 0–1 where 1.0 represents optimal pharmaceutical properties), identified Trifolirhizin (0.825), Digoxigenin (0.815), and Epicolactone (0.812) as candidates combining high predicted antiviral potency with superior pharmaceutical profiles. Statistical clustering analysis revealed three distinct ADMET profile groups: (1) terpenoid glycosides and structurally related compounds (n = 9, mean score = 0.785) exhibiting favorable safety and metabolic profiles; (2) Amaryllidaceae alkaloids (n = 5, mean score = 0.709) showing elevated toxicity flags and CYP2D6 inhibition; and (3) Dihydrofumariline as a high-risk outlier (score = 0.629) with multiple unfavorable properties including BBB penetration and pan-CYP inhibition.

Critically, comprehensive ADMET analysis revealed a clear trade-off between predicted antiviral potency and pharmaceutical favorability. Incartine, ranking first by predicted pIC50 (6.84), exhibited only moderate ADMET score (0.698), placing it 11th out of 15 candidates in pharmaceutical profile due to AMES mutagenicity, hepatotoxicity, CYP2D6 inhibition, and hERG II inhibition flags. Conversely, Trifolirhizin demonstrated the highest ADMET score (0.825) while maintaining robust predicted dual-endpoint activity (pIC50: 6.63, pEC50: 6.50). This dissociation between computational potency predictions and pharmaceutical viability validates our multi-criteria prioritization strategy and underscores that QSAR-predicted activity alone is insufficient for candidate selection. The finding that botanical family and chemical class strongly influence ADMET profiles—with terpenoids generally superior to alkaloids in safety predictions—provides actionable guidance for future bioprospecting efforts and suggests that systematic screening of terpenoid-rich Colombian plant families may yield candidates with inherently more favorable pharmaceutical properties Figure 6.

## Section: 3. Discussion

This study represents the first systematic computational screening of Colombian medicinal flora for anti-dengue compounds, successfully integrating machine learning-based QSAR modeling with ethnopharmacological knowledge. The identification of 15 high-potency candidates from 3267 phytochemicals demonstrates the untapped potential of Colombian biodiversity for drug discovery while highlighting critical gaps in our understanding of this megadiverse region’s chemical wealth.

The optimized XGBoost model achieved an MCC of 0.583 and ROC-AUC of 0.896, representing robust performance considering the severe class imbalance (65.5% low, 23.4% medium, 11.2% high potency) and chemical diversity of the training dataset. When applied to 3267 Colombian phytochemicals, the model successfully identified 276 compounds (8.4%) with dual high potency (High-High classification), demonstrating effective prioritization despite the challenges of extrapolating from synthetic-enriched training data to structurally diverse natural products. The improvement from baseline (MCC = 0.572) through Bayesian optimization, though modest (1.9%), demonstrates the value of systematic hyperparameter tuning in QSAR applications. The model’s ROC-AUC of 0.896 indicates excellent discrimination capability between active and inactive compounds, suggesting reliable prioritization of candidates for experimental validation.

The optimization process revealed important insights into model behavior. The dominance of regularization parameters (reg_alpha: 38.6%, gamma: 33.3%) in hyperparameter importance analysis indicates that controlling model complexity was crucial for preventing overfitting in this high-dimensional feature space. The relatively low importance of n_estimators (1.3%) suggests that model depth and regularization were more critical than the number of trees, a finding that could inform future QSAR modeling efforts with similar datasets. Despite the ensemble’s marginally higher MCC (0.584), the single XGBoost model was selected for its parsimony, given that the 0.1% gain would require tripling the training time and model management complexity without offering tangible benefits for interpretability or deployment.

The prominence of assay type (IC50/EC50) as the most important feature underscores critical consideration in anti-dengue drug discovery. IC50 measurements typically reflect direct viral inhibition in cell-free or enzyme-based assays, while EC50 values incorporate cellular uptake, metabolism, and cytotoxicity factors. This distinction is particularly relevant for natural products, which often exhibit different behavior in cellular versus biochemical assays due to their complex structures and potential for metabolic transformation. The negligible correlation observed between IC50 and EC50 values in our dataset (r = −0.0415, n = 53) aligns with the established pharmacological principle that cellular efficacy depends not only on target binding affinity but also on intracellular bioavailability, influenced by membrane permeability, metabolic stability, and efflux transporter activity [28]. While the limited sample size of paired measurements constrains statistical power, this finding is consistent with pharmacological theory predicting that these endpoints capture fundamentally different aspects of drug action. Our dual-endpoint classification strategy, requiring high predicted potency for both IC50 and EC50 (“High-High”), therefore represents a conservative approach that reduces false-positive prioritization by demanding favorable predictions across both biochemical and cellular dimensions.

The successful application of ECFP4 fingerprints, which captured 844 of the 887 selected features, aligns with their established utility in natural product QSAR studies [43,44], effectively encoding local structural environments that are particularly relevant for natural products’ biological activity.

The performance metrics achieved (MCC = 0.583, ROC-AUC = 0.896) are competitive with state-of-the-art QSAR models for antiviral prediction. For comparison, recent studies targeting flavivirus inhibitors report MCC values ranging from 0.45–0.65 [22,45,46], with our optimized model performing in the upper range. The inclusion of assay type as a distinguishing feature proved crucial, improving MCC by approximately 0.08 compared to models without this distinction. This highlights the importance of considering experimental context in QSAR modeling, particularly when combining data from different assay formats.

The comprehensive structure–activity relationship (SAR) analysis of the 276 High-High compounds revealed critical insights into the molecular determinants of anti-dengue activity and the challenges inherent in natural product drug discovery. The striking disparity in drug-likeness—with only 20 compounds (7.2%) achieving QED ≥ 0.5—reflects a fundamental tension between the evolutionary optimization of phytochemicals for ecological functions versus pharmaceutical requirements for human therapeutics [47]. Natural products have evolved to maximize biological activity through structural features that often violate Lipinski’s Rule of Five [41], including high molecular weight, excessive hydrogen bonding capacity, and elevated polar surface area. Our finding that 256 compounds (92.8%) exhibited suboptimal drug-likeness despite high predicted potency underscores the necessity of multi-criteria filtering in virtual screening campaigns and validates our strategic focus on the 20 high-QED candidates for experimental prioritization.

The remarkable structural novelty observed among high-potency hits—with all 276 compounds (100%) exhibiting Tanimoto similarity < 0.5 to ChEMBL training data (median: 0.214)—provides compelling evidence that Colombian biodiversity harbors unique chemical scaffolds worthy of systematic investigation. Murcko scaffold analysis revealed 145 unique scaffolds, of which 144 (99.3%) were completely absent from the training dataset. This unprecedented novelty rate far exceeds typical virtual screening campaigns against synthetic libraries, where 40–60% novelty is considered exceptional [48,49]. The chemical space segregation visualized through principal component analysis (Figure 3B) confirms that novel candidates occupy distinct structural regions, suggesting that they may engage dengue viral targets through alternative binding modes or access entirely different protein pockets compared to known inhibitors. This structural divergence presents both opportunities and challenges: while novel scaffolds offer potential for circumventing resistance mechanisms and accessing unexplored intellectual property space, they also require more extensive mechanistic characterization and may necessitate greater structural optimization to achieve clinical candidates.

The descriptor–activity correlation analysis (Figure 3D) revealed differential molecular property associations between IC50 and EC50 endpoints, reinforcing their biological distinction. The weak correlations observed for IC50 activity (maximum |ρ| = 0.06) compared to EC50 (maximum |ρ| = 0.15) suggest that biochemical target inhibition is influenced by subtle structural features not captured by simple physicochemical descriptors, potentially involving specific three-dimensional arrangements or pharmacophoric elements. In contrast, the stronger correlations for EC50—particularly the negative TPSA association (ρ = −0.15) and positive QED relationship (ρ = 0.14)—indicate that cellular antiviral efficacy is more predictable from bulk molecular properties, likely reflecting the importance of membrane permeability, intracellular distribution, and metabolic stability. The TPSA-EC50 negative correlation provides actionable guidance for lead optimization: strategic reduction of the polar surface area through modifications such as methylation of hydroxyl groups, replacement of carboxylic acids with bioisosteric alternatives, or removal of sugar moieties from glycosides could enhance cellular penetration while maintaining target affinity. Conversely, the positive QED-EC50 association validates our prioritization strategy, as compounds naturally possessing drug-like features are inherently more likely to demonstrate cellular efficacy without requiring extensive medicinal chemistry optimization.

Detailed examination of the 15 top-priority candidates (Table 2, Figure 4) revealed a structurally diverse collection spanning five chemical classes, with alkaloids predominating (n = 7, 46.7%). Incartine (#1), an indole alkaloid from Hippeastrum puniceum exhibiting the highest QED score (0.83) and balanced dual-endpoint activity (pIC50: 6.84, pEC50: 6.13), emerged as the most promising lead candidate. Its favorable pharmaceutical profile—moderate molecular weight (312.4 Da), balanced lipophilicity (LogP: 2.1), and low polar surface area (TPSA: 67.8 Ų)—combined with structural novelty (Tanimoto: 0.28) positions it as an ideal starting point for medicinal chemistry optimization. The identification of two compounds from Hippeastrum puniceum among the top 15 (Incartine #1 and Hippeastrine #11) suggests that this species may be particularly rich in anti-dengue scaffolds, warranting comprehensive phytochemical profiling and possibly representing an underexplored source of Amaryllidaceae alkaloids with antiviral potential.

Comprehensive ADMET profiling (Figure 6) revealed critical insights into the pharmaceutical viability of priority candidates and exposed a fundamental trade-off between predicted antiviral potency and drug-likeness. While all 15 candidates demonstrated universal compliance with Lipinski’s Rule of Five and absence of PAINS alerts, integrated ADMET scoring identified substantial variation in overall pharmaceutical favorability (scores ranging from 0.629 to 0.825). Notably, Incartine—despite ranking first by predicted pIC50 (6.84)—exhibited only moderate ADMET score (0.698, rank 11/15) due to computational flags for AMES mutagenicity, hepatotoxicity, CYP2D6 inhibition, and hERG II inhibition. This contrasts sharply with Trifolirhizin, which achieved the highest ADMET score (0.825) while maintaining robust predicted activity (pIC50: 6.63). This dissociation between computational potency predictions and pharmaceutical profiles validates our multi-criteria optimization approach and underscores that QSAR-predicted activity alone provides insufficient basis for candidate prioritization. The observation that 80% of candidates flagged positive for AMES mutagenicity, while concerning, must be interpreted cautiously given the documented 35–45% false-positive rate of computational AMES predictions for natural products, necessitating experimental validation through bacterial reverse mutation assays. The structural class-dependent ADMET patterns observed—with terpenoid glycosides (mean score: 0.785) consistently outperforming Amaryllidaceae alkaloids (mean score: 0.709) in safety and metabolic stability predictions—provides actionable guidance for future bioprospecting efforts and suggests that the systematic investigation of terpenoid-rich Colombian plant families may yield inherently more pharmaceutically tractable candidates.

The presence of Lycorine (13, Tanimoto: 1.00) and Pseudolycorine (15, Tanimoto: 1.00) among our top predictions provides crucial internal validation of model performance. These compounds, present in the ChEMBL training dataset with experimentally confirmed anti-dengue activity, were successfully recovered by our screening protocol despite not being explicitly identified as validation targets. Lycorine, in particular, has demonstrated broad-spectrum antiviral activity in recent studies, including against SARS-CoV-2 and influenza A virus through mechanisms involving protein synthesis inhibition and immunomodulation [50,51]. The model’s ability to correctly prioritize these validated compounds increases confidence in predictions for structurally novel candidates and suggests that our top 12 novel compounds merit immediate experimental evaluation.

Intriguingly, several terpenoid glycosides appeared among the top candidates (Byzantionoside B #5, (6R,9R)-3-Oxo-alpha-ionol glucoside #10, 9-Hydroxy-7-megastigmen-3-one glucoside #12), despite their typically challenging pharmaceutical properties. Glycosylation, while often improving water solubility and reducing toxicity, generally compromises oral bioavailability due to poor membrane permeability and susceptibility to intestinal glycosidases [52]. However, for dengue treatment—where severe cases require hospitalization and intravenous administration is standard—this limitation may be less critical than for orally administered therapeutics. Additionally, prodrug strategies employing enzymatically cleavable linkers could enable the targeted delivery of aglycone active compounds while exploiting the favorable solubility of glycosides. The moderate QED scores achieved by these glycosides (0.51–0.54) suggest that they occupy a pharmaceutical property space that, while suboptimal for oral drugs, may be acceptable for parenteral formulations or with appropriate delivery modifications.

Comparative analysis with ChEMBL training set high-potency references (Figure 4, right panels) revealed both validating similarities and important distinctions. The training set was dominated by Amaryllidaceae alkaloids, with Narciclasine analogs (ChEMBL464432, pActivity: 10.82) and Pancratistatin (pActivity: 10.20) exhibiting exceptional nanomolar potencies (IC50 = 0.01–0.06 nM). However, many of these highly potent training compounds exhibit low drug-likeness (e.g., ChEMBL5188858 QED: 0.22, ChEMBL3392006 QED: 0.13), illustrating the disconnect between biochemical potency and pharmaceutical viability that our filtering strategy explicitly addresses. Our identification of structurally related but drug-like Amaryllidaceae alkaloids (Incartine QED: 0.83, 3-Acetylnerbowdine QED: 0.80) represents a potential breakthrough in balancing potency with developability.

The structural diversity among our novel candidates—ranging from simple indole alkaloids (Incartine, Indican) to complex sesquiterpene lactones (Bilobalide, Epicolactone) to cardiac glycoside aglycones (Digoxigenin)—contrasts sharply with the training set’s heavy enrichment in Amaryllidaceae alkaloids. This chemical diversity suggests our top candidates may target multiple points in the dengue viral replication cycle or engage different protein pockets, offering opportunities for rational combination therapy. Recent structural biology studies have identified multiple druggable sites across dengue viral proteins, including the NS3 protease active site [53], NS5 RNA-dependent RNA polymerase catalytic pocket [54], NS2B-NS3 protease allosteric sites [55], and envelope protein domain II [56]. The structural heterogeneity of our candidates makes it plausible that different chemical classes engage different targets, potentially enabling synergistic multi-target inhibition strategies that could address antiviral resistance.

The finding that only 14.3% of Colombian plant species have documented antiviral activity, and nearly half of these lack phytochemical characterization, reveals both a challenge and an opportunity. This knowledge gap is particularly concerning given Colombia’s status as the world’s second-most biodiverse country [57] and the increasing pressure on natural habitats from deforestation and climate change [58]. The urgency to document and preserve this chemical diversity cannot be overstated, as each lost species potentially represents unique bioactive compounds that could address current and future health challenges.

The predominance of certain plant families in our antiviral activity compilation—particularly Asteraceae, Fabaceae, and Lamiaceae—reflects both their chemical richness and the historical focus of ethnopharmacological research. Asteraceae’s prevalence is unsurprising given its production of diverse sesquiterpene lactones, compounds with well-documented antiviral properties [59,60]. However, this distribution may also reflect sampling bias, as these families are among the most studied globally, potentially overlooking equally valuable but less investigated families. However, this distribution may also reflect sampling bias, as these families are among the most studied globally, potentially overlooking equally valuable but less investigated families. Our identification of Digoxigenin (#14), a cardiac glycoside aglycone from Digitalis purpurea, as a high-priority candidate despite steroids being underrepresented in anti-dengue literature, exemplifies how unbiased computational screening can reveal unexpected chemotype–activity relationships that might be missed by hypothesis-driven approaches.

The identification of Amaryllidaceae alkaloids—specifically Incartine, Lycorine, and Kalbreclasine from Hippeastrum puniceum—as top candidates provides compelling validation of our approach. Lycorine has demonstrated broad-spectrum antiviral activity in recent studies, including against SARS-CoV-2 [50] and influenza viruses [51], through mechanisms involving protein synthesis inhibition and immunomodulation. The high predicted activity of these compounds against dengue virus (pActivity > 7.0) suggests potential for repurposing these natural products, which could significantly accelerate drug development timelines. The structural analysis revealing that 100% of the 276 High-High compounds represent novel chemotypes (Tanimoto < 0.5) not present in the ChEMBL training set is particularly significant. This finding suggests that Colombian flora contains a unique structural diversity that could provide new mechanisms of action against dengue virus. Among the 15 prioritized candidates, alkaloids predominate (7/15, 46.7%), followed by terpenoids (6/15, 40.0%), flavonoids (1/15, 6.7%), and steroids (1/15, 6.7%). This chemical diversity contrasts with current anti-dengue drug development, which has primarily focused on nucleoside analogs and protease inhibitors.

The favorable drug-likeness profiles of our 15 prioritized candidates—all satisfying Lipinski’s Rule of Five with zero violations and QED scores ranging from 0.51 to 0.83—suggest good potential for pharmaceutical development. However, the presence of glycosylated compounds (5/15, 33.3%) presents both opportunities and challenges. While glycosylation can improve water solubility and reduce toxicity, it often compromises oral bioavailability due to poor membrane permeability and susceptibility to intestinal glycosidases. The alignment between our computational predictions and traditional uses of these plants provides important validation.

This study has several limitations that should be considered when interpreting the results:

Model-related limitations: The QSAR model’s applicability domain may not fully encompass the structural complexity of natural products, particularly those with multiple chiral centers or unusual functional groups rare in synthetic compounds. While our model achieved competitive performance (MCC = 0.583, ROC-AUC = 0.896), predictions for highly novel compounds (Tanimoto < 0.3) should be interpreted with appropriate caution.

Activity threshold considerations: The potency thresholds employed (pActivity > 6 for high potency) follow established drug discovery conventions for submicromolar activity classification [61,62]. Sensitivity analysis demonstrated that compounds classified as high potency in the training dataset exhibited pActivity values substantially above the threshold (mean: 7.04 ± 0.97; margin: +1.04 log units). The prioritized candidates exhibited predicted pActivity values above the cutoff (mean pIC50: 6.42 ± 0.30; mean pEC50: 6.45 ± 0.34), with margins (+0.42 to +0.45 log units) consistent with expected QSAR model uncertainty (±0.3–0.5 log units) and experimental variability in heterogeneous IC50 data (σ = 0.68) [63]. The dual-endpoint “High-High” classification requirement provides additional conservatism against threshold-dependent artifacts.

Training dataset considerations: The training dataset exhibited class imbalance characteristic of bioactivity databases, with high-potency compounds representing 11.1% of the data. While this imbalance was addressed through sample weighting mechanisms and validated using appropriate metrics (MCC, ROC-AUC), the limited sample size of high-potency examples (n = 227) may constrain the model’s ability to capture the full structural diversity of potent inhibitors. The dataset size of 2034 compounds represents the maximum available high-confidence experimental data for dengue virus targets in public databases [64,65].

Experimental validation: This study represents an in silico screening campaign without experimental validation of predicted activities. While computational predictions provide valuable prioritization, in vitro and in vivo studies are necessary to confirm antiviral efficacy, determine mechanisms of action, and assess safety profiles.

Single-compound approach: Our methodology evaluated individual compounds in isolation, whereas traditional medicinal preparations often rely on synergistic interactions between multiple constituents. The potential for synergistic or antagonistic effects among phytochemicals was not assessed.

Mechanistic insights: The lack of target-specific predictions represents a limitation; while our model predicts general anti-dengue activity, it does not identify which viral proteins are targeted, which would greatly facilitate lead optimization. As a ligand-based QSAR approach, this study predicts general anti-dengue activity without identifying specific molecular targets. The IC50 and EC50 measurements used for model training derive from whole-virus assays that may reflect the inhibition of multiple viral proteins or host–pathogen interactions. Consequently, structure-based computational methods such as molecular docking and molecular dynamics simulations are not appropriate at this stage, as they require prior knowledge of the specific protein target(s). Target deconvolution studies using experimental approaches (thermal shift assays, enzymatic inhibition assays, or surface plasmon resonance) represent essential next steps following vitro validation of antiviral activity and would enable subsequent structure-based optimization of confirmed hits.

Data availability and sampling bias: The 48.6% of antiviral plant species lacking phytochemical characterization represents a significant knowledge gap that may cause us to overlook potentially important bioactive compounds from understudied species. Additionally, the literature-based screening for antiviral activity inherently favors well-studied cosmopolitan families (e.g., Asteraceae, Fabaceae, Lamiaceae) over endemic or understudied taxa. This reporting bias likely results in conservative underestimation of Colombian flora’s true antiviral potential rather than the inflation of results, as species lacking published antiviral studies were excluded regardless of their potential bioactivity.

Despite these limitations, this computational framework provides a valuable prioritization tool that can significantly reduce the time and cost of experimental screening. The public availability of our model and datasets enables other researchers to validate predictions, extend the analysis to additional plant species, or adapt the methodology for other therapeutic targets.

This study’s implications extend beyond immediate drug discovery applications. By demonstrating the pharmaceutical potential of Colombian biodiversity, we provide economic arguments for conservation that complement ethical and ecological rationales. The identification of high-value compounds from native species could support sustainable development models where local communities benefit from biodiversity conservation through benefit-sharing agreements aligned with the Nagoya Protocol. The development of an open-access platform for continuing this screening effort democratizes access to these findings and enables collaborative research, aligning with global efforts to make drug discovery more inclusive. This pioneering work successfully demonstrates the feasibility and value of applying modern computational approaches to explore Colombian biodiversity for anti-dengue drug discovery. Moving forward, immediate priorities include experimental validation of top candidates through viral inhibition assays, mechanism of action studies for confirmed hits, and chemical characterization of the understudied antiviral plant species. This integrated approach positions Colombia to leverage its extraordinary biodiversity for global health benefit while promoting the sustainable development and conservation of its natural heritage.

## Section: 4. Materials and Methods › 4.1. Data Sources and Availability

All datasets, trained models, and analysis code generated during this study are publicly available to ensure full reproducibility. Bioactivity Data Raw anti-dengue bioactivity data were retrieved from the ChEMBL database, version 33 [31,66] (https://www.ebi.ac.uk/chembl/, accessed 1 March 2024). The curated training dataset is provided as Data S1 in the Supplementary Materials. Plant species information was obtained from the official checklist ‘Plantas alimenticias y medicinales de Colombia’ (I2D-BIO_2014_IN045), a Darwin Core-standardized dataset curated by the Alexander von Humboldt Biological Resources Research Institute covering the entirety of Colombian territory [11]. The complete Colombian phytochemical library (3267 compounds from 358 medicinal plant species) is available as Data S2 in the Supplementary Materials. Detailed ethnobotanical information for all plant species is provided in Table S1. Computational Models and Code. The optimized XGBoost model, preprocessing objects, and model parameters are available as Data S3 in the Supplementary Materials. All Python scripts for data curation, molecular descriptor calculation, model training, Bayesian optimization, and virtual screening are deposited at https://github.com/Sergio111999/QSAR_DENV#qsar-denv-anti-dengue-drug-discovery-from-colombian-medicinal-flora (accessed on 1 November 2025) under an MIT license (DOI to be provided upon acceptance).

## Section: 4. Materials and Methods › 4.2. Anti-Dengue Compound Dataset Curation

Bioactivity data were retrieved from ChEMBL using the following SQL query structure:

sqlSELECT * FROM activities

WHERE target_organism LIKE ‘%dengue%’

AND standard_type IN (‘IC50’, ‘EC50’)

AND standard_relation = ‘=’

Data curation followed the workflow described by Mendez et al. (2019) [31]. Briefly, activity values were standardized to molar units and converted to pActivity (−log10[M]). Compounds were categorized into three potency classes following the established drug discovery conventions: high potency (pActivity > 6, corresponding to submicromolar activity IC50/EC50 < 1 µM), medium potency (5 < pActivity ≤ 6, corresponding to low micromolar activity 1–10 µM), and low potency (pActivity ≤ 5, corresponding to IC50/EC50 > 10 µM). The pActivity > 6 threshold for high potency represents the widely accepted benchmark for identifying compounds with sufficient potency to warrant further development in drug discovery campaigns [61,62]. Duplicate structures were identified using InChIKey and resolved by retaining the highest pChEMBL value. The final dataset contained 2034 activity records corresponding to 1981 unique molecules, with 53 molecules having both IC50 and EC50 measurements.

IC50 and EC50 endpoints were modeled independently based on three considerations: (1) pharmacological distinction—IC50 measures biochemical target inhibition while EC50 integrates cellular factors including membrane permeability, metabolic stability, and intracellular distribution; (2) statistical independence—analysis of 53 compounds with both measurements revealed no significant correlation (r = −0.0415, p = 0.77, 95% CI: [−0.31, 0.23]); and (3) data utilization—independent modeling preserves 1339 IC50 and 695 EC50 measurements that would be lost if analysis was restricted to the 53-compound overlap.

## Section: 4. Materials and Methods › 4.3. Colombian Medicinal Flora Database Construction

The initial species pool (n = 2567) was obtained from the official checklist ‘Plantas alimenticias y medicinales de Colombia’ (I2D-BIO_2014_IN045), curated by the Alexander von Humboldt Biological Resources Research Institute through systematic review of Colombian herbaria with taxonomic validation against the Missouri Botanical Garden database (Tropicos) [11]. This Darwin Core-standardized dataset provides nationwide geographic coverage and was developed under Colombia’s National Strategy for Plant Conservation.

After removing duplicate entries and infraspecific taxa, 2501 unique species remained for analysis. Species with documented antiviral activity were identified through a systematic literature review following the PRISMA guidelines [67]. PubMed and Scopus were searched (January–April 2024) using: “[species name]” AND “antiviral”. Of the 2501 species evaluated, 358 (14.3%) exhibited documented antiviral activity. However, within this subset, only 184 species (51.4%) had any level of phytochemical characterization or reported metabolites in the literature to which the observed antiviral activity could be attributed. The structures of these metabolites were retrieved from the primary literature and standardized using RDKit (v2024.03.5), following the protocol of Bento et al. (2020) [68].

## Section: 4. Materials and Methods › 4.4. Molecular Descriptors and Machine Learning

Molecular descriptors (n = 43) and fingerprints (ECFP4, 2048 bits) were calculated using RDKit. The complete feature matrix (2091 features) was reduced to 887 informative features using variance filtering (threshold > 0.01). Correlation analysis of the 40 physicochemical descriptors identified clusters of related features (e.g., molecular size indices: MW, Chi0, Chi1, MolMR), which is expected given their chemical relationships. However, these correlated descriptors contributed only 6.3% of total model importance, with 91.9% derived from ECFP4 fingerprint bits that lack systematic correlations. Tree-based ensemble methods are inherently robust to multicollinearity for prediction tasks, as correlated features compete for split selection without affecting predictive performance.

Machine learning models were implemented using scikit-learn (v1.3.2) and XGBoost (v3.0.2). To address class imbalance in the training dataset (High potency: 11.1%; Medium: 23.4%; Low: 65.5%), sample weights were calculated during XGBoost training using the formula weight[class] = N_total/(N_classes × N_class). This approach weights minority class instances proportionally to their underrepresentation, ensuring that classification errors on high-potency compounds contribute appropriately to model updates. Additional protection against overfitting was achieved through XGBoost’s comprehensive regularization: L1 regularization (reg_alpha = 0.016), L2 regularization (reg_lambda = 4.73), tree pruning (gamma = 1.53), and column subsampling (colsample_bytree = 0.91).

Model performance was evaluated using the Matthews Correlation Coefficient (MCC) and ROC-AUC, metrics specifically suited for imbalanced classification. Model evaluation employed 5-fold stratified cross-validation. The optimal model (XGBoost with Descriptors+ECFP4 representation) achieved an MCC = 0.572 ± 0.048.

## Section: 4. Materials and Methods › 4.4. Molecular Descriptors and Machine Learning › Model Validation

Model validation employed four complementary approaches to ensure robustness and prevent overfitting:

Extended Bayesian Optimization: Hyperparameter optimization was extended to 100 trials to confirm convergence. Analysis revealed that 99.6% of the final performance was achieved by trial 50 (MCC = 0.5832 vs. final 0.5854), with the marginal improvement of 0.38% demonstrating adequate convergence within the original optimization budget.

Y-Randomization Testing: To validate that the model captures genuine structure-activity relationships rather than random correlations, Y-randomization testing was performed with 100 permutations of the target labels. The real model MCC (0.585) was dramatically higher than any permuted model (max = 0.059, p < 0.01), confirming that the model captures genuine structure–activity relationships.

Hyperparameter Importance Analysis: Regularization parameters dominated the optimization landscape: reg_alpha (38.6%), gamma (33.3%), and reg_lambda (0.8%), collectively accounting for 72.7% of performance variance, indicating the optimization process prioritized overfitting prevention.

Independent Hold-out Validation: A stratified 80/20 train–test split with completely unseen test data (n = 407) was performed. Hold-out MCC (0.576) differed by only 1.2% from CV MCC (0.583), and hold-out ROC-AUC (0.888) differed by only 0.9% from CV ROC-AUC (0.896), confirming that cross-validation estimates accurately predict performance on completely unseen data.

## Section: 4. Materials and Methods › 4.5. Virtual Screening Protocol

The trained XGBoost model was applied to predict anti-dengue activity for 3267 phytochemicals from Colombian medicinal flora. For each compound, predictions were generated independently for both IC50 and EC50 endpoints, yielding pActivity values calculated as −log10 (predicted activity in molar units). The dual-endpoint classification framework categorized compounds into nine classes based on combined IC50 and EC50 potency thresholds: Low (pActivity ≤ 5.0), Medium (5.0 < pActivity ≤ 6.0), and High (pActivity > 6.0). Compounds achieving high predicted potency for both endpoints (pIC50 > 6.0 AND pEC50 > 6.0) were designated as “High-High” and prioritized for subsequent analysis.

Drug-likeness assessment was performed using Lipinski’s Rule of Five criteria and Quantitative Estimate of Drug-likeness (QED) scores calculated following the methodology of Bickerton et al. [47] as implemented in RDKit. QED integrates eight molecular properties (MW, LogP, HBA, HBD, PSA, rotatable bonds, aromatic rings, structural alerts) into a unified drug-likeness metric ranging from 0 (non-drug-like) to 1 (ideal drug-like properties). A QED threshold of 0.5 was applied to distinguish compounds with favorable pharmaceutical properties from those requiring extensive optimization.

Compounds were prioritized for experimental validation based on a multi-criteria strategy: (i) dual high potency (pActivity > 6.0 for both IC50 and EC50), (ii) favorable drug-likeness (QED ≥ 0.5), (iii) structural novelty assessment via Tanimoto similarity to training compounds, and (iv) compliance with applicability domain criteria. This hierarchical filtering identified 20 compounds meeting all criteria, from which the top 15 were selected based on pIC50 ranking for detailed characterization.

## Section: 4. Materials and Methods › 4.5. Virtual Screening Protocol › Comprehensive Structure–Activity Relationship (SAR) Analysis

Following QSAR-based virtual screening, a systematic SAR analysis pipeline was implemented to characterize activity distributions, assess chemical diversity, evaluate structural novelty, and identify molecular properties correlated with antiviral potency. The analysis comprised four integrated components executed using Python 3.12.3 with RDKit 2024.03.5, scikit-learn 1.3.2, and custom analysis scripts.

Dual-Endpoint Classification and Activity Distribution: All 3267 screened compounds were classified into a 3 × 3 activity matrix based on combined IC50 and EC50 predicted potencies using the thresholds defined above (Low ≤ 5.0, Medium 5.0–6.0, High > 6.0). This classification generated nine mutually exclusive categories (e.g., “Low-Low “, “High-Medium”, “High-High”), enabling systematic characterization of dual-endpoint activity patterns across the chemical library. Frequency distributions were calculated for each category, and the “High-High” class was designated as the priority population for downstream analyses.

Structural Novelty Assessment: The structural novelty of high-potency compounds relative to the ChEMBL training dataset was quantified using Tanimoto similarity coefficients calculated from Extended Connectivity Fingerprints (ECFP4, radius = 2, 2048 bits) as implemented in RDKit. For each screened compound, Tanimoto similarity was computed against all 1981 training set compounds, and the maximum similarity value was retained as the novelty metric. Compounds were classified into novelty categories as follows: Novel/Very Novel (Tanimoto < 0.5), indicating low structural similarity to known anti-dengue agents; Moderate similarity (0.5 ≤ Tanimoto < 0.7); and Training-like (Tanimoto ≥ 0.7), indicating high structural resemblance to training compounds. This classification enables the identification of both validated chemotypes (high Tanimoto) and potentially innovative scaffolds (low Tanimoto).

Chemical Space Visualization and Diversity Analysis: Principal component analysis (PCA) was performed on the ECFP4 fingerprint matrix to project the high-dimensional chemical space into two dimensions for visualization. PCA was implemented using scikit-learn’s decomposition module with standardized features, and the first two principal components (PC1, PC2) were retained for plotting. The projection enables the visual assessment of chemical space coverage, identification of structural clusters, and evaluation of segregation between novelty categories. The cumulative variance explained by PC1 and PC2 quantifies the effectiveness of dimensionality reduction.

Drug-likeness Assessment: All compounds were evaluated for drug-likeness using the QED metric calculated via RDKit’s QED module (Chem.QED.qed function). QED scores were dichotomized using a threshold of 0.5: compounds with QED ≥ 0.5 were classified as “High QED” (favorable pharmaceutical properties), while QED < 0.5 indicated “Low QED” (suboptimal properties requiring optimization). For High-High compounds, the proportion achieving high QED was calculated to assess the pharmaceutical development challenge inherent in the high-potency population.

Descriptor-Activity Correlation Analysis: Spearman rank correlation coefficients (ρ) were calculated between 11 molecular descriptors and predicted pActivity values for both IC50 and EC50 endpoints across all 3267 compounds. The descriptor set included: Molecular Weight (MW), octanol-water partition coefficient (LogP), hydrogen bond acceptors (HBA), hydrogen bond donors (HBD), rotatable bonds (RotBonds), topological polar surface area (TPSA), total ring count (Rings), aromatic rings (AromaticRings), aliphatic rings (NumAliphaticRings), fraction of sp3 carbons (FractionCSP3), and QED. Correlations were computed using scipy.stats.spearmanr, and statistical significance was assessed using two-tailed tests with Bonferroni correction for multiple comparisons (α = 0.05/22 = 0.0023, accounting for 11 descriptors × 2 endpoints). Only correlations with |ρ| > 0.05 and corrected p < 0.0023 were considered statistically significant. Results were visualized as heatmaps using seaborn 0.13.2 with diverging color scales centered at zero correlation.

Top Candidate Selection and Characterization: From the 20 compounds meeting all filtering criteria (High-High + QED ≥ 0.5), the top 15 were selected based on descending pIC50 values and subjected to comprehensive characterization. For each compound, the following properties were tabulated: predicted pIC50 and pEC50, QED score, molecular descriptors (MW, LogP, HBA, HBD, TPSA), novelty category, maximum Tanimoto similarity to training compounds, assigned chemical class based on structural features, and botanical source from phytochemical databases. Chemical class assignments integrated automated substructure searches (using RDKit’s HasSubstructMatch for scaffold identification) with manual curation based on established phytochemical taxonomy. Plant source assignments were cross-referenced with the primary literature and validated against the Colombian medicinal flora database compiled in this study.

All SAR analysis workflows, including data preprocessing, statistical calculations, and visualization generation, were implemented in reproducible Python scripts with full parameterization, enabling adaptation to alternative screening datasets. Complete code with detailed documentation is available in the public repository accompanying this manuscript.

## Section: 4. Materials and Methods › 4.6. Applicability Domain Assessment

To ensure the reliability of predictions, the applicability domain was evaluated using:-Chemical similarity: Tanimoto coefficient > 0.3 to nearest training set compounds;-Leverage analysis: Compounds with leverage hi < 3p/n (p = features, n = training samples);-Descriptor range: All molecular descriptors within training set min-max bounds.

Only compounds meeting at least two criteria were considered reliable predictions.

Additionally, leverage analysis was performed by calculating the hat matrix diagonal elements (hi) for each prediction using SVD decomposition for numerical stability, with the warning threshold set at h* = 3p/n where p is the number of features (887) and n is the training set size (2034), yielding a critical leverage value of 1.308. Compounds exceeding this threshold were flagged as requiring extrapolation and treated with appropriate caution in interpretation.

Comprehensive applicability domain assessment of the 15 prioritized candidates employed dual criteria following the OECD guidelines. Leverage-based analysis identified 2/15 compounds (13.3%) within the leverage-based AD: Lycorine and Pseudolycorine, both present in the ChEMBL training dataset with experimentally confirmed anti-dengue activity. Tanimoto similarity analysis (threshold > 0.3) identified 5/15 compounds (33.3%) within acceptable structural coverage: Lycorine (Tc = 1.000), Pseudolycorine (Tc = 1.000), Hippeastrine (Tc = 0.515), Indican (Tc = 0.345), and Incartine (Tc = 0.328). The observation that most prioritized compounds fell outside the leverage-based AD was scientifically expected for natural products from underexplored chemical space and does not invalidate the predictions, as these compounds represent the novel chemotypes that constitute the primary objective of this bioprospecting study. Based on AD assessment, experimental validation is recommended in three tiers: Tier 1 (highest confidence): Lycorine, Pseudolycorine—within both AD criteria; Tier 2 (high confidence): Hippeastrine, Indican, Incartine—within Tanimoto AD; Tier 3 (exploratory): remaining compounds—novel chemotypes requiring experimental confirmation.

## Section: 4. Materials and Methods › 4.7. ADMET Profiling of Prioritized Candidates

The 15 prioritized compounds from virtual screening were subjected to comprehensive in silico ADMET (Absorption, Distribution, Metabolism, Excretion, and Toxicity) profiling using a multi-platform approach to assess pharmaceutical viability prior to experimental validation.

Physicochemical properties and pharmacokinetic parameters were computed using SwissADME [69], which calculated molecular descriptors including molecular weight (MW), lipophilicity (consensus Log P from five independent methods: iLOGP, XLOGP3, WLOGP, MLOGP, Silicos-IT), topological polar surface area (TPSA), hydrogen bond acceptors/donors (HBA/HBD), number of rotatable bonds, molar refractivity (MR), and fraction of sp3 carbons (Csp3). Absorption properties evaluated included gastrointestinal (GI) absorption level (High/Low classification), and blood–brain barrier (BBB) permeability (Yes/No). Distribution parameters included P-glycoprotein (P-gp) substrate status and skin permeability coefficient (log Kp). Metabolic liability was assessed through the prediction of inhibition for five major cytochrome P450 isoforms (CYP1A2, CYP2C9, CYP2C19, CYP2D6, CYP3A4), which collectively mediate >80% of Phase I drug metabolism. Solubility was predicted using three independent algorithms (ESOL, Ali, Silicos-IT), with the ESOL classification (Very soluble/Soluble/Moderately soluble/Poorly soluble/Insoluble) used as the primary descriptor.

Drug-likeness was evaluated according to established medicinal chemistry filters: Lipinski’s Rule of Five (MW ≤ 500 Da, Log P ≤ 5, HBA ≤ 10, HBD ≤ 5), Ghose filter (160 ≤ MW ≤ 480, −0.4 ≤ Log P ≤ 5.6, 40 ≤ MR ≤ 130, 20 ≤ atoms ≤ 70), Veber rule (rotatable bonds ≤ 10, TPSA ≤ 140 Ų), Egan rule (TPSA ≤ 131.6 Ų, Log P ≤ 5.88), and Muegge rule. Structural alerts were evaluated for pan-assay interference compounds (PAINS) using established substructure filters and for potentially reactive or toxic functional groups (Brenk alerts). Bioavailability scores were computed as the probability of achieving ≥10% oral bioavailability in rats. Synthetic accessibility was assessed on a 1–10 scale (lower scores indicating easier synthesis) using fragment-based analysis of structural complexity.

Toxicological endpoints were predicted using pkCSM [70], which provides empirical models trained on experimental data for: (1) Ames mutagenicity (bacterial reverse mutation assay), (2) hERG I and II cardiac ion channel inhibition as cardiotoxicity surrogates, (3) hepatotoxicity, (4) skin sensitization potential, (5) oral rat acute toxicity (LD50 in mol/kg), (6) oral rat chronic toxicity (LOAEL in log mg/kg_bw/day), and (7) maximum tolerated dose in humans (log mg/kg/day). Environmental toxicity was additionally assessed through Tetrahymena pyriformis and fathead minnow (Pimephales promelas) toxicity predictions.

An integrated ADMET favorability scoring system was developed by converting each property to a normalized 0–1 scale where 1.0 represents the optimal pharmaceutical properties and 0.0 represents unfavorable characteristics. The conversion scheme was property-specific: (1) for binary categorical properties (e.g., GI absorption: High = 1.0, Low = 0.0; BBB permeant: No = 1.0 for peripheral drugs, Yes = 0.0), (2) for ordinal solubility classes (Very soluble = 1.0, Soluble = 0.75, Moderately soluble = 0.5, Poorly soluble = 0.25), (3) for continuous toxicity values, normalization by min-max scaling with higher LD50 values corresponding to higher favorability scores, (4) for synthetic accessibility, inversion of the 1–10 scale such that easier synthesis received higher scores, and (5) for violation counts, inverse scoring (1.0—violations/max_violations). The global ADMET score for each compound was calculated as the arithmetic mean across all 17 normalized properties. Hierarchical clustering of compounds based on their ADMET profiles was performed using Ward’s method with Euclidean distance on the complete favorability score matrix. Statistical analyses were conducted in Python 3.12.3 using pandas, NumPy, SciPy, and scikit-learn libraries. Heatmap visualizations were generated using Matplotlib and Seaborn with a diverging color scheme (green-yellow-red) to facilitate interpretation of favorable versus unfavorable properties.

## Section: 4. Materials and Methods › 4.8. Statistical Analysis

Statistical analyses used Python 3.12.3. Distribution comparisons employed the Mann–Whitney U test. Multiple testing correction used the Bonferroni method (α = 0.05). Chemical space visualization used UMAP (umap-learn v0.5.7; n_neighbors = 15, min_dist = 0.1) and hierarchical clustering (Ward linkage on Tanimoto distances).

## Section: 4. Materials and Methods › 4.9. Computational Resources

All computations were performed on a workstation equipped with an Intel Core i5 CPU, 16 GB RAM, SSD storage, and dual GPUs (NVIDIA GeForce RTX 3050 Laptop GPU with 4 GB dedicated VRAM and Intel Iris Xe Graphics), running Windows 11. XGBoost and LightGBM models utilized GPU acceleration via CUDA support. Model training required approximately 6 h, while the virtual screening of 3267 compounds was completed in three minutes.

## Section: 4. Materials and Methods › 4.10. Code Availability

Complete code for reproducing all analyses is available at https://github.com/Sergio111999/QSAR_DENV#qsar-denv-anti-dengue-drug-discovery-from-colombian-medicinal-flora under MIT license. Key dependencies: Python (3.12.3) [71], RDKit (2024.03.5) [72], NumPy (1.26.4) [73], pandas (2.3.0) [74], SciPy (1.13.1) [75], scikit-learn (1.3.2) [76], XGBoost (3.0.2) [19], LightGBM (4.6.0) [77], Optuna (4.4.0) [29], imbalanced-learn (0.12.3) [78], matplotlib (3.9.2) [79], seaborn (0.13.2) [80], joblib (1.4.2), umap-learn (0.5.7) [32], streamlit (1.37.1) [81].

## Section: 4. Materials and Methods › 4.11. Use of AI Tools

Claude Opus 4.1 was used to assist with the code debugging and optimization of data visualization scripts. All AI-generated code was manually reviewed and validated. No AI tools were used for data generation, analysis, or interpretation of results.

## Section: 5. Conclusions

This study successfully demonstrated the application of optimized machine learning-based QSAR modeling integrated with comprehensive structure–activity relationship analysis to systematically screen Colombian medicinal flora for potential anti-dengue compounds, revealing the untapped pharmaceutical potential of one of the world’s most biodiverse regions. The development of a robust predictive model through Bayesian hyperparameter optimization (MCC = 0.583, ROC-AUC = 0.896) enabled the virtual screening of 3267 phytochemicals, identifying 276 compounds (8.4%) with dual high potency (High-High classification) and subsequently prioritizing 15 exceptional candidates combining high predicted activity, favorable drug-likeness (QED ≥ 0.5), and diverse structural scaffolds for experimental validation.

The comprehensive SAR analysis revealed critical insights into the molecular landscape of anti-dengue activity within Colombian biodiversity. All 276 High-High compounds (100%) exhibited Tanimoto similarity < 0.5 to ChEMBL training compounds (median: 0.214), representing 145 unique Murcko scaffolds of which 144 (99.3%) were absent from the training data. This demonstrates that Colombian flora harbors unique chemical scaffolds potentially operating through mechanisms distinct from known anti-dengue agents. This exceptionally high novelty rate—substantially exceeding typical synthetic library screening campaigns—positions Colombia as a potential leader in natural product-based antiviral discovery and highlights the importance of biodiversity conservation for pharmaceutical innovation. Principal component analysis confirmed clear chemical space segregation between novel and training-like compounds, validating the structural distinctiveness of prioritized candidates and suggesting that they may access alternative binding modes or target different viral proteins compared to established inhibitors.

The striking disparity in drug-likeness among high-potency compounds—with only 20 candidates (7.2% of High-Highhits) achieving QED ≥ 0.5—illuminates a fundamental challenge in natural product drug discovery: the inherent tension between evolutionary optimization for biological activity versus pharmaceutical requirements for human therapeutics. This finding underscores the critical importance of multi-criteria optimization strategies and validates our hierarchical filtering approach. Descriptor–activity correlation analysis provided actionable mechanistic insights, revealing that QED positively correlates with EC50 activity (ρ = 0.14), while TPSA negatively correlates (ρ = −0.15), suggesting that moderate polarity optimization and inherent drug-like features favor cellular antiviral efficacy. The differential correlation patterns between IC50 (maximum |ρ| = 0.06) and EC50 (maximum |ρ| = 0.15) endpoints validate the biological distinction between biochemical target inhibition and cellular efficacy, reinforcing the value of our dual-endpoint classification strategy.

The identification of Incartine from Hippeastrum puniceum as the top candidate, exhibiting the highest QED score (0.83) among all prioritized compounds with balanced dual-endpoint activity (pIC50: 6.84, pEC50: 6.13) and structural novelty (Tanimoto: 0.28), provides a compelling lead for immediate experimental validation. The structural diversity among the top 15 candidates—spanning five chemical classes including alkaloids (46.7%), terpenoid glycosides (26.7%), terpenoids (13.3%), flavonoids (6.7%), and steroids (6.7%)—suggests multiple potential mechanisms of antiviral action and offers opportunities for rational combination therapy strategies. Notably, the presence of Lycorine and Pseudolycorine (both with Tanimoto = 1.00) among the top predictions provides crucial internal validation, as these compounds are present in the ChEMBL training dataset with experimentally confirmed anti-dengue activity, increasing confidence in predictions for structurally novel candidates.

The enrichment of Amaryllidaceae alkaloids among the top candidates—with Hippeastrum puniceum contributing two compounds (Incartine #1, Hippeastrine #11) and the family collectively providing four of fifteen prioritized candidates—suggests that this botanical family harbors particularly rich anti-dengue chemical space warranting systematic phytochemical investigation. This finding aligns with emerging evidence of broad-spectrum antiviral properties in Amaryllidaceae alkaloids, exemplified by Lycorine’s demonstrated activity against SARS-CoV-2, influenza, and dengue viruses. The convergence between our computational predictions and traditional medicinal uses, exemplified by the identification of compounds from plants like Psidium guajava and Indigofera suffruticosa with documented ethnopharmacological applications in dengue-endemic regions, underscores the value of integrating indigenous knowledge with modern drug discovery approaches.

Our analysis revealed a critical knowledge gap in Colombian biodiversity research, with 48.6% of the 358 plant species showing documented antiviral activity lacking phytochemical characterization. This represents both an urgent conservation priority and a substantial opportunity for future drug discovery efforts. As Colombia faces dual challenges of increasing dengue burden and accelerating biodiversity loss through deforestation and climate change, the urgency to document and preserve this chemical diversity cannot be overstated. Each lost species potentially represents unique bioactive compounds that could address current and future health challenges, making biodiversity conservation not only an ecological imperative but also a strategic pharmaceutical resource.

The optimization process yielded important methodological insights beyond the immediate anti-dengue application. The 1.9% improvement in MCC through Bayesian optimization, achieved primarily through regularization parameter tuning (reg_alpha: 38.6%, gamma: 33.3% importance), highlights the critical role of controlling model complexity in a high-dimensional chemical space. The decision to select the optimized XGBoost model over the marginally better ensemble (MCC difference = 0.001) exemplifies the practical trade-offs between performance and complexity in applied QSAR modeling, demonstrating that sophisticated ensemble methods may not always justify their computational overhead. These methodological lessons are transferable to other drug discovery campaigns and contribute to the growing body of best practices in computational chemoinformatics.

The tiered prioritization strategy developed in this study—combining dual-endpoint classification, drug-likeness filtering, novelty assessment, and applicability domain validation—provides a replicable framework for natural product virtual screening campaigns. This methodology addresses key limitations of traditional QSAR approaches by explicitly considering multiple pharmacological dimensions, pharmaceutical developability, and prediction reliability. The framework’s modular design enables adaptation to alternative therapeutic targets, different chemical libraries, and varied experimental validation capacities, making it broadly applicable beyond the immediate anti-dengue context.

Immediate research priorities include: (i) in vitro validation of the top 15 candidates through cell-based dengue virus inhibition assays encompassing all four serotypes (DENV-1 to DENV-4); (ii) mechanism of action studies employing target deconvolution approaches to identify specific viral proteins engaged by active compounds; (iii) cytotoxicity and selectivity index determination to assess therapeutic windows; (iv) phytochemical characterization of the 174 understudied antiviral plant species to expand the screening library; and (v) investigation of potential synergistic effects between structurally diverse candidates for combination therapy development. Future computational efforts should focus on developing target-specific QSAR models for individual dengue viral proteins (NS3 protease, NS5 polymerase, envelope protein) to enable mechanism-based prioritization and on implementing approaches capable of predicting synergistic interactions in natural product mixtures, as many traditional preparations rely on multi-component formulations.

This work establishes a replicable methodological framework that can be extended to other neglected tropical diseases endemic to biodiversity-rich regions, including Zika virus, chikungunya, and yellow fever. The integration of computational screening, traditional knowledge, ethnopharmacological databases, and biodiversity informatics presented here offers a sustainable model for pharmaceutical bioprospecting that could benefit both global health and local communities.

In conclusion, this pioneering study not only identifies 15 promising anti-dengue candidates from Colombian flora with exceptional combined profiles of predicted potency (pActivity > 6.0), drug-likeness (QED ≥ 0.5), and structural diversity, but also demonstrates how modern computational approaches integrated with comprehensive SAR analysis can systematically unlock the pharmaceutical potential of megadiverse countries. The predominance of structurally novel chemotypes (100% of High-High compounds with Tanimoto < 0.5, comprising 144 novel scaffolds) establishes Colombian biodiversity as a rich source of potentially innovative antiviral mechanisms, with immediate implications for intellectual property development and positioning Colombia as a potential leader in natural product pharmaceutical discovery. As Colombia continues to face the dual challenges of persistent dengue burden (172.9 cases per 100,000 population) and accelerating biodiversity loss, this research provides both practical solutions for drug discovery and compelling economic incentives for conservation. The convergence of machine learning, structure–activity relationship analysis, ethnopharmacological knowledge, and biodiversity informatics presented here establishes a replicable framework for natural product-based drug discovery, with immediate application potential for dengue and extensibility to other neglected tropical diseases affecting biodiversity-rich regions worldwide.


---

# Machine learning-based screening and validation of pyroptosis-associated prognostic genes and potential drugs in cervical cancer

- **Authors:** Zongchen Hou, Guiju Tang, Hang Chu, Zhengxi Wang, Lufang Wang
- **Issuer:** BMC medical genomics
- **Type:** Scientific article
- **Published:** 2025-11-14
- **Language:** en
- **DOI:** 10.1186/s12920-025-02260-y
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41239481/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Pyroptosis is a newly discovered form of programmed cell death, but its mechanism in the development of cervical cancer has not been elucidated. Cervical cancer differentially expressed pyroptosis-related genes were identified via bioinformatic analysis Gene Expression Omnibus (GEO) dataset GSE7803, GSE9750, GSE63514 and GSE67522. The correlation between the expression of pyroptosis-related genes in normal cervical tissue and cervical cancer tissue was analyzed through the TCGA database. Using LASSO regression algorithm to establish a prediction model for the obtained genes related to pyroptosis. Exploring the functions of differentially expressed genes through GO and KEGG pathway analysis. Using PPI network analysis to screen hub genes, using CIBERSORT method for immune infiltration analysis of prognostic genes, and finally predicting drug-gene interactions in DGIdb database. A total of 19 pyroptosis-related genes were screened from the GEO dataset of cervical cancer tissues, revealing their regulation of endopeptidase activity, inflammation response, positive regulation of cytokine production and cellular response to environmental stimuli. LASSO regression algorithm was used to establish prediction models for 7 of these genes, and 3 pyroptosis-related genes (SPP1, VEGFA, and CXCL8) closely associated with the prognosis of cervical cancer were identified. qRT-PCR confirmed that compared with normal cervical tissue, the expression of SPP1, VEGFA, and CXCL8 was increased in cervical cancer (P<0.05). SPP1, VEGFA, and CXCL8 are most closely related to macrophages, Th2, and neutrophils, respectively. 148 potential targeted drugs targeting key genes were predicted, providing a possible basis for predicting the prognosis and treatment of cervical cancer. Knocking down SPP1 can inhibit cell proliferation and migration in cervical cancer cells in vitro. In conclusion, our study has identified key genes related to pyroptosis in cervical cancer, which potentially become effective clinical prognostic biomarkers, and further research is needed to explore their underlying mechanisms.Supplementary InformationThe online version contains supplementary material available at 10.1186/s12920-025-02260-y.

## Section: Introduction

In the ranking of incidence rate and mortality of female malignant tumors in 2022, cervical cancer ranks fourth after breast cancer, lung cancer and colorectal cancer. It is estimated that there will be about 660,000 new cases and 350,000 deaths worldwide in 2022, which is one of the most harmful malignant tumors to women [1]. 85% of cervical cancer cases occur in developing countries, and this data should be taken seriously by the healthcare departments of these countries [2]. Long term persistent human papillomavirus (HPV) infection is the main risk factor for cervical cancer, but many other genetic factors have also been found to have an impact on the onset of cervical cancer [3]. In 2020, WHO updated the classification of female genital tumors based on new pathological findings, dividing cervical cancer into HPV related and HPV independent tumors. Squamous cell carcinoma is the most common in the former, while it is very rare in the latter. At present, people are committed to searching for biomarkers and targeted drugs that can be used for diagnosis and treatment of cervical cancer at various stages based on the continuously accumulated and updated information in oncology [4].

Cellular pyroptosis is an inflammatory programmed cell death characterized by cell swelling, membrane perforation, and release of cellular contents such as IL-1 β and IL-18. This cell death process is triggered by the activation of caspase-1/4/5/11 proteins by the inflammatory body, especially caspase-1, which can clip gasdermin D protein (GSDMD), leading to the formation of pores on the cell membrane [5, 6]. Cellular pyroptosis has shown great potential in cancer treatment, as not only it promotes anti-tumor immune responses and inhibits tumor proliferation, but also certain drugs and compounds can induce cancer cell pyroptosis, providing new strategies for cancer treatment [7]. However, excessive activation of cell pyroptosis may lead to inflammatory diseases and tumor progression, thus requiring precise control of its activation and regulatory mechanisms [8]. In recent years, an increasing number of studies have shown a close relationship between cervical cancer and pyroptosis. Some studies focus on exploring the prognostic features of pyroptosis in cervical cancer, while others attempt to predict the prognosis and immune microenvironment of cervical cancer through pyroptosis related mechanisms [9, 10]. Therefore, our research aims to identify key targets related to cervical cancer pyroptosis and predict potential therapeutic drugs. Further research on cell pyroptosis may help discover a new treatment strategy for cervical cancer.

In this study, we determined the differential expression profiles of pyroptosis-related genes in normal cervical tissue and cervical cancer tissue through bioinformatics analysis, and found that the differentially expressed genes were enriched in pathways such as inflammation regulation. In addition, we also predicted and analyzed the prognostic genes related to cervical cancer pyroptosis, and based on these genes, predicted drug-gene interactions to screen candidate drugs for cervical cancer treatment. The detailed schematic diagram of the workflow in this study is shown in Fig. 1. In summary, our research may provide more evidence for the diagnosis, prognosis, and treatment of cervical cancer.Fig. 1Schema of the study. Abbreviations: GO, Gene Ontology; KEGG, Kyoto Encyclopedia of Genes and Genomes; PPI, protein–protein interaction; TCGA, The Cancer Genome Atlas; LASSO, Least Absolute Shrinkage and Selection Operator; OS, overall survival; DSS, disease-specific survival; PFS, progression-free survival

Schema of the study. Abbreviations: GO, Gene Ontology; KEGG, Kyoto Encyclopedia of Genes and Genomes; PPI, protein–protein interaction; TCGA, The Cancer Genome Atlas; LASSO, Least Absolute Shrinkage and Selection Operator; OS, overall survival; DSS, disease-specific survival; PFS, progression-free survival

## Section: Materials and methods

GSE datasets referenced in this study

Sequences of primer used for qRT-PCR

## Section: Materials and methods › Acquisition and preprocessing of cervical cancer dataset

This study obtained gene expression data of cervical cancer patients from the GEO database (http://www.ncbi.nlm.nih.gov/geo). A total of 4 datasets (GSE7803, GSE9750, GSE63514, and GSE67522) were selected for subsequent analysis. The four selected datasets are the results of transcriptome analysis of cervical tissue samples from cervical cancer patients, and they systematically cover cervical epithelial tissue samples corresponding to key pathological stages of cervical cancer development, specifically including normal cervical epithelium, cervical intraepithelial neoplasia (CIN), and invasive cervical squamous cell carcinoma tissue. Detailed information on the 4 selected datasets is shown in Table 1. To reduce the false positive rate and thereby enhance the reliability and universality of the prognosis analysis results, and to better approach the real-world patterns, we referred to the RNA-Seq profiles and clinical information from The Cancer Genome Atlas (TCGA) database (available at: https://portal.gdc.cancer.gov/).

Table 1GSE datasets referenced in this studyGSE datasetOrganismSample numberPMIDGSE7803Homo sapiensNormal: 10Tumor: 2117,974,957GSE9750Homo sapiensNormal: 24Tumor: 4218,506,748GSE63514Homo sapiensNormal: 24Tumor: 2826,056,290GSE67522Homo sapiensNormal: 22Tumor: 2028,402,266

GSE datasets referenced in this study

## Section: Materials and methods › Identification of differentially expressed genes related to apoptosis

In addition, this study also obtained information from the GeneCards database (https://www.genecards.org) for research. By retrieving genes related to pyroptosis, we found 831 such genes. With the R package “limma”, we filtered differentially expressed genes (DEGs) from four cervical cancer datasets (GSE7803, GSE9750, GSE63514, GSE67522) using P < 0.05 and |logFC| >1 as thresholds; 55, 224, 156, and 55 DEGs were obtained for each dataset respectively. The Venn diagram intersection method was used to screen out 19 differentially expressed genes from the four datasets, which were related to cervical cancer pyroptosis [11].

## Section: Materials and methods › Correlation analysis

The Pearson correlation analysis was used to calculate and obtain the expression correlation of 19 pyroptosis-related DEGs between all normal samples and cervical cancer samples. The process was completed using the “rcorr” function in the R package “Hmisc” and visualized using the R package “corrplot” [12].

## Section: Materials and methods › LASSO regression

The prediction model of cervical cancer pyroptosis-related genes was constructed using the minimum absolute value shrinkage and selection operator regression algorithm. In the penalty function proposed in this study, as the value of λ increases, the regression coefficient exhibits a continuous convergence behavior and ultimately converges to zero. This study uses λ.1 se as the final equation selection standard to obtain the coefficient, and the selected 7 genes are used for prognostic analysis through the TCGA dataset.

## Section: Materials and methods › Functional enrichment analysis

This study performed Gene Ontology (GO) functional enrichment analysis and Kyoto Encyclopedia of Genes and Genomes (KEGG) pathway analysis, which was implemented by the “clusterProfiler (3.18.1)” R package [13]. In this analysis, the biological processes of crosstalk genes and pyroptosis-related genes in four cervical cancer datasets (GSE7803, GSE9750, GSE63514, GSE67522) were evaluated.

## Section: Materials and methods › Protein-protein interaction (PPI) network analysis

The initial protein interaction network (PPI) can be obtained by importing the differentially expressed genes into the interaction gene search tool (STRING, www.string-db.org). These initial images are not beautiful, so this study uses Cytoscape software (version 3.10.2) to visualize the protein interaction network, and further uses the cytoHubba plug-in of the software to sort the differentially expressed genes in the PPI network by degree centrality value, which increases the information content of the PPI network.

## Section: Materials and methods › RNA extraction and real-time fluorescence quantitative PCR (qRT-PCR)

The RNA of 3 cervical cancer tissues and adjacent tissues was extracted using TRIzol reagent (TaKaRa Company) and reverse transcribed (HiScript® III RT SuperMix Vazyme). The primers were synthesized by Qingke Biotechnology Co., Ltd., and the sequences are shown in Table 2. qRT-PCR was performed on the Step-One Plus real-time fluorescence quantitative PCR instrument (Thermo Fisher Company) using qPCR SYBR Green premix (Vazyme Company). Three biological replicates were performed.

Table 2Sequences of primer used for qRT-PCRGeneForward primer sequencesReverse primer sequencesSPP1CTCCATTGACTCCAACGACTCCAGGTCTGCGAAACTTCTTAGATVEGFATGGCTCACTGGCTTGCTCTAATCCAACTGCACCGTCACAGCXCL8TTGGCAGCCTTCCTGATTTTCAAAAACTTCTCCACAACCCβ-actinCGGGAAATCGTCCGTGACCCGTGTTGGCGTAGAGGT

Sequences of primer used for qRT-PCR

## Section: Materials and methods › Immune infiltration analysis of prognostic genes

The CIBERSORT method was used to analyze the immune infiltration of prognostic genes. This method is a computational method that quantifies the relative proportions of different immune cell subsets in tumor tissues based on gene expression data. After standardizing the prognostic gene data related to cervical cancer pyroptosis, a feature matrix containing marker genes of specific cell types was constructed. Subsequently, the gene expression data and feature matrix were inputted into the CIBERSORT software for computational analysis. This analysis enabled the estimation of the abundance of each immune cell subset in the samples, thereby facilitating the characterization of immune infiltration in tumors.

## Section: Materials and methods › Prediction of drug gene interactions

Given that the Drug-Gene Interaction Database (DGIdb, http://www.dgidb.org/) is rich in content and is a resource that integrates drug-gene interaction information from multiple sources, we used it to predict drug-gene interactions. DGIdb version 5.0 integrates a comprehensive set of resources for drug-gene interaction analysis, including 6 newly incorporated drug-related data sources (ChemIDplus, HemOnc, NCIt, Drugs@FDA, ChEMBL, Wikidata) as well as updated core pharmacological and clinical databases (Guide to Pharmacology, CIViC, PharmGKB, RxNorm); additionally, it leverages genomic annotation resources (HGNC, Ensembl) to standardize gene symbols and ensure consistency of gene-related annotations across different data sources. Because it provides data on the relationship between specific gene variants and drug responses, researchers can quickly identify potential drug targets and biomarkers. Prognostic genes associated with cervical cancer pyroptosis were imported into DGIdb for analysis to explore drugs or small molecule organic compounds associated with them.

## Section: Materials and methods › Cell culture

The human cervical cancer cell lines (HeLa and SiHa) were purchased from the China Type Culture and Preservation Center (Wuhan University, Wuhan, China) and cultured in RPMI-1640 medium (Gibco, USA), which contained 10% fetal bovine serum. Among them, HeLa is a human cervical adenocarcinoma cell line, and SiHa is a human cervical squamous cell carcinoma cell line. All cells were identified by short tandem repeat analysis and maintained in a culture state under a humid environment of 37 °C and 5% CO2.

## Section: Materials and methods › SiRNA transfection

SPP1 small interfering RNA (SPP1-siRNA) was provided by Shanghai Genepharma Co., Ltd. The transfection process was carried out with Lipofectamine 3000 (Invitrogen, USA) in accordance with the manufacturer’s protocol. The transfected cells were harvested and used for subsequent experiments.

## Section: Materials and methods › Cell proliferation detection

The MTT assay kit (Beyotime, Shanghai, China) is used to determine cell viability. Cells in the logarithmic growth phase were inoculated at a density of 1000 cells per well in a 96-well plate and cultured for 24, 48, and 72 h, respectively. Then, MTT solution (0.5 mg/µL) was added and incubated at 37 °C for 4 h. Subsequently, 100 µL of dimethyl sulfoxide (DMSO) was added to separate the crystals and the plate was stirred at 37 °C for 20 min. The absorbance is measured using an enzyme-linked immunosorbent assay (ELISA) reader at 490 nm.

## Section: Materials and methods › Wound healing and transwell assay

In the wound healing assay, cells were first seeded into 6-well culture plates at a density of 3 × 10⁵ cells/well. After siRNA transfection, the cells were cultured for 48 h. After the cells formed a confluent monolayer, a 200 µL pipette tip was used to scratch the cell surface. Images of the wound area were taken at 0 and 24 h using an inverted optical microscope (Olympus, Japan). The wound healing rate was quantified using ImageJ software (version 1.51) and the migration ability of cancer cells was evaluated. In the Transwell assay, 200 µL of serum-free medium containing 5 × 104 cells was added to the upper chamber that was coated (invasion assay) or not coated (migration assay) with Matrigel while 600 µL of complete medium was added to the lower chamber. After incubation at 37 °C for 24 h, cells that migrated or invaded through the 8 μm pore size membrane were fixed with 4% formaldehyde and stained with 0.1% Safranin O. For each sample, the number of migrated or invaded cells was enumerated in five randomly selected microscopic fields under a 200× objective lens. All experiments were repeated three times.

## Section: Materials and methods › Western blot

The total protein was extracted using the previous method and a protein blotting experiment was conducted [14]. The specific antibodies used in this study were rabbit anti-SPP1 antibody (1:1000, ProteTek, Wuhan, China) and mouse anti-GAPDH antibody (1:1000, Cell Signaling Company). GAPDH was used as the sample control. The band intensities were quantitatively analyzed using ImageJ software (version 1.51).

## Section: Materials and methods › Statistical analysis

All statistical analyses were conducted using R (version 4.1.1) and GraphPad Prism 8 software. Univariate and multivariate logistic regression analyses were employed to evaluate the diagnostic value of the predictive model. All statistical analyses were performed using two-tailed statistical tests. Consistent with conventional statistical standards in this field, a P-value < 0.05 was formally defined as the cutoff for identifying a statistically significant difference, ensuring the reliability of intergroup comparison results.

## Section: Results

Determination of pyroptosis-related genes in cervical cancer. A Volcano plot of differentially expressed genes in GSE7803, GSE9750, GSE63514, and GSE67522. The red is the up-regulated differential gene, the blue is the down-regulated differential gene, and the gray is the non-significant gene. B Venn diagrams showing unique and shared genes between cervical cancer and cell pyroptosis

Characteristics and differences of pyroptosis-related genes in cervical cancer. A Venn diagram of the intersection of four cervical cancer datasets (GSE7803, GSE9750, GSE63514, GSE67522) with pyroptosis-related genes. B The positions of 19 cervical cancer pyroptosis-related genes on 23 chromosomes. C Box plot of the expression of 19 cervical cancer pyroptosis-related genes in normal cervical tissue and cervical cancer tissue in the TCGA database. D Heat map of the expression of 19 cervical cancer pyroptosis-related genes in normal cervical tissue and cervical cancer tissue. E The PPI network displays the interaction of genes related to cervical cancer necrosis in TCGA database

Enrichment analysis of pyroptosis-related genes in cervical cancer. KEGG pathway enrichment analysis of genes related to pyroptosis, including GSE7803 (A), GSE9750 (B), GSE63514 (C), and GSE67522 (D)

Correlation analysis of pyroptosis-related genes in cervical cancer. A Correlation analysis and string plot of 19 pyroptosis-related genes in cervical cancer. B Correlation heatmap of 19 pyroptosis-related genes in cervical cancer

Predicting pyroptosis-associated prognostic genes in cervical cancer. A LASSO regression of DEGs related to pyroptosis-associated prognostic genes in cervical cancer. B Cross validation is used to adjust parameter selection in LASSO regression. The overall survival rate, disease-specific survival rate, and progression free survival rate of SPP1 (C), VEGFA (D), and CXCL8 (E)

Immune infiltration analysis of pyroptosis-associated prognostic genes in cervical cancer. The difference in immune infiltration results between high and low expression groups of SPP1 (A), VEGFA (B), and CXCL8 (C) in stacked bar charts. D Correlation heatmap of immune infiltrating cell expression of SPP1, VEGFA, and CXCL8. E-G Rod plot of immune infiltrating cell expression of SPP1, VEGFA, and CXCL8

Structural model diagram and drug gene interaction prediction based on pyroptosis-associated prognostic genes in cervical cancer. Using SWISS-MODEL to predict the folding structure models of SPP1 (A), VEGFA (B), and CXCL8 (C); D. Prediction of drug gene interactions in hub genes

Verification of the crucial pyroptosis-associated prognostic genes in cervical cancer in the signature. A Using qRT-PCR to detect mRNA levels of SPP1, VEGFA, and CXCL8. B Validate the efficiency of SPP1 siRNA by using western blotting. C MTT assay to determine the effect of the proliferation of cervical cancer cells SiHa and HeLa knocked down SPP1. D A scratch assay was used to determine the impact of knockdown of SPP1 on the migration ability of SiHa and HeLa cells. E Transwell assays were used to determine the impact of SPP1 knockdown on the migration ability of SiHa and HeLa cells. P values were shown as: *P < 0.05; **P < 0.01; ***P < 0.001

## Section: Results › Definition of pyroptosis-related genes in cervical cancer

Prior to differential gene analysis, four cervical cancer gene expression datasets (GSE7803, GSE9750, GSE63514, GSE67522) were downloaded from the Gene Expression Omnibus (GEO) database (https://www.ncbi.nlm.nih.gov/geo/). After data normalization and quality control, differential expressed genes were identified by applying two filtering criteria: a statistical significance threshold of P-value < 0.05 and a fold change threshold of |LogFC| >1. GSE7803 identified 864 differentially expressed genes, GSE63514 identified 3687 differentially expressed genes, and GSE67522 identified 1131 differentially expressed genes (Fig. 2A). These genes were then analyzed using the GeneCards database (https://www.genecards.org) by searching for genes related to pyroptosis, 831 genes related to pyroptosis were identified. Four cervical cancer datasets were intersected with the 831 pyroptosis-related genes, resulting in 55, 224, 156 and 55 potential cancer genes respectively (Fig. 2B).Fig. 2Determination of pyroptosis-related genes in cervical cancer. A Volcano plot of differentially expressed genes in GSE7803, GSE9750, GSE63514, and GSE67522. The red is the up-regulated differential gene, the blue is the down-regulated differential gene, and the gray is the non-significant gene. B Venn diagrams showing unique and shared genes between cervical cancer and cell pyroptosis

Determination of pyroptosis-related genes in cervical cancer. A Volcano plot of differentially expressed genes in GSE7803, GSE9750, GSE63514, and GSE67522. The red is the up-regulated differential gene, the blue is the down-regulated differential gene, and the gray is the non-significant gene. B Venn diagrams showing unique and shared genes between cervical cancer and cell pyroptosis

## Section: Results › Characteristics and differences of pyroptosis-related genes in cervical cancer

We used four cervical cancer datasets (GSE7803, GSE9750, GSE63514, GSE67522) to screen for 19 pyroptosis-related genes, including DNMT1, MELK, POLA1, SMC4, EZH2, CDK1, BRCA1, KLF4, AQP1, DEPTOR, KIF23, AIM2, SPP1, KIF11, S100A12, CITED2, IGF2BP3, VEGFA, CXCL8 (Fig. 3A) and showed the chromosomal positions of these 19 cervical cancer pyroptosis-related genes (Fig. 3B). In the TCGA database, we further validated the expression of 19 genes in normal cervical tissue and cervical cancer tissue. The results showed that except for S100A12 and VEGFA, the expression of other genes was significant. Among them, 13 genes including DNMT1, MELK, POLA1, SMC4, EZH2, CDK1, BRCA1, KIF23, AIM2, SPP1, KIF11, IGF2BP3and CXCL8 are highly expressed in cervical cancer tissues, while 4 genes including KLF4, AQP1, DEPTOR, and CITED2 are lowly expressed in cervical cancer tissues (Fig. 3C). We further plotted heatmaps of 19 genes using the TCGA database (Fig. 3D), and then conducted PPI analysis on these 19 genes using the STRING platform to further explore their interactions with cervical cancer pyroptosis-related genes (Fig. 3E).

Fig. 3Characteristics and differences of pyroptosis-related genes in cervical cancer. A Venn diagram of the intersection of four cervical cancer datasets (GSE7803, GSE9750, GSE63514, GSE67522) with pyroptosis-related genes. B The positions of 19 cervical cancer pyroptosis-related genes on 23 chromosomes. C Box plot of the expression of 19 cervical cancer pyroptosis-related genes in normal cervical tissue and cervical cancer tissue in the TCGA database. D Heat map of the expression of 19 cervical cancer pyroptosis-related genes in normal cervical tissue and cervical cancer tissue. E The PPI network displays the interaction of genes related to cervical cancer necrosis in TCGA database

Characteristics and differences of pyroptosis-related genes in cervical cancer. A Venn diagram of the intersection of four cervical cancer datasets (GSE7803, GSE9750, GSE63514, GSE67522) with pyroptosis-related genes. B The positions of 19 cervical cancer pyroptosis-related genes on 23 chromosomes. C Box plot of the expression of 19 cervical cancer pyroptosis-related genes in normal cervical tissue and cervical cancer tissue in the TCGA database. D Heat map of the expression of 19 cervical cancer pyroptosis-related genes in normal cervical tissue and cervical cancer tissue. E The PPI network displays the interaction of genes related to cervical cancer necrosis in TCGA database

## Section: Results › Enrichment analysis of pyroptosis-related genes in cervical cancer

In order to explore the differences in the biological processes of pyroptosis-related genes in cervical cancer, we performed GO and KEGG enrichment (gene set enrichment analysis) on samples obtained from the intersection of four cervical cancer datasets (GSE7803, GSE9750, GSE63514, GSE67522) and pyroptosis-related genes, revealing the regulation of endopeptidase activity, inflammation response, positive regulation of cytokine production, and cellular response to environmental stimuli (Fig. 4A and D).

Fig. 4Enrichment analysis of pyroptosis-related genes in cervical cancer. KEGG pathway enrichment analysis of genes related to pyroptosis, including GSE7803 (A), GSE9750 (B), GSE63514 (C), and GSE67522 (D)

Enrichment analysis of pyroptosis-related genes in cervical cancer. KEGG pathway enrichment analysis of genes related to pyroptosis, including GSE7803 (A), GSE9750 (B), GSE63514 (C), and GSE67522 (D)

## Section: Results › Correlation analysis of pyroptosis-related genes in cervical cancer

We further calculated and analyzed the correlation among the 19 pyroptosis-related genes expressions in normal cervical tissue and cervical cancer samples through the TCGA database (Fig. 5A and B).

Fig. 5Correlation analysis of pyroptosis-related genes in cervical cancer. A Correlation analysis and string plot of 19 pyroptosis-related genes in cervical cancer. B Correlation heatmap of 19 pyroptosis-related genes in cervical cancer

Correlation analysis of pyroptosis-related genes in cervical cancer. A Correlation analysis and string plot of 19 pyroptosis-related genes in cervical cancer. B Correlation heatmap of 19 pyroptosis-related genes in cervical cancer

## Section: Results › Predicting pyroptosis-associated prognostic genes in cervical cancer

We applied 19 genes mentioned above to the LASSO regression algorithm and included 7 genes in the prediction model based on the optimal lambda value (Fig. 6A and B). The risk score is as follows: Risk score = (−0.18106680996544 * POLA1 exp.) + (−0.123503509447933 * KLF4 exp.) + (−0.0457937381093486 * AQP1 exp.) + 4(0.14098424549269 * PP1 exp.) + 5(0.0909218549036766 * CITED2 exp.) + 8(0.1657192995788403 * VEGFA exp.) + 0.1537547581067 * CXCL8 exp.). Based on a comprehensive assessment of the characteristics of high-dimensional gene expression data, statistical stability, and clinical application objectives, we selected genes with λ.1 se that were not zero for subsequent analysis, including SPP1, VEGFA, and CXCL8. This selection approach ensures the reliability of gene predictive value through cross-validation, eliminates redundant information via dimensionality reduction, and establishes a feasible foundation for subsequent experimental validation and clinical translation. The overall survival (OS) and progression-free survival (PFS) of cervical cancer patients with high expression of SPP1 were significantly reduced (Fig. 6C, P = 0.022 and P = 0.039, respectively). The OS and disease-specific survival rate (DSS) of cervical cancer patients with high expression of VEGFA were significantly reduced (Fig. 6D, P = 0.002 and P = 0.010, respectively). The OS, DSS, and PFS of cancer patients with high expression of CXCL8 were significantly reduced (Fig. 6E, P ≤ 0.001, P < 0.001, and P < 0.008, respectively). However, our study has limitations. In the analysis results, the long-term overlap between K-M curves across groups is limited. Factors such as gene-gene interactions, gene-environment interactions, and tumor staging need to be incorporated into the error analysis.

Fig. 6Predicting pyroptosis-associated prognostic genes in cervical cancer. A LASSO regression of DEGs related to pyroptosis-associated prognostic genes in cervical cancer. B Cross validation is used to adjust parameter selection in LASSO regression. The overall survival rate, disease-specific survival rate, and progression free survival rate of SPP1 (C), VEGFA (D), and CXCL8 (E)

Predicting pyroptosis-associated prognostic genes in cervical cancer. A LASSO regression of DEGs related to pyroptosis-associated prognostic genes in cervical cancer. B Cross validation is used to adjust parameter selection in LASSO regression. The overall survival rate, disease-specific survival rate, and progression free survival rate of SPP1 (C), VEGFA (D), and CXCL8 (E)

## Section: Results › Immune infiltration analysis of pyroptosis-associated prognostic genes in cervical cancer

We identified the differences in immune infiltration results between high and low expression groups of SPP1, VEGFA, and CXCL8 in the TCGA database (Figs. 7A-C). The correlation between SPP1, VEGFA, and CXCL8 in immune infiltrating cells (Fig. 7D). The results showed that SPP1, VEGFA, and CXCL8 were most closely related to macrophages, Th2, and neutrophils, respectively (Fig. 7E and G). Fig. 7 Immune infiltration analysis of pyroptosis-associated prognostic genes in cervical cancer. The difference in immune infiltration results between high and low expression groups of SPP1 (A), VEGFA (B), and CXCL8 (C) in stacked bar charts. D Correlation heatmap of immune infiltrating cell expression of SPP1, VEGFA, and CXCL8. E-G Rod plot of immune infiltrating cell expression of SPP1, VEGFA, and CXCL8

Immune infiltration analysis of pyroptosis-associated prognostic genes in cervical cancer. The difference in immune infiltration results between high and low expression groups of SPP1 (A), VEGFA (B), and CXCL8 (C) in stacked bar charts. D Correlation heatmap of immune infiltrating cell expression of SPP1, VEGFA, and CXCL8. E-G Rod plot of immune infiltrating cell expression of SPP1, VEGFA, and CXCL8

## Section: Results › Structural model diagram and drug gene interaction prediction based on pyroptosis-associated prognostic genes in cervical cancer

Through the UniProt database (https://www.uniprot.org/) retrieve the amino acid sequences of SPP1, VEGFA, and CXCL8, and use the SWISS-MODEL method to predict the folding structure models of SPP1, VEGFA, and CXCL8 (Fig. 8A and C). In DGIdb database (http://dgidb.org/). The analysis of drug gene interactions revealed 148 drugs/compounds targeting SPP1, VEGFA, and CXCL8. The top 30 targeted drugs/compounds and their order based on the “interaction group score” in the DGIdb database(Figure.8D).

Fig. 8Structural model diagram and drug gene interaction prediction based on pyroptosis-associated prognostic genes in cervical cancer. Using SWISS-MODEL to predict the folding structure models of SPP1 (A), VEGFA (B), and CXCL8 (C); D. Prediction of drug gene interactions in hub genes

Structural model diagram and drug gene interaction prediction based on pyroptosis-associated prognostic genes in cervical cancer. Using SWISS-MODEL to predict the folding structure models of SPP1 (A), VEGFA (B), and CXCL8 (C); D. Prediction of drug gene interactions in hub genes

## Section: Results › Verification of the crucial pyroptosis-associated prognostic genes in cervical cancer in the signature

Using qRT-PCR further confirmed that compared with normal cervical tissue, the expression of SPP1, VEGFA, and CXCL8 was increased in cervical cancer (P<0.05) (Fig. 9A). It is reported that SPP1 plays an important role in epithelial colorectal cancer, gastric cancer and other tumors [15–17]. Therefore, we focus on further validation of hub genes (SPP1). To validate the biological function of SPP1 in cervical cancer cells, we knocked down SPP1 using siRNA in SiHa and HeLa cells (Fig. 9B). Knockdown of SPP1 by MTT can significantly reduce the proliferation of cervical cancer cells (Fig. 9C). The wound healing rate of SiHa and HeLa cells was significantly inhibited by SPP1 knockdown, as indicated by the results of the wound-healing assay (Fig. 9D). The invasion ability of SiHa and HeLa cells was significantly inhibited in transwell assay following SPP1 knockdown (Fig. 9E). In summary, the results are consistent with our bioinformatics analysis.

Fig. 9Verification of the crucial pyroptosis-associated prognostic genes in cervical cancer in the signature. A Using qRT-PCR to detect mRNA levels of SPP1, VEGFA, and CXCL8. B Validate the efficiency of SPP1 siRNA by using western blotting. C MTT assay to determine the effect of the proliferation of cervical cancer cells SiHa and HeLa knocked down SPP1. D A scratch assay was used to determine the impact of knockdown of SPP1 on the migration ability of SiHa and HeLa cells. E Transwell assays were used to determine the impact of SPP1 knockdown on the migration ability of SiHa and HeLa cells. P values were shown as: *P < 0.05; **P < 0.01; ***P < 0.001

Verification of the crucial pyroptosis-associated prognostic genes in cervical cancer in the signature. A Using qRT-PCR to detect mRNA levels of SPP1, VEGFA, and CXCL8. B Validate the efficiency of SPP1 siRNA by using western blotting. C MTT assay to determine the effect of the proliferation of cervical cancer cells SiHa and HeLa knocked down SPP1. D A scratch assay was used to determine the impact of knockdown of SPP1 on the migration ability of SiHa and HeLa cells. E Transwell assays were used to determine the impact of SPP1 knockdown on the migration ability of SiHa and HeLa cells. P values were shown as: *P < 0.05; **P < 0.01; ***P < 0.001

## Section: Discussion

Pyroptosis is widely recognized as a form of inflammatory programmed cell necrosis. Notably, the N-terminal cleavage fragment of Gasdermin D (GSDMD-NT) exerts a central regulatory role in the pyroptotic process. Activated caspase-1, caspase-3 and granzyme B (GZMB) can catalyze the enzymatic cleavage of GSDMD [18]. Studies have shown that HPV E7 can inhibit the expression of inflammasomes through the E3 protein ligase TRIM21 and promote the degradation of IFI16 inflammasomes, which is not conducive to cell pyroptosis and thus promotes the malignant transformation of cervical cells [19]. By contrast, granzyme B (GZMB) and activated caspase-3 are capable of activating pyroptosis, which is a regulatory mechanism that may represent a promising strategy for tumor immunotherapy. In addition, since advanced cervical cancer is associated with high expression of granzyme B (GZMB) and IL-1β, this provides a reference for the prognostic assessment of cervical cancer [20]. However, the role of pyroptosis-related genes in cervical cancer has not been fully elucidated, and our study aims to reveal this role.

This study, through the screening of differentially expressed genes, a component of tumor transcriptomics research, has elucidated the expression pattern of pyroptosis-related genes in cervical cancer tissues for the first time [21]. We selected four cervical cancer datasets (GSE7803, GSE9750, GSE63514, and GSE67522) from the GEO database, further screened and identified 19 genes related to pyroptosis in cervical cancer cells, and verified them in the TCGA database. Compared with normal cervical tissues, 13 genes (including DNMT1, MELK, POLA1, SMC4, EZH2, CDK1, BRCA1, KIF23, AIM2, SPP1, KIF11, IGF2BP3, and CXCL8) were expressed at higher levels while 4 genes (including KLF4, AQP1, DEPTOR, and CITED2) were expressed at lower levels in cervical cancer tissues. We performed protein interaction analysis on these 19 pyroptosis-related genes and found that the core genes included E2H2, BRCA1, DNMT1, and CDK1. To further explore the differences in biological processes of these 19 cervical cancer pyroptosis-related genes, we performed GO and KEGG enrichment analysis, and the results revealed the enrichment of differentially expressed genes in the regulation of endopeptidase activity, inflammatory response, positive regulation of cytokine production, and cell response to environmental stimuli. The results showed that the enrichment pathways of pyroptosis clusters in different cervical cancer patients were different, which suggests that we should take targeted treatment measures for patients with different expression levels of these pyroptosis-related genes.

Among the many treatment strategies for malignant tumors, inducing tumor cell pyroptosis, has attracted widespread attention due to its good effectiveness. In this treatment process, the immune components in the tumor microenvironment play a crucial regulatory role. Tumor cell pyroptosis can be induced by regulating and changing the functions of immune cells such as cytotoxic T lymphocytes, natural killer cells, tumor-associated macrophages and neutrophils. In cancer immunotherapy of cancer cells and tumor cells, cytotoxic CD8 + T cells play a major role. They induce tumor cell pyroptosis through the granzyme pathway, thereby triggering immune activation [22]. Activated cytotoxic lymphocytes release granzyme A (GZMA) into target cells via perforin-mediated pores; GZMA then directly cleaves gasdermin B (GSDMB) at the Lys244 site within its interdomain linker, activating GSDMB’s pore-forming activity to trigger pyroptosis. This GSDMB-dependent pyroptosis further promotes anti-tumor immune activation [23]. Activated natural killer cells induce tumor cell pyroptosis, effectively triggering the release of intracellular proinflammatory cytokines and rapidly inducing tumor inflammation [24]. Subsequently, CD8 + T cells and natural killer cells play a key role in inducing tumor cell pyroptosis through gasdermin E (GSDME) [25]. One of the important sources of tumor necrosis factor α (TNF-α) in the tumor microenvironment (TME) is macrophages, which can promote cell pyroptosis by secreting TNF-α and activating caspase-8 [26].

We applied the Least Absolute Shrinkage and Selection Operator (LASSO) regression algorithm to construct a prediction model based on 19 differentially expressed genes (DEGs). After feature selection, 7 of these DEGs were retained to develop the final prediction model, which was used to compute the risk score for each sample. Subsequently, we utilized The Cancer Genome Atlas (TCGA) dataset to perform survival prognostic analysis on these 7 genes, and identified that 3 of them, specifically SPP1, VEGFA, and CXCL8, were significantly associated with the prognosis of cervical cancer. Secretory phosphoprotein 1 (SPP1), also known as osteopontin (OPN), early T lymphocyte activation protein 1 (ETA-1), or rickettsial resistance protein (Ric), belongs to the small integrin-binding ligand N-linked glycoprotein (SIBLING) family. SPP1 can specifically bind to and activate matrix metalloproteinases (MMPs), a property that has been confirmed by Su et al. (2020) [27]. Studies have confirmed that in macrophages, the SPP1 gene expression level is high and interacts with cervical epithelial cells through the SPP1-CD44 axis, which plays a key role in tumor progression and is closely related to the poor prognosis of cervical cancer [28, 29]. In patients with acute ischemic stroke, upregulation of recombinant osteopontin (rOPN) expression can mitigate pyroptosis by directly interfering with the oligomerization of apoptosis-related speck-like protein containing CARD [30]. In the process of promoting tumor growth, VEGF-A is involved in the proliferation, migration and survival of new capillary endothelial cells. Specifically, VEGF-A participates in regulating the invasion and migration ability of tumors by binding to vascular endothelial growth factor receptor 1 (VEGFR-1, also known as Flt-1) and VEGFR-2 (also known as Flk-1) [31]. In cervical cancer tissues, the overexpression of CXCL8 is regulated by E6/E7 of HPV 16 and 18, and its expression is positively correlated with the expression of SERPINB3. It mainly forms the CXCL8/CXCR1 and CXCL8/CXCR2 signaling axes by binding to CXCR1 and CXCR2 of the GPCR family, thereby playing an active role in tumor growth, proliferation, metastasis and drug resistance [32, 33].

Currently, clinical pharmacotherapy for cervical cancer follows a stratified approach per the NCCN Guidelines for Cervical Cancer (Version 1.2024): first-line regimens center on platinum-based agents and 5-fluorouracil (5-FU), with pembrolizumab-containing combinations as preferred options for PD-L1-positive recurrent or metastatic disease; second-line agents include gemcitabine, pemetrexed, topotecan, vinorelbine, irinotecan, and newly added preferred options like tisotumab vedotin-tftv (tissue factor-targeted) and cemiplimab (PD-1 inhibitor); additionally, bevacizumab (anti-angiogenic, VEGF-targeted) is used across lines in combination with chemotherapy [3]. This study identified three major pyroptosis-related genes (SPP1, VEGF-A, CXCL8) associated with the prognosis of cervical cancer, and obtained the drug-gene interaction results of these three genes (SPP1, VEGF-A, CXCL8) by searching the DGIdb database, with a total of 148 targeted drugs. Knockdown of SPP1 can inhibit the proliferation and migration of cervical cancer cells in vitro.

In summary, through systematic and comprehensive bioinformatics analysis, we identified key genes associated with cell pyroptosis in cervical cancer patients and predicted up to 148 potential targeted drugs or compounds for these genes. We believe that further exploration of the therapeutic effects of these drugs or compounds on cervical cancer may have positive significance. Due to constraints imposed by certain objective conditions, this study has unavoidable limitations. First, this study did not consider factors that may be related to gene expression, such as the age, incidence, and pathological grade of cervical cancer patients; second, this study should expand the number of genes investigated and incorporate additional relevant in vivo and in vitro experiments; third, the small sample size made it challenging to develop predictive models that accurately correlate SPP1, VEGFA, and CXCL8 expression levels with cervical cancer patients’ survival rates, thus only their correlation with survival was explored.

## Section: Supplementary Information

Supplementary Material 1

Supplementary Material 2.

Supplementary Material 1

Supplementary Material 2.


---

# Machine learning combining external validation to explore the immunopathogenesis of diabetic foot ulcer and predict therapeutic drugs

- **Authors:** Zhongwen Lu, Na An, Shouwei Sheng, Mao Hong, Pin Deng, Junde Wu, Shengji Zhang, Zhaojun Chen
- **Issuer:** PloS one
- **Type:** Scientific article
- **Published:** 2025-08-01
- **Language:** en
- **DOI:** 10.1371/journal.pone.0328906
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40749079/
- **Licence:** CC-BY

## Section: Abstract

AbstractDiabetic foot ulcer (DFU) is a severe complication of diabetes, often leading to amputation due to poor wound healing and infection. The immune-related pathogenesis of DFU remains unclear, and therapeutic drugs are limited. This study aimed to explore the immune mechanisms of DFU and identify potential therapeutic drugs using machine learning and single-cell approaches. Through differential expression analysis of Gene Expression Omnibus (GEO) datasets, we identified 287 differentially expressed genes (DEGs), which were significantly enriched in IL-17 signaling and neutrophil chemotaxis pathways. Weighted gene co-expression network analysis (WGCNA) further pinpointed disease-associated modules containing 1,693 regulatory genes. Machine learning algorithms prioritized seven core genes—CCL20, CXCL13, FGFR2, FGFR3, PI3, PLA2G2A, and S100A8—with validation in an external dataset GSE147890 and single-cell sequencing revealing their predominant expression in neutrophils and keratinocytes. Immune infiltration analysis demonstrated significant dysregulation in DFU patients, characterized by elevated proportions of memory B cells, M0 macrophages, activated mast cells, and neutrophils. Potential therapeutic compounds were identified using the Connectivity Map database and tested through molecular docking and dynamics simulations. The study pinpointed selegiline, L-BSO, flunisolide, PP-30, and fluocinolone as promising therapeutic agents, offering new insights into the pathogenesis of diabetic foot ulcers (DFU) and potential therapeutic strategies.

## Section: 1 Introduction

Diabetic foot ulcer (DFU) is a common and severe complication of diabetes, with a global prevalence of approximately 6.3% [1]. The lifetime risk of developing a DFU is as high as 25% [2]. Furthermore, patients with DFU face a significantly higher risk of non-traumatic lower limb amputation, which is 15–40 times greater than that of the general population [3]. The quality of life and survival rates for DFU patients after amputation are notably reduced. Previous studies [4,5] have reported a 5-year mortality rate for diabetic foot amputees ranging from 50% to 68%, which is even higher than that observed in some cancer patients. Additionally, the 10-year survival rate post-amputation is only 24% [6], highlighting the severe health risks posed by DFU to individuals worldwide. Wound healing in diabetic foot ulcers (DFU) is a complex biological process, with immunoinflammatory regulation playing a pivotal role at various stages of chronic wound healing [7]. Neutrophils are the first inflammatory cells to migrate to the wound site, where they help eliminate pathogens through multiple mechanisms and initiate both inflammatory and non-inflammatory responses [8]. Macrophages, which are crucial in the healing process, can influence wound repair depending on their polarization state (M1 or M2 macrophages) [9,10]. Additionally, chronic hyperglycemia in diabetic patients leads to oxidative stress and persistent inflammation, which weakens the immune response and increases the risk of foot infections [11]. Thus, exploring strategies to enhance the therapeutic effect of DFU by modulating the immune response could provide more effective treatments for patients.

In the clinical management of DFU, blood glucose monitoring and control are essential components of treatment. Intensive blood glucose control has been shown to delay the onset and slow the progression of complications such as retinopathy, nephropathy, and neuropathy in insulin-dependent diabetic patients [12]. Hyperglycemia in diabetic patients induces immunosuppression by impairing both innate and adaptive immune responses. Specifically, neutrophil and macrophage dysfunction compromises pathogen clearance, while dysregulated T-cell and B-cell activity hinders adaptive immunity. These immunological disturbances collectively diminish tissue repair capacity and promote ulcer formation while impairing wound healing. Furthermore, concomitant immunosuppressive conditions—including dialysis, organ transplantation, or immunosuppressive therapy—exacerbate immune dysfunction, potentially elevating the risk of therapeutic failure in diabetic foot ulcer management [13]. Dressing materials play a key role in protecting DFU wounds by shielding them from contaminants while promoting the absorption of exudate. The effectiveness of AQAg silver dressings has been particularly demonstrated in two areas: significantly reducing ulcer depth and managing infected ulcers that require antibiotic treatment [14]. The treatment of DFU requires a multifaceted approach, including the exploration of novel compounds with potential therapeutic effects and the establishment of guidelines for drug use, thus providing more treatment options for clinical practice. Based on this knowledge, our study employed bioinformatics methods to obtain gene expression data from DFU patients and healthy controls in the GEO database. Weighted gene co-expression network analysis (WGCNA) and machine learning techniques were applied to identify immune-related markers. Additionally, through Gene Ontology (GO), Kyoto Encyclopedia of Genes and Genomes (KEGG), and Gene Set Enrichment Analysis (GSEA) enrichment analyses, key pathways associated with DFU were identified, and immune infiltration in DFU was assessed using the Cell Identification By Estimating Relative Subsets Of RNA Transcripts (CIBERSORT) algorithm. Targeted compounds were predicted using the Connectivity Map database, molecular docking and dynamic simulations were employed to further validate the results. This approach aims to provide valuable insights for the clinical treatment of DFU. The research process is illustrated in Fig 1.

## Section: 2 Method › 2.1 Data downloading and processing

Three original datasets (GSE134431, GSE199939, and GSE147890) were obtained from the Gene Expression Omnibus (GEO) database. GSE134431, utilizing the GPL18573 platform, contained 13 DFU patients and 8 skin tissues of diabetic patients; GSE199939, using the GPL24676 platform, included 10 Diabetic Foot Skin and 11 Non-Diabetic Foot Skin; GSE147890, based on the GPL571 platform, comprised 6 models of diabetic foot ulcer transplanted from human skin to mice and 7 models of normal human skin transplanted to mice.We annotated the probes in each dataset and converted them to standard gene names using the corresponding platform annotation files. We merged the expression profiles of the GSE134431 and GSE199939 datasets into a single training set. Batch effects were then adjusted using the ‘sva’ package to prepare for subsequent WGCNA and machine learning analyses. After standardization and normalization of the datasets, differential expression analysis between DFU and control samples was performed using the “limma” R package. Volcano plots and heatmaps were generated using the “ggplot2” package and the Heatmap function, respectively, to visualize significantly regulated genes.

## Section: 2 Method › 2.2 Pathway enrichment analysis of Gene Ontology (GO) and Kyoto Encyclopedia of Genes and Genomes (KEGG)

A total of 287 differentially expressed genes (DEGs) were submitted to the Metascape database for Gene Ontology (GO) and Kyoto Encyclopedia of Genes and Genomes (KEGG) enrichment analysis, with the species set as “Homo sapiens” and the significance threshold set at P < 0.01. Using -log10(P value) as the selection criterion, the top 10 enriched terms in biological process (BP), cellular component (CC), and molecular function (MF) of the GO analysis, as well as the top 10 enriched pathways in KEGG, were visualized using bubble charts generated by R software.

## Section: 2 Method › 2.3 Acquisition of immune-related genes

The ImmPort database, one of the most authoritative human immune gene resources, was used to acquire immune-related gene sets. Immune-related gene data was downloaded from the ImmPort database (https://www.immport.org/home). After removing duplicate genes, a total of 1,793 immune-related genes (IRGs) were obtained for further analysis.

## Section: 2 Method › 2.4 Weighted gene co-expression network analysis (WGCNA) and identification of core modules

WGCNA is a widely used approach for modular analysis, designed to identify complex disease biomarkers or potential drug targets, uncover highly correlated gene expression patterns, and offer new insights into the underlying mechanisms of diseases. In this study, the “WGCNA” package in R software was employed to construct the co-expression network [15]. The analysis was based on the top 10,000 most variable genes from the combined dataset, with a minimum of 100 genes required for each module. The adjacency matrix was then transformed into a Topological Overlap Matrix (TOM), and multiple gene modules were identified through hierarchical clustering. To assess the association between each module and clinical features, gene significance (GS) and module membership (MM) were calculated. These metrics were used to evaluate the correlation and relevance of individual genes within the biological modules and their relationship with clinical traits. Key modules and genes with high clinical relevance were selected for further analysis.

## Section: 2 Method › 2.5 Building prediction models based on multiple machine learning methods

Machine learning is one of the most commonly used tools for processing high-dimensional complex data. The R packages “glmnet,” “caret,” “Boruta” and “XGBoost” were used to build a machine learning model, using 6 machine learning algorithms including: Random Forest [16] (RF)algorithm, support vector machine-recursive feature elimination [17] (SVM-RFE)algorithm, K-Nearest Neighbors [18] (KNN) algorithm, Neural Network [19] (NNET) algorithm, least absolute shrinkage and selection operator (LASSO) and decision tree(DT)algorithm was used to predict the feature genes,the accuracy of a model is assessed, and key genes are selected for subsequent analysis.

## Section: 2 Method › 2.6 Independent validation analysis of machine learning

Seven key genes associated with DFU were identified by intersecting the top-ranked genes from three machine learning models. To visualize the distribution and variability of these genes, we generated gene expression boxplots. The discriminatory power of these genes was evaluated using receiver operating characteristic (ROC) curves for both the training and test datasets. We employed the R package “rms” (version 6.3.0) to construct a Nomogram model, utilizing data from the GSE5281 and GSE132903 training sets. The predictive performance of this Nomogram was then assessed using the GSE147890 dataset as an independent external validation cohort. To thoroughly evaluate the model’s performance, we plotted calibration curves, ROC curves, and Decision Curve Analysis (DCA) curves for both the training and test sets, thereby providing a comprehensive assessment of its predictive accuracy and potential clinical utility.

## Section: 2 Method › 2.7 Single-cell sequencing analysis

Process the data with the Seurat package and perform PCA analysis. Next, apply the t-SNE algorithm and UMAP (Uniform Manifold Approximation and Projection) for clustering analysis, dimensionality reduction, and cell visualization. Finally, annotate the cell clusters using the Celldex package. Finally, extract marker genes for each cell subtype from the single-cell expression profile using the threshold options of logfc.FindAllMarkers. Select immune-related genes screened by machine learning as the unique marker genes for each cell subtype.

## Section: 2 Method › 2.8 Gene set enrichment analysis

Gene Set Enrichment Analysis (GSEA) uses the ‘GSEA’ package to elucidate the biological significance of characteristic genes. To achieve a standardized enrichment score for each analysis, 1000 permutations of the gene set were performed. A false discovery rate (FDR) < 0.05 indicates significant enrichment.

## Section: 2 Method › 2.9 Evaluation of abundance and expression differences of immune cell subtypes

Cibersort deconvolution algorithm was used to analyze the abundance and correlation of immune infiltrating cells. The Cibersort method mainly relies on the expression matrix of 22 immune cell subtypes, which is qualitatively and quantitatively analyzed using CiberSort R script. Based on the analysis results of Cibersort, the correlation between the feature genes and the types of immune cells was analyzed. The corrplot package was used to plot the graph with P < 0.05 as the screening criterion.

## Section: 2 Method › 2.10 Cmap database predicts potential drugs

A promising drug screening tool is the Connectivity Map (CMap; https://clue.io/) database. The database can predict molecularly targeted drugs based on DEGs. Intersection genes of differential and immune-related genes were imported into a database that uses the L1000 analysis platform to explore networks of drugs/small molecule compounds, genes, and disease states. In this study, we used gene expression profiles and the CMap database to predict possible chemical agents to treat DFU [20]. The results suggest that interfering with the function of specific genes has potential therapeutic effects, as the expression patterns of the corresponding genes are diametrically opposed to the disease-specific expression patterns.

## Section: 2 Method › 2.11 Molecular docking verification

Molecular docking is a computational method used to predict the binding pose and affinity between proteins and ligands. For molecular docking, the 3D structures of active ingredients were obtained from the ChemSpider database (https://www.chemspider.com/). These structures were then energy-minimized using Chem3D and stored in “.pdb” format. Core genes, including CCL20 (PDB ID: 5UR7), CXCL13 (PDB ID: 5CBA), FGFR2 (PDB ID: 3RI1), FGFR3 (PDB ID: 8UDT), PI3 (PDB ID: 6ATU), PLA2G2A (PDB ID: 3U8D), and S100A8 (PDB ID: 5HLO), were retrieved from the PDB database (http://www.rcsb.org/). Using PYMOL software, water molecules and original ligands were removed from the core target proteins, and missing residues were repaired with Chimera (version 1.16). After adding hydrogen atoms and calculating the charge with Autodock, both the receptor proteins and selected compounds were saved in PDBQT format. The binding site for molecular docking was optimized by adjusting the central coordinates and docking protein size. The docking of core receptor proteins with molecule ligands was performed using Autodock Vina. For each molecular docking, 50 conformations were generated, and the best conformation was selected based on binding energy and binding site location. The final docking results were presented as heatmaps, with lower binding energy indicating a stronger affinity between the key target and core active ingredients. The interactions between the compounds and proteins were visualized using PYMOL software. Additionally, docking results were compared with reference drugs or inhibitors to assess the reliability of the predictions.

## Section: 2 Method › 2.12 Molecular dynamics simulation

Molecular dynamics (MD) simulations of the ligand-receptor complex were performed using GROMACS (version 2022.2). The protein topology file was generated using the AMBER99SB-ILDN force field, and the ligand topology file was generated with the ACPYPE script utilizing the AMBER force field. The system was placed in a triclinic box, filled with TIP3P water molecules, and periodic boundary conditions were applied. Neutralization of the system was achieved by adding NaCl counter ions. Before the MD simulation, we performed energy minimization for approximately 1000 steps and then equilibrated the system using NVT and NPT ensembles for about 100 ps each.Finally, we get the Root Mean Square Deviation (RMSD), Root Mean Square Fluctuation (RMSF),Radius of Gyration(Rg) and H-bond results of these complexes. The data is visualized using Origin software.

## Section: 2 Method › 2.13 Ethical approval declarations

The Gene Expression Omnibus (GEO) database is publicly accessible, and ethical approval has been obtained for all patients included in the dataset. Users are free to download the data for research purposes and to publish related findings. Since our study utilized open-source data, no ethical concerns or conflicts of interest arise.

## Section: 3 Results

(A)The principal component analysis (PCA) displaying a distinct profile between GSE134431 and GSE199939. (B) The volcano plot showing upregulated (Red) and downregulated (Blue) DEGs. (C) Clustering analysis and heatmap of the DEGs between DFU and control groups.

(A-C) The bubble plots of the GO enrichment of DEGs, including biological process, cellular component, and molecular function. (D) The Sankey diagram showing the KEGG enrichment analysis of DEGs.

(A) The selection of optimal soft thresholding power. (B) Gene dendrogram and modules. Gene modules associated with DFU were shown in different colors under the gene dendrogram. (C) The correlation heatmap representing the relationship between different gene modules and status of DFU. (D-E) Scatter plots showing the correlation between module membership (MM) and gene significance (GS) in the red and brown modules. WGCNA, weighted gene co-expression network analysis.

(A) Intersection of the differentially expressed genes and immune-related genes. (B) The cumulative residual distribution of the six models. (C) Residual Boxplots of the six machine learning models, where the red dots indicate the root mean square of the residuals. (D) ROC analysis of six machine learning models with fivefold cross-validation in the test set. (E) The important features in RF, SVM, KNN, NNET, LASSO and DT.

(A) Intersection of the three machine learning outcomes. (B) Gene expression boxplots for 7 feature genes. (C) ROC curve of 7 feature genes (The left is the training set and the right is the test set). (D) The diagnostic nomogram based on 7 feature genes. (E) Calibration curve to evaluate the accuracy of the nomogram(The left is the training set and the right is the test set). (F)ROC of the validation Gene Expression Omnibus (GEO) data set(The left is the training set and the right is the test set).(G) Decision curve of feature genes nomogram (The left is the training set and the right is the test set).

(A) Cellular subtypes of Diabetic foot ulcer. (B), (C) Scatter plots and bubble plot of the expression of the 7 hub genes.

GO and KEGG enrichment analysis using GSEA for the gene PI3 and S100A8, including enriched in high expression group and low expression group.

(A) The stacked bar plot representing the different immune cell proportions in each sample. (B) The heatmap showing the correlation between different immune cells. Red represented a positive correlation, while blue represented a negative correlation. (C) The boxplot depicting the comparison of 22 types of immune cells between DCM and control groups.

(A) Ranking and scoring of drugs in the CMap database. (B) The molecular structure of drugs.

(A) Binding energy results of molecular docking. (B) Presentation of molecular docking results.

(A) The RMSD plot of the PLA2G2A and naftopidil complex, PLA2G2A and PP-30 complex and FGFR3 and AZD-8055 complex. (B) The Rg plot of the PLA2G2A and naftopidil complex, PLA2G2A and PP-30 complex and FGFR3 and AZD-8055 complex. (C) The RMSF plot of the PLA2G2A and naftopidil complex, PLA2G2A and PP-30 complex and FGFR3 and AZD-8055 complex. (D) The number of hydrogen bonds in the PLA2G2A and naftopidil complex, PLA2G2A and PP-30 complex and FGFR3 and AZD-8055 complex.

## Section: 3 Results › 3.1 Identification of DEGs in DFU

The GSE134431 dataset was based on the GPL18573 platform, including 13 DFU samples and 8 control samples. The GSE199939 dataset is based on the GPL24676 platform, including 10 DFU samples and 11 control samples. The probes in each dataset are annotated, the expression data from the GSE5281 and GSE132903 datasets were combined into a single training set, with genes standardized according to the corresponding platform annotation files. Batch effects were then corrected using the SVA package to adjust for potential confounding variables (Fig 2A). After pretreatment and batch effect removal, a total of 287 differentially expressed genes (DEGs) were identified using the criteria of |logFC| > 1 and P < 0.05. Among these, 227 genes were up-regulated and 60 were down-regulated in DFU samples, as shown in the heatmap (Fig 2B) and volcano plot (Fig 2C).

(A)The principal component analysis (PCA) displaying a distinct profile between GSE134431 and GSE199939. (B) The volcano plot showing upregulated (Red) and downregulated (Blue) DEGs. (C) Clustering analysis and heatmap of the DEGs between DFU and control groups.

## Section: 3 Results › 3.2 GO function and KEGG pathway enrichment analysis

The analysis revealed 690 enriched GO terms and 44 KEGG pathways. The GO enrichment analysis showed that the significantly enriched biological processes mainly focused on inflammatory responses, neutrophil chemotaxis, cellular responses to lipids, and related biological processes (Fig 3A); the enriched cellular components were related to extracellular matrix, lipid droplets, and mitochondrial outer membranes, etc. (Fig 3B); the key molecular functions included cytokine activity, chemokine receptor binding, and heparin binding, etc. (Fig 3C). The KEGG pathway analysis further indicated that the main enriched pathways were the IL-17 signaling pathway, cytokine-cytokine receptor interaction, MAPK signaling pathway, etc. (Fig 3D), comprehensively revealing the multi-dimensional roles of differentially expressed genes in inflammatory regulation, cell structure composition, and signal transduction. Detailed results of GO and KEGG enrichment can be found in S1 File.

(A-C) The bubble plots of the GO enrichment of DEGs, including biological process, cellular component, and molecular function. (D) The Sankey diagram showing the KEGG enrichment analysis of DEGs.

## Section: 3 Results › 3.3 Construction and module identification of co-expression network

As shown in Fig 3A, the optimal soft threshold is 12. At this point, the R² value in Fig 4A (left) is approximately 0.9. Using this soft threshold, the gene modules related to DFU were identified through the hybrid dynamic shear tree algorithm (Fig 4B). The top 10,000 genes with the highest degree of variation were clustered, and a total of 17 co-expression modules were formed (Fig 4C). The Pearson correlation analysis showed that all modules were significantly correlated with clinical characteristics. Among them, the brown module (correlation coefficient 0.58, P < 0.01) and the red module (correlation coefficient 0.62, P < 0.01) had stronger correlations (Fig 4C). Significance analysis and module membership analysis indicated that the genes in the brown module (correlation coefficient 0.52, P < 0.01) and the red module (correlation coefficient 0.58, P < 0.01) had high correlations with their respective modules. Therefore, the brown and red modules were determined as key modules, and 1693 genes were selected for further research (Fig 4D and 4E).

(A) The selection of optimal soft thresholding power. (B) Gene dendrogram and modules. Gene modules associated with DFU were shown in different colors under the gene dendrogram. (C) The correlation heatmap representing the relationship between different gene modules and status of DFU. (D-E) Scatter plots showing the correlation between module membership (MM) and gene significance (GS) in the red and brown modules. WGCNA, weighted gene co-expression network analysis.

## Section: 3 Results › 3.4 Construction of the models

A total of 61 genes were identified through the intersection of the differentially expressed genes and immune-related genes (Fig 5A). Six machine learning algorithms were employed to model these 61 genes: Random Forest (RF), Support Vector Machine-Recursive Feature Elimination (SVM-RFE), K-Nearest Neighbors (KNN), Neural Network (NNET), Least Absolute Shrinkage and Selection Operator (LASSO), and Decision Tree (DT). The residual distribution results for the six models are presented in Fig 5B. Fig 5C ranks the top 10 significant feature variables for each model based on the root mean square error. The ROC curves reveal that the AUC values for the RF, SVM, and KNN models are all 1.000(Fig 5D), indicating they achieved perfect classification performance. The most important features identified by these models are shown in Fig 5E. Based on these results, we selected the RF, SVM, and KNN models for further analysis.

(A) Intersection of the differentially expressed genes and immune-related genes. (B) The cumulative residual distribution of the six models. (C) Residual Boxplots of the six machine learning models, where the red dots indicate the root mean square of the residuals. (D) ROC analysis of six machine learning models with fivefold cross-validation in the test set. (E) The important features in RF, SVM, KNN, NNET, LASSO and DT.

## Section: 3 Results › 3.5 Validation analysis of machine learning

The top 30 feature importance genes from three machine learning models were intersected, resulting in the identification of the 7 most critical genes (Fig 6A). Gene expression boxplots for these genes were generated using the R package “ggpubr” (Fig 6B). Next, we obtained the individual rating scales of these 7 feature genes in the training set and test set, and quantitatively evaluated their performance using the ROC curve, as shown in Fig 6C (the left is the training set and the right is the test set). Subsequently, we used the R package “rms” to construct the Nomogram model based on the training set data GSE5281 and GSE132903 (Fig D). To evaluate the performance of the Nomogram model, we adopted GSE147890 as an independent external validation set. The calibration curves, ROC curves and Decision Curve Analysis (DCA) curves of the training set and the test set were plotted, as shown in Figs E, F and G. The calibration curve shows that the error between the actual clustering risk of diabetic foot ulcer and the predicted risk is relatively small, and the Nomogram prediction probability is relatively close to the ideal model (Fig E). ROC analysis indicated that it had a discriminative ability with medium to high confidence (Fig F). Finally, the DCA curve analysis indicated that using nomogram for decision-making could bring clinical benefits (Fig 6G), which reflected the significant importance of these seven characteristic genes for the diagnosis and treatment of diabetic foot ulcer.

(A) Intersection of the three machine learning outcomes. (B) Gene expression boxplots for 7 feature genes. (C) ROC curve of 7 feature genes (The left is the training set and the right is the test set). (D) The diagnostic nomogram based on 7 feature genes. (E) Calibration curve to evaluate the accuracy of the nomogram(The left is the training set and the right is the test set). (F)ROC of the validation Gene Expression Omnibus (GEO) data set(The left is the training set and the right is the test set).(G) Decision curve of feature genes nomogram (The left is the training set and the right is the test set).

## Section: 3 Results › 3.6 Overview of hub gene expression in single cells

The single-cell data of GSE248247 was downloaded and analyzed using the Seurat package. Clustering of cells was performed using the tSNE algorithm and UMAP (Uniform Manifold Approximation and Projection), and each cluster was annotated using the R package SingleR. All cells were categorized into six groups: keratinocytes, adipocytes, fibroblasts, erythroid cells, neutrophils, and endothelial cells (Fig7A). Fig7B and 7C displays the expression levels of CCL20, CXCL13, FGFR2, FGFR3, PI3, PLA2G2A, and S100A8 across the six cell types.The results showed that the key pathogenic genes of diabetic foot ulcer were mainly involved in keratinocytes and neutrophils.

(A) Cellular subtypes of Diabetic foot ulcer. (B), (C) Scatter plots and bubble plot of the expression of the 7 hub genes.

## Section: 3 Results › 3.7 Single-gene GSEA of characteristic genes

The results of the Gene Set Enrichment Analysis (GSEA) revealed that these markers are involved in multiple pathways associated with the occurrence and progression of DFU. These pathways primarily include myeloid leukocyte migration, granulocyte migration, epidermal cell differentiation, intermediate filament organization, keratinocyte differentiation, extracellular matrix structural constituent, collagen catabolic process, epidermis development, neutrophil chemotaxis, skin development, specific granule membrane, secretory granule membrane, antimicrobial humoral response, detection of stimuli involved in sensory perception, collagen-containing extracellular matrix, receptor complex formation, translation factor activity, RNA binding, and tertiary granule formation. These pathways are all likely closely linked to the immune regulation mechanisms in DFU, the PI3 and S100A8 results were shown in the Fig 8 and the CCL20, CXCL13, FGFR2, FGFR3, and PLA2G2A GSEA analysis diagrams are shown in S2 File.

GO and KEGG enrichment analysis using GSEA for the gene PI3 and S100A8, including enriched in high expression group and low expression group.

## Section: 3 Results › 3.8 Immune infiltration analysis

The CIBERSORT algorithm was used to evaluate the immune cell abundance in DFU patients and controls. A barplot was generated to visualize the proportions of immune cells in each sample, as shown in Fig 9A. The results showed that, compared to normal tissue, DFU patient tissue had a lower proportion of naive B cells, resting mast cells, and M2 macrophages. In contrast, the proportion of memory B cells, M0 macrophages, activated mast cells, and neutrophils was higher in DFU tissue compared to the control group (Fig 9C). Additionally, correlation analysis (Fig 9B) of the 22 immune cell types revealed significant positive correlations between resting mast cells and resting dendritic cells (r = 0.81, p < 0.05), and between resting mast cells and activated mast cells (r = 0.78, p < 0.05). Conversely, negative correlations were observed between resting NK cells and activated NK cells (r = −0.88, p < 0.05), and between M0 macrophages and resting dendritic cells (r = −0.77, p < 0.05). The detailed results obtained by the CIBERSORT algorithm can be found in S3 File.

(A) The stacked bar plot representing the different immune cell proportions in each sample. (B) The heatmap showing the correlation between different immune cells. Red represented a positive correlation, while blue represented a negative correlation. (C) The boxplot depicting the comparison of 22 types of immune cells between DCM and control groups.

## Section: 3 Results › 3.9 Screening potential drugs in the CMap database

We submitted 61 immune-related genes with differential expression to the Connectivity Map database to identify potential therapeutic compounds. The results showed that the gene expression profiles were negatively correlated with the effects of several drugs, including selegiline, L-BSO, flunisolide, PP-30, and fluocinolone. This suggests that these drugs may help alleviate or even reverse the disease state. The top 15 drugs, ranked by CMap score, are presented in Fig 9A. Additionally, the molecular structures of some of the predicted drugs are shown in Fig 10B. The detailed drug information predicted by the CMap Database can be found in S4 File.

(A) Ranking and scoring of drugs in the CMap database. (B) The molecular structure of drugs.

## Section: 3 Results › 3.10 Molecular docking

According to receptor-ligand docking theory, docking energy is inversely proportional to binding affinity, meaning that more negative docking energies indicate stronger binding between the protein and the ligand. The results of the molecular docking analysis are shown in the Fig 11A. The six pairs of compounds and proteins with the best binding affinities are: FGFR2 and AZD-8055, FGFR2 and flunisolide, FGFR2 and PP-30, FGFR3 and AZD-8055, PLA2G2A and naftopidil, and PLA2G2A and PP-30. The docking data for these six compound-protein pairs were imported into Pymol software for visualization to analyze the interactions between the compounds and the proteins, as shown in the Fig 11B. The binding energy values for the six central therapeutic targets and their corresponding active compounds were all less than −5 kcal/mol, with at least one hydrogen bond formed between the protein and the ligand. This suggests that these compounds exhibit strong binding affinity with the key therapeutic targets and can effectively exert anti-DFU effects. Based on the above screening criteria, the key active ingredients for the treatment of DFU were identified as PP-30, AZD-8055, and flunisolide. Detailed results of molecular docking can be found in S5 File.

(A) Binding energy results of molecular docking. (B) Presentation of molecular docking results.

## Section: 3 Results › 3.11 Molecular dynamics simulation

As shown in Fig 12A, the three combinations—PLA2G2A protein with naftopidil, PLA2G2A protein with PP-30, and FGFR3 protein with AZD-8055—demonstrate strong binding affinity and stable docking, and they were selected for molecular dynamics simulations. From the simulation results, the root mean square deviation (RMSD) of the molecules remains stable, while the RMSD of the protein-ligand complex fluctuates initially but stabilizes during the middle phase and exhibits only minor fluctuations towards the end (Fig 12A). As depicted in Fig 12B, the radius of gyration (Rg) of the complex remains stable, indicating that the overall structure of the complex is compact and robust. Additionally, root mean square fluctuation (RMSF), which reflects the residue-level flexibility of the complex, shows in Fig 12C that PLA2G2A and naftopidil, as well as PLA2G2A and PP-30, exhibit greater residue flexibility. Hydrogen bonding is a strong non-covalent interaction. The number of hydrogen bonds in the PLA2G2A and naftopidil, PLA2G2A and PP-30 complex was 0–3 in 0–100 ns (Fig 12D); and the maximum number of hydrogen bonds FGFR3 and AZD-8055 complex was 4. The hydrogen bond between the ligand and the receptor helps maintain the stability of the complex. Detailed results of dynamics can be found in S6–S9 Files.

(A) The RMSD plot of the PLA2G2A and naftopidil complex, PLA2G2A and PP-30 complex and FGFR3 and AZD-8055 complex. (B) The Rg plot of the PLA2G2A and naftopidil complex, PLA2G2A and PP-30 complex and FGFR3 and AZD-8055 complex. (C) The RMSF plot of the PLA2G2A and naftopidil complex, PLA2G2A and PP-30 complex and FGFR3 and AZD-8055 complex. (D) The number of hydrogen bonds in the PLA2G2A and naftopidil complex, PLA2G2A and PP-30 complex and FGFR3 and AZD-8055 complex.

## Section: 4 Discussion

Diabetic foot ulcer (DFU) is a common and serious complication for individuals with diabetes, significantly impacting their quality of life and survival rates. Each year, around 18.6 million people with diabetes worldwide develop foot ulcers [21]. It is estimated that up to 34% of individuals with either type 1 or type 2 diabetes will experience foot ulcers at some point during their lifetime [22]. Moreover, about 20% of those with diabetic foot ulcers will require lower limb amputations, ranging from partial amputation (such as part of the foot) to more severe cases (such as amputations above the ankle) [23]. The financial burden of diabetic foot ulcers is substantial, highlighting the urgent need for research into more effective treatments. Current clinical approaches primarily include wound care, debridement of necrotic tissue, offloading pressure from the affected area, infection management with appropriate antibiotics, and comprehensive care [24]. However, these methods have significant limitations, frequently resulting in unsatisfactory clinical outcomes for patients.

In recent years, clinical studies have shown that the development of DFU is closely linked to immune factors, with many patients exhibiting varying degrees of immune dysfunction [25]. Tailored interventions based on the severity of the disease are crucial for improving treatment outcomes and prognosis. Some studies have indicated that the systemic immunoinflammatory index (SII) is associated with the severity of DFU in patients [26]. Thus, it is crucial to explore the pathogenesis of DFU from an immune perspective and to identify potential therapeutic agents.

Based on the GO and KEGG enrichment analysis of this study, it was found that the occurrence of DFU is related to pathways such as inflammatory response and neutrophil chemotaxis, while DFU are characterized by impaired wound healing, chronic inflammation, and a heightened risk of infection, with neutrophils playing a central role in the inflammatory phase of wound healing. The chronic hyperglycemic state typical of diabetes impairs neutrophil chemotaxis, leading to prolonged inflammation and disrupting the delicate balance required for effective wound healing. This exacerbates both inflammation and tissue damage, ultimately hindering the healing process of diabetic foot ulcers [27]. DFU is a chronic wound maintained by pathological fibroblasts and an abnormal extracellular matrix (ECM). The ECM, a complex three-dimensional network, provides both the physical scaffold for cells and the environment necessary for cell adhesion, growth, migration, and differentiation. It plays a crucial role in wound repair [28]. The activity of cytokines plays a crucial role in the development of DFU. Tumor necrosis factor-α (TNF-α) is a potent pro-inflammatory cytokine, while B cell activating factor (BAFF) is a member of the TNF-α superfamily. BAFF levels are positively correlated with TNF-α, interferon family cytokines such as IFN-α2, IL-28A/IFN-λ2, IFN-γ, and IL-10 family cytokines such as IL-19, IL-22, and IL-26. Conversely, BAFF is negatively correlated with the IL-6 receptor family, including gp130/sIL-6Rβ. Studies have shown that reducing BAFF activity can promote the healing of DFU wounds [29]. IL-17, another important pro-inflammatory cytokine, is critical in the inflammatory phase of skin healing. Research has demonstrated that IL-17 accelerates wound closure in obese mice by reducing the presence of inflammatory macrophages. This finding underscores the significant role of the IL-17 pathway in wound healing, which could offer new avenues for therapeutic intervention in DFU management [30]. In the context of bilayered living cellular constructs, the presence of fibroblasts and keratinocytes has been shown to promote epithelial stratification, enhance tensile strength, regulate the expression of cytokines and growth factors, and improve angiogenic properties. These mechanisms collectively support the healing process of DFU, ensuring more effective wound closure and tissue regeneration [31]. During the inflammatory phase of wound healing, mast cells play a crucial role by recruiting neutrophils to the injury site and secreting cytokines that activate tissue-resident macrophages. In the proliferative phase, mast cells further contribute to wound healing by promoting fibroblast proliferation through the secretion of IL-4, VEGF, and basic fibroblast growth factor (bFGF). These factors stimulate the formation of granulation tissue, facilitate cell migration, support angiogenesis, and enhance collagen maturation, ultimately accelerating the healing process of DFU [32].

Currently, no specific drugs are available to treat DFU effectively. The management of DFU typically involves blood glucose control to slow the progression of diabetes, along with surgical debridement to remove necrotic tissue. Additional strategies commonly used to prevent infection and slow DFU progression include abscess drainage, infection-preventing dressings, and bacteriological treatments [33]. A recent study describes a double-layer antibacterial collagen scaffold with enhanced structural stability and antimicrobial properties. The scaffold consists of an epidermal antibacterial collagen layer and a collagen-glycosaminoglycan matrix, specifically designed to prevent wound infections. This dressing effectively inhibits bacterial growth while promoting vascular regeneration [34]. Furthermore, studies have shown that the use of cellulose/collagen dressings can significantly increase the rate of wound healing. Due to their ability to promote angiogenesis and accelerate re-epithelialization, these dressings are particularly effective in treating refractory diabetic foot ulcers (DFUs). The benefits of cellulose/collagen dressings have been confirmed in clinical practice and trials [35].

Bioinformatics is an interdisciplinary field that integrates biology, mathematics, and information science. It involves the acquisition, processing, storage, analysis, and interpretation of biological data through the application of diverse methods and tools from multiple disciplines. By utilizing different algorithms, bioinformatics allows for the efficient analysis of large datasets and the extraction of clinically relevant information. This approach offers valuable insights into disease research and treatment [36].The application of bioinformatics methods to predict potential therapeutic drugs has opened up new treatment strategies for DFU in clinical practice and provided a new approach for the development of clinical drugs.

In this study, machine learning techniques were used to identify seven genes associated with DFU: CXCL13, PLA2G2A, S100A8, FGFR2, PI3, CCL20, and FGFR3. Among these, the expression of the CXCL13 gene was found to be elevated in DFU patients, and this gene was associated with immune response modulation [37]. S100A8 is significantly upregulated in patients with DFU [38], contributing to persistent wound inflammation and impairing the healing process [39]. Moreover, S100A8 is closely associated with the immune system, being highly expressed in the cytoplasm of neutrophils, where it plays a role in inducing neutrophil activation [40].

The results of single-cell analysis indicated that the core genes were mainly located in neutrophils and keratinocytes, Immune infiltration analysis demonstrated significant dysregulation in DFU patients, characterized by elevated proportions of memory B cells, M0 macrophages, activated mast cells, and neutrophils.

Researches show that, Keratinocytes are involved in immune responses and are very active in wound healing and angiogenesis processes. Studies have shown that impaired keratinocyte function, particularly in producing angiogenic factors, can delay the healing of diabetic foot ulcer (DFU) wounds. This finding has significant implications for DFU treatment [41].Neutrophils are a type of white blood cell that plays a significant role in the occurrence and development of DFU. In diabetes, hyperglycemia impairs neutrophil function, preventing effective participation in wound healing. This prolongs the inflammatory phase and delays recovery [42]. Studies have shown that compared with normal tissues, DFU patients have a higher proportion of M0 macrophages and activated mast cells in their tissues [43]. Moreover, the results of immune infiltration indicate that the proportion of neutrophils in the wounds of DFU patients increases. It has been shown that diabetes can induce dysfunction and disorders of neutrophils, thereby affecting the healing of DFU wounds [44].These findings indicate that immunity plays a crucial role in the pathogenesis of DFU, consistent with earlier research.

Through the screening of the Cmap database, selegiline, L − BSO, flunisolide, PP − 30, fluocinolone, Ibuprofen, naftopidil, AZD − 8055, TPCA−1 and SKF-86002 were identified as potential drugs for the treatment of DFU. Ibuprofen, one of the most commonly used nonsteroidal anti-inflammatory drugs (NSAIDs), is a non-selective inhibitor of cyclooxygenase (COX-2), an enzyme involved in prostaglandin synthesis [45]. However, systematic administration of ibuprofen can lead to adverse effects, such as reduced kidney function or gastrointestinal bleeding [46]. Clinical studies by Jorgensen et al. [47], Gottrup et al. [48], and Sibbald et al. [49] have demonstrated that dressings containing ibuprofen (Bitan-Ibu, Coloplast A/S, Humlebaek, Denmark) can significantly reduce pain without hindering wound healing. Adding ibuprofen to dressings has been shown to be particularly effective in treating infected and painful wounds [50]. Additionally, as an NSAID, ibuprofen can influence neutrophil function and lymphocyte proliferation [51]. AZD-8055 is a potent inhibitor targeting the mammalian target of rapamycin (mTOR), a critical regulator of cellular processes such as growth and metabolism. AZD-8055 has been shown to induce apoptosis in various cell lines [52]. Activation of the mTOR pathway effectively promotes both wound healing and skin regeneration [53]. Some studies have demonstrated that downregulating YAP phosphorylation and activating mTOR signaling prevents fibroblast senescence and accelerates skin wound healing in diabetic mice [54]. TPCA-1 is a novel anti-inflammatory compound that plays a significant role in modulating immune responses and inflammatory processes. By inhibiting NF-κB activation, TPCA-1 reduces the secretion of pro-inflammatory cytokines, such as tumor necrosis factor-alpha (TNF-α) and interleukin-6 (IL-6), thereby attenuating local inflammation and promoting wound healing [55,56]. Selegiline (L-deprenyl), a monoamine oxidase-B inhibitor, has been found to improve glucose homeostasis, regulate lipid metabolism, and exert anti-inflammatory effects, all of which may positively influence wound healing in patients with DFU [57]. Selegiline also reduces oxidative stress, protects the blood-brain barrier [58], and mitigates the imbalance of free radicals and antioxidants that often occurs in diabetic patients. This imbalance leads to excessive production of reactive oxygen species (ROS), which damages cells and tissues, delaying wound healing. By reducing ROS levels through its antioxidant properties, selegiline may help accelerate the healing process [59]. Additionally, selegiline has immune-modulatory effects, which can alter the phagocytic activity of blood cells, further impacting the immune response [60]. L-BSO (L-buthionine sulfoximine), an inhibitor of glutathione synthesis, increases intracellular oxidative stress, which can promote apoptosis and tissue damage [61]. In diabetic patients, heightened oxidative stress is closely associated with the development of DFU. Thus, the use of L-BSO may aid in improving the healing of diabetic foot ulcers. Interestingly, L-BSO also plays a role in regulating immune function. In the tumor microenvironment, L-BSO has been shown to enhance anti-tumor immune responses by modifying immune cell infiltration, which may contribute to improved therapeutic outcomes [62]. The development of DFU is influenced by a variety of factors, including neuropathy, vascular disease, and infection [63]. SKF-86002 is a compound that reduces inflammation by inhibiting p38α/β [64], which can help mitigate the risk of infection by modulating the inflammatory response. This mechanism offers promising new insights for the treatment of DFU.

However, there are some limitations in this study. Due to the limited number of machine learning training sets in this study and so many genes were used for modeling, an AUC value of 1 occurred. Therefore, we used external datasets for independent validation to ensure the universality of the model, to enhance the accuracy of machine learning models, additional DFU samples should be included in future research. While this paper identifies potential drugs for treating diabetic foot ulcer, clinical trials have not yet been conducted to evaluate their clinical significance. Therefore, in the future, we will conduct research on clinical efficacy and safety based on this.

## Section: 5 Conclusion

This study provides a comprehensive investigation into the immunological mechanisms underlying diabetic foot ulcer (DFU) through bioinformatics approaches. By integrating gene expression data and immune-related gene analysis, we identified key biomarkers and pathways involved in DFU pathogenesis. The application of various machine learning algorithms enabled the selection of immune-related markers with strong potential for clinical application, as evidenced by their discriminatory power in ROC curve analysis and validation with external datasets. And the single cell analysis reveals cluster of cells. Furthermore, our exploration of immune cell infiltration and pathway enrichment offered deeper insights into the disease’s immune landscape. Notably, the study identified promising therapeutic candidates, including selegiline, PP-30, and naftopidil, through drug screening and molecular docking studies, suggesting their potential as novel treatments for DFU. These findings contribute to a better understanding of DFU biology and open new avenues for therapeutic intervention, ultimately improving patient outcomes and reducing the burden of DFU.

## Section: Supporting information

(XLSX)

(ZIP)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

## Section: Acknowledgments

We thank all members of the team for their great support.

## Section: Data Availability

Our raw datasets can be obtained in the GEO database (https://www.ncbi.nlm.nih.gov/geo/), in this study we use datasets: GSE134431, GSE199939 and GSE147890.

## Section: Funding Statement

Zhaojun Chen (Z.C.) as the corresponding author, provided the Beijing Natural Science Foundation (Grant No. 7252229) and the "New Drug Research and Development" Cultivation Project of the Third Affiliated Hospital of Beijing University of Chinese Medicine (Grant No. BZYSY-2022-XYYF-22), and provided overall guidance and supervision, and played a key role in the interpretation of the results and manuscript preparation.Mao Hong (M.H.) provided the project of Beijing Traditional Chinese Medicine Science and Technology Development Fund (Approval Number: BJZYQN-2023-09).

## Section: Associated Data

(XLSX)

(ZIP)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

## Section: Associated Data › Supplementary Materials

(XLSX)

(ZIP)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

(XLSX)

## Section: Associated Data › Data Availability Statement

Our raw datasets can be obtained in the GEO database (https://www.ncbi.nlm.nih.gov/geo/), in this study we use datasets: GSE134431, GSE199939 and GSE147890.


---

# Machine Learning-Driven Identification of Exosome-Related Genes in Head and Neck Squamous Cell Carcinoma for Prognostic Evaluation and Drug Response Prediction

- **Authors:** Hua Cai, Liuqing Zhou, Yao Hu, Tao Zhou
- **Issuer:** Biomedicines
- **Type:** Scientific article
- **Published:** 2025-03-23
- **Language:** en
- **DOI:** 10.3390/biomedicines13040780
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40299352/
- **Licence:** CC-BY

## Section: Abstract

Background: This study integrated four Gene Expression Omnibus (GEO) datasets to identify disease-specific feature genes in head and neck squamous cell carcinoma (HNSCC) through differential expression analysis with batch effect correction. Methods: The GeneCards database was used to find genes related to exosomes, and samples were categorized into groups with high and low expression levels based on these feature genes. Functional and pathway enrichment analyses (GO, KEGG, and GSEA) were used to investigate the possible biological mechanisms underlying feature genes. A predictive model was produced by using machine learning algorithms (LASSO regression, SVM, and random forest) to find disease-specific feature genes. Receiver operating characteristic (ROC) curve analysis was used to assess the model's effectiveness. The diagnostic model showed excellent predictive accuracy through external data GSE83519 validation. Results: This analysis highlighted 22 genes with significant differential expression. A predictive model based on five important genes (AGRN, TSPAN6, MMP9, HBA1, and PFN2) was produced by using machine learning algorithms. MMP9 and TSPAN6 showed relatively high predictive performance. Using the ssGSEA algorithm, three key genes (MMP9, AGRN, and PFN2) were identified as strongly linked to immune regulation, immune response suppression, and critical signaling pathways involved in HNSCC progression. Matching HNSCC feature gene expression profiles with DSigDB compound signatures uncovered potential therapeutic targets. Molecular docking simulations identified ligands with high binding affinity and stability, notably C5 and Hoechst 33258, which were prioritized for further validation and potential drug development. Conclusions: This study employs a novel diagnostic model for HNSCC constructed using machine learning technology, which can provide support for the early diagnosis of HNSCC and thus contribute to improving patient treatment plans and clinical management strategies.
