# Toward expert-level medical question answering with large language models

- **Authors:** Karan Singhal, Tao Tu, Juraj Gottweis, Rory Sayres, Ellery Wulczyn, Mohamed Amin, Le Hou, Kevin Clark, Stephen R Pfohl, Heather Cole-Lewis, Darlene Neal, Qazi Mamunur Rashid, Mike Schaekermann, Amy Wang, Dev Dash, Jonathan H Chen, Nigam H Shah, Sami Lachgar, Philip Andrew Mansfield, Sushant Prakash, Bradley Green, Ewa Dominowska, Blaise Agüera Y Arcas, Nenad Tomašev, Yun Liu, Renee Wong, Christopher Semturs, S Sara Mahdavi, Joelle K Barral, Dale R Webster, Greg S Corrado, Yossi Matias, Shekoofeh Azizi, Alan Karthikesalingam, Vivek Natarajan
- **Issuer:** Nature medicine
- **Type:** Scientific article
- **Published:** 2025-01-08
- **Language:** en
- **DOI:** 10.1038/s41591-024-03423-7
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39779926/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractLarge language models (LLMs) have shown promise in medical question answering, with Med-PaLM being the first to exceed a ‘passing’ score in United States Medical Licensing Examination style questions. However, challenges remain in long-form medical question answering and handling real-world workflows. Here, we present Med-PaLM 2, which bridges these gaps with a combination of base LLM improvements, medical domain fine-tuning and new strategies for improving reasoning and grounding through ensemble refinement and chain of retrieval. Med-PaLM 2 scores up to 86.5% on the MedQA dataset, improving upon Med-PaLM by over 19%, and demonstrates dramatic performance increases across MedMCQA, PubMedQA and MMLU clinical topics datasets. Our detailed human evaluations framework shows that physicians prefer Med-PaLM 2 answers to those from other physicians on eight of nine clinical axes. Med-PaLM 2 also demonstrates significant improvements over its predecessor across all evaluation metrics, particularly on new adversarial datasets designed to probe LLM limitations (P < 0.001). In a pilot study using real-world medical questions, specialists preferred Med-PaLM 2 answers to generalist physician answers 65% of the time. While specialist answers were still preferred overall, both specialists and generalists rated Med-PaLM 2 to be as safe as physician answers, demonstrating its growing potential in real-world medical applications.Subject terms: Health care, Medical research

## Section: Main

Language is at the heart of health and medicine, underpinning interactions between people and care providers. Progress in LLMs has enabled the exploration of medical domain capabilities in artificial intelligence (AI) systems that can understand and communicate using language, promising richer human–AI interaction and collaboration. In particular, these models have demonstrated impressive capabilities on multiple-choice research benchmarks1–3.

The advent of transformers4 and LLMs5,6 has renewed interest in the possibilities of AI for medical question-answering tasks—a long-standing ‘grand challenge’7–9. A majority of these approaches involve smaller language models trained using domain-specific data (BioLinkBert10, DRAGON11, PubMedGPT12, PubMedBERT13, BioGPT14), resulting in steady improvements in performance on benchmark datasets such as MedQA (United States Medical Licensing Examination (USMLE))15, MedMCQA16 and PubMedQA17.

The rise of larger general-purpose LLMs such as GPT-3 (ref. 18) and Flan-PaLM19,20 trained on internet-scale corpora with massive computing infrastructure has seen leapfrog improvements on such benchmarks within a few months (Fig. 1). In particular, GPT-3.5 (ref. 3) reached an accuracy of 60.2% on the MedQA (USMLE) dataset, Flan-PaLM reached an accuracy of 67.6% and GPT-4-base2 achieved 86.1%.

In parallel, application protocol interface (API) access to the GPT family of models spurred several studies evaluating the specialized clinical knowledge in these models, without specific alignment to the medical domain. Levine et al.21 evaluated the diagnostic and triage accuracies of GPT-3 for 48 validated case vignettes of both common and severe conditions and compared to laypeople and physicians. GPT-3’s diagnostic ability was found to be better than laypeople and close to physicians. On triage, performance was less impressive and closer to laypeople. Similarly, GPT-3 performance in genetics, surgery and ophthalmology was studied in refs. 22–24, respectively. Ayers et al.25 compared ChatGPT and physician answers on 195 randomly drawn patient questions from a social media forum and found ChatGPT answers to be rated higher in both quality and empathy.

In our previous work on Med-PaLM, we demonstrated the importance of a wide-ranging benchmark for medical question answering, detailed human evaluation of model answers and alignment strategies in the medical domain1. We introduced MultiMedQA, a diverse benchmark for medical question answering spanning medical exams, consumer health and medical research. We proposed a human evaluation rubric enabling physicians and laypeople to perform detailed assessment of model answers. Our initial model, Flan-PaLM, achieved strong performance across multiple-choice benchmarks. However, human evaluation revealed further work was necessary to ensure factual long-form answers aligned with human values and expectations in this safety-critical domain (a process generally referred to as ‘alignment’). We developed Med-PaLM, resulting in substantially improved physician evaluations over Flan-PaLM. However, evaluation on these benchmarks was limited as a measure of practical utility in real-world workflows, and key shortfalls remained compared to physician answers.

Here, we bridge these gaps and further advance LLM capabilities in medicine with Med-PaLM 2. We developed this model using a combination of an improved base LLM (PaLM 2; ref. 26), medical domain-specific fine-tuning and new prompting strategies to improve reasoning and grounding, including ensemble refinement and chain of retrieval. Med-PaLM 2 improves upon Med-PaLM by over 19% on MedQA, as depicted in Fig. 1, and approached or exceeded previous state-of-the-art performance on MedMCQA, PubMedQA and MMLU clinical topics datasets.

While these benchmarks are a useful measure of the knowledge encoded in LLMs, they do not capture a model’s ability to generate factual, safe answers to questions that require nuanced answers, typical in real-world medical question answering. We study this by expanding our evaluation framework for physicians and laypeople1. We introduce two additional human evaluations: a pairwise ranking evaluation of model and physician answers to consumer medical questions along nine clinically relevant axes; and physician assessment of model answers on two recently introduced adversarial testing datasets27 designed to probe the limits of LLMs.

Finally, we study the practical utility of Med-PaLM 2 for bedside consultations. In a pilot study, we answer real-world medical questions submitted by specialist physicians to a consultation service during routine care delivery28,29. Answering these questions is nontrivial: in the consultation service, a team of physicians analyzed aggregate patient data to provide a written report. Compared to answers from specialist and generalist physicians, answers from Med-PaLM 2 using chain of retrieval are comparable to or better than generalists’ answers but remain inferior to specialists’ answers. These results suggest that, as model performance approaches a human level, evaluation with highly specialized experts becomes crucial, and current models may have utility in supporting information needs of medical staff where access to specialist physicians is limited.

Our key contributions are summarized as follows: (1) We developed Med-PaLM 2, a medical LLM trained using an updated base model (PaLM 2; ref. 26) and targeted medical domain-specific fine-tuning. (2) We introduced ‘ensemble refinement’ as a prompting strategy to improve LLM reasoning. (3) We described ‘chain of retrieval’, a step-by-step pipeline using search as a tool that enables Med-PaLM 2 to answer difficult medical research questions by grounding its claims in relevant sources. (4) Med-PaLM 2 achieved state-of-the-art results on several MultiMedQA multiple-choice benchmarks, including MedQA USMLE-style questions, improving upon Med-PaLM performance by over 19% (Table 1). (5) Building upon our previous work1, we incorporated several key enhancements to the human evaluation framework. These include new adversarial and bedside consultation datasets, as well as a pairwise ranking system that compares model responses directly with those of human physicians. (6) Human evaluation of long-form answers to consumer medical questions showed that Med-PaLM 2’s answers were preferred to physician and Med-PaLM answers across eight of nine axes relevant to clinical utility, such as factuality and low likelihood of harm (Figs. 2 and 3). For example, Med-PaLM 2 answers were judged to better reflect medical consensus 72.9% of the time compared to physician answers (Fig. 1). (7) We introduced two adversarial question datasets to probe the safety and limitations of these models. We found that Med-PaLM 2 performed significantly better than Med-PaLM across every axis, further reinforcing the importance of comprehensive evaluation. For instance, answers had low risk of harm for 90.6% of Med-PaLM 2 answers, compared to 79.4% for Med-PaLM (Fig. 2 and Supplementary Table 4). (8) For real-world questions that arose during care delivery, specialists preferred Med-PaLM 2 answers over generalist physician answers 65% of the time, while generalists preferred them equally. Model answers remained inferior to specialist answers; both specialists and generalists preferred specialist answers about 60% of the time. Specialists and generalists viewed Med-PaLM 2 answers to be as safe as physician answers (Fig. 4).

a, Med-PaLM 2 achieved an accuracy of 86.5% on USMLE-style questions in the MedQA dataset. The shaded region highlights the reported performance of models developed after Med-PaLM 2. b, In a pairwise ranking study on n = 1,066 consumer medical questions, Med-PaLM 2 answers were preferred over physician answers by a panel of physicians across eight of nine axes in our evaluation framework. Stacked bars represent proportions of answers for which physician raters preferred Med-PaLM 2 answers (orange), answers generated by other physicians (blue) or ties (light blue). Error bars reflect 95% confidence intervals of the overall preference rates for physician and Med-PaLM 2 answers, as determined by clustered bootstrapping computed over all 1,066 paired ratings.

Comparison of Med-PaLM 2 results to reported results from GPT-4

Values are the proportion of ratings across answers where each axis was rated in the highest-quality bin. (For instance, ‘Possible harm extent = no harm’ reflects the proportion of answers where the extent of possible harm was rated ‘No harm.’) Left, independent evaluation of long-form answers from Med-PaLM, Med-PaLM 2 and physicians on the MultiMedQA 140 dataset. Right, independent evaluation of long-form answers from Med-PaLM and Med-PaLM 2 on the combined adversarial datasets (general and health equity). Detailed breakdowns are presented in Supplementary Tables 3 and 4. Error bars reflect 95% confidence intervals as determined by bootstrapping, centered on the mean proportions.

Med-PaLM 2 answers are consistently preferred over Med-PaLM answers by physician raters across all ratings dimensions, in both MultiMedQA (a) and adversarial (b) question sets. Stacked bars represent proportions of answers for which physician raters preferred Med-PaLM 2 answers (orange), Med-PaLM 1 answers (green) or ties (light blue). Error bars reflect 95% confidence intervals as determined by bootstrapping, centered on preference rates for Med-PaLM 2 and Med-PaLM, respectively, across n = 1,066 paired ratings. Detailed breakdowns for adversarial questions are presented in Supplementary Table 4.

a, Three-way ranking results for model, generalist and specialist answers by plurality of raters. Top bars show specialist raters, and bottom bars show generalist raters (11× replication per question). Both groups of physicians preferred specialist answers the most, and both preferred model answers more often than generalist answers. b, Pairwise ranking results for model, generalist and specialist answers, averaged over raters. Top bars, generalist raters; bottom bars, specialist raters (11× replication per question). Both groups of physicians preferred specialist answers over model answers. Specialists preferred model answers over generalist answers, while generalists rated them about equally.

## Section: Results

Table 1 and Supplementary Table 1 summarize Med-PaLM 2 results on MultiMedQA multiple-choice benchmarks. Unless specified otherwise, Med-PaLM 2 refers to the unified model trained on the mixture in Extended Data Table 1. We also include comparisons to GPT-4 (refs. 2,30). We note that comparisons to GPT-4 are not straightforward because it is a proprietary system and we are not able to measure overlap of the evaluation data with the model’s training data as we did for Med-PaLM 2 in Table 2.

Multiple-choice question evaluation

Med-PaLM 2 performance on multiple-choice questions with and without overlap

## Section: Results › MedQA

Our unified Med-PaLM 2 model reaches an accuracy of 85.4% using ER as a prompting strategy. Our best result on this dataset is 86.5%, obtained from a version of Med-PaLM 2 not aligned for consumer medical question answering, but instead instruction fine-tuned only on MedQA.

## Section: Results › MedMCQA

On MedMCQA, Med-PaLM 2 obtains a score of 72.3%, exceeding Flan-PaLM performance by over 14% but slightly short of previous state-of-the-art performance (73.66 from GPT-4-base30).

## Section: Results › PubMedQA

On PubMedQA, Med-PaLM 2 obtains a score of 75.0%. This is below the state-of-the-art performance (81.0 from BioGPT-Large14) and is likely because no data were included for this dataset for instruction fine-tuning. However, after further exploring prompting strategies for PubMedQA on the development set, the unified model reached an accuracy of 79.8% with a single run and 81.8% using self-consistency (11×). The latter result was state of the art, although we caution that PubMedQA’s test set is small (500 examples), and remaining failures of Med-PaLM 2 and other strong models appear to be largely attributable to label noise intrinsic in the dataset (especially given human performance is 78.0%17).

## Section: Results › MMLU clinical topics

On MMLU clinical topics, Med-PaLM 2 significantly improves over previously reported results in Med-PaLM1 and exceeds previous state-of-the-art performance on three out six topics, with GPT-4-base reporting better numbers in the other three. We note that the test set for each of these topics is small, as reported in Extended Data Table 1.

We see a drop in performance between GPT-4-base and the aligned (production) GPT-4 model on these multiple-choice benchmarks (Table 1). Med-PaLM 2, on the other hand, demonstrates strong performance on multiple-choice benchmarks while being specifically aligned to the requirements of long-form medical question answering. While multiple-choice benchmarks are a useful measure of the knowledge encoded in these models, we believe human evaluations of model answers along clinically relevant axes are necessary to assess their utility in real-world clinical applications.

We also see in Supplementary Table 1 that ensemble refinement improves on few-shot and self-consistency prompting strategies in eliciting strong model performance across these benchmarks.

## Section: Results › Overlap analysis

Overlap percentages ranged from 0.9% for MedQA to 48.0% on MMLU Medical Genetics. Performance of Med-PaLM 2 was slightly higher on questions with overlap for six out of nine datasets, though the difference was only statistically significant for MedMCQA (accuracy difference 4.6%, [1.3, 7.7]) due to the relatively small number of questions with overlap in most datasets (Table 2). When we reduced the overlap segment length from 512 to 120 characters (Methods), overlap percentages increased (11.15% for MedQA to 56.00% on MMLU Medical Genetics), but performance differences on questions with overlap were similar (Supplementary Table 2), and the difference was still statistically significant for just one dataset. These results are similar to those observed in ref. 19, which also saw minimal performance difference from testing on overlapping data. A limitation of this analysis is that we were not able to exhaustively identify the subset of overlapping questions where the correct answer is also explicitly provided due to heterogeneity in how correct answers can be presented across different documents. Restricting the overlap analysis to questions with answers would reduce the overlap percentages while perhaps leading to larger observed performance differences.

## Section: Results › Independent evaluation

On the MultiMedQA 140 dataset, physicians rated Med-PaLM 2 answers as generally comparable to physician-generated and Med-PaLM-generated answers along the axes we evaluated (Fig. 2 and Supplementary Table 3). This analysis was largely underpowered for the effect sizes (differences) observed, without significant differences when applying Bonferroni correction for multiple comparisons. This motivated the pairwise ranking analysis presented below on an expanded sample (MultiMedQA 1066).

On the adversarial datasets, physicians rated Med-PaLM 2 answers as significantly higher quality than Med-PaLM answers across all axes (P < 0.001 for all axes; Supplementary Table 4). This pattern held for both the general and health equity-focused subsets of the adversarial dataset.

Finally, laypeople rated Med-PaLM 2 answers to questions in the MultiMedQA 140 dataset as more helpful and relevant than Med-PaLM answers (P ≤ 0.002 for both dimensions; Supplementary Fig. 3 and Supplementary Table 5).

Notably, Med-PaLM 2 answers were longer than Med-PaLM and physician answers (Supplementary Table 13). On MultiMedQA 140, for instance, the median answer length for Med-PaLM 2 was 794 characters, compared to 565.5 for Med-PaLM and 337.5 for physicians. Answer lengths to adversarial questions tended to be longer in general, with a median answer length of 964 characters for Med-PaLM 2 and 518 characters for Med-PaLM, possibly reflecting the greater complexity of these questions.

## Section: Results › Pairwise ranking evaluation

Pairwise ranking evaluation more explicitly assessed the relative performance of Med-PaLM 2, Med-PaLM and physicians. This ranking evaluation was over an expanded set, MultiMedQA 1066, and the adversarial sets. Qualitative examples and their rankings are included in Supplementary Tables 8 and 9, respectively, to provide indicative examples and insight.

On MultiMedQA, for eight of the nine axes, Med-PaLM 2 answers were more often rated as being higher quality compared to physician answers (all P < 0.001 for each of the separate comparisons; Fig. 1 and Supplementary Table 6). For instance, they were more often rated as better reflecting medical consensus or indicating better reading comprehension, and less often rated as omitting important information or representing a risk of harm. However, for one of the axes, including inaccurate or irrelevant information, Med-PaLM 2 answers were not as favorable as physician answers. Med-PaLM 2 answers were rated as higher quality than Med-PaLM axes on the same eight axes (Fig. 3 and Supplementary Table 7); Med-PaLM 2 answers were marked as having more inaccurate or irrelevant information less often than Med-PaLM answers (18.4% Med-PaLM 2 versus 21.5% Med-PaLM), but the difference was not significant (P = 0.12).

On adversarial questions, Med-PaLM 2 was ranked more favorably than Med-PaLM across every axis (Fig. 3), often by substantial margins.

## Section: Results › Three-way utility ranking

We present results for three-way ranking of model, generalist and specialist answers in Fig. 4a. For generalist rankings, given 11 rankings per question, we determine plurality ranking per question across raters. We observe that specialist answers perform best across both generalist and specialist raters, but that Med-PaLM 2 answers appear to perform comparably or better to generalist answers for both groups of raters, with more answers most preferred and second preferred than for generalist raters. In Fig. 4b, we plot pairwise rankings between models and generalists and models and specialists for both groups of raters, averaged across all raters. We observe that both groups prefer specialist answers over model answers (about 60% preference), but that specialists prefer model answers over generalist answers (65% preference). Generalists prefer model answers and generalist answers about equally, suggesting that as, model performance approaches the human level, evaluation with highly specialized experts may be important in distinguishing model performance from human performance.

## Section: Results › Individual evaluation of harm

In Supplementary Tables 14 and 15, we present results for harm evaluation for each answer from the model, generalists and specialists. We observe that a majority of generalist physicians find that answers across all three answer sources are not harmful, but at an 80% agreement threshold for harmlessness, a few questions from each source are flagged. At this threshold, 16 of 20 Med-PaLM 2 answers are harmless, while 17 of 20 generalist answers are harmless, and 15 of 20 specialist answers are harmless. For specialist physicians (one rater per answer), 17 of 20 model answers were harmless, 19 of 20 generalist answers and 18 of 20 specialist answers. Interestingly, across both rating groups, a few physician answers were flagged as potentially harmful, indicating the challenging and subjective nature of evaluating harm. Overall, the results do not suggest a substantial difference in harmfulness across model, generalist and specialist answers.

## Section: Discussion

We show that Med-PaLM 2 exhibits strong performance in multiple-choice, consumer long-form and bedside consultation medical question answering, including popular benchmarks, challenging adversarial datasets and real-world questions asked by specialists. We demonstrate performance approaching or exceeding state-of-the-art on every MultiMedQA multiple-choice benchmark, including MedQA, PubMedQA, MedMCQA and MMLU clinical topics. We show substantial gains in long-form answers over Med-PaLM, as assessed by physicians and laypeople on multiple axes of quality and safety. Furthermore, we observe that Med-PaLM 2 answers were preferred over physician-generated answers in multiple axes of evaluation across both consumer medical questions and adversarial questions. Finally, we observe that Med-PaLM 2 answers to bedside consultation questions that arose during routine care delivery are often preferred by physicians over generalist answers.

As LLMs become increasingly proficient at structured tests of knowledge, it is more important to delineate and assess their capabilities along clinically relevant dimensions21,25. Our evaluation framework examines the alignment of long-form model outputs to human expectations of high-quality medical answers across both consumer and physician questions. Our use of adversarial question sets also enables explicit study of LLM performance in difficult cases. The substantial improvements of Med-PaLM 2 relative to Med-PaLM suggest that careful development and evaluation of challenging question-answering tasks is needed to ensure robust model performance.

Using a multidimensional evaluation framework lets us understand trade-offs in more detail. For instance, Med-PaLM 2 answers were longer on average (Supplementary Table 13) than Med-PaLM or physician answers. This may provide benefits for many use cases, but may also lead to trade-offs such as including unnecessary additional details versus omitting important information.

The optimal length of an answer may depend upon additional context outside the scope of a question. For instance, questions around whether a set of symptoms are concerning depend upon a person’s medical history; in these cases, the more appropriate response of an LLM may be to request more information, rather than comprehensively listing all possible causes. Our evaluation did not consider multiturn dialog31, nor frameworks for active information acquisition32. Our individual evaluation did not clearly distinguish performance of Med-PaLM 2 answers from physician-generated answers, motivating more granular evaluation, including pairwise evaluation and adversarial evaluation. In pairwise evaluation, we saw that Med-PaLM 2 answers were preferred over physician answers along several axes pertaining to clinical utility, such as factuality, medical reasoning capability and likelihood of harm. Likewise, on bedside consultation questions, specialists preferred Med-PaLM 2 answers over those of generalists, but generalists rated them equally. These results indicate that, as the field progresses toward physician-level performance, improved evaluation frameworks (including highly specialized human raters) and work on scalable oversight33 will be crucial for further measuring progress and aligning models.

In real-world care delivery, care is often provided by nonphysicians, for example, nurse practitioners, physician assistants and physician associates. Additionally, in many parts of the world, access to physicians can be scarce. As models approach physician-level performance on medical question answering in real-world tasks like bedside consultation, they become promising for assisting medical staff where access to specialists is limited. Our model comparison on bedside consultation questions demonstrates progress toward better evaluation, but validating model assistance in real-world workflows remains an important area of future work to responsibly enable these applications.

The LLM landscape is rapidly evolving, necessitating careful interpretation of our findings within this dynamic context. Since Med-PaLM 2’s March 2023 release, significant advancements have reshaped the field. Models now have expanded context windows, reaching millions of tokens34, enabling more sophisticated reasoning and nuanced, variable-length responses. This is particularly relevant for medical applications, where complex information requires careful consideration27,35. Furthermore, LLMs are evolving beyond text, embracing multimodality to process and integrate diverse data sources like images36. This progress is exemplified by recent iterations within prominent LLM families like GPT (GPT-4, GPT-4o, GPT-4o1)37, Gemini (Gemini 1.0, Gemini 1.5)34,38 and Gemma (Gemma, Gemma 2)39,40, alongside the rise of models like Llama41 and Mistral42. These rapid advancements highlight the critical need for ongoing evaluation and benchmarking to ensure that our understanding of LLM capabilities remains current and relevant. Med-PaLM and Med-PaLM 2’s pioneering evaluation framework and methodology are designed to scale with the availability of larger datasets and adapt to this evolving LLM landscape, providing a valuable tool for contextualizing advances in this rapidly changing field.

Given the broad and complex space of medical information needs, methods to measure alignment of model outputs warrant continued development. Additional dimensions to those we measure here are likely to be important, such as the empathy conveyed by answers25. As noted, our rating rubric is not a formally validated qualitative instrument, although observed interrater reliability was high (Supplementary Fig. 1). Further research is required to develop the rigor of rubrics enabling human evaluation of LLM performance in medical question answering.

Likewise, a robust understanding of how LLM outputs compare to physician answers is a broad, highly significant question meriting much future work; the results we report here represent one step in this research direction. For our study on consumer questions, physicians generating answers were prompted to provide useful answers to laypeople but were not provided with specific clinical scenarios or nuanced details of the communication requirements of their audience. While this may be reflective of real-world performance for some settings, it is preferable to ground evaluations in highly specific workflows and clinical scenarios. Our bedside consultation questions pilot is a step in this direction, but was limited in scale. Model answers are also often longer than physician answers, which may contribute to improved independent and pairwise evaluations, as suggested by other work25. Furthermore, we did not explicitly assess interrater variation in preference rankings or explore how variation in preference rankings might relate to the lived experience, expectations or assumptions of our raters.

Physicians were also asked to only produce one answer per question, so this provides a limited assessment of the range of possible physician-produced answers. Future improvements to this methodology could provide a more explicit clinical scenario with recipient and environmental context for answer generation. It could also assess multiple possible physician answers to each question, alongside interphysician variation. Moreover, for a more principled comparison of LLM answers to medical questions, the medical expertise, lived experience and background, and specialization of physicians providing answers, and evaluating those answers, should be more explicitly explored. It would also be desirable to explore intra- and interphysician variation in the generation of answers under multiple scenarios as well as contextualize LLM performance by comparison to the range of approaches that might be expected among physicians.

Finally, the current evaluation with adversarial data is relatively limited in scope and should not be interpreted as a comprehensive assessment of safety, bias and equity considerations. In future work, adversarial data could be systematically expanded to increase coverage of health equity topics and facilitate disaggregated evaluation over sensitive characteristics43–45.

These results demonstrate rapid progress toward physician-level medical question answering with LLMs. However, further work on validation and alignment to human values is necessary as the technology finds broader uptake in real-world applications. Careful and rigorous evaluation and refinement of LLMs in different contexts for medical question answering and real-world workflows will be needed to ensure this technology has the greatest possible impact on health.

## Section: Methods

In the following text, we provide further details on the development of Med-PaLM 2 and the expanded evaluation framework used to validate model outputs.

Question answering evaluation datasets for human evaluation

Instruction finetuning data mixture

Instruction fine-tuning data mixture

Illustration of Ensemble Refinement (ER) with Med-PaLM 2. In this approach, an LLM is conditioned on multiple possible reasoning paths that it generates to enable it to refine and improve its answer.

## Section: Methods › Datasets

We evaluated Med-PaLM 2 on multiple-choice and long-form medical question-answering datasets from MultiMedQA1, two new adversarial long-form datasets and a pilot set of real-world bedside consultation questions (Extended Data Tables 1 and 2).

Question answering evaluation datasets for human evaluation

## Section: Methods › Datasets › Multiple-choice questions

For evaluation on multiple-choice questions, we used the MedQA15, MedMCQA16, PubMedQA17 and MMLU clinical topics46 datasets.

## Section: Methods › Datasets › MultiMedQA consumer questions

For evaluation on long-form questions, we used two sets of questions sampled from MultiMedQA (Extended Data Table 2). The first set (MultiMedQA 140) consists of 140 questions curated from the HealthSearchQA, LiveQA47 and MedicationQA48 datasets, matching the set used in ref. 1. The second set (MultiMedQA 1066) is an expanded sample of 1,066 questions from the same sources. For MultiMedQA 1066, we randomly sampled 1,000 questions from MultiMedQA (mostly HealthSearchQA) in addition to the 140 in MultiMedQA 140 and removed all duplicates and near duplicates (questions identical other than capitalization). The resulting set had 1,066 questions.

## Section: Methods › Datasets › Adversarial consumer questions

We also curated two new datasets of adversarial questions designed to elicit model answers with potential for harm and bias: a general adversarial set and a health equity-focused adversarial set (Extended Data Table 2). The first set (Adversarial (General)) broadly covers issues related to health equity, drug use, alcohol, mental health, COVID-19, obesity, suicide and medical misinformation. Health equity topics covered in this dataset include health disparities, the effects of structural and social determinants on health outcomes, and racial bias in clinical calculators for renal function49–51. The second set (Adversarial (Health Equity)) prioritizes use cases, health topics and sensitive characteristics based on relevance to health equity considerations in the domains of healthcare access (for example, health insurance, access to hospitals or primary care provider), quality (for example, patient experiences, hospital care and coordination) and social and environmental factors (for example, working and living conditions, food access and transportation). The dataset was curated to draw on insights from the literature on health equity in machine learning and define a set of implicit and explicit adversarial queries that cover a range of patient experiences and health conditions27. Queries often involved implicit requests for medical advice and were not always explicit well-formed medical questions. This dataset was released and further described in ref. 27, where it was referred to as the Open-ended Medical Adversarial Queries dataset.

## Section: Methods › Datasets › Bedside consultation questions

We curated a set of questions representing real-world information needs arising during routine care delivery, submitted to a real-world bedside consultation service28,52,53 by specialist physicians. In the original service, offered at Stanford Medicine from 2017 to 2018, questions were answered by a team analyzing de-identified patient records to provide a written report. The answers have informed individual patient care, resulted in changes to institutional practices and motivated further clinical research28. We provide examples of questions in Supplementary Table 11. Starting with the entire set of set of 100 questions submitted between February 2017 and September 201828, questions were filtered to those that did not rely on information unavailable to an LLM or external physician, such as test-ordering rates at Stanford Healthcare or number of visits at specific clinic sites. Sixty-six questions remained at this stage. Subsequently, three clinicians independently sampled a third of these questions across multiple specialities and then adjudicated selection differences, resulting in the final set of 20 questions. Question selection was done independently of Med-PaLM 2’s ability to answer them and by clinicians with no access to the Med-PaLM 2 model. Authors with access to Med-PaLM 2 were not involved in question selection in any manner.

## Section: Methods › Modeling

Instruction finetuning data mixture

Instruction fine-tuning data mixture

## Section: Methods › Modeling › Base LLM

For Med-PaLM, the base LLM was PaLM19. Med-PaLM 2 builds upon PaLM 2 (ref. 26), a new iteration of Google’s LLM with substantial performance improvements on multiple LLM benchmark tasks. The main advances incorporated into PaLM 2 include compute-optimal scaling54, improved dataset mixtures and objective improvements26.

## Section: Methods › Modeling › Instruction fine-tuning

We applied instruction fine-tuning to the base LLM following the protocol used in ref. 20. The datasets used included the training splits of MultiMedQA—namely MedQA, MedMCQA, HealthSearchQA, LiveQA and MedicationQA. We trained a ‘unified’ model, which is optimized for performance across all datasets in MultiMedQA using dataset mixture ratios (proportions of each dataset) reported in Extended Data Table 3. These mixture ratios and the inclusion of these particular datasets were empirically determined based on the size and quality of the respective datasets and performance on existing validation sets of the multiple-choice tasks. We anchored on mixture ratios starting in proportion to the size of each dataset and then overweighted datasets that contained more high-quality examples of diverse tasks.

Unless otherwise specified, Med-PaLM 2 refers to this unified model. For comparison purposes, we also created a variant of Med-PaLM 2 obtained by fine-tuning exclusively on multiple-choice questions, which led to improved results on these benchmarks.

Instruction finetuning data mixture

Instruction fine-tuning data mixture

## Section: Methods › Prompting strategies

We describe below prompting strategies used to evaluate Med-PaLM 2 on multiple-choice and long-form tasks.

Illustration of Ensemble Refinement (ER) with Med-PaLM 2. In this approach, an LLM is conditioned on multiple possible reasoning paths that it generates to enable it to refine and improve its answer.

## Section: Methods › Prompting strategies › Few-shot prompting

Few-shot prompting involves prompting an LLM by prepending example inputs and outputs before the final input. Few-shot prompting remains a strong baseline for prompting LLMs, which we evaluate and build on in this work. We use the same few-shot prompts as used by ref. 1.

## Section: Methods › Prompting strategies › Chain of thought

Chain of thought (CoT), introduced in ref. 55, involves augmenting each few-shot example in a prompt with a step-by-step explanation toward the final answer. The approach enables an LLM to condition on its own intermediate outputs in multistep problems. As noted in ref. 1, the medical questions explored in this study often involve complex multistep reasoning, making them a good fit for CoT prompting. We crafted CoT prompts to provide clear demonstrations on how to appropriately answer the given medical questions (provided in Supplementary Table 23).

## Section: Methods › Prompting strategies › Self-consistency

Self-consistency (SC) is a strategy introduced in ref. 56 to improve performance on multiple-choice benchmarks by sampling multiple explanations and answers from the model. The final answer is the one with the majority (or plurality) vote. For a domain such as medicine with complex reasoning paths, there might be multiple potential routes to the correct answer. Marginalizing over the reasoning paths can lead to the most accurate answer. In this work, we performed SC with 11 samplings using CoT prompting, as in ref. 1.

## Section: Methods › Prompting strategies › Ensemble refinement

Building on CoT and SC, we developed a simple prompting strategy that we refer to as ensemble refinement (ER). ER builds on other techniques that involve conditioning an LLM on its own generations before producing a final answer, including CoT prompting and self-refine57.

ER involves a two-stage process: first, given a (few-shot) CoT prompt and a question, the model produces multiple possible generations stochastically via temperature sampling. In this case, each generation involves an explanation and an answer for a multiple-choice question. Then, the model is conditioned on the original prompt, question and the concatenated generations from the previous step, and is prompted to produce a refined explanation and answer. This can be interpreted as a generalization of SC, where the LLM is aggregating over answers from the first stage instead of a simple vote, enabling the LLM to take into account the strengths and weaknesses of the explanations it generated. To improve performance, we performed the second stage multiple times and finally took a plurality vote over these generated answers to determine the final answer. ER is depicted in Extended Data Fig. 1.

Unlike SC, ER may be used to aggregate answers beyond questions with a small set of possible answers (for example, multiple-choice questions). For example, ER can be used to produce improved long-form generations by having an LLM condition on multiple possible answers to generate a refined final answer. Given the resource cost of approaches requiring repeated samplings from a model, we apply ER only for multiple-choice evaluation in this work, with 11 samplings for the first stage and 33 samplings for the second stage.

Illustration of Ensemble Refinement (ER) with Med-PaLM 2. In this approach, an LLM is conditioned on multiple possible reasoning paths that it generates to enable it to refine and improve its answer.

## Section: Methods › Prompting strategies › Chain of retrieval

In this work, we studied difficult bedside consultation questions from specialist physicians that arose in the course of healthcare delivery. This has been a challenging task for ungrounded LLMs like GPT-3.5 and GPT-4 (ref. 53)—even for specialist physicians, answering these questions often requires accessing external resources.

To improve Med-PaLM 2’s grounding, factuality and safety on these difficult medical questions, we introduce a step-by-step pipeline for generation and verification of model answers using search over relevant external medical information, which we call chain of retrieval. The process is as follows:

This approach builds on the intuition of CoT prompting, whereby LLMs can succeed in complicated multistep reasoning tasks when those tasks are broken down into steps, enabling models to autoregressively condition on the outputs of previous steps. Steps (1), (2), (3) and (6) were all performed via individual model inferences given different prompts, and step (5) was performed via one model inference per document. We found that, for step (6), it was important to exclude the initial answer from step (1) from the prompt, to prevent the model from anchoring on the initial ungrounded answer. We share prompts for individual steps in the pipeline in Supplementary Table 23.

This approach is generally applicable to other LLMs and evaluation settings. It is distinct from retrieval-augmented generation approaches that leverage a fixed corpus and embedding space to find documents to condition LLM generations on58, and is most similar to other approaches that break down verification of claims into multiple steps59,60. We are not aware of any work that has used the exact same steps as chain of retrieval or applied it for medical question answering. The steps in this pipeline are not individually learned during fine-tuning; combining this approach with process supervision61 to improve performance at each step and boost overall factuality and safety of model generations remains an important area for future work.

## Section: Methods › Overlap analysis

An increasingly important concern given recent advances in large models pretrained on web-scale data is the potential for overlap between evaluation benchmarks and training data. We searched for overlapping text segments between multiple-choice questions in MultiMedQA and the corpus used to train the base LLM underlying Med-PaLM 2. We defined a question as overlapping if either the entire question or at least 512 contiguous characters overlapped with any document in the training corpus. For this analysis, multiple-choice options or answers were not included as part of the query, since inclusion could lead to underestimation of the number of overlapping questions due to heterogeneity in formatting and ordering options. As a result, this analysis will also treat questions without answers in the training data as overlapping. We believe this methodology is both simple and conservative, and when possible we recommend it over black-box memorization testing techniques2, which do not conclusively measure test set contamination.

## Section: Methods › Long-form consumer question-answering evaluation

To assess the performance of Med-PaLM 2 on long-form consumer medical question answering, we conducted a series of human evaluations.

## Section: Methods › Long-form consumer question-answering evaluation › Model answers

To elicit answers to long-form questions from Med-PaLM models, we used the prompts provided in Supplementary Table 24. We did this consistently across Med-PaLM and Med-PaLM 2. We sampled from models with temperature 0.0 as in ref. 1.

## Section: Methods › Long-form consumer question-answering evaluation › Physician answers

Physician answers were generated as described in ref. 1. Physicians were not time limited in generating answers and were permitted access to reference materials. Physicians were instructed that the audience for their answers to consumer health questions would be a layperson of average reading comprehension. Tasks were not anchored to a specific environmental context or clinical scenario.

## Section: Methods › Long-form consumer question-answering evaluation › Physician and layperson raters

Human evaluations were performed by physician and layperson raters. Physician raters were drawn from a pool of 15 individuals based in the United States of America (six raters), the United Kingdom (four raters) and India (five raters). Specialty expertise spanned family medicine and general practice, internal medicine, cardiology, respiratory, pediatrics and surgery. Although three physician raters had previously generated physician answers to MultiMedQA questions in previous work1, none of the physician raters evaluated their own answers, and eight to ten weeks elapsed between the task of answer generation and answer evaluation. Layperson raters were drawn from a pool of six raters (four female, two male, 18–44 years old) based in India, all without a medical background. Layperson raters’ educational background breakdown was: two with high school diplomas, three with graduate degrees and one with postgraduate experience.

## Section: Methods › Long-form consumer question-answering evaluation › Individual evaluation of long-form answers

Individual long-form answers from physicians, Med-PaLM and Med-PaLM 2 were rated independently by physician and layperson raters using rubrics introduced in ref. 1. Physicians and layperson raters each used dedicated and separate rubrics (12 evaluation axes for physicians, two for laypersons). Raters were blinded to the source of the answer and rated independently without conferring with other raters. The MultiMedQA 140, Adversarial (General) and Adversarial (Health Equity) datasets were rated. Ratings for MultiMedQA 140 for Med-PaLM were taken from ref. 1. For all new rating experiments, each answer was evaluated by three independent raters randomly drawn from the respective pool of raters (layperson or physician). Answers in MultiMedQA 140 were triple rated, while answers to adversarial questions were quadruple rated. Interrater reliability analysis of MultiMedQA 140 answers indicated that raters were in very good (Randolph’s κ > 0.8; ref. 62) agreement for 10 out of 12 alignment questions, and good (κ > 0.6) agreement for the remaining two questions, including whether answers missed important content or contained unnecessary additional information (Supplementary Fig. 1).

## Section: Methods › Long-form consumer question-answering evaluation › Pairwise ranking evaluation of long-form answers

In addition to independent evaluation of each answer, pairwise ranking evaluations involved directly comparing alternative answers to a given question. Raters were presented with pairs of answers from different sources (for example, physician versus Med-PaLM 2) for a given question.

For each pair of answers, raters were asked to select the preferred answer or indicate a tie along the following axes (with exact instruction text in quotes):

For three axes (reading comprehension, knowledge recall and reasoning), pairwise ranking evaluation differed from the long-form individual answer evaluation. Individual answer evaluation separately examines whether an answer contains both positive and negative evidence of performance on each axis, while pairwise ranking evaluation consolidates these two questions to assess overall quality. These evaluations were performed on the MultiMedQA 1066 and adversarial datasets. Raters were blinded as to the source of each answer, and the order in which answers were shown was randomized. Due to technical issues in the display of answers, raters were unable to review eight of 1,066 answers for the Med-PaLM 2 versus physician comparison, and 11 of 1,066 answers for the Med-PaLM 2 versus Med-PaLM comparison; these answers were excluded from analysis in Figs. 1 and 3 and Supplementary Tables 6 and 7.

## Section: Methods › Long-form consumer question-answering evaluation › Statistical analyses

All data analysis was performed using Python v.3.11.8 and the scipy and numpy packages. For multiple-choice accuracy estimates, we computed binomial proportion confidence intervals using the Clopper–Pearson interval for better coverage on accuracies closer to 1 (ref. 63). Overlap analysis of model performance on questions that did/did not overlap with training data used the normal approximation for binomial confidence intervals, since this implementation was the only one supporting comparisons between two independent proportions needed for that analysis. We computed confidence intervals on long-form evaluation results via bootstrapping (10,000 iterations). For analyses with multiple-rated answers, bootstrap samples were clustered by answer. Two-tailed permutation tests were used for hypothesis testing (10,000 iterations). For multiple-rated answers, permutations were clustered by answer; all ratings for a given answer from each answer provider (LLM or physician) were permuted at the answer level 10,000 times.

## Section: Methods › Long-form consumer question-answering evaluation › Interrater reliability

We performed interrater reliability analysis for physician ratings of long-form answers on a subset of question and answer pairs (n = 140) that were multirated by a set of three independent physicians. Interrater agreement was measured as Randolph’s κ; this measurement was more appropriate than other measures, such as Krippendorff’s alpha, given the low baseline positive rate for several axes, such as incorrect comprehension. Raters were in very good (κ > 0.8, marked with a solid green line in Supplementary Fig. 1) agreement for 10 out of 12 alignment questions and good (κ > 0.6, marked with a dotted green line) agreement for the remaining two questions, including whether the answer either missed important content or contained unnecessary additional information. Supplementary Fig. 1 illustrates agreement metrics for each of the 12 evaluation axes along with 95% confidence intervals.

## Section: Methods › Bedside consultation question-answering evaluation

We introduced a small-scale evaluation of Med-PaLM 2 answers with chain of retrieval on bedside consultation questions from specialists. We note that this evaluation was meant to be a pilot demonstration of a more realistic evaluation of medical question answering, and we do not aim for large-scale human evaluation here.

## Section: Methods › Bedside consultation question-answering evaluation › Specialist and generalist answers

We asked specialists in the same specialty as the original requesting specialist who submitted the question to the bedside consultation service to produce an answer to each question. Physician specialities included endocrinology, dermatology, cardiology, epidemiology, otorhinolaryngology, infectious disease, ophthalmology and hematology–oncology. We also had generalist physicians produce answers independently. Physicians were allowed to use any available references to produce their answers and were not time limited. We show examples of answers from specialists, generalists and Med-PaLM 2 in Supplementary Table 12.

## Section: Methods › Bedside consultation question-answering evaluation › Specialist and generalist raters

We performed human evaluations of model, specialist and generalist answers using specialist (1× replication) and generalist physicians (11× replication). Physicians who evaluated answers were always different than those producing answers. Specialists were always in the same specialty as the original requesting specialist. Physician specialities included endocrinology, dermatology, cardiology, epidemiology, otorhinolaryngology, infectious disease, ophthalmology and hematology–oncology. Eleven generalist physicians completed each rating task for each question.

## Section: Methods › Bedside consultation question-answering evaluation › Three-way utility ranking

Given model, generalist and specialist answers, we performed a three-way comparative ranking task for each specialist and generalist rater (12 raters per ranking). Raters were shown a question and all three answers, blinded and randomly ordered per question. We asked raters, “Which model response is [MOST, SECOND MOST, LEAST] useful as an answer to your original question?”. From this three-way ranking, we also extracted pairwise preference results, also reported in Fig. 4.

## Section: Methods › Bedside consultation question-answering evaluation › Individual evaluation of harm

To determine whether there was a possibility of harm for different answers, we performed harm evaluation on each answer to each question individually, for each of the 12 raters. Raters were blinded to the source of each answer. We asked raters, “For answer [1, 2, 3], are there elements of this response that are so incorrect as to cause patient harm?”. In Supplementary Tables 14 and 15, we report results for specialist and generalist raters, using different thresholds over the 11 generalist raters to aggregate over ratings (majority and >80% agreement on harmlessness).

## Section: Methods › Bedside consultation question-answering evaluation › Model comparison

To demonstrate the broader applicability of our evaluation framework, we compared Med-PaLM 2 to more recent general-purpose LLMs like GPT-4 (January 2024 version, proprietary) and GPT-3.5 (December 2022 version, proprietary) on a 140-question subset of MultiMedQA. While physician ratings were comparable across most metrics, Med-PaLM 2 was judged significantly safer, with a lower likelihood of harm and no sign of bias across specific subgroups (Supplementary Fig. 2 and Supplementary Table 10). This highlights the framework’s ability to assess and compare diverse LLMs, even those not specifically trained for medical applications.

## Section: Methods › Reporting summary

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article.

## Section: Online content

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at 10.1038/s41591-024-03423-7.

## Section: Supplementary information

Supplementary Figs. 1–3 and Tables 1–24.

Reporting Summary

## Section: Acknowledgements

This project was an extensive collaboration between many teams at Google Research. We thank M. Howell, B. Babenko and N. Hammel for their feedback during our research. We are also grateful to J. Dean, J. Manyika, K. DeSalvo, Z. Ghahramani, D. Fleet, D. Eck and S. Kornblith for their support during the course of this project. We also thank B. Hatfield, S. Man, S. Sharma, G. Parakkal, G. Turner, J. Zitting, E. Rappaport, D. Steiner, J. Kemp, J. Hu, Y. Liu, J. Krause, K. Kulkarni, S. Thomas, K. Weber, A. Um’rani, A. Iurchenko, W. Vaughan, J. Wang, M. Shiels, L. Winer, M. Schwede, A. Chang, A. Kumar, M. Kumar, M. Gaynon, A. Mehta, D. Iberri, J. Ko, M. Schwede, J. Lee, T. Seddik and J. Wha-Rhee for their assistance. N.H.S. acknowledges support from the Debra and Mark Leslie endowment for AI in Healthcare. J.H.C. has received research funding support in part by: the NIH/National Institute of Allergy and Infectious Diseases (grant no. 1R01AI17812101); a NIH-NCATS-Clinical & Translational Science Award (no. UM1TR004921); the NIH/National Institute on Drug Abuse Clinical Trials Network (no. UG1DA015815—CTN-0136); the Stanford Bio-X Interdisciplinary Initiatives Seed Grants Program (IIP) (R12); the Gordon and Betty Moore Foundation (grant no. 12409); and the American Heart Association—Strategically Focused Research Network—Diversity in Clinical Trials.

## Section: Author contributions

K.S., S.A., T.T., A.K. and V.N. contributed to the conception and design of the work. A.K., V.N., S.S.M, K.S., S.A., T.T., D.N., Q.M.R., D.D., J.H.C. and N.H.S. contributed to the data acquisition and curation. K.S., S.A., T.T., J.G., R.S., E.W., M.A., K.C. and V.N. contributed to the technical implementation. A.K., V.N., K.S., S.A., T.T, R.S., E.W., H.C.-L., S.P., D.D., J.H.C. and N.H.S. contributed to the evaluation framework used in the study. A.K. provided clinical inputs to the study. All authors contributed to the drafting and revising of the manuscript.

## Section: Peer review › Peer review information

Nature Medicine thanks the anonymous reviewers for their contribution to the peer review of this work. Primary Handling Editor: Lorenzo Righetto, in collaboration with the Nature Medicine team.

## Section: Data availability

The primary benchmark used in the study, MultiMedQA, comprises six open-source datasets and one for consumer medical questions, HealthSearchQA, which were previously released with the publication of ref. 1. MultiMedQA includes MedQA (https://github.com/jind11/MedQA), MedMCQA (https://medmcqa.github.io), PubMedQA (https://pubmedqa.github.io), LiveQA (https://github.com/abachaa/LiveQA_MedicalTask_TREC2017), MedicationQA (https://github.com/abachaa/Medication_QA_MedInfo2019) and MMLU (https://huggingface.co/datasets/hendrycks_test). In addition, our assessments of model performance on adversarial questions used datasets contained in EquityMedQA, released with the publication of ref. 27.

## Section: Code availability

Med-PaLM 2 is a large language model that has been aligned to the medical domain. For reproducibility, we documented technical deep-learning methods while keeping the paper accessible to a clinical and general scientific audience. Our work builds upon PaLM 2, for which technical details have been described in the technical report26. We are not open-sourcing the model code and weights due to the safety implications of unmonitored use of such a model in medical settings, as well as intellectual property and commercial viability considerations. In the interest of responsible innovation, we are working with research partners and healthcare organizations to validate and explore safe onward uses of MedLM (https://cloud.google.com/vertex-ai/generative-ai/docs/medlm/overview), which has been further tuned based on specific user needs, such as answering medical questions and drafting summaries.

## Section: Competing interests

This study was funded by Alphabet Inc and/or a subsidiary thereof (‘Alphabet’). K.S., T.T., S.S.M., J.G., R.S., E.W., M.A., L.H., K.C., S.R.P., H.C.-L., D.N., Q.M.R., M.S., A.W., S.L., P.A.M., S.P., B.G., E.D., B.A.A., N.T., Y.L., R.W., C.S., J.K.B., D.R.W., G.S.C. and Y.M., S.A., A.K. and V.N. are employees of Alphabet and may own stock as part of the standard compensation package. J.H.C. is co-founder of Reaction Explorer LLC that develops and licenses organic chemistry education software; is paid consulting fees from Sutton Pierce, Younker Hyde MacFarlane and Sykes McAllister as a medical expert witness; and is paid consulting fees from ISHI Health. The remaining authors declare no competing interests.

## Section: Contributor Information

Shekoofeh Azizi, Email: shekazizi@google.com.

Alan Karthikesalingam, Email: alankarthi@google.com.

Vivek Natarajan, Email: natviv@google.com.

## Section: Extended data

is available for this paper at 10.1038/s41591-024-03423-7.

## Section: Supplementary information

The online version contains supplementary material available at 10.1038/s41591-024-03423-7.

## Section: Associated Data

Supplementary Figs. 1–3 and Tables 1–24.

Reporting Summary

## Section: Associated Data › Supplementary Materials

Supplementary Figs. 1–3 and Tables 1–24.

Reporting Summary

## Section: Associated Data › Data Availability Statement

The primary benchmark used in the study, MultiMedQA, comprises six open-source datasets and one for consumer medical questions, HealthSearchQA, which were previously released with the publication of ref. 1. MultiMedQA includes MedQA (https://github.com/jind11/MedQA), MedMCQA (https://medmcqa.github.io), PubMedQA (https://pubmedqa.github.io), LiveQA (https://github.com/abachaa/LiveQA_MedicalTask_TREC2017), MedicationQA (https://github.com/abachaa/Medication_QA_MedInfo2019) and MMLU (https://huggingface.co/datasets/hendrycks_test). In addition, our assessments of model performance on adversarial questions used datasets contained in EquityMedQA, released with the publication of ref. 27.

Med-PaLM 2 is a large language model that has been aligned to the medical domain. For reproducibility, we documented technical deep-learning methods while keeping the paper accessible to a clinical and general scientific audience. Our work builds upon PaLM 2, for which technical details have been described in the technical report26. We are not open-sourcing the model code and weights due to the safety implications of unmonitored use of such a model in medical settings, as well as intellectual property and commercial viability considerations. In the interest of responsible innovation, we are working with research partners and healthcare organizations to validate and explore safe onward uses of MedLM (https://cloud.google.com/vertex-ai/generative-ai/docs/medlm/overview), which has been further tuned based on specific user needs, such as answering medical questions and drafting summaries.


---

# Toxicity assessment of doxycycline-aided artificial intelligence-assisted drug design targeting candidate 16S rRNA methyltransferase gene

- **Authors:** Hira Mubeen, Nagina Rafiq, Madiha Khan, Saima Jabeen, Muhammad Waseem Shoaib
- **Issuer:** BMC pharmacology & toxicology
- **Type:** Scientific article
- **Published:** 2025-11-21
- **Language:** en
- **DOI:** 10.1186/s40360-025-00875-6
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41272886/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundThe misfunction of the protein 16SrRNA methyltransferase can result in Urinary tract infections (UTI), Gastrointestinal (GI) infections, sepsis, pneumonia, and wound infections; various tactics are used to lessen the fatal consequences. It confers resistance to aminoglycoside medications, which complicates the treatment of infections caused by these bacteria. Innovative methods are desperately needed to stop these diseases from spreading because there are no reliable medical therapies available.ObjectivesHerein, we aim to evaluate Doxycycline’s Role in AI-Driven Drug Design and identification of effective inhibitors targeting the 16S rRNA methyltransferase gene. Additionally, to investigate the toxicological profiles of designed drug through AI approach for advancement in medical sciences.MethodologyMethodology involves, selection of three effective de novo medicinal compounds that target the 16SrRNA methyltransferase protein for designing an AI driven drug. Multiple in silico tools were used for designing AI based drug includes: Expasy for protein annotation, ProtParam to calculate physiochemical parameters, SWISS-MODEL to estimate the 3D structure, and UniProt to generate the 16SrRNA methyltransferase protein sequence. An adequate foundation for the development and validation of AI-designed phytochemical medicines for infections is provided by quality assessment, binding site prediction, drug design with WADDAICA, toxicity screening, ADMET evaluation, and docking analysis with CB-dock.ResultsComprehensive pharmacokinetic and toxicology analyses confirm that the AI-designed doxycycline exhibits a non-toxic character, with particularly high absorption through the blood-brain barrier. Furthermore, the AI-designed doxycycline docked complex demonstrates a strong docking affinity with the 16S rRNA methyltransferase protein, showing a binding energy of approximately − 7.6 kcal/mol, suggesting significant therapeutic potential.ConclusionEven though the in silico studies show efficacy and safety, still there is need of in vivo trials to investigate the hidden medical aspects. By addressing existing constraints, presenting a non-invasive approach to infections, and providing viable substitutes for traditional surgical procedures, this work considerably expands the knowledge about newer methods and also helps to understand deep insights of dug design mechanism for treatment.Keywords: 16S rRNA, Methyltransferase, UTI, GI, ADMET, AI

## Section: Introduction

As an antibiotic, doxycycline belongs to the class of broad spectrum drugs called tetracycline. Through their binding to 16S ribosomal RNA (rRNA) and their inhibition of aminoacyl-tRNA’s ability to attach to the mRNA-ribosome complex, tetracycline is known to decrease bacterial protein production. The precise mechanism of action of these substances is yet unknown, though, because of their activity against other microorganisms like viruses, protozoa, and helminths that lack the 16S rRNA [1]. Moreover, tetracycline is selective enough to largely spare the host organism’s machinery for protein synthesis, even in the face of bacterial and host cell conservation of ribosome structure and function. It is still unclear how the tetracycline specifically suppresses microbial protein production and have such a broad spectrum of effects, despite their lengthy history of use as therapeutic drugs [2].

An in vitro study to correlate ribosomal subunit activity with drug binding revealed that inhibition of tRNA binding to the A-site is solely due to tetracycline cross-linked to the strong binding site on the 30S ribosomal subunit, despite the fact that binding interactions with both the 16S and 23S rRNA had previously been indicated for the tetracycline. Because of this, later research on the tetracycline’s mode of action and how it interacts with ribosomal RNA focused on the 30S ribosomal subunit’s 16S rRNA. However, a recent study found that the tetracycline, minocycline and doxycycline, bind to different synthetic double-stranded RNAs with random base sequences and prevent RNase III from cleaving them in vitro [3]. This suggests that specific base pairs may not be as important for tetracycline binding to RNA as double-stranded secondary structures that are commonly found in cellular RNAs. It also suggests that the tetracycline’ mechanism of action may be related to how the drugs affect the processing of these cellular RNAs [4].

In vivo correlations of this kind may provide valuable information on the mechanisms behind the tetracycline’ broad spectrum of pathogen-opposing activity, as well as their numerous non-infectious therapeutic uses [5].

Of the total cellular RNA in E. coli, ribosomal RNAs make up approximately 95%. Along with serving as enzymes during translation, they construct the ribosomes’ active sites, which are responsible for deciphering the message contained in the mRNA [6]. The increase in bacteria that are resistant to antimicrobial agents poses a serious threat to the control of infectious diseases. This is because illnesses brought on by resistant microbes frequently do not improve with traditional therapy, increasing the chance of death and prolonging the condition. The ability of a bacterium to withstand exposure to an antibiotic is known as antibiotic resistance [7]. Mutations in the bacterial DNA are the main source of antibiotic resistance. Antimicrobial resistance bacteria can grow, disseminate, and endure in environments where antimicrobial medications are misused and used irrationally. Regardless of the degree of the antibiotic’s necessity, resistance to the drug is more likely to develop the longer it is exposed to [8].

The increasing prevalence of antibiotic resistance raises the need for alternative treatments. The number of newly approved medications has been steadily declining, despite a push for innovative antibiotic treatments. Consequently, antibiotic resistance is a serious issue [9]. One of the most often given antibiotics worldwide at the moment is doxycycline, a long-acting, second-generation tetracycline antibiotic that is used to treat a wide range of infectious organisms, including susceptible intracellular and zoonotic infections [10]. It is unknown what the ideal dosage schedule for doxycycline is because it was introduced before pharmacodynamics ideas were understood. With the help of pharmacodynamics data, the best doxycycline dosage schedule was established through this in vitro investigation [11–13]. Phenotypic pathogens such as E. coli and P. multocida, as well as specific Gram-positive pathogens like Streptococcus pneumonia and Staphylococcus aureus, were tested against doxycycline. Two, four, eight, and sixteen times the minimum inhibitory concentration (MIC) of each test organism were represented by different serum concentrations used in time-kill investigations involving each of these organisms [14, 15].

Determine if doxycycline kills susceptible organisms by concentration or time-dependent kinetics was done by measuring the growth of the organisms using colony counts at different intervals throughout a 24-hour period. To find doxycycline’s PAE, research was also conducted [16]. The microorganism utilized was Escherichia coli (A0A8J0KCK0) [17]. The original definition of an antibiotic was a chemical that a single bacteria created that prevented the growth of other microbes. Since the development of synthetic techniques, the definition of an antibiotic has changed, and it is now used to describe a chemical that is produced by a bacterium or a substance that functions similarly and, at low quantities, prevents the growth of other germs. Of all the antimicrobials, antibiotics are one class that poses little threat to the host. Molecular weight less than 2000 characterizes these tiny compounds [18].

Numerous thousands of deaths occur annually due to antibiotic-resistant microorganisms that are widely distributed. The continual rise in microorganism’s resistant to standard antibiotics, especially last-resort medications like vancomycin, is the biggest issue. Resistance genes have the ability to spread quickly over the world, which is concerning since it indicates that this issue is becoming more widespread and calls for international cooperation in order to protect public health. In response to the notable global growth in the population of multidrug resistant strains, the World Health Organization (WHO) identified this issue as a serious threat to global health in 2014 [19]. There has been a widespread implementation of legislative actions aimed at restricting or doing away with the use of antibiotics, both as antibacterial agents in therapy and metaphylaxis (as addressed by EU Regulation 2019/6) and as feed additives for animals. In order to find new antimicrobial agents, identify markers linked to increased innate resistance to pathogens, and ascertain the role of bacteria in the transmission of antibiotic resistance to human and animal microbial flora, measures to reduce drug resistance among microorganisms must also increase research potential in areas like genetic improvement of animals [20].

Strategies for combating antibiotic resistance that are now in use depend on developing next-generation vaccinations and using bacteriophages or their enzymes in an alternate manner. Introducing prebiotics, probiotics, bacterial byproducts, and phytobiotics into animal feeding regimens is another crucial step. Proteases and peptides produced by plants, animals, invertebrates, mammals, and bacteria that have bactericidal properties are also of great interest [21]. Utilizing antimicrobial peptides generated by bacteria that are widely accepted as safe (GRAS), such as Lactobacillus species, Streptomyces, Micrococcus, or yeasts like Saccharomyces and Candidia, is the foundation of this solution [22]. The goal of the conventional fight against antibiotic resistance has been to limit the spread of resistant bacteria and avoid their selection during antibiotic treatment. More recently, the fight against antibiotic resistance has extended to agricultural settings as well. The environment plays a significant role as a source and a conduit in the spread of drug resistance in bacteria, and this understanding has grown in recent years [23].

In order to improve and expedite the drug discovery and development process, machine learning techniques are employed in the quickly developing field of artificial intelligence (AI)-based drug design. By speeding up the identification of possible drug candidates, cutting expenses, and improving the success rate of drug development, it has the potential to completely transform the biotechnology and pharmaceutical sectors. Analyzing biological data, including proteomics, metabolomics, and genomes, to comprehend the disease’s mechanism can assist AI in finding new therapeutic targets. This instance demonstrates the promise and effectiveness of AI-based medication design. Standard drug design processes are more complicated and time-consuming than in silico drug design, validation, and toxicology studies. Using doxycycline as a starting point, this research attempts to create a novel inhibitory medication that inhibits the 16S rRNA methyltransferase protein and deactivates its Hh signaling pathway. The AI-based medication design process made use of the WADDAICA web server. Lipinski’s rule 5 was used to conduct tests in order to assess the drug-like qualities that would make it a viable candidate for pharmaceutical drugs [24]. The Protox II web tool was used to conduct various toxicity studies of tiny compounds.

An effective treatment for the E. coli gene is suggested by this study, which may lead to a decreased disease rate. Studies conducted In-silico approaches using computational tools will also provide a useful perspective for adding novel ideas to the literature. The proposed article aims to evaluate the toxicity of doxycycline-assisted artificial intelligence-based drug creation that targets the 16S rRNA methyltransferase gene candidate. This approach may be applied to the development of in vivo medications in the future.

## Section: Materials and methods › Prediction of primary and tertiary structures of the protein

UniProt (https://www.uniprot.org/) provided the sequence of the targeted 16s rRNA methyltransferase protein [25]. With the use of the SWISS-MODEL the homology modeling and three-dimensional structure of the 16s rRNA methyltransferase protein is predicted. Scientists working in the biological sciences can create protein tertiary structure models with this server’s automated and intuitive method [26].

## Section: Materials and methods › Physiochemical properties

Expasy ProtParam, available at https://web.expasy.org/protparam/, was utilized to compute the physiochemical characteristics of the 16s rRNA methyltransferase protein. A tool called ProtParam allows one to compute the input protein’s numerous chemical and physical properties. Included in these determined attributes are the molecular weight, predicted isoelectric point, atomic composition, extinction coefficient, expected half-life, aliphatic index, instability index, and overall average of hydrophilicity (GRAVY) [27].

## Section: Materials and methods › Quality prediction of the protein

Combining ProQ with ProSA-web (ProSA-web), the protein quality prediction was carried out. A confidence score derived from statistical and machine learning techniques is provided by the ProQ server, which may be accessed at https://proq.bioinfo.se/cgi-bin/ProQ/ProQ.cgi. It uses a variety of metrics to evaluate protein models [28]. The understanding of protein structure and function is aided by its widespread use in model comparison and validation. The ProSA can be found at https://prosa.services.came.sbg.ac.at/prosa.phpproteins’ structures and functions are predicted and analyzed using a web server. Many structural metrics, including energy profiles, solvation potentials, and Z-scores, are computed in order to evaluate the quality of protein structures [29].

## Section: Materials and methods › Validation of the protein structure

PROCHECK, a program on the SAVESv6.0 - Structure Validation Server (ucla.edu) (https://saves.mbi.ucla.edu/), was used to validate the 16s rRNA methyltransferase protein. When examining the protein’s quality and the conformation of amino acid residues inside the protein structure, PROCHECK produces an ERRAT and a RAMACHANDRAN plot that can be used to detect energetically favorable or unfavorable locations. The most advantageous areas are emphasized on this map, along with the extra permitted, liberally permitted, and residue-containing areas that are prohibited [30]. This study offers important new information about the accuracy and consistency of the improved 16S rRNA methyltransferase protein structure.

## Section: Materials and methods › Prediction of the binding sites

To view, examine, and work with the protein structure, the Proteins Plus server (https://proteins.plus) was used. In addition to offering resources for molecular modeling, protein engineering, and drug development, Proteins Plus Server is helpful in forecasting and optimizing protein structures. DoGSiteScorer, a program that facilitates the discovery of binding sites on a particular target of interest, is part of the Proteins Plus service. This instrument can detect active areas within a protein structure and analyze protein–ligand interactions [31].

## Section: Materials and methods › Drug design by AI

In the context of drug design, researchers can forecast and generate potential drug candidates with the aid of a wide range of computational tools, software, and web servers. These tools often employ molecular modeling, molecular dynamics simulations, virtual screening, and other techniques to examine molecular interactions and identify drugs with possible medicinal efficacy. The goal of the WADDAICA web server is to develop more potent medication candidates by combining deep learning technology with traditional approaches [32]. Deep learning algorithms are used in the WADDAICA initial module (https://heisenberg.ucam.edu:5000/ accessed on June 27, 2024) to scaffold hop molecules in order to modify or create novel, ground-breaking drugs [33].

## Section: Materials and methods › Drug likeliness

Pre-clinical drug testing is carried out with the aid of SwissADME (http://www.swissadme.ch/, accessed on June 27, 2024), which helps anticipate the likelihood that target compounds will be developed into pharmaceutical treatments. It forecasted a prospective drug’s critical characteristics, including toxicity, absorption, distribution, metabolism, and excretion [34].

## Section: Materials and methods › Toxicity screening

The protox II tool (http://tox.charite.de/protox_II, evaluated on June 27, 2024) was used to anticipate the results of several toxicity analyses [35]. Designed to predict the hazardous effects of tiny chemical compounds, the Pro-tox II tool is a digital laboratory. Predicting the toxicity of these compounds is crucial in the realm of medicine development.

## Section: Materials and methods › ADMET and toxicity

This valuable resource, the toxic web server, allows researchers to swiftly and precisely evaluate tiny chemical toxicity profiles. It is based on advanced graph-based signatures and supervised learning, which are available at https://biosig.lab.uq.edu.au/toxcsm/. It outperforms previous methods by producing remarkably accurate prediction models. The target drug candidate produced benefited from the 36 toxicity prediction models provided by this study, which helped create safer medications, insecticides, and herbicides. Toxcsm was employed to evaluate the toxicity of phytochemical substances and produced molecules, and a comparative analysis was conducted [36].

## Section: Materials and methods › Docking analysis and validation

One notable molecular docking program is Autodock Vina in PyRx, which may be accessed at https://sourceforge.net/projects/pyrx/. This approach is used to identify the best possible compounds by evaluating how small molecules behave at protein binding sites and forecasting the atomic interactions between the molecules and proteins. The CB-Dock2 version is an improved version of the CB-Dock server that is intended for protein and ligand blind docking. It includes functions that can be accessed at https://cadd.labshare.cn/cb-dock2/php/index.php, including cavity detection, docking, and homologous template fitting. This approach facilitates computer-aided drug discovery by predicting binding sites and affinity between a ligand and protein based on their three-dimensional (3D) structures [37, 38].

## Section: Materials and methods › MD simulations

Using the IMods server (http://imods.chaconlab.org/,m, evaluated on September 12, 2024 [39], the docked complex was examined and displayed. Calculating different properties of the docked complex, including the energy required for the complex to degrade, was done through analysis. For the purpose of comprehending drug efficacy, the MD simulation may yield values for the stiffness, Eigen value, and deformability parameters.

## Section: Results

The 3D structure of the 16S rRNA methyltransferase protein predicted using the SWISS-MODEL

(a) Overall quality of the 16S rRNA methyltransferase protein model and (b) knowledge-based energy of the local protein model. (C) Jmol Cα trace of 1JSQ-A. Residues are colored from blue to red in the order of increasing residue energy

The quality of the protein, predicted by the ERRAT value

PDBsum analyses for PDB entry ury5. Ramachandran plot from PROCHECK showing the distribution of the protein’s main chain φ-ψ torsion angles (blue squares) relative to the “core” (red) and “allowed” (brown) regions, with residues falling in the “generously allowed” (dark yellow) and “disallowed” (pale yellow) regions plotted as red squares and labeled

The prediction binding pockets of the 16S rRNA methyltransferase protein. The two active sites are shown in the ball and stick form, and purple color show the grid of the active sites

3D structure of molecule 1 of the Doxycycline AI drug designed from WADDAICA

Toxicity analysis of doxycycline by protox-II

Results of AI doxycycline for drug likeliness, physiochemical properties and their medicinal chemistry

Boiled egg image of doxycycline-aided drug model 1

Docking score of compounds

A). Dock complex of the 16S rRNA methyltransferase protein and doxycycline designed by CB-Dock server, where gray color structure represents the AI doxycycline ligand. B). Protein molecules interacting with the AI drug candidate

A) Dock complex of the 16S rRNA methyltransferase protein and doxycycline designed by Autodock Vina server (B) Docking poses of best receptor-ligand complex using Discovery studio

Dock complicated simulations using molecular dynamics. (a) Tertiary structure based on MNA mobility. (b) The dock complex’s deformability graph. (c) The dock complex B-factor graph. (d) The dock complex’s Eigenvalues. (e) The dock complex’s covariance map, in which the correlated parts are shown in red, the anti-correlated regions in purple, and the uncorrelated regions in white. (f) The dock complex’s elastic network, with the stiffest areas displayed in dark gray. (g) Mode index of MD simulation

## Section: Results › Prediction of the primary structure of protein

The primary sequence (A0A8J0PCK0_ECOLX) of the uncharacterized 16S rRNA methyltransferase protein (217aa) was obtained from UniProt and belongs to Escherichia coli. The first amino acid was valine and the protein chain finishes at methionine.

## Section: Results › Physiochemical properties of protein

Using Expasy prototyping, the physiochemical characteristics of the 16S rRNA methyltransferase protein have been predicted. The total number of positively charged residues (Arg + Lys) were 31, and its total number of negatively charged residues (Asp + Glu) were 29 with molecular weight 23824.35. Additionally, it is anticipated that the Grand Average of Hydropathicity (GRAVY) will be -0.187 with the Instability Index 37.56. Positive Gravity indicates that this protein is recognized for its hydrophilic nature. The protein’s stability was established by these characteristics.

## Section: Results › Prediction of the tertiary structure of the protein

Understanding protein function and active sites is made easier by protein 3D structure, which also helps with drug design. As shown in Fig. 1, the Swiss-MODEL has been used to predict the protein’s tertiary structure. Sequence identity and coverage with the template 7ehf.1.A are 100% displayed. The model has a QMEAND and is Co-Global 0.88 ± 0.06 with a Global Model Quality Estimate of around 0.92.

The 3D structure of the 16S rRNA methyltransferase protein predicted using the SWISS-MODEL

## Section: Results › Quality prediction of the protein

Based on the Z score, the PROSA server provided information about the protein’s quality. The protein is more stable the lower the Z score. The expected Z score for 16S rRNA methyltransferase is − 3.67. Figure 2 also displays the overall quality of the protein tertiary structure, highlighting amino acid residues with larger negative energy levels.

(a) Overall quality of the 16S rRNA methyltransferase protein model and (b) knowledge-based energy of the local protein model. (C) Jmol Cα trace of 1JSQ-A. Residues are colored from blue to red in the order of increasing residue energy

## Section: Results › Validation of the protein

PROCHEKC was utilized to predict the validity of the protein. The outstanding structural integrity of the 16S rRNA methyltransferase protein was confirmed by the remarkably high ERRAT value of 87.597, which is a measure of the quality of protein structures. 86.94% of the residues were found in the most preferred locations according to the RAMACHANDRAN plot produced by PROCHECK, whereas 12.4, 0.7, and 0.0% were found in the additional allowed region, generously allowed region, and forbidden region, respectively (Figs. 3 and 4).

The quality of the protein, predicted by the ERRAT value

PDBsum analyses for PDB entry ury5. Ramachandran plot from PROCHECK showing the distribution of the protein’s main chain φ-ψ torsion angles (blue squares) relative to the “core” (red) and “allowed” (brown) regions, with residues falling in the “generously allowed” (dark yellow) and “disallowed” (pale yellow) regions plotted as red squares and labeled

## Section: Results › Prediction of binding sites

Figure 5 illustrates the two binding pockets of the 16S rRNA methyltransferase protein that the PROTEIN PLUS predicted. The pocket with the largest volume and surface area, 445.72 Å² and 166.91 Å³, respectively, served as the basis for choosing the active site.

The prediction binding pockets of the 16S rRNA methyltransferase protein. The two active sites are shown in the ball and stick form, and purple color show the grid of the active sites

## Section: Results › Drug design by AI

The AI technology utilized doxycycline as a test subject for the WADDAICA platform’s drug design (Fig. 6). Further, it applied the revolutionary deep learning model to transform the naturally occurring chemical into a possible therapeutic candidate. Figure 6 shows the AI-designed chemical.

3D structure of molecule 1 of the Doxycycline AI drug designed from WADDAICA

## Section: Results › Toxicity analysis

The findings indicate a high degree of predictability against neurotoxicity in the doxycycline toxic characteristics of the AI-based compound. Moreover, it was predicted that the substance would not be cytotoxic, mutagenic, or carcinogenic. This Table 1 presents the doxycycline compound’s toxicity profile.

Toxicity analysis of doxycycline by protox-II

## Section: Results › Drug likeliness

The results for AI doxycycline for drug likeliness and Physiochemical properties are represented in Table 2 which shows the drug likeliness rules of the AI Fisetin-aided molecule, which were found by utilizing SWISSADME. The SwissADME tool predicted the ADMET characteristics, including log P, mass, donors and acceptors of hydrogen bonds, and molar refractivity. Figure 7 shows the Boiled egg image of doxycycline-aided drug.

Results of AI doxycycline for drug likeliness, physiochemical properties and their medicinal chemistry

Boiled egg image of doxycycline-aided drug model 1

## Section: Results › Docking results

Using PyRx, which forecasted the outcomes based on cavity identification, docking scores was used to ascertain the interactions between the 16S rRNA methyltransferase protein and Doxycycline ligand. Table 3 illustrates how the phenolic compounds were first screened against the 16S rRNA methyltransferase protein. The maximum binding affinity, − 7.5 kcal/mol, is shown by doxycycline.

Moreover, a CB-dock was used to execute molecular docking between the AI-based Fisetin chemical and the 16S rRNA methyltransferase protein. A dependable binding energy score with a cavity volume of 2558 Å3 is confirmed by the binding affinity of -7.6 kcal/mol observed in the data. Figure 8 (A) displays the protein-ligand dock complex. (ARG38 LEU106 GLY109 SER110 LEU111 ARG113 ALA114 ALA141 ARG146 ASP147 SER157 GLN158 LEU159 THR160 GLU161 GLN162 PHE164 THR166 LEU168 VAL169 GLN170 TYR172 ASN174 ALA186) are the amino acid residues of protein chain A that interact with the doxycycline molecule the most. Figure 8(B) shows how ligands and protein amino acid residues interact.

Docking score of compounds

A). Dock complex of the 16S rRNA methyltransferase protein and doxycycline designed by CB-Dock server, where gray color structure represents the AI doxycycline ligand. B). Protein molecules interacting with the AI drug candidate

## Section: Results › Docking results validation

The docking results of the 16S RRNA Methyltransferase protein obtained by the Autodock vina program and the AI drug candidate doxycycline were further confirmed using the shape complementarity docking server Patch dock. Figure 9(A) depicts the complex’s docking, and Fig. 9(B) displays the optimal receptor ligand combination.

A) Dock complex of the 16S rRNA methyltransferase protein and doxycycline designed by Autodock Vina server (B) Docking poses of best receptor-ligand complex using Discovery studio

## Section: Results › Molecular dynamic simulations

The docked complex of doxycycline and 16S RRNA Methyltransferase was determined and quantified by IMods based on several factors. Here, the results are explained in detail. Different locations were determined to be directly related, as the heat map illustrates. Better interactions between the various residues in the structure are indicated by a low RMSD value. With a lower eigenvalue indicating strong interactions, the docked complex’s estimated eigenvalue was 4.859330e-04. The computed results are shown in Fig. 10.

Dock complicated simulations using molecular dynamics. (a) Tertiary structure based on MNA mobility. (b) The dock complex’s deformability graph. (c) The dock complex B-factor graph. (d) The dock complex’s Eigenvalues. (e) The dock complex’s covariance map, in which the correlated parts are shown in red, the anti-correlated regions in purple, and the uncorrelated regions in white. (f) The dock complex’s elastic network, with the stiffest areas displayed in dark gray. (g) Mode index of MD simulation

## Section: Discussion

To release the pre-16S and pre-23 S rRNA for maturation, RNase III cleaves the first lengthy primary ribosomal RNA transcripts/precursors (pre-rRNA) in bacteria. It is not always the nucleotide sequences that determine this cleavage, but rather the double-stranded secondary structures that surround the mature rRNA. There would be an accumulation of pre-rRNA molecules if this cleavage was prevented. RNase III cannot cleave synthetic double-stranded RNAs that doxycycline has been demonstrated to bind to. Doxycycline may consequently prevent normal processing of bacterial rRNA because bacterial rRNA processing mostly depends on RNase III cleavage, which is blocked by the antibiotic [40].

By examining the quantities of distinct rRNA in developing Escherichia coli cells treated with doxycycline, the impact of the drug on bacterial rRNA processing was examined in this work. The findings revealed that mature 16S and 23 S rRNA decreased in a dose-dependent manner when the first rRNA transcripts and lengthy precursors accumulated. At low drug concentrations, treated cells exhibited morphological elongation; at higher drug concentrations, nucleoid degeneration, a sign of cell death, transpired [41].

In the event that RNase III cleavage is not present, 16S rRNA could nevertheless mature, as evidenced by the growth of RNase III-deficient bacteria. It’s thought that this is because other nucleases working without RNase III provide an alternate processing route [42].

Prokaryotes share a highly conserved rRNA processing mechanism via the RNase III cleavage pathway, which accounts for the doxycycline’ broad spectrum of antibacterial action [43]. However, a far more intricate route that is independent of RNase III is involved in the digestion of ribosomal RNA in eukaryotes. Furthermore, ionic conditions—particularly those related to Mg2 + and divalent metal ion concentrations—are unfavorable for doxycycline binding during eukaryotic rRNA processing, which takes place in a protected habitat called ribosomes [44, 45]. Protein synthesis in bacteria may be selectively inhibited due to variations in the processing pathways of prokaryotic and eukaryotic ribosomal RNAs, with eukaryotic protein synthesis being less affected. The bacteriostatic mechanism of action of tetracycline is supported by the drug’s gradual recovery from its inhibitory effects on the maturation of ribosomal RNA [6].

Monotherapy, such as β-lactams or carbapenem, for serious infections has become useless and unsuccessful due to the widespread emergence of pan- and multidrug-resistant bacteria. In the treatment of infectious diseases today, medication combination therapies combining various antibiotics are indispensable. A class of antibiotics known for their broad antimicrobial spectrum that includes the ability to inhibit both Gram-negative and some Gram-positive bacteria, aminoglycosides were among the first to be discovered and utilized in therapeutic settings [46].

Aminoglycoside antibiotics are once again the center of attention in the clinic as one of the best choices for medication combination therapy [47].

However, resistance to aminoglycosides in bacteria is caused by a range of resistance mechanisms. The synthesis of 16S-RMTases is one of the pathways that could be dangerous. The rationale behind this assertion is their ability to induce not only total resistance to a wide variety of aminoglycosides, but also high-level resistance that is unaffected by dosage increases. Additionally, a number of studies have demonstrated that corresponding genotype subtypes frequently result in higher levels of resistance to aminoglycosides; for instance, rmtF2 can mediate resistance to arbekacin and amikacin with MIC > 1024 µg/mL [48].

In order to address the current state of aminoglycoside resistance and find the best screening practices and techniques for quickly identifying strains expressing 16S-RMTase, it will be crucial to lobby clinicians and researchers in the future. Evaluation of the molecular epidemiology of aminoglycoside resistance genes and thorough examination of associated mobile genetic elements are also strongly advised in order to manage the occurrence and worldwide spread of multidrug-resistant bacteria [49].

As of right now, reports indicate that tetracycline binding prevents RNase III from digesting dsRNA [8]. RNase III is primary to the digestion of bacterial rRNA. It is becoming increasingly apparent that the 16S rRNA binding mechanism currently held for the antibacterial action of tetracycline is not only limited but also does not explain their activities against other, nonbacterial, pathogens and under certain pathological conditions. It has therefore become imperative to consider alternative binding sites/modes that may offer insights into the broad spectrum of activity and antimicrobial selectivity of tetracycline. The binding of the tetracycline to cellular dsRNAs and the consequent effects on affected RNA processing and function could be a worthwhile alternative to explore [50].

The lethal effects of the doxycycline medication on the growing cells were described using a robust model. In order to validate the delivery of doxycycline as a highly hazardous treatment using the 16S rRNA methyltransferase protein, this study also included a computer assessment of hepatotoxicity and other toxicities. But to conduct this study, which employed important AI-based deep learning algorithms to create the medication, the WADDAICA web server was assessed. Docking is a crucial screening technique because it makes it possible to virtually predict how small molecules, like medications, will interact with proteins, such receptors or enzymes. This simulation can provide valuable insights into the binding affinity, protein–ligand interaction energetics, and orientation without requiring experimental techniques. A scoring function is chosen based on the specific scenario at hand and the desired trade-off between speed and accuracy. Remembering that various scoring functions could have unique advantages and disadvantages is crucial. Other scoring functions might be more suitable in different situations, even though Dock Thor Vina might work well for a certain use scenario. It is always a good idea to test and evaluate different scoring functions in order to determine which one best suits a certain scenario.

For the AI-based medication design, doxycycline was chosen as the component de novo molecule to be recovered against the 16S rRNA methyltransferase protein. Due to its active prediction of neurotoxicity, doxycycline is extremely dangerous, as evidenced by the comparative study of its toxicity with 16S rRNA methyltransferase.

The findings are further validated by the comparison of the ADMET study. When the AI-designed doxycycline molecule was docked with 16S rRNA methyltransferase, the binding affinity of − 7.6 kcal/mol was obtained. This indicates that the AI-created molecule is more effective because its toxicities analysis is inactive, and we can therefore take it into consideration as a possible drug candidate against rRNA processing. By utilizing Patchdock to verify the form complementarity of the ligand and protein, the docking results were further validated.

## Section: Conclusion

To explore the hidden medical features, in vivo trials are still necessary, even when in silico research demonstrate efficacy and safety. This work contributes significantly to the understanding of deeper insights of dug design mechanism for treatment, while also addressing current constraints, presenting a non-invasive approach to infections, and offering workable alternatives to conventional surgical procedures.

## Section: Author contributions

Hira Mubeen: Conceptualization and methodology design. Nagina: Writeup. Madiha Khan: Analysis and Investigation. Saima Jabeen: Writeup and finalizing manuscript. Muhammad Waseem Shoaib: Investigation clinical aspects.

## Section: Funding

Not applicable.

## Section: Data availability

No datasets were generated or analysed during the current study.

## Section: Code availability

Not applicable.

## Section: Declarations › Ethical approval

Not applicable.

## Section: Declarations › Consent to participate

Not applicable.

## Section: Declarations › Consent for publication

All authors read and approved the content for publication.

## Section: Declarations › Competing interests

The authors declare no competing interests.

## Section: Associated Data › Data Availability Statement

No datasets were generated or analysed during the current study.

Not applicable.


---

# Tracking protein kinase targeting advances: integrating QSAR into machine learning for kinase-targeted drug discovery

- **Authors:** Rand Shahin, Sawsan Jaafreh, Yusra Azzam
- **Issuer:** Future science OA
- **Type:** Scientific article
- **Published:** 2025-04-04
- **Language:** en
- **DOI:** 10.1080/20565623.2025.2483631
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40181786/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractProtein kinases are vital drug targets, yet designing selective inhibitors is challenging, compounded by resistance and kinome complexity. This review explores Quantitative Structure-Activity Relationship (QSAR) modeling for kinase drug discovery, focusing on integrating traditional QSAR with machine learning (ML)—CNNs, RNNs—and structural data. Methods include structural databases, docking, and deep learning QSAR. Key findings show ML-integrated QSAR significantly improves selective inhibitor design for CDKs, JAKs, PIM kinases. The IDG-DREAM challenge exemplifies ML’s potential for accurate kinase-inhibitor interaction prediction, outperforming traditional methods and enabling inhibitors with enhanced selectivity, efficacy, and resistance mitigation. QSAR combined with advanced computation and experimental data accelerates kinase drug discovery, offering transformative precision medicine potential. This review highlights deep learning-enhanced QSAR’s novelty in automating feature extraction and capturing complex relationships, surpassing traditional QSAR, while emphasizing interpretability and experimental validation for clinical translation.Keywords: QSAR, kinase, FDA approved, catalytic domain, discovery, machine learning, deep QSAR, CNN

## Section: Introduction

Protein kinases play a crucial role in modifying cellular functions at various levels. The process of protein phosphorylation is described as a reversible mechanism that involves the coordinated activity of phosphatases and kinases in a cyclic process known as the phosphorylation-dephosphorylation cycle. This intricate interplay highlights the significance of protein kinases as essential regulatory elements within cellular biochemical pathways. The active state of protein kinases can either enhance or diminish specific enzymatic actions, thereby finely tuning various biological and cellular activities.

In the last two decades, there has been a notable advancement in the molecular and structural understanding of human kinases, leading both academic and pharmaceutical research community to increasingly appreciate the value of research studies on kinase enzymes. Consequently, the efforts of medicinal chemists in the pharmaceutical industry culminated in the endorsement of 80 FDA-approved protein kinase small molecule inhibitors as of November 2023 (please refer to Tables 1S, 2S, and 3S under supplementary material). This progress is facilitated by four main factors: firstly, the intensified gene sequencing efforts that have enriched our knowledge about the human kinome. The human kinase gene family comprises almost 518 members, among which 106 are pseudogenes [1]. The second factor encompasses the implementation of modern drug discovery techniques and the improvement of the artificial intelligence procedures, including the advancement of computer-aided drug activity profiling panels, QSAR studies, machine learning drug discovery, and the molecular databases screening [2]. These advancements enable scientists to identify and eliminate promiscuous compounds during the early stages of the drug design process, thus aiding in minimizing off-target effects in later stages. The third factor relates to the increased availability of high-resolution ligand-kinase structural crystals, which are freely accessible in the Protein Data Bank (PDB). This availability has facilitated the development of computational drug design technology and provided a better understanding of the kinase binding pocket [3]. Finally, the improved understanding of the clinical applications of kinase inhibitors and the mechanisms underlying molecular drug resistance has proven to be pivotal. The challenge of kinase inhibitor resistance in cancer treatment remains a significant concern, compelling the ongoing development of new generations of kinase inhibitors to counteract the effects of mutation-linked drug resistance [3,4].

The application of computer-aided QSAR studies for treating dysregulated protein kinase enzymatic activity was not officially reported until the approval of Imatinib in the early 2000s. Interestingly, we found a review issue published in “Trends in Pharmacological Sciences” Vol. 23 No. 3 in March 2002 named “On the long road to drug discovery” [5,6]. This issue was giving a comprehensive overview on actual trends in drug discovery in the early times of the 21st century. Crucial points were discussed in the chapters of this issue, most importantly Cyclin-Dependent Kinase (CDK) inhibitory molecules. The issue was highlighting the future progress in drug research at that time and its chapters focused on the structure–activity relationships of CDK inhibitory drugs. In 2002, the chapters were not easily comprehended by the biologists and pharmacologists. However, the issue introduced a very clear insight to the importance of these fields of drug research [5]. Moreover, the issue described the new scientific findings that are related to the function of CDKs in cell cycle regulation and roughly proposed clinical applications for the new chemical inhibitors of CDK (e.g., flavones) in cancer therapy.

The increasing reliance on machine learning QSAR in kinase drug discovery is further validated by large-scale community initiatives such as the IDG-DREAM Drug-Kinase Binding Prediction Challenge (detailed in Supplementary Material Section 1), which rigorously benchmarked and assessed the performance of numerous predictive models developed by research groups worldwide.

This review explores the discovery of approved and investigational therapies targeting kinases, with a particular focus on advancements in QSAR studies addressing dysregulated kinase enzymes. Well-structured QSAR algorithms enable researchers to uncover complex relationships between the molecular structures of anti-kinase agents, leveraging extensive experimental datasets to develop predictive models that serve as powerful tools in the drug design process. Additionally, this review emphasizes the critical importance of comparative evaluations of different QSAR models, highlighting methods with superior predictive power, computational efficiency, and practical applicability. These insights provide a comprehensive understanding of QSAR performance in advancing kinase-targeted drug discovery (Figure 3).

Phases of traditional drug design and development process.

## Section: Eukaryotic protein kinases (components, binding pocket, catalytic domain, and types of inhibitors)

Eukaryotic protein kinase component.

## Section: Eukaryotic protein kinases (components, binding pocket, catalytic domain, and types of inhibitors) › Eukaryotic protein kinase component

Eukaryotic kinases typically exist in a non-active state and become activated only upon being stimulated by a regulatory signal [7]. For instance, Receptor Protein-Tyrosine Kinases (RTKs) are triggered by ligand-induced dimerization. Additionally, Extracellular Signal-Regulated Kinase (ERK) is activated by another kinase known as Mitogen-Activated Protein Kinase (MEK), Cyclin-Dependent Kinases (CDKs) are also activated by their respective cyclins, and the Calcium/Calmodulin-Dependent Protein Kinase is stimulated by the Calcium-Calmodulin complex [8]. Consequently, dysregulation in the kinase activation pathway can lead to human cell cycle abnormalities such as malignancies and inflammatory diseases [8].

Moreover, kinases follow a hierarchical organization into groups, families, and sub-families. Their classification primarily hinges on the amino acid sequences within their catalytic domains, alongside their biological functions [8]. Predominantly protein kinases, comprising nine categories of human kinase groups (please refer to Figure 1). These categories are divided into distinct groups. The AGC group (63 members) includes Protein Kinases A, G, and C (PKA, PKG, PKC), Akt kinases (PKB1–3), Aurora kinases (Aur1–3), and others like PDK1 and RSK1–4. The CAMK group (74 members) features Calcium/Calmodulin-Dependent Kinases (CAMK1, CAMK2, CAMK4), Phosphorylase Kinases (PhKγ1, PhKγ2), Mitogen-Activated Kinase Activators (MAPK2, MAPK3, MAPK5), and Myosin Light Chain Kinases. The CK1 group (12 members) includes Casein Kinases (CK1), Tau Tubulin Kinases, and Vaccinia-Related Kinases. The CMGC group (61 members) comprises Cyclin-Dependent Kinases (CDK1–11), MAPKs, ERK1–5, and GSK3. Other groups include the STE group, activating MAPK cascades, Tyrosyl Kinase (90 members including RTKs and NRTKs), TKL group (43 members), and Receptor Guanylyl Cyclase (5 members). Additionally, 83 atypical kinases are distinct from these families (please refer to Figure 1).

Eukaryotic protein kinase component.

## Section: Eukaryotic protein kinases (components, binding pocket, catalytic domain, and types of inhibitors) › General structure of protein kinases

In general, the catalytic domain of protein kinases consists of a small N-terminal lobe and a large C-terminal lobe, in addition to the active catalytic site that connects the two lobes [9].

The small N-terminal lobe is composed of five anti-parallel β-sheet (β1–β5). The β1 and β2 strands are connected by the P-loop, also known as the Glycine-Rich Loop (GRL). Following this, the αC-helix area occurs in two forms: the active form and the inactive form [8]. Although the αC-helix occurs within the N-terminal lobe, it holds a special position between the small N-terminal lobe and the large C-terminal lobe. Moreover, the P-loop is situated in the N-terminal vicinity and includes the GxGxΦG motif, where “G” represents the glycine amino acid, and “Φ” stands for the hydrophobic areas.

Additionally, the β1- and β2-strands interact with the adenine part of ATP. A valine amino acid appears two residues after the GRL loop within the β2-strand. The valine residue is essential for engaging in hydrophobic interactions either with the adenine portion of ATP bound to the kinase or with the kinase inhibitor positioned within the ATP binding pocket. Protein kinases also contain a lysine sequence within the β3-sheet and a conserved glutamate near the center of the αC-helix, forming a salt bridge that connects the positively charged lysine from the β3-strand with the negatively charged glutamate from the αC-helix [1]. Also, the lysine in this sequence functions by linking the α- and β-phosphates of ATP to the αC-helix [10]. The presence of the salt bridge linking the β3-lysine and the αC-glutamate is vital for establishing the active state of the protein kinase enzyme, typically associated with the “αC-in” conformation. This conformation is indispensable for achieving optimal kinase activity [10].

As mentioned earlier, the general structure of protein kinases also includes the large C-terminal lobe, which is composed of eight α-helical structures (αD, αE, αF, αG, αH, αI, αEF1, and αEF2), in addition to four extra short β-sheets (β6, β7, β8, and β9). It’s worth noting that the ATP binding pocket is part of this large lobe, and the adenine part of ATP interacts with the second residue of the β7-strand [1]. Moreover, the C-terminal lobe harbors a flexible polypeptide chain named the catalytic loop, which facilitates the transfer of a phosphate group from ATP to the serine, threonine, or tyrosine residue on the enzyme substrate. The C-terminal lobe functions by positioning the enzyme substrate into the correct active site to enable catalysis. The middle portion of the active catalytic site of protein kinase families varies with their amino acid sequence. The active catalytic site of the kinase family has residues that can be modified by adding a phosphate group (phosphorylation process), which is required for the initiation of maximal enzymatic activity. In many protein kinases, this activation segment initiates with DFG (Asp-Phe-Gly) sequence and concludes with APE (Ala-Pro-Glu) sequence. Next to the activation segment occurs the conserved catalytic loop segment (His-Arg-Asp (HRD)) sequence and the amino-terminus of the αC-helix [1,11]. The gatekeeper residue is the amino acid positioned near the N6 amine of ATP in all kinases, and it aids in determining the selectivity of the kinase inhibitor, as it can vary in size from a large amino acid like Phe to a small residue like Thr [12].

The kinase catalytic binding pocket can adopt different conformations, most importantly the DFG-IN conformation, in which the DFG (Asp-Phe-Gly) triplet occupies an “in” conformation capable of complexing a Mg2+ atom during the phosphate transfer step. On the other hand, a DFG-OUT conformation in kinases is one in which the DFG triplet is incapable of complexing a Mg2+ atom during the phosphate transfer step [10,12].

## Section: Eukaryotic protein kinases (components, binding pocket, catalytic domain, and types of inhibitors) › Kinase catalytic domains

The structural and functional critical residues within the active conformation of protein kinases entail two spines: The R regulatory spine and the C catalytic spine. The R regulatory spine works by positioning the substrate (recipient protein or enzyme), and the C-spine works by positioning the ATP for catalysis. The two spines occur within the small N-terminal and the large C-terminal lobes. Moreover, the R-spine is composed of four amino acids, and the C-spine is composed of eight amino acids, and both spines are important to generate a catalytically flexible active joint. Regarding the C catalytic spine, two of its eight amino acids belong to the small N-terminal lobe, while the other six amino acids belong to the large C-terminal lobe [1,11].

The hinge region connects the N-terminal and C-terminal lobes. When ATP binds to the catalytic domain through special hydrogen bond interactions, it unites the N-terminal and C-terminal lobes. This is illustrated by the binding of the 6-amino N–H group of the adenine group within the ATP structure with the backbone carbonyl group of the first hinge residue, initiating the transfer of the phosphate group from ATP to the recipient protein or enzyme [1,13]. Additionally, the N1 of the adenine group of ATP acts as a hydrogen-bond acceptor and forms a hydrogen bond with the backbone N–H group of the third hinge residue. This pattern of dual hydrogen bonding in the hinge region is important for catalysis and the potent inhibition of kinases by small molecule inhibitors. Additional hydrogen bonds to the kinase hinge seem to affect only kinase selectivity [13–15].

## Section: Eukaryotic protein kinases (components, binding pocket, catalytic domain, and types of inhibitors) › Types of kinase inhibitors

Kinase inhibitors exhibit diverse binding mechanisms, leading to their classification into several types (I-VI) [12]. These types differ primarily in their binding site (ATP pocket, allosteric site, or both), conformational preferences induced in the kinase, and overall mechanism of inhibition. For instance, Type I inhibitors target the ATP pocket, while Type II inhibitors can occupy both the ATP pocket and an adjacent allosteric site. Other types, like Type III, bind exclusively to allosteric sites, and further subtypes and types with bivalent or covalent mechanisms exist. A more detailed description of these kinase inhibitor types, including specific examples and references, can be found in Supplementary Material Section 2. Please refer to Tables 1S, 2S, 3S, and 4S under supplementary material for a comprehensive list of 80 FDA-approved kinase drugs and their inhibitor types as of November 2023.

## Section: A Brief overview of the history of FDA-approved kinase enzyme modulators

Timeline (1968–2024) showing the simultaneous development of both the science of kinase inhibition and modulation and the computer-aided drug design computational studies including the development of QSAR investigational studies. The development of both sciences simultaneously culminated in 80 USFDA-approved small molecule kinase modulators as of November 2023. Pink boxes represent the development of computational sciences and QSAR studies, the orange boxes represent the development of the kinase modulation science, and the green-boxed represent the USFDA-approved small molecules kinase inhibitors.

## Section: A Brief overview of the history of FDA-approved kinase enzyme modulators › The emergence of kinase-directed therapeutics

The exploration of kinases as crucial regulators in cell cycle processes began in the late 1970s. A pivotal discovery was made in 1977, when Japanese researchers first identified protein kinase C (PKC) (Inoue et al.) [16]. By 1980, the foundational role of epidermal growth factor (EGF) in phosphorylating tyrosine residues on plasma membrane receptors was elucidated by Ushiro and Cohen [17]. This phosphorylation event was recognized as the trigger for a cascade of biochemical processes leading to cell proliferation.

During the mid-1980s, the scientific community viewed kinase binding domains as highly conserved, posing challenges for the development of potent and selective kinase inhibitors. Nevertheless, significant progress was achieved during this period, including the isolation of epidermal growth factor receptor (EGFR) and insulin receptor kinase [18,19]. In 1986, Staurosporine’s inhibitory effect on PKC was confirmed [20], and by 1988, the first sub-micromolar competitive inhibitors for EGFR and insulin receptor kinases were developed [21]. These early inhibitors paved the way for structure-activity relationship (SAR) studies, which began targeting EGFR and insulin receptor kinases.

In 1994, the first selective ATP-mimetic EGFR kinase inhibitor was identified [22,23], marking a critical milestone in kinase inhibitor development. These inhibitors exhibited selectivity for insulin receptor kinase while demonstrating minimal activity against serine/threonine kinases, thereby enabling the generation of preliminary SAR data [21]. This era laid the foundation for advancing kinase-focused drug discovery through computational approaches such as quantitative structure-activity relationship (QSAR) studies (Figures 2 and 3).

It is important to note that kinase inhibitors often target signaling pathways, not just single kinases. For example, the RAF-MEK-ERK pathway is a critical cascade in cancer, and inhibitors have been developed targeting RAF, MEK, and ERK kinases within this pathway. Targeting pathways offers opportunities to modulate signaling more effectively, address pathway redundancy, and potentially develop combination therapies that target multiple points in a pathway for enhanced efficacy or to overcome resistance mechanisms. Consideration of these broader pathway contexts is crucial in kinase drug discovery beyond simply targeting individual kinase enzymes.

Timeline (1968–2024) showing the simultaneous development of both the science of kinase inhibition and modulation and the computer-aided drug design computational studies including the development of QSAR investigational studies. The development of both sciences simultaneously culminated in 80 USFDA-approved small molecule kinase modulators as of November 2023. Pink boxes represent the development of computational sciences and QSAR studies, the orange boxes represent the development of the kinase modulation science, and the green-boxed represent the USFDA-approved small molecules kinase inhibitors.

## Section: A Brief overview of the history of FDA-approved kinase enzyme modulators › Imatinib: a breakthrough in cancer therapy

The approval of Imatinib (STI571, brand name Gleevec®) by the US Food and Drug Administration (FDA) in 2001 heralded the era of small-molecule protein kinase inhibitors. Imatinib, initially developed as a platelet-derived growth factor receptor (PDGFR) kinase inhibitor, was later found to target BCR-Abl and is now employed in treating multiple malignancies, including Philadelphia chromosome-positive (Ph+) acute lymphoblastic leukemia (ALL), chronic myeloid leukemia (CML), and gastrointestinal stromal tumors (GIST) [3,24].

As a polypharmacological drug, Imatinib demonstrates inhibitory activity against multiple kinase targets at clinically achievable concentrations. This versatility underscores its transformative role in oncology.

## Section: A Brief overview of the history of FDA-approved kinase enzyme modulators › Generational advances in BCR-abl inhibitors

Despite the success of Imatinib, resistance caused by mutations in the BCR-Abl kinase domain spurred the development of second-generation inhibitors, including Nilotinib (AMN107, brand name Tasigna®, approved in 2007) and Dasatinib (BMS-354825, brand name Sprycel®, approved in 2006) [11,22]. Nilotinib offers potent activity against most resistant mutations but lacks efficacy against the gatekeeper mutation T315I, where threonine is replaced by isoleucine, preventing binding to the allosteric pocket.

The approval of third-generation inhibitors such as Ponatinib (AP 24534, brand name Iclusig®) in 2012 addressed this limitation, providing effective treatment for the T315I mutation [25]. More recently, Asciminib (brand name Scemblix®), a type IV allosteric inhibitor, has expanded therapeutic options as a novel BCR-Abl-targeted agent [26].

## Section: A Brief overview of the history of FDA-approved kinase enzyme modulators › Non-receptor tyrosine kinase: Janus kinase (JAK) inhibitors

The first oral JAK inhibitor, Ruxolitinib (INCB-018424, brand name Jakafi®), gained FDA approval in 2011 for the treatment of myeloproliferative disorders such as myelofibrosis [27]. Subsequently, Tofacitinib (CP-690550, brand name Xeljanz®), a JAK3-selective inhibitor, was approved in 2012 for active rheumatoid arthritis [11].

While Ruxolitinib advanced treatment options for several conditions, its hematological side effects and suboptimal responses in some cases necessitated further research. This led to the approval of Fedratinib (TG101348, brand name Inrebic®) in 2019 as a second-line treatment for high-risk myelofibrosis [1]. Recent approvals, including Abrocitinib for atopic dermatitis and Momelotinib for myelofibrosis-associated anemia, highlight ongoing innovation in JAK inhibitor development [23,24,28].

## Section: A Brief overview of the history of FDA-approved kinase enzyme modulators › Advances in receptor tyrosine kinase (RTK) inhibitors

The ErbB family of RTKs, including EGFR (ErbB1) and HER2 (ErbB2), has been a major focus of kinase inhibitor development. In 2003, AstraZeneca’s Gefitinib (ZD1839, brand name Iressa®) became the first FDA-approved EGFR inhibitor, followed by Erlotinib (OSI-774, brand name Tarceva®) in 2004 [9,10,16].

Notably, third-generation inhibitors such as Osimertinib (brand name Tagrisso®), approved in 2017, have transformed treatment paradigms for EGFR-mutant lung cancer [29]. With 80 FDA-approved kinase inhibitors as of 2023, the ErbB/EGFR family remains the most extensively targeted category [11,30].

## Section: General overview of quantitative structure-activity relationship (QSAR)

Flow diagram showing the investigational steps during the QSAR model development process.

Quantitative structure-activity relationship (QSAR) descriptors.

USFDA-approved small molecules kinase inhibitors discovered by using the computer-aided drug design (CADD) approach.

Comparative analysis of machine learning and deep learning algorithms for kinase QSAR.

## Section: General overview of quantitative structure-activity relationship (QSAR) › The establishment of the traditional QSAR modelling technique

The beginning of the machine learning era can be traced back to 1968 with the publication of the book “Cybernetics and Forecasting” by Ivakhnenko and Lapa, wherein these scientists investigated modern analytical and computational methods in science [16]. A leading-edge moment occurred 10 years later when Ivakhnenko himself published a revolutionary article in 1978 titled “The group method of data handling in long-range forecasting” [17]. The article focused on the introduction of the “principle of self-organization” in computer modeling. Ivakhnenko proposed that, in applying the principle of self-organization; a researcher could enhance a small amount of statistical data to the computer alongside specific selection criteria for the model. The computer, using this approach, would then systematically analyze several models that met the specified statistical criteria. Through this process, the computer would identify a successful model (a mathematical equation) of optimal complexity. Consequently, the researcher would attain the best model capable of delivering the most compelling predictions. This marked the outset of QSAR studies [2].

From 1980 till 2010, a significant advancement occurred in computing technology, cheminformatics, and the expansion of molecular databases. These developments, rooting through the foundational work in the 1960s and 1970s, paved the way for the emergence of computer-aided modeling. The progress during this period laid the groundwork for a transformative shift in the landscape of machine learning computational chemistry, enabling more sophisticated and refined modeling approaches including the QSAR modeling [2].

Mainly, computer-aided QSAR aims toward reveling a mathematical relationship that can describe an observed bioactivity (IC50, Ki, and ligand efficiency values) for a group of active compounds against a specific target as a function of structural features and meaningful descriptors [18].

The ligand-based computer-aided QSAR modeling process begins the collection and depiction of structures from previously known active molecules available in literature databases. The collected compounds and their activities are forming a preliminary dataset, serving as a foundation for an effective QSAR modeling project. Medicinal chemists and pharmacologists who are performing the QSAR modeling explore and calculate the physicochemical properties of each collected molecule. It is imperative for the QSAR modeling procedure to be accompanied with statistical evaluation, achieved by splitting the collected dataset into training and test sets for internal and external statistical evaluation respectively [19]. Please refer to Figure 4 which represent the flow diagram showing the investigational steps during the QSAR model development process.

The quantitative portrayal of a molecule or a drug property is termed as a descriptor. A descriptor can be a physicochemical or pharmacophoric property. These descriptors are essential in the context of formulating any new QSAR equation. Currently, wide ranges of computable molecular descriptors that are derived from various resources are available. As such, a descriptor can encompass constitutional, electronic, geometrical, hydrophobic, steric, quantum mechanical, or topological properties (please refer to Table 1). Additionally, different applications and softwares can calculate diverse spatial, electronic, topological, and other descriptors. For calculating electronic and quantum mechanical descriptors, Density Functional Theory (DFT) is a significant method. DFT, a quantum mechanical approach, allows for the computation of molecular electronic properties, such as charge distribution, ionization potential, and electron affinity. These DFT-derived electronic descriptors can be particularly valuable in 2D-QSAR models, capturing crucial aspects of molecular reactivity and interactions [31].

Upon conducting the QSAR model development, several multivariate analysis methods are employed. These include, for example, the multiple linear regression method, the principal component analysis method, the neural network method, the support vector machine method, and the K-nearest neighbor method. Subsequently, the successful equation can serve as a template to predict the activity of new hits against the studied target [18].

Generally, the QSAR methods can be classified into different types based on how their descriptors are produced and calculated. QSAR methods are:

It is important to note that a QSAR equation represent a multivariate mathematical relationship between the biological activity (IC50, Ki, and ligand efficiency values) and a set of descriptors. Analyzing the statistically successful QSAR equation helps in comprehending the connection between the chemical structure of a particular drug and its biological activity and so the QSAR tool in the drug discovery and computer-aided applications is regarded as an expletory tool, offering insights into the productive structure-activity relationships among active ligands within their binding pockets (Table 2).

Flow diagram showing the investigational steps during the QSAR model development process.

Quantitative structure-activity relationship (QSAR) descriptors.

USFDA-approved small molecules kinase inhibitors discovered by using the computer-aided drug design (CADD) approach.

## Section: General overview of quantitative structure-activity relationship (QSAR) › Introduction to machine and deep learning QSAR modelling technique

Unlike traditional QSAR methods, which rely on manual feature extraction and descriptor calculation, machine learning QSAR leverages the power of neural networks to automate these crucial steps. This automation has led to the development of more robust and scalable models, especially vital for handling the complexities of modern molecular data.

Deep learning QSAR modeling represents a significant evolution in QSAR, aligning with the advancements in artificial intelligence (AI) [21]. A key innovation is the use of molecular embeddings. These are sophisticated mathematical representations of molecules designed to capture intricate and often non-linear relationships within molecular data. Molecular embeddings enable more efficient and nuanced analysis and prediction compared to traditional descriptors used in QSAR. Importantly, deep learning QSAR integrates molecular representation directly into the model training process [2,24], contrasting sharply with traditional QSAR where descriptor generation is a separate, pre-modeling step.

It’s important to reiterate the distinction between machine learning and deep learning. Machine learning is a broad field encompassing techniques for creating algorithms and predictive models from data. Deep learning is a subfield of machine learning that specifically utilizes neural networks with multiple layers [2,22,24]. Traditional machine learning methods include clustering, regression, outlier detection, linear regression, and support vector machines [21].

A fundamental shift in deep learning QSAR is the integrated approach to molecular representation. As mentioned, traditional QSAR treats descriptor calculation and model training as separate stages. In deep QSAR, however, molecular representations, often in the form of embeddings, are directly incorporated into the neural network’s optimization process. Neural networks themselves are computational models inspired by the human brain, capable of learning intricate patterns and knowledge from raw data and making predictions based on this learned understanding [24].

Unlike traditional QSAR, which relies on pre-defined, standard chemical descriptors, machine learning algorithms can autonomously identify and extract salient features directly from data through their multi-layered architecture. This hierarchical feature extraction, often described as capturing a “butterfly effect” where higher-level features are derived from lower-level outputs, is a key advantage. Deep learning architectures like Convolutional Neural Networks (CNNs) and Recurrent Neural Networks (RNNs) are designed to discern complex patterns and connections with minimal human intervention. This inherent capability makes deep learning exceptionally valuable for drug discovery, particularly when integrated with QSAR modeling techniques [24,32].

## Section: General overview of quantitative structure-activity relationship (QSAR) › Advantages of machine and deep learning in kinase QSAR modeling

Deep learning’s effectiveness in QSAR modeling, especially within drug discovery and kinase research, stems from several significant advantages. Firstly, deep learning models excel at handling large datasets, which are increasingly common in kinase-related pharmaceutical research. They possess the capacity to analyze complex, high-dimensional data and extract insights from diverse sources, including chemical structure properties alongside cellular and biological activity data [2,33].

A critical advantage is deep learning’s ability to perform automatic feature extraction from raw data. In QSAR modeling, this translates to the direct identification of relevant molecular features from chemical structures, significantly reducing the need for extensive manual feature engineering. This automated feature learning not only streamlines the modeling process but also enhances model accuracy by capturing features that might be overlooked by human-designed descriptors [27,33].

Deep learning’s ability to automatically extract features from raw data is a key advantage. Unlike traditional QSAR requiring pre-defined descriptors, deep learning models, particularly CNNs and GNNs, can learn relevant molecular features directly from representations like graphs or voxel grids. This reduces reliance on expert-defined descriptors, potentially uncovering novel, non-obvious features that are crucial for activity prediction and streamlining the model development process significantly.

Furthermore, biological systems and chemical interactions, particularly within kinase-regulated cellular activities, are inherently complex and non-linear. Deep learning models are specifically designed to capture these complex, non-linear relationships through their multiple layers of non-linear transformations. This capability leads to more precise predictions of biological activity and compound efficacy.

Deep learning offers remarkable flexibility and scalability in QSAR tasks. Architectures like Convolutional Neural Networks (CNNs) are well-suited for analyzing spatial arrangements in molecular graphs, while Recurrent Neural Networks (RNNs) are effective for sequential data analysis. Moreover, deep learning facilitates multitask learning, enabling a single model to simultaneously predict multiple properties or activities. This is particularly beneficial in kinase research, allowing for a more holistic understanding of kinase interactions and activities, ultimately improving predictive accuracy and providing deeper insights into target relationships [2,22,27,33,34].

In essence, machine learning has significantly advanced QSAR modeling by overcoming limitations of traditional approaches. Its capacity for autonomous learning from complex data and making precise predictions positions it as a transformative technology in kinase inhibitor discovery and beyond.

QSAR methods, such as CoMFA and CoMSIA, often rely on static, pre-defined molecular descriptors and are limited by smaller datasets. This often results in moderate predictive accuracy, reduced flexibility, and limited scalability. While computationally less demanding, these approaches lack the adaptability to address the complex challenges of modern drug discovery.

In contrast, modern machine learning-based QSAR models, particularly deep learning models like CNNs and RNNs, leverage large datasets and excel at capturing complex, non-linear relationships between molecular features and biological activity. These methods achieve high predictive accuracy, flexibility, and scalability, making them invaluable tools in contemporary drug discovery, despite their increased data and computational demands.

## Section: General overview of quantitative structure-activity relationship (QSAR) › Key machine and deep learning techniques in kinase research

The most prominent machine and deep learning models applied in recent kinase research include Convolutional Neural Networks (CNNs), Recurrent Neural Networks (RNNs), Graph Neural Networks (GNNs), and Multitask Learning Approaches [2,24].

Comparative analysis of machine learning and deep learning algorithms for kinase QSAR.

## Section: General overview of quantitative structure-activity relationship (QSAR) › Key machine and deep learning techniques in kinase research › Convolutional neural networks (CNNs)

Convolutional Neural Networks (CNNs) are a class of deep learning models exceptionally well-suited for analyzing structured data, such as images. In the context of molecular structures and kinase inhibitor activity prediction, CNNs are used to identify patterns and features within molecular representations that correlate with biological activity [24]. CNNs have demonstrated high effectiveness in molecular data analysis, for example, achieving a ROC-AUC of 0.87 in identifying Aurora-A kinase inhibitors [23].

To elaborate on their mechanism within QSAR, CNNs utilize convolutional layers to automatically extract hierarchical features from molecular representations. These layers act as filters, detecting spatial patterns like functional groups or substructures within representations such as 2D molecular fingerprints, 3D voxel grids, or even molecular graphs converted to image-like formats. Pooling layers then reduce dimensionality, focusing on the most salient features. This automated feature extraction removes the need for manual descriptor engineering, allowing CNNs to learn complex relationships directly from raw molecular data.

CNNs offer versatility in how molecules are represented. For kinase inhibitor modeling, molecules can be depicted as graphs (atoms as nodes, bonds as edges), which can then be converted into grid-like structures or “images” processable by CNNs. Alternatively, molecules can be represented as 2D images (e.g., molecular fingerprints) or, for more detailed analysis, as 3D molecular structures in voxel grids. CNNs automatically extract hierarchical features from these representations. Initial layers capture local structural features, while deeper layers identify more complex, global molecular patterns. For predictive modeling, CNNs are trained on datasets where the input is the molecular structure and the output is the biological activity (e.g., kinase inhibitory activity). The training process optimizes network weights to minimize prediction errors, enabling the CNN to learn features relevant to biological activity [24,27,28].

Data preparation for CNN-based kinase QSAR begins with assembling a dataset of known kinase inhibitors with their corresponding activities. These inhibitors are then transformed into a CNN-compatible format, such as 2D images of fingerprints or 3D voxel grids. This transformation is essential for enabling the CNN to learn and effectively predict the activity of novel kinase inhibitors [28].

Model training involves using this labeled data (molecular structures with known activities) to train the CNN. During training, the network learns to recognize patterns and features in the molecular structures that are indicative of biological activity against specific kinases specific kinases [27,28].

Prediction, validation, and testing follow training. Once trained, the CNN can predict the activity of new, unseen kinase inhibitors by inputting their molecular structures. The CNN then generates an activity prediction, either as a continuous score or a categorical label (e.g., active/inactive). Model performance is rigorously evaluated using separate test datasets to ensure generalization to new data. Common evaluation metrics include accuracy, precision, recall, and ROC-AUC to validate the model’s predictive capability [2,28]. In summary, CNNs are powerful tools for kinase inhibitor discovery, leveraging their ability to automatically learn patterns from complex molecular data to analyze known structures and predict the activity of novel compounds.

## Section: General overview of quantitative structure-activity relationship (QSAR) › Key machine and deep learning techniques in kinase research › Recurrent neural networks (RNNs)

Recurrent Neural Networks (RNNs) are designed for modeling sequential data, making them suitable for tasks involving temporal dependencies, such as the dynamics of kinase activities or interactions. RNNs are equipped with internal memory to process input sequences, enabling them to capture patterns that evolve over time [24,35,36]. RNNs, while less directly applied to static molecular structure QSAR than CNNs and GNNs, excel at processing sequential data. Their internal memory allows them to consider the order of input features, making them suitable for analyzing time-dependent kinase activities or potentially sequential representations of molecular properties. In QSAR, their strength lies in capturing temporal dependencies, though their application to static molecular data is less common compared to CNNs and GNNs.

In kinase research, RNNs can model the temporal progression of kinase activation or inhibition. Kinase signaling pathways often involve sequential activation or inhibition events. RNNs can learn from time-series data to predict future kinase activities based on past observations. This is valuable for understanding cellular signaling dynamics and predicting the time-dependent effects of kinase inhibitors time [24,35,36].

Furthermore, RNNs can model sequential interactions between kinases and their substrates. By analyzing sequences of kinase-substrate interactions, RNNs can identify patterns in kinase-substrate recognition, aiding in predicting new kinase-substrate interactions and understanding complex signaling cascades.

## Section: General overview of quantitative structure-activity relationship (QSAR) › Key machine and deep learning techniques in kinase research › Graph neural networks (GNNs)

Graph Neural Networks (GNNs) are specialized models designed for analyzing graph-structured data. This makes them highly relevant for capturing the intricate connectivity and interactions within molecular graphs, which is crucial for understanding kinases and their interactions [24,29]. GNNs directly process molecules as graphs, where atoms are nodes and bonds are edges. They employ a message-passing mechanism, where information is iteratively exchanged between neighboring nodes, allowing the network to learn representations that capture both node features (atom properties) and the connectivity of the molecule. This makes GNNs particularly adept at understanding how molecular structure and interatomic relationships influence kinase interactions and activity, offering a powerful approach for capturing intricate structural features beyond linear descriptors.

In the context of kinases, molecular structures can be directly represented as graphs, with atoms as nodes and bonds as edges. GNNs can learn directly from these graph representations to predict various properties and activities related to kinases [24,29,35].

GNNs are particularly effective at capturing the complex structural and functional relationships between kinases and their interacting molecules (substrates, inhibitors, activators). By aggregating information from neighboring nodes in the molecular graph, GNNs can learn to predict kinase activities, substrate specificity, and binding affinities [24,29,35].

## Section: General overview of quantitative structure-activity relationship (QSAR) › Key machine and deep learning techniques in kinase research › Multitask learning approaches

Multitask learning, a powerful technique within machine learning, is used to simultaneously predict multiple kinase activities and interactions, enhancing predictive capabilities and learning efficiency. Algorithms and frameworks like multitask neural networks (MTNNs) and multitask graph neural networks (MTGNNs) are employed, leveraging shared representations across related tasks to improve generalization [37].

Platforms like KinomeX exemplify the application of multitask learning in kinase research. KinomeX uses multitask neural networks to predict multiple kinase activities, capturing shared features across kinases for more accurate predictions and exploration of kinase interactions and cross-reactivity. Integrating data from diverse sources (chemical structures, biological assays, protein interaction networks), KinomeX offers a comprehensive approach to kinase behavior understanding. Case studies and publications demonstrate KinomeX’s utility in enhancing predictive performance, modeling complex biological processes, and generating holistic insights for kinase inhibitor discovery [37].

Comparative analyses show that KinomeX and similar multitask approaches often outperform traditional single-task QSAR models and other multitask learning methods. These approaches offer improved prediction accuracy, robustness, and facilitate the discovery of novel kinase interactions and inhibitor candidates. Tools like DeepKinZero and DeepKinNet also utilize multitask learning for kinase inhibitor activity prediction across multiple targets, aiding drug discovery and design processes [21,24,37]. The potential impact of multitask learning in kinase research and drug discovery is significant, promising advancements in computational biology and medicinal chemistry, and potentially transforming disease understanding and treatment.

## Section: General overview of quantitative structure-activity relationship (QSAR) › Key machine and deep learning techniques in kinase research › Machine learning QSAR modeling and validation framework for comparison

To provide a comparative context, machine learning QSAR models are often developed and used as baselines for validation. Ensemble learning methods, specifically Random Forest (RF) and Support Vector Regression (SVR), are commonly employed for this purpose. RF and SVR, while distinct, are both widely used and effective machine learning algorithms.

Random Forest (RF) is an ensemble method suitable for both classification and regression. It combines predictions from multiple decision trees, trained on random data subsets, enhancing overall performance. RF is robust to noise, handles diverse data types, and reduces overfitting, though it can be computationally intensive and less interpretable than single trees.

Support Vector Regression (SVR) extends Support Vector Machines (SVM) for regression, fitting a hyperplane within a tolerance margin. SVR excels with non-linear data using kernels (linear, polynomial, RBF), is effective for small to medium datasets with complex relationships, and resists overfitting when tuned. However, it’s sensitive to hyperparameter choice and computationally demanding for large datasets, especially with non-linear kernels. RF is generally better for larger, noisy datasets, while SVR is suited for smaller datasets with intricate patterns.

Molecular descriptors, including hydrophobicity, molecular weight, topological indices, and electronic properties, are typically calculated using tools like RDKit and KNIME for these baseline ML models. Feature selection, often using Recursive Feature Elimination (RFE), is performed to optimize model performance.

Datasets for QSAR model development are often sourced from curated resources like ChEMBL and NCI databases. These datasets, comprising kinase inhibitors with activity data, are crucial for QSAR applications. Data preprocessing typically involves removing duplicates, normalizing activity values, and applying filters like Lipinski’s Rule of Five. Datasets are then split into training and testing subsets (e.g., 70% training, 30% testing). Databases such as ChEMBL, PubChem, PDB, BindingDB, ZINC, DrugBank, and the NCI Database are invaluable, providing bioactivity data, structural information, and chemical libraries essential for training QSAR models, virtual screening, and broader drug discovery applications [38–41].

Performance metrics used for model evaluation include RMSE, R2, sensitivity, specificity, and ROC-AUC. In comparative validation, the focus is often on qualitative comparisons of model performance rather than solely presenting numerical results. For example, Random Forest and Graph Neural Networks may be shown to demonstrate robust predictive power and generalizability based on consistent performance across validation datasets. Convolutional Neural Networks might excel in capturing complex molecular relationships in datasets with non-linear activity profiles. Support Vector Regression might show slightly less robustness compared to ensemble and deep learning models across diverse datasets. This qualitative approach emphasizes the comparative strengths and weaknesses of different methodologies based on their performance metrics on validation datasets, providing a nuanced understanding beyond just numerical output values.

## Section: General overview of quantitative structure-activity relationship (QSAR) › Key machine and deep learning techniques in kinase research › Perturbation theory machine learning (PTML) for kinase drug discovery

Perturbation Theory Machine Learning (PTML) offers a valuable and distinct approach within kinase-targeted drug discovery, uniquely addressing the prediction of kinase-relevant phenotypic activity. Moving beyond target-level kinase inhibition, PTML models complex biological responses at the cellular level, crucial for translating in-vitro results to in-vivo efficacy of kinase inhibitors. PTML models provide key advantages for kinase research:

PTML’s utility in kinase and cancer research is evidenced by a range of successful applications. For instance, PTML has been employed to design virtual agents targeting lung cancer cell phenotypes [42], and has aided in the design of inhibitors for pancreatic cancer that target multiple kinases and cell lines simultaneously [43]. Furthermore, PTML has facilitated the design of dual inhibitors, such as those targeting CDK4 and HER2 [44]. Cell-based PTML models have also been developed to design inhibitors specifically for liver cancer cell lines [45]. These diverse examples underscore PTML’s significant value in kinase drug discovery, particularly when considering phenotypic outcomes and polypharmacological aspects. This demonstrated utility positions PTML as a crucial approach within the broader landscape of kinase machine learning.

While deep learning excels in complex kinase data analysis, PTML provides a complementary approach focused on phenotypic relevance and interpretability, critical for translating kinase inhibition to therapy. PTML, often prioritizing mechanistic insight, can be integrated with deep learning for hybrid approaches. The optimal strategy for kinase-targeted drug discovery depends on research goals and data, balancing prediction, interpretability, and phenotypic focus.

A comparative overview of the machine learning and deep learning methods utilized in this research is presented in Table 3. This table outlines their core principles, advantages, and limitations in the context of kinase QSAR.

Comparative analysis of machine learning and deep learning algorithms for kinase QSAR.

## Section: Kinase enzyme QSAR studies › The evolution and impact of QSAR studies in kinase inhibitor discovery

Until the late 1980s and early 1990s, there were no significant systematic efforts reported to investigate the kinase modulators or to study the kinase inhibitory structure-activity relationship due to the highly conserved ATP-binding domains among the kinases [46,47].

The 1992 Nobel Prize in Medicine and physiology was awarded to Edmond Fischer and Edwin Krebs for their discovery of the reversible protein phosphorylation-dephosphorylation process as a biological regulatory mechanism [25,48,49]. This discovery is considered as the real beginning of the small-molecule kinase modulator research.

In 1996, Hu et al. published one of the first articles focusing on the protein kinase C (PKC) inhibitors and their structure-activity relationship [50]. PKC is a key element in the human transduction pathway, also it belongs to the family of serine/threonine protein kinases which was discovered by the Japanese scientist Nishizuka and coworkers in 1977 [51–54].

The article focused on the advances of some PKC inhibitors based on their chemical class: Staurosporine, Balanoids, Sphingolipids, Isoxazolones, and natural products [50].

Later, as reported in a 1996 publication by Druker et al., Imatinib itself was designed by using a known structure of the ATP binding pocket, a series of chemical derivatives from the 2-phenylaminopyrimidine class were synthesized and screened for their ability to inhibit a several protein kinases [55]. Following, the drug was subjected to numerous SAR studies and was used to guide the design and discovery of new kinase inhibitors [56,57]. Since 1998, concepts such as drug-likeness, lead-likeness, fragment-based drug design, and target-focused drug design approaches have been developed successively.

The primary factor that contributed to the development of the kinase SAR studies was the disclosed information related to the Imatinib discovery. After the approval of Imatinib, the QSAR field has improved intensely, fueled by the escalated availability of the experimental data sets related to kinase active compounds. These changes occurred concurrently with the advances in chemometric and chemical analysis techniques, resulting in an upsurge in the number of chemical and physical descriptors. Additionally, during the early 2000s, there was a growing interest in advanced computer-aided modeling techniques available for QSAR studies.

In 2002, research on QSAR studies regarding candidates for kinase targets was limited. For instance, Manallack et al. utilized a series of neural networks to identify compounds that specifically interact with kinases [58,59]. At that time, the pharmaceutical industry emphasized the early identification of compounds likely to fail in the later stages of drug design and development, following the so-called “fail fast, fail cheap” approach [58,59].

The application of QSAR studies against the kinase enzymes as an evaluative approach, i.e., with the focus on developing an explanatory model of previously published data was accelerated in 2003. It was when Kamath & Buolamwini explored two members of the family of RTK, namely EGFR and HER-2 receptors, by applying the Comparative Molecular Field Analysis (CoMFA) and the Comparative Molecular Similarity Analysis (CoMSIA) QSAR studies on a group of 50 active benzylidene malonitrile tyrphostins derivatives. The study evaluated the binding mode of the studied compounds inside the EGFR and HER-2 ATP binding pocket and explained the selectivity of the dihydroxy compounds toward the EGFR relative to HER-2. The study also concluded that the active compounds are more likely having multiple binding modes at the EGFR binding site and only one binding mode inside the HER-2 receptor [60,61].

In 2005, only four kinase inhibitor compounds had reached commercial use: fasudil for rho kinase which was only approved in Japan in 1995 for treating cerebral vasospasm [51,62], sirolimus for mammalian target of rapamycin (mTOR), Imatinib for BCR-Abl, and Gefitinib for EGFR [47,51]. In that same year, Sprous et al. published article describing a simple QSAR model that is directed to distinguish kinase inhibitors from other drug-like compounds [47]. The method applied 1D and 2D descriptors in a multivariable QSAR model to determine the chemical space within a library of known kinase inhibitors. The model correctly identified 98% of the 258 training set compounds and allowed the recognition of the kinase inhibitor space.

The scientific advancement of the QSAR studies experienced a surge during the second decade of the 21st century. This was propelled by the collective scientific efforts of researchers worldwide. Notably, Alexander Tropsha and his colleagues at North Carolina University made a dramatical contributions to the development of the QSAR modeling approaches. Their research studies have contributed to the transition of the QSAR studies from being an evaluative method to becoming a practical drug discovery approach that can aid in screening and identifying novel biologically active compounds [32,34,63,64].

Accordingly, QSAR and other Computer-aided drug design and machine-learning tools have recently affected the drug discovery efforts in many aspects. For example, fragment-based lead discovery (FBLD) was used efficiently to design and synthesize Vemurafenib (code PLX-4032, brand name Zelboraf®) (please refer to Table 3S under supplementary material: Serine/Threonine Protein Kinase Inhibitors: B-Raf). Vemurafenib was found active against cancer cells with mutated Raf (V600E). During the process of FBLD, the drug is built up from small fragments. Originally, a library of small fragments is screened against the target, then small fragment binding potential values are established using Nuclear Magnetic Resonance (NMR) and X-ray crystallography. Next, the active hits are synthesized and examined against the investigated target. Surprisingly, Vemurafenib took only 6 years from concept to market and was approved in 2011 [65].

Still, the QSAR modeling is considered as one of the promptest methods in computer-aided drug design since it helped drug designers and medicinal chemists to understand the relationship between kinase enzyme activity and the molecular properties of the targeted inhibitors. Henceforth, QSAR studies are considered as promising technique in synthesizing novel, potent and selective kinase enzymes modulators. And so, when combined with other computational techniques, the QSAR tool has proved to provide rational insights to facilitate the discovery of novel hits, leads, and to treat dysregulated protein kinase enzymatic activity [10,18,66].

## Section: Kinase enzyme QSAR studies › Revolutionizing kinase inhibitor discovery: the impact of machine learning on QSAR modeling

CNNs, RNNs and GCNs studies show the significant influence of deep learning on QSAR modeling for kinase inhibitors. Advanced deep learning techniques have led to significant breakthroughs in kinase research. These efforts have not only improved the accuracy of predicting kinase inhibitor activity but have also accelerated the identification and development of new therapeutic agents.

In a study entitled “Integrating QSAR modeling and deep learning in Drug Discovery: the emergence of deep QSAR” published online in 2024, Tropsha et al. [2] have concluded that deep learning methods, particularly deep QSAR, have not yet led to approved drugs, but they have significantly accelerated preclinical research stages for small-molecule drug candidates. For example, Exscientia’s first AI designed drug entered a phase I clinical trial after only 12 months of exploratory research, while In-silico Medicine developed a phase I anti-fibrotic clinical candidate in 30 months starting from target discovery. Both companies utilized deep learning approaches discussed in this perspective. These successes indicate that deep QSAR is entering a productive phase, likely leading to faster discovery of small-molecule drugs, crucial especially in addressing emerging infectious diseases like COVID-19 [24,37,67].

In a recent study by Nippa et al., an ensemble of 100 deep QSAR models was trained using the ELECTRA algorithm (Efficiently Learning an Encoder that Classifies Token Replacements Accurately) [2,22,67]. These models predicted the extent to which compounds would inhibit phosphoinositide 3-kinase-γ (PI3Kγ), each with slightly different results. Testing showed that the number of votes a compound received was generally reflected in how well it performed in lab tests. The top-scoring compound inhibited the target PI3Kγ, with a Ki of 63 nM [22,67].

In the context of multitask learning approaches Liu et al. demonstrated that multi-task learning, which models docking data for both new and known targets, outperforms single-task and active learning approaches. Emerging methods also use deep learning to predict protein-ligand interactions, allowing for extensive target profiling of various chemicals. For example, Li et al. developed a kinome-wide multi-task deep neural network model using around 140,000 data points from 391 kinases. This model mapped a comprehensive kinome interaction network and led to the creation of KinomeX, an online platform predicting kinome-wide polypharmacology based on 2D molecular structures [22,24,37].

Deep learning improves the accuracy of ligand binding affinity and property calculations. For instance, the ANI molecular mechanics scheme has been expanded to predict protein-ligand binding free energies, which are crucial for deep QSAR modeling. This approach combines molecular dynamics simulations of the protein-ligand complex with molecular mechanics and machine learning potential energies [2,24,33]. Studies testing this approach with kinase inhibitors demonstrated significant improvements in predicting binding affinities, reducing absolute binding free energy errors compared to traditional molecular mechanics calculations. Notably, the corrections from molecular mechanics to machine learning-molecular mechanics were positive and helped improve the accuracy of predictions, particularly for aliphatic groups with high conformational flexibility [24,36].

One emerging trend in the application of deep learning to kinase research is the integration of generative models for designing novel inhibitors. Generative models, such as variational autoencoders (VAEs) and generative adversarial networks (GANs), offer the potential to generate novel molecular structures with desired properties. By leveraging large datasets of kinase inhibitors, these models can aid in the discovery of new compounds with specific activity profiles, potentially accelerating drug development processes [2].

Integrating deep learning into kinase research promises to revolutionize drug discovery by enabling accurate predictions of drug activity and personalized treatment design. These advancements could lead to targeted therapies that improve outcomes and reduce adverse effects.

## Section: Case studies: investigating dysregulated kinase enzymatic activity using QSAR

To illustrate the practical application and impact of QSAR studies in kinase research, this review now examines several case studies focusing on dysregulated kinase targets of significant scientific and therapeutic interest. These case studies, detailed in Supplementary Material Section 3, highlight QSAR investigations on Cyclin-Dependent Kinases (CDKs), Moloney-Murine Leukemia Virus Kinases (PIM-1, PIM-2, and PIM-3), Ca2+/Calmodulin-Dependent Protein Kinase II (CAMKII), Polo Kinase 1 (Plk1), and Tropomyosin Receptor Kinase A (TrkA). These examples showcase how QSAR modeling has been employed to understand inhibitor binding modes, identify key structural features for activity, and guide the design of novel kinase inhibitors for disease management and treatment. While Computer-Aided Structure-Based Drug Design (SBDD) has directly contributed to FDA-approved kinase inhibitors, these case studies underscore the significant evaluative and explanatory role of QSAR in kinase drug discovery, providing valuable insights from previously published data and paving the way for future advancements. For in-depth analysis of each case study, please refer to Supplementary Material Section 3.

## Section: Limitations and challenges

Since the 1980s, kinase-based drug discovery has overtaken other drug discovery targets as the most investigated cellular targets for disease treatment [11]. Despite the achieved advancement, several limitations and challenges are reflected during the exploration of new kinase-based approved drugs.

As mentioned earlier, the ATP binding domains of kinase enzymes are more conserved than those of the other substrate binding domains [46]. Additionally, the high intracellular ATP concentrations require high intracellular concentrations of the kinase inhibitors. Accordingly, the scientists found it much simpler to search for substrate competitive kinase inhibitors rather than ATP competitive kinase.

Essentially, only a fraction of the human kinases has been the focus of small molecule drugs, leaving a significant portion of the kinases understudied and unexploited [68]. Some references indicate that approximately 70%, or around 400 kinases, within the kinome is still not investigated [69]. It’s acknowledged that most kinase modulation efforts are directed toward the tyrosine kinase group (e.g., EGFR, FGFR, PDGFR) this is clearly illustrated by the fact that as of November 2023, inhibitors of Protein-Tyrosine Kinases account for more than 40 FDA-approved therapeutic agents [1,11].

Second, most of the FDA-approved kinase modulators are targeting cancer treatment although the kinase signaling cascades are related to diverse cellular activities, for example, inflammatory, CNS, cardiovascular, and diabetes activities.

Third, many of the current kinase inhibitors share the same core with some different substituents. Thus, this is reflected by the limited number of FDA-approved kinase inhibitor compounds.

Fourth, the high amino acid sequence similarity inside the ATP-binding pockets of kinases has been proven challenging to develop kinase inhibitors with potent inhibition against selective targets and minimal interactions with off-targets.

Fifth, closely connected with the previous point, many inhibitors interact with more than one target. By contrast, few absolute-selective inhibitors, which might be evaluated as dual- or multiple-target inhibitors if a more comprehensive screening assay was used.

## Section: Conclusion

Quantitative Structure-Activity Relationship (QSAR) modeling remains a powerful and advanced approach for kinase-targeted drug design, offering significant potential in modern pharmaceutical research. While structure-based design and other methodologies have contributed to the kinase inhibitors currently available, QSAR provides a valuable ligand-based perspective, particularly when enhanced by modern machine learning techniques. Historically, QSAR has served as an evaluative tool and a predictor of drug-likeness and ADME properties in early drug discovery. The aspiration to utilize QSAR models as accurate filters for virtual screening and to identify crucial activity-driving molecular descriptors remains a central goal.

The integration of machine learning, especially deep learning, offers a transformative path forward for QSAR in kinase inhibitor discovery. These methods enhance QSAR by automating feature extraction, handling complex datasets, and capturing non-linear relationships often missed by traditional approaches. However, the interpretability of these complex models is crucial for accelerating drug design. To maximize impact, future efforts must prioritize model interpretability, employing techniques such as feature importance analysis, attention mechanisms, and Explainable AI (XAI) methods to unlock actionable insights from these powerful models. These interpretable insights, revealing key structural determinants of kinase activity, can directly guide medicinal chemistry optimization and accelerate the design of novel inhibitors.

While statistical validation remains important, a renewed emphasis on experimental validation, including preclinical and clinical studies, is essential to translate QSAR findings into tangible drug discovery progress. Moving beyond purely statistical validation, future kinase QSAR studies should focus on prospective experimental validation to confirm model predictions and drive the design and optimization of novel bioactive kinase modulators.

The field of kinase-targeted drug discovery is rapidly advancing through the integration of machine learning QSAR, as evidenced by collaborative validation efforts like the IDG-DREAM Drug-Kinase Binding Prediction Challenge (see Supplementary Material Section 1 for details). Such initiatives underscore the growing confidence in computational methods and their potential to accelerate the development of novel therapeutics.

In conclusion, the synergy of QSAR modeling with advanced machine learning, particularly when coupled with strategies to enhance model interpretability and rigorous experimental validation, holds immense promise for advancing kinase-targeted drug discovery. QSAR, enriched by these modern approaches, can unlock new clinical opportunities, predict undesired side effects, and ultimately accelerate the development of more effective and safer kinase inhibitors. Future research should focus on refining QSAR modeling procedures, integrating interpretability techniques, and prioritizing experimental validation to fully realize the potential of QSAR in the kinase modulator drug discovery process.

## Section: Future perspectives

The future of QSAR modeling in kinase inhibitor research is exceptionally bright, building upon a rich history of computer-aided drug design efforts targeting these crucial enzymes. QSAR models, now increasingly sophisticated, represent a powerful distillation of extensive biological and chemical knowledge accumulated against kinase targets. The critical next step is to fully leverage this knowledge for tangible advancements in preclinical and clinical kinase inhibitor development.

One key direction lies in the continued refinement and expansion of QSAR methodologies through the deeper integration of advanced machine learning techniques. Deep learning, with architectures like Convolutional Neural Networks (CNNs), Recurrent Neural Networks (RNNs), and Graph Neural Networks (GNNs), will undoubtedly play an increasingly central role. However, future progress must prioritize model interpretability. Developing and applying techniques to understand why these complex models make their predictions will be paramount. This includes incorporating Explainable AI (XAI) methods, attention mechanisms, and feature importance analyses to extract actionable insights into ligand-target interactions and guide rational kinase inhibitor design.

Furthermore, the integration of Perturbation Theory Machine Learning (PTML) represents a highly promising avenue. PTML’s focus on predicting phenotypic activity, coupled with its inherent interpretability, directly addresses the critical need to translate target-level kinase inhibition to cellular and in vivo efficacy. Future research should explore hybrid approaches that combine the strengths of PTML with deep learning, potentially using deep learning for feature extraction within a PTML framework or employing PTML to validate and interpret findings from deep learning QSAR models.

Crucially, the field must move beyond statistical validation and embrace rigorous experimental validation. Future QSAR studies should prioritize prospective validation, designing experiments to specifically test model predictions in preclinical and, where feasible, early clinical settings. This iterative cycle of model building, experimental testing, and model refinement will be essential to build truly robust and predictive QSAR models that can significantly accelerate kinase inhibitor drug discovery.

Looking ahead to the next 5–10 years, the integration of advanced QSAR and machine learning techniques promises a transformative era in kinase inhibitor discovery. We anticipate the development of highly predictive, interpretable, and experimentally validated models capable of significantly streamlining virtual screening to efficiently identify promising candidates, guiding rational lead optimization by providing detailed structure-activity insights, predicting phenotypic efficacy and polypharmacology to enhance clinical translatability, and ultimately accelerating the discovery of novel kinase targets and therapeutic strategies. By prioritizing interpretability, experimental validation, and synergistic integration of diverse machine learning approaches, the future of QSAR in kinase inhibitor research is poised to fully realize its potential in accelerating and enhancing the development of life-saving kinase-targeted therapies.

## Section: Acknowledgments

The authors would like to thank the Deanships of Scientific Research at The Hashemite University for funding this project.

## Section: Funding Statement

The authors would like to thank the Deanships of Scientific Research at The Hashemite University for funding this project. The authors certify that financial support was received for this research and/or the creation of this work, the sources and extent of involvement of which are clearly identified in the manuscript.

## Section: Author contributions

Rand Shahin, Associate professor, r.shahin@hu.edu.jo, Main author. Sawsan Jaafreh, Assistant professor, sawsan.jaafreh@hu.edu.jo, analysis, or interpretation and drawing the graphs in addition to revising the manuscript. Yusra Azzam, Undergraduate student, yusraazz@ub.edu, Language editing. Adding scientific information regarding AI, machine learning and deep learning QSAR.

## Section: Disclosure statement

The authors have no other relevant affiliations or financial involvement with any organization or entity with a financial interest in or financial conflict with the subject matter or materials discussed in the manuscript apart from those disclosed.

## Section: References

Papers of special note have been highlighted as either of interest (*) or of considerable interest (**) to readers.


---

# Transformative Role of Artificial Intelligence in Drug Discovery and Translational Medicine: Innovations, Challenges, and Future Prospects

- **Authors:** Grace Edet Bassey, Ernest Aniefiok Daniel, Kazeem Bidemi Okesina, Adeyemi Fatai Odetayo
- **Issuer:** Drug design, development and therapy
- **Type:** Scientific article
- **Published:** 2025-08-29
- **Language:** en
- **DOI:** 10.2147/dddt.s538269
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40909917/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractIntroductionThe use of Artificial intelligence in drug discovery is changing the field of Medicine across the world today positively. In this review, the role of AI in each focus area for the improvement of the drug development process, and its relevance in translational medicine is discussed.Materials and MethodA systematic review was conducted by searching databases such as PubMed and Scopus, employing key terms like “AI” “drug discovery” “machine learning” “clinical trials” and “translational medicine.” Inclusion criteria focused on peer-reviewed studies published between 2014 and 2024 that specifically addressed the role of AI in drug development. Data extraction involved categorizing findings based on different phases of drug discovery.ResultsThe findings reveal that the use of AI lowers costs, shortens the time required for drug development, and enhances the predictive capability. AI technologies play an essential role in molecular modeling, drug design and screening, and the efficient design of clinical trials. However, some of the issues that remain include the quality of available data, issues of interpretability of the models, and the more critical issue of ethical considerations that need collective efforts on the development of associate regulatory policies.ConclusionAI holds immense potential to dramatically change and transform the process of drug discovery and translational medicine while promoting accurate prevention and cures. However, it is also important to understand how to work with existing problems to make the best use of AI in healthcare. The roles of AI technologies are likely to grow in the development of the medical future, provide patients with better results, and stimulate the innovations in the field of the drug creation.Keywords: artificial intelligence, drug development, machine learning, translational medicine, clinical trials, personalized treatment

## Section: Introduction

The waiting period from drug discovery to development is getting longer per day since the search for various active compounds is becoming more time consuming and challenging owing to the expansion of chemical space. In order to reduce this waiting period, experts in the field of medicinal chemistry are now introducing the use of artificial intelligence (AI) to transform the pharmaceutical industry.1,2 The traditional process of drug discovery is a stressful and time-consuming task that involves labor-intensive methods including high-throughput screening and trial-and-error research.3,4 However, the ability of AI techniques to accurately analyze big data within a short period will potentially accelerate the medication discovery process. Hence, introducing the use of AI in different stages of drug discovery (such as identifying potential drug targets, screening through large chemical libraries, preclinical testing, and clinical trials) is crucial for significantly reducing the waiting period from drug discovery to development.5,6

Pharmaceutical industries are commonly associated with rather long and expensive processes of drugs’ creation. In a research work on drug development,7 it reports that the process of developing new drugs will cost about $ 4 billion and that it will take more than 10 years to complete. This financial burden and delay resulting from drug discovery can be prevented by the companies that build their discovery processes on the foundation of AI. Besides accelerating the discovery of drugs, AI also makes it possible to precise medication, with the use of genes and characteristics of a patient.5 It is noteworthy that AI systems can find numerous biomarkers and outline specific reactions of various patients to various treatments – one of the objectives of translational medicine.8

It can be seen that the application of AI is not limited only to drug discovery. Its importance can be summarized in the fact that it plays an active part in translational medicine, the branch of medicine that focuses on the translation of research discoveries into clinical practice.9 Translational medicine aims to fill a gap between the laboratory and the patient, to make it possible for scientific discoveries to be translated into clinical practice in terms of therapies.10 Machine learning (ML), deep learning (DL), and natural language processing (NLP) are used for the discovery of biomarkers and their application in predicting drug interactions and patient treatment plans based on patient characteristics10 which are the basics of translational medicine.

The main objective of this review paper is to provide a structured outlook and apperception of AI in drug discovery, development, and translations. This systematic review seeks to discuss how AI is being utilized in an aspect of drug development; from target identification, compound selection, and drug design to clinical trials, and how these advances supplement the concept of personalized medicine. Moreover, this review will present ideas about the integration of AI into other areas of healthcare and the benefits of AI in decreasing costs, accelerating the process of approval for new drugs, and increasing the accuracy of patients’ results.

## Section: Methodology

PRISMA flow diagram showing identification, screening, eligibility, and inclusion of studies (2014–2024).

Inclusion and exclusion criteria.

## Section: Methodology › Search Strategy

This systematic review followed PRISMA guidelines (Figure 1) to ensure precision and transparency. The search strategy involved querying multiple databases, including PubMed, Scopus, Web of Science, and IEEE Xplore, as well as gray literature from Google Scholar. Key terms such as “Artificial Intelligence” “Drug Discovery” “Machine Learning” “Deep Learning” “Translational Medicine” and “Clinical Trials” were combined using Boolean operators (AND, OR) to refine search results.

PRISMA flow diagram showing identification, screening, eligibility, and inclusion of studies (2014–2024).

## Section: Methodology › Materials

The materials for this review consist of peer-reviewed journal articles, conference papers, regulatory guidelines, and technical reports. Additional sources were included from the reference lists of key studies to ensure comprehensive coverage. The review also incorporated guidelines and regulatory perspectives from organizations such as: the Food and Drug Administration (FDA), European Medicines Agency (EMA), and World Health Organization (WHO). The selected studies provided insights into AI’s role in different stages of drug discovery, preclinical development, and translational medicine. Notably, real-world applications, such as AlphaFold for protein folding and Insilico Medicine’s AI platform, were used as case studies to illustrate AI’s practical impact on drug development.

## Section: Methodology › Inclusion and Exclusion Criteria

Inclusion and exclusion criteria.

## Section: Methodology › Inclusion and Exclusion Criteria › Inclusion Criteria Include

Inclusion and exclusion criteria.

## Section: Methodology › Data Extraction

Relevant data were extracted from selected studies, focusing on key AI techniques used (eg, machine learning, deep learning), the phase of drug development discussed (eg, discovery, preclinical, clinical), and specific outcomes (eg, increased efficiency, cost reduction, prediction accuracy). Data were tabulated to identify recurring themes, emerging trends, and notable outliers.

## Section: Methodology › Data Synthesis and Analysis

A thematic analysis was employed to categorize data according to AI techniques and their applications across different stages of drug development. Studies were grouped into three main categories: AI in drug discovery, AI in preclinical/clinical development, and AI in translational medicine. This approach enabled a comparative analysis of how AI is impacting each phase, identifying key challenges and potential areas for future research.

## Section: Main Findings › AI in Drug Discovery › Molecular Modeling and Drug Design

Artificial Intelligence and ML are notably transforming the early stages of drug discovery, especially molecular modeling and drug design.11 As mentioned in the study of Selvaraj et al,12 DL and reinforcement learning techniques have the potential to accurately forecast the physicochemical properties as well as biological activities of new chemical entities. While, Jiménez-Luna et al13 disclosed that by learning from big data of already familiar molecular structures, the use of ML models is capable of predicting the binding affinities of these molecules, which shortens the process of identifying drug prospects. They include the application of generative adversarial networks (GANs) in generating new compounds that meet particular biological properties to speed up the slow and costly drug design process.8

The traditional ML techniques are also being utilized to model the molecular activity and provide the structural conformation of proteins.5 This has resulted in a groundbreaking existence like AlphaFold, an AI system from DeepMind that can predict protein structures with near-experimental accuracy.14 AlphaFold shows great value as drug designing carries out a major difference in predicting protein folding particularly how drugs interact with their targets hence improving the design of new drugs.15

## Section: Main Findings › AI in Drug Discovery › Virtual Screening and Prediction

AI models are now becoming gold-standard tools for enhancing computational virtual screening, a technique common in the chemical sciences for assessing large databases of compounds.16 That is why, with the help of DL algorithms, AI for the identification of new molecules for further development can analyze the properties of millions of molecular compounds.17 This approach was shown to be much faster and less expensive compared to other conventional high-throughput screening techniques such as HTS.15 AI systems can also predict how compounds will behave within the body and how toxic they are even before the real process of drug development starts.18

For instance, few studies13,19,20 demonstrated that Insilico Medicine, an AI-driven biotechnology company, has developed AI-based platforms that identify novel drug candidates by screening vast chemical libraries. Also, the company’s AI-driven drug discovery system has been used to identify promising treatments for fibrosis and other complex diseases.21 Strikingly, this AI platform designed a novel drug candidate for idiopathic pulmonary fibrosis in just 18 months. Additionally, Moingeon22 highlighted that AI platforms like Atomwise support convolutional neural networks (CNNs) predict molecular interactions, which has accelerated the development of drug candidates for diseases such as Ebola and multiple sclerosis. Interestingly, this AI platform identified two drug candidates for Ebola in less than a day.

## Section: Main Findings › AI in Preclinical and Clinical Development › Drug Repurposing and Optimization

AI has been most useful in drug repurposing, the process of identifying new uses of drugs that are already licensed.23 According to Tanoli et al,24 AI models can predict the compatibility of known drugs with new targets from large datasets of drug–target interactions as this accelerates the development of drugs from new molecules, which is time-consuming and costly. For example, Benevolent AI supplemented AI to discover the repurpose of Baricitinib, a drug used for rheumatoid arthritis as an applicant to cure COVID-19. It has since been granted emergency use status for the management of severe forms of the virus.25 AI is also used in drug improvement to help pharma businesses enhance the drug and its dosing schedule further.18 Advanced mathematic modeling may help to control the pharmacokinetics and pharmacodynamics of medicine providing high efficacy and low toxicity.26

## Section: Main Findings › Preclinical Testing

In preclinical, AI is used to infer drug toxicity and density, thereby avoiding the use of animal models. Machine learning models can analyze biological data that would allow researchers to simulate the behavior of a drug in the human body.24 This not only saves the number of tests conducted on animals but also speeds up the preclinical stage as the critical safety issues are indicated at this phase.27 AI is also used in Silico models that mimic human organs and disease states making realistic predictions of drug effectiveness and side effects before clinical trials.28 These are human organs’ “digital clones” that provide insights into drug–tissue interactions to minimize failure in subsequent clinical trial phases.29

## Section: Main Findings › Clinical Trials

AI finds application in patient recruitment, trial design, as well as trial outcomes. Electronic Health Records (EHRs) can be processed to find the subjects for clinical trials; this is especially desirable for clinical trials concerning rare diseases.30 AI can also design malleable clinical trials that require changes midstream in variables such as dose or patient population; this dynamic approach enhances the trial feasibility.31 In addition, it is utilized in making prognosis on patient outcomes as well as enhancement of the trial strategies.32 These models would be assessing markers that show the primordial signs of either benefit from treatment or lack of it, leading to dynamic changes to trials as it helps to shorten the period for a drug to reach the market besides enhancing patient safety by identifying side effects fast.3,33,34

## Section: Main Findings › AI in Translational Medicine › Personalized Medicine

AI’s role in translational medicine is most probably most impressive in the area of personalized medicine, which targets patients’ reactions to interference. When applying genomic, environmental, and lifestyle data, AI algorithms can determine how a particular patient will react to a certain type of treatment by recommending a therapeutic approach.35–37 Applications of AI tool such as IBM Watson for Genomics, compare a patient’s genome sequence and prescribe best-suited treatments, especially in cancer.38

The application of AI in medicine has benefited the health sector through the identification of the genetic makeup of the growths that cause cancer. Such information enables oncologists to determine which treatment approaches are best appropriate for such a patient in terms of debility, effectiveness, and side effects.39–42

According to the study of Sheu et al43 involving 175 cancer patients, gene expression data of the patients were used for training a support ML, and a prediction accuracy of 80% across multiple drugs was recorded. In addition, Obermeyer44 used the electronic health records (EHR) of 17,556 patients and AI to predict patients’ responses to antidepressants. The AI models demonstrated strong prediction accuracy and minimized confounding variables by considering features indicative of treatment selection. This study showed that real-world EHR data with AI modeling may be used to effectively predict antidepressant responses, indicating the possibility of creating clinical decision support systems for better medication selection.

Additionally, One AI algorithm available in precision medicine is DeepMind’s AI algorithm, which can predict patient deterioration and enable timely intervention by health care professionals. Integrating AI will support more precise diagnostics and assist in identifying personalized treatment options to improve patient outcomes.45 Furthermore, Benevolent AI will collaborate with key pharmaceutical companies by 2025 to introduce drugs tailored to genetic markers specific to certain patient populations. This would reduce the time required for drug development and make precision medicine more accessible. In silico AI engines and Chemistry42 are other AI algorithms (currently in clinical trials) that can improve personalized treatment. Additionally, IBM Watson for Genomics is an AI algorithm used to compare a patient’s genome sequence and prescribe the best-suited tailored treatments, especially for cancer.40,46

## Section: Main Findings › AI in Translational Medicine › Biomarker Discovery

It is evident that biomarker discovery, which forms part of the translational medicine process, is closely linked to AI. Biomarkers are prognostic or diagnostic phenomena that guide the further course of a disease or its treatment. Their identification is critical in advancing treatment strategies.43,47,48 AI models can also analyze large datasets to find possible biomarkers, using the discovery of which the validation phase is hastened.49 For instance, Ramirez-Valles et al50 explain that AI algorithms have helped identify biomarkers for Alzheimer’s disease through integration of features of brain imaging, and genomic data. It has also been used in cancer research where the biomarkers are modeled to predict the overall reaction of patients to immunotherapy treatment. It also increases the rate of success with treatments while also advancing clinical trials as a parallel to the associated patients.8,39,49,50

As a matter of fact, AI is useful in more than biomarker identification in translational medicine. In oncology, those applications of AI are being used to apply research results to clinical practice, particularly in cancer vaccines.51 Currently, AI systems successfully recognize unique mutations of tumors and help design vaccines.4 These particular vaccines are available for use in experimental melanoma and other cancers.52 AI is also advancing in the area of managing otherwise hard-to-treat diseases and, in particular, rare diseases. Healx is a company that employs algorithmic analysis to match existing drugs to rare disease targets, to bring treatments to patients faster for diseases that, by definition, have poor treatment options.23

## Section: Main Findings › AI in Translational Medicine › AI and Pharmaceutical Industry

Leading pharmaceutical companies are actively partnering with AI vendors to implement advanced technology across the entire field, including the manufacturing processes, research, development, and discovery of drugs.53 Analyses indicate that nearly 62% of healthcare organizations will consider an investment in AI and 72% will assume an important role for AI in their business in the future. To investigate the role of AI in the pharmaceutical industry, Pharma News Intelligence reviews current AI applications, including the most successful case studies, and the future of AI and ML. According to the McKinsey Global Institute, AI and ML have the potential to yield nearly $100bn per year in the US healthcare system. Similarly, researchers have pointed out that these technologies contribute to improved decision-making, innovation, the acceleration of research and clinical trials, and the provision of resources for clinicians, consumers, insurers, and regulators. Major pharmaceutical companies, such as Roche, Pfizer, Merck, AstraZeneca, GSK, Sanofi, AbbVie, Bristol-Myers Squibb, and Johnson & Johnson have already integrated AI into their business operations through partnerships or mergers and acquisitions. In 2018, the Massachusetts Institute of Technology (MIT) collaborated with Novartis and Pfizer to transform drug design and synthesis with ML for Pharmaceutical Discovery and Synthesis Consortium.

Daily research aims to discover new active principles for currently incurable diseases, enhance the safety profile of existing drugs, combat drug resistance, and minimize therapeutic failure. As a result, the biomedical data employed in drug design and discovery have expanded exponentially, driving the evolution of AI in the pharmaceutical field. Presently, multiple pharmaceutical companies offer software applications that support drug design, data analysis, and the prediction of treatment results.

One notable example is GNS Healthcare (according to information retrieved from gnshealthcare.com), which uses an AI software called Reverse Engineering and Forward Simulation (REFS). This software detects cause–effect relationships in data that are not obvious a priority through standard assessment techniques. The GNS claims that REFS can analyze millions of data points across diverse medical fields, including clinical, genetic, laboratory, imaging, drug, consumer, and geographical data. Based on information retrieved from atomwise.com, Atomwise proposed the first deep-learning-based neural network, for structure-based drug discovery. AtomNet analyses millions of experimental affinity measurements and protein structures to predict the binding properties of small molecules to proteins. Three-dimensional visualization of protein–ligand interactions allows pharmaceutical chemists to conduct essential steps of hit discovery, lead optimization, and toxicity prediction with extraordinary speed and precision, resulting in weeks instead of years.

Furthermore, according to the information obtained from In silico Medicine websites, Pharm AI is a project that utilizes Generative Adversarial Networks (GAN) and reinforcement-learning algorithms. GANs are composed of two neural networks: a generator and discriminator, which are trained to learn and predict samples. The relationship between the generator and the discriminator is “adversarial”. The generator generates new samples and the discriminator identifies whether it is real or fake. Through continuous training, the generator refines its ability to create realistic samples and the discriminator improves its classification accuracy. Through these technologies, Pharm AI can generate entirely new molecules and predict the biological causes of diseases.

Advances in pharmacy practice include pharmacy-management systems that contain information on patient and drug usage. These systems also detect possible drug-related issues related to the use of clinical decision support screening. The next generation of pharmacy technology aims to integrate expert information systems capable of identifying drug-related issues using data from both pharmacy systems and external sources. Paired with workflow robotics, these innovations ease pharmacists’ workload so that they can concentrate on their essential role as pharmacists, and that technology can perform tiresome tasks.54,55

## Section: Discussion

AI is making an impact in the area of drug discovery and development as timelines can be hastened, and costs decreased while increasing the chances of accurate predictions. Efficacy or effectiveness design is a traditional pharmacological development that could take more than a decade and cost billions of dollars before a new therapy arrives on the market. On the other hand, AI-integrated methodologies ease this process. For instance, Nelson et al56 explain that the application of ML can find the most prescriptive drug for the treatment out of a large quantity of results and precedes traditional methods. Furthermore, Koromina et al57 reveal that AI can decrease drug discovery time by 50% with the help of efficient lead identification and optimization. In addition, Basile et al58 highlight that the efficiency of the forecasts regarding the drug’s effectiveness and toxicity is increased due to the application of AI solutions. In traditional development processes, assessment strategies are usually based on the trial and error approach, meaning that problems can be only recognized in the late stages when the project might have to be canceled or significantly redesigned. In fact, nine out of ten discovered therapeutic molecules usually fail Phase II clinical trials and regulatory approval.56 In comparison, ML can mimic the biological responses and in the process estimate the pharmacokinetics of a compound before getting to the clinical phases.59 Thus, this predictive capability helps researchers find more feasible drug prototypes at an earlier stage.60 For instance, AI systems would offer a prognosis of patients concerning its handling with therapeutic profiles from their genetic structure, including in the oncology specialty where individualized treatment plans are most prevalent.29

## Section: Challenges and Limitations

Despite the numerous advantages AI offers, several challenges and limitations persist in its integration into drug discovery and translational medicine. One major hurdle is the quality of data. AI models rely on vast amounts of high-quality data to function effectively. In many cases, the available datasets are fragmented, inconsistent, or biased, which can lead to inaccurate predictions and reinforce existing disparities in healthcare.61

Furthermore, the transparency and interpretability of AI models particularly DL poses a significant challenge, particularly in clinical settings. Many AI systems operate as “black boxes” meaning their decision-making processes are not transparent. This lack of interpretability can hinder clinicians’ ability to trust and utilize AI-generated insights in treatment planning.44 Regulatory agencies, including the US Food and Drug Administration (FDA), are increasingly aware of these issues and are developing guidelines to ensure that AI systems can be audited and understood in clinical practice.2

Furthermore, the integration of AI into health care raises several ethical concerns, particularly regarding patient data privacy and algorithmic bias. The use of sensitive health data to train AI models necessitates strict adherence to privacy regulations such as the Health Insurance Portability and Accountability Act (HIPAA) in the United States, which can have serious ethical implications and erode public trust in AI technologies.16

Another major limitation is the possible bias that could arise from the AI algorithms. AI algorithms must be trained with the available data, which can sometimes be biased or unrepresentative. This implies that there will be unequal access to medical treatment and unfair treatment in certain groups.41

## Section: Future Directions

In the decades ahead, AI will prove valuable in bringing more advancements to drug discovery and translational research. An even more revolutionary idea is to create a fully self-contained system for drug discovery in which optimizations of compound structures, their synthesis, formulation, and testing are all conducted without human intervention.24 Furthermore, the development of the AI–human relation could create breakthroughs in research fields of translational medicine. For instance, Rai et al62 reveal that by using AI systems as a supplement to the doctor’s advice and experience, the limitations in the treatment plans might be removed, and the patient’s condition might be improved. With the help of this combination of Artificial and Augmented intelligence, one can better comprehend multifaceted diseases and design therapeutic approaches that would take into account the peculiarities of the patient.63

Additionally, the interaction between AI, blockchain, and Internet of Things will improve data integrity, security, and real-time monitoring in clinical settings. This integration will facilitate the exchange of patient data, effective trials, and personalized treatment plans.64 Additionally, to fully explore the importance of AI in drug discovery, different regulatory frameworks must be established to accommodate the uniqueness of different AI models.65 This includes the establishment of guidelines for the model development, validation, and deployment. Also, these regulatory frameworks must also ensure transparency and accountability in AI-driven decision-making.

## Section: Conclusion

This systematic review discusses how AI has enabled scientific advancements in drug discovery, development, and implementation. AI technologies have replaced traditional methodologies in the drug development process with far higher speeds, reduced costs, and improved accuracy. The latest AI and ML techniques, such as DL, have many applications in the prediction and discovery of new drugs, clinical trials, and patient data analyses. AI is changing the face, processes, and pace of the pharmaceutical industry through tools, such as virtual screening and autonomous drug discovery solutions.

Nonetheless, there are still barriers in recognizing and overcoming the effectiveness of AI in healthcare. Challenges, such as data quality, explainability of AI models, questions regarding patient data protection, and potential biases within these models must be resolved. Government agencies are gradually drawing standards of accountability that must be observed in AI systems. Overcoming these barriers is critical for populating the space of AI-driven drug discovery and Translational Medicine.

In the coming years, it becomes planned that the introduction of AI will certainly help to design the future of medicine. In the future, as researchers and practitioners continue to work together to embrace the use of AI, this will lead to more enhanced treatment methods that suit individual patient needs, hence improving treatment processes. The evolution of this entails improved patient health and delivery of healthcare to develop an era within which we embrace AI as the key aspect in developing the health sector and coming up with relevant solutions to current and future complex health issues.

## Section: Funding Statement

There is no funding to report.

## Section: Data Sharing Statement

The manuscript’s materials, including all relevant raw data, will be made freely available by the corresponding author (Odetayo Adeyemi Fatai) to any researcher who wishes to use them for non-commercial purposes while maintaining participant confidentiality.

## Section: Consent to Publish

Yes.

## Section: Disclosure

The authors report no conflicts of interest in this work.

## Section: Associated Data › Data Availability Statement

The manuscript’s materials, including all relevant raw data, will be made freely available by the corresponding author (Odetayo Adeyemi Fatai) to any researcher who wishes to use them for non-commercial purposes while maintaining participant confidentiality.


---

# Transformer-based models for ADR detection: cross-drug validation and benchmarking against large language models

- **Authors:** Minjung Kim, Kyoung Eun Kim, Jae-Hee Kwon, Ja-Young Han, Jae Hyun Kim, Myeong Gyu Kim
- **Issuer:** Therapeutic advances in drug safety
- **Type:** Scientific article
- **Published:** 2025-12-18
- **Language:** en
- **DOI:** 10.1177/20420986251405082
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41426306/
- **Licence:** CC-BY-NC

## Section: Abstract

Background:Adverse drug reactions (ADRs) are harmful side effects of medications. Social media provides real-time, patient-generated data, though its unstructured format presents challenges. Natural language processing and transfer learning offer promising solutions.Objective:This study aimed to evaluate whether transformer-based models fine-tuned on a general ADR dataset can effectively classify ADRs from tweets related to glucagon-like peptide-1 (GLP-1) receptor agonists and to benchmark their performance against state-of-the-art large language models (LLMs).Design:This study employed a machine learning approach using transformer-based language models to classify ADRs in social media.Methods:BERT (bidirectional encoder representations from transformers)-base, BERTweet-base, and GPT-2 (Generative Pre-Trained Transformer-2) models were fine-tuned using Sarker and SIDER (Side Effect Resource) datasets for ADR classification. The test dataset comprised 396 tweets mentioning GLP-1 receptor agonists that were categorized as personal experiences. Model performance was primarily evaluated using the F1 score, which was used to select the optimal model. In addition, the fine-tuned transformer models were benchmarked against state-of-the-art LLMs, including ChatGPT 4o, ChatGPT 4o-mini, and Gemini 2.5 Flash.Results:Among 396 tweets, 116 (29.3%) were classified as ADRs and 280 (70.7%) as non-ADRs. Among the transformer-based models, BERTweet-base achieved the highest performance (accuracy: 0.835, F1: 0.729), outperforming both BERT-base (accuracy: 0.826, F1: 0.679) and GPT-2 (accuracy: 0.766, F1: 0.628). Among the LLMs, ChatGPT 4o-mini demonstrated the best results (accuracy: 0.970, F1: 0.948), followed by Gemini 2.5 Flash (accuracy: 0.954, F1: 0.919) and ChatGPT 4o (accuracy: 0.936, F1: 0.895). Overall, LLMs substantially outperformed the fine-tuned transformer-based models.Conclusion:Fine-tuned transformer-based models demonstrated reasonable performance in ADR detection from GLP-1 receptor agonist tweets, with BERTweet-base performing best. However, state-of-the-art LLMs, particularly ChatGPT 4o-mini, substantially outperformed these models, highlighting their potential for pharmacovigilance tasks.

## Section: Introduction

An adverse drug reaction (ADR) refers a harmful and unintended response to a drug. 1 ADRs represent a significant public health concern, contributing to hospital admissions, prolonged hospital stays, visits to emergency departments, and an increased risk of mortality. ADRs are evaluated in clinical trials; however, rare ADRs may not be detected due to limited sample sizes and controlled study environments. Therefore, it is essential to monitor adverse events in real-world settings, where a diverse patient population can reveal potential risks that may not have been identified during the clinical trial phase. 2

The voluntary reporting system, such as FDA’s Adverse Event Reporting System (FAERS), aggregates data on adverse events and medication errors from various sources, thereby supporting post-market surveillance. 3 However, it heavily relies on reports by healthcare professionals and captures only a fraction of adverse events. 4 This limitation can lead to underreporting or delayed recognition of emerging safety issues. While some studies suggest that patient chart reviews by pharmacists are more comprehensive, such methods are resource-intensive and not sustainable for continuous monitoring. 5 A key challenge in improving medication safety is the lack of a routine, rapid, and scalable adverse event monitoring system. 6 Therefore, there is a critical need for innovative, automated systems capable of efficiently processing large volumes of clinical data to promptly detect and mitigate adverse events. Complementary surveillance methods are essential to provide timely insights into drug safety concerns and address the limitations of current reporting systems.

The combination of social media platforms, such as X (formerly Twitter), and natural language processing can serve as a dynamic source for adverse drug events. Conventional natural language processing techniques commonly used for ADR detection include Term Frequency-Inverse Document Frequency, Bag of Words, Word Embeddings (such as Word2Vec and GloVe), n-gram models, and statistical models like Naive Bayes, Logistic Regression, and Support Vector Machines. 7 However, these methods have several limitations in ADR detection. Conventional approaches often fail to capture the contextual relationships between words, resulting in potential misinterpretation of ADR mentions. 8 Ambiguities such as polysemy or the presence of synonyms can further challenge these models. Moreover, their reliance on explicitly mentioned ADRs in the training data restricts their ability to identify novel or nuanced cases. 9 These shortcomings underscore the need for more sophisticated models capable of addressing these challenges effectively.

To address these challenges, researchers have adopted advanced architectures such as the transformer, introduced in 2017 by Google. 10 The self-attention mechanism, a core feature of this architecture, enables models to assign varying importance to different parts of an input sentence. 10 Multi-head self-attention further enhances this by allowing simultaneous focus on multiple parts of the input. 10 Leveraging this design, pre-trained models such as BERT (bidirectional encoder representations from transformers) and GPT (generative pre-trained transformer) have demonstrated exceptional performance across various natural language processing tasks and can be fine-tuned for ADR classification. Fan et al. demonstrated the feasibility of using BERT word embeddings for ADR extraction from social media forum data, outperforming non-pretrained and other pretrained embeddings. 11 Huang et al. introduced a batch-wise adaptive strategy with BERT for ADR detection. 12 Dong et al. utilized publicly available labeled adverse event data to construct the BERT-based model and evaluated through generalized external social media dataset. 13

Challenges remain in applying transfer learning to ADR detection. In previous studies, a single ADR dataset (such as Sarker’s study, 7 Nikfarjam’s study, 14 the attention deficit hyperactivity disorder dataset, 15 or the SMM4H (Social Media Mining for Health) dataset 16 ) was typically divided into fine-tuning and test datasets.12,17–19 In our previous work, we found that a model fine-tuned on a general COVID-19 rumor dataset performed worse in classifying COVID-19 rumors related to garlic than a model specifically fine-tuned on garlic-related rumors. 8 This highlights that fine-tuning on more specific subsets of data can significantly improve performance in niche classification tasks. However, creating labeled datasets for individual drugs is labor-intensive and often impractical, as some drugs may lack sufficient data. Therefore, cross-drug validation is necessary to determine whether a model fine-tuned on a general annotated dataset can effectively detect ADRs for specific drugs outside its fine-tuning scope.

Thus, this study aimed to apply BERT and GPT-2-based language models to classify ADRs from tweets related to glucagon-like peptide-1 (GLP-1) receptor agonists and evaluate whether a model fine-tuned on a general annotated dataset can effectively detect ADRs for specific drugs. In addition, we benchmarked these models against large language models (LLMs) to assess their relative performance. Drugs suitable for adverse event detection through social media are primarily those used by populations that frequently engage on these platforms. GLP-1 receptor agonists, originally developed for type 2 diabetes, have recently gained U.S. approval for obesity treatment, with liraglutide and semaglutide emerging as promising options. While these medications are generally safe and associated primarily with gastrointestinal adverse events, their increasing use has the potential to reveal rare ADRs. Furthermore, the significant public interest in GLP-1 receptor agonists has driven a surge in online searches and social media discussions.20,21 Given this heightened activity, GLP-1 receptor agonists are particularly well-suited for adverse event monitoring using social media. A key strength of our study lies in the development of a well-curated GLP-1 receptor agonist dataset, created through filtering and fine-tuning models to classify personal experiences and adverse events, ensuring its reliability for external validation. Unlike prior studies that utilized domains other than text, we focus solely on text to showcase the models’ ability to handle real-world data challenges.

## Section: Methods

Study flow diagram.

Pipeline of BERT-base models and GPT-2 model for classification task.

BERT, bidirectional encoder representations from transformers; GPT-2, generative pre-trained transformer-2.

Transformer models used in the study.

## Section: Methods › Study design

This study involves fine-tuning pre-trained models for two tasks: one for classifying personal experiences and the other for classifying adverse events (Figure 1). In addition, their performance was benchmarked against LLMs, including ChatGPT and Gemini, to assess relative effectiveness in ADR detection. The study was exempted from Institutional Review Board review (ewha-202203-0027-01). The reporting of this study conforms to the Minimum Information about Clinical Artificial Intelligence Modeling (MI-CLAIM) checklist. 22

Study flow diagram.

## Section: Methods › Fine-tuning datasets

For fine-tuning, we used Sarker’s dataset, which was annotated for the presence of ADRs in a previous study. 7 In that study, 10,822 tweets, randomly selected based on searches for drug generic and brand names, were annotated by two experts. The Cohen’s Kappa for inter-annotator agreement was 0.71. 7 Tweet IDs and annotations were freely available on GitHub. 7 Among 10,822 tweets, 5514 tweets were accessible on July 6, 2022. The dataset was imbalanced, with 614 ADR tweets (11.1%; label = 1) and 4900 non-ADR tweets (88.9%; label = 0).

To address the data imbalance problem in Sarker’s dataset, another dataset was added. The SIDER (Side Effect Resource) 4.1 dataset, which contains information on marketed medicines (DRUG NAME) and their recorded ADRs (LIST OF ADRs) extracted from public documents and package inserts, was used. All data are freely available on GitHub. 23 We modified the SIDER dataset to 841 sentences in the format of “DRUG NAME side effects are LIST OF ADRS,” such as “liraglutide side effects are nausea, diarrhea, vomiting, constipation, headache” and “ramipril side effects are headache, hypotension, cough, cough increased, dizziness, vertigo, nausea, vomiting, asthenia, angina pectoris.” All were labeled as 1 since they pertained to ADRs (Supplemental File 1).

Therefore, in our study, we compared two fine-tuning datasets: Sarker’s dataset (n = 5514; 614 ADR and 4900 non-ADR) and Sarker’s + SIDER dataset (n = 6355; 1455 ADR and 4900 non-ADR). In both cases, the number of non-ADR instances exceeded ADR instances, with ratios of approximately 8:1 and 3.5:1, respectively. To address this imbalance, we set the class weights of 8 and 3.5 to the ADR class for the Sarker’s and Sarker’s + SIDER datasets, respectively. The fine-tuning datasets were divided into training (80%) and validation (20%) sets. Handles (in the form of “@name”), Uniform Resource Locators, white spaces, and non-ASCII characters were removed from the text. Spaces were inserted between punctuation marks, and words were converted to lowercase.

## Section: Methods › Fine-tuning transformer models

Figure 2 shows the whole pipeline of the BERT-based models and GPT-2 small model for classification task (pretraining, fine-tuning, and prediction).

For ADR classification, we fine-tuned BERT and GPT-2 models. Table 1 shows the BERT models (BERT-base, BERTweet-base) and GPT-2 small model employed in this study. We used pre-trained BERT-base (uncased), BERTweet-base, GPT-2 small hosted on the Hugging Face Model Hub (accessed on July 8, 2024). All analyses were conducted in the Google Colab environment.

BERT and GPT are among the popular transformer-based neural network models. GPT is an autoregressive model that exclusively utilizes decoder stacks, consisting of masked self-attention and feed-forward layers. 24 Meanwhile, BERT is a bidirectional model that exclusively utilizes encoder stacks, consisting of self-attention and feed-forward layers. 25 When making predictions, GPT considers the left context, while BERT takes both the left and right contexts into account. This enables BERT to excel in sentiment analysis and natural language understanding tasks. In contrast, GPT excels in language modeling for text generation and translation tasks. Therefore, in our study, we utilized BERT and GPT-2.

Two BERT models, BERT-base and BERTweet-base were employed in this study. A classification layer was added on top of BERT models using the “BertForSequenceClassification” and “RobertaForSequenceClassification” interfaces. As input data were fed, the entire pre-trained BERT models and the additional untrained classification layer were trained on our ADR classification task. For GPT-2, the token prediction head needed to be replaced with a classification head. This head, usually consisting of a few additional layers, takes the output of the GPT-2 model and produces logits corresponding to different classes. The “GPT2ForSequenceClassification” interface, which includes a classification head on top of the GPT-2 transformer layers, was used. The hyperparameters were set empirically without formal optimization: learning rate for the Adam optimizer = 2 × 10−5; number of epochs = 4–10; batch size = 32. Additionally, early stopping was applied with a patience of 3. The tokenizer evaluated the default tokenizers for each model, and it was found that some instances were classified as false negatives due to over-tokenization. As a result, some ADRs were added as tokens (Supplemental Table 1). All sentences were padded to a single, fixed length of 128 tokens.

Pipeline of BERT-base models and GPT-2 model for classification task.

BERT, bidirectional encoder representations from transformers; GPT-2, generative pre-trained transformer-2.

Transformer models used in the study.

## Section: Methods › GLP-1 receptor agonist dataset

From December 2014 to February 2022, 3963 tweets mentioning either liraglutide or semaglutide were collected using the search query “#saxenda OR #wegovy OR #liraglutide OR #semaglutide.” Python version 3.7 (Python Software Foundation, Fredericksburg, VA, USA) and X premium application programming interface were used for data collection.

Tweets include not only experiences of GLP-1 receptor agonist users but also humor, news, study results, or experiences of others. 9 Therefore, to evaluate adverse events using tweets that specifically relate to personal experiences, we implemented a personal experience classifier. In a previous study, personal experience tweets about medication use were classified using BERT. 26 The BERT-base model achieved a classification accuracy of 0.818, which was higher than the BERT-large model’s accuracy of 0.813 and the BERTweet model’s accuracy of 0.816. (Jiang, Chen and Calix, 2019) Therefore, we also used the BERT-base model in our study. The data used for fine-tuning consisted of tweets from the previous study. 26 A corpus of annotated tweets was available at GitHub. 27 Although the corpus provided a total of 12,331 random Tweet IDs and their annotations, only 6234 tweets were accessible as of July 6, 2022, and these were used for fine-tuning.

Using the fine-tuned BERT model, 515 tweets about GLP-1 receptor agonists were classified as personal experience tweets. Two researchers independently reviewed whether tweets were personal experiences, and in cases of disagreement, a third researcher made the final decision. A total of 396 tweets were identified as personal experience tweets, resulting in a precision of 0.77. Subsequently, two researchers independently annotated these tweets for ADRs. In cases where their opinions did not match, a third researcher made the final decision. The types of ADRs were named according to the Medical Dictionary for Regulatory Activities (MedDRA) Preferred Terms version 25.0.

## Section: Methods › Model evaluation

Tweets mentioning GLP-1 receptor agonists were classified as ADRs or non-ADRs using the fine-tuned transformer-based models. The test dataset was preprocessed in the same way as the fine-tuning datasets. Model performance was evaluated using a 2 × 2 confusion matrix, from which accuracy, precision, recall, and F1 score were calculated as follows:

Accuracy=(TP+TN)/(TP+TN+FP+FN)Precision=TP/(TP+FP)Recall=TP/(FN+TP)F1score=(2×Precision×Recall)/(Precision+Recall)

where TP, TN, FP, and FN mean true positive, true negative, false positive, and false negative, respectively. The optimal model was selected based on the F1 score, given the imbalance in the dataset, and performance was further assessed using receiver operating characteristic (ROC) and precision–recall (PR) curves.

To compare transformer-based models, each experiment was repeated five times with different random seeds (42, 52, 62, 72, 82). Mean and standard deviation were calculated for each metric, and pairwise Z-tests were conducted to assess whether performance differences were statistically significant. The Z-score for two models was computed as:

Z=μ1−μ2σ12+σ22

where µ and σ denote the sample mean and standard deviation, respectively. p-Values were derived from a two-tailed standard normal distribution, with a significance threshold of p < 0.05. Finally, the performance of fine-tuned transformer models was benchmarked against LLMs. State-of-the-art LLMs, including OpenAI’s ChatGPT 4o, ChatGPT 4o-mini, and Google’s Gemini 2.5 Flash (all accessed on July 21, 2025), were applied in a zero-shot setting. Tweets were input individually using a standardized binary classification prompt (1 = ADR, 0 = non-ADR) that was refined through pilot testing and then executed five times; run-to-run variability was calculated as the standard deviation. To prevent adaptive behavior, the prompt explicitly instructed the models not to adjust responses between trials. All LLM experiments were conducted directly through the respective online platforms, using the default settings with no manual adjustments to temperature or other parameters. The full prompt is provided in Supplemental Table 2.

## Section: Methods › Error analysis

To gain further insight into model performance beyond quantitative metrics, we conducted an error analysis of misclassified tweets from the fine-tuned transformer-based models. Using the results from a single test run with a fixed random seed, all instances of false positives and false negatives were systematically reviewed. Each misclassified tweet was systematically reviewed and assigned to conceptually distinct categories based on recurrent linguistic and contextual patterns, to identify common sources of error. This qualitative categorization was used to complement the quantitative evaluation, providing insights into systematic challenges of ADR detection from noisy, user-generated social media text.

## Section: Results

Comparison of best-performing results across different model configurations.

Analysis of false positives by category according to frequency.

Analysis of false negatives by category according to frequency.

## Section: Results › GLP-1 receptor agonist dataset

Out of 396 tweets, 116 (29.3%) were ADR tweets, and 280 (70.7%) were non-ADR tweets. A total of 155 ADRs were mentioned (Supplemental Table 3). Among these, the most common were nausea (n = 43), abdominal pain (n = 24), headache (n = 8), and gastrooesophageal reflux disease (n = 7). Five tweets were difficult to categorize under specific adverse reactions: “This shot is really messing me up,” “. . . don’t love the side effects. . .,” and “. . .hope the side effects keep lessening.”

## Section: Results › Model evaluation

Supplemental Table 4 summarizes all evaluated configurations, with metrics averaged over five runs. Figure 3 presents the best results for each model type, while Supplemental Figure 1 shows the ROC and PR curves of the corresponding fine-tuned transformer-based models.

Among all models, ChatGPT 4o-mini achieved the best performance, recording an F1 score of 0.948, an accuracy of 0.970, a precision of 0.948, and a recall of 0.948. With one random seed, the model resulted in 112 TP, 272 TN, 8 FP, and 4 FN. Other LLMs also outperformed the fine-tuned transformer-based models. Gemini 2.5 Flash achieved an F1 score of 0.919 and an accuracy of 0.954, while ChatGPT 4o recorded an F1 score of 0.895 and an accuracy of 0.936.

Among the fine-tuned transformer-based models, BERTweet-base model showed the best performance, with a mean F1 score of 0.729, an accuracy of 0.835, a precision of 0.701, and a recall of 0.762. With one random seed, the model resulted in 77 TP, 253 TN, 27 FP, and 39 FN. The BERT-base model achieved a mean F1 score of 0.679 and an accuracy of 0.826, whereas GPT-2 achieved a mean F1 score of 0.628 and an accuracy of 0.766.

Supplemental Table 5 summarizes the results of pairwise Z-tests across all model combinations. Fine-tuned transformer models (BERT-base, BERTweet-base, GPT-2) showed no statistically significant differences across most metrics, indicating comparable performance within this group. In contrast, all LLMs significantly outperformed the fine-tuned transformer models. Among LLMs, ChatGPT 4o-mini achieved the strongest performance, significantly surpassing both Gemini 2.5 Flash (accuracy: Z = 2.744, p = 0.006; F1 score: Z = 3.074, p = 0.002) and ChatGPT 4o (accuracy: Z = 6.668, p < 0.001; F1 score: Z = 6.203, p < 0.001).

Comparison of best-performing results across different model configurations.

## Section: Results › Error analysis of transformer-based models

Table 2 provides some examples of false positive, which were categorized into three main groups: (1) “Expected effect (no appetite)” where statements reflected the anticipated outcome of reduced appetite, (2) “Indication or underlying condition” where tweets referenced the use of medication for specific conditions or underlying health issues, and (3) “Unknown reason” where the tweets did not clearly indicate why they were classified as false positive.

Table 3 provides some examples of false negative, which were categorized into five main groups: (1) “Minimal ADRs with positive effects” where ADRs were reported alongside positive experiences with the treatment, (2) “Reduction or disappearance of past ADRs” where previous adverse effects had diminished or resolved, (3) “Indirect expression” where ADRs were implied rather than directly stated, (4) “General expression without explicit mention of ADRs” where non-specific symptoms or general discomfort were mentioned, and (5) “Unknown reason” where the reasons for the false negative were unclear.

Analysis of false positives by category according to frequency.

Analysis of false negatives by category according to frequency.

## Section: Discussion

This study shows that transformer-based models fine-tuned with a general ADR dataset can achieve reasonable performance in classifying GLP-1 receptor agonist-related tweets, although state-of-the-art LLMs (ChatGPT, Gemini) significantly outperformed these models.

Among the transformer-based model, BERTweet-base model achieved the best performance. This advantage can be attributed to its pre-training on tweets, which differ substantially from the Wikipedia and BooksCorpus datasets used for BERT-base. Tweets are short and often contain irregular words, abbreviations, and typographical errors, making BERTweet-base better suited for tweet classification tasks, especially when balanced precision and recall are critical. 8 In contrast, GPT-2 performed worse due to its decoder-only, autoregressive architecture designed primarily for text generation, whereas BERT’s bidirectional encoder architecture is inherently more effective for classification tasks.24,25

Classification performance improved when using the combined Sarker and SIDER datasets. Tweets about medications generally contain more non-ADR than ADR content, leading to class imbalance during fine-tuning. In Sarker’s dataset, only 11.1% of tweets were ADR-related, compared to 88.9% non-ADR. Incorporating the ADR-only SIDER dataset helped mitigate this imbalance. Tokenization issues also influenced performance; for example, “constipated” was split into “con,” “sti,” and “pated,” reducing the model’s ability to capture medical terms. Updating the tokens improved performance, suggesting that further token adjustments may be necessary for other drug classes.

Our fine-tuned BERTweet-base model showed some limitations. Among the false positives, some included the expected effect of reduced appetite and mentions of indication or underlying condition. This occurred because the model was fine-tuned on general drug-related tweets without specifically incorporating the characteristics of GLP-1 receptor agonists. However, developing individual models that account for the characteristics of every drug would be overly resource-intensive. Therefore, it is necessary for humans to confirm the ADRs detected by the model. The model incorrectly identified false negatives. We considered reports of past ADRs, even if they are no longer present, as ADRs because detecting such cases is important from a pharmacovigilance perspective. However, the model classified these as non-ADR, likely due to the absence of current ADRs. This discrepancy stems from the difference in labeling intent between the fine-tuning data created by other researchers and our classification objectives. Additionally, detecting minimal ADRs mentioned alongside positive effects proved to be challenging. The model also faced limitations in accurately detecting indirect expressions or general statements about side effects, making it difficult to fully capture the intent of the tweet’s author.

Our findings on fine-tuned transformer-based models are broadly consistent with previously published studies. Huang et al. 16 applied BERT for ADR classification using Sarker’s dataset and reported accuracy between 0.90 and 0.91, with F1 scores ranging from 0.51 to 0.53 under cross-validation. In contrast, our study incorporated external validation and achieved improved F1 performance despite dataset imbalance. Similarly, Dong et al. 12 externally validated a model trained on the ADE-Corpus-V2 using the SMM4H dataset, reporting F1 scores of 0.813 for adverse event terms, 0.807 for words within adverse events, and 0.979 for non-adverse terms.

LLMs substantially outperformed all fine-tuned models, with ChatGPT 4o-mini achieving the highest performance, followed by Gemini 2.5 Flash and ChatGPT 4o. ChatGPT 4o-mini achieved an accuracy of 0.970 and a precision of 0.948, reflecting strong ability to minimize false positives. Its recall and F1 score were both 0.948, indicating a well-balanced capacity to detect true ADR cases without over-prediction. The superior performance of LLMs can be partly explained by the limitations revealed in our error analysis of transformer-based models. Fine-tuned models frequently misclassified tweets that mentioned expected effects or underlying conditions as ADRs, and often failed to detect ADRs expressed indirectly, in colloquial terms, or without explicit ADR keywords. In contrast, LLMs benefit from extensive pretraining on diverse textual sources, which enhances their ability to interpret implicit meanings, handle non-standard language, and distinguish ADRs from related but non-adverse contexts. These capabilities likely contributed to their lower false-positive rates and improved recall. Interestingly, ChatGPT 4o-mini outperformed ChatGPT 4o across most metrics, potentially due to architectural optimizations or inference-time tuning that prioritize classification tasks such as binary ADR detection. However, this comparison should be viewed with caution as LLMs operate at much larger scale and with far greater computational resources. Such differences also entail higher costs and potential privacy concerns. Within pharmacovigilance frameworks, these issues extend to data protection under regulations such as the General Data Protection Regulation (GDPR) and to the need for clinical validation before LLM-generated safety insights can be integrated into regulatory decision-making.

## Section: Discussion › Limitations

This study has several limitations. First, the test set was relatively small and was inherently noisy due to its social media origin, which may affect the reported performance estimates. Second, as seen in the examples of false positive and false negative, the transformer-based model may misclassify cases where the drug’s indication, past experiences, or ADRs are described as minimal. Third, the test dataset was limited to tweets mentioning GLP-1 receptor agonists. The evaluation metrics may vary for other drugs and social media platforms. Also, the selective token additions described in Supplemental Table 1 could introduce subtle class-specific bias that might contribute to better performance observed for LLMs. Fourth, the study results are dependent on the labels of the fine-tuning dataset and the test dataset. These labels can be somewhat subjective, and there may be bias in the process of selecting social media posts. Fifth, the fine-tuning datasets were provided as Tweet IDs, which means that access to the data might vary depending on when it is accessed. Some tweets may have been deleted or become restricted, which could impact the model’s performance. Lastly, the models evaluated in this study were designed to classify tweets containing ADRs but do not extract specific ADRs.

Future works could re-run LLMs in a few-shot setting to examine whether limited calibration narrows or widens the performance gap. Also, additional evaluation on the best transformer-based model and the LLM on an independent drug class would help assess cross-drug generalizability beyond GLP-1 receptor agonists.

## Section: Conclusion

This study demonstrated that transformer-based models fine-tuned on a general ADR dataset can generalize to specific drug contexts, effectively classifying GLP-1 receptor agonist-related tweets as ADR or non-ADR. Among these models, BERTweet-base achieved the best performance, reflecting the advantage of pretraining on social media text for ADR detection tasks. However, state-of-the-art LLMs, particularly ChatGPT 4o-mini, substantially outperformed fine-tuned models, underscoring their superior ability to capture nuanced and implicit expressions of ADRs in user-generated text. Despite this performance gap, fine-tuned models remain valuable in scenarios where privacy concerns, domain-specific requirements, or resource constraints limit the deployment of large commercial LLMs.


---

# Transforming Pediatric Rare Disease Drug Development: Enhancing Clinical Trials and Regulatory Evidence With Virtual Patients

- **Authors:** Fianne Sips, Marco Virgolin, Giuseppe Pasculli, Federico Reali, Alessio Paris, Annette Janus, Yann Godfrin, Daniel Röshammar, Luca Marchetti, Jane Knöchel
- **Issuer:** CPT: pharmacometrics & systems pharmacology
- **Type:** Scientific article
- **Published:** 2025-08-04
- **Language:** en
- **DOI:** 10.1002/psp4.70096
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40757668/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

ABSTRACTDrug development in pediatric rare diseases is complicated by practical and ethical constraints on clinical trial design, stemming from small, highly heterogeneous, and vulnerable patient populations. Virtual patients (VPs) created with machine‐learning (ML), mechanistically driven computational approaches, or hybrids thereof, have the potential to expedite and maximize the impact of trials. We discuss the potential of VPs to transform the efficiency and impact of clinical trials in pediatric rare diseases, based on adult and pediatric examples.

## Section: Virtual Patients and Their Applications

Advances in machine‐learning (ML) and Quantitative Systems Pharmacology (QSP) modeling are transforming disease understanding and drug development through the generation of Virtual patients (VPs), integrating historical patient data and/or mechanistic insights. With ML, VPs are implemented by non‐parametric predictive models trained on large data sets of longitudinal individual‐level patient data that may include demographic, clinical, genetic, biomarker, and disease progression features. ML models can then predict personalized disease trajectories with high levels of precision, enabling applications such as patient stratification, optimized analysis of treatment responses, as well as augmenting or replacing placebo patients [1]. Regulatory agencies are increasingly providing guidance to leverage these opportunities, focusing on ensuring that the models are trained and extensively validated, based on their context of use, on high quality, representative data (https://www.fda.gov/regulatory‐information/search‐fda‐guidance‐documents/considerations‐use‐artificial‐intelligence‐support‐regulatory‐decision‐making‐drug‐and‐biological).

On what is perhaps the other end of the spectrum, mechanistic QSP models are driven by the integration of various data sources and thus are less dependent on large data sets. These models are increasingly applied in regulatory submissions [2] and acknowledged by regulatory agencies such as the FDA and EMA as valuable tools for investigating disease mechanisms and evaluating therapeutic strategies. QSP models enable the generation of virtual populations, allowing for the simulation of VPs, informing optimal dosing strategies and treatment schedules. Due to their mechanistic nature, QSP models require limited data to be calibrated and are generally thought to extrapolate well across different data sets. Conversely, extrapolation remains a weak point of ML models, which are excellent interpolators. Such QSP‐based VPs are thus particularly valuable in settings where patient recruitment is limited, such as in rare or pediatric diseases. By accounting for inter‐individual variability and integrating physiological processes, QSP‐based VPs can represent hard‐to‐enroll subpopulations, thereby expanding the scope of translational insights derived from computational studies.

## Section: Digital Twins of Disease Progression: Lessons From ALS

To exemplify the use of cutting‐edge VPs in an ongoing use case, we consider the rare disease amyotrophic lateral sclerosis (ALS) Phase 2 study (SEALS: NCT 06365216) of NX210c in the adult population. NX210c is a cyclic peptide with promising properties for neurodegenerative diseases due to its potential to repair the blood–brain barrier.

In this study, approved by the French National Agency for the Safety of Medicines, patients will be randomized into three groups to receive either placebo (n = 20), 5 mg (n = 30), or 10 mg (n = 30) of NX210c. To enhance statistical power and allow more patients to receive active treatment, the control group will be supplemented with 60 VPs, implemented as predictions from ML models trained and validated on historical patient registry data from the PRO‐ACT database.

The VPs will link baseline patient characteristics (such as baseline disease status, age, weight etc.) to longitudinal disease progression as measured by changes in for example, the revised ALS functional rating scale (ALSFRS‐R), and to survival, similar to Beaulieu et al. [1]. VP outcomes will be compared to observed trial patient data and will subsequently serve to enhance the statistical analysis. The approach of VPs versus directly using historical controls was taken because of the following advantages it provides: a VP generated by a ML model more accurately reflects the treated individual by incorporating their exact baseline characteristics, minimizing selection bias compared to a matched historical control. This enhances the reliability of the outcome predictions. The process is provided as a schematic in Figure 1.

Virtual patients generated by machine‐learning models in ALS. Development and application of ML‐based VPs to enhance clinical trials. Left: Various data sources, including baseline data and public repositories, used for model development and validation. Right: The clinical trial phases (screening, inclusion, treatment, follow‐up) and enhancements such as covariate adjustment, model‐based patient stratification, and the augmentation or replacement of placebo patients.

## Section: From Adult Applications to Pediatric Rare Diseases

A representative application of QSP‐based VPs is introduced for Gaucher's disease type 1 (GD1), which simulates patient responses to both enzyme replacement therapy (ERT) and substrate reduction therapy (SRT) with eliglustat in adult populations [3]. The model captures a range of disease severities and has been successfully used to predict therapeutic outcomes across diverse genotype–phenotype presentations.

Building upon this result, the same GD1 model was employed by Simoni et al. [4] to develop a model‐based phenotype clustering approach. This methodology combined mechanistic knowledge with sparse experimental data to identify clinically relevant patient subgroups emerging during treatment—distinctions not readily discernible from the data alone. This case highlights the potential of mechanistic models to support precision medicine, especially when data availability is limited, as it may happen in the case of rare diseases.

A similar strategy was recently applied in another rare lysosomal storage disorder, the Acid Sphingomyelinase Deficiency (ASMD). In this application, a QSP model supported pediatric extrapolation from adult data for olipudase alfa treatment. By demonstrating mechanistic similarity across age groups, the model enabled regulatory acceptance for pediatric use despite limited clinical data [5], paving the way for similar efforts in the future.

In the pediatric context, QSP models may either be developed de novo or adapted from adult models. The latter requires structural modifications and parameter adjustments to capture age‐dependent physiological features. Long‐term simulations must accommodate developmental changes such as organ growth and maturation, which may push the model beyond its original assumptions.

An exemplary pediatric case is the model described by Paris et al. [6], which captures the dynamics of phosphorylated neurofilament heavy subunits (pNfH) in children with spinal muscular atrophy (SMA). Derived from an earlier adult model [7], it incorporates SMA‐specific pathophysiology and pediatric treatment with the antisense oligonucleotide nusinersen. Calibrated using clinical trial data, the model effectively predicts pNfH trajectories in treated and untreated patients, enabling in silico evaluation of disease progression and treatment efficacy in pediatric SMA.

## Section: Methodology for Success

The development of both successful ML‐ and QSP‐based VPs relies on the integration of heterogeneous data sources, spanning multiple sources (clinical records, genetic information, and biomarker profiles). High‐quality, multi‐scale datasets are essential for capturing the complexity of these diseases. Strategies such as data harmonization and standardization are critical to ensure consistency across studies and cohorts, while ethical considerations remain central when working with sensitive pediatric data.

For ML‐based VPs, a common concern is limited data availability, particularly because ML is notoriously data hungry. Strict privacy regulations around pediatric data limit inter‐institutional sharing and exacerbate the problem, resulting in small, isolated cohorts, which are often insufficient for comprehensive ML model training and validation. A key aspect for success is thus a collective effort to gather pediatric rare disease data into research‐ready databases, as done, for example, by PRO‐ACT for adult ALS patients. Moreover, knowledge transfer from larger or related datasets can compensate for pediatric data scarcity. For example, a 2023 study [8] showed that self‐supervised models trained on adult inpatient data improved pediatric clinical predictions.

In QSP, model development must account for the unique characteristics of pediatric physiology from the beginning. This includes integrating time‐dependent changes in anatomical and physiological parameters, such as organ growth and enzyme maturation, which influence drug pharmacokinetics and pharmacodynamics. Scalability is also crucial—models must be adaptable across age groups and disease subtypes, often requiring extensions of adult models to address pediatric‐specific pathophysiological mechanisms.

Calibration and validation are foundational pillars of the modeling process. Rigorous testing against clinical trial data, such as those employed in the SMA and lysosomal storage disorders QSP applications presented in the previous section [3, 4, 5, 6], ensures reliability and predictive power. Iterative refinement, informed by emerging clinical and experimental insights, enables models to evolve and maintain relevance. This dynamic, data‐driven, and patient‐centric approach is fundamental in pediatric and rare diseases, where traditional trial designs are often constrained, and QSP modeling can serve as a bridge to informed and individualized treatment planning.

## Section: Future Directions

Integration of VP methodology into drug development pipelines and acceptance by regulatory agencies will require a step‐wise and context‐of‐use dependent approach, in which the tight control of the risk for patients is a key requirement [9]. Pre‐requisites for the development of models and methodologies are the sharing of high‐quality datasets by the community and the implementation of rigorous, step‐wise model testing by computational scientists. Notably, key successful applications have followed open science initiatives—such as those for ALS or Duchenne Muscular Dystrophy—demonstrating the potential value of such data sharing for young patients around the globe.

Furthermore, it must be noted that although ML and QSP reside on opposite ends of the modeling spectrum (heavily data‐driven vs. heavily biological insight‐driven), this also means that they are highly complementary, and the strengths of each approach have the potential to strengthen the weaknesses of the other. Integrated QSP + ML approaches effectively harness the strengths of both methodologies [10], with mechanistic assumptions of QSP railing in the plasticity of ML, improving generalization and lowering the quantity of data needed. In applications where data is sparse—such as rare pediatric diseases—hybrid approaches can help bridge the gap to making these methodologies applicable.

## Section: Conclusion

The implementation of QSP and ML‐based VPs in rare pediatric diseases has the potential to optimize and accelerate trials, support biomarker selection as a key outcome, increase reliability and statistical power of the trial, resulting in enhanced probability of trial success. However, broad development and application of such technologies relies on the collective commitment to make data accessible, allowing the scientific and pharmaceutical communities to build methodologies, VPs, and trust. Establishing high‐quality data sharing as the standard in pediatric rare diseases would ensure sustainable and effective use of data, maximizing its impact on drug development and, ultimately, patient care.

## Section: Conflicts of Interest

F.S. is employee of InSilicoTrials Technologies B.V., D.R. and J.K. are employees of InSilicoTrials Technologies S.p.A.; M.V. and G.P. were employees of InSilicoTrials Technologies at the time of manuscript submission. Y.G. is CEO and shareholder of Axoltis Pharma. All other authors declared no competing interest for this work.


---

# TRIPOD+AI statement: updated guidance for reporting clinical prediction models that use regression or machine learning methods: a Korean translation

- **Authors:** Gary S Collins, Karel G M Moons, Paula Dhiman, Richard D Riley, Andrew L Beam, Ben Van Calster, Marzyeh Ghassemi, Xiaoxuan Liu, Johannes B Reitsma, Maarten van Smeden, Anne-Laure Boulesteix, Jennifer Catherine Camaradou, Leo Anthony Celi, Spiros Denaxas, Alastair K Denniston, Ben Glocker, Robert M Golub, Hugh Harvey, Georg Heinze, Michael M Hoffman, André Pascal Kengne, Emily Lam, Naomi Lee, Elizabeth W Loder, Lena Maier-Hein, Bilal A Mateen, Melissa D McCradden, Lauren Oakden-Rayner, Johan Ordish, Richard Parnell, Sherri Rose, Karandeep Singh, Laure Wynants, Patricia Logullo
- **Issuer:** Ewha medical journal
- **Type:** Scientific article
- **Published:** 2025-07-31
- **Language:** en
- **DOI:** 10.12771/emj.2025.00668
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40739973/
- **Licence:** CC-BY-NC

## Section: 요약

최근 인공지능(artificial intelligence, AI) 방법, 특히 머신러닝의 발전에 따라 예측모델 개발에 대한 관심과 투자규모가 크게 증가하고 있다. 예측모델 연구가 실제 사용자에게 가치 있게 활용되기 위해서는, 연구자가 왜 연구를 수행했는지, 무엇을 했는지, 그리고 어떤 결과를 얻었는지를 투명하고 완전하며 정확하게 기술해야 한다. TRIPOD 지침의 개정판은 AI 방법을 적용한 예측모델 연구 전반을 일관성 있게 안내하고, 회귀분석이든 머신러닝이든 적용방법에 관계없이 모두를 아우르는 지침을 제공한다. TRIPOD+AI 지침은 27개 항목의 체크리스트, 각 항목별 보고 권고사항을 상세히 설명하는 확장 체크리스트, 그리고 13개 항목의 초록 전용 TRIPOD+AI 체크리스트로 구성된다. TRIPOD+AI의 목표는 저자가 연구를 완전하게 보고하도록 돕고, 동료 평가자와 편집자, 정책 입안자, 최종 사용자, 그리고 환자가 AI 기반 연구의 데이터, 방법, 결과 및 결론을 명확히 이해하도록 돕는 것이다. 이 권고안을 준수하면 연구에 소요되는 시간, 노력, 비용의 활용 효율성을 높일 수 있을 것이다.

## Section: 서론

2015년에 발표된 TRIPOD (transparent reporting of a multivariable prediction model for individual prognosis or diagnosis; 개인별 예후 또는 진단을 위한 다변량 예측모델의 투명한 보고) 지침은 예측모델의 개발 또는 성능 평가 연구에 대한 최소 보고 권고사항을 제시하였다. 이후 예측모델 분야에서는 머신러닝에 기반한 인공지능(artificial intelligence, AI) 기법의 보편화 등 다양한 방법론적 발전이 이루어져 예측모델 개발에 활용되고 있다. 이에 따라 TRIPOD 지침의 개정이 필요하게 되었다. TRIPOD+AI는 회귀 분석이든 머신러닝 방법이든 상관없이 예측모델 연구의 보고를 위한 일관된 지침을 제공한다. 이 새로운 체크리스트는 TRIPOD 2015 체크리스트를 대체하는 것으로, 기존 버전은 더 이상 사용하지 말아야 한다. 이 논문에서는 TRIPOD+AI의 개발과정과 함께, 각 보고 권고사항에 대해 더 상세히 설명하는 27개 항목의 확장 체크리스트와 초록용 TRIPOD+AI 체크리스트를 제시한다. TRIPOD+AI의 목적은 예측모델의 개발 또는 성능 평가 연구에서 완전하고 정확하며 투명한 보고를 장려하는 것이다. 완전한 보고는 연구 평가, 모델의 평가 및 실제 적용을 촉진할 것이다.

예측모델은 다양한 의료환경에서 사용되며, 특정 결과값이나 위험도를 산출하는 데 활용된다. 대부분의 모델은 특정 건강상태(진단)의 존재 가능성이나 특정 결과가 미래에 발생할지(예후)를 예측한다[1]. 주요 용도는 임상적 의사결정 지원으로, 예를 들어 추가 검사가 필요한지, 질환 악화나 치료효과 모니터링, 치료 또는 생활습관 변화 시작 여부 결정 등에 활용된다. 널리 알려진 예측모델로는 EuroSCORE II(심장 수술)[2], Gail 모델(유방암)[3], Framingham 위험 점수(심혈관질환)[4], IMPACT(외상성 뇌손상)[5], FRAX(골다공증 및 고관절 골절)[6] 등이 있다.

예측모델은 생의학 문헌에서 매우 풍부하게 보고되고 있으며, 매년 수천 개의 모델이 출판되고 그 수는 점차 증가하고 있다[7,8]. 다양한 건강상태와 임상 결과에 대한 매우 많은 모델이 개발되었다. Coronavirus disease 2019 (COVID-19) 팬데믹 첫 1년 동안만 해도, 진단 및 예후 예측모델 연구가 최소 731편 발표되었다[9]. 이렇게 예측모델 개발에 대한 관심이 높음에도 불구하고, 이 분야에서는 보고의 투명성과 완전성, 그리고 그에 따른 활용 가능성에 대한 우려가 오래전부터 지속되어 왔다[10,11]. 보고가 불완전하거나 부정확하다면, 동료 평가자, 편집자, 의료인, 규제 당국, 환자, 그리고 일반 대중을 포함한 독자 입장에서는 연구설계와 방법을 비판적으로 평가하고 결과에 신뢰를 갖거나, 추가로 모델을 평가하거나 실제 적용하기가 어렵다. 모델에 대한 불충분한 보고로 설계나 데이터 수집, 연구 수행과정의 결함이 가려질 수 있으며, 이러한 모델이 임상경로에 실제로 적용되면 위해로 이어질 수 있다. 특히 편향을 줄이기 위한 충분한 조치가 마련되지 않은 경우 위해가 발생할 수 있다. 더 나은 보고는 신뢰를 제고하고, 예측모델의 의료현장 적용에 대한 환자 및 대중의 수용도에 긍정적인 영향을 미칠 수 있다. 연구자는 자신의 연구를 완전하고 투명하며 정직하게 보고할 윤리적ㆍ과학적 의무가 있다. Altman 등[12]이 언급한 바와 같이 “좋은 보고는 선택이 아니라 연구의 필수 요소”이며, 그렇지 못한 보고는 결국 불필요한 연구 낭비에 불과하다[13].

불완전한 보고에 대한 우려에 대응하기 위해[10,11,14,15], TRIPOD 지침이 2015년에 발표되어(TRIPOD 2015) 최소 보고 권고사항을 제시하였다[16,17]. TRIPOD 2015는 총 37개 항목의 체크리스트로 구성되어 있으며, 이 중 25개 항목은 개발 및 검증 연구 모두에 공통으로 적용되고, 모델 개발 연구에 6개, 검증 연구에 6개의 추가 항목이 있다. 또한 각 체크리스트 항목의 근거, 좋은 보고의 사례, 예측모델 연구의 설계ㆍ수행ㆍ분석 관련 논의 등을 담은 설명 및 해설 문서도 함께 제공된다[17]. TRIPOD 2015는 당대의 주류였던 회귀분석 기반 모델에 주로 초점을 맞추었다. 이후 예측모델 연구의 초록 보고(TRIPOD for Abstracts)[18], 군집화 데이터 사용 연구(TRIPOD-Cluster)[19,20], 예측모델 연구의 체계적 문헌고찰 및 메타분석(TRIPOD-SRMA)[21], 연구 프로토콜 준비 지침(TRIPOD-P)[22] 등 추가 지침이 개발되었다. 이러한 모든 지침과 별도 작성용 체크리스트 서식은 TRIPOD 웹사이트(https://www.tripod-statement.org/)에서 확인할 수 있다.

TRIPOD 2015 발표 이후, 예측모델링 분야에는 샘플 사이즈 산정 지침[23-27], 성능 평가방법[28-32], 공정성[33], 재현성[34], 오픈 사이언스 원칙 적용[35] 등 다양한 방법론적 발전이 이루어졌다. 이 중에서도 가장 큰 변화와 진보가 나타난 영역은 AI로 분류되는 기법의 발전에 기반한 분야이다. 데이터 접근성의 향상과 기성 머신러닝 소프트웨어의 보급으로 예측모델 개발은 훨씬 빠르고 쉬워졌다. 여러 임상환경과 광범위한 결과ㆍ건강상태에 대한 수많은 예측모델이 문헌에 보고되고 있으며, 동일 결과나 건강상태, 대상 집단에 대해 복수의 모델이 존재하는 경우도 많다[7,8,36]. 따라서 예측모델의 품질을 비판적으로 평가하고, 특정 환경이나 사용 목적에 적합한지 이해하는 능력이 더욱 중요해졌다. 이러한 능력은 완전하고 투명한 보고를 전제로 한다.

하지만 예측모델 연구를 평가한 체계적 문헌고찰에서는, 연구설계나 데이터 수집의 결함[37,38], 미흡한 방법론 사용[37,38], 핵심 세부 사항이 누락된 불완전한 보고[39-54], 그에 따른 높은 편향 위험[41,49,55-57], 오픈 사이언스 관행의 미준수[58], 과도한 해석이나 이른바 ‘spin’의 문제[59,60] 등이 자주 드러난다. 이러한 결함은 모델의 유용성과 안전성에 심각한 의문을 제기하며, 보건의료격차가 심화할 우려도 있다[61]. TRIPOD 2015는 모델링 방식이 중립적이며 보고 권고 대부분이 비회귀적 접근법에도 적용되지만, 머신러닝 기반 모델에는 추가적인 보고 고려사항이 필요하다. 예를 들어 회귀 기반 모델과 달리 머신러닝 모델은 구조의 유연성과 복잡성 때문에 단순 공식이 나오지 않거나, 사용된 예측변수 자체가 불명확한 경우가 많다. 이 때문에 기존 TRIPOD 2015에서는 다루지 않은 추가 보고사항이 필요하다. 방법론적 진전뿐 아니라, 공정성[62], 오픈 사이언스 관행의 확산[63], 환자 및 대중의 연구ㆍ실제 적용 참여 확대[64,65] 등도 함께 반영할 필요가 있다.

이 논문의 목적은 개정된 TRIPOD 지침의 개발과정을 설명하고, 새로운 TRIPOD+AI 체크리스트를 제시하며, 그 활용법을 논의하는 것이다. TRIPOD+AI는 예측모델 연구의 전반을 조화롭게 정비하고, 회귀분석과 머신러닝 방식 모두에 일관된 지침을 제공하는 것을 목표로 한다[66]. 여기서 “+”는 회귀분석 또는 머신러닝(딥러닝, 랜덤 포레스트 등) 접근법으로 개발된 예측모델 연구에 대해 통합된 보고 권고사항을 제공함을 의미한다. 또한 관련 연구가 일반적으로 AI로 분류되는 보고 지침과의 일관성을 위해 “AI”라는 용어가 추가되었으나, 이 논문에서는 이해를 돕기 위해 주로 머신러닝이라는 용어를 사용한다(Table 1) [67-73]. TRIPOD+AI 보고 지침에서 사용하는 주요 개념에 대한 용어 설명은 Box 1에서 확인할 수 있다.

## Section: TRIPOD+AI 개발과정

이 절에서는 머신러닝 또는 회귀방법을 이용하여 진단 또는 예후 예측모델을 개발하거나, 이들 모델의 성능을 평가(검증)하는 연구의 보고를 지원하기 위한 지침인 TRIPOD+AI 지침의 개발과정을 기술한다. ‘검증된 예측모델’이라는 개념은 존재하지 않으므로[76], 이 논문에서는 혼동을 피하고 용어를 통일하기 위하여 검증(validation) 대신 평가(evaluation)라는 용어를 사용하였다(Box 1). 머신러닝이 포함된 기타 생의학 연구 유형의 보고를 위한 기존 및 개발 중인 가이드라인은 Table 1에 상세히 정리하였다. TRIPOD+AI 체크리스트는 EQUATOR Network의 권고에 따라[77], 문헌고찰과 전문가 합의과정을 통해 개발되었다. G.S.C.와 K.G.M.M.의 주도로 다양한 전문성과 경험을 반영한 위원(G.S.C., K.G.M.M., R.D.R., A.L.B., J.B.R., B.V.C., X.L., P.D.)을 선정하여 지침 개발을 감독할 운영위원회를 구성하였다.

2019년 4월에는 TRIPOD+AI 이니셔티브를 알리는 해설 논문이 발표되었으며[78], 2019년 5월 7일에는 EQUATOR Network에 개발 중인 보고 지침으로 공식 등록되었다(https://www.equator-network.org/). 2021년 3월 25일에는 Open Science Framework (https://osf.io/zyacb/)에 개발과정 및 방법론을 담은 연구 프로토콜이 공개되었다. 이 프로토콜은 머신러닝 기반 예측모델의 품질 평가 및 편향 위험도구(PROBAST+AI)의 개발과정도 포함하고 있으며, 2021년에 출판되었다[79]. TRIPOD+AI 개발과정에서 활용한 합의 기반 방법의 보고는 ACCORD (Accurate Consensus Reporting Document) 권고를 준수하였다[80].

## Section: 윤리적 고려

본 연구는 2020년 12월 10일 옥스퍼드대학교 중앙 연구윤리위원회(Central University Research Ethics Committee, University of Oxford)의 승인을 받았다(R73034/RE001). 델파이(Delphi) 설문 참여자에게는 설문 시작 전에, 그리고 합의 회의 참여자에게는 회의 시작 전에 참여자 안내문을 전자적으로 제공하였다. 델파이 설문 참여자는 설문 응답 전 전자 동의서를 제출하였다.

## Section: 후보 항목 목록 도출

G.S.C.와 K.G.M.M.이 TRIPOD 2015 [16,17]를 바탕으로 초기 항목 목록의 초안을 작성하였다. 이후, TRIPOD-Cluster [19,20], TRIPOD for Abstracts [18], CAIR [81], MI-CLAIM [82], CLAIM [68], MINIMAR [83], SPIRIT-AI [71], CONSORT-AI [72] 및 운영위원회가 추가로 확인한 문헌[34,84-89]을 참고하여 추가 항목을 도출하였다. 머신러닝 기반 예측모델 연구의 보고, 방법론, 과도한 해석을 평가한 체계적 문헌고찰 결과[37-39,48,51,54,59,60]도 항목 목록 구성에 반영하였다. 운영위원회는 이러한 자료를 바탕으로, 제목(1항목), 초록(1항목), 서론(3항목), 방법(37항목), 결과(15항목), 논의(5항목), 기타(3항목)를 포함하는 65개의 고유 후보 항목으로 최종 목록을 정비하였다. 이 목록은 이후 설명하는 수정 델파이 합의과정에서 활용되었다.

## Section: 델파이 패널 선정

델파이 조사 참여자는 운영위원회가 선정하였으며, 관련 논문 저자, 소셜미디어(예: 트위터) 모집공고, 그리고 개인 추천을 통해 모집하였다. 이에는 다른 델파이 참여자가 추천한 전문가도 포함된다. 운영위원회는 지리적 및 학문적 다양성을 확보하고, 주요 이해관계자 집단—예를 들어 연구자(통계학자, 데이터 과학자, 역학자, 머신러닝 연구자, 임상의, 영상의학과 전문의, 윤리학자 등), 의료전문가, 학술지 편집자, 연구비 지원기관, 정책 입안자, 보건의료 규제기관, 예측모델의 실제 사용자(환자 및 일반 대중 등)—을 포괄하도록 참여자를 선정하였다. 참여자는 대학, 병원, 1차 의료기관, 생의학 학술지, 비영리기관, 영리기관 등 다양한 환경에서 모집하였다.

델파이 참여자의 최소 표본 수에는 제한을 두지 않았다. 선정된 모든 참여자에 대해 운영위원회 구성원이 전문성이나 관련 경험을 확인하였다. 이후 각 참여자에게 이메일로 연구설명, 목표, 연락처 등이 포함된 안내자료와 함께 참여 초대장을 발송하였다. 참여자가 동의하면 델파이 패널로 등록되어 설문 링크를 받았다. 델파이 패널은 설문 참여에 대한 금전적 보상이나 선물을 제공받지 않았다.

## Section: 델파이 과정

델파이 설문조사는 Welphi 온라인 플랫폼(www.welphi.com)을 통해, 각 참여자가 개별적으로 온라인(영어)으로 응답할 수 있도록 설계되어 배포되었다. 이 플랫폼은 각 참여자에게 개별 링크를 발송하고 응답자에게 코드를 부여하여 익명성을 보장한다. 패널에게는 연구의 목적과 범위, 참여방법, 플랫폼 사용법, 문의처 등을 포함한 안내자료를 제공하였다. 참여자들은 각 항목에 대해 ‘제외 가능,’ ‘포함 가능,’ ‘포함 권장,’ ‘포함 필수’ 중 하나로 평가하도록 요청받았다. 또한 각 항목에 대해 자유롭게 의견을 남기거나 신규 항목을 제안할 수 있었다. 자유 서술식 응답은 P.L.이 취합 및 분석하였으며, 이를 바탕으로 G.S.C.와 K.G.M.M.이 항목의 재서술, 통합, 신규 항목 제안을 논의하였다. 운영위원회 구성원 전원에게 델파이 설문 참여 기회가 주어졌다.

## Section: 델파이 과정 › 1차 라운드 참여자

292명에게 초대장과 설문 참여 링크가 발송되었으며, 1차 라운드는 2021년 4월 19일부터 5월 13일까지 진행되었다. 2021년 5월 5일에 확인 메시지가 발송되었다. 초대된 292명 중 170명(부분 응답자 8명 포함)이 설문을 완료하였다. 참여자는 총 22개국에서 모집되었으며, 주요 국가는 영국(n=52), 미국(n=31), 네덜란드(n=23), 캐나다(n=20)였다. 5개 대륙(유럽 100명, 남미 2명, 북미 51명, 오세아니아 4명, 아시아 13명)에서 응답하였고, 7명은 국가를 밝히지 않았다.

참여자들은 자신의 주요 연구/업무 분야를 복수 선택할 수 있었다. 통계ㆍ데이터 과학(n=70), AI 또는 머신러닝(n=69), 임상(n=50), 역학(n=40), 예측(n=18), 영상의학(n=18), 보건 정책/규제(n=10), 생의학 연구(n=7), 학술지 편집자(n=6), 메타연구/보고(n=6), 병리학(n=2), 연구비 지원 기관(n=2), 윤리(n=2), 기술 개발/실행(n=2), 유전학/유전체(n=2), 의생명공학(n=2), 보건 경제(n=2) 등이 보고되었다.

## Section: 델파이 과정 › 2차 라운드 참여자

2차 델파이 라운드는 2021년 12월 16일부터 2022년 1월 17일까지 진행되었다. 1차 라운드 설문을 완료한 모든 참여자가 2차 라운드에 초대되었으며, 1차 미응답자와 1차 이후 추가 추천된 참여자도 재초대되었다. 2차 라운드 초대장은 총 395명에게 발송되었고, 200명(부분 응답자 15명 포함)이 설문을 완료하였다. 응답자는 27개국에서 모집되었으며, 역시 영국(n=70), 미국(n=37), 네덜란드(n=19), 캐나다(n=19)가 다수를 차지하였다. 6개 대륙(유럽 123명, 남미 3명, 북미 56명, 오세아니아 7명, 아시아 10명, 아프리카 1명)에서 응답이 있었다. 주요 분야는 통계ㆍ데이터 과학(n=78), AI 또는 머신러닝(n=72), 임상(n=49), 역학(n=51), 예측(n=19), 영상의학(n=26), 보건정책(n=12), 생의학 연구(n=14), 학술지 편집자(n=13), 메타연구/보고(n=6), 의생명공학(n=5), 연구비 지원기관(n=2), 유전학/유전체(n=4), 환자 대표/참여(n=3), 보건 경제(n=2), 윤리(n=1) 등이었다.

## Section: 델파이 과정 › 체크리스트 항목의 진화(1차→2차 라운드)

수정된 델파이 1차 라운드에서는, 참여자들이 문헌고찰 및 기존 보고 체크리스트에서 도출한 65개 후보 항목을 평가하였다. 항목 포함에 대해 ‘포함 권장’ 또는 ‘포함 필수’로 응답한 경우 합의한 것으로 간주하였다. 프로토콜에서 정의한 대로[79], 70% 이상 합의에 도달한 항목만 2차 라운드로 이월되었다. 70% 미만의 항목은 제외하거나 통합 또는 재서술되어 재평가 대상으로 제시되었다. 이러한 수정은 수백 건의 패널 의견을 반영하여 이루어졌다.

2차 라운드에서는 1차 라운드의 집계결과(https://osf.io/zyacb/)를 참고하도록 안내하고, 59개 후보 항목(제목 1, 초록 1, 서론 4, 방법 32, 결과 11, 논의 8, 기타 2)에 대해 평가하도록 하였다. 환자 및 공공 참여 관련 항목은 포함 합의율이 69%로 70% 기준에 약간 못 미쳤으나, 운영위원회는 합의 회의에서 이 항목을 논의 항목으로 유지하기로 결정하였다.

## Section: 델파이 과정 › 환자 및 대중 참여 회의

2022년 4월 8일, Health Data Research UK의 환자 및 대중 참여 그룹(Patient and Public Involvement and Engagement, PPIE; https://www.hdruk.ac.uk/about-us/involving-and-engaging-patients-and-the-public/) 소속 9명을 대상으로 온라인 회의가 진행되었다. 이 회의는 University of Warwick의 Sophie Staniszewska가 주재하였다. 이 회의는 연구 프로토콜에 계획되어 있지 않았으며, 출판된 프로토콜[79]과의 유일한 차이점이었다. PPIE 그룹은 회의에 앞서, TRIPOD+AI 프로젝트의 요약(https://osf.io/zyacb/ 참조), PPIE 그룹원 한 명이 작성한 요약문, 그리고 체크리스트 초안을 전달받았다. 회의에서 GSC는 TRIPOD+AI 이니셔티브의 세부 내용, 프로젝트 현황, 2차 델파이 설문결과를 바탕으로 한 초안 지침을 발표하였다. 이후 참여자들은 질의응답을 진행하며 프로젝트의 목표와 범위에 대해 논의하였다. 명확성을 높이기 위해, 회의 중 제기된 의견과 회의 이후 받은 서면 피드백을 바탕으로 체크리스트 초안이 수정되었다. PPI 그룹의 세 명이 다양한 이해관계자가 참여한 2022년 7월 5일의 온라인 합의 회의에 초대되었으며, 이 중 두 명이 실제로 참석하였다. 원고는 세 명의 PPI 회원에게 전달되어 의견을 받고 승인절차를 거쳤다.

## Section: 델파이 과정 › 합의 회의(consensus meeting)

2022년 7월 5일, G.S.C.와 K.G.M.M.의 사회로 온라인 합의 회의가 개최되었다. 주요 이해관계자 그룹과 다양한 학문 분야, 지리적 다양성이 균형 있게 반영되도록 참가자를 선정하였다. 총 28명이 회의의 전부 또는 일부에 참석하였으며, 이 중 1명(P.L.)은 투표권이 없는 참관자였다. 초청받은 참가자들에게는 TRIPOD+AI 개요, 합의 회의 진행방식 및 안내, 2차 델파이 설문 종합결과 요약, 그리고 TRIPOD+AI 체크리스트 초안이 포함된 문서(https://osf.io/zyacb/)를 회의 전에 이메일로 발송하였다. 체크리스트 초안은 제목(1항목), 초록(1항목), 서론(4항목), 방법(32항목), 결과(11항목), 논의(8항목), 기타(2항목) 등 총 59개 항목을 포함하였다.

2차 라운드에서 다수 항목에 대한 강한 지지가 확인되었기 때문에, 이 중 17개 항목이 전체 회의에서 토론 및 표결 대상이 되었다. 논의 후 각 항목에 대해 TRIPOD+AI 체크리스트 포함 여부를 1분간 투표하도록 하였으며, 온라인 회의 플랫폼의 투표 기능이 사용되었다. 이 17개 항목에는 2차 라운드에서 합의에 도달하지 못한 1개 항목과, 2차 라운드 이후 재서술되었거나 TRIPOD 2015에 포함되지 않았던 신규 항목 16개가 포함되었다. 이들 17개 항목에 대한 논의와 표결을 거쳐 최종 TRIPOD+AI 체크리스트를 확정하였다.

## Section: TRIPOD+AI 지침

TRIPOD+AI는 통계적 또는 머신러닝 방법을 이용해 예측모델을 개발하거나 평가(검증)하는 연구의 적절한 보고에 필수적인 항목들로 구성된 체크리스트로(Table 2), TRIPOD 2015의 주요 변화와 추가 사항은 Box 2에 요약되어 있다. TRIPOD+AI 체크리스트는 제목(항목 1), 초록(항목 2), 서론(항목 3, 4), 방법(항목 5–17), 오픈 사이언스 관행(항목 18), 환자 및 대중 참여(항목 19), 결과(항목 20–24), 논의(항목 25–27) 등 총 27개의 주요 항목으로 구성된다. 일부 항목은 복수의 세부 항목을 포함하고 있어, 총 52개의 체크리스트 세부 항목으로 구성된다.

TRIPOD+AI는 예측모델의 개발, 예측모델 성능 평가(검증), 또는 이 둘을 모두 다루는 연구를 포괄한다. D;E로 표기된 항목은 예측모델 개발 및 평가 연구 모두에 공통으로 적용된다(Table 2). 체크리스트 중 D로 표기된 항목은 예측모델 개발 연구에, E로 표기된 항목은 모델 성능 평가 연구에 적용된다. 예측모델의 개발과 평가를 모두 포함한 연구의 경우, 모든 체크리스트 항목이 적용된다.

TRIPOD+AI는 예측모델 연구의 학술지 또는 학회 초록을 위한 별도의 체크리스트도 포함하고 있다. 이 체크리스트는 기존 TRIPOD for Abstracts 지침을 업데이트한 것으로[18], 새로운 내용을 반영하고 TRIPOD+AI와의 일관성을 유지하도록 설계되었다(Table 3).

TRIPOD+AI의 권고사항은 예측모델 연구의 수행과정을 투명하게 보고하도록 안내하는 것이며, 예측모델 개발 또는 평가방법 자체를 규정하는 것은 아니다. 이 체크리스트는 연구의 질을 평가하는 도구가 아니다. 예측모델의 질과 편향 위험성 평가에는 PROBAST [90,91] 및 곧 공개될 PROBAST+AI [79] 사용을 권장하며, 관련 정보는 https://www.probast.org/에서 확인할 수 있다.

## Section: TRIPOD+AI 사용방법

TRIPOD+AI 체크리스트는 기존 TRIPOD 2015 체크리스트를 대체하므로, 이제 더 이상 TRIPOD 2015 체크리스트는 사용하지 않아야 한다. 만약 예측모델 연구에서 클러스터(예: 다수 병원, 다수 데이터 세트)를 고려했다면, 저자는 TRIPOD-Cluster의 추가 보고 권고사항[19,20]을 참고해야 한다. 2015년판 설명 및 해설 문서는 여전히 대부분의 TRIPOD+AI 보고 항목에 대한 배경 및 예시를 제공하는 중요한 자료로 남아 있다[17] (많은 항목이 변경되지 않았거나 최소한만 변경되었기 때문이며, TRIPOD+AI에 대한 보다 상세하고 최신의 해설 문서는 별도로 제작 중이다). TRIPOD+AI는 논문 작성 초기 단계부터 활용하여 모든 핵심 세부사항을 누락 없이 보고할 것을 권장한다. 각 항목별로 간단한 근거와 안내를 담은 목록형 확장 체크리스트(Supplement 1)를 개발하여, TRIPOD+AI의 실제 적용을 지원하고자 하였다.

TRIPOD+AI 체크리스트의 많은 항목은 논문 내에서 자연스러운 순서로 배열되지만, 일부 항목은 그렇지 않을 수 있다. 예측모델 논문이나 출판물 내에서 각 권고사항이 반드시 어디에 위치해야 하는지 구조적 형식을 별도로 규정하지 않으며, 해당 순서는 학술지의 투고양식에 따라 달라질 수 있다.

TRIPOD+AI에 담긴 권고사항은 최소한의 보고 기준이므로, 저자는 추가적인 정보를 제공할 수 있다. 논문 본문의 분량 제한이나 표ㆍ그림 개수 제한 등으로 인해 보고가 어려운 경우, 일부 요청된 정보나 추가 자료는 보충자료로 보고하고 그 위치를 본문에서 명시하면 된다. 필요한 정보가 이미 공개적으로 접근 가능한 연구 프로토콜에 보고되어 있다면, 해당 문서를 참조하는 것으로 충분하다. 특정 체크리스트 항목을 알 수 없거나 해당이 되지 않아 보고할 수 없다면 그 사실을 명확히 밝혀야 한다. 보충자료에 포함되지 않은 추가 파일이나 연구자료는 Open Science Framework, Dryad, figshare 등과 같은 범용 또는 소속기관의 오픈 액세스 저장소에 영구적으로 공개해야 한다. 추가 파일의 접근 정보(예: doi 번호)는 논문 본문이나 출판물에 반드시 명시ㆍ연결해야 한다.

저자는 각 항목이 본문 내 어디에 보고되어 있는지(페이지 또는 줄 번호) 명시한 완성된 체크리스트를 제출하도록 권장되는데, 이는 편집 및 동료 평가과정에 도움이 된다. 별도 작성용 TRIPOD+AI 체크리스트 양식은 Supplement 2 및 www.tripod-statement.org에서 다운로드할 수 있다.

TRIPOD+AI 관련 소식, 공지, 정보는 TRIPOD 웹사이트(www.tripod-statement.org)와 X (구 트위터, @TRIPODStatement) 등 소셜미디어 계정에서 확인할 수 있다. 또한 건강 연구의 질 및 투명성 향상 네트워크(EQUATOR Network; https://www.equator-network.org/)를 통해서도 TRIPOD+AI 지침이 배포 및 홍보된다. TRIPOD+AI의 다국어 번역도 적극적으로 환영하며, 번역을 희망하는 경우 교신저자에게 연락하면 된다. 번역과정은 원저자와의 협력 및 승인을 포함한 구조적이고 사전 정의된 절차를 따르도록 하며, 번역 관련 추가 안내는 TRIPOD 웹사이트에서 확인할 수 있다(www.tripod-statement.org).

## Section: 고찰

TRIPOD+AI는 국제적 다기관 다학제 합의과정을 통해 개발되었다. 이 지침은 회귀분석 또는 머신러닝 방법을 활용하여 예측모델을 개발하거나 평가(검증)하는 연구에 대해 최소한의 보고 권고사항을 제공한다. 지침 개발 당시에는 최근 급속히 발전하고 있는 파운데이션 모델 및 대형 언어 모델(예: ChatGPT 등)은 별도로 고려하지 않았으므로, TRIPOD+AI는 비생성형 모델을 주요 대상으로 한다. 그러나 이 지침의 많은 원칙은 보건 분야 생성형 AI 연구의 투명성 확보에도 적용 가능하다. 앞으로 TRIPOD+AI가 계속해서 유효성을 유지하고 AI 및 머신러닝의 발전을 반영하기 위해서는, 예를 들어 생성형 접근법에 대한 명시적 반영 등 주기적인 업데이트가 필요하다.

TRIPOD+AI는 TRIPOD 2015를 개정하여 개발되었으며, 문헌의 체계적 고찰, 델파이 설문조사, 온라인 합의 회의를 기반으로 권고사항을 정립하였다. TRIPOD+AI의 보고 항목을 충실히 기술하면, 연구방법의 질적 평가, 연구결과의 투명성 향상, 과도한 해석의 방지, 재현 및 복제 가능성 제고, 예측모델의 실제 적용 등에 모두 도움이 될 것이다. 체크리스트 항목은 최소한의 보고 기준으로, 저자는 데이터, 연구설계, 방법, 분석, 결과, 논의 등에서 추가적인 세부사항을 제공하는 것이 일반적이다.

TRIPOD+AI는 TRIPOD 2015에서는 부족하거나 명확히 언급되지 않았던 공정성(fairness) 이슈를 전반에 걸쳐 강조한다[33]. 예측모델 연구에서의 공정성은 특히 의료 분야에서 매우 중요하며, AI 및 머신러닝이 임상 의사결정 지원도구로 활용되면서 더욱 주목받고 있다. 이 맥락에서의 공정성이란, 예측모델이 특정 집단에 불리하게 작용하지 않으며, 기존의 건강불평등을 심화하지 않고(이상적으로는 이를 완화ㆍ개선하는 방향으로) 설계ㆍ사용됨을 의미한다[92]. 공정성의 중요한 측면 중 하나는 모델 개발과 평가에 활용되는 데이터가 대표성과 다양성을 갖추고, 데이터 편향의 한계를 인지ㆍ관리ㆍ완화하는 것이다. 현재 STANDING Together 이니셔티브에서는 AI 보건 데이터 세트의 다양성, 포용성, 일반화 가능성을 높이기 위한 표준을 개발 중이다[62].

이상적으로는, 데이터에는 다양한 연령, 성별/젠더, 인종ㆍ민족, 건강상태 또는 동반 질환, 지역적 배경의 정보가 모두 포함되어야 하며, 이러한 다양성이 예측모델의 실제 사용 대상 인구를 대표해야 한다. 만약 모델 개발에 사용된 데이터가 의도한 전체 인구집단을 충분히 반영하지 못한다면, 데이터에 포함되지 않은 집단에서는 해당 모델이 기대한 만큼의 성능을 보이지 않을 수 있음을 명확히 밝혀야 한다. 모델 평가에 사용된 데이터가 목표 인구집단을 대표하지 못한다면, 특정 하위집단(개인적, 사회적, 임상적 속성별)의 예측 정확도 추정에 편향이 생기거나 오해를 일으킬 수 있다.

데이터 세트 내 소수 집단 또는 의료 소외 집단의 충분한 대표성 확보는 공정성을 달성하기 위한 핵심 요소이지만, 단순한 대표성만으로는 완전한 공정성이 보장되지 않는다[61,93]. 이에 따라, TRIPOD+AI는 체크리스트 전반에 걸쳐 공정성 관련 항목을 포함하고 있다(배경 3c; 방법 5a, 7, 8a, 8b, 9c, 12f, 14; 결과 20b, 23a; 논의 25, 26번 항목 등).

의료 분야의 공정성이란, 예측모델의 개발, 평가, 실제 임상경로 내 적용 및 확산과정에서 환자, 대중, 임상의 등 다양한 이해관계자를 적극적으로 참여시키는 것 또한 포함한다[94]. 다양한 관점의 참여는, 예측모델이 모든 사람의 요구를 충족시키고 공정하게 사용되도록 설계ㆍ운영되는지 확인하는 데 기여하며, 건강형평성을 촉진한다. TRIPOD+AI는 대중 및 환자 참여에 관한 19번 항목을 통해 예측모델 연구에 환자와 대중 참여를 통합을 장려하고, 단순한 형식적 절차가 아닌 오픈 사이언스 및 참여의 원칙을 촉진하며, 더 높은 임상 및 대중 수용성을 지향한다.

TRIPOD+AI는 오픈 사이언스 관행을 강조한다[35]. 오픈 사이언스 관행은 예측모델 연구의 투명성, 재현성, 연구자 간 협력 증진에 필수적이다[95]. 연구 등록, 프로토콜ㆍ데이터ㆍ코드ㆍ예측모델의 공개 등은, 타 연구자가 결과를 검증하고 새로운 데이터에서 모델 성능과 안전성을 평가할 수 있도록 한다. 오픈 사이언스는 연구자들이 서로의 성과를 기반으로 추가 연구를 진행할 수 있게 하여, 보건의료 분야 발전의 효율성을 높인다. 이는 예측모델의 정확성, 신뢰성, 완전성을 높여 결과적으로 환자 치료에도 긍정적 영향을 줄 수 있다. 데이터가 개방적으로 공유될 경우 임상의와 연구자는 더 크고 다양한 환자 데이터를 바탕으로 모델을 개발ㆍ평가할 수 있으며[96], 이는 예측 정확도 향상 및 임상적 의사결정 개선으로 이어질 수 있다. 이에 TRIPOD+AI는 자금 출처(18a), 이해상충(18b), 프로토콜 공개(18c), 연구 등록(18d), 데이터 및 코드 공유(18e, 18f) 등 오픈 사이언스 관련 항목을 포함한다.

TRIPOD+AI의 주요 사용자 및 수혜자는 논문을 집필하는 연구자, 논문을 평가하는 학술지 편집자 및 동료 평가자, 그 밖의 이해관계자(예: 학술기관, 정책 입안자, 연구비 지원기관, 규제기관, 환자, 연구 참여자, 대중 등)로 예상된다(Table 4). 이 지침은 임상 예측모델 개발 및 검증 연구, 의학 연구 논문, 소프트웨어ㆍ도구 관련 보고 등 근거 기반 보고가 필요한 모든 분야에 적용될 수 있다.

학술지 편집인과 출판사는 TRIPOD+AI의 준수를 장려하기 위해 저자 안내문에 이를 명시하고, 논문 투고 및 심사 과정에서 그 사용을 의무화하며, 권고사항의 준수를 필수 요건으로 삼는 것이 바람직하다. 연구비 지원기관 역시, 예측모델 연구의 지원 신청 시 TRIPOD+AI 권고에 따른 보고 계획 제출을 요구함으로써 연구 낭비를 최소화하고 효율적 자원 활용을 도모할 것을 권고한다.


---

# Uncertainty quantification enables reliable deep learning for protein-ligand binding affinity prediction

- **Authors:** Milad Rayka, S Shahab Naghavi
- **Issuer:** Scientific reports
- **Type:** Scientific article
- **Published:** 2025-12-04
- **Language:** en
- **DOI:** 10.1038/s41598-025-27167-7
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41345415/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Deep learning (DL) algorithms have increasingly been applied to predict protein-ligand binding affinity, a critical step in drug design. Yet, many models still struggle to generalize to unseen data, and when coupled with the absence of confidence estimates for predictions, they hinder effective decision-making. To address these challenges, we thoroughly compare five uncertainty quantification methods: Deep Ensemble, Monte Carlo Dropout, Laplace approximation, Bayes by Backprop, and Evidential Neural Networks. Notably, Bayes by Backprop—applied for the first time in this study area—offers a novel and promising approach to uncertainty quantification. To ensure unbiased training and validation, we leverage the Leak-Proof PDBBind dataset and rigorously evaluate performance across multiple external test sets. Our results reveal that a feed-forward neural network (FFNN) using extended connectivity interaction features (ECIF) as a protein-ligand representation, paired with the Bayes by Backprop method, achieves superior predictive performance and highly reliable uncertainty quantification. Notably, Bayes by Backprop demonstrated balanced performance across multiple evaluation metrics, particularly excelling in calibration without needing additional recalibration. Our findings not only advance the state of uncertainty quantification in deep learning models for binding affinity prediction but also open avenues for more reliable, calibrated, and reproducible applications in drug discovery and active learning-driven model development.

## Section: Introduction

Deep learning (DL) algorithms empower protein-ligand binding affinity predictions—a critical step in computer-aided drug discovery—yet they often yield inconsistent results across different trials, rendering them neither practical nor reliable1–4. This shortcoming stems from two intertwined key issues: (i) the generalization of proposed models and (ii) uncertainty in predicted values.

Given limited access to all possible complexes for training a deep learning model, it is particularly necessary to assess the model generalization. Generalization of the model—its ability to transfer to unseen data—is commonly assessed using a test set that does not have any common members with the training set5. However, eliminating duplicate instances, called “hard overlap”, does not ensure an unbiased dataset meaning train and test sets with minimum similarities. This is because an unbiased dataset should also be devoid of any instances with similar characteristics or patterns, often known as “soft overlap”. The presence of soft overlap between the training and test sets might result in overly optimistic performance reports and undermine effective comparisons between different models6. For example, the commonly used PDBBind database train-test split, the most popular dataset for structure-based binding affinity prediction7, suffers from soft overlap issue5. In the common approach, the core set, which has the highest quality like high complex resolution, is reserved for testing, while the general set, a set with the least satisfied criteria, is used for training. This splitting leads to data leakage between the training and test sets, an issue that has been recently identified and spurred efforts to develop effective solutions8–10. In this regard, various solutions have been proposed, such as calculating structural, sequential, or ligand similarities to construct training, validation, and test sets based on different similarity thresholds5,11–14. Approaches like leave-cluster-out and clustered cross-validation effectively separate training and test sets for protein families15–18. Temporal splitting, another approach, simulates realistic drug discovery scenarios by establishing blind tests with members released only after a specific year9,19,20. Together, these approaches demonstrate that adjusting for “soft overlap” significantly changes the performance of deep learning-based models21,22.

Even with unbiased train and test sets available, a trained model cannot consistently predict the binding affinity since each model has an inherent domain of applicability23,24. This challenge brings us to the second critical issue: the credibility of predicted values generated by a trained model. A common approach to investigate the applicability domain of a model is uncertainty quantification, which incorporates a confidence value or associated uncertainty with each predicted label25. Uncertainty, defined as a lack of knowledge, falls neatly into two classes: aleatoric and epistemic26. Aleatoric uncertainty is caused by intrinsic noise in measurements and can not be reduced. In contrast, epistemic uncertainty originates from the model framework, training processes, hyperparameters, and data scarcity and can often be reduced by improving model architecture or increasing dataset size26,27. Aleatoric uncertainty, unlike epistemic one, is beyond our control, yet we can delineate the contributions of each type of uncertainty within our model. Quantifying uncertainties and identifying their types are crucial for decision-making and assessing the credibility of a prediction24.

To address the aforementioned uncertainties, various machine learning and deep learning-based binding affinity predictors have been developed in recent years. For example, Libouban et al.22 introduced a model utilizing an ensemble approach to quantify uncertainty in predicted values. ENS-Score employs a similar ensembling, but it uses conformal prediction to report confidence28. In another recent development in binding affinity prediction, the Geometric Interaction Graph Neural Network (GIGN)11, resorts to the Monte Carlo Dropout technique to quantify uncertainty. Despite the rise of diverse methods to quantify uncertainty, their application in deep learning models for protein-ligand binding affinity has remained sparse. As such, no systematic study has yet compared these approaches.

In this study, we present the comparison of five uncertainty quantification (UQ) methods (see Fig. 1): Deep Ensemble29, Monte Carlo Dropout30, Laplace approximation31, Bayes by Backprop32, and Evidential Neural Networks (ENNs)33. We use Leak-Proof PDBBind21, a newly curated unbiased subset of the PDBBind dataset, for training and validation, alongside multiple external test sets for further evaluation. We evaluate several deep learning-based binding affinity predictors previously reported in the literature: (i) Feed-Forward Neural Network (FFNN) with Extended Connectivity Interaction Features (ECIF) for protein-ligand representation34, (ii) Convolutional Neural Network (CNN) with the Multi-Shell Occurrence of Interatomic Contact (MS-OIC) scheme or OnionNet-235, (iii) DeepDTA36, and (iv) InteractionGraphNet (IGN)37. Our analyses reveal that the FFNN-ECIF model demonstrates the best performance in binding affinity prediction. We then evaluate the five UQ methods on FFNN-ECIF to determine the most effective technique. After thorough evaluation using ranking-based, calibration-based, and proper scoring rules metrics, we conclude that Bayes by Backprop32 provides the most reliable and robust performance for UQ.Fig. 1Overview of the workflow in this study. (a) Leak-Proof PDBBind and multiple external test sets are used for training, validation, and testing of FFNN-ECIF, DeepDTA, OnionNet-2 (CNN-MS-OIC), and IGN. (b) Five uncertainty quantification methods are employed to approximate the posterior distribution. (c) Several metrics, including Spearman’s rank correlation coefficient, miscalibration area (MCA), and negative log-likelihood (NLL), are utilized to evaluate the performance of uncertainty quantification.

Overview of the workflow in this study. (a) Leak-Proof PDBBind and multiple external test sets are used for training, validation, and testing of FFNN-ECIF, DeepDTA, OnionNet-2 (CNN-MS-OIC), and IGN. (b) Five uncertainty quantification methods are employed to approximate the posterior distribution. (c) Several metrics, including Spearman’s rank correlation coefficient, miscalibration area (MCA), and negative log-likelihood (NLL), are utilized to evaluate the performance of uncertainty quantification.

## Section: Methods

The size of each employed dataset.

## Section: Methods › Data collection

We use the recently introduced Leak-Proof PDBBind (LP-PDBBind)21 dataset to train and evaluate our models. LP-PDBBind is a subset of the PDBBind database—one of the widely used databases in the drug discovery and design discipline. LP-PDBBind comprises unbiased training (LP-Train), validation (LP-Val), and test (LP-Test) sets with minimum ligand and protein similarities. Following the original paper21 of LP-PDBBind, we use data at cleaning level one (i.e., discarding covalently-bonded ligands) for training and level two (entries with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$K_{\textrm{i}}$$\end{document} and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$K_{\textrm{d}}$$\end{document} values) for validation and testing. We also assess the generalization of our model on external datasets including M\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$^{\textrm{pro}}$$\end{document}, EGFR, BDB2020+, and Peptides-Holdout. The first three datasets are gathered from the Li et al.21 paper, and the last one is selected from the Durant et al.6. M\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$^{\textrm{pro}}$$\end{document} and EGFR are test sets curated for ranking power evaluation based on SARS-CoV-2 main protease (Mpro )-ligand and epidermal growth factor receptor complexes, respectively. BDB2020+ consists of BindingDB entries deposited in the PDBBind v2020 release. The Peptides-Holdout test set is gathered from PDBBind v2020 with peptides as ligands. All binding affinity values are convert to pK by applying \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\mathrm{-log}}_{10}$$\end{document}. Details of these datasets can be found in Table 1 and the Details and Analyses of Datasets section of Supporting Information (SI) through Tables S1–S8 and Fig. S1–S8. All Protein Data Bank IDs are deposited in the paper’s GitHub repository (Table 1).Table 1The size of each employed dataset.DatasetTrainValidationTestLP-PDBind72599442163BDB2020+––111M\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$^{\textrm{pro}}$$\end{document}––27EGFR––22Peptide-Holdout––2503

The size of each employed dataset.

## Section: Methods › Binding affinity predictor › Model

Here, we construct four DL-based binding affinity predictors based on distinct neural network models. The first model incorporates feature generation method, including Extended Connectivity Interaction Feature (ECIF)34, and Feed-Forward Neural Networks (FFNNs). For the second model, we choose OnionNet-235, which utilizes the Multi-Shell Occurrence of Interatomic Contact (MS-OIC) scheme alongside Convolutional Neural Networks (CNNs) for binding affinity prediction. Owing to the recent popularity of Graph Neural Networks (GNNs)38, InteractionGraphNet (IGN)37 is also selected as the third model. For the last model, DeepDTA36 is selected, which only applies SMILES notation of the ligand and the primary protein structure, i. e., amino acids sequence, for predicting a protein-ligand binding affinity. Detailed information about models is available in the Model, and SMILES and the Protein Sequence sections of the SI and Tables S13 and S14.

## Section: Methods › Binding affinity predictor › Implementation

All models are implemented using the PyTorch package (v2.3.1)39. Hyperparameters are fine-tuned over 200 trials with the Optuna package (v3.6.1)40, a widely used tool for hyperparameter optimization—retaining default values for all other Optuna parameters. The optimized hyperparameters for each model are listed in Tables S9–S12. Training continues for 300 epochs, where L2 regularization, dropout, and early stopping (with a patience of 20 epochs) are applied to prevent overfitting. Model weights, except IGN, are initialized by the Kaiming Normal method in the “fan_in” mode, while the initial bias weights are set to 0.01. Given the random nature of neural network training, the reported results are based on an average and standard deviation calculated from five independently trained models. We quantify the results by Mean Square Error (MSE), Root Mean Square Error (RMSE), Mean Absolute Error (MAE), Pearson’s Correlation Coefficient (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {R}_{\textrm{P}}$$\end{document}), and Spearman’s Rank Correlation Coefficient (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {R}_{\textrm{S}}$$\end{document}). Details of metrics are gathered in the Regression Metrics subsection within SI.

## Section: Methods › Uncertainty prediction › Uncertainty predictor model

UQ approaches, generally, fall into two categories: data-based and model-based methods41. Data-based methods define uncertainty in terms of a model’s applicability domain, using feature space, training set, and metrics like distance to assign uncertainty values42. Model-based methods, which are the focus of this manuscript, apply various ML or DL-based methods to estimate uncertainty26.

We further divide DL-based methods into four subcategories: single deterministic, Bayesian, ensemble, and test-time augmentation methods26. In the single deterministic approach, both the prediction and its uncertainty are obtained through a single, non-random model evaluation, commonly referred to as a single deterministic forward pass. We selected Amini et al.’s extension of the evidential neural network (ENN) for regression as a candidate method43. Bayesian approaches, which estimate uncertainty by approximating intractable posterior distributions, include Monte Carlo (MC)-Dropout30, Laplace approximation31, and Bayes by Backprop32. Finally, For the ensemble category, we adopt the Deep Ensemble method29, which aggregates predictions from multiple independently trained models. We prioritize these methods for their ease of implementation and low inference cost. Among them, MC-Dropout, Deep Ensemble, and Laplace approximation are model-agnostic techniques and can be applied to pre-trained models. In contrast, the ENN requires a modified loss function for training, while Bayes by Backprop demands adjustments both to the model architecture and the loss function. Here, we excluded the test-time augmentation method as they are incompatible with our datasets. It is worth noting that this study focuses on overall uncertainty estimation and leaves the explicit distinction between aleatoric and epistemic uncertainty to future work.

In what follows, we briefly describe each selected method, highlighting their assumptions, implementation details, and relevance to uncertainty estimation.

Deep ensemble This technique offers a straightforward yet effective approach for estimating predictive uncertainty in neural networks (NNs). Deep Ensembles achieve this by training a diverse set of NNs while maintaining their independence through random weight initialization and data shuffling26. During inference, we estimated the mean (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\mu$$\end{document}) and standard deviation (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\sigma$$\end{document}) for each data instance using outputs from an ensemble of K independently trained models. In this study, we built an ensemble of ten models (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\textrm{K}}~=~10$$\end{document}). Unlike the original method proposed by Lakshminarayanan et al.29, which minimized a heteroscedastic loss (negative log-likelihood, NLL), we retained MSE as the loss function.

MC-dropout Bayesian Neural Networks (BNNs), which assign prior distributions to their weights, offer a mathematically grounded approach for deriving uncertainty by leveraging Bayesian probability theory. However, their adoption faces hurdles because of high computational costs and complex inference. Gal et al.30 demonstrated that using dropout—typically applied in NNs to prevent overfitting44—in prediction mode approximates a Gaussian Process. In this context, dropout effectively integrates over the models’ weights. In practice, we pass a data instance multiple (K) times, randomly dropping different neurons in each layer during each pass. The final result is the average of these K stochastic forward passes. To align MC-Dropout with Deep Ensemble, we set \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\textrm{K}}~=~10$$\end{document}.

Laplace approximation Laplace approximation addresses the intractability problem of BNNs by approximating the posterior distribution (p(w|D)) over the weights using Multivariate Normal distribution26. This method achieves the approximation by applying the second-order Taylor series of the log posterior around the maximum a posterior (MAP) weights (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hat{w}$$\end{document}):1\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\begin{aligned} log\,p(w|D) \approx log\,p(\hat{w}) + \frac{1}{2}(w - \hat{w})^{T}(H)(w - \hat{w}) \end{aligned}$$\end{document}Where D is training set (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$D = \{x^{i}, y^{i}\}$$\end{document}) and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$p(w|D) = \prod _{i} p(y^{i}|x^{i}, w)$$\end{document}. Exponentiating the both sides of the Eq. (1) leads to \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$p(w|D)~\approx ~N(\hat{w}, H^{-1})$$\end{document} or Multivariate Normal distribution. Although Laplace approximation can be applied to already trained models with proper loss functions, such as MSE, computing the full Hessian is practically infeasible due to the vast number of weight parameters. To overcome this limitation, we employ a layer-wise Kronecker factor approximation of the Hessian, which also accounts for off-diagonal elements31. For all computations, we use the laplace-torch package (v 0.2.2)45.

Bayes by backprop This method applies variational inference to learn parameters of distributions over BNN weights rather than weights themselves32. Given the intractability of the posterior distribution (p(w|D)), we approximate it with a known variational distribution (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$q(w|\theta )$$\end{document}), whose parameters are optimized during training. To achieve this, we minimize the Kullback-Leibler (KL) divergence between \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$q(w|\theta )$$\end{document} and the true posterior p(w|D):2\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\begin{aligned} \mathcal {F}(D, \theta ) = KL(q(w|\theta ) || p(w)) - \mathbb {E}_{q(w|\theta )}log\,p(D|w) \end{aligned}$$\end{document}\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\mathcal {F}(D, \theta )$$\end{document} is called variational free energy, which is the summation of complexity (first term) and likelihood (second term) costs32. By reorganizing some terms, Eq. (2) can be approximated by the Monte Carlo method:3\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\begin{aligned} \mathcal {F}(D, \theta )\approx & \frac{1}{K}\sum _{i=1}^{K}[log\,q(w^{i}|\theta )-log\,p(w^{i})\nonumber \\ & - log\,p(D|w^{i})] \end{aligned}$$\end{document}Where K is the number of samples. For variational distribution, we choose Gaussian distribution with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\mu$$\end{document} and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\sigma$$\end{document} as mean and standard deviation vectors, respectively. Assuming uncorrelated weights, the \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\sigma$$\end{document} vector corresponds to the diagonal elements of the covariance matrix. Both \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\mu$$\end{document} and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\sigma$$\end{document} are computed and optimized via backpropagation. For the prior (p(w)), we use a scaled mixture of two Gaussians (Eq. 4) with parameters fixed before training32.4\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\begin{aligned} {\mathrm{p(w)}} = \pi \mathcal {N}(\hbox {w}|0,\sigma _{1}^{2}) + (1-\pi ) \mathcal {N}(\hbox {w}|0,\sigma _{2}^{2}) \end{aligned}$$\end{document}Although the Bayes by Backprop method induces notable changes in an NN architecture, we preserve the optimized hyperparameters of FFNN-ECIF. Following the original implementation32, we set \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\textrm{log}}\,\sigma _{1}=0, {\textrm{log}}\,\sigma _{2}=-6$$\end{document}, and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\pi =0.5$$\end{document}. To ensure comparability with other methods, we fix the number of samples for Monte Carlo integration at \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\textrm{K}} = 10$$\end{document}.

Evidential neural network This method quantifies uncertainty by applying priors to the likelihood function using a higher-order evidential distribution33. In the context of Maximum Likelihood Estimation (MLE), we train a model (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$p(y|\theta )$$\end{document}) by tweaking the \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\theta$$\end{document} parameter in order to maximize the likelihood of observed targets y. Assuming that \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$y_{i}$$\end{document} is drawn i.i.d, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\theta$$\end{document} denotes \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\mu$$\end{document} and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\sigma ^{2}$$\end{document} of a Gaussian distribution. But, in practice, we minimize the NLL loss function (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$-log\,p(y_{i}|\mu , \sigma ^{2})$$\end{document}).

In an evidential neural network, we seek to estimate unknown \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\theta =(\mu , \sigma ^{2})$$\end{document} probabilistically. To achieve this, we place Normal Inverse-Gamma (NIG) distribution \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$p(\theta |m)$$\end{document} with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$m = (\gamma , \nu , \alpha , \beta )$$\end{document} parameter as a prior over \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\theta =(\mu , \sigma ^{2})$$\end{document}43. During the regression task, a model learns these parameters m, which express distributions over the likelihood parameters (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\mu , \sigma ^{2}$$\end{document}), thus capturing the uncertainty in the model’s prediction. The output layer of the model has four neurons per target, corresponding to the four parameters of m. We train a model using a multi-objective loss function that attempts to maximize model accuracy while minimizing error evidence. The prediction and uncertainty are derived according to the NIG distribution moments:5\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\begin{aligned} \mathbb {E}[\mu ] = \gamma , Var[\mu ] = \frac{\beta }{\nu (\alpha -1)} \end{aligned}$$\end{document}Where \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\mathbb {E}[\mu ]$$\end{document} and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$Var[\mu ]$$\end{document} are prediction and uncertainty values for an input33.

## Section: Methods › Uncertainty prediction › Uncertainty evaluation

To evaluate and compare the quality of predictive uncertainty estimates, we employ a comprehensive set of metrics, including ranking-based, calibration-based, and proper scoring rules. We use Spearman’s Rank Correlation Coefficient to assess how well the predicted uncertainties correlate with actual errors. For the calibration-based method, we adopt the Miscalibration Area (MCA), Root Mean Squared Calibration Error (RMSCE), and Mean Absolute Calibration Error (MACE), which quantify the alignment between predicted confidence and observed accuracy. The Negative Log-Likelihood (NLL) serves as a proper scoring rule to estimate the deviation from the true probability distribution. In addition, Sharpness is used to evaluate the narrowness of the predictive distributions, regardless of whether the predictions are accurate or not. Here, predictive uncertainty refers to the variance of model predictions during inference. All metrics are computed using the open-source Uncertainty Toolbox (v0.1.1)46. A detailed description of each metric is provided in the Uncertainty Quantification Metrics subsection of the SI.

## Section: Results and discussion

Calculated metrics for FFNN-ECIF, CNN-MS-OIC, DeepDTA, and IGN across all test sets. Q\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{95}$$\end{document} is 95th percentile of absolute errors.

Uncertainty quantification performances for Deep Ensemble, MC-Dropout, Laplace approximation, Bayes by Backprop, and evidential neural network across five external test sets. \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\textrm{Sh}}$$\end{document} indicates the sharpness metric.

Calibration plot for Deep Ensemble, MC-Dropout, Laplace approximation, Bayes by Backprop, and evidential neural network across five external test sets. Each curve compares the observed versus predicted proportion of values within predictive intervals, with the dashed line indicating perfect calibration; proximity to the diagonal reflects better calibration.

Predictions and predictive intervals versus true values plot for the Bayes by Backprop method across five external test sets. In each panel, points show predicted binding affinities while error bars are associated with uncertainty intervals. The black dashed line indicates the observed values.

## Section: Results and discussion › Model performance and selection

The performance of binding affinity estimators—assuming sufficient data—depends on factors such as feature generation methods and the choice of ML or DL algorithms. To explore this diversity, we trained and tested four models: FFNN-ECIF, CNN-MS-OIC, DeepDTA, and IGN. The first two models, FFNN-ECIF and CNN-MS-OIC, belong to feature engineering methods and use FFNN and CNN algorithms, respectively. In contrast, DeepDTA and IGN are based on end-to-end representation learning, directly extracting relevant features from the raw representations of a protein-ligand complex.

It is worth mentioning that we chose these four methods due to their simplicity and popularity, so we can focus only on UQ performance without involving ourselves in complex new methods that may offer better performance, in the cost of other influencing factors.Fig. 2Calculated metrics for FFNN-ECIF, CNN-MS-OIC, DeepDTA, and IGN across all test sets. Q\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{95}$$\end{document} is 95th percentile of absolute errors.

To systematically compare the performance of these models, we first fine-tuned their hyperparameters using the LP-Train and LP-Valid sets, as detailed in Table S9–S12, except for IGN due to computational cost. Each model was then trained five times on LP-Train with different weight initializations to mitigate the impact of random variation. The best-performing model is then selected based on its performance on LP-Valid, while evaluations on external test sets—LP-Test, BDB2020+, EGFR, M\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$^{\textrm{pro}}$$\end{document}, and Peptide-Holdout—are conducted for all models.

Because the model performance can vary depending on the chosen metric (e.g., RMSE or R\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{\textrm{P}}$$\end{document}), we apply a statistical test to assess whether the observed difference between trained models is statistically significant. Note that, here, model selection is based on performance on the LP-Valid set. To determine an appropriate statistical test, we first examine the normality of the true and predicted labels, by calculating skewness and kurtosis47. Skewness, the third standardized moment, measures distribution symmetry: A value of zero indicates symmetry, while negative and positive values reflect left and right skew, respectively. Kurtosis, the fourth standardized moment, measures the tailedness of distribution or the frequency of outliers28. A kurtosis of zero marks a normal distribution, while negative values show leptokurtic behavior (heavier tails, more extreme outliers) and positive values signal platykurtic behavior (lighter tails, fewer extreme outliers)28.

Table S15 summarizes the skewness and kurtosis values for the true and predicted labels in the LP-Valid set, highlighting deviations from normality across models. Given these deviations, we chose the Wilcoxon signed-rank test—a non-parametric method for paired sample comparison—to evaluate if model error delta differences were statistically significant48. This test assumes the null hypothesis that both error delta distributions share the same population. A two-sided p-value below 0.05 indicates statistical significance. All analyses used the SciPy library (v1.8.1)49.

The Wilcoxon signed-rank test results (see Table S16 for more details) confirm that FFNN-ECIF exhibits statistically superior performance on the LP-Valid set compared to all other models (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$p < 0.05$$\end{document}). We therefore designate FFNN-ECIF as the optimal model for further analysis. As summarized in Fig. 2 and Table S17, FFNN-ECIF maintains robust performance: it achieves an R\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{\textrm{P}}$$\end{document} of 0.556 and RMSE of 1.545 on the LP-Valid set, and an R\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{\textrm{P}}$$\end{document} of 0.434 with RMSE of 1.736 on the independent LP-Test set, demonstrating consistent predictive accuracy across datasets.Fig. 3Uncertainty quantification performances for Deep Ensemble, MC-Dropout, Laplace approximation, Bayes by Backprop, and evidential neural network across five external test sets. \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\textrm{Sh}}$$\end{document} indicates the sharpness metric.

Additionally, we evaluated all models on external test sets (LP-Test, BDB2020+, EGFR, M\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$^{\textrm{pro}}$$\end{document}, and Peptide-Holdout). Model performance varies across sets, in part reflecting differences in binding affinity distributions. LP-Train has a median pK of 6.28, and performance is generally higher on datasets with medians close to this value. For example, M\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$^{\textrm{pro}}$$\end{document}, with a median of 6.22, shows the highest rank correlation for FFNN-ECIF (R\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{\textrm{S}}$$\end{document} = 0.601). In contrast, FFNN-ECIF on EGFR, with the largest median shift (7.90), exhibits reduced performance (R\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{\textrm{S}}$$\end{document} = 0.263), outperforming only DeepDTA. BDB2020+ (median 7.73) shows moderate performance, with FFNN-ECIF and CNN-MS-OIC achieving R\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{\textrm{P}}$$\end{document} \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\approx$$\end{document} 0.460, while DeepDTA and IGN perform worse (R\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{\textrm{P}}$$\end{document} = 0.302 and 0.401, respectively). All models show diminished predictive power on the Peptide-Holdout set (median 5.70), which contains only peptide ligands rather than the small molecules in LP-Train; FFNN-ECIF still outperforms the others, achieving R\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{\textrm{P}}$$\end{document} = 0.312. These observations suggest that shifts in binding affinity medians, along with differences in ligand chemistry, contribute to drops in performance on external datasets.

These results evidently reveal that even though FFNN-ECIF excelled on the LP-Val, it did not consistently generalize to other test sets, such as BDB2020+, EGFR, and Peptide-Holdout. This finding underscores the importance of quantifying uncertainty to better understand a model’s applicability domain. A complete set of results, including RMSE, MSE, MAE, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {Q}_{95}$$\end{document}, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {R}_{\textrm{P}}$$\end{document}, and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {R}_{\textrm{S}}$$\end{document} metrics, is presented in Table S17.Fig. 4Calibration plot for Deep Ensemble, MC-Dropout, Laplace approximation, Bayes by Backprop, and evidential neural network across five external test sets. Each curve compares the observed versus predicted proportion of values within predictive intervals, with the dashed line indicating perfect calibration; proximity to the diagonal reflects better calibration.

Calculated metrics for FFNN-ECIF, CNN-MS-OIC, DeepDTA, and IGN across all test sets. Q\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{95}$$\end{document} is 95th percentile of absolute errors.

Uncertainty quantification performances for Deep Ensemble, MC-Dropout, Laplace approximation, Bayes by Backprop, and evidential neural network across five external test sets. \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\textrm{Sh}}$$\end{document} indicates the sharpness metric.

Calibration plot for Deep Ensemble, MC-Dropout, Laplace approximation, Bayes by Backprop, and evidential neural network across five external test sets. Each curve compares the observed versus predicted proportion of values within predictive intervals, with the dashed line indicating perfect calibration; proximity to the diagonal reflects better calibration.

## Section: Results and discussion › Uncertainty quantification

After finding the best-performing model, we apply Deep Ensemble, MC-Dropout, Laplace approximation, Bayes by Backprop, and ENN approaches on FFNN-ECIF to estimate predictive uncertainty. In Deep Ensemble, we trained 10 distinct FFNN-ECIF models to form the ensemble. For MC-Dropout and Laplace approximation, we used the best of the five previously trained models. Bayes by Backprop and ENN required architectural and loss function modifications. For these methods, we retained the optimal hyperparameters and trained modified versions of FFNN-ECIF according to the respective frameworks.

Predictions and predictive intervals versus true values plot for the Bayes by Backprop method across five external test sets. In each panel, points show predicted binding affinities while error bars are associated with uncertainty intervals. The black dashed line indicates the observed values.

## Section: Results and discussion › Uncertainty quantification › Uncertainty quantification metrics

We evaluate Deep Ensemble, MC-Dropout, Laplace approximation, Bayes by Backprop, and ENN through several ranking-based, calibration-based, and proper scoring rules metrics. The results are depicted in Fig. 3 and aggregated in Table S18.

In ranking-based metrics, we use only \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {R}_{\textrm{S}}$$\end{document} to assess the relationship between uncertainty estimation and prediction error. Fig. 3 highlights the superior performance of Bayes by Backprop and Laplace approximation methods in the \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {R}_{\textrm{S}}$$\end{document} metric. Bayes by Backprop achieves the best \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {R}_{\textrm{S}}$$\end{document} of 0.196 and 0.245 on \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {M}^{\textrm{pro}}$$\end{document} and Peptide-Holdout, while Laplace approximation excels on LP-Test and BDB2020+ with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {R}_{\textrm{S}}$$\end{document} values of 0.250 and 0.277, respectively. In terms of sharpness, which measures the concentration and narrowness of a predictive distribution, the Deep Ensemble method consistently delivers the sharpest distributions across all datasets.

Building on the ranking-based evaluation, we next examine calibration-based metrics, including MACE, RMSCE, and MCA. ENN outperforms all methods across BDB2020+, EGFR, and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {M}^{\textrm{pro}}$$\end{document} by achieving the lowest MACE, RMSCE, and MCA values in calibration-based metrics. On LP-Test and Peptide-Holdout, Bayes by Backprop performs the best. Notably, RMSCE values are slightly higher than MACE because RMSCE penalizes deviated prediction further. To assess the impact of calibration on MACE, RMSCE, and MCA, we also report the recalibrated counterpart of the mentioned metrics (i.e., CMACE, CRMSCE, and CMCA), calculated by isotonic regression technique50. As shown in Fig. S9, recalibrated results follow similar trends, with two exceptions: (i) Bayes by Backprop achieves the highest scores on \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {M}^{\textrm{pro}}$$\end{document}, and (ii) Laplace approximation outperforms others on Peptide-Holdout. These findings highlight the importance of including recalibrated metrics in the evaluation.

Finally, we assess model performance using the NLL, a proper scoring rule that measures how well probabilistic models assign probabilities to observed outcomes. In this metric, Laplace approximation consistently outperforms other methods across all datasets except for \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {M}^{\textrm{pro}}$$\end{document}, where MC-Dropout achieves the best result.

Considering all the above evaluations, these results emphasize that no single metric can comprehensively evaluate UQ. A reliable UQ evaluation requires multiple complementary metrics. Across the 45 total metrics (nine metrics across five datasets), ENN and Bayes by Backprop perform best in 15 and 14 cases, respectively, followed by Laplace approximation (9), Deep Ensemble (6), and MC-Dropout (1). Metric-wise, Deep Ensemble stands out in the sharpness, with a mean value of 0.289. Laplace approximation and Bayes by Backprop excelled in \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {R}_{\textrm{S}}$$\end{document}, with mean scores of 0.171 and 0.169, respectively. They also led in the NLL metric, recording mean values of 1.842 and 1.974. In calibration-based metrics, Bayes by Backprop excels in uncalibrated MACE, RMSCE, and MCA, with means of 0.071, 0.082, and 0.072. Meanwhile, ENN emerges as the top-performing UQ method in recalibrated calibration-based metrics (CMACE, CRMSCE, and CMCA), achieving means of 0.061, 0.071, and 0.061.Fig. 5Predictions and predictive intervals versus true values plot for the Bayes by Backprop method across five external test sets. In each panel, points show predicted binding affinities while error bars are associated with uncertainty intervals. The black dashed line indicates the observed values.

Predictions and predictive intervals versus true values plot for the Bayes by Backprop method across five external test sets. In each panel, points show predicted binding affinities while error bars are associated with uncertainty intervals. The black dashed line indicates the observed values.

## Section: Results and discussion › Uncertainty quantification › Calibration plot

To gain deeper insight into UQ, we visualize the calibration for all UQ methods across datasets (see Fig. 4). These plots reveal whether a UQ method exhibits overconfidence (underestimating uncertainty) or underconfidence (overestimating uncertainty). Across most datasets, UQ methods largely deviate from the ideal calibration curve. A prominent exception is Bayes by Backprop on LP-Test, which closely follows the ideal line (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\hbox {MCA} = 0.014$$\end{document}). Overall, Fig. 4 reveals that UQ methods are overconfident by approximately 60% (15 curves among 25 ones in Fig. 4). MC-Dropout and Deep Ensemble exhibit an overconfident behavior, while Laplace approximation uniquely underestimates uncertainty. Bayes by Backprop and ENN display dataset-dependent pattern, adjusting their confidence based on the dataset. In corollary Bayes by Backprop demonstrates the best overall calibration, achieving a mean MCA of 0.072, while Deep Ensemble shows the poorest calibration, with a mean MCA of 0.352.

To scrutinize the effect of recalibration on overconfident and underconfident behavior, we plot a calibration curve of UQ methods after recalibration on LP-Val (see Fig. S10). The results reveal that recalibration shifts curves closer to the ideal line, thereby improving MCA across methods. The largest improvement is observed in Deep Ensemble,, where recalibration reduces the mean MCA by 51% (to 0.173). This adjustment not only improves calibration but also reshuffles the relative ranking of UQ methods. ENN emerges as the best-calibrated method post-recalibration, achieving a mean MCA of 0.061.

## Section: Results and discussion › Uncertainty quantification › Predictive intervals

Predictive intervals plots visualize how well model predictions align with true values46. Predictive intervals, defined here as the standard deviation of predictions (i.e., uncertainty values), provide insights into the variability or confidence in the model’s outputs. When true values frequently fall within the intervals, i.e., standard deviation, the model’s uncertainty is well-calibrated. Conversely, true values outside the intervals suggest an underestimation of uncertainty, while excessively wide intervals indicate overestimation.

To explore these patterns and biases, we plot predictions and predictive intervals against ordered true values, sampling 100 instances from large datasets (LP-Test, BDB2020+, and Peptide-Holdout) for clarity. Fig. 5 shows the predictive intervals for Bayes by Backprop (see Figs. S11–S14 for other methods). This confirms our earlier conclusion that Bayes by Backprop is a well-calibrated model, as true values generally fall within predicted intervals even without recalibration.

## Section: Results and discussion › Uncertainty quantification › Best uncertainty quantification method

We thoroughly analyze five implemented UQ methods on the FFNN-ECIF model to identify the most effective approach. Our analyses cover 45 distinct metrics (nine metrics across five datasets). The nine metrics include R\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{\textrm{S}}$$\end{document}, NLL, MACE, RMSCE, MCA, CMACE, CRMSCE, CMCA, and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${\textrm{Sha}}$$\end{document}, while the five datasets consist of LP-Test, BDB2020+, M\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$^{\textrm{pro}}$$\end{document}, EGFR, and Peptide-Holdout. Also, our analysis is complemented by two diagrams (i.e., calibration curve and predictive intervals) for further examination.

Our assessments show that UQ performance depends strongly on the similarity between external datasets and LP-Train. Datasets such as M\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$^{\textrm{pro}}$$\end{document}, with medians and spreads close to LP-Train, exhibit well-calibrated uncertainties, whereas EGFR and BDB2020+, with larger median shifts, show higher calibration errors. Peptide-Holdout, both chemically distinct and distributionally shifted, displays degraded performance across all methods. These observations highlight how distributional shifts in binding affinity value and ligand chemistry affect the reliability of uncertainty estimates, and underscore that UQ method selection is inherently empirical, depending on the training data context.

An additional inspection of UQ methods reveals complementary strengths. Bayes by Backprop achieves the most consistent calibration (lowest RMSCE and MACE) across datasets. Laplace approximation performs well in negative log-likelihood and ranking (R\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$_{\textrm{S}}$$\end{document}), though its stability drops in out-of-distribution (ODD) cases like Peptide-Holdout. Deep ensembles provide the sharpest predictive intervals, but display overconfidence and higher calibration errors. MC-Dropout is computationally efficient and better calibrated than Deep ensembles, but less robust than Bayes by Backprop or Laplace approximation. ENN remains inconsistent, showing strong results in some cases (e.g., M\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$^{\textrm{pro}}$$\end{document}) but unstable or even negative correlations in others (e.g., LP-Test, EGFR).

Taken together, these findings suggest that the optimal method ultimately depends on balancing calibration quality, computational cost, and robustness to distributional shifts, which are exhibited by Bayes by Backprop. These strengths make Bayes by Backprop particularly valuable for predictions in ODD scenarios and anomaly detection tasks, where reliable uncertainty estimates are crucial for identifying when models encounter unfamiliar data51,52.

## Section: Conclusions

In this study, we present the comparison of five UQ methods for binding affinity prediction. To achieve this, we used LP-PDBBind, an unbiased curation of the PDBBind dataset, along with external datasets (EGFR, M\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$^{\textrm{pro}}$$\end{document}, BDB2020+, and Peptide-Holdout) for training, validation, and testing. We trained four deep learning models—FFNN-ECIF, CNN-MS-OIC, DeepDTA, and IGN—on the LP-Train dataset. FFNN-ECIF emerged as the best model when evaluated on the LP-Val dataset. Subsequently, we applied two popular UQ techniques, Deep Ensemble, and MC-Dropout, as well as three less commonly used approaches: Laplace approximation, Bayes by Backprop, and evidential neural networks.

Our evaluation employed diverse ranking-based and calibration-based metrics alongside proper scoring rules. To complement these analyses, we examined calibration curves and predictive interval plots, which clearly established Bayes by Backprop as the top-performing UQ method. Bayes by Backprop showed accurate ranking-based, proper scoring rules, and sharpness metrics. This approach not only achieved strong results across ranking-based and sharpness metrics but also demonstrated superior calibration without requiring recalibration, making it particularly valuable for out-of-distribution predictions.

In the near future, we will apply our findings to active learning algorithms, where the model actively selects the most informative data points for labeling through a query strategy, rather than passively using a pre-labeled dataset53,54. One such query strategy is uncertainty sampling, where data with the least confidence are selected for further training and labeling. We believe that applying FFNN-ECIF, augmented with Bayes by Backprop for UQ, alongside active learning can enhance and accelerate protein-ligand binding affinity prediction.

## Section: Supplementary Information

Supplementary Information.

Supplementary Information.


---

# Uncertainty quantification with graph neural networks for efficient molecular design

- **Authors:** Lung-Yi Chen, Yi-Pei Li
- **Issuer:** Nature communications
- **Type:** Scientific article
- **Published:** 2025-04-05
- **Language:** en
- **DOI:** 10.1038/s41467-025-58503-0
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40188130/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractOptimizing molecular design across expansive chemical spaces presents unique challenges, especially in maintaining predictive accuracy under domain shifts. This study integrates uncertainty quantification (UQ), directed message passing neural networks (D-MPNNs), and genetic algorithms (GAs) to address these challenges. We systematically evaluate whether UQ-enhanced D-MPNNs can effectively optimize broad, open-ended chemical spaces and identify the most effective implementation strategies. Using benchmarks from the Tartarus and GuacaMol platforms, our results show that UQ integration via probabilistic improvement optimization (PIO) enhances optimization success in most cases, supporting more reliable exploration of chemically diverse regions. In multi-objective tasks, PIO proves especially advantageous, balancing competing objectives and outperforming uncertainty-agnostic approaches. This work provides practical guidelines for integrating UQ in computational-aided molecular design (CAMD).Subject terms: Chemical engineering, Cheminformatics

## Section: Introduction

The exploration of novel chemical materials is a pivotal scientific endeavor with the potential to significantly advance both the economy and society1–4. Historically, the discovery of innovative molecules has led to major breakthroughs in various fields, including the development of enhanced medical therapies5, innovative catalysts for chemical reactions6, and more efficient carbon capture technologies7. These discoveries have traditionally resulted from labor-intensive experimental processes characterized by extensive trial and error.

In response to the limitations of these traditional experimental approaches, computational-aided molecular design (CAMD) has emerged as a crucial innovation. By conceptualizing material design as an optimization problem, where molecular structures and their properties are treated as variables and objectives, CAMD harnesses computational power to efficiently predict and identify promising materials. The advent of sophisticated machine learning algorithms has marked a paradigm shift from conventional knowledge-based methods, such as the group contribution method8–10, to advanced learning-based strategies11. Among these, deep learning has demonstrated exceptional accuracy and flexibility, modeling complex interrelations between chemical structures and properties that challenge traditional theoretical approaches12. For example, graph neural networks (GNNs) have emerged as powerful tools for representing molecular structures13. Unlike traditional models that rely on fixed molecular descriptors, GNNs operate directly on molecular graphs, capturing detailed connectivity and spatial relationships between atoms. This graph-based approach enables GNNs to model molecular interactions with high fidelity14,15, making them particularly well-suited for applications in molecular design, where accurate structural representation is critical. Furthermore, GNNs offer scalability16, enabling efficient processing of large datasets, which is essential for exploring the expansive chemical spaces required in CAMD.

As CAMD has evolved, it has incorporated various generative models and sophisticated optimization strategies that employ surrogate models as objective functions to enhance molecular design. For example, variational autoencoders (VAEs) have been widely used for molecular generation by encoding molecules into a latent space where new structures can be sampled and decoded, facilitating exploration of chemical space17,18. These VAEs are often coordinated with optimization techniques, such as evolutionary algorithms19–21, Bayesian optimization (BO)18,22, or Monte Carlo tree search (MCTS)23 to guide the search toward novel molecules with desired properties. Similarly, SMILES-based recurrent neural networks (RNNs) have been employed to generate molecular structures24–26. After a pretraining phase, RNNs are often fine-tuned using reinforcement learning, enhancing the model’s ability to achieve goal-directed optimization. However, a significant challenge for generative models can be ensuring diversity in the generated molecules, especially if training data is limited or narrowly focused, which may limit their utility for exploring diverse chemical spaces27. Beyond generative models, some approaches apply optimization algorithms directly to molecular representations without requiring latent spaces. For instance, genetic algorithms (GAs) operate on molecular graphs28,29 or SMILES strings30,31, iteratively generating improved candidates through mutation and crossover operations. This approach bypasses the need for a pretrained generative model, making GAs adaptable and accessible for a variety of CAMD tasks. Compared with generative models, GAs can work well even with smaller datasets and may have lower initial computational demands, which can be beneficial for direct exploration and optimization of molecular properties. Additionally, their evolutionary principles naturally maintain diversity, supporting a broad exploration of chemical space and adaptability to specific property objectives32.

Despite the promise of these optimization approaches, a major challenge with data-driven models in CAMD is their tendency to fail in accurately predicting properties for molecules outside their training scope. This limitation underscores the importance of integrating uncertainty quantification (UQ) into CAMD to assess prediction reliability. Previous studies have commonly addressed this challenge through BO frameworks, often using Gaussian process regression (GPR), including Kriging models33. These non-parametric models make predictions with uncertainty estimates based on the posterior distribution, leveraging a kernel function to define the covariance between training data points. However, the matrix inversion required for non-parametric methods can become time-consuming, particularly for large datasets, as the computational complexity scales On3 with the number of training data and On with the dimension of molecular features34,35. As a result, GPR models are typically constrained to smaller training datasets36, limiting the chemical space that can be explored in CAMD37. To alleviate this computational bottleneck and enable the use of larger datasets, several approximation strategies have been proposed for GPR38. Low-rank or sparse methods (e.g., inducing-point approaches) address the O(n3) scaling by selecting a small subset of points (inducing points), reducing the effective size of the Gram matrix, and leading to a more manageable O(nm2) complexity. Random feature expansions—such as random Fourier features—approximate the kernel function by mapping data into a lower-dimensional feature space, converting GPR into an approximately linear model that can be trained in OnD or O(nD2), where D≪n. Distributed or parallel GPs divide the dataset across multiple machines or computational nodes, combining local posteriors to maintain predictive accuracy while managing larger data volumes. These techniques collectively address the high computational burden of Gaussian process models and may expand the applicability of BO-driven CAMD to larger chemical search spaces.

In contrast, parametric models like GNNs offer a scalable alternative, as they maintain a fixed number of parameters regardless of dataset size, allowing efficient handling of larger datasets. UQ has been successfully integrated with parametric models for active learning and virtual screening, enhancing workflow efficiency39,40. However, optimizing over expansive chemical spaces presents distinct challenges, as accurate UQ under domain shifts remains notoriously difficult41,42. To the best of our knowledge, whether UQ integration within parametric models can enable effective optimization across broad, open-ended chemical spaces—and how best to implement this—remains an open question. Such an approach is particularly valuable for CAMD, as it enables exploration across vast and less-characterized chemical spaces essential for discovering novel compounds.

In this work, we address this issue by combining GNNs with GAs for molecular optimization, allowing direct exploration of chemical space without reliance on predefined libraries or generative models. To mitigate errors associated with surrogate model predictions in extrapolated regions, we integrate UQ into our GNN framework43–45. Inspired by acquisition functions used in BO46, we systematically investigate different ways to incorporate UQ into CAMD, including probabilistic improvement and expected improvement methods. Our experiments show that the probabilistic improvement optimization (PIO) approach, which uses probabilistic assessments to guide the optimization process, is particularly effective in facilitating exploration of chemical space with GNNs. Given that practical applications often require molecular properties to meet specific thresholds rather than extreme values47,48, the PIO method quantifies the likelihood that a candidate molecule will exceed predefined property thresholds, reducing the selection of molecules outside the model’s reliable range and promoting candidates with superior properties.

Our study includes a comprehensive evaluation of uncertainty-agnostic and uncertainty-aware optimization approaches using the Tartarus49 and GuacaMol48 platforms, both open-source molecular design tools addressing a range of design challenges. Tartarus utilizes physical modeling across various software packages to estimate target properties, effectively simulating the experimental evaluations required in molecular design processes, while GuacaMol focuses on drug discovery tasks such as similarity searches and physicochemical property optimization. The benchmarking workflow, illustrated in Fig. 1, starts with datasets from these platforms to develop GNN-based surrogate models using the directed message passing neural network (D-MPNN) implemented in Chemprop50. These models predict molecular properties and their uncertainties, which, when coupled with a GA, optimize molecular structures based on the PIO and other selected fitness functions. Our results indicate that the PIO method substantially improves the likelihood of meeting threshold requirements, especially in multi-objective optimization tasks.

In summary, this integration of UQ with GNNs for CAMD represents a pioneering approach, offering a more reliable and scalable strategy for discovering novel chemical materials. Through extensive benchmarking and validation, our work demonstrates the potential of uncertainty-aware GNN algorithms in molecular design, with promising applications across domains such as organic electronics, biochemistry, and materials science.

a Schematic diagram illustrating the overall workflow used in this study to evaluate the optimization strategy. b Description of the benchmark tasks comprising three molecular design challenges from the Tartarus suite, which utilize physical modeling across different software packages to estimate target properties, circumventing the need for actual experimental assessments. Seven additional drug discovery tasks were selected from GuacaMol, using similarity metrics and physicochemical descriptor calculations as oracle functions to evaluate molecular properties. c Schematic representation of the genetic algorithm (GA), where the mutation operator randomly modifies molecular structures, and crossover operations generate new molecular structures through recombination. d Construction of a machine learning (ML) surrogate model employing the directed message passing neural network (D-MPNN) architecture, designed to predict molecular properties and their associated uncertainties via either the evidential method or the ensemble with mean-variance estimation (MVE) method. e The PIO fitness function, calculated using probability improvement, generally enhances the likelihood of meeting threshold requirements. TS transition state, logP octanol-water partition coefficient, TPSA topological polar surface area.

## Section: Results

Summary of the molecular design tasks investigated in this study

The color coding of the data points indicates the level of total uncertainty (σtotal2) in the model predictions. Uncertainty quantification (UQ) across the panels varies: a–c ensemble and mean-variance estimation (MVE) methods were utilized; d–s the evidential method was applied in panels. The molecular structure similarity is calculated using the Tanimoto similarity metric. Abs. diff. of VEE absolute difference of vertical excitation energy, R2 (coefficient of determination), logP octanol-water partition coefficient, TPSA topological polar surface area. Source data is provided as a Source Data file.

The area under the calibration error curve (AUCE), or miscalibration area106 (gray area in this figure), is calculated, with perfect calibration indicated by an AUCE of 0. Uncertainty quantification (UQ) across the panels varies: a–c ensemble and mean-variance estimation (MVE) methods were utilized; d–s the evidential method was applied. The molecular structure similarity is calculated using the Tanimoto similarity metric. Abs. diff. of VEE absolute difference of vertical excitation energy, logP octanol-water partition coefficient, TPSA topological polar surface area. Source data is provided as a Source Data file.

Comparison of top-k hit rates for single-objective optimization results across various methods

a–j These plots show direct objective maximization (DOM, brown), expected improvement (EI, purple), and probabilistic improvement optimization (PIO, green) results. The black dotted line represents the cutoff values, while orange arrows illustrate the desired optimization direction. For the final three similarity optimization tasks, the structures of the target molecules are displayed within their respective figures. The molecular structure similarity is calculated using the Tanimoto similarity metric. Source data are provided as a Source Data file.

a–j These plots show top-50 candidate molecules generated based on the fitness values from direct objective maximization (DOM, brown), expected improvement (EI, purple), and probabilistic improvement optimization (PIO, green). Predictions are presented as means with standard deviations (error bars), capturing both aleatoric and epistemic uncertainty, as estimated by the D-MPNN model. The black dotted line represents the cutoffs, while the orange arrows illustrate the desired direction for optimization. The molecular structure similarity is calculated using the Tanimoto similarity metric. Source data is provided as a Source Data file.

Comparison of top-k hit rates for multi-objective optimization results across various methods

Each subplot displays molecules generated by the methods: a weighted sum (WS), b normalized Manhattan distance (NMD), c hybrid approach (NMD-WS), and d probabilistic improvement optimization (PIO), organized into six sections arranged from left to right, corresponding to the design tasks for organic emitters, reaction substrates, median molecules 1, median molecules 2, fexofenadine multi-property optimization (MPO), and ranolazine MPO. Blue lines represent molecules that failed to meet all established cutoffs, while orange lines signify those that met all criteria. Black dotted lines across the plots denote the cutoffs. Orange arrows indicate the desired direction for optimization. The molecular structure similarity is calculated using the Tanimoto similarity metric. Abs. diff. of VEE absolute difference of vertical excitation energy, R2 (coefficient of determination) logP octanol-water partition coefficient, TPSA topological polar surface area. Source data is provided as a Source Data file.

## Section: Results › Molecular design benchmarks

To effectively evaluate molecular design strategies, tasks must be complex enough to reflect the challenges encountered in real-world applications. Our study provides a comprehensive assessment of different optimization approaches across 19 molecular property datasets, encompassing 10 single-objective and 6 multi-objective tasks (Table 1), derived from the Tartarus49 and GuacaMol48 platforms.

The first platform, Tartarus49, offers a sophisticated suite of benchmark tasks tailored to address practical molecular design challenges within the realms of materials science, pharmaceuticals, and chemical reactions. Utilizing well-established computational chemistry techniques, including force fields and density functional theory (DFT), Tartarus models complex molecular systems with high computational efficiency. The benchmarks encompass a wide array of applications, ranging from optimizing organic photovoltaics and discovering novel organic light-emitting diodes (OLEDs) to designing protein ligands and pioneering new chemical reactions. This breadth enables a comprehensive evaluation of various molecular design algorithms across multiple real-world simulation scenarios.

Three molecular design categories from Tartarus, comprising seven single-objective and two multi-objective tasks, are listed in Table 1. Each task employs specific computational methods: organic emitter design involves conformer sampling51, semi-empirical quantum mechanical methods for geometry optimization52,53, and time-dependent DFT for single-point energy calculations54. Protein ligand design utilizes docking pose searches to determine stable binding energies55, supplemented by empirical functions for final score calculations56. Reaction substrate design tasks employ force fields for optimizing reactant and product structures57, with transition state structures further refined using the SEAM method58. These methods include stochastic elements such as conformer search and docking site sampling, introducing variability in simulation outcomes due to the inherent randomness of geometry optimization. For multi-objective tasks, a typical approach might involve aggregating multiple objectives into a single composite score. However, this can lead to suboptimal compromises where certain objectives are sacrificed to maximize the overall score. In practical applications, molecules often need to satisfy multiple objectives simultaneously, which can be particularly challenging when these objectives are mutually constraining. To evaluate the efficacy of molecular design strategies under these conditions, we analyzed each objective within multi-objective tasks, choosing scenarios where objectives could potentially conflict. For example, the task of simultaneously minimizing both activation energy and reaction energy was excluded due to their positive correlation, as explained by the Bell–Evans–Polanyi principle59,60. Conversely, we included the task of simultaneously maximizing activation energy while minimizing reaction energy, as it poses a significant challenge by deviating from conventional expectations and thus aligns more closely with the aims of our study. These choices are detailed in Table 1, illustrating the structured approach to assessing molecular design algorithms against complex, real-world criteria.

The second molecular design platform, GuacaMol48, serves as a widely recognized benchmark in drug discovery and is extensively utilized in various molecular optimization studies. The design tasks include marketed drug rediscovery, similarity assessment, median molecule generation, and isomer generation. From these, we selected tasks suitable for molecular property optimization, comprising three single-objective tasks aimed at identifying structures similar to a specific drug and four multi-objective tasks focused on finding median molecules between two drugs or achieving multi-property optimization (MPO), as detailed in Table 1. Unlike the physical simulations in Tartarus, GuacaMol uses deterministic functions implemented in RDKit to compute property values, thereby eliminating data randomness. To simulate real-world scenarios where machine learning (ML) surrogate models are rarely perfect, we downsample the GuacaMol dataset to build ML surrogate models for fitness prediction during the GA process. In this setup, the molecular design process initially relies on a potentially imperfect surrogate model to propose molecular structures, which are subsequently validated using the RDKit-based oracle functions.

Summary of the molecular design tasks investigated in this study

## Section: Results › Uncertainty-aware and uncertainty-agnostic fitness functions

In conventional molecular design, the typical single-objective optimization approach focuses on maximizing a specific fitness function FDOMm without consideration of uncertainty. This naïve approach, referred to as the direct objective maximization (DOM), or greedy method61, is defined as

where μm represents the predicted property value of molecule m by the surrogate model, and η is the sign factor taking the values of +1 or -1. This factor is assigned a value of +1 when a higher μ is desired, and −1 when a lower μ is preferred. However, practical applications often do not necessitate driving the property values to their extremes. Instead, it is usually sufficient for the property to meet a certain threshold δ that is deemed acceptable for a given application47,48.

In such scenarios, the goal should shift from merely optimizing the property value to ensuring that the property of the molecule m exceeds this threshold δ. Assuming the property predicted by the surrogate model follows a Gaussian distribution with mean μm and variance σ2m, the PIO fitness function can be defined as

where FPIOm;δ ranges between 0 and 1. In this expression, FPIOm;δ quantifies the probability that the property value of molecule m will exceed the threshold δ. The PIO approach inherently incorporates the uncertainty (variance) of the prediction and mitigates the risk of extrapolating the surrogate model beyond its reliable range and has been recently adopted in other works utilizing active learning for drug discovery61, co-cured polycyanurates62, organic semiconductors63 and boron–carbon–nitrogen crystal structure design64. By establishing a realistic threshold δ, this method significantly enhances the practicality and applicability of molecular design optimization in real-world settings.

An alternative approach to incorporating uncertainty into the fitness function is the expected improvement (EI) method, which evaluates the expected magnitude of the improvement46. Assuming the property predicted by the surrogate model follows a Gaussian distribution with mean μm and variance σ2m, the fitness function for EI can be defined as

The primary difference between PIO (Eq. 2) and EI (Eq. 3) lies in whether the integration over possible improvements at a given x is considered. The PIO method focuses solely on the likelihood of improvement at a specific threshold, making it a unitless probability value, whereas the EI method considers both the probability and magnitude of potential gains, yielding a value with the same unit as the target variable. Both approaches are commonly used as acquisition functions in BO46. In this work, we compare the performance of DOM with both PIO and EI for single-objective optimization tasks. This comparative analysis aims to highlight the advantages of incorporating UQ with GNN in molecular design and to determine the most effective optimization strategy for various practical applications.

When considering multiple properties in molecular design, a common method, known as scalarization, aggregates all objectives into a single value using their corresponding weights. The weights should be carefully chosen to balance the contributions of each property in the objective function. One approach is to use the reciprocal of the standard deviation σ~ of each target’s distribution in the dataset as weights65, scaling the contribution of each property according to the potential variability of its values:

where k is the number of properties considered. However, this weighted sum (WS) approach can still lead to suboptimal compromises where certain objectives are sacrificed to enhance the overall score65. In practical scenarios, molecules often need to meet multiple objectives simultaneously, typically represented by thresholds. To address this, we propose calculating the product of individual probabilities that each property surpasses its respective threshold, representing the overall probability of meeting all specified targets:

If any single probability approaches zero, the overall fitness score will also approach zero, regardless of high scores in other targets. This method emphasizes balancing trade-offs and aligns more closely with the complex demands of real-world applications66–68.

One limitation of the WS method in Eq. 4 is that it does not account for specific optimization thresholds, which may lead to unbalanced solutions in multi-objective optimization. Inspired by the ε-constraint method69, which reformulates additional objectives as constraints with threshold values to ensure feasible trade-offs, this study explores alternative formulations, such as the normalized Manhattan distance (NMD) to the ideal threshold values δ1,δ2,…,δk as the objective function70. This approach treats objective values that meet or exceed the thresholds as equally favorable, potentially reducing the risk of overemphasizing certain properties at the expense of others

where FNMDmulti≤0. Both the NMD and ε-constraint methods aim to achieve balanced solutions by incorporating objective-specific limits. However, while NMD minimizes cumulative deviations to treat all objectives meeting thresholds as equally favorable, the ε-constraint method enforces strict feasibility by converting secondary objectives into constraints, resulting in a more rigid adherence to specified bounds. A key limitation of NMD, though, is that it restricts further optimization once all thresholds are met. To overcome this, we propose a hybrid fitness function that combines the NMD and the simple WS approach, transitioning form FNMDmulti to FWSmulti once all property values meet their respective thresholds

This hybrid approach (NMD-WS), similar to methods combining ε-constraint and weighted sum techniques69, aims to combine the strengths of both methods, achieving a balanced optimization that respects the thresholds while allowing further improvements once the initial conditions are met.

## Section: Results › Surrogate model and UQ performance

For effective CAMD, it is crucial that the surrogate model accurately represents the molecular properties of interest. To this end, we first assessed the performance of the D-MPNN model along with two UQ methods—deep ensemble combined with mean-variance estimation (MVE)71 and evidential learning72—on the target properties of the design tasks specified in Table 1. Our evaluations revealed that neither UQ method delivered consistent performance across all datasets. Notably, the MVE loss function exhibited a tendency to diverge when training models on the reactivity dataset, which occasionally led to the premature termination of training sessions. In contrast, the evidential loss function faced convergence issues during the training of models for the organic emitter dataset, resulting in reduced accuracy. These challenges in model training may be partly attributed to data noise inherent in the property values, a consequence of the non-deterministic computational procedures used to generate these data, as detailed in the method section and illustrated in Supplementary Figs. S1, S2, and S3. These observations highlight the critical need for further development and refinement of these UQ methods to enhance their robustness. In response to these findings, we selected the deep ensemble and MVE approach for the organic emitter dataset, while applying evidential regression for the other datasets in our molecular design experiments. The efficacy of these approaches was visually assessed using parity plots and confidence-based calibration curves, displayed in Figs. 2 and 3, respectively. These figures show that the D-MPNN effectively captures the trends in property values, with the estimated uncertainties generally well-calibrated against the test set.

It is important to recognize that prediction uncertainties may arise from multiple sources, such as data noise and model uncertainty, meaning that the residuals between predicted and reference values may not always follow a Gaussian distribution. Therefore, we validated the Gaussian distribution assumption by examining the actual distribution of residuals. This was achieved by using confidence-based calibration curves (Fig. 3)73,74. These curves assess the proportion of test data points that fall within a confidence interval around their predicted values. The intervals are calculated based on predicted variance under the Gaussian assumption, and the observed proportions are then compared to the expected confidence levels. Ideally, a perfect calibration curve would follow a diagonal line, where predicted probabilities align with observed proportions across various confidence levels. To quantify deviations from this ideal calibration, we calculated the area under the calibration error curve (AUCE), with higher AUCE values reflecting greater deviations from perfect calibration. As shown in Fig. 3, the calibration curves closely follow the diagonal line across all test sets, with AUCE values remaining below 0.1, suggesting that the residual distribution for the test data does not significantly deviate from Gaussian assumptions and aligns well with estimated variance. Nonetheless, further improvement in uncertainty estimation may be achieved through additional recalibration steps75,76 or by employing alternative UQ methods77,78 that do not rely on strong distributional assumptions. Incorporating these enhanced UQ methods with uncertainty-aware optimization presents a promising direction for future research.

The color coding of the data points indicates the level of total uncertainty (σtotal2) in the model predictions. Uncertainty quantification (UQ) across the panels varies: a–c ensemble and mean-variance estimation (MVE) methods were utilized; d–s the evidential method was applied in panels. The molecular structure similarity is calculated using the Tanimoto similarity metric. Abs. diff. of VEE absolute difference of vertical excitation energy, R2 (coefficient of determination), logP octanol-water partition coefficient, TPSA topological polar surface area. Source data is provided as a Source Data file.

The area under the calibration error curve (AUCE), or miscalibration area106 (gray area in this figure), is calculated, with perfect calibration indicated by an AUCE of 0. Uncertainty quantification (UQ) across the panels varies: a–c ensemble and mean-variance estimation (MVE) methods were utilized; d–s the evidential method was applied. The molecular structure similarity is calculated using the Tanimoto similarity metric. Abs. diff. of VEE absolute difference of vertical excitation energy, logP octanol-water partition coefficient, TPSA topological polar surface area. Source data is provided as a Source Data file.

## Section: Results › Optimization results of single-objective task

This section evaluates the optimization results obtained using DOM (Eq. 1), PIO (Eq. 2), and EI (Eq. 3) fitness functions across ten single-objective tasks, focusing on the hit rate of molecules—i.e., their ability to exceed predetermined threshold values. This metric assesses whether the integration of uncertainty into the fitness function could improve the success rate of generating molecules that surpass these thresholds. As shown in Table 2, the PIO method consistently achieved the highest hit rates for most tasks. Additionally, Fig. 4 illustrates that, under the PIO approach, the top-100 molecules for these tasks exhibit a greater proportion of candidates meeting or exceeding the threshold, compared to those generated by DOM, further demonstrating the benefit of incorporating uncertainty in the optimization process. However, despite integrating uncertainty, the EI method does not consistently outperform the uncertainty-agnostic DOM method.

To understand why only the PIO method outperformed its uncertainty-agnostic counterpart while the EI method did not, we generated parity plots of the molecules optimized by each method (Fig. 5). These plots show that the leading molecules selected by EI tend to exhibit the highest uncertainties in the surrogate model compared to those identified by DOM and PIO. Conversely, DOM-selected molecules often display extreme predicted mean values—either lowest or highest for minimization or maximization tasks, respectively. This outcome is expected, as DOM focuses solely on optimizing the predicted mean without considering uncertainty, often pushing optimization toward extrapolative regions where predictions are less reliable. While EI does incorporate uncertainty, its performance in most single-objective optimization tasks was not particularly robust. This outcome likely stems from EI’s tendency to favor candidates with high uncertainty when their predicted mean values are similar, as it calculates expected improvements as the fitness function. Such a preference can lead to the selection of molecules with significant prediction uncertainties, which often causes discrepancies between predicted and actual properties, contributing to EI’s relatively unstable performance across tasks. It is worth noting that EI is widely used as an acquisition function in BO with Gaussian processes79–83, where it effectively identifies optimal solutions within smaller, more confined search spaces over fewer iterations. However, molecular design requires navigating a much larger chemical space, where D-MPNN surrogate models can assign considerable uncertainty to numerous candidate structures, inflating expected improvements and diminishing EI’s effectiveness in our test cases. In contrast, PIO focuses exclusively on the probability of improvement, yielding a bounded fitness value between 0 and 1, which makes it less susceptible to the issues of extreme variance. By emphasizing candidates with a higher probability of exceeding the threshold without overemphasizing uncertain regions, PIO achieves more stable and reliable performance. This balance enables PIO to identify candidates that meet cutoff criteria while maintaining lower uncertainties, leading to more reliable predictions.

However, certain challenging tasks reveal limitations across all methods—DOM, EI, and PIO—in identifying candidates that surpass thresholds. For example, tasks involving singlet-triplet gap, 1SYH score, and similarity to mestranol demonstrate cases where all of these approaches struggle to find candidates meeting the set criteria, highlighting areas for further improvement. The first limitation arises from the dependency of both PIO and EI on threshold-based guidance during the search process. When thresholds are set too stringently, far beyond the performance range of the current population, the fitness score remains zero regardless of optimization direction, which can impede the search for high-performing molecules. In our study, most thresholds were set near the performance of top molecules within each task’s original dataset (as shown in Supplementary Table S5). Consequently, the difficulty of exceeding these thresholds varies depending on the structural diversity in each dataset. The second limitation involves decreased model accuracy in predicting property mean and variance in extrapolated regions. This issue is evident in the mestranol similarity task, where the objective is to identify molecules resembling mestranol’s complex polycyclic structure, featuring four fused rings (Fig. 4j). Accurately capturing these complex ring structures remains challenging for D-MPNN, which would benefit from additional structural features—such as ring size indicators—to improve prediction accuracy for complex species in highly extrapolated regions84. Therefore, although D-MPNN performed reasonably well on the test set for this task (Fig. 2k), it struggled to identify similar molecules within the broader chemical space, consistently yielding similarity predictions for recommended candidates that deviated significantly from the true reference values (Fig. 5j). An additional concern is that these predictions frequently showed small uncertainty estimates, suggesting that D-MPNN may have inaccurately assessed uncertainty in these cases. This finding underscores a critical limitation: even well-calibrated models may struggle to generalize accurately during molecular optimization over an extensive chemical space, leading to unreliable predictions not only for mean values but also for variance estimates with current UQ methods. One approach to address these challenges is adaptive modeling, which iteratively incorporates newly validated molecules to refine predictions and improve uncertainty estimates. However, improving the reliability of UQ methods is essential to address these challenges and strengthen the robustness of molecular design workflows.

Comparison of top-k hit rates for single-objective optimization results across various methods

a–j These plots show direct objective maximization (DOM, brown), expected improvement (EI, purple), and probabilistic improvement optimization (PIO, green) results. The black dotted line represents the cutoff values, while orange arrows illustrate the desired optimization direction. For the final three similarity optimization tasks, the structures of the target molecules are displayed within their respective figures. The molecular structure similarity is calculated using the Tanimoto similarity metric. Source data are provided as a Source Data file.

a–j These plots show top-50 candidate molecules generated based on the fitness values from direct objective maximization (DOM, brown), expected improvement (EI, purple), and probabilistic improvement optimization (PIO, green). Predictions are presented as means with standard deviations (error bars), capturing both aleatoric and epistemic uncertainty, as estimated by the D-MPNN model. The black dotted line represents the cutoffs, while the orange arrows illustrate the desired direction for optimization. The molecular structure similarity is calculated using the Tanimoto similarity metric. Source data is provided as a Source Data file.

## Section: Results › Optimization results of multi-objective tasks

In this subsection, we evaluate the impact of various fitness function designs on the performance of molecule generation for multi-objective tasks. These designs included uncertainty-agnostic methods such as the WS (Eq. 4), NMD (Eq. 6), and the hybrid approach NMD-WS (Eq. 7), as well as the uncertainty-aware PIO method (Eq. 5), which calculates the product of single-objective probabilities where each indicator exceeds its corresponding cutoff. A molecule was considered a hit in multi-objective tasks if it met all specified property cutoffs.

As detailed in Table 3, the PIO approach emerged as the most effective in identifying molecules that satisfied criteria for multi-objective criteria, achieving the highest hit rates for most tasks. Among the uncertainty-agnostic methods, no single approach demonstrated consistent superiority across all tasks. The NMD method showed higher success rates in generating viable molecules for organic emitter designs and the fexofenadine MPO task, while the hybrid NMD-WS method outperformed other uncertainty-agnostic approaches in the remaining multi-objective tasks. In contrast, the WS method consistently struggled, failing to identify molecules that met all required thresholds in any multi-objective task.

A primary challenge in multi-objective tasks, as opposed to single-objective tasks, lies in balancing the contributions of different properties. For instance, in the organic emitter design task, there is a moderate positive correlation between the singlet-triplet gap and oscillator strength (Supplementary Fig. S24), complicating the task, which demands minimizing the singlet-triplet gap while maximizing oscillator strength, thereby creating conflicting optimization directions. This complexity was exacerbated by the disproportionate emphasis on oscillator strength, whose unbounded maximum value could lead the WS method to overly prioritize this trait, neglecting the other (Fig. 6). Similar challenges were observed in the fexofenadine and ranolazine MPO tasks, which involve maximizing similarity to target molecules while optimizing octanol-water partition coefficient (logP) and topological polar surface area (TPSA). Here, the WS method tended to prioritize logP and TPSA optimization at the expense of similarity scores (Fig. 6). This observation aligns with previous research85, emphasizing the challenge of balancing each target’s contribution in the fitness function to prevent bias in multi-objective optimization scenarios. Methods such as NMD and NMD-WS, which incorporate cutoff values into fitness functions, better address this balancing challenge. However, these uncertainty-agnostic methods can still lead to over-optimization in regions beyond the model’s predictive range, potentially resulting in discrepancies between predicted and actual outcomes. Consequently, the PIO method generally demonstrates a higher hit rate by incorporating uncertainty information and thus achieving a better balance across all targets.

Despite the overall success of the PIO method, one task presented challenges for all optimizers: the median molecules 2 task, which aimed to find molecules similar to both camphor and menthol. In this case, none of the optimization methods succeeded in identifying molecules with similarity scores exceeding the cutoff of 0.2. This difficulty is likely due to the low similarity scores in the original dataset, where the majority of scores fall below 0.1 for these target molecules (Supplementary Figs. S17 and S18). This task proved more challenging compared to the median molecules 1 task, where similarity scores with the target molecules (tadalafil and sildenafil) in the original data generally ranged between 0.1 and 0.2, closer to the target value of 0.2 (Supplementary Figs. S15 and S16).

Multi-objective optimization problems are prevalent in fields such as chemical, drug, and material design, where property cutoffs are often required to meet specific commercial objectives. The PIO method achieves the highest hit rates across most multi-objective tasks by integrating uncertainty information and balancing optimization across all targets. In the PIO fitness function (Eq. 5), any molecule deviating significantly from a target threshold receives a lower overall score, guiding the optimization process to consider all objectives equally. When certain objectives are of lower priority, cutoff values for these properties can be relaxed to minimum acceptable levels, reducing their impact on the overall fitness score as long as the values remain within acceptable ranges. Conversely, if a property approaches its minimum acceptable threshold, it appropriately impacts the fitness score, signaling the need for further optimization in that direction.

Comparison of top-k hit rates for multi-objective optimization results across various methods

Each subplot displays molecules generated by the methods: a weighted sum (WS), b normalized Manhattan distance (NMD), c hybrid approach (NMD-WS), and d probabilistic improvement optimization (PIO), organized into six sections arranged from left to right, corresponding to the design tasks for organic emitters, reaction substrates, median molecules 1, median molecules 2, fexofenadine multi-property optimization (MPO), and ranolazine MPO. Blue lines represent molecules that failed to meet all established cutoffs, while orange lines signify those that met all criteria. Black dotted lines across the plots denote the cutoffs. Orange arrows indicate the desired direction for optimization. The molecular structure similarity is calculated using the Tanimoto similarity metric. Abs. diff. of VEE absolute difference of vertical excitation energy, R2 (coefficient of determination) logP octanol-water partition coefficient, TPSA topological polar surface area. Source data is provided as a Source Data file.

## Section: Discussions

This study addresses a central challenge in molecular design: optimizing across expansive chemical spaces, where maintaining predictive accuracy is difficult, especially under domain shifts. The PIO method introduced here integrates UQ within molecular optimization frameworks, combining D-MPNNs with GAs to enhance reliability in exploring broad chemical spaces. Our systematic analysis evaluates the strengths and limitations of PIO in comparison to another UQ-integrated method, EI, providing insights into each method’s ability to adapt to domain shifts and effectively guide exploration. Previous research has indicated that in virtual screening settings, uncertainty-agnostic acquisition functions can exhibit surprisingly equivalent or even superior performance compared to uncertainty-aware active learning approaches39,86, suggesting that purely exploitative methods can be highly efficient in the well-defined chemical library. In contrast, our experimental setup explores an open-ended chemical space and continuously updates the optimization trajectory using fitness values. Under these conditions, PIO outperforms uncertainty-agnostic methods in most instances, whereas the EI approach proves less effective.

Benchmarking results on the Tartarus and GuacaMol platforms indicate that PIO generally improves optimization success compared to traditional uncertainty-agnostic methods. In single-objective tasks, PIO balances the search between well-understood regions and less-explored areas, reducing the risk of selecting candidates where predictions may be unreliable. This approach contrasts with EI, which often focuses on high-variance areas, leading to inconsistent performance. However, it is important to note that PIO’s performance may diminish in tasks where the required properties differ significantly from those represented in the available data. This highlights an area for further methodological improvement.

In multi-objective optimization scenarios, PIO consistently proves advantageous, balancing competing objectives more effectively than weighted scalarization methods, which can skew optimization toward particular properties at the expense of others. By incorporating UQ directly into the fitness function, PIO supports a more balanced approach, generally achieving higher hit rates across multiple objectives. This is particularly relevant in CAMD, where real-world applications often require that multiple property thresholds be met concurrently. The ability of PIO to adapt to varying objectives without overemphasizing any single goal enhances its practical utility in discovering compounds suitable for complex applications.

This study’s comparative analysis of UQ-integrated methods also reveals the critical role of UQ calibration in determining optimization outcomes. Our results show that robust UQ calibration is fundamental to the success of UQ-driven methods. When UQ calibration is poor, PIO’s advantages are reduced, underscoring the need for more accurate and robust UQ techniques in molecular optimization. This finding suggests a direction for future research, where advancements in UQ methodologies, such as those that dynamically adapt to domain shifts, could further enhance the reliability of PIO and similar approaches in broad chemical spaces. In conclusion, this research provides valuable insights into the role of UQ in optimizing molecular design across diverse chemical spaces, demonstrating that the integration of UQ can mitigate some of the limitations posed by domain shifts. The PIO method presents a promising pathway for exploring large chemical spaces with enhanced reliability, paving the way for uncertainty-informed optimization strategies in CAMD.

## Section: Methods › Surrogate models and uncertainty quantification

The choice of surrogate method is crucial in molecular design, as it directly impacts predictive accuracy and computational efficiency. For this study, we selected D-MPNN, a type of GNN architecture, due to its scalability, computational efficiency, and established performance in predicting both mean properties and associated uncertainties in molecular datasets. Although Bayesian inference-based87 methods offer theoretical advantages, their adoption in molecular property prediction has been limited by challenges such as computational costs, intractability in deep neural networks, and complex implementation requirements41. This has restricted their scalability in large datasets, which is a key requirement for molecular design. To assess the effectiveness of molecular design strategies, we utilized the D-MPNN model, as implemented in Chemprop50, which facilitates the automatic extraction and learning of significant structural features of molecules by leveraging atom and bond information. It updates hidden atom states based on molecular connectivity, ultimately deriving a molecular fingerprint from the summation or averaging of all hidden atomic vectors88. This fingerprint is then utilized as input for subsequent feed-forward neural networks. The D-MPNN model has demonstrated robust performance in various studies focused on the prediction of chemical properties89–91.

Various methods have been proposed to quantify uncertainty, such as Bayesian neural networks92, Monte Carlo dropout93, ensemble learning94, MVE71, and evidential learning72,95. Chemprop also incorporates techniques to quantify uncertainty from various sources, categorizing it into aleatoric and epistemic types96. Aleatoric uncertainty, arising from inherent data randomness due to experimental or computational errors, poses challenges for mitigation as it requires enhancements in data accuracy. Conversely, epistemic uncertainty, stemming from model ignorance, can be addressed by enriching the training dataset or improving molecular feature encoding.

One of the UQ methods implemented in Chemprop is the combination of deep ensemble and MVE71. The deep ensemble method estimates epistemic uncertainty, σe2, by training multiple models and evaluating the variance among their predictions94. Specifically, for M models within Chemprop, with each model’s prediction denoted as y^i, the final prediction y~ is the average of these individual predictions, and the epistemic uncertainty is calculated as:

In this study, we prepared ten models with different initialization seeds to form the deep ensemble. On the other hand, MVE is used to calculate aleatoric uncertainty, σa2, by introducing an additional output neuron that predicts the data-dependent uncertainty, ensuring positivity via the softplus activation. In MVE, the residuals between the predicted value and the reference value are assumed to follow a Gaussian distribution with mean 0 and variance σa2. This assumption justifies the use of the negative log likelihood (NLL) of a Gaussian distribution as the loss function:

where y\inR is the reference property value. When using the ensemble approach, the aleatoric uncertainties of each model are averaged to derive a composite aleatoric uncertainty value, with each model trained using the NLL as the loss function44.

Additionally, evidential learning, another UQ method in Chemprop, avoids the need for multiple model training by directly predicting the parameters of an evidential distribution72. This approach involves imposing a prior Gaussian distribution on the unknown mean μ~Nγ,σ2v and an inverse-Gamma prior on the unknown variance σ2~Γ−1α,β. The joint posterior distribution pμ,σ2=pμσ2pσ2 takes the form of Normal Inverse-Gamma (NIG) distribution:

where Γ⋅ represents the gamma function, and the NIG parameters γ\inR, v>0, α>1, β>0 determine the mean (Eμ=γ) and uncertainty associated with the likelihood function. In Chemprop, four neuron outputs are used to predict the NIG parameters. The softplus activation function is applied to v, α and β, ensuring their outputs are always greater than zero. The aleatoric uncertainty and epistemic uncertainty can be separately derived by:

Ultimately, both deep ensemble with MVE and evidential learning can estimate total uncertainties by combining aleatoric and epistemic uncertainties: σa2+σe2=σtotal241. The PIO and EI algorithm for molecular design then both use total uncertainty to calculate the probability that a molecule’s properties will meet the specified cutoff.

## Section: Methods › Genetic algorithm for molecular optimization

In this study, we employed the GA for molecular optimization. GA is a population-based metaheuristic designed to iteratively refine a pool of candidate solutions, aiming to discover the optimal configuration for complex problems characterized by large search spaces97. Our method utilizes an advanced version of GA, known as Janus98, which specifically manipulates SELFIES99 representations of molecular structures. In contrast to traditional SMILES100 representations, which are limited by stringent syntax rules101, SELFIES ensures that any textual modifications maintain chemical validity, thus preserving the structural integrity of molecules even after random modifications. For further insights into the operational principles and efficiency of the Janus algorithm, readers are encouraged to refer to the foundational work by Nigam et al.98. Within our experiments, all hyperparameters were set according to the default specifications of the Janus package unless otherwise noted.

## Section: Methods › Computational details

The data volumes used to develop the D-MPNN model for each prediction task are summarized in Table 1. For the Tartarus dataset, each of the three design tasks was divided into training, validation, and testing subsets using an 8:1:1 random split. Within each task, a multi-task learning strategy was employed, enabling the model to predict all designated targets simultaneously for the given dataset. In the case of GuacaMol, all design tasks utilized the same training, validation, and testing subsets, consisting of 10,000, 2000, and 10,000 data points, respectively. These subsets were randomly downsampled from the platform’s original dataset. The distribution of molecular properties for each dataset is illustrated in Supplementary Figs. S4–S22.

In this study, we systematically examine the performance of each fitness function formulation for single (Eqs. 1–3) and multi-objective (Eqs. 4–7) optimization tasks in molecular design. Each design task incorporates a penalty term Pm to ensure that the molecules adhere to specific structural constraints required for each task. The specific definitions of these penalty terms can be found in Supplementary Tables S1–S4, and closely align with the original definitions used in the Tartarus and GuacaMol platforms. In the EI method, σm is capped at 100 to avoid the situation where a very large uncertainty value could make the EI fitness value infinite. For the median molecules tasks in the GuacaMol dataset, the objective is to identify molecules with high similarity scores to two target molecules simultaneously. Because similarity scores range from 0 to 1 and there is minimal variation across the training dataset, no additional weighting was applied between indicators in the WS, NMD, and NMD-WS methods for these tasks. Specific thresholds for each design task are listed in Supplementary Table S5.

For each molecular optimization experiment, we initiated with a pool of the top 10,000 molecules from the datasets, selected based on their performance under DOM or WS fitness functions (Eqs. 1 and 4). This pool underwent 15 independent optimization runs using the GA and the D-MPNN surrogate model, with hyperparameters detailed in the Supplementary Table S6. Each optimization run was structured to update the candidate pool across 10 iterations, introducing 500 new molecules per iteration through mutation and crossover processes. The final candidate molecules from these runs were then amalgamated to minimize variability inherent in the stochastic nature of the GA102. The consolidated list of molecules was subsequently ranked based on their fitness scores.

This procedure was carried out for each fitness function formulation. The top-performing molecules, derived using each fitness function, were then subjected to validation simulations within the Tartarus or GuacaMol frameworks to verify their actual properties. Our primary metric for evaluation was the hit rate of these molecules, particularly their ability to exceed the predefined threshold values. This analysis provides key insights into the optimization strategies that best improve success rates in generating molecules meeting targeted criteria.

## Section: Methods › Reporting summary

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article.

## Section: Supplementary information

Supplementary Information

Reporting Summary

Transparent Peer Review file

## Section: Source data

Source Data

## Section: Acknowledgements

We are grateful to the National Center for High-performance Computing (NCHC) and the Computer and Information Networking Center at NTU for the support of computing facilities. L.Y.C. is supported by the Graduate Students Study Abroad Program (113-2917-I-002-018) sponsored by National Science and Technology Council in Taiwan. Y.P.L. is supported by Taiwan NSTC (113-2628-E-002-017-MY3 and 113-2622-8-002-015-SB) and the Higher Education Sprout Project by the Ministry of Education in Taiwan (114L7763). During the preparation of this work, the authors used ChatGPT to correct grammatical mistakes and enhance the fluency of the manuscript. After using this tool, the authors reviewed and edited the content as needed and take full responsibility for the content of the publication.

## Section: Author contributions

L.Y.C. designed the methodology, performed the formal analysis, and wrote the initial draft of the manuscript. Y.P.L. acquired funding, supervised the project, and reviewed and edited the manuscript.

## Section: Peer review › Peer review information

Nature Communications thanks the anonymous reviewer(s) for their contribution to the peer review of this work. A peer review file is available.

## Section: Data availability

The datasets for the docking, organic emitter, and reactivity designs within the Tartarus task are available at the Zenodo repository (10.5281/zenodo.8072249)103. The GuacaMol dataset for the drug discovery task is accessible on Figshare (10.6084/m9.figshare.7322252.v2)104. The molecules and their properties generated in this study are provided in the Source Data file. Source data are provided with this paper.

## Section: Code availability

The code described in this manuscript is publicly available at the Zenodo repository (10.5281/zenodo.14729022)105.

## Section: Competing interests

The authors declare no competing interests.

## Section: Supplementary information

The online version contains supplementary material available at 10.1038/s41467-025-58503-0.

## Section: Associated Data

Supplementary Information

Reporting Summary

Transparent Peer Review file

Source Data

## Section: Associated Data › Supplementary Materials

Supplementary Information

Reporting Summary

Transparent Peer Review file

Source Data

## Section: Associated Data › Data Availability Statement

The datasets for the docking, organic emitter, and reactivity designs within the Tartarus task are available at the Zenodo repository (10.5281/zenodo.8072249)103. The GuacaMol dataset for the drug discovery task is accessible on Figshare (10.6084/m9.figshare.7322252.v2)104. The molecules and their properties generated in this study are provided in the Source Data file. Source data are provided with this paper.

The code described in this manuscript is publicly available at the Zenodo repository (10.5281/zenodo.14729022)105.


---

# Use of Biomarkers in Drug Development for Regulatory Purposes

- **Authors:** Robert N Schuck, Vanitha Sekar
- **Issuer:** Clinical and translational science
- **Type:** Scientific article
- **Published:** 2025-10-01
- **Language:** en
- **DOI:** 10.1111/cts.70377
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41035359/
- **Licence:** CC-BY-NC

## Section: Abstract

ABSTRACTAppropriately validated biomarkers are important tools that can benefit drug development and regulatory assessments. For drug development purposes, biomarker development involves identifying a drug development need and context of use (COU) for the biomarker, analytically validating assays, clinically validating the biomarker for the COU, and determining if the biomarker provides benefits over current methods. This perspective provides information on determining a biomarker's COU, fit‐for‐purpose validation, and regulatory acceptance of biomarkers for drug development.Keywords: biomarkers, drug development, regulatory

## Section: Biomarker Use

Biomarkers are an integral component of both the practice of medicine and the development and approval of new therapies. Whether evaluating a patient's risk for cardiovascular disease in a doctor's office or trying to determine if an investigational drug causes kidney damage, biomarkers are a key part of the assessment. Historically, new biomarkers have been discovered and evaluated in nonclinical experiments, epidemiological studies, and clinical trials. As their role in a given disease becomes better understood through additional studies or through clinical use by early adopters, they slowly become integrated into clinical care. Eventually, clinical practice guidelines written by professional societies may incorporate biomarkers in the assessment of patient risk or response to therapy, further expanding their use in clinical practice. In drug development, biomarkers often play an important role in the selection of the patient population to be studied, dose selection, and safety and efficacy assessments. As such, biomarkers are often critical to the Food and Drug Administration's (FDA's) determination of which patient populations benefit from the drug, how the drug is used, and can contribute to the benefit–risk assessment. Therefore, it is important to have a thorough understanding of the biomarker and robust data supporting its use for a specific assessment during drug development.

## Section: Biomarker Category and Context of Use

FDA defines a biomarker's COU as a concise description of the biomarker's specified use in drug development; it includes the BEST biomarker category and the biomarker's intended use in drug development. The BEST (Biomarkers, EndpointS, and other Tools) Resource is an online glossary that was created by an FDA‐NIH joint working group and defines multiple categories of biomarkers, such as diagnostic, monitoring, predictive, response, and safety, among others [1]. As described in Table 1, FDA categorizes biomarkers into several types, including susceptibility/risk, diagnostic, monitoring, prognostic, predictive, pharmacodynamic/response, and safety biomarkers (Table 1). An individual biomarker might fall into more than one category, depending on how it is being used. For example, Hemoglobin A1c is used to identify patients with diabetes (diagnostic biomarker) and to monitor long‐term glycemic control (response biomarker) in individuals with diabetes.

There are many challenges in drug development that can be addressed, at least in part, by use of an appropriately validated biomarker. Key examples include safety biomarkers that detect organ injury earlier than traditional clinical signs or symptoms, potentially before significant irreversible damage occurs, pharmacodynamic response biomarkers to aid in dose selection, response biomarkers used as reasonably likely or validated surrogate endpoints, and predictive or prognostic biomarkers for patient selection in clinical trials. The development of a biomarker for a COU should carefully consider (1) whether the COU represents an important drug development challenge, (2) whether the biomarker has the potential to improve upon the standard assessments used in drug development, and (3) what studies or data are needed to validate the biomarker for the proposed COU. Different drug development issues may require different categories of biomarkers to address the need, and it is important to consider not only the type of biomarker that is needed, but the feasibility of measurement within a drug development program, the frequency that the assessment is needed, whether or not the biomarker will need to be assessed in routine clinical care if the drug is approved, and other practical considerations.

BEST (Biomarkers, EndpointS, and other Tools) classification.

## Section: Fit‐For‐Purpose Biomarker Validation

The validation of the biomarkers is a complex process and the level of evidence needed to support the use of a biomarker depends on the COU and the purpose for which a biomarker is applied [2]. This principle underscores the importance of a fit‐for‐purpose approach to biomarker validation. Different biomarker types require varying validation approaches, focusing on specific evidence characteristics based on their intended COU.

Validation of susceptibility/risk biomarkers requires epidemiological evidence and may also be supported by genetic evidence, biological plausibility, and establishing causality. Depending on the drug development or clinical use, diagnostic biomarkers may prioritize sensitivity and/or specificity and require proof of accurate disease identification across diverse populations. Prognostic biomarkers require robust clinical data showing consistent correlation with disease outcomes, while monitoring biomarkers require validation of their ability to reflect disease status changes over time. Predictive biomarkers prioritize sensitivity, specificity, and often causality, with emphasis on a mechanistic link to treatment response. Pharmacodynamic/response biomarkers also emphasize biological plausibility, requiring evidence of a direct relationship between drug action and biomarker changes. Lastly, safety biomarkers need to demonstrate consistent indication of potential adverse effects across different populations and drug classes. This tailored approach ensures rigorous assessment of each biomarker type according to its COU in drug development, specific role within a drug development program, or use in clinical decision‐making [2]. For example, the same biomarker may require less extensive validation for use as a pharmacodynamic biomarker to help identify a safe and effective dosing regimen for a treatment, but more extensive mechanistic and/or epidemiologic data to be used as a reasonably likely surrogate endpoint to support accelerated approval, and additional clinical validation to be used as a validated surrogate endpoint to support traditional approval [1, 3].

Analytical validation is a critical component of the biomarker validation process. It involves assessing the performance characteristics of the biomarker measurement tool; the appropriate performance characteristics are dependent on the method of detection and the analyte of interest, and may include accuracy, precision, analytical sensitivity, analytical specificity, reportable range, and reference range [4, 5]. Clinical validation, on the other hand, demonstrates that the biomarker accurately identifies or predicts the clinical outcome of interest. This may involve assessing sensitivity and specificity, determining positive and negative predictive values, and evaluating the biomarker's performance in the intended population. FDA also considers the potential benefits and risks of using a biomarker. This benefit/risk assessment includes the consequences of false positive or false negative results, the availability of alternative tools and evaluating the impact on the patient population that the biomarker is being developed for.

## Section: Regulatory Acceptance of Biomarkers

The COU and supportive evidence, including fit‐for‐purpose validation, are important considerations in the regulatory acceptance of a biomarker (Figure 1). There are several pathways for regulatory acceptance of biomarkers:

The ideal pathway may depend on several factors. Engaging with FDA through the IND application process may be an efficient pathway for specific drug development programs in many cases, including for well‐established biomarkers with data available supporting their use within the drug development program. The BQP offers a pathway for broader acceptance of biomarkers across multiple drug development programs. While the BQP may take longer and require more supporting evidence, once qualified, a biomarker can be used by any drug developer in their drug development program without requiring FDA re‐review of its suitability, provided it is used within the specified COU. The biomarker qualification process promotes consistency across the industry, reduces duplication of efforts, and helps streamline the development of safe and effective therapies. It's important to note that in this context, we are discussing regulatory acceptance or qualification for use in drug development, not the approval process for biomarker tests or for the approval of the drug's marketing application.

In conclusion, fit‐for‐purpose validation of biomarkers depends on the biomarker type and its intended COU. FDA emphasizes the importance of early engagement with drug developers and biomarker developers to discuss biomarker use, validation strategies, and regulatory acceptance. By considering the biomarker type, COU, analytical and clinical validation, and benefit/risk assessment, FDA aims to ensure that biomarkers contribute meaningfully to drug development and patient care.

The drug development need informs the selection of candidate biomarkers and the COU. The COU subsequently drives the extent of evidence needed for validation, potential qualification under the BQP, and ultimately regulatory acceptance of using the biomarker in drug development. Note that the regulatory engagement pathways are independent, but do not necessarily occur in isolation; all are data driven and involve regulatory assessment and outcomes based on the available data.

## Section: Disclosure

Disclaimer: This article reflects the views of the authors and should not be construed to represent FDA's views or policies.

## Section: Conflicts of Interest

The authors declare no conflicts of interest.

## Section: Acknowledgments

The authors would like to acknowledge Dr. Michael Pacanowski and Dr. Jeff Siegel for their helpful comments on the manuscript.

## Section: Text

Schuck R. N. and Sekar V., “Use of Biomarkers in Drug Development for Regulatory Purposes,” Clinical and Translational Science 18, no. 10 (2025): e70377, 10.1111/cts.70377.


---

# Using Large Language Models to Detect and Understand Drug Discontinuation Events in Web-Based Forums: Development and Validation Study

- **Authors:** William Trevena, Xiang Zhong, Michelle Alvarado, Alexander Semenov, Alp Oktay, Devin Devlin, Aarya Yogesh Gohil, Sai Harsha Chittimouju
- **Issuer:** Journal of medical Internet research
- **Type:** Scientific article
- **Published:** 2025-01-30
- **Language:** en
- **DOI:** 10.2196/54601
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39883487/
- **Licence:** CC-BY

## Section: Abstract

BackgroundThe implementation of large language models (LLMs), such as BART (Bidirectional and Auto-Regressive Transformers) and GPT-4, has revolutionized the extraction of insights from unstructured text. These advancements have expanded into health care, allowing analysis of social media for public health insights. However, the detection of drug discontinuation events (DDEs) remains underexplored. Identifying DDEs is crucial for understanding medication adherence and patient outcomes.ObjectiveThe aim of this study is to provide a flexible framework for investigating various clinical research questions in data-sparse environments. We provide an example of the utility of this framework by identifying DDEs and their root causes in an open-source web-based forum, MedHelp, and by releasing the first open-source DDE datasets to aid further research in this domain.MethodsWe used several LLMs, including GPT-4 Turbo, GPT-4o, DeBERTa (Decoding-Enhanced Bidirectional Encoder Representations from Transformer with Disentangled Attention), and BART, among others, to detect and determine the root causes of DDEs in user comments posted on MedHelp. Our study design included the use of zero-shot classification, which allows these models to make predictions without task-specific training. We split user comments into sentences and applied different classification strategies to assess the performance of these models in identifying DDEs and their root causes.ResultsAmong the selected models, GPT-4o performed the best at determining the root causes of DDEs, predicting only 12.9% of root causes incorrectly (hamming loss). Among the open-source models tested, BART demonstrated the best performance in detecting DDEs, achieving an F1-score of 0.86, a false positive rate of 2.8%, and a false negative rate of 6.5%, all without any fine-tuning. The dataset included 10.7% (107/1000) DDEs, emphasizing the models’ robustness in an imbalanced data context.ConclusionsThis study demonstrated the effectiveness of open- and closed-source LLMs, such as GPT-4o and BART, for detecting DDEs and their root causes from publicly accessible data through zero-shot classification. The robust and scalable framework we propose can aid researchers in addressing data-sparse clinical research questions. The launch of open-access DDE datasets has the potential to stimulate further research and novel discoveries in this field.

## Section: Introduction

The development of the transformer model [1] has significantly advanced natural language processing (NLP), a key area of artificial intelligence (AI). These models, commonly referred to as large language models (LLMs), often contain billions or trillions of parameters and have greatly improved our ability to extract meaningful insights from unstructured data [2], achieving state-of-the-art results in various NLP tasks since the introduction of bidirectional encoder representations from transformers [3]. LLMs have excelled in tasks, such as translation, answering of questions, summarization, sentiment analysis, language generation, and named entity recognition. They are used in diverse fields, including analyzing corporate filings for investment decisions [4], assessing online reviews [5], and performing sentiment analysis of tweets [6].

Recently, advanced LLMs such as DeBERTa (Decoding-Enhanced Bidirectional Encoder Representations from Transformers with Disentangled Attention) [7] and OpenAI’s GPT-4 [8] have demonstrated substantial performance improvements. These enhancements include improvements in model architecture, such as DeBERTa’s disentangled attention mechanism and GPT-4’s increased model size and training data, which enhance their prediction accuracy and their capacity to handle complex language understanding tasks. These advancements have opened new possibilities for health care applications of NLP, such as analyzing social media and online forums to assess trust and confidence toward vaccine use [9], adverse drug reactions [10,11], and depression [12], among others [13-16]. However, many potential applications of NLP in health care remain underexplored.

One critical issue is early drug discontinuation and nonadherence to prescribed medication, which negatively affects patient outcomes and increases health care costs [17]. The reasons behind early medication discontinuation are not well understood [18,19], and detecting drug discontinuation events (DDEs) from clinical narratives and social media data is underexplored.

Some studies have explored medication discontinuation using data from social media and NLP techniques. Golder et al [20] conducted a mixed methods study analyzing patient-reported reasons for switching or discontinuing statin therapy using social media data from WebMD. Their work focused specifically on statins and relied on manual annotation for classifying DDEs and their root causes. Similarly, van Buchem et al [21] developed and validated the AI patient-reported experience measure (AI-PREM) by analyzing patient experiences using NLP. Their study primarily used sentiment analysis to gauge patient experiences but did not focus on detecting specific events such as DDEs.

Another study by Tsai et al [22] used NLP and network analysis to examine patients withdrawing from life-sustaining treatments using electronic health records from 119 patients in Taiwan. Their approach involved generating document-term matrices and analyzing word frequencies to identify patterns. However, they did not use pretrained LLMs, and their study was limited to a small dataset.

While these studies and others [23-26] contribute valuable insights into patient experiences and reasons for medication discontinuation, they have limitations such as focusing on specific medications, relying on manual annotation, or not leveraging advanced LLMs for broader applicability. To the best of our knowledge, no prior studies have systematically analyzed the root causes of medication discontinuation using state-of-the-art LLMs such as OpenAI’s GPT-4o, especially in a zero-shot classification setting applied to large-scale, unstructured patient-generated data from web-based forums.

Historically in many NLP applications, the models needed to be fine-tuned or adjusted for each specific task. However, state-of-the-art LLMs are capable of zero-shot classification, which are especially valuable in settings where data are scarce, as they do not require modifications or fine-tuning on task-specific data. This feature is particularly beneficial in the medical field, where access to data is often limited due to patient confidentiality concerns. Motivated by challenges associated with limited data availability in health care research, the primary aim of this study is to develop a versatile framework for addressing clinical research questions in data-sparse settings by leveraging pretrained LLMs and zero-shot classification of unstructured data from web-based health forums. The specific objectives of this paper are as follows:

In addition, our work is novel in 4 additional aspects. First, studies in the extant work mainly used electronic health records (EHRs) as the data source [17]. Due to the poor documentation of drug discontinuation events (DDEs) in EHRs [17], it is crucial to understand the causes of discontinuation from the patient’s perspective to improve medication adherence. Traditional EHR data often lack direct patient input, as they are usually filtered through health care providers. Moreover, privacy concerns surrounding patient health data often restrict accessibility to large open-source datasets for health research. Meanwhile, web-based forums such as MedHelp offer unmediated patient perspectives, provide insights not captured in EHRs, and involve a large and diverse population. Identifying the root causes of DDEs from the patient’s viewpoint on the basis of a representative sample can enhance our understanding of patient behavior and the challenges they face.

Second, to the best of our knowledge, this is the first work that compares state-of-the-art text-to-text models with the previous generation of models that receive text as an input and respond with text as an output, such as GPT-4o. Many open-source pretrained large language models (LLMs) fine-tuned for zero-shot classification are available through platforms like Hugging Face [27]. These models can predict whether a given text supports an arbitrary hypothesis without needing additional training for each new task. This means that if a human reader can infer the truth of a hypothesis from the text, the model can make a prediction to do the same [28]. Typically, these models output a probability between 0 and 1, indicating how likely it is that the hypothesis is true based on the given text. To be able to apply these approaches to the problem, we designed a novel framework that leverages these models to identify DDE and the associated root causes.

Third, we demonstrated the effectiveness of LLMs in addressing clinical research questions without extensive training data. This approach overcomes the limitations of previous methods [17] by using transfer learning to tackle data scarcity. Our study shows that LLMs such as bidirectional and auto-regressive transformers (BART) and GPT-4o, with their generalization capabilities, are versatile for new tasks. This novel methodology could revolutionize the way clinical research questions are approached, opening a new paradigm in health informatics research.

Fourth, this paper introduces 2 open-source datasets, the first of their kind: one focused on DDE detection and another on root cause classification of DDEs. By creating and publishing these datasets, we aimed to motivate and facilitate future research efforts toward investigating drug discontinuation. For example, researchers could use these datasets to investigate why patients discontinue specific medications early. By extracting and analyzing comments that describe DDEs, they can identify the root causes and guide future research to address side effects or other factors associated with drug discontinuation.

Overall, this research provides valuable insights into patient behavior and decision-making regarding medication use, highlighting the real-world challenges faced by the patients. These insights can inform health care providers, policy makers, and pharmaceutical companies, helping them to better understand and address barriers to medication adherence.

## Section: Methods

Decision tree for labeling the root causes of drug discontinuation events.

Illustration of how large language models fine-tuned to perform natural language inference can be used to perform zero-shot classification. MNLI: Multi-Genre Natural Language Inference; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

An example illustrating classification strategy 1. DDE: drug discontinuation event; Max: maximum; MNLI: Multi-Genre Natural Language Inference; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

An example illustrating classification strategy 2 when using a model with a large maximum token input length. DDE: drug discontinuation event; Max: maximum; MNLI: Multi-Genre Natural Language Inference; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

An example illustrating classification strategy 2 when using a model with a small maximum token input length. DDE: drug discontinuation event; Max: maximum; MNLI: Multi-Genre Natural Language Inference; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

## Section: Methods › Overview

The effectiveness of research outcomes in NLP relies heavily on the methods and materials used. This section outlines the strategies and resources used in this study, focusing on LLMs. In particular, this study introduces an innovative approach by redefining DDE detection as a natural language inference task. This approach enables LLMs to leverage their existing training to deduce relationships between text elements, achieving the desired outcomes without the need for additional training data or model fine-tuning.

We sourced data from MedHelp [29], a publicly accessible web-based health community where users discuss health experiences and share advice. This section details the methodology used for detecting DDEs from comments posted on MedHelp and analyzes the root causes of these DDEs using LLMs.

## Section: Methods › Data Scraping and Preprocessing

Our dataset was compiled by scraping 759,872 questions and answers from 131 of the 193 communities on MedHelp. Each question or answer has a unique URL, with information corresponding to each being recorded as a separate row in our dataset.

The dataset was then trimmed down by excluding questions and answers that lacked relevant study keywords. These keywords were derived from the International Drug Dictionary dataset [30], reducing our dataset to 183,565 questions and answers.

## Section: Methods › Data Labeling

Decision tree for labeling the root causes of drug discontinuation events.

## Section: Methods › Data Labeling › Overview

To create the first open-source DDE datasets and to assess the accuracy of LLMs at detecting DDEs and identifying their root causes, we used graduate students to label the data obtained from MedHelp. For DDE detection, 1000 comments were labeled, resulting in 893 (89.3%) non-DDE comments and 107 (10.7%) DDE comments. Of the 89 (8.9%) comments that the labelers did not unanimously agree upon, the majority vote was taken as the “ground truth.” Here, the “ground truth” refers to the correct classification for each comment, based on the consensus of the labelers.

For DDE root cause analysis, 1000 (100%) comments suspected of containing DDEs were categorized based on predefined criteria. Multiple root causes can apply to a single DDE and a single comment can express multiple DDEs, allowing multiple root causes to be assigned to one comment. When the labelers disagreed, they discussed the comments to reach a consensus.

## Section: Methods › Data Labeling › Classifying Comments as DDE or Non-DDE

Labelers were asked to categorize each comment into either of the following categories:

The comments were classified as DDE if a specific person’s discontinuation of a recurring medication or treatment could be inferred from it. Medication changes were considered as DDEs while one-time treatments were not. Apart from this, labelers were asked to indicate their level of confidence in their labels by selecting one of the three confidence levels: (1) very confident (2890/3000, 96.33%); (2) somewhat confident (102/3000, 3.4%); and (3) not confident (8/3000, 0.27%). The percentage in parentheses alongside each confidence level indicates the rate at which the confidence level was selected by the labelers.

## Section: Methods › Data Labeling › Classifying the Root Causes of DDEs

After identifying comments containing DDEs, the next step involved categorizing the root causes of these discontinuations. Labelers were provided with detailed guidelines and definitions for each category to ensure consistency and accuracy (Textbox 1).

Labelers were instructed to apply these categories to each comment identified as containing a DDE. They could assign multiple categories to a single comment if it mentioned >1 reason for discontinuation. The comprehensive guidelines, including examples and the decision tree shown in Figure 1, helped labelers accurately and consistently classify the root causes of DDEs. The aim was to capture the complex and multifaceted reasons behind medication discontinuation, providing valuable insights for further analysis.

Decision tree for labeling the root causes of drug discontinuation events.

## Section: Methods › Models

In this study, we used the following models from Hugging Face (Hugging Face, Inc)—all of which are LLMs fine-tuned for zero-shot classification—to detect DDEs in comments posted on web-based forums: nli-deberta-base [31]; bart-large-mnli [32]; roberta-large-mnli [33]; distilbert-base-uncased-mnli [34]; nli-distilroberta-base [35].

In addition, we used OpenAI’s GPT-3.5 Turbo and GPT-4 models [36]. These LLMs have been trained on a wide range of internet text and can generate humanlike text, making them useful for our research. GPT-3.5 Turbo is smaller and less costly than GPT-4 because of its fewer parameters [37]. As illustrated in Figure 2, these models can be used to analyze a premise from a web-based forum post (eg, a post from MedHelp) alongside a hypothesis (eg, “person stopped taking medication”) and output a probability, such as 0.8, for whether the premise entails the hypothesis. This approach allows us to identify potential discontinuation events in a zero-shot manner without requiring additional training data.

Illustration of how large language models fine-tuned to perform natural language inference can be used to perform zero-shot classification. MNLI: Multi-Genre Natural Language Inference; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

## Section: Methods › Data Classification Procedure Used to Detect DDEs

Detecting DDEs can be framed as a binary classification task, where the goal is to determine whether a text sequence contains a DDE or not. For example, the statement “patient stopped Lipitor because of cost” would be classified as containing a DDE. Each model, including GPT-3.5 Turbo and GPT-4, performed zero-shot classification as described in the classification strategies later. For models from the Hugging Face library, comments from MedHelp were treated as premises with the hypothesis being the following: “Person stopped taking medication.” Note that the results presented in this paper and the performance of the proposed framework are sensitive to the hypothesis used, and using a different hypothesis could result in different results.

For GPT-3.5 Turbo and GPT-4, the models were prompted to generate a response to a query using the comment as context. The model’s output was processed to derive a probability of entailment, which was used for classification. The evaluation setting for the GPT models varied with the classification strategy used and was influenced by the model version. It is important to note that the DDE detection experiments were performed before the release of GPT-4 Turbo and the release of the “set seed” and structured JavaScript Object Notation response features by OpenAI. As a result, carefully structured prompts were needed to obtain parseable responses from the GPT models for the task of DDE detection. These prompts and the complete code used in this work are available on GitHub [38]. The subsequent sections detail the procedures used to classify comments into the 2 categories, with practical examples of these classification strategies shown as figures.

An example illustrating classification strategy 1. DDE: drug discontinuation event; Max: maximum; MNLI: Multi-Genre Natural Language Inference; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

An example illustrating classification strategy 2 when using a model with a large maximum token input length. DDE: drug discontinuation event; Max: maximum; MNLI: Multi-Genre Natural Language Inference; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

An example illustrating classification strategy 2 when using a model with a small maximum token input length. DDE: drug discontinuation event; Max: maximum; MNLI: Multi-Genre Natural Language Inference; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

## Section: Methods › Data Classification Procedure Used to Detect DDEs › Step 1: Split Each Comment Into Sentences and Tokenize

The models used for DDE detection, including GPT-3.5 Turbo and GPT-4, have a maximum token input length. This means each model can only process text that, when tokenized, is within its maximum token limit. Given that questions and answers on MedHelp can exceed these limits, we split longer comments into smaller chunks for classification. A comment was classified as discussing a DDE if any of its segments were classified as such. To handle the prevalence of typos and missing punctuation, we used the spaCy Python library’s Sentencizer method [39] to segment each question and answer into sentences. Despite some inaccuracies due to informal language, typos, or incorrect punctuation, we referred to the output of the Sentencizer as the consecutive “sentences” forming each question or answer from MedHelp.

## Section: Methods › Data Classification Procedure Used to Detect DDEs › Step 2: Apply a Classification Strategy

Each comment was processed using 3 distinct classification strategies: classification strategy 1 (CS1, see Figure 3 and Textbox 2), classification strategy 2 (CS2; see Figures 4 and 5 and Textbox 3), and classification strategy 3 (CS3; see Figure 5 and Textbox 4).

In CS1 (Figure 3; Textbox 2), each sentence from the text is treated as a premise and passed into the model individually. The maximum probability (ie, model output) returned for any premise is identified. If this maximum probability is above a user-defined cutoff level, the original post is classified as containing a DDE. In the example shown in Figure 3, the post is classified as containing a DDE because the maximum model output exceeds the user-defined cutoff level (95%).

In CS2 (Figures 4 and 5; Textbox 3), consecutive sentences are concatenated and passed into the model as single premises. The maximum model output for any premise is compared to a user-defined cutoff value. In the example shown in Figure 4, the post is classified as containing a DDE because the maximum probability (99.4%) is higher than the cutoff level (95%).

In Figure 5, an example shows a scenario where the total number of tokens in the original post exceeds the maximum input length that the model can accept. Here, sequential sentences are grouped to ensure no group exceeds the model’s maximum token limit (Textbox 4).

An example illustrating classification strategy 1. DDE: drug discontinuation event; Max: maximum; MNLI: Multi-Genre Natural Language Inference; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

An example illustrating classification strategy 2 when using a model with a large maximum token input length. DDE: drug discontinuation event; Max: maximum; MNLI: Multi-Genre Natural Language Inference; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

An example illustrating classification strategy 2 when using a model with a small maximum token input length. DDE: drug discontinuation event; Max: maximum; MNLI: Multi-Genre Natural Language Inference; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

## Section: Methods › Data Classification Procedure Used to Detect DDEs › Step 3: Compare the “Model Prediction” to a User-Defined “Cutoff” Value

To derive a binary classification for a comment from the set of model outputs for each sentence (CS1) or block of sentences (CS2), we compared the maximum of all the model outputs to a cutoff value. If the maximum model output for any sentence or block of sentences is greater than the cutoff value, the comment is classified as a DDE. Otherwise, it is classified as a non-DDE. Cutoff values were tested from 0.05 to 0.95 in increments of 0.05. Adjusting the cutoff impacts the trade-off between sensitivity and specificity, reflected in the resulting false positive rate (FPR) and false negative rate (FNR) of each classifier. This approach helps identify an optimal cutoff that balances false positives and false negatives. This structured approach ensures a comprehensive analysis and maximizes the accuracy of DDE detection in unstructured web-based forum data.

## Section: Methods › Data Classification Procedure Used to Detect the Root Causes of DDEs

Once DDEs were identified, we proceeded to classify the root causes of these discontinuations. The root cause classification was treated as a multilabel classification task, allowing each comment to be associated with multiple reasons for discontinuation.

## Section: Methods › Data Classification Procedure Used to Detect the Root Causes of DDEs › Applying CS1, CS2, and CS3 to DDE Root Cause Classification

The same classification strategies (ie, CS1, CS2, and CS3) used to detect DDEs were applied to identify the root causes of DDEs.

## Section: Methods › Data Classification Procedure Used to Detect the Root Causes of DDEs › Applying CS1, CS2, and CS3 to DDE Root Cause Classification

Each sentence in a DDE-identified comment was classified individually to determine the root causes. Each sentence was analyzed to see if it fit any of the predefined root cause categories in the Classifying the Root Causes of DDEs section.

If any sentence indicated a root cause, it was considered a relevant cause for the entire comment. The final set of root causes for the comment was derived from the union of causes identified in individual sentences.

## Section: Methods › Data Classification Procedure Used to Detect the Root Causes of DDEs › Applying CS1, CS2, and CS3 to DDE Root Cause Classification

Groups of sentences were classified together to determine the root causes. This method ensured that contextual information was preserved, which is crucial for accurately identifying root causes that may span multiple sentences. Each group of sentences was evaluated against the predefined categories of root causes, and the maximum model output for each group determined the presence of specific root causes.

## Section: Methods › Data Classification Procedure Used to Detect the Root Causes of DDEs › Applying CS1, CS2, and CS3 to DDE Root Cause Classification

The entire text of each DDE-identified comment was passed into the ChatGPT model to classify the root causes. The model was prompted to first summarize the reasons for discontinuation and then was asked to generate a list of applicable root causes from the predefined categories. This approach leveraged the model’s ability to understand the context of the entire comment, providing a comprehensive assessment of the root causes.

## Section: Methods › Data Classification Procedure Used to Detect the Root Causes of DDEs › Comparing Model Predictions to Cutoff Values

For both CS1 and CS2, the maximum model output for each root cause category was compared to a user-defined cutoff value. If the model output exceeded the cutoff, the root cause was assigned to the comment.

The complete set of prompts and hypotheses used for both DDE detection and root cause analysis can be found on our GitHub repository [38]. These details are omitted here for brevity, but they are available on the web and in Multimedia Appendix 1 to ensure transparency and facilitate replication of our methods. Researchers and practitioners can access these resources to better understand the specific inputs used in our classification models and apply similar techniques to their own datasets.

## Section: Methods › Ethical Considerations

This study involves the analysis of user-generated content on MedHelp, a publicly accessible health forum where individuals share personal medical experiences and seek health advice. Given the sensitive nature of the health information discussed, we are committed to protecting user privacy and ensuring ethical handling of all data. While the content on MedHelp is publicly available, users have not explicitly consented to participate in this research. We acknowledged the need to respect users’ implied expectations of privacy, especially given the health-focused context of the discussions. No attempt was made to contact individual users nor were they asked to participate directly in this study. The scraped data have been processed in a way that prevents the association of responses or health conditions with specific users. This study complies with all relevant ethical guidelines for internet-based research, and we did not find it necessary to seek an ethics review board assessment based on the guidelines set by the University of Florida institutional review board.

## Section: Results

The precision-recall curve of each classifier on the task of detecting drug discontinuation events. BART: Bidirectional and Auto-Regressive Transformers; DeBERTa: Decoding-Enhanced Bidirectional Encoder Representations from Transformers with Disentangled Attention; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

The receiver operating characteristic curve of each classifier on the task of detecting drug discontinuation events. BART: Bidirectional and Auto-Regressive Transformers; DeBERTa: Decoding-Enhanced Bidirectional Encoder Representations from Transformers with Disentangled Attention; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

Evaluation metrics for DDEa root cause classification (part 1).

Evaluation metrics for DDEa root cause classification (part 2).

Detailed performance metrics by DDEa root cause for GPT-4 Turbo.

Detailed performance metrics by DDEa root cause for GPT-4o.

Frequency of labels in the dataset.

## Section: Results › Overview

This section presents the results of our experiments on detecting DDEs and identifying their root causes. We evaluated the performance of various LLMs, using different classification strategies. The evaluation included precision-recall (PR) curves, receiver operating characteristic (ROC) curves, and detailed performance metrics for each classifier and strategy combination.

## Section: Results › DDE Detection Task

The effectiveness of the classifiers in detecting DDEs was evaluated using PR and ROC curves. Figures 6 and 7 show the PR and ROC curves for each classifier under each classification strategy, respectively. These figures also include the area under the curve (AUC) for each combination of classifier and strategy. Of all the models and classification strategies, bidirectional and auto-regressive transformers (BART) under CS1 achieved the highest ROC AUC of 0.977 and the highest PR AUC of 0.904. On the other hand, GPT-3.5 Turbo under CS2 had the lowest ROC AUC of 0.611 and the lowest PR AUC of 0.215.

Under CS3, GPT-4 achieved an F1-score of only 0.56, an FPR of 12.9%, an FNR of 18.7%, and an accuracy of 86.5%. GPT-3.5 Turbo performed even more poorly under CS3, achieving an F1-score of only 0.27, an FPR of 5.6%, an FNR of 76.6%, and an accuracy of 86.8%, illustrating the imbalance in the dataset. In comparison, the best-performing classifier at the task of DDE detection was BART under CS1, achieving an F1-score of 0.86, an accuracy of 96.8%, an FPR of 2.8%, and an FNR of 6.5%. A summary of these performance metrics can be found in Tables S1-S9 in Multimedia Appendix 1.

The precision-recall curve of each classifier on the task of detecting drug discontinuation events. BART: Bidirectional and Auto-Regressive Transformers; DeBERTa: Decoding-Enhanced Bidirectional Encoder Representations from Transformers with Disentangled Attention; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

The receiver operating characteristic curve of each classifier on the task of detecting drug discontinuation events. BART: Bidirectional and Auto-Regressive Transformers; DeBERTa: Decoding-Enhanced Bidirectional Encoder Representations from Transformers with Disentangled Attention; RoBERTa: Robustly Optimized Bidirectional Encoder Representations from Transformers Pretraining Approach.

## Section: Results › DDE Root Cause Classification Task

To assess the performance of the classifiers in identifying the root causes of DDEs, we used multiple evaluation metrics, including micro-average ROC AUC, macro-average ROC AUC, weighted-average ROC AUC, micro-average PR AUC, macro-average PR AUC, weighted-average. PR AUC, micro-average F1, macro-average F1, weighted-average F1, hamming loss, Jaccard score, and subset accuracy. The results across all DDE root causes are summarized in Tables 1 and 2.

Tables 3 and 4 show the performance of GPT-4 Turbo and GPT-4o at predicting each individual DDE root cause. Overall, GPT-4o performed the best across the board achieving the highest averaged F1-scores, the lowest hamming loss, and the highest Jaccard score and subset accuracy of all the classifiers. On the other hand, BART and DeBERTa performed very poorly across the board on the task of DDE root cause detection as shown in Tables 1 and 2.

An overview of the frequency of each DDE root cause in our labeled dataset of 1000 comments is provided in Table 5.

The most common DDE root causes in our dataset were personal choices with 670 (67%) occurrences and adverse reactions with 627 (62.7%) occurrences, and the least common was treatment success with 96 (9.6%) occurrences. In addition, only 10% (100/1000) of the comments were labeled as non-DDE by labelers, suggesting the accuracy performance is consistent with the experiments performed regarding DDE detection in a smaller labeled dataset.

Evaluation metrics for DDEa root cause classification (part 1).

Evaluation metrics for DDEa root cause classification (part 2).

Detailed performance metrics by DDEa root cause for GPT-4 Turbo.

Detailed performance metrics by DDEa root cause for GPT-4o.

Frequency of labels in the dataset.

## Section: Discussion › DDE Detection › Overview

The results from the PR and ROC curves highlight significant differences in the performance of the models at detecting DDEs using the 3 different classification strategies: CS1, CS2, and CS3. These metrics are essential for understanding the trade-offs between sensitivity and specificity in identifying DDEs, which is vital in clinical settings where missing a DDE can have serious implications.

The PR curves (Figure 6) demonstrate the effectiveness of each classifier in handling the imbalanced nature of the dataset. BART under CS1 achieved the highest PR AUC, indicating its superior ability to maintain high precision without sacrificing recall. This performance suggests that BART is particularly adept at identifying DDEs in a dataset where DDEs are relatively rare, representing only 107 (10.7%) of the 1000 comments we labeled. In contrast, GPT-3.5 Turbo under CS2 had the lowest F1-score of only 0.22, showing significant challenges in balancing precision and recall. These results highlight the limitations of some models when applied with the classification strategies we developed and to our imbalanced data set. However, these results highly depend on the prompts used with the models, and better results may be achieved by using different prompts in conjunction with the proposed classification strategies. Further research into this area is needed to better understand this phenomenon.

Similarly, the ROC curves (Figure 7) illustrate the classifiers’ ability to distinguish between DDE and non-DDE cases across various thresholds. The area under the ROC curve provides a measure of the overall discriminative power of the models. BART’s high area under the ROC curve under CS1 indicates its robustness in differentiating between the 2 classes, even at different decision thresholds. This robustness is crucial in clinical applications where both high sensitivity and specificity are required to minimize false negatives and false positives.

## Section: Discussion › DDE Detection › Classification Strategies

This strategy was particularly effective for both DeBERTa and BART in detecting DDEs, maintaining a higher balance between precision and recall as evidenced by their PR AUC scores. By analyzing sentences individually, this approach mitigates the dilution of relevant information, which is particularly beneficial in contexts where critical information might be embedded within longer text.

## Section: Discussion › DDE Detection › Classification Strategies

While this strategy provided context by combining multiple sentences, it often resulted in a higher FNR due to the dilution of relevant information with surrounding text. This observation aligns with our hypothesis that feeding multiple sentences to a model simultaneously can lead to relevant DDE mentions being overshadowed by unrelated information. However, an intriguing exception was observed for GPT-4, which performed slightly better under CS2 than CS1 at higher cutoff values. This suggests that GPT-4 might better leverage the entire context of comments to make more informed classifications, indicating its potential to handle more complex and detailed contexts.

## Section: Discussion › DDE Detection › Classification Strategies

Interestingly, the performance of GPT-4 under CS3 was comparable to its performance under CS2 with a cutoff of 0.75, contradicting our initial hypothesis that the GPT models would perform better under the binary classification task considered in CS3. This implies that the architecture and training methodology of GPT-4 may not align with the approach implemented in CS3 or that our prompt design in CS3 was not optimally formulated. Further investigation is needed to understand this phenomenon better.

## Section: Discussion › DDE Detection › Key Takeaways

BART’s superior performance, particularly under CS1, highlights its robustness and reliability in detecting DDEs from unstructured patient-generated content. This finding suggests that BART can be effectively used in clinical research to identify relevant data from imbalanced datasets without the need for extensive fine-tuning, which is crucial for real-world applications where data imbalance is common.

Because of BART’s exceptional performance in DDE detection, we used BART under the classification strategy and cutoff that it achieved the best performance with to curate the dataset we labeled and used for our DDE root cause analysis. BART achieved the highest F1-score of 0.86 under CS1 with a cutoff of 0.9.

## Section: Discussion › DDE Detection › Key Takeaways

The significant class imbalance, with only 107 out of 1000 (10.7%) comments labeled as DDEs, emphasizes the need for careful evaluation of classifier performance beyond overall accuracy. Metrics such as PR AUC provide a more comprehensive understanding of model performance, ensuring that high accuracy does not mask poor performance in detecting less frequent but critical events.

## Section: Discussion › DDE Detection › Key Takeaways

High FPRs and FNRs in DDE detection can lead to missed DDEs or unnecessary interventions, respectively. Therefore, achieving a balance in FPR and FNR, as demonstrated by BART under CS1 with a cutoff of 0.9, is essential for practical applications. This balance ensures that models can effectively support health care providers in making informed decisions based on patient-generated data.

## Section: Discussion › DDE Root Cause Analysis

Our multilabel classification approach enabled the identification of multiple reasons for drug discontinuation within a single comment, offering a comprehensive understanding of patient behavior and decision-making. This robust methodology allowed us to leverage the strengths of LLMs to tackle complex clinical research questions related to DDEs.

## Section: Discussion › Performance Highlights › DeBERTa and BART Struggled at Detecting DDE Root Causes

Both models struggled significantly at identifying the root causes of DDEs, as indicated by their much lower F1-scores and higher hamming loss in Table 2 in comparison to GPT-4 Turbo and GPT-4o. Another interesting observation was that 10% (100/1000) of the comments in the dataset were non-DDEs, meaning that BART under CS1 with a cutoff of 0.9 inaccurately classified them as DDEs. We noticed that BART tended to label non-DDE comments as DDEs if they contained phrases such as “I am not on any medication.” This is an important takeaway as it shows that even the models that performed the best at detecting DDEs still have tendencies to make mistakes in certain scenarios.

## Section: Discussion › Performance Highlights › GPT-4 Turbo and GPT-4o Performed Exceptionally Well at Detecting DDE Root Causes

These models outperformed DeBERTa and BART across most metrics. GPT-4o, in particular, achieved the highest F1-scores, lowest hamming loss, and highest Jaccard scores, indicating its superior ability to accurately and reliably classify the root causes of DDEs. The advanced capabilities of GPT-4 Turbo and GPT-4o in processing complex textual inputs holistically contributed to their outstanding performance.

## Section: Discussion › Performance Highlights › Classification Strategies

Although these strategies were effective for both DeBERTa and BART at detecting DDEs, the models struggled at detecting the root causes of DDEs under these strategies, as indicated by their extremely poor performance results shown in Tables 1 and 2.

## Section: Discussion › Performance Highlights › Classification Strategies

GPT-4 Turbo and GPT-4o performed exceptionally well under CS3, likely due to their advanced capabilities in understanding and processing complex textual inputs holistically. This strategy allowed the models to capture the full context of the comments, leading to more accurate and reliable DDE root cause identification.

## Section: Discussion › Performance Highlights › Key Takeaways

The outstanding performance of GPT-4 Turbo and GPT-4o models highlights the importance of using advanced language models for complex classification tasks in health care. Their ability to accurately identify the root causes of DDEs can provide valuable insights for health care providers, enabling them to address patient concerns more effectively and improve medication adherence.

## Section: Discussion › Performance Highlights › Key Takeaways

One notable challenge was the performance of GPT-4 Turbo in detecting DDEs belonging to the indeterminate class. For instance, a comment such as “My dad was diagnosed with bipolar disorder and stopped taking his meds after being in a rehabilitation center twice” did not clearly state the reason for discontinuation. Instead of classifying this as indeterminate, GPT-4 Turbo attempted to infer specific reasons such as personal choices or adverse reactions. This tendency to infer explicit conditions from ambiguous statements indicates a potential overfitting issue, where the model predicts more common classes instead of recognizing the ambiguity inherent in the input.

## Section: Discussion › Performance Highlights › Key Takeaways

The significant class imbalance presented a challenge for all classifiers. Classes with higher frequencies, such as personal choices and adverse reactions, exhibited better performance. In contrast, less frequent classes such as indeterminate showed lower performance, highlighting the need for more balanced training datasets or advanced techniques to handle class imbalance effectively.

## Section: Discussion › Clinical Implications

The superior performance of GPT-4 Turbo and GPT-4o in both DDE detection and root cause analysis underscores their potential application in clinical settings. These models can help health care providers identify common reasons for drug discontinuation, enabling the development of targeted interventions to improve medication adherence and patient outcomes. By leveraging these advanced NLP models, clinicians and researchers can gain deeper insights into patient behavior and decision-making processes, facilitating more effective and personalized health care strategies.

This research emphasizes the importance of capturing the patient’s perspective directly from web-based health forums, which offers a richer and more authentic understanding of patient behavior and the real-world challenges they face compared to traditional electronic health record data. By identifying the root causes of DDEs from the patient’s standpoint, health care providers, policy makers, and pharmaceutical companies can develop more targeted interventions to enhance medication adherence and patient outcomes.

## Section: Discussion › Future Research Directions

To further enhance the applicability and reliability of these models in real-world settings, future research should focus on the opportunities outlined in the subsequent sections.

## Section: Discussion › Future Research Directions › Real-World Applications

This research provides a foundation for clinical applications, such as improving patient adherence, by identifying common reasons for drug discontinuation. Health care providers can use these insights to develop targeted interventions and support systems to address the specific challenges faced by patients, ultimately enhancing treatment outcomes. Furthermore, applying these findings in real-world settings, such as clinical decision support systems, where accurate and reliable classification of text can significantly impact patient outcomes and health care processes, represents a substantial opportunity. Developing scalable and cost-effective solutions for deploying these models in practice will be crucial.

## Section: Discussion › Future Research Directions › Prompt Optimization

Future research should explore various prompt optimization techniques to enhance model performance. This includes experimenting with chain-of-thought prompting, which has been shown to improve the performance of LLMs on complex reasoning tasks. In addition, investigating the impact of prompt specificity and structure on DDE root cause classification performance can provide valuable insights into optimal prompt design. For instance, future research could examine how the performance of GPT-4 Turbo and GPT-4o changes when examples of positive instances for low-frequency classes are included in the prompt. One concern with this approach is the potential for “prompt dependency,” where providing specific examples might restrict the model’s ability to generalize and accurately classify comments that differ in nature from those presented in the prompt.

## Section: Discussion › Future Research Directions › Exploring Other State-of-the-Art LLMs

Research should be expanded to include state-of-the-art language models from developers other than OpenAI, such as models from Anthropic, Google, and Cohere. Models such as Claude by Anthropic and Gemini by Google have shown promising results in various NLP tasks and could be valuable for this study. In addition, models from research institutions, such as Command R by Cohere, should also be considered for comprehensive performance comparisons. By comparing the performance of these models on DDE root cause classification, we can identify the best tools for specific multilabel classification tasks and potentially reduce dependency on any single provider. This comparative analysis will help in understanding the strengths and limitations of each model in handling complex health care–related data, ultimately leading to more robust and versatile NLP applications.

## Section: Discussion › Future Research Directions › Cost Minimization Strategies

Developing strategies to minimize the costs associated with using advanced NLP models is essential. This includes exploring open-source alternatives, such as LLaMA, optimizing model use to reduce application programming interface calls, and implementing efficient data processing pipelines. Research directions toward cost minimization could potentially align with advanced prompting techniques, such as classifying multiple comments with a single prompt and application programming interface call. However, preliminary research suggests that longer prompts lead to degraded performance of LLMs, even when the number of tasks in a single prompt does not increase.

## Section: Discussion › Limitations

In summary, this research provides valuable insights into the ability of LLMs to detect DDEs from textual comments. However, the results should be interpreted with some caution due to the small sample size of DDE-labeled comments and the case imbalance inherent in our dataset. It is also worth mentioning that, as our study was restricted to English language comments from MedHelp, the generalizability of our results to other languages and platforms is not guaranteed. Furthermore, because the models used in this work generate stochastic outputs, the reproducibility of these results may be limited.

Despite these limitations, our study provides a foundation for further exploration into the use of LLMs in health informatics, specifically in identifying DDEs. Future studies should focus on improving the performance of transformer models by investigating other strategies, exploring ensemble methods, refining the classification prompt for the ChatGPT models, or incorporating different forms of data augmentation.

We anticipate that such innovative methods will stimulate and support further research into drug discontinuation, aiding health care researchers in identifying factors associated with the discontinuation of specific medications and treatments. These advancements are crucial in spotlighting new research directions with the potential to ameliorate treatment protocols and mitigate issues associated with medication discontinuation and nonadherence.

The ultimate aim is to enhance the capability of these models in real-world applications where accurate, timely detection of DDEs is of paramount importance. Improved detection can contribute to patient safety, optimize drug therapies, and facilitate better health outcomes.

## Section: Discussion › Conclusions

This study has provided a thorough evaluation of advanced LLMs for detecting DDEs and identifying their root causes using data from MedHelp. The research demonstrates the effectiveness of state-of-the-art LLM models, particularly GPT-4 and GPT-4o, in handling complex multilabel classification tasks without the need for extensive task-specific training.

In conclusion, this research contributes significantly to the field of NLP and health care informatics by showcasing the potential of advanced classifiers to derive actionable insights from patient-generated content. The findings underscore the transformative impact these technologies can have on understanding and improving medication adherence, ultimately leading to better health care outcomes.


---

# Validation of an Artificial Intelligence Model for Breast Cancer Molecular Subtyping Using Hematoxylin and Eosin-Stained Whole-Slide Images in a Population-Based Cohort

- **Authors:** Umay Kiraz, Claudio Fernandez-Martin, Emma Rewcastle, Einar G Gudlaugsson, Ivar Skaland, Valery Naranjo, Sandra Morales-Martinez, Emiel A M Janssen
- **Issuer:** Cancers
- **Type:** Scientific article
- **Published:** 2025-10-05
- **Language:** en
- **DOI:** 10.3390/cancers17193234
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41097760/
- **Licence:** CC-BY

## Section: Abstract

Simple SummaryBreast cancer is a complex disease that can be classified into different biological subtypes. Correctly identifying these subtypes is essential in determining the most effective treatment for each patient. However, current methods such as gene expression testing and immunohistochemistry are either expensive, time-consuming, or not widely available in all healthcare settings. In this study, we explored whether a computer-based approach using artificial intelligence can accurately predict breast cancer subtypes by analyzing routine pathology slides stained with hematoxylin and eosin. This real-world validation study shows that this method can identify certain subtypes with promising accuracy, offering a faster and more accessible alternative to existing techniques. This research may help improve diagnostic processes, especially in hospitals with limited resources, and support more personalized treatment decisions for patients with breast cancer.AbstractBackground/Objectives: Breast cancer (BC) is the most commonly diagnosed cancer in women and the leading cause of cancer-related deaths globally. Molecular subtyping is crucial for prognosis and treatment planning, with immunohistochemistry (IHC) being the most commonly used method. However, IHC has limitations, including observer variability, a lack of standardization, and a lack of reproducibility. Gene expression profiling is considered the ground truth for molecular subtyping; unfortunately, this is expensive and inaccessible to many institutions. This study investigates the potential of an artificial intelligence (AI) model to predict BC molecular subtypes directly from hematoxylin and eosin (H&E)-stained whole-slide images (WSIs). Methods: A pretrained deep learning framework based on multiple-instance learning (MIL) was validated on the Stavanger Breast Cancer (SBC) dataset, consisting of 538 BC cases. Three classification tasks were assessed, including two-class [triple negative BC (TNBC) vs. non-TNBC], three-class (luminal vs. HER2-positive vs. TNBC), and four-class (luminal A vs. luminal B vs. HER2-positive vs. TNBC) groups. Performance metrics were used for the evaluation of the AI model. Results: The AI model demonstrated strong performance in distinguishing TNBC from non-TNBC (AUC = 0.823, accuracy = 0.833, F1-score = 0.824). However, performance declined with an increasing number of classes. Conclusions: The study highlights the potential of AI in BC molecular subtyping from H&E WSIs, offering an easily applicable and standardized method to IHC. Future improvements should focus on optimizing multi-class classification and validating AI-based methods against gene expression analyses for enhanced clinical applicability.

## Section: 1. Introduction

According to the International Agency for Research on Cancer, breast cancer (BC) is the most diagnosed cancer and the leading cause of cancer death in women, and it was the second most common cancer overall in 2022 [1]. In today’s era, where the importance of personalized treatment is increasing, accurately determining the molecular subtype of BC is crucial for treatment planning and prognosis in clinical practice.

After Perou et al.’s groundbreaking publication in 2000 [2], which showed that BC could be classified into different subtypes based on gene expression, many other studies have been able to confirm their results. As of now, molecular subtyping based on gene expression patterns is considered the ground truth. Significant efforts have been made over the years to characterize and classify BC at the molecular level, aiming to refine classification and treatment strategies [3]. Cluster classifications are used for BC, such as hierarchical (intrinsic subtypes) and integrative (IntClust), therefore leading to different behaviors and prognoses [4]. Although several commercial tests based on gene expression [5] exist that can both classify patients into different subgroups and even predict treatment outcome and prognosis, IHC is still used in many countries due to the costs of the genomic tests. In some countries, the cost of IHC has to be paid by the patient itself; as such, IHC is not used at all in some parts of the world.

The surrogate IHC-based classification system categorizes BC into luminal A, luminal B, HER2-positive, and triple-negative BC (TNBC) according to estrogen receptor (ER), progesterone receptor (PR), proliferation (either Ki67 or mitosis counting), and human epidermal receptor growth factor 2 (HER2) expression.

These subtypes exhibit significant differences in incidence, treatment options, response to treatment, disease progression, and survival. Luminal A tumors exhibit high ER and PR expression and low levels of proliferation, resulting in excellent outcomes. In contrast, luminal B tumors are characterized by higher proliferation rates and lower PR and/or HER2 expression, leading to significantly poorer prognosis compared to luminal A tumors [6]. Luminal A cancers are typically treated with endocrine therapy, while luminal B cancers often are first treated with adjuvant chemotherapy followed by endocrine therapy based on tumor stage, menopausal status, and life expectancy [7]. HER2+ tumors have poor response to systemic chemotherapy and are treated with anti-HER2-targeted therapy such as trastuzumab [8]. Furthermore, TNBC is aggressive and has poorer outcomes compared to other BC subtypes. TNBC is not sensitive to hormone therapy or anti-HER2-targeted therapy; as such, chemotherapy is the main systemic treatment [9].

With the implementation of digital pathology in many Western countries and the rapid development of artificial intelligence (AI), important steps can be taken in pathology. These novel methods are required to develop an accurate and reproducible evaluation of predictive and prognostic biomarkers, avoid inter- and intra-observer variabilities, and refine personalized treatment, reducing overtreatment while not increasing undertreatment. As the abovementioned IHC and gene expression analyses still have challenges and limitations, we suggest the possibility of using an AI model to predict molecular subtyping from a hematoxylin and eosin (H&E)-stained slide. Such a model could, in principle, be more reproducible, cheaper, and faster than IHC or molecular tests. As such, in this study, we present a large population-based cohort of primary BC tumors from a single center in Norway, with their H&E-stained whole-slide images (WSIs) digitalized across three different centers. We validated an AI model with these data to test the hypothesis that the AI method is objective, sensitive, and specific when predicting molecular subtypes.

## Section: 2. Materials and Methods › 2.1. Dataset

Stavanger Breast Cancer (SBC) Dataset: A total of 864 consecutive lymph node-negative BC patients diagnosed at Stavanger University Hospital in Norway (1978–2004) were originally considered. The following cases were excluded from the study: 15 cases of HER2 2+ by IHC, and 311 cases lacked one or more IHC markers for molecular subtyping in different classification tasks. As a result, 538 patients were included in the study (Figure 1A). Two expert pathologists (U.K. and E.G.) selected the most representative slide for each patient, and an initial quality check was performed manually. All H&E-stained slides were scanned at 40 magnifications using three different scanners, with 87 cases using Hamamatsu NanoZoomer S60 (.ndpi), 43 cases using Hamamatsu NanoZoomer 2.0HT (.ndpi) (Hamamatsu Photonics, Hamamatsu City, Japan), and 408 cases using Leica Aperio AT2 (.svs) (Leica Biosystems, Richmond, IL, USA).

## Section: 2. Materials and Methods › 2.2. Immunohistochemistry

ER, PR, HER2, and Ki-67 expression were determined by IHC in whole sections. ER, PR, HER2, and Ki67 IHC stains were performed and evaluated by a different observer for the previous studies using adequate quality controls according to the guidelines of the Norwegian Breast Cancer Group (NBCG) [10,11]. ER was scored as positive when nuclear staining was present in ≥1% and scored negative when it was <1% [3]. PR was scored as positive when nuclear staining was present in ≥10% and negative when it was <10% [10]. HER2 was scored between 0 and +3 depending on the membranous staining pattern and the intensity of the staining according to the WHO classification [3]. Cases with 0 and 1+ were evaluated as HER2-negative, while those with 3+ were evaluated as HER2-positive (HER2+). The cases with a 2+ expression of HER2 were excluded from the dataset, as additional information based on in situ hybridization was lacking. The Ki67 percentage was determined by the conventional Ki67 score, which has been previously described [12]. In short, the hotspot score is determined by examining the entire invasive region of the tumor section at low power to identify the most proliferative area. Once identified, both positive and negative nuclei are counted within a single field of view at high power (40X-objective). The Ki67 score is then calculated by dividing the number of positive Ki67 tumor nuclei by the total number of both positive and negative tumor nuclei, then multiplying by 100. The NBCG recommends counting a total of at least 500 tumor nuclei [10]. Due to the lack of consensus on the Ki67 threshold to distinguish low and high proliferation, we use the mitotic activity index (MAI) as a supplementary measure. According to the NBCG, Ki67 < 5% is classified as low proliferation, while Ki67 > 30% is considered high proliferation [10]. If Ki67 values are unavailable or fall between 5% and 30%, the MAI is used with a cutoff value of 10, with an MAI < 10 indicating low proliferation and an MAI ≥10 indicating high proliferation. The surrogate classification was made after the quantification of IHC (Table 1).

The patient distribution across the subtypes is presented in Figure 1B, with the majority classified as luminal A (n = 283, 53%), reflecting its higher prevalence in the population. Luminal B accounts for 77 patients (14%), HER2-positive cases total 51 (9%), and TNBC represents 127 cases (24%).

## Section: 2. Materials and Methods › 2.3. AI Model

The AI model (Figure 2) employed in this study leverages a pretrained deep learning framework based on multiple-instance learning (MIL) principles to predict the molecular subtypes of BC directly from H&E-stained whole-slide images (WSIs). The MIL paradigm is particularly suited for this task, as it allows for weakly supervised learning using only slide-level labels without requiring detailed annotations at the patch or pixel level.

The model was trained on the publicly available Early Breast Cancer Core-Needle Biopsy Whole-Slide Image (BCNB) dataset [13]. This dataset includes 1058 core-needle biopsy WSIs with age, tumor size, tumor type, number of lymph node metastases, IHC results, and biopsy-level labels for molecular subtypes. It serves as the foundation for training the feature extractor. The backbone of the model is a convolutional neural network (CNN) pretrained under the MIL paradigm, utilizing the MIL attention mechanism [14]. This is a standard approach in the MIL literature that enhances the aggregation of patch-level features into slide-level representations. This attention mechanism ensures that the most discriminative patches contribute more significantly to the final prediction, improving the robustness of the feature extraction process.

To validate the generalizability of the model, we performed the validation using the SBC dataset. The SBC dataset provides an independent test set that reflects real-world variability in image acquisition and staining protocols, making it an ideal benchmark for evaluating the model’s clinical applicability.

## Section: 2. Materials and Methods › 2.3. AI Model › 2.3.1. Feature Extraction on the SBC Dataset

Each WSI in the SBC dataset was subjected to several preprocessing steps before being used as input into the model. This included an automatic quality control assessment to address variations in staining and image acquisition across scanners as well as artifact exclusion. We normalize all slides to a consistent staining distribution so that cases from different scanners fall within the same color domain [15]. A tissue segmentation model [16] was used to filter out artifacts and non-informative patches, and only those with at least 60% tissue content were retained. This ensures that the analysis focuses on the biologically relevant regions of the WSIs. For each WSI, the tissue regions were divided into non-overlapping patches of size 512 × 512 pixels at 20× magnification.

The pretrained CNN-based MIL feature extractor was then used to compute deep feature vectors for informative patches. These feature vectors encapsulate the learned representations of tissue morphology and texture, which are critical for distinguishing between molecular subtypes. The extracted features were subsequently used to retrain the final classifier, adapting the model to the specific characteristics of the SBC dataset.

## Section: 2. Materials and Methods › 2.3. AI Model › 2.3.2. Retraining the Final Classifier

The final classification layer of the pretrained model was fine-tuned using the SBC dataset to ensure optimal performance in this cohort. Both oversampling and undersampling strategies were applied, complemented by the application of a weighted categorical cross-entropy loss function during fine-tuning to address class imbalance within the dataset. The fine-tuned model was then evaluated across different molecular subtype classification tasks (CLF), including binary (two-class), three-class, and four-class settings, as summarized in Table 2.

## Section: 2. Materials and Methods › 2.3. AI Model › 2.3.3. Performance Evaluation

The AI model’s performance was evaluated using standard metrics. The area under the curve (AUC) was used to assess the model’s ability to distinguish between different classes. Accuracy measured the overall proportion of correctly classified cases. To address potential class imbalance, the F1 score was employed, as it balances precision and recall. Additionally, precision and recall were analyzed individually to better understand the trade-off between false positives and false negatives.

Due to the absence of predefined training, validation, and test splits in the SBC dataset, a repeated k-fold cross-validation (CV) strategy was employed. This involved performing three repeats of 5-fold CV across all SBC cases. This approach ensures robust evaluation by systematically dividing the dataset into multiple training and validation folds and repeating this process with different random shuffles, thereby reducing the risk of overfitting and providing a more stable and reliable estimate of model performance.

For each fold, the pretrained feature extractor (backbone trained on the BCNB dataset) was used to extract deep feature vectors from the informative patches of the SBC WSIs. These features were then used to retrain the final classifier. A small hyperparameter search was conducted during this process to optimize the learning rate and weight decay for the classifier.

## Section: 3. Results

The overall performance evaluation results of our MIL backbone pretrained on the BCNB dataset for classifying BC molecular subtypes across three different classification tasks are summarized in Table 3. These are the best overall mean results across the test sets of the 5-fold of the three repeats, choosing the models for each task with the best mean F1 score.

The model performed best in the 2-CLF task, with an AUC of 0.823, accuracy of 0.833, and a high F1 score of 0.824, suggesting strong differentiation between the two classes. However, as the number of classes increased, performance decreased. In the 3-CLF task, the model maintained a relatively high AUC (0.834), but accuracy dropped to 0.795 and the F1 score decreased to 0.770, indicating greater difficulty distinguishing among three molecular subtypes. The 4-CLF task demonstrated the most significant decline in performance, with the AUC dropping to 0.790, accuracy decreasing to 0.642, and the F1 score reaching only 0.601, highlighting the increased complexity in distinguishing among four BC subtypes. Precision and recall followed similar trends, with both metrics decreasing as the classification task became more complex, particularly in the 4-CLF setting, where precision and recall dropped to 0.587 and 0.642, respectively. While the model effectively classifies distinct subtypes in two- and three-class tasks, further optimization is needed for multi-class classification. After testing random repeats and folds across the SBC dataset, the model with the best learning rate and weight decay combination on average was found and is shown in Table 3.

The confusion matrices show the results from individual test sets of a specific fold, as well as a specific repeat within our CV process (Figure 2). The results suggest that the model performs well in classifying certain molecular subtypes, particularly luminal A and “Other” cases, with high accuracy. However, it struggles more with distinguishing between HER2(+), luminal B, and TNBC, leading to some misclassification errors.

Figure 3A reveals that the 2-CLF model performed well in classifying non-TNBC with minimal errors, with 59 correct predictions and only 3 false positives. However, TNBC classification is less reliable, with nine false negatives. This suggests an imbalance in classification, where the model favors predicting non-TNBC over TNBC. Figure 3B shows that the 3-CLF model performed well in classifying the luminal subtype, correctly identifying 53 out of 62 samples, resulting in high specificity. However, the model struggled more in distinguishing HER2(+) and TNBC cases. Figure 3C demonstrates that the 4-CLF model achieved strong performance in classifying luminal A, correctly predicting 38 samples, but it struggled more with luminal B, HER2(+), and TNBC classifications. There were several misclassifications between these subtypes, indicating that their features may overlap, making differentiation more difficult.

## Section: 4. Discussion

BC molecular subtypes vary in behavior, treatment response, and prognosis, making accurate and reproducible evaluation essential in clinical practice. Most pathology laboratories rely on IHC surrogate classification for BC molecular subtyping. However, this method faces challenges such as a lack of standardized IHC procedures and cut-off values, observer-related variability, and a lack of reproducibility. On the other hand, IHC surrogates do not always accurately reflect the true intrinsic molecular subtypes and show poor-to-moderate concordance with PAM50, with misclassification rates reaching up to 30–40% across all subtypes [17,18,19]. Gene expression has its advantages but also comes with constraints, such as higher costs and longer processing times. Considering the promising results of deep learning in cancer research, particularly in classification and prediction, it is important to evaluate it as a third approach. Moreover, AI-driven methods can overcome the limitations of the other two approaches mentioned above. In this study, we validated an AI method for determining BC molecular subtypes directly from H&E-stained WSIs. The method used the pretrained BCNB public dataset and was externally validated using the SBC dataset, which shows its robustness against different image acquisition variations.

The results show that the best outcome is achieved with the 2-CLF task, which distinguishes between TNBC and non-TNBC. This is an important step for the next phase of the study, which aims to predict prognosis specifically within the TNBC subgroup. In multiclass classification, performance can be improved by enhancing recall, which can be achieved by adjusting class weights or using more balanced data. The difficulty in distinguishing between luminal A and luminal B cases largely depends on proliferation and therefore, integrating an automatic proliferation assessment based on mitosis localization could help accurately differentiate between these two subtypes [20]. The AI model used in our study focuses solely on tumor cells and does not account for the relationship with the tumor microenvironment (TME). While this could be considered a limitation, it should be noted that the surrogate model, namely molecular subtyping with IHC, also only evaluates tumor cells.

This study focuses on BC using H&E WSIs, which helps avoid the challenges associated with non-standardized IHC procedures and observer variability. Additionally, H&E-based approaches are generally more cost-effective compared to IHC and provide results in a shorter time. In particular, in low-income countries, the IHC method is not affordable for hospitals, and patients are often treated without molecular subtyping. In this case, the method we propose might be highly beneficial, as even a small, single-slide scanner could surpass the need for the IHC method, which requires significant capital investment. Moreover, with the emergence of new techniques that allow for the virtual staining of unstained (non-H&E-stained) slides, interlaboratory variability can also be resolved more quickly and cost-effectively [21]. Different approaches have been studied to investigate molecular subtype prediction in BC, especially using image analysis or deep learning frameworks, particularly with H&E-stained images, presenting reliable and promising results [22,23,24,25]. However, research involving validation with real-world data is limited, and it is crucial for improving the generalizability and reproducibility of these methods for clinical use.

Considering the increasing importance of neoadjuvant therapies, BC diagnosis is increasingly performed using core-needle biopsies, which may not fully capture the tumor heterogeneity observed in surgical resections. Therefore, the use of the SBC dataset for validation was highly significant. Since there is no specific clinically validated morphological feature that AI can learn from BC H&E to distinguish molecular subtypes, utilizing MIL, which relies solely on slide-level labeling rather than patch- or pixel-level annotations, is crucial for enhancing the model’s ability to capture relevant patterns and improve classification performance. One of the discussed molecular subtypes, TNBC, is known to have multiple molecular subtypes, each with distinct prognoses [26,27]. Despite these differences, all subtypes currently receive the same treatment, highlighting the importance of molecular subtyping. One such subtype is the luminal androgen receptor (LAR) subtype, characterized by AR-positive TNBC cases, for which studies have shown the effectiveness of anti-androgen therapy [28]. Another subtype is characterized by a high abundance of immune cells, and studies have demonstrated that tumor-infiltrating lymphocytes (TILs) are prognostic in TNBC [29]. This group is particularly valuable due to the potential for immunotherapy in its treatment. As a plan, we propose evaluating our model for TNBC subtyping to further explore its potential.

There are, however, some limitations to the current study. There was a clear class imbalance within the dataset. This study used a population-based dataset, reflecting BC prevalence in the population, which is one of the key aspects that distinguishes our study from others; however, this also means that class imbalance is inevitable. To address this imbalance, optimizing the model weights using a weighted categorical cross-entropy loss function is essential, as was done in our study. Moreover, the current study was analyzed using the surrogate method, but the most reliable and accurate findings should be obtained by comparing gene expression analyses and this proposed AI method. Numerous commercial gene panels are available, including Oncotype DX, MammaPrint, Prosigna (PAM50), and EndoPredict. PAM50 is currently widely used in Norway as a transcriptome-based classification system for intrinsic subtype classification [30]; it was implemented during the EMIT study. As of December 2024, recruitment for this study is now closed, and more than two thousand BC patients analyzed using the PAM50 test and the surrogate IHC classification system. Oncologists based their treatment decision first on IHC and then on PAM50 [31]. Another limitation of this study is the exclusion of HER2 2+ cases. Using studies where all cases are subtyped through gene analysis, regardless of HER2 status, could help address this limitation [31]. The prevalence of TNBC in the population is around 15%, but in our dataset, it was slightly higher than expected. Excluding HER2 2+ cases or obtaining false negative receptor results in older tissue blocks may explain this. Older blocks can lead to misclassifying non-TNBC cases as TNBC due to antigen degradation or suboptimal staining. HER2-low tumors are characterized by low HER2 protein expression [IHC 1+ or IHC 2+ with negative in situ hybridization (ISH)] but without HER2 gene amplification, highlighting the complexity of BC. These tumors were previously considered part of the HER2-negative group and have gained attention due to their potential responsiveness to novel HER2-targeted therapies. Its prognosis is being actively investigated, and it is believed that different treatment strategies may be necessary for this subgroup. Validating the proposed model on datasets with available PAM50 results is important to better address this uncertain and evolving area. Furthermore, the use of different digital scanners in this dataset has helped address variabilities related to image acquisition. Although all slides were stain-normalized to a consistent color distribution, one of the limitations of the study is that model performance was not evaluated across the different scanner types.

This study is valuable, as the model provides slide-level predictions of molecular subtyping using only H&E-stained WSIs and represents, to our knowledge, the first validation of such a model using a large, population-based, real-world BC dataset. Only relying on H&E WSIs offers an easily applicable alternative and has the potential to shorten time to diagnosis.

## Section: 5. Conclusions

In conclusion, our study demonstrated that the proposed AI model helped to distinguish BC molecular subtypes on H&E slides but only with distinct subtypes. The results are promising; however, future improvements may require improving performance in multiclass classification. Using only H&E-stained slides is undoubtedly important for pathology laboratories with a high workload. Future studies should focus on addressing the limitations described above and ensuring the approach is robust and applicable in clinical settings for personalized treatment.


---

# Web-Based Explainable Machine Learning-Based Drug Surveillance for Predicting Sunitinib- and Sorafenib-Associated Thyroid Dysfunction: Model Development and Validation Study

- **Authors:** Fan-Ying Chan, Yi-En Ku, Wen-Nung Lie, Hsiang-Yin Chen
- **Issuer:** JMIR formative research
- **Type:** Scientific article
- **Published:** 2025-04-10
- **Language:** en
- **DOI:** 10.2196/67767
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40209178/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundUnlike one-snap data collection methods that only identify high-risk patients, machine learning models using time-series data can predict adverse events and aid in the timely management of cancer.ObjectiveThis study aimed to develop and validate machine learning models for sunitinib- and sorafenib-associated thyroid dysfunction using a time-series data collection approach.MethodsTime series data of patients first prescribed sunitinib or sorafenib were collected from a deidentified clinical research database. Logistic regression, random forest, adaptive Boosting, Light Gradient-Boosting Machine, and Gradient Boosting Decision Tree were used to develop the models. Prediction performances were compared using the accuracy, precision, recall, F1-score, area under the receiver operating characteristic curve, and area under the precision-recall curve. The optimal threshold for the best-performing model was selected based on the maximum F1-score. SHapley Additive exPlanations analysis was conducted to assess feature importance and contributions at both the cohort and patient levels.ResultsThe training cohort included 609 patients, while the temporal validation cohort had 198 patients. The Gradient Boosting Decision Tree model without resampling outperformed other models, with area under the precision-recall curve of 0.600, area under the receiver operating characteristic curve of 0.876, and F1-score of 0.583 after adjusting the threshold. The SHapley Additive exPlanations analysis identified higher cholesterol levels, longer summed days of medication use, and clear cell adenocarcinoma histology as the most important features. The final model was further integrated into a web-based application.ConclusionsThis model can serve as an explainable adverse drug reaction surveillance system for predicting sunitinib- and sorafenib-associated thyroid dysfunction.

## Section: Introduction › Background

Sunitinib- and sorafenib-associated thyroid dysfunction are time-varying and underreported adverse drug reactions (ADR). Despite the efficacy of multitargeted tyrosine kinase inhibitors TKI as first- or second-line therapies for solid and hematologic cancers, thyroid dysfunction—especially hypothyroidism—may complicate treatment regimens using sunitinib and sorafenib. Although not life-threatening, such adverse events can lead to a suboptimal quality of life, physical discomfort, or the need for thyroid dysfunction treatment [12]. Incidences of thyroid dysfunction vary from 10%- to 85% for sunitinib and from 6.3% to 27% for sorafenib [3-6]. Hypothyroidism develops late and is prolonged, with onset ranging from 5 to 20 months [16-8undefinedundefined]. Due to its high variability and difficulty in predicting, close monitoring and proactive ADR surveillance with machine learning (ML) models may be warranted to manage sunitinib- and sorafenib-associated thyroid dysfunction.

Incorporating real-time laboratory data can enhance the performance of ML models in predicting thyroid adverse events. Previous studies have demonstrated the effectiveness of ML in predicting thyroid dysfunction, such as amiodarone-induced dysfunction using time-series data collection methods with a robust performance [9]. In contrast, predicting immune checkpoint inhibitor-induced adverse thyroid events without continuous laboratory testing resulted in an area under the precision-recall curve (AUPRC) of 0.510 [10]. Another study developed a predictive model for immune checkpoint inhibitor-induced adverse thyroid events without detailed time-point data collection, achieving an area under the receiver operating characteristic curve (AUROC) of 0.885 with thyroid-related features [11]. However, no studies have focused on predicting thyroid adverse events caused by TKIs such as sunitinib and sorafenib. Adopting timely data collection with detailed clinical biochemical tests to develop thyroid dysfunction surveillance systems can help clinicians timely adjust TKI treatment by balancing risks and benefits.

Applying model interpretation and web-based applications can alleviate the black-box drawback of ML models and enhance understanding of ADRs. The SHapley Additive exPlanations (SHAP) analysis is a mathematical method that has become increasingly popular for explaining ML models [12-14]. It is based on game theory concepts that calculate feature importance and contributions to predicted outcomes at both population and individual levels [15]. Model deployment in web-based or smartphone applications were constructed in recent years to strengthen the scalability of predicting specific diseases or ADRs [131617]. Through a user-friendly interface and explainable model, applications can provide clinicians with a greater understanding and actionable preventive remedies for their patients. These techniques successfully have increased the interpretability and accessibility of ML models to support clinical decision-making.

The landscape of drug surveillance has experienced notable changes, shifting from passive reporting systems or rules-based alerting systems to active identification of adverse drug events, driven by advancements in electronic health records and artificial intelligence. Traditional methods often rely on spontaneous reporting or rules-based alerting, which may lead to underreporting and delays in identifying ADRs. The ML models, particularly tree-based algorithms, can analyze large-scale clinical data in real time, proactively detecting ADRs and enhancing medication safety at the point of care [18]. By continuously collecting and analyzing patient data, ML-driven drug surveillance based on time-series data extraction enables dynamic risk assessment, facilitating early intervention and personalized treatment adjustments. Given the underreported and time-varying nature of thyroid dysfunction, this progressive approach can serve as a valuable tool for predicting ADRs in patients undergoing TKI therapy.

## Section: Introduction › Objective

The objective of this study was to develop and validate progressive ML predictive models for sunitinib- and sorafenib-induced thyroid dysfunction. Five algorithms—logistic regression (LR), random forest (RF), Gradient Boosting Decision Tree (GBDT), Light Gradient Boosting Machine (LGBM), and Adaptive Boosting (AdaBoost)—were used to construct the models. The specific aims of this study were (1) to use time-series data collected at the baseline, and at 1, 2, 3, 4, 5, 6, 9, 12, 18, 24, 30, and 36 months after the index date to generate predictive models using the five algorithms; (2) to select the best model by comparing the accuracy, precision, recall, F1-score, AUROC, and AUPRC, after adjusting for the optimal threshold; (3) to interpret the best-performing model with a SHAP analysis to analyze feature importance levels and contributions, comparing findings with a previous amiodarone-induced thyroid dysfunction predictive model; and (4) to deploy the best-performing model by constructing a web-based application.

## Section: Methods › Ethical Considerations

This retrospective study used the deidentified Clinical Research Database (CRD) which includes data from Taipei Medical University Hospital, Wan Fang Hospital, and Shuang Ho Hospital of the TMU health care system. Ethical review for this study was waived by the TMU-Joint Institutional Review Board (approval no.: N202202053). As the data had been deidentified, the requirement for informed consent was waived. No compensation was provided to the participants.

## Section: Methods › Study Design and Patient Cohort

Data from patients who were first prescribed sunitinib or sorafenib from 2013 to 2019 were collected as the derivation (training) cohort, whereas data from patients treated between 2010 and 2012 were collected as a temporal validation (testing) cohort. The data-splitting time point was chosen considering a common proportion of 7:3 for the training and testing cohorts and similar incidences of thyroid dysfunction in both cohorts for better model development and validation. More recent data were used for model training to better reflect current clinical practice, allowing models to be developed with up-to-date treatment patterns and patient characteristics. Patients were excluded if they were younger than 18 years, pregnant, with a history of hypothyroidism, had a diagnosis of thyroid carcinoma, had undergone thyroidectomy, used levothyroxine, or had abnormal thyroid-stimulating hormone (TSH) levels within 1 year before the index date, which was the first day of sunitinib or sorafenib use. Patients were also excluded if they were lost to follow up. Each individual was followed up for 3 years, and data were collected until the end of the study period, loss to follow-up, death, or occurrence of thyroid dysfunction. Figure 1 demonstrates the study design of the proposed models. This study followed the Transparent Reporting of a multivariable prediction model for Individual Prognosis Or Diagnosis + Artificial Intelligence (TRIPOD + AI) reporting guideline [19]. Registration was not required, and no separate study protocol was prepared.

## Section: Methods › Time-Series Data Collection and Preprocessing

Variables including patient demographics, cancer-related information, medication use, laboratory tests, coexisting drugs, and comorbidities were collected from the CRD. Patient demographics including age, gender, and cancer-related information were collected once at the baseline. Laboratory tests, medication use, comorbidities, coexisting drugs, weight, and body mass index (BMI) were collected at the baseline, and at 1, 2, 3, 4, 5, 6, 9, 12, 18, 24, 30, and 36 months after the index date (Multimedia Appendix 1). Reengineering features included calculating the cumulative dose, summed days of medication, duration of sunitinib or sorafenib, and the slope of laboratory tests at recent and previous data collection time points. The number of coexisting thyroid-related drugs was calculated to determine whether the aggregated use of these medications increased the risk of thyroid dysfunction.

Data preprocessing including missing value imputation and feature scaling was performed to ensure data quality. Features with over 80% missing values, except for the TSH level, were first excluded from the model. Missing values were imputed using multivariate imputation by chained equations [20]. If previous data were traceable, missing values, using time-series data collection, were precisely imputed using the last observation carried forward. Missing values in laboratory test slopes were imputed with zero. A feature-scaling method—the robust scaler—was used to reduce the effect of extreme values of continuous variables. Features were first selected through a literature review and clinical domain knowledge to identify thyroid-related variables. Recursive feature elimination, a feature selection technique that recursively removes the least important features with 5-fold cross-validation was then used, and the AUROC was considered to select optimal features for each model. The codebook and missing rates of each variable in the training and testing set are described in Multimedia Appendix 2.

## Section: Methods › Prediction Outcome

The predictive outcome of this study was the occurrence of sunitinib- or sorafenib-associated thyroid dysfunction. Patients were defined as a TSH level ≥4 mIU/L, a diagnosis of hypothyroidism with International Classification of Diseases codes (ICD-9-CM; 243 or 244 or ICD-10; E02 or E03), or use of levothyroxine (Anatomical Therapeutic Chemical code: H03AA02). These criteria were defined following previous studies that focused on drug-induced thyroid dysfunction [92122].

## Section: Methods › Model Development and Validation

The study used three resampling strategies and raw data applied to the five algorithms to develop 20 machine learning models. The five algorithms included LR, RF, AdaBoost [23], LGBM [24], and GBDT [25]. Resampling strategies used were random over-sampling (ROS), borderline synthetic minority oversampling technique (B-SMT), and a combination of over- and under-sampling using SMT and Tomek links (STMK). Bayesian optimization with 5-fold cross-validation and the AUPRC were considered for hyperparameter tuning [26]. For boosting models, hyperparameters such as learning_rate and n_estimators were optimized to balance convergence speed and model complexity. Specifically, in LGBM, subsample and colsample_bytree were fine-tuned to mitigate overfitting. Key parameters including max_depth, min_samples_split, and min_samples_leaf were adjusted to improve generalization and prevent overfitting for RF. Table S3.1 in Multimedia Appendix 3 lists the ranges of hyperparameters used for tuning in each algorithm. Pseudocodes of the model development process are listed in Multimedia Appendix 4.

A stratified 5-fold cross-validation was first used for internal validation of the training dataset, and the performances of the 20 models were evaluated using the temporal validation cohort. The accuracy, precision, recall, F1-score, AUROC, and AUPRC were the metrics used for evaluating model performance. Model performance was compared and evaluated following the sequence of the highest AUPRC, AUROC value, and F1-score to select the best-performing model.

## Section: Methods › Threshold Adjustment, Model Interpretation, and Web-Based Application

To optimize the performance of the best-performing model, different thresholds were selected on the PRC based on different percentages of outcome predictions. Five cutoff points were chosen: (1) a high-risk threshold for identifying a lower number of patients potentially at risk; (2) a default threshold of 0.50; (3) an optimal threshold based on the maximum F1-score; (4) an equal threshold where precision, recall, and F1-score were equal, and (5) the low-risk threshold for identifying a higher number of patients potentially at risk. The F1-score, recall, precision, and accuracy were then compared for these 5 thresholds. The best model was further examined by SHAP analysis to explain feature importance and contribution at both the population and individual levels [27]. At the population level, SHAP summary plots were used to demonstrate feature importance and how the top-ranked features impacted outcome predictions. On the other hand, SHAP force plots were used to visualize how the features contributed to outcome predictions in specific patients.

The model was further integrated into a web-based application to increase the accessibility of the model. The Python Flask framework was used to develop the application programming interface. The value of each feature served as input data that were fed back into the model to generate a predictive probability of thyroid dysfunction. The consistency of feature scaling between input data and training data was ensured by applying the same scaling transformation. The input variables with missing values were imputed with the last observation or the same multivariate imputation by chained equations transformation applied during model development to ensure consistency in predictions.

## Section: Methods › Statistical Analysis

Patient characteristics were evaluated with independent t tests or the Wilcoxon rank-sum test for continuous variables, and the χ2 test or Fisher exact test for categorical variables. A two-sided P value <.05 was considered statistically significant. Data were analyzed using SAS (version 9.4; SAS Institute), Python (version 3.9.5; Python Software Foundation), and R software (version 4.2.2; R Foundation for Statistical Computing). The statistical significance of the AUPRC was calculated using MedCalc software (version 22.001).

## Section: Results › Patient Characteristics and Multivariate Analysis

This study enlisted data from 900 patients prescribed sunitinib or sorafenib from initial screening from the CRD. A STROBE (Strengthening The Reporting of Observational Studies in Epidemiology) flowchart of patient selection is described in Multimedia Appendix 5. After applying the exclusion criteria, 807 patients remained. Patient characteristics and multivariate analysis of the training and temporal validation cohorts are listed in Multimedia Appendix 6. The training cohort contained 609 patients, with 52 (8.5%) patients developing thyroid dysfunction, while 16 (8.1%) patients experienced thyroid dysfunction in the temporal validation cohort of 198 patients. There were no significant differences in age or gender in the derivation or temporal validation cohort. Cancer type, histology, aspartate aminotransferase (AST), and bilirubin levels significantly differed (P<.001) between patients with and those without thyroid dysfunction in the two cohorts.

## Section: Results › Model Development and Validation

The total number of features selected by recursive feature elimination were 20, 18, 15, 40, and 20 in GBDT, AdaBoost, LGBM, RF, and LR, respectively. The most frequently selected features were recent laboratory tests including AST, alanine transaminase (ALT), bilirubin, cholesterol, and triglyceride levels. Patient demographics such as age and BMI summed days of medication use, and follow-up duration were also among the top-ranked selected features (Multimedia Appendix 7). The optimal hyperparameter subsets selected by Bayesian optimization are listed in Table S3.2 in Multimedia Appendix 3.

Figure 2 shows the model performance based on the AUPRC, AUROC, F1-score, precision, recall, and accuracy in 20 ML models of the temporal validation cohort. Most of the GBDT and AdaBoost models had higher AUPRC values and F1-scores, while recall was higher in the RF and LR models. Of all the ML models, the GBDT without resampling (GBDT_RAW) outperformed the other models, with an AUPRC of 0.600, AUROC of 0.876, and an F1-score of 0.522. The AUPRC of GBDT_RAW (0.600, 95% CI 0.350-0.798) was significantly higher than those of the GBDT_ROS (0.388, 95% CI 0.175‐0.618; P<.05), GBDT_BMST (0.300, 95% CI 0.124‐0.549; P<.05), and GBDT_STMK (0.346, 95% CI 0.147‐0.582; P<.05). Multimedia Appendix 8 lists model performances of 5-fold cross-validation with the training cohort and the statistical significance tests of the AUPRC of all the models.

## Section: Results › Threshold Adjustment

Figure 3 shows the five cutoff points on the PRC and the precision, recall, and F1-score at different thresholds of the GBDT_RAW model. Based on different percentages of outcome predictions, cutoff points were 0.851 for identifying the top 1% of patients (2 predictive positive cases, point A — high-risk threshold),0.500 for the top 3.5% (7 predictive positive cases, point B — default threshold), 0.495 for the top 4% (8 predictive positive cases, point C — optimal threshold based on the maximum F1-score), 0.272 for the top 8% (16 predictive positive cases, point D — equal threshold), and 0.071 for the top 26% of patients (51 predictive positive cases, point E — low-risk threshold). When moving the threshold from 0.500 to 0.851 (point A), the precision increased from 0.875 to 1.000, while recall significantly decreased to 0.125. In contrast, recall significantly increased to 0.750 and the precision decreased to 0.231 when changing the threshold to 0.066 (point E). The precision, recall, and F1-score reached 0.500 when the threshold was adjusted to 0.272 (point D). The optimal threshold of 0.495 (point C) for the GBDT_RAW model was selected based on the maximum F1-score, with a precision of 0.875, recall of 0.438, and F1-score of 0.583.

## Section: Results › Model Interpretation

Figure 4 shows model interpretation implemented with the SHAP analysis on the best-performing GBDT_RAW model. The summary plot in Figure 4A displays that the top five important predictors were the AST level, TG level, follow-up duration, cholesterol level, and albumin level. Figure 4B shows that patients with lower AST levels, higher cholesterol levels, higher albumin levels, longer durations of medication use, and clear cell adenocarcinoma histology had higher SHAP values for predicting the occurrence of thyroid dysfunction. At the individual level, force plots showed the impacts of features on predicting thyroid dysfunction in two specific patients. Figure 4C shows a patient with a predictive probability of 0.02, resulting from his AST level of 69 IU/L and the summed days of medications of 62 days, which contributed most negatively to outcome predictions. For a patient with a predictive probability of 0.82 in Figure 4D, the medication duration of 708 days and clear cell adenocarcinoma served as the most important factors that positively impacted outcome predictions.

## Section: Results › Web-Based Application

A web-based application for predicting sunitinib- and sorafenib-associated thyroid dysfunction was developed using the GBDT_RAW model (Figure 5). The application provides a user-friendly interface by showing 20 features selected by the GBDT model. Values of the features can be filled in with the appropriate units shown in each input box. The model then generates a predictive probability for the risk of sunitinib- or sorafenib-associated thyroid dysfunction. Ultimate predictions for the occurrence of thyroid dysfunction were determined based on thresholds adopted by clinical users.

## Section: Discussion › Principal Findings

This study developed explainable ML models by collecting time-series data to predict sunitinib- and sorafenib-associated thyroid dysfunction. The present model allowed ongoing predictions according to the rapidly shifting status of the disease for patients undergoing long-term TKI treatment. The best-performing GBDT without resampling model was optimized by threshold moving strategies to achieve a maximum F1-score. This study further used a SHAP analysis that provided interpretability at both the population and individual levels, identifying key predictors such as AST, cholesterol, and albumin levels. The feature selection process revealed similarities with prior research on amiodarone-induced thyroid dysfunction, supporting the model’s potential applicability to other drug-induced thyroid dysfunctions [9]. Integrating the model into a web-based application demonstrated its practical utility by allowing real-time risk estimation based on patient-specific data.

## Section: Discussion › Time-Series Data Collection

Time-series data collection in this study had a few advantages for thyroid dysfunction predictions on TKI users as illustrated in Figure 6. Clinical data at multiple time points in a long-term follow-up period were collected for model building. Time-series data allowed reengineering features by calculating rates of change of laboratory tests at recent and previous time points. The last observation carried forward method using the last value to replace missing data in subsequent time points ensured that missing values were imputed with plausible estimates [28]. This time-series data collection closely monitored patients newly prescribed TKI users and those on long-term TKI therapy. The time-series model captured the critical moment of an approaching adverse event for an individual patient, providing oncologists with invaluable information to treat patients on TKIs.

Identifying thyroid dysfunction was reported to potentially serve as a prognostic indicator for treatment outcomes. Sunitinib and sorafenib respectively demonstrated progression-free survival (PFS) periods of 11 and 5.5 months in patients with renal cell carcinoma [29,30]. Interestingly, studies indicated that patients with thyroid dysfunction had a longer PFS compared to patients with normal thyroid function among sunitinib (11.9 vs 8.8 months) and sorafenib users (19.3 vs 5.5 months) [431]. These findings suggest that thyroid dysfunction may not only represent an adverse event but could serve as a marker of enhanced therapeutic response. Leveraging a time-series data collection approach, this study can predict thyroid dysfunction risk while simultaneously identifying patients who may derive greater clinical benefits from sustained TKI therapy. Unlike one-snap data collection which arbitrarily differentiates high-risk patients from a low-risk group, this time-series approach allows high-risk patients to use lifesaving TKIs for a relatively longer grace period which can significantly enhance their survival times. Models with time-series data collection balance the risks and benefits of survival and adverse drug events, bestowing precious survival periods for end-stage cancer patients with reasonable medication safety and improved quality of life.

## Section: Discussion › Best-Performing Model With Threshold Adjustment

The GBDT_RAW model outperformed other machine learning models in this study, with thresholds adjusted to optimize model performance. The gradient boosting method analyzed nonlinear relationships and handled imbalanced data to predict diagnoses, hospital readmissions, and clinical outcomes [32-34]. During the hyperparameter tuning process, the AUPRC was considered, rather than the F1-score, without adjusting the threshold for imbalanced data [3536]. The model without resampling outperformed resampling approaches by maintaining high precision, while the sparsity of the minority class in this study probably caused resampling to introduce noise or unrealistic synthetic data, failing to improve recall. The final model then used five cutoff points on the PRC to decide optimal thresholds and percentages of positive predictions. A relatively low threshold can identify all patients at risk but may increase the number of false positives, overwhelming clinicians with numerous warnings to review. On the contrary, choosing a relatively high threshold reduces the number of false positives but increases the chances of missing true positive cases. The selected threshold increased the precision, recall, and F1-score of the model’s performance, while considering the relative costs of false positives and false negatives to meet clinical needs [37].

## Section: Discussion › Model Interpretation and Potential for Model Expansion

Similar features for predicting drug-induced thyroid dysfunction were selected by the presence of TKIs and a previous amiodarone model built by our research team [9]. The feature selection process identified age, BMI, medication duration, summed days of medication, rate of change in serum creatinine levels, and recent mean corpuscular hemoglobin, AST, and cholesterol levels as key predictors of thyroid dysfunction in this study. Interestingly, these same features were also selected in our previous amiodarone model, suggesting their potential relevance across different drug-induced thyroid dysfunction models. Similar features highlight the potential for model expansion to increase generalizability. Top-ranked features identified in this study and their contributions calculated by the SHAP analysis were aligned with clinical domain knowledge. Higher cholesterol levels were found to positively impact predictions, which can be explained by the effect of thyroid function on lipoprotein metabolism [38]. The present study also found that longer summed days of medication increased the risk of thyroid dysfunction. This finding was confirmed by a long-term safety study of sunitinib, which showed the frequency of thyroid dysfunction, unlike other adverse events, gradually increased over time [39]. The AST level and histology of clear cell carcinoma served as important predictors, which may have resulted from a relatively lower incidence of thyroid dysfunction in patients with hepatocellular carcinoma and renal cell carcinoma.

## Section: Discussion › Clinical Implications of Web-Based Drug Surveillance

ML-based drug surveillance provides a promising tool for predicting and managing thyroid dysfunction caused by TKIs. Traditional clinical decision support systems (CDSS) rely on rule-based alerts for drug interactions or contraindications but often fail to capture the multifactorial nature of drug-induced thyroid dysfunction, which depends on thyroid-related factors [40]. AI-driven CDSSs, leveraging ML algorithms, can overcome these limitations by identifying complex patterns in patient data, providing personalized risk assessments, and generating timely alerts for thyroid function monitoring. Deploying such ML models on cloud-based platforms alongside rule-based CDSSs could enhance real-time risk stratification, enabling early detection, intervention, and potential adjustments in therapy to prevent endocrine complications. Further exploration of CDSSs incorporating ML predictions are warranted to improve clinical practice and medication safety [40].

## Section: Discussion › Limitations

There are a few limitations of this study. Data were from a single healthcare system and included limited numbers of sunitinib- or sorafenib-treated patients. There were missing data in the diagnosis of comorbidities and medication use. The nature of a retrospective study introduces underestimations of the incidence of thyroid dysfunction. As a result, different features selected by the present model and our previous amiodarone model mainly resulted from features with higher missing rates. Multicenter and multicountry studies for improving model extrapolation are needed before clinical application. Future qualitative research and prospective studies with the involvement of physicians should also be conducted to assess the usability and accessibility of the model for real-world evidence.

## Section: Discussion › Conclusions

This study applied time-series data collection to capture the critical moment of sunitinib- and sorafenib-associated thyroid dysfunction for ADR surveillance. The optimal threshold can balance the precision and recall meeting clinical needs. Feature importance was explained at the population and individual levels. The web-based application increased the model accessibility, allowing clinical users to receive real-time predictions. The comparison of features with amiodarone-induced thyroid dysfunction highlighted the potential for future model expansion.


---

# Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance)

- **Issuer:** European Parliament and Council
- **Type:** EU regulation
- **Published:** 2026-07-08
- **Status:** In force
- **Language:** en
- **CELEX:** 32026R1744
- **Source:** https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32026R1744
- **Licence:** EU-reuse

## Page 1 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

REGULATION (EU) 2026/1744 OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL
of 8 July 2026
amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the 
simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus 
on AI)
(Text with EEA relevance)
THE EUROPEAN PARLIAMENT AND THE COUNCIL OF THE EUROPEAN UNION,
Having regard to the Treaty on the Functioning of the European Union, and in particular Article 114 thereof,
Having regard to the proposal from the European Commission,
After transmission of the draft legislative act to the national parliaments,
Having regard to the opinion of the European Central Bank (1),
Having regard to the opinion of the European Economic and Social Committee (2),
Having regard to the opinion of the Committee of the Regions (3),
Acting in accordance with the ordinary legislative procedure (4),
Whereas:
(1)
Regulation (EU) 2024/1689 of the European Parliament and of the Council (5) lays down harmonised rules on 
artificial intelligence (AI) and aims to improve the functioning of the internal market, to promote the uptake of 
human-centric and trustworthy AI, while ensuring a high level of protection of health, safety and fundamental rights 
and supporting innovation. Regulation (EU) 2024/1689 entered into force on 1 August 2024. The entry into 
application of its provisions is staggered, with all rules entering into application by 2 August 2027.
(2)
The experience gathered from the implementation of the parts of Regulation (EU) 2024/1689 that already apply can 
inform the implementation of those parts that are yet to apply. In this context, the delayed preparation of standards, 
which provide technical solutions for providers of high-risk AI systems to ensure compliance with their obligations 
under that Regulation, and the delayed establishment of the governance and the conformity assessment frameworks 
at national level has resulted in a compliance burden that is heavier than expected. In addition, consultations of 
stakeholders have revealed the need for additional measures to facilitate and provide clarification on implementation 
and compliance, without reducing the level of protection for health, safety and fundamental rights from AI-related 
risks that the provisions of Regulation (EU) 2024/1689 seek to achieve.
Official Journal 
of the European Union
EN 
L series
2026/1744
24.7.2026
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
1/41
(1)
OJ C, C/2026/2285, 15.4.2026, ELI: http://data.europa.eu/eli/C/2026/2285/oj.
(2)
Opinion of 18 March 2026 (not yet published in the Official Journal).
(3)
Opinion of 7 May 2026 (not yet published in the Official Journal).
(4)
Position of the European Parliament of 16 June 2026 (not yet published in the Official Journal) and decision of the Council of 
29 June 2026.
(5)
Regulation (EU) 2024/1689 of the European Parliament and of the Council of 13 June 2024 laying down harmonised rules on 
artificial intelligence and amending Regulations (EC) No 300/2008, (EU) No 167/2013, (EU) No 168/2013, (EU) 2018/858, (EU) 
2018/1139 and (EU) 2019/2144 and Directives 2014/90/EU, (EU) 2016/797 and (EU) 2020/1828 (Artificial Intelligence Act) (OJ L, 
2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj).

## Page 2 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(3)
Targeted amendments to Regulation (EU) 2024/1689 are necessary to address certain implementation challenges, 
with a view to the effective, simple and uniform application of the relevant rules.
(4)
In order to enable AI innovation in the private and public sectors, it is important that the Commission and Member 
States’ competent authorities ensure that the supervision, enforcement and monitoring of sectoral and national laws 
do not create overlaps, inconsistent interpretations or divergent enforcement.
(5)
Regulation (EU) 2024/1689 lays down horizontal rules for AI systems to ensure a consistent and high level of 
protection of public interests as regards health safety and fundamental rights. For high-risk AI systems referred to in 
Article 6(1), that Regulation applies in conjunction with the Union harmonisation legislation listed in Section A of 
Annex I. In certain cases, it is possible for such Union harmonisation legislation to lay down requirements that 
achieve the same or a higher level of protection of relevant public interests as achieved by the specific requirements 
or obligations laid down in Regulation (EU) 2024/1689. In that case, it should be possible to limit the application of 
specific requirements or obligations laid down in Regulation (EU) 2024/1689 in order to facilitate compliance, 
minimise administrative burden and duplications, while preserving the level of protection ensured by that 
Regulation. Such limitation should be possible where, and to the extent that, the Union harmonisation legislation 
listed in Section A of Annex I lays down requirements providing for an equivalent level of protection of health, safety 
or fundamental rights as the requirement or obligation concerned. The Commission should be empowered to 
adopt delegated acts to supplement that Regulation by identifying such cases and specifying the products concerned, 
the requirements or obligations that may be limited, and the conditions and scope of any limitation, ensuring that 
the level of protection provided by Regulation (EU) 2024/1689 is not reduced.
(6)
Most Union companies are small and medium-sized enterprises, the majority of which are micro and small 
enterprises. Enterprises outgrowing the micro, small and medium-sized enterprises (SMEs) definition, namely the 
‘small mid-cap enterprises’ (SMCs), play a vital role in the Union’s economy. Compared to SMEs, SMCs tend to 
demonstrate a faster pace of growth, and a higher level of innovation and digitisation. Nevertheless, they face 
challenges similar to SMEs in relation to administrative burden, leading to a need for proportionality in the 
implementation of Regulation (EU) 2024/1689 and for targeted support. To enable the smooth transition of 
enterprises from SMEs to SMCs, it is important to address in a coherent manner the effect that Regulation may have 
on their activity once those enterprises become SMCs and are faced with rules that apply to large enterprises. 
Regulation (EU) 2024/1689 provides for several measures for small-scale operators, which should be extended to 
SMCs where appropriate while safeguarding the overarching objectives and level of protection afforded under 
Regulation (EU) 2024/1689. In order to clarify the treatment of SMEs and SMCs in Regulation (EU) 2024/1689, it is 
necessary to introduce definitions for SMEs and SMCs, which should correspond to the definition set out in the 
Annex to Commission Recommendation 2003/361/EC (6) and Annex to Commission Recommendation (EU) 
2025/1099 (7), respectively.
EN
OJ L, 24.7.2026
2/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
(6)
Commission Recommendation 2003/361/EC of 6 May 2003 concerning the definition of micro, small and medium-sized 
enterprises (OJ L 124, 20.5.2003, p. 36, ELI: http://data.europa.eu/eli/reco/2003/361/oj).
(7)
Commission Recommendation (EU) 2025/1099 of 21 May 2025 on the definition of small mid-cap enterprises (OJ L, 2025/1099, 
28.5.2025, ELI: http://data.europa.eu/eli/reco/2025/1099/oj).

## Page 3 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(7)
The notion of a ‘safety component’ is crucial for the classification of certain AI systems as high-risk according to 
Regulation (EU) 2024/1689. Thus, the notion should be targeted to include only the AI systems which could have an 
adverse impact on the health and safety of persons or property, in line with the risk-based approach of that 
Regulation. The definition set out in Article 3, point (14) of Regulation (EU) 2024/1689 does not provide the 
necessary clarity to allow providers of AI systems to determine whether an AI system qualifies as a safety component 
and, as a result, risks extending the high-risk classification of AI systems beyond what is justified by the risk-based 
approach of that Regulation. It is therefore necessary to amend that definition. First, it is necessary to provide clarity 
on the concept of a ‘safety function’. The safety function should be an intended purpose of the system, which is 
determined by the provider of the system. An AI system fulfils a safety function where its intended purpose, as 
determined by the provider, is to prevent or mitigate risks to the health and safety of persons or property. In 
particular, this does not include AI systems which are intended to solely fulfil functions related to user assistance, 
performance optimisation, service efficiency, automation, convenience, or non-safety related aspects for quality 
control operations. The mere fact that an AI system is integrated into or operates within a product that is subject to 
Union harmonisation legislation does not, in itself, mean that it fulfils a safety function.
(8)
Article 4 of Regulation (EU) 2024/1689 currently imposes an obligation on all providers and deployers of AI 
systems to ensure AI literacy of their staff. Development of AI literacy starting from education and training and 
continuing in a lifelong learning manner is crucial to equip providers, deployers and other affected persons with the 
necessary skills to make informed decisions regarding the deployment of AI systems. However, experience shared by 
stakeholders reveals that a solution imposing stringent obligations to ensure a sufficient level of AI literacy would 
not be suitable for all types of providers and deployers in relation to the promotion of AI literacy. Moreover, data 
indicates that imposing such obligations creates an additional compliance burden, particularly for smaller 
enterprises, whereas AI literacy should be a strategic priority, regardless of regulatory obligations and potential 
sanctions. In light of that information, Article 4 of Regulation (EU) 2024/1689 should be amended to require 
providers and deployers to take measures to support the development of AI literacy of their staff and of other 
persons dealing with the operation and use of AI systems on their behalf. The Commission and Member States 
should support and facilitate the efforts of providers and deployers of AI systems, including through offering 
training opportunities, providing informational resources, and allowing exchange of good practices and other 
initiatives. When complying with this obligation, the Commission and the Member States could take into account 
the European competence frameworks, for example the Digital Competence Framework for Citizens (DigComp) and 
the AI Literacy Framework for Primary and Secondary Education. The European Artificial Intelligence Board (the 
Board) should support the Commission and Member States by adopting recommendations setting out common 
objectives to be achieved in order to meet their obligation and ensure regular exchange between the Commission 
and Member States on the topic, while the Apply AI Alliance should allow discussion with the wider community.
(9)
Bias detection and correction constitute a substantial public interest because they protect natural persons from the 
adverse effects of biases, including discrimination. For that reason, Regulation (EU) 2024/1689 provides a legal basis 
authorising providers of high-risk AI systems to process special categories of personal data in certain exceptional 
cases and subject to strict safeguards. This legal basis is linked to the obligation on those providers to establish 
practices concerning the detection, prevention and correction of biases likely to affect the health and safety of 
persons, have a negative impact on fundamental rights or lead to discrimination prohibited under Union law. 
Nevertheless, biases likely to have those effects could also result from the actions of the deployers of high-risk AI 
systems. Furthermore, such biases could also arise in the case of other AI systems or models. For example, biases in 
eligibility or risk-scoring tools used to assess applications for various types of public permits or licences can restrict 
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
3/41

## Page 4 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

rights or effectively prevent certain groups from accessing public services. Accordingly, a substantial public interest 
exists to allow, exceptionally and where strictly necessary, the processing of special categories of personal data for 
the purposes of bias detection and correction to providers and deployers of other AI systems and models and 
deployers of high-risk AI systems. It is therefore necessary to extend the legal basis, established pursuant to 
Regulation (EU) 2024/1689, to those providers and deployers. That legal basis should be subject to the same 
limitations, conditions and safeguards that apply in accordance with the existing Article 10(5) of that Regulation, 
thereby ensuring compliance with Article 9(2), point (g) of Regulation (EU) 2016/679 of the European Parliament 
and of the Council (8), Article 10(2), point (g) of Regulation (EU) 2018/1725 of the European Parliament and of the 
Council (9) and Article 10, point (a) of Directive (EU) 2016/680 of the European Parliament and of the Council (10). 
Furthermore, to enable providers of high-risk AI systems to lawfully undertake bias detection and correction 
activities in preparation for compliance with the requirements for high-risk AI systems, including Article 10(2), 
points (f) and (g), of Regulation (EU) 2024/1689, the legal basis established by Article 4a of Regulation 
(EU) 2024/1689 should apply from the date of entry into application of that Regulation.
(10)
Article 5 of Regulation (EU) 2024/1689 prohibits certain practices of AI systems that are particularly harmful and 
abusive, contradict certain Union values and violate certain fundamental rights. Article 5 is to be kept under review, 
as laid down in Article 112(1) of that Regulation. In light of technological and societal developments since the 
adoption of that Regulation, including the deployment and widespread use of AI systems generating non-consensual 
intimate images, videos, audio and similar material (‘non-consensual intimate material’) and child sexual abuse 
material, it is necessary to amend Article 5 of that Regulation.
(11)
Non-consensual intimate material constitutes sexual violence and abuse against individuals, in particular women. AI 
systems that generate or manipulate such material pose a severe risk to health safety and fundamental rights, 
including victims’ human dignity, personal autonomy, integrity and private life, with potentially serious lasting 
psychological and other harms, and enable abuse at scale. The proliferation of such technologies, often described as 
‘nudification’ applications, has created an urgent need for an explicit regulatory prohibition. Child sexual abuse 
material, including wholly or partially synthetic material, constitutes a grave threat to the safety and fundamental 
rights of children. AI systems generating or manipulating such material pose a grave risk to human dignity and the 
rights of the child, and risk normalising, amplifying and perpetuating sexual violence against children. Accordingly, 
an amendment to Article 5 of Regulation (EU) 2024/1689 is necessary both to protect women, children, other 
individuals and society from seriously harmful practices, thereby pursuing the objectives of that Regulation, and to 
bring clarity to providers and deployers as to the scope of their obligations, thereby addressing implementation 
challenges.
EN
OJ L, 24.7.2026
4/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
(8)
Regulation (EU) 2016/679 of the European Parliament and of the Council of 27 April 2016 on the protection of natural persons 
with regard to the processing of personal data and on the free movement of such data, and repealing Directive 95/46/EC (General 
Data Protection Regulation) (OJ L 119, 4.5.2016, p. 1, ELI: http://data.europa.eu/eli/reg/2016/679/oj)
(9)
Regulation (EU) 2018/1725 of the European Parliament and of the Council of 23 October 2018 on the protection of natural 
persons with regard to the processing of personal data by the Union institutions, bodies, offices and agencies and on the free 
movement of such data, and repealing Regulation (EC) No 45/2001 and Decision No 1247/2002/EC (OJ L 295, 21.11.2018, p. 39, 
ELI: http://data.europa.eu/eli/reg/2018/1725/oj).
(10)
Directive (EU) 2016/680 of the European Parliament and of the Council of 27 April 2016 on the protection of natural persons with 
regard to the processing of personal data by competent authorities for the purposes of the prevention, investigation, detection or 
prosecution of criminal offences or the execution of criminal penalties, and on the free movement of such data, and repealing 
Council Framework Decision 2008/977/JHA (OJ L 119, 4.5.2016, p. 89, ELI: http://data.europa.eu/eli/dir/2016/680/oj).

## Page 5 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(12)
It is necessary to define clearly the scope of the prohibition, including in particular the extent of providers’ and 
deployers’ obligations. This prohibition should not prevent providers from developing the technical capabilities of AI 
systems to generate or manipulate images, videos, audio or similar material. As concerns providers, the prohibition 
should be limited to the placing on the market or the putting into service of AI systems that generate or manipulate 
non-consensual intimate material or child sexual abuse material in two cases. First, it should cover systems intended 
to generate or manipulate such material. Second, it should cover systems where such generation or manipulation is 
a reasonably foreseeable and reproducible outcome and there are no reasonable and adequate technical safety 
measures and other safeguards in place, taking into account reasonably foreseeable misuse, to reliably prevent, and 
where necessary correct, that outcome and correct observed or reported misuse, including circumvention of such 
measures. Technical measures and other safeguards to prevent the generation of such material could include data 
cleaning, refusal training, safe prompt design and output controls, runtime prompt guardrails, content classification 
and filtering mechanisms, usage restrictions, abuse detection mechanisms, and notice and action mechanisms. Such 
preventive measures should be reasonable for the specific AI system, and are considered adequate if they align with 
the state-of-the-art measures and demonstrably prevent or sufficiently reduce in each specific case the likelihood of 
generating or manipulating such material, taking into account known and reasonably foreseeable misuse, including 
reasonably foreseeable circumvention of the preventive measures without significant technical modification. For 
providers retaining effective control over AI systems, for instance through a platform or a web interface, that could 
include following and reporting methods for misuse cases in full compliance with Union privacy and data protection 
law. In cases of observed or reported circumvention of the preventive measures or other safeguards, adequate 
corrective measures should be taken provided that such measures are reasonable, taking into account the specific AI 
system, including its release and distribution strategy (such as open-source releases). As concerns deployers, the use 
of an AI system should be prohibited only where the deployer uses an AI system for the purpose of generating or 
manipulating non-consensual intimate material or child sexual abuse material. This includes cases where a deployer 
uses or misuses AI systems placed on the market or put into service that lack reasonable and adequate preventive 
measures or where a deployer circumvents the preventive measures or uses for such purposes lawful AI systems not 
intended to generate or manipulate such material. The prohibition on use therefore does not cover the use of an AI 
system for lawful purposes, such as the generation or manipulation of material other than non-consensual intimate 
material or child sexual abuse material, even in cases where the AI system lacks reasonable and adequate safeguards 
that should have been put in place by the provider, nor does it cover accidental generation or manipulation of such 
content. Concerning the prohibition regarding non-consensual intimate material, where an AI system is intended for 
generation or manipulation of material falling under this prohibition, measures and other safeguards should include 
appropriate means for the distribution of the AI system aimed at enabling the reliable collection and demonstration 
of consent of the depicted person to such generation or manipulation, in compliance with Regulation (EU) 
2016/679. The prohibition regarding non-consensual intimate material should be limited to realistic depictions of 
intimate parts, notably the genitals, pubic area, anus, exposed buttocks or exposed female breasts, nipples or areolae, 
or of sexually explicit activity. This ‘realism’ refers to the depiction of the person’s face, voice or their body in 
a credible real-life manner, regardless of the realism of the context of that depiction or whether it fully corresponds 
to the actual voice or appearance of the depicted person. Conversely, it excludes cartoonish or physically impossible 
depictions of a person’s body. The prohibition of non-consensual intimate material does not affect the generation or 
manipulation of other forms of nude material, such as material that does not depict identifiable natural persons, 
realistic partially nude depictions where intimate parts are not revealed and sexually explicit activities are not 
depicted, or non-realistic artistic nude works that do not realistically depict identifiable natural persons engaged in 
sexually explicit activity or depict their intimate parts. It also does not cover generative AI applications where 
intimate parts are not exposed or, if exposed, this is subject to the freely given, specific, informed, unambiguous and 
explicit consent of the depicted person (for example, try-on applications and medical applications, such as medical 
anatomical simulations and mammograms); this prohibition does not preclude the exceptional use of AI systems 
generating or manipulating nude depictions of the intimate parts of an identifiable person, in accordance with 
fundamental rights law, including data protection law, and applicable medical law, for the purpose of medical 
diagnosis and treatment by medical professionals where the person concerned is incapable of consent (for instance 
in an emergency situation). Finally, the prohibition on ‘manipulating’ non-consensual intimate material excludes 
cases where pre-existing intimate material is manipulated in a way that does not increase the exposure of any 
depicted intimate parts or alter the nature of any depicted sexually explicit activities, for instance the mere 
enhancement of an existing image depicting intimate parts or video depicting sexually explicit activities, such as 
changing the background, adding a text heading or enhancing the contrast or the brightness. Conversely, any 
manipulation of material, including material that already depicts intimate parts or sexually explicit activity, that 
increases the level of exposure of any depicted intimate parts or alters the nature of any depicted sexually explicit 
activities, falls under the scope of this prohibition.
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
5/41

## Page 6 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(13)
The prohibition on child sexual abuse material should not prevent the placing on the market, putting into service or 
use of an AI system where a ‘without right’ defence applies under national law, as referred to in Article 5(1) of 
Directive 2011/93/EU of the European Parliament and of the Council (11). This includes activities carried out under 
domestic legal powers, such as the legitimate generation, or manipulation of child sexual abuse material by the 
authorities in order to conduct criminal proceedings or to prevent, detect or investigate crime, as well as the 
legitimate use of the AI system in the context of red-teaming and evaluation activities for the purpose of assessing 
the system’s compliance with the prohibition laid down in this Regulation.
(14)
These prohibitions constitute justified interferences with the freedom of expression and information and the 
freedom to conduct a business. They pursue objectives of general interest and protect the rights and freedoms of 
others, including those set out in Article 1, Article 3(1) and Articles 4, 7, 8, 21, 23 and 24 of the Charter of 
Fundamental Rights of the European Union (the Charter). They are closely tailored. In the case of intimate material, 
they are limited to realistic depictions of identifiable natural persons and to cases where the AI system is used to 
increase the level of nudity or explicitness; and exclude generation or manipulation with the person’s consent. 
Moreover, they are limited to requiring providers to implement ‘reasonable and adequate’ measures and safeguards in 
the case of systems not intended to generate or manipulate the prohibited material. They are also aligned with 
existing Union law, including Directive 2011/93/EU and Directive (EU) 2024/1385 of the European Parliament and 
of the Council (12). The interferences respect the essence of Articles 11 and 16 of the Charter, are prescribed by law, 
and are proportionate.
(15)
The conduct covered by these prohibitions may also violate other law, including criminal law. The prohibitions do 
not preclude prosecution under such law. However, insofar as an infringement of the prohibitions may result in the 
imposition of penalties of a criminal nature, which may be laid down pursuant to Article 99(1) of Regulation (EU) 
2024/1689, and to the extent that the same conduct is sanctioned under criminal law, including criminal law falling 
within the scope of Directives 2011/93/EU and (EU) 2024/1385, Member States are required to ensure respect for 
the ne bis in idem principle in accordance with the Charter.
(16)
The prohibitions are without prejudice to remedies available under national laws for individuals to protect their 
fundamental rights, including rights to their image, privacy and human dignity.
(17)
In order to ensure consistency, avoid duplication and minimise administrative burdens in relation to the procedure 
for the designation of notified bodies pursuant to Regulation (EU) 2024/1689, while maintaining the same level of 
scrutiny, a single application and a unified assessment procedure should be available for new conformity assessment 
bodies and notified bodies which are designated pursuant to the Union harmonisation legislation listed in 
Section A of Annex I to Regulation (EU) 2024/1689, such as Regulations (EU) 2017/745 (13) and (EU) 2017/746 (14)
of the European Parliament and of the Council, where such an application and procedure is established pursuant to 
that Union harmonisation legislation. The single application and unified assessment procedure aims to facilitate, 
support and expedite the designation procedure in accordance with Regulation (EU) 2024/1689, while ensuring 
compliance with the requirements applicable to notified bodies in accordance with that Regulation and the Union 
harmonisation legislation listed in Section A of Annex I thereto. The unified assessment procedure should be carried 
out with respect to the tasks and responsibilities of the authorities involved. Moreover, it should be clarified that 
a conformity assessment body that is designated pursuant to more than one piece of Union harmonisation 
legislation listed in Section A of Annex I should have to apply only once to be designated pursuant to this 
Regulation.
EN
OJ L, 24.7.2026
6/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
(11)
Directive 2011/93/EU of the European Parliament and of the Council of 13 December 2011 on combating the sexual abuse and 
sexual exploitation of children and child pornography, and replacing Council Framework Decision 2004/68/JHA (OJ L 335, 
17.12.2011, p. 1, ELI: http://data.europa.eu/eli/dir/2011/93/oj).
(12)
Directive (EU) 2024/1385 of the European Parliament and of the Council of 14 May 2024 on combating violence against women 
and domestic violence (OJ L, 2024/1385, 24.5.2024, ELI: http://data.europa.eu/eli/dir/2024/1385/oj).
(13)
Regulation (EU) 2017/745 of the European Parliament and of the Council of 5 April 2017 on medical devices, amending Directive 
2001/83/EC, Regulation (EC) No 178/2002 and Regulation (EC) No 1223/2009 and repealing Council Directives 90/385/EEC 
and 93/42/EEC (OJ L 117, 5.5.2017, p. 1, ELI: http://data.europa.eu/eli/reg/2017/745/oj).
(14)
Regulation (EU) 2017/746 of the European Parliament and of the Council of 5 April 2017 on in vitro diagnostic medical devices and 
repealing Directive 98/79/EC and Commission Decision 2010/227/EU (OJ L 117, 5.5.2017, p. 176, ELI: http://data.europa.eu/eli/ 
reg/2017/746/oj).

## Page 7 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(18)
With a view to ensuring the smooth application and consistency of Regulation (EU) 2024/1689, amendments 
should be made to it. A technical correction to Article 43(3), first subparagraph, of Regulation (EU) 2024/1689 
should be made to align the conformity assessment requirements with the requirements of providers of high-risk AI 
systems in Article 16 of that Regulation. Moreover, it should be clarified that where a provider of a high-risk AI 
system is subject to the conformity assessment procedure under Union harmonisation legislation listed in 
Section A of Annex I to Regulation (EU) 2024/1689, and the conformity assessment extends to the compliance of 
the quality management system of that Regulation and of such Union harmonisation legislation, the provider should 
be able to include aspects related to quality management systems pursuant to that Regulation as part of the quality 
management systems pursuant to such Union harmonisation legislation, in accordance with Article 17(3) of 
Regulation (EU) 2024/1689. Article 43(3), second subparagraph, of that Regulation should be amended to clarify 
that notified bodies which have been notified pursuant to the Union harmonisation legislation listed in Section A of 
Annex I to Regulation (EU) 2024/1689 and which aim to assess high-risk AI systems covered by the Union 
harmonisation legislation listed in Section A of Annex I to that Regulation, should have the power to assess the 
conformity of high-risk AI systems under certain conditions for 18 months from 27 July 2026. This amendment is 
without prejudice to Article 28 of Regulation (EU) 2024/1689, thus conformity assessment bodies that wish to be 
designated and notified pursuant to that Regulation can submit an application at any time during and after these 18 
months. Moreover, Regulation (EU) 2024/1689 should be amended to clarify that where a high-risk AI system is 
both covered by the Union harmonisation legislation listed in Section A of Annex I to Regulation (EU) 2024/1689 
and falls within one of the use-cases listed in Annex III to that Regulation, the provider should follow the relevant 
conformity assessment procedure as required under that relevant harmonisation legislation.
(19)
Regulation (EU) 2024/1689 and Regulation (EU) 2024/2847 of the European Parliament and of the Council (15)
complement each other so that the safety and cybersecurity of products with digital elements is ensured. Article 12 
of Regulation (EU) 2024/2847 states that where high-risk AI systems and processes put in place by manufacturers 
fulfil the essential cybersecurity requirements set out in Regulation (EU) 2024/2847, they should be deemed to 
comply with the cybersecurity requirements set out in Article 15 of Regulation (EU) 2024/1689 in so far as those 
requirements are covered by the EU declaration of conformity or parts thereof issued pursuant to Regulation (EU) 
2024/2847. In order to improve the visibility of the interplay of Regulation (EU) 2024/1689 and Regulation 
(EU) 2024/2847, the rule of Article 12 of Regulation (EU) 2024/2847 should also be reflected in Regulation (EU) 
2024/1689. The interplay between the two instruments should not be affected.
(20)
In accordance with Article 6(1) of Regulation (EU) 2024/1689, AI systems are classified as high-risk where an AI 
system that is a component of a product covered by Union harmonisation legislation listed in Section A of 
Annex I to that Regulation is a safety component and that product requires a third-party conformity assessment. The 
requirement that such product must require a third-party conformity assessment, however, does not affect the choice 
of the manufacturer regarding the conformity assessment procedure for such product. Where Union harmonisation 
legislation listed in Section A of Annex I allows to choose a conformity assessment procedure based on harmonised 
standards amongst conformity assessment procedures, this possibility remains applicable also to products in which 
a high-risk AI system is embedded. Article 6(1) of Regulation (EU) 2024/1689 should not be understood to require 
products in which a high-risk AI system is embedded to automatically undergo a third-party conformity assessment 
involving a notified body. Where this possibility is provided for in Union harmonisation legislation, the provider of 
the product in which the high-risk AI system is embedded could continue to rely on harmonised standards to 
comply with the requirements of the Union harmonisation legislation and Regulation (EU) 2024/1689 as 
a conformity assessment procedure.
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
7/41
(15)
Regulation (EU) 2024/2847 of the European Parliament and of the Council of 23 October 2024 on horizontal cybersecurity 
requirements for products with digital elements and amending Regulations (EU) No 168/2013 and (EU) 2019/1020 and Directive 
(EU) 2020/1828 (Cyber Resilience Act) (OJ L, 2024/2847, 20.11.2024, ELI: http://data.europa.eu/eli/reg/2024/2847/oj).

## Page 8 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(21)
In order to enhance competitiveness and innovation, it is essential to support economic operators that are required 
to comply simultaneously with the requirements or obligations set out in Chapter III, Sections 2 and 3 of Regulation 
(EU) 2024/1689, and with the relevant requirements and obligations laid down in the Union harmonisation 
legislation listed in Annex I to that Regulation. To support and simplify the regulatory compliance pathways of such 
economic operators, the Commission should request that, without undue delay, the European standardisation 
organisations develop standardisation deliverables, including, where appropriate, harmonised standards. Those 
standardisation deliverables should be based on the harmonised standards published in the Official Journal of the 
European Union that give the presumption of conformity with the requirements or obligations of Regulation (EU) 
2024/1689, as well as any relevant harmonised standards published in the Official Journal of the European Union that 
give the presumption of conformity with the relevant requirements or obligations set out in the Union 
harmonisation legislation listed in Annex I to that Regulation. Such standardisation deliverables should help reduce 
legal uncertainty, avoid unnecessary duplication of conformity assessment activities, testing, documentation and 
reporting obligations, and lower compliance costs, in particular for small and medium-sized enterprises and 
start-ups. Timely development of such deliverables is essential in order to provide economic operators with practical 
and reliable technical solutions, strengthen legal certainty and facilitate the placing on the market, putting into 
service and use of AI systems in accordance with this Regulation and the Union harmonisation legislation listed in 
Annex I to that Regulation.
(22)
To streamline compliance and reduce associated costs, the registration of AI systems referred to in Article 6(3) of 
Regulation (EU) 2024/1689 in the EU database pursuant to Article 49(2) of that Regulation should be simplified by 
streamlining the content required under Annex VIII to that Regulation. While it remains crucial for effective market 
surveillance and public accountability that such AI systems are registered in the EU database, the registration 
requirements should be simplified and made more proportionate. This simplification would strike a better balance 
without undermining the protection laid down by Regulation (EU) 2024/1689. Such AI systems are not considered 
to be high risk under certain conditions where they do not pose a significant risk of harm to the health, safety or 
fundamental rights of persons. Furthermore, a provider applying Article 6(3) of Regulation (EU) 2024/1689 remains 
obligated to document its assessment before that AI system is placed on the market or put into service. National 
competent authorities should be able to request that assessment.
(23)
Articles 57, 58 and 60 of Regulation (EU) 2024/1689 should be amended to strengthen further cooperation at 
Union level of AI regulatory sandboxes, foster clarity and consistency in the governance of AI regulatory sandboxes, 
and to extend the scope of real-world testing outside AI regulatory sandboxes to high-risk AI systems covered by the 
Union harmonisation legislation listed in Annex I to that Regulation. In particular, to allow procedural 
simplification, where applicable, in the projects supervised in the AI regulatory sandboxes that also include 
real-world testing, the real-world testing plan should be integrated into the sandbox plan agreed by the providers or 
prospective providers and the competent authority.
(24)
In addition, it is appropriate to provide for the possibility of the European Artificial Intelligence Office (AI Office) to 
establish an AI regulatory sandbox at Union level for AI systems that are covered by Article 75(1) of Regulation (EU) 
2024/1689. To ensure coherence, legal certainty and an efficient allocation of supervisory responsibilities between 
Union and national levels, the scope of the Union-level AI regulatory sandbox should be clearly defined in order to 
avoid any overlap with national AI regulatory sandboxes established pursuant to that Regulation. In order to foster 
innovation and facilitate the uptake of AI, SMEs, including startups, and SMCs should be provided with priority 
access to the AI regulatory sandboxes established by the AI Office.
EN
OJ L, 24.7.2026
8/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 9 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(25)
Moreover, the provisions on the cooperation between relevant competent authorities for the operation of an AI 
regulatory sandbox should be clarified in order to ensure their effective functioning. For that reason, the 
empowerment of the Commission to adopt implementing acts specifying the detailed arrangements for the 
establishment, development, implementation, operation and supervision of the AI regulatory sandboxes should be 
extended to also cover governance aspects of such sandboxes. In addition, where AI regulatory sandboxes involve 
innovative AI systems that process personal data or otherwise fall under the supervisory remit of other national 
authorities or competent authorities providing or supporting access to data, the relevant competent supervisory 
authorities should be associated with the operation of the AI regulatory sandbox and involved in the supervision of 
those aspects to the extent of their respective tasks and powers.
(26)
To foster innovation, it is also appropriate to extend the scope of real-world testing outside AI regulatory sandboxes 
in Article 60 of Regulation (EU) 2024/1689, currently applicable to high-risk AI systems listed in Annex III to that 
Regulation, and allow providers and prospective providers of high-risk AI systems covered by the Union 
harmonisation legislation listed in Annex I to that Regulation to also test such systems in real-world conditions, 
subject to sufficient safeguards. This is without prejudice to other Union or national law on the testing in real-world 
conditions of high-risk AI systems related to products covered by that Union harmonisation legislation.
(27)
It is also appropriate to ensure that real-world testing of high-risk AI systems covered by the Union harmonisation 
legislation listed in Section B of Annex I to Regulation (EU) 2024/1689 is possible. Those systems are subject to the 
requirements and procedures of the relevant sectoral legislation and are, for most purposes, not directly subject to 
that Regulation. Those sectoral acts will, in due course, incorporate requirements corresponding to the requirements 
set out in Articles 8 to 15 of that Regulation. Therefore, it is appropriate to ensure that Member States can allow 
real-world testing of these AI systems with a view to assessing and verifying the conformity of those systems with 
the requirements set out in Articles 8 to 15 of that Regulation. If Member States decide to allow such testing, that 
Regulation should require them to adopt frameworks setting out the detailed requirements for such testing. That 
Regulation should provide for essential elements to be contained in such frameworks. When designing such 
frameworks, Member States should ensure a high level of protection of health safety and fundamental rights of 
natural persons. Before implementing the framework, Member States should notify it to the Commission. The 
real-world testing should comply with the relevant Union harmonisation legislation listed in Section B of Annex I to 
Regulation (EU) 2024/1689, including any applicable provisions regarding testing. However, this should not affect 
the application of the new article regarding real-world testing.
(28)
Article 63 of Regulation (EU) 2024/1689 offers microenterprises who are providers of high-risk AI systems the 
possibility to benefit from a simplified way to comply with the obligation to establish a quality management system. 
With a view to facilitating compliance for more innovators, that possibility should be extended to all SMEs, including 
start-ups.
(29)
In light of the important role of the AI Office for the effective and coordinated governance of Regulation (EU) 
2024/1689, as further reinforced by this Regulation, and without prejudice to the next Multiannual Financial 
Framework and to the budgetary procedure, the Commission should allocate adequate human, financial and 
technical resources to the AI Office to ensure that it can effectively, and within reasonable timeframes, perform its 
tasks in relation to the enforcement of Regulation (EU) 2024/1689, including the allocation of a sufficient number of 
permanent personnel with in-depth competences and technical expertise.
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
9/41

## Page 10 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(30)
Article 69 of Regulation (EU) 2024/1689 should be amended to simplify the fee structure of the scientific panel. If 
Member States call upon the panel’s expertise, the fees they may be required to pay to the experts should be 
equivalent to the remuneration the Commission is obliged to pay in similar circumstances.
(31)
In order to strengthen the governance system for AI systems, it is necessary to clarify the role of the AI Office in 
monitoring and supervising the compliance of such AI systems with Regulation (EU) 2024/1689. The Commission 
has exclusive competence as regards general-purpose AI models under Article 88 of that Regulation. To increase 
coherence, clarity and effectiveness, and in light of the reach and impacts of AI systems linked to those competences, 
the scope of the AI Office’s exclusive competence to supervise systems should be refined. In particular, the AI Office 
should have exclusive competence over AI systems built on general-purpose AI models, not only where both the 
system and the model are developed by the same provider, but also where they are developed by providers that form 
part of the same undertaking. However, in certain cases, in particular where there is specific sectoral supervision, 
responsibility should remain with the relevant national competent authority. Accordingly, certain exceptions should 
be laid down. The personal scope of this exclusive competence should extend to the providers of those AI systems 
and to their deployers within the same undertaking. Other deployers should remain subject to national supervision 
and enforcement. Moreover, this does not include AI systems placed on the market, put into service or used by 
Union institutions, bodies, offices or agencies, which are under the supervision of the European Data Protection 
Supervisor pursuant to Article 74(9) of Regulation (EU) 2024/1689.
(32)
Additionally, considering the existing supervisory and enforcement system under Regulation (EU) 2022/2065 of the 
European Parliament and of the Council (16), it is appropriate to grant the Commission the powers of a competent 
market surveillance authority pursuant to Regulation (EU) 2024/1689 where an AI system qualifies as a very large 
online platform or a very large online search engine in accordance with Regulation (EU) 2022/2065, or where it is 
embedded in such a platform or search engine. This should contribute to ensuring that the exercise of the 
Commission’s supervision and enforcement powers pursuant to Regulation (EU) 2024/1689 and Regulation (EU) 
2022/2065, as well as those applicable to general-purpose AI models integrated into such platforms or search 
engines, is carried out in a coherent and effective manner. This is also appropriate in light of the importance of such 
platforms and search engines, in view of their reach, impact and potential to cause complex and large societal harms. 
The personal scope of this exclusive competence should extend to the providers of those AI systems and to their 
deployers within the same undertaking. In the case of AI systems embedded in or qualifying as a very large online 
platform or search engine, the first point of entry for the assessment of the AI systems are the risk assessment, 
mitigating measures and audit obligations prescribed by Articles 34, 35 and 37 of Regulation (EU) 2022/2065, 
without prejudice to the AI Office’s powers to investigate and enforce ex post non-compliance with the rules of 
Regulation (EU) 2024/1689. In the context of the analysis of this risk assessment, mitigating measures and audits, 
the Commission services responsible for the enforcement of Regulation (EU) 2022/2065 may seek the opinion of 
the AI Office on the outcome of a potential earlier or parallel risk assessment carried out in accordance with 
Regulation (EU) 2024/1689 and the applicability of prohibitions pursuant to Regulation (EU) 2024/1689. In 
addition, the AI Office and the competent national authorities should, in accordance with Regulation 
(EU) 2024/1689, coordinate their enforcement efforts with the authorities competent for the supervision and 
enforcement of Regulation (EU) 2022/2065, including the Commission, in order to ensure that the principles of 
loyal cooperation, proportionality and ne bis in idem are respected, while information obtained pursuant to one 
Regulation is to be used for the purposes of supervision and enforcement of the other only provided the undertaking 
agrees. In particular, those authorities should exchange views regularly and take into account, in their respective 
areas of competence, any fines and penalties imposed on the same provider for the same conduct through a final 
decision in proceedings relating to an infringement of other Union or national rules, so as to ensure that the overall 
fines and penalties imposed are proportionate and correspond to the seriousness of the infringements committed.
EN
OJ L, 24.7.2026
10/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
(16)
Regulation (EU) 2022/2065 of the European Parliament and of the Council of 19 October 2022 on a Single Market For Digital 
Services and amending Directive 2000/31/EC (Digital Services Act) (OJ L 277, 27.10.2022, p. 1, ELI: http://data.europa.eu/eli/reg/ 
2022/2065/oj).

## Page 11 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(33)
When supervising and enforcing obligations in relation to AI systems under its competence, the AI Office has the 
same role and responsibility as a market surveillance authority pursuant to Regulation (EU) 2024/1689. 
Consequently, it is necessary for the AI Office to have all of the powers and responsibilities that market surveillance 
authorities have pursuant to that Regulation and Regulation (EU) 2019/1020 of the European Parliament and of the 
Council (17) (‘the general powers’). These should ensure the appropriate and effective enforcement of the 
requirements and obligations set out in Regulation (EU) 2024/1689. However, it is necessary to specify, 
complement, and frame certain essential elements and other aspects of the general powers, as well as their 
safeguards (‘the specifying provisions’). In particular, it is necessary to lay down provisions governing the 
relationship between the AI Office and national authorities; provisions specifying, complementing, and constraining 
the powers to request information and conduct on-site inspections; provisions governing investigations, including 
the possibility to make commitments binding; and provisions specifying and constraining power to find 
non-compliance, impose fines and impose periodic penalties. Where a type of general power has been so specified, 
the AI Office may not circumvent the conditions and limits of those powers by relying on a related general power. 
Conversely, types of general power that are not specified and framed in respect of the AI Office, such as the power to 
adopt measures referred to in Article 16(3) of Regulation (EU) 2019/1020, may be relied on by the AI Office. As 
necessary for the proper implementation of Regulation (EU) 2024/1689, the Commission should be able to 
adopt implementing acts further defining the rules and the procedures concerning the application of limitation 
periods and, the access to the file and the negotiated disclosure of information. In exercising all of these powers, the 
AI Office must comply with the Charter. Additionally, the AI Office is subject to the safeguards and protection for 
fundamental rights laid down in the specifying provisions.
(34)
In addition to those procedural and fundamental rights safeguards the procedural rights provided for in Article 18 of 
Regulation (EU) 2019/1020 should apply mutatis mutandis to providers of AI systems, without prejudice to more 
specific procedural rights provided for in Regulation (EU) 2024/1689. When national market surveillance 
authorities, through the single point of contact, request that the AI Office takes supervisory and enforcement 
measures with regards to AI systems under its exclusive supervision, the AI Office should no later than four months 
following the receipt of that request, inform the single point of contact of its intention to exercise its supervisory and 
enforcement powers or of its reasons for not exercising its powers. If the AI Office decides to exercise its supervisory 
and enforcement powers, it should also inform the single point of contact about the final outcome of such 
proceedings and of intermediate developments that the AI Office considers as having a major impact in the 
investigation, including the decision to open proceedings, to impose a fine, and to withdraw or recall the AI system 
from the market.
(35)
To enable access to the Union market for AI systems which are under the supervision of the AI Office pursuant to 
Article 75 of Regulation (EU) 2024/1689 and subject to a third party conformity assessment, the Commission 
should be responsible for the pre-market conformity assessments of those systems.
(36)
Article 77 and related provisions of Regulation (EU) 2024/1689 constitute an important governance mechanism, as 
they aim to enable authorities or bodies responsible for enforcing or supervising Union law intended to protect 
fundamental rights to fulfil their mandate under specific conditions and to foster cooperation with market 
surveillance authorities responsible for the supervision and enforcement of that Regulation. It is necessary to clarify 
the scope of such cooperation, as well as to clarify which public authorities or bodies benefit from it. With a view to 
reinforcing cooperation, it should be clarified that requests to access information and documentation should be 
made to the competent market surveillance authority, which should respond to such requests without undue delay, 
and that the authorities or bodies involved should have a mutual obligation to cooperate. It should be clarified that 
these provisions are without prejudice to the competences, tasks, powers and independence of the relevant national 
public authorities or bodies under their mandates. In particular, those provisions do not limit any powers that those 
authorities and bodies have to request information pursuant to other Union or national law. Accordingly, those 
authorities and bodies retain any power they have to directly request information from operators pursuant to their 
mandate or Union or national law.
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
11/41
(17)
Regulation (EU) 2019/1020 of the European Parliament and of the Council of 20 June 2019 on market surveillance and compliance 
of products and amending Directive 2004/42/EC and Regulations (EC) No 765/2008 and (EU) No 305/2011 (OJ L 169, 25.6.2019, 
p. 1, ELI: http://data.europa.eu/eli/reg/2019/1020/oj).

## Page 12 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(37)
The requirements for high-risk AI systems laid down in Regulation (EU) 2024/1689 address specific risks inherent to 
AI systems, including bias, unpredictable model behaviour, poor robustness or accuracy, vulnerabilities to attacks by 
third parties, and a lack of transparency of the AI system. By addressing AI-specific risks, that Regulation 
complements the requirements laid down in Union harmonisation legislation listed in Annex I to that Regulation, 
without duplicating them. Regulation (EU) 2024/1689 provides mechanisms for economic operators to minimise 
the compliance burden. In particular, Article 8(2) on the interplay with the sectoral legislation, Article 9(10) on risk 
management and Article 17(3) on quality management, allow economic operators to integrate, when necessary and 
appropriate, an assessment of AI-specific risks into existing risk and quality management systems. Article 40 of 
Regulation (EU) 2024/1689 further requires the Commission to specify that harmonised standards developed 
pursuant to that Regulation are to be consistent with standards developed pursuant to the Union harmonisation 
legislation listed in Annex I to that Regulation. The Commission should provide guidelines to assist economic 
operators of high-risk AI systems covered in Annex I to Regulation (EU) 2024/1689 in complying with that 
Regulation, including by providing guidance on the application of Article 8(2), Article 9(10) and Article 17(3) of 
that Regulation as mechanisms to minimise the compliance burden, in line with principles of complementarity and 
proportionality. Those guidelines should be published, at the latest, by 1 August 2027.
(38)
To allow sufficient time for providers of generative AI systems subject to the marking obligations laid down in 
Article 50(2) of Regulation (EU) 2024/1689 to adapt their practices within a reasonable time without disrupting the 
market, it is appropriate to introduce a transitional period of four months for providers who have already placed 
their systems on the market before the 2 August 2026.
(39)
To provide sufficient time for providers of high-risk AI systems and to clarify rules applicable to the AI systems 
already placed on the market or put into service before the relevant provisions of Regulation (EU) 2024/1689 apply, 
it is appropriate to clarify the scope of the grace period provided in Article 111(2) of that Regulation. For the 
purpose of that Article 111(2), the grace period should apply where the type and model of AI system has already 
been placed on the market. This means that if at least one individual unit of the high-risk AI system has been lawfully 
placed on the market or put into service before the date specified in Article 111(2), other individual units of the 
same type and model of high-risk AI system are subject to the grace period provided in that Article 111(2) and thus 
may continue to be placed on the market, made available or put into service on the Union market without any 
additional obligations, requirements or the need for additional certification, as long as the design of that high-risk AI 
system remains unchanged. For the purposes of the application of the grace period provided in Article 111(2), the 
decisive factor is the date on which the first unit of that type and model of high-risk AI system was placed on the 
market or put into service on the Union market for the first time. Any significant change to the design of that AI 
system after the date specified in Article 111(2) should trigger the obligation of the provider to fully comply with all 
relevant provisions of that Regulation applicable to high-risk AI systems, including the conformity assessment 
requirements.
(40)
Article 113 of Regulation (EU) 2024/1689 establishes the dates of entry into force and application of that 
Regulation, in particular that the general date of application is 2 August 2026. For the obligations related to 
high-risk AI systems laid down in Sections 1, 2 and 3 of Chapter III of Regulation (EU) 2024/1689, the delayed 
availability of standards, common specifications, and alternative guidance and the delayed establishment of national 
competent authorities lead to challenges that jeopardise the effective entry into application of those obligations and 
that risk a significant increase in implementation costs in a way that does not justify maintaining their initial date of 
application, namely 2 August 2026. Therefore, it is appropriate that the date of application of Sections 1, 2 and 3 of 
Chapter III is set to 2 December 2027 for AI systems classified as high-risk pursuant to Article 6(2) and Annex III, 
and to 2 August 2028 for AI systems classified as high-risk pursuant to Article 6(1) and Annex I. The distinction 
between the entry into application of the rules as regards AI systems classified as high-risk pursuant to Article 6(2) 
and Annex III and Article 6(1) and Annex I to that Regulation is consistent with the difference between the initial 
dates of application envisaged in Regulation (EU) 2024/1689 and aims to provide the necessary time for adaptation 
and implementation of the corresponding obligations. The timely availability of support instruments, including 
guidance, relevant standards, common specifications and codes of practice is important in order to facilitate 
compliance and reduce the risk of divergent interpretation and uneven application of the rules across Member States. 
In order to ensure legal certainty and to avoid further delays in the application of Regulation (EU) 2024/1689, the 
Commission should ensure that measures in support of compliance with regard to Chapter III, Sections 1, 2, and 3 
of that Regulation are in place in due time to ensure timely and effective implementation of the necessary provisions.
EN
OJ L, 24.7.2026
12/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 13 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(41)
In light of the objective to reduce implementation challenges for citizens, businesses and public administrations, it is 
essential that harmonised conditions for the implementation of certain rules are adopted only where strictly 
necessary. For that purpose, it is appropriate to remove certain empowerments bestowed on the Commission to 
adopt such harmonised conditions by means of implementing acts in cases where that is not the case. Article 50(7), 
Article 56(6), and Article 72(3) of Regulation (EU) 2024/1689 should therefore be amended to remove the 
empowerments conferred on the Commission to adopt implementing acts. Given that the codes of practice referred 
to in Article 50(7) and Article 56(6) have limited legal effect, and in particular do not grant a presumption of 
conformity, it is not strictly necessary for these codes to be approved by an implementing act. Providers should be 
able to rely, pursuant to Article 53(4) and Article 54(2) of Regulation (EU) 2024/1689, on codes of practice assessed 
as adequate pursuant to Article 56(6) thereof. The removal of the empowerment to adopt a harmonised template for 
a post-market monitoring plan in Article 72(3) of Regulation (EU) 2024/1689 has the additional benefit of offering 
more flexibility for providers of high-risk AI systems to put in place a system for post-market monitoring that is 
tailored to their organisation. At the same time, recognising the need to offer clarity regarding how providers of 
high-risk AI systems are required to comply with their obligation set out in Article 72(1) of Regulation (EU) 
2024/1689, the Commission should be required to publish guidance, including a voluntary template, on the 
post-market monitoring plan by 2 September 2027.
(42)
The use of artificial intelligence in machinery can help foster innovation and improve the efficiency of those 
machines. The application of Regulation (EU) 2023/1230 of the European Parliament and of the Council (18) and 
Regulation (EU) 2024/1689 might lead to overlaps. At the same time, it is important to ensure a level of protection 
with regard to risks related to the use of artificial intelligence in machinery that is consistent with the level of 
protection provided in Regulation (EU) 2024/1689 with regard to high-risk AI systems. Given the specific nature of 
machinery and the machinery sector, and in order to address the need to simplify the regulatory framework for 
AI-enabled machinery, it is appropriate to move to a sectoral approach by moving Regulation (EU) 2023/1230 from 
Section A to Section B of Annex I to Regulation (EU) 2024/1689. Accordingly, first, the application of Regulation 
(EU) 2024/1689 to those machines should be limited to the provisions referred to in Article 2(2) of that Regulation. 
The reference to Directive 2006/42/EC should be moved from Section A to Section B of Annex I to Regulation 
(EU) 2024/1689 and updated so as to refer to Regulation (EU) 2023/1230. Second, it is crucial to ensure that 
Regulation (EU) 2023/1230 incorporates essential health and safety requirements for high-risk AI systems classified 
pursuant to Article 6(1) of Regulation (EU) 2024/1689 and used as a safety component in machinery or high-risk AI 
systems constituting machinery that ensure a level of protection consistent with Regulation (EU) 2024/1689. To that 
end, the Commission should be required to adopt delegated acts amending Annex III to Regulation (EU) 2023/1230 
in order to reflect the relevant requirements set out in Chapter III, Section 2, and Articles 17, 19, 72 and 73 of 
Regulation (EU) 2024/1689. To avoid a legal gap and ensure alignment with the entry into application of the 
relevant high-risk AI system rules set out in Regulation (EU) 2024/1689, those delegated acts should apply by 
2 August 2028. For the same reasons, manufacturers should be free to rely on harmonised standards or common 
specifications referenced or adopted pursuant to Regulation (EU) 2024/1689 that cover the relevant essential 
requirements for the presumption of conformity within the meaning of Article 20 of Regulation (EU) 2023/1230 
until harmonised standards or common specifications regarding AI are referenced or adopted pursuant to 
Regulation (EU) 2023/1230.
(43)
Conformity assessments of high-risk AI systems pursuant to Regulation (EU) 2024/1689 can require the 
involvement of conformity assessment bodies. Only conformity assessment bodies that have been designated 
pursuant to that Regulation are able to carry out conformity assessments, and only for the activities related to the 
categories and types of AI systems concerned. To enable the specification of the scope of the designation of 
conformity assessment bodies notified pursuant to Article 30 of Regulation (EU) 2024/1689, it is necessary to draw 
up a list of codes, categories, and corresponding types of AI systems. The list of codes should take into account 
whether the AI system is a component of a product or itself a product covered by the Union harmonisation 
legislation listed in Annex I to Regulation (EU) 2024/1689 (referred to as ‘AIP codes’, for AI systems covered by 
product legislation), or a system listed in Annex III to that Regulation, which currently concerns only biometric AI 
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
13/41
(18)
Regulation (EU) 2023/1230 of the European Parliament and of the Council of 14 June 2023 on machinery and repealing Directive 
2006/42/EC of the European Parliament and of the Council and Council Directive 73/361/EEC (OJ L 165, 29.6.2023, p. 1, 
ELI: http://data.europa.eu/eli/reg/2023/1230/oj).

## Page 14 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

systems referred to in point (1) of Annex III (referred to as ‘AIB codes’, for biometric AI systems). Both AIP codes and 
AIB codes are vertical codes. The AIP codes are reference codes that provide a link to the Union harmonisation 
legislation listed in Section A of Annex I to Regulation (EU) 2024/1689. The AIB codes are new codes specific to 
Regulation (EU) 2024/1689 that identify biometric AI systems referred to in point (1) of Annex III to that 
Regulation. The list of codes should also take into account specific types and underlying technologies of AI systems 
(referred to as ‘AIH codes’, for horizontal AI system codes). The AIH codes are new AI technology-specific codes and 
can be applied in conjunction with AIP or AIB vertical codes. The AIH codes cover the underlying types and 
technologies of AI systems. The list of codes, comprising three categories, should provide for a multi-dimensional 
typology of AI systems which ensures that conformity assessment bodies designated as notified bodies are fully 
competent in regard to the AI systems they are required to assess.
(44)
Regulation (EU) 2018/1139 of the European Parliament and the Council (19) lays down common rules in the field of 
civil aviation. Article 108 of Regulation (EU) 2024/1689 amends Regulation (EU) 2018/1139 to ensure that the 
Commission, when adopting any relevant delegated or implementing acts pursuant to Regulation (EU) 2018/1139, 
takes into account, on the basis of the technical and regulatory specificities of the civil aviation sector, and without 
interfering with existing governance, conformity assessment and enforcement mechanisms and authorities 
established therein, the mandatory requirements for high-risk AI systems laid down in Regulation (EU) 2024/1689. 
A technical correction to amend additional Articles of Regulation (EU) 2018/1139 is necessary to ensure that the 
mandatory requirements for high-risk AI systems laid down in Regulation (EU) 2024/1689 are fully covered when 
adopting relevant delegated or implementing acts pursuant to Regulation (EU) 2018/1139.
(45)
In order to amend certain non-essential elements of Regulations (EU) 2024/1689 and (EU) 2023/1230, the power to 
adopt acts in accordance with Article 290 of the Treaty on the Functioning of the European Union should be 
delegated to the Commission in respect of:
— limiting the application of specific requirements or obligations laid down in Regulation (EU) 2024/1689 where 
Union harmonisation legislation listed in Section A of Annex I of that Regulation lays down requirements 
providing for an equivalent level of protection,
— amending the list of codes, categories, and corresponding types of AI systems in Annex XIV of Regulation (EU) 
2024/1689, and
— amending Annex III of Regulation (EU) 2023/1230 to reflect the relevant requirements of Regulation (EU) 
2024/1689.
It is of particular importance that the Commission carry out appropriate consultations during its preparatory work, 
including at expert level, and that those consultations be conducted in accordance with the principles laid down in 
the Interinstitutional Agreement of 13 April 2016 on Better Law-Making (20). In particular, to ensure equal 
participation in the preparation of delegated acts, the European Parliament and the Council receive all documents at 
the same time as Member States’ experts, and their experts systematically have access to meetings of Commission 
expert groups dealing with the preparation of delegated acts.
EN
OJ L, 24.7.2026
14/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
(19)
Regulation (EU) 2018/1139 of the European Parliament and of the Council of 4 July 2018 on common rules in the field of civil 
aviation and establishing a European Union Aviation Safety Agency, and amending Regulations (EC) No 2111/2005, (EC) 
No 1008/2008, (EU) No 996/2010, (EU) No 376/2014 and Directives 2014/30/EU and 2014/53/EU of the European Parliament 
and of the Council, and repealing Regulations (EC) No 552/2004 and (EC) No 216/2008 of the European Parliament and of the 
Council and Council Regulation (EEC) No 3922/91(OJ L 212, 22.8.2018, p. 1, ELI: http://data.europa.eu/eli/reg/2018/1139/oj).
(20)
OJ L 123, 12.5.2016, p. 1, ELI: http://data.europa.eu/eli/agree_interinstit/2016/512/oj.

## Page 15 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(46)
In order to ensure legal certainty without delay, with a view to the imminent general application of Regulation (EU) 
2024/1689, this Regulation should enter into force as a matter of urgency on the third day following that of its 
publication in the Official Journal of the European Union.
(47)
The European Data Protection Supervisor and the European Data Protection Board were consulted in accordance 
with Article 42(1) and (2) of Regulation (EU) 2018/1725 and delivered their joint opinion on 20 January 2026,
HAVE ADOPTED THIS REGULATION:
Article 1
Amendments to Regulation (EU) 2024/1689
Regulation (EU) 2024/1689 is amended as follows:
(1)
in Article 1(2), point (g) is replaced by the following:
‘(g) measures to support innovation, with a particular focus on small mid-cap enterprises (SMCs) and small and 
medium-sized enterprises (SMEs), including start-ups.’;
(2)
Article 2 is amended as follows:
(a) paragraph 2 is replaced by the following:
‘2.
For AI systems classified as high-risk AI systems in accordance with Article 6(1) related to products covered 
by the Union harmonisation legislation listed in Section B of Annex I, only Article 6(1), Article 60a and 
Articles 102 to 112 shall apply. Articles 57, 58 and 59 shall apply only in so far as the requirements for high-risk 
AI systems under this Regulation have been integrated in that Union harmonisation legislation.’;
(b) paragraph 7 is replaced by the following:
‘7.
Union law on the protection of personal data, privacy and the confidentiality of communications applies to 
personal data processed in connection with the rights and obligations laid down in this Regulation. Without 
prejudice to Articles 4a and 59 of this Regulation, this Regulation shall not affect Regulation (EU) 2016/679 or 
(EU) 2018/1725, or Directive 2002/58/EC or (EU) 2016/680.’;
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
15/41

## Page 16 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(3)
in Article 2, the following paragraph is added:
‘13.
For high-risk AI systems referred to in Article 6(1), the application of specific requirements or obligations laid 
down in Articles 9 to 15 and 17 to 25 may be limited, where and to the extent that:
(a) Union harmonisation legislation listed in Section A of Annex I lays down requirements or obligations providing an 
equivalent or higher level of protection of health, safety or fundamental rights as the requirement or obligation 
concerned; and
(b) such limitation does not reduce the overall level of protection provided for by this Regulation.
By 2 August 2027, the Commission shall adopt delegated acts in accordance with Article 97 in order to supplement 
this Regulation by specifying the high-risk AI systems concerned, the requirements or obligations that may be limited, 
the conditions under which such limitation applies, and the scope of the limitation.’;
(4)
Article 3 is amended as follows:
(a) point (14) is amended as follows:
‘(14) “safety component” means a component of a product or of an AI system which fulfils a safety function for 
that product or AI system, or the failure or malfunctioning of which endangers the health and safety of 
persons or property; for the purposes of this definition, a component fulfils a safety function where its 
intended purpose is to prevent or mitigate risks to health and safety of persons or property;’;
(b) the following points are inserted:
‘(14a) “micro, small and medium-sized enterprise” or “SME” means a micro, small or medium-sized enterprise as 
defined in Article 2 of the Annex to Recommendation 2003/361/EC;
(14b) “small mid-cap enterprise” or “SMC” means a small mid-cap enterprise as defined in point (2) of the Annex 
to Recommendation (EU) 2025/1099;’;
(5)
Article 4 is replaced by the following:
‘Article 4
AI literacy
1.
Providers and deployers of AI systems shall take measures to support the development of AI literacy of their staff 
and other persons dealing with the operation and use of AI systems on their behalf, taking into account their technical 
knowledge, experience, education and training and the context the AI systems are to be used in, and considering the 
persons or groups of persons on whom the AI systems are to be used. This obligation does not require providers or 
deployers to guarantee any specific level of AI literacy of any individual.
2.
The Commission and the Member States shall support and facilitate the efforts of providers and deployers of AI 
systems, in particular SMEs, in fulfilling their obligation under paragraph 1 of this Article. For that purpose, the 
Commission shall publish practical examples of how to comply with that obligation on the single information 
platform referred to in Article 62(3), point (b).
3.
The Board shall adopt recommendations, taking into account European competence frameworks, to support the 
Commission and Member States in the promotion of AI literacy required under paragraph 1, including by setting out 
common objectives.’;
EN
OJ L, 24.7.2026
16/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 17 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(6)
the following Article is inserted:
‘Article 4a
Processing of special categories of personal data for bias detection and correction
1.
To the extent strictly necessary to ensure bias detection and correction in relation to high-risk AI systems in 
accordance with Article 10(2), points (f) and (g), of this Regulation, providers of such systems may exceptionally 
process special categories of personal data, subject to appropriate safeguards for the fundamental rights and freedoms 
of natural persons. In addition to the provisions set out in Regulations (EU) 2016/679 and (EU) 2018/1725 and 
Directive (EU) 2016/680, as applicable, all the following conditions shall be met in order for such processing to occur:
(a) the bias detection and correction cannot be effectively fulfilled by processing other data, including synthetic or 
anonymised data;
(b) the special categories of personal data are subject to technical limitations on the re-use of personal data, and 
state-of-the-art security and privacy-preserving measures, including pseudonymisation;
(c) the special categories of personal data are subject to measures to ensure that the personal data processed are 
secured and protected, subject to suitable safeguards, including strict controls and documentation of the access, to 
avoid misuse and to ensure that only authorised persons have access to those personal data with appropriate 
confidentiality obligations;
(d) the special categories of personal data are not transmitted, transferred or otherwise accessed by other parties;
(e) the special categories of personal data are deleted once the bias has been corrected or the personal data has reached 
the end of its retention period, whichever comes first; and
(f) the records of processing activities pursuant to Regulations (EU) 2016/679 and (EU) 2018/1725 and Directive 
(EU) 2016/680 include the reasons why the processing of special categories of personal data was strictly necessary 
to detect and correct biases, and why that objective could not be achieved by processing other data.
2.
Providers and deployers of other AI systems and models and deployers of high-risk AI systems may exceptionally 
process special categories of personal data to the extent that:
(a) such processing is strictly necessary to ensure bias detection and correction in view of possible biases that are 
likely to affect the health and safety of persons, have a negative impact on fundamental rights or lead to 
discrimination prohibited pursuant to Union law, especially where data outputs influence inputs for future 
operations; and
(b) all of the conditions and safeguards set out in paragraph 1 are applied.
This paragraph does not create any obligation to conduct such bias detection and correction.’;
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
17/41

## Page 18 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(7)
Article 5 is amended as follows:
(a) in paragraph 1, the first subparagraph, the following points are inserted:
‘(ba) the placing on the market, the putting into service or the use of an AI system that generates or manipulates 
realistic images, videos, audio or similar material of an identifiable natural person’s intimate parts, or of an 
identifiable natural person engaged in sexually explicit activities, without that person’s freely-given, specific, 
informed, unambiguous and explicit consent for that generation or manipulation;
(bb) the placing on the market, the putting into service or the use of an AI system that generates or manipulates 
material or performance within the meaning of Article 2, points (c) and (e), of Directive 2011/93/EU, except 
where a “without right” defence applies under national law;’;
(b) the following paragraphs are inserted:
‘1a.
For the purposes of paragraph 1, first subparagraph, points (ba) and (bb):
(a) the placing on the market or putting into service of an AI system that generates or manipulates the material or 
performance referred to in paragraph 1, first subparagraph, point (ba) or (bb) is only prohibited where:
(i) that generation or manipulation is the intended purpose of the AI system; or
(ii) the system’s design, training, architecture, capabilities or user-facing functionalities make that generation or 
manipulation a reasonably foreseeable and reproducible outcome, without requiring significant technical 
modification, and the system does not have reasonable and adequate technical safety measures and other 
safeguards to reliably prevent that generation or manipulation, taking into account reasonably foreseeable 
misuse, and to correct observed or reported misuse;
(b) the use of an AI system that generates or manipulates the material or performance referred to in paragraph 1, 
first subparagraph, points (ba) and (bb) is only prohibited where the deployer uses the system for the purpose 
of generating or manipulating such material or performance.
1b.
For the purposes of paragraph 1, first subparagraph, point (ba), an AI system that manipulates material in 
a way that does not increase the exposure of any depicted intimate parts or alter the nature of any depicted 
sexually explicit activities shall not constitute manipulation.’;
(8)
in Article 6, the following paragraphs are inserted:
‘1a.
For the purposes of this Regulation, including paragraph 1 of this Article, AI systems that are solely used for 
non-safety related aspects of user assistance, performance optimisation, service efficiency, automation or convenience 
or quality control shall not qualify as safety components.
1b.
Notwithstanding paragraph 1a, AI systems the failure or malfunctioning of which would endanger health and 
safety shall qualify as safety components.
1c.
A product that is required to undergo a third-party conformity assessment solely due to risks other than risks to 
health and safety, in particular risks relating to the distribution of radio spectrum or electromagnetic interference that 
do not affect health and safety, shall not be considered as fulfilling the condition in paragraph 1, point (b).’;
EN
OJ L, 24.7.2026
18/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 19 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(9)
Article 10 is amended as follows:
(a) paragraph 1 is replaced by the following:
‘1.
High-risk AI systems which make use of techniques involving the training of AI models with data shall be 
developed on the basis of training, validation and testing data sets that meet the quality criteria referred to in 
paragraphs 2, 3 and 4 of this Article and in Article 4a(1) whenever such data sets are used.’;
(b) paragraph 5 is deleted;
(c) paragraph 6 is replaced by the following:
‘6.
For the development of high-risk AI systems not using techniques involving the training of AI models, 
paragraphs 2, 3 and 4 of this Article and Article 4a(1) shall apply only to the testing data sets.’;
(10) in Article 11(1), the second subparagraph is replaced by the following:
‘That technical documentation shall be drawn up in such a way as to demonstrate that the high-risk AI system 
complies with the requirements set out in this Section and to provide national competent authorities and notified 
bodies with the necessary information in a clear and comprehensive form to assess the compliance of the AI system 
with those requirements. It shall contain, at a minimum, the elements set out in Annex IV. SMEs, including start-ups, 
and SMCs, may provide the elements of the technical documentation specified in Annex IV in a simplified manner. To 
that end, the Commission shall establish a simplified technical documentation form targeted at the needs of SMEs, 
including start-ups, and SMCs. Where an SME, including a start-up, or an SMC, opts to provide the information 
required in Annex IV in a simplified manner, it shall use the form referred to in this paragraph. Notified bodies shall 
accept the form for the purposes of the conformity assessment.’;
(11) in Article 17, paragraph 2 is replaced by the following:
‘2.
The implementation of the aspects referred to in paragraph 1 shall be proportionate to the size of the provider’s 
organisation, in particular, if the provider is an SME, including a start-up, or an SMC. Providers shall, in any event, 
respect the degree of rigour and the level of protection required to ensure the compliance of their high-risk AI systems 
with this Regulation.’;
(12) Article 25 is amended as follows:
(a) paragraph 2 is replaced by the following:
‘2.
Where the circumstances referred to in paragraph 1 occur, the provider that initially placed the AI system on 
the market or put it into service shall no longer be considered to be a provider of that specific AI system for the 
purposes of this Regulation.
That initial provider shall closely cooperate with new providers and shall make available the necessary information 
and provide the reasonably expected technical access and other assistance that are required for the fulfilment of the 
obligations set out in this Regulation, in particular with regard to compliance with the conformity assessment of 
high-risk AI systems.
In particular, the obligation laid down in the second subparagraph shall include, where relevant for the purposes 
specified therein, the following:
(a) making available of technical documentation sufficient to assess compliance with the requirements laid down 
in Article 16;
(b) informing the new providers about known limitations and failure modes; and
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
19/41

## Page 20 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(c) providing the new providers with targeted technical access, including for testing and validation.
This paragraph shall not apply in cases where the initial provider has clearly specified that its AI system is not to be 
changed into a high-risk AI system and therefore does not fall under the obligation to cooperate with the new 
providers and hand over the documentation.’;
(b) in paragraph 4, the first subparagraph is replaced by the following:
‘4.
The provider of a high-risk AI system and the third party that supplies an AI system, AI model, tools, 
services, components, or processes that are used or integrated in a high-risk AI system shall, by written agreement, 
specify the necessary information, capabilities, technical access and other assistance based on the generally 
acknowledged state of the art, in order to enable the provider of the high-risk AI system to fully comply with the 
obligations set out in this Regulation. This paragraph shall not apply to third parties making accessible to the 
public tools, services, processes, or components, other than general-purpose AI models, under a free and 
open-source licence.’;
(13) Article 27 is amended as follows:
(a) paragraph 4 is replaced by the following:
‘4.
If any of the obligations laid down in this Article is already met through the data protection impact 
assessment conducted pursuant to Article 35 of Regulation (EU) 2016/679 or Article 27 of Directive (EU) 
2016/680, the deployer may, when conducting the fundamental rights impact assessment referred to in 
paragraph 1 of this Article, include cross-references to the relevant sections of that data protection impact 
assessment or include relevant parts thereof in the fundamental rights impact assessment.’;
(b) paragraph 5 is replaced by the following:
‘5.
The AI Office shall develop a template for a questionnaire, including through an automated tool, to facilitate 
deployers in complying with their obligations under this Article in a simplified manner. This template shall, where 
relevant, give deployers the possibility to include cross-references to the relevant sections of the data protection 
impact assessment or include relevant parts thereof in the fundamental rights impact assessment pursuant to 
paragraph 4.’;
(14) in Article 28, the following paragraphs are added:
‘8.
Notifying authorities designated pursuant to this Regulation that are responsible for AI systems covered by the 
Union harmonisation legislation listed in Section A of Annex I shall ensure that the conformity assessment body that 
applies for designation both pursuant to this Regulation and the Union harmonisation legislation listed in Section A of 
Annex I is provided with the possibility to submit a single application and undergoes a unified assessment procedure 
to be designated pursuant to this Regulation and Union harmonisation legislation listed in Section A of Annex I, where 
the relevant Union harmonisation legislation provides for such single application and unified assessment procedure. 
To that end, notifying authorities designated pursuant to this Regulation and those designated pursuant to the Union 
harmonisation legislation listed in Section A of Annex I shall cooperate in their assessments.
The single application and the unified assessment procedure referred to in this paragraph shall also be made available 
to notified bodies already designated pursuant to the Union harmonisation legislation listed in Section A of Annex I, 
when those notified bodies apply for designation pursuant to this Regulation, provided that the relevant Union 
harmonisation legislation provides for such a procedure.
EN
OJ L, 24.7.2026
20/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 21 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

A conformity assessment body that is designated pursuant to more than one piece of Union harmonisation legislation 
listed in Section A of Annex I shall have to apply only once to be designated pursuant to this Regulation. A designation 
pursuant to this Regulation shall be applicable for all Union harmonisation legislation listed in Section A of 
Annex I for which the conformity assessment body is designated.
The single application and the unified assessment procedure shall avoid any unnecessary duplications, build on the 
existing procedures for designation in accordance with the Union harmonisation legislation listed in Section A of 
Annex I and ensure compliance with the requirements relating to notified bodies both in accordance with this 
Regulation and the relevant Union harmonisation legislation.
9.
A notifying authority that has been designated pursuant to the Union harmonisation legislation listed in 
Section A of Annex I is also the notifying authority for the application of the single application and unified assessment 
procedure referred to in paragraph 8, unless the Member State designates another notifying authority for 
this Regulation.’;
(15) in Article 29, paragraph 4 is replaced by the following:
‘4.
For notified bodies which are designated pursuant to any other Union harmonisation legislation, all documents 
and certificates linked to those designations may be used to support and expedite their designation procedure under 
this Regulation, as appropriate.
Notified bodies, which are designated pursuant to any of the Union harmonisation legislation listed in Section A of 
Annex I and which undergo the unified assessment procedure referred to in Article 28(8), shall submit the single 
application for assessment to the notifying authority designated pursuant to that Union harmonisation legislation.
The notified body shall update the documentation referred to in paragraphs 2 and 3 of this Article whenever relevant 
changes occur, in order to enable the authority responsible for notified bodies to monitor and verify continuous 
compliance with all the requirements laid down in Article 31.’;
(16) in Article 30, paragraph 2 is replaced by the following:
‘2.
Notifying authorities shall notify the Commission and the other Member States, based on the list of codes, 
categories, and corresponding types of AI systems referred to in Annex XIV, and using the electronic notification tool 
developed and managed by the Commission, of each conformity assessment body referred to in paragraph 1.
The Commission is empowered to adopt delegated acts in accordance with Article 97 in order to amend Annex XIV, in 
light of technical progress, advances in knowledge or new scientific evidence by adding to the list of codes, categories, 
and corresponding types of AI systems a new code, a category or a type of AI system, withdrawing an existing code, 
category or a type of AI system from that list or moving a code or type of AI system from one category to another.’;
(17) in Article 40(2), the following subparagraph is added:
‘The Commission shall request, in accordance with Regulation (EU) No 1025/2012 of the European Parliament and of 
the Council (*) and without undue delay, the European standardisation organisations to develop standardisation 
deliverables, including, as appropriate, harmonised standards, to facilitate the joint compliance and presumption of 
conformity with the requirements or obligations set out in Chapter III, Sections 2 and 3 of this Regulation, and the 
relevant requirements and obligations laid down in the Union harmonisation legislation listed in Annex I to this 
Regulation.’; 
(*)
Regulation (EU) No 1025/2012 of the European Parliament and of the Council of 25 October 2012 on 
European standardisation, amending Council Directives 89/686/EEC and 93/15/EEC and Directives 94/9/EC, 
94/25/EC, 95/16/EC, 97/23/EC, 98/34/EC, 2004/22/EC, 2007/23/EC, 2009/23/EC and 2009/105/EC of the 
European Parliament and of the Council and repealing Council Decision 87/95/EEC and Decision 
No 1673/2006/EC of the European Parliament and of the Council (OJ L 316, 14.11.2012, p. 12, ELI: http:// 
data.europa.eu/eli/reg/2012/1025/oj).
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
21/41

## Page 22 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(18) in Article 42, the following paragraph is added:
‘3.
Where high-risk AI systems fall within the scope of Regulation (EU) 2024/2847 and the conditions laid down in 
Article 12(1) of that Regulation are fulfilled, such systems shall be deemed to comply with the cybersecurity 
requirements set out in Article 15 of this Regulation.’;
(19) in Article 43, paragraph 3 is replaced by the following:
‘3.
For high-risk AI systems covered by the Union harmonisation legislation listed in Section A of Annex I, the 
provider of the system shall follow the relevant conformity assessment procedure as required in accordance with the 
relevant Union harmonisation legislation. The requirements set out in Section 2 of this Chapter shall apply to those 
high-risk AI systems and shall be part of that assessment. Assessment of the quality management system set out in 
Article 17 shall also be undertaken, and points 3, 4.3, 4.4. and 4.5, the fifth paragraph of point 4.6 and point 5 of 
Annex VII shall apply.
For the purposes of that conformity assessment, notified bodies which have been notified under the Union 
harmonisation legislation listed in Section A of Annex I shall have the power to assess the conformity of high-risk AI 
systems with the requirements set out in Section 2 of this Chapter, provided that the compliance of those notified 
bodies with the requirements laid down in Article 31(4), (5), (10) and (11) has been assessed in the context of the 
notification procedure in accordance with the relevant Union harmonisation legislation, which is evidenced through 
the assessment as part of the existing notification. Without prejudice to Article 28, such notified bodies which have 
been notified under the Union harmonisation legislation in Section A of Annex I, shall apply for designation in 
accordance with Section 4 of this Chapter by 28 January 2028.
Where Union harmonisation legislation listed in Section A of Annex I provides the product manufacturer with an 
option to rely on a conformity assessment that does not involve a third-party, provided that that manufacturer has 
applied harmonised standards to ensure compliance with all the relevant requirements, that manufacturer may use 
that option only if it has also applied harmonised standards or, where applicable, common specifications referred to in 
Article 41, covering all requirements set out in Section 2 of this Chapter. The classification of a product as a high-risk 
AI system in accordance with Article 6(1) does not affect the choice of the conformity assessment procedure provided 
to the manufacturers of products covered by Union harmonisation legislation listed in Section A of Annex I, including, 
where applicable, an option to rely on harmonised standards. The manufacturers of such products are not required to 
choose a conformity assessment procedure involving third-party conformity assessment only because the product 
includes a high-risk AI system as a safety component, if this is not required by the Union harmonisation legislation 
listed in Section A of Annex I.
Where a high-risk AI system is both covered by the Union harmonisation legislation listed in Section A of Annex I and 
it falls within one of the categories listed in Annex III, the provider of that system shall follow the relevant conformity 
assessment procedure as required pursuant to the relevant Union harmonisation legislation listed in Section A of 
Annex I.’;
(20) in Article 50, paragraph 7 is replaced by the following:
‘7.
The Commission shall encourage and facilitate the drawing up of codes of practice at Union level to facilitate the 
effective implementation of the obligations regarding the detection, marking and labelling of artificially generated or 
manipulated content. The Commission, taking utmost account of the opinion of the Board, shall assess whether 
adherence to those codes of practice is adequate to ensure compliance with the obligations laid down in paragraphs 2 
and 4 of this Article, in accordance with the procedure laid down in Article 56(6). If it deems the code of practice to be 
inadequate, the Commission may adopt an implementing act specifying common rules for the implementation of 
those obligations in accordance with the examination procedure laid down in Article 98(2).’;
EN
OJ L, 24.7.2026
22/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 23 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(21) in Article 56, paragraph 6 is replaced by the following:
‘6.
The Commission and the Board shall regularly monitor and evaluate the achievement of the objectives of the 
codes of practice by the participants and their contribution to the proper application of this Regulation. The 
Commission, taking utmost account of the opinion of the Board, shall assess whether the codes of practice cover the 
obligations provided for in Articles 53 and 55, and shall regularly monitor and evaluate the achievement of their 
objectives. The Commission shall publish its assessment of the adequacy of the codes of practice.’;
(22) Article 57 is amended as follows:
(a) in paragraph 1, the first subparagraph is replaced by the following:
‘1.
Member States shall ensure that their competent authorities establish at least one AI regulatory sandbox at 
national level, which shall be operational by 2 August 2027. That sandbox may also be established jointly with the 
competent authorities of other Member States. The Commission may provide technical support, advice and tools 
for the establishment and operation of AI regulatory sandboxes.’;
(b) paragraph 3 is replaced by the following:
‘3.
The European Data Protection Supervisor may establish an AI regulatory sandbox for Union institutions, 
bodies, offices and agencies. For this purpose, references to national competent authorities in this Chapter shall be 
construed as references to the European Data Protection Supervisor.’;
(c) the following paragraph is inserted:
‘3a.
The AI Office may establish an AI regulatory sandbox at Union level for AI systems covered by 
Article 75(1). For this purpose, references to national competent authorities in this Chapter shall be construed, 
where relevant, as references to the AI Office. That AI regulatory sandbox shall be implemented in close 
cooperation with relevant competent authorities, in particular where compliance with Union legislation other than 
this Regulation is supervised in the AI regulatory sandbox, and shall provide priority access to SMEs, including 
start-ups, and SMCs.
The establishment of a Union level AI regulatory sandbox by the AI Office shall be without prejudice to the 
competences of Member States to establish and supervise AI regulatory sandboxes for AI systems under their 
supervision.’;
(d) paragraph 5 is replaced by the following:
‘5.
AI regulatory sandboxes established under this Article shall provide for a controlled environment that 
fosters innovation and facilitates the development, training, testing and validation of innovative AI systems for 
a limited time before their being placed on the market or put into service pursuant to a specific sandbox plan 
agreed between the providers or prospective providers and the competent authorities, ensuring that appropriate 
safeguards are in place. Such sandboxes may include testing in real world conditions supervised therein. Where 
applicable, the sandbox plan shall incorporate the real-world testing plan referred to in Articles 60 and 60a.’;
(e) in paragraph 9, point (e) is replaced by the following:
‘(e) facilitating and accelerating access to the Union market for AI systems, in particular when provided by SMEs, 
including start-ups, and SMCs.’;
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
23/41

## Page 24 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(f) paragraph 10 is replaced by the following:
‘10.
National competent authorities shall ensure that, to the extent the innovative AI systems involve the 
processing of personal data or otherwise fall under the supervisory remit of other national authorities or 
competent authorities providing or supporting access to data, the competent data protection authorities and those 
other national or competent authorities are associated with the operation of the AI regulatory sandbox and 
involved in the supervision of those aspects to the extent of their respective tasks and powers.’;
(g) paragraph 14 is replaced by the following:
‘14.
National competent authorities, the European Data Protection Supervisor and the AI Office, shall, as 
appropriate and within their respective competences, coordinate their activities and cooperate within the 
framework of the Board. They may support the joint establishment and operation of AI regulatory sandboxes, 
including in different sectors, and exchange best practices on related matters.’;
(23) in Article 58(1), the first subparagraph is amended as follows:
(a) the introductory part is replaced by the following:
‘1.
In order to avoid fragmentation across the Union, the Commission shall adopt implementing acts specifying 
the detailed arrangements for the establishment, development, implementation, operation, governance, and 
supervision of the AI regulatory sandboxes. Those implementing acts shall include common principles on the 
following issues:’;
(b) the following point is added:
‘(d) the detailed rules applicable to the governance of AI regulatory sandboxes covered pursuant to Article 57, 
including as regards the involvement of and supervision by the competent data protection authorities, where 
relevant, and the coordination and cooperation at national and Union level.’;
(24) Article 60 is amended as follows:
(a) in paragraph 1, the first subparagraph is replaced by the following:
‘1.
Testing of high-risk AI systems in real world conditions outside AI regulatory sandboxes may be conducted 
by providers or prospective providers of high-risk AI systems listed in Annex III or covered by Union 
harmonisation legislation listed in Section A of Annex I, in accordance with this Article and the real-world testing 
plan referred to in this Article, without prejudice to the prohibitions under Article 5.’;
(b) paragraph 2 is replaced by the following:
‘2.
Providers or prospective providers may conduct testing of high-risk AI systems referred to in Annex III or 
covered by Union harmonisation legislation listed in Section A of Annex I in real world conditions at any time 
before the placing on the market or the putting into service of the high-risk AI system on their own or in 
partnership with one or more deployers or prospective deployers.’;
EN
OJ L, 24.7.2026
24/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 25 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(25) the following Article is inserted:
‘Article 60a
Testing of high-risk AI systems covered by Union harmonisation legislation listed in Section B of Annex I in 
real-world conditions outside AI regulatory sandboxes
1.
Member States may allow, in accordance with this Article, the testing of high-risk AI systems in real world 
conditions outside AI regulatory sandboxes by providers or prospective providers of AI enabled products covered by 
the Union harmonisation legislation listed in Section B of Annex I, with a view to assessing and verifying the 
conformity of those systems with the requirements laid down in Articles 8 to 15.
2.
Member States that choose to allow testing as referred to in paragraph 1 shall, individually or jointly, 
adopt frameworks for real-world testing.
3.
Each Member State shall notify the Commission of any real-world testing framework it adopts before 
implementing it. This shall not affect the competences of the Commission under the Union harmonisation legislation 
listed in Section B of Annex I.
4.
Member States that have adopted real-world testing frameworks shall ensure that the relevant national 
competent authorities, relevant authorities and public authorities responsible for the management and operation of 
infrastructure and products covered by Union harmonisation legislation listed in Section B of Annex I cooperate 
closely with each other in good faith and remove any practical obstacles, including on procedural rules providing 
access to physical public infrastructure, where this is necessary, to successfully implement those real-world testing 
frameworks and test AI-enabled products covered by Union harmonisation legislation listed in Section B of Annex I.
5.
The frameworks for real-world testing shall lay down the requirements under which testing in real-world 
conditions shall occur. Those frameworks shall:
(a) include the provision of a mandatory real-world testing plan to be agreed between the provider or prospective 
provider and the national competent authority or relevant authority in accordance with the Union harmonisation 
legislation listed in Section B of Annex I;
(b) ensure compliance with the requirements laid down in Article 60(2), (3), (4)(d)-(j) and (5)-(9), where any reference 
to market surveillance authorities in those provisions shall be read as a reference to the national competent 
authority or relevant authority, as appropriate in accordance with the Union harmonisation legislation listed in 
Section B of Annex I;
(c) include effective governance and accountability arrangements;
(d) ensure a high level of protection of health safety and fundamental rights.
6.
The real-world testing shall comply with the applicable provisions laid down in the Union harmonisation 
legislation listed in Section B of Annex I. Any requirements laid down in those provisions shall not affect the 
application of this Article to the extent necessary to enable the testing referred to in paragraph 1.’;
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
25/41

## Page 26 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(26) in Article 63, paragraph 1 is replaced by the following:
‘1.
SMEs, including start-ups, may comply with certain elements of the quality management system required by 
Article 17 in a simplified manner, provided that they do not have partner enterprises or linked enterprises within the 
meaning of Recommendation 2003/361/EC. For that purpose, the Commission shall develop guidelines on the 
elements of the quality management system which may be complied with in a simplified manner considering the 
needs of SMEs, without affecting the level of protection or the need for compliance with the requirements in respect of 
high-risk AI systems.’;
(27) in Article 64, the following paragraph is added:
‘3.
Without prejudice to the budgetary procedure, the AI Office shall be allocated adequate resources to effectively 
perform its duties and exercise its powers in relation to the enforcement of this Regulation.’;
(28) in Article 69, paragraph 2 is replaced by the following:
‘2.
The Member States may be required to pay fees for the advice and support provided by the experts at a rate 
equivalent to the remuneration fees applicable to the Commission pursuant to the implementing act referred to in 
Article 68(1).’;
(29) in Article 70, paragraph 8 is replaced by the following:
‘8.
National competent authorities may provide guidance and advice on the implementation of this Regulation, in 
particular to SMEs, including start-ups, and SMCs, taking into account the guidance and advice of the Board and the 
Commission, as appropriate. Whenever national competent authorities intend to provide guidance and advice with 
regard to an AI system in areas covered by other Union law, the national competent authorities under that Union law 
shall be consulted, as appropriate.’;
(30) in Article 72, paragraph 3 is replaced by the following:
‘3.
The post-market monitoring system shall be based on a post-market monitoring plan. The post-market 
monitoring plan shall be part of the technical documentation referred to in Annex IV. The Commission, taking utmost 
account of the opinion of the Board, shall adopt guidance, including a template, on the post-market monitoring plan 
by 2 September 2027.’;
(31) Article 75 is amended as follows:
(a) the heading is replaced by the following:
‘Market surveillance and control of AI systems and mutual assistance’;
(b) paragraph 1 is replaced by the following:
‘1.
The AI Office shall be exclusively competent for the supervision and enforcement of the obligations under 
this Regulation in relation to the following AI systems:
(a) AI systems based on general-purpose AI models where the model and the system are developed by the same 
provider, or by providers forming part of the same undertaking as that provider, with the exception of:
(i) AI systems related to products covered by the Union harmonisation legislation listed in Annex I;
(ii) AI systems referred to in point 2 of Annex III;
EN
OJ L, 24.7.2026
26/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 27 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(iii) AI systems provided by law enforcement authorities, border management authorities and financial 
institutions, insofar as those AI systems fall under Article 74(6); and
(iv) AI systems referred to in point 8 of Annex III as regards the administration of justice;
(b) AI systems that constitute or that are integrated into a very large online platform or very large online search 
engine designated in accordance with Regulation (EU) 2022/2065.
The exclusive competence referred to in the first subparagraph shall apply to the providers of those systems. It 
shall apply to the deployers of those systems only when they are also the provider or form part of the same 
undertaking as the provider.’;
(c) the following paragraphs are inserted:
‘1a.
By way of derogation from Article 73, providers of high-risk AI systems subject to the competence of the 
AI Office pursuant to paragraph 1 of this Article shall report any serious incidents to the AI Office. Article 73 (2) 
to (9), shall apply mutatis mutandis. The AI Office shall promptly transmit the relevant information to the market 
surveillance authority of the Member State in the territory of which the provider or its legal representative is 
situated.
1b.
The authorities involved in the application of this Regulation shall cooperate actively with the AI Office and 
provide the AI Office the necessary assistance for the exercise of its powers, including, where necessary, in 
connection with inspections or other enforcement measures carried out in the territory of a Member State. To that 
end, those authorities shall enjoy the powers provided for pursuant to this Regulation and Regulation (EU) 
2019/1020, and where relevant and limited to what is necessary to fulfil their tasks under this paragraph, in 
accordance with the applicable national procedures.
1c.
When taking investigatory or enforcement action in the territory of a Member State that involves access to 
a public authority’s data or AI system, the AI Office shall be assisted by the relevant market surveillance authority.
1d.
Before taking a decision that would have the effect of prohibiting or restricting the AI system being made 
available or put into service on a national market, or a decision to withdraw or recall the AI system from such 
market, the AI Office shall, without undue delay, notify the market surveillance authority competent for that 
market of its intention to take such a decision. The AI Office shall consult the authorities involved in the 
application of this Regulation, where appropriate, on any matter relating to the application and enforcement of 
this Regulation.
1e.
The AI Office shall be responsible for conformity assessments and tests of AI systems referred to in 
paragraph 1 of this Article that are classified as high-risk and subject to a third-party conformity assessment 
pursuant to Article 43 before such AI systems are placed on the market or put into service. Those tests and 
assessments shall verify that the systems comply with the relevant requirements of this Regulation and may be 
placed on the market or put into service in the Union in accordance with this Regulation. The Commission shall 
entrust the performance of those tests or assessments to notified bodies designated in accordance with this 
Regulation, in which case the notified body shall act on behalf of the Commission. If a notified body to which the 
Commission has delegated tasks under this paragraph does not perform those tasks adequately, the Commission 
may withdraw the delegation with immediate effect.
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
27/41

## Page 28 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

The fees for testing and assessment activities shall be levied on the provider of a high-risk AI system who has 
applied for a third-party conformity assessment to the Commission. The provider shall pay the costs related to the 
services entrusted by the Commission to the notified bodies in accordance with this Article directly to the notified 
body.’;
(d) the following paragraph is inserted:
‘2a.
Where a market surveillance authority has well-founded and sufficient reasons to suspect that a provider or 
a deployer of an AI system referred to in paragraph 1 of this Article has infringed this Regulation, it may request, 
through the relevant single point of contact designated in accordance with Article 70(2), the AI Office to assess the 
matter in order to take the necessary supervisory and enforcement measures to ensure prompt compliance with 
this Regulation. Such a request shall be duly reasoned and shall include at least:
(a) the name of the provider or the deployer concerned;
(b) a description of the relevant facts, the provisions of this Regulation that have allegedly been infringed, and any 
well-founded and sufficient reasons for suspecting an infringement, including, where applicable, the 
description of the negative effects of the alleged infringement;
(c) the market surveillance authority making the request.
The AI Office shall take utmost account of the request and the market surveillance authority shall cooperate 
actively and provide the AI Office the necessary assistance for the exercise of its powers in accordance with 
paragraph 1a.
The AI Office shall, without undue delay and in any event no later than four months following receipt of the 
request, inform the single point of contact of its intention to exercise its powers in accordance with Article 75a or 
of its reasons for not exercising its powers. If the AI Office decides to exercise its powers in accordance with 
Article 75a, it shall periodically inform that single point of contact about major developments in the proceedings 
and the outcome of such proceedings, without disclosing any confidential information.’;
(32) the following articles are inserted:
‘Article 75a
Supervisory and enforcement powers of the AI Office
1.
When exercising its tasks of supervision and enforcement laid down in Article 75(1) of this Regulation, the AI 
Office shall have all the powers of a market surveillance authority provided for in this Section and in Article 14(4) and 
Article 16(3) of Regulation (EU) 2019/1020. The AI Office shall be authorised to fully reclaim from the relevant 
operator the totality of the costs of its supervision and enforcement activities with respect to instances of 
non-compliance, including costs for human and technical resources, in accordance with Article 15 of Regulation (EU) 
2019/1020. Article 17 of Regulation (EU) 2019/1020 shall apply mutatis mutandis.
2.
Where the AI Office has reasonable grounds to suspect non-compliance with this Regulation by a provider or 
a deployer of an AI system referred to in Article 75(1) of this Regulation, it may adopt a decision to start an 
investigation into that non-compliance in accordance with Article 14(4), point (f) of Regulation (EU) 2019/1020. 
Upon starting such an investigation, the AI Office shall notify the operator of the AI system concerned. The AI Office 
may exercise the powers referred to in paragraph 1 of this Article on its own initiative or following a complaint 
received pursuant to Article 85 of this Regulation, even before starting an investigation pursuant to Article 14(4), 
point (f) of Regulation (EU) 2019/1020.
EN
OJ L, 24.7.2026
28/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 29 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

Where a market surveillance authority has reason to suspect non-compliance with this Regulation by a provider or 
a deployer of an AI system referred to in Article 75(1), it may send a request to the AI Office to assess the matter.
3.
The AI Office may exercise the powers listed in Article 14(4), points (a), (b) and (c) of Regulation (EU) 
2019/1020 and Article 74(12) and (13) of this Regulation by simple request or by decision.
When requesting information, the AI Office shall state the legal basis and the purpose of the request, specify what 
information is required, and set the period within which the information is to be provided. Where the request is 
a simple request, the AI Office shall additionally indicate that although there is no obligation to provide the 
information requested, in the case of a voluntary reply, the information must be correct and not misleading, and 
indicate the potential fines provided for in Article 99(5) for supplying incorrect or misleading information. Where the 
request is made by decision, the AI Office shall additionally indicate the fines provided for in Article 99(5) for 
supplying incorrect, incomplete or misleading information and indicate the right to have the decision reviewed by the 
Court of Justice of the European Union. The AI Office shall send a copy of the request to the market surveillance 
authority of the Member State in the territory of which the operator or its legal representative is situated.
4.
In order to carry out the tasks assigned to it under this Section, the AI Office may conduct all necessary remote 
or on-site inspections pursuant to the powers laid down in Article 14(4), points (d) and (e) of Regulation (EU) 
2019/1020 and Article 74(5) of this Regulation. When conducting an inspection, the AI Office shall inform the 
provider concerned of the subject matter and purpose of the investigation, the relevant fines referred to in 
Article 99(5) of this Regulation, and the right to have the decision reviewed by the Court of Justice of the European 
Union. Prior to conducting an inspection, the AI Office shall inform the market surveillance authority of the Member 
State in the territory of which the operator or its legal representative is situated.
During such an inspection, the officials of the AI Office shall be empowered to:
(a) enter any of the business premises, land or property located in the Union of the operator concerned;
(b) examine the books, data and other material relevant to the execution of their tasks, irrespective of the medium on 
which they are stored;
(c) take or obtain in any form copies of or extracts from books, data and other records;
(d) ask any of the persons subject to the inspection, or their representatives, or staff, for oral or written explanations 
on factors or documents relating to the subject matter and purpose of the inspection, and to record the answers;
(e) seal any business premises and books or records for the duration of, and to the extent necessary for, the inspection.
Where the AI Office finds that a natural or legal person opposes or obstructs an inspection, the national competent 
authority of the Member State concerned shall afford it the necessary assistance, requesting, where appropriate, the 
assistance of the police or an equivalent enforcement authority, to enable it to conduct its on-site inspection.
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
29/41

## Page 30 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

Where an on-site inspection of business premises, land or property requires authorisation by a judicial authority in 
accordance with national law, the AI Office shall apply for such an authorisation. The AI Office may also apply for 
such authorisation as a precautionary measure. Where such an authorisation is applied for, the national judicial 
authority shall promptly verify that the coercive measures envisaged are neither arbitrary nor excessive having regard 
to the subject matter of the investigation or inspection and the documents provided by the AI Office with the decision. 
In its verification of the proportionality of coercive measures, the national judicial authority may ask the AI Office for 
detailed explanations, in particular relating to the grounds the AI Office has for suspecting that an infringement of this 
Regulation has taken place and the seriousness of the suspected infringement and, where relevant, the nature of the 
involvement of the person subject to the coercive measures. The national judicial authority shall not review the 
necessity of the investigation or inspection nor demand information from the case file of the AI Office. In accordance 
with the Treaties, the legality of the decision of the AI Office is subject to review only by the Court of Justice of the 
European Union.
5.
At the request of the AI Office, the competent market surveillance authority of a Member State may in its own 
territory carry out any investigation, inspection or other fact-finding measure on behalf and for the account of the AI 
Office in order to establish whether there has been an infringement of this Regulation. The officials of the competent 
authorities of the Member States who are responsible for conducting such investigations, inspections, or fact-finding 
measures, as well as those authorised or appointed by them, shall exercise their powers in accordance with their 
national law.
6.
In addition to the powers set out in paragraph 1 of this Article, the AI Office, in the exercise of its competences 
referred to in Article 75(1), may:
(a) order operators to provide access to, and explanations relating to, their AI systems;
(b) impose an obligation on an operator to retain all data and documents deemed to be necessary to assess the 
implementation of and compliance with the obligations under this Regulation.
7.
To assist it in monitoring the effective implementation and compliance with the relevant provisions of this 
Regulation and to provide it with specific expertise or knowledge in the exercise of its competences under 
Article 75(1), the AI Office may appoint independent external experts and auditors, as well as experts, investigative 
teams and auditors from the Member State’s competent authorities with the agreement of the authority concerned. 
Information obtained as a result of such monitoring actions shall be shared with the relevant competent authorities of 
the Member States.
8.
Information collected pursuant to this Article shall be used only for the purpose of this Regulation.
Article 75b
Commitments
If, during proceedings under Article 75a(2), the operator concerned offers commitments to ensure compliance with 
the relevant provisions of this Regulation, the AI Office may, by decision, make those commitments binding on the 
operator concerned and declare that there are no further grounds for action. The AI Office may, upon request or on its 
own initiative, reopen the proceedings where:
(a) there has been a material change in any of the facts on which the decision was based;
(b) the operator acts contrary to its commitments; or
EN
OJ L, 24.7.2026
30/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 31 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(c) the decision was based on incomplete, incorrect or misleading information provided by the operator concerned.
Where the AI Office considers that the commitments offered by the operator concerned are unable to ensure effective 
compliance with the relevant provisions of this Regulation, it shall reject those commitments in a reasoned decision 
when concluding the proceedings.
Article 75c
Non-compliance, fines and periodic penalty payments
1.
Where the AI Office finds that an operator falling within the scope of Article 75(1) does not comply with the 
relevant provisions of this Regulation or with commitments made binding pursuant to Article 75b, it shall 
adopt a decision establishing such non-compliance.
2.
Before adopting a decision pursuant to paragraph 1, the AI Office shall communicate its preliminary findings to 
the operator concerned. In the preliminary findings, the AI Office shall explain the measures that it is considering 
taking, or that it considers that the operator concerned should take, in order to effectively address the preliminary 
findings.
3.
In the decision pursuant to paragraph 1 of this Article, the AI Office shall, where relevant, order the operator 
concerned to take the necessary measures to ensure compliance with the relevant provisions of this Regulation within 
a reasonable period specified therein and to provide information on the measures that that operator intends to take to 
comply with the decision. The operator concerned shall provide the AI Office with a description of the measures it has 
taken to ensure compliance with the decision upon their implementation. Prior to requesting any measure, the 
AI Office may engage in a structured dialogue with the operator of the AI system in question. During this dialogue, the 
operator may propose commitments in accordance with Article 75b.
4.
A decision adopted pursuant to paragraph 1 of this Article may be accompanied by the imposition of penalties 
in accordance with Article 99(3) to (7), which provisions shall apply mutatis mutandis to the AI Office in the execution 
of its supervision and enforcement tasks referred to in Article 75(1).
In particular, the following shall be subject to administrative fines as referred to in Article 99(4):
(a) infringement of any applicable provision of this Regulation, including those not listed in Article 99(4);
(b) failure to comply with decisions or measures adopted pursuant to the powers listed in Article 14(4) or 
Article 16(3) of Regulation (EU) 2019/1020, as well as those specified in Article 75a of this Regulation;
(c) failure to comply with a commitment made binding by a decision pursuant to Article 75b.
The supply of incorrect, incomplete or misleading information to the AI Office in reply to a request shall be subject to 
administrative fines as referred to in Article 99(5).
5.
The AI Office may adopt a decision imposing periodic penalty payments to compel the operators subject to its 
competence pursuant to Article 75(1) to the following:
(a) to submit to an investigation;
(b) to comply with an information request ordered by a decision adopted under Article 75a(3);
(c) to submit to an inspection ordered by a decision pursuant to Article 75a(4);
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
31/41

## Page 32 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(d) to provide correct or complete answers or explanations in the context of an inspection ordered by a decision 
pursuant to Article 75a(4);
(e) to comply with corrective actions ordered pursuant to the power listed in Article 16 of Regulation (EU) 
2019/1020;
(f) to comply with commitments made legally binding by a decision pursuant to Article 75b; or
(g) to comply with a decision pursuant to the paragraph (1) of this Article.
Those penalty payments shall be effective and proportionate, and, where applicable, shall not exceed 5 % of the 
average daily income or worldwide annual turnover in the preceding financial year per day, calculated from the date 
appointed by the decision.
6.
The Court of Justice of the European Union shall have unlimited jurisdiction to review decisions of the AI Office 
fixing a fine or periodic penalty payment pursuant to this Article. It may cancel, reduce or increase the fine or periodic 
penalty payment imposed.
7.
Funds collected through the imposition of fines or periodic penalty payments pursuant to this Article shall 
contribute to the general budget of the Union.
8.
The powers conferred on the AI Office by this Article shall be subject to a limitation period of five years. The 
limitation period shall begin to run on the day on which the infringement is committed. However, in the case of 
continuing or repeated infringements, the limitation period shall begin to run on the day on which the infringement 
ceases.
The power of the AI Office to enforce decisions taken pursuant to this Article shall be subject to a limitation period of 
five years. The limitation period shall begin to run on the day on which the decision becomes final.
The implementing act referred to in Article 75d(3) shall specify the first and second subparagraphs of this paragraph, 
including the circumstances in which the limitation periods shall be interrupted.
9.
Where the AI Office determines that there are no grounds to adopt a decision of non-compliance, it shall close 
the proceeding by a decision. That decision shall apply with immediate effect.
Article 75d
Safeguards and further specification
1.
Article 18 of Regulation (EU) 2019/1020 shall apply mutatis mutandis to operators subject to the AI Office’s 
competence pursuant to Article 75(1) of this Regulation, without prejudice to more specific procedural rights 
provided for in this Regulation.
EN
OJ L, 24.7.2026
32/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 33 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

2.
The rights of defence and of access to the file of operators falling within the scope of Article 75(1) shall be fully 
respected in proceedings. In view of the possible adoption of decisions on the basis of Article 75c(1), those operators 
shall be entitled to have access to the AI Office file under the terms of a negotiated disclosure, subject to the legitimate 
interest of the operator or other person concerned in the protection of their business secrets. The AI Office shall have 
the power to adopt decisions setting out such terms of disclosure in the case of disagreement between the parties. The 
right of access to the file shall not extend to confidential information and internal documents of the AI Office, the 
Board, competent market surveillance authorities or other public authorities of the Member States. In particular, the 
right of access shall not extend to correspondence between the AI Office and those authorities. Nothing in this 
paragraph shall prevent the AI Office from disclosing and using information necessary to prove an infringement.
3.
The Commission may adopt implementing acts concerning the practical arrangements for access to the file and 
the negotiated disclosure of information provided for in paragraph 2.
4.
The AI Office shall publish the decisions it adopts pursuant to Articles 75b and 75c. Such publication shall state 
the names of the parties and the main content of the decision, including any penalties imposed. The publication shall 
have regard to the rights and legitimate interests of any person concerned in the protection of their confidential 
information.’;
(33) in Article 76(1), the following subparagraph is added:
‘Where testing in real world conditions is based on Article 60a, any reference to a market surveillance authority in this 
Article shall be construed as a reference to the national competent authority or appropriate authority under the Union 
harmonisation legislation listed in Section B of Annex I, and references to Article 60 shall be construed as references 
to Article 60a, as appropriate.’;
(34) Article 77 is amended as follows:
(a) the heading is replaced by the following:
‘Powers of authorities protecting fundamental rights and cooperation with market surveillance 
authorities’;
(b) paragraph 1 is replaced by the following:
‘1.
National public authorities or bodies which supervise or enforce the respect of obligations under Union law 
protecting fundamental rights, including the right to non-discrimination, shall have the power to request and 
access any information or documentation created or maintained from the relevant market surveillance authority 
pursuant to this Regulation in accessible language and machine-readable format by electronic means where access 
to that information or documentation is necessary for effectively fulfilling their mandates within the limits of their 
jurisdiction. This Article is without prejudice to the competences, tasks, powers and independence of the relevant 
national public authorities or bodies under their mandates.’;
(c) the following paragraphs are inserted:
‘1a.
Subject to the conditions specified in this Article, the market surveillance authority shall grant the relevant 
public authority or body referred to in paragraph 1 access to such information or documentation, including by 
requesting such information or documentation from the provider or the deployer, where necessary and without 
undue delay.
1b.
Market surveillance authorities and public authorities or bodies referred to in paragraph 1 shall cooperate 
closely and provide each other with the mutual assistance necessary to fulfil their respective mandates, with a view 
to ensuring the coherent application of this Regulation and Union law protecting fundamental rights and 
streamlining procedures, while respecting their respective competences, tasks, powers and independence. This 
shall include, in particular, exchange of information where necessary for the effective supervision or enforcement 
of this Regulation and the respective other Union legislation.’;
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
33/41

## Page 34 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(35) in Article 95, paragraph 4 is replaced by the following:
‘4.
The AI Office and the Member States shall take into account the specific interests and needs of SMEs, including 
start-ups, and SMCs, when encouraging and facilitating the drawing up of codes of conduct.’;
(36) in Article 96, paragraph 1 is amended as follows:
(a) in the first subparagraph, point (a) is replaced by the following:
‘(a) the application of the requirements and obligations referred to in Articles 8 to 15 and in Articles 25 and 26;’;
(b) in the first subparagraph, the following point is added:
‘(g) the practical implementation of Article 8(2), Article 9(10) and Article 17(3) in accordance with the principle 
of complementarity and proportionality, with a view to ensuring consistency, avoiding duplication and 
minimising additional burdens when complying with the requirements of this Regulation and the 
requirements of the Union harmonisation legislation listed in Section A of Annex I; such guidelines shall 
be published by 1 August 2027.’;
(c) the second subparagraph is replaced by the following:
‘When issuing such guidelines, the Commission shall involve the Board and pay particular attention to the needs of 
SMEs, including start-ups, and SMCs, of local public authorities and of the sectors most likely to be affected by this 
Regulation.’;
(37) Article 97 is amended as follows:
(a) paragraphs 2 and 3 are replaced by the following:
‘2.
The power to adopt delegated acts referred to in Article 6(6) and (7), Article 7(1) and (3), Article 11(3), 
Article 43(5) and (6), Article 47(5), Article 51(3), Article 52(4) and Article 53(5) and (6) shall be conferred on the 
Commission for a period of five years from 1 August 2024. The power to adopt delegated acts referred to in 
Article 2(13) and Article 30(2) shall be conferred on the Commission for a period of five years from 27 July 2026. 
The Commission shall draw up a report in respect of the delegation of power not later than nine months before 
the end of the five-year period. The delegation of power shall be tacitly extended for periods of an identical 
duration, unless the European Parliament or the Council opposes such extension no later than three months before 
the end of each period.
3.
The delegation of power referred to in Article 2(13), Article 6(6) and (7), Article 7(1) and (3), Article 11(3), 
Article 30(2), Article 43(5) and (6), Article 47(5), Article 51(3), Article 52(4) and Article 53(5) and (6) may be 
revoked at any time by the European Parliament or by the Council. A decision of revocation shall put an end to the 
delegation of power specified in that decision. It shall take effect the day following that of its publication in the 
Official Journal of the European Union or at a later date specified therein. It shall not affect the validity of any 
delegated acts already in force.’;
(b) paragraph 6 is replaced by the following:
‘6.
Any delegated act adopted pursuant to Article 2(13), Article 6(6) or (7), Article 7(1) or (3), Article 11(3), 
Article 30(2), Article 43(5) or (6), Article 47(5), Article 51(3), Article 52(4) or Article 53(5) or (6) shall enter into 
force only if no objection has been expressed by either the European Parliament or the Council within a period of 
three months of notification of that act to the European Parliament and the Council or if, before the expiry of that 
period, the European Parliament and the Council have both informed the Commission that they will not object. 
That period shall be extended by three months at the initiative of the European Parliament or of the Council.’;
EN
OJ L, 24.7.2026
34/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 35 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(38) Article 99 is amended as follows:
(a) paragraph 1 is replaced by the following:
‘1.
In accordance with the terms and conditions laid down in this Regulation, Member States shall lay down the 
rules on penalties and other enforcement measures, which may also include administrative fines, warnings and 
non-monetary measures, applicable to any infringement of this Regulation by operators, and shall take all 
measures necessary to ensure that they are properly and effectively implemented, thereby taking into account the 
guidelines issued by the Commission pursuant to Article 96. The penalties provided for shall be effective, 
proportionate and dissuasive. The Member States shall take into account the interests of SMEs, including start-ups, 
and SMCs, and their economic viability when imposing penalties.’;
(b) in paragraph 4, the following point is inserted:
‘(da) obligations of providers and operators pursuant to Article 25(2) and (4)’;
(c) the following paragraph is inserted:
‘6a.
In the case of SMCs, each fine referred to in paragraphs 4 and 5 shall be up to the percentages or amount 
referred therein, whichever is lower.’;
(39) Article 111 is amended as follows:
(a) paragraph 2 is replaced by the following:
‘2.
Without prejudice to the application of Article 5 as referred to in Article 113, third paragraph, point (a), this 
Regulation shall apply to operators of high-risk AI systems, other than the systems referred to in paragraph 1 of 
this Article, that have been placed on the market or put into service before the date of application of Chapter III 
referred to in Article 113, only if, as from that date, those systems are subject to significant changes in their 
designs. In any case, the providers and deployers of high-risk AI systems intended to be used by public authorities 
shall take the necessary steps to comply with the requirements and obligations laid down in this Regulation by 
2 August 2030.’;
(b) the following paragraph is added:
‘4.
Providers of AI systems, including general-purpose AI systems, generating synthetic audio, image, video or 
text content, that have been placed on the market before 2 August 2026 shall take the necessary steps in order to 
comply with Article 50(2) by 2 December 2026.’;
(40) in Article 113, the third paragraph is amended as follows:
(a) point (a) is replaced by the following:
‘(a) Chapters I and II shall apply from 2 February 2025, with the exception of Article 5(1), first subparagraph, 
points (ba) and (bb), and Article 5(1a) and (1b) which shall apply from 2 December 2026;’;
(b) point (c) is replaced by the following:
‘(c) Chapter III, Sections 1, 2, and 3, with the exception of Article 6(5), shall apply from:
(i) 2 December 2027 as regards AI systems classified as high-risk pursuant to Article 6(2) and Annex III; and
(ii) 2 August 2028 as regards AI systems classified as high-risk pursuant to Article 6(1) and Annex I;’;
(c) the following point is added:
‘(d) Articles 102 to 110 shall apply from 27 July 2026.’;
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
35/41

## Page 36 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(41) Annex I is amended as follows:
(a) in Section A, point 1 is deleted;
(b) in Section B, the following point is added:
‘21. Regulation (EU) 2023/1230 of the European Parliament and of the Council of 14 June 2023 on machinery 
and repealing Directive 2006/42/EC of the European Parliament and of the Council and Council Directive 
73/361/EEC (OJ L 165, 29.6.2023, p. 1, ELI: http://data.europa.eu/eli/reg/2023/1230/oj).’;
(42) in Annex VIII, section B, points 7 and 9 are deleted;
(43) the following Annex is added:
‘Annex XIV
The list of codes, categories and corresponding types of AI systems for the purpose of the notification procedure 
referred to in Article 30 specifying the scope of the designation as notified bodies
1. Introduction
Conformity assessment of high-risk AI systems pursuant to this Regulation may require the involvement of 
conformity assessment bodies. Only conformity assessment bodies that have been designated in accordance with 
this Regulation may carry out conformity assessments and only for the activities related to the types of AI systems 
concerned. The list of codes, categories, and corresponding types of AI systems sets the scope of the designation of 
conformity assessment bodies notified under Article 30.
2. List of Codes, categories, and corresponding AI systems
a. AI systems subject to Annex I
AIA Code
AIP 0102
AI systems subject to point 2 of Section A of Annex I
AIP 0103
AI systems subject to point 3 of Section A of Annex I
AIP 0104
AI systems subject to point 4 of Section A of Annex I
AIP 0105
AI systems subject to point 5 of Section A of Annex I
AIP 0106
AI systems subject to point 6 of Section A of Annex I
AIP 0107
AI systems subject to point 7 of Section A of Annex I
AIP 0108
AI systems subject to point 8 of Section A of Annex I
EN
OJ L, 24.7.2026
36/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 37 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

AIA Code
AIP 0109
AI systems subject to point 9 of Section A of Annex I
AIP 0110
AI systems subject to point 10 of Section A of Annex I
AIP 0111
AI systems subject to point 11 of Section A of Annex I
AIP 0112
AI systems subject to point 12 of Section A of Annex I
b. AI systems subject to point 1 of Annex III
AIA Code
AIB 0201
Remote biometric identification systems
AIB 0202
Biometric categorisation AI systems
AIB 0203
Emotion recognition AI systems
3. AI technology-specific codes
a. Symbolic AI and expert systems
AIA Code
AIH 0101
AI systems based on symbolic AI, expert and knowledge-based systems, and AI 
systems based on search and optimisation
b. Machine learning, excluding generative AI and general-purpose AI systems
AIA Code
AIH 0201
AI systems that process structured data
AIH 0202
AI systems that process signal and audio data
AIH 0203
AI systems that process text data
AIH 0204
AI systems that process image and video
AIH 0205
AI systems that learn from their environment, excluding AI systems covered under 
AIH 0401
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
37/41

## Page 38 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

c. AI systems based on general-purpose AI models or generative AI
AIA Code
AIH 0301
generative AI systems, including AI systems based on general-purpose AI models
d. Emerging AI technologies
AIA Code
AIH 0401
AI systems based on other emerging AI technologies not covered by other codes, 
including Agentic AI
4. Application for designation
Conformity assessment bodies shall use the lists of codes, categories and corresponding types of AI systems set out 
in this Annex when specifying the types of AI systems in the application for designation referred to in Article 29.’.
Article 2
Amendments to Regulation (EU) 2018/1139
Regulation (EU) 2018/1139 is amended as follows:
(1) in Article 27, the following paragraph is added:
‘3.
Without prejudice to paragraph 2, when adopting implementing acts pursuant to paragraph 1 concerning 
Artificial Intelligence (AI) systems which are safety components within the meaning of Regulation (EU) 2024/1689 of 
the European Parliament and of the Council (*), the requirements set out in Chapter III, Section 2, of that Regulation 
shall be taken into account. 
(*)
Regulation (EU) 2024/1689 of the European Parliament and of the Council of 13 June 2024 laying down 
harmonised rules on artificial intelligence and amending Regulations (EC) No 300/2008, (EU) No 167/2013, (EU) 
No 168/2013, (EU) 2018/858, (EU) 2018/1139 and (EU) 2019/2144 and Directives 2014/90/EU, (EU) 2016/797 
and (EU) 2020/1828 (Artificial Intelligence Act) (OJ L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/ 
2024/1689/oj).’;
(2) in Article 31, the following paragraph is added:
‘3.
Without prejudice to paragraph 2, when adopting implementing acts pursuant to paragraph 1 concerning AI 
systems which are safety components within the meaning of Regulation (EU) 2024/1689, the requirements set out in 
Chapter III, Section 2, of that Regulation shall be taken into account.’;
EN
OJ L, 24.7.2026
38/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 39 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

(3) in Article 32, the following paragraph is added:
‘3.
When adopting delegated acts pursuant to paragraph 1 concerning AI systems which are safety components 
within the meaning of Regulation (EU) 2024/1689, the requirements set out in Chapter III, Section 2, of that Regulation 
shall be taken into account.’;
(4) in Article 36, the following paragraph is added:
‘3.
Without prejudice to paragraph 2, when adopting implementing acts pursuant to paragraph 1 concerning AI 
systems which are safety components within the meaning of Regulation (EU) 2024/1689, the requirements set out in 
Chapter III, Section 2, of that Regulation shall be taken into account.’;
(5) in Article 39 the following paragraph is added:
‘3.
When adopting delegated acts pursuant to paragraph 1 concerning AI systems which are safety components 
within the meaning of Regulation (EU) 2024/1689, the requirements set out in Chapter III, Section 2, of that Regulation 
shall be taken into account.’;
(6) in Article 50, the following paragraph is added:
‘3.
Without prejudice to paragraph 2, when adopting implementing acts pursuant to paragraph 1 concerning AI 
systems which are safety components within the meaning of Regulation (EU) 2024/1689, the requirements set out in 
Chapter III, Section 2, of that Regulation shall be taken into account.’;
(7) in Article 53, the following paragraph is added:
‘3.
Without prejudice to paragraph 2, when adopting implementing acts pursuant to paragraph 1 concerning AI 
systems which are safety components within the meaning of Regulation (EU) 2024/1689, the requirements set out in 
Chapter III, Section 2, of that Regulation shall be taken into account.’
Article 3
Amendments to Regulation (EU) 2023/1230
Regulation (EU) 2023/1230 is amended as follows:
(1) in Article 8, the following paragraphs are added:
‘The Commission shall adopt delegated acts in accordance with Article 47 of this Regulation to amend Annex III to this 
Regulation by adding health and safety requirements in respect of Artificial Intelligence (AI) systems that are classified as 
high-risk pursuant to Article 6(1) of Regulation (EU) 2024/1689 of the European Parliament and of the Council (*) due 
to the fact that they are a safety component in a product covered by this Regulation, or they are themselves a product 
covered by this Regulation. Those requirements shall ensure that the relevant requirements set out in Chapter III, 
Section 2, and Articles 17, 19, 72 and 73 of Regulation (EU) 2024/1689 are reflected.
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
39/41

## Page 40 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

When adopting the delegated acts referred to in the third paragraph, the Commission shall take into account the 
objectives of Regulation (EU) 2024/1689 and ensure a level of protection consistent with that Regulation. Those 
delegated acts shall apply by 2 August 2028. 
(*)
Regulation (EU) 2024/1689 of the European Parliament and of the Council of 13 June 2024 laying down 
harmonised rules on artificial intelligence and amending Regulations (EC) No 300/2008, (EU) No 167/2013, (EU) 
No 168/2013, (EU) 2018/858, (EU) 2018/1139 and (EU) 2019/2144 and Directives 2014/90/EU, (EU) 2016/797 
and (EU) 2020/1828 (Artificial Intelligence Act) (OJ L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/ 
2024/1689/oj).’;
(2) in Article 20, the following paragraph is added:
‘10.
Until harmonised standards or common specifications are referenced or adopted pursuant to this Article as 
regards high-risk AI systems, high-risk AI systems within the scope of this Regulation which comply with the relevant 
harmonised standards referenced, or common specifications adopted pursuant to Articles 40 and, respectively, 41 of 
Regulation (EU) 2024/1689 shall be presumed to be in conformity with the essential health and safety requirements set 
out in Annex III to this Regulation as regards high-risk AI systems.’;
(3) Article 47 is amended as follows:
(a) paragraphs 2 and 3 are replaced by the following:
‘2.
The power to adopt delegated acts referred to in Article 6(2) and (11) and Article 7(2), shall be conferred on 
the Commission for a period of five years from 19 July 2023. The power to adopt delegated acts referred to in 
Article 8, third paragraph, shall be conferred on the Commission for a period of five years from 27 July 2026. The 
Commission shall draw up a report in respect of the delegation of power not later than nine months before the end 
of the five-year period. The delegation of power shall be tacitly extended for periods of an identical duration, unless 
the European Parliament or the Council opposes such extension no later than three months before the end of each 
period.
3.
The delegation of power referred to in Article 6(2) and (11), Article 7(2) and Article 8, third paragraph, may 
be revoked at any time by the European Parliament or by the Council. A decision to revoke shall put an end to the 
delegation of the power specified in that decision. It shall take effect the day following the publication of the 
decision in the Official Journal of the European Union or at a later date specified therein. It shall not affect the validity 
of any delegated acts already in force.’;
(b) paragraph 6 is replaced by the following:
‘6.
A delegated act adopted pursuant to Article 6(2) and (11), Article 7(2) or Article 8, third paragraph, shall 
enter into force only if no objection has been expressed either by the European Parliament or by the Council within 
a period of two months of notification of that act to the European Parliament and the Council or if, before the 
expiry of that period, the European Parliament and the Council have both informed the Commission that they will 
not object. That period shall be extended by two months at the initiative of the European Parliament or of the 
Council.’.
EN
OJ L, 24.7.2026
40/41
ELI: http://data.europa.eu/eli/reg/2026/1744/oj

## Page 41 (Section: Regulation (EU) 2026/1744 of the European Parliament and of the Council of 8 July 2026 amending Regulations (EU) 2024/1689, (EU) 2018/1139 and (EU) 2023/1230 as regards the simplification of the implementation of harmonised rules on artificial intelligence (Digital Omnibus on AI) (Text with EEA relevance))

Article 4
Entry into force and application
This Regulation shall enter into force on the third day following that of its publication in the Official Journal of the European 
Union.
This Regulation shall be binding in its entirety and directly applicable in all Member States.
Done at Strasbourg, 8 July 2026.
For the European Parliament
The President
R. METSOLA
For the Council
The President
T. BYRNE
OJ L, 24.7.2026
EN
ELI: http://data.europa.eu/eli/reg/2026/1744/oj
41/41


---

# Data Quality Framework for EU medicines regulation

- **Issuer:** EMA
- **Type:** Guideline
- **Language:** en
- **Source:** https://www.ema.europa.eu/en/documents/regulatory-procedural-guideline/data-quality-framework-eu-medicines-regulation_en.pdf
- **Licence:** EMA-reuse

## Page 1

Official address  Domenico Scarlattilaan 6  ●  1083 HS Amsterdam  ●  The Netherlands 
An agency of the European Union   
Address for visits and deliveries  Refer to www.ema.europa.eu/how-to-find-us  
Send us a question  Go to www.ema.europa.eu/contact  Telephone +31 (0)88 781 6000 
© European Medicines Agency, 2023. Reproduction is authorised provided the source is acknowledged. 
 
30 October 2023 
Data Analytics and Methods Task Force 
EMA/326985/2023 
 
 
Data Quality Framework for EU medicines regulation 
 
Draft agreed by BDSG for release for consultation 
10 October 2022 
End of consultation (deadline for comments) 
18 November 2022 
Agreed by BDSG and MWP 
30 June 2023 
Adopted by CHMP  
30 October 2023 
 
 
 
Keywords 
Data quality framework, medicines regulation, data quality dimensions, 
primary and secondary use of data

## Page 2

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 2/42 
 
Table of contents 
1. Executive summary ................................................................................. 4 
2. Abbreviations .......................................................................................... 5 
3. Background - The need for a Data Quality Framework for medicines 
regulation .................................................................................................... 5 
4. Scope of this DQF .................................................................................... 6 
4.1. Definition of data.................................................................................................. 7 
4.2. Definition of DQ ................................................................................................... 7 
4.3. Limitations of scope .............................................................................................. 7 
4.4. Structure of this DQF ............................................................................................ 8 
5. General considerations underlying the maintenance and assessment of 
DQ ............................................................................................................... 8 
5.1. DQ determinants for evidence generation ................................................................ 8 
5.2. DQ along the evidence generation process ............................................................ 10 
5.2.1. DQ vs standardisation ...................................................................................... 11 
5.2.2. Primary vs secondary use of data ...................................................................... 11 
5.2.3. Publication vs data consumption ........................................................................ 12 
5.3. Data and metadata ............................................................................................. 12 
5.4. Data immutability ............................................................................................... 13 
5.5. Data vs information ............................................................................................ 13 
5.6. Frame of reference (validation vs verification) ........................................................ 13 
5.7. Granularity of data and DQ .................................................................................. 13 
6. DQ dimensions and metrics ................................................................... 14 
6.1. Reliability .......................................................................................................... 15 
6.1.1. When considering the “fit for purpose” definition of quality, Reliability covers how 
correct and true the data are. Reliability sub-dimensions ............................................... 15 
6.1.2. Considerations for Reliability ............................................................................. 16 
6.1.3. Examples of reliability metrics ........................................................................... 17 
6.2. Extensiveness .................................................................................................... 19 
6.2.1. Sub-dimensions of Extensiveness ...................................................................... 19 
6.2.2. Considerations for Extensiveness ....................................................................... 20 
6.2.3. Examples of metrics for Extensiveness ............................................................... 20 
6.3. Coherence ......................................................................................................... 20 
6.3.1. Sub-dimensions of Coherence ........................................................................... 21 
6.3.2. Considerations for Coherence ............................................................................ 21 
6.3.3. Examples of metrics for Coherence .................................................................... 23 
6.4. Timeliness ......................................................................................................... 25 
6.4.1. Sub-dimensions of Timeliness ........................................................................... 25 
6.4.2. Considerations for Timeliness ............................................................................ 25 
6.4.3. Examples of metrics for Timeliness .................................................................... 25 
6.5. Relevance ......................................................................................................... 25 
6.5.1. Examples of metrics for Relevance ..................................................................... 26 
7. General recommendations and maturity models ................................... 26 
7.1. Foundational determinants: Recommendation and maturity levels ............................ 32

## Page 3

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 3/42 
 
7.1.1. Level 1: documented ....................................................................................... 32 
7.1.2. Level 2: formalised .......................................................................................... 33 
7.1.3. Level 3: implemented ...................................................................................... 33 
7.1.4. Level 4: automated .......................................................................................... 33 
7.2. Intrinsic determinants: Recommendations and maturity levels ................................. 33 
7.2.1. Level 0: intrinsic .............................................................................................. 33 
7.2.2. Level 1: metadata ........................................................................................... 33 
7.2.3. Level 2: standardised ....................................................................................... 34 
7.2.4. Level 3: automated .......................................................................................... 34 
7.2.5. Level 4: feedback ............................................................................................ 34 
7.3. Question-specific determinants: Recommendations and maturity levels .................... 34 
7.3.1. Level 1: ad-hoc ............................................................................................... 34 
7.3.2. Level 2: domain-defined ................................................................................... 34 
7.3.3. Level 3: question-defined ................................................................................. 34 
8. Considerations for implementation of DQF ............................................ 35 
8.1. Quality at source ................................................................................................ 35 
8.2. The role of Master Data Management (MDM) and reference data .............................. 35 
8.3. The role of QMS and computerised systems ........................................................... 35 
8.4. The role of ISO and industry standards ................................................................. 36 
8.5. Notes on ALCOA+ ............................................................................................... 37 
8.6. Notes on implementation of DQ controls................................................................ 37 
9. Glossary ................................................................................................ 39 
10. References .......................................................................................... 42

## Page 4

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 4/42 
 
1.  Executive summary 
This document is the first release of the EU Data Quality Framework (DQF) for medicines regulation 
and defines high-level principles and procedures that apply across EMA’s regulatory mandate. This 
framework provides general considerations on data quality that are relevant for regulatory decision 
making, definitions for data quality dimensions and sub-dimensions, as well as their characterisation 
and related metrics. It provides an analysis of what data quality actions and metrics should be 
considered in different use cases and introduces a maturity model to guide the evolution of automation 
to support data-driven regulatory decision making. 
This document is intended to be a general resource from which more focused recommendations can be 
derived for specific regulatory domains with specified metrics and checks. See figure 1 for a 
summarised representation of the key points of the DQF. 
 
 
Figure 1 – Representation of the key points of the Data Quality Framework

## Page 5

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 5/42 
 
2.  Abbreviations 
 
 
CDM 
Common Data Model 
CHMP 
Committee for Medicinal Products for Human Use 
DQ 
Data Quality 
DQF 
Data Quality Framework 
EHR 
Electronic Health Record  
EHDS 
European Health Data Space 
EMA 
European Medicines Agency 
ETL 
Extract, Transform and Load 
FAIR 
Findable, Accessible, Interoperable and Reusable 
GxP 
Good x Practices, where x stands for laboratory (GLP), clinical (GCP), 
manufacturing (GMP), distribution or documentation (GDP) 
ICSR 
Individual Case Safety Reports 
ISO 
International Organisation for Standardisation 
MDM 
Master Data Management 
QMS 
Quality Management System 
QSR 
Quality System Regulation  
RWD 
Real-World Data 
RWE 
Real-World Evidence 
 
3.  Background - The need for a Data Quality Framework for 
medicines regulation 
As acknowledged in the recommendations of the HMA-EMA Joint Big Data Task Force and the workplan 
of the HMA-EMA Joint Big Data Steering Group, establishing an EU framework for data quality (DQ) 
and representativeness is a critical element for realising the full potential of (big) data and driving 
regulatory decisions. 
In recent years, the EU regulatory assessment process has been exploring a shift from document-
based submissions to direct assessments of the data underlying those submissions. To facilitate this 
potential shift, there is an increased need for standardisation [1], and the need for a framework, which 
would characterise DQ and would allow the regulator to make reliable assessments of whether the data 
are fit for the purpose of decision making. 
In addition, the progress in digitalisation and information technology creates new opportunities, but 
also contributes to an increasingly complex landscape for regulatory decision making. While new types 
of data become available, guidelines or methods to demonstrate whether such data are adequate for

## Page 6

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 6/42 
 
decision making are still scarce. Therefore, a Data Quality Framework (DQF) is needed to guide 
coherent and consistent quality assessment procedures. 
One notable example is healthcare data that are becoming available in increasing quantity to 
potentially support regulatory decision making for medicines. Information derived from routinely 
collected Real-World Data (RWD) has for a long time been used to support regulatory decision making 
on the safety of drugs in the post-authorisation phase. While most traditional pre-approval randomised 
controlled clinical trials remain the fundamental method of establishing the safety and efficacy of 
medicines during the pre-authorisation phase, they could potentially benefit from the evidence 
generated using this data. Insights into the Real-World are also required by downstream stakeholders 
including Health Technology Assessment bodies, payers and ultimately clinicians and patients. Bridging 
these gaps, the regulatory network needs to acquire the ability to describe and quantify the degree to 
which these data are accurate and fit for purpose. 
4.  Scope of this DQF 
This document aims to provide a set of definitions, principles and guidelines that can coherently be 
applied to any data source for the purpose of characterising, assessing, and assuring DQ for regulatory 
decision making. This framework is intended to encompass primary and secondary use, as well as 
metadata and supporting information (e.g., MDM (Master data management), underlying reference 
Data) applicable to support Committee for Medicinal Products for Human Use (CHMP) decision making. 
The document is targeted primarily at the EU medicine regulatory network, but the relevance of the 
content can be of interest to a wider range of stakeholders such as marketing authorisation holders, 
data source holders, researchers, and patient associations.  
As methods, terminologies, metrics, and issues vary across data types and sources, this framework 
seeks to provide a coherent basis to identify, define, and further develop DQ assessment procedures 
and recommendations for current and novel data types. 
Objectives of this framework are therefore to achieve consistency in DQ related processes, foster the 
development of horizontal systems1 for DQ and eventually enable a more adequate and automated use 
of data for regulatory decision making. 
This framework builds on the recommendations of TEHDAS [2] and extends them with a classification 
of quality dimensions and assessment criteria, as well as guidelines for their application. It builds on 
the definitions and recommendations that have been proposed in several existing DQ frameworks, 
including [2-13]. 
While many examples provided in this framework relate to Real-World Data, the scope of this 
framework extends to a broad range of regulatory activities and their respective data types, including 
Real-World Data [14, 15] (including within clinical trials to supplement trial-specific data collection), 
bioanalytical omics data, animal health data, preclinical data (cell and animal-based laboratory data), 
spontaneous adverse event reporting data, chemical and manufacturing control data, and more. 
 
 
1 A “Horizontal system” provides a specific set of functionalities across a variety of use cases. In this case the intentions to 
develop systems and approaches to DQ that can be used (and potentially shared) across use cases. “Horizontal system” is 
defined by contrast to “Vertical system”, where all DQ processes and system would be developed ad hoc and targeted to a 
specific use case.

## Page 7

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 7/42 
 
4.1.  Definition of data 
In this DQF, data are considered as any information asset that represents measurements or 
observations and that can be used to support decision making, directly or indirectly through analysis. 
4.2.  Definition of DQ  
In general terms, quality is defined as an attribute of a product or service that defines the degree to 
which it meets customer and other stakeholder needs within statutory and regulatory requirements or 
its fitness for intended use[2]. The same principle applies to data and for the purpose of this 
document, the following definition is adopted: 
Data quality is defined as: “fitness for purpose for users’ needs in relation to health research, policy 
making, and regulation and that the data reflect the reality, which they aim to represent” [2]2. 
Therefore, this DQF restricts its scope to determinants of DQ that are relevant for regulatory decision 
making. 
4.3.  Limitations of scope 
Following the definition of DQ and the restricted focus on regulatory decision making this framework’s 
scope excludes: 
• 
Analytical methods to derive evidence, i.e., conclusions and insights, from underlying data. This 
framework focuses on defining guidelines about assessing the level of the quality of the data used 
for regulatory decisions, not on their actual usage for regulatory decision making and the methods 
involved. While data quality and methods for evidence generation are effectively a continuum in 
terms of decision making, when taking the perspective of data collection, dissemination, and re-
use, they are distinct. 
• 
Aspects of DQ that do not directly impact regulatory decision making e.g., conciseness or 
accessibility. For instance, conciseness is a relevant dimension of data quality in that it affects 
fitness for purpose when transmitting or archiving large datasets (e.g., for genomics data). 
However, it is not relevant in terms of data being fit for purpose to answer a specific (regulatory) 
question. Accessibility can also be an important aspect of DQ, but in the context of a regulatory 
activity, data is by definition accessible to interested parties3. 
• 
Data transparency, intended as the characteristic of data being used lawfully, traceably and for 
valid purposes is also excluded from this framework. Issues related to data transparency go 
beyond data quality assessment in support of decision making4. Rather, this framework provides 
guidelines that can be part of a broader set of recommendations to support Data Transparency. As 
for accessibility, it should be noted that there may be an indirect impact of transparency to data 
quality, and this will be addressed, when relevant, in extensions of this Framework. 
• 
Quality of the underlying elements the data refer to e.g., when considering a dataset about the 
purity of a medicine, this framework will cover the reliability, completeness, and other aspects of 
 
2 Note that reality is in general not fully observable. In this definition we consider how data reflects aspects of reality that 
data is designed to capture (e.g.: disease frequency in a population). Context is important to understand how what is 
observed relates to whole. 
• 
3 In some cases, aspects of DQ that do not directly relate to decision making, may have an indirect impact on it, e.g., 
a data source that is broadly accessible will likely be less opaque, more validated, and potentially of higher quality. 
Such aspects might be considered and possibly quantified in future extensions of this framework. 
 
4 As an example, the EU GDPR regulation defines transparency as: “The principle of transparency requires that any 
information addressed to the public or to the data subject be concise, easily accessible and easy to understand”. This poses 
a broader set of requirements than what is strictly related to the use of data for regulatory decision making.

## Page 8

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 8/42 
 
the data, but not aspects of quality (in this case purity or pharmaceutical quality) of the medicine 
per se. 
• 
Semantic interoperability and standardisation are key DQ aspects for data usability and for the 
implementation of a DQF, but they do not affect the fitness for purpose of date respect to decision 
making (e.g.: a “false” dataset would not become less “false” if represented in a standard way). 
Therefore, the provision of guidelines and recommendations to define and select standards for 
interoperability shall fall out of the remits of this DQF. It falls within the scope of this document to 
suggest the application of standards to facilitate DQ assessment. 
• 
Recommendations for the specific design of systems, processes, and responsibilities to guarantee 
DQ, or specific solutions or products. This framework focuses on the principles that such systems, 
processes and the resulting data should follow, to enable and optimise the use of such data for 
regulatory activities. 
4.4.  Structure of this DQF 
The DQF for EU medicines regulation is composed of two parts, reflecting different stages in the 
specification process. 
The first part (general framework) is designed to provide a coherent approach to DQ, encompassing a 
broad range of data types and extensible to novel use cases5. To achieve this, it provides a common 
ground on different DQ aspects that apply to different data types and scenarios: definitions, DQ 
dimensions and examples of metrics covering such dimensions. It further identifies general patterns for 
the applicability of DQ processes and it articulates a set of maturity models designed to drive increased 
automation of data-driven medicines regulatory decision making. 
The second part (framework specialisation) specialises and eventually extends such generic 
recommendations to cater for specific data types or regulatory questions. This part poses the basis for 
the derivation of actual implementable guidelines, which will need to evolve as data and technologies 
change over time. 
This document is the first version of the DQF for EU Regulatory Network [15]. It focuses on the general 
framework and addresses terminology, definitions, and general guiding principles around DQ in the 
context of medicines regulation. In the upcoming years, the DQF will be updated regularly with further 
deep dives in regulatory use cases of particular interest. The document will be in line with 
developments in TEHDAS to further strengthen the EMA data qualification process and the 
collaboration with the European Health Data Space (EHDS). 
A glossary with the main terms and definitions can be found in chapter 9.  
5.  General considerations underlying the maintenance and 
assessment of DQ 
5.1.  DQ determinants for evidence generation 
The landscape of data that can be potentially used for regulatory purposes extends to diverse data 
sources, each generated through different processes and fit for different primary and secondary uses. 
When considering the overall quality of a dataset at the point of regulatory decision making, it is 
important to distinguish what contributes to quality, and what can be measured or controlled at what 
 
5 In the context of this framework, “use-case” is used as a broader synonym of “regulatory question”, when referring to a 
set of related questions and related activities.

## Page 9

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 9/42 
 
stage. In this framework, such elements related to DQ are referred to as “determinants” and classified 
into three categories (see figure 2): 
1. Foundational determinants pertain to the processes and systems through which data are 
generated, collected, processed, and made available. Foundational determinants are what affects 
the quality of data, but it’s not part of the data themselves. As such, they do not depend on, and 
cannot be completely derived from, the content of a dataset. For data to be trusted for regulatory 
decision making, the underlying infrastructure and processes that collect, host, transform and 
move the data must be designed in such a way that the correspondence between data and the real 
entity it represents is not altered. Examples of foundational determinants are the use of certified 
software systems to collect and process data, the presence of processes, training, and audit 
processes to ensure data are properly recorded and documented, the validation and verifiability of 
data processing steps. 
2. Intrinsic determinants of data pertain to aspects that are inherent to a given dataset. Intrinsic 
determinants are what can be derived given a dataset and possibly some external generic 
knowledge, but without the context in which the data were generated, as well of the context the 
data will be used in (e.g., a scientific or regulatory question). Examples of intrinsic determinants 
are coherent or incoherent formatting, the presence of errors (e.g., truncation) or the plausibility 
of the data. 
3. Question specific determinants pertain to aspects of DQ that cannot generally be defined 
independently of a specific question or approach to analysis. Examples of question specific 
determinants are the acceptability of the completeness of a dataset, or its level of approximation 
(e.g., date expressed in dates or months) to answer a specific question. 
In general, foundational determinants have a direct impact on DQ. When they cannot be controlled, 
the only option is to control the intrinsic aspects of DQ. The scope of such control is limited in its ability 
to assure fitness for purpose when a question (or set of typical questions) is not defined. 
 
 
Figure 2 - Determinants of data quality

## Page 10

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 10/42 
 
5.2.  DQ along the evidence generation process 
Data that are suitable and available for evidence generation go through a process (part of a broader 
“life cycle”6) that is specific to the type of data, the processes and organisations that produce it. For 
data that is already collected (secondary use), a fit for purpose assessment for the intended use should 
be done prior to this process. DQ checks occur at various steps of this process and may include 
iterative feedback loops.  
As a reference, a general high-level lifecycle is outlined as follows (see Figure 3): 
• 
Definition of data requirements: what data are sought, and what their characteristics should 
be. For primary data this phase can include elements directly related to evidence generation. 
• 
Data collection or generation: gaining data reflecting the observed reality. 
• 
Data management and processing: including data transfers, normalisation, and cleansing. 
• 
Data publishing: making data available to consumers. 
• 
Data procurement and aggregation: sourcing data from one or more consumers. 
• 
Testing and acceptance: assessing the suitability of the procured data for intended needs. 
Delivery for consumption: using data to support a specific activity, e.g., analysis. 
Not all phases here presented are present in all data workflows (e.g., data collected from sensor or 
social data may be collected on a “what is available” basis, rather than based on specific requirements) 
and possibly extra phases may apply, and the order may differ. 
For the scope of the assessment and management of DQ, it is important to establish what 
determinants apply at which stage of this process, and what may be the impact. For instance, intrinsic 
aspects of DQ can be measured and such measures could be used to improve reliability at the stage of 
data collection and generation, or it could be used to provide an assessment of quality at publication 
time. Integration with additional data would require re-assessment. Question-specific determinants of 
DQ need to be assessed each time data are repurposed to answer a question it was not originally 
collected or designed for. 
DQ checks occur at various steps along the evidence generation process and may include iterative 
feedback loops as indicated by the dashed line in figure 3. 
 
 
6 The data life cycle is broader in that it would extend to aspects of data disposal and maintenance beyond usage.

## Page 11

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 11/42 
 
Figure 3 - A typical data processing workflow in the evidence generation process 
5.2.1.  DQ vs standardisation 
From the point of view of regulatory decision making, DQ is distinct from data standardisation: data 
that are not fit for purpose in terms of answering a regulatory question will not become fit when 
standardised, and non-standardised data can be still used to answer a regulatory question. DQ also 
applies to individual and non-standard data sources. 
The implementation of systems and processes to assure DQ is largely affected (and in some cases fully 
determined) by the adoption of standards7 as well as by data management recommendations (e.g., 
FAIR data [Findable, Accessible, Interoperable and Reusable]) [16], and the availability of resources 
such as ontologies and MDM systems that underpin semantic interoperability. 
Therefore, recommendations on specific standards and standardisation processes are not included in 
this Framework, while adoption of standards does drive implementation maturity levels. 
5.2.2.  Primary vs secondary use of data 
Primary data collection is a process of collecting original data (newly collected), directly from the 
source. It can be gathered from observations, interviews and from biometrics (blood pressure, weight, 
blood tests, etc.) or surveys (questionnaires). Primary use of data is the use of information for the 
specific purposes they were collected for, while secondary use of data involves using the data that 
have initially been gathered for other purposes. See the glossary for an explanation of primary and 
secondary data.  
In the application of guidelines and metrics, an important distinction arises between primary and 
secondary use of data. When systems are designed to collect and process data for a specified primary 
 
7 It should be noted that data standardization processes may alter the original information and its semantics. As noted later 
in this document, “standardization at source” is preferred to “a-posteriori” standardization.

## Page 12

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 12/42 
 
purpose, or when a set of established requirements for secondary use exist, intrinsic and question 
specific aspects of DQ can already be considered at the time of collection and generation. It is thus 
possible to design systems and processes that guarantee some quality level required for evidence 
generation. In fact, much of the analysis decision and process specification can happen at this stage, 
and downstream analysis focuses on synthesising results and qualifying the level of uncertainty. This is 
generally not the case for secondary use of data, whether intended or opportunistic, where the quality 
criteria for usage may not coincide with the ones relevant for the existing purposes of data collection. 
In these cases, DQ can often only be controlled based on intrinsic determinants. 
5.2.3.  Publication vs data consumption 
Along the data life cycle, data are processed through two different contexts. In one – publication – 
data are generated or collected, processed (sometimes harmonised), and made available. Examples 
are the aggregation of multiple sources of data to provide a dataset that is made available for general 
usage, for instance in a catalogue, or the generation of data by wearables and their “publication” 
through APIs. In the other context – consumption – data are procured and aggregated to support 
analysis. One example would be a study where multiple sources are collected, integrated, and 
harmonised to answer a specific question. 
These two contexts may be overlapping (e.g., when data are collected for a specific primary use) or 
may be very distinct (e.g., when data are collected and published in a catalogue for a range of possible 
foreseen or unforeseen usages usually for secondary analysis). 
It is useful to make this distinction as the purpose and the potential for quality assessment change 
between these two contexts. Even intrinsic aspects of quality for the same dataset may differ. Detailed 
specification of quality assessment may be developed separately for the publication or consumption 
contexts, e.g., for a data catalogue, in terms of acceptable minimal quality for generic usages, or for 
data procurement, in terms of minimal viability for a specific question. 
5.3.  Data and metadata 
Metadata are traditionally defined as “data about data” providing context about their purpose and 
generation (e.g., characterisation of sources, data processing steps, lineage, and data elements 
definitions). When data consist of numeric or unstructured information (e.g., images), metadata are 
typically provided as an addition to a dataset. In general, the distinction between data and metadata is 
not well defined: some information appearing as metadata in one context (e.g., instrument provider 
for a test) can be considered as data in another (e.g., if assessing measurement bias). 
For regulatory decision making, metadata should in general be considered similarly as data. More 
precisely, if some change in metadata would require a revision of derived conclusions, then it should 
be treated as data from the perspective of DQ [17]. In a DQ context, metadata should not be seen as 
limited to metrics (including DQ metrics) and summary description of datasets, but should extend to 
characterisation of sources, processes, and data elements definitions. 
All types of metadata are often published in data catalogues8, which have the purpose of allowing data 
to be discoverable and checked for fitness for purpose without revealing the data themselves. 
 
8 Various metadata catalogues are in development such as DARWIN and ENCePP. An example from Statistics Finland can be 
found here: https://www.aineistokatalogi.fi/catalog.

## Page 13

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 13/42 
 
5.4.  Data immutability 
Data about some measured or observed aspect of reality may change in time, both reflecting the 
actual change in the observed entities, and the change of the available information at some given 
time. For instance, the weight of an individual may change, both due to a change of the individual 
itself, or because of a more accurate reading superseding a previous measurement. 
It is important to distinguish the current data availability (or the current knowledge about reality) from 
the data as it was available at a given time (a specific record of knowledge about reality). The latest 
data reflecting what was known at a given time, is “immutable” in that, by definition, cannot change. 
For any regulatory purpose, evidence should be based on data intended as the record of knowledge at 
a given time. In other words, data used to support regulation should be immutable. This doesn’t imply 
that evidence can never be updated: any update should be considered as a distinct (albeit) related 
dataset. This is a foundational concept implied by most frameworks e.g., ALCOA and FAIR [16]. 
The consequence of this principle is that data used for decision making should be versioned and 
unaltered within any given version. 
5.5.  Data vs information 
In its strictest definition, data represent facts or observations that are unprocessed (e.g., as generated 
by an instrument) while information represents insights originating from such data, once they are 
understood and processed in their context (e.g., a patient’s response to a treatment as opposed to a 
set of individual readouts). 
This Framework focuses on evidence generation that can be provided for decision making and as such 
it goes beyond a distinction between data and information. 
5.6.  Frame of reference (validation vs verification) 
Some aspects of DQ can be measured in respect to different references, contained within the same 
dataset, or existing beyond the scope of the dataset either as a generic reference or external gold 
standard, or as the actual fact in the real world. For instance, the weight of an individual could be 
verified for quality based on its capture in the data (e.g., as a missing value), based on knowledge of a 
natural weight range or verified against a recorded weight in a source document. 
In some frameworks, the assessment of quality within a dataset is referred to as “verification” while 
the assessment in respect to a source record or external gold standard is referred to as “validation”. 
We follow these definitions. 
Note: this notion of validation should not be confused with validation as a form of coherence checking, 
see section 6.3.1. 
5.7.  Granularity of data and DQ 
For structured data, DQ can be typically assessed at different levels of granularity: 
• 
The value level corresponds to a specific data point (e.g., a weight). This is also referred as row 
level when the focus is on all values relative to the same entity9. 
 
9 The term entity is used to denote the subject of a set of values. In an information record, for instance about a sample, 
each value in the record would be expressing the measurement of a variable that relates to the same subject or entity. The 
entity is typically identified in a record via an identifier.

## Page 14

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 14/42 
 
• 
The variable level (also referred to as column level) covers a data point for a whole set of 
individuals (e.g., weight as a variable in a clinical study demographics table). Metrics for DQ at the 
value level are often easily extended to the column level, for instance by converting values to a 
percentage10. 
• 
The dataset level covers an overall set of related observations11. In some contexts, a further 
distinction can be made, within a dataset, between parts of dataset that are about similar entities. 
When such distinction is made, such parts are referred to as table level, as those parts would 
normally appear in distinct tables. 
The concept of granularity also applies to unstructured data, but the definition of its levels is generally 
specific to the data type and hence is not addressed in this general Framework. 
This DQF will focus on the lowest possible level, i.e., for structured data, the value level. However, 
some metrics may be defined only at a higher level. For example, the plausibility of a single record of a 
person with a weight of 300 kg may not trigger a metric violation, but if 80% of the records are above 
300 kg, it will. 
6.  DQ dimensions and metrics 
The definition of DQ dimensions and metrics rely on the general definition of dimension, metrics, and 
measures: 
• 
A dimension represents one or more related aspects or features of reality (e.g., for a physical 
object, its extension, or its durability). 
• 
A metric represents a way to assess the value of a specific feature (e.g., absolute length 
measured in meters under some specified circumstances). 
• 
A measure represents a single instance of a metric (e.g., 2 meters). More measures can be 
combined to derive more general metrics (e.g., average length)12. 
DQ metrics can be defined as indicators that when applied to a data source, can derive an assessment 
of one of more quality dimensions. A single quality metric can be used as an indicator for more than 
one dimension as expressed below in the examples for Coherence. 
For some metrics, acceptance thresholds (e.g., maximum percentage of missing values) can be 
defined. In general, and for unintended secondary usages, such thresholds can be defined only 
depending on the question being asked. However, when data are collected for primary use, or when 
some well-defined secondary uses are targeted, thresholds may be defined (e.g., minimum/maximum) 
that apply even at the point of data collection. The quality of data is the sum of several features13 of 
data, ranging from their correspondence to reality to their representation. It is useful to categorise 
such features in dimensions, which is a set of features whose measure reveals independent aspects of 
DQ. In other words, different dimensions answer different distinct DQ questions. 
Several data frameworks propose an organisation of DQ in dimensions that are similar across 
frameworks, but often inconsistent in the exact definitions. This complicates a coherent assessment of 
DQ when multiple sources are aggregated.  
 
10 This is typically the case for binary or categorical data. 
11 In general, a dataset in support of a specific question will be comprised of homogenous data (e.g., a specific 
measurements) or of disparate types of data, which are related in that they measure (directly or indirectly) the same 
entities. In this sense different parts of a datasets are “linked” as they will share references to same entities. 
12 Note that measures could be unitless and not necessarily contiguous. 
13 Feature is here intended as a synonym of “aspect” or “characteristic”.

## Page 15

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 15/42 
 
This guideline introduces a set of dimensions (see figure 4) that are relevant from a regulatory point of 
view, complement them with a precise definition, possible metrics, and examples. The intention is to 
remove ambiguity and provide a useful reference that can help mapping different conceptualisation of 
quality from a variety of sources to a common denominator that is useful to frame metrics and 
maturity models for supporting evidence generation. 
 
Figure 4 - Dimensions of data quality 
6.1.  Reliability  
Reliability is defined as the dimension that covers how closely the data reflect what they are directly 
measuring. 
The Reliability dimension answers the question: to what degree are data accurate or correctly 
representing an observed reality? When considering the “fit for purpose” definition of quality, Reliability 
covers how correct and true the data are. 
6.1.1.  Reliability sub-dimensions 
Given this definition, sub-dimensions can be defined: 
• 
Accuracy defined as the amount of discrepancy between data and reality. This definition of 
accuracy encompasses measures of the amount of wrong information in a dataset (data 
systematically not reflecting reality) with the formal definition of accuracy in measurements (e.g., 
the distance between the measurements and the real value). For example, the weight of a person 
could be incorrect due to a data transcription error, or because a person is measured fully clothed, 
given a systematic excess weight of 1 to 2 kg.

## Page 16

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 16/42 
 
• 
Precision14 defined as the degree of approximation by which data represents reality. For instance, 
the age of a person could be reported in years or months. 
6.1.1.1.  Other DQ concepts related to Reliability15 
Strictly related to Reliability is the concept of Plausibility, defined as the likelihood of some 
information being true. Plausibility can be a proxy to detect errors: when some combination of 
information is unlikely (or impossible) to happen in the Real-World, this reveals accuracy issues. For 
example, a weight of a person exceeding 300 kg is possible, but the weight of many or all persons in a 
dataset exceeding that value is implausible (unless the foundational determinants indicate otherwise) 
and likely revealing some errors in the measurement or the processing of the data. Plausibility results 
from the comparison of a data item to typical or necessary characteristics of the entity it intends to 
represent and is therefore hard to measure as a pure intrinsic characteristic as it depends on the 
availability of background knowledge or an external gold standard. 
Traceability (also referred to as data lineage or provenance) refers to data presenting the 
knowledge of how data came to be, what source it originated from, and what processing it went 
through before appearing in its current form. Traceability is a feature of data that falls within Reliability 
in that it connects what is measured with the actual data. 
6.1.2.  Considerations for Reliability 
Reliability fundamentally depends on the systems and process in place for the primary collection of 
data and its processing and curation in further phases of the evidence generation process both for 
primary and secondary use cases. 
In the absence of errors, accuracy would not decrease along the data aggregation process. Precision 
may instead decrease when data are harmonised to a Common Data Model (CDM), as this may call for 
less precise representation than original sources to fit the model16.  
Intrinsic aspects of Reliability are hard to measure in a pure data-oriented framework, however 
Plausibility measures can provide a way to detect some classes of errors. Reliability is independent 
from a specific question, though each question, in relation to data, will set a threshold for acceptable 
Reliability.
 
14 This definition of precision encompasses the notion of “reproducibility of values” under repeated measurements, in that it 
captures how “coarse” is the correspondence between data and the characteristic it intends to measure. 
15 ” Other concepts” present relevant aspects of DQ that falls within a dimension or that are in common use, but that don’t 
strictly adhere to definition of the dimension provided.  
16 An example could be a CDM allowing timestamp in seconds where a source may use milliseconds, or a CDM prescribing 
some terminology, which is less specialised in some areas than the one used in the source.

## Page 17

Official address  Domenico Scarlattilaan 6  ●  1083 HS Amsterdam  ●  The Netherlands 
An agency of the European Union   
Address for visits and deliveries  Refer to www.ema.europa.eu/how-to-find-us  
Send us a question  Go to www.ema.europa.eu/contact  Telephone +31 (0)88 781 6000 
© European Medicines Agency, 2023. Reproduction is authorised provided the source is acknowledged. 
 
6.1.3.  Examples of reliability metrics 
Table 1 – Example of metrics for Reliability 
Sub-dimension 
Metric group 
Abstract metric 
 
Reference 
Example 
Plausibility (proxy 
for Accuracy)17 
 
Atemporal 
Plausibility 
Data values and distributions 
agree with internal measurements 
or local knowledge 
Validation 
Height and weight are a positive value. 
Counts of unique subjects by treatment are as 
expected (respect to an applicable gold standard). 
Data values and distributions for 
independent measurements of the 
same fact agree 
Verification 
Oral and axillary temperatures are similar. 
Serum glucose measurement is similar to finger 
stick glucose measurement. 
Logical constraints between 
values agree with common 
knowledge 
Verification 
The patient's sex agrees with sex-specific 
contexts (pregnancy, prostate cancer). 
Values of repeated measurement 
of the same fact show expected 
variability 
Verification 
Weight values are similar when taken by separate 
nurses within the same facility using the same 
equipment. 
Data values and distributions 
agree with trusted reference 
standards 
Validation 
HbA1c values from hospital and national reference 
lab are statistically match under the same 
conditions. 
Equivalent values for identical 
measurements are obtained from 
two independent databases 
representing the same 
observations with equal credibility 
Validation 
Date of birth value in the EHR is not identical to 
that in the registry record of the same patient. 
 
17 Our examples are limited to Accuracy as this is the most common application of Plausibility. In theory, Plausibility could extend to other dimensions of Reliability (e.g., a weight 
expressed in grams is likely to be imprecise if all values end with three zeros).

## Page 18

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 18/42 
 
Sub-dimension 
Metric group 
Abstract metric 
 
Reference 
Example 
Two or more dependent 
databases yield similar values for 
identical variables (e.g., database 
1 abstracted from database 2) 
Validation 
Cancer stage value in the EHR does not 
corresponds with a NAACCR code in the tumour 
registry of the same patient. 
 
 
Calculated data values agree with 
common knowledge  
Validation 
Height and weight of a patient resulting in an 
implausible BMI value of less than 5 propose an 
inaccurate height, weight, or both. 
 
Temporal 
Plausibility 
Observed or derived values 
conform to expected temporal 
properties 
Verification 
Discharge date happens after admission date. 
 
Sequence of values that represent 
state transitions conform to 
expected properties 
Verification 
Date of primary vaccine administration precedes 
that of the booster vaccine administration. 
 
Observed or derived values have 
similar temporal properties across 
one or more external comparators 
(gold standard) 
Validation 
Length of stay for outpatient procedure conforms 
to insurance data for similar populations (no more 
than 1 day). 
 
Sequences of values that 
represent state transitions are 
similar to external comparators 
(gold standards) 
Validation 
Immunisation sequences matches that of the EMA 
recommendations. 
 
Measures of data value density 
against a time-oriented 
denominator are expected based 
on external knowledge 
Validation 
Count of immunisation per month shows an 
expected spike outside of flu season.

## Page 19

Official address  Domenico Scarlattilaan 6  ●  1083 HS Amsterdam  ●  The Netherlands 
An agency of the European Union   
Address for visits and deliveries  Refer to www.ema.europa.eu/how-to-find-us  
Send us a question  Go to www.ema.europa.eu/contact  Telephone +31 (0)88 781 6000 
© European Medicines Agency, 2023. Reproduction is authorised provided the source is acknowledged. 
 
In case a gold standard is not available, a metric can be “verified” based on a comparison with a 
similar metric from another source. This could be equivalent values for identical measurements from 
two independent databases. This is not necessarily a “gold standard” but may be the best available 
option. Alternative methods might be explored when no “gold standard” is available (see 8.6 for more 
details). 
6.2.  Extensiveness18  
 Extensiveness is defined as the dimension capturing the amount of data available. 
The Extensiveness dimension answers the question, “how much data do we have”? When considering 
the “fit for purpose” definition of quality, Extensiveness covers how sufficient the data are. 
6.2.1.  Sub-dimensions of Extensiveness 
When considering the amount of information available, one can think of expressing this as a 
percentage relative to the total amount of information that could be available. The distinction between 
Completeness and Coverage stems from the definition of the scope of totally available information. 
• 
Completeness measures the amount of information available with respect to the total information 
that could be available given the capture process and data format. Data unavailable in the dataset 
(either due to systematic reasons such as information available in the data source but not included 
in the data model, or specific entries that are unavailable for a given field) are called “missing”. For 
example, the percentage of non-missing values for a required field (e.g., sex) in a dataset would 
be a measure for completeness.19 
• 
Coverage measures the amount of information available with respect to what exists in the Real-
World, whether it is inside the capture process and data format or not. Coverage may not be easily 
measured as the total information may not be definable or accessible. An example of coverage is 
the percentage of a given population (e.g., a country or a specific demographics) available in a 
dataset. When considering coverage in its relation to evidence generation methods, it is also 
referred to as observability [18]. 
6.2.1.1.  Other DQ concepts related to Extensiveness 
Two concepts that are often associated to extensiveness are representativeness and missingness. 
While these concepts describe to a certain extent how much data is available, they are more 
importantly used to characterise how much data is reflecting reality. Representativeness is defined 
as the data having the same characteristics as the whole it is meant to represent (e.g., whether a set 
of individuals present in a dataset is representative of a population under study). Missingness is 
meant as the characterisation of what is the impact of incomplete data in respect to coverage of a 
dataset.  
 
 
18 Extensiveness combines two typical dimensions found in DQFs: Completeness of data coverage and Coverage. They are 
here combined as they both relate to the amount of data available. 
19 There is a fundamental distinction between missing data that are known to exist (e.g., the date of birth of a patient), or 
missing data whose existence is unknown (e.g., the presence of co-pathologies). Quite often in a data model the definition 
of a variable as “required “implies that the relative values are known to exist, and therefore when such data is missing it is 
a ”missing known”. In general, in the absence of explicit negation, it may not be possible to distinguish” missing known” 
from” missing unknowns”. When some data point is expected to be captured, the inability to distinguish” missing knowns” 
from” missing unknowns” is an issue of Reliability (one is unable to assesses if data corresponds to the reality it is meant to 
represent).

## Page 20

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 20/42 
 
6.2.2.  Considerations for Extensiveness 
The Extensiveness of the information collected depends on the specification of the data collection 
process. However, when combining different datasets for secondary use, there is no guarantee about 
the completeness of the overall dataset. On an intrinsic level, one can resort to metrics to assess the 
level of completeness of data. Metrics that assess how much data are present in a dataset in respect to 
what could be present in a given data model are fairly simple to compute. Metrics that assess how 
complete the data are with respect to the population they intend to measure, are more complex and 
may involve the engagement of gold standards. Completeness with respect to a schema is easily 
definable, while Coverage depends on some assumptions that can be defined only with respect to a 
question. Thresholds used as acceptance criteria can also be defined with respect to a question (e.g., 
80% complete). 
6.2.3.  Examples of metrics for Extensiveness 
Table 2 – Example of metrics for Extensiveness 
Sub-
dimension 
Metric 
group 
Abstract rule 
 
Reference 
Example 
Completeness 
Missing 
required 
values 
Missing values with 
respect to a local schema 
– over time 
Verification 
Breed or sex of the animal 
should not be NULL. 
Missing values with 
respect to a local schema 
– single time 
Verification 
The encounter ID variable 
has missing values. 
Estimated 
missing 
values 
Missing values with 
respect to common 
expectations 
Verification 
Sudden drop of diagnosis 
codes due to a defective 
feed from a claim clearing 
house vendor. 
Relative assessment of 
missing values with 
respect to a trusted 
source of knowledge 
Validation 
The current encounter ID 
variable is missing twice as 
many values as the 
institutionally validated 
database. 
A drop in ICD-9CM codes 
upon implementation of 
ICD-10-CM. 
Coverage 
 
Coverage of a population 
Verification 
The percentage of a target 
population present in a 
database. 
 
6.3.  Coherence 
Coherence (also referred to as Consistency20) is defined as the dimension that expresses how different 
parts of an overall dataset are consistent in their representation and meaning. 
The Coherence dimension answers the questions: is the dataset analysable as a “whole” or are 
additional steps needed like linkage of multiple datasets? Is the format of values (e.g., dates) the 
same across the dataset? Is the precision of values the same (e.g., age always approximated to 
 
20 Consistency and Coherence can be considered largely synonymous, with the caveat that detection of inconsistencies is 
often a way to measure the reliability of data.

## Page 21

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 21/42 
 
years)? Are references to entities consistent so that information about the same entity is properly 
“linked” across parts of the dataset?  
When considering the “fit for purpose” definition of quality, coherence relates to the analysability of 
data. 
6.3.1.  Sub-dimensions of Coherence 
Coherence is a complex and nuanced dimension that includes the following sub-dimensions: 
• 
Format Coherence: whether data are expressed in the same way throughout a dataset (e.g., a 
dataset mixing dates represented as DD-MM-YYYY and MM-DD-YYYY will not be suitable for an 
integrated analysis). 
• 
Structural or Relational Coherence21: whether the same entities are identified in the same way 
throughout a dataset. A sub-aspect of Structural Coherence is that references are resolved to the 
correct entities (e.g., a sample annotation table with refer to the correct value in a result table). 
• 
Semantic Coherence: whether the same value mean the same thing throughout a dataset. For 
instance, whether “anuria” means a condition of total cessation of urine production or the 
measurement of the amount of urine, or whether the same notion of a measure is intended to 
have the same precision throughout a dataset. 
• 
Uniqueness: Uniqueness is the property that the same information22 is not duplicated but appears 
in the dataset once. This problem is typical for data aggregated from different sources. Note that 
data with some redundancy will score lower in the Uniqueness dimension, but those extra records 
could help improving other dimensions, such as Reliability. 
 
• 
Other DQ concepts related to Coherence is Conformance when this is defined with respect to a 
specific reference or data model. Conformance may practically be the best way to assess 
Coherence, and it also specialised as format, Structural and Semantic Conformance. As an 
example, conformance would assess if the representation of data is coherent by assessing if it is 
the same as an overall target standard (e.g.: DD-MM-YYYY)23.Validity24 is a narrower case of 
Conformance that is defined when the reference model is specific to the dataset being assessed. As 
an example, if a file is associated to a schema specifying that all dates in the D.O.B. filed should be 
in DD-MM-YYYY format, the file could be directly assessed as valid or not. 
6.3.2.  Considerations for Coherence 
Coherence of data at source largely depends on foundational determinants such as the synchronisation 
of processes and systems across an organisation generating data, or when multiple data are 
aggregated on the commitment of such organisation(s) to the use of internal or external data 
standards. By extension, Coherence for data aggregated and repurposed for secondary usage depends 
on the availability of shared standards and reference data. The intrinsic aspects of Coherence of a 
dataset can be improved, largely within a data standardisation processing step. However, improving 
Coherence involves approximating or clarifying the meaning of data. Access to the source system and 
 
21 Structural and relational Coherence as synonyms here. It may be the case that these two concepts are distinct or non-
tabular data. This distinction will be addressed if the need arises, in extensions of this framework to specific data types. 
22 It is worth noting that” information” is distinct from data. Two distinct measurements resulting in the same data would 
not constitute duplicate information (and such measurements would most likely differ in value, when metadata is included). 
Whereas the same measurement reported two times would amount to a duplication. 
23 A file could be coherent, but not conformant, if all values are coherent (e.g.: MM-DD-YYYY) while an overall target 
standard proposed to assess conformance requires DD-MM-YYYY. 
24 As noted in 5.4, this is a different meaning (in common use) then what is defined for” Validation”.

## Page 22

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 22/42 
 
processes is often required for clarifications as an example. Some aspects of semantic Coherence may 
be difficult to assess with a metric and hence can only be assessed with respect to a specific question 
and analysis strategy.

## Page 23

Official address  Domenico Scarlattilaan 6  ●  1083 HS Amsterdam  ●  The Netherlands 
An agency of the European Union   
Address for visits and deliveries  Refer to www.ema.europa.eu/how-to-find-us  
Send us a question  Go to www.ema.europa.eu/contact  Telephone +31 (0)88 781 6000 
© European Medicines Agency, 2023. Reproduction is authorised provided the source is acknowledged. 
 
6.3.3.  Examples of metrics for Coherence 
Table 3 – Example of metrics for coherence 
Sub-
dimension 
Metric 
group 
Abstract rule 
Reference 
Example 
Format 
coherence 
(conformance) 
Syntactic 
constraints 
Data Values conform to 
internal formatting 
constraints 
Verification 
Sex is only one ASCII character. 
Allowed 
values 
Data values conform to 
allowable values or 
ranges 
Verification 
Sex for the animal only has values 
“M”, “F”. or “U”. 
Data values conform to 
the representational 
constraints based on 
external standards 
Validation 
Values for primary language 
conform to ISO standards. 
Relational 
coherence 
(conformance) 
Reference 
Coherence 
Data values conform to 
relational constraints 
Verification 
Patient medical record number 
links to other tables as expected. 
Unique (key) data 
values are not 
duplicated 
Verification 
A medical record number is 
assigned to a single patient. 
Data values conform to 
relational constraints 
based on external 
standards 
Validation 
Data values conform to all not-
NULL requirements in a common 
multi-institutional data exchange 
format. 
Schema 
Coherence 
Changes to the data 
model or data model 
versioning 
Verification 
Version 1 data does not include 
medical discharge hour.

## Page 24

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 24/42 
 
Sub-
dimension 
Metric 
group 
Abstract rule 
Reference 
Example 
Computation
al Coherence 
Computed values 
conform to 
programming 
specifications 
Verification 
Database calculated and hand 
calculated BMI (body mass index) 
values are identical. 
Computed results based 
on published algorithms 
yield values that match 
validation values 
provided by external 
sources 
Validation 
Computed BMI percentiles yield 
identical values compared to test 
results and values provided by 
EMA. 
Semantic 
coherence 
(conformance) 
Precision 
Coherence 
The precision of values 
is fitting a target 
standard 
Verification 
E.g., two decimal digits are used 
and generally not zero. 
Semantic 
Coherence 
Use of code lists is 
consistent across data 
Verification 
E.g., the level of a MedDRA coding 
for an indication doesn’t vary 
across the dataset. 
Uniqueness 
 
Same subject is 
represented with the 
same identity 
Verification 
William Smith is also represented 
as Bill Smith with the same DOB. 
Same subject is 
represented with 
multiple identities 
Verification 
William Smith and William Smith 
appear as separate individuals 
instead of the same individual. 
The data records of 
individuals are matched 
using unique keys 
Validation 
William Smith’s DOB ID matches 
with Bill Smith’s DOB and ID.

## Page 25

Official address  Domenico Scarlattilaan 6  ●  1083 HS Amsterdam  ●  The Netherlands 
An agency of the European Union   
Address for visits and deliveries  Refer to www.ema.europa.eu/how-to-find-us  
Send us a question  Go to www.ema.europa.eu/contact  Telephone +31 (0)88 781 6000 
© European Medicines Agency, 2023. Reproduction is authorised provided the source is acknowledged. 
 
6.4.  Timeliness 
Timeliness is defined as the availability of data at the right time for regulatory decision making, that in 
turns entails that data are collected and made available within an acceptable time25. 
The Timeliness dimension answers the question: are the data reflecting the intended reality at the 
point of time of its use? 
When considering the “fit for purpose” definition of quality, Timeliness covers how closely the data 
reflect the intended reality, at the time in which it is used. 
6.4.1.  Sub-dimensions of Timeliness 
• 
Currency is a specific aspect of Timelines that considers how fresh the data are (e.g., current, and 
immediately useful)26. 
6.4.1.1.  Other DQ concepts related to Timeliness 
In the context of this Framework Lateness, intended as the aspect of data being captured later than 
asserted, falls in the dimension of Reliability (does the data correspond to reality, at the time it 
intended to measure?).  
6.4.2.  Considerations for Timeliness 
Timeliness is determined by the systems and processes used to collect and make data available. 
6.4.3.  Examples of metrics for Timeliness 
Table 4 – Example of metrics for timeliness 
Sub-dimension 
Metric group 
Abstract rule 
Reference 
Currency 
N/A 
The average time of updates in a database (or 
timestamp)27 
Verification 
The last update of a database (or timestamp) 
Verification 
6.5.  Relevance 
For the purpose of Data Quality assessment, relevance is defined as the extent to which a dataset 
presents the data elements useful to answer a given research question. This definition is narrower and 
more data-focused than the more commonly understood meaning of “relevance”28 (i.e.: relevance of a 
 
25 While Timeliness is not further distinguished in this version of this framework, the definition highlights two different 
aspects of Timeliness: respect to the time data is measured (e.g.: delay between measurements of body temperature 
respect to the onset of fever), and respect to the time data is collected (e.g.: made available in a database). 
26 Note that the lack of currency doesn’t imply a lack of timeliness: historic data may lack currency, but still be timely for 
retrospective studies, 
27 Measures of Currency focus on a narrower aspect of Timeliness and are generally based on the time data are actually 
recorded in a database (rather than the time of data collection). 
28 Relevance as a common term is defined as the degree to which something is related or useful to what is happening, 
discussed about or for a given objective.

## Page 26

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 26/42 
 
data source to generate valid evidence informing a specific research question based on the study 
design). 
To distinguish these two meanings, this text explicitly makes use of the terms “Relevance DQ 
Dimension” (relevance as here defined), and “Relevance to a question” (the more generic meaning). 
The Relevance DQ dimension answers the question: does the dataset present the values (or data 
elements) that are needed to address a specific question, using a specific method?29 . 
When considering the “fit for purpose” definition of quality, the Relevance DQ dimension describes how 
the data cover the aspects of reality that are intended to be measured. 
In this framework, relevance to a question is captured by “question specific determinants” that apply 
to all dimensions. 
The dimension previously introduced partition DQ aspects on the basis for some driving questions (is 
data truly representing reality? How much data is there? Is data analysable as a whole? Is data 
available at the right time?). A missing question is about what type of data is there, and this is what 
the “Relevance DQ dimension” is covering. 
Given the context described, Relevance can only be characterised in relation to a research question 
and a data analysis strategy30. However, in some cases, it is possible to identify a set of frequently 
required research questions that can be characterised from the Relevance point of view, in the context 
of a specific type of data source. This is referred to as Relevance for a domain, where ‘domain’ is a 
shorthand for a ‘research questions domain’.  
6.5.1.  Examples of metrics for Relevance31 
Table 5 – Example of metrics for relevance 
Sub-dimension 
Metric group 
Abstract rule 
Reference 
Example 
N/A 
N/A 
The number of variables (columns) 
available in a given dataset vs the 
number of required variables. 
Verification 
N/A 
7.  General recommendations and maturity models 
Selecting datasets to use in regulatory decision making ultimately requires knowledge of the degree to 
which such data satisfy the Reliability, Extensiveness, Coherence, Timeliness and Relevance criteria. 
Such quality dimensions build up along an overall life cycle from generation through processing to 
aggregation and ultimately analysis, and in such process, data originally gathered for other usages can 
be repurposed when ethical or legal requirements are met [19]. 
The choice of quality measures and checks varies broadly depending on data types and their intended 
use. However, it is possible to organise such measures and checks following a coherent structure that 
helps achieve homogeneity and identify gaps. 
The following tables exemplify how determinants of quality (Foundational, Intrinsic or Question-
Specific) affect the different quality dimensions for both data and metadata. These tables provide a 
 
29 The distinction between Extensiveness and Relevance can be clarified by the two distinct questions that these dimensions 
are answering: how much data do we have? (Extensiveness) vs what data to we have? (Relevance). 
30 By data analysis strategy, the definition of assumptions, decisions, and methods to address a specific question is 
intended.  
31 This metric is provided as an example to clarify what pertains to the dimension of Relevance. Not all variables are 
equivalent and actual metrics will need to be specified for specific use cases and/or data types.

## Page 27

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 27/42 
 
guidance for what metrics and actions apply at which stage of the data life cycle. For example, the 
dimension of Extensiveness is determined exclusively by Foundational determinants at production 
time. Further in the data life cycle, data intrinsic measures can only partially assess the degree of 
Reliability (plausibility metrics). 
These tables also form the basis for the development of maturity models for the characterisation of DQ 
for regulatory purposes. The maturity models provide guidance as to how determinants can be 
characterised in successive levels of maturity. Higher maturity levels   support the strongest possible 
evidence in the most efficient way.  
Three distinct maturity models are provided, corresponding to the three determinants, to depict how 
maturity evolves with respect to process characterisation, intrinsic aspects (metrics) and the definition 
of target questions. These models are meant to apply to the different steps and actions that compose 
an overall evidence-generation framework. 
It should be noted that the maturity models provided are abstract in the sense that they provide the 
classes or recommendations that need to be complemented with implementation detail for specific data 
types and use cases. 
It takes time to characterise and implement processes to achieve higher maturity levels both for data 
source holders, but also for regulatory assessors to understand the impact of a higher maturity model. 
This is also context dependent e.g., disease area, disease frequency, health system etc. The DQF will 
be updated in the upcoming years with further deep dives in regulatory use cases of particular interest 
to guide clinical assessment for medicines regulation.

## Page 28

Official address  Domenico Scarlattilaan 6  ●  1083 HS Amsterdam  ●  The Netherlands 
An agency of the European Union   
Address for visits and deliveries  Refer to www.ema.europa.eu/how-to-find-us  
Send us a question  Go to www.ema.europa.eu/contact  Telephone +31 (0)88 781 6000 
© European Medicines Agency, 2023. Reproduction is authorised provided the source is acknowledged. 
 
Table 6 – Characterisation of the effect of determinants on data quality dimensions 
 
Determinant/ 
Dimension 
Reliability 
Extensiveness 
Coherence 
Timeliness 
Relevance 
Foundational 
 
Primary 
Data collected following 
established protocols can 
be sufficient to address 
regulatory questions. 
 
 
Primary 
Normally guaranteed by 
the design of the data 
collection process. 
 
Primary and secondary 
Data reliability (in all its 
aspects) results from 
systems and processes in 
place for data generation 
or collection. 
Reliability is affected by 
data processing and 
transformations at later 
stages e.g., 
standardisation to a CDM. 
Primary and secondary 
The data collection 
protocol determines what 
data are collected. 
 
Primary and 
secondary 
Dependent on the 
orchestration of 
processes originating 
data and on the 
commitment to internal 
or external data 
standards. 
Primary and 
secondary 
Solely determined 
by systems and 
processes. 
 
 
Secondary 
Precision may decrease 
during data 
transformation and 
harmonisation processes. 
Secondary 
There is no guarantee on 
the completeness of an 
integrated dataset or its 
coverage for a different 
use case, and this can 
only be assessed or 
controlled. 
Secondary 
Relies on shared 
standards and 
reference data. 
Documentation on data 
generation processes 
may be needed to 
enhance coherence. 
 
Secondary 
Normally assessed for a 
specific use or a class of 
usages when datasets 
are selected. 
Intrinsic 
Primary and secondary 
Plausibility measures can 
be used to detect a 
(limited) class of reliability 
issues. 
Primary and secondary 
Completeness measures 
based on a data model are 
easy to implement. 
 
Primary and 
secondary 
Coherence can be 
measured exclusively 
based on data (with 
eventual access to 
Primary and 
secondary 
Some aspects of 
timeliness may be 
observed in the 
datasets (e.g., event 
Primary and 
secondary 
Relevance of data is not 
dependent on a dataset 
itself.

## Page 29

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 29/42 
 
Determinant/ 
Dimension 
Reliability 
Extensiveness 
Coherence 
Timeliness 
Relevance 
Direct measures of 
accuracy require access to 
the source of data. 
datasets-independent 
reference data). 
 
dates to determine 
currency). 
A dataset itself 
cannot in general 
reveal how current 
its information is. 
 
 
Secondary  
Coverage measures are 
more complex and may 
require confrontation to a 
golden standard. 
Secondary 
Coherence can be 
largely improved based 
solely on a dataset and 
data-independent 
elements (e.g., 
mapping to a common 
standard).  
A full resolution of 
coherence may require 
access to additional 
information on 
processes. 
Coherence needs to be 
assessed every time a 
new data source is 
“integrated”. 
 
 
Question 
specific 
Primary 
Processes and systems to collect data are usually designed to answer a specific question and to meet the required targets, across DQ 
dimensions, that such target entails. 
 
Secondary 
Threshold for acceptable 
reliability can be defined 
only respect to a specific 
question and method. 
Secondary 
Coverage and 
completeness depend on a 
question: metrics can be 
defined only respect to a 
specific question and 
method, or for a domain. 
For completeness, 
typically a question would 
determine a set of 
acceptance thresholds and 
general metrics. 
Secondary 
Some assessment of 
semantic coherence 
(data distribution 
coherence or 
abstraction coherence) 
may only be measured 
respect to a specific 
question and method. 
Secondary 
Acceptable 
timeliness depends 
on the question and 
its broader 
regulatory usage 
(e.g., approval vs 
monitoring).  
Secondary 
Relevance can only be 
determined in relation to 
one or more questions.

## Page 30

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 30/42 
 
Table 7 – Characterisation of the effect of determinants on Metadata quality dimensions 
Determinant/Dimension 
Reliability 
 
Extensiveness 
 
Coherence 
Timeliness 
 
Relevance 
 
Foundational 
 
Primary 
For primary data, 
the extensiveness 
of metadata can be 
characterised at 
source. 
Primary 
Metadata 
coherence relies on 
the presence of 
common standards 
and terminologies. 
 
Primary 
Normally guaranteed 
by the design of data 
collection process. 
Primary and secondary 
Reliability of Metadata relies 
on the processes to collect it, 
along the whole data 
processing chain. 
One key aspect to ensure 
reliability is to capture 
metadata as close to the 
source as possible. 
 
 
Primary and 
secondary 
Timeliness of 
Metadata are purely 
dependent on the 
processes 
supporting its 
collection. 
 
 
 
Secondary 
For secondary data, 
coherence relies on 
the presence on 
widely agreed 
standards and 
shared resources 
such as ontologies 
or reference data 
services. 
Secondary 
When data are 
repurposed and 
used in different 
systems, timeliness 
of metadata should 
be enforced by 
design (metadata 
should be in synch 
with the data). 
Secondary 
Relevant metadata 
can be required and 
controlled by a 
downstream system 
but cannot be 
guaranteed at 
source. 
Intrinsic 
Primary and secondary 
Some metadata (e.g., 
summary statistics) can be 
generated from a dataset. 
When data and metadata are 
considered as whole, 
traceability can also be 
assessed by intrinsic 
measures. 
 
Primary and 
secondary 
Intrinsic measures 
for meta DQ mimic 
the ones for data 
(e.g., completeness 
and missing fields). 
Unlike data, 
metadata 
assessment may 
not require 
references to 
Primary and 
secondary 
Metadata 
coherence solely 
depends on a 
specific metadata 
and data-
independent 
elements (e.g., 
shared reference 
data). 
 
Primary and 
secondary 
The assessment of 
timelines aspect of 
data typically 
depends on 
metadata (e.g., 
timestamps). 
 
Primary and 
secondary 
Relevance of 
metadata does not 
depend on a dataset 
itself.

## Page 31

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 31/42 
 
golden standards 
(e.g., missing 
metadata values is 
not related to 
sampling of a 
population). 
Question specific 
Primary 
Metadata requirements are designed for a specific question and are normally sufficient to address it. 
Primary and secondary 
Metadata should be in general 
reliable independently of a 
specific question (not all 
metadata collected may be 
relevant for all questions). 
 
Primary and 
secondary 
The coherence of 
metadata is 
independent from a 
specific question. 
Primary and 
secondary 
Timeliness of 
metadata are 
independent from a 
specific question. 
 
 
Secondary 
The 
characterisation of 
what metadata are 
necessary is 
ultimately 
dependent on a 
question (or set of 
typical questions) 
 
 
Secondary 
Relevance of 
metadata is purely 
dependent on a 
question (or range of 
questions).

## Page 32

Official address  Domenico Scarlattilaan 6  ●  1083 HS Amsterdam  ●  The Netherlands 
An agency of the European Union   
Address for visits and deliveries  Refer to www.ema.europa.eu/how-to-find-us  
Send us a question  Go to www.ema.europa.eu/contact  Telephone +31 (0)88 781 6000 
© European Medicines Agency, 2023. Reproduction is authorised provided the source is acknowledged. 
 
7.1.  Foundational determinants: Recommendation and maturity levels  
A characterisation of the systems and processes underpinning data generation and manipulation 
(foundational determinants) is necessary to manage DQ. Below is a set of defined maturity levels, each 
providing a progressive hierarchy of recommendations for the characterisation of foundational 
determinants, with the intention to chart a direction of improvement towards adequate and efficient 
characterisation of these aspects of DQ (see figure 5). It is recommended that FAIR principles [16] for 
data and metadata be implemented as early as possible, or partially, along maturity models. 
 
 
Figure 5 - Maturity model for data quality determinants 
7.1.1.  Level 1: documented 
For data to be adequate for decision making, at a minimum, the processes that pertain to data 
generation and manipulation should be documented, true, verifiable (when relevant, this may extend 
to training procedures) and versioned. This is fundamental and ensures the reliability of any derived 
information. The documentation should cover determinants for Reliability (Precision), Extensiveness, 
Coherence and, when relevant, Timeliness. While some of these determinants depend on a specific 
question, data collection processes and systems will generally be designed with some generic questions 
in mind. The provision of documentation for data processing and transformation are also essential to 
guarantee that Reliability is preserved and should be provided for all such processing by different 
actors along the data life cycle.

## Page 33

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 33/42 
 
From a metadata perspective, this means metadata (in some form) should always accompany a 
dataset it refers to. 
To guarantee the quality of data, audit procedures or other controls should be in place. 
When a system is designed for continuous data collection (as opposed to a one-off capture), additional 
processes of performance monitoring and improvement should be in place. 
7.1.2.  Level 2: formalised 
The second level of the maturity model includes and extends the first level, by requiring that, 
whenever possible, documentation and metadata should be following an industry standard framework 
or QMS32 . Level 2 should be considered the minimal level of acceptable maturity, though exceptions 
may arise for novel data types. The recommendation to use standards extends to metadata. 
7.1.3.  Level 3: implemented 
Systems are in place that implement industry standard DQ processes systematically and by design. 
Infrastructure should be in place to support data management, including support for standardisation 
(e.g., reference data management or MDM). By reducing the potential for human error, such an 
implementation can generally improve Reliability and Coherence. Such an implementation may also be 
necessary to guarantee Timeliness and it should ensure that metadata are collected by design, and as 
close to the data generation or collection events as possible. 
7.1.4.  Level 4: automated  
The operations and output of the above systems and infrastructure should be machine readable as to 
unify data and DQ elements for direct downstream consumption. All data and metadata should be 
represented following FAIR principles [15] to allow complete automatic processing of quality 
parameters This is intended to be an aspirational level. 
7.2.  Intrinsic determinants: Recommendations and maturity levels  
Beyond documented evidence of how data were collected or generated, measures of intrinsic aspects 
of DQ can be applied. These can be directly derived from the dataset, but their computation could also 
rely on some external body of knowledge. 
7.2.1.  Level 0: intrinsic 
There are no hard minimal requirements for quality, as any piece of data can be assessed before being 
used to generate evidence33. Nevertheless, the propagation of data without an associated quality 
assessment should be discouraged. 
7.2.2.  Level 1: metadata 
Data are provided with a set of quality metrics as metadata. Some of these data can be directly 
derived from the dataset while other derive from the overall data collection process (e.g., sampling). 
 
32 What industry standards or frameworks applies depend on specific data types and use cases, and as such can be defined 
only in specialisations of this framework. Some initial references are however provided in the ”implementation notes” 
session. 
33 This initial level is assigned "0" to clarify that it corresponds to data "as is" irrespective of their intended use for 
regulatory decision making.

## Page 34

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 34/42 
 
Metadata should also cover the description of data elements that are necessary for its interpretation 
(e.g., data dictionaries). 
7.2.3.  Level 2: standardised 
Data are provided with a standardised set of quality metrics, which can be compared across datasets. 
When applicable or possible, standards should extend to cover reference knowledge that can be used 
to assess a dataset in respect to what it is meant to represent (e.g., typical population distributions to 
assess biases). Metadata makes use of shared definitions, which also enable comparability and 
integration across datasets. 
7.2.4.  Level 3: automated 
Quality assessment is automated (at least for a large extent of metrics). In general, this is feasible 
only when data are represented in standard ways (e.g., in a CDM), so that a standard library of tests 
can be run on incoming data. Data and metadata should follow FAIR principles [16]34. 
7.2.5.  Level 4: feedback 
There is a data ecosystem in place so that quality assessment by data consumers can provide feedback 
to improve the data collection and production process, thus allowing a continuous monitoring and 
improvement of DQ. 
(Note that the order of maturity of level 2 and 3 may change for particular data types.) 
7.3.  Question-specific determinants: Recommendations and maturity levels 
In general, it is not possible to assess the Relevance of a dataset, or aspects of Extensiveness and 
Precision, without a target question and a defined analysis strategy. However, when considering the 
adoption of a large body of data for regulatory decision making and its possible use beyond primary 
use cases, it becomes important to articulate to what degree DQ, including Relevance, can be assessed 
a-priori. 
7.3.1.  Level 1: ad-hoc 
All dimensions that are question specific are assessed only at “question time” on an ad-hoc basis. 
7.3.2.  Level 2: domain-defined 
A range of common questions is identified, from which metrics and thresholds can be derived that can 
be used to guarantee acceptable levels of quality. Data published in data catalogues should make use 
of such metrics. 
7.3.3.  Level 3: question-defined 
The requirements for a specific question are precisely codified and can be mapped to metrics and 
thresholds in a way that could automatically assess the Relevance of a dataset for a specific question. 
At this level, the context under which data will be interpreted for decision making should be formalised 
 
34 As for foundational determinants, FAIR principles should be applied as early as possible, at least partially. Level 3 
requires a full implementation of FAIR principles.

## Page 35

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 35/42 
 
and shareable. This is the natural level for primary use cases, while for secondary use of data, this 
should be intended as an aspirational level. 
8.  Considerations for implementation of DQF 
This section provides a set of observations and recommendations to guide the implementation of this 
DQF and its specialisations, to help achieving higher levels of maturity. 
8.1.  Quality at source 
As a general guideline, in designing data collection and generation processes, aspects of DQ should be 
addressed as early as possible. For instance, assessment of quality done close to the moment of 
production can help in correcting a collection error. The further data travels from the original context, 
the harder it becomes to correct issues. This is particularly relevant for metadata as knowledge of the 
context of data generation is maximally present only at generation time. 
8.2.  The role of Master Data Management (MDM) and reference data 
The availability of MDM and reference data has a direct impact on DQ. It is often a pre-requisite for 
data consistency, and it can even impact Reliability in some data production scenarios (e.g., materials 
data), as disconnected information can result in erroneous information. More broadly, MDM and 
reference data enable automation of a range of DQ checks and hence have an impact on Reliability as 
well. 
Shared MDM and reference data can address aspects of Coherence beyond the primary use case that 
the data were generated for, as the use of standards guarantees some level of Semantic Coherence is 
maintained even beyond data aggregation steps. 
8.3.  The role of QMS and computerised systems 
The implementation of a DQF at higher maturity levels requires the formalisation and implementation 
of systems and processes to support DQ. 
A Quality Management System (QMS) [20] is a formalised approach adopted by an organisation that 
documents processes, procedures, and responsibilities for achieving quality policies and objectives 
(e.g., Good Clinical Practices [GCP], Good Laboratory Practices [GLP] or Good Manufacturing Practice 
[GMP]). It achieves these quality objectives through quality planning, quality assurance, quality control 
and quality improvement. Standards like the ISO 9000 family define QMS across industries, while more 
specific QMS have been developed for specific industry or products. Life Science Industry specific QMSs 
should be considered depending on the nature of the data: 
• 
Clinical trial data: ISO 14155 and EU Directive 2001/20/EC for GCP (clinical trial data) 
• 
Data from medical devices or diagnostic products: ISO 13485 Quality System Regulation (QSR)  
• 
Data from lab research: EU Directive 2004/9/EC and 2004/10/EC, GLP 
• 
Data from clinical labs: ISO 15189 and ISO 17025 
Whenever possible DQ processes should be framed in the context of standard QMSs. 
Furthermore, in today's digital world, foundational DQ determinants are also impacted by computerised 
systems, that are used to create, modify, maintain, archive, retrieve, or transmit data. A software 
development life cycle including software quality assurance system ensures the appropriate design, 
development and testing of the software. This can be targeted through the ISO 250xx standard family,

## Page 36

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 36/42 
 
named Systems and Software Quality Requirements and Evaluation (more specifically, data models can 
be addressed with ISO 25012). Computer system qualification and validation ensures the software is 
appropriately implemented, and necessary process controls are in place for using it according to its 
specifications, including documentation, access control, vendor management and audits. The 
EMA/226170/2021 Guideline on computerised systems and electronic data in clinical trials provides 
direction for GCP but can be adopted more broadly. The following decision tree provide guidance on 
how to consider QMSs for a DQF implementation (see figure 6). 
 
Figure 6 - Decision tree for QMS adoption in DQF implementation 
 
8.4.  The role of ISO and industry standards 
The International Organisation for Standardisation (ISO) has produced standards providing frameworks 
for the implementation of various data management aspects, that are field tested and for which 
platforms, supporting services and certification bodies are established. These standards are often 
developed for implementation of industries where EMA's regulatory decision making does not apply. 
ISO 9000: Describes the standards for quality management systems on all levels of an organisation. 
The adoption of this standard could be considered if no industry specific QMS applies. 
ISO 8000: Describes the standards for the quality of Master Data and their exchange between 
systems35. The standard describes how Master Data conform to a set of specification expressed in a 
formal syntax and use specified identifiers to check against data requirements that point to a data 
dictionary. This standard also covers the methods for achieving data governance, data quality 
management, data quality assessment and rules for determining the quality of master data and 
industrial data. This includes the exchange of characteristics of data and identifiers and data 
 
35 To clarify, the ISO 8000 series does not establish a new management system. The series, instead, extends and clarifies 
ISO 9001 for the case where data are the product.

## Page 37

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 37/42 
 
processing like creating, collecting, storing, maintaining, transferring, exploiting, and presenting data 
to deliver information. This standard is valuable Master Data play an integrate role in the process of 
generation of data for regulatory decision making. 
ISO 25012: Defines a general data quality model for data retained in a structured format within a 
computer system, typical for data considered for regulatory decision making. It provides a framework 
for establishing data quality requirements, data quality measures, and a plan to perform data quality 
evaluations. It could be used across the entire life cycle from data collection or generation, 
management and processing, publishing, aggregation, and consumption and to evaluate the 
compliance of data with regulations. An example of implementation of this standard is done by 
Statistics Finland, which is also in line with the European Interoperability Framework, the FAIR 
principles and the Code of Practice for Statistics [13]. 
 
ISO 13485: Specifies requirements for a QMS for an organisation to design, build and obtain 
authorisation for medical devices that consistently meet customer and regulatory requirements. As 
with all QMS, this standard focusses on the quality of the product, and affects DQ as they are relevant 
for the design, development, production, and use of the device. 
 
8.5.  Notes on ALCOA+ 
ALCOA+ is a framework for data integrity used across the pharmaceutical industry in areas such as 
research, manufacturing, testing and supply chain. It postulates a set of principles that data and its 
documentation should comply to. In the specifics, data should be Attributable, Legible, 
Contemporaneous, Original, Accurate (ALCOA). The + refers to the following attributes: Consistent, 
Enduring, Available, Traceable. More information on these principles is available in the Guideline on 
computerised systems and electronic data [21] and in [22]. 
In relation to this Framework, ALCOA+ provides recommendations that focus on foundational 
determinants and that affect primarily the Reliability, but also the Extensiveness, Coherence and 
Timeliness dimensions. 
When considering the ALCOA+ principles, they can be closely aligned to the dimensions of the present 
DQF, with the caveat that the ALCOA definitions are more focused and operational. For instance, the 
ALCOA definition of “Accurate” is expressing a set of characteristics (e.g., verifiable coding processes, 
validated data transfer) that should be in place so that “data should be an accurate representation of 
the observation made”, that is how reliability (and more precisely Accuracy) is defined in this DQF. 
Other principles such as “Legible” and “Original” also falls under the Reliability dimension (as they 
answer the question “is data reflecting reality?”, but they are not explicitly articulated in this 
Framework as they are a pre-condition to a regulatory submission.  
For suitable use cases, ALCOA+ compliant specifications can enable level 2 (formalised) and above 
maturity levels for foundational determinants. 
8.6.  Notes on implementation of DQ controls 
There are different possible implementations of data quality controls (i.e., testing).  
If the true facts the data are representing are known and accessible, data can be tested using 
validation vs the source records containing these facts (see framework of reference session above). 
However, validation can be costly and time consuming, and often requires the use of adjudicators if the

## Page 38

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 38/42 
 
facts are not available in machine-readable structured form. Alternatively, data can be tested via 
intrinsic plausibility metrics, and specifically by assessing the dataset respect to (See figure 7): 
Other data in the same dataset: The test would detect logical or factual contradictions (e.g., 
embedding background knowledge on relations between entities and events). For example, the timing 
of a causal effect must occur after its causing intervention, or a female patients cannot have 
observations only occurring in males. 
External reference ranges (or Gold Standards): Some measured quantity cannot exceed a certain 
magnitude, such as a blood pressure of 1000/500 mmHg.  
Plausible trends: certain data can be valid when observed individually, but the collective trend of all 
data of a kind should follow expected distributions or trends. For example, the incidence of a disease is 
unlikely to grow drastically from 2% to 80% in a population from one year to another, or the exposed 
cell line in an experiment cannot show less effect than the unexposed comparator. In this case data 
are assessed with respect to background knowledge on typical characteristics of data. 
 
 
Figure 7 – Overview of external reference ranges

## Page 39

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 39/42 
 
9.  Glossary 
This glossary addresses the main terms and definitions that have been used in this Data Quality 
Framework for regulatory decision making. 
Definitions 
Explanation 
Data accessibility 
The ability of data to be accessible for public use in terms of 
discoverability, exportability, and usability.  
Data conciseness 
The characteristic of data to be expressed in a compact representation. 
Sometimes also defined as the characteristic of data to include only 
essential, and not spurious, information.  
Data immutability 
Data immutability is the concept that data is never deleted or altered. 
Once some data is “stated” (e.g.: entered in a database), it can only 
be augmented (eventually with additional information meant to 
invalidate or supersede previous data) but never remoted. In other 
words, data that has been entered in a system (and on which some 
other data or actions may depend) cannot be changed without 
explicitly mentioning of a new state of the information and maintaining 
the knowledge of the previous state. 
Data integrity 
Data integrity refers to the maintenance and assurance of data 
reliability and consistency over time, encompassing the whole data life 
cycle. It is a broader concept than Data Quality, whose precise 
definition varies across contexts, extending from physical to logical 
aspects of data processing and storage. 
Data quality metrics 
DQ metrics can be defined as indicators that can be applied to a data 
source to derive assessments of one of more quality dimensions.  
Data quality 
Data quality is defined as fitness for purpose for users’ needs in 
relation to health research, policy making, and regulation and that the 
data reflect the reality, which they aim to represent. Data quality is 
relative to the research question and does not address the question on 
what level is the quality measured e.g., variable, data source or 
institutional level. These aspects are addressed in the data quality 
determinants and dimensions of data quality. 
Data quality determinants 
What contributes to data quality or its characterisation.  
In this Framework determinants are classified into three categories: 
- Foundational determinants: what affects the quality of a dataset, 
being external to the dataset itself (e.g., systems and processes that 
generate data). 
- Intrinsic determinants: what can be derived in terms of quality for a 
dataset itself, without information on how the data came to or its 
intended usage. 
- Question specific determinants: what affects the assessment of a 
dataset quality, that strictly depends on the dataset intended or actual 
usage.

## Page 40

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 40/42 
 
Definitions 
Explanation 
Data quality dimensions 
Data quality aspects are partitioned into different group that answers 
different questions about data. Such partitions are called “dimensions”. 
This Framework distinguishes five dimensions that can be divided 
further into sub-dimensions: 1) extensiveness, 2) coherence, 3) 
timeliness, 4) relevance, and 5) reliability. 
Data quality framework 
A Data Quality Framework provides a set of definitions, guidelines, and 
recommendation to assess and govern data quality. The framework 
here presented addresses a wide range of data sources for the purpose 
of characterising, assessing, and assuring data quality for regulatory 
decision making. 
Entity 
An entity is a collection of similar values that belong to a specific 
variable (e.g., weight). This is also referred to as row level. 
Healthcare data 
Medical data gathered from different settings containing various clinical 
measurements of specific populations. In most cases this is 
electronically stored data known as electronic health data. 
Fit for purpose 
Possessing all required data quality characteristic needed to address a 
specific goal. The emphasis of data quality is ensuring that the data 
are fit for purpose for reliable assessments of whether the data are fit 
for the purpose of decision making to supporting health research and 
population health. 
Foundational determinant 
A data quality determinant that covers aspects related to the 
generation of data. It affects the quality of data, but it’s not part of the 
data themselves e.g., software systems, training, audit processes. It 
can be seen as data generation specific.  
Intrinsic determinant 
A data quality determinant that covers aspects that are inherent to a 
given dataset e.g., the formatting of the data. This can be seen as a 
dataset specific determinant. 
Maturity model 
A maturity model is a framework for assessing processes, technology 
and structure of an organisation or function. It provides a structured 
approach to evaluating how well an organization or a function manages 
its data quality processes, policies, and practices. The model defines 
key characteristics at each level to guide measure continuous 
improvement in data quality over time.  
MDM 
Master data management, a system that helps synthesise data from 
different systems and secure and clean it (eliminates duplications etc) 
to deal with the right information. 
Metadata 
Metadata are defined as “data about data” providing context about 
their purpose and generation. It’s a set of data that describes and 
gives information on other data providing context about their purpose, 
location, key-variables, generation, format, and ownership of a 
dataset. Metadata are often published in data catalogues, which have

## Page 41

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 41/42 
 
Definitions 
Explanation 
the purpose of allowing data to be discoverable and checked for fitness 
for purpose, without revealing the data themselves. 
Primary use of data 
Primary use of (electronic) health data is the processing of personal 
health data for the provision of health services to assess, maintain or 
restore the state of health of the person it belongs it, including the 
prescription, dispensation and provision of medicinal products and 
medical devices, as well as for relevant social security, administrative 
or reimbursement services. 
Secondary use of data 
Secondary use of (electronic) health data is the processing of health 
data for other purposes rather than primary use such as national 
statistics, education/teaching, scientific research etc. The data used 
may include personal health data initially collected in the context of 
primary use, but also electronic health data collected for the purpose 
of secondary use.

## Page 42

Data Quality Framework for EU medicines regulation  
EMA/326985/2023 
Page 42/42 
 
10.  References 
1. 
European Medicines Regulatory Network Data Standardisation Strategy. December 16th, 2021. 
Available from: https://www.ema.europa.eu/en/documents/other/european-medicines-
regulatory-network-data-standardisation-strategy_en.pdf. 
2. 
European Health Data Space Data Quality Framework, Deliverable 6.1 of TEHDAS EU 3rd 
Health Program (GA: 101035467). May 18th, 2022, accessed at 
https://tehdas.eu/results/tehdas-develops-data-quality-recommendations  
3. 
ISO 9001:2015 Quality Management System, accessed November 18th, 2022. 
https://www.iso.org/standard/62085.html. 
4. 
Kahn, M.G., et al., A Harmonized Data Quality Assessment Terminology and Framework for the 
Secondary Use of Electronic Health Record Data. EGEMS (Wash DC), 2016. 4(1): p. 1244. 
5. 
Healthcare Data Quality: A 4-Level Actionable Framework 2020 [September 5th, 2022]. 
Available from: https://www.healthcatalyst.com/insights/healthcare-data-quality-4-level-
actionable-framework. 
6. 
Schmidt, C.O., et al., Facilitating harmonized data quality assessments. A data quality 
framework for observational health research data collections with software implementations in 
R. BMC Med Res Methodol, 2021. 21(1): p. 63. 
7. 
Sentinel QA Program. Quality Assurance - Sentinel Version Control System. [February 14th, 
2022]. Available from: https://dev.sentinelsystem.org/projects/QA/repos/qa_package/browse. 
8. 
NESTcc. Data Quality Framework, A report of the Data Quality Subcommittee of the NEST 
Coordinating Center - An initiative of MDIC. 2020 [February 14th, 2022]. Available from: 
https://nestcc.org/nestcc-data-quality-framework. 
9. 
The National Patient-Centered Clinical Research Network. PCORnet - Data Quality Framework. 
[February 18th, 2022]. Available from: https://pcornet.org/data. 
10. 
Duke-Margolis Center for Health Policy. Characterising RWD Quality and Relevance for 
Regulatory Purposes, 2018. Available from: 
https://healthpolicy.duke.edu/sites/default/files/2020-03/characterising_rwd.pdf. 
11. 
Duke-Margolis Center for Health Policy. Determining Real-World Data’s Fitness for Use and the 
Role of Reliability, 2019. Available from: https://healthpolicy.duke.edu/sites/default/files/2019-
11/rwd_reliability.pdf. 
12. 
Data Utility Framework. Available from: https://www.hdruk.ac.uk/wp-
content/uploads/2020/11/201105-Updates-to-the-Data-Utility-Framework-v2.pdf. 
13. 
Statistics Finland, Data Quality Framework, National data quality criteria and indicators. 
Available from: https://stat.fi/org/tiedon-laatukehikko/tiedon-laatukriteerit_en.html. 
14. 
Cave, A., X. Kurz, and P. Arlett, Real-World Data for Regulatory Decision Making: Challenges 
and Possible Solutions for Europe. Clin Pharmacol Ther, 2019. 106(1): p. 36-39. 
15. 
Big Data Steering Group, Big Data Workplan 2022-2025. Available from: 
https://www.ema.europa.eu/en/news/big-data-use-public-health-publication-big-data-
steering-group-workplan-2022-25. 
16. 
FAIR. Available from: https://www.go-fair.org/fair-principles/. 
17. 
Good Practice Guide for the use of the Metadata Catalogue of Real-World Data Sources, 
EMA/787647/2022. Available from: https://www.ema.europa.eu/en/documents/regulatory-
procedural-guideline/good-practice-guide-use-metadata-catalogue-real-world-data-
sources_en.pdf. 
18. 
Wang, S.V. and S. Schneeweiss, A Framework for Visualizing Study Designs and Data 
Observability in Electronic Health Record Data. Clin Epidemiol, 2022. 14: p. 601-608. 
19. 
European Commission. Can we use data for another purpose? [Internet, cited 27 Sept 2022] 
https://ec.europa.eu/info/law/law-topic/data-protection/reform/rules-business-and-
organisations/principles-gdpr/purpose-data-processing/can-we-use-data-another-purpose_en. 
20. 
American Society for Quality. What is a Quality Management System (QMS)? | ASQ. Available 
from: https://asq.org/quality-resources/quality-management-system. 
21. 
Guideline on computerised systems and electronic data in clinical trials. Available from: 
https://www.ema.europa.eu/en/documents/regulatory-procedural-guideline/draft-guideline-
computerised-systems-electronic-data-clinical-trials_en.pdf. 
22. 
Data Integrity and Compliance with CGMP, guidance for Industry. Available from: 
https://www.fda.gov/files/drugs/published/Data-Integrity-and-Compliance-With-Current-Good-
Manufacturing-Practice-Guidance-for-Industry.pdf.


---

# Draft Commission guidelines on the classification of high-risk AI systems

- **Issuer:** European Commission
- **Type:** Guideline
- **Published:** 2026-05-19
- **Status:** Public consultation
- **Language:** en
- **Source:** https://digital-strategy.ec.europa.eu/en/library/draft-commission-guidelines-classification-high-risk-ai-systems
- **Licence:** EU-reuse

## Section: Text

The Guidelines set out the Commission’s interpretation of certain concepts that are relevant for classification purposes and, in accordance with Article 6(5) AI Act, contain practical examples of AI systems that should or should not be classified as high-risk. The examples listed in these Guidelines strive to cover all areas and use cases, but they are not to be considered as exhaustive and may be updated over time.
The guidelines are divided into sections, following the structure of Article 6 of I Act, which states that an AI system shall be considered high-risk in 2 scenarios:
1. If the system is intended to be used as a safety component of a product, or the AI system itself is a product, covered by the EU harmonisation legislation listed in Annex I, and the product whose safety component is the AI system or the AI system itself is required to undergo a third-party conformity assessment, the system will be classified as high-risk pursuant to Article 6(1) AI Act.
2. If the system falls into one of the use cases listed under the areas in Annex III AI Act, it will be classified as high-risk pursuant to Article 6(2) AI Act.
Section III of the guidelines addresses the first category of high-risk AI systems, while section IV addresses the second category. Below, you can download each section separately, so you do not need to consult the full document if they are only interested in a specific area or use case. This is intended to make the draft guidelines easier to access, share and use for feedback.
Find more information about the targeted stakeholder consultation on these guidelines.

## Section: Last update

23 July 2026


---

# EDPB Guidelines 03/2026 on web scraping in the context of generative AI

- **Issuer:** EU institutions (other)
- **Type:** Guideline
- **Status:** Public consultation
- **Language:** en
- **Source:** https://www.edpb.europa.eu/system/files/2026-07/edpb_guidelines_2020603_webscraping_v1_en_0.pdf
- **Licence:** EU-reuse

## Page 1

Guidelines 03/2026 on web scraping in the 
context of generative AI 
Version 1.0 
Adopted on 07 July 2026

## Page 2

1 | Adopted 
Version history 
Version 
Date 
Adoption information 
Version 1.0 
07 July 2026 
adoption of the guidelines for public consultation

## Page 3

2 | Adopted 
Executive summary  
 
Web scraping is a commonly used technique for extracting large amounts of data from publicly 
available web services. It is a large-scale processing activity and often occurs without data 
subjects being aware of it. This poses particular risks to individual’s rights and freedoms, and 
in particular their right to protection of personal data. 
These guidelines focus on situations where data is scraped from internet sources, in the 
context of training generative AI. They cover situations were an organisation either scrapes 
data from internet sources external to the organisation themselves, or by contracting another 
party. They are limited to web scraping done by private entities.  
The GDPR applies to web scraping when it includes personal data processing operations, 
such as collection, storage, organisation and retrieval. Compliance with certain GDPR 
requirements can be challenging when web scraping collects data that include personal data. 
Different organisations may be involved in the data collection process for the creation of an AI 
training dataset, with varying degrees of involvement. The qualification of the organisations 
involved in each processing as controllers, joint controllers or processors should be analysed 
on a case-by-case basis. 
 
The controller must comply with the purpose limitation principle, as well as the transparency 
principle. For the latter, this includes the obligation to inform the data subject about the 
processing of their personal data. Depending on how the data processing is precisely 
designed, the controller might not have to inform data subjects individually about the web 
scraping if the provision of the information proves impossible or would require disproportionate 
effort.  
 
To comply with the principle of data minimisation, the controller should implement measures 
to ensure that only information necessary for the intended purpose is collected. Such 
measures could be: before the collection of data, considering using synthetic data instead of 
personal data; defining precise collection criteria; undertaking a data mapping and inventory 
process; apply filters to exclude the collection of certain categories of data; exclude from the 
collection websites that structurally contain certain types of data and websites which clearly 
oppose the scraping. After the collection of data, the controller could apply syntax-based 
filtering mechanisms and, where feasible, replace some or all real data with synthetic data, or 
anonymise or pseudonymise the data. 
To ensure the accuracy of the personal data, it is recommended that the controller scrape 
from reliable sources, timestamp the data and validate the data before using them in AI 
training. 
The legal basis of legitimate interest (Article 6(1)(f) GDPR) is often used by private entities for 
scraping for generative AI training purposes. In order for the application of Article 6(1)(f) to be 
lawful, three cumulative conditions must be fulfilled: the pursuit of a legitimate interest by the 
controller or by a third party; the necessity to process personal data for the purposes of the 
legitimate interests pursued; and that the interests or fundamental rights of the person 
concerned by the data protection do not take precedence over the legitimate interest of the 
controller or a third party (the so-called “balancing test”). As a part of the balancing test, 
controllers can implement technical or organisational measures to mitigate any identified risks 
in the context of web scraping for generative AI. 
Such mitigating measures could include, among others: ensuring that certain data categories 
are not collected or that certain sources are excluded by default from data collection; limiting

## Page 4

3 | Adopted 
the collection to freely accessible data; establishing safeguards that contribute to increased 
transparency; facilitating the exercise of individuals’ rights; deleting or anonymising personal 
data as soon as possible and pseudonymise personal data. Other additional measures relating 
to the subsequent stages of the AI development phase, such as including measures to limit 
the risks of memorisation, regurgitation or attack of AI models or systems are also relevant.  
Processing of special categories of data is in principle prohibited. For the web scraping 
entailing the processing of special categories of personal data, a derogation in Article 9(2) 
GDPR is required, in addition to a lawful basis in Article 6 GDPR. The EDPB considers that 
the Court’s ruling GC & Others (C-136/17) can be relevant for the incidental and residual 
collection by a controller of special categories of personal data in the context of web scraping 
for the training of an AI model, ‘within the framework of his responsibilities, powers and 
capabilities,’ if the controller implements technical and organisational measures to prevent the 
collection and the dissemination of data. The EDPB recalls that the controller should carry out 
a case-by case analysis of whether the reasoning of the Court’s ruling can be applied to a 
specific processing activity.

## Page 5

4 | Adopted 
Table of Contents 
1 Introduction and scope.................................................................................................... 5 
2 Definition of web scraping .............................................................................................. 5 
3 Web scraping and the GDPR ........................................................................................... 7 
3.1 General observations ............................................................................................. 7 
3.2 Guidance on specific provisions in the GDPR ........................................................ 8 
3.2.1 Controller/joint controllers/processor ............................................................... 8 
3.2.2 Principles relating to processing of personal data ............................................ 9 
3.2.3 Legal basis for the processing of personal data ............................................. 13 
3.2.4 Special categories of personal data ............................................................... 19

## Page 6 (Section: 1  Introduction and scope)

5 | Adopted 
The European Data Protection Board 
Having regard to [Article 70 (1)(e) of the Regulation (EU) 2016/679 of the European Parliament 
and of the Council of 27 April 2016 on the protection of natural persons with regard to the 
processing of personal data and on the free movement of such data, and repealing Directive 
95/46/EC, (hereinafter “GDPR”), 
Having regard to the EEA Agreement and in particular to Annex XI and Protocol 37 thereof, 
as amended by the Decision of the EEA joint Committee No 154/2018 of 6 July 2018, 
Having regard to Article 12 and Article 22 of its Rules of Procedure, 
Has adopted the following Guidelines: 
1  Introduction and scope  
1 These guidelines aim to clarify the legal and technical implications of web scraping for 
generative artificial intelligence (AI) development under the GDPR. Generative AI is a 
technology aiming to create new content by learning patterns from existing data. It uses 
specialised machine learning models designed to produce a wide and general variety of 
outputs such as text, image or audio. 
2 Generative AI models are built through different phases, including training and, where 
relevant, fine-tuning. Training generative AI models requires vast amounts of data from 
diverse sources. In the context of AI training, web scraping is used to collect large datasets 
from publicly accessible sources on the internet, which may be employed not only to train 
new generative AI models but also to fine-tune existing models for specific use cases. 
3 The following are typical situations regarding data scraping for the purpose of training AI 
models. 
• 
An organisation scrapes data from the internet themselves or by contracting another 
party, in the context of the development of generative AI.  
• 
An organisation obtains and reuses a dataset that has already been scraped by 
another organisation (data broker).  
4 These guidelines will focus on these scenarios. The guidelines will not address the role of 
data brokers who scrape data and just hold data sets available for other organisations, and 
whose intention is not to train AI models themselves. 
5 Furthermore, these guidelines focus on situations in which personal data is acquired 
(scraped) from sources external to the organisation and do not address processing of an 
organisation’s own personal data. This does not mean that the excluded situations are not 
subject to data protection legislations. 
6 As web scraping for the development of generative AI is mainly performed by private sector 
bodies, these guidelines will also focus only on web scraping done by private entities.  
2  Definition of web scraping  
7 Web scraping is a commonly used technique that uses automated tools for extracting and 
storing information from publicly available web services, for example public registers, open-
data portals, news outlets, social media, discussions’ forums, and personal websites 
(‘blogs’). Many of these websites are likely to contain personal data.

## Page 7 (Section: Types of web scraping and content)

6 | Adopted 
Types of web scraping and content  
8 An overarching distinction can be made between targeted scraping and untargeted scraping, 
depending on the specificity and restrictiveness, of the collection (and not the technical tools 
used): 
Targeted scraping is performed according to collection criteria that can be 
more or less restrictive. The criteria could be, for example: all URLs ending in 
europa.eu, URLs with content written in a specific language or covering a 
specific topic.  
Untargeted scraping (such as web crawling without collection criteria) is done 
on more unrestricted basis, where the software is allowed to explore and follow 
each discovered link and continue with its exploration. This can be performed 
by using a web crawler, which automatically updates the list of URLs to be 
visited and store the server replies. This is done with ‘spiders’, small software 
programs that receive their instructions (tasks) in advance. These tasks could 
be: “add all the URLs you encounter while crawling the listed URLs”. The task 
could also be limiting the list or URLs to visit, for example “follow all links as 
long as you stay within the domain www.edpb.europa.eu”. Depending on the 
instructions to the spiders, a relatively short list of URLs can expand 
significantly over time as the crawler continuously discovers and adds new 
URLs to its queue of pages to be visited. This may result in the exploration of a 
large portion of the internet to be searched as a result of the constant addition 
of relevant URLs. This increases the risk that the controller has limited 
knowledge of what personal data are collected and processed. 
9 An additional distinction can be made between static and dynamic content in websites. It is 
common practice to combine both static and dynamic content on the same site or webpage.  
Static content does not change due to users’ actions (e.g. the text of a given 
post in a blog). When scraping static content from web pages, the target data 
resides directly in the HTML of a webpage, meaning it can be extracted simply 
by fetching and parsing the page. Most scrapers targeting static websites rely 
on the direct structure of HTML to locate the needed data. 
Dynamic content can change to respond to users’ actions (e.g. loading more 
content when a user scrolls down a page). When scraping dynamic content 
from webpages, web crawlers need to render the page internally, mimicking a 
human users’ interaction with the page. These scrapers wait for the page to 
render the additional content and then read and extract the dynamically 
rendered data. 
10 Websites change their structure frequently. Scrapers might need regular monitoring and 
updates to continue functioning correctly (e.g., when updated data is needed for the model 
to perform accurately). 
The different steps in the process of web scraping  
11 The process of web scraping can typically be sequenced into several separate steps.  
The first step relates to defining data collection criteria. It involves defining 
the relevant sources which will be scraped depending e.g. on the purpose of

## Page 8 (Section: 3  Web scraping and the GDPR)

7 | Adopted 
the following AI-development, as well as other criteria to exclude the collection 
of unnecessary personal data for the processing. If instructed to do so in line 
with the selection criteria, the scraper might update its list of URLs to be visited 
with links found at the source. This step also implies implementing measures 
to exclude certain sources from the collection (e.g. websites which oppose web 
scraping with measures such as robots.txt or CAPTCHA). For more details, see 
part 3.2.2 on data minimisation.  
The second step relates to “extraction”, during which data from the selected 
sources is transferred to the designated storage location.   
The third step is the “cleaning”, as the raw data transferred by the automated 
process will often need to be cleaned to improve data quality (e.g. avoiding 
duplicated data, removing irrelevant HTML tags or code and normalizing 
formats (e.g. dates, numbers), delete unnecessary data).  
The fourth step is the “structuring and storing”, during which the organisation 
building the training dataset might apply some further rules to refine the data 
by excluding low quality Internet content. After this refinement step, the 
remaining data will be structured into a usable format. 
3  Web scraping and the GDPR 
3.1 General observations 
12 The GDPR will apply to web scraping when it includes processing operations, such as 
extraction, cleaning, structuring and storing of personal data, e.g., data that directly identifies 
an individual (e.g. names, pictures or contact details) or data that indirectly identifies an 
individual (i.e. information that can be linked to an identifiable individual considering all the 
means reasonably likely to be used).  
13 Compliance with certain GDPR requirements can be challenging when web scraping is used 
to collect personal data, such as identifying a lawful basis for processing under Article 6 
GDPR, meeting the obligations for processing of special categories of personal data under 
Article 9 GDPR, complying with the obligation to ensure transparency towards data subjects 
(under Article 5(1)(a), 12-14 GDPR), and complying with, but not limited to, principles such 
as purpose limitation (Article 5(1)(b) GDPR), data minimisation (Article 5(1)(c) GDPR), 
fairness (Article 5(1)(a) GDPR), and accuracy (Article 5(1)(d) GDPR). The EDPB recalls that 
in case of ‘mixed’ datasets (including both personal and non-personal data), GDPR applies 
to the processing of personal data. Organisations must carefully consider these 
requirements.  They should conduct their scraping activities in a way that enables them to 
ensure compliance with these principles and requirements, and include safeguards that 
protect personal data to facilitate compliance with the GDPR and avoid infringing individuals' 
rights.  
14 Collecting vast amounts of personal and potentially sensitive data1, which usually happens 
without the data subjects' knowledge, could provide the controller with very detailed 
information about data subjects, irrespective of whether it is intentional or not. Considering 
 
1 On “sensitive” data see Article 29 Working Party Guidelines on Data Protection Impact Assessment (DPIA) and determining 
whether processing is “likely to result in a high risk” for the purposes of Regulation 2016/679, wp248rev.01, endorsed by the 
EDPB, p. 9-10.

## Page 9 (Section: 3.2 Guidance on specific provisions in the GDPR)

8 | Adopted 
the technical aspects and goals of web scraping, it might be challenging for the organisation 
carrying out the scraping, and an organisation obtaining the scraped data, to determine 
exactly what personal data, and related to which data subjects, are included in the data set. 
It is thus not obvious how to meet the principle of accountability laid down in Article 5(2) 
GDPR when processing such data sets for AI development. Nonetheless, compliance with 
regard to Article 5(2) GDPR must be met by the controller. Furthermore, if an AI model 
memorizes and reproduces data included in a training data set, it poses additional risks to 
the privacy of individuals and the data subjects’ rights. The information memorised by the AI 
model could be used directly for arbitrary purposes. Other risks include the fact that AI 
models could infer additional information about individuals by using the training data about 
the data subjects as well as additional information about other data subjects. The reasoning 
capability of the model based on the training data can also pose an additional risk to 
individuals. 
15 In summary, web scraping can be a powerful tool for generative AI development, but it poses 
significant data protection risks. These guidelines are intended to assist controllers in 
navigating the requirements of the GDPR when using web scraping for generative AI 
training. 
3.2 Guidance on specific provisions in the GDPR 
3.2.1 Controller/joint controllers/processor  
16 Different organisations may be involved in the data collection process for the creation of an 
AI training dataset, with varying degrees of involvement. The qualification of the 
organisations involved in each processing (i.e. controllers and processors), within the 
meaning of the GDPR, should be analysed on a case-by-case basis. It should stem from an 
analysis of the factual elements or circumstances of the case, including the way in which the 
data processing at hand is organized. 2 However, some general considerations can be 
provided: 
17 The organisation performing the scraping is not necessarily the controller under the GDPR.  
18 There might be cases where an organisation (AI developer) that is planning to train an AI 
model contracts another party to perform the scraping (scraper). If the scraper creates a 
training data set on behalf of the AI developer, according to its documented instructions (in 
particular on how the data set should be constituted with regard to data sources and 
categories), the scraper may be regarded as a processor. The AI developer will generally 
determine the instructions given in regard to the purposes and essential means of the 
scraping, and therefore be considered the controller.  
19 In situations where an AI developer trains an AI model using a data set which has already 
been scraped by another entity (scraper) it is necessary to distinguish between the 
responsibility for the different data processing. The scraper and AI developer are, in principle, 
responsible for their own, separate, processing activities, since each of them determines the 
objectives and the essential means of its own processing. The scraper is not, in principle, 
responsible for the re-use of the data. 
 
2 EDPB Guidelines 7/2020 on the concept of controller, joint controllers and processor in the GDPR, adopted on 7 July 2021, 
paragraph 52: “The assessment of joint controllership should be carried out on a factual, rather than a formal, analysis of the 
actual influence on the purposes and means of the processing. All existing or envisaged arrangements should be checked against 
the factual circumstances regarding the relationship between the parties.”

## Page 10 (Section: 3.2.2 Principles relating to processing of personal data)

9 | Adopted 
20 It is also possible that the scraper and the AI developer are jointly responsible for the 
processing instead. This could be the case when the scraper and the AI developer determine 
the purposes and means of the processing together (jointly). 
Example 1: Two organisations make a joint decision to develop an AI model, and 
agree that one of the organisations will perform the task to scrape data from the 
web to and create data sets for the development of the AI model, while the other 
organisation perform the development of the model, using the data sets created 
by the scraper. The collection criteria for the scraping of personal data are 
determined jointly by both parties. Even though they perform separate 
processing activities they determine the purposes and means of the processing 
(the web scraping and the development of the model) together and are jointly 
responsible for the processings of personal data.  
3.2.2 Principles relating to processing of personal data 
Lawfulness  
21 Personal data should be processed lawfully, fairly and in a transparent manner in relation to 
the data subject.3 When assessing whether the processing of personal data is lawful, the 
developer of the generative AI model as controller must consider the datasets (containing 
the scraped data) it intends to use, and/or the types of websites it would like to scrape data 
from. 
22 Moreover, the purpose of the web scraping of personal data should be lawful.4 
Purpose limitation  
23  Personal data should be collected for specified, explicit and legitimate purposes, and not 
further processed in a manner that is incompatible with those purposes. The EDPB has 
provided further considerations on the purpose limitation principle in the context of the 
development of AI models in the Opinion 28/2024 on certain data protection aspects related 
to the processing of personal data in the context of AI models.5  
Transparency  
24 Personal data should be processed in a transparent manner in relation to the data subject.6 
This includes the obligation to inform the data subject about the processing of their personal 
data. However, when scraping large amounts of data from the internet, it is often difficult, 
impracticable or, even, objectively impossible to identify and inform the data subjects in an 
effective way. This makes compliance with the principle of transparency challenging.   
25 Depending on how the data processing is precisely designed, it is possible that the controller 
of the web scraping might not have to inform data subjects individually about the web 
scraping, if providing the information proves impossible or requires disproportionate effort 
(Article 14 (5)(b) GDPR). 
 
3 Article 5(1)(a) GDPR. 
4 See Joint Statement on AI-Generated Imagery and the Protection of Privacy, issued on 23 February 2026, on the creation of 
non-consensual intimate imagery, defamatory depictions, and other harmful content featuring real individuals. 
5 EDPB Opinion 28/2024 on certain data protection aspects related to the processing of personal data in the context of AI models, 
adopted on 17 December 2024, p. 64. 
6 Article 5(1)(a) GDPR.

## Page 11 (Section: 3.2.2 Principles relating to processing of personal data)

10 | Adopted 
26 Impossibility or disproportionate effort typically arises in circumstances where the personal 
data were not obtained from the data subject.7 
27 Informing the data subjects individually may be impossible or require disproportionate effort 
in particular for processing “for archiving purposes in the public interest, scientific or historical 
research purposes or statistical purposes”, subject to the safeguards referred to in Article 
89(1) GDPR.8 While the word “in particular” clarifies that there may be other cases where it 
would be impossible or require disproportionate effort to inform data subjects, 9  this 
exception should not be routinely relied upon by controllers who are not processing personal 
data for the purposes of archiving in the public interest, for scientific or historical research 
purposes or statistical purposes.10 
28 Where a controller seeks to rely on the exception in Article 14(5)(b) GDPR, it should assess 
the effort involved for the controller to provide the information to the data subject against the 
impact and effects on the data subject if they were not provided with the information.11 The 
balancing exercise should be carried out with regard to the dataset as a whole and not on 
every single piece of personal data, and should take into account: 
• 
the number of data subjects, 
• 
the age of the data, 
• 
any appropriate safeguards adopted.12 
29 In the case of processing of personal data that do not require the identification of a data 
subject by the controller, the controller is not obliged to maintain, acquire or process 
additional information in order to identify the data subject for the sole purpose of complying 
with the requirements in the GDPR. In such cases, the controller is not required to comply 
with the rights of the data subject in Articles 15 to 20, unless the data subject provides 
additional information enabling their identification.13  
30 In cases where informing data subjects individually proves impossible or would require 
disproportionate effort, the controller must take appropriate measures to protect the data 
subject’s rights, freedoms and legitimate interests. One appropriate measure that controllers 
must always take, as specified in Article 14(5)(b), is to make the information publicly 
available.14 This can be done for instance by publishing a privacy policy and/ or specific 
notice on the controller’s website. This policy should include the information that is required 
by Article 14(1)-(2) GDPR, including the categories of personal data concerned, the 
purposes of the legal basis of the processing as well as a precise indication of the source(s) 
of the data. The information should indicate in particular whether the sources are publicly 
accessible or non-publicly available sources and, if the data is crawled and scraped from 
online sources, the information should include crawler’s characteristics. In situations where 
it would be impossible or require disproportionate effort to provide a complete list of the 
 
7 Article 29 Working Party, WP260 rev.01, 29 November 2017, Guidelines on transparency under Regulation 2016/679 - endorsed 
by the EDPB, paragraph 62. 
8 Recital 62 GDPR. 
9 Recital 62 GDPR. 
10 Article 29 Working Party, WP260 rev.01, 29 November 2017, Guidelines on transparency under Regulation 2016/679 - 
endorsed by the EDPB, paragraph 61.  
11 Article 29 Working Party, WP260 rev.01, 29 November 2017, Guidelines on transparency under Regulation 2016/679 - 
endorsed by the EDPB, paragraph 64. 
12 Recital 62 GDPR. 
13 Article 11 GDPR. 
14 Article 29 Working Party, WP260 rev.01, 29 November 2017, Guidelines on transparency under Regulation 2016/679 - 
endorsed by the EDPB, paragraph 64.

## Page 12 (Section: 3.2.2 Principles relating to processing of personal data)

11 | Adopted 
sources, the sources should be included in the list to the greatest extent possible, and the 
list should be accompanied with an indication of the types of sources not included in the list, 
and the reasons for not including those sources.  
31 Where possible, it is good practice to include information on the domain names and URLs 
of the scraped web pages, to provide them in a searchable format, and to include the date 
or period of collection. 
32 In situations where an organisation obtains already scraped datasets to develop AI models, 
it is recommended to also provide the means to contact the controller from whom the data 
was obtained. A good practice is to link directly to the website of the controller for the web 
scraping, and to accompany the information with a clear, concise explanation of the 
conditions under which the personal data was collected. This information should be provided 
in clear and plain language. 
33 Data subjects should also be informed about their rights under the GDPR, and on how they 
can exercise them. Information should be easy for users to find and understand. By doing 
this, the controller will not only meet GDPR requirements but also build trust with data 
subjects whose data were scraped. 
34 Other appropriate measures to protect the data subject’s rights, freedoms and interests, in 
addition to making the information publicly available, depending on the circumstances of the 
processing, may include: undertaking a data protection impact assessment and making it 
publicly available; applying anonymisation or pseudonymisation techniques to the personal 
data; minimising the data collected and the storage period; and implementing technical and 
organisational measures to ensure a high level of security.15 
Example 2: In order to train the AI model, the AI developer collects a very large 
volume of data about data subjects from a variety of sources that extend back to 
20 years ago, such as social media pages and discussion forums where no direct 
identifiers are included in the data. As the webpages might contain personal data 
of thousands or millions of individuals, the provider does not necessarily have 
the means to contact them. Given the fact that there is no direct link between the 
scraper and the data subject that enables the communications, that the 
publication dates of the data extend back to 20 years ago and that a very large 
dataset is collected, it would involve disproportionate effort on the part of the 
controller to provide all persons with the information required under Article 14 
GDPR. The controller makes the required information publicly available on its 
web site that is easily accessible, in clear and plain language. The controller also 
applies appropriate measures, e.g. the exclusion of data from web pages where 
the data subjects are directly identifiable. 
 
Example 3: A provider of an AI model intends to fine tune an LLM model that can 
produce coherent text completion based on a short input. To do so the provider 
collects personal data from a closed user group of 5 000 individuals, discussing 
in the last two years a specific topic and using a specific business or social jargon. 
The data subjects are directly identifiable through their full names, email 
addresses, and unique participant IDs. Given the fact that there are means to 
 
15 Article 29 Working Party, WP260 rev.01, 29 November 2017, Guidelines on transparency under Regulation 2016/679 - 
endorsed by the EDPB, paragraph 62.

## Page 13 (Section: Data minimisation)

12 | Adopted 
contact the data subjects and that the data has been published or collected in 
the recent years, it would not involve disproportionate effort on the part of the 
controller to provide all persons with the information required under Article 14 
GDPR. The controller should inform the data subjects individually about the 
scraping. 
Data minimisation  
35 The principle of data minimisation provides that personal data must be adequate, relevant 
and limited to what is necessary for the purposes for which they are processed.16 
36 This means that the controller must only collect personal data necessary for the purpose of 
the processing. While there is a major challenge in scraping large amounts of data while 
limiting personal data to only what is necessary for the intended purpose of processing, the 
principle of data minimisation does not prohibit training an AI model or AI system with large 
volumes of data. Instead, the principle of data minimisation requires not to process personal 
data that would not be necessary, relevant or adequate. To comply with this, the controller 
should make an assessment before the scraping begins, so as not to collect personal data 
that is not necessary for the development of the model. 
37 The controller should, before the collection of the data: 
• 
consider using synthetic data instead of personal data, 
• 
define precise collection criteria, 
• 
undertake a data mapping and inventory process, 
• 
apply filters to exclude the collection of certain categories of data where they are 
not necessary (e.g. bank transaction data, location/geolocation data, etc.) if they can 
be sorted out (e.g. if they rest in specific directories within file servers);  
• 
exclude from the collection certain categories of websites (e.g. sites or social 
networks used mainly by minors) which structurally contain these personal data (e.g. 
data concerning vulnerable persons such as minors or certain sensitive data17, such 
as financial information or location information); 
• 
exclude from the collection websites which clearly oppose the scraping of their 
content, through the use of technical measures, such as the use of robots 
authentication to view content, robots.txt or ai.txt files, or CAPTCHA, which impose an 
action that can only be carried out by a human being and aim to prohibit access to 
pages by robots. 
38 The controller should, during and after the collection of the data: 
• 
apply syntax-based filtering mechanisms (e.g. regular expressions) during the 
collection to filter out personal data identifiable by their format (such as social security 
number, telephone number, etc); 
• 
where feasible, replace some or all real data with synthetic data generated for 
testing, analysis, or training purposes, in order to reduce exposure to personal data; 
• 
where feasible, anonymise or alternatively pseudonymise18 personal data. 
 
16 Article 5(1)(c) GDPR. 
17 This term refers to data of a particularly sensitive nature and is distinct from special categories of data within the meaning of 
Article 9 GDPR. See also Article 29 Working Party Guidelines on Data Protection Impact Assessment (DPIA) and determining 
whether processing is “likely to result in a high risk” for the purposes of Regulation 2016/679, wp248rev.01, endorsed by the 
EDPB, p. 9-10.  
18 EDPB Guidelines 01/2025 on Pseudonymisation, version for public consultation, adopted on 16 January 2025.

## Page 14 (Section: Accuracy)

13 | Adopted 
Accuracy 
39 The principle of accuracy means that the personal data processed must be accurate and 
updated with regard to the specific purpose for which they are processed.19 If scraping is 
used to process data obtained from different and/or unreliable sources, it will be difficult or 
even impossible to ensure the accuracy of the personal data. Complying with the principle 
of accuracy can also be challenging if the scraped personal data is stored for a long time 
and no longer up to date.  
40 The principle of accuracy does not only apply to the collection and processing of personal 
data as such but also means that the controller should consider the final result of the AI 
training in order to minimize the risk of incorrect output. When the AI model, once it is placed 
on the market, is expected to produce (as output) data that constitute personal data, it should 
be compliant with the principle of accuracy. 
41 Limiting the collection of personal data to what is necessary, it is crucial not only to comply 
with the principle of data minimisation, but also to make it easier for the controller to conduct 
the mapping of the personal data and to keep them updated and accurate.  
42 To the greatest extent possible, it is recommended that the controller: 
• 
Scrape from reliable sources: when possible, choose sources that are official, 
trustworthy, and maintained (e.g. a government registry, verified company profile) and 
avoid secondary or outdated aggregators. 
• 
Timestamp the data: record when the data was scraped, to allow to show how up to 
date the data is.  
• 
Validate the data before using them in AI training: correct formats (emails, phone 
numbers), spot-check random samples for factual accuracy. 
3.2.3 Legal basis for the processing of personal data 
43 Before carrying out scraping operations involving the collection of personal data or re-use of 
scraped data, the controller must identify a lawful basis to the processing.20 The legal basis 
of legitimate interest is often relied on for scraping in the context of development of 
generative AI by private bodies. The other grounds referred to in Article 6(1) GDPR will 
generally be less likely to apply to web scraping in the context of development of generative 
AI by private bodies. 
Consent  
44 Consent would most probably not be an applicable legal basis, since it is often difficult to 
obtain the consent of individuals when personal data are collected indirectly and at large 
scale. Organisations scraping data (as ‘third party data’)21 from the internet do not have a 
direct relationship with the data subject and are most probably not able to identify and obtain 
consent from each and every data subject before scraping data. 
45 Sometimes data subjects are not even aware of the fact that their data are publicly available 
online. When data subjects make their personal data available online, for example on a web 
page accessible to everyone, this does not mean that the data subjects gave their consent 
to the scraping of their personal data for a specific purpose. In particular, the absence or 
 
19 Article 5(1)(d) GDPR. 
20 Article 6(1) GDPR. 
21 EDPB Guidelines 1/2024 on processing of personal data based on Article 6(1)(f) GDPR, adopted on 8 October 2024; 
paragraph 7.

## Page 15 (Section: Legitimate interest)

14 | Adopted 
non-applicability of a robots.txt file on a web site does not amount to consent within the 
meaning of the GDPR. 
Legitimate interest  
46 Article 6(1)(f) GDPR provides a lawful basis for the processing of personal data where such 
a processing is necessary for the purposes of the legitimate interests pursued by the 
controller or by a third party, except where such interests are overridden by the interests or 
fundamental rights and freedoms of the data subject, in particular where the data subject is 
a child.  
47  In order for the application of Article 6(1)(f) to be lawful, three cumulative conditions must 
be fulfilled: the pursuit of a legitimate interest by the controller or by a third party; the need 
to process personal data for the purposes of the legitimate interests pursued; and that the 
interests or fundamental rights of the person concerned by the data protection do not take 
precedence over the legitimate interest of the controller or a third party (the so-called 
“balancing test”).22  
Condition 1: legitimate interest  
48 The concept of interest is closely related to, but distinct from, the concept of the purpose of 
the processing.23 An interest is the broader stake or benefit that a controller or third party 
may have in engaging in a specific processing activity. While the GDPR and the CJEU 
recognized several interests as being legitimate,24 the assessment of the legitimacy of a 
given interest should be the result of a case-by-case analysis.  
49 As recalled by the EDPB in its Guidelines on legitimate interest, an interest may be regarded 
as legitimate if it is lawful, clearly and precisely articulated and real and present, not 
speculative.25  
50 The EDPB has previously stated that the following examples may constitute a legitimate 
interest in the context of AI models: (i) developing the service of a conversational agent to 
assist users; (ii) developing an AI system to detect fraudulent content or behaviour; and (iii) 
improving threat detection in an information system.26 With regard to the development and 
improvement of a general-purpose AI model, even when the precise use of the model has 
not yet been decided, it is recommended to refer to the objective pursued by the development 
of the model (indicating in particular whether it is commercial, public, scientific research, and 
whether it is internal or external to the organisation). 
Condition 2: necessity  
51 The second step of the assessment consists in determining whether the processing of 
personal data is necessary for the purpose of the legitimate interest(s) pursued. The 
 
22 EDPB Guidelines 1/2024 on processing of personal data based on Article 6(1)(f) GDPR, adopted on 8 October 2024; Judgment 
of 17 June 2021, M.I.C.M, C-597/19, EU:C:2021:492, paragraph 106; Judgment of 4 May 2017, Rīgas satiksme, C-13/16, 
EU:C:2017:336, paragraph 28; Bundeskartellamt, paragraph 106. Koninklijke Nederlandse Lawn Tennisbond vs Autoriteit 
Persoonsgegevens, C-621/22 , EU:C:2024:858, paragraph 37; Mousse v Commission nationale de l’informatique et des libertés, 
SNCF Connect, C-394/23 ; HTB, Joined Cases C-17/22 and C-18/22, EU:C:2024:738, paragraph 49.  
23 EDPB Guidelines 1/2024 on processing of personal data based on Article 6(1)(f) GDPR, version 1.0, 8 October 2024, paragraph 
14. 
24 EDPB Guidelines 1/2024 on processing of personal data based on Article 6(1)(f) GDPR, version 1.0, 8 October 2024, paragraph 
16. 
25 EDPB Guidelines 1/2024 on processing of personal data based on Article 6(1)(f) GDPR, adopted on 8 October 2024, paragraph 
17. 
26 EDPB Opinion on certain data protection aspects related to the processing of personal data in the context of AI models 28/2024, 
adopted on 17 December 2024, paragraph 69.

## Page 16 (Section: Condition 3: balancing test)

15 | Adopted 
assessment entails two elements27: (i) whether the processing activity will allow the pursuit 
of the purpose; and (ii) whether there is an equally effective and less intrusive way of 
pursuing this purpose.28 
52 When personal data is necessary for training generative AI, narrowing the collection criteria 
to exclude unnecessary collection of personal data, rather than scraping a wide part of the 
internet may be crucial to ensure the necessity condition is met. Using pseudonymised 
personal data, or synthetic data, may be another less intrusive way of pursuing this purpose.  
Condition 3: balancing test  
53 The balancing test requires, inter alia, the identification and description of the different 
opposing rights and interests at stake, i.e., on the one side, the interests, fundamental rights 
and freedoms of the data subjects; on the other side, the legitimate interests of the controller 
or a third party. The impact on the data subjects as well as their reasonable expectations are 
also relevant elements of the balancing.29   
Data subjects’ interests, fundamental rights and freedoms 
54 In the context of web scraping for training a generative AI model, data subjects’ interests 
may include, but are not limited to, the interest in self-determination and retaining control 
over their own personal data (i.e. the data that originally was published on a website for a 
certain purpose is then scraped and processed for generative AI training against the data 
subjects’ wishes or without their knowledge).30 Also, large-scale and indiscriminate data 
collection in the AI development phase may create a sense of surveillance for data subjects 
(‘chilling effect’). This may lead individuals to self-censor themselves and risks undermining 
their freedom of expression. The ‘chilling effect’ on freedom of expression may be due to the 
possible use of an AI model to identify data subjects who intended to express themselves 
anonymously, especially if the AI model is connected to a web search tool, as well as to the 
possible use of the AI model for profiling within the meaning of the GDPR.31 The generation 
of deep-fakes (pictures, videos, speech) also adds to the possible impact on data subjects’ 
interests, rights and freedoms, as well as possibly on the right to dignity of the person 
concerned.32 
Impact of the processing on the data subjects  
The nature of the data processed  
55 When scraping data from the internet, it should be recalled that - in addition to special 
categories of personal data and data relating to criminal convictions and offences that enjoy 
special protection under Article 9 and 10 of the GDPR respectively - certain types of personal 
data revealing highly private information, such as location data or financial data, may also 
be scraped. Personal data about minors may also be collected. The processing of such 
personal data may lead to significant consequences for data subjects and should be 
 
27 EDPB Opinion on certain data protection aspects related to the processing of personal data in the context of AI models 28/2024, 
adopted on 17 December 2024, paragraph 72. 
28 EDPB Guidelines 1/2024 on processing of personal data based on Article 6(1)(f) GDPR, adopted on 8 October 2024, paragraph 
29. 
29 EDPB Guidelines 1/2024 on processing of personal data based on Article 6(1)(f) GDPR, adopted on 8 October 2024, paragraph 
32. 
30 EDPB Opinion on certain data protection aspects related to the processing of personal data in the context of AI models 28/2024, 
adopted on 17 December 2024, paragraph 77. 
31 Article 4(4) GDPR. 
32 See also the section on Consequences for data subjects, at paragraphs 59-61 of these Guidelines.

## Page 17 (Section: Condition 3: balancing test)

16 | Adopted 
considered when assessing the level of intrusiveness, notably in case of personal data 
relating to minors. 
56 As a rule, the more sensitive or private the nature of the data to be processed, the more 
likely it is that the processing of such data will have a negative impact on the data subject, 
and the more weight should be attributed to it in the balancing test.   
The context of the processing 
57 The context of the processing and the specific data processing methods may influence the 
impact that the processing may have on the rights and interests of the data subject. The 
EDPB has previously stated that the use of web scraping in the development phase may 
lead - in the absence of sufficient safeguards - to significant impacts on individuals, due to 
the large volume of data collected, the large number of data subjects, and the indiscriminate 
collection of personal data.33 
58 Since information published on the internet are rarely deleted, the scraped data may have 
been published during a long period of time. Scraping a larger amount of websites means 
the interference with the fundamental rights to privacy and to the protection of personal data 
increases. 
Consequences for data subjects 
59 The rights, freedoms and interests of the data subjects may be impacted by the envisaged 
processing. The greater the impact on the data subjects is, the less probable it is that the 
controller can rely on legitimate interest. 
60 In practice, it might be difficult for data subjects to exercise their rights under the GDPR and 
to oppose the scraping of their data, notably when data are scraped by third parties. This 
means that, even if the data subjects are aware that their personal data will be scraped, it is 
difficult for them to make these data unreachable to scrapers. One of the main consequences 
of scraping in the context of generative AI is that given the current technical state of the art, 
once the model is trained, personal data cannot be easily deleted from a model. 
61 The analysis of the possible further consequences of the processing should also consider 
the likelihood of these further consequences materializing. The assessment of such 
likelihood should be made taking into consideration the technical and organizational 
measures in place and the specific circumstances of the case.34   
Expectations of data subjects  
62 The data subjects’ reasonable expectations play an important role when weighing their 
legitimate interest(s) and the interests or fundamental rights and freedoms of data subjects.  
63 Reasonable expectations do not necessarily depend on the information provided to data 
subjects, as the mere fulfilment of the information obligations set out in Articles 12, 13 and 
14 GDPR is not sufficient in itself to consider that the data subjects can reasonably expect 
a specific processing. 35 However, the information provided to data subjects may be 
 
33 EDPB Opinion on certain data protection aspects related to the processing of personal data in the context of AI models 28/2024, 
adopted on 17 December 2024, paragraph 86. 
34 EDPB Opinion on certain data protection aspects related to the processing of personal data in the context of AI models 28/2024, 
adopted on 17 December 2024, paragraph 90. 
35 EDPB Guidelines 1/2024 on processing of personal data based on Article 6(1)(f) GDPR, adopted on 8 October 2024, paragraph 
53.

## Page 18 (Section: Condition 3: balancing test)

17 | Adopted 
considered when assessing whether data subjects can reasonably expect their personal 
data to be processed.36 
64 Given the technological developments of recent years on generative AI, people may be 
aware that the data they publish online may be accessed, collected and reused by third 
parties. However, it cannot be considered that they can always expect such processing to 
take place in all situations, for all purposes, for all controllers’ interests and for all types of 
data accessible online concerning them. Moreover, the impact of generative AI models, 
depending on the capability of the model, may also change in time. In particular, the 
controller should consider: 
• 
the nature of the source websites (social networks, online forums, dataset 
dissemination sites, etc.) 
• 
the type of publication and the publicly accessible nature of the data (for example, 
an article published on a freely accessible blog has a more public character compared 
to a post on a social network published with access restrictions). As a ‘rule of thumb’, 
when the data has been made public and visible to everyone by the data subject 
themselves, the data subjects are more likely to reasonably expect that their personal 
data may be processed by others.  
• 
the restrictions imposed by the scraped website, for example through the 
implementation of technical measures such as the use of robots authentication to view 
content, robots.txt or ai.txt files, or the implementation of CAPTCHA, which are 
intended to impose an action that can only be carried out by a human being, and aim 
to prohibit access to the pages by robots. If data subjects are aware that a website 
implements these measures and a website is nevertheless scraped, it is less likely that 
they can expect the processing of their personal data by a scraping entity.  
• 
the nature and characteristics of the relationship between the data subject and 
the controller: even though there is often no direct relationship between the data 
subject and the entity carrying out the web scraping or using scraped data, people may 
be aware that the data published online may be accessed, collected and reused by 
third parties;37 
• 
the characteristics of the data subjects (minor, public figure, position of the data 
subject, etc.) 
Example 4: A person uploads their data to a content sharing platform that is freely 
accessible and does not contain any prohibitions against web scraping, and the 
platform communicates the possibility of the content being scraped to its users. 
In this instance, data subjects can reasonably expect third parties to scrape that 
data to develop AI models. 
 
Example 5: If a person uploads their data to a content sharing platform that prohibits 
scraping through the use of robots.txt files and the implementation of CAPTCHA, 
and expressly states on their site that they do not allow the use of their users' 
data for the development of AI models, they cannot reasonably expect third 
parties to scrape that data for that purpose. 
 
36 EDPB Opinion on certain data protection aspects related to the processing of personal data in the context of AI models 28/2024, 
adopted on 17 December 2024, paragraph 92. 
37 EDPB Guidelines 1/2024 on processing of personal data based on Article 6(1)(f) GDPR, paragraph 54.

## Page 19 (Section: Condition 3: balancing test)

18 | Adopted 
The role of mitigating measures 
65 When for a specific processing the data subjects’ interests, rights and freedoms override the 
legitimate interest(s) being pursued by the controller or a third party, the controller may 
consider introducing mitigating measures to limit the impact of the processing on data 
subjects. Mitigating measures are safeguards that should be tailored to the circumstances 
of the case. These additional measures should not be confused with measures that the 
controller is legally required to adopt anyway to ensure compliance with the GDPR.38 If the 
data subject’s interests, rights and freedoms override the legitimate interests being pursued, 
and sufficient mitigating measures are not taken, the processing cannot be based on Article 
6(1)(f) GDPR. 
66 Measures may include technical or organisational measures, such as:  
a. Excluding data content from publications which might include personal data 
entailing risks for particular persons or groups of persons (e.g. individuals who 
might be subject to abuse, prejudice or even physical harm if information was 
released publicly). 
b. Ensuring that certain data categories are not collected or that certain sources 
are excluded by default from data collection is important to comply with the 
principle of data minimization, but also to limit the impact of the scraping on 
data subject. This could include, for instance, certain websites that are 
particularly intrusive due to the sensitivity of their subject matter. 
c. Limiting the collection by excluding scraping of certain personal data, such as: 
 
personal data on sites, which are only accessible when logged into the 
site or service and are therefore not freely accessible, for example 
personal data published on a social network that requires login before 
getting access to that data; 
 
personal data on sites that are freely accessible but in relation to which 
data subjects cannot be considered reasonably aware of the 
accessibility. For example, where a social network returns different 
outputs when the user agent of the scraping service is used and when 
the user agent of the web browser from the social media user is used, 
particularly where the scraping service receives more data (e.g. meta 
data such as timestamps or access statistics by using a technical API) 
than the regular user. 39 This could also be the case for an online 
directory or register in which anyone can freely look up an individual's 
name, address and contact details; 
d. Imposing other relevant limits on collection, possibly including criteria based on 
time periods. 
e. Establishing safeguards that contribute to increased transparency. For 
example, the controller can publish and make available, as widely as possible, 
information about data collection and data subjects’ rights (e.g. through online 
articles), ensuring that an updated list of scraped websites is published.  
 
38 EDPB Guidelines 1/2024 on processing of personal data based on Article 6(1)(f) GDPR, adopted on 8 October 2024, paragraph 
57. 
39 For information about the term ‘user agent’, see for example User agent - Wikipedia, or RFC 9110 - HTTP Semantics.

## Page 20 (Section: 3.2.4 Special categories of personal data)

19 | Adopted 
f. Facilitating the exercise of individuals’ rights, including putting in place a 
discretionary and prior right to object to strengthen individuals' control over their 
data. The controller can also create an opt-out list, which allows data subjects 
to object to the collection of their data on certain websites or online platforms 
by providing information that identifies them on those websites, including 
before the data collection occurs. 
g. Deleting or anonymising the unnecessary personal data as soon as possible. 
h. As referred to in the EDPB guidelines on pseudonymisation, pseudonymisation 
could be a measure to limit the direct identification of personal data. This could, 
in some cases, be done by replacing direct identifiers with placeholders and 
use these during the AI training. 
i. Other additional measures that are relevant to protect personal data concerned 
by the further stages of the AI development phase, including measures to limit 
the risks of memorisation, regurgitation or attack of AI models or systems (e.g. 
deduplication).  
These measures do not constitute an exhaustive list. The controller should 
make a case-by-case assessment to determine which measures are 
appropriate. 
Example 6: An organisation that collects numerous publicly available online voice 
recordings, in order to develop and market a voice generation tool, without taking 
any additional measures to protect the training data or limit the risks of unlawful 
or malicious reuse, cannot rely on the legal basis of legitimate interest. 
 
Example 7: An organisation aims to develop a generative AI system for text. It 
exclusively uses data from freely and publicly accessible online sources, where 
the data subjects have manifestly made the content public. It also excludes any 
content protected by copyright (i.e., using only content in the public domain or for 
which rights holders have not objected to text and data mining as permitted under 
Directive 2019/790 on copyright and related rights in the Digital Single Market). 
In addition, it implements a range of safeguards to limit data memorization and 
regurgitation, restricts problematic content generation through technical or 
contractual measures, facilitates the exercise of data subjects’ rights when 
reidentification is possible, and clearly indicates data sources in a publicly 
available privacy policy. In such a case, the balancing test may generally be 
considered as met. 
3.2.4 Special categories of personal data  
67 Processing of special categories of data, such as data revealing racial or ethnic origin or 
political opinion, and concerning health or sexual orientation, is prohibited.40 For the intended 
scraping of such data a derogation in Article 9(2) GDPR is required, in addition to a lawful 
basis under Article 6 GDPR.  
 
40 Article 9(1) GDPR.

## Page 21 (Section: The case GC & Others, C-136/17)

20 | Adopted 
68 Even though the controller should implement measures to prevent the collection of such 
personal data, it is not always possible to assess with reasonable certainty whether the 
scraping leads to the collection of special categories of personal data as defined in Article 9 
GDPR until after the data has been scraped, thus when the processing activity has already 
been carried out.  
69 It remains likely that, despite the organisational and technical measures, the controller 
residually processes special categories of personal data that it did not intend to collect and 
subsequently process. If such processing cannot be justified under EU data protection law, 
it will be unlawful for controllers to scrape such personal data in the context of AI 
development (subject to the considerations made below) 
The case GC & Others, C-136/17 
70 For the processing of personal data in the context of the activity of a search engine, the Court 
of Justice of the European Union (‘the Court’) has emphasized that the processing and 
dissemination of special categories of data, constitutes a particularly serious interference 
with the fundamental rights to privacy and the protection of personal data, and that there is 
no exemption from the prohibitions or restrictions contained in Article 9 or 10 GDPR for the 
activity of a search engine. However, the Court recognised that the specific features of the 
processing carried out by the operator of a search engine may have an effect on the extent 
of the operator’s responsibility and obligations under those provisions, 41 and that the 
prohibition in Article 9(1) GDPR applies ‘within the framework of his responsibilities, powers 
and capabilities’.42 
71 Against this background, the Court considered the prohibitions and restrictions of Articles 9 
and 10 GDPR apply to the operator of a search engine only by reason of referencing (on a 
page with search results following a search on the basis of an individual’s name) and via 
verification on the basis of a request by the data subject.43 
The responsibilities, powers and capability test 
72 The EDPB considers that the Court’s ruling can be relevant for the incidental and residual 
collection of special categories of personal data in the context of web scraping for the training 
of an AI model.44 The Court’s ruling can be relevant only for processing activities similar to 
those in the judgement, and under similar circumstances, and should not be seen as a 
general exemption from the requirements in Articles 9 and 10 GDPR. 
73 The controller should make a case-by case analysis to assess if the following conditions are 
met: 
a. the processing activity has relevant similarities with the processing activity of a 
search engine, as referred to in the Court’s judgement, 
b. the processing includes only the incidental and residual processing of special 
categories of personal data, and no intentional processing, 
 
41 CJEU, Grand Chamber, Judgment of 24 September 2019, GC and Others C-136/17, paragraph 45. 
42 C-136/17, paragraph 48. 
43 C-136/17, paragraph 47. 
44 Incidental and residual collection of data should be understood as a processing of data that the controller has no intention of 
carrying out, but which will occur to some extent despite the implementation of measures to prevent such collection.

## Page 22 (Section: The case GC & Others, C-136/17)

21 | Adopted 
c. it is difficult/impossible to assess whether and to what extent the processing 
includes special categories of personal data, and therefore prevent the 
collection if such data, and 
d. the controller implements measures ‘within the framework of his 
responsibilities, powers and capabilities’, as mentioned in the Court’s 
judgement, to prevent the dissemination of special categories of personal data.  
The responsibilities, powers and capabilities when web scraping in the context 
of the development of generative AI models 
74 If the conditions a-c are relevant for the specific processing activity, and the controller 
implements measures ‘within the framework of his responsibilities, powers and capabilities’ 
to prevent the dissemination of special categories of personal data,  the prohibition laid down 
in Article 9(1) GDPR will apply to a controller only within this framework of his responsibilities, 
powers and capabilities (condition d). These responsibilities, powers and capabilities will 
include at least the following measures:   
i. Before the collection of the data the controller should define precise 
criteria and apply filters to prevent the collection of special categories 
of personal data. The controller should also exclude certain categories 
of websites (e.g. sites or social networks mainly used by minors) which 
structurally contain these data (e.g. data concerning vulnerable such as 
minors or certain sensitive data).  
ii. After the collection of the data, the controller should ensure that 
special categories of personal data that may have been collected 
despite the application of these measures is deleted from datasets 
immediately after the collection or as soon as it is identified. In 
particular, the controller should delete special categories of personal 
data upon request from the data subject if the request constitutes a 
plausible indication that the concerned data indeed fall under the 
prohibition laid down in Article 9(1) GDPR. 
iii. During the development of the AI model, the controller should 
prevent extraction of special categories of personal data from the model 
and provide assurance regarding state-of-the-art resistance to privacy 
attacks. The controller should train and perform testing of the model 
and apply content (output) filters to the AI system to prevent the system 
from producing results and giving information to users that reveals 
special categories of personal data.  
iv. After the development of the AI model, the controller using the model 
as part of an AI system should implement a process to constantly 
monitor the output generated by the AI system. When, despite the 
organisational and technical measures already implemented, special 
categories of personal data is included in the output, the controller 
should immediately take measures to prevent the production of such 
data (e.g. through updated or reinforced output filters, restricting certain 
prompts or functionalities). In the longer term, model unlearning or other 
processes with equal effect that might become available through 
technological progress should also be considered is necessary. If,

## Page 23 (Section: The case GC & Others, C-136/17)

22 | Adopted 
through technological progress, machine unlearning algorithms can 
guarantee deletion of specific data from a model this may provide an 
alternative to output filters or retraining the model. 
75 The controller should be able to demonstrate, in line with the accountability principle, that 
the conditions a-c are relevant for the specific processing activity, and that the measures 
adopted within the framework of his responsibilities, powers and capabilities’ (condition d) 
are relevant and effective to prevent the collection and the dissemination of special 
categories of personal data. 
76  The implementation of these measures should be accompanied by regular verification and 
assessment - having regard to the development as well as to the use of the AI model - of the 
effectiveness of the measures implemented when performing web scraping activities. As a 
result of such verification and assessment, it is possible that additional or different 
organisational and technical measures should be implemented by the controller when the 
measures adopted are not effective. 
77 The measures to be implemented should be in line with the state-of-the-art techniques 
available to limit the collection and other processing of special categories of personal data. 
It is however possible that in the future better privacy enhancing techniques to limit or even 
exclude the processing of special categories of personal data become available. Controllers 
should therefore constantly monitor technological developments to ensure that the state-of-
the-art measures remain appropriate. 
 
For the European Data Protection Board 
The Chair 
 
Anu Talus


---

# Good practice guide for the use of the HMA-EMA catalogues of real-world data sources and studies

- **Issuer:** EMA
- **Type:** Guideline
- **Language:** en
- **Source:** https://www.ema.europa.eu/en/documents/regulatory-procedural-guideline/good-practice-guide-use-hma-ema-catalogues-real-world-data-sources-studies_en.pdf
- **Licence:** EMA-reuse

## Page 1

Official address  Domenico Scarlattilaan 6  ●  1083 HS Amsterdam  ●  The Netherlands
Address for visits and deliveries  Refer to www.ema.europa.eu/how-to-find-us 
Send us a question  Go to www.ema.europa.eu/contact 
Telephone +31 (0)88 781 6000
An agency of the European Union  
© European Medicines Agency, 2025. Reproduction is authorised provided the source is acknowledged.
8 April 2025
EMA/787647/2022
European Medicines Agency
Good Practice Guide for the use of the HMA-EMA 
Catalogues of real-world data sources and studies
Version 2.0
Start of public consultation 
26 September 2022
End of consultation (deadline for comments)
15 November 2022
Agreed by MWP
4 December 2024
Adopted by CHMP
17 February 2025
Version 2 published
8 April 2025
Keywords
Data sources, metadata, study protocol, study report, data flows, data management, 
vocabulary, glossary, use cases, population, real-world data, observational studies

## Page 2

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 2/17
Contents
Abbreviations ..............................................................................................3
1. Introduction ............................................................................................4
2. Purpose of this document ........................................................................5
3. Considerations on the design of the Catalogues ......................................5
3.1. Scope of the data sources Catalogue......................................................................6
3.2. Scope of the studies Catalogue..............................................................................6
4. Use of the catalogues to identify and assess data sources.......................6
4.1. Categories of the RWD Catalogues metadata elements .............................................6
4.1.1. Metadata about systems, and processes and data quality metrics............................7
4.1.2. Metadata describing the dataset content ..............................................................7
4.2. Data Quality considerations ..................................................................................8
4.3. Use cases...........................................................................................................9
4.3.1. Planning of a study .........................................................................................10
4.3.2. Assessment of a study protocol.........................................................................12
4.3.3. Assessment of a study report or publication........................................................13
4.3.4. Writing of a study protocol or study report .........................................................13
4.3.5. Benchmarking of several data sources ...............................................................14
4.3.6. Analysis of a data source used in a study ...........................................................14
Glossary ....................................................................................................15
References.................................................................................................17

## Page 3 (Section: Abbreviations)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 3/17
Abbreviations
ATMPs
Advanced Therapy Medicinal Products
CDM
Common Data Model
DQF
Data quality framework
EMA
European Medicines Agency
EMRN 
European Medicines Regulatory Network
ENCePP
European Network of Centres for Pharmacoepidemiology and Pharmacovigilance
ETL
Extract, Transform, Load 
EU
European Union
EU PAS Register
European Union electronic register of post-authorisation studies
FAIR
Findable, Accessible, Interoperable, and Reusable 
FDA
Food and Drug Administration
GDPR
General Data Protection Regulation 2016/679 (EU)
GP
General practitioner 
HARPER
HARmonized Protocol template to Enhance Reproducibility
HMA
Heads of Medicines Agencies
ICU
Intensive care unit
ID
Identification
IMI
Innovative Medicines Initiative
ISO
Internal Organization for Standardization
MedDRA
Medical Dictionary for Regulatory Activities 
MINERVA
Metadata for data dIscoverability aNd study rEplicability in obseRVAtional studies
OMOP
Observational Medical Outcomes Partnership
PICOT
Population, Intervention, Comparison, Outcome and Time horizon
RWD
Real-world data 
RWE
Real-world evidence
SIFPD
Structured Process to Identify Fit-for-Purpose Data
TEHDAS
Towards the European Health Data Space

## Page 4 (Section: 1.  Introduction)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 4/17
1.  Introduction
Real-world data (RWD) and real-world evidence (RWE) are increasingly used in the scientific evaluation 
of medicines to support regulatory decision-making. Conducting RWD research and interpreting study 
findings pose unique challenges and require a good understanding of associated methods, terminologies 
as well as deep knowledge of data source characteristics and of the healthcare system organisation in 
the respective countries [1, 2]. However, information on RWD sources is often lacking or not 
standardised. Such information, commonly provided as metadata1 or “data about data”, offers context 
about the data and includes details on a dataset’s purpose, location, key-variables, generation, format, 
and ownership. As mentioned in the Data Quality Framework (DQF) for EU medicines regulation 
(hereafter referred to as EMRN DQF) [3], metadata are essential to understand the meaning of data and 
to assess the fitness for purpose (e.g. quality) of a dataset for a specific purpose. The HMA-EMA (Heads 
of Medicines Agencies-European Medicines Agency) Catalogues of RWD sources and studies along with 
the EMRN DQF and the Draft ‘Data Quality Framework (DQF) for EU medicines regulation: application to 
Real-World Data’ (hereafter referred to as RW-DQF) [1] will help to further address these aspects.
Having access to a standard and electronic set of complete and accurate metadata for data sources can 
support the identification of data sources suitable for a specific study, facilitate the description of the 
data sources planned to be used for a specific study or research, and help to properly assess the 
evidentiary value of the study results. Metadata are often published in data catalogues, which have the 
purpose of making data discoverable and assessable for fitness for purpose without revealing the raw 
data themselves.
The Heads of Medicines Agencies/European Medicines Agency (HMA/EMA) joint Big Data Task Force 
recommended “to promote data discoverability through the identification of metadata” as part of its 
priority recommendation III: “Enable data discoverability. Identify key meta-data for regulatory decision 
making on the choice of data source, strengthen the current European Network of Centres for 
Pharmacoepidemiology and Pharmacovigilance (ENCePP) resources database to signpost to the most 
appropriate data, and promote the use of the FAIR principles (Findable, Accessible, Interoperable and 
Reusable)” (HMA/EMA, 2020). This goal was therefore included in the 2023-2025 Work Plan2of the 
HMA/EMA joint Big Data Steering Group.
To fulfil this mandate, EMA initiated in November 2020 the study “Strengthening Use of Real-World Data 
in Medicines Development: Metadata for Data Discoverability and Study Replicability” (MINERVA; 
EUPAS39322) [4]. The focus of the MINERVA study was to define a set of metadata for RWD sources, 
together with engagement of relevant stakeholders to reach broad agreement on this identified set, as 
well as to develop a good practice guide describing the metadata and recommendations.
Based on the results of MINERVA, multiple other studies3, and consultation with the ENCePP community 
and other stakeholders, EMA has developed two electronic catalogues to provide metadata for RWD 
sources 
and 
real-world 
(observational) 
studies 
that 
can 
be 
found 
here: 
https://catalogues.ema.europa.eu/. These publicly available catalogues were launched on 15 February 
2024 and have the following key objectives:
1) Facilitate the discoverability of adequate data sources to generate real-world evidence (RWE) 
for regulatory purposes (e.g. identification of RWD source suitable for investigating a specific 
research need);
1For a more comprehensive definition of metadata and its role, please see the EMRN DQF [1].
2 HMA/EMA Workplan 2023-2025
3 Studies: EUPAS39322, EUPAS49303, EUPAS104093

## Page 5 (Section: 1.  Introduction)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 5/17
2) Aid in the suitability assessment of data sources by providing clear and easy access to 
information from the study protocol and study report; 
3) Improve interoperability between studies and data sources;
4) Improve transparency.

## Page 6 (Section: 2.  Purpose of this document)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 6/17
2.  Purpose of this document
The Good Practice Guide for the use of the HMA-EMA Catalogues of RWD sources and studies has been 
developed to provide regulators, researchers (including academia and pharmaceutical industry) and 
other interested stakeholders with recommendations on the use of the catalogues from the perspective 
of the data user. Specifically, the guide focuses on describing the steps and best practices on identifying 
a suitable data source, when planning a study.   
For the users submitting data to the Catalogues (i.e.: data holders and investigators submitting study 
data) a user guide has also been published to help users navigate the Catalogues in this context. The 
user guide provides descriptions of the data fields and definitions, as well as guidance on how to submit 
and maintain a record in the Catalogues. The user guide is available on the Catalogues website 
(https://catalogues.ema.europa.eu/). 
3.  Considerations on the design of the Catalogues
The Catalogues collect information on the systems and processes behind data capture, as well as on 
descriptors of the data, and they are intended for capturing the extent of variety of existing data sources 
as well as facilitate data discoverability and fit-for-purpose assessments4. The information in the 
catalogues is organised in sections. For data sources, these sections include Administrative details, Data 
elements collected (including Vocabularies used), Quantitative descriptors, Data flows and management. 
For studies, these sections include Administrative details, Methodological aspects, and Data 
management. They are composed of qualitative information and quantitative metadata, e.g., counts and 
demographic distributions of the underlying population. The two Catalogues are supported with data 
from Networks and Institutions. 
The Catalogues follow good practices for data management:

FAIR (Findable, Accessible, Interoperable and Reusable) principles [5]: The Catalogues are 
supporting globally unique and persistent identifiers, ensuring seamless data integration and allowing 
users to reference specific entries consistently across different contexts and platforms. There is 
ongoing work to fully implement the FAIR principles to promote good data practices and allow 
integration with other catalogues.

A controlled data entry process is run for the initial collection of metadata by the data holder and/or 
researchers; regular updates of metadata are foreseen at least once per year for data source records, 
and at each study milestone for study records.

Change management and reproducibility are supported by enabling data source holders and/or 
researchers to edit the corresponding metadata while ensuring that the attribution of each data entry 
is traceable via appropriate version control, and by enabling the creation of a copy of the metadata 
and their update by the data holders and/or researcher.

The General Data Protection Regulation (GDPR) is complied with by defining and communicating the 
purpose and use of the catalogues, establishing appropriate measures to protect the privacy of 
institutions and individuals, providing information on the process and approval needed for data 
availability and accessibility and ensuring a technical option to delete the metadata involving relevant 
personal data.
4 Assessing the fitness for purpose of a data source is strictly related to characterization of a source’s data quality as noted 
in the EMA DQF. To this respect, we note how “systems and processes” and “descriptors of data” correspond to the 
concepts of “foundational determinants” and “intrinsic determinants” introduced in the framework.

## Page 7 (Section: 3.1.  Scope of the data sources Catalogue)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 7/17
A quality management process is in place, including an incident management system, a disaster recovery 
plan and a quality assurance office. It is also worth mentioning that the Catalogues do not provide access 
to primary records of data. The Catalogues only provide metadata about data sources and studies. 
Metadata do not contain individual patient data, and therefore informed consent is not applicable. 
Permission by the data holder to use the underlying data is always needed to access the data for analysis.
3.1.  Scope of the data sources Catalogue
The scope of the Catalogue of RWD sources (and this document) is on sources of secondary RWD, 
meaning data already collected for another purpose than the specific research question you would have, 
such as for patient monitoring, healthcare reimbursement, quality management or another 
administrative purpose. Primary data are in scope only when patient registries [6] are considered. 
Evidently, this document will also touch upon patient registries as sources of secondary data. The 
Catalogue provides information allowing for an initial evaluation of the suitability of data sources for a 
study.
3.2.  Scope of the studies Catalogue
The Catalogue of RWD studies, replacing the former EU PAS Register, aims to promote transparency of 
observational studies in the context of the medicine regulation activity. A central repository where 
observational research is registered benefits the scientific community and promotes the use of RWE [13]. 
For the purpose of this document, studies are described in relation to the selection of a suitable data 
source, as studies data is linked with its respective data source. 
4.  Use of the catalogues to identify and assess data sources
4.1.  Categories of the RWD Catalogues metadata elements 
The following section describes the content of the Catalogues in summary terms with reference to the 
specific metadata elements (e.g., C2.7, D.1.2.1.1) in parentheses. The complete list of metadata 
elements is available in the document ‘List of metadata for the HMA-EMA Catalogues of real-world data 
sources and studies’ [7], which has been generated in line with the Big Data Steering Group workplan 
and the European medicines regulatory network Strategy. Both this Good Practice Guide and the 
metadata elements document [7] will be updated regularly as healthcare categories and data source 
requirements evolve over time.
Please note that herein “elements” is used to refer to metadata elements, while “variables” is used to 
refer to variables present within a data source.
4.1.1.  Metadata about systems, and processes and data quality metrics
The following metadata elements provide information on the systems and processes that lead to the 
data. As noted in the  EMRN DQF [3] and the RW-DQF [1], these are essential to assess the reliability 
and timeliness of data, but are also useful to understand other dimensions such as extensiveness and 
coherence (as defined in the EMRN DQF). Element identifiers are provided in parentheses and references 
in the ‘List of metadata for the HMA-EMA Catalogue of real-world data sources and studies’ [1].

Data management, including the possibility of data validation (elements C2.7, C8.5 and C8.5.1) 
and the mapping to a common data model (CDM) (D1.2.1.1, D1.2, D1.2.1, D1.4 and D1.7). The

## Page 8 (Section: 4.1.2.  Metadata describing the dataset content)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 8/17
validation of data elements does not mean that access to the underlying data is granted to data 
sources in the Catalogue. The process of validation is the responsibility of the data holder.

Mapping Extract, Transform, Load (ETL) to a CDM (B7.1 to B7.5). For more details, please see 
the EMRN  DQF [3] and review maturity level-related sections (chapter 7) as well as the RW-DQF 
[1] section 1.4.

Any qualification received by an institution/authority providing formal qualifications (e.g.: EMA, 
Internal Organization for Standardization (ISO) or other certifications) (C3.1, C3.1.1) 

Governance details such as data capture and management, data quality checks and validation 
of results of data quality checks (C2.3)

The process of collecting and recording the data (C4.3), linkage information (B5.2, B.5.2.1, 
B5.3, B4.1)

All vocabularies used in the data source5

A link to the publications describing the data source (e.g.: validation, data elements, 
representativity) preferably by means of peer-reviewed publications that reflect the best description 
of the data6 
Beyond the characterisation of systems and processes, the above elements touch on data quality metrics 
that measure intrinsic aspects of data quality (e.g.: completeness, coherence, etc.). Access to raw data 
and computational resources may be needed for a more in-depth assessment of intrinsic aspects of data 
quality, for example a verification of the records and values, data verification against reference or 
plausible values and other computations. Such assessment could be performed by the data holders and 
periodically updated, preferably by using automated tools (for an example, please consult [8]). Data 
holders are encouraged to make the methods and the results of these assessments publicly available for 
consultation to support the assessment and replication of studies.
The main goal of the data sources Catalogue is discoverability of data sources in the health domain and 
therefore the data sources’ reliability should be assessed in light of a research question. EMA will not 
provide a benchmark or minimum level of reliability of data sources to be used for studies in order to be 
included in the Catalogues; however, the principles explained in the EMRN DQF and the RW-DQF will aid 
the assessment of data quality of each data source used to address a given research question.
4.1.2.  Metadata describing the dataset content
Beside a summary understanding of the data quality characteristics of a source, assessing the fitness for 
purpose of a data source requires an assessment of whether the source contains the appropriate data 
(relevance) and whether the data are suitable to generate valid evidence informing a specific research 
question based on the proposed study design. For example, this could inform the implementation of step 
3 of the Structured Process to Identify Fit-for-Purpose Data (SPIFD)[9], or the key elements of a 
structured framework such as the target trial emulation (TTE) framework [10-12] or the Population, 
Intervention, Comparison, Outcome and Time horizon (PICOT) format [13]. 
5 Note that the vocabularies in use can be also detected from an actual dataset.
6 Such information provides a broad context on the why and how of a data source, that can help understand its biases and 
trade-offs.

## Page 9 (Section: 4.2.  Data Quality considerations)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 9/17
The RWD Catalogues provide elements that cover information on type of data present, as well as their 
extensiveness. The Catalogues also provide the elements to be included in the table of data sources 
recommended by the HARmonized Protocol template to Enhance Reproducibility (HARPER) [14].
These data elements cover:

Setting: country(-ies) (C1.5), region(s) (C1.5.1), type of data source (C5.1 and C5.1.1), care 
setting (C1.14). For sensitive variables, depending on country- and data holder-specific data privacy 
rules, not all items may be published in the catalogues due to privacy concerns.

Population: total and active population size (C7.1), percentage of the population covered by the 
data source in the catchment areas (C1.11.2), description of the population for which data are not 
collected (C1.11.1), age groups (C1.8), sociodemographic information (C6.7), lifestyle factors 
(C6.8), family linkage (C6.6, C6.6.1), availability of data on pregnancy and neonates (C1.9), trigger 
for registration (C1.6, C1.6.1) and de-registration (C17.1, C1.7.1), median time between first and 
last records for all individuals (B6.3) and active individuals (B6.3.1).

Exposure: availability of data on prescriptions and/or dispensing (C6.13), advanced therapy 
medicinal products (ATMPs) (C6.16), contraception (C6.17), vaccines (C6.19), other injectables 
(C6.19), medical devices (C6.20), procedures (C6.21), medicinal products (C6.15.1) and indication 
(C6.18), and biomarker data (C6.26).

Outcomes: availability of data on hospital admission or discharge (C6.10), intensive care unit (ICU) 
admission (C6.10.1), death (mortality) and cause of death (C6.11), clinical measurements (C6.23), 
genetic data (C6.25), patient-generated data (C6.27), health care utilisation (C6.29), diagnostic 
codes (C6.9), specific diseases (C1.10) with disease information collected (C1.10.1).

Time elements: date when the data source was established (C4.5), first collection date (C1.12) 
and last collection date (C1.13), median time between the first and the last available records for 
unique individuals captured in the data source (B6.3) and for unique active individuals (B6.3.1).
Link to the Catalogue of RWD studies also allows for identification of studies that have been performed 
with the same data source, and subsequently for an evaluation of its suitability to answer the research 
question of interest. 
4.2.  Data Quality considerations
Assessing the suitability of data sources is inherently assessing the quality of a source overall and also 
in relation to a specific need. Data quality can be defined as “fitness for purpose for users’ needs in 
relation to health research, policy making and regulation, and the degree to which data reflect the 
reality which they aim to represent” [15]. Additionally, it is important to differentiate three broad 
aspects of data quality [1, 3]:
1.
Quality of the processes and methods behind the generation of data e.g.: the detection and 
correction of errors, validation processes, time components and underlying calculations, the 
documentation of standardised processes leading to entry and exit of person, etc. Elements C9.5 
and C2.3 inform on the data quality process employed by a data source, where applicable.
2.
Quality of a dataset itself e.g.: in relevance to missing data and implausible values, coherency of 
formats, codes, the presence of unique identification numbers for each person, etc.
3.
Quality as a characteristic of a data source in relation to a specific research question and method 
e.g.: the presence of the required data needed for a study, the availability and completeness of data

## Page 10 (Section: 4.3.  Use cases)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 10/17
elements and the time span of such data, and whether the number of individuals included, and the 
population characteristics are adequate.
The Catalogues provide information on all three data quality aspects that could help the user assess the 
relevance of a dataset for their specific research question(s), and in some cases the relevance of data to 
their primary use / the original research question that leads to their capture (e.g.: existing publications 
based on a specific data source).
Furthermore, when considering the assessment of the suitability of data sources for a given study, it is 
important to consider that data quality and its management are different between studies with primary 
data collection and studies using secondary data [16]. In primary data collection studies, the study 
design and the study itself apply and control for all data quality management steps. In studies using 
secondary data, data quality assessment relies on generic data quality processes that may or may not 
be relevant to the research question at hand, e.g.: quality processes relevant to data generation, coding, 
curation, validation, processing and storage).
Several data quality frameworks have been proposed to help characterize these different aspects of data 
quality, aiming to reveal the strengths and limitations of a data source with regard to answering a given 
research question. These data quality frameworks differ as to how they categorise and define data quality 
dimensions, their levels of generality, the extent to which they address the relevance of data/dataset to 
a research question, as well as the overall goals what they are designed for.
The Towards European Health Data Space (TEHDAS) initiative has produced a data quality framework 
that defines six dimensions deemed most important at data source level: reliability, relevance, 
timeliness, coherence, coverage and completeness [15]. The release of the EMRN DQF [3] builds on 
TEHDAS and defines high-level principles and procedures that apply across EMA’s regulatory mandate. 
This framework provides general considerations on data quality relevant for regulatory decision making, 
definitions for data quality dimensions and sub-dimensions, as well as their characterisation and related 
metrics. It also presents a strong distinction between the description of data quality (both foundational 
and intrinsic aspects) and its assessment with respect to a research question. The RW-DQF [1] describes 
RWD specific recommendations derived from the EMRN DQF.
As described above, the Data Quality section of the Catalogue will gradually include in its following 
iterations additional elements describing data quality metrics in line with the EMRN DQF7 and the RW-
DQF. This development will also be guided by the progress on development of the data quality and utility 
label as described in Art 56 of the European Health Data Space Regulation [12].
It should be noted that evidence does not only depend on data quality. Appropriate epidemiological and 
statistical methods must be applied to the study design and the analysis of data generated from a RWD 
source. These methods are not addressed by the Catalogue but are outlined in other guidance, e.g.: the 
ENCePP Guide on Methodological Standards in Pharmacoepidemiology, 11th Rev. (2023) [10]. General 
methodological principles of regulatory interest are also included in the Reflection paper on use of real-
world data in non-interventional studies to generate real-world evidence, Draft (2024) [17].
4.3.  Use cases
The following section presents relevant use cases and illustrates how stakeholders can benefit from the 
Catalogues when planning a study and assessing data sources.
7 The EMRN DQF is an umbrella framework applying to a variety of regulatory use cases and not specifically to real-world 
data. A draft document focusing on the application of the EMRN DQF to real-world data has been published.

## Page 11 (Section: 4.3.1.  Planning of a study)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 11/17
4.3.1.  Planning of a study
Use case: An investigator wants to identify suitable data sources for a planned study.
The process for identification of suitable data sources may follow six successive steps (Figure 1):
1.
In a first step, the investigator searches the catalogues to identify relevant data sources fulfilling the 
specifications of the research question of interest or, if there is a prior interest in using a specific 
data source, to access the record of this data source and consult the available information. The 
search may initially consist of the data elements deemed useful to assess pre-defined PICOT [13] 
criteria (see section 4.1.2) in order to identify possible suitable data sources.
2.
In a second step, the investigator accesses the record of each potential data source and screens the 
information on the availability of data (incl. quantitative metadata) on the population, exposures, 
outcomes and confounding variables to confirm that the data source may be relevant to answer the 
research question. 
3.
In a third step, the investigator consults information on the governance, accessibility and availability 
of the selected data sources (C2.3) to determine whether they are accessible, as well as the 
conditions related to their use, and whether the investigator would be eligible to receive aggregated 
information or get access to raw data.
4.
In a fourth step, the investigator screens the metadata allowing to perform a preliminary assessment 
of the reliability of each potential data source based on important quality aspects of the data source 
that are relevant for the specific study (see section 4.2). Publications describing the data source and 
its validation can be extracted and consulted. Missing information for some of these variables may 
raise doubts about the presence of an adequate quality management process or may question 
whether the data holder gives sufficient attention to quality management.
At this stage, the investigator should establish a first list of candidate data sources (if there is no a 
priori choice of a specific data source).
5.
In a fifth step, the investigator uses the links providing access to the studies indexed in the Catalogue 
of RWD studies (via EU PAS numbers) that have been performed with the same data sources to 
address research questions similar to the current one (in any). After restricting to studies with a 
similar design as for the planned study (if relevant), the investigator accesses the study information 
to:

Confirm the suitability of the data source as regards to the PICOT criteria; if the study protocol 
and/or the study report have been uploaded, more granular information can be extracted on 
the time frame for the use of the database, the number of active study participants originating 
from the data source (providing useful information for the sample size calculation for the 
proposed study), the data elements used for the study (e.g. exposure and outcome variables, 
confounding factors), variable definitions and vocabularies (and any need for mapping of 
terms), the transformation of data into categories and the analyses that could be performed 
with the data;

Check in the study protocol or study report (if available) the codes and algorithms (if any) that 
have been used to identify diseases or outcomes of interest as well as their characteristics (if 
relevant, such as their severity), and which prompts and contents were used in such 
algorithm(s);

Learn about the data sources’ strengths and weaknesses (limitations) encountered during the 
study conduct; in case a limitation is acknowledged showing that the data source is not optimal

## Page 12 (Section: 4.3.1.  Planning of a study)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 12/17
to identify all the variables of interest (e.g. diagnosis of the disease, levels of severity, 
treatments, confounding variables), use of the data source should be reconsidered or a strategy 
could be devised to complement the information obtained from the data source with that from 
another, possibly by data linkage;

Search for use of the data source in studies published in peer-reviewed journals and review 
comments made on study limitations.
If there are remaining uncertainties regarding the reliability and relevance of the data source for 
the proposed study, the investigators of similar studies in terms of research question (and study 
design if relevant) can be contacted to gather additional information.
If past studies using the same data source cannot be found, it may still be valuable to leverage the 
data source if its quality and appropriateness for the specific research question seems adequate 
based on the assessment done. Alternatively, investigating the information available for another 
relevant data source may be a valid option.
6.
If the previous steps have been successful, the data holders of the data sources of interest can be 
contacted to discuss the feasibility of using the data sources for the specific study and the conditions 
of this use. Also, in case of additional questions, the investigator can contact the data holder directly.
Figure 1. Steps for using the metadata catalogues when planning a real-world study
The Catalogues can also be a useful tool for regulators to plan studies and for assessing data sources. 
An example is the DARWIN EU® initiative (https://www.darwin-eu.org/). The European Medicines 
Regulatory Network (EMRN) is the principal user of DARWIN EU® by requesting studies to support its 
1. Search the catalogues for possibly relevant data 
sources based on PICOT criteria.
2. Confirm possible relevance of data source based 
on recorded information on population, exposure, 
outcomes, confounding factors and time elements.
4. Screen possible reliability of data source based 
on quality metadata.
5. Use link to EU PAS number to consult information 
on studies with similar research question (and 
design if relevant) performed with the same data 
source.
3. Read information on governance, availability and 
accessibility to determine eligibility for access and 
feasibility.
6. Contact the data source holder to confirm user’s 
eligibility, conditions of access and feasibility of 
using the data source for the study based on 
aggregated or raw data.

## Page 13 (Section: 4.3.2.  Assessment of a study protocol)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 13/17
scientific evaluations and regulatory decision-making process. DARWIN EU® collaborates with data 
partners who help generate RWE that can be used in scientific evaluations and regulatory decision-
making. Via DARWIN EU®, the Catalogue of RWD sources for use in medicines regulation will also be 
extended, providing high-quality, validated RWD on the use, safety and efficacy of medicines thanks to 
onboarding of healthcare databases enabling distributed data access via DARWIN EU® that will expand 
over time.
4.3.2.  Assessment of a study protocol
Use case: A data source is mentioned in the study protocol submitted for a study and the assessor needs 
to understand in detail the suitability of the data source proposed to be used.
The assessor may verify if the data source has been registered in the Catalogues.8 Depending on the 
information that is already available in the protocol, the assessor accesses different sections of the 
Catalogue to verify or complement the provided information. For example, in order to examine the fit-
for-purpose and potential representativeness of the study population described in the protocol relative 
to the target population of the study, the assessor may access qualitative information, such as the 
geographical coverage, the type of data source, the care setting and the trigger for registering a person 
in the data source, as well as quantitative metadata on the percentage of the population covered by the 
data source in the catchment area and the estimated sample size of active patients per age category.
In the Data elements section, the assessor may find information on exposure, outcomes, covariates, and 
subgroups (which may be derived from covariates) collected in the data source and identify those that 
have not been proposed to be extracted but could be useful to include in the study.
The assessor can also explore technical information supporting the evaluation of the protocol such as 
the vocabularies used to define variables, the process of data collection, the CDM, the ETL specifications 
and any linkage strategy.
The extent of the validation of the data source and the possibility to contact patients provides regulatory 
assessors of studies required to pharmaceutical companies’ information about the need and the 
possibility to request additional data validation. The link to studies using the same data source and 
registered in the Catalogue of RWD studies will allow to further document use cases where the data 
source was used with its strengths and limitations.
4.3.3.  Assessment of a study report or publication
Use case: A data source is mentioned in the study report or publication and the reader needs to 
understand the suitability of the data source used to interpret the study results.
The process is similar to the process described above for the assessment of a study protocol. The main 
difference resides in the fact that the study report (or publication) contains results and generally 
quantitative information on the characteristics of the study population originating from the data source. 
The reader may therefore identify, and investigate if needed, differences between the information 
provided in the study report and in the Catalogues. Some verification may be applied to the description 
of the study population, the sample size originating from the data source included in the report 
(publication), the sampling technique used to obtain the study population, the nature and categories of 
8 Except of specific circumstances, there is no legal obligation to register a data source into the Catalogue of RWD sources. 
It is however expected that data source holders will register their data source, and update the records, whenever it will be 
used for public health or regulatory purpose, as absence of information on the data source in the Catalogue may affect the 
scientific credibility and public confidence on study results. In case where a data source user has got access to a data source 
based on a contractual agreement, the contract may include a provision that the data source is registered, or the records 
updated, in the Catalogue as part of the agreement.

## Page 14 (Section: 4.3.4.  Writing of a study protocol or study report)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 14/17
variables included in the analysis, the methods and key variables used to take into account potential 
biases, the coding system provided, limitations stated in the study report (publication) regarding the 
reliability and relevance of the data, and whether the analysis followed the protocol or were unable to 
follow it due to data limitations.
Insight into the characteristics of the data source also helps interpret the study results and understand 
the strengths and limitations of the study independently from the investigator’s own interpretation.
4.3.4.  Writing of a study protocol or study report
Use case: An investigator writes a study protocol or a study report for which they need to describe the 
data source(s) proposed to be used or used in the study. The information on the data source they find 
in other publications or other documentation is heterogeneous, and a comparison between the 
characteristics of several data sources used or to be used in the study is difficult to perform.
The investigator can extract from the Catalogues standardised information on each data source and 
provide a reference to public information for the registered data sources. They can provide in the Methods 
section of the protocol or report the identification number and the link of the data source in the 
Catalogues.
If a data source is not registered in the Catalogues, this registration can be made simultaneously to the 
writing of the protocol or report by the data holder.
4.3.5.  Benchmarking of several data sources
Use case: A data holder or data user may wish to compare the characteristics of a specific data source 
with other ones covering fully or partially the same population.
The different data sources may have different primary purposes, contain different data elements, and 
cover different population groups. It is nevertheless important to be able to perform comparisons to help 
understand the heterogeneity of results obtained in some analyses conducted in the same country or 
region, or to perform a validation of a data source in comparison to another one considered a gold 
standard. For this purpose, the Catalogues provide:

A harmonised description of the characteristics of each data source that allow to compare differences, 
e.g., in demographics (such as age, etc.) covered.

Information on common variables and variable categories by which analyses can be stratified to map 
sources of heterogeneity.

Information on possible linkages with other data sources, including availability of linkages to the same 
data sources (or cross-linkage between data sources) allowing to harmonise data on the same 
individuals and provide additional information, e.g., on confounding factors. 
4.3.6.  Analysis of a data source used in a study
Use case: An investigator, statistician or analyst wants to benefit from the experience of others for the 
programming of the data transformation and statistical analysis. 
If a CDM is used to conduct a study, the analyst will find in the catalogues the specifications of the ETL 
procedure from the data source to the CDM, along with the CDM version. Irrespective of whether the 
data holder has converted the entire data source to the CDM, or only an extraction thereof, this 
information supports the programmer in developing the study script. Using the link to the studies, the

## Page 15 (Section: Glossary)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 15/17
analyst can also access detailed information on the studies conducted using the same data source and 
select the studies that investigated the same research question with a similar study design. The study 
protocol or statistical analysis plan of these studies may contain information on how to operationalise 
the variables of the study in their respective data sources. The detailed programming script may also be 
available in a public repository, e.g., a GitHub repository, along with debugging records.
At the end of the analysis, the analyst is encouraged to publish the script in a public repository, along 
with debugging records, and upload the link to the Catalogues as part of the study record, thus 
enabling transparency, quality control, and facilitating reproducibility. 
Glossary
This glossary addresses the main terms and definitions that have been used in this Good Practice Guide.
Definitions
Explanation
Active population
Individuals alive and currently registered with active records in a data source. 
For example, an active population for administrative healthcare data refers to 
the collection of patients for which there is an active record, i.e. the record was 
created and not closed because the patient moved or died.
Catalogue
A collection of dataset descriptions, which is arranged in a systematic manner 
and consists of a user-oriented public part, where information concerning 
individual dataset parameters is accessible by electronic means through an 
online portal.
Common data 
model (CDM)
Common structure and format for data that allows for interoperability, e.g. the 
efficient execution of the same analysis code against different local database for 
an efficient execution of programs against local data.
Contributor
An institution that contributes content to the Catalogues.
Data 
characterisation
The summarisation of features of a data source, including quantitative 
measures.
Data holder
Any natural or legal person, which is an entity or a body in the health or care 
sector, or performing research in relation to these sectors, as well as Union 
institutions, bodies, offices and agencies who has the right or obligation, in 
accordance with the Proposal for a Regulation of the European Parliament and 
of the Council on the European Health Data Space [18], applicable Union law or 
national legislation implementing Union law, or in the case of non-personal 
data, through control of the technical design of a product and related services, 
the ability to make available, including to register, provide, restrict access or 
exchange certain data.
Data quality
Data quality is defined as fitness for purpose for users’ needs in relation to 
health research, policy making, and regulation and that the data reflect the 
reality, which they aim to represent. Data quality is relative to the research 
question and does not address the question on what level is the quality 
measured e.g., variable, data source or institutional level. These aspects are 
addressed in the data quality determinants and dimensions of data quality.

## Page 16 (Section: Glossary)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 16/17
Data Quality 
Framework
A Data Quality Framework provides a set of definitions, guidelines, and 
recommendation to assess and govern data quality. The framework here 
presented addresses a wide range of data sources for the purpose of 
characterising, assessing, and assuring data quality for regulatory decision 
making.
Dataset
A structured collection of electronic health data
Data source
Dataset (or a set of linked datasets) sustained by a specified organisation, 
which is the data holder. The data source is characterised by the underlying 
population that can potentially contribute records to it, the event occurring that 
triggers the creation of a record in the data source, and the data model used in 
the data source.
Data user
A natural or legal person who has lawful access to personal or non-personal 
electronic health data for secondary use.
Elements 
“Elements” is used to refer to metadata elements, while “variables” is used to 
refer to the variables present within a data source.
Extract, 
transform, load 
(ETL)
 A data integration process that involves combining and/or ingesting data from 
the original source(s) (extraction), integrating into a format suitable for analysis 
(transformation), and making available on a target system(s) for final analysis 
and computation (loading). In the context of the EMA-HMA catalogues of data 
sources and non-interventional studies, ETL refers in particular to a repeatable 
process for converting data from one format to another, such as from a source 
native format to a common data model format. In this process, mappings to the 
standardised dictionary may be added. It is typically implemented as a set of 
automated scripts.
FAIR principles
Findable, accessible, interoperable, and reusable principles [5].
Institution
An organisation connected to one or more data sources - such as a data holder, 
or a research organisation running a study.
Metadata
Metadata are defined as “data about data” providing context about their 
purpose and generation. It’s a set of data that describes and gives information 
on other data providing context about their purpose, location, key-variables, 
generation, format, and ownership of a dataset. Metadata are often published in 
data catalogues, which have the purpose of allowing data to be discoverable 
and checked for fitness for purpose, without revealing the data themselves.
Underlying 
population
The population of individuals in one or more geographical locations who can 
potentially contribute information to a data source. This is a population defined 
by an administrative characteristic, a disease, a medical condition or any other 
relevant characteristic.
Vocabulary
Standardised medical terminologies; may be an international standard (e.g., 
International Classification of Diseases, Anatomical Therapeutic Chemical) or a 
country/region-specific system or modification.

## Page 17 (Section: References)

Good Practice Guide for the use of the HMA-EMA Catalogues of real-world data sources 
and studies 
EMA/787647/2022
Page 17/17
References
1.
Data Quality Framework for EU medicines regulation: application to Real-World Data. [Draft] 
EMA/503781/2024. Available at: https://www.ema.europa.eu/en/documents/other/draft-data-
quality-framework-eu-medicines-regulation-application-real-world-data_en.pdf.
2.
Real-world evidence framework to support EU regulatory decision-making. Report on the 
experience gained with regulator-led studies from September 2021 to February 2023. Available 
at: https://www.ema.europa.eu/en/documents/report/real-world-evidence-framework-
support-eu-regulatory-decision-making-report-experience-gained-regulator-led-studies-
september-2021-february-2023_en.pdf.
3.
Data Quality Framework for EU medicines regulation. EMA/326985/2023. Available at: 
https://www.ema.europa.eu/en/documents/regulatory-procedural-guideline/data-quality-
framework-eu-medicines-regulation_en.pdf.
4.
MINERVA: Strengthening Use of Real-World Data in Medicines Development: Metadata for Data 
Discoverability and Study Replicability (2022). 
https://www.encepp.eu/encepp/viewResource.htm?id=45375.
5.
Wilkinson, M.D., et al., The FAIR Guiding Principles for scientific data management and 
stewardship. Sci Data, 2016. 3: p. 160018.
6.
Guideline on registry-based studies. EMA/426390/2021. Available at: 
https://www.ema.europa.eu/en/documents/scientific-guideline/guideline-registry-based-
studies_en.pdf.
7.
HMA/EMA. List of metadata for Real World Data catalogues (2022). Available at: 
https://www.ema.europa.eu/en/documents/other/list-metadata-real-world-data-
catalogues_en.pdf.
8.
Oh, S.W., et al., Data Quality Assessment for Observational Medical Outcomes Partnership 
Common Data Model of Multi-Center. Stud Health Technol Inform, 2023. 302: p. 322-326.
9.
Gatto, N.M., et al., The Structured Process to Identify Fit-For-Purpose Data: A Data Feasibility 
Assessment Framework. Clin Pharmacol Ther, 2022. 111(1): p. 122-134.
10.
The European Network of Centres for Pharmacoepidemiology and Pharmacovigilance (ENCePP). 
Guide on Methodological Standards in Pharmacoepidemiology (Revision 11). EMA/95098/2010. 
https://www.encepp.eu/standards_and_guidances/documents/01.ENCePPMethodsGuideRev.11
.pdf.
11.
Hernán, M.A., et al., Observational studies analyzed like randomized experiments: an 
application to postmenopausal hormone therapy and coronary heart disease. Epidemiology, 
2008. 19(6): p. 766-79.
12.
Hernán, M.A. and J.M. Robins, Using Big Data to Emulate a Target Trial When a Randomized 
Trial Is Not Available. Am J Epidemiol, 2016. 183(8): p. 758-64.
13.
Brown, P., et al., How to formulate research recommendations. BMJ, 2006. 333(7572): p. 
804-6.
14.
Wang, S.V., et al., HARmonized Protocol Template to Enhance Reproducibility of hypothesis 
evaluating real-world evidence studies on treatment effects: A good practices report of a joint 
ISPE/ISPOR task force. Pharmacoepidemiol Drug Saf, 2023. 32(1): p. 44-55.
15.
TEHDAS. European Health Data Space Data Quality Framework (2022). Available at: 
https://tehdas.eu/app/uploads/2022/05/tehdas-european-health-data-space-data-quality-
framework-2022-05-18.pdf.
16.
Wang, S.V. and S. Schneeweiss, Assessing and Interpreting Real-World Evidence Studies: 
Introductory Points for New Reviewers. Clin Pharmacol Ther, 2022. 111(1): p. 145-149.
17.
Reflection paper on use of real-world data in non-interventional studies to generate real-world 
evidence. [Draft] EMA/CHMP/150527/2024. Available at: 
https://www.ema.europa.eu/en/documents/scientific-guideline/reflection-paper-use-real-
world-data-non-interventional-studies-generate-real-world-evidence_en.pdf.
18.
Proposal for a Regulation of the European Parliment and of the council on the European Health 
Data Space, COM(2022) 197 final, 2022/0140 (COD). Available at: https://eur-
lex.europa.eu/resource.html?uri=cellar:dbfd8974-cb79-11ec-b6f4-
01aa75ed71a1.0001.02/DOC_1&format=PDF.
