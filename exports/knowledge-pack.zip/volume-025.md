# Benchmarking Real-World Applicability of Molecular Generative Models from De novo Design to Lead Optimization with MolGenBench

- **Authors:** Duanhua Cao, Zhehuan Fan, Jie Yu, Mingan Chen, Xinyu Jiang, Xia Sheng, Xingyou Wang, Chuanlong Zeng, Xiaomin Luo, Dan Teng, Mingyue Zheng
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2025-11-04
- **DOI:** 10.1101/2025.11.03.686215
- **Source:** https://doi.org/10.1101/2025.11.03.686215
- **Licence:** CC-BY-NC-ND-4.0

## Section: Abstract

ABSTRACT Structure-based drug design (SBDD) has been profoundly reshaped by the advent of deep generative models, yet their practical impact on drug discovery remains limited. A central issue is the absence of a rigorous, application-oriented benchmark that mirrors the multi-stage, target-aware workflows of real-world pharmaceutical development. Inspired by recent advances in benchmarking for computer vision and large language models, where systematic evaluation has catalysed rapid progress, we introduce MolGenBench, a comprehensive benchmark designed to close the gap between molecular generation algorithms and tangible drug discovery outcomes. MolGenBench integrates a structurally diverse, large-scale dataset spanning 120 protein targets, 5,433 chemical series comprising 220,005 experimentally confirmed active molecules. Beyond conventional de novo generation, it incorporates a dedicated hit-to-lead (H2L) optimization scenario, which represents a critical phase in hit optimization that is seldom evaluated in existing benchmarks. We further introduce novel, pharmaceutically grounded metrics that assess a model’s ability to both rediscover target-specific actives or progressively optimize compounds for potency. Through extensive evaluation, MolGenBench uncovers significant gaps between current generative models and the demands of real-world drug development, establishing a foundational resource for building generative models with enhanced practical impact and accelerated translational potential.


---

# Integrated Genetic, Molecular, and Wearable Sensor Biomarkers Enable Bayesian Machine Learning-Driven Precision Stratification in Parkinson’s Disease: A Comprehensive Multi-Cohort Validation Study

- **Authors:** Harsh Milind Tirhekar, Priyanshi Yadav, Chandrajit Bajaj
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2025-12-04
- **DOI:** 10.64898/2025.12.02.25340302
- **Source:** https://doi.org/10.64898/2025.12.02.25340302
- **Licence:** CC0-1.0

## Section: Abstract

Abstract We present a Bayesian machine learning framework integrating genetic, molecular, and wearable sensor biomarkers for precision medicine in Parkinson’s disease. Using PPMI (4,775 patients, 14,473 longitudinal records) and LRRK2 Consortium (627 individuals, 2,958 biological specimens), we demonstrate: (1) LRRK2 G2019S confers 1.92-fold PD risk (individual-level χ 2 = 36.6, p = 1.4 × 10 − 9 ; sex-adjusted OR=2.73) with carriers exhibiting 4.35-point higher motor severity (95% CI [1.95, 6.47], rank-biserial r = −0.270); (2) Wearable IMU sensors quantified Arm Swing Asymmetry (27% prevalence, n = 178) and Dual-Task Cost (14.87% degradation, t = 14.98, p &lt; 0.001), enabling continuous cognitive-motor network monitoring; (3) Molecular markers phospho-LRRK2 ( n = 884) and CSF ε -synuclein seed amplification ( n = 145) provide therapeutic monitoring and differential diagnosis; (4) Prodromal screening identified olfactory dysfunction (50.2%, n = 5, 122) and RBD (37.5%, n = 1, 548). Bayesian clustering via Evidence Lower Bound selection achieved Silhouette=0.535 with bootstrap stability (Jaccard=0.769), outperforming alternatives (0.170–0.452). Risk prediction model: AUC=0.717, calibration slope=1.197. This reproducible framework (complete code-result traceability, TRIPOD+AI compliant) enables mechanism-targeted precision medicine aligned with SDGs 3, 9, 10.


---

# Interdisciplinary Study on Drug-Induced-Phospholipidosis of Repurposing Libraries through Machine Learning and Experimental Evaluation in Different Cell Lines

- **Authors:** Maria Kuzikov, Adelinn Kalman, Jeanette Reinshagen, Johanna Huchting, Kun Qian, Hanna Axelsson, Paeivi Oestling, Brinton Seashore-Ludlow, Yojana Gadiya, Philip Gribbon, Andrea Zaliani
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2025-07-09
- **DOI:** 10.1101/2025.07.08.663638
- **Source:** https://doi.org/10.1101/2025.07.08.663638
- **Licence:** CC-BY-NC-ND-4.0

## Section: Abstract

Phospholipidosis (PLD), a cellular adverse effect that is, among others, caused by numerous cationic amphiphilic drugs. Interest is raised within pharma discovery to predict this phenomenon, as it can impact the outcome of phenotypic cellular screens and significantly delay drug development processes. The development of accurate and validated machine learning models for predicting drug-induced PLD across different cell lines and research centers could provide a valuable early application tool for the pharmaceutical industry, potentially accelerating drug discovery and reducing the risk of late-stage failures. We report here the assembly, curation, testing and modeling of one of the largest datasets of repurposed drugs (5K+) tested for PLD induction on different cell lines. A machine-learning classification method was developed and validated to predict whether molecules are prone to induce PLD effects when applied in cell-based screens


---

# SynVerse: A Framework for Systematic Evaluation of Deep Learning Based Drug Synergy Prediction Models

- **Authors:** Nure Tasnina, Maryam Haghani, T. M. Murali
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2025-05-01
- **DOI:** 10.1101/2025.04.30.651516
- **Source:** https://doi.org/10.1101/2025.04.30.651516
- **Licence:** CC-BY-4.0

## Section: Abstract

Abstract Synergistic drug combinations are often used to treat cancer. Experimental exploration of all possibilities is expensive. Deep learning (DL) for predicting the synergy of drug pairs in specific cell lines might provide an alternative. However, current approaches often suffer from data leakage. They also lack systematic ablation studies. To address these gaps, we propose SynVerse, a comprehensive evaluation framework featuring four data-splitting strategies to assess DL model generalizability and three ablation studies: module-based, feature shuffling, and a novel network-based approach to disentangle factors influencing model performance. We evaluated sixteen models incorporating eight drug- and cell line-specific features, five preprocessing techniques, and two widely used encoders. Our analysis revealed several insights. None of the models outperformed a naive baseline using one-hot encoding as features. Biologically meaningful drug or cell line features and drug–drug interactions were not the drivers of predictive performance. All models demonstrated poor generalization to unseen drugs and cell lines. SynVerse emphasizes the need for substantial improvements before computational predictors can reliably support experimental and clinical settings.


---

# MDCG 2025-6 / AIB 2025-1: FAQ on the interplay between the MDR/IVDR and the AI Act

- **Issuer:** European Commission
- **Type:** Q&A
- **Published:** 2025-06-19
- **Language:** en
- **Source:** https://health.ec.europa.eu/document/download/b78a17d7-e3cd-4943-851d-e02a2f22bbb4_en?filename=mdcg_2025-6_en.pdf
- **Licence:** EU-reuse

## Page 1

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 1 of 27 
 
 
 
 
 
 
AIB 2025-1 
MDCG  2025-6  
Interplay between the Medical   Devices 
Regulation (MDR) & In vitro Diagnostic 
Medical Devices Regulation (IVDR) and 
the Artificial Intelligence Act (AIA) 
 
 
 
 
 
 
 
 
         
 
June 2025 
 
 
This document has been endorsed by the Artificial Intelligence Board (AIB) and the 
Medical Device Coordination Group (MDCG) established by Article 65 of Regulation 
(EU) 2024/1689 and Article 103 of Regulation (EU) 2017/745. Both groups are 
composed of representatives of all Member States and are chaired by a 
representative of the European Commission MDCG and a Member State (AIB). 
The document is not a European Commission document and it cannot be regarded 
as reflecting the official position of the European Commission. Any views expressed 
in this document are not legally binding and only the Court of Justice of the European 
Union can give binding interpretations of Union law.

## Page 2

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 2 of 27 
 
 
Interplay between the Medical Devices Regulation 
(MDR)1 & In vitro Diagnostic Medical Devices 
Regulation (IVDR)2 and the Artificial Intelligence Act 
(AIA)3 
Introduction 
This document provides a first set of answers, that will be continuously developed 
and updated, to the most frequently asked questions related to the joint application of 
the AIA and the MDR or IVDR4 for manufacturers. This Frequently Asked Questions 
(FAQ) document is primarily aimed at (but not limited to) medical device 
manufacturers, notified bodies and competent authorities. All references to 
‘manufacturer’ within the meaning of the MDR/IVDR should be understood as 
references to ‘provider’ in accordance with the AIA.  ‘Deployer’ defined in the Article 
3(4) AIA as a natural or legal person, public authority, agency or other body using AI 
systems under their authority, unless the use is for a personal non-professional 
activity.  The AIA does not define the concept of ‘user’ which is defined in the 
MDR/IVDR as any healthcare professional or lay person who uses a device. 
Therefore, the concept of ‘deployer’ under AIA cannot be understood as referring to 
‘user’ under MDR/IVDR. 
The MDR and IVDR requirements address risks related to medical device software, 
however, they do not explicitly address risks specific to AI systems. The AIA 
complements the MDR/IVDR by introducing requirements to address hazards and 
risks for health, safety and fundamental rights specific to AI systems. In line with the 
New 
Legislative 
Framework 
approach, 
this 
means 
a 
simultaneous 
and 
complementary application of the MDR/IVDR and the AIA for medical devices that 
contains one or more high-risk AI system. 
For the purposes of this document, AI systems used for medical purposes are 
referred to as Medical Device Artificial Intelligence (MDAI). All references to MDAI 
shall be understood to also cover MDR Annex XVI products, accessories to medical 
devices, in vitro diagnostic medical devices and accessories to in vitro diagnostic 
medical devices.   
 
1 Regulation (EU) 2017/745 of the European Parliament and of the Council of 5 April 2017 on medical devices 
2 Regulation (EU) 2017/746 of the European Parliament and of the Council of 5 April 2017 on in vitro diagnostic 
medical devices 
3 Regulation (EU) 2024/1689 of the European Parliament and of the Council of 13 June 2024 laying down 
harmonised rules on artificial intelligence  
4 On the basis of the New Legislative Framework, as clarified in the Commission notice ‘The “Blue Guide” on the 
implementation of EU product rules 2022’,  the general rule is that more than one legal act of Union harmonisation 
legislation, such as the MDR and the IVDR and the AIA , may be applicable to one product, since the making 
available or putting into service can take place only when the product complies with all applicable Union 
harmonisation legislation.

## Page 3

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 3 of 27 
 
The guidance provided in this document is without prejudice to the guidance that the 
European Commission may adopt on the basis of the AIA.  
In order to ensure consistency, avoid duplication and minimise additional burdens, 
manufacturers of MDAI, in accordance with paragraph 2 of Article 8 of the AIA, have 
a choice of   integrating, as appropriate, the necessary testing and reporting 
processes, information and documentation they provide with regard to their MDAI into 
documentation and procedures that already established under the MDR/IVDR. 
Manufacturers of MDAI, are strongly encouraged to use this flexibility provided in 
paragraph 2 Article 8 of the AIA. In applying this flexibility, MDAI manufacturers, 
however, shall ensure that MDAI are fully compliant with all applicable requirements 
of the AIA, MDR or IVDR and any other applicable Union legislation.

## Page 4

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 4 of 27 
 
Contents 
 
I. 
Scope of application and classification .............................................. 5 
II. Requirements .................................................................................... 7 
1. Management Systems ................................................................... 7 
2. Data Governance ........................................................................... 9 
3. Technical Documentation ............................................................. 12 
4. Transparency and human oversight ............................................. 13 
5. Accuracy, Robustness and Cybersecurity .................................... 18 
III. 
Clinical /Performance Evaluation and Testing .............................. 20 
IV. 
Conformity assessment ................................................................ 22 
V. Substantial Modification/significant change ..................................... 23 
VI. 
Post-market monitoring ................................................................ 25 
VII. Other questions ............................................................................ 26

## Page 5

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 5 of 27 
 
I. 
Scope of application and classification 
1.  When does the AIA apply to the ‘medical device software’?  
According to MDCG 2019-115, "medical device software" (MDSW) refers to software 
intended, either alone or in combination, to fulfil a medical purpose as defined in 
Article 2(1) MDR or Article 2(2) IVDR. The AI Act (AIA) defines an AI system in Article 
3(1) as a machine-based system that is designed to operate with varying levels of 
autonomy and that may exhibit adaptiveness after deployment, and that, for explicit 
or implicit objectives, infers, from the input it receives, how to generate outputs such 
as predictions, content, recommendations, or decisions that can influence physical or 
virtual environments.6 
Note 1: all references to Medical Device Artificial Intelligence (MDAI) shall be 
understood to also cover MDR Annex XVI products, accessories to medical devices, 
in vitro diagnostic medical devices and accessories to in vitro diagnostic medical 
devices.   
Note 2: Refer to MDCG 2019-11 for further details on the qualification and 
classification of software, including the distinction between MD and IVD software and 
on the definition of an AI system to the Commission Guidance on the AI system 
definition7. 
2.  Under what conditions is a MDAI considered a high-risk AI system within 
the meaning of the AIA?  
A MDAI is considered a high-risk AI system under Article 6(1) AIA if it meets both of 
the following conditions:  
1. the MDAI is a safety component8 9 ,or the AI system is itself a medical 
device and   
2. the MDAI is subject to a third-party conformity assessment by a notified 
body in accordance with the MDR/IVDR (See table 1 below). 
 
 
 
 
5 MDCG 2019-11: Guidance on Software Qualification and Classification.  
6 Commission Guidelines on the definition of an artificial intelligence system established by Regulation (EU) 
2024/1689 (AIA).  
7 Commission Guidelines on the definition of an artificial intelligence system established by Regulation (EU) 
2024/1689 (AI Act), C(2025) 924 final.  
8 AIA Art 3(14) defines safety component as ‘a component of a product or of an AI system which fulfils a safety 
function for that product or AI system, or the failure or malfunctioning of which endangers the health and safety of 
persons or property’. European Commission is preparing horizontal guidelines on the classification of AI systems 
as high-risk that will also cover the concept of ‘safety component’. 
9 As regards AI systems that are safety components of products, or which are themselves products, falling within 
the scope of [MDR or IVDR], it is appropriate to classify them as high-risk under the AIA if the product concerned 
undergoes the conformity assessment procedure with a third-party conformity assessment body pursuant to the 
[MDR or IVDR].

## Page 6

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 6 of 27 
 
 
Classification 
Notified 
Body 
Involved? 
AIA High-Risk (Art. 
6(1)) 
conditions 
fulfilled? 
MDR Class I (non-sterile, non-measuring, non-
reusable surgical) 
 
 No 
 
 No 
MDR Class I (sterile, measuring, reusable 
surgical) 
 
 Yes 
 
 Yes 
MDR Class IIa, IIb, III 
 
 Yes 
 
 Yes 
MDR Annex XVI10 
 
 Yes 
 
 Yes 
IVDR Class A (non-sterile) 
 
 No 
 
 No 
IVDR Class A) 
 
 Yes 
 
 Yes 
IVDR Class B, C, D 
 
 Yes 
 
 Yes 
In-house 
device 
according 
to 
Art. 
5(5) 
MDR/IVDR 
 
 No 
 
 No 
Table 1: Non-exhaustive list of AIA Article 6(1) application to MDR/IVDR 
3. When do provisions on high-risk AI systems apply to MDR Annex XVI 
devices? 
The AIA applies to devices covered by the MDR and therefore also applies to an 
Annex XVI device if it is or it contains an AI system and fulfils the conditions of Article 
6(1) AIA (refer back to Q2). 
4. Does the AIA impact the risk classification of MDAI under the MDR/IVDR? 
The classification of an AI system as a high-risk under Article 6(1) AIA does not imply 
that the medical device or in vitro diagnostic medical device falls in a higher risk class 
under the MDR and IVDR.11 Therefore, the AIA does not impact the risk classification 
of medical devices or in vitro diagnostic medical devices (IVDs) under the MDR or 
IVDR.  
It is rather the classification of a medical device under the MDR/IVDR which 
determines whether the AI system qualifies as high-risk under Article 6(1) AIA (refer 
back to Q2). The classification of MDAI under the MDR or IVDR determines the 
applicable legal requirements for high-risk AI systems under Article 6(1) AIA and 
therefore impacting the regulatory scrutiny and oversight required for the high-risk 
MDAI.  
The application of Article 5 AIA, prohibited AI practices and Article 50 AIA 
transparency obligations for providers and deployers of certain AI systems does not 
depend on the MDR/IVDR classification.12 
 
 
10 Note: Except for non-invasive devices which are classified as Class I in accordance with ‘Guidance on 
qualification and classification of Annex XVI products - A guide for manufacturers and notified bodies’. 
11 Recital 51 AIA. 
12 Commission Guidelines on prohibited artificial intelligence practices established by Regulation (EU) 2024/1689 
(AI Act), C(2025) 884 final.

## Page 7

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 7 of 27 
 
 
II. Requirements  
1. Management Systems 
5. How do the MDR/IVDR and AIA address the lifecycle management for MDAI? 
The MDR and IVDR require manufacturers to manage the entire lifecycle of MDAI, 
ensuring that the MDAI remains safe and performant throughout its use.13  
The AIA reinforces this by also expecting continuous review, oversight, and 
consistent performance of high-risk MDAI throughout the lifecycle14 and post-market 
monitoring that is proportionate to the nature and risks of the AI system15.  
This includes design choices allowing natural persons to oversee functioning of high-
risk MDAI and to ensure that they are used as intended and that their impacts are 
addressed over the system’s lifecycle,16 a risk management system that shall be 
understood as a continuous iterative process planned and run through the entire 
lifecycle of a high-risk AI system, requiring regular systematic review and updating,  
analysing data provided by deployers or collected through other sources on the 
performance of the high-risk MDAI in its lifetime to assess continued compliance.  
This may include activities such as high-risk MDAI design, development, testing, 
deployment, monitoring, and updates, along with comprehensive documentation of 
all relevant changes and their impacts.  
For high-risk MDAI that continues to learn after being deployed the post-market 
monitoring system is key to ensuring continued performance and compliance. It helps 
identify and address emerging risks in a timely and efficient manner and ensures that 
updates are communicated to relevant parties, including patients or professional 
users (as applicable), deployers and notified bodies, as necessary.17  
6. How do the MDR, IVDR and the AIA address the implementation of a quality 
management system?  
Jointly, the AIA and MDR or IVDR emphasize the importance of quality management 
to ensure the safety and performance of MDAI. The MDR and IVDR require 
manufacturers to establish, document, implement, maintain, keep up to date and 
continually improve a quality management system to ensure compliance with the 
MDR and IVDR in the most effective manner and in a manner that is proportionate to 
the risk class and the type of the device.   
 
13 e. g. Art. 10, Chapter VI, Chapter VII Annex I, Annex II, Annex IX, Annex X, Annex XIV. 
14 Article 9 para 2, Article 15, par. 1 AIA 
15 Article 72, par. 1, AIA 
16 Article 14 and recital 73 AIA 
17 AIA Recital 155, Article 15(4), Article 9, 11, 15, Annex IV.

## Page 8

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 8 of 27 
 
Similarly, the AIA mandates that providers/ manufacturers implement quality 
management systems for AI systems to ensure compliance with the AIA.18 The 
quality management system required under the AIA covers substantive requirements, 
procedural obligations and at least thirteen aspects, to be implemented in a 
proportionate manner according to the size of the provider’s organization. Similar to 
the MDR / IVDR, this includes a strategy for regulatory compliance, the 
documentation of a quality management system, which should encompass written 
policies, procedures, and instructions regarding aspects such as risk management 
and performance testing.19  
The quality management system obligations under the AIA are specifically targeted to 
the AI system. Therefore, the AIA requirements are complementary to the quality 
management system required under the MDR or IVDR and applicable to the overall 
MDAI. As the quality management system obligations under the AIA are specifically 
targeted to the AI system, additional requirements such as data and data 
governance, record-keeping, transparency, human oversight must be integrated, as 
appropriate (non-exhaustive).20   
To ensure this complementarity and to avoid unnecessary administrative burden, 
manufacturers of AI systems may include the elements of the quality management 
system provided by the AIA as part of the existing quality management system 
provided by the MDR and IVDR.21   
In addition, the development of harmonised European and international standards 
relevant to quality management systems for high-risk MDAI is ongoing, including 
under the framework of the AIA and MDR/IVDR, to support consistent implementation 
and compliance across manufacturers. 
7. What risk management requirements are outlined in the MDR, IVDR and AIA 
for high-risk MDAI? 
The MDR, IVDR and AIA require a risk management system that is a continuous 
iterative process throughout the entire lifecycle of the device, including in both the 
pre-market and post-market phases.22 The process primarily aims at identifying and 
mitigating risks on health, safety and fundamental rights.23  
Risk management requirements specific to high-risk MDAI include ongoing 
assessments of known and reasonably foreseeable risks that the high-risk MDAI can 
pose to fundamental rights, data biases, and system robustness, including 
identification, analysis, and mitigation of risks related to system design, development, 
and deployment, and may include training to deployers. This includes measures to 
ensure the safety and reliability of high-risk MDAI in healthcare settings through 
 
18 Article 17 
19 AIA, Article 17 
20 Refer to Section 2 Chapter III) 
21 Recital 81, Article 8 (2) and Article 17 (3) AIA  
22 Annex I Chapter MDR or IVDR  
23 Article 9 AIA

## Page 9

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 9 of 27 
 
comprehensive risk assessments, documentation of risk mitigation measures, and 
continuous monitoring of system performance.24 These requirements aim to prevent, 
and address known and reasonably foreseeable risks to ensure the safety and 
performance of MDAIs.  
Manufacturers of high-risk MDAI may integrate the additional risk management 
requirements specific to MDAI set out in paragraphs 1-9 of Article 9 of the AIA into the 
testing, reporting processes, information and documentation required under the AIA 
into their existing documentation and procedures under the MDR and IVDR.25 Risk 
management systems under both AIA and MDR/IVDR require a manufacturer to 
reduce the identified and assessed risks, and to address risks in their risk 
management systems that can reasonably be mitigated.  This refers not only to 
organisational measures, but also to specific actions taken during the development 
and design of MDAI.  
2. Data Governance 
8. What data governance requirements are specified in the AIA, MDR and IVDR 
for high-risk MDAI? 
Data is addressed in both the AIA and the MDR/IVDR, though with a different scope 
and focus. 
The MDR/IVDR mandate that clinical data used for device evaluation is robust, 
reliable, and derived from well-designed studies. To support the generation of 
sufficient clinical evidence, the clinical or performance evaluation must be based on 
clinical data representative of the intended use of the device. The procedures and 
techniques for verifying, validating and controlling the design of the devices as well 
as documented information arising from those procedures and techniques, should be 
documented as part of the clinical evidence (and reviewed by the notified body).  
Article 10 AIA provides further specifications related to the data and datasets of AI 
systems. Moreover, it includes a provision for exceptional processing of special 
categories of personal data.26 These requirements aim to ensure that high-risk MDAI 
is built and validated on trustworthy data.  
To ensure that MDAI performs as intended and safely, high-quality data plays a 
central role in providing structure and in ensuring performance, especially for the 
development of high-risk MDAI-based on machine learning techniques. High-quality 
data sets for training, validation and testing of MDAI require the implementation of 
appropriate data governance and management practices. The data governance and 
management practices, in the case of personal data, should be fully compliant with 
the GDPR provisions and include transparency about the original purpose of the data 
collection. The requirements related to data governance can be complied with by 
 
24 AIA, Article 72 
25 Recital 64 AIA 
26 Article 10(5) AIA

## Page 10

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 10 of 27 
 
having recourse to third parties that offer certified compliance services including 
verification of data governance.27 
To ensure comprehensive data governance practices for MDAIs, datasets for training, 
validation, and testing must be relevant, sufficiently representative, and, to the best 
extent possible, free of errors and complete.28 When training, validating and testing 
high-risk MDAI, manufacturers must ensure that the datasets are sufficiently 
representative of the target population, and in relation to the performance study 
population specifications on selection criteria and decisions related to the size of the 
performance study population are defined.29 Manufacturers must implement 
procedures ensuring data transparency and integrity and examine the data in view of 
possible biases, with detailed documentation of compliance. For further information 
on generation on clinical evaluation (MDR) / performance evaluation (IVDR) of 
MDSW, see MDCG 2020-1. 
9. What requirements are in place under the AIA, MDR and IVDR to ensure 
monitoring and mitigation of unwanted bias in MDAI? 
The AIA requires high-risk MDAI manufacturers to implement data governance and 
management practices appropriate for the claimed intended purpose, including with a 
view of possible biases that are likely to affect the health and safety of persons, have 
a negative impact on fundamental rights or lead to discrimination prohibited under 
Union law, especially where data outputs influence inputs for future operations  
Furthermore, manufacturers must implement appropriate measures to detect, prevent 
and mitigate possible biases identified.  
In addition, the AIA introduces requirements on record keeping arising from logging 
capabilities implemented for high-risk MDAI, which aim to facilitate the traceability, 
such as identification of situations whereby an MDAI may present a risk due to 
potential bias in the training, validation or testing data sets in the initial system 
development or as a result of substantial modification.  The AIA, as one of the 
essential requirements, requires all high-risk MDAI to have technical capabilities for 
the automatic recording of events (logs) over the lifetime of the MDAI.  
The record-keeping and logging requirements under the AIA also involve sufficiently 
representative datasets analysing relevant data provided by the deployers.  The MDR 
and IVDR complements this by requiring that clinical data used in device evaluation 
be robust and reliable, ensuring that high-risk MDAI perform consistently across the 
intended use population.  Documentation of these activities and their effectiveness is 
required by all three regulations (refer to Section 3 for more on technical 
documentation). 
 
27 Recital 67 AIA 
28 AIA Article 10, recital 67 
29 see IVDR Annex XIII part 2.3.2 (m); Article 10 para 3 AIA

## Page 11

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 11 of 27 
 
Furthermore, the requirements for appropriate record keeping include logging 
capabilities as part of post-market monitoring.  The aim is to ensure that 
manufacturers put in place appropriate mechanisms to detect possible bias not 
originally detected in pre-market activities but rather as a result post-market 
monitoring or learning. 
10. How does the AIA define different types of data required to demonstrate 
compliance of the AI system?  
The AIA introduces four definitions related to data that include:  
Article 3 (29) AIA defines ‘training data’ as data used for training an AI system 
through fitting its learnable parameters;  
Article 3 (30) AIA ‘validation data’ means data used for providing an evaluation of the 
trained AI system and for tuning its non-learnable parameters and its learning 
process in order, inter alia, to prevent underfitting or overfitting;  
Article 3 (31) AIA ‘validation data set’ means a separate data set or part of the 
training data set, either as a fixed or variable split;  
Article 3 (32) AIA ‘testing data’ means data used for providing an independent 
evaluation of the AI system in order to confirm the expected performance of that 
system before its placing on the market or putting into service.  
11. How do the MDR, IVDR and AIA address training, validation and testing data 
used for high-risk MDAI? 
The importance of utilising data which is appropriate for the intended purpose of the 
MDAI is essential in order to produce accurate and (clinically) relevant outputs. In 
accordance with the claimed intended purpose of the device. The training data used 
must be representative of the intended patient population.30  
The MDR and IVDR require that clinical data used for device evaluation is robust, 
reliable, and derived from well-designed studies.31  Data collection protocols aim to 
ensure that the relevant characteristics of the intended patient population (for 
example, in terms of age, gender, sex, race, ethnicity, geographical location, medical 
condition), intended use environment, and measurement inputs are sufficiently 
represented in a sample of adequate size in the datasets for training, validation, 
testing, and monitoring so that results can be reasonably generalized to the targeted 
population. These are fundamental for clinical / performance evaluations and 
important to manage any unintended bias or dataset drift, promote appropriate and 
generalizable performance across the intended patient population, assess usability, 
 
30 Annex II TD section 3, a and b and section 6 on product verification and validation MDR and IVDR 
31 MDR, Art. 57 (3)).). Annex XIV - MDCG 2020-1 Guidance on clinical evaluation (MDR) / Performance 
evaluation (IVDR) of medical device software).

## Page 12

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 12 of 27 
 
and identify circumstances and subgroups where the model may underperform 
including over time. 
Manufacturers should employ stringent data governance practices to maintain data 
integrity and prevent unwanted bias.32 In addition, the validation of training data used 
MDAI is paramount and should be demonstrated as part of the studies to ensure the 
accuracy, reliability, and effectiveness of the MDAI. 
As outlined in the AIA, training, validation and testing data sets for high-risk MDAI 
must be of high quality, sufficiently representative, free of errors (to the best extent 
possible), complete in the view of the intended purpose , include the appropriate 
statistical properties and be examined in view of possible biases that are likely to 
affect the health and safety of persons, have negative impact on fundamental rights 
ore lead to discrimination prohibited under Union law.33 The AIA also requires the 
inclusion of measures to address data privacy and security concerns, as well as 
transparency in data collection and processing.   
Note: In line with the AI Act the Commission will develop horizontal guidelines on the 
practical implementation of the requirements and obligations for high-risk AI systems 
including on the requirements included in Article 1034 on data and dataset.35 
Moreover, in line with the European Commission standardisation request 
CEN/CENELEC Joint Technical Committee 21 is working on the developing a 
harmonised standards on data and bias.   
The Commission horizontal guidelines and the harmonized standards in support of 
the AI Act will provide further clarifications on the scope of the requirements related to 
data and data governance of the AI Act. The specific application of AI act provisions 
on data and data governance in the context of medical devices will be developed 
following the adoption of horizontal guidelines.  
3. Technical Documentation  
12. What technical documentation is required by the MDR/IVDR and AIA for 
MDAI? 
The MDR, IVDR and the AIA mandate the provision of comprehensive technical 
documentation for MDAI. The MDR/IVDR require detailed descriptions of software, 
software architecture, data processing methods, and risk management strategies.36 
The AIA requires additional documentation, focusing on transparency and 
accountability, including risk assessments, data governance practices, and 
performance testing outcomes of the high-risk MDAI.37  
 
32 AIA, Article 10 
33 AIA, Article 10 
34 e.g. high quality, sufficiently representative, free of errors (to the best extent possible). 
35 e.g. principles related to separation of datasets.   
36 MDR and IVDR Annex II, MDR/IVDR Annex III 
37 AIA, Article 11 and 72

## Page 13

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 13 of 27 
 
This documentation should include detailed information about the device's design, 
development, key design choices, functionality, performance characteristics, system 
architecture, computational resources to develop, train and test, and intended use 
and purpose. Manufacturers must also provide evidence of conformity with relevant 
regulatory requirements, including training, validation and test data, risk 
assessments, and quality management processes.38 All three regulations aim to 
ensure that manufacturers maintain detailed and up-to-date records to demonstrate 
compliance.  
Note: Where it relates to technical documentation, Article 11 (2) of the AIA indicates 
that a single set of technical documentation shall be drawn up for high-risk MDAI. 
13. Will the assessment of the technical documentation by a notified body as it 
is defined in Annex VII of the AIA follow a sampling of MDR Class IIa / Class 
IIb and IVDR Class B / Class C devices as it is laid out in MDCG 2019-13?  
Yes, sampling rules of the governing conformity assessment procedure remain 
applicable. Therefore, high-risk MDAI are governed by the applicable sampling rules 
under the MDR and IVDR.  
Background: The MDR and IVDR establish the need to assess the technical 
documentation of at least one representative device per generic device group (for 
Class IIb and Class C) and for each category of devices (for Class IIa and Class B) 
prior to issuing a certificate.39 Section 2.3 and 3.4 of Annex IX of IVDR and MDR (and 
section 10 of Annex XI of the MDR) defines that the quality management system 
assessment must be accompanied by the assessment of technical documentation for 
devices selected on a representative basis. 
4. Transparency and human oversight 
14. What requirements do the AIA and MDR/IVDR impose regarding 
transparency and for MDAI? 
The AIA and MDR/IVDR put in place complementary obligations that address both 
manufacturers and deployers to ensure transparency in the development, 
deployment and use of MDAI. 
Under the AIA, transparency is a core requirement for high-risk MDAI. It introduces 
on providers a legally binding requirement to design and develop high-risk MDAI in 
such a way as to ensure that operation of high-risk MDAI is sufficiently transparent to 
enable deployers, to interpret outputs correctly and use the system appropriately, 
supported by clear and comprehensible instructions for use.40 
Furthermore,  manufacturers must ensure that high-risk MDAI intended to interact 
directly with natural persons are designed and developed in such a way that the 
 
38 MDR, Annex II; IVDR Annex II, AIA, Article 11).  
39 Article 52(4) and (6) MDR and Article 48(7) and (9) IVDR 
40 Article 13 AIA.

## Page 14

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 14 of 27 
 
concerned users of high-risk MDAI, regardless of risk class, are informed that they 
are interacting with an AI system unless this is obvious from the point of view of a 
user who is reasonably well-informed, observant and circumspect, taking into 
account the circumstances and the context of use.41,42 Additionally, it imposes 
transparency obligations on deployers, including the requirement to inform providers 
appropriately and ensure proper use of the system.43 
The MDR/IVDR embed transparency requirements within the General Safety and 
Performance Requirements (GSPRs).44 They require that manufacturers provide 
clear and accessible information regarding the device’s intended purpose, operation 
and limitations.45 In addition, they require that software development follows the state 
of the art, incorporating lifecycle and risk management processes that inherently 
support traceability, documentation, and usability.46 These elements contribute to 
transparency and the broader goal of ensuring that deployers and notified bodies can 
understand how the MDAI contributes to its performance and risk profile. In addition 
to Annex I, Annex II and III of the MDR/IVDR also impose detailed documentation 
requirements, including on software development and performance evaluation, which 
contribute to transparency and traceability throughout the device lifecycle.  
Accordingly, the MDR/IVDR and AIA collectively support a coherent regulatory 
framework that ensures MDAI systems are designed, documented, and deployed in a 
transparent and explainable manner. Therefore, transparency requirements are not 
optional design features, but essential requirements to be addressed within the 
manufacturer’s risk and quality management systems and verified through the 
conformity assessment procedure. These requirements collectively ensure that 
users, deployers, and patients are adequately informed about the nature, operation 
and limitations of MDAI.  
15. How do the MDR/IVDR and the AIA address transparency, explainability and 
data processing requirements for high-risk MDAI? 
The AIA provides that transparency, including the accompanying instructions for use, 
should assist deployers in the use of the system and support informed decision 
making by them.47 Deployers should, inter alia, be in a better position to make the 
correct choice of the system that they intend to use in light of the obligations 
applicable to them, be educated about the intended and precluded uses, and use the 
AI system correctly and as appropriate. This is further supported by requirements for 
clear and comprehensible instructions for use, the provision of information on the 
system’s capabilities and limitations, and documentation that enables the 
explainability of AI-based decisions.  
 
41 Further transparency requirements for certain AI systems are contained in AIA Article 50.  
42 Article 50 AIA. 
43 Article 26 AIA. 
44 Annex I MDR and IVDR. 
45 Annex I GSPR 23 MDR and IVDR. 
46 Annex I GSPR 14.2(h) MDR and IVDR. 
47 Articles 12 and 13 AIA, as clarified in recitals 71 and 72 AIA.

## Page 15

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 15 of 27 
 
Transparency requirements related to data processing include obligations regarding 
data quality, management, and documentation.48 Data used for training, validation 
and testing of high-risk MDAI must be relevant, representative of the intended 
purpose, free of errors and bias, (to the extent possible) and sufficiently 
comprehensive. These provisions aim to ensure the robustness and performance of 
high-risk MDAI but also their transparency in terms of data processing.  As explained 
in Question 11 above, the Commission will provide horizontal guidelines on the 
practical implementation of Article 10 AI act on data and data governance which will 
provide further clarifications on the meaning and practical application of this 
provision. This is aligned with MDR/IVDR which require manufacturers to ensure that 
users are provided with comprehensive and comprehensible information regarding 
the device, its performance and risks (Annex I). Where applicable, the information 
provided must describe how software, including AI components, contributes to the 
performance of the device, and must be reflected in the instructions for use or user 
interface. Furthermore, MDR/IVDR Annex I, Chapter III, also supports informed 
decision-making by users.  
In this sense, the AIA expands and reinforces the MDR and IVDRs foundational 
principle that information provided to deployers must be clear, complete, and 
actionable, especially when decisions may impact health outcomes or fundamental 
rights. Taken together, the MDR/IVDR and AIA establish a framework in which 
transparency and explainability are not only expectations but binding obligations for 
high-risk MDAI. Manufacturers must ensure that deployers can understand the logic, 
limitations, and behaviour of AI components within a medical device. This includes 
implementing safeguards, interpretation tools, and user interfaces that make AI 
outputs meaningful and trustworthy. The integration of these requirements throughout 
the high-risk MDAI lifecycle, design, documentation and record-keeping, labelling, 
and post-market surveillance ensures that MDAI is developed and deployed in a 
manner that supports patient safety, professional accountability, and public trust. 
16. How do the MDR/IVDR and the AIA address the accountability of MDAI? 
Accountability is addressed in both the AIA and the MDR/IVDR, though with a 
different scope and focus. 
The MDR/IVDR, include requirements for documentation and clinical and 
performance evaluation. They require that the information provided to users be clear 
and complete, including details on how the device operates and, where applicable, 
how embedded software components (including MDAI) contribute to device 
functionality.49 The documentation50 required must describe the design and 
functioning of the software, including how inputs are processed and how outputs are 
generated, thereby supporting explainability and accountability in practice. To 
promote trust and accountability, the AIA introduces explicit obligations concerning 
 
48 Article 10 AIA. 
49 Annex I MDR and IVDR. 
50 Annex II MDR and IVDR.

## Page 16

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 16 of 27 
 
transparency.51 Transparency contributes to explainability which in turn facilitates 
accountability.  
As such, high-risk MDAI must be designed and developed in a manner that enables 
deployers to understand how the system functions and reaches its outputs. This 
includes information on the characteristics, capabilities, and limitations of the high-
risk MDAI, as well as documentation to support interpretability of outputs.  
These combined obligations enable both developers and deployers of high-risk MDAI 
to demonstrate and communicate how high-risk MDAI-based decisions are made. 
Moreover, these obligations support robust traceability of changes, informed use, and 
post-market control mechanisms that reinforce the safe and trustworthy deployment 
of MDAI and enhance accountability throughout the product lifecycle. 
17. How do the MDR, IVDR and AIA address usability engineering for MDAI? 
The MDR and IVDR require manufacturers to apply usability engineering principles to 
MDAI in the design and development to ensure their safe and effective use by 
intended users. Manufacturers must eliminate or reduce as far as possible risks 
related to use errors, having particular regard to the knowledge of the user and 
consideration of whether training might be appropriate. It is recommended that AI 
systems, especially those in healthcare, be designed with user-centric principles to 
facilitate safe and effective interaction. Documentation of usability engineering 
processes and outcomes is required under all three regulations.  
18. What human oversight requirements are included in the MDR, IVDR and AIA 
for high-risk MDAI?  
The AIA emphasizes the importance and sets a legal obligation on the manufacturer 
to design and develop AI systems, including high-risk MDAI, with appropriate human 
oversight mechanisms.  
In particular, human oversight measures should guarantee that the system is 
designed by the manufacturer with in-built operational constraints that cannot be 
overridden by the system itself and is responsive to the human operator.52 This 
involves designing high-risk MDAI to allow human intervention in critical decision-
making processes. The MDR and IVDR support this by requiring that MDAI, be 
designed for safe and performant use.53 The AIA details that oversight measures 
should be commensurate with the risks, level of autonomy, and context of use of the 
high-risk MDAI. Thus, clearly defined and documented human oversight mechanisms 
as well as appropriate instructions for use54 will be necessary to ensure safe and 
performant use and deployment of high-risk MDAI and allow appropriate supervision 
by healthcare professionals and institutions. 
 
51 Article 13 AIA. 
52 AIA, Article 14. 
53 MDR and IVDR, Annex I. 
54 MDR and IVDR Annex I.

## Page 17

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 17 of 27 
 
19. Can human oversight for medical devices be understood as a part of 
existing risk management measures such as a design measure (e. g. ‘stop’ 
button)? 
Human oversight in addition to the design and operational requirement (see Q18), is 
also considered a risk mitigating factor that aims to prevent or minimise the risks to 
health, safety or fundamental rights when a high-risk AI system is used in accordance 
with its intended purpose or under conditions of reasonably foreseeable misuse.55 
Proper human oversight could be understood as a risk management measure which 
calls for manufacturers to, in the following order of priority:   
a) eliminate or reduce risks as far as possible through safe design and 
manufacture take adequate protection measures, and  
b) (where appropriate) include including alarms, if necessary, in relation to risks 
that cannot be eliminated and 
c) provide information for safety. 
 
For MDAI, specific considerations as to what level of human oversight is necessary 
and appropriate according to the level of risk associated with possibly e.g. robotic 
driven surgical medical device intervention where a healthcare professional oversees 
the operation and has variable possibilities to ‘override’ the MDAI. However, the 
software design should not allow human intervention in critical parts of the surgical 
operation of a highly autonomous surgical MDAI whereby leaving the patient at risk. 
The manufacturer must include considerations as part of the risk assessment and 
management. 
20. How do the MDR/IVDR and AIA approach informed consent in the context of 
MDAI? 
The MDR/IVDR and AIA both include provisions aimed at protecting individual rights 
through transparency and informed interaction with MDAI. 
Under the MDR and IVDR, informed consent is explicitly required in the context of 
clinical investigations and performance studies.56 These provisions ensure that 
individuals participating in such studies are adequately informed of the risks, benefits, 
and objectives of MDAI. 
The AIA complements these requirements by introducing additional transparency 
obligations that extend to the general deployment of high-risk AI systems (see 
Question 14). Furthermore, the requirements on human oversight57 and 
transparency58 reinforce the need to provide deployers and affected persons with 
sufficient information to understand the system’s capabilities, limitations, and 
potential risks. 
 
55 Article 14(2) of the AIA. 
56 Article 69 MDR and Article 59 IVDR. 
57 Article 14 AIA. 
58 Article 13 AIA.

## Page 18

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 18 of 27 
 
Together, these requirements contribute to safeguarding patient autonomy and 
support the ethical deployment of MDAI. 
 
21. How do the MDR/IVDR and AIA address the traceability of high-risk MDAI? 
Traceability is a key component of both regulatory frameworks, albeit with different 
focal points. 
The MDR and IVDR require that devices, including those incorporating AI, are 
traceable throughout the supply chain and device lifecycle.59 This includes 
obligations related to Unique Device Identification (UDI), registration, and post-
market surveillance.  
With the same intent, under the AI Act the EU declaration of conformity, among other 
information, requires “AI system name and type and any additional unambiguous 
reference allowing the identification and traceability of the AI system” to be included. 
Moreover, Article 12 AIA introduces requirements related to functional traceability. 
Article 12 mandates that high-risk AI systems maintain logs of system performance 
and behaviour throughout their lifecycle to support monitoring and post-market 
monitoring. Article 12 and recital 71 underscore that logging and documentation are 
essential to ensure system traceability of the functioning of a high-risk AI system.  
Thus, the concept of traceability is applied in two interrelated ways: (1) traceability of 
device movement and lifecycle and (2) traceability of system functioning and 
performance. Together, these ensure that both the hardware and software 
dimensions of high-risk MDAI are adequately monitored and controlled. 
5. Accuracy, Robustness and Cybersecurity  
22. What cybersecurity measures are required by the AIA and MDR/IVDR?  
The MDR, IVDR and AIA emphasise the need for robust cybersecurity measures in 
both the pre-market and post-market stages of high-risk MDAI. The MDR and IVDR 
underline that any risks associated with the operation of the device must be 
acceptable so as to enable a high level of protection of health and safety, taking into 
account the generally acknowledged state of the art. This can only be achieved 
through the establishment of an adequate balance between benefit and risk during all 
possible operation modes of a device. To this end, there is a need to consider the 
relationship between "safety” and “security" related risk.60  
The cybersecurity measures implemented by manufacturers must aim to prevent 
unauthorised access, cyberattacks, exploits, manipulation and ensure operational 
resilience. The AIA requires for high-risk MDAI the implementation of technical 
 
59 Article 25 MDR and Article 22(1) IVDR.  
60 See MDCG 2019-16.

## Page 19

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 19 of 27 
 
solutions to address AI specific vulnerabilities.61 Manufacturers of high-risk MDAI 
should ensure a level of cybersecurity appropriate to the risks and take suitable 
measures to secure AI specific assets such as training data sets or trained model as 
well as appropriate the underlying ICT (Information and communications technology) 
infrastructure.62  
Manufacturers of MDAI should implement measures to secure data transmission and 
storage, prevent unauthorised access,63 data and model poisoning, and detect and 
respond to cybersecurity incidents. These requirements are also applicable at the 
level of data governance (e.g. at the time of developing the MDAI, through the use of 
training, validation and testing data).  
Manufacturers must also conduct risk assessments to identify potential cybersecurity 
vulnerabilities and implement appropriate mitigation measures.64 The technical 
solutions aiming to ensure the cybersecurity of MDAIs shall be appropriate to the 
relevant circumstances and the risks. 
As cybersecurity65 is part of the essential requirements for high-risk AI systems, and 
thus an obligation of the manufacturer,66 it should be part of the risk management 
system,67 and the quality management system68 and therefore subject to conformity 
assessment.69 All three regulations require manufacturers to establish procedures to 
consider safety and security risk aspects from an early stage of design and 
throughout the entire life cycle, taking into account the operational environment of 
use and ICT infrastructure.70 
Note:  medical devices and in vitro diagnostic medical devices are out the scope of 
Regulation (EU) 2024/2847 of the European Parliament and of the Council of 23 
October 2024 on horizontal cybersecurity requirements for products with digital 
elements and amending Regulations (EU) No 168/2013 and (EU) 2019/1020 and 
Directive (EU) 2020/1828 (Cyber Resilience Act). 
 
 
 
 
61 Article 15 AIA 
62 MDR, Annex I, section 17, IVDR, Annex I, section 16, MDCG 2019-16 rev. 1 and Recital 76 and 77 AIA 
63 See MDCG 2019-16. 
64 MDR, Annex I, Section 17; AIA, Article 15, Annex IV, Section 2.h. 
65 Article 15 AIA. 
66 Article 9 AIA. 
67 Article 16 (a) AIA. 
68 Article 17 AIA. 
69 Article 43 AIA. 
70 Based on MDR, Annex I, section 17, IVDR, Annex I, section 16, MDCG 2019-16 rev. 1 and Recital 76 AIA.

## Page 20

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 20 of 27 
 
III. Clinical /Performance Evaluation and 
Testing 
23. What criteria is specified in the AIA for evaluating the performance of MDAI? 
The AIA specifies criteria for ensuring the safety, reliability, and effectiveness of high-
risk MDAI. While the AIA does not explicitly use the term “clinical evaluation” or 
"performance evaluation," it mandates requirements such as accuracy, robustness, 
and cybersecurity for high-risk MDAI, which are essential aspects of performance71 
as well as specifically requires testing of high-risk MDAI against prior defined metrics 
and probabilistic thresholds to ensure that high-risk MDAI perform consistently for 
their intended purpose and that they are in compliance with the requirements of the 
AIA.72 Article 9 (8) specifically states that testing of high-risk MDAI shall be 
performed, as appropriate, at any time throughout the development process. 
The AIA mandate validations of AI training pipelines to ensure the reliability and 
accuracy of the AI systems. This includes validating design, manufacturing, data 
collection, preprocessing, model training, and quality management processes under 
various conditions, with continuous monitoring to address potential issues.73  
24. What specific requirements do the MDR, IVDR and AIA impose for the 
clinical (MDR) or performance (IVDR) evaluation of high-risk MDAI?  
The MDR and IVDR require manufacturers to validate MDAI outputs through rigorous 
testing in the form of clinical or performance evaluation to ensure compliance and 
that the MDAI performs as intended.74Manufacturers must perform software 
verification and validation activities to ensure that MDAI meets specified 
requirements and functions correctly. This requires clinical validation to demonstrate 
that the MDAI is safe and provides accurate, reliable, and clinically relevant 
outputs.75 Similarly, the AIA mandates verification and validation of high-risk MDAI to 
ensure it operates as intended and meets safety and performance requirements. In 
addition to the MDR and IVDR, the AIA introduces the requirement for the validation 
of high-risk MDAI, in terms of transparency, human oversight, accuracy, robustness 
and cybersecurity.76 Furthermore, the AIA requires that validation of high-risk MDAI 
involves verifications that the high-risk MDAI does not infringe on fundamental rights.  
All three frameworks emphasize testing under various conditions, documentation of 
evaluation processes, and continuous monitoring to ensure compliance. These 
regulations require manufacturers to provide evidence to support their claims, 
ensuring that MDAI adhere to rigorous safety and performance standards. 
 
71 Article 61 and Annex XIV MDR, Article 56 and Annex XIV IVDR, Article 15 and recital 74 AIA.  
72 Article 9 AIA. 
73 Article 10 and 13 AIA. 
74 Article 61 and Annex XIV MDR, Article 56 and Annex XIV IVDR. 
75 MDR and IVDR Annex XIV. 
76 Chapter III, Section 2 AIA.

## Page 21

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 21 of 27 
 
This includes testing documentation of validation processes, and continuous 
monitoring to address any issues that may arise.77 The regulations provide flexibility 
in choosing validation methods but emphasise the importance of demonstrating that 
the MDAI functions correctly and meets specified requirements. In addition, clinical or 
performance evaluation should also support the generation of clinical evidence of the 
MDAI including clinical benefit within the intended patient population, in alignment 
with the intended purpose and risk classification of the device. 
For high-risk MDAI that continue to learn after being placed on the market or put into 
service, the AIA introduces an additional consideration to be taken into account as 
part of the clinical or performance evaluation in the form of pre-determined 
changes.78 
For further information on establishing clinical evidence, see MDCG 2020-01 
“Guidance on Clinical Evaluation (MDR) / Performance Evaluation (IVDR) of Medical 
Device Software”. 
Note: Guidance on Pre-determined Change Control Plans for MDAI is currently under 
development at the level of the International Medical Device Regulators Forum 
(IMDRF) which will likely serve as a basis for future EU guidance on the subject-
matter.   
25. How might manufacturers conduct clinical investigations and clinical 
performance studies in conformity with both MDR/IVDR and the AIA? 
High-risk MDAI must be supported by clinical evidence to demonstrate the device’s 
safety, performance, and, where applicable, clinical benefit. In accordance with the 
MDR and IVDR, such clinical evidence may need to be generated through a clinical 
investigation (under the MDR) or a performance study (under the IVDR), as 
appropriate. 
Where high-risk MDAI undergoes a clinical investigation or performance study, this 
constitutes real-world testing under the AIA.79 In such cases, paragraph 3 of Article 
60(1) applies, which allows real-world testing of high-risk AI systems prior to their 
placing on the market or putting into service, provided that such testing is in 
accordance with applicable Union or national laws, including those under the MDR 
and IVDR. 
Although the AIA does not apply to AI systems that are not yet placed on the market 
or put into service,80 the AIA introduces a specific provision for Annex III high-risk AI 
systems which states that under certain conditions, these systems may undergo 
testing in real-world conditions prior to their placing on the market or putting into 
 
77  Articles 9, 10, 12 and 17 AIA. 
78 Article 43 AIA. 
79 Article 60(1) AIA.  
80 Article 2(8) AIA.

## Page 22

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 22 of 27 
 
service.81 Article 60(1), third subparagraph, explicitly states that such real-world 
testing is permitted "without prejudice to Union or national law on the testing in real-
world conditions of high-risk AI systems that are medical devices or in vitro diagnostic 
medical devices.” 
26. What processes are outlined in the MDR, IVDR and AIA for generating 
clinical evidence to support the safety and performance of MDAI?  
The MDR and IVDR introduce requirements on the generation of clinical evidence to 
support the safety and performance of MDAI. The MDR/IVDR require manufacturers 
to generate clinical evidence through the conduct of clinical/performance evaluations, 
which may be generated through clinical investigations and clinical performance 
studies (as applicable) to demonstrate conformity with the applicable requirements.82 
This involves designing and conducting studies to evaluate the performance, 
reliability, and (clinical) impact of MDAI, with specific requirements for study design, 
data collection, and statistical analysis. All three regulations emphasise the 
importance of generating robust evidence to demonstrate the safety, performance 
and effectiveness of MDAI. 
IV. Conformity assessment  
 
27. Which conformity assessment procedure apply to AI systems in the scope 
of the MDR/IVDR and AIA?   
For AI systems classified as high-risk MDAI under Article 6(1) (See Q2) the relevant 
conformity assessment procedure is determined by the MDR/IVDR.83  For high-risk 
MDAI, where both AIA Annexes I and III apply, Annex I alone should prevail for that 
MDAI.    
An AI system that is classified as high-risk MDAI based on Article 6(2) AIA and falls 
into one of the areas listed in Annex III points 2 to 9, in accordance with paragraph 2 
Article 43 (2) AIA, shall follow the conformity assessment procedure set in Annex VI 
AIA. This is the procedure based on internal control which does not provide for the 
involvement of a notified body.   
An AI system that is classified as a high-risk MDAI based on Article 6(2) AIA, and falls 
into area listed in Annex III point 1, in accordance with Article 43(1) AIA, shall follow 
one of the conformity assessment procedures provided in this article.  
For example, if an AI system used for healthcare, such as an emergency triage 
system, qualifies as MDAI, then the conformity assessment procedure following AIA 
Art. 6 (1) is applicable. AI systems that qualify as high-risk AI systems under Article 
6(1) AIA must comply with both MDR or IVDR and the AIA.  
 
81 Article 60. 
82 Annex XIV MDR and IVDR. 
83 Article 43 (3) AIA

## Page 23

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 23 of 27 
 
However, if an AI system qualifies solely as a biometric categorisation system under 
Annex III Section 1 (b) AIA, then this system must comply only with the requirements 
and obligations of the AIA and undergo a conformity assessment procedure in 
accordance with Article 43 (1) AIA.  
28. What is the process for demonstrating conformity to both the AIA and 
MDR/IVDR? 
High-risk MDAI undergoes the relevant conformity assessment procedure based on 
the device's risk classification under the MDR and IVDR.84 Most MDAI are classified 
as Class IIa (MDR), B (IVDR), or above, meaning that they require a notified body to 
conduct a quality management system audit, technical documentation review, and 
inspections to ensure compliance with all regulatory requirements.  
According to Article 43(3) AIA, for high-risk MDAI the requirements set in Articles 8 to 
15 AIA and specific provisions related to the assessment of quality management 
system and technical documentation covered in Annex VII point 4.3, 4.4, 4.5, and the 
fifth paragraph of point 4.6 AIA must be assessed or taken into consideration as part 
of the conformity assessment procedure under MDR and IVDR.  
V. Substantial Modification/significant 
change 
29. Will the type of substantial modifications under AIA be aligned with the 
changes that could necessitate a new conformity assessment under 
MDR/IVDR?   
The concept of substantial modification is an autonomous concept under the AIA 
which is defined in Article 3 (23). In accordance with Article 43(4) of the AIA, high-risk 
MDAIs that have been subject to a conformity assessment procedure shall undergo a 
new conformity assessment procedure in the event of a substantial modification, 
regardless of whether the modified system is intended to be further distributed or 
continues to be used by the current deployer.  
In accordance with Article 96 (1) (c) AIA, the Commission will develop guidelines on 
the practical implementation of the provisions related to substantial modification. 
Once published, an assessment on application to medical devices and in vitro 
diagnostic medical devices will be necessary.  
30. When do changes to a high-risk MDAI after being placed on the market or 
put into service not constitute a substantial modification under AIA and 
MDR/IVDR? 
In addition to MDR/IVDR requirements for the implementation of procedures to 
manage updates and modifications to MDAIs, high-risk MDAIs that continue to learn 
 
84 Article 16(f) and Article 43(3) AIA, Article 52 MDR or Article 48 IVDR

## Page 24

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 24 of 27 
 
after being placed on the market or put into service have the possibility of having pre-
determined changes plan checked at the time of the conformity assessment (Article 
43(4) AIA).  Changes to high-risk MDAIs that have been pre-determined by the 
manufacturer and assessed at the moment of the initial conformity assessment and 
are part of the information contained in the technical documentation referred to in AIA 
Annex IV point 2(f) shall therefore not constitute a substantial modification.  
Therefore, such pre-determined change should not be understood as a change to the 
certified medical device or IVD under MDR Annex IX Section 4.10 and IVDR Annex 
IX Section 4.11. The above-specified rule should be included in the change 
management procedure of the MDR/IVDR device and in the technical documentation 
as provided in AIA Annex IV point 2(f). It is essential that at the time of conformity 
assessment, the pre-determined changes must be clearly specified and adaptable to 
the device's evolving nature. This performance, documented in the technical 
documentation, should include a detailed description of the initial performance 
expectations alongside mechanisms for validating and managing changes that occur 
post-market.  
Note: Guidance on Pre-determined Change Control Plans for MDAI is currently under 
development at the level of the International Medical Device Regulators Forum 
(IMDRF) which will likely serve as a basis for future EU guidance on the subject-
matter.   
31. Do high-risk MDAI that are already on the market and that undergo a 
significant change in the design (Article 111 AIA) before 2 August 2027 need 
to undergo a new conformity assessment following the entry into force of 
the AIA? 
 
No. Considering that as per the ‘Blue Guide’ on the implementation of EU product 
rules 2022[1], the term “placing on the market” refers to each individual product 
rather than to a type of product. 
AIA Art. 6(1) sets out the conditions for an “Annex I high-risk AI system”. The date of 
application of obligations for “Annex I high-risk AI systems” is 2 August 2027, 
meaning: 
 
- 
If the medical device has been placed on the market/put into service before 2 
August 2027: 
o If the AI system is subject to any significant changes in its design on 
or after 2 August 2027, EU AIA obligations apply, including 
obligations for “Annex I high-risk AI systems” 
o If the AI system is subject to any significant changes in its design 
before 2 August 2027: obligations for “Annex I high-risk AI 
systems” do not yet apply 
- 
If the medical device is placed on the market/put into service on or after 2 
August 2027, then EU AIA obligations apply, including obligations for 
“Annex I high-risk AI systems”

## Page 25

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 25 of 27 
 
Note: Article 111 (2) AIA gives provisions for high-risk AI systems already placed on 
the market or put into service and says that the EU AIA applies to high-risk AI 
systems that are subject to significant design changes already as of 2 August 2026. 
However, because EU AIA, Art. 6 (1) only applies as of 2 August 2027 (as specified in 
EU AIA, Art. 113 (c)), AI systems that are part of a medical device (or that are 
themselves medical devices) are not classified as high-risk AI systems prior to 2 
August 2027, and therefore Art. 111 (2) does not apply to them prior to 2 August 
2027. It is, however, to be assumed that Article 111 (2) applies to such “Annex I high-
risk AI systems” by analogy, i.e. for significant changes on or after 2 August 2027. 
VI. Post-market monitoring 
32. What post-market surveillance requirements are outlined in the MDR/IVDR 
and AIA for MDAI?  
Both the MDR/IVDR and AIA mandate that manufacturers establish and implement 
post-market monitoring and surveillance systems to monitor the performance and 
safety of MDAI after they are placed on the market. This includes systematic 
collecting and analysing data on device performance, risk analysis, adverse events 
assessment and reporting, and other safety-related issues, as well as taking 
appropriate corrective and preventive actions as necessary. Manufacturers must also 
implement a vigilance system, report adverse events and other safety-related 
information to regulatory authorities and users as required.85 Manufacturers must 
regularly update their risk and quality management systems and compliance 
strategies based on post-market monitoring and regulatory feedback.  
33. How do the MDR/IVDR and AIA mandate continuous performance 
monitoring mechanisms for MDAI?  
The MDR/IVDR require manufacturers to establish post-market surveillance systems 
to monitor the performance and safety of medical devices and IVDs, including MDAI, 
after they are placed on the market.86 Similarly, the AIA mandates post-market 
monitoring and a post-market monitoring plan to actively and systematically collect, 
document, and analyse relevant data on the performance of high-risk MDAIs through 
their lifetime and ensure continuous compliance with requirements of Article 8 to 15 
AIA. The post-market monitoring system shall be proportionate to the nature of the 
technology and the risks of the system, to ensure ongoing compliance with safety 
and performance standards.87 
34. What new dimensions of requirements does the AIA introduce to the 
existing post-market surveillance requirements of the MDR/IVDR? 
Firstly, what doesn’t change is the obligation of the manufacturers for post-market 
monitoring of MDAI. Both MDR/IVDR and AIA include obligations on the 
 
85 Article 83 MDR; Article 78 IVDR Article 72 AIA 
86 MDR, Article 83, IVDR Article 78 
87 Article 72 AIA.

## Page 26

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 26 of 27 
 
manufacturer to establish and document a post-market monitoring system that is risk-
based and clearly established in the quality management system that the device 
continues to operate as intended.  
The major monitoring change required by the AIA will be the need, where relevant, to 
detect for interaction with other AI systems, including other devices and software. 
Furthermore, deployers are required to monitor the operation88 and where relevant 
inform the manufacturer.89  
In accordance with Article 72(3) AIA, the Commission shall adopt implementing act 
laying down detailed provisions establishing a template for the post-market 
monitoring plan and the list of elements to be included in the plan by 2 February 
2026. In accordance with Article 72 (4) paragraph 4, the necessary elements of the 
post-market monitoring plan and the elements of the template adopted under the AIA 
may be integrated into already existing post-monitoring plan under the MDR/IVDR, 
provided it achieves an equivalent level of protection. 
VII. Other questions  
35. Should ‘in-house’ MDAI manufactured and used only within health 
institutions be classified as a high-risk AI system? 
As stated in Question 2 of this FAQ, one of the conditions to determine if an AI-
system is high-risk is that the MDAI must be subject to a third-party conformity 
assessment by a notified body designated under the MDR and or IVDR. 
Consequently, MDR/IVDR in-house developed medical devices and in vitro 
diagnostic medical devices manufactured and used only within health institutions 
established in the Union are not subject to third-party conformity assessment, 
provided that the conditions of Article 5(5) are met. 
Therefore, such a MDAI is not classified as a high-risk AI system. Nevertheless, other 
AIA obligations apply including but not limited to prohibited practices. 
Note: due to the inherent possible risks associated with in-house MDAI and in order 
to ensure their safety and performance, the AIB and MDCG will provide further 
guidance and clarifications on appropriate requirements for in-house MDAI.   
36. Are MDAI manufacturers required to define some minimum AI training e.g. 
to medical physics experts and radiologists to be able to understand 
potential risks of diagnostic support tools? 
 
The MDR, IVDR and AIA require manufacturers to ensure training of deployers using 
MDAI when appropriate as part of their risk management to ensure appropriate use, 
reduce foreseeable misuse and oversight during its deployment. One of the essential 
 
88 Article 26 AIA. 
89 Article 72 AIA.

## Page 27

Medical Devices 
     
Joint Artificial Intelligence Board and  
 
AIB 2025-1 
Medical Device Coordination Group Document  
MDCG  2025-6 
 
Page 27 of 27 
 
requirements of the AIA for high-risk AI systems includes transparency and provision 
of information for deployers.90  
As explained in Recital 72 of the AIA, the accompanying instructions for use, should 
assist deployers in the use of the system and support informed decision making by 
them. Deployers, should be in a better position to make the correct choice of the 
system that they intend to use in light of the obligations applicable to them, be 
educated about the intended and precluded uses, and use the AI system correctly 
and as appropriate.  
In addition, when human oversight measures are identified commensurate with the 
risk, level of autonomy and context of use, the natural persons to whom human 
oversight is assigned must be enabled to understand the capabilities and limitations 
and be able to duly monitor. Manufacturers should advise on education and training 
which would provide a sufficient understanding on the MDAI interpretability of the 
generated output to mitigate reasonably foreseeable misuses. Similarly, MDR and 
IVDR require manufacturers to supply information on special training required to use 
the device.91 
Furthermore, the AIA obliges manufacturers and deployers of AI systems, to ensure, 
to their best extent, a sufficient level of AI literacy of their staff and other persons 
dealing with the operation and use of AI systems on their behalf, taking into account 
their technical knowledge, experience, education and training and the context the AI 
systems are to be used in, and considering the persons or groups of persons on 
whom the AI systems are to be used.92  
For further information on AI literacy, please consult the following Questions and 
Answers document on the topic.   
 
 
90 Article 13 AIA 
91 Annex I MDR and IVDR. 
92 Article 4, as explained in Recital 20 AIA.


---

# A Brief Report on Proposed Areas of International Harmonization of Real-World Evidence Relevance, Reliability and Quality Standards Among Medical Product Regulators

- **Authors:** Maryam Nafie, Valerie J Parker, Mark McClellan, Rachele M Hendricks-Sturrup
- **Issuer:** Pharmacoepidemiology and drug safety
- **Type:** Scientific article
- **Published:** 2025-03-01
- **Language:** en
- **DOI:** 10.1002/pds.70127
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40084391/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

ABSTRACTBackgroundInternational harmonization of real‐world data and evidence (RWD/E) standards is a goal among real‐world data/real‐world evidence (RWD/E) policy stakeholders. The Duke‐Robert J. Margolis Institute for Health Policy developed an online ‘International Harmonization of RWE Standards Dashboard’ to provide timely updates around these goals.MethodsGuidance for industry (draft and final) and related literature available online by medical product regulators globally was sought and, where needed, translated into English language using a certified translator. Consultations were then held with practicing experts to identify, collate, and interpret documents. An online Tableau tool was assembled to collate guidance documents and regulatory definitions of the following key terms used among the community to describe fit‐for‐use RWE in regulatory submissions: relevance, reliability, and quality.ResultsAs of February 2025, the United States Food and Drug Administration (FDA) has released the most RWE guidance documents to date (n = 13; 4 draft, 9 final). Four (4) regulators globally (US FDA, EMA, Taiwan FDA, Brazil ANVISA) have directly defined at least two (2) out of the three key terms (reliability, relevance, quality), indicating alignment around the importance of these terms used in the context of RWD/E. Across these terms, we propose areas of definitional alignment: data representativeness and research and regulatory concern (relevance), accuracy in data interpretation and quality and integrity during data accrual (reliability), and data quality assurance across sites and time (quality). We propose areas of definitional misalignment regarding clinical context, data availability and representativeness, and ensuring study sample sizes and/or datasets are adequate to address a given study question.ConclusionsOur assessment of definitions provided among these four regulators lends us to propose distinct areas for harmonization based on our assessment of where regulators appear to align and highlight opportunities to address misalignment.Keywords: international harmonization, real‐world data, real‐world evidence, regulatory science

## Section: Purpose

Real‐world data (RWD) and real‐world evidence (RWE) are increasingly used to demonstrate both the efficacy and safety of medical products investigated globally across a broad range of therapeutic and disease areas [1]. RWE approaches have involved but have not been limited to the use of external RWD controls (direct matching, benchmark/natural history), external controls (literature/prior trials), and RWD generated via an expanded access program [1, 2]. For these reasons, international harmonization of RWD and RWE standards has become a stated goal among regulators, medical product developers, and their collaborators globally.

In 2022, members of the International Coalition of Medicines Regulatory Authorities (ICMRA; European Medicines Agency [EMA]; the United States Food and Drug Administration [US FDA]; and Health Canada) published a statement noting their interest and intent to converge on terminology for RWD and RWE. More recently, members of the M14 working group within the International Conference on Harmonization (ICH) have published draft guidelines on M14 General Principles on Plan, Design, and Analysis of Pharmacoepidemiological Studies That Utilize Real‐World Data for Safety Assessment of Medicines [3].

To augment transparency and support this effort's partnership with communities of practice, the Duke‐Robert J. Margolis Institute for Health Policy's RWE Collaborative, we developed an online and publicly accessible International Harmonization of RWE Standards Dashboard (“Dashboard”) [4]. This brief report, builds on current and relevant work, including that of the International Society for Pharmacoepidemiology (ISPE), conducted to generate recommendations for improvements to RWD identification and feasibility assessments [5]. Building on our recent engagement and presentation at the 2024 ISPE Annual Meeting, entitled “Catalyzing International Harmonization of Real World Evidence Standards,” we describe our general process taken to build the Dashboard and summarize quantitative and qualitative findings. We highlight and discuss signs of definitional alignment around key terms, as well as highlight areas of definitional misalignment, to offer practical recommendations.

## Section: Methods › Identification and Selection of Guidance Documents and Frameworks for Industry

A broad internet search, alongside consultations with practicing experts across government, industry, and academia, was conducted with the intent to locate, source, and collate both draft and final regulatory guidance documents and frameworks on RWD/RWE. Guidance documents and frameworks found were evaluated as published in the English language, or as certified translated into English, among three analysts (M.N., V.J.P., R.M.H‐S.). We extracted and captured, using Microsoft Excel, both formal and informal definitions for the following key terms used to describe fit‐for‐use RWE in regulatory settings: reliability, relevance, and quality.

## Section: Methods › Quantitative and Qualitative Assessment

We quantified the total number of guidance documents and frameworks published to date across all regulators globally, as well as the total number of guidance documents and frameworks published by each regulator to date. We also quantified the total number of regulators who have defined the following terms: reliability, relevance, and quality. We evaluated definitions provided among a subset of regulators that have formally defined at least two (2) of those terms to determine early signs of definitional alignment/misalignment, propose areas for harmonization based on our assessment of where regulators appear to align, and highlight opportunities to address misalignment.

## Section: Methods › Statement of Work in Progress

Information captured in Microsoft Excel was imported into Tableau Desktop to display summarized findings online via Tableau Public on the Duke‐Margolis International Harmonization of RWE Standards Dashboard (https://healthpolicy.duke.edu/projects/international‐harmonization‐real‐world‐evidence‐standards‐dashboard). Information within the Dashboard continues to be updated regularly. The Dashboard in its current form is meant to serve as a foundational work‐in‐progress, particularly as new guidance documents and/or frameworks published by government agencies globally are released and/or finalized and thus captured within the Dashboard.

## Section: Results

Proposed areas for harmonization and opportunities to address signs of potential misalignment among regulators globally concerning the relevance, reliability, and quality of real‐world data and evidence.

## Section: Results › Quantitative Findings

As of February 2025, we observed 58 guidance documents that have been published across 14 regulators. The number of publications published, however, varies by regulator. The United States Food and Drug Administration (US FDA) has released the greatest proportion of guidance documents (n = 13; 4 draft, 9 final), followed by the European Medicines Agency (EMA) and the National Medical Products Administration/China Center for Drug Evaluation (NMPA/CDE‐China) and Pharmaceuticals and Medical Devices Agency (PMDA—Japan), which have each released seven (n = 7) guidance documents. Four (4) of the 14 regulators (US FDA, EMA, Taiwan FDA, Brazil ANVISA) have directly defined and aligned around the use of at least two (2) of the three stated key terms (reliability, relevance, and quality).

## Section: Results › Qualitative Findings: Definitional Alignment

We observed signs of definitional alignment among the subset of regulators that have formally defined at least two of the three following terms: relevance, reliability, and/or quality (see Appendix A and Table 1). The US FDA and ANVISA have defined data “relevance” as inclusive of “sufficient numbers of representative patients for the study” and “data is robust and representative,” thus indicating potential definitional alignment.

Regarding “reliability,” the EMA includes “accuracy” and “representation” in its definition of reliability, as does the US FDA in one of its definitions (“data accuracy, completeness, provenance, and traceability”). “Quality” is also a consideration in the EMA, Taiwan FDA, and one of the US FDA's definitions of reliability, and the US FDA and Taiwan FDA consider quality within the scope of data accrual.

For the term “quality” as a standalone definition, the Taiwan FDA advises sponsors to “take into account completeness, accuracy, consistency, and transparency of the data.” The US FDA notes this in its definition of “quality,” such that quality would involve an “assessment of completeness, accuracy, and consistency across sites and over time.” Likewise, ANVISA notes regarding quality, “data that presents, in every aspect of its origin, clarity and traceability, and it is also auditable.”

Proposed areas for harmonization and opportunities to address signs of potential misalignment among regulators globally concerning the relevance, reliability, and quality of real‐world data and evidence.

## Section: Results › Qualitative Findings: Definitional Misalignment

Despite signs of alignment, we observed areas of possible misalignment for these terms among the subset of regulators (see Appendix A). We observed that the Taiwan FDA and ANVISA have defined data “relevance” as specific to a regulatory purpose or problem driven by clinical context, while the FDA and EMA define “relevance” as specific to a research question and involving aspects of data availability and representativeness, thus indicating potential definitional misalignment.

The Taiwan FDA considers quality control and quality/data assurance in its definition of reliability. The EMA includes “accuracy” and “representation” in its definition of reliability, though, as mentioned above, both the US FDA and ANVISA include “representative” within their definitions of “relevance.” ANVISA has yet to formally or clearly define “reliability” as a key term.

Regarding the term “quality,” the EMA includes “extent to which a dataset presents the data elements useful to answer a given research question” and “data quality is relative to the research question and does not address the question on what level is the quality measured,” in its definition of “relevance” versus “quality.” Yet, the US FDA includes “study sample size should be adequate to address the study question” in its definition of “quality,” thus indicating not only differences in these definitions themselves, but also differences in quality measurement considerations (i.e., sample size).

In Table 1, we propose areas for harmonization based on our assessment of where regulators seem to align most and highlight opportunities to address misalignment.

## Section: Conclusion

Overall, our findings indicate opportunities for regulators to consider our proposed areas of alignment and discuss opportunities to address signs of potential misalignment. We believe this work is critical to continue to help shape national and international RWE regulatory policy conversations; guide operational goals and standards for RWE consideration broadly among regulators, health technology assessment bodies, and payers; and, importantly, support researchers and other regulatory stakeholders seeking to identify, in real‐time, global regulatory policy developments focused on RWE [6].

## Section: Conclusion › Plain Language Summary

Harmonization around the consideration and use of real‐world evidence (RWE) is a stated goal among regulators globally. As a helpful step towards achieving this goal, we collated, quantified, and evaluated regulatory guidance documents and definitions of key terms used among the community to describe fit‐for‐use RWE (relevance, reliability, quality) provided in regulatory submissions. To date, the United States Food and Drug Administration has released the most guidance documents to date (n = 13; 4 draft, 9 final). Only four (4) of these regulators (US FDA, EMA, Taiwan FDA, Brazil ANVISA), however, have directly defined and aligned around the use of at least two (2) of the aforementioned key terms. Our assessment of definitions provided among these four regulators leads us to propose distinct areas for harmonization based on our assessment of where regulators appear to align and highlight opportunities to address misalignment.

## Section: Ethics Statement

The authors have nothing to report.

## Section: Conflicts of Interest

Dr. McClellan is an independent director on the boards of Johnson & Johnson, Cigna, Alignment Healthcare, and PrognomIQ; co‐chairs the Guiding Committee for the Health Care Payment Learning and Action Network; and receives fees for serving as an advisor for Arsenal Capital Partners, Blackstone Life Sciences, and MITRE.

## Section: Acknowledgments

We formally acknowledge and thank Dr. Eric Monson within the Duke University Libraries' Center for Data and Visualization Sciences for providing close data visualization guidance and assistance towards the development of the Dashboard. We also formally acknowledge and thank Adam Aten, former Duke‐Margolis Institute for Health Policy staff, for his early thought and contributions towards the development of this work and Dr. Trevan Locke and Matt D'Ambrosio within the Duke‐Margolis Institute for Health Policy for their ongoing support towards engagement with our Duke‐Margolis RWE Collaborative members to support this work. We also acknowledge and thank Rachel Neha Shaw for her efforts in supporting this work during its initial phases. Last but not least, we formally acknowledge and thank our Duke‐Margolis RWE Collaborative members who have contributed to the successful development and maintenance of the Duke‐Margolis International Harmonization of RWE Standards Dashboard.

## Section: Text

See Table A1.

Overview of definitions of relevance, reliability, and quality among a subset of medical product regulators globally with definitions for at least two key fit‐for‐purpose terms (n = 4).


---

# A framework to assess clinical safety and hallucination rates of LLMs for medical text summarisation

- **Authors:** Elham Asgari, Nina Montaña-Brown, Magda Dubois, Saleh Khalil, Jasmine Balloch, Joshua Au Yeung, Dominic Pimenta
- **Issuer:** NPJ digital medicine
- **Type:** Scientific article
- **Published:** 2025-05-13
- **Language:** en
- **DOI:** 10.1038/s41746-025-01670-7
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40360677/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractIntegrating large language models (LLMs) into healthcare can enhance workflow efficiency and patient care by automating tasks such as summarising consultations. However, the fidelity between LLM outputs and ground truth information is vital to prevent miscommunication that could lead to compromise in patient safety. We propose a framework comprising (1) an error taxonomy for classifying LLM outputs, (2) an experimental structure for iterative comparisons in our LLM document generation pipeline, (3) a clinical safety framework to evaluate the harms of errors, and (4) a graphical user interface, CREOLA, to facilitate these processes. Our clinical error metrics were derived from 18 experimental configurations involving LLMs for clinical note generation, consisting of 12,999 clinician-annotated sentences. We observed a 1.47% hallucination rate and a 3.45% omission rate. By refining prompts and workflows, we successfully reduced major errors below previously reported human note-taking rates, highlighting the framework’s potential for safer clinical documentation.Subject terms: Risk factors, Outcomes research, Health care

## Section: Introduction

One of the most appealing applications of LLMs in healthcare is for administrative tasks1. Clinicians devote a substantial amount of time to documentation2, and prolonged interaction with electronic health records, where clinical documentation is logged, has been demonstrated to raise cognitive load and lead to burnout3. In fact, the use of LLMs for clinical documentation, especially clinical note generation4 or consultation summarisation5,6, is an active area of research.

However, LLMs are known to produce errors in many settings, from document summarisation7, to general reasoning tasks as well as more clinically relevant tasks8. These errors can be categorised as “hallucinations”9: known as an event where LLMs generate information that is not present in the input data, or omissions: the event where LLMs miss relevant information from the original document. Errors in clinical documentation generation can lead to inaccurate recording and communication of facts10,11. Inaccuracies in the document summarisation task can introduce misleading details8 into transcribed conversations or summaries, potentially delaying diagnoses12 and causing unnecessary patient anxiety.

The problem of hallucinations poses a significant challenge to date1,13. The occurrence of hallucinations has previously been attributed to the data quality during model training14,15, the type of model training methodology16 and prompting strategies17.

Recent work has established that hallucination may be an intrinsic, theoretical property of all LLMs9. Consequently, there is a growing body of work focused on the technical evaluation of LLM accuracy and the detection and mitigation of hallucinations in LLMs18. However, the prevalence, causation, and evaluation of hallucinations in a clinical context, as well as their subsequent impact on clinical safety, remains an open question.

Clinical documentation can be variable in quality19,20, and studies estimate that human-generated clinical notes have, on average, at least 1 error and 4 omissions21. Given the increased usage of LLMs for clinical documentation22,23, several methods have been proposed for evaluating clinical documentation generated using LLMs.

Relevant clinical evaluation frameworks typically include categorising clinical errors for downstream analysis. Typically, these differ from traditional natural language processing (NLP) taxonomies16, which have separated hallucination types into distinct categories, for example, into “intrinsic” and “extrinsic”24, “factuality” and “faithfulness”16, “factual mirage” and “silver lining”25 errors. The differences between general and clinical taxonomies arise from the necessity of increased granularity of clinical error types, which are not captured by the broader, general methods.

For example, Tierney et al.26 propose using a modified version of the Physician Documentation Quality Instrument-9, accounting for hallucinations and bias, while Abacha et al.23 propose evaluating clinical note quality using automated metrics. However, these relevant clinical categorisations have not assessed the implications of the mistakes for downstream harm.

Automated metrics, such as Recall-oriented Understudy for Gisting Evaluation (ROUGE)27, Bilingual Evaluation Understudy (BLEU)28 and Bidirectional Encoder Representations from Transformers (BERT)-score29, while useful for comparing model-generated text with expert-written examples, exhibit significant limitations when applied to the evaluation of healthcare-related content. These metrics, primarily focused on surface-level textual similarity, fail to capture the semantic nuances, contextual dependencies, and domain-specific knowledge crucial for accurate medical discourse30. This deficiency is particularly problematic in healthcare settings, where understanding complex medical concepts (e.g., symptoms, diagnoses, treatments) and their interrelationships is paramount for patient well-being and effective decision-making.

Despite the exponential growth in benchmarks for model reasoning abilities31, the evaluation of LLMs on clinical tasks has typically been carried out via “question-answering” (QA) benchmarks5,8,32. These tasks assess models’ accuracy over various clinical questions, typically derived from licensing exams. While these methods offer insights into the factual knowledge and reasoning abilities of LLMs, they do not assess clinical or medical capabilities such as medical text summarisation.

Singhal et al.33 have outlined the challenges of evaluating LLMs in various medical contexts, including medical exams, research and consumer queries. They have proposed a human evaluation model for the answers provided by different LLMs that checks on factuality, precision, possible harm and bias. Other evaluation factors such as fairness, transparency, trustworthiness and accountability have been suggested in using LLMs in healthcare34. In a more recent study, Tang et al. assessed human evaluation based on metrics such as coherence, factual consistency, comprehensiveness and potential harm. Interestingly, they assessed the clinician’s preference for different outputs35. More recently, Tam et al.36 have introduced QUEST as a framework for human evaluation of LLMs in healthcare following a comprehensive literature review on the topic. QUEST includes five principles for human evaluation of LLMs, including Quality of information, Understanding and reasoning, Expression style and persona, Safety and harm, and Trust and confidence.

Multiple benchmarks have been proposed to evaluate model summarisation capabilities in the biomedical domain, including over biomedical literature37–40, medical forum conversations41, and radiology reports22,42. However, these benchmarks do not capture the nuances of patient-facing clinical interactions, where LLM-documentation holds most promise.

Recently, Umapathi et al.43 have assessed models’ tendency towards hallucination. They reported that LLMs were significantly variable in their accuracy depending on the prompts used. However, the MedHALT benchmark is limited to assessing LLM’s reasoning capabilities over the medical domain in a QA format. Most relevantly, Moramarco et al.21 benchmark BART models on the PriMock dataset and find that they produce 3.9 errors and 6.6 omissions on average per note. However, they did not assess the model’s impact or human errors on patient safety as part of their study.

This study aims to contribute to the ongoing effort to ensure clinical safety in using LLMs for note generation by introducing a framework which has four components: (1) a clinically and technically-informed error taxonomy to classify LLM outputs, (2) an experiment structure to comprehensively and iteratively compare outputs within our LLM document generation pipeline, (3) a clinical safety framework to assess potential harms of errors in LLM outputs, and (4) an encompassing graphical user interface (GUI), CREOLA, to perform and assess all previous steps. Figure 1 shows our workflow based on the framework. We present our findings and insights from applying our framework, which, to our knowledge, represents the largest manual evaluation of LLM clinical note generation to date.

Our objective is to promote the efficient, reliable, and confident use of LLMs for clinical documentation, thus supporting healthcare providers in delivering high-quality care and overall reducing the administrative workload for clinicians.

This diagram illustrates the process we followed using the available dataset for various experiments, including the input from clinicians for labelling and consolidating reviews, followed by a safety analysis.

## Section: Results

The figure illustrates the occurrence of hallucinations in the generated sentences based on different prompts (a) and their corresponding percentages (b). It also highlights the type and clinical severity of hallucinations (c) and the specific sections of the note where they appeared (d).

The figure illustrates the number of omitted sentences using different prompts (a) and their respective percentage (b).

We assessed the clinical risk resulting from major hallucinations based on our suggested framework.

We have categorised the clinician severity of hallucination risks based on their type (a) and the section of the clinical notes where they occurred (b).

This figure illustrates the clinical risk severity due to major omissions (a) and indicates the sections of the notes where they are most likely to occur (b).

Comparing omissions (a) and hallucinations (b) using the base prompt from Experiment 1 and the updated style prompt from Experiment 8. Each connected dot represents the change in hallucinations or omissions for a given document.

Prompt changes that led to decreased hallucinations and omissions

The figure shows the changes in the counts of hallucinations (a) and omissions (b) between Experiments 3 and 8 which have resulted from the changes in the prompts.

Comparing omissions (a) and hallucinations (b) in our base experiment (Experiment 1) with Experiment 5 where the transcript was broken down into concise facts before being passed to the LLM for note generation. Each connected dot represents the change in hallucinations or omissions for a given document.

The figure compares the number of hallucinations (a) and omissions (b) between Experiment 3, where the standard note generation step was used, and experiment 5, where data extraction was performed before note generation.

Prompts used in experiments 6, 9, 10 and 11

This figure illustrates how the change in prompts within the function call experiments can change the number of major and minor hallucinations and omissions in the output.

The figures illustrate the type and severity of clinical risk resulting from major hallucinations in Experiments 8 (a) and 11 (c) and the section of the notes they occur (b and d).

The figure illustrates the clinical risk from major omissions in Experiment 8 and the section of the clinical notes where it has occurred.

## Section: Results › Dataset

We conducted a series of 18 experiments, each consisting of 25 primary care consultation transcripts from the PriMock dataset44 For each transcript, we generated paired clinical documentation using an LLM, resulting in 450 consultation transcript-note pairs. This was a total of 49,590 transcript sentences and 12,999 clinical note sentences that were manually evaluated and labelled for any hallucinations or omissions.

## Section: Results › Experiments

Our experiments were guided by our framework, which provides a systematic approach to evaluate LLM outputs quantitatively. Using a baseline LLM prompt and workflow, we generated 25 transcript-note pairs. We recruited 50 medical doctors for manual evaluation. For each paired transcript-note, we had two clinician reviewers evaluate each sentence in the clinical note to ensure it was evidenced in the transcript; sentences that were not evidenced were labelled as hallucinations. We also highlighted each sentence in the transcript for review, checking if it was present in the output note if it was clinically relevant; and if not, they were labelled as an omission. If the hallucination or omission could change the diagnosis or management of the patient (if left uncorrected), it was marked as ‘Major’, otherwise, they would be labelled as ‘minor’. In cases of discrepancy between the two reviewers, consolidation was performed by a senior clinician with over 20 years of clinical experience.

We additionally identified the specific sections of the notes where the hallucinations occur (main history, examination, discussion, symptoms assessment, and plan). The result of each experiment informed our subsequent experiment approach to analyse how prompt/ workflow/ engineering changes affect the hallucinatory potential for clinical note generation.

All experiments were conducted on CREOLA, our in-house platform, designed to allow clinicians to identify and label relevant hallucinations and omissions in clinical text. Using this platform, we were able to implement our framework to quantify and track changes in our prompts and model configurations and iteratively modify our approach to ensure the safe integration of LLM-generated summaries into clinical practice.

## Section: Results › Hallucinations

Of 12,999 sentences in 450 clinical notes, 191 sentences had hallucinations (1.47%), of which 84 sentences (44%) were major (could impact patient diagnosis and management if left uncorrected). Of the hallucination types, 82 (43%) were fabricated, 56 (30%) were negations, 33 (17%) were contextual, and 20 (10%) were related to causality.

Major hallucinations occurred in all sections, but most commonly in Plan (21%), Assessment (10.5%), and Symptoms (5.2%) sections. The most common hallucination type were fabrications and primarily appeared in the planning section of the clinic note (Fig. 2). Examples of the various hallucination types are available in supplementary materials.

The figure illustrates the occurrence of hallucinations in the generated sentences based on different prompts (a) and their corresponding percentages (b). It also highlights the type and clinical severity of hallucinations (c) and the specific sections of the note where they appeared (d).

## Section: Results › Omissions

Of the 49,590 sentences from our consultation transcripts, 1712 sentences were omitted (3.45%), of which 286 (16.7%) of which were classified as major and 1426 (83.3%) as minor. Figure 3 shows the number of omissions and the percentage of omitted sentences based on different prompts.

The figure illustrates the number of omitted sentences using different prompts (a) and their respective percentage (b).

## Section: Results › Grading hallucinations and omissions by clinical safety impact

Inspired by protocols in medical device certifications, we applied the clinical safety assessment of our framework described in the methods section. We classified the clinical risk (Major or Minor) and evaluated the risk severity of all identified major hallucinations as depicted in Fig. 4. We also determined the risk of hallucinations based on their type and where in the sentence they occurred (Fig. 5).

We assessed the clinical risk resulting from major hallucinations based on our suggested framework inspired by protocols in medical device certifications.

We conducted the risk assessment on the omissions (Fig. 6a) and detailed the note section that would likely have been affected (Fig. 6b). Major omissions were most common in current issues, followed by PMFS, and Info and Plan sections (55%, 35%, and 10%, respectively).

Examples of hallucinations and omissions are available in the supplementary materials.

We assessed the clinical risk resulting from major hallucinations based on our suggested framework.

We have categorised the clinician severity of hallucination risks based on their type (a) and the section of the clinical notes where they occurred (b).

This figure illustrates the clinical risk severity due to major omissions (a) and indicates the sections of the notes where they are most likely to occur (b).

## Section: Results › Iterative experiments can significantly reduce hallucination and omission rates in LLM-generated clinical notes

Through a series of 18 iterative experiments, we tested a combination of prompting and workflow strategies, including structured prompting, atomisation, function calls and JSON-based outputs, an additional LLM revision step, and templating (SOAP -Subjective, Objective, Assessment, plan- note), which are explained in more detail in the methods section.

Modifying the prompt from the baseline used in Experiment 1 to include a style update used in Experiment 8, resulted in a reduction of both major and minor omissions. Although there was a slight increase in hallucinations in Experiment 8, these were mostly minor. Figure 7 illustrates the number of hallucinations and omissions recorded in Experiments 1 and 8.

We then compared the outputs using various structured prompts in Experiments 3 and 8 illustrated in Table 1.

The change in the prompt from Experiments 3 to 8 reduced the incidence of major hallucinations by 75% (from 4 to 1), major omissions by 58% (24 to 10), and minor omissions by 35% (114 to 74) (Fig. 8). By following structured prompting, including a style update and instructing the model to output the status “unknown” for instances where information was missing from the transcript, we significantly improved performance.

In a subsequent experiment (Experiment 5), we found that incorporating a chain-of-thought prompt (Table 1, supplementary material), to extract facts from the transcript—a process referred to as atomisation—before generating the clinical note, led to an increase in major hallucinations and omissions. Figure 9 shows the comparison between omissions and hallucinations between this experiment and our base Experiment (Experiment 1).

We also compared the output of Experiment 5 to Experiment 3, which used structured prompts. We found that major hallucinations increased from 4 to 25, minor hallucinations from 5 to 29, major omissions from 24 to 47, and minor omissions from 114 to 188 (Fig. 10). This result precluded the new change from being evaluated for clinical safety, as the increase in hallucinations and omissions was considered too large to be considered useful.

We found that using prompts with function calling was useful in ensuring that the outputs adhered to a specific structure required for different electronic health records. Utilising our framework, we iteratively improved the performance of the structured notes across several experiments (6, 9, 10, and 11). From the first to the last iteration (Experiments 6 to 11), we made meaningful improvements to the prompts, including instructions on adherence to subheadings and the addition of a writing style guidance (e.g., a list of writing rules to follow). Table 2 shows the prompts used in the four function call experiments.

As a result of these changes, we eliminated major omissions completely, decreasing them from 61 to 0, and reduced minor omissions by 58%, from 130 to 54. Additionally, we lowered the total number of hallucinations by 25%, reducing them from 4 to 3 (Fig. 11).

We then examined the two best-performing experiments with the fewest hallucinations and omissions (Experiments 8 and 11) for the type of hallucinations they produced and where they were more likely to appear in the sentence (Fig. 12).

Experiment 11 did not have any major omissions, and the risk assessment of major omissions for Experiment 8 is shown in Fig. 13.

Comparing omissions (a) and hallucinations (b) using the base prompt from Experiment 1 and the updated style prompt from Experiment 8. Each connected dot represents the change in hallucinations or omissions for a given document.

Prompt changes that led to decreased hallucinations and omissions

The figure shows the changes in the counts of hallucinations (a) and omissions (b) between Experiments 3 and 8 which have resulted from the changes in the prompts.

Comparing omissions (a) and hallucinations (b) in our base experiment (Experiment 1) with Experiment 5 where the transcript was broken down into concise facts before being passed to the LLM for note generation. Each connected dot represents the change in hallucinations or omissions for a given document.

The figure compares the number of hallucinations (a) and omissions (b) between Experiment 3, where the standard note generation step was used, and experiment 5, where data extraction was performed before note generation.

Prompts used in experiments 6, 9, 10 and 11

This figure illustrates how the change in prompts within the function call experiments can change the number of major and minor hallucinations and omissions in the output.

The figures illustrate the type and severity of clinical risk resulting from major hallucinations in Experiments 8 (a) and 11 (c) and the section of the notes they occur (b and d).

The figure illustrates the clinical risk from major omissions in Experiment 8 and the section of the clinical notes where it has occurred.

## Section: Discussion

Our study supported that hallucinations and omissions may be intrinsic theoretical properties of current LLMs9. LLMs can output unfactual or unfaithful text with high degrees of confidence45 which can be particularly dangerous in a high-stakes environment such as healthcare. Our framework quantifies the clinical impact and implications that LLM omissions and hallucinations may lead to if unchecked or uncorrected; only then can clinical safety be meaningfully addressed. Once LLM errors are identified and quantified, we can make iterations on LLM prompts, workflows or engineering design to reduce or eliminate these errors. By concentrating on minimising errors that could significantly impact patient care, we can align LLMs with clinical safety standards and regulations.

To our knowledge, we have conducted the largest manual evaluation on the task of LLM clinical note generation to date. To implement our framework at scale we built CREOLA, an in-house platform, designed to enable clinicians to identify and label relevant hallucinations and omissions in clinical text and inform future experiments. However, similar publicly available platforms (e.g. labelbox, explosion AI, autoblocks etc.) may be used for this task. Experiments within CREOLA can validate or discredit architectures and prompt approaches in a safe sandbox environment before clinical deployment.

Our experiment results show that omissions are more common than hallucinations (3.45% to 1.47%, respectively). However, hallucinations were much more likely to be classified as a “major” error compared to omissions (44% to 16.7%, respectively). This means that hallucinations are more likely to lead to downstream harm and impact clinical care if left uncorrected. Hallucinations occurred in all sections, but most commonly (20%) in the Plan section of the clinical note. This is an important finding as this section often contains direct instructions or actions to colleagues or patients that can impact clinical safety. The most concerning hallucinations were the negation type (30% of total hallucinations). These mostly appeared in the planning section and contradicted what was said during the consultation. Negation hallucinations can lead to significant confusion and harm, and without the full context of the consultation, readers may struggle to discern which negation is true and which is false.

By designing prompts that addressed specific aspects of the notes (base, template and style), we were able to focus our iterations to achieve the best results. However, it is important to note that summarisation tasks require the ablation of certain data from the original text to make it a concise, relevant, and useful summary artefact. Optimal omission rates depend significantly on the context, the quality of input and the reviewer receiving output. Our framework allows us to focus on the clinical impact of omissions and hallucinations quantitatively. Overall, our hallucination rates are similar to those reported in the literature for generalist tasks46. For the clinical summarisation task, Experiment 8 achieved 1 major hallucination and 10 major omissions, whilst experiment 11 achieved 2 major hallucinations and 0 major omissions over 25 notes. These results are highly encouraging, as our iterative experiment process has resulted in fewer errors per note than those reported in the clinical literature. Moramarco et al.21 reported 3.9 errors and 6.6 omissions per note as produced by a BART model and 1 error and 4 omissions per human-written note. This improvement is likely due to the large parameter sizes of modern large language models in combination with our framework. Although this rate is subject to change depending on the text and experiment, our results suggest that we can achieve state-of-the-art, sub-human clinical error rates by carefully engineering and subsequently validating LLMs to produce safe outputs.

Our study is limited in several ways. Firstly, the sample size of medical transcripts used was relatively small; the sample size was chosen to balance the trade-off of annotation volume required for the comparison of different experiments against sample size and number of experiments performed. Additionally, we only evaluated one LLM (GPT-4), selected due to its established performance in text summarisation at the time of our experiments. The ongoing development and enhancement of open-source large language models (LLMs) are likely to boost their application in medicine47. Recently, Zhang et al. reviewed how fine-tuning open-source LLMs such as PRIMERA, LongT5, and Llama-2 can enhance their ability to summarise medical evidence effectively48. Furthermore, our experiments use a direct prompting scheme (Supplementary Data 1). Newer methods such as (but not limited to) Retrieval-Augmented Generation (RAG)49, Chain of Thought (CoT)50, or the use of knowledge graphs51 have recently been used to enhance the performance of LLMs. For example, by equipping LLMs with domain-specific knowledge, RAG enables the models to generate more precise and pertinent results52,53, whilst CoT generally enhances model reasoning abilities. A straightforward extension of this work is using this framework over different experimental configurations, such as using different models or prompting techniques, and comparing the impact on reported performance to clinical safety metrics.

Finally, using human annotators to evaluate large amounts of data is expensive and unsustainable. In the long run, the automated evaluation of model output54 is a consequential future direction which will enable the scalable assessment of a larger volume of information, with clinicians remaining in the loop by “supervising” evaluator models via the inspection of a sub-sample of the outputs. ‘LLM-as-a-Judge’, which refers to an LLM tasked with evaluating, scoring, or assessing the quality, correctness, or appropriateness of outputs, has recently been described55 and its applicability has been discussed56. Utilising the capabilities of LLMs for initial screening can significantly reduce the time and resource demands on human evaluators. This can make the CREOLA framework more scalable and efficient over time. This hybrid approach aligns with ongoing advancements in AI and has the potential to maintain rigorous oversight while ensuring scalability.

In this work, we present a framework for the clinical safety assessment of LLMs in clinical documentation scenarios. Using the CREOLA platform, we analyse the impact of prompting techniques on the safety of LLM outputs. Our iterative modification process allows us to reach new low hallucination and omission rates - our best-performing experiments outperform previously reported model and human error rates - facilitating confident deployment of our solutions to end clinical users. Additionally, CREOLA provides a sandbox environment which buffers users and patients from harm in case the iteration leads to higher clinical error rates. The addition of clinical safety assessment to prompt evaluation creates a valuable framework for implementing note summarisation tools in clinical practice. We propose that our suggested framework, which combines the assessment of hallucinations and omissions with an evaluation of their impact on clinical safety, can serve as a governance and clinical safety assessment template for various organisations. This approach aims to empower clinicians to become key stakeholders in the deployment of large LLMs in clinical settings.

## Section: Methods

We propose a multi-component framework to evaluate hallucinations and omissions in clinical documentation generated by LLMs. Central to our approach is the concept of “clinician in the loop”. Given their expertise, clinicians are uniquely positioned to identify clinical errors made by the models, making their involvement essential. A specialised annotation platform (CREOLA) was developed to facilitate clinician labelling for each experimental dataset.

Experimental design: Our experiments systematically assessed how various prompting techniques and workflow structures influenced the accuracy and reliability of clinical notes derived from primary care consultation transcripts. Typical parameters varied in our experiments included the complexity and specificity of prompts (such as the addition of structured sections, negations, or perspective changes), as well as the number of LLM calls, such as introducing an additional revision step through a secondary LLM call. For consistency and reproducibility, we used OpenAI’s GPT-4 (GPT-4-32k-0613), setting the seed to 210, temperature to 0, and a top-p value of 0.95 to accommodate clinical language complexities.

All prompts used are detailed in Supplementary Materials, Table 4. To achieve a meaningful clinical comparison of efficacy and safety in a data-driven way, our framework relies on the definition of a ‘baseline’ experiment against which to compare results. The baseline experiment must use the same input data points as the new experiment. To clearly attribute an experiment’s results to a specific change, we aim only to alter one parameter from the baseline experiment configuration at a time.

We used different methodologies to assess and improve model output as described below:

Model Improvements: This outlines modifications to individual LLM calls within our workflow while preserving the same overall structure. Common modifications include the prompt, the model used for the call, or the model hyperparameters, such as maximum output tokens (Table 1).

Workflow Improvements: We implemented changes to explore new methods for generating a specific type of output. For instance, in our clinical note generation based on a transcript, we decided to extract a list of facts from the transcript before making a single call to the LLM for the final note (Supplementary Table 1). We then evaluated how this approach affected the frequency of hallucinations and omissions (Figs. 9 and 10). Additionally, we included an extra LLM call in some experiments to improve the quality of the output (Supplementary Fig. 1).

Clinician vs LLM generated notes: Several members of our clinical team were tasked with creating notes based on consultation transcripts. We then utilised the framework to identify any hallucinations and omissions in these notes, which allowed us to compare the clinician-created notes with those generated by the language model. Results shown in supplementary Fig. 3, Experiment 17.

Guidance for assessing the level of harm

The likelihood of a hazard occurring

This figure illustrates the scoring of clinical risk based on the likelihood of an incident occurring and the severity of harm it may cause.

Calculating the likelihood of an error occurring in the text output

To facilitate clinician review, the closest sentence matches (highlighted in yellow) for each portion of the text under review were extracted from the counterpart document. In the case of hallucinations, portions of text in the note were compared to the consultation (a), whereas for omissions, portions of the transcript were compared against the note (b).

## Section: Methods › Summary of experimental approaches in LLM-based note summarisation

Our study evaluated various approaches to prompt design and output structuring for LLM-based clinical notes. The experiments were designed to iteratively refine the model’s ability to produce accurate, structured, and clinically relevant summaries. The key methodological approaches across our 18 experiments are summarised below:

The likelihood of a hazard occurring

This figure illustrates the scoring of clinical risk based on the likelihood of an incident occurring and the severity of harm it may cause.

Calculating the likelihood of an error occurring in the text output

To facilitate clinician review, the closest sentence matches (highlighted in yellow) for each portion of the text under review were extracted from the counterpart document. In the case of hallucinations, portions of text in the note were compared to the consultation (a), whereas for omissions, portions of the transcript were compared against the note (b).

## Section: Methods › Summary of experimental approaches in LLM-based note summarisation › Baseline prompts (Experiments 1 and 2)

These were the initial prompts we had in our product prior to adopting the framework. We used these as a benchmark against which the later prompts were compared.

## Section: Methods › Summary of experimental approaches in LLM-based note summarisation › Structured prompts (Experiments 3, 7, 8, and 4)

Prompts were organised into three components: base (context and goal setting), template (content and structure), and style (formatting). Experiment 3 was a customisation experiment to test a new prompt structure (base, template, style preferences) for generating custom notes based on a transcript. Experiment 7 introduced a first-person perspective in generated notes. Experiment 8 refined the style section by incorporating negations and an “unknown” category for problems not explicitly mentioned in transcripts. Experiment 4 tested an enhancement to the baseline SOAP (Subjective, Objective, Assessment, Plan) note by improving medication record representation.

## Section: Methods › Summary of experimental approaches in LLM-based note summarisation › Atomisation (Experiment 5)

This method used a chain-of-thought prompt to extract atomic facts from transcripts to ensure the precise organisation of clinical details. The approach facilitated structured extraction, breaking down information into fundamental components.

## Section: Methods › Summary of experimental approaches in LLM-based note summarisation › Function calls & JSON-based output (Experiments 6, 9, 10, 11)

LLMs were instructed to generate responses in structured JSON format instead of free text. This structured format was optimised for integration with primary care electronic health record systems. Successive experiments refined style handling, negation accuracy, and clinical specificity, progressively reducing hallucinations.

## Section: Methods › Summary of experimental approaches in LLM-based note summarisation › Structured prompt + LLM revision step (Experiments 14 and 15)

We added a second LLM pass to review and refine outputs based on structured prompting. Experiment 14 built on Experiment 11 with a revision step to improve SOAP notes and introduce an “unknown” option for missing details. Experiment 15 applied this process to a ‘Bad SOAP’ note, containing hallucinations and omissions, to evaluate how well errors could be mitigated.

## Section: Methods › Summary of experimental approaches in LLM-based note summarisation › New note generation approach (Experiment 16)

A novel template-driven method was introduced for generating customised outputs. However, comparison with baseline results (Experiment 8) revealed an increase in major hallucinations and minor omissions, highlighting potential trade-offs.

## Section: Methods › Summary of experimental approaches in LLM-based note summarisation › Clinician vs. LLM comparison (Experiment 17)

In this experiment, clinicians manually created notes based on medical transcripts. These notes were then assessed for hallucinations and omissions, providing a benchmark against LLM-generated content. Interestingly, findings suggested slightly more hallucinations in clinician-written notes but fewer omissions, highlighting key differences in human vs. LLM-generated summaries.

## Section: Methods › Summary of experimental approaches in LLM-based note summarisation › Experiment 18

In this experiment, we assessed the performance of the notes within the publicly available ACI Bench dataset.

Hallucination and Omission Taxonomy: We follow the conventional AI literature and taxonomise LLM errors into two types 1) hallucinations, which are instances of text unsupported by the associated clinical documentation, and 2) omissions21, which are instances where relevant details are missed in the supporting evidence. Furthermore, inspired by protocols in medical device certifications57,58, we categorise errors as either ‘major’ or ‘minor’, where major errors can impact on the diagnosis or the management of the patient if not corrected.

To make our categories more granular, we propose to divide hallucinations into four categories: (1) fabrication, occurring when the model produced information that was not evidenced in the text, (2) negation, occurring when the model output negates a clinically relevant fact, (3) causality, occurring when a model speculates the cause of a given condition without explicit support from the text, and (4) contextual, occurring when the model mixes topics otherwise not related to the given context.

In the case of omissions, we further divide them into sections: (1) current issues, occurring when details about the current presentation were omitted, (2) PMFS (past medical history, medication history, family and social history), occurring when details about the past medical history, medications including allergies, family and social history, including drinking and smoking, were omitted, and 3) information and plan: when discussions and explanations of the condition and management plans were omitted. Examples of each of the sub-categories are provided in the Supplementary Materials.

Experimental Structure and Annotation Protocol: Here, we define a process to assess how model parameters affect the model outputs and clinical safety. To do this, we define “experiments”, which are parametrised by (1) the number of data points processed by the LLM, (2) the type of data the LLM will ingest, (3) the model configuration (type of model, random seed, temperature,…), (4) the prompt used to obtain an LLM output, and (5) the number of clinicians which must review the data point for clinical errors.

Given an experiment configuration, we extract model outputs from the input data and store the results in a database with the associated experiment metadata. We task annotators to classify whether given sub-sections of the output contain hallucinations or omissions according to our taxonomy, and explain in free text the reason for classification. The annotators were volunteer doctors who were paid £5 per note for annotations. Recognising the subjectivity inherent in annotation, we require annotation by at least two clinicians for each input-output pair. This step is followed by a consolidation step, i.e. a detailed review by our internal team of senior clinicians, ensuring a consistent evaluation of all annotations.

Clinical Safety Assessment: Recognising that safety assessment is a crucial part of using any medical technology, we designed a safety evaluation framework of the LLM outputs based on the framework used for evaluating a medical device57,58. Overall, this assessment involves estimating the likelihood of an error happening (Table 3) in conjunction with the potential impact of the error on the clinical outcome if it does occur. Table 4 shows the classification of the level of harm, and Fig. 14 presents the estimation of risk based on the likelihood and consequences of an event.

To maintain consistency in assessing the likelihood of hallucinations and omissions in each experiment, we created a percentage-based metric for their occurrence across experiments, as detailed in Supplementary data 1. ‘Very High’ likelihood represents scenarios where errors were very common (>90%), whereas ‘Very Low’ likelihood was associated with situations where errors were rare (<1%). For the ‘Medium’ likelihood category, which covers 10–60%, we used a broader range to accommodate the output variability and the understanding that some errors may be less predictable or depend on context (Table 5).

CREOLA, Clinical Review of LLMs and AI: We combine the experiment design, hallucination and omission taxonomy, and clinical safety evaluation in a platform we denote CREOLA, short for Clinical Review of LLMs and A1 (pays tribute to Creola Katherine Johnson59, a pioneering human computer at NASA. Just as human computers were integral to the safe landing of Apollo moon missions, clinicians play a vital role in safely integrating AI technologies into clinical practice).

The platform is used to identify resultant changes in generated clinical documentation arising from changes to processes in LLM architecture. As illustrated in the “experimental structure”, these changes could involve—but are not limited to—the type of model used or prompts used to obtain outputs. The platform was hosted as a Streamlit web application (https://creola.tortus.ai/); the annotation user interface is displayed in Fig. 15.

Annotator recruitment: As outlined earlier, our framework requires annotators to review model outputs. Clinicians are uniquely skilled in critically assessing the veracity of clinical facts in the text. Therefore, we ask clinicians to annotate errors for our experiments. Annotators could register to contribute to the annotation through the CREOLA platform. To ensure annotators had a good understanding of the process, one-to-one tuition was initially provided by the study team. As the number of annotators grew, a short online course was developed to explain the annotation process, followed by a questionnaire to ensure a comprehensive understanding of the material. The annotators were only able to participate if they completed the questionnaire correctly. The annotators could contact the study teams with any questions through the CREOLA platform in order to ensure any problems in the platform were dealt with promptly.

The likelihood of a hazard occurring

This figure illustrates the scoring of clinical risk based on the likelihood of an incident occurring and the severity of harm it may cause.

Calculating the likelihood of an error occurring in the text output

To facilitate clinician review, the closest sentence matches (highlighted in yellow) for each portion of the text under review were extracted from the counterpart document. In the case of hallucinations, portions of text in the note were compared to the consultation (a), whereas for omissions, portions of the transcript were compared against the note (b).

## Section: Date availability

We have used data from Primock and ACI bench which are publicly available clinical transcripts and notes (references in the main text)

## Section: Supplementary information

Supplementary Materials

Supplementary Data 1

## Section: Acknowledgements

The authors would like to thank the many physicians who helped with our CREOLA experiments and the annotation of the clinical transcripts and notes. No funding has been received for this study.

## Section: Author contributions

D.P., E.A., M.D., N.M., S.K. and J.B. contributed to the concept, design and execution of the study. M.D. and S.K. built the CREOLA platform and with NM designed the various prompts and experiments. MD analysed all the results and prepared the figures. E.A. and N.M. wrote, reviewed and revised the paper. E.A. and D.P. designed the clinical safety framework, reviewed all the annotations and scored the impact of errors on clinical safety. JAY provided expert advice on paper writing and direction and contributed to significant paper revision and rewriting. E.A., J.A.Y., M.D., N.M., S.K., J.B. and D.P. contributed to the review and revision of the paper.

## Section: Code availability

We have added all our prompts used in the supplementary materials of the article. As explained in the methods section, we used OpenAI’s GPT-4 (GPT-4-32k-0613) as the LLM for all our experiments.

## Section: Competing interests

D.M. is the CEO of the company Tortus AI and all authors were employees of Tortus AI at the time of the writing the paper (M.D., N.M., S.K. and J.B. as full time and E.A. part time, J.A.Y. full time employee at the time of revision). The authors declare no competing interests.

## Section: Supplementary information

The online version contains supplementary material available at 10.1038/s41746-025-01670-7.

## Section: Associated Data

Supplementary Materials

Supplementary Data 1

## Section: Associated Data › Supplementary Materials

Supplementary Materials

Supplementary Data 1

## Section: Associated Data › Data Availability Statement

We have added all our prompts used in the supplementary materials of the article. As explained in the methods section, we used OpenAI’s GPT-4 (GPT-4-32k-0613) as the LLM for all our experiments.


---

# A scoping review of artificial intelligence applications in clinical trial risk assessment

- **Authors:** Douglas Teodoro, Nona Naderi, Anthony Yazdani, Boya Zhang, Alban Bornet
- **Issuer:** NPJ digital medicine
- **Type:** Scientific article
- **Published:** 2025-07-30
- **Language:** en
- **DOI:** 10.1038/s41746-025-01886-7
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40731070/
- **Licence:** CC-BY

## Section: Abstract

AbstractArtificial intelligence (AI) is increasingly applied to clinical trial risk assessment, aiming to improve safety and efficiency. This scoping review analyzed 142 studies published between 2013 and 2024, focusing on safety (n = 55), efficacy (n = 46), and operational (n = 45) risk prediction. AI techniques, including traditional machine learning, deep learning (e.g., graph neural networks, transformers), and causal machine learning, are used for tasks like adverse drug event prediction, treatment effect estimation, and phase transition prediction. These methods utilize diverse data sources, from molecular structures and clinical trial protocols to patient data and scientific publications. Recently, large language models (LLMs) have seen a surge in applications, featuring in 7 out of 33 studies in 2023. While some models achieve high performance (AUROC up to 96%), challenges remain, including selection bias, limited prospective studies, and data quality issues. Despite these limitations, AI-based risk assessment holds substantial promise for transforming clinical trials, particularly through improved risk-based monitoring frameworks.Subject terms: Risk factors, Predictive medicine, Machine learning, Drug safety, Drug discovery, Drug discovery and development

## Section: Introduction

Clinical trials are key for evaluating the safety and efficacy of novel drugs and therapies1,2. Recent estimates of clinical trial failure show an increase for various phases, and the average cost of a successful molecular entity has trended significantly upward for decades3–5. However, navigating the intricate landscape of potential risks associated with the execution of clinical trials can be a daunting6 but nevertheless required task. Clinical trial risks encompass not only the well-being of participants (safety) and the ability of the intervention to deliver intended benefits (efficacy) but also the smooth and efficient execution of the trial itself up to drug approval (operational effectiveness)4,7,8. Identifying and mitigating these diverse risks throughout the trial process is crucial for improving patient safety as well as ensuring the integrity and ultimate success of the research enterprise.

Assessing risks in clinical trials presents several challenges both before and during the research process9,10. Firstly, ensuring adequate participant safety and informed consent remains paramount, requiring thorough evaluation of potential adverse effects and mitigation strategies11. Secondly, maintaining trial integrity amidst evolving scientific knowledge and external factors demands continuous monitoring and adjustment of risk assessments to uphold data validity and ethical standards11,12. Lastly, meeting regulatory and compliance obligations adds a layer of intricacy, necessitating careful adherence to protocols and guidelines to minimize legal and reputational risks while facilitating meaningful research outcomes5. Balancing these concerns is essential for effective risk management in clinical trials, safeguarding both participant well-being and scientific integrity throughout the research journey.

Research shows that artificial intelligence (AI) holds significant potential to enhance risk assessment in clinical trials13 by leveraging data-driven insights to improve safety, efficacy14, and operational effectiveness15 throughout the research lifecycle. AI algorithms can analyze vast amounts of data from various sources, including electronic health records, genomic data, and real-world evidence, to identify potential safety concerns, such as adverse events or drug interactions, more efficiently than traditional methods16. Additionally, AI-driven predictive models can assess the efficacy of interventions by analyzing complex patterns in patient data, aiding in the identification of promising treatments and patient subpopulations for targeted therapies17. Furthermore, AI-powered tools hold significant potential to streamline operational processes by optimizing trial design, patient recruitment, and data collection. These advancements increase the efficiency and cost-effectiveness of clinical research18.

Several reviews address the emerging potential and challenges of using AI in clinical trials from various perspectives. The works of Askin et al.19 and Harrer et al.13 offer comprehensive overviews of opportunities of AI for improved efficiency, recruitment, and faster trial design, while also acknowledging ethical concerns, data limitations, and regulatory hurdles. Weisller et al.20 take a multi-stakeholder approach, exploring machine learning applications across various trial phases. They acknowledge the need for more evidence and address ethical and philosophical barriers. Zame et al.21 focus on the specific challenges of health emergencies caused by pandemics. They demonstrate how machine learning can aid in predicting outcomes, repurposing drugs, and optimizing trial design in these urgent contexts. More recently, Ghim and Ahn examined the diverse roles that large language models (LLMs) can play in clinical trials, focusing on aspects such as improving the matching of patients to trials and aiding in technical writing tasks22. Other reviews, such as the works of Paul et al.23 and Patel and Shah24, either broadly discuss AI and machine learning in drug discovery, development, repurposing, clinical trials, and more, or focus on intervention safety14, such as the work of Basile et al.25. Finally, the review of Feijoo et al.15 analyzed specific operational risks within trials. Still, the literature lacks a scoping review highlighting the specific role of AI in the assessment of risks in clinical trials at large, particularly in light of recent advances in the field of machine learning.

To bridge this gap, this work reviews the scope of the current literature on the application of AI methods in clinical trial risk assessment. More specifically, we aim to answer the following research questions:

The scoping review includes peer-reviewed articles published in English and was conducted in electronic databases, including PubMed, Web of Science, and Google Scholar. The review focuses on studies that apply AI algorithms to predict risks in clinical trials, including safety-, efficacy-, and operational-related risks, as in the framework proposed by Badwan et al.14. Overall, it provides a comprehensive overview of the current state of AI in clinical trial risk prediction, and our findings could contribute to the development of more effective and efficient risk prediction strategies for clinical trials.

## Section: Results

The initial search yielded 4328 records from PubMed (n = 1605), Web of Science (n = 1086), and Google Scholar (n = 1628). After removing 1026 duplicates, 3302 records were evaluated for eligibility, with 3108 being excluded and 2 not retrieved for full-text analyses. Of the remaining 192 records, 50 were excluded after full-text assessment, resulting in a final selection of 142 studies. The study selection flowchart is shown in Fig. 1. The full lists of records identified, screened, and included for review are provided in Supplementary Data 1.

From the 4,328 manuscripts identified during the search phase, 3302 titles and abstracts were screened after de-duplication, and 194 full texts. A total of 142 studies were included for full-text analysis.

AI applications can be categorized into safety, efficacy, and operational risk assessment. They follow a typical three-step analysis approach: representation, learning, and prediction (or inference). In the first step, clinical trial-related information, such as compound, participants, and protocol, is encoded as vectors. In the second step, models are learned to infer risks. In the last step, different risk types are predicted, and performance metrics are obtained.

Overview of the studies identified, classified by risk and application

Distribution of published studies a over time, and categorized by b subject area, c country, and d venue type. The drop in the number of studies in 2024 is due to the cut-off date - 15.07.2024 - in the study selection criteria.

a Number of studies focused on phases I-IV. b Number of phases per study. c Conditions in condition-specific studies. d Safety categories in safety-specific studies.

a Trends of the different types of machine learning approaches for risk prediction of clinical trials. b Approaches used for the different risk assessment tasks. c Algorithms with results published in at least 10 risk assessment studies. d Trends in utilizing large language models for clinical trial risk assessment. The drop in the number of studies in 2024 is due to the cut-off date - 15.07.2024 - in the study selection criteria.

a Distribution of studies using (only) public and (at least one) private dataset. b Number of compounds, participants, and protocols used to train and evaluate models. c Top-10 metrics used in clinical trial risk assessment. d Number of reported metrics per study.

Main datasets used for safety, efficacy, and operational risk assessment studies

a Model performance across ADE (safety), outcome (efficacy), and phase success (operational) risk assessment using SIDER, individual trial data, and clinical trial protocols, respectively. b Number of instances used in the ADE, outcome, and phase success prediction tasks. Transparent Horizontal lines in (a) represent the median performance for each prediction task: ADE (red), outcome (grey), and phase success (blue).

## Section: Results › What types of risks in clinical trials can AI methods be used to predict?

After the full-text analysis of the included articles, we categorized AI applications based on the type of clinical trial risk they address (Fig. 2). To do so, we followed the framework proposed by Badwan et al.14, which describes three main phases in which AI methods can be used for risk prediction in clinical trials: toxicity, efficacy, and approval. In our analysis, we generalize the toxicity application to overall safety risk and consider operational risk instead of approval so that more fine-grained risk analysis can be taken into account, such as phase transition. An overview of the studies included in the review, categorized by risk type, is presented in Table 1.

AI applications can be categorized into safety, efficacy, and operational risk assessment. They follow a typical three-step analysis approach: representation, learning, and prediction (or inference). In the first step, clinical trial-related information, such as compound, participants, and protocol, is encoded as vectors. In the second step, models are learned to infer risks. In the last step, different risk types are predicted, and performance metrics are obtained.

Overview of the studies identified, classified by risk and application

Distribution of published studies a over time, and categorized by b subject area, c country, and d venue type. The drop in the number of studies in 2024 is due to the cut-off date - 15.07.2024 - in the study selection criteria.

## Section: Results › What types of risks in clinical trials can AI methods be used to predict? › Safety

As experimental treatments are being tested for the first time in humans, there may be unknown safety risks that are not fully understood until the trial is underway. The safety risk assessment category (Fig. 2 - left) encompasses AI applications that, given a drug or compound, predict safety risks that can cause unexpected or severe adverse events to study participants, ranging from mild discomfort to serious health complications before the pharmacological intervention26–80. Safety risk studies can be further subdivided into three predictive application use cases: adverse drug event (ADE), severity, and toxicity. In ADE prediction26–43, AI models are designed to predict the occurrence of ADEs, that is, injuries resulting from the use of a drug81. These methods are usually multi-class, multi-label classifiers that infer the occurrence of adverse event categories, such as those proposed by the MedDRA terminology82. Differently, methods for ADE severity prediction43–49 are usually binary classifiers that aim to infer the severity of ADEs, such as serious vs. non-serious or death vs. non-death events. Similarly, toxicity prediction methods50–80 are often binary classifiers that predict whether a drug or compound will be toxic to an organ, such as methods for predicting drug-induced liver injury (DILI)51,56,59,61,63–68,70,73,79.

## Section: Results › What types of risks in clinical trials can AI methods be used to predict? › Efficacy

Efficacy risk assessment in clinical trials is the process of evaluating potential risks that could hinder the successful demonstration of a drug or treatment’s effectiveness (Fig. 2 - center). AI applications within this category focus on predicting drug response, outcome, survival, and treatment effect47,83–127. In drug response applications, methods predict the potential for a drug to exhibit varying levels of efficacy across different patient populations or under specific conditions, often evaluated using in vitro models like cell lines to predict drug concentration and response83–93. In outcome prediction, the likelihood of a patient achieving a desired clinical outcome (e.g., disease remission, improved quality of life) following treatment is estimated94–106. These methods are typically assessed using binary classification tasks that predict the probability of response or non-response. In survival (or time-to-event) prediction, methods are specifically designed to analyze time-to-event data, such as time to death, disease progression, or recurrence47,86,90,92,107–118. They are particularly suited for risk prediction in the presence of censored data, where the event of interest might not have occurred for some individuals within the study period. Lastly, methods for treatment effect estimation128 quantify the differential impact of treatment on patient outcomes compared to a control group47,85,107–109,114,116,119–127. Unlike survival analysis, which explicitly models time-to-event data and competing risks, treatment effect estimation can be applied to a variety of outcomes, such as binary outcomes (e.g., disease remission vs. no remission) or continuous outcomes (e.g., blood pressure). Notable examples of studies predicting treatment effect include the works of Wang et al.123 and Qi and Tang121. Wang et al.123 estimates treatment effect by employing response-adaptive randomization within clinical trials. This adaptive allocation, guided by predicted treatment efficacy via traditional machine learning, allows for a real-time estimation and optimization of treatment effect. Differently, Qi and Tang121 estimate individualized treatment effects using a two-stage deep learning framework to predict Phase 3 clinical trial results trained on Phase 2 data. To estimate individualized treatment effects, the model predicts outcomes for both the planned treatment and a simulated placebo (zero dose), with the difference between these predictions representing the individual treatment effect.

## Section: Results › What types of risks in clinical trials can AI methods be used to predict? › Operational

Operational risk in clinical trials refers to the potential for disruptions, delays, or failures that can impact the successful execution and completion of a study, and ultimately the approval by regulatory agencies (Fig. 2 - right). This category includes AI applications that assess the risk of the phase’s success, the likelihood of regulatory approval, or other operational factors, such as enrollment, duration, and site selection risk as well as informativeness of the protocol15,38,43,51,129–169. We categorized papers in the first two subcategories following the approach of Feijoo et al.15. In the likelihood of approval risk, AI applications aim to estimate the overall probability of a drug receiving regulatory approval, often based on the study protocol15,38,51,129–141. In phase success prediction, AI applications are designed to estimate the probability of advancing a specific phase (e.g., from phase I to II)15,43,142–162. In practice, methods predict whether a clinical trial will complete the study gracefully or terminate before completion. Lastly, we include in the other subcategory the remaining operation risks, such as enrollment, duration, informativeness, etc., as their number of references was limited148,150,163–169.

In Fig. 3, we provide a high-level overview of the studies included in the analyses according to their publication date (Fig. 3a), scientific subject area (Fig. 3b), country of publication (Fig. 3c), and type of publication venue (Fig. 3d). We notice a growing interest in risk assessment of clinical trials based on AI, following an exponential growth trend (Fig. 3a). The research in the field has an increasing trend over the past decade, with an important jump between 2020 and 2021. While between 2013 and 2020, the majority of studies focused on safety risk assessment (safety: n = 18, efficacy+operational: n = 18), from 2021 onwards, there is a more even distribution in the three high-level risk categories (safety: n = 37; efficacy: n = 36; operational: n = 37). Studies are published in multidisciplinary journals, in the fields of Medicine, Computer Science as well as Biochemistry, Genetics and Molecular Biology, which ranked in the top 3 subject areas of journals and conferences (Fig. 3b). When considering the affiliation of the first author as the origin of the study, we notice a clear dominance of US institutions (n = 53), followed by China (n = 16) and the UK (n = 10); South Korea (n = 9) and Switzerland (n = 7) (Fig. 3c). Lastly, 90% of the studies are published in peer-reviewed scientific journals, and the remaining 10% in peer-reviewed conferences (Fig. 3d). The conference manuscripts were identified through Google Scholar searches. Out of the 14 manuscripts, three were presented at ICML workshops and three at EMNLP (n = 2) and ACL (n = 1) conferences. All the conference papers were classified within the Computer Science subject area, but also included multidisciplinary conferences like the MLHC, which spans both Computer Science and Medicine. Consequently, about one-third of the publications in the Computer Science category were presented at conferences.

Distribution of published studies a over time, and categorized by b subject area, c country, and d venue type. The drop in the number of studies in 2024 is due to the cut-off date - 15.07.2024 - in the study selection criteria.

## Section: Results › During which clinical trial phases and for which conditions are AI methods used to predict risks?

Since clinical trials face unique challenges depending on the phase and condition being investigated, we analyzed the distribution of studies based on these factors (Fig. 4). Operational risk assessment methods are distributed across phases I-IV (Fig. 4a) and tend to be phase-specific (n = 37) (Fig. 4b). In contrast, only a small fraction of safety risk assessment studies are phase-specific (n = 10 vs. n = 45 non-phase-specific), while efficacy risk studies are concentrated in phase III (n = 21 vs. n = 13 for phases I, II, and IV altogether). Regarding the condition studied in the clinical trial, most condition-specific risk assessment methods focused on neoplasms (n = 29), followed by mental disorders (n = 6) and infections (n = 5) (Fig. 4c). Most disease-specific studies focused on efficacy risk assessment (n = 41 out of 64). Figure 4d shows the distribution of adverse event-specific studies. All adverse event-specific studies are related to safety risk assessment (n = 55). Studies predicting the risk of hepatic disorders (i.e., DILI) (n = 16) together with those focused on multiple adverse events (n = 16) represent 32 out of the 56 identified safety works.

a Number of studies focused on phases I-IV. b Number of phases per study. c Conditions in condition-specific studies. d Safety categories in safety-specific studies.

## Section: Results › What specific AI methods and datasets are currently used to assess risks in clinical trials?

In Fig. 5, we show the AI methods used for risk assessment in clinical trials. Based on the algorithm and prediction task, they can be categorized into six classes of machine learning analysis paradigms (Fig. 5a):

Traditional machine learning includes algorithms that learn patterns from data to make predictions or decisions. These methods are often used with structured data extracted using feature engineering and are available from out-of-the-box toolkits, such as scikit-learn and caret in Python and R programming languages, respectively. As shown in Fig. 5a, traditional machine learning has been the dominant approach used in clinical trial risk assessment (safety: n = 37; efficacy: n = 23; operational: n = 23). They are used across all the clinical trial risk prediction tasks (Fig. 5b). Examples of traditional machine learning algorithms used in clinical trial risk assessment include random forest, which is the most used algorithm (n = 61), followed by support vector machines (SVM) (n = 28), and extreme gradient boosting (XGBoost) (n = 26) (Fig. 5c).

Deep learning is a subset of machine learning that uses artificial neural networks with multiple layers to learn complex patterns. Importantly, they can handle complex data types, such as free-text, images, graphs, etc., and extract features from the data automatically within a unified learning pipeline170. Together with traditional machine learning (n = 21), deep learning is the main approach used in operational risk assessment (n = 19) (Fig. 5b). Examples of deep learning algorithms used in clinical trial risk assessment include graph neural networks (GNNs)31,33,35,38,73,77,91,93,141,144,147,149,155,159 (n = 14), transformers43,75,137,144,147,149,152,154,155,158,159,162 (n = 12), and convolutional neural networks (CNNs)32,38,61,88,91,102,111,112,133,154 (n = 10) (Fig. 5c).

Survival analysis is a statistical learning method used to analyze time-to-event data, such as death or clinical trial termination, and includes methods such as the Cox proportional hazards model171. While survival analysis is often not considered a machine learning category in itself, we created a specific category for manuscripts including survival analyses as it accounts for time-to-event and for censoring data, which is an important feature in clinical trial risk analyses. Traditional and deep learning approaches can be combined with survival loss functions to provide survival curve predictions. Recent advances in deep representation learning have been expanded to include survival estimation.

For example, DeepSurv172 enhances survival estimation by substituting the classic log-linear parameterization in a Cox proportional hazards model with a multi-layer perceptron (MLP). Traditional survival analysis models assume a proportional hazard, where risk factors linearly affect the logarithm of risk. DeepSurv, using neural networks, models the log-risk function of the hazard function, enabling more complex, non-linear relationships, potentially yielding more accurate survival predictions. Thus, approaches categorized into this category for clinical trial risk assessment47,86,92,107–111,113–118,137,151,161,169 can be based originally on traditional statistical learning as well as on deep learning. Most survival analysis works use traditional methods (n = 10; the remaining n = 5 are based on deep learning) and are applied to efficacy risk assessment (n = 11) (Fig. 5b).

Causal machine learning is a specialized subset of AI that aims to identify cause-and-effect relationships between variables. This is distinct from traditional machine learning, which often focuses on identifying correlations. Causal models are used in clinical trial risk assessment to identify factors that directly influence a patient’s response to a treatment47,87,108,116,120,125. For instance, a causal model based on an MLP architecture, with a common trunk and two output heads, was used for modeling the potential outcome of treatment and placebo on disability progression in multiple sclerosis108. The common trunk learns shared covariate representations, while the output heads predict treatment and control outcomes. This design generates counterfactual predictions, approximating individual treatment effects through the difference of these outcomes. Shared feature learning followed by treatment-specific predictions captures both common and heterogeneous treatment effects, establishing a foundation for robust causal inference. Together with survival analysis, causal inference is gaining traction in clinical trial risk assessment, particularly for treatment effect risk assessment (n = 6) (Fig. 5b).

Two other AI approaches are used to predict risks in clinical trials: relational learning (n = 1) and quantum machine learning (n = 1). Relational learning is a classic AI technique that can handle data with complex relationships between entities. It includes methods such as inductive logic programming, which allows learning a concept definition from observations, i.e., sets of positive and negative examples, and background knowledge173. On the other hand, quantum machine learning is a nascent field that leverages quantum theory to model machine learning tasks. Both methodologies have been used to assess safety risks26,78. While relational learning did not increase in popularity, quantum machine learning has only recently been applied to assess clinical trial risks.

a Trends of the different types of machine learning approaches for risk prediction of clinical trials. b Approaches used for the different risk assessment tasks. c Algorithms with results published in at least 10 risk assessment studies. d Trends in utilizing large language models for clinical trial risk assessment. The drop in the number of studies in 2024 is due to the cut-off date - 15.07.2024 - in the study selection criteria.

## Section: Results › The rise of large language models

More recently, LLMs based on the transformer architecture have been successfully applied in clinical trial risk assessment43,75,77,137,144,147,149,152,154,155,158,159,162. In 2023, LLM-based approaches accounted for 7 of the 33 studies analyzed (Fig. 5d). On the other hand, the use of generative LLMs is still restricted, with only three studies between 2022 and July 2024. Ferdowsi et al.144 were the first to propose an AI method using LLM (encoder-based) to predict clinical trial risks. Their approach encoded sections of the clinical trial protocol using BERT, which were then fed into a GNN model to predict phase success risks. For safety risk assessment, the work of Morozov et al.75 used ProteinBERT174 to represent protein and predict toxicity. Katsimpras and Paliouras137 were among the first to propose generative LLMs to predict effectiveness risk using LLMs. Their approach was based on BART, an encoder-decoder model based on the transformer architecture. More recent examples of approaches using generative LLMs include inClinico158 (which was evaluated prospectively) and TWIN-GPT43. While the former used GPT-3.5 to extract clinical trial results from free-form text, such as publications and press releases, the latter explored the full power of LLM to create virtual trials and assess multiple risk types. To date, no approach based on LLM or transformers in general has been proposed in efficacy risk assessment.

## Section: Results › Data sources and performance metrics

Most studies assessing safety and operational risks used publicly available benchmarks to train and evaluate their models (safety: n = 50; operational: n = 37) (Fig. 6a) while efficacy studies used mostly private datasets (n = 32). These studies used datasets containing a median of 803 compounds, 1087 participants, and 17'538 protocols (Fig. 6b), which are the main information types used for risk inference in safety, efficacy, and operational studies, respectively. Models were mostly evaluated using the area under the receiver operating characteristic (AUROC) curve (n = 94), with accuracy (n = 56) and recall (n = 51) completing the top 3 metrics (Fig. 6c). Only one metric in the top 10 reported, root mean square error (RMSE), refers to regression tasks. The remaining 9 metrics are used in classification tasks. Safety and operational studies reported a median of 3 metrics per study, while efficacy studies reported 2 (Fig. 6d).

Table 2 lists the most used datasets in safety, efficacy, and operational risk assessment studies. For safety risk, the main data source used was SIDER (Side Effect Resource)175, a comprehensive database of adverse drug reactions (ADRs) extracted from the FDA Adverse Event Reporting System (FAERS). Studies that used SIDER for safety risk assessment had a median number of 1063 compounds in the benchmark dataset, and the majority used only publicly available datasets (n = 20). The full list of datasets used in safety risk assessment is provided in Supplementary Table 1. The main dataset used in efficacy studies was individual trials, with a medium number of only one trial and 1'250 participants per study. Most efficacy studies (n = 29) used at least one private evaluation dataset. As for safety risk studies, operational risk used mainly public data sources (n = 33), with most studies using data from clinicaltrials.gov.

Another interesting type of dataset used in clinical trials risk assessment is synthetic data created via computational simulations to represent virtual trials27,37,43,52,54,69,87,92,119,120,176. Virtual trials176, or in silico trials, employ computational models to simulate clinical studies, predicting the safety27,37,43,52,54,69 and efficacy87,92,119,120 of medical interventions.

In these works, synthetic datasets are created using purely analytical frameworks, for example, of treatment effect69,120, or in combination with real-world clinical trial results27,37,43,52,54,87,92,119. Notable examples of virtual trials include the study of Sové et al.92, which employs a quantitative systems pharmacology (QSP) model to conduct a virtual clinical trial of nivolumab and ipilimumab in hepatocellular carcinoma. The model simulates immune and cancer cell interactions, generating virtual patients calibrated to clinical trial data. Retrospective analyses and machine learning techniques are then used to predict biomarker importance, demonstrating the QSP model’s ability to replicate observed clinical outcomes. Differently, Wang et al.43 use a generative LLM to create a digital twin model that can retain the features of the target patient. Their generator simulates personalized patient trajectories based on the real record, predicting the next step in the patient trajectory in an auto-regressive manner.

a Distribution of studies using (only) public and (at least one) private dataset. b Number of compounds, participants, and protocols used to train and evaluate models. c Top-10 metrics used in clinical trial risk assessment. d Number of reported metrics per study.

Main datasets used for safety, efficacy, and operational risk assessment studies

## Section: Results › How effective are AI methods in evaluating risks in clinical trials?

Due to the different prediction tasks (Table 1), metrics (Fig. 6c), and benchmark datasets (Table 2) used in clinical trial risk assessment, it is hard to compare the effectiveness of AI methods quantitatively. In an attempt to have a minimally comparative view, we analyzed performance across the largest subset of experiments using the same prediction tasks, reporting metrics, and dataset type. Figure 7a shows the performance across ADE (safety), outcome (efficacy), and phase success (operational) prediction tasks using SIDER, individual trial, and clinical trial protocol datasets, respectively, for studies reporting performance using the AUROC metric. In this subset, the top 3 ADE prediction studies all reported AUROC above 90%, with Masumshah et al.30 achieving the highest performance (96.6% AUROC), followed by Zhao et al.31 (93.1% AUROC), and Galeano et al.28 and Zhong et al.42 (92.0% AUROC). The top 3 outcome prediction models100,103,104 achieved AUROC between 84.0% and 87.4%, with Lei et al.103 achieving the best performance. For phase success prediction, Ferdowsi et al.144,149,155 rank in the top 3, with AUROC performance varying between 92.3% and 92.7%. For this subset of studies, the median number of instances in the datasets used in phase success prediction (n = 75,174 protocols) is two orders of magnitude higher as compared to ADE (n = 766 compounds) and outcome (n = 235 participants) prediction experiments.

a Model performance across ADE (safety), outcome (efficacy), and phase success (operational) risk assessment using SIDER, individual trial data, and clinical trial protocols, respectively. b Number of instances used in the ADE, outcome, and phase success prediction tasks. Transparent Horizontal lines in (a) represent the median performance for each prediction task: ADE (red), outcome (grey), and phase success (blue).

## Section: Results › What are the key limitations of AI methods in predicting clinical trial risks? › Selection bias

Data used in clinical trial risk assessment might not be representative of the entire population of interest, leading to biased results. In safety risk studies, the number of compounds and drugs used in the experiment is significantly limited compared to the estimated drug-like chemical space (O(103) vs. O(1060))177 or, more concretely, to the number of compounds in PubChem (O(103) vs. O(108)). Similarly, efficacy approaches are evaluated using individual trials, with a median number of trials per study equal to one (Table 2), that is, it is unclear if these methods will generalize to different interventions or conditions.

## Section: Results › What are the key limitations of AI methods in predicting clinical trial risks? › Evaluation strategy

Datasets used in clinical trial risk assessment are often imbalanced. For example, for a given drug, the number of negative ADE cases is far greater than the number of positive cases. Thus, results should be reported using metrics robust to class imbalance, such as F1-score, Matthew’s correlation coefficient (MCC), and weighted accuracy. However, as shown in Fig. 6c, the top 3 most reported metrics are not robust to highly imbalanced datasets and could present high scores just by predicting the majority class.

## Section: Results › What are the key limitations of AI methods in predicting clinical trial risks? › Data quality and availability

While operational risk studies tend to use large and representative sets of clinical trials, they often lack access to real-world clinical trial data, being mostly based on the design protocol (Table 2). Similarly, most safety risk studies ignore key factors, such as dosage and route of administration, when predicting toxicity and ADE risks.

## Section: Results › What are the key limitations of AI methods in predicting clinical trial risks? › Retrospective studies

Despite some notable examples103,158, most clinical trial risk assessment studies use only retrospective data. While retrospective studies provide valuable insights into AI applications in clinical trial risk assessment, they may not be generalizable to different compounds, populations, or clinical trial contexts. Yet, some prospective studies used proprietary clinical trial datasets158, hindering their reproducibility. Overall, these issues limit the applicability of the findings to broader clinical trial risk assessment.

## Section: Results › What are the key limitations of AI methods in predicting clinical trial risks? › Siloed risk models

Clinical trial risks are assessed separately, even though they are interconnected. A minimal dose (e.g., homeopathic) is unlikely to cause safety risks, but also to statistically demonstrate efficacy against the condition under study. Similarly, interventions with severe safety risks might lead to operational trial termination. Despite these interdependencies, only a few studies38,43,47,51, including TWIN-GPT43, consider a more holistic approach to clinical trial risk assessment. Nevertheless, they only investigate safety and a second category combined (efficacy47; operational38,43,51), and no study to date integrates the three risk assessment categories.

## Section: Discussion

In this scoping review, we analyzed the existing literature on the applications of AI methods for predicting risks in clinical trials. Our review identified 142 studies describing safety (n = 55), efficacy (n = 46), and operational (n = 45) risk assessment applications published in peer-reviewed journals and conferences between January 2013 and July 2024. We notice a growing interest in the field, with an exponential growth trend between 2013 and 2024. On the modeling methodology, various AI approaches have been used, including traditional machine learning, deep learning, and causal machine learning, in many risk prediction tasks, such as ADE, treatment effect, and phase transition. More recently, there was a surge in the applications of LLMs, reaching around 20% of the studies in 2023. However, the number of studies using generative approaches remains minimal. Models were trained and evaluated using a variety of benchmark datasets, both public, such as SIDER and clinicaltrials.gov, and private, such as individual trial data. The risk prediction models achieved high performance on some specific tasks, with AUROC as high as 96%. However, issues such as selection bias, poor evaluation strategies, and lack of prospective studies hinder the applications of the proposed methodologies in real-world scenarios. Nevertheless, AI-based risk assessment for clinical trials seems a promising research avenue and, based on the identified trends, is expected to grow in the coming years. In particular, these models could be used to improve risk-based monitoring frameworks in clinical trials and extend their adoption, which is not widespread6.

Four potential reasons contribute to drug development failure: unmanageable toxicity, poor drug-like properties, lack of clinical efficacy, and lack of commercial needs with poor strategic planning178. These failure reasons can be categorized into the three high-level risk types outlined in this review: safety, efficacy, and operational. AI-based safety methods aim to predict safety risks associated with the intervention, including potential adverse events, toxicity (e.g., DILI and drug-induced kidney injury), and severity (e.g., serious ADE and mortality). Efficacy methods predict whether an intervention is effective in treating a condition. Methods for efficacy risk assessment were further subdivided into approaches for predicting drug response and treatment outcome, estimating the treatment effect of an intervention, and progression-free survival. Only one study considered combined safety and efficacy risks47. Lastly, in operational risk assessment, AI-based methods were used to predict whether a drug will be approved, which depends on demonstrating its safety and efficacy, as well as whether a trial will complete a phase. It is important to note that completing a trial phase does not necessarily demonstrate the intervention’s safety (e.g., serious ADE events might have been identified) or efficacy (e.g., outcome measurements do not differ statistically between different interventions). Additionally, AI-based methods were used to predict issues related to the quality of the protocol and the trial process, such as recruiting. A few studies combined safety and operational risk prediction38,43,51. Despite their interconnection, risk prediction studies are rather siloed. A possible research avenue would be using multi-task learning for estimating multiple risk types at once, given that relevant data is available. For example, Yazdani et al.179 use a multi-task (or joint) learning approach to identify and normalize ADE-related entities in clinical notes. Similarly, Tan84 uses multi-task learning to predict anti-cancer drug response. Multi-task learning methods typically combine the loss functions of different tasks to enhance data efficiency, reduce overfitting through shared representations, and accelerate learning by utilizing auxiliary information84,180. Thus, multi-task learning approaches could be employed to simultaneously and more effectively infer safety, efficacy, and operational risks.

The clinical trial process varies significantly according to the study phase. Thus, taking into account the phase but also experimenting across different phases is essential to capturing specific risks and generalizing to different scenarios. Interestingly, the majority of operational risk studies considered at least three phases (n = 27 vs. n = 18 for phases I, II, and non-phase-specific altogether), which could lead to better generalisability of such approaches as compared to the safety and efficacy AI-based risk assessment42,105, which are either non-phase-specific or focus on a single phase (Fig. 4b). As the potential efficacy of compounds is already assessed in phase II, efficacy models focusing only on phase III, i.e., the majority, are likely to be biased. A notable example of efficacy risk study across phases I-III is described by Lu et al.87, proposing an application of deep learning to predict drug concentration and response time course. All the identified safety risk assessment studies are non-phase-specific. While ADEs are heavily dependent on the drug and dosage, the study population, which is phase-specific, has a non-negligible impact82. Additionally, an interesting application of in-silico risk assessment is to avoid providing potentially toxic interventions to participants. Thus, applications of AI risk could focus on phase I studies. In this line, the study of Bedon et al.66 proposes a machine learning model to predict the maximum tolerated dosage.

AI methods are applied in a variety of prediction tasks for clinical trial risk assessment, including i) binary classification as in toxicity (safety), treatment outcome (efficacy), and phase transition (operational) predictions, ii) multi-class, multi-label classification as in ADE prediction (safety), and iii) regression as in drug response and survival (efficacy) predictions. They use different types of input data, such as molecular structure, clinical information as well as semi-structured free-text clinical trial protocols. As a result, many types of AI algorithms based on machine learning techniques have been investigated. Safety prediction methods require methods for representing molecular structure, but also relationships between drugs, genes, proteins, and ADEs. Thus, several studies leveraged the power of GNNs to capture these complex relationships and different modalities in an integrated machine learning pipeline31,33,35,38,77. Efficacy methods are often based on structured data derived from clinical trial results. As such, they tend to apply classic methods (including survival and causal learning) based on ensemble learning, such as random forest, gradient boosting machine (GBM), and XGBoost, for learning and inference85,92,94–96,98–101,103,105–107,109,110,113,114,116,117,119,122–127. Differently, in operational risk studies, the clinical trial protocol is often the focus of the analyses. Given the complex, semi-structured, free-text nature of the protocol, these methods tend to use deep learning, in particular, LLMs, to encode protocol information43,137,144,147,149,152,154,155,158,159,162. Indeed, apart from a few exceptions43,137,158, LLMs have been mostly used for textual representation (protocol, protein sequence, etc.) as dense vectors77,144,155. Natural language inference capabilities of LLMs have been little explored in this field.

Among the different AI-based risk assessment tasks, treatment effect estimation has a distinct character as it focuses on inferring causal impacts through simulated or real-world alternative scenarios. These studies bridge predictive machine learning and causal inference by employing machine learning models to generate counterfactual predictions, thus estimating treatment effects beyond mere correlational relationships. While having varied strategies85,108,119–127, the central approach across these studies is the use of machine learning to generate counterfactual predictions for treatment effect estimation. This involves training models to predict outcomes under both observed and alternative (or control) conditions, then computing the difference. This simulated or real-world counterfactual contrast quantifies the treatment’s impact, enabling the estimation of individual and heterogeneous effects, as demonstrated in various contexts from clinical trial simulations121 to real-world data applications122,124,127. This predictive approach facilitates the estimation of treatment effects by leveraging machine learning’s ability to model complex relationships and simulate hypothetical scenarios, as seen in response-adaptive randomization123, virtual patient cohorts120, and personalized trial applications121,125,126. Moreover, the emphasis on interpretability distinguishes these methods; they often utilize techniques that provide insights into the underlying causal mechanisms, such as feature importance measures and subgroup analyses, rather than solely relying on “black box” predictions, a distinctive feature of causal machine learning.

Another important research avenue identified in the review is risk assessment using virtual or in silico trials, which are created using synthetic data via computational simulations92,120,176. Synthetic data modeling biological processes and patient populations is particularly interesting as it allows for better interpretability of the results, which is often difficult with “black-box” machine learning models trained on real-world data. Moreover, these simulations generate outcome predictions, potentially reducing the time and cost of traditional clinical trials while addressing ethical considerations. Thus, these computational approaches offer a complementary strategy for evaluating risks of medical products that goes beyond real-world benchmark datasets. Nonetheless, this potential also raises concerns, including the possibility of amplifying biases and a lack of effective strategies for assessing data quality181.

We have identified some key limitations of existing AI-based clinical trial risk assessment studies. In particular, they include some selection biases and can have poor evaluation strategies, which can hinder their generalizability to different interventions or conditions and thus their real-world applications. Indeed, a recent study by Chekroud et al.105 found that machine learning accuracy for predicting patient outcomes is similar to chance when applied to out-of-sample trials. Despite the limitation of the study itself, which evaluates only one machine learning method (elastic net), being thus hardly generalizable to the ensemble of AI and machine learning methods, it gives some evidence of the limited generalizability of current AI studies for predicting efficacy risks. Moreover, for safety prediction, a recent study42 showed that advanced ADE prediction models do not differ significantly from a naïve classifier according to the AUROC metric, which is the main evaluation strategy used in this task. By only using the mean values of ADEs of known drugs to predict the ADEs for all the new drugs, the naïve model achieved 91% AUROC on the SIDER dataset, which is only 2 percentage points below the state-of-the-art model31.

Based on the identified limitations, several key recommendations can be made for future research in AI-based clinical trial risk assessment. First, data limitations for training and evaluating the models should be addressed. Researchers should increase the diversity and representativeness of datasets used in AI-based risk assessment, including data from real-world clinical trials and a wider range of compounds and outcomes, while ensuring high-quality data collection and annotation. For example, dosage and route of administration should be incorporated into safety risk assessment models to improve faithfulness to application scenarios, and large intervention-outcome scenarios should be considered. Moreover, evaluation strategies should be improved. Researchers should consistently employ evaluation metrics that are more robust to imbalanced datasets, such as F1-score, MCC, and weighted accuracy. Additionally, they should assess the generalizability of AI models to different interventions, conditions, and populations and on unseen data to demonstrate their real-world applicability. In this line, studies should move beyond retrospective analysis. Researchers should conduct prospective studies to establish causality and improve the generalizability of findings, as well as explore the use of real-time data, i.e., safety, efficacy, and operational data collected during the study, to enable continuous monitoring and risk assessment during clinical trials. Finally, a promising research avenue would be to integrate risk assessment categories. In this direction, AI models could be developed to simultaneously predict multiple risk types within the safety, efficacy, and operational categories. Thus, they would account for the interdependencies between different risk categories to provide a more holistic assessment.

This review has a few limitations. First, the field of AI is broad, which makes it challenging to identify the correct set of keywords for querying the databases. Some studies might focus on specific methodologies, e.g., SVM, XGBoost, and description logics, and do not mention in the abstract one of the high-level methodology-related keywords used in the search, i.e., AI, machine learning, etc. Thus, we might have missed some relevant studies. Despite that, we identified a large variety of modeling approaches, including even more classic AI methodologies, such as relational learning. Second, we took a strategic decision to guide our risk-related search keywords according to the application framework proposed by Badwan et al.14, which identified AI applications in clinical trials in three predictive areas: toxicity, efficacy, and approval. Instead, other viewpoints could be considered, for example, using components of risk-based quality management approaches6. This could be the subject of a specific and more targeted review. Finally, we were unable to fully answer one of the questions related to the effectiveness of the models for risk prediction due to the lack of common benchmarks and evaluation strategies used in the reviewed studies. We attempted to create a homogeneous set, focusing on specific tasks with common evaluation metrics and using the same benchmark datasets. Nevertheless, they are not comparable due to differences in the dataset used for training and evaluation, including size and content. Even so, these results provide a preliminary overview of the effectiveness of AI-based risk assessment in clinical trials.

In conclusion, this scoping review explored the potential of AI for risk assessment in clinical trials. We identified a rapidly growing field with diverse applications, focusing on safety, efficacy, and operational risks. AI models leverage various data sources, from molecular structures to clinical protocols, and employ techniques like traditional machine learning and, more recently, large language models. While some models achieve high performance, limitations exist. Selection bias and poor evaluation strategies hinder generalizability. Future research should address these issues by employing more diverse and representative datasets, incorporating real-world data, and focusing on generalizable evaluation metrics. Prospective studies and real-time (or continuous) data integration further hold promise. Additionally, exploring models that simultaneously predict multiple risk types could provide a more holistic assessment. Overall, AI holds significant promise for risk assessment in clinical trials, but further research is needed to ensure its real-world effectiveness.

## Section: Methods

We conducted this systematic scoping review between October 2023 and July 2024. For processing and reporting the results of this review, we followed the guidelines of Preferred Reporting Items for Systematic Reviews and Meta-Analyses Extension for Scoping Reviews (PRISMA-ScR) Guidelines182. The PRISMA-ScR checking list is provided in Supplementary Table 2.

Search keywords in different groups

Inclusion and exclusion criteria for studies

## Section: Methods › Search strategy and study selection

We collaborated with a health sciences librarian to develop a three-step search plan. Initially, we searched PubMed to locate key articles on risk assessment, clinical trials, and AI. These articles helped us create a comprehensive set of relevant keywords, organized into four categories: technology, application field, type of analysis, and task. We intentionally designed the keywords to be broad in order to enhance recall and provide a more comprehensive picture of the field’s scope. We combined the keywords within each group using the OR operator and then linked all the groups using the AND operator. The search keywords used in the process are listed in Table 3. We then adjusted the syntax to ensure it could be used across the other databases. The systematic search was carried out in three databases – Medline, Web of Science, and Google Scholar – using their default search settings. Note that for the search in Google Scholar, we split Group 3 into three subgroups as the full query exceeded the character limit of the API. For each subquery, we considered for analysis the first 750 articles retrieved.

Search keywords in different groups

## Section: Methods › Study eligibility criteria

In Table 4, we list the inclusion and exclusion criteria used in the screening and full-text analysis process:

Inclusion and exclusion criteria for studies

## Section: Methods › Dataset screening

We used Bibdesk to de-duplicate the results, sorting articles by key, title, and first author. Identified duplicated articles were manually checked. Then, we uploaded all the results to an online spreadsheet to make it easier for the team to review and extract information from titles, abstracts, and full texts. To ensure a convergent approach, two reviewers pilot-tested the screening of titles and abstracts on a random sample of 10 studies. After the pilot test, two independent reviewers examined each article. If they disagreed on whether to include a citation, a third reviewer would evaluate the citation, and we would then discuss it together to reach a consensus. We uploaded the full texts of potentially relevant articles to Zotero for further screening by two reviewers. Any differences in including or excluding full-text studies were resolved during a consensus meeting.

## Section: Methods › Dataset annotation

We randomly divided the articles included for full-text review among four researchers. Each researcher read the full-texts separately and used a standard spreadsheet to extract item information based on the CHARMS (Critical Appraisal and Data Extraction for Systematic Reviews of Prediction Modeling Studies) checklist183. The spreadsheet included study characteristics (authors, publication date, country of first author, subject area, journal or conference), and information about the source of data (data source and public availability), outcome to be predicted (type of risk analysis, prediction task, and ADE), candidate predictors (study phase and condition, compound, clinical trial data, and clinical trial protocol), sample size (dataset size and dataset type), model development (algorithm, model type, and training strategy), model performance (evaluation metrics), and results (performance on the test set). We piloted the template, added a “not available” option for some items, and included examples to enhance consistency and ease of use. After extraction, an independent reviewer normalized and consolidated the information.

## Section: Methods › Data analyses

We analyzed the data using Microsoft Excel for Mac (Microsoft Office 365, version Version 16.89.1). We used descriptive statistics like frequencies, medians, and ranges, and presented the data graphically and in tabular format as needed. We summarized the study characteristics, including the frequency and distribution of publication year, country of the first author, subject area, and type of publication venue. Additionally, we examined dataset and evaluation characteristics, such as mean/median size, frequency/distribution of phase, condition, ADE, and metrics, as well as model considerations, including the frequency/distribution of algorithms and training strategies, and performance.

## Section: Supplementary information

Supplementary Information

Supplementary Data 1

## Section: Acknowledgements

This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.

## Section: Author contributions

D.T. conceptualized the study, defined the methodology, performed the database searches and coordinated the screening process. D.T. also performed analyzed the data and authored the original draft. N.N. and D.T. performed the screening process. N.N., A.Y., B.Z., and A.B. extracted item information from full-texts. All authors reviewed and approved the manuscript.

## Section: Data availability

No datasets were generated or analyzed during the current study.

## Section: Competing interests

The authors declare no competing interests.

## Section: Supplementary information

The online version contains supplementary material available at 10.1038/s41746-025-01886-7.

## Section: Associated Data

Supplementary Information

Supplementary Data 1

## Section: Associated Data › Supplementary Materials

Supplementary Information

Supplementary Data 1

## Section: Associated Data › Data Availability Statement

No datasets were generated or analyzed during the current study.


---

# A scoping review of OMOP CDM adoption for cancer research using real world data

- **Authors:** Liwei Wang, Andrew Wen, Sunyang Fu, Xiaoyang Ruan, Ming Huang, Rui Li, Qiuhao Lu, Heather Lyu, Andrew E Williams, Hongfang Liu
- **Issuer:** NPJ digital medicine
- **Type:** Scientific article
- **Published:** 2025-04-07
- **Language:** en
- **DOI:** 10.1038/s41746-025-01581-7
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40189628/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThe Observational Medical Outcomes Partnership (OMOP) common data model (CDM) supports large-scale research by enabling distributed network analyses. However, the breadth of its adoption in cancer research is not well understood. We conducted a scoping review to describe the adoption of the OMOP CDM in cancer research. A total of 49 unique articles were included in the review, with 30 on the data analysis theme, and 20 on the infrastructure theme. This review highlighted that while the OMOP CDM ecosystem has enabled successful data support for cancer research, particularly for collaborative studies, ongoing model development and iterative improvement remain needed to fulfill additional research data needs. Expanding disease sites, specifically for rare cancers, integrating more diverse types of data sources, improving data quality, adopting advanced analytics methodology, and increasing multisite evaluations serve as important opportunities to facilitate secondary usage of observational data in future cancer research.Subject terms: Cancer, Data integration, Data processing, Standards, Epidemiology, Predictive medicine

## Section: Introduction

Cancer has been a major cause of premature death globally1 throughout the 21st century, prompting increasing research efforts and funding. Observational research has emerged as a powerful approach for generating hypotheses and uncovering unique insights into patient populations, treatments, and outcomes2,3. This methodology has significantly advanced clinical understanding and influenced medical practices4. Primary sources of observational health data include electronic health records (EHRs), administrative claims, hospital billing systems, clinical registries, and longitudinal surveys5. Given the extensive role of observational health data, a robust framework for the generation of this information is essential to complete effective cancer studies and deliver high-quality cancer care.

Multicenter studies are widely utilized in observational research to improve the generalizability of findings. Distributed research networks, such as the Observational Health Data Sciences and Informatics (OHDSI)6, the Agency for Healthcare Research and Quality-supported projects7, the National Patient-Centered Clinical Research Network (PCORnet)8 and the Electronic Medical Records and Genomics (eMERGE) network, have emerged in recent years to promote multicenter observational studies9. Among these efforts, OHDSI supplies both a common data model (CDM) and the concept representation (terminology) for standardization to support federated analytics, demonstrating great potential for large-scale, collaborative observational cancer studies10,11. The OHDSI network adopts the CDM developed as part of the Observational Medical Outcomes Partnership (OMOP) to represent data from disparate sources in a standardized format through data normalization processes. The OHDSI network’s CDM allows users to map data from disparate sources to a standardized format through data normalization processes. This enables a federated model, which allows individual data holders to maintain their patient-level databases locally, while allowing collaboration via systematic analytics, fostering diverse and geographically diverse patient cohorts, enhancing reproducibility, and ensuring patient confidentiality.

There have been two prior reviews on the role of OMOP CDM. One focused on the adoption of the OMOP CDM for observational patient data research between 2016 and 2021 and concluded that the relevance of the OMOP CDM is increasing regarding multi-country studies12. Another review of the literature from 2016 through 2021 explored the potential application of the OMOP CDM in cancer prediction, specifically on the role of genomic vocabulary extensions in AI-based prediction models13. This study found that the OMOP CDM can enable a decentralized use of AI in the early prediction and diagnosis of cancer, personalized cancer treatment, and the discovery of important biological markers. While these studies have established the potential for the OMOP CDM, the breadth of its adoption in cancer research is not well understood. This paper aims to address this gap by presenting a scoping overview of the OMOP CDM in the field of cancer research to identify key opportunities and highlight unexplored areas for future investigation.

## Section: Results

The complete article selection process is shown in Fig. 1. After identifying the included articles, the study team performed a comprehensive full-text review of the resulting 49 studies. There were 30 studies on data analysis and 20 studies on data infrastructure. Among them, one article (published in 2018) belonged to both themes14. All extracted data elements from the articles are provided in the Supplementary Data 1.

Flow diagram illustrating the PRISMA approach for the identification, screening, and selection of studies.

Article distribution is shown across publication year (a), data sources (b), publication year and geographic region (c), and cancer types (d).

Comparison of Infrastructure and Data analysis in data sources

Comparison of Infrastructure and Data analysis in cancer types

a Infrastructure theme, b Data analysis theme. The infrastructure theme (a) covered all 8 CDM tables in the data analysis theme (b), and additionally incorporated several more tables, including Care_site, Cohort, Episode, Episode_event, Fact_relationship, Location, Note, Note_NLP, Device_exposure, and Specimen. It also covered extensions of the OMOP CDM including Genomic_test, Imaging_series, Imaging_study, Target_gene, Variant_annotation, Variant_occurrence, and Vocabulary_extension.

A summary of papers in the infrastructure theme

Numbers refer to paper numbers. A global study is defined as a study that includes at least two countries, in contrast to a single-country study.

By geolocation (a), study cohort size (b), top in-network institutions (c), and top out-network institutions (d).

References for the study methods

Numbers refer to paper numbers. This figure illustrates the relationships between target domains, study designs, statistical methods, and CDM domain names used across all included data analysis papers.

Types of cancer research questions addressed in the disease target domain

## Section: Results › Overview analysis

The analysis of the included studies’ metadata revealed insights into the distribution and trends of the research across the two themes: Infrastructure and Data Analysis. (Fig. 2) Although articles were collected from 2010 onward, the first article included in our study was published in 2017. There was an increasing trend in the publication of data analysis papers from 2018 to 2022 (Fig. 2a). Figure 2b compares the data sources used between Infrastructure and Data Analysis studies. One article may include more than one data source. EHR data were the most frequently used data source across both themes. Claims data served as another important source, particularly for the data analysis studies. EHR data were used in combination with another data source in six infrastructure-themed articles (claims and survey)15–20, and seven data analysis-themed articles (claims, registry, and omics)10,21–26. EHR data were used with two additional data sources (claims and registry) in only one infrastructure-themed article27. Table 1 lists the references of data sources in each theme. EHR was the most commonly used data source in both the infrastructure and data analysis themes.

In terms of geographic distribution, North America, Asia, and Europe were the leading continents for article contribution, and a jump in accumulated publication numbers appeared in the year 2020 (Fig. 2c). Figure 2d illustrates a similar trend of cancer types studied across both themes, though there were more studies on blood and lymph cancers in the infrastructure theme. Table 2 provides detailed references of the specific cancer types and categorizations in each theme. Colorectal cancer was well studied in both themes.

Clusters based on cancer types and CDM table names were compared between the infrastructure and data analysis themes (Fig. 3). The infrastructure theme (Fig. 3a) covered all 8 CDM tables in the data analysis theme (Fig. 3b), and additionally incorporated several more tables, including Care_site, Cohort, Episode, Episode_event, Fact_relationship, Location, Note, Note_NLP, Device_exposure, and Specimen. It also covered extensions of the OMOP CDM including Genomic_test, Imaging_series, Imaging_study, Target_gene, Variant_annotation, Variant_occurrence, and Vocabulary_extension. Such extensions of OMOP tables or vocabularies aimed to enable more comprehensive studies by addressing gaps that currently limit research due to the absence of necessary tables or vocabularies. For example, the Note_NLP table was included for colorectal cancer; Imaging_series and Imaging_study tables were included for prostate cancer; the Device_exposure table was included for breast and lung cancer; the Note table was included for thyroid cancer, and the Specimen table was included for blood, lung, and colorectal cancer. In the data analysis theme (Fig. 3b), the Condition_occurrence and Person tables were the most frequently used across all cancer types, followed by the Drug_exposure table, and the Observation, Measurement, and Procedure_occurrence tables. There was minimal use of the Visit_occurrence and Death tables.

Article distribution is shown across publication year (a), data sources (b), publication year and geographic region (c), and cancer types (d).

Comparison of Infrastructure and Data analysis in data sources

Comparison of Infrastructure and Data analysis in cancer types

a Infrastructure theme, b Data analysis theme. The infrastructure theme (a) covered all 8 CDM tables in the data analysis theme (b), and additionally incorporated several more tables, including Care_site, Cohort, Episode, Episode_event, Fact_relationship, Location, Note, Note_NLP, Device_exposure, and Specimen. It also covered extensions of the OMOP CDM including Genomic_test, Imaging_series, Imaging_study, Target_gene, Variant_annotation, Variant_occurrence, and Vocabulary_extension.

## Section: Results › Infrastructure theme

For all studies included in the infrastructure theme, efforts to develop reusable tooling and practices to transform cancer-specific data to the OMOP CDM format and to expand the OMOP CDM to support additional data were described. A total of 20 studies fell under this category. Studies in this category were divided into 4 subcategories (Table 3).

Studies in the infrastructure category were split relatively equally across three geographic regions including the United States (n = 7)16,17,20,27–30, Europe (n = 7)15,19,31–35, Asia with South Korea (n = 5)18,36–39 and China (n = 1)14. Within Europe, Germany was particularly distinct as it contributed five of the included studies from that region19,31–33,35.

A majority of articles utilized a single dataset (n = 11)14,17,19,29–32,34,36–38, which is reasonable for infrastructure construction efforts. One study reported four datasets27, three studies involved three datasets16,33,39, three studies involved two datasets18,20,28, one study involved eight datasets35, and one study involved 20 datasets15.

Of the studies (n = 7) that sought to extend the OMOP CDM or enrich the data contained within18,19,27,30,38,39, four sought to extend the model to better support oncology-related data elements27,30,38,39, two sought to extend support for –omics data18,19, and one sought to extend support for imaging data34.

A bulk (n = 9)14,16,17,20,32,34–37 of the studies in this category did not report a direct evaluation of the mapping quality into the OMOP CDM. Evaluation metrics were similarly ill-defined (Table 3 shows papers with some form of evaluation), although the most common evaluation was mapping coverage/percentage of source rows that were successfully mapped to the OMOP CDM standard (n = 4)28,29,38,39, or the proportion of clinical concepts that could be successfully represented in the OMOP CDM standard (n = 2)27,31. Two studies32,35 did not include an evaluation of the mapping process but did report a metric of the percentage of concepts that were not represented in their tables.

Common themes regarding data mapping limitations were that the OMOP CDM could not represent certain clinically relevant concepts without further extension (n = 6)14,19,27,30,34,35 and some data were not directly available in structured form and required algorithmic normalization (n = 3)14,20,38.

A summary of papers in the infrastructure theme

## Section: Results › Data analysis theme

To better delineate the relationship amongst the various data elements collected, we conducted synthesis analyses for the data analysis theme. Figure 4 shows the linkage between aggregated cancer types, geographic area, study cohort size, study start year, and the study period. To categorize geographic locations, a global study is defined as a study that includes at least two countries, in contrast to a single-country study. Global studies (n = 6) began in 202010,21,23,26,40,41, and accounted for 20% of papers in the data analysis theme. Global collaborations were evident across multiple regions and countries, including USA, Spain, France, Germany, UK, Denmark, Netherlands, South Korea, and China, with the USA participating in the majority of studies, contributing to 5 out of 6 studies (83.3%). Among the 24 single-country studies, 15 came from South Korea, 6 from the USA, 2 from Denmark and 1 from China.

Among 30 studies in the data analysis theme, 15 (50%) studies leveraged multi-site datasets ranging from 2 to 11 individual sites10,11,21,23,25,26,41–49. The remaining 15 studies used a single dataset, including 8 from South Korea50–57 4 studies from USA22,24,58,59, and 1 each from Denmark60, China14, and a collaboration effort between Denmark and Netherland40. In terms of cancer types and population, 15 studies on the South Korean population covered all cancer types except nervous system (brain cancer), which was exclusively conducted in the US population47. Six local studies in the USA concentrated on genitourinary, nervous, and respiratory cancers22,24,44,47,49,59. Denmark48,60 and China14 focused on digestive system cancers in their local studies. While global studies had the capacity to cover a population of more than one million patients23,26, local studies included populations ranging from <=1000 to 1 million. The earliest dataset started in 1986; two were from the South Korea25,44, and one was an international, multisite study49. The study periods of 8 studies exceeded 15 years10,23,25,44,46,48,49,60. Four studies didn’t provide the period of the studied population. Figure 5 shows the details of the distributions of cancer types by geolocation and study cohort size, top in-network institutions, and top out-network institutions compared with OHDSI collaborators (https://www.ohdsi.org/who-we-are/collaborators/).

Since studies from South Korea were disproportionately represented compared with other nations, Supplementary Fig. 1 shows the linkage after excluding studies from South Korea.

Study designs were categorized under two broader groups: “observational study” and “advanced analytics”. The “observational study” group was comprised of 22 (73.3%) papers, and “advanced analytics” group was comprised of 8 (26.7%) studies. Table 4 provides a list of the study methodologies.

Figure 6 illustrates the relationships between target domains, study designs, analysis methods, and CDM domain names used across all included data analysis papers. The majority (86.7%) of the research efforts focused on two primary target domains, i.e., diseases (n = 15)10,14,22,24,40,41,43,47–49,51,55,56,58,60 and drug-cancer association (n = 11)11,21,23,42,44–46,50,52–54,56, respectively. Other domains included risk factors for emergency department (ED) visits57, treatment patterns25,26, and trial eligibility59. Specifically, studies focusing on diseases are listed with their specific research questions in Table 5.

Other study designs in Fig. 6 include case control55,58, cross sectional43, and phenotyping59. All 11 observational studies on drug-cancer association exclusively utilized the cohort study design. Conversely, observational studies on diseases included a variety of study designs. Among these, predictive modeling was the dominant approach (n = 6)40,41,47–49,60, followed by cohort studies (n = 4)10,22,24,51. The Cox regression model was the most widely used statistical method in observational studies (n = 12)11,14,21–23,42,44–46,50,52,55, followed by logistic regression (n = 5)24,43,53,54,56. Machine learning was the sole method for advanced analytics in predictive modeling study design (n = 7). NLP was only employed for the trial eligibility via phenotyping59. Supplementary Table 1 summarizes the studies using NLP. In data analysis papers, a wide range of CDM tables were analyzed by both statistical and machine learning methods, with the number of studies for each table shown in Fig. 6.

Numbers refer to paper numbers. A global study is defined as a study that includes at least two countries, in contrast to a single-country study.

By geolocation (a), study cohort size (b), top in-network institutions (c), and top out-network institutions (d).

References for the study methods

Numbers refer to paper numbers. This figure illustrates the relationships between target domains, study designs, statistical methods, and CDM domain names used across all included data analysis papers.

Types of cancer research questions addressed in the disease target domain

## Section: Discussion

In our review, cancer studies using OMOP CDM fell into two themes, data analyses and infrastructure construction. The presence of studies in both arenas indicates an ongoing evolution of OMOP integration into the data infrastructure for cancer researchers and centers. OHDSI was founded in 2008 and started to yield publications in 201061, however, we found that studies with in-depth data analyses with OMOP data were not published until 201747, and publications in building out individual OMOP infrastructures were published in 2018. Global collaborative studies using OMOP started being published in 202021,26,41. Notably, the OMOP CDM enabled longitudinal studies with a study period spanning up to 15 years21,24,26,44,48,49,60 and projects with more than 1 million patients23,26. Our review also demonstrated leaders in the field with the USA, South Korea, and Germany standing out as the leading countries leveraging the OMOP CDM for the cancer specific studies; this is consistent with a previous review62. Types of cancer research questions addressed in the data analytics studies varied widely and included disease-specific topics, drug-cancer association, risk factors for emergency department (ED) visits, treatment patterns, and clinical trial eligibility. Disease-specific and drug-cancer association were the most commonly studied topics. This demonstrates the potential utilization of the OMOP CDM for other types of cancer-specific topics such as drug repurposing and disease trajectory discovery.

To gain an understanding of whether real-world data are diverse enough and meet the data needs for downstream analysis, we investigated the cancer types in the studies across both themes. There was a wide range of cancer types covered in our review. However, when examining the cancer types, rare cancers were not well represented with limited studies on pancreatic cancer45,51 and pediatric brain cancer47. The potential of OMOP CDM facilitating rare cancer science and discovery by pooling large-scale data is invaluable and warrants further exploration.

The diverse set of data sources included in the reviewed infrastructure studies suggests that cancer studies often require additional data sources including but not limited to clinical registries, omics, biobank, and population based datasets beyond the current EHR/Claims data-focused ecosystem. Meanwhile, new target CDM tables, such as Episode, Note_NLP and Specimen, and data model for omics and imaging data were extended in the infrastructure theme. It is evident that the OMOP CDM ecosystem is still undergoing active development and iteration, which will result in continuous improvements in its ability to support cancer research.

The reviewed studies in the data analysis theme were mostly observational cohort studies, demonstrating the important role of longitudinal analyses in generating hypotheses and showing important trends over time. Although limited in number, predictive studies using OMOP data were also highlighted in this review. Machine learning models were often used in these studies, while deep learning and large language model-based approaches remain yet unexplored. Advanced methodologies were also emphasized in the infrastructure theme – one study presented an overview of sustainable cloud-based platforms for developing, implementing, verifying, and validating trustable, usable, and reliable AI models for cancer care63. Adopting advanced analytics methodologies will become important as data systems become more mature.

It should be noted that a substantial amount of clinically relevant information for cancer is represented in unstructured form. This is particularly true for certain types of data. For example, information within pathology reports is often difficult to capture, as synoptic reporting has been adopted for few cancer types at many institutions. However, limited studies explored the integration of NLP methods in building data infrastructure37–39, and only one study leveraged NLP-derived data in the data analysis theme59. The potential challenges of current NLP methodologies for handling text data were highlighted in these studies, e.g., the limitations of using simple regex in NLP, along with concerns regarding generalizability and systematic evaluation of annotation schemas37,38,59. We identified similar issues and barriers for wide adoption of cancer NLP in our previous study64. Despite these challenges, it is critical to incorporate NLP-derived data within OMOP CDM instances for cancer research. A federated NLP deployment framework following the RITE-FAIR (Reproducible, Implementable, Transparent, Explainable - Findable, Accessible, Interoperable, and Reusable) principles with scientific rigor and transparent (TRUST) provides a solution towards real-world clinical NLP while preserving the integrity and privacy for data from multiple sites65,66.

Data quality challenges were typically attributed to two issues: accessibility information quality (IQ) and representational IQ67,68. For accessibility IQ, concerns related to poor record linkage and inaccessible geocoding information were discussed by several studies16,28,34. Data timeliness was another issue as the current data retrieval and operation process is steward-based and lacks a real-time process (n = 2)17,33. Data privacy, security (e.g., data identification), and regulatory considerations play a significant role in addressing accessibility IQ17. Regarding representational IQ, the lack of data standardization, particularly in the context of limited OMOP vocabularies, was noted as a challenge. In addition, a substantial portion of the reviewed studies in the infrastructure theme did not perform mapping quality evaluation. This is a significant issue as variations in this process can have profound effects on the validity of any downstream use cases. The potential solution for the data standardization and concept mapping problems lies in efforts to derive human-driven consensus amongst multiple use-cases on individual value-sets corresponding to individual clinical entities. Most prolific amongst these efforts is the NLM’s Value Set Authority Center (VSAC)69 which aims to render clinical concept sets publicly available for further reuse and refinement. Beyond that, efforts have been made to create additional tooling allowing for similar functions at an institutional level (with greater human interaction), such as the OHNLP Valueset Workbench70. Nevertheless, greater efforts should be made to integrate similar functionality into current clinical phenotyping workflows.

Although the OMOP CDM is designed to support multi-site studies, our review indicates that the majority of studies used single-site data. A gap in multisite evaluation for proposed methods/frameworks14,16,17,20,25,32,34–37,41,63 and representativeness of research findings due to single site data analysis design14,22,24,40,50–60 was observed in the infrastructure and data analysis themes, respectively. Site-specific biases within individual data sources further compound these challenges. Overall, the challenges lie in the multifaceted nature of the data ETL and harmonization processes, emphasizing the need for comprehensive and collaborative approaches to overcome technical, regulatory, and operational challenges.

While harmonization of clinical data via the OMOP CDM has vastly improved data standardization for multisite studies, these issues persist due to non-standard approaches by which these data are populated, particularly when it comes to concept normalization approaches. This issue is further complicated by the closed nature of many current EHR system licenses, limiting public sharing of developed ETL pipelines and leading to a substantial amount of re-implementation with differing methodologies. In the absence of any changes to EHR system licensing processes, the best approach is to actively publish concept mappings (e.g., via mechanisms such as the aforementioned Valueset Workbench69) such that they can be reviewed, refined, and re-used by other collaborating institutions, particularly in the case of manual mappings and/or NLP-derived mappings from text-based clinical concepts71.

Limitations in our study included the potential biases of missing relevant articles that may be caused by search strings and databases selected, as well as the inherent ambiguity associated with data element collection, normalization, and analysis due to subjectivity occurred in the review process.

In conclusion, we conducted a scoping review to describe the adoption of the OMOP CDM in cancer research, providing an overview of efforts aimed at leveraging the OHDSI ecosystem for oncology studies. This review highlighted that while the OMOP CDM ecosystem has enabled successful data support for cancer research, particularly for collaborative studies, ongoing model development and iterative improvement remain needed to fulfill additional research data needs. Expanding disease sites, specifically for rare cancers, integrating more diverse types of data sources, improving data quality, adopting advanced analytics methodology, and increasing multisite evaluations serve as important opportunities to facilitate secondary usage of observational data in future cancer research.

## Section: Methods

We opted to employ a scoping review to explore the scope of the OMOP CDM for cancer research72. Our approach followed the framework outlined by Arksey and O’Malley73, as well as the Preferred Reporting Items for Systematic Reviews and Meta-Analyses (PRISMA) extension for scoping reviews74. The process was conducted in five stages as detailed below:

## Section: Methods › Identifying the objectives

To analyze the status, challenges, and opportunities of adopting OMOP CDM for cancer research using real-world data, it’s critical to have a complete understanding of the studies on practical applications of OMOP CDM, and those on data infrastructure construction. Therefore, we aimed to address the following objectives in the review process: (1) Examine the landscape of currently published cancer studies that utilized the OHDSI/OMOP CDM, (2) Assess the role of OHDSI/OMOP CDM as an appropriate data infrastructure for cancer research, and (3) Highlight challenges and opportunities to identify directions for future investigations.

## Section: Methods › Identifying relevant studies

We included articles published between January 1, 2010 through December 31, 2023. Articles written in English were retrieved from the following databases: Ovid, IEEE Xplore, PubMed, Web of Science, and Embase. A detailed description of the search strategies for articles using OHDSI OMOP for cancer related studies is provided in Supplementary Table 2.

## Section: Methods › Study selection

Two reviewers (L.W. and A.W.) independently screened the titles and abstracts of all articles retrieved. Publications were included if the OHDSI/OMOP CDM was used for cancer related studies. The following exclusion criteria were applied:

A second round of full-text screening was performed by the same reviewers to ensure all publications met the inclusion and exclusion criteria. When disagreement arose, they discussed to achieve a consensus.

## Section: Methods › Charting the relevant studies

Four authors (L.W., A.W., S.F., H. Liu) designed the study themes, standardized templates for summarizing pertinent publications, and systematically organizing the information. Studies were categorized into two main themes: data analysis and infrastructure. The data analysis theme included observational studies or articles that utilized advanced analytics such as machine learning or natural language processing (NLP). In the infrastructure theme, we focused on studies describing reusable tools and practices for transforming data into the OMOP CDM format and expanding them to support additional data types, specifically in relation to cancer. Three reviewers (L.W., X.R., M.H.) were allocated for data element extraction for the data analysis theme, and three reviewers (A.W., Q.L., R.L.) were allocated for the infrastructure theme. Any disagreements were resolved by inter-discussion or discussion with a third reviewer to achieve a consensus.

The following described our review protocol. For the data analysis theme, data elements were extracted following the STROBE (strengthening the reporting of observational studies in epidemiology) checklist75 a reporting guideline that describes core considerations for observational research. Key data elements included publication years, objectives, data sources, cancer type, institution names, geographic region, cohort size, target domain of study (disease, drug-cancer association, other.), method (machine learning, descriptive analysis, logistic regression, etc.), NLP usage (yes or no), study period (start year, end year), study design (cohort, case-control, and cross-sectional studies for observational study, predictive modeling, or phenotyping, etc.), variables analyzed (diagnosis, procedures, etc.), and number of datasets. To facilitate subsequent analyses, variables were aggregated based on table names in OHDSI CDM version 5.4 (https://ohdsi.github.io/CommonDataModel/). Specifically, variables indicating lower-level clinical events were manually extracted from the method sections of included articles, and then manually mapped to the corresponding CDM tables. For example, medical history was mapped to the Condition_occurrence table, smoking status was mapped to the Observation table (see Supplementary Table 3). In addition, we extracted countries of the OMOP CDM datasets used for data analysis to identify geographic regions and institution names of the authors.

For the infrastructure theme, we categorized articles according to the OMOP CDM construction process (data linkage and standardization, transformation, etc.). Data elements of interest included publication year, geographic regions, institution names, cancer types, study topics, source data type (local EHR, claims data, etc.), target CDM table, mapping coverage, ETL (extract, transform, and load) challenges, mapping evaluation methods, data model extension, and limitations of data model (data element not specified, no definition, etc.). We extracted the countries of the authors to identify geographic regions and institution names of the datasets.

## Section: Methods › Collating, summarizing, and reporting the results

Data from the charting process were summarized, analyzed, and visualized to present an overview of the application of the OHDSI CDM in cancer research.

## Section: Supplementary information

PRISMA-ScR Checklist

Supplementary Data 1

Supplementary File 1

## Section: Acknowledgements

This project is supported by the Cancer Prevention Research Institute of Texas (CPRIT). RR230020, National Institute of Aging grant RF1AG072799, National Human Genome Research Institute R01HG12748, and National Library of Medicine R01LM11934. The funders played no role in the study design, data collection, analysis and interpretation of data, or the writing of this manuscript.

## Section: Author contributions

L.W.: conceptualized and designed the study, analyzed the data of the data analysis theme, visualized results and drafted the manuscript; A.W.: conceptualized and designed the study, analyzed the data of the infrastructure theme and drafted the manuscript; F.S.: designed the study, analyzed the data of infrastructural theme and drafted the manuscript; X.R.: analyzed the data of the data analysis theme, visualized results and drafted the manuscript; M.H.: analyzed the data of the data analysis theme, visualized results and drafted the manuscript; R.L.: analyzed the data of infrastructural theme and visualized results; Q.L.: analyzed the data of infrastructural theme; A.E.W.: revised the manuscript; H.L.: revised the manuscript; H.L.*: conceptualized, supervised, designed the study and revised the manuscript.

## Section: Data availability

Data is provided within the manuscript or supplementary information files.

## Section: Competing interests

Heather Lyu is an associate editor, and Hongfang Liu is an Editorial Board Member of NPJ Digital Medicine.

## Section: Supplementary information

The online version contains supplementary material available at 10.1038/s41746-025-01581-7.

## Section: Associated Data

PRISMA-ScR Checklist

Supplementary Data 1

Supplementary File 1

## Section: Associated Data › Supplementary Materials

PRISMA-ScR Checklist

Supplementary Data 1

Supplementary File 1

## Section: Associated Data › Data Availability Statement

Data is provided within the manuscript or supplementary information files.


---

# A survey on deep learning for drug-target binding prediction: models, benchmarks, evaluation, and case studies

- **Authors:** Kusal Debnath, Pratip Rana, Preetam Ghosh
- **Issuer:** Briefings in bioinformatics
- **Type:** Scientific article
- **Published:** 2025-08-31
- **Language:** en
- **DOI:** 10.1093/bib/bbaf491
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40977267/
- **Licence:** CC-BY

## Section: Abstract

AbstractConventional drug discovery is expensive, time-consuming, and prone to failure. Artificial intelligence has become a potent substitute over the last decade, providing strong answers to challenging biological issues in this field. Among these difficulties, drug-target binding (DTB) is a key component of drug discovery techniques. In this context, drug-target affinity and drug–target interaction are complementary and essential frameworks that work together to improve our comprehension of DTB dynamics. In this work, we thoroughly analyze the most recent deep learning models, popular benchmark datasets, and assessment metrics for DTB prediction. We look at the paradigm shift in the development of drug discovery research since researchers started using deep learning as a potent tool for DTB prediction. In particular, we examine how methodologies have evolved, starting with early heterogeneous network-based approaches, progressing to graph-based approaches that were widely accepted, followed by modern attention-based architectures, and finally, the most recent multimodal approaches. We also provide case studies utilizing an extensive compound library against specific protein targets implicated in critical cancer pathways to demonstrate the usefulness of these approaches. In addition to summarizing the latest developments in DTB prediction models, this review also identifies their drawbacks. It also highlights the outlook for the DTB prediction domain and future research directions. Combined, these studies present a more comprehensive view of how deep learning offers a quantitative framework for researching drug-target relationships, speeding up the identification of new drug candidates and making it easier to identify possible DTBs.

## Section: Introduction

Drug-target binding (DTB) prediction plays a pivotal role in drug discovery. DTB analysis unfolds the possible interactions of drug compounds with target proteins crucial in several biological pathways involving various diseases. Traditional approaches for identifying DTBs demand a heavy investment in time and cost. Recent advances in computational methods, particularly artificial intelligence (AI)-based approaches, showcased remarkable progress in DTB prediction. These approaches act as reliable alternatives, diminishing the constraints tied to traditional methods and offering better accuracy.

In early developments, statistics and classical machine learning methods were predominant approaches, leveraging manually curated descriptors or features of drugs and targets. However, a significant challenge of these methods is that they depend solely on available clinical data for analysis. In addition, there are challenges in manually selecting features for model training, as it requires in-depth knowledge of pharmacodynamics concepts. Also, some of these methods require iterative analysis through standard statistical methods, which are susceptible to errors. In contrast, deep learning gained popularity because of its ability to handle large datasets, better performance, and ability to learn intricate relationships between input data and output.

The last decade witnessed a surge in deep learning-driven DTB prediction methodologies, fueled by the widespread availability of data resources hosting information related to molecular entities and biological networks related to specific cell lines and diseases. In addition, improved computational power facilitated the development of more sophisticated deep-learning algorithms. Such deep learning models’ ability to handle large amounts of data and learn complex non-linear relations from them is a crucial aspect of modern DTB research.

Deep learning-based approaches can extract complex features and their inter-relations through a network of artificial neurons, diminishing the challenge of manual selection of features important for prediction. The availability of structural and functional information on compounds and proteins allows the application of such approaches in modeling DTB prediction problems. Early approaches in modeling DTB prediction task leverage simpler feature extraction methods using convolutional neural networks (CNNs) and recurrent neural networks from one-dimensional sequential information (e.g. SMILES [1], SMARTS [2], and SMIRKS [3]) of drugs and targets (e.g. amino acid sequences). Although these approaches showed superior results to earlier statistical and machine learning-based methods, they had some significant limitations. Firstly, they addressed drugs and proteins in their native primary-structural forms, often ignoring their three-dimensional configurations consisting of bond lengths, bond angles, inter-atomic distances, and scaffolds. In addition, information on specific binding pockets is often missing in these representations, limiting the modeling of chemistry-informed binding inside the human system.

Later developments using the primary representations of drugs and compounds utilized more sophisticated feature extraction methods such as graph-based, attention-based, and hybrid approaches. Though working with the exact one-dimensional representations, graph-based methods further represented the molecules in higher-dimensional graphs considering the positional aspects of constituent atoms. Attention-based approaches discussed concepts such as multi-headed attention, mutual learning, and feature aggregation for extracting more complex features relevant to modeling DTB prediction tasks, providing better results than previous methods. Some hybrid methods also demonstrate significant results in DTB prediction, incorporating information related to drugs and targets encompassing spatial chemical environments, molecular substructure-specific modeling, similarity accumulation, cross-attention, and molecular augmentation.

Recent developments in natural-language-based methods paved the way for representing DTB prediction as a hybrid-natural language-based problem, extracting semantic features from the drug and target structures. Developing domain-specific large language model (LLM) derivatives from the established ones (e.g. ChemBERTa [4] and ProtBERT [5] derived from original BERT [6] model) is an active research area in the field of drug discovery. These language models facilitate drug discovery research by providing crucial semantic information from chemical structures. Generated embeddings are combined with previously established approaches for DTB prediction, including graph-based and attention-based methods that aid in a better understanding of the importance of features and provide better prediction results.

In this work, we conducted an evaluation-based survey for DTB prediction approaches. In the Background section, we discussed the early attempts and how the continuous development led to the most recent modern attempts in drug-target affinity (DTA) predictions. In the methodology section, we discuss the model selection procedure, summarize the selected models, discuss standard datasets used for benchmarking, and evaluate the results. In addition, we conducted multiple case studies to predict DTB in cancer, using crucial proteins in key biological pathways associated with various types of cancer. Finally, we briefly discussed the general research scenario for deep learning-based DTB prediction. In summary, this work offers valuable insights into the current research landscape of deep learning-driven DTB prediction, which will support researchers in advancing groundbreaking findings in this field. A comprehensive overview of the evaluation workflow is represented in Fig. 1.

Graphical representation of the essential components discussed through systematic survey.

## Section: Background

The quest for potential drug targets and identifying suitable drugs for targets has always been one of the central topics in targeted cancer therapy. Advancements in computational technologies have only facilitated the extent of this quest. Since the inception of deep learning, the research in the virtual screening of drugs has advanced considerably. Nevertheless, the earlier developments remain highly relevant, as they are crucial in laying the foundation for the current progress. This section discusses the early discoveries in the DTB domain and how they have inspired modern deep-learning approaches. This section thus can be divided into two key stages—the pre-deep learning era and the post-deep learning era.

List of models utilized LLMs for feature encoding

## Section: Background › Pre-deep learning era

At this stage, researchers primarily relied on the extensive clinical data on the topological and therapeutic properties of drugs and physiological interactions related to target proteins available in various databases. In an earlier study, Yıldırım et al. [7] built a bipartite graph containing FDA-approved drugs and proteins linked by drug-target binary associations. Clusters of drugs were created according to the anatomy, therapeutic properties, and chemical configuration of each drug. This network emphasized the prevalence of “follow-on” drugs that target already targeted proteins. The goal was to integrate the principles of network biology and the knowledge of drug–target interactions (DTIs) to analyze drug-target networks in cells and their mutual interactions with disease gene products. Bleakley et al. [8] used a supervised inference approach called bipartite local models, where target proteins for a given drug and target drugs for a given protein were predicted independently for each drug-target pair. Mei et al. [9] presented a method called neighbor-based interaction-profile inferring and integrated it into the existing bipartite local model to handle unknown DTIs. The interaction profile is treated as label information. It is used for model learning of new candidates, crucial in finding targets for new drug candidates and drugs for new target candidate proteins.

Yamanishi et al. [10, 11] found that DTIs correlate more with pharmacological effect similarity than chemical structure similarity. They emphasized mapping the pharmacological effects of chemical, genomic, and pharmacological data of given compounds. Iorio et al. [12] utilized similarities among gene expression profiles following drug treatment for multiple cell lines and dosages to get estimates on drug effects and mode of action (MoA). Drug compounds are clustered based on their MoA or targeting a specific biological pathway, thus assessing the usability of multiple drugs for a common disease. Perlman et al. [13] introduced a novel approach for scoring the drug-gene association by combining the drug-drug and gene-gene similarity measures through a logistic regression component to integrate multiple association scores to give an estimate of the final association score, emphasizing the importance of heterogeneous information integration for DTI prediction. Mizutani et al. [14] introduced a novel approach combining the drug-protein interactions and side effects linking the molecular and side effects scale of drug actions. The work discusses the analysis of the co-occurrence of drugs in protein-binding profiles and side-effect profiles, proven to be effective for predicting possible side-effects of new drug candidates based on their protein-binding profiles. Campillos et al. [15] utilized phenotypic side-effect similarities to infer potential shared targets between two drugs, discovering novel DTIs. However, one significant downside of this method is the manual inference of the shared targets between drug pairs, which can be a time-consuming and error-prone process. In addition, there exists a degree of uncertainty in accurately associating a given target with a specific side effect. Sirota et al. [16] demonstrated the importance of molecular signatures in drug-disease pairs for DTI prediction. They integrated gene-expression measurements from several diseases and drugs, emphasizing the fact that drugs exerting similar gene expressions may have some degree of similarity. Chen et al. [17] utilized a heterogeneous network approach, combining protein-protein similarity network, drug-drug similarity network, and known DTI network with further integration with a random walk. They emphasized the hypothesis that similar drugs often target similar target proteins.

Li et al. [18] introduced a web tool named TarFishDock. The reverse docking methodology is utilized for ligand-protein docking to search for potential protein targets for specific drugs by screening protein databases. Kinnings et al. [19] addressed the limitations of docking scoring functions in assigning bond weights correctly and the inaccuracy in mapping the inter-dependency of noncovalent bonds while scoring. They introduced an improved scoring function by training support vector machines on IC50 values of BindingDB [20] dataset and directory of useful decoys (DUD) dataset [21] utilizing the individual energy terms retrieved from molecular docking along with the known binding affinity values from high throughput screening experiments. Shaikh et al. [22] propose proteochemometric models for enhanced DTI prediction, emphasizing the importance of negative instances in the prediction task. Moreover, a novel fingerprint-based approach was demonstrated to develop the applicability domain of the proposed models.

Van Laarhoven et al. [23] demonstrated that machine learning algorithms can accurately predict DTIs using limited information. They introduced a kernel-based approach known as Gaussian interaction profile (GIP), which uses the interaction profiles of drug-target networks and a simple classifier called Regularized Least Squares to predict these interactions. In a later work, they introduced a weighted nearest neighbor (WNN) approach [24] to predict unknown DTIs, where an interaction score profile is constructed for a new drug based on the chemical and interaction information similarity of the existing drug compounds in the dataset. Further, they integrated GIP and WNN and called it WNN-GIP. Gonen et al. [25] used a novel approach called Bayesian formulation, combining dimensionality reduction, matrix factorization, and binary classification to predict DTIs. Similarity analysis was performed for drug compounds based on their chemical structures. For target proteins, corresponding genomic similarities were used to project the drugs and proteins in a unified subspace for prediction. Wang et al. [26] demonstrated DTI prediction as a two-layer graphical model known as a restricted Boltzmann Machine (RBM). Here, DTIs are represented as multi-dimensional networks. A practical learning algorithm called Contrastive Divergence is used here, and it utilizes the probability distribution over input data to train the RBM. Cobanoglu et al. [27] proposed a collaborative filtering algorithm called probabilistic matrix factorization (PMF), which can predict DTIs by analyzing large interaction networks without additional similarity information.

While the methods mentioned above showed some success in predicting DTIs, they were hindered by several limitations, such as a) solely depending on experimental clinical data for analysis can lead to challenges due to the ambiguity of data across databases; b) the manual selection of significant features among entities for prediction is a meticulous process; and c) iterative statistical analyses, while crucial, are susceptible to errors in calculations. In response to these challenges, researchers have turned to deep learning-based methods for DTI prediction, offering a more robust and practical approach.

## Section: Background › Post-deep learning era

Since its inception, deep learning has provided promising approaches to automate feature extraction by learning salient representations from raw biological data. In this section, we scrutinize the chronological progression of deep learning applications enhancing DTB predictions, from initial network-based and sequence-based approaches through the revolution of graph-based modeling, and finally, to the current transformer-based and multi-modal fusion approaches.

List of models utilized LLMs for feature encoding

## Section: Background › Post-deep learning era › The foundational era: network integration and sequence-based methods

This phase marked the pivot from traditional, feature engineering-based machine learning approaches toward automated feature extraction-based deep learning approaches. This era majorly involves the exploitation of heterogeneous network-based approaches. Utilization of 1D biological sequences became mainstream. Additionally, due to the advent of large-scale experimental bioactivity assays, this period witnessed the clear bifurcation of DTI classification and DTA regression tasks; therefore, a separate set of evaluation approaches, metrics, and benchmarks emerged.

Luo et al. addressed the limitation that existing DTI methods were primarily designed for homogeneous networks or simple bipartite models that got troubled handling the noisy, incomplete, and high-dimensional biological data in their proposed approach called DTINet [28]. DTINet revolutionized this approach by integrating diverse heterogeneous data sources into a unified network. It learned low-dimensional vector representations that capture the topological properties of nodes (drugs and proteins). This approach aided in finding an optimal projection from drug space to protein space, such that feature vectors of drugs are geometrically close to the feature vectors of their known interacting proteins. Later, DeepDR [29] used a more sophisticated multi-modal deep autoencoder in their model architecture to enhance the non-linear relationships capturing among individual networks in the heterogeneous network setup. It provides pharmacological interpretability and visualizable vector representations of network vertices.

Öztürk et al. introduced DeepDTA [30] and pioneered in framing the DTI prediction as a regression task with binding affinity values instead of a binary classification task. They simplified the 1D representation of drugs and targets, diminishing reliance on 3D drug-protein complexes. They adopted a CNN-based automatic feature learning approach from raw data instead of manual feature engineering. Instead of indirect learning from network-based/similarity-based approaches, they attempted direct learning from input drug and protein structural data using vectorization of the string-based data.

Lee et al. proposed DeepConvDTI [31], which uses CNN-based feature extraction from raw protein sequences to address the limitation of pre-computed descriptors (e.g. CTD), which were unable to capture crucial local features and binding-site specific features.

While graph-based approaches were proven to outperform sequence-based approaches, Wang et al. DeepDTAF [32] emphasized utilizing the secondary structural features and binding pocket information and outperformed models like Pafnucy in their proposed model named DeepDTAF [32]. It combines binding pocket features (local) with entire protein features (global). In a similar work, Dou et al. later introduced a more granular, fragment-oriented framework called BCM-DTI [33] that extracts diverse fragment types (branch chain, common substructure, motif/fragments) leveraging biological knowledge.

To mitigate the limitation of the requirement of 3D structural data, which also hinders scaling due to issues like low quality and computational bottleneck, Thafar et al. proposed Affinity2Vec [34], which transformed the DTI problem as a graph-based regression problem utilizing a heterogeneous graph network.

While the models above often tried to bypass the dependency on 3D structural data, Zheng et al. proposed OnionNet [35] leveraging 3D compound-protein complex data from the PDBBind dataset (v2016) to work toward physics-based atomic-level interaction prediction approach constructing multiple sequentially distant shells to capture both short-range (van der Waals) and long-range (electrostatic) interactions. This work thus laid the foundation for the current rotation-invariant molecular representation in de novo drug design while outperforming previous state-of-the-art physics-based 3D binding approaches like Pafnucy [36] and KDeep [37].

Recently, researchers explored the impact of similarity features, lower-dimensional inductive embeddings, structural topology, semantic graphs, and contrastive learning-oriented approaches for means of heterogeneous network-based binding prediction [38–40].

## Section: Background › Post-deep learning era › The graph revolution: embracing molecular topology

In this phase, researchers started representing drugs as 2D graphs, which better showcase the structural topology instead of 1D strings. Future studies prove that representing drugs as graphs is more effective than as strings. This conceptual drift laid foundational stones for representing macromolecules like proteins as graphs. At a later stage, with the integration of attention mechanisms, graph-based approaches became more robust.

Existing sequence-based methods represented drugs as 1D strings, unable to capture crucial topological features like inter-atomic bond length and angles. Nguyen et al. pioneered in representing drugs as 2D molecular graphs by introducing GraphDTA [41], where nodes of the graphs represent atoms and edges represent bonds. They used RDKit [42] to extract atomic features (atom symbol, number of adjacent atoms/hydrogens, implicit value, aromatic structure, etc.), which are eventually used as the node features. Similarly, Tran et al. proposed DeepNC [43], representing drugs as graphs and employing various graph neural network (GNN) algorithms to learn their chemical and structural characteristics. Later, Voitsitskyi et al. proposed 3DProtDTA [44] leveraging AlphaFold’s [45] protein structure predictions to generate residue-level protein graphs, thereby providing abundant structural data and preserving connectivity and 3D arrangement information. This model performed equally well when evaluated on cold targets containing tyrosine-protein kinases and serine/threonine protein kinases.

Jiang et al. went forward with not only representing biological entities as graphs, they also encoded protein structures as graphs and introduced DGraphDTA [46]. They utilized contact map prediction to capture protein spatial structure from raw sequences. These contact maps are then used as graph edges, while the amino acids are used as nodes.

By incorporating the weight-assigning ability of the attention mechanism in MHSADTI [47], Cheng et al. utilized a graph attention network (GAT) for drugs to reduce the effect of noisy connections within the nodes of the drug graph structure. Visualization of high-scoring attention weights provides interpretability of the approach. Similarly, Yu et al. incorporated multi-scale encoders for both drugs and proteins in an interpretable approach called MSFFDTA [48], developing a Selective cross-attention mechanism to filter out trivial interactions and focusing on crucial drug-protein substructure pairs. Recently, Wang et al. proposed WDGBANDTI [49] where they used a deep graph convolutional network (GCN) to extract rich atomic and sub-structural drug information, a CNN for protein features, and a Bilinear Attention Network to learn and visualize local sub-structural interactions explicitly providing interpretability.

Zhang et al. proposed DeepMGT-DTI [50] to discuss the fragile nature of SMILES sequences, as a slight change in SMILES structure can drastically alter molecular conformation. In addition, precise inter-atomic interaction estimation was often impossible from only sequence information. Thus, they proposed a multilayer graph fusion approach using a transformer network to accumulate information from different hidden layers of the graph convolution network. Moreover, they implemented a multi-headed attention architecture (four and six heads) to enhance edge feature learning, which was often missing in previous graph-based approaches. He et al. proposed NHGNN-DTA [51], a hybrid GNN that combines sequence-based feature generation with graph-level information interaction, including a unique central node to connect drug and protein graphs. They performed three types of splitting for cold-start scenarios: (i) cold-drug, (ii) cold-target, and (iii) cold-drug-target. For interpretability analysis, they provided attention-weight visualization of the final output.

Wang et al. introduced MSN-DTA [52] to address the limitations of current GNN-based DTA models that poorly extract drug molecular substructure information and rely on insufficient manually configured node features, which hinders generalization for similar structures, by introducing a multi-scale graph isomorphic network to extract multi-level structural information. To estimate the interpretability of DTI, they provided attention-weight visualization of protein binding sites. Similarly, Luo et al. used a hybrid GATv2-GCN and three-layer GCN in their proposed approach named GS-DTA [53] for a comprehensive, hierarchical drug feature extraction strategy with dynamic attention and global context, and by combining CNN, Bidirectional Long Short-Term Memory (BiLSTM), and Transformer for multi-level (local, contextual, and global) protein feature extraction.

Wang et al. proposed DHGT-DTI [54] to address the limitations of heterogeneous network methods that often fail to fully integrate both local and global network information simultaneously and struggle with generalization to new drug-target pairs by proposing a novel dual-view heterogeneous network approach that comprehensively captures network structural information from both local [using heterogeneous Graph Sample and Aggregate (GraphSAGE) for neighbor features] and global (using Graph Transformer with residual connections for higher-order meta-path features). To assess the generalizability of this approach, they used 1:4 cold-splitting. Similarly, Zhao et al. utilized meta-paths to represent regulatory mechanisms, constructing regulation graphs through random-walk sampling in an approach named RGLDR [55].

Wu et al. proposed AttentionMGT-DTA [56], which utilizes AlphaFold2-predicted protein structures to construct protein pocket graphs with rich spatial information to mitigate the limitation of 2D protein contact maps used in previous graph-based methods, which are unable to describe higher-dimensional protein structures accurately. In addition, they used a cross-attention module to fuse 1D sequence and 3D graph protein features. It provides high interpretability through its visualized attention matrices. Fusing biological and chemical property information in the model architecture and utilizing pre-trained embeddings enabled this approach to handle cold-start scenarios efficiently.

Zhang et al. proposed a graph dilated convolution strategy called GDilatedDTA [57] for improved feature extraction from indirect neighborhoods, integrating a multilayer residual connection network for local chemical information from SMILES and utilizing BiLSTM for target sequences, thereby enhancing interpretability, predictive accuracy and robustness in cold-start scenarios.

iGRLDTI [58], proposed by Zhao et al., addresses the over-smoothing issue prevalent in GNN-based DTI models, which reduces the discriminative ability of learned representations by adaptively determining the node-specific propagation depth for each biomolecule using a node-dependent local smoothing strategy.

Huang et al. integrated GNNs with a self-supervised invariant feature learning module in their proposed approach called GFLearn [59] to extract robust and generalizable features and reduce dependence on specific feature patterns. Integrating one-dimensional and three-dimensional embedding using cross-attention has proven to be effective in the cold-start scenarios in this approach.

## Section: Background › Post-deep learning era › The age of attention: influence of natural language processing

In this era, studies were conducted to complement the topological feature extraction using graph-based approaches with promising attention-based approaches for focusing on extracting essential features. In addition, pre-trained language models (PLMs) started taking center stage in diverse learning scenarios, namely imbalanced data, data scarcity, and label bias, eventually providing interpretability for the models.

DrugVQA [60] pointed out the limitation of 1D protein sequences representing 3D spatial features crucial for DTB. On the other hand, the scarce nature of co-crystallized 3D protein data leads to sparse feature generation. Hence, they figured out a middle ground by utilizing 2D protein distance maps to mitigate the limitations above. They represented the DTI as a visual question-answering problem, where protein distance maps are the “images” and drug SMILES are the “questions.” Thus diminishing the reliability of 3D protein structures. Multi-headed attention is used to identify binding pocket regions in protein sequences and crucial molecular fragments within drug structures, while attention visualization is used to showcase interpretability.

TransformerCPI [61] addressed the hidden ligand bias in the DUD-E dataset that leads to learning only ligand patterns instead of true protein–ligand interactions and emphasized appropriate data for better generalizability. It used curated G-Protein Couple Receptor (GPCR) and Kinase datasets from pre-existing datasets, where each ligand appears in positive and negative classes. It performed rigorous tests where ligands appeared only in one class during training but in opposite classes during testing. Finally, it used a self-attention mechanism for dynamic feature extraction instead of memorizing ligand patterns. The interpretability of this approach was estimated by mapping attention weights back to protein sequences and compound molecules.

DeepCDA [62] highlighted a fundamental statistical misconception that training data and test data come from the same distribution. Training and test data may come from entirely different distributions in real-world scenarios. Thus, they proposed an effective adversarial learning method—Adversarial Discriminative Domain Adaptation. This method makes the model learn from a test domain feature encoder using adversarial domain adaptation between training and unlabeled test data. The adapted test encoder is then applied to predict binding affinity in the cold-start scenario. This approach utilizes two-sided attention to calculate pairwise compound-protein interaction.

MolTrans [63] emphasized that not the entire drug/protein structure participates in interactions; instead, specific repetitive regions within drug/targets are responsible for the interaction. They called these regions Frequent Consecutive Sequence (FCS), which were mined from the overall structure using a hierarchical decomposition mechanism. Drugs/proteins are tokenized into their most minor units, then sequentially combined to form frequently occurring sub-sequences. They used transformer encoders to extract contextual relationships within the sub-sequences, providing interpretability.

Observing the sole dependence on molecular features only and neglecting the interaction features in previous DTI prediction tasks, DeepFusion [64] adopted a multiscale feature fusion approach to combine global structural similarity features with local sub-structure features (carrying on the idea of FCS in MolTrans) utilizing a two-channel architecture. Similarly, GIFDTI combines CNN and transformer architecture to extract global molecular and intermolecular features (IIF module). To effectively explain the validity and interpretability of the IIF module, they map the intermolecular interaction scores of proteins calculated from the IIF module onto the 3D structure and protein sequence. IHDFN-DTI [65] introduces a hybrid deep feature extraction module for proteins that captures multi-level information via dynamic encoding and DIFF Transformer and fuses them with StarNet. Even though the approach achieves interpretability through attention focusing, the protein sequence embeddings were generated randomly, resulting in an embedding matrix that lacked biological context.

MONN [66] pointed out the issue of interpretability of attention mechanisms in DTI. It states that attention mechanisms only show pseudo-interaction among drug-target pairs by showing mere correlations among them instead of capturing actual non-covalent interactions. It utilizes a dual-attention network (DAN) for monitoring individual DTI pairs. It combines compound and protein features using predicted pairwise interactions as links as part of a multi-objective framework for simultaneously predicting binding affinities and non-covalent interactions among drug-target pairs.

HyperAttentionDTI [67] emphasized the shallow DTI modeling nature of the existing attention-based approaches and proposed a superior approach of modeling semantic inter-dependencies in both spatial and channel dimensions to capture more granular atom-amino acid binding by assigning pairwise attention vectors. Similarly, GraphsformerCPI [68] integrates semantic and spatial structural features of compounds and proteins using a structure-enhanced self-attention mechanism, which provides interpretability. SMFF-DTA [69] represents structural information and physicochemical properties of drugs and targets sequentially with innovative encoding and employing multiple attention blocks.

While approaches like BiCOMP-DTA [70] propose a unified, complementary protein encoding measure (BiComp) to address the computational overheads, complexity, and reliance on multiple data sources of existing DTA methods and showcase consistent results in cold-start scenario, MGDTI [71] employs a meta-learning framework that rapidly adapts to unseen tasks, incorporating drug-drug and target-target structural similarity to mitigate data scarcity.

BINDTI [72] provides an end-to-end framework that encodes drug features using GCNs and protein features with a mixed ACmix model and fuses these features through a bi-directional Intention network. FragXsiteDTI [73] leverages information-rich representations from drug molecule fragments and protein pockets and employs a transformer-based architecture with a learnable latent array that acts as a mediator for seamless and insightful information translation. It demonstrates high interpretability by attention score visualization for binding sites.

PLMs are pre-trained on large amounts of data. Thus, they are most suitable for small-sample learning and often perform better in cold-start scenarios. DTI-BERT [74] utilizes pre-trained BERT (ProtBert) for context-aware protein sequence features and Discrete Wavelet Transform for drug molecular fingerprints. DTI-LM [75] leverages PLM for sequence encoding and enhancing these representations with neighborhood information through GATs. They discussed the usefulness of pre-trained models, especially for proteins, in handling cold-start problems. LANTERN [76] integrates LLMs and Transformer-based architectures to generate high-quality, context-aware embeddings for drug and protein sequences and employs a Transformer-based fusion mechanism that enhances scalability, predictive accuracy, and generalizability without requiring 3D structural data. G-K BertDTA [77] proposed a novel framework that integrates protein features using a redesigned DenseSENet (DenseNet with Squeeze-and-Excitation blocks), molecular structural information using an improved Graph Isomorphism Network (GIN) with CNNs for high-dimensional feature extraction from SMILES, and rich pre-trained molecular semantic embeddings from a knowledge-based BERT (KB-BERT) model. LLMDTA [78] uses pre-trained biological LLMs (Mol2Vec for drugs and Evolutionary Scale Modeling-2 (ESM-2) for proteins) as feature extractors and employs a bilinear attention module. Table 1 provides a brief overview of such approaches that utilize language models for extracting features from biological entities.

DLM-DTI [79] adopts a hint-based learning strategy with a compact student model that blends general and task-oriented knowledge. Due to including simple, fully connected layers, this approach performs poorly in cold-start scenarios. Potential strategies to handle the cold-start scenario could have been integrating a squeeze-and-excitation, capsule, and cross-attention network. MiRAGE-DTI [80] addresses the challenges existing DTI models face in effectively representing complex biological data, integrating diverse data sources, ensuring scalability, handling sparse and noisy datasets, and maintaining interpretability, along with class imbalance and data variability, by incorporating diverse drug and target similarity measures (structural, functional, and interaction-based) into a unified model.

GRA-DTA [81] employing a soft attention-based Bidirectional Gated Recurrent Unit (BiGRU) for protein features, GraphSAGE for drug graph representations, and an attention neural network. This approach showcased good results in the cold-start scenario when adequate unique drugs were present. MultiKD-DTA [82] addresses the limitations of GNNs susceptible to overfitting and CNNs/Transformers requiring fixed-length protein sequences leading to information loss by integrating a novel multiscale Wide and Deep CNN after GIN for enhanced drug feature exploration (both depth and breadth) and utilizing the ESM-2 pre-trained model with a BiLSTM network. To improve the interpretability of this approach, they applied t-distributed stochastic neighbor embedding for dimensionality reduction on the dataset.

List of models utilized LLMs for feature encoding

## Section: Background › Post-deep learning era › The current frontier: multi-modal fusion, integration, and generation

Relying on the efficient feature learning capabilities of the attention mechanism, the current era is witnessing the amalgamation of multi-modal feature fusion, multi-level data stacking, and more PLM-based embedding generation while maintaining model interpretability.

Yang et al. emphasized dynamic learning by introducing a mutual learning mechanism using multi-headed attention and position-aware attention in their approach named ML-DTI [83], enabling bi-directional information flow between drug and target representations. It shows interpretability by mapping attention weights to protein sequences and compound molecules. Later, Yuan et al. proposed FusionDTA [84], which utilizes a multi-headed attention mechanism where the conventional rough pooling is replaced with global information aggregation and adopts a teacher-student model approach where learnable information is transferred from the teacher model to student model to reduce model complexity while maintaining performance, even in the cold-start scenario.

Singh et al. proposed ConPLex [85], which addressed that existing DTI methods suffer from ground-truth data scarcity and are highly dependent on physicochemical similarity-based modeling, which makes these models unable to distinguish true-positive binding compounds from physicochemically similar false positives (“decoys”). ConPLex handles these two limitations using two distinct modules: The “Con” module employs protein-anchored contrastive learning, which can distinguish positive compounds from decoys specifically, and the “PLex” module utilizes pre-trained protein language models (PLMs) to adopt knowledge from millions of protein sequences to handle the data scarcity issue.

Although attention mechanisms display superior binding prediction performance compared to other methods, binding prediction often relies on learned attention weights, lacking real-world biological insights. To mitigate this drawback, Hua et al. introduced MFR-DTA [86] that incorporates a BioMLP/CNN block along with a Mix-decoder block that relies on supervised learning with actual binding site information and learns by extracting element-wise and global features form biological sequences. In a similar approach, Ma et al. proposed a model named MSF-DTA [87] that gathers additional information from “neighboring” proteins in protein–protein interaction (PPI) and sequence similarity networks (SSNs) for more informed prediction.

To discuss the multi-modal approaches, Maroua et al. integrated tri-modality representations (molecular images, chemical sequences, and graph representations of drugs) to comprehensively capture structural, spatial, and functional aspects in their proposed approach called TriCvT-DTI [88]. Similarly, Debnath et al. proposed GramSeqDTA [89] that employs a Grammar Variational Autoencoder for drug feature extraction to learn semantic and syntactic rules and by fusing chemical perturbation (gene expression) information from the L1000 [90] project to incorporate functional features. HMSA-DTI [91] takes multiple drug and protein representations as input and employs a hierarchical multi-modal self-attention mechanism to fuse features deeply. MGSDTA [92] integrates both graph features and pre-trained sequence embeddings (from Mol2vec for drugs and ProtVec for targets) into a unified multi-modal framework with a weighted fusion module, suitable for handling cold-start problem. Luo et al. developed DrugLAMP [93] that leverages PLM and traditional feature extractors, coupled with novel multi-modal fusion modules (Pocket-Guided Co-Attention (PGCA) and Paired Multi-Modal Attention (PMMA)) and a contrastive pre-training module to align features across modalities and conditions. This model has outperformed previous state-of-the-art in cold-split settings and demonstrates high interpretability by visualization of attention maps.

Talo et al. proposed Top-DTI [94] to address the limitation of existing DTI prediction methods overlooking crucial topological components and structural data and facing challenges in cold-split scenarios for unseen drugs or targets by integrating Topological Data Analysis to extract topological features from protein contact maps and drug molecular images, while simultaneously employing LLMs to generate semantically rich embeddings from sequences. Another approach that explicitly handles the cold-split scenario is ColdDTA [95], which employs a data augmentation strategy that generates new drug-target pairs through subgraph removal and utilizing an attention-based feature fusion module to integrate drug and protein features better. Instead of a random split, the model performance is evaluated exclusively in cold-split settings. It provides model weights visualization from interpretability.

MMDG-DTI [96] addresses the limited generalization ability of existing deep learning DTI methods to unseen samples and unfamiliar domains, caused by their reliance on source-domain-restricted prior knowledge and susceptibility to redundant domain information by leveraging pre-trained LLMs for generalized textual features. They provide visualization of the high-response regions of protein–drug pairs for an interpretable verification of their method. Similar feature stacking-based approaches include DrugKANs [97] that integrates a dual-tower architecture with Kolmogorov–Arnold Network technology to enhance quality and interpretability, utilizing pre-trained models for initial representations, employing a lightweight attention mechanism and feature interaction to capture key features and mitigate overfitting. Developed by Shi et al., SSCPA-DTI [98] is an interpretable approach that extracts both original and sub-structural features from drug and protein sequences using a multi-feature Information Mining Module (MIMM) and then interactively integrating these features and extracting interaction information using a Cross-public attention mechanism (CPA). MultiGranDTI [99] showcased an explainable multi-granularity representation framework that integrates atomic and sub-structural information for drugs via a hierarchical network and models multi-order sequence and spatial data for proteins. AMMVF-DTI [100] extracts interactive features from both node-level and graph-level embeddings, enabling more effective capture of local and global structural information.

Approaches that address the issue of interpretability include IMAEN [101], which employs a molecular augmentation mechanism and an interpretable stack convolutional encoding module. DrugAgent [102] integrates multiple specialized AI agents (ML, Knowledge Graph, Search) that leverage Chain-of-Thought and ReAct frameworks to provide transparent, human-interpretable reasoning for each prediction.

The unavailability of large-scale positive interaction data makes deep learning models poorly distinguish between binders and non-binders. Thus, Zhang et al., in their proposed model named PLANET [103], proposed a multi-objective training approach that learns from non-binders collected from ChEMBL and performs tasks including affinity prediction, protein-ligand contact map prediction, and ligand distance matrix prediction. This approach allows contact map-based rescaling of energy contributions from interacting residue-atom pairs. Several other approaches adopted the multitask prediction architecture, namely DTIAM [104] employs self-supervised pre-training on vast amounts of unlabeled drug molecular graphs and protein sequences to learn comprehensive representations for accurate DTI, DTA, and MoA prediction. Shah et al. developed a novel multitask learning framework that simultaneously predicts DTB affinities and generates new target-aware drug variants using standard features called DeepDTAGen [105] that shows robustness in the DTA prediction through (i) drug selectivity, (ii) Quantitative Structure-Activity Relationships analysis, and (iii) cold-start tests.

## Section: Popular benchmarks

This section discusses the most frequently used benchmarks for DTI and DTA tasks from the surveyed literature:

Statistics of most frequent benchmarks

Frequency distribution of top ten most frequent datasets used in the surveyed methods.

## Section: Popular benchmarks › BindingDB

BindingDB [20] contains experimental binding affinities between small molecules and protein targets and pharmacological annotations of the entities (e.g. ID, Structure etc.). The affinity records are sourced from popular biological database like ChEMBL [106], PDB [107], PubChem [108], and UniProt [109]. Even though the total no of records is very large, but researchers usually preprocess this dataset as per their requirement.

## Section: Popular benchmarks › BioSNAP

BioSNAP [110] was created by multiple researchers and is sourced from DrugBank [111] database. This dataset ensures a balance in the number of negative and positive samples.

## Section: Popular benchmarks › Caenorhabditis elegans

Curated by Liu et al. [112], C.elegans is a balanced DTI dataset. The positive instances are sampled from DrugBank [111], Matador [113], and STITCH [114] databases. Originally only contains positive samples, the highly credible negative samples are generated using an in silico screening method based on the assumption that similar compounds interact with the proteins similar to known proteins.

## Section: Popular benchmarks › Davis

As the survey suggests, Davis [115] is the most widely used dataset for benchmarking DTI and DTA models. Davis consists interaction information from the selectivity assay of the kinase protein family and corresponding inhibitors from their original experimental study. For DTA tasks, the affinity information between drugs and targets is given as K\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $_{d}$\end{document}(dissociation constant) measurements.

## Section: Popular benchmarks › DrugBank

Curated by Zhao et al. [67], DrugBank is created by sourcing positive interactions from DrugBank (v5.1.5). Drugs which are inorganic compounds, very small molecule compounds [e.g. Iron (DB01592) and Zinc (DB01593)] or those of which the SMILES string cannot be recognized by RDKit [42] python package are then discarded. Further sampling is performed from the unlabeled drug–protein pairs to generate negative samples and obtain a balanced dataset with equal positive and negative samples.

## Section: Popular benchmarks › DTINet

Created by Luo et al [28], DTINet is a heterogeneous network. It contains four types of nodes—drugs, proteins, diseases and side effects, and the nodes are inter-connected by eight types of interactions, including drug-protein interactions. The nodes information are extracted form DrugBank(drugs), HPRD(proteins with UniProt IDs) [116], Comparative Toxicogenomics Database(disease) [117] and SIDER(side-efects) [118] databases.

## Section: Popular benchmarks › DUD-E

DUD-E [21] is a robust, high coverage dataset for structure-based virtual screening methods. It is a well-known benchmark consisting of 102 targets across 8 protein families. On average, each target has 224 actives and each active has 50 decoys. Decoys are chosen in such a way that they are physically similar but topologically dissimilar to the actives.

## Section: Popular benchmarks › Gold-standard

Created by Yamanishi et al. [10] by sourcing KEGG BRITE [119], BRENDA [120], SuperTarget [113], and DrugBank databases, this dataset contains high-quality positive interactions and is one of the earliest DTI benchmarks. It is consists of four sub-datasets: Enzymes, GPCRs, Ion Channels (ICs), and Nuclear Receptors (NRs).

## Section: Popular benchmarks › Human

Similar to C.elegans dataset, Human is a balanced DTI dataset is curated by Liu et al. [112], where the highly credible negative samples are generated based on the assumption that similar compounds interact with the proteins that are similar to known proteins.

## Section: Popular benchmarks › KIBA

Similar to Davis, KIBA [121] is one of the most widely used benchmarks for DTI and DTA tasks. KIBA contains the largest collection of binding informations for kinase family proteins and corresponding inhibitors sourced from widely used bioactivity databases like ChEMBL and STITCH. The binding affinity is measured using KIBA, which is a statistical combination of IC\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $_{50}$\end{document}, K\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $_{d}$\end{document}, and K\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $_{i}$\end{document} values.

## Section: Popular benchmarks › PDBBind

PDBbind [122] contains collection of experimentally validated DTB affinity samples from PDB, with available 3D structures of the drugs and targets. The dataset is distributed into three sub-datasets—general, refined and core. The general set contains all drug-target complexes from the PDB databses, the refined set contains refined, high-quality binding affinity measurements.

Table 2 and Fig. 2 summarizes the statistics and the usage frequency of the aforementioned benchmarks, respectively.

Statistics of most frequent benchmarks

Frequency distribution of top ten most frequent datasets used in the surveyed methods.

## Section: Evaluation metrics

The selection of appropriate evaluation metrics is of utmost importance for a thorough comparative analysis of the performances of different computational approaches for DTI prediction. Here, we discuss some of the most frequently used evaluation metrics in DTA and DTI prediction tasks.

Frequently used metrics across DTI prediction methods: (a) Accuracy, (b) Precision, (c) Recall, (d) F1, (e) AUPR, and (f) AUROC.

Frequently used metrics across DTA prediction methods: (a) CI, (b) MSE, (c) PCC, and (d) r\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $^{2}_{m}$\end{document}.

## Section: Evaluation metrics › Evaluation metrics for DTI prediction

In DTI predictions, the goal is to classify the likelihood of interaction between a drug-target pair. An interaction is positive if a drug-target pair is likely to interact, otherwise negative. In classification tasks, performance of a model is usually represented using the following components: True positive (TP), True Negative (TN), False Positive (FP), and False Negative (FN).

TP denotes the number of correctly predicted positive labels.

TN denotes the number of correctly predicted negative labels.

FP denotes the number of instances where the actual label is negative but the model predicts it as positive.

FN denotes the number of instances where the actual label is positive but the model predicts it as negative.

Evaluation metrics for DTI prediction are constructed combining the aforementioned components:

## Section: Evaluation metrics › Evaluation metrics for DTI prediction › Accuracy

Accuracy is defined as the fraction of correctly predicted labels, calculated as the sum of correctly predicted positive and negative instances over total number of predictions. The fraction is often multiplied by 100 to transform into a percentage.

## Section: Evaluation metrics › Evaluation metrics for DTI prediction › Precision

Precision, aka Positive Predictive Value is the fraction of correctly predicted positive instances, calculated as the number of correctly predicted positive labels over all the predicted positive labels.

## Section: Evaluation metrics › Evaluation metrics for DTI prediction › Recall

Recall, aka Sensitivity or True Positive Rate (TPR) is the fraction of actual positives correctly identified, calculated as the number of correctly predicted positive labels over all the actual positive labels.

sectionF1 Score F1 Score is defined as the harmonic mean of precision and recall, balancing both to measure the accuracy of a model handling false positive and false negatives, especially useful for imbalanced datasets.

## Section: Evaluation metrics › Evaluation metrics for DTI prediction › AUPR

Area Under the Precision-Recall Curve (AUPR) measures the trade-off between precision and recall, especially useful in imbalanced datasets where positive class is rare.

## Section: Evaluation metrics › Evaluation metrics for DTI prediction › Area under the receiver operating characteristic curve

Area under the receiver operating characteristic curve (AUROC) evaluates the ability of a model to distinguish between classes by calculating the area under the ROC curve plotting TPR against False Positive Rate (FPR) across different thresholds.

## Section: Evaluation metrics › Evaluation metrics for DTA prediction

In DTA prediction, the goal is predict a continuous label representing the degree of interaction between a drug-target pair. These labels are usually interaction coefficients like \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $ K_{d} $\end{document}, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $ K_{i} $\end{document}, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $ IC_{50} $\end{document}, or \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $ EC_{50} $\end{document}.

\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $ K_{d} $\end{document} (dissociation constant) is the equilibrium concentration at which half of the ligand-target complex dissociates, indicating binding affinity. Lower the value of \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $ K_{d} $\end{document}, higher the affinity between ligand-target complex. Similarly, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $ K_{i} $\end{document} (inhibition constant) represents the binding affinity of an inhibitor to its target, independent of the substrate concentration. Lower \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $ K_{i} $\end{document} indicates stronger affinity.

\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $ IC_{50} $\end{document} (inhibitory concentration 50%) signifies the concentration of an inhibitor required to reduce a biological activity (e.g. enzyme function) by 50%. Similarly, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $ EC_{50} $\end{document} (effective concentration 50%) denotes the concentration of a drug that produces 50% of its maximum effect.

Evaluation metrics for DTA prediction predicted are as follows:

Frequently used metrics across DTI prediction methods: (a) Accuracy, (b) Precision, (c) Recall, (d) F1, (e) AUPR, and (f) AUROC.

Frequently used metrics across DTA prediction methods: (a) CI, (b) MSE, (c) PCC, and (d) r\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $^{2}_{m}$\end{document}.

## Section: Evaluation metrics › Evaluation metrics for DTA prediction › Concordance index

Concordance index (CI) measures how well a model ranks predicted labels relative to the actual ones by evaluating concordant pairs—instances where the model predicts higher value for an actual high value label. A concordant pairing occurs when the predicted ranking is well aligned with the actual ranking, while a pair is called discordant when the ranking is incorrect. A CI value of 1.0 indicates perfect ranking while a vlue of 0.5 represents random performance.

where, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $y_{i}$\end{document}, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $ \hat{y}_{i} $\end{document}, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $Z$\end{document}, and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $h$\end{document} are actual labels, predicted labels, total number of comparable pairs, and a step function, respectively.

## Section: Evaluation metrics › Evaluation metrics for DTA prediction › Mean squared error

Mean squared error (MSE) measures the average squared differences between actual and predicted labels.

## Section: Evaluation metrics › Evaluation metrics for DTA prediction › Pearson correlation coefficient

Pearson correlation coefficient (PCC) measures linear correlation between predicted and actual labels, with +1 being a perfect negative correlation and +1 being a perfect positive correlation. It is one of the most widely used metrics used to capture the linear trend between the predicted and ground truth values.

## Section: Evaluation metrics › Evaluation metrics for DTA prediction › \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $r_{m}^{2}$\end{document} Score

First introduced in [30], \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $r_{m}^{2}$\end{document} score penalizes overfitting, assuring the accuracy and robustness of the model.

where, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $R_{0}^{2}$\end{document} is a variant of \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $R^{2}$\end{document}, Coefficient of Determination, computed without an intercept in the regression. \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $R^{2}$\end{document} can be defined as:

Figures 3 and 4 display the distribution of the most frequently used metrics in surveyed DTI and DTA prediction methods, respectively.

Frequently used metrics across DTI prediction methods: (a) Accuracy, (b) Precision, (c) Recall, (d) F1, (e) AUPR, and (f) AUROC.

Frequently used metrics across DTA prediction methods: (a) CI, (b) MSE, (c) PCC, and (d) r\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $^{2}_{m}$\end{document}.

## Section: Evaluation methodology

Methodological Description of Deep Learning Architectures for DTI Prediction

Methodological description of deep learning architectures for DTA prediction

Methodology of article selection procedure for DTB prediction and related topics.

Evaluation of DTI models on human dataset

Evaluation of DTA models on Davis dataset

Evaluation of DTA models on KIBA dataset

## Section: Evaluation methodology › Model selection

Conducting a comprehensive literature review is essential for identifying state-of-the-art evaluation techniques. This section outlines the methodology for selecting relevant works, primarily leveraging Google Scholar. Search queries were refined with keywords such as “AI,” “Deep Learning,” “state-of-the-art,” “Cancer Drug Discovery,” “Cancer Drug Repurposing,” “Peer-reviewed,” and “GitHub.” The search results were initially screened by evaluating the abstract, methodology, and results sections to determine relevance. Selected articles were then organized using Research Rabbit, a citation-based research mapping tool. Research Rabbit was further utilized to explore related works and trace relevant citations. Priority was given to studies offering comparative analyses of existing techniques. Additionally, the availability of open-source code was considered to facilitate ease of evaluation. The model selection procedure is discussed in detail in Fig. 5. Tables 3 and 4 provide brief descriptions about the DTI and DTA models selected for evaluation in this work, respectively.

Methodological Description of Deep Learning Architectures for DTI Prediction

Methodological description of deep learning architectures for DTA prediction

Methodology of article selection procedure for DTB prediction and related topics.

## Section: Evaluation methodology › Evaluation

In this section, we discussed about the evaluation outcomes for each of the selected models. The models were evaluated using key performance metrics—AUROC for DTI models and MSE and CI for DTA models. The performance variation across different models can be attributed to the diversity of their underlying architecture and modes of feature representations. Tables 5–7 showcases the performance of the models when evaluated on Human dataset for DTI models and Davis and KIBA dataset for DTA models, respectively.

Based on the evaluation results among DTI approaches on the Human dataset, we can observe that models focusing on multi-level and more sub-structure-specific methodologies show the best results, while models focusing on global-scale structural features only showcase sub-optimal performance. Most best-performing models integrate attention mechanisms and visualization capabilities that provide biological insights into binding mechanisms and critical interaction sites: FragXsiteDTI (AUROC 0.991) uses transformer architecture focusing on drug fragments and protein pockets; SSCPA-DTI (AUROC 0.992) extracts both original and sub-structural features through specialized mining modules; GraphsformerCPI (AUROC 0.990) treats molecules as structured sequences with dual-attention mechanisms. Meanwhile, IMAEN, which is designed for interpretability, comparatively shows lower performance (AUROC 0.954).

Evaluation of DTA methods on both the Davis and KIBA datasets shows that models using attention-based methods outperformed graph convolution and classical sequence-based approaches. 3DProtDTA (best CI 0.891 in Davis) uses AlphaFold predictions, FusionDTA (best CI 0.898 in KIBA) incorporates global feature aggregation using multi-headed attention, GS-DTA (CI 0.903, 0.895 in Davis and KIBA, respectively) uses GAT along with Transformer; are the best-performing models. While models including DeepNC (CI 0.876 in Davis) utilize graph convolution methods, GraphDTA (CI 0.878 in KIBA) uses trivial graph representation, and DeepDTA (CI 0.858 in KIBA) uses CNNs to extract features from 1D sequences; shows sub-optimal performance.

Evaluation of DTI models on human dataset

Evaluation of DTA models on Davis dataset

Evaluation of DTA models on KIBA dataset

## Section: Case studies: predictive modeling for drug–target binding in cancer

Case studies have been performed to predict potential compound-target relationships. We used a dataset of lead-like compounds from the GDB-17 database, with molecular weights (MWs) ranging from 100 to 350 and clogP values between 1 and 3. This dataset, consisting of \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} $\sim $\end{document}8 million compounds [123], was curated to exclude molecules with small rings containing 3 to 4 atoms. For the protein targets, we selected few of the most researched key proteins involved in cancer pathways from the GDSC database, as listed below: EGFR (Pathway: EGFR signaling, UniProt: P00533), Tyrosine-protein kinase ABL1 (Pathway: ABL signaling, UniProt: P00519), Serine/threonine-protein kinase mTOR (Pathway: P13K/MTOR signaling, UniProt: P42345), Cellular tumor antigen p53 (Pathway: P53, UniProt: P04637), Mitogen-activated protein kinase kinase kinase 1 (MAP3K1) (Pathway: ERK/MAPK signaling, UniProt: Q13233). Table 8 summarizes all target proteins.

EGFR is a tyrosine kinase receptor protein crucial in activating several signaling cascades to convert extracellular cues into designated cellular responses [124]. It regulates cell growth and survival and is frequently targeted in cancer therapy. Often, it is associated with lung cancer [125] and Neonatal nephrocutaneous inflammatory syndrome [126] development.

ABL1 is a non-receptor tyrosine kinase associated with key cell growth and survival processes, including cytoskeletal remodeling in response to extracellular stimuli, cell motility and adhesion, DNA damage response, and apoptosis [127]. It utilizes Mg2+ as its cofactor to operate. Chromosomal aberrations in ABL1 lead to fusion with the BCR gene, forming the oncogenic BCR-ABL1 complex, resulting in chronic myeloid leukemia [128]. ABL1 is also associated with acute lymphoblastic leukemia [129] and Congenital heart defects and skeletal malformations syndrome [130].

Associated with direct or indirect phosphorylation of over 800 proteins, mTOR is a Serine/threonine-protein kinase that is central to PI3K/AKT/mTOR pathway, playing a pivotal role in cellular growth and metabolism, response to hormones, growth factors, and other external signals [131]. It is part of two distinct signaling complexes, mTORC1 and mTORC2 [132]. It is associated with Smith–Kingsmore syndrome [133].

Upon binding with its target DNA sequences, p53 acts as a multifunctional transcription factor that regulates cell cycle arrest, DNA repair, and apoptosis, thereby acting as a tumor suppressor [134]. Uses Zn2+ as a cofactor. Mutations in p53 result in several types of cancers, including Esophageal cancer [135] and Li–Fraumeni syndrome [136].

MAP3K1 is an upstream regulator of the Extracellular signal-Regulated Kinase/Mitogen-Activated Protein Kinase (ERK/MAPK) signaling pathway. It activates the ERK and c-Jun N-Terminal Kinase (JNk) pathways by phosphorylating MAP2K1 and MAP2K4 [137]. It undergoes frequent alterations in various cancers, including breast and prostate cancer [138, 139].

Essentially the case studies can be divided into two categories: (i) case study for DTI prediction, and (ii) case study for DTA prediction.

Target proteins selected for case studies from GDSC database with corresponding gene, UniProt ID and pathway information

Top ten predicted compounds with highest binding probabilities against (a) Endothelial Growth Factor Receptor, (b) Tyrosine-protein kinase ABL1, (c) Serine/threonine-protein kinase mTOR, (d) Cellular tumor antigen p53, and (e) MAP3K1.

Top ten predicted compounds with highest KIBA scores against (a) Endothelial Growth Factor Receptor, (b) Tyrosine-protein kinase ABL1, (c) Serine/threonine-protein kinase mTOR, (d) Cellular tumor antigen p53, and (e) MAP3K1.

## Section: Case studies: predictive modeling for drug–target binding in cancer › Case study-I: DTI prediction in cancer

We chose FragXsiteDTI as the inference model to run a case study for DTI predictions, as it shows exceptional AUROC values when evaluated with the Human dataset. Moreover, FragXsiteDTI utilizes a state-of-the-art transformer-based approach for analyzing fine-grained interaction between compound fragments and protein binding pocket, avoiding the consideration of redundant complete structures of the compound and protein. DTI prediction aims to calculate the probability of binding between a drug and a target pair. The probability can lie between 0 and 1. We chose a threshold value of 0.5, below which we can nullify the interaction. Against all five proteins selected as targets, we iteratively test the GDB-17 compounds.

## Section: Case studies: predictive modeling for drug–target binding in cancer › Case study-II: DTA prediction in cancer

FusionDTA is used for inference involving DTA predictions on GDB-17 compounds. We chose FusionDTA as it has fewer failure rates than DTA models working with 3D structural protein data, which sometimes tend to be sensitive to the quality, conformational state, and structural flexibility of the 3D protein structural data. Moreover, FusionDTA was one of the early attempts where a language model (ESM-1b) was incorporated in a DTB prediction architecture. In addition, FusionDTA pioneered the handling of the cold-start problem. In summary, the multi-dimensional functionality of the FusionDTA approach made us choose FusionDTA as our go-to model for the large-scale downstream analysis.

## Section: Case studies: predictive modeling for drug–target binding in cancer › In silico downstream analysis—evaluate drug-likeness

The predicted compounds require rigorous experimental validation to substantiate their efficacy on the selected targets. Experimental validations of these extensive predictions can be exponentially time-consuming and costly. However, we can mitigate the risk of nullifying the predictions by conducting in silico downstream analysis to gain estimates on their performance within a living system. Therefore, we performed further downstream analysis on the predicted compounds to evaluate their drug-likeness. In this analysis, we tested the compounds against some criteria crucial to drug development.

We applied Lipinski’s Rule of Five [140] and the Veber test [141]. According to Lipinski’s Rule of Five, a compound is considered drug-like if it satisfies the following conditions:

Veber’s Rule checks the molecular flexibility and permeability of a compound, which aids in oral bioavailability. It states that a drug may have good oral bioavailability if it meets the following criteria:

We also assessed basic criteria that define the ADMET (Absorption, Distribution, Metabolism, Excretion, and Toxicity) [142, 143] profile of a drug-like compound, specifically solubility, permeability, hERG risk [144], and the AMES test [145]. Another critical metric is the blood–brain barrier (BBB) permeability, which is defined by the ability of a drug to traverse the protective barrier that restricts the entry of harmful substances from the bloodstream into the brain while permitting the passage of essential nutrients. However, this criterion is only relevant for drugs of the central nervous system [146]. Various physicochemical properties contribute to defining these criteria, with their acceptable values outlined as follows:

Absorption of a drug through the gastrointestinal (GI) lining plays a crucial role in its distribution and, consequently, its effect on the designated target [147]. Certain criteria must be met for GI absorption, which are as follows:

Synthetic accessibility [148, 149] defines the ease of synthesis of a compound, ranging from 1 (easily synthesizable) to 10 (difficult to synthesize). It is a crucial aspect of drug discovery, particularly in the synthesis of de novo drugs.

The in silico analysis emphasizes the significance of drug-likeness filters, as the filtered compounds meet the physicochemical requirements essential for being lead compounds. The analysis results identify those compounds with the potential to pass experimental validation. We showed the top ten compounds predicted to have the highest probabilities to bind to each target protein in Fig. 6, all of which meet the drug-likeness criteria mentioned above. Importantly, we also mention the predicted probabilities of binding along with the figures for comprehension. Similarly, Fig. 7 presents the top ten predicted compounds with the highest binding affinity scores for selected target proteins. As for the DTA case study, the predictions were made using the FusionDTA model pre-trained on the KIBA dataset; the Affinity values represent KIBA scores for compound-target pairs.

Case studies suggest that most of the compounds predicted with high binding probabilities in the DTI case study also showcase good binding affinities for the DTA case study, which emphasizes the mutual accountability and coherence of the case studies. Notably, most top-ranked compounds in each case study exhibit aromatic, cyclic, and heterocyclic functional groups. Literature suggests these structural motifs are prevalent in known protein kinase inhibitors and other cancer-related therapeutic agents. These findings underscore the importance of the predicted compounds as potential lead candidates for targeting kinases in cancer therapies, with room for further modifications. This analysis bridges the gap between computational prediction and practical drug development.

Approaches like multi-omics integration for personalized target selection and incorporating tumor heterogeneity data to predict context-specific interactions can provide potential means of addressing critical oncology-specific challenges through DTB models. However, current approaches struggle with the dynamic evolution nature of cancers and lack sufficient training data for rare mutations. Off-target toxicity prediction remains inadequate due to an incomplete understanding of cancer-specific protein interactions and resistance mechanisms.

Top ten predicted compounds with highest binding probabilities against (a) Endothelial Growth Factor Receptor, (b) Tyrosine-protein kinase ABL1, (c) Serine/threonine-protein kinase mTOR, (d) Cellular tumor antigen p53, and (e) MAP3K1.

Top ten predicted compounds with highest KIBA scores against (a) Endothelial Growth Factor Receptor, (b) Tyrosine-protein kinase ABL1, (c) Serine/threonine-protein kinase mTOR, (d) Cellular tumor antigen p53, and (e) MAP3K1.

## Section: Challenges and limitations

Classical and reverse pharmacology approaches have limitations in identifying new molecular entities (NMEs). The process is time-consuming, expensive, and often has high failure rates. Deep-learning-based drug discovery approaches hold immense potential in developing NMEs for various diseases. However, some challenges and limitations must be addressed and bypassed for effective implementation of the approaches.

One major challenge is the quality and quantity of the available data resources. Deep learning models thrive on large volumes of high-quality data for training. Researchers must ensure that the data for training deep learning models are precise, representative, and related to specific research objectives. Addressing data limitations, such as biases or incomplete datasets, is prioritized to avoid skewed results and unreliable conclusions. For instance, two of the most used benchmark datasets in DTB prediction models are Davis and KIBA—which we also used for our evaluation task. Both of these datasets represent kinase–inhibitory compounds in their drug set. Models trained on these two datasets thus only capture drug features effective against kinase and similar proteins. Even though, as per the studies, kinase proteins play a crucial role in various cancer progressions, targeting only those proteins creates a void in research focusing on related proteins playing a crucial role in the overall cancer microenvironment. Curating such a dataset, which includes other important kinase proteins, is highly important to avoid bias toward developing compounds effective against kinase-proteins only.

Considering effective representation strategies for drugs and proteins is also a crucial aspect of constructing a model. From the evaluation outcomes above, it is evident that structure-based approaches perform better than the models considering sequence information only. The reason can be the definite topological skeleton information carved in the structural representations of the biological entities, which aids the models in extracting meaningful and natural biological features from those representations. Upon administration, drugs enter the human system in their complete structural form (3D), which is then transformed into subsequent simpler forms through absorption, digestion, and metabolism. Thus, considering the complex structural form as the representation’s starting point is the most meaningful approach to mimic the natural compound activity inside the human system. The same goes for the target proteins. Proteins take their most stable quaternary form inside the human system. Thus, considering that particular form as the starting point and extracting biologically relevant structural features from those makes the utmost sense. Although graph-based approaches can model complex representations of biological entities from their primary representations, experimentally validated complex structures are more trustworthy and meaningful. Resources like AlphaFold are gaining popularity with their highly accurate predicted 3D protein structures, but such a resource for compounds is still unavailable.

Experimental validation of the predictions adds more weight to the outcomes, as the final goal is to design a real-life compound to be administered in the human system. The cycle starts with lab-scale testing of the compound, followed by a mouse model, and finally, clinical trials on humans. The absorption, digestion, metabolism, and excretion profile must be monitored upon administering a compound in a human system. The process is standardized and proven effective in analyzing a compound’s efficacy and side effects before proceeding with its large-scale manufacturing. Nevertheless, starting from the lab-scale experiments and industry-scale manufacturing, the process demands a lot of time and economic resources, often with high failure rates. On top of that, there are frequent regulatory alterations and ethical concerns. Thus, instead of de novo compound design, drug repurposing is gaining much importance, which talks about using existing drugs that have proven effective for one disease and can be used for another.

In summary, deep learning-driven DTB prediction presents exciting opportunities, but the aforementioned concerns must be addressed. Deep learning approaches provide possibilities for revolutionizing the field by speeding up the identification of DTBs. However, the challenges and limitations mentioned above emphasize the importance of interdisciplinary collaboration, better data curation, innovative yet practical representations, and ethical and scientific considerations. Overcoming this obstacle will lead to the successful integration of deep learning in DTB prediction and ultimately fuel innovation across the computational drug discovery domain.

## Section: Discussion and future scope

The AI-driven drug discovery market is growing daily and is projected to grow significantly in the coming years. Advancements in AI technologies, such as machine learning, deep learning, and natural language processing, have developed sophisticated algorithms capable of analyzing complex biological data and predicting DTBs. Deep learning models actively analyze large compound libraries and databases to identify potential compounds against specific targets and diseases with higher accuracy and efficacy than traditional methods. Nevertheless, each methodology class evaluated for DTB prediction has advantages and disadvantages.

Sequence-based methods are good when the primary sequence information for compounds and targets is available, but they often lack generalizability and struggle with capturing high-dimensional molecular interactions. Graph-based methods can effectively analyze structural dependencies in molecular graphs, but they are computationally heavy and often depend on the availability of high-quality structural data. Attention-based methods can model long-range dependencies, and utilization of multi-headed attention enables better feature aggregation but often requires large datasets for optimal performance and is sensitive to dataset biases and inconsistencies. Hybrid models integrate multiple representations and embeddings to enhance affinity prediction but often result in complex model architectures. Studies also suggest that models that are pre-trained on large amount of relevant molecular/biological data are more suitable for small-sample learning.

The literature from both the pre-deep and post-deep learning eras shows that integrating additional information other than drug and protein improves the DTB prediction efficiency. Supplementary information, including PPI, drug-drug interaction, drug-disease relationship, gene-disease relationship, side-effect information, and chemical perturbation information, play crucial roles in DTB prediction by working as an additional modality.

Targeting specific proteins in human proteomes is a conventional practice in targeted cancer therapy. The pre-deep learning era was all about trial and error testing and statistical analysis-driven approaches for DTB predictions on selected proteins, which is now directed toward a more precise approach leveraging the data-driven decisions post-deep learning era. The human genome contains an estimated 6000–8000 potential drug targets, but only a tiny fraction have been exploited for drug development. This vast untapped potential highlights the need for continued research and development in DTB prediction. The availability of experimentally validated and high-confidence predicted structural data sources will play a crucial role here.

To effectively address critical data quality issues including label bias and class imbalance in model training and generalization, researchers must systematically adopt comprehensive intervention strategies. This specifically requires deploying advanced sampling techniques like SMOTE and cost-sensitive learning, establishing robust multi-source annotation protocols with uncertainty quantification, and implementing sophisticated ensemble frameworks with adaptive loss functions. These strategic approaches will ensure highly reliable, generalizable DTB prediction models that can effectively overcome fundamental dataset limitations completely.

The cold-start problem arises when models perform poorly when tested on unseen data, which reflects their performance in real-world scenarios. Various approaches have been adopted to improve model performance in cold-start scenarios. One such approach is enabling domain adaptation through adversarial training, which addresses the distribution shifts between training and test scenarios. An alternative strategy involves capturing robust, generalizable features using methods like feature fusion and representation learning. A further methodology discusses generating diverse drug-target pairs by systematically removing drug sub-graphs to enhance topological generation. Another complementary approach is to adopt a meta-learning framework that enables adaptation to novel scenarios by learning optimal parameter initialization strategies from historical tasks. In more recent approaches, pre-trained molecular representations sourced from language models are used to get the structural priors of biological entities that improve zero-shot prediction capabilities. However, challenges remain in making biologically and chemically feasible predictions, which is an active area of research and requires major innovation.

Most of these DTB models usually get integrated in industry-scale drug discovery piplines as early stage filters and are often combined with ADMET prediction models for pharmacokinetic filtering. Integration occurs through APIs or embedded modules that output confidence scores and binding predictions. However, their real-world impact remains limited—most models show poor performance on novel targets due to training bias toward well-studied proteins.

The future of DTB prediction lies in leveraging advancements in computational power, data analysis, and AI to develop more sophisticated and accurate models. With an increasing number of advanced DTB models, concerns regarding the ’black box’ limitations of these models are increasingly prominent. Several approaches incorporate interpretability to their models using methods namely attention weight visualization, attention focusing and mapping attention weights back to protein sequences and compound molecules. These models adopt the approach of domain-specific knowledge integration. However, these models are computationally demanding and often face the challenge of knowledge graph bias. These limitations must be addressed in future developments.

As regulatory agencies, such as the FDA, continue to embrace AI applications in drug development, the market potential of AI in the pharmaceutical industry is expected to grow further. However, challenges remain, including data privacy concerns, the validation of AI models, and the integration of AI with existing drug development processes.


---

# A Tutorial and Use Case Example of the eXtreme Gradient Boosting (XGBoost) Artificial Intelligence Algorithm for Drug Development Applications

- **Authors:** Matthew Wiens, Alissa Verone-Boyle, Nick Henscheid, Jagdeep T Podichetty, Jackson Burton
- **Issuer:** Clinical and translational science
- **Type:** Scientific article
- **Published:** 2025-03-01
- **Language:** en
- **DOI:** 10.1111/cts.70172
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40067353/
- **Licence:** CC-BY-NC

## Section: Abstract

ABSTRACTApproaches to artificial intelligence and machine learning (AI/ML) continue to advance in the field of drug development. A sound understanding of the underlying concepts and guiding principles of AI/ML implementation is a prerequisite to identifying which AI/ML approach is most appropriate based on the context. This tutorial focuses on the concepts and implementation of the popular eXtreme gradient boosting (XGBoost) algorithm for classification and regression of simple clinical trial‐like datasets. Emphasis is placed on relating the underlying concepts to the code implementation. In doing so, the aim is for the reader to gain knowledge about the underlying algorithm and become better versed with how to implement the algorithm functions for relevant clinical drug development questions. In turn, this will provide practical ML experience which can be applied to algorithms and problems beyond the scope of this tutorial.

## Section: Introduction

The goal of this tutorial is to enable the reader to understand and implement the XGBoost machine learning (ML) algorithm for both classification and regression tasks. The implementation is in the R programming language, utilizing open‐source packages and open‐source clinical trial‐like datasets given the wide use of R in the field of clinical pharmacology and pharmacometrics. The ideal audience for this guide is those familiar with clinical trial data and some proficiency in R coding, but with no significant experience in hands‐on implementation of machine learning algorithms. Significant emphasis will be given to the conceptual framework that underpins the XGBoost algorithm to help the reader cultivate intuition behind the methods. This tutorial will not only aid the reader in understanding the implementation itself, but also address some of the “black box” vernacular that is common with artificial intelligence (AI) approaches. Note that XGBoost is only one of the many choices available for AI/ML algorithms. It was selected for this tutorial because of its popularity, flexibility, and generally good performance across a range of datasets.

## Section: Introduction › Tutorial Structure

For readers new to XGBoost, an introductory description and brief history of the algorithm are provided in addition to some features that differentiate it from existing methods for classification and regression.

The “AI/ML Applications in Drug development” section provides an overview of the types of use cases where XGBoost and general artificial intelligence/machine learning (AI/ML) approaches have been applied in drug development.

The “Working Example” section provides an overview of the problem, including the underlying dataset used for the implementation of the classification example. The focus for this hands‐on example is to provide comprehensive code implementation details. A second dataset and corresponding regression problem are then described, and details of adapting the code from classification to regression are provided.

The “Background Concepts” section contains the underlying technical aspects of the XGBoost algorithm accompanied by a basic numeric example. The basic example borrows data from the working example but only for illustration purposes. The section concludes with an overview of the common hyperparameters and optimization features of XGBoost.

The “Data Pre‐processing” section briefly covers the importance of understanding the clinical and biological context of the data. Within this section, the “Code for Data Preprocessing and Model Preparation” provides step‐by‐step instructions for preparing the data for building the XGBoost model. These include common transformations of different data types (categorical and ordinal variables) using R data wrangling packages such as dplyr.

The “Code Implementation for Classification” section covers step‐by‐step instructions for implementing the classification working example. Detailed descriptions of the code including function inputs and outputs are included. Code for model implementation and evaluation are also included. Special attention is given to hyper parameter tuning for optimizing the model performance and as a key general ML principle. Subsequently, in the “XGBoost for Regression” section, code is provided for adapting the code for a regression problem on a separate dataset. The reader is encouraged to generate this model based on learnings from the classification example.

Lastly, the “Discussion/conclusions” section outlines a summary of the tutorial and reemphasizes the types of applications appropriate for XGBoost. Important caveats of using the oversimplified case study are discussed.

A supplemental glossary file accompanies the tutorial, which contains essential terms defined throughout the main body of the tutorial. Words bolded in the main body indicate that they are defined in the glossary. In the glossary, a definition is provided with references. In this setting, more informal references were selected (online tutorials and websites) to lower the barrier to access to relevant teaching material. The reader is encouraged to refer to the glossary and references as needed. The data for the working example and model files are located in a GitHub repository (https://github.com/metrumresearchgroup/ascpt‐ml‐tutorial/).

## Section: What Is XGBoost?

XGBoost is a powerful and efficient learning method based on an implementation of gradient‐boosted decision trees. It is typically used for supervised learning tasks, particularly regression and classification problems. At a high level, XGBoost works by combining weak learners, such as decision trees, sequentially, with each new learner effectively correcting errors made by the previous ones. Similar to other supervised learning methods, such as neural networks, XGBoost seeks to minimize a loss function, such as mean squared error for regression problems or crossentropy loss for classification problems. XGBoost does so by sequentially building trees to fit the negative gradient of the loss function with respect to the predictions, in contrast to neural network training via backpropagation.

The history of XGBoost is intertwined with the broader evolution of machine learning, particularly the field of ensemble learning techniques. Ensemble methods, which combine multiple models to improve predictive performance, have been around since the early days of machine learning. The development of boosting, an ensemble method, was significantly advanced by Jerome Friedman's seminal work on gradient boosting in 2001 [1]. Friedman's gradient boosting machine (GBM) provided a powerful framework for combining weak learners (typically decision trees) to form a strong predictive model. Building on this foundation, the introduction of XGBoost by Tianqi Chen and Carlos Guestrin marked a major leap forward in the efficiency and scalability of gradient boosting algorithms [2]. Their 2016 work, “XGBoost: A Scalable Tree Boosting System,” presented at the ACM SIGKDD International Conference on Knowledge Discovery and Data Mining (KDD), demonstrated how novel algorithmic optimizations and system designs could significantly enhance the performance of gradient boosting models for real‐world data. Specifically, XGBoost includes an array of techniques to handle missingness, imbalanced data via weighting and large datasets in addition to other powerful software‐level optimizations.

## Section: Advantages of XGBoost Compared With Alternative Methods

There are many supervised learning algorithms available, with logistic regression for classification and linear regression for regression being perhaps the most widely known. In addition to these classic methods, a wide range of AI architectures exists, from a vast range of neural network methods, nonlinear “kernel” methods such as support vector machines, tree‐based methods, and various ensemble methods. Every architecture comes with performance and implementation overhead tradeoffs, with more complex methods offering potential state‐of‐the‐art performance but typically at a high implementation cost. While XGBoost can at first appear complex to understand and tune compared with other methods, its superior performance and versatility often make it worth the investment, especially in scenarios where high accuracy and predictive power are crucial. Implementation time overhead is partially mitigated by the powerful software features of the XGBoost framework, such as automatic hyperparameter tuning and robust missingness handling. Moreover, XGBoost is advantageous due to its ability to efficiently handle large datasets, its robustness against overfitting thanks to regularization, and its flexibility in tuning through various hyperparameters. Additionally, XGBoost has robust open‐source implementations in many major programming languages such as Python, C++, Julia, and R [3], with every implementation providing the same powerful features, allowing the user to use their preferred language. It should be emphasized that XGBoost's strength is best demonstrated on large, complex datasets. Smaller datasets may be more appropriately analyzed with simpler methods. In ML terms, XGBoost has lower bias because the model is more flexible but higher variance because it is more sensitive to the data than parametric methods such as logistic regression or linear regression.

One of the notable features of XGBoost is its ability to handle missing data during training and prediction phases. This capability is achieved through a process called sparsity‐aware split finding [2]. Additionally, XGBoost includes features like built‐in crossvalidation, which is essential when evaluating algorithm performance. The algorithm also benefits from being able to run on multiple cores during training, significantly speeding up computation times and making it scalable for larger datasets. Table 1 provides a comparison of XGBoost to established methods for classification and regression.

Comparison of XGBoost properties to established classification and regression methods.

## Section: AI/ML Applications in Drug Development

Exploration of ML algorithms that aid in clinical drug development questions is becoming widespread. The ability to predict the likelihood of achieving a clinically meaningful risk or outcome is a focus across new AI/ML tools as they permeate through the drug development landscape. As these methods evolve, predictions and outputs from AI/ML models should be validated, with assumptions stated, and clinical relevance over existing models/methodologies highlighted. It is also imperative that clinical development teams are familiar with these methods in order to critically assess conclusions supported by AI/ML.

ML algorithms, such as XGBoost, can be used to support predictions of the risk of disease worsening [4, 5], patient response to a therapy type [6], clinical outcomes or response [7, 8], or the risk of an adverse event occurring [9, 10]. XGBoost has been utilized in ML efforts to determine cancer‐related mutations in cell‐free, circulating tumor DNA, where the feature importance aspect of the algorithm improved data dimensionality and overall model interpretability [11]. ML‐based models are being explored for risk assessment in clinical settings. For instance, they are being used to assess the risk of mortality in individuals experiencing first‐episode psychosis, which could aid in determining the most appropriate therapy [12]. Additionally, they are being applied to predict the risk of developing Type 1 diabetes earlier (before symptoms arise), using data from electronic health records [13]. Furthermore, ML algorithms are also being investigated to aid in therapeutic drug monitoring, including both prediction of the correct therapeutic dose and prediction of drug concentration or exposure, in contrast to traditional Bayesian approaches [14, 15]. Finally, digital or virtual twin models are beginning to gain traction within the medical community [16].

ML is being used to strengthen and improve existing quantitative approaches in clinical development to build upon dose finding and selection methodologies. ML algorithms can help predict drug concentration, supplement or enhance pharmacokinetic model prediction, and can be applied in the development of critical exposure–response models informing optimal dose selection across different patient populations and age groups [17, 18, 19, 20, 21]. ML‐based tools are being developed to aid clinicians in decision making—such as predicting the optimal therapeutic dose based on the likelihood of achieving a predefined pharmacodynamic response [22].

In the clinic, AI is highly prevalent in the fields of medical imaging and radiomics [23, 24, 25, 26, 27]. The application of AI has been prominent in oncology, advancing cancer imaging and detection [24, 25]. Furthermore, ML and deep learning algorithms have become prevalent in the radiomics processing of large medical dataset evaluations [28]. Ge and colleagues have reviewed numerous examples of using AI/ML to extract data from PET/CT images and successfully classify tumors based upon EGFR mutational status [29]. Despite the widespread use, more learning is needed on how AI/ML and DL algorithms can be more relevant in the clinic. During the model building process, developers should consider any potential data or subgroup imbalances, how to minimize such effects, improve the integrity of data annotations, support translation from research to clinical settings, and avoid bias [23, 25, 27, 30]. For example, while datasets of natural images such as those used to train generative AI methods are vast in size, medical datasets are much smaller, and patient characteristics, protocols, and data preprocessing methods can vary substantially across institutions [27].

Outside of the purview of XGBoost, we note that AI is also being used to mine and extract information from electronic health record data with natural language processing. These efforts help in structuring, interpreting, and organizing medical datasets for use in current and future clinical research endeavors [31, 32, 33, 34].

## Section: Working Example

For this tutorial, the task is to predict which patients will have recurrence of breast cancer using nine predictive features in the open‐source dataset “Breast Cancer” from the UC Irvine Machine Learning Repository (Table 2) [35]. This dataset is a common example and benchmark in the Machine Learning literature and consists of 286 patients with breast cancer. Since the outcome is binary (recurrence = yes or no), this is a binary classification task. Notable features of the dataset include imbalanced classes, with 201 out of 286 patients having no recurrence; mostly ordered categorical type data for the predictors; and missing values for covariates. Note that we selected this dataset as a baseline to illustrate the implementation details of XGBoost, with the goal of understanding the method rather than comparing XGBoost's performance to other approaches or achieving state‐of‐the‐art results for this particular benchmark.

For a regression task, we consider a second dataset from a study on alcoholic drinks and liver function. This dataset can also be found on the UCI Machine Learning Repository [36]. In this example, the task is to predict the number of daily drinks based on several biomarkers of liver function, such as alkaline phosphatase levels. The model building is similar to the classification example, but we will discuss several key differences.

Breast cancer dataset features and their properties used in the working example.

## Section: Background Concepts

XGBoost numerical example.

## Section: Background Concepts › Conceptual Foundations

The purpose of this section is to provide the reader with an understanding of the fundamental concepts pertaining to the XGBoost algorithm. Gaining an understanding of these concepts enables users to understand which applications are ideally suited for using XGBoost, how the syntax of code implementation relates to the mechanism of the algorithm, and how to evaluate/tune a model. As stated earlier, this section is intended to be bottom‐up, beginning with the basic building blocks of the algorithm before advancing to more complex aspects using intuitive examples and illustrations.

## Section: Background Concepts › XGBoost Algorithm Concepts

The approach in XGBoost for assembling multiple weak learners (decision trees) to build a strong learner is based on gradient boosting. Conceptually, gradient boosting builds each new weak learner sequentially by correcting the errors, that is, the residuals, of the previous weak learner. Prediction for a new data point then makes use of the entire sequence of learners to arrive at a final prediction. In this manner, a more accurate overall prediction is generated. Note that more generally, gradient boosting performs sequential correction using the negative gradient of a loss function. For the most commonly used loss functions, these negative gradients are vectors of residuals, that is, actual minus predicted, so we will continue to use this intuitive terminology.

XGBoost uses decision trees as the weak learners and iteratively combines them into a single strong learner. Normal decision trees split the target based on the levels (or continuous value) of a feature into decision nodes. This process continues producing additional decision nodes until arriving at a final node, that is, a leaf node. The longest path from the parent node to the leaf node is called the tree depth (referred to as “tree_depth” in the R code). The general aim of decision trees was to generate leaf nodes with groups of targets that are as homogeneous as possible. The completed decision tree can then take new data as input and classify the input based on the decision node splits derived during training to classify the input.

Decision trees in XGBoost are used differently compared to the typical approach of making predictions directly. Instead, XGBoost trees are built to fit the residuals of the previous tree (or initial prediction) to improve the prediction iteratively. To help illustrate this overall process, an example is provided in Figure 1 with sequential steps. The decision tree embedded in this example is specific to the residual tree‐building step of XGBoost with the intent to provide a clear depiction of how XGBoost proceeds algorithmically.

In the example presented, the key concepts of gradient boosting are discussed. Practicality, XGBoost has additional algorithmic features that help improve its performance and accuracy (discussed later). Second, the mathematical approach to gradient boosting differs somewhat between regression and classification. Here we focus on gradient boosting for classification in line with the example, but the reader is encouraged to examine the additional resources highlighted for background on regression.

Mathematically, gradient boosting can be summarized as (1) Fkx=F0x+εT1x+εT2x+…+εTkx, where k is the number of trees, x is the vector of features, Fk is the current strong learner, F0 is the initial prediction (e.g., mean), ε is the learning rate, and Tn is the kth decision tree that helps in correcting the residuals from the previous prediction. It is important to note that for binary classification, Equation (1) predicts the log‐odds which is defined here as the natural logarithm of the ratio of yes to no for the target. Because these need to be converted to class probabilities, we perform the inverse logit transform given by Equation (2). Which is the logistic function (2) pkx=11+e−Fkx, where p is the class probability and x is a record (row of the data). This is interpreted as the probability of a recurrence event occurring. Once a decision threshold is selected (using ROC analysis, for instance), the final binary classifier can be defined. The probabilities in Equation (2) will be used to calculate the residuals at each step.

A brief numerical example is developed here that uses a subset of the breast cancer dataset. We show the steps to perform the details of the calculation of Equation (1).

In Figure 1, Step 1 a subset of the breast cancer dataset is provided with features including tumor size (ordinal) and radiation (binary yes/no) with the outcome class (recurrence [yes]/nonrecurrence [no]). Because of the ordinal nature of tumor size, it is assigned ordered integer values to represent each ordered level of the feature as noted in parenthesis in the Table of Figure 1, Step 1. The initiation of XGBoost starts with an initial prediction defined as F0 based on Equation (1), which is calculated as the observed log‐odds, that is, log (# yes/# no) shown in Figure 1, Step 2. Note that this initial prediction is identical for all observations. In theory, any initial prediction can be used, including the output of another classifier such as logistic regression.

Next, the residuals for this prediction must be calculated as Res_F0 = (Observed—Predicted). Given that we are working with probabilities, observed values for recurrent events are defined as 1 while observed values for nonrecurrent events are defined as 0. The residuals are then calculated for F0 shown in Figure 1, Step 2. Mathematically speaking, these values arise as the gradient of the crossentropy loss, but conceptually is not critical to understand this fact.

The next step highlights a key aspect of gradient boosting: A decision tree is built to predict the residuals. This approach iteratively corrects the errors of the previous prediction, making gradual improvements that result in a strong learner. This approach contrasts with methods like random forests, which use bootstrap aggregating (“bagging”) to train multiple trees independently on random subsets of the data and combine their outputs, rather than iteratively refining predictions. The steps to build the residual tree are as follows.

An initial node called the root node is specified, which contains all the current residuals, derived either from the initial prediction or from a previous tree. For simplicity, let's begin with residuals from the initial prediction, as seen in Figure 1, Step 3. The features are now used to split the root node into leaf nodes. For the sake of illustration, we will compare two proposed thresholds of tumor size and demonstrate how the “better” split is chosen based on something called maximum gain.

The metric used for determining optimal splits is based on the similarity score (SS) given by (3) SS=∑i=1nresiduali2∑i=1npriorpi×1−priorpi+λ, where residual i is the ith residual in the node, prior p i is previous predicted probability, λ is the regularization parameter, and n is the total number of residuals in the leaf. The parameter λ will be discussed later; for now, assume it is 0. An initial split for the leaf nodes is produced by using a threshold of tumor size above 1. The SS score is derived for each node as shown in Figure 1, Step 3. Note that in the SS, the residuals are summed first before squaring. Also note that initially, the prior p i values are simply the initial probabilities, p 0 derived in Figure 1, Step 2.

To determine an overall value for the quality of the split, a metric called gain is calculated, given by (4) Gain=SSLeft leaf+SSRight leaf−SSParent, where SSLeft leaf, SSRight leaf, and SSParent are the similarity scores for the left, right, and parent nodes. Recall that the parent node is the node from which the leaf nodes originated, which is currently the root node. Gain is calculated for different features with different thresholds chosen. The split resulting in the highest gain value is then determined to be optimal. In Figure 1, Step 3, the gain is calculated for the tumor size split using the threshold > 1. In Figure 1, Step 4, the same calculations are carried out, instead using a tumor size threshold of > 2. Note that the gain for tumor size > 2 is higher, which is based on the split using this threshold results in leaves with more homogenous groupings of residuals. Hence, the tumor size threshold > 2 results in the better split, and thus is kept going forward.

Building off the initial split using tumor size, the tree can be grown with additional leaf nodes to further separate the residuals. For simplicity, let us assume that the tree can be grown further using radiation (yes/no) as in Figure 1, Step 5. Note that since radiation is binary, no threshold is needed. Hence, gain values can be compared directly across different categorical features. Notice now that the resulting tree depth is 2 (the longest path from the root node to a leaf node). In XGBoost, the user specifies the maximum tree depth such that the tree can grow no larger, which prevents overfitting and reduces overall model complexity.

We now have a “best” tree for classifying the current residuals (i.e., ResF0). The reader is encouraged to check how a data point given by row in the data table of Figure 1, Step 1 leads to a specific leaf node. For example, the data in row one start at the root node, go to the right node (tumor size > 2), then go to the left leaf node (radiation = no) which contains the residual for that observation.

Before computing F1x, we need to convert the leaf nodes of T1x into a log‐odds form as they were derived based on probabilities. To calculate the output value for each leaf (LO) into a log‐odds form, we use a formula very similar to the SS given by (5) LO=∑i=1nresiduali∑i=1npriorpi×1−priorpi+λ, where the variables are defined similarly as in Equation (3). The calculation for each leaf node is shown in Figure 1, Step 5. Each observation, therefore, begins in the root nodes and then arrives at a leaf node with a specific log‐odds value defined by Equation (5). For example, row 2 in Figure 1, Step 1 arrives at the blue node Figure 1, Step 5. In other words, T1row2 = 0.66.

We are now ready to generate F1 as we have T1, F0, and ε, which is the learning rate hyperparameter (referred to as “learn_rate” in the R code). Here we will assign it the value of 0.3. Conceptually the learning rate helps reduce overfitting, but a very low value will require a greater sequence of trees to be generated. From Equation (1), we have F1x=F0x+εT1x. F1x is calculated as shown in Figure 1, Step 6 for the data from the first row, noting that T1row1=1.5. To determine the probability of cancer recurrence based on F1, that is, our target, we convert F1x to a probability via Equation (2). At this point, the residuals of F1x may be calculated, and the process can repeat with a new tree for F2x. The reader is encouraged to calculate the remaining values for F1x and the residuals for F1x.

A few comments are made regarding the example. First, the origins of Equations (3) and (5) are derived from minimizing the loss function for classification, and details can be found in the reference provided here: https://www.youtube.com/watch?v=ZVFeW798‐2I&t=359s [37]. Second, it should be noted here that since XGBoost is ideal for large complex datasets, testing all possible features and splits can be computationally infeasible. XGBoost instead employs various algorithms to more efficiently select meaningful features and splits. Details around various optimizations that XGBoost utilizes are briefly described later in this section. Third, the SS score is different (and simpler) for regression. Lastly, XGBoost utilizes several regularization techniques that help address overfitting. As regularization is a key aspect of XGBoost, these techniques are discussed with simple examples in combination with other XGBoost hyperparameters in the next section.

XGBoost numerical example.

## Section: Background Concepts › XGBoost Hyperparameters

As with most ML algorithms, XGBoost relies on several hyperparameters that help dictate the training process and overall model structure. These hyperparameters can either be set explicitly by the user or automatically tuned. While heuristics and prior knowledge can guide their selection, best practice is to perform hyperparameter tuning to optimize model performance. We will focus on regularization‐related hyperparameters, as they play a critical role in controlling overfitting and shaping the structure of the final XGBoost model. Other commonly used hyperparameters are described in the code implementation section.

The parameter λ, also known as reg_lambda, helps prevent an XGBoost model from overfitting the data by adding a penalty to the model's loss function. It effectively achieves this by lowering the split score (SS) function when λ>0, which can be seen in Equation (3). Importantly, if a node has relatively few observations in it, then a positive value of λ, say λ=1, will lower the SS more significantly in comparison with a node with many observations. For example, suppose λ=1 and the SS score was recalculated for the green node in Figure 1, Step 3. The new value of SSTS>1,RL would be 0.082, about 50% lower from the original value of 0.16 when λ=0. In contrast, if λ=1 and the SS was recalculated for the red node in Figure 1, Step 3, the new value of SSTS≤1,LL would be 0.13, which is about an 80% lower from the original value of 0.66. Intuitively, this is because the effect of lambda is inversely proportional to the number of residuals. Hence, λ penalizes nodes with very few observations by lowering the SS score more so compared to nodes with more observations.

The hyperparameter γ, also known as the tree complexity parameter (and referred to as “loss_reduction” in R code), controls the criteria for how new trees are built, and operates largely independent of λ. The value of γ is used to “prune” trees by preventing branches that do not result in sufficient gain. If the gain of a split is < γ, that is, Gain < γ, where Gain is defined in Equation (5), it implies that the split did not produce a substantial enough increase of information, that is, the loss function did not significantly reduce, and the branch node is removed (or rather, not built in the first place). Hence the tree becomes simpler. The value of γ therefore dictates how simple or complex trees will get. For example, if γ was set to 3 in Figure 1, Step 4, then the branch split by tumor size > 2 would be removed since Gaintumorsize>2−γ=2.21−3<0 and therefore, only the root node would remain. However, if =2, then this branch would remain.

Another hyperparameter in XGBoost is called the cover, which is also known as min_child_weight (referred to as “min_n” in the R code) specifies the minimum sum of instance weights needed in a child node. For classification, this often correlates with the minimum number of observations in a node but is not identical. If the value is high enough, it may prune a leaf with relatively few observations.

These regularization hyperparameters help prevent the model from essentially “fitting the noise,” that is, they prevent the model from overfitting the training set. Regularization reduces the model's variance, making it less sensitive to the training data. Optimizing these hyperparameters is a key aspect of building a robust XGBoost model, and more generally, understanding hyperparameter optimization is key to understanding model development in machine learning.

## Section: Background Concepts › XGBoost Optimization Features

The concepts described so far are not specific to XGBoost alone, but rather to the more general class of gradient‐boosted tree methods of which XGBoost is a member. Where XGBoost is differentiated is in its optimization features that allow for efficient model building for large, complex datasets. These features are briefly described with general descriptions as they are not critical to the underlying algorithmic process. Approximate greedy algorithm—A greedy algorithm is used to efficiently generate reasonable quantiles within a feature that can be used as thresholds to build trees. This is motivated by the fact that it is not feasible to test all possible thresholds within a feature for large datasets with high‐dimensional feature sets.Block structure for parallelization—For a feature with many observations, subsets of the feature/target can be distributed in parallel across computing cores or machines and used to generate an approximate histogram of the feature, for which quantiles are approximated.Weighted quantile sketch—To simplify the search space for continuous features, histograms are used to set candidate split points. In the case of imbalanced classes or other data‐dependent situations, weights can be incorporated into these distribution sketches.Sparsity‐aware split finding: This is an approach that prescribes how to build trees when there are missing observations for some features. This is especially useful for real‐world data that tends to have missing information, which does not have to be addressed a priori.Cache aware access: This is a hardware‐level feature in which the cache memory within the CPU is used to do the first and second derivative calculations, which are computationally more intensive. Cache memory is very efficient in comparison to RAM memory or a hard drive.Blocking for out‐of‐core computation—This feature compresses a portion of the dataset onto the hard drive when the dataset is too large for the cache and RAM. By compressing the data, it reduces the time for writing the data to the hard drive, which is traditionally very slow. XGBoost will then bring back compressed portions and uncompress them, which has a net efficiency without compression of any kind.

## Section: Data Preprocessing

Data preprocessing describes the steps taken to initially evaluate and prepare a dataset(s) prior to modeling. Preprocessing involves any filtering, transforming, or encoding of data to ensure it is in a format compatible with the AI/ML algorithm(s) being used. Common steps in data preprocessing include reviewing the dataset, handling null or missing values, and defining rules for treating missing data, such as removing incomplete entries or applying imputation techniques. Depending on the dataset and algorithm, additional steps of encoding (converting them into a format readable by the algorithm) and scaling the data (normalizing data to a specific range) may also be performed. It should be noted that XGBoost, like other tree‐based methods, is effectively scale‐invariant since it relies on the relative ordering of features or categorical splits rather than the absolute values of features. Hence, scaling is not typically needed. Finally, the data are split into training, validation, and test subsets [38, 39, 40] to facilitate model building and evaluation.

## Section: Code for Data Preprocessing and Model Preparation

The R code (provided in alternate font) is designed to preprocess the dataset for a binary classification task, specifically predicting whether a subject had a recurrence of cancer. Below is a description of the key parts of the code, integrated into the explanation.

1. Data Transformation and Feature Engineering

The code begins by transforming the raw dataset. The mutate function from dplyr is used to create new variables and transform existing ones: A logical variable class_n is created to indicate whether the subject had recurrence events (TRUE) or not (FALSE).The Class variable is converted into a factor with levels c(“recurrence‐events”, “no‐recurrence‐events”), ensuring that “recurrence‐events” is the first level because it is the event of interest, and creating the factors this way will cause other functions to have the desired behavior by default.The age, tumor_size, and inv_nodes variables are converted into ordered factors, preserving the natural order of these categories. For example, tumor_size is ordered from “0–4” to “50–54” and inv_nodes is ordered from “0–2” to “24–26”Logical variables are created for other binary attributes: irradiat_n for whether the subject received radiation, node_caps_n for whether lymph node capsular invasion was present, and breast_left for whether the tumor was in the left breast.

This transformation prepares the data for machine learning models by handling categorical and ordinal data effectively.

2. Defining the Preprocessing Formula

A preprocessing formula, using typical R formula syntax, is defined to specify the target variable and the predictors: The formula class_n ~ age_f + menopause + tumor_size_f + inv_nodes_f + node_caps + deg_malig + breast + breast_quad + irradiat captures the covariate model, with class_n as the target and the remaining variables as predictors.

This formula serves as the blueprint for subsequent data preprocessing.

3. Recipe for Preprocessing with tidymodels

A recipe is created using the recipes package to preprocess the data. The recipe performs the following steps: Ordinal factors like age_f, tumor_size_f, and inv_nodes_f are converted into numeric scores using the step_ordinalscore() function, ensuring that their ordinal nature is preserved in a numeric format.Dummy variables are created for categorical variables such as breast, breast_quad, irradiat, menopause, and node_caps. The one_hot = TRUE option ensures that all levels except the reference level are represented as separate dummy variables.

This recipe ensures the data are transformed appropriately for model fitting.

4. Fitting and Applying Preprocessing

The preprocessing steps are then fitted on the training data to avoid data leakage: The prep(preprocessing_XGBoost, training(init_split)) function fits the recipe to the training data, learning the transformations without leaking any information from the test set.

5. Preparing Data for Model Training and Testing

Finally, the transformed data is extracted and prepared for model training and testing: The bake() function is used to apply the learned transformations to both the training and testing datasets, resulting in the x_train and x_test matrices, which contain the preprocessed features.The y_train and y_test vectors are extracted using pull(class_n) to obtain the target variable.

This process ensures that both the training and testing data are ready for fitting the XGBoost model, with consistent preprocessing applied to both sets.

## Section: Code Implementation For Classification

The data and R file code for fitting and evaluating the XGBoost model is provided in the supplemental materials (https://github.com/metrumresearchgroup/ascpt‐ml‐tutorial/), with key sections described below. Two approaches for implementing the model are used in this example. The first uses the XGBoost package interface directly, and the second uses the tidymodels package. More emphasis is placed on the second approach using tidymodels.

ROC‐AUC curve for classification example.

Precision‐recall curve for classification example.

Calibration table for classification example.

## Section: Code Implementation For Classification › Approach 1: Direct Use of XGBoost Package Interface

The XGBoost package interface (XGBoost function) does not directly use the R formula modeling syntax but instead uses the design matrix (x_train) and labels (y_train) from the data preprocessing steps directly as input. Some arguments (e.g., nrounds) are arguments directly provided to the function, while other arguments to control the model fit are specified as a list in the params argument. A simple example of fitting an XGBoost model for binary classification is:xgboost::xgboost(data = x_train,label = y_train,nrounds=15,params = list(objective = "binary:logistic")).

x_train: is the design matrix from the previous preprocessing section where the covariate model is specified. label: vector of the dependent variable (binary for binary classification, continuous for regression). nrounds: number of boosting iterations (the value of p in Equation (1). params: additional information for the model, including the loss function and specification of the type of model (e.g., classification or regression).

By default, during training, the loss of the training set is returned every iteration, which helps in monitoring the training process. Additional options allow for more information to be returned, including the loss on a test set. The returned XGBoost fit object contains information about the model and training process but is useful only with further analysis functions (e.g., when compared to the results of lm in R). The generic predict function is a straightforward way to return predictions for the training set or for new observations.

## Section: Code Implementation For Classification › Approach 2: Use of the Tidymodels Package

Alternatively, the tidymodels collection of packages uses a more standardized and generic syntax to specify the model. The workflows subpackage combines data preprocessing with model fitting to aid in common ML tasks. The model, using the recipes package, is specified similarly to the preprocessing method, using the R formula syntax:recipes::recipe(Class ~ age_f + menopause + tumor_size_f + inv_nodes_f + node_caps + deg_malig + breast + breast_quad + irradiat,data = training(init_split)).

ROC‐AUC curve for classification example.

Precision‐recall curve for classification example.

Calibration table for classification example.

## Section: Code Implementation For Classification › Approach 2: Use of the Tidymodels Package › Hyperparameter Tuning

As described previously, hyperparameters are user‐chosen to help guide the training process. Unfortunately, there is little intuition on the optimal selection of training parameters. However, within XGBoost, a systematic search and crossvalidation scheme within the training data is typically performed to find approximately optimal hyperparameter tuning. In practice, the space of hyperparameters can be large, and several hyperparameters have similar effects in the final model. Therefore, in practice, only a subset of hyperparameters will be tuned, with the others set to reasonable default values. Tuning procedures are varied and have a range of theoretical complexity, implementation difficulty, and computational requirements. Here, we will use a grid search to perform the tuning. A grid search can be easily parallelized, and the grid values to test are easily computed using a regular grid or a Latin‐hypercube to efficiently cover the space of hyperparameters.

Within the tuning process, for each candidate set of hyperparameters, the training data is again split into training and validation sets via crossvalidation. Within each fold, the model is fit using the candidate hyperparameters and evaluated on the holdout set using the same objective function as for the final model, for example, log‐likelihood, RMSE, or ROC‐AUC. The performance metric across the crossvalidation folds is aggregated (e.g., mean) and the best set of hyperparameters is chosen for a final fit of the model using all the training data.

Commonly tuned hyperparameters for XGBoost classification and regression applications are included below: [41] Step size (eta, learning rate): How much weight is given to each tree. Lower numbers reduce overfitting but increase the number of trees required and therefore increase the run time.Maximum Tree Depth: The maximum depth of any single tree that can occur (deep trees are not recommended).Minimum Number of Observations at Each Leaf (min_n, min_child_weight): Controls overfitting of each tree by adjusting the minimum number of observations in each leaf node. Larger values cause less complex trees and less overfitting.

The number of trees to create is an important hyperparameter, but is commonly fixed in advance. Other tuning parameters can also be used to control the complexity of the tree and have slightly different results than the tuning parameters described above. However, in our experience, and in most occasions, adjusting more than a couple of hyperparameters does not yield improved model fit. Within the tidymodels package, the tune() function is used in place of a specific hyperparameter argument to specify that the parameter will be tuned.

## Section: Code Implementation For Classification › Approach 2: Use of the Tidymodels Package › Crossvalidation and Final Model Fitting

For this working example, two hyperparameters will be tuned: the maximum tree depth and the minimum number of observations in a leaf. The crossvalidation scheme as described previously is specified with the following lines of code:boost_tree(trees=15,tree_depth = tune(),min_n = tune(),loss_reduction = 0,sample_size = 1.0,learn_rate = 0.3) %>%set_engine("XGBoost") %>%set_mode("classification")

In this code, all the possible hyperparameters are specified, along with the algorithm used (XGBoost) and the problem type (classification). Note that all hyperparameters in the code above have been defined in the “Background Concepts” section except for “sample_size,” which is another hyperparameter to help reduce overfitting. It is fixed at a default value of 1.0. Additionally, the grid of points to search over is described, here using a Latin‐hypercube design:grid_latin_hypercube(tree_depth(range = c(2, 6)),min_n(range = c(1, 15)),size = 25)

Twenty‐five sets of parameters are used for the crossvalidation (referred to as “size” in the R code), and the possible ranges for the hyperparameters are also specified. While increasing the number of crossvalidation points may give the appearance of better results, often this is simply noise because many similar values of the hyperparameters generate very similar final predictive powers. Therefore, in practice, only reasonable and not perfect hyperparameters are necessary.

Once the final hyperparameters are selected with some criteria, for example, receiver operating characteristic‐area under the curve (ROC‐AUC), the model is refit on all the training data. Again, the tidymodels package simplifies this workflow, with two steps: first, to apply the selected hyperparameters in the workflow, and second, to fit the model:final_wf <- finalize_workflow(xgb_wf,best_auc_params)final_fit <- final_wf %>%last_fit(init_split)

This fit can be used to perform model evaluation, both ML‐specific checks and standard pharmacometrics modeling checks. For example, the ROC curve for the test set can be plotted (Figure 2):

final_fit %>%collect_predictions() %>%roc_curve(Class, `.pred_recurrence-events`, event_level = "first") %>%autoplot()

A confusion matrix created for a default classification threshold:final_fit %>% collect_predictions() %>% conf_mat(Class, .pred_class)

Alternatively, because these classes were imbalanced, the precision‐recall curve may be more informative (Figure 3):

final_fit %>%collect_predictions() %>%pr_curve(Class, `.pred_recurrence-events`, event_level = "first") %>%autoplot()

A calibration table analogous to a predicted versus observed plot for a regression problem can help evaluate the predictive power of the model on a test set. In Table 3, the test set is divided into quartiles (or any number of groups, e.g., deciles) of the model predicted probabilities, and the observed and predicted event rates are computed within each group. Two aspects of the model are evaluable. First, the predicted and observed should have similar rates for the accuracy of the model, that is, smaller residuals. Second, large differences between the lower quartiles and higher quartiles should be large, which demonstrates the predictive power of the model. This is because if differences across quartiles were small, it would indicate that the predicted probabilities are similar, and hence the model does not have a high degree of discrimination.

final_fit %>%collect_predictions() %>%mutate(predicted_quartile = ntile(`.pred_recurrence-events`, 4)) %>%group_by(predicted_quartile) %>%summarize(n = n(), observed = mean(Class == "recur rence-events"), predicted = mean (`.pred_recurrence-events`))

For new data, for example, in simulations, the predict() function is a simple way to make predictions. The functions available in the XGBoost and tidymodels packages perform common model evaluation tasks, but any specific model should be evaluated within the context it will be used. In general, quantitative evaluation of models in clinical pharmacology and pharmacometrics typically reports substantially worse performance than nonclinical pharmacology ML applications, such as image recognition. Hence, performance should be considered within the context of use and compared against evaluation metrics for alternative approaches to reliably compare performance.

ROC‐AUC curve for classification example.

Precision‐recall curve for classification example.

Calibration table for classification example.

## Section: XGBoost For Regression

For the regression example, the task is to predict the number of alcoholic drinks consumed based on liver biomarker data using the open‐source dataset [36]. All files, including the data and code, are located in the GitHub repository (https://github.com/metrumresearchgroup/ascpt‐ml‐tutorial/). The analysis workflow for regression is generally similar to that for the classification example presented thus far. Since the outcome is continuous (number of alcoholic drinks), this is a regression task. This dataset is already appropriately preprocessed for regression with XGBoost. For tidymodels and XGBoost in this context for regression, the three primary changes are: (1) the mode (tidymodels) or objective (XGBoost.fit) is changed from classification to regression; (2) the evaluation metric is changed to root mean square error (RMSE); (3) the classification‐specific approaches (confusion matrix, ROC‐AUC curve) are removed and replaced with the familiar model evaluation approaches for regression.

Within the tidymodels package, updating XGBoost to a regression problem is set again with the set_mode() function:set_mode("regression")

The crossvalidation output (metrics) is ones appropriate for regression:metrics <- metric_set(rmse, rsq_trad, rsq)best_rmse <- select_best(tuning_results, metric = "rmse")

Instead of class labels, the output will be a single real number for the model prediction given the input covariate vector. Depending on the hyperparameters, it is not uncommon for the output to visually look like a series of step functions that have a particular visual appearance or do not capture extreme values well. The model evaluation code is a simple predicted versus observed scatterplot, which is more akin to traditional pharmacometrics diagnostic plots compared to the classification example (Figure 4). Note that the GitHub repository contains final results for the regression code adaptation, and the reader is encouraged to refer to it after attempting the implementation.

Other regression variations are available within the XGBoost package. For example, there are loss functions for quantile regression, Poisson regression, or accelerated failure time survival models. Detailed explanations are beyond the scope of this tutorial, but the modeling syntax and ideas described here apply to those types of regression analyses as well.

Observed versus predicted results for the regression example.

## Section: Conclusion and Discussion

The aim of this tutorial was to provide the reader with a comprehensive introduction to the concepts and implementation of the XGBoost algorithm motivated by clinical drug development applications. By providing a conceptual framework and a practical example, it is expected that the reader will be equipped to better identify practical applications for which XGBoost could be used. Machine learning algorithms such as XGBoost can be applied to support research efforts involving drug discovery or a variety of clinical development questions, spanning from radiomics to predicting clinical outcomes such as risk or response variables. XGBoost can also play a role in clinical pharmacology questions, such as aiding in PK profile prediction and optimizing dose‐regimen selection through population PK or exposure–response analyses [42].

In drug development, XGBoost can be particularly useful in applications involving Real‐World Data (RWD), which encompasses large‐scale, high‐dimensional datasets such as electronic health records (EHRs), claims data, or patient‐reported outcomes [42]. These datasets are often messy and incomplete, requiring significant time and resources to preprocess them. XGBoost's ability to handle missing data, scale to large datasets, and deliver strong predictive performance makes it well‐positioned to handle such data. As a best practice, consider fitting simpler models like linear/logistic regression or decision trees. These provide a baseline for performance and can highlight if navigating the complexity of XGBoost is necessary. Simple models may be more interpretable and sufficient for smaller datasets or applications with limited features.

A key consideration for the use of XGBoost is having a large, complex dataset. Unsurprisingly, there is no formal definition of large and complex, so the choice to use XGBoost rather than more traditional approaches is not always clear. Although, as mentioned, comparing outputs from different methods is highly encouraged, as it provides insight to scenarios that may benefit from more sophisticated approaches.

The textbook and tutorial examples (such as the ones presented here) are oversimplified and missing much of the nuance and typical challenges. Questions regarding sufficient model performance and how this is measured should be given substantially more consideration than what is presented here. Additionally, even as ML algorithms are promoted as having the capability to solve a wide variety of modeling questions, careful thought should be given to model evaluation, much like traditional pharmacometrics analysis. Limitations of the model stemming from the flexible structure and underlying data should also be assessed. Furthermore, more in‐depth model validation should be performed for actual case studies. Ideally, such a process helps the modeler learn about what their data does and does not contain. Within this process, feature engineering, data cleaning, data wrangling, and other tasks in an ML pipeline are time‐consuming and important even though this example used a generally clean, well‐formatted appropriate dataset and question. Such a convenient setup is not the norm in practice.

In summary, there is no doubt that in the proper contexts, approaches like XGBoost can offer tremendous value and insight while being less resource‐intensive. As the typical rates of clinical data generation continue to rise, the need for new analytical methodologies, especially those in the AI/ML space, will also continue to grow.

## Section: Conflicts of Interest

The authors declare no conflicts of interest.

## Section: Supporting information

Data S1


---

# Addressing global regulatory challenges in rare disease drug development

- **Authors:** Enrico Costa, Vijayalekshmi Ajith, Ahmed F Al Khaldi, Antonella Isgrò, Kerry J Lee, Riccardo Luigetti, Anna M G Pasmooij, Violeta Stoyanova-Beninska, Eveline Trachsel, Julienne Vaillancourt, Steffen Thirstrup
- **Issuer:** Drug discovery today
- **Type:** Scientific article
- **Published:** 2025-08-30
- **Language:** en
- **DOI:** 10.1016/j.drudis.2025.104462
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40889637/
- **Licence:** CC-BY

## Section: Abstract

Despite progress in rare disease treatment, many conditions still lack therapeutic options. In addition to specific legislation promoting research and investment, regulators have supported early dialogs with stakeholders, optimized processes and expedited the approval of medicines in areas with unmet medical needs, such as rare diseases. However, several challenges persist, particularly in generating robust evidence. The introduced flexibility must be balanced with uncertainty management. Our analysis identifies several priorities: establishing a common global regulatory language; recognizing and validating surrogate endpoints; involving patients in defining meaningful outcomes; and leveraging digital health technologies and decentralized clinical trials. These tools offer opportunities to improve evidence generation and access, supporting more efficient and inclusive development processes where traditional approaches can be limited or unfeasible.


---

# ADMET evaluation in drug discovery: 21. Application and industrial validation of machine learning algorithms for Caco-2 permeability prediction

- **Authors:** Dong Wang, Jieyu Jin, Guqin Shi, Jingxiao Bao, Zheng Wang, Shimeng Li, Peichen Pan, Dan Li, Yu Kang, Tingjun Hou
- **Issuer:** Journal of cheminformatics
- **Type:** Scientific article
- **Published:** 2025-01-10
- **Language:** en
- **DOI:** 10.1186/s13321-025-00947-z
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39794857/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

The Caco-2 cell model has been widely used to assess the intestinal permeability of drug candidates in vitro, owing to its morphological and functional similarity to human enterocytes. While Caco-2 cell assay is considered safe and cost-effective, it is also characterized by being time-consuming. Therefore, computational models that achieve high accuracies in predicting Caco-2 permeability are crucial for enhancing the efficiency of oral drug development. In this study, we conducted an in-depth analysis of the characteristics of an augmented Caco-2 permeability dataset, and evaluated a diverse range of machine learning algorithms in combination with different molecular representations. The results indicated that XGBoost generally provided better predictions than comparable models for the test sets. In addition, we investigated the transferability of machine learning models trained on publicly available data to internal pharmaceutical industry datasets. Our findings, based on the Shanghai Qilu’s in-house dataset, showed that the boosting models retained a degree of predictive efficacy when applied to industry data. Furthermore, Y-randomization test and applicability domain analysis were employed to assess the robustness and generalizability of these models. Matched Molecular Pair Analysis (MMPA) was utilized to extract chemical transformation rules. We believe that the model developed in this study could represent a reliable tool for assessing Caco-2 permeability during early-stage drug discovery and the chemical transformation rules derived here could provide insights for optimizing Caco-2 permeability. Scientific contribution A comprehensive validation of various machine learning algorithms combined with diverse molecular representations on a large dataset for predicting Caco-2 permeability was reported. The transferability of machine learning models trained on publicly available data to internal pharmaceutical industry datasets was also investigated. Matched molecular pair analysis was carried out to provide reasonable suggestions for researchers to improve the Caco-2 permeability of compounds.Graphical Abstract Supplementary InformationThe online version contains supplementary material available at 10.1186/s13321-025-00947-z.

## Section: Introduction

The oral route is often preferred for drug administration because of its convenience, cost-effectiveness, and high patient adherence [1]. However, about 10% of drugs fail in development due to poor pharmacokinetic properties [2]. One of the foremost challenges faced by orally administered drugs is the traversal across the intestinal epithelial barrier, which determines the rate and extent of absorption in humans, thereby critically influencing their bioavailability [3]. Furthermore, the permeability process itself is intricate. Transport across the intestinal epithelial cell barrier may occur through one or more of four different routes: paracellular and transcellular passive diffusion, the carrier-mediated route, and transcytosis [4]. Therefore, it is paramount to accurately reconstitute the differentiated human epithelial cell monolayer in vitro, as this enables precise prediction of oral drug absorption in humans.

Several cells culture models have been developed to replicate the pertinent characteristics of in vivo absorption, such as Parallel Artificial Membrane Permeability Assay (PAMPA) [5], the human colon adenocarcinoma (Caco-2) cell lines [6], the Madin–Darby canine kidney (MDCK) cell [7], and porcine kidney epithelial cell lines (LLC-PK1) [8]. Among these models, Caco-2 cell monolayers have emerged as the “gold standard” for drug permeability due to their ability to closely mimic the human intestinal epithelium [9]. Indeed, this in vitro model has been endorsed by the US Food and Drug Administration (FDA) for assessing the permeability of compounds categorized under the Biopharmaceutics Classification System (BCS) [10].

Nevertheless, high-throughput screening (HTS) with the traditional Caco-2 cell model poses challenges due to its extended culturing period (7–21 days), which is necessary for full differentiation into an enterocyte-like phenotype [11, 12]. The extended cultivation not only increases the risk of contamination but also imposes significant costs, making it less desirable in the context of drug discovery. Furthermore, there is a growing need to apply selection filters prior to designing and acquiring large compound libraries, thereby shifting the focus towards in silico predictions of ADME-related properties.

Numerous machine learning models have been developed for both classification and regression analysis of Caco-2 permeability based on a variety of molecular representations, such as fingerprints, descriptors and embeddings extracted from neural network models [13–19]. Notably, there are fewer classification models than regression models for predicting Caco-2 cell permeability, primarily due to the lack of a consensus on the optimal cut-off for modeling and practical application. Here, this study also focused on the regression task. Prior research on Caco-2 permeability prediction has exhibited considerable variation in dataset size, descriptor types, and modeling methods. For instance, Wang et al. constructed different models based on the MOE 2D/3D descriptors to predict Papp values using a structurally diverse data set of 1272 compounds [13]. The comparison between Boosting and other methods revealed that the Boosting model achieved better results, with an R2 value of 0.81 and an RMSE of 0.31 for the test set. Additionally, Wang and colleagues proposed the MESN deep learning model, which uses a curated Caco-2 dataset with 4464 compounds to predict the features associated to oral bioavailability [15]. Three molecular embedding approaches were employed in the MESN model, namely, Morgan fingerprints, SMILES-based embedding, and molecular-graph-based embedding. For membrane permeability prediction, the MESN model obtained an MAE score of 0.410 and an RMSE of 0.545. More recently, Gabriela et al. introduced a QSPR approach developed on the KNIME analytical platform, based on a structurally diverse dataset of over 4900 molecules [16]. They employed random forest supervised recursive algorithms for data cleaning and feature selection. The modeling algorithm consisted of a conditional consensus model composed of individual regression random forests, achieving RMSE values ranging from 0.43 to 0.51 and R2 values between 0.57–0.61 for all validation sets.

Although progress has been made in predicting Caco-2 permeability, several issues still required discussion. Firstly, Caco-2 permeability is a highly complex process that can occur through various nonlinear routes. The characteristics of the Caco-2 permeability data were not discussed and the scarcity of high-quality Caco-2 permeability data has impeded the development of accurate models with a wide applicability domain. Secondly, there remains a question regarding the performance of deep learning in Caco-2 permeability data. Thirdly, the effectiveness of machine learning models trained on publicly accessible databases in industrial settings remains unclear.

Taking into account the mentioned concerns, we thereby reported a comprehensive validation of various machine learning algorithms combined with diverse molecular representations for predicting Caco-2 permeability. Initially, a relatively larger Caco-2 permeability dataset was collected, and the structural diversity of the compounds was analyzed. Four machine learning methods (XGBoost, RF, GBM, and SVM) and two deep learning models (DMPNN and CombinedNet) were used to build prediction models. For each algorithm, the optimal model was selected for further analysis. Next, we conducted a direct comparison of different in silico predictors through several model validation methods, including the Y-randomization test and application domain (AD) analysis. Additionally, we carried out a performance assessment of different models trained on public data using the Shanghai Qilu’s in-house dataset. Lastly, based on the results of matched molecular pair analysis (MMPA), we provided reasonable suggestions for researchers to improve the Caco-2 permeability of compounds. We anticipate that our findings will shed light on future method development and offer insights for optimizing Caco-2 permeability.

## Section: Methods › Data collection and preparation

Experimental values of Caco-2 permeability were obtained from three publicly available datasets [13–15]. The first dataset, reported by Wang et al., comprised 1272 compounds used for developing predictive models and an additional 298 compounds for validation [13]. Wang and Cheng collected the second dataset of 1827 compounds to develop QSPR models using neural networks and other machine learning methods [14]. The third dataset, consisting of 4464 compounds, was utilized by Wang et al. for modeling Caco-2 permeability with neural networks [15]. These datasets were combined into an initial dataset of 7861 compounds for subsequent analysis. To ensure data consistency and minimize uncertainty, the following procedures were applied: (1) Permeability measurements were converted to cm/s × 10–6 and transformed logarithmically (base 10) for modeling. (2) Entries with missing permeability values were excluded. (3) Mean values and standard deviations were calculated for duplicate entries. Only entries with a standard deviation ≤ 0.3 were retained, and the mean values of these compounds were used as standard values for model training. (4) The RDKit module MolStandardize was employed for molecular standardization to achieve consistent tautomer canonical states and final neutral forms, while preserving stereochemistry. After curation, an exhaustive dataset comprising 5654 non-redundant Caco-2 permeability records was compiled. Subsequently, these records were randomly divided into the training, validation, and test sets in an 8:1:1 ratio, ensuring an identical distribution across the datasets. To enhance the robustness of model evaluation against data partitioning variability, the experimental dataset underwent 10 splits using different random seeds. The model was then assessed based on the average performance across these ten independent runs. According to the OECD principles, both internal and external validations are essential to assess model reliability and predictive capability [20, 21]. An additional set of 67 compounds from the Shanghai Qilu’s in-house collection was included as an external validation set to test the prediction performance of the model trained on the public data set on the private data set.

## Section: Methods › Molecular representations

To incorporate comprehensive chemical information at both global and local levels, three types of molecular representation methods were employed to depict the structural features of molecules. Specifically, the molecular representations utilized were as follows:Morgan fingerprints with a radius of 2 and 1024 bits: The RDKit implementation of Morgan fingerprints was utilized [22].RDKit2D descriptors: Normalized descriptors from descriptastorus (https://github.com/bp-kelley/descriptastorus), which wraps the RDKit implementation and normalizes values using a cumulative density function from Novartis’ compound catalog.Molecular graphs: For the message-passing neural network, molecular graphs \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$G=(V,E)$$\end{document}G=(V,E) served as the foundational representation, where \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$V$$\end{document}V represents atoms (nodes) and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E$$\end{document}E represents bonds (edges). This approach was implemented using the open-source ChemProp package to enhance model performance and effectively capture nuanced molecular features [23].

Furthermore, a combination of Morgan fingerprints and RDKit2D normalized descriptors was employed to train all methods, with the exception of DMPNN and CombinedNet, which utilized molecular graphs. Specifically, CombinedNet employed a hybrid approach that combined Morgan fingerprints and molecular graphs: the former providing information on substructure existence and the latter conveying connectivity knowledge.

## Section: Methods › Model construction and evaluation

In this study, we conducted a comprehensive comparison of multiple machine learning and deep learning algorithms for quantitative predictions of Caco-2 permeability. The evaluated algorithms included Random Forest (RF) [24], extreme gradient boosting (XGBoost) [25], Support Vector Machine (SVM) [26], Gradient Boosting Machine (GBM) [27], Directed Message Passing Neural Network (DMPNN) [28], and CombinedNet (Figure S1) [29]. The first four methods were implemented using the scikit-learn package, while the latter two deep learning techniques were implemented using the ChemProp package [23, 30]. Hyperparameters for all algorithms, except DMPNN and CombinedNet, were optimized through fivefold cross-validation and grid search. The DMPNN algorithm employed the Adam optimizer for gradient descent optimization, while CombinedNet utilized the LAMB optimizer with a mean squared error (MSE) loss function [31]. Hyperparameters in neural networks were fine-tuned using Bayesian optimization algorithms, and to prevent overfitting, an early stopping strategy was applied. Further details about each algorithm can be found in the Table S1.

To ensure robust generalization ability of the QSPR models in predicting Caco-2 permeability for new chemical entities, both fivefold cross-validation and independent test sets were employed. The performance of different machine learning models on the Caco-2 permeability datasets was evaluated utilizing the following metrics: Coefficient of determination (R2), Mean absolute error (MAE), Root mean squared error (RMSE), Pearson correlation coefficient (Pearson’s r), and Spearman’s rank correlation coefficient (Spearman’s rho).

## Section: Methods › Definition of applicability domain

Due to the limitations inherent by the chemical space represented by the training set, each machine learning model demonstrated a predisposition towards predicting certain types of compounds [32]. This suggests that predictions may be more reliable when the compounds being evaluated fall within the specific applicability domain of each machine learning model. In this study, we adopted a methodology named the Euclidean distance-based method for applicability domain analysis [33]. This method introduces a distance cutoff value \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${D}_{c}$$\end{document}Dc that defines a similarity threshold for external compounds. Morgan fingerprints was utilized to calculate the similarity between molecules. The detailed formula is as follows:\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$D_{c} = \overline{y} + Z\sigma$$\end{document}Dc=y¯+Zσwhere \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\overline{y }$$\end{document}y¯ represents the average Euclidean distance of the k nearest neighbors of each compound in the training set, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\sigma$$\end{document}σ is the corresponding standard deviation of Euclidean distances, and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$Z$$\end{document}Z is an optional parameter to control the significance level. If the distance from an external compound to any of its nearest neighbors in the training set is above the distance cutoff \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$${D}_{c}$$\end{document}Dc, the compound is considered to be outside of domain; otherwise, it is considered to be within the domain.

## Section: Methods › Matched molecular pairs (MMP) analysis

Matched molecular pair (MMP) analysis elucidates the impact of specific chemical transformations on activity or property changes within a molecule [34]. This approach has become widely adopted for optimizing both biological activity and ADMET properties [35, 36]. To gain deeper insights into how minor chemical modifications influence Caco-2 permeability properties and to guide ligand optimization, we constructed an MMP database. This database incorporates transformation rules linked to shifts in logPapp derived from our curated Caco-2 permeability datasets. For the creation of this MMP database, we utilized the open-source mmpdb package [37]. The process involved two main stages: fragmentation and indexing. During the fragmentation phase, we permitted up to three cuts per molecule, with constraints on the maximum number of heavy atoms (100) and rotatable bonds (10). Chirality was preserved when cutting bonds. In the subsequent Indexing phase, variable fragments were defined with a minimum of 2 and a maximum of 15 heavy atoms. The maximum radius for indexing was set to 3. The portion of heavy atoms in changing fragments was no more than half of the molecule. Default values were applied for other parameters as per the mmpdb package settings. We included only the transforms that contained at least ten matched pairs and showed a significant property shift with a p-value < 0.05. This rigorous approach ensures that the results comprise meaningful and actionable insights into how specific chemical alterations affect Caco-2 permeability.

## Section: Results and discussion

Chemical space and scaffold analysis of the curated Caco-2 permeability data set. A The experimental logPapp value distribution showing that most of the compounds belong to the highly permeable class (n = 2746) while the least number of structures are categorized as low permeable. B t-SNE plot of curated Caco-2 permeability data set (green: high permeable compounds; blue: medium permeable; orange: low permeable). C Heat map of Tanimoto similarity based on with the ECFP4 fingerprints of the total data set. D Frequency of the Murcko scaffolds in the data set

Performance of different machine learning methods. The summary of A R2 and B RMSE for different machine learning models on test set (indicated by colors). C Global ranking of all methods using PCA, scaled between best and worst performance. Every point represents a different combination of the machine learning method and the descriptor it relied on. “Worst” and “Best” indicated the worst and best performance obtained across all data sets, respectively

Comparison of Caco-2 permeabilities predictions to experimentally measured values for test set (blue dash line: two-fold error; orange part of each subplot: low permeable; blue part: medium permeable; green part: high permeable)

Bar chart plots showing the R2, RMSE and MAE in prediction as a function of binned structural similarities for different models

The performance of different models considering the applicability domain on the test set

The performance of different models on the Shanghai Qilu’s internal data set

Correlation of logPapp measurements (x-axis) against machine learning model predictions (y-axis) across 7 Shanghai Qilu’s internal projects (orange part of each subplot: low permeable; blue: medium permeable; green: high permeable)

Representative medicinal chemistry transforms with corresponding changes of Caco-2 permeability

## Section: Results and discussion › Data set analysis

We collected data from public databases and previous studies, resulting in 7861 compounds being included in this research. After data preparation, a total of 5654 compounds with structural diversity were obtained. The distribution of the logPapp values was shown in Fig. 1a. The logPapp values ranged from − 8.778 to − 3.510, with a mean of − 5.340. The permeabilities were then categorized as follows: compounds with a permeability less than 1 × 10–6 cm/s are considered low permeability, those up to 7 × 10–6 cm/s are classified as medium permeability, and compounds with a permeability greater than 7 × 10–6 cm/s are regarded as highly permeable. It can be observed that the curated dataset is highly unbalanced and contains a higher number of highly permeable compounds (n = 2746) compared to medium (n = 1747) and low (n = 1161) permeable compounds. Figure 1b shows that most structural clusters are quite mixed in terms of permeability classes. However, these clusters are not equally representative of all permeability classes, as many are predominantly composed of highly permeable (green) compounds. The presence of a biased chemical space presents a substantial complication in the accurate prediction of Caco-2 permeability. To further explore the chemical space of the Caco-2 data set, the Tanimoto similarity based on the ECFP4 fingerprints was calculated and the Murcko scaffolds were analyzed. The Murcko scaffolds of the total data set were extracted by removing side chain substituents but retaining the linkers and ring systems with the RDKit package. The overall color of the Tanimoto similarity heat map was light blue with an average similarity of 0.5 (Fig. 1c), indicating the structural diversity of the data set. Additionally, we detected 2979 different Murcko scaffolds from the data set, suggesting that each Murcko scaffold shared an average of ~ 1.9 molecules. The most common scaffolds in the data set were shown in Fig. 1d along with their frequency. Apparently, the six-membered ring was the most frequent scaffold in many drug compounds and molecules with polycyclic scaffolds may be the focus of Caco-2 permeability studies. In a word, the above analysis demonstrated the structural diversity and biased distribution of the current Caco-2 permeability data set.Fig. 1Chemical space and scaffold analysis of the curated Caco-2 permeability data set. A The experimental logPapp value distribution showing that most of the compounds belong to the highly permeable class (n = 2746) while the least number of structures are categorized as low permeable. B t-SNE plot of curated Caco-2 permeability data set (green: high permeable compounds; blue: medium permeable; orange: low permeable). C Heat map of Tanimoto similarity based on with the ECFP4 fingerprints of the total data set. D Frequency of the Murcko scaffolds in the data set

Chemical space and scaffold analysis of the curated Caco-2 permeability data set. A The experimental logPapp value distribution showing that most of the compounds belong to the highly permeable class (n = 2746) while the least number of structures are categorized as low permeable. B t-SNE plot of curated Caco-2 permeability data set (green: high permeable compounds; blue: medium permeable; orange: low permeable). C Heat map of Tanimoto similarity based on with the ECFP4 fingerprints of the total data set. D Frequency of the Murcko scaffolds in the data set

## Section: Results and discussion › Performance of Caco-2 permeability prediction models

First, we evaluated the ability of machine learning approaches to predict Caco-2 permeability. To improve the representation of the chemical and structural features of molecules for classical machine learning and DNN models, various combinations of molecular descriptors and fingerprints were considered. The detailed statistical results for all models across the training, validation, and test sets were summarized in Table S2. The performance was quantified using the R2 and RMSE metrics on the test set molecules. Notably, large differences in predictive performance were observed among the data sets, with the R2 values ranging from ~ 0.4 to ~ 0.65 log units (Fig. 2a). This trend was also evident in the overall performance of the test set molecules, with the RMSE values ranging from ~ 0.5 to ~ 0.6 log units (Fig. 2b). The performance variations were primarily attributed to the chosen molecular descriptor, with rdkit2d descriptors yielding the relatively low average prediction error. Binary fingerprints generally performed worse than nonbinary descriptors, with higher variation across data sets. Additionally, it was observed that a combined molecular representation would benefit machine learning algorithms.Fig. 2Performance of different machine learning methods. The summary of A R2 and B RMSE for different machine learning models on test set (indicated by colors). C Global ranking of all methods using PCA, scaled between best and worst performance. Every point represents a different combination of the machine learning method and the descriptor it relied on. “Worst” and “Best” indicated the worst and best performance obtained across all data sets, respectively

To provide a comprehensive assessment of methodological performance across the analyzed data sets, we conducted principal component analysis (PCA) on the obtained RMSE values (Fig. 2c). To enhance the PCA results, we added additional rows representing the best and worst RMSE values for each dataset along the direction defined by both the best and worst outcomes, as observed in previous studies [38, 39]. The proximity of a method’s position to the “best” point in the PCA plot signified its superior overall performance across the considered data sets. Furthermore, the magnitude of orthogonal deviation from the best–worst line indicated the extent of variability in a method’s performance based on the data set. Compared to machine learning models, deep learning models were obviously more sensitive to the specific data used during training. Additionally, the results confirmed the higher impact of molecular descriptors than the chosen machine learning algorithm on the model performance. On average, XGB coupled with a combined molecular representation proved to be the best method for predicting Caco-2 permeability. Machine learning models coupled with ECFPs outperformed DMPNN based on graphs, which was somewhat surprising given that ECFPs were derived from molecular graphs. The finding highlights a current gap in efficiently learning features from “raw” molecular representations in the small-data regimes typical of drug discovery. However, the deep learning model coupled with ECFPs showed comparable results to machine learning models coupled with ECFPs. These results once again emphasize the importance of including both generic molecular representations and local chemical information in MPNN models, which is in alignment with the prior research findings [40].

Performance of different machine learning methods. The summary of A R2 and B RMSE for different machine learning models on test set (indicated by colors). C Global ranking of all methods using PCA, scaled between best and worst performance. Every point represents a different combination of the machine learning method and the descriptor it relied on. “Worst” and “Best” indicated the worst and best performance obtained across all data sets, respectively

## Section: Results and discussion › Understanding of the generalization of Caco-2 permeability prediction models

The model with the most superior performance throughout 10 independent runs for all machine learning algorithms was selected to carry out further analysis. As shown in Fig. 3, a similar tendency was discerned, wherein the majority of combinations of models and molecular representations attained favorable performance in predicting highly permeable compounds. However, medium and, in particular, low permeable compounds exhibited a propensity to be overestimated. We supposed that the suboptimal prediction performance regarding low-permeable compounds is not attributable to the improper choice of algorithms and descriptors. Instead, the model’s bias towards highly-permeable compounds might give rise to an overestimation of their permeability (Fig. 1a and b).Fig. 3Comparison of Caco-2 permeabilities predictions to experimentally measured values for test set (blue dash line: two-fold error; orange part of each subplot: low permeable; blue part: medium permeable; green part: high permeable)

To ensure the robustness of our QSPR model against random generation, we employed the Y-randomization test to validate its reliability. This method involved random shuffling of the logPapp values to disrupt their original order [41]. It was expected that the resulting QSPR models would exhibit poor performance when applied to the validation dataset. This randomization process was repeated 100 times, and the collective results were illustrated in Figure S2. It was obvious that the performance of the randomly shuffled models was quite different from the real model, with R2 values of approximately − 0.5 to 0. The limited predictive ability of the randomized models demonstrated that our predictive models have adeptly captured the genuine relationship between molecular properties and logPapp, rather than spurious correlations.

Defining the domain of applicability for any predictive model is critical in order to gain an understanding of the model generalization and the origin of estimated errors [32]. Herein, we calculated the similarity between a test compound and its nearest neighbor in the training set to quantify its distance to the model’s domain of applicability and to understand further the potential link with the uncertainty in prediction. More specifically, the structural similarity between any two samples was measured using the Tanimoto coefficient based on the ECFP4 fingerprints with a folding size of 1024 bits. The resulting similarity score was binned in intervals of 0.1 units. Figure 4 highlighted the correlation between the prediction error and the binned average structural similarity for all compounds in the Caco-2 data set. A general trend was observed where the model performance, regardless of machine learning algorithms, increased as the similarity for the test compound against the training set increased, which was in agreement with the conclusions from previous studies [40]. In this case, we believed that compounds with similarities higher than 0.70 to the training set tended to obtain more reliable prediction results.Fig. 4Bar chart plots showing the R2, RMSE and MAE in prediction as a function of binned structural similarities for different models

The Euclidean distance-based method was then used to evaluate the domain of application. According to equation, it can be presumed that the elevation of the Z value and reduction in k led to a corresponding augmentation of the distance threshold and a consistent diminution of compounds external to the AD. We calculated the average Euclidean distance of the compounds in the training set of 9.203 and the standard deviation of the Euclidean distance of 0.920. For each model, the statistical results before and after considering the applicability domain were collected in Table 1 with the R2 values for model fit and RMSE for the test set. As anticipated, the improvement in model performance correlated positively with the reduction in the distance threshold. It makes sense because decreasing the distance threshold causes a greater number of compounds with lower similarity scores to fall outside AD (Figure S3 showed the examples of out-of-domain compound structures). To minimize the loss of valuable chemical space, the value of k and Z were set to 6 and 0.9, respectively. Accordingly, the final distance threshold was 8.375. As a result, the XGBoost model and SVM model performed best. For instance, XGB_combined and SVM_combined model yielded the similar performance with R2 value of 0.663, 0.667 and RMSE of 0.479, 0.475, respectively.Table 1The performance of different models considering the applicability domain on the test setModelsWithout ADZ = 0.9 and k = 6Z = 1.5 and k = 6Test_R2Test_RMSETest_R2†Test_RMSE†Test_R2†Test_RMSE†XGB_fp0.6140.5170.6190.5130.6320.500SVM_fp0.6320.5040.6390.4990.6540.485GB_fp0.5760.5410.5840.5360.6000.521RF_fp0.6020.5240.6030.5240.6170.510XGB_rdkit2d0.6250.5090.6280.5070.6460.490SVM_rdkit2d0.6260.5080.6370.5010.6460.491GB_rdkit2d0.5770.5410.5750.5420.5960.524RF_rdkit2d0.6130.5170.6160.5150.6320.500XGB_combined0.6470.4940.6510.4910.6630.479SVM_combined0.6490.4920.6540.4890.6670.475GB_combined0.6190.5130.6300.5060.6430.492RF_combined0.6450.4950.6470.4940.6600.480DMPNN0.5840.5360.5860.5350.5940.525CombinedNet0.6050.4980.6100.4950.6220.488†The statistical results considering the applicability domain of the model

Comparison of Caco-2 permeabilities predictions to experimentally measured values for test set (blue dash line: two-fold error; orange part of each subplot: low permeable; blue part: medium permeable; green part: high permeable)

Bar chart plots showing the R2, RMSE and MAE in prediction as a function of binned structural similarities for different models

The performance of different models considering the applicability domain on the test set

## Section: Results and discussion › Model validation on the Shanghai Qilu’s in-house dataset

We next assessed how well machine learning models trained on public data can be transferred to pharmaceutical industry data by applying them to the Shanghai Qilu’s in-house dataset. We also compared the established best-performing model with existing Caco-2 prediction model in the ADMET prediction platform ADMETlab 2.0 [42]. The regression performance statistics for prospective validation of aforementioned prediction models on the Shanghai Qilu’s in-house dataset were given by Table 2 and further visualized by Fig. 5. In general, the performance of these models on the external test set was significantly lower than that on the test set in terms of R2 value. There may be two reasons that lead to such a poor performance and negative R2 values. First, the similarity of molecules between the Shanghai Qilu’s internal dataset and training set is low. As illustrated in Figure S4, the highest Tanimoto similarity was less than 0.45. Second, most compounds in the Shanghai Qilu’s internal data set belong to the low/medium permeability class (Figure S5), while the high permeability bias in the curated data set tends to overpredict the low and medium permeable compounds. However, particular models showed a high correlation between their prediction results and experimental values with Pearson’s r of at least 0.6 and Spearman’s rho of at least 0.6. More specifically, two boosting algorithms (XGBoost, GB) coupled with ECFPs outperformed RF in all cases in terms of Pearson’s r, Spearman’s rho, MAE and RMSE. SVM seemed to work well with all representations but did not outperform the boosting models. The optimal model XGB_fp and GB_fp achieved the Pearson’s r of 0.702, 0.719, Spearman’s rho of 0.704, 0.725, MAE of 0.629, 0.659 and RMSE of 0.771, 0.797, respectively. Similarly, the deep learning approach showed improvements across metrics of Pearson’s r and Spearman’s rho compared to the other machine learning models but did not outperform XGBoost and GB. Although in the last few years, it is a general belief that the increase of the dimension of descriptors gives models with better predictive performances [43]. Based on our findings, the extra addition of 2D descriptors conversely increases the redundancy of features and makes the model become more complicated, thus inversely reducing the prediction performance. Noticeable exceptions from this conclusion seemed to be the Project3, where GB_combined model was the best method. Additionally, the CombinedNet model which used a feature combination of the molecular graph and the molecular fingerprints achieved acceptable performance with the Pearson’s r of 0.677, Spearman’s rho of 0.677, MAE of 0.730 and RMSE of 0.873. However, it did not further enhance prediction performance when compared to boosting algorithms. We also investigated for each project, which of the machine learning methods worked best (see Table S3). Here only projects with more than 8 molecules were included. It can be noted that boosting models were advantageous for the majority of projects in general. Subsequently, we used these models to predict the in-domain compounds in the in-house data set and the performance was provided by Table S4 and Figure S6. It can be found that the GB_fp model had the best overall predictive performance, but it may not necessarily apply to specific project. For example, GB_combined model achieved the best performance in Project 3 (Table S5). However, it is worth to mention that the overall performance of all models has decreased when compared to Table 2. The results suggested that defining a strict similarity threshold correlating with decreased generalization error is challenging and potentially highly dependent on the explored chemical space and in vitro ADME property.Table 2The performance of different models on the Shanghai Qilu’s internal data setModelsR2RMSEMAEPearsonSpearmanXGB_fp− 0.0760.7710.6290.7020.704SVM_fp− 0.3930.8770.7280.6150.608GB_fp− 0.1490.7970.6590.7190.725RF_fp− 0.7370.9790.7950.4260.497XGB_rdkit2d− 0.2660.8360.6810.4560.429SVM_rdkit2d− 0.9001.0240.8830.6100.599GB_rdkit2d− 0.7850.9930.8100.1950.074RF_rdkit2d− 0.3190.8530.7030.4790.488XGB_combined− 0.3500.8630.6940.5710.598SVM_combined− 0.2870.8430.7020.5970.635GB_combined− 0.6840.9640.7240.3180.247RF_combined− 0.4240.8870.7340.4290.413CombinedNet− 0.3790.8730.7300.6770.677DMPNN− 0.9151.0280.8680.6780.700MGA− 1.3831.1470.927− 0.036− 0.103Model with Pearson’s r > 0.6 and Spearman’s rho > 0.6 was indicated in boldFig. 5Correlation of logPapp measurements (x-axis) against machine learning model predictions (y-axis) across 7 Shanghai Qilu’s internal projects (orange part of each subplot: low permeable; blue: medium permeable; green: high permeable)

Together, these results suggested that (1) the boosting model presents a favorable option for the prediction of Caco-2 permeability, (2) the public model transfer is observed with a certain performance decrease but is still valuable for prospective predictions, (3) deep learning models outperforms few methods investigated in this study on industrial data but may not be the best solutions, and (4) it is worth keeping in mind that the feature combination becomes effective only when the added features indeed complement the lacked information and sometimes less can be more.

The performance of different models on the Shanghai Qilu’s internal data set

Correlation of logPapp measurements (x-axis) against machine learning model predictions (y-axis) across 7 Shanghai Qilu’s internal projects (orange part of each subplot: low permeable; blue: medium permeable; green: high permeable)

## Section: Results and discussion › Representative MMP transformations of Caco-2 permeability

The diffusion of a compound is a complex process influenced by various types of interactions [4]. In an attempt to understand how different functional groups affect in Caco-2 permeability, we applied the open-source package mmpdb version 2 to generate a MMP knowledge base tool using all the 5654 compounds in the curated dataset. The three-cut method was used for the analysis, resulting in 65,440 matched molecular pairs and a total of 415,716 rules. A representative set of MMP rules reflecting common medicinal chemistry transformations was listed in Fig. 6 for the optimization of Caco-2 endpoints. For this analysis, we included only transformations that contained at least 10 matched pairs and showed a significant property shift as measured with a p-value < 0.05. In the Fig. 6, “MMP transformations” refers to the transform rules of molecular pairs, “ΔCaco-2 ± std” denotes the average difference and standard deviation in the value of logPapp of molecular pairs, and “nPairs” is the number of molecular pairs. Entries in Fig. 6 can broadly be classified in two groups. The first group involves the introduction of hydrocarbon groups, which tends to increase the logPapp values. Because of the presence of phospholipid bilayer, high lipophilicity of a compound is favorable for efficient permeability. The second group includes transformations of polar groups. As we know, high polarity is detrimental to permeability [44]. Removing or masking hydrogen-bond donors seems to be a good tactic to improve permeability. The introduction of heteroatoms (e.g., O, N) tends to reduce logPapp. Additionally, the halogen substitution in the molecules may play an important role in increasing the polarization and thus decreasing the water solubility and absorption of the molecule. In conclusion, the above rules are generally consistent with our chemical intuition that Caco-2 permeability is related to key physicochemical parameters of molecules, such as lipophilicity, ionization, hydrogen bonding, and molecular size [45]. We believe that these rules will be an important assistive tool for Caco-2 prediction and provide a reference for medicinal chemists to optimize lead compounds.Fig. 6Representative medicinal chemistry transforms with corresponding changes of Caco-2 permeability

Representative medicinal chemistry transforms with corresponding changes of Caco-2 permeability

## Section: Conclusions

Understanding Caco-2 permeability is crucial for predicting drug behavior within the gastrointestinal tract and guiding decisions in the early stages of drug discovery and development. This study systematically evaluated Caco-2 permeability using machine learning models trained on public data. Regression models for Caco-2 permeability were developed using four machine learning methods (RF, SVM, GBM, and XGBoost) and two deep learning methods (DMPNN and CombinedNet). Various molecular representations, including ECFP4, RDKit2D descriptors, and combinations thereof (ECFP4 + RDKit2D), were explored to assess their impact on model performance. Our results reinforced previous evidence suggesting that deep learning methods currently do not consistently outperform simple machine learning methods in drug discovery applications [46]. Boosting models demonstrated superior overall performance compared to deep learning models across both training and test datasets. Approaches leveraging human-engineered molecular descriptors surpassed graph-based deep learning methods in predictive accuracy, while the deep learning model coupled with ECFPs yielded comparable results to machine learning methods. Furthermore, the models trained on public data were transferred and evaluated on Shanghai Qilu’s in-house dataset, revealing that particular models such as XGBoost_fp, GBM_fp, and CombinedNet maintained robust predictive quality to some extent with Pearson’s r and Spearman’s rho of about 0.65 to 0.70, despite potential differences in data distributions between public and industry databases. Additionally, the contributions of common substituents to logPapp were elucidated using Matched Molecular Pair Analysis (MMPA), offering insights into structural optimization strategies.

## Section: Supplementary Information

Supplementary Material 1. Table S1. The optimal hyperparameters for the six machine learning approaches. Table S2. The performances of different models across the training, validation, and test sets. Table S3. The performances of different models across four Shanghai Qilu’s internal project. Table S4 The performance of different models considering the applicability domain on Shanghai Qilu’s internal data set. Table S5. The performances of different models considering the applicability domain across two Shanghai Qilu’s internal project. Table S6. The performances of different models on the external set. Table S7. The performances of different models on the external set considering the applicability domain. Figure S1. The architecture of CombinedNet. Figure S2. The distribution of R2 of 100 randomized models on the validation set compared with the real model in the Y-randomization test. The orange vertical line on the right side represents the R2 value of the true model, and the distribution on the left side represents the distribution of R2 of prediction models after randomization. Figure S3. Structures of the five out-of-domain compounds. Figure S4. The Tanimoto similarity between the Shanghai Qilu’s internal data set and the training set from the curated Caco-2 permeability data set, measured by Morgan fingerprint. Figure S5. The experimental logPapp value distribution of Shanghai Qilu’s internal data set showing that most of the compounds belong to the low permeable class (n=30) while the least number of structures are categorized as high permeable (n=17). Figure S6. Correlation of machine learning model predictions (x-axis) of compounds within the applicability domain against logPapp measurements (y-axis) across 6 Shanghai Qilu’s internal projects. Figure S7. (A) Density plot showing the distribution of logPapp values between external data set and curated data sets. (B) Heatmap showing the Tanimoto similarity between external set and training set. (C) Frequency plot showing the highest Tanimoto similarity to the training set. Figure S8. Correlation of machine learning model predictions (x-axis) against logPapp measurements (y-axis) on the external set. Figure S9. Correlation of machine learning model predictions (x-axis) of compounds within the applicability domain against logPapp measurements (y-axis) on the external set.

Supplementary Material 1. Table S1. The optimal hyperparameters for the six machine learning approaches. Table S2. The performances of different models across the training, validation, and test sets. Table S3. The performances of different models across four Shanghai Qilu’s internal project. Table S4 The performance of different models considering the applicability domain on Shanghai Qilu’s internal data set. Table S5. The performances of different models considering the applicability domain across two Shanghai Qilu’s internal project. Table S6. The performances of different models on the external set. Table S7. The performances of different models on the external set considering the applicability domain. Figure S1. The architecture of CombinedNet. Figure S2. The distribution of R2 of 100 randomized models on the validation set compared with the real model in the Y-randomization test. The orange vertical line on the right side represents the R2 value of the true model, and the distribution on the left side represents the distribution of R2 of prediction models after randomization. Figure S3. Structures of the five out-of-domain compounds. Figure S4. The Tanimoto similarity between the Shanghai Qilu’s internal data set and the training set from the curated Caco-2 permeability data set, measured by Morgan fingerprint. Figure S5. The experimental logPapp value distribution of Shanghai Qilu’s internal data set showing that most of the compounds belong to the low permeable class (n=30) while the least number of structures are categorized as high permeable (n=17). Figure S6. Correlation of machine learning model predictions (x-axis) of compounds within the applicability domain against logPapp measurements (y-axis) across 6 Shanghai Qilu’s internal projects. Figure S7. (A) Density plot showing the distribution of logPapp values between external data set and curated data sets. (B) Heatmap showing the Tanimoto similarity between external set and training set. (C) Frequency plot showing the highest Tanimoto similarity to the training set. Figure S8. Correlation of machine learning model predictions (x-axis) against logPapp measurements (y-axis) on the external set. Figure S9. Correlation of machine learning model predictions (x-axis) of compounds within the applicability domain against logPapp measurements (y-axis) on the external set.


---

# AI-enabled language models (LMs) to large language models (LLMs) and multimodal large language models (MLLMs) in drug discovery and development

- **Authors:** Chiranjib Chakraborty, Manojit Bhattacharya, Soumen Pal, Srijan Chatterjee, Arpita Das, Sang-Soo Lee
- **Issuer:** Journal of advanced research
- **Type:** Scientific article
- **Published:** 2025-02-12
- **Language:** en
- **DOI:** 10.1016/j.jare.2025.02.011
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39952319/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Graphical abstract

## Section: Introduction

In 2020, Exscientia, an artificial intelligence/machine learning (AI/ML) and automation-based pharmaceutical company, announced that the first AI-discovered molecule (DSP-1181) entered the Phase-1 clinical trial as a drug molecule. Exscientia and Sumitomo Dainippon Pharma developed the molecule through a joint venture [1], [2], [3]. Exscientia is a UK-based drug discovery company, and Sumitomo Dainippon Pharma is a Japan-based pharmaceutical company. The news has gained attention to the drug discovery and development in the pharmaceutical companies. Drug discovery and development is a complicated process, and vast knowledge is required from basic science research, medicinal chemistry, biological assays, and pharmaceutical technologies. At the same time, researchers should know the different methodologies, tools, and technologies from different fields for drug target identification, target validation, hit-to-lead (H2L) generation using high throughput screen (HTS), synthesis of the drug molecule, drug molecule testing using the animal model, drug delivery system development, ADME/ADMET (absorption, distribution, metabolism, excretion/toxicity) analysis. Therefore, it is a complicated and time-consuming process. However, the association of AI in drug discovery and development has reduced the cost and accelerated the timeline. Therefore, AI-enabled drug molecule discovery by Exscientia and Sumitomo Dainippon Pharma and its entrance into the clinical trial has created a new hope in the pharmaceutical sector for drug molecule discovery. As of 2024, several AI-generated molecules have entered the clinical trial [4], [5], [6]. AI and deep learning (DL) have been used in different drug discovery and development steps to help speed up the process. For example AI and DL has been used in high-throughput screening (HTS) and molecular docking to speed up drug discovery and development. HTS allows for the experimental testing of large libraries of compounds against biological targets, significantly speeding up the identification of active compounds [7]. On the other hand, molecular docking simulates interactions between small molecules and proteins to predict binding affinities. At the same time, quantitative structure–activity relationship (QSAR) models use statistical methods to relate chemical structures to biological activities, providing valuable insights into molecular function [8]. AI-enabled large language models (LLMs) or generative Al (Gen AI) have been used in HTS, molecular docking, QSAR, etc., for drug discovery and development processes [9].

After the Alan Turing test in 1950, AI started to progress. ML algorithms were introduced in 1959, and the first chatbot, ELIZA, was introduced in 1966 (Fig. 1). After the introduction of DL algorithms, the area has advanced very fast. AI-empowered LLMs have emerged as a transformative force in NLP and are driving notable progress in diverse domains. LLM, a DL based computational model, can perform various NLP (natural language processing) related assignments. Using the token or word as a form of generative AI, LLMs can take text as the input and repeatedly generate the output. LLMs were developed from the language models (LMs), and before 2017, few LMs existed. In 2017, transformer algorithms, a DL-based architecture, were developed, which allows the LMs to process and generate large amounts of text data [10]. It is a landmark discovery by Vaswani et al. where text is converted into a token. The token is a numerical representation in the transformer algorithm, and each token can be converted into a vector [10], [11]. The full potential of LLMs materialized with the introduction of GPT-3 by OpenAI in 2020. Trained on an unparalleled scale, encompassing over 175 billion parameters and a dataset comprising nearly a trillion words, GPT-3 demonstrated exceptional performance across a broad spectrum of natural language tasks, including text generation, translation, summarization, and question answering [12]. Models like GPT-3, BERT, and Claude have undergone training on billions, or even trillions, of tokens, enabling them to amass an unparalleled comprehension of human language and its subtleties (Fig. 2). Recently, LLM has evolved in MLLM (multimodal large language model). The evolution of MLLMs represents a significant leap in AI, enabling models to process and understand multiple forms of data, such as text, images, audio, and video [13]. MLLM has also been applied in different domains of biology to medicine, including drug discovery and development.Fig. 1The timeline illustrates AI progress and its landmark achievements.Fig. 2The timeline illustrates the introduction of different AI-powered chatbots from time to time.

The rapid growth of LLM or MLLM has recently led to significant advancements in various domains. The transformer-enabled LLM or MLLM is widely applied in different areas of science, including chemical science, computer science, and biology, due to its impressive capabilities and several advantages [14], [15], [16]. LLMs or MLLMs are also applied in various fields of medical science, including orthopedics, pathology, medicine, radiology, etc. [17], [18], [19], [20]. After the launch of ChatGPT on November 30, 2022, LLM gained immense importance from users. Within a few days after its launch, a few million users were added to the new users list for the chatbot. Now, billions of users use different chatbots such as ChatGPT and others. Like other users, drug discovery researchers have gained massive interest in AI-enabled research. Researchers are using ChatGPT and other LLMs or MLLMs to speed up the process of drug discovery and development [1], [21], [22], [23]. Therefore, a focus shift has been noted to the relevance of LLMs in pharmaceutical research.

This article discusses the role of AI-enabled LMs, LLMs, and MLLMs in different drug discovery and development fields such as de-novo drug discovery, drug target identification and validation, ADME/ADMET, etc. We also discuss the other applications of LMs, LLMs, and MLLMs in drug discovery and development. Furthuremore, different challenges and prospects in drug discovery for LLMs have also been discussed.

The timeline illustrates AI progress and its landmark achievements.

The timeline illustrates the introduction of different AI-powered chatbots from time to time.

## Section: Molecular design using DL and deep generative models

Molecular design using DL and deep generative models has revolutionized drug discovery, material science, and chemistry by enabling efficient chemical space exploration, molecular properties prediction, and the generation of novel molecules with desired characteristics. These advancements have dramatically accelerated the pace of innovation and discovery across multiple scientific disciplines. HTS is used to test large libraries and identify active compounds experimentally. Scientists are trying to include the LLM or Gen AI in HTS. Similarly, combinatorial chemistry systematically generates large libraries of molecules, which are then screened for biological activity, expanding the potential for discovering new therapeutic agents.. Computational methods, such as molecular docking, are critical in this revolution. AI-based docking has revolutionized drug discovery. LLM used is tried in this area. QSAR models, which use AI or DL models, provide more insights into molecular function. Deep QSAR is an example [24]. In the future, LLM or MLLM will play a significant role in this area.

DL in molecular design leverages DNNs for property prediction and feature extraction. DNNs predict molecular properties such as solubility, toxicity, and binding affinity from molecular structures, while CNNs and graph neural networks (GNNs) automatically extract relevant features from molecular graphs or SMILES strings [25]. Reinforcement learning (RL) further enhances molecular design by optimizing molecular structures to improve desired properties and guiding the search within chemical space. RL also facilitates inverse design, where molecules with specific properties are iteratively refined (Fig. 3) [26].Fig. 3The overview of a workflow of AI-enabled target-specific drug molecule design.

Deep generative models, including variational autoencoders (VAEs), generative adversarial networks (GANs), recurrent neural networks (RNNs), and transformers, are pivotal in molecular design. VAEs encode molecules into a continuous latent space, allowing for smooth interpolation and generation of novel molecules, and conditional VAEs generate molecules with specific properties by conditioning the latent space on desired characteristics. GANs improve the quality of generated molecules through adversarial training, where a generator creates new molecules and a discriminator distinguishes between real and generated molecules. GANs are particularly useful in drug discovery, generating novel drug-like molecules by learning from existing chemical libraries. RNNs generate new molecules as SMILES strings, learning these strings' syntax and chemical validity and predicting the next character in a sequence to ensure chemical validity. With their sequence-to-sequence generation and attention mechanisms, transformers generate molecules as sequences with high efficiency and accuracy, capturing complex dependencies in molecular structures [27].

The applications of deep generative models are vast. In drug discovery, these models facilitate de novo drug design, creating new drug candidates with high affinity for specific targets, and lead optimization, improving properties such as potency, selectivity, and pharmacokinetic profiles [28], [29]. In material science, they aid in designing new polymers with specific mechanical, thermal, or electrical properties and generating novel catalysts with high efficiency and selectivity for chemical reactions. In chemistry, these models predict feasible synthetic routes for complex molecules and the outcomes of chemical reactions, assisting in planning experiments [28].

Molecular design using DL and deep generative models has been applied in different drug discovery and development areas. LLMs or MLLMs have started to be used in molecular design through the transformative use in this field. However, several challenges remain. High-quality labeled data is often scarce, especially for novel or rare molecules, necessitating techniques for data augmentation such as virtual screening and synthetic data generation. The black-box nature of DL models raises concerns about interpretability, making it difficult to understand why specific molecules are generated. Developing explainable AI methods is crucial for interpreting and understanding the decisions made by deep generative models. Integrating these models with experimental workflows for validation and combining them with automated synthesis and testing platforms can ensure the practical utility of generated molecules. Ethical and safety considerations are paramount to prevent the misuse of generative models for creating harmful substances and to ensure compliance with regulatory standards for designing and using novel molecules.

The overview of a workflow of AI-enabled target-specific drug molecule design.

## Section: AI-enabled LLMs in drug discovery

Presently, AI-enabled models using LLM are used significantly in the different steps of drug discovery and development and can perform a wide range of tasks in this domain (Fig. 4). Researchers are developing LLMs to speed up the process. Here, we have identified how LLMs perform these tasks.Fig. 4AI-enabled LLMs in the context of drug discovery and development. The figure depicts the different stages of drug discovery and development and the applications of LLMs in these stages.

LLMs have been used in drug design in different fields of chemistry, including structure-based drug molecule generation and de novo drug design, drug target identification and validation, ADME/ADMET study, etc.(Table 1).Table 1Significant LLMs and MLLMs in drug discovery and development.Sl. No.LLMs/MLLMsDeveloperRemarksReference1.Med-PaLM 2GoogleIt analyses large volumes of medical literature and clinical trial data to accelerate drug discovery and identify drug targets[122]2.Tx-LLMGoogleThe wide variety of chemical or biological entities (dataset, targets) support to various stages of the drug discovery[123]3.SynerGPTOpenAIThis GPT language model is used to learn drug synergy relations and designing novel synergistic drug structures by personalized dataset[124]4.CancerGPTLi et al.This application supports to hold the drug pair synergy prediction in rare tissues with partial structured data and features[125]5.GenePTChen et al.The fine tuned model is used to know the perturbation predictions and drug-gene interactions, as well as classifying gene properties and cell types[126]6.DTI-BERTZheng et al.It is used for genomic drug discovery, and computational prediction of drug target prediction, specifically to generate information from drug molecular fingerprints[127]7.GeneformerTheodoris et al.It is applied the to identify the candidate therapeutic targets for cardiomyopathy and is capable to transform public datasets into candidate therapeutic target[128]8.MOLE-BERTXia et al.It uses the molecular graphs as input data and predict the molecular properties of drug molecules[129]9.LSCPP-BERTUKPLabThis tool used for predicting coding lncRNA-sORFs and prospective to expressively contribute to drug development and agricultural applications[130]10.SMILES-BERTWang et al.It is used to extract drug features of fine-tuned large protein models, and offers potential representations of drug-target pairs[131]11.MolGPTBagal et al.In the token prediction task, it integrates an extra training work for conditional prediction and generation of innovative and efficacious drug molecules[39]12.C2P2Nguyen et al.It uses the dataset for protein–protein interaction (PPI) and chemical-chemical interaction (CCI) tasks to obtain information of intermolecular interactions and consequently transfer this to affinity prediction[130], [131]13.K-BERTWu et al.The model is applied for atom feature prediction, prediction of molecular feature, and contrastive learning across the multiple pharmaceutical datasets[132]14.DrugAssistYe et al.The interactive molecule optimization model can perform to optimization for the critical task in the drug discovery pipeline[40]15.DrugLLMLiu et al.This LLM is tailored for drug design and able to produce novel molecules with predictable properties based on limited examples[38]16.FSM-DDTRMonteiro et al.This architecture in the framework of drug design, is capable of exploring the immense chemical representation space to generate novel molecules with enhanced pharmacological properties and target selectivity[62]17.QuoteTarge-tChen et al.It is an effective sequence-based identifier for drug target proteins, and support to produce novel insights into identifying drug molecule-binding sites[65]18.cMolGPTWang et al.This valued tool is used for de novo molecule design and has the potential to quicken molecular optimization cycle time[60]

AI-enabled LLMs in the context of drug discovery and development. The figure depicts the different stages of drug discovery and development and the applications of LLMs in these stages.

Significant LLMs and MLLMs in drug discovery and development.

Overview of the application of LLMs from structure-based drug molecule design to de novo drug design. (a) the application of LLMs in structure-based drug molecule design, (b) the generation of SMILES strings from molecular graphs during drug design, and (c) the application of LLMs in de novo drug design.

## Section: AI-enabled LLMs in drug discovery › Structure-based drug molecule design using AI-enabled LLMs

LLMs can perform a variety of tasks in different areas of chemistry. The pre-trained LLMs can answer the question of structural perspective of chemical structure [30], [31], [32]. Tran et al. illustrated pre-trained LMs to answer the different questions in chemistry. They tried to understand how the text-to-text pre-trained LM can assist in chemical classifications, information about chemical species and their physical and chemical properties, and applications through the question-answering (QA) system for chemistry. The LM’s ability to answer complex questions with superior accuracy [33] is a good example. Using DL-based LLM, researchers embed chemistry knowledge and develop further models for drug discovery and development. Using these models, researchers design the ligand using the conventional method [34]. It is also called the structure-based ligand or structure-based drug molecular design (Fig. 5A). For structure-based drug molecular design, SMILES strings are generated from molecular graphs (Fig. 5B). Therefore, several molecular structures can be generated through LMs or LLMs using the SMILES string [35], [36]. Sadeghi et al. used two LLMs, LLaMA from Meta AI and GPT from OpenAI, to understand the fundamental molecular-input of SMILES. They found that LLaMA outperformed in both drug drug interaction (DDI) and molecular property prediction tasks. It shows that LLMs, in generating SMILES embeddings, have great potential [36]. Zhumagambetov et al. developed an LM called Transmol. It can be used for molecular generation of drug molecules. It might be helpful for molecular library generation and lead generation. It included an ML-generated molecules database (cheML.io web database) for advanced molecule design with cutting-edge methodology [37]. Similarly, DrugLLM has been generated by a group of researchers. It is a few-shot molecule generation using open LLM and GMR (group-based molecular representation) for proper molecular representation [38]. Bagal et al. have developed a MolGPT model using a transformer-decoder algorithm. The model can create molecules with required scaffolds. The chosen molecular properties can be generated for this molecule by creating scaffold SMILES [39]. Ye et al. recently developed an LLM to optimize the drug molecule. The model is called Drugassist, and it performs a molecule optimization process by grasping the underlying patterns in chemical structures [40]. Recently, Wang et al. developed a LLM for drug design and to comprehend three-dimensional (3D) structures through tokenization. The model is called Token-Mol 1.0. The researchers proposed a GCE (Gaussian cross-entropy) loss function during drug design [41]. Researchers can facilitate high-quality and rapid drug design using the model.Fig. 5Overview of the application of LLMs from structure-based drug molecule design to de novo drug design. (a) the application of LLMs in structure-based drug molecule design, (b) the generation of SMILES strings from molecular graphs during drug design, and (c) the application of LLMs in de novo drug design.

Overview of the application of LLMs from structure-based drug molecule design to de novo drug design. (a) the application of LLMs in structure-based drug molecule design, (b) the generation of SMILES strings from molecular graphs during drug design, and (c) the application of LLMs in de novo drug design.

## Section: AI-enabled LLMs in drug discovery › De novo drug design using AI-enabled LLMs

De novo drug design is a procedure that involves creating a novel drug-like molecule without a starting template [42]. It is a prioritized area. Researchers are developing drug molecules through de novo drug design using AI-enabled LLM or AI-enabled chemical language models (Fig. 5C) [43]. Haroon et al. recently developed a GPT-based LM for de novo drug design. It might help researchers design drugs with desired properties [44].

Similarly, Wang et al. have developed a conditional GPT-based model for de novo drug design through the generation of SMILES string. The model is called cMolGPT. It is a significant tool for de novo molecule design that can help quicken the molecular optimization cycle time [45]. Using the chemical language model (CML), Moret et al. tried to understand the relationship between molecular structure and bioactivity. In this study, a collection of CML design ligand molecules were used ligands of PI3Kγ (phosphoinositide 3-kinase gamma) and showed positive results. The model can be used for de novo drug design [46]. CLM is generated from NLP. Further this group advocated that CML to be used for de novo molecular structure generation, activity-focused molecular design, and virtual compound screening. Grisoni illustrates that CLM can generate new molecules. Therefore, it accelerates de novo drug design [47].

Similarly, Monteiro et al. developed a multi-objective LM for de novo drug design. The model, called FSM-DDTR, performs de novo drug design transformer-based architecture exploring the vast chemical space. The generated drug molecule has optimal drug-likeness properties, optimal values of synthetic accessibility score, topological polar surface area, molecular lipophilicity, and molecular weight [48].

## Section: AI-enabled LLMs in drug discovery › Drug target identification, validation, and interaction using AI-enabled LLMs

Drug target identification, validation, and interaction is one of the essential areas of drug discovery and development. Researchers are developing different LLM-based models to target identification, validation, and interaction. Recently, drug target interaction studies in wet labs have become costly and time-consuming. In this direction, LLM-based models help to show the path for faster drug discovery methods. LLMs identify drug targets through gene-related literature and explore disease mechanisms and biological pathways [49]. One example is ChatGPT v.4, which has a plug-in that assists with an initial interpretation of protein-related drug target discovery. Sheikholeslami et al. developed DrugGen, an LLM-based model that can develop the drug and its target's interactions. In this DrugGen model, drug targets are essential components [50]. To keep in mind the problem, Kalakoti et al. have developed a transformer-based LM to study the drug target interaction (DTI). The model is called TransDTI. The model is backed by molecular docking and simulation analysis [51]. It has been noted that the maximum candidates of the drug target class are proteins such as GPCR, ion channel receptors, enzymes, and transporter proteins [52]. Protein language models (PLM) have been developed to understand the different properties of proteins. The protein language model is used to identify the potentially druggable protein targets. Chen et al. have developed a sequence-based transformer PLM to find the druggable protein targets. The model is called QuoteTarget. The model uses the joint sequence-enabled self-supervised pretraining PLM, and it identified 1213 possible drug target proteins. The model applied residue-binding weights using the Grad-Cam (gradient-weighted class activation mapping) algorithm and the well-trained network [53]. Some protein language models help to understand the properties of proteins that can be used as protein-based drug targets. Some examples are PLMSearch for homology sequences [54]; xCAPT5 for PPI (protein–protein interaction) [55], LMPhosSite for prediction of phosphorylation site [56], LMNglyPred for estimate of N-linked glycosylation sites [57].

## Section: AI-enabled LLMs in drug discovery › ADME/ADMET using AI-enabled LLMs

Understanding a drug molecule's ADME attributes is a significant criterion for drug development. Presently, along with the four properties, toxicity is also measured. Therefore, presently, it is termed ADMET [58], [59]. ADMET can be studied through the LLM technologies [60]. Several researchers stated that ChatGPT helps to comprehend the ADMET properties through the QA model [22], [61], [62]. Wang et al. have studied the ADMET properties of drug molecules using ChatGPT. In this study, the researchers have used as a case study on anticocaine addiction drug [63]. ChatGPT or other AI-enabled chatbots or LLMs might be a successful platform for understanding a drug molecule's ADME/ADMET properties. Zheng et al. have also studied ADME attributes of a drug through LLMs [64]. Similarly, Niu et al. developed PharmaBench, a multi-agent data mining system. It is a benchmark for ADMET model prediction [65]. Aksamit et al. discussed the hybrid SMILES-fragment tokenization method for ADMET forecast during drug discovery. The method is coupled with two pre-training strategies [66].

## Section: AI-enabled LLMs in drug discovery › Other areas of drug discovery and development and AI-enabled LLMs

Several other LLMs have been developed to bridge this drug discovery and development gap. Recently, researchers developed an LLM for the pharmaceutical domain. The model is called PharmGPT, and it helps understand the biopharmaceutical and chemical sectors [67]. DDIs are one of the critical parameters that researchers understand after drug development [68]. Using the effectiveness of ChatGPT, Juhi et al. studied the DDIs using two-stage questions. In this study, a total of 40 DDI lists were studied. For the first question, 20 were inconclusive, and 19 were conclusive. For the second question, they found that 22 were inconclusive, 17 were conclusive, and one answer was wrong [69]. Liang et al. developed a ChatGPT-like model for understanding the drug molecule graphs. The model is called DrugChat [70]. LLMs have shown the capacity for drug safety documentation search. Researchers have searched the drug safety documentation [70], [71].

## Section: AI-enabled LLMs in drug discovery › LLM selection

The objective of LLM selection is to increase the task's performance during drug discovery and development. However, different LLMs can perform the same task. Therefore, the selection of LLMs is an essential process in drug discovery and development. It is a critical decision that requires a profound understanding of the model's capabilities and where it fits the drug discovery process with the highest output. Most importantly, we should know the LLM's application in drug discovery and development. Therefore, for LLM selection, we should also consider the drug compound-specific parameters and biological system-specific parameters. At the same time, we should understand each LLMs' advantages and disadvantages. Following this process, we can efficiently use LLMs in drug discovery and development.

## Section: MLLMs in drug discovery and development

Multimodal LLMs thats MLLMs are used to handle many non-text datasets and text data sets. It can handle images, audio, video, and other vast range of non-text datasets. To explore diverse promises, researchers have applied MLLMs in different areas of medical science. Using a multimodal DL model, researchers predicted multiclass surgical outcomes in glaucoma. The model can forecast the binary outcomes when the surgeries have numerous consequences. Also, the model can provide significant understanding for clinical decision-making [72]. Recently, Xiao et al. developed the ProteinGPT, an MLLM-based protein structure understanding and property prediction model. Understanding the property prediction of the protein-based drug target may be helpful [73]. Besides the protein-based drug target, MLLM will also help to understand the biological macromolecules that can be used as drug targets [74].

Researchers have recently used the MLLM to understand the mutations that cause nAb escape. This model might help to detect drug-resistance mutations [75]. However, more efficient models are needed in this direction.

Similarly, Liu et al. have created GIT-Mol, an MLLM to combine text, images, and graphs for complex information on molecular science and explore further potential in this area. The model can execute downstream tasks, such as chemical reaction prediction and compound name recognition [76]. The model can be used to recognize the drug molecule recognition. Sirumalla et al. developed a multi-task and multimodal transformer to help discover small molecular drugs [77]. Similarly, Lu et al. proposed a model called MMFDL (multimodal fused deep learning). It can assist in predicting drug molecules' properties. These researcher indicated the binding constants for drug molecules' protein–ligand complex using this model, and the model can provide information from different molecular representations [78]. There is an enormous possibility for MLLMs for different areas of drug discovery and development because they can use images. Therefore, MLLMs can potentialy shape the future landscape of drug discovery and development.

## Section: LLMs in other medical use

LLMs can significantly revolutionize medical science by increasing many applications, including improving the accuracy of diagnoses and assisting the decision-making processes in clinical settings (Table 2) [79]. These models can enhance patient care by enhancing crucial medical competencies, encompassing factual knowledge and interpersonal communication skills. ChatGPT has also exhibited a significant comprehension of medical semantics and the capacity to carry out intricate medical reasoning tasks [80]. This proficiency is demonstrated by its impressive performance in medical licensure examinations [81], [82], [83]. AI-driven systems like ChatGPT significantly impact doctor-patient relations and help distribute medical knowledge in today's complex medical field. LLMs serve as initial online consultation tools, offering patients fundamental yet essential information regarding their medical issues, treatment options, and preventive measures [84], [85]. This feature helps patients save crucial time and provides them with fundamental knowledge and guidance before their face-to-face medical appointments. LLMs excel at simplifying intricate medical terminology, providing lucid and understandable explanations that improve patients' comprehension of medical diagnoses and recommendations [86].Table 2Significant LLMs and MLLMs in the medical and healthcare sectors.Sl. No.LLMs/MLLMsDeveloperRemarksReference1.GalacticaMeta AIIt is trained on over 48 million papers, reference material, textbooks, proteins, compounds, and additional sources of scientific knowledge intended for the research community to develope personalized medicine[133], [134]2.BioLinkBERTYasunaga et al.The 110 million parameters containing model is used for extraction of data from clinical trial reports[135]3.BioMegatronNVIDIAThis biomedical text performing LLM is used for recognition, relation extraction, and question answering in diverse biomedical aspect[136]4.BioMedLMBolton et al.It holds 2.7 billion parameters and is a GPT-style autoregressive model trained entirely on PubMed abstracts and full articles, and MCQs in biomedicine[137]5.PerplexityPerplexity.aiIt is able to generate medical information with the convinced level of accuracy for questions usually modeled by patients having health issues for prostate, skin, breast, lung, and colorectal cancers[138]6.ChatDoctorLi et al.The bulky dataset of 100,000 patient-doctor dialogues specifically used for used online medical consultation platform (error tolerance)[139]7.PMC-LLaMAWu et al.It is the open-source language model (30 thousand medical textbooks and 4.8 million biomedical academic papers) specifically designed for medicine applications[140]8.PubMedBERTGu et al.It uses the PubMed vocabulary, pretrained using PubMed abstracts for evidence-based medical information extraction, medical notes and domain-specific biomedical support[141]9.ClinicalCamelToma et al.The dialogue-based knowledge encoding model for data from dense medical texts for within the healthcare domain and clinical applications[142]10.GPT3.5OpenAIIt is used as different models as a diagnostic aid for complex medical cases, cancer diseases, medical questionaries and imaging study[143]11.BioGPTMicrosoftIn biomedical domains it is used through the biomedical literature to generate fluent descriptions for biomedical terms[144]12.MedAlpacaHan et al.It is the open-source collection of medical conversational AI models and training data used for improving medical workflows, patient care, diagnostics, and health education services[145]13.B-LBConAYang et al.This model includes disambiguation clues about the relevance among the reference context and candidate entities via the context-aware mechanism[146]14.GeneGPTJin et al.It uses the Web APIs of the NCBI for answering genomics questions, and it supports improved access to biomedical information[147]15.ClinicalBERTHuang et al.The lab values and medications, other structured data used for modeling of clinical notes ad associate patients information.[97]16.MT-BioNERKhan et al.The biomedical datasets of (time and memory) used for slot time tagging as a multi-task learning model.[148]

Moreover, current research highlights the significance of these sophisticated instruments in enhancing the precision of consultations and combating medical misinformation, specifically in domains like vaccination [87]. LLMs possess a vast knowledge base that enables them to cover various medical specialties, including orthodontics and cardiac surgery. It can reduce the communication barrier between doctors and patients [88].

Various instances of LLMs optimized explicitly for medical applications demonstrate the potential of transfer learning, domain adaptation, and other specialized approaches in this domain. For example, BioBERT, a pre-trained language representative model, can specifically design several biomedical applications. It is built on the BERT architecture. The model has undergone extensive optimization using vast biomedical datasets, including PubMed abstracts and PMC full-text publications. This optimization has led to notable enhancements in several biomedical NLP tasks, such as identifying named entities, extracting relationships, and answering questions [89]. ClinicalBERT, a specialized model, has undergone fine-tuning using the MIMIC-III dataset, comprising electronic health records of patients in critical care units. This model has improved efficacy in clinical NLP tasks, such as predicting patient mortality, de-identifying information, and classifying diagnoses [90]. BlueBERT, which shares the same BERT architecture and has been pre-trained on an extensive collection of biomedical text data, has demonstrated exceptional performance in several biomedical related NLP tasks. Some examples are named relation extraction, entity recognition, and biomedical question-answering [91].

LLMs are extensively utilized in medicine and biomedical research for several purposes, such as generating, summarizing, and correcting text. These models can produce substantial amounts of original material, such as templates that can be used for clinical documentation, standardized reports, presentation outlines, or cover letter samples, particularly for book submissions. LLMs can summarize intricate academic papers into concise content, allowing the readers to grasp challenging concepts in articles and automatically generate some of the abstracts. Moreover, they can condense large quantities of clinical data, such as transforming notes into precise summarized statements that help in patient evaluations. LLMs can improve the grammar, coherence, readability, and conciseness of the written information without changing the actual meaning and context of the text. This feature is especially advantageous in scholarly writing since it can enhance the clarity and consistency of manuscripts and grant proposals [92]. The introduction of LLMs has uniquely transformed medical writing, particularly by incorporating models like ChatGPT [93]. Although significant limitations exist in understanding and creating medical texts, LLMs for medical science are skilled at quickly accessing a wide range of interdisciplinary data, which helps researchers rapidly combine newly made discoveries [94]. Researchers at the multi-country level performed a series of tests to comprehend the pattern of ChatGPT-derived answers, and different statistical models were developed for validation. However, the ChatGPT-derived answers show plagiarism [95]. Therefore, previously, we urged the researchers that plagiarism-free LLMs are required for writing [96]. LLMs have exceptional proficiency in composing the first iterations of articles and improving the syntax and manner of existing publications, hence augmenting their clarity and consistency [97], [98].

Significant LLMs and MLLMs in the medical and healthcare sectors.

## Section: LLMs in rare disease drug discovery and development

Rare diseases affect fewer people. Less data is available for rare diseases, so drug development is challenging. On the other hand, drug development for rare diseases is complex because many such cases are linked to multiple variations in genotypic and phenotypic manifestations [99]. Multimodal learning is helping in this direction to perform genotype-phenotype mapping. Khodaee et al. developed a multimodal foundation model to understand genotype-phenotype mapping and its relationship. It might provide an advanced resolution to explore cellular heterogeneity [100]. Gene prioritization is another area of research for rare diseases. Liang et al. developed a Genetic Transformer (GeneT) for identifying causative variants of candidate genes. It will be a helpful solution for gene prioritization in rare diseases [101]. Therefore, LLM or MLLM helps to understand multiple variations in genotypic and phenotypic manifestations. Kafkas et al. illustrated the LLM and its application in causative gene prioritization (phenotype-based) in rare diseases [102]. Similarly, Kim et al. described the benefit of LLM for phenotype-based gene prioritization [103].

For rare diseases, the number of patients recruited for clinical trials is low, and this has generated less data. Therefore, it is very challenging to collect sufficient efficacy and safety data for clinical trials in rare diseases [104]. On the other hand, LLMs might help match the patients in clinical trials, which might assist the clinical trials in rare diseases. Jin et al. developed TrialGPT, an LLM-based model to support clinical trials. This LLM has three modules: TrialGPT-Retrieval to conduct large-scale filtering to recover trial candidates, TrialGPT-Matching to indicate patient eligibility, and TrialGPT-Ranking to yield the trial-level scores [104]. Using these three modules, one can perform clinical trials efficiently. This LLM will help the fewer patients recruited for clinical trials, such as those for rare diseases.

## Section: LLMs for drug repurposing

Drug repurposing helps us to find a molecule for a symptom that already exists as a drug to treat other diseases and conditions. It is one of the cost and time saving ways in the drug discovery and development process to create new medicines. In urgent situations, drug repurposing helps to find therapeutic solutions [105], [106]. During the emergency conditions of the COVID-19 pandemic, researchers have tried to develop several repurposed drugs [107], [108]. Recently, LLM has helped in drug repurposing. Wei et al. have developed DrugReAlign, an LLM for drug repurposing using the multi-source prompt framework. The model can handle extensive training data and vast parameter sizes [109]. Similarly, Inoue et al. developed DrugAgent, which is another drug-repurposing model. This model shows the framework’s possibility to forecast drug-disease interactions [110]. These LLM-based drug repurposing models reduce the costs and time compared to traditional drug discovery methods.

## Section: Ethical challenges of utilizing LLMs in drug discovery

The ethical challenges of utilizing LLMs in drug discovery encompass accountability, fairness, and the risk of unforeseen outcomes. A key concern is determining who should be held accountable for decisions shaped or guided by these models. Concerns about privacy in LLMs are significant, as these models can retain information from their training datasets. For instance, in the context of handling sensitive multi-omics data obtained during patient profiling, it is crucial to guarantee that the data is properly anonymized, making it impossible to link back to an individual patient [49].

Many prominent LLM inference platforms implement rate limits, preventing any single client from monopolizing the request queue to maintain equitable handling of client requests. However, this basic approach to fairness can lead to inefficient resource usage and a suboptimal experience for clients, especially when additional capacity is available. Although there is extensive research on fair scheduling, deploying LLMs introduces distinct challenges due to the unpredictability of request durations and the specific batching dynamics on parallel accelerators [111].

## Section: Future prospect

The potential of AI in drug discovery is rapidly transitioning from theoretical to practical, especially with the emergence of LLMs. Utilizing AI in the drug discovery and development stages is poised to revolutionize the competitive landscape for pharmaceutical companies, enabling them to innovate more effectively by harnessing the capabilities of LLMs [112]. Researchers have been exploring the potential of AI for new drug discovery, employing techniques such as graph neural networks [113], [114] and, more recently, generative models [115]. Numerous AI-driven approaches exist for molecular design and drug development, including GPT-based models that leverage scaffold SMILES strings with desired molecular properties [39]. The T5 architecture has also been utilized for tasks like reaction prediction [116] and translating between molecular captions and SMILES strings [117].

LLMs now exhibit human-like proficiency in processing text. Significantly, transformer neural networks form the foundation for text and image processing networks, creating multimodal AI models that can simultaneously handle various data types. It represents a significant shift from the specialized, niche models of the 2010s [118]. Drug research and development (R&D) is a challenging and intricate process characterized by lengthy timelines, substantial financial investment, and high failure rates. With its robust capability to analyze large datasets and complex networks, ML is increasingly enhancing the efficiency and success rates in drug R&D [119]. In the rapidly evolving landscape of drug discovery, the fusion of multimodal data with AI and ML technologies sets the stage for ground-breaking advancements. This synergy is not only expediting traditional processes but also paving the way for innovative approaches to complex, manpower intensive challenges [120]. When looking into the future of clinical trials, AI is unquestionably a multifaceted technology shaping the drug discovery process.

The ideology behind using AI-driven tools in clinical trials is establishing a systemic channel to evaluate vast amounts of information generated during drug research with higher accuracy. Researchers are leveraging AI tools to pinpoint drug molecules and detect specific complex disease patterns in patients. When AI is integrated with ML, it enhances researchers' ability to analyze vast datasets, leading to the optimization of drug molecules for better outcomes. AI algorithms streamline various stages of the drug discovery process, making clinical trials for drug approval faster, more accurate, and more efficient. The future of clinical research lies in the broad adoption of digital technologies, virtual learning, and AI. This technological integration will reduce the financial burden on pharmaceutical companies during drug development. Moving forward, pharmaceutical companies will utilize AI applications to create patient-centric drugs with high precision, effectively closing the gaps between drug discovery, development, clinical trials, approval, and market distribution [121].

## Section: Conclusion

Integrating prompt-engineering LMs, LLMs and MLLMs represent a transformative leap in drug discovery and development. These sophisticated AI technologies facilitate the precise and efficient identification of drug candidates and offer deeper insights into complex biological processes by synthesizing extensive and varied datasets. Using LLMs in drug research accelerates the development pipeline, significantly reduces costs, and enhances the success rates of clinical trials by automating and optimizing numerous stages of the process. As pharmaceutical companies increasingly adopt these AI-driven methodologies, the industry is poised for rapid innovation and development of highly effective, patient-centric therapies. This shift promises to expedite the creation and approval of new drugs and aims to improve healthcare outcomes. By embracing these AI-enabled advanced tools, the pharmaceutical industry can better meet the demands of modern medicine, addressing critical health challenges more efficiently and effectively. In summary, prompt-engineering-powered and multimodal LLMs are set to revolutionize drug discovery and development, paving the way for a future where cutting-edge technology and healthcare innovation go hand in hand and will revolutionize the pharmaceutical sector through the fastest and most cost-effective method of drug discovery and development shortly.

## Section: Compliance with Ethics Requirements

This article does not contain any studies with human or animal subjects.

## Section: CRediT authorship contribution statement

Chiranjib Chakraborty: Investigation, Supervision, Writing – original draft, Writing – review & editing. Manojit Bhattacharya: Validation, Writing – original draft. Soumen Pal: Validation, Formal analysis, Writing – original draft. Srijan Chatterjee: Validation, Formal analysis, Writing – original draft. Arpita Das: Validation, Formal analysis. Sang-Soo Lee: Validation, Funding acquisition.

## Section: Declaration of competing interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.


---

# AI-Integrated QSAR Modeling for Enhanced Drug Discovery: From Classical Approaches to Deep Learning and Structural Insight

- **Authors:** Mahesh Koirala, Lindy Yan, Zoser Mohamed, Mario DiPaola
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2025-09-25
- **Language:** en
- **DOI:** 10.3390/ijms26199384
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41096653/
- **Licence:** CC-BY

## Section: Abstract

AbstractIntegrating artificial intelligence (AI) with the Quantitative Structure-Activity Relationship (QSAR) has transformed modern drug discovery by empowering faster, more accurate, and scalable identification of therapeutic compounds. This review outlines the evolution from classical QSAR methods, such as multiple linear regression and partial least squares, to advanced machine learning and deep learning approaches, including graph neural networks and SMILES-based transformers. Molecular docking and molecular dynamics simulations are presented as cooperative tools that boost the mechanistic consideration and structural insight into the ligand-target interactions. Discussions on using PROTACs and targeted protein degradation, ADMET prediction, and public databases and cloud-based platforms to democratize access to computational modeling are well presented with priority. Challenges related to authentication, interpretability, regulatory standards, and ethical concerns are examined, along with emerging patterns in AI-driven drug development. This review is a guideline for using computational models and databases in explainable, data-rich and profound drug discovery pipelines.Keywords: QSAR modeling, artificial intelligence, machine learning, deep learning, molecular docking, molecular dynamics, PROTACs, ADMET prediction, cheminformatics, drug discovery, graph neural networks

## Section: 1. Introduction

Drug discovery is undergoing a significant revolution, driven by integrating artificial intelligence (AI) into Quantitative Structure-Activity Relationship (QSAR) modeling [1,2,3,4]. Until recently, drug discovery was conducted primarily by trial-and-error, an approach that was time-consuming and burdened with high costs; currently, drug development is increasingly shaped by data-driven computational methodologies that should lead to speedier drug discovery and, ultimately, safer drugs as shown in Figure 1. Advances in QSAR have evolved from basic linear models to sophisticated machine learning (ML) and deep learning (DL) frameworks that integrate complex nonlinear patterns across large chemical spaces [1,5,6,7].

QSAR predictive power, when properly combined with AI, can facilitate virtual screening of extensive chemical databases, containing billions of compounds, de novo drug design and lead optimization for specific targets. Algorithms incorporating neural networks, generative models and reinforcement learning are reshaping how compounds are selected, modified, and evaluated for defined targets. Furthermore, integrating omics data, real-world evidence from medicine, and multi-parametric optimization pushes the frontier of personalized medicine and targeted therapeutics [8,9].

This article aims to explore the current trends in AI-augmented QSAR methodologies, highlighting key breakthroughs, and outlining emerging trends that could reshape the future of discovery and development of novel pharmaceutical products, especially with respect to small molecule compounds, such as inhibitors, degraders (PROTACS) and other modalities [9,10]. With the prospects of improving hit-to-lead timelines to designing safer and more effective drugs, the synergy between QSAR and AI is becoming the new foundation in modern drug discovery and development [11]. Recent applications highlight the role of AI-enhanced QSAR in real-world discovery. Talukder et al. integrated docking, QSAR, and simulations to investigate EGFR-targeting phytochemicals in non-small cell lung cancer [12]; Kaur et al. developed BBB-permeable BACE-1 inhibitors for Alzheimer’s disease using 2D-QSAR, docking, ADMET, and MD [13]; Souza et al. combined ML approaches and QSAR to analyze SARS-CoV-2 Mpro inhibitors [14]; and Maliyakkal et al. applied QSAR-driven virtual screening to identify potential therapeutics against Trypanosoma cruzi [15]. These case studies illustrate how QSAR continues to advance modern inhibitor discovery.

Computational approaches significantly accelerate the preclinical stage of drug discovery by reducing costs, minimizing attrition, and expediting the identification of viable candidates. Ou-Yang et al. described how computational pipelines streamline hit-to-lead discovery, reducing reliance on expensive high-throughput screening [16]. More recently, Ouma et al. reviewed modern computational approaches and emphasized their role in decreasing attrition rates and supporting ADMET profiling in early discovery [17]. In parallel, Lavecchia highlighted how virtual screening and QSAR methodologies have become central tools in prioritizing compounds before synthesis, directly cutting down experimental costs [18]. Similarly, Paul et al. demonstrated that computational filtering and optimization strategies reduce the time required to progress leads into the preclinical pipeline, showing tangible benefits in pharmaceutical R&D [19]. These studies collectively demonstrate that computational drug discovery is not only complementary to laboratory methods but also indispensable for modern, cost-effective preclinical development.

Overview of the shift from the trial-and-error methods to the personalized drug design, ranging from the classical approach to the modern AI techniques.

## Section: 2. Foundations of QSAR and Molecular Descriptors

QSAR modeling is dependent on molecular descriptors, which are numerical values that encode various chemical, structural, or physicochemical properties of compounds. The descriptors are generally classified according to dimensions as 1D, 2D and 3D that correspond to the compound’s properties like molecular weight, topological indices and molecular shape or electrostatic potential map, respectively. To increase the model efficiency and reduce overfitting, dimensionality reduction techniques such as principal component analysis (PCA) and recursive feature elimination (RFE) are being highly used [7,20]. The appropriate selection and interpretation of these descriptors are necessary for making predictive, robust QSAR models. There are even more sophisticated methods, including LASSO (Least Absolute Shrinkage and Selection Operator), and mutual information ranking. They are being used frequently to eliminate irrelevant or redundant variables and to identify the most significant features [21,22,23]. These methods not only improve model performance but also enhance interpretability, which is essential for governing approval and hypothesis generation in medicinal chemistry. In addition to 1D, 2D, and 3D descriptors, 4D descriptors have also been developed. These account for conformational flexibility by considering ensembles of molecular structures rather than a single static conformation. Ensemble-based descriptors provide more realistic representations of molecules under physiological conditions and have been applied in ligand-based pharmacophore modeling and QSAR refinement [24,25].

Furthermore, Quantum chemical descriptors like the HOMO-LUMO gap, dipole moment, molecular orbital energies, and electrostatic potential surfaces have also found extensive application in QSAR modeling, particularly for drug-like molecules where electronic properties influence bioactivity [1,9]. The use of 3D descriptors such as molecular surface area, volume, and conformer-based properties has expanded with the availability of tools like DRAGON, PaDEL, and RDKit [26,27,28]. Likewise, the latest integration of deep learning techniques has led to the development of learned molecular representations, or “deep descriptors,” which are derived from molecular graphs or SMILES strings without manual descriptor engineering [29]. These latent embeddings created by graph neural networks (GNNs) or autoencoders are capable of capturing more abstract and hierarchical molecular features, which opens new possibilities for constructing data-driven, flexible QSAR pipelines applicable across diverse chemical spaces [30,31].

## Section: 3. Classical QSAR: Statistical Modeling Techniques

In classical QSAR, the molecular descriptors are correlated with biological activity by statistical regression method. Other traditional but effective approaches used extensively in drug discovery and environmental toxicology includes Multiple Linear Regression (MLR), Partial Least Squares (PLS), and Principal Component Regression (PCR). These approaches are esteemed for their simplicity, speed, and ease of explanation, specifically in governing settings. They are generally practical when a reasonably small number of variables show linear relationships with the biological response. For model validation, internal metrics such as R2 (coefficient of determination) and Q2 (cross-validated R2), as well as external datasets that test the model’s generalizability on unseen compounds, are used. These models while being mostly dependent on assumptions of linearity, normal distribution, and independence among variables, which might not be true in large and chemically varied datasets [7,32,33].

Several efforts have been made over the years to boost the capabilities of classical QSAR models by incorporating robust feature selection and data preprocessing tactics. Several methods, like stepwise regression, bootstrapping, and residual analysis, have been initiated to expand stability and diminish overfitting [34,35]. Nevertheless, these models frequently falter while dealing with extremely nonlinear relationship or noisy data that cannot be modeled with simple parametric equations. Subsequently, hybrid approaches that combine the classical statistical tools with machine learning methods like PLS, combined with decision trees or ensemble averaging, have been developed to narrow this gap when gaining interpretability [11,36]. Despite the upwelling in popularity of complex models like random forests and deep learning, classical QSAR remains obligatory for preliminary screening, mechanism clarification, and when explainability is a greater priority, as in regulatory toxicology and REACH compliance [37]. Additional software packages like QSARINS and Build QSAR endure to support classical model development with enriched validation roadmaps and visualization tools [7,38].

Classical QSAR remains highly relevant in modern drug discovery when combined with rigorous validation. Olenginski et al. applied QSAR to RNA-binding small molecules, uncovering structural determinants of RNA–ligand recognition [39]. Talukder et al. integrated classical QSAR, docking, and simulations to prioritize EGFR-targeting phytochemicals for non-small cell lung cancer [12]. Kaur et al. designed BBB-permeable BACE-1 inhibitors using 2D-QSAR for Alzheimer’s disease, highlighting how traditional QSAR supports lead design [13]. Finally, Cherkasov et al. provided a landmark review demonstrating how classical QSAR principles underpin contemporary drug discovery pipelines [1]. These cases illustrate the enduring value of classical QSAR.

## Section: 4. Machine Learning Rise in QSAR

Machine learning has significantly increased the predictive influence and flexibility of QSAR models, mainly in managing complex, high-dimensional chemical datasets. Algorithms like Support Vector Machines (SVM), Random Forests (RF), and k-Nearest Neighbors (kNN) are the most standard tools in cheminformatics and are widely used for tasks ranging from virtual screening to toxicity projection [40,41,42]. Unlike classical linear models, these algorithms can successfully capture nonlinear relationship between molecular descriptors and biological activity without earlier assumptions about data distribution. Generally, Random Forests are preferred for their robustness, built-in feature selection, and ability to handle noisy data, while SVMs are more efficient in conditions with regulated samples and high descriptor-to-sample ratios [43,44,45]. This is because of the several reasons. RF can manage irrelevant or redundant descriptors because its random feature selection at each split reduces the risk of overfitting to noisy variables, it tolerates collinearity among descriptors, since each tree considers only a subset of variables. and it demonstrates resilience to outliers in bioactivity data, as the ensemble averaging across many trees dampens the effect of anomalous points [46,47]. Grid search and Bayesian optimization are other hyperparameter optimization strategies that are regularly applied to fine-tune these models for top predictive performance.

Modern developments have also focused on boosting interpretability and decreasing the “black-box” nature of machine learning in QSAR. Feature importance ranking methods like permutation importance, SHAP (SHapley Additive exPlanations), and LIME (Local Interpretable Model-agnostic Explanations) now allow researchers to comprehend which descriptors influence model predictions the most [48]. Ensemble learning methods such as stacking, bagging, and boosting have further improved model stability and precision across diverse chemical spaces. These novelties, combined with increasing access to curated datasets and open-source platforms which including scikit-learn, KNIME [49], and AutoQSAR, have democratized machine learning-based QSAR modeling [50]. Despite these encroachments, careful consideration of justification, applicability domain, and dataset bias remains indispensable to evade overfitting and confirm regulatory acceptance, principally in safety-critical domains like pharmacovigilance and environmental hazard prediction [51]. Machine learning has rapidly expanded QSAR capabilities. Singh et al. developed ML-guided QSAR for imidazole scaffolds, achieving strong predictive accuracy even in noisy datasets [42]. Souza et al. combined ML and QSAR to reveal antagonistic trends in SARS-CoV-2 Mpro inhibitors, illustrating ML’s role in antiviral discovery [14]. Maliyakkal et al. performed QSAR-driven virtual screening for Trypanosoma cruzi therapeutics, showing the utility of ML-enhanced QSAR in neglected tropical diseases [15]. Zhang et al. demonstrated the power of ML-based QSAR for kinase inhibitor optimization, highlighting broader applicability across target classes [52]. Together, these studies show how ML augments QSAR with robustness and generalizability

## Section: 5. Deep Learning and Neural Models in Drug Discovery

Deep learning has meaningfully renovated QSAR modeling by empowering automated feature extraction and representation learning right from raw molecular structures. Contrasting traditional models that depend on pre-calculated descriptors, deep learning architectures can generate molecular graphs, SMILES strings, and even 3D conformations to come up with abstract, high-level features relevant to biological activity prediction [9,53,54]. Convolutional Neural Networks (CNNs) have been adapted to operate on molecular grids and images, while Recurrent Neural Networks (RNNs), principally Long Short-Term Memory (LSTM) networks, are compatible with sequential representations like SMILES strings [55,56]. Another emerging field is Graph Neural Networks (GNNs), which have been particularly powerful tools in cheminformatics, as they natively model atoms as nodes and bonds as edges, perfectly reflecting the topology of molecular structures. Other tools like DeepChem [57], Chemprop [58], and DGL-LifeSci have also made these models more straightforward to non-experts [30].

Likewise, another most groundbreaking development in this area is the rise of chemical language models, such as SMILES-based transformers and autoencoders. The models, such as ChemBERTa [59] and MolBERT [60], are trained on millions of chemical structures and can be adjusted for explicit tasks such as activity projection, retrosynthesis, or de novo molecular generation. To propose novel compounds with enhanced activity and ADMET properties, Generative models that include Variational Autoencoders (VAEs) and Generative Adversarial Networks (GANs) are now commonly employed. One example includes REINVENT, which pools reinforcement learning with RNN-based generators to enhance molecules toward a predefined goal iteratively [61]. Deep Learning models in QSAR also encounter issues in interpretability, data disparity, and transferability within distinctive chemical domains. To solve these challenges, several techniques like attention mechanisms, multi-task learning, and data reinforcement approaches are being incorporated into pipelines to refine generalizability and cut overfitting [62,63,64]. Deep learning enables abstraction of complex features beyond the reach of classical QSAR. Li et al. developed DeepPROTACs, a deep learning framework for PROTAC design [65]. Goh et al. pioneered deep learning models for compound–protein interaction prediction, outperforming conventional QSAR [66]. Kim et al. applied SMILES-based deep networks for bioactivity prediction, achieving superior accuracy in chemical space coverage [67]. Altae-Tran et al. demonstrated one-shot learning for drug discovery, highlighting DL’s ability to learn from extremely limited data [68]. These advances underscore how DL reshapes QSAR by capturing nonlinear, high-dimensional representations.

## Section: 6. Molecular Docking and Dynamics

Molecular docking is a powerful tool in drug discovery that simulates the interaction between ligands and target proteins, yielding the binding poses and estimating binding affinities through their scoring functions. It offers a critical first look at how a small molecule might bind to a receptor and is essential for virtual screening, lead identification, and understanding structure-activity interactions. The most commonly used docking platforms include AutoDock Vina (v1.1.2) [69], Glide (2004 release) [70], GOLD (v5.2) [71], and LeDock (2015 release) [72]. Each docking method differs in sampling techniques and scoring algorithms [73], with its binding affinities and pose geometries that can be further incorporated into QSAR models as molecular descriptors for improving predictive performance and interpretability. Besides its popularity and accessibility, it has some discrepancies as it treats receptors as rigid, and scoring functions usually might not completely capture entropic and solvent effects. While rigid docking assumes a fixed receptor structure, most modern approaches employ semi-flexible docking (ligand flexible, receptor side chains partially flexible) or flexible docking (both ligand and receptor sampled). These methods better capture induced-fit effects but also present limitations. First, flexible docking is computationally intensive, often requiring significant resources for conformational sampling. Second, it provides only a limited representation of receptor flexibility, as most algorithms sample a subset of side chains or backbone motions rather than the full conformational landscape. Third, flexible docking can increase the risk of false positives, since greater conformational freedom may allow unrealistic ligand poses without sufficient energetic penalties [73,74]. To address these limitations, flexible docking is frequently combined with molecular dynamics simulations, which provide a more rigorous account of receptor flexibility.

Molecular Dynamics (MD) simulations, which offer atomistic insights into the temporal behavior of protein-ligand complexes in a fully solvated environment, are used to overcome the limitations of docking tools. MD simulations help to determine the structural and conformational dynamics of protein-ligand complexes, which include pose stability, protein flexibility, and significant non-covalent interactions such as hydrogen bonds, salt bridges, van der Waals, and electrostatic interactions, which might be unnoticed in static docking studies. Software packages like GROMACS (v5.x), AMBER (v12/14), NAMD (v2.6) and CHARMM (CHARMM36) are commonly used to simulate biological systems on timescales ranging from nanoseconds to microseconds [75,76,77,78,79]. There are different commercial packages available for easy and fast MD simulations. The simulation results are combined with MM/PBSA or MM/GBSA methods to estimate binding free energies more precisely. The docking and MD are then combined with QSAR or ML/DL frameworks, resulting in the hybrid models that achieve higher performance in predicting binding affinity and action mechanisms [80]. It is widely known that integrating MD-derived features like root-mean-square deviation (RMSD), hydrogen bond analysis, and conformational clustering [81,82,83] can considerably advance both regression and classification outcomes in modern drug discovery pipelines [84,85]. Docking and molecular dynamics (MD) simulations complement QSAR by providing mechanistic insight into ligand–target interactions. Koirala and Fagerquist combined MD with QSAR to probe Colicin–Immunity protein complexes [81]. Lu et al. applied long-timescale MD to GPCRs, revealing conformational states essential for ligand binding [86]. Hollingsworth and Dror reviewed how MD simulations guide drug discovery across multiple protein classes, demonstrating predictive power at atomic resolution [75]. Pagadala et al. provided a comprehensive review of docking applications, emphasizing the strengths and limitations of docking tools in lead optimization [73]. These cases illustrate how docking and MD extend QSAR into structure-based discovery.

## Section: 7. PROTACs and Targeted Protein Degradation

Proteolysis-targeting chimeras (PROTACs) or degraders represent a highly promising therapeutic strategy that goes beyond inhibition by eliminating disease-causing proteins by harnessing the ubiquitin-proteasome system. These bifunctional molecular constructs bind to a target protein and an E3 ubiquitin ligase, concurrently, forming a ternary complex that leads to ubiquitination and subsequent proteolysis of the target protein. This mechanism unlocks potential access to previously “undruggable” proteins and opens new avenues for treating cancer, neurodegenerative diseases, and immune disorder. PROTACs’ development presents several challenges due to the size, flexibility, and reliance on complex protein–protein interactions of these molecular constructs. Indeed, existing drug discovery tools are not very effective at accurately predicting degraders’ pharmacokinetics, efficacy, or degradation behavior [87,88,89].

Most degraders are over 800 Da in molecular weight, display high flexibility, and contain three distinct substructures: a moiety specific to the target protein, a linker, and an E3 ligase binder. This modular structure creates complex, nonlinear relationship between chemical structure and biological activity. Existing QSAR models rely on relatively static structure–activity correlations and thus are not well suited to capture multi-factorial interactions. Descriptors, including LogP, molecular size, and polar surface area (PSA), are insufficient for prediction of critical degrader determinants, such as ternary complex stability, target-E3 ligase cooperativity, linker geometry and flexibility and cell permeability and metabolic stability [90,91,92].

To overcome these shortcomings, the combination of AI and QSAR models is being evaluated and trained to learn from relatively sparse, noisy, and complex, high-dimensional data, to better capture patterns in structure–function relationships of PROTACs, leading to better prediction of degrader constructs, with drug-like attributes, against specific target proteins. This new paradigm in AI-driven QSAR has resulted in novel predictive algorithms, including graph neural networks (GNNs), generative models for linkers, multi-task and transfer learning algorithms and explainable AI [93,94], along with the use of transformers to process molecular representations for high-accuracy predictions of PROTAC behavior [95].

GNNs modeling describes molecules as graphs, with nodes representing atoms and edges representing bonds. This modeling approach can accurately capture the topological and relational information within PROTACs and learn representations directly from molecular structure. Recent publications [96] have reported that GNNs can accurately predict ternary complex formation and degradation potential across multiple E3 ligases. More recently, a 3D graph neuronal network, DegradeMaster is introduced, which utilizes 3D spatial information to further improve PROTAC degradation effectiveness [97,98].

Composition and geometry of linker regions in degrader structures are critical to degrader function, affecting ternary complex formation, solubility and cell permeability, and overall degradation efficiency. Novel AI models like DeLinker [99] and DiffLinker [100] employ deep generative techniques to allow for the design of optimal linkers. These models learn linker patterns from large chemical databases and generate novel candidates based on specific spatial constraints, thus reducing the number of experimental iterations. Deep learning models capable of predicting multiple endpoints, such as degradation efficiency, off-target effects, and ADME properties, offer a comprehensive approach to degrader optimization. Multi-task models leverage shared information across tasks to improve learning efficiency, especially within the limitations of available data [101].

Transfer learning approaches are also obtaining traction; these reuse available knowledge from related drug discovery tasks and apply such knowledge to new conditions. For example, models pretrained on large chemical datasets can be fine-tuned on smaller PROTAC-specific datasets, improving performance on degradation tasks. As degraders enter the clinical space, interpretability becomes crucial. Explainable AI techniques like SHAP (SHapley Additive exPlanations) and attention-based mechanisms allow researchers to identify which molecular substructures or linker properties affect degradation efficiency the most, allowing for feedback to guide in the rational design of degrader structures [102,103,104].

## Section: 8. Predicting ADMET and Toxicity Profiles

A major reason for therapeutic drug failure lies in undesirable Absorption, Distribution, Metabolism, Excretion, and Toxicity (ADMET) properties. Predicting these critical drug properties early in the development process allows for significant de-risking in drug development, reducing costs, and accelerating the delivery of significant therapies. Until recently, ADMET properties have been evaluated through laborious and expensive experimental methods, frequently involving in vitro and in vivo studies. These methods can be resource-intensive, time-consuming, and can be applied to a limited number of compounds. Nevertheless, with new developments in Artificial Intelligence (AI), ADMET drug properties can now be predicted in silico, leading to significant reduction in costs and time, and potential de-risking of drug failure [105,106].

AI, through the combination of machine learning (ML) and deep learning (DL), has emerged as a promising tool in overcoming the ADMET bottleneck in drug development. By leveraging vast datasets of chemical structures and their associated experimental ADMET and toxicity data, AI models can learn complex patterns and make highly accurate predictions of ADMET properties for novel compounds [106,107].

Most ML approaches in ADMET prediction are dependent on algorithms such as Random Forest, Support Vector Machines (SVM) and Gradient Boosting Machines (GBM). These models require cautiously curated datasets of molecular descriptors and associated ADMET characteristics. Otherwise, DL algorithms, especially GNNs, have shown great success. GNNs let the processing of molecular structures as graphs, capturing complex relationships between atoms and bonds, which is vital for understanding the process of molecular interaction with biological systems. GNN-based platforms, when trained on widespread datasets, can provide fast and accurate predictions across a wide range of ADMET properties. Additional methods, such as AutoML, automate the predictive process by choosing the best machine learning algorithms and augmenting their hyperparameters, making AI-driven ADMET prediction more accessible and efficient. Furthermore, newly emerging research focuses on the use of quantum machines in ADMET predictions, promising significant improvement in performance and prediction accuracy [108,109,110,111].

A series of AMET prediction software packages, including both open source and commercial ones, is provided in Table 1 and the list of available databases for training various AI models is provided in Table 2.

List of ADMET prediction software programs.

ADMET databases for AI model training.

## Section: 9. Assessing Model Validity and Reliability

Model endorsement is important in QSAR development because it confirms that predictive models are precise and generalizable. There are several internal validation practices such as leave-one-out (LOO), k-fold cross-validation, and bootstrapping [131] are regularly used to evaluate a model’s stability and validity during training. Internal validation alone is not enough so different external authentication using an independent dataset is crucial to validate that the model performs better on unseen compounds. For this, several Metrics such as the coefficient of determination (R2), cross-validated R2 (Q2), root mean square error (RMSE), and concordance correlation coefficient (CCC) are greatly used to evaluate the performance. OECD guidelines require a model to pass both internal and external validation criteria to be considered predictive [3,132].

Another keystone of QSAR model trustworthiness is the Applicability Domain (AD), the chemical space in which a model can make consistent predictions. There exists several techniques for this, including the leverage approach (Williams plot), distance-based methods (Euclidean or Mahalanobis distance), and ensemble-based probability approximations [133]. ADAN (Applicability Domain Analysis) and other tools like Ambit Discovery and QSAR Toolbox deals with practical applications to consider whether query compounds fall within the domain. In addition, Y-randomization (or response permutation testing) is used to identify chance correlations by randomly shuffling the activity data and rebuilding the model several times. It is expected a valid model should perform implicitly better than the randomized complements. Recently, Monte Carlo sampling, double cross-validation, and consensus modeling have further boosted model robustness and reproducibility [134]. These validation pipelines are specifically important for supervisory approval in fields like environmental toxicology and medicines, where consistency and transparency are principal.

While model validation is an established requirement in QSAR, inadequate or superficial validation often leads to overfitting and misleading performance metrics. Internal validation methods such as k-fold cross-validation, bootstrapping, and Y-randomization assess robustness within the training dataset, but they cannot fully guarantee generalizability [135]. External validation using independent test sets is considered the gold standard, as emphasized by Tropsha and Golbraikh [136]. Moreover, the OECD principles for QSAR validation recommend defining the applicability domain (AD), which delineates the chemical space where predictions are reliable [137]. To mitigate failure cases, best practices include combining internal and external validation, applying consensus modeling, and benchmarking against well-curated datasets. Practical adoption of these recommendations can reduce model overestimation and enhance regulatory acceptance.

Despite significant progress, ML and DL approaches face critical limitations. ML methods, though robust against noise, often struggle with interpretability and may overfit in small datasets. DL models, while powerful in capturing nonlinear renonlinears, typically require large, high-quality datasets and are vulnerable to bias from imbalanced training data [138]. Furthermore, most reported QSAR successes underrepresent negative results, limiting awareness of failure cases [139]. Addressing these challenges requires transparent reporting, model explainability, and rigorous external validation.

## Section: 10. Software, Databases and Computational Platforms

With the growth of computational resources and several AI tool, many platforms now play a vital role in the rationalization of computational drug discovery pipelines, especially in QSAR modeling as presented in Table 3. RDKit (2019 release) [28], is a very popular open-source cheminformatics toolkit in Python and is being extensively used for calculating molecular descriptors, generating molecular fingerprints, and performing structure-based filtering. Similarly, PaDEL-Descriptor (2011 release) [27] is another widely used tool for computing more than 1,400 descriptors and fingerprints, making it suitable for both academic and industrial workflows. KNIME (2015 release) [49], is a very popular graphical workflow-based analytics platform that permits users to build and automate modeling pipelines by drag-and-drop components which later integrates the tools for data preprocessing, machine learning, and molecular descriptor generation [140,141].

DeepChem (2018 release) [57] and Chemprop (2019 release) [58] are other Deep Learning and graphical based approach that has become increasingly admired. DeepChem use real executions of deep neural networks, graph convolutional networks (GCNs), and multitask learning frameworks custom-made for molecular property prediction. In contrast, Chemprop (2019 release) built with PyTorch (release 2017), is adjusted for message passing neural networks and is predominantly operative for structure-activity relationship tasks using SMILES strings [30]. There are several public databases like ChEMBL2017 release) [142], ZINC (2012 release) [143], and PubChem (2004/2006 release) [144] that provide broad curated chemical and bioactivity data, empowering large-scale QSAR and machine learning studies [145]. These are complemented by different cloud-based resources like Google Colab (2018 release) [57] and AWS SageMaker (2017 release) [146] that makes it possible to run QSAR workflows at scale without demanding local hardware. On the other hand, cheminformatics incorporation with cloud-based notebooks accelerates reproducible investigation and easy distribution of computational pipelines, profoundly decreasing the barrier to entry for scholars all over the world [147].

Computational Tools and Their Applications in QSAR-Based Drug Discovery.

## Section: 11. Challenges, Ethical Considerations and Regulatory Aspects

AI-driven drug discovery and development represent a promising platform for accelerating the development of new medicines; at the same time, such technology brings significant challenges, ethical considerations, and evolving regulatory aspects that must be carefully navigated [148,149]. Among the many challenges, key issues are data quality and availability. AI models require extensive data for model training; furthermore, these data must be of high quality. In the drug discovery space, the availability of large amounts of quality, that is comprehensive and unbiased data from various sources, is a major hurdle. Frequently the available datasets can be incomplete, noisy or proprietary, making it difficult to integrate and use effectively for properly training AI-models. AI models trained on narrowly defined datasets will likely not have much utility as minor variations in training parameters or input data can lead to different outputs, raising concerns about reproducibility and reliability. Additionally, certain data, especially for pharmacokinetic and toxicity analysis, may be biased toward particular chemical scaffolds or patient demographics, limiting model generalization.

Modeling complex biological systems to determine how a drug will interact with such systems presents major challenges; indeed, modeling even simpler systems, such as cellular structures, can be overwhelming given the complex interrelations between the cellular components and the dynamic nature of these systems. Commercially, the employment of AI in drug discovery requires considerable investment in advanced computational hardware and software, infrastructure, and skilled workforce with proficiency in both AI/machine learning and pharmaceutical sciences. Such investments can be a barrier for smaller companies or research institutions. Furthermore, the integration of AI technology into existing drug discovery and development pipelines and workflows within pharmaceutical organizations can present significant integration challenges and, potentially, low adoption.

From ethical considerations, AI models trained on biased data can perpetuate and even reinforce existing disparities in healthcare. If datasets are not representative of diverse patient populations, the AI’s predictions may lead to inequitable outcomes in drug efficacy and safety for underrepresented groups. The use of patient-level data, including genomic, electronic health record data, and clinical trial data for AI training must be governed by strict privacy protections and ethical standards of informed consent to prevent re-identification of anonymized data, data breaches, or unauthorized secondary use of the data.

The nature of some AI models raises ethical concerns regarding accountability. If an AI-driven drug leads to adverse outcomes, it can be challenging to pinpoint the exact reasons for the AI’s decision, making it difficult to allocate responsibility. Likewise, when AI systems are used to lead therapeutic decisions or impact clinical trial designs, questions of accountability arise; therefore, inventors must ensure traceability of model inputs, outputs, and decision logic. The regulatory landscape as it applies to the use of AI in drug development is as challenging as the ethical issues discussed above. Meanwhile, regulatory bodies worldwide, such as the FDA (US) and EMA (Europe), are working to develop appropriate guidelines for AI-driven drug development [150]. This is a rapidly evolving and changing area, and companies face the challenge of complying with frameworks that are still conceptual in some respects and, at best, partially defined.

Regulatory agencies are increasingly incorporating AI and QSAR into safety assessment. While still in the very early stages, both FDA and EMA currently accept QSAR assessments under ICH M7(R2) for the identification and control of DNA-reactive impurities [151]. Additionally, the FDA’s Center for Drug Evaluation and Research (CDER) has partnered with the National Center for Toxicological Research (NCTR) through the ‘SafetAI Initiative’ to develop and validate AI-based QSAR models for predicting key safety endpoints, including hepatotoxicity, carcinogenicity, and cardiotoxicity [152]. This effort not only strengthens internal expertise but also establishes standards against which industry submissions can be evaluated.

Interpretability remains a regulatory priority. Approaches such as SHAP (Shapley Additive Explanations) have been successfully applied to QSAR toxicity models, where they highlight the molecular substructures most responsible for predictions, thereby improving transparency and confidence in model use [153,154]. These developments indicate a convergence between regulatory acceptance and explainable AI, supporting safer integration of AI-enhanced QSAR into decision-making.

When utilizing AI Models to support regulatory submissions, regulatory agencies invariably require robust validation and verification of AI models that facilitate regulatory decision-making, especially in relation to drug safety, effectiveness, and quality. Regulatory requirements will necessitate demonstration of data integrity and traceability, and verifiable model performance. Additionally, regulatory submission, relying on any AI-driven decisions, will require that such AI models be extensively validated using external datasets and benchmarked against established clinical standards and must contain documentation details on data source, preprocessing, model architecture, and performance metrics. Regulatory agencies are likely to shift towards a risk-based approach, where the level of scrutiny for an AI model depends on its “context of use” (COU) and the potential risk associated with its output. Eventually, data used to train AI models must be “fit for use,” meaning that the data must be applicable, reliable, and of sufficient quality to support the intended regulatory purpose. Furthermore, regulators are going to demand a greater need for transparency and explainability in AI models, especially those impacting on critical regulatory decisions.

For continuous learning AI models that adapt over time (“self-evolving”), regulatory agencies will be faced with ensuring ongoing model validation and monitoring to prevent “model drift,” such that the model’s performance does not degrade or become unreliable. For situations in which AI is being used in pharmacovigilance to identify adverse drug events and safety signals from large datasets. Regulators should make sure that the AI model used in this crucial post-marketing phase is precise and real. Correspondingly, if AI is applied in patient stratification, simulation of trial outcomes, and identification of relevant biomarkers, it is important that such applications do not introduce bias or compromise statistical integrity.

## Section: 12. Conclusions

The future direction of AI in drug development will be characterized by several key trends and advancements. Firstly, AI will continue to revolutionize the early stages of drug development through the use and analysis of vast datasets, including genomics, proteomics and clinical studies to efficiently identify and validate promising drug targets. This process will allow drug developers to focus and manage resources on the most relevant proteins and molecules involved in disease pathways. Additionally, generative AI and deep learning models, including variational autoencoders, generative adversarial networks and large language models, will become even more sophisticated, especially with appropriate training, in the design of novel compounds with drug-like properties, predicting molecular interactions, and optimizing chemical structures to improve efficacy, simulating biological responses and reducing off-target interactions and side effects, thus minimizing toxicity.

AI will also be deployed for the rapid identification of existing drugs that can be repurposed for new indications; therefore, shortening the development timeline relative to the discovery and development of entirely new compounds and also proposing potential synergistic drug combinations.

AI will play a more dominant role in clinical trial design by analyzing historical data, resulting in ideal trial protocols, optimal endpoints, and timelines [155]. It will be used to simulate trial scenarios and allow for fine-tuning of dosage and treatment duration. AI algorithms will be used to analyze available medical data to determine suitable patient candidates for clinical trials and ensure more diverse and representative cohorts. The use of AI in trial design and management will enable real-time modifications to trials, allowing adjustments to dosages or patient cohorts based on interim results, increasing efficiency and supporting decentralized clinical trials. Furthermore, AI algorithms will enable better patient stratification via the analysis of genomic, proteomic, and clinical data, allowing for targeted treatments and personalized medicine approaches and even predicting individual patient responses to specific therapies for customized treatment plans for optimal outcomes.

To conclude, we presented the use of QSAR modeling with artificial intelligence, molecular docking, and molecular dynamics simulations that have meaningfully upgraded the field of computational drug discovery. Classical regression methods, which remain foundational, are now being conveyed by robust machine learning and deep learning approaches proficient in seizing complex, nonlinear hips in chemical data. While rigorous validation practices continue to ensure their scientific and regulatory credibility, the implementation of cloud-based platforms and open-source tools has made these technologies more accessible. As the field progresses, the conjunction of data-driven methods with mechanistic modeling may be the key to building more robust, reliable, and ethical drug discovery pipelines.

## Section: Abbreviations

QSAR, Quantitative Structure–Activity Relationship; QSPR, Quantitative Structure–Property Relationship; AI, Artificial Intelligence; ML, Machine Learning; DL, Deep Learning; MD, Molecular Dynamics; CNN, Convolutional Neural Network; RNN, Recurrent Neural Network; GNN, Graph Neural Network; GCN, Graph Convolutional Network; SVM, Support Vector Machine; RF, Random Forest; kNN, k-Nearest Neighbors; PLS, Partial Least Squares; MLR, Multiple Linear Regression; PCR, Principal Component Regression; PCA, Principal Component Analysis; RFE, Recursive Feature Elimination; RMSE, Root Mean Square Error; RMSD, Root Mean Square Deviation; LOO, Leave-One-Out; AD, Applicability Domain; ADAN, Applicability Domain Analysis; SHAP, SHapley Additive exPlanations; LIME, Local Interpretable Model-agnostic Explanations; HOMO, Highest Occupied Molecular Orbital; LUMO, Lowest Unoccupied Molecular Orbital; SMILES, Simplified Molecular Input Line Entry System; GANs, Generative Adversarial Networks; VAEs, Variational Autoencoders; PROTAC, PROteolysis Targeting Chimera; ADMET, Absorption, Distribution, Metabolism, Excretion, and Toxicity; GBSA, Generalized Born Surface Area; MM/PBSA, Molecular Mechanics/Poisson–Boltzmann Surface Area; OECD, Organisation for Economic Co-operation and Development; FDA, Food and Drug Administration; EMA, European Medicines Agency; REACH, Registration, Evaluation, Authorisation and Restriction of Chemicals; KNIME, Konstanz Information Miner; CHARMM, Chemistry at HARvard Macromolecular Mechanics; GROMACS, GROningen MAchine for Chemical Simulations; NAMD, Nanoscale Molecular Dynamics.

## Section: Author Contributions

M.K. and M.D. jointly wrote the manuscript and revised it; L.Y. and Z.M. cross-checked the content and performed proofreading. All authors have read and agreed to the published version of the manuscript.

## Section: Data Availability Statement

No new data were created or analyzed in this study. Data sharing is not applicable to this article.

## Section: Conflicts of Interest

Mahesh Koirala is a consultant at Therabene Inc., serving as a Computational Chemistry Scientist. Lindy Yan, Zoser Mohamed and Mario DiPaola are employees and shareholders of Therabene, Inc.

## Section: Correction Statement

This article has been republished with a minor correction to the Data Availability Statement and Reference 94. This change does not affect the scientific content of the article.

## Section: Funding Statement

This research received no external funding.

## Section: Associated Data › Data Availability Statement

No new data were created or analyzed in this study. Data sharing is not applicable to this article.


---

# Aligning with regulatory agencies for the use of digital health technologies in drug development: a case study from Parkinson's disease

- **Authors:** Derek L Hill, Camile Carroll, Ramona Belfiore-Oshan, Diane Stephenson
- **Issuer:** Frontiers in digital health
- **Type:** Scientific article
- **Published:** 2025-10-23
- **Language:** en
- **DOI:** 10.3389/fdgth.2025.1415202
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41208852/
- **Licence:** CC-BY

## Section: Abstract

Digital Health Technologies (DHTs) have been under investigation for many years as innovative tools for Parkinson's disease motor symptoms given their inherent high-frequency, sensitive, and objective measurement properties. DHTs used in drug development, can be defined as Drug Development Tools (DDT), though some DHTs may also be categorized as medical devices. The recent rapid increase in use of DHTs in clinical trials has been accompanied by a rapidly evolving regulatory landscape, resulting in a challenging environment for widespread implementation of DHTs in applications that will provide clear impact on pharmaceutical company drug development pipelines. Parkinson's disease represents a disease of escalating burden with high unmet need for therapies that are disease modifying. Early intervention is a key area of focus, yet the heterogeneity of symptoms and lack of biomarkers poses challenges for drug development. Furthermore, the technologies and device platforms, both hardware and software, are rapidly evolving, and the companies developing the underlying devices frequently have objectives and timelines that may not align with those of the pharmaceutical industry. DHTs therefore have a unique set of challenges in terms of devising meaningful measures, standardization of data collected, responding to evolving regulatory expectations, and ensuring alignment across stakeholders. There is a growing need for new models of collaboration to bring together diverse stakeholders required to achieve regulatory endorsement of DHTs for use as DDTs. Collaborations between stakeholders working on DHTs need to be firmly anchored in the regulatory ecosystem as many regulatory challenges in DHTs have parallels in other technologies. Furthermore, there is an especially urgent need to define the pre-competitive space in which DHT data can be shared, data collection standards devised, and novel analysis approaches that are robust to residual variability developed. Critical Path for Parkinson's Consortium's (CPP) Digital Drug Development Tool (3DT) initiative is highlighted as a case example to illustrate how pre-competitive public private partnerships can advance the regulatory maturity of digital health technology measures for use in clinical trials.

## Section: Introduction

Digital Health Technologies (DHTs) used as Drug Development tools (DDTs) represent an important example of a regulated technology to support medical product development. These technologies have the potential to meet pharmaceutical industry needs for high frequency, sensitive, and objective measures of a patient's disease progression, and a patient's response to treatment in real-world settings (1).

DHTs have attracted particular interest in chronic progressive diseases of the nervous system (2). This is due to the heterogenous nature of symptoms, slow insidious onset of symptoms with long duration of presymptomatic underlying disease, and lack of patient centered measures that can be used to define true impact of novel therapies on patient's quality of life.

DHT measures may therefore accelerate the development of new drug and biological therapies in areas of unmet medical need and enable these treatments to be better focused on treating the aspect(s) of disease of most importance to patients.

DHTs, when used to support drug development, sit at the interface between medicine and device regulations. The applicable regulatory landscape is rapidly evolving including across regulatory authorities. Here we make use of terminology from the FDA's recent guidance document on Digital Health Technologies for Remote Data Acquisition (3), and limit our discussion to DHTs that incorporate sensors (e.g., motion sensors). We use the term “DHT measure” to mean the output of a DHT used as a drug development tool, and “DHT Device” for the data collection device e.g., wearable sensor from which the DHT measure is obtained or derived.

In this paper, we describe the work of Critical Path Institute's (C-Path) Critical Path for Parkinson's (CPP) Digital Drug Development Tools (3DT) initiative to collect evidence that DHTs can reliably and accurately measure PD progression at early stages in drug naïve patients over one year duration, in order to advance the regulatory maturity of DHTs for assessing patients with Parkinson's disease (PD). CPP is a public private partnership focused on the development of drug development tools targeting early stages of the disease. The key milestones for DHTs being used as DDTs are (a) letter of support and (b) qualification. A letter of support is issued by the medicines regulator to describes the regulator's thoughts on the potential value of a DDT and encourages further evaluation. A DDT qualification is a public regulatory opinion that encourages the use of a qualified DDT for a specific context of use to expedite drug development and review of regulatory applications.

The regulatory landscape for DHTs has been evolving significantly since CPP was launched in 2015 (4): there has been a rapid increase in the response of regulators to the needs of DHTs and their use in drug development. Regulatory agencies have published several guidance and discussion documents focused on DHTs and with some DHT measures reaching a high level of maturity with certain regulators. This regulatory framework enables DHTs to be used on a protocol-specific basis, or to be qualified for more general application in a context of use. Many DHT measures are generated using machine learning (ML) and artificial intelligence (AI), which means they may be impacted by AI-specific regulations being proposed in several jurisdictions, including the European Union AI Act (5).

Table 1 shows the timeline for advances in the regulatory landscape over the past several years both in U.S. and Europe, with key regulatory publications from the U.S. Food and Drug Administration (FDA) and European Medicines Agency (EMA) highlighted. Although primarily focused on regulation of medicinal products, we include cybersecurity guidance documents focused on medical devices generally relevant to all DHTs, whether medical devices or not. Notably, the FDA's March 2024 “AI & Medical Products” guidance specifically describes how medicines and device regulators are working together in this rapidly evolving area.

Recent key regulatory guidance and frameworks relevant to DHTs. The majority are published by medicines regulators though cybersecurity guidance documents published by medical device regulators are also included.

## Section: Unique challenges of DHTs

Regulators have made much progress in provision of guidance for DHTs in drug development, though the impact of DHTs in clinical trials has so far been limited; for example, no drug has yet been approved by the FDA based on a DHT derived primary endpoint (6) and the EMA has recently described regulatory experience with DHTs in the context of registrational studies as minimal (7). Issues relate to the rapid rate of innovation in digital technologies, the types of companies in the ecosystem, and the intersection between regulations related to clinical trials, medical devices, and data protection/privacy.

## Section: Unique challenges of DHTs › Rapid rate of innovation

The rapid rate of innovation in the technologies incorporated in DHTs (e.g., sensors, ML algorithms, connected devices) means that the product lifecycle of a DHT is often a small number of years. A DHT may rely on consumer computing platforms such as smartphones. The lifetime of DHT devices, and sometimes even digital companies, is short compared to the timescale of drug development. It is therefore hard for DHTs to “travel with a molecule” from phase I to approval, which might be a period of more than 10 years. Even if a particular hardware remains stable, the installed software might periodically upgrade in ways that make the data non-comparable.

## Section: Unique challenges of DHTs › Standardization and harmonization

A consequence of the rapid rate of innovation in the hardware, software and measurements from DHTs is the need to obtain comparable data across time and studies. The diversity in technologies available, the speed of innovation, including software upgrades and new versions of hardware, and the proprietary nature of some algorithms means that obtaining comparable data is a considerable challenge.

One state-of-the-art approach in this area has been described by the Mobilise-D consortium (8), in which multiple types of motion sensors have been compared against a gold standard in a laboratory setting. This highlighted considerable remaining challenges in standardizing DHT data even from accelerometers, which are arguably the most mature of DHT sensor technology. The authors suggest guidelines to assist standardization efforts for future studies.

Parallels have previously been drawn between DHTs and imaging. Putting in place suitable standardization has been important in the development of neuroimaging in clinical trials (9, 10) and is a focus of the FDA guidance on imaging endpoints in clinical trials (11). It is important to note that, while there are parallels with imaging, DHTs are used for remote data acquisition (e.g., in the home) and there is considerable additional variability compared to that of the in-clinic controlled environment applicable to imaging. This puts additional requirements on the standardization of DHTs that allow for bridging in-clinic with at-home measurements. Standardization of a particular DHT measure, therefore, should consider implications of hardware, software, and measurement environment. The experience of standardizing imaging endpoints encourages the standardization to be done in the context of a specific measurement such as hippocampal volume (12) or Positron Emission Tomography standardized uptake value (PET SUV) (10), and for measurements obtained from diverse scanners (sometimes with contrast or tracers) and algorithms to be compared in terms of effect size in a relevant comparison e.g., separating diseased from normal or progressing from non-progressing subjects (13, 14). Once a measurement is clearly defined, the standardization task is easier to specify. The lack of consensus on specific DHT measures has been a barrier to progress in this measurement-driven standardization. Because some DHT devices can generate multiple possible DHT-derived measures (for example the output from a wrist-worn accelerometer could be used to calculate measures of gait, tremor or sleep), the appropriate standardization and algorithm validation should be measure rather than device specific.

## Section: Unique challenges of DHTs › Business models and data protection and privacy

Technology companies, whether focused on digital health or consumer tech, frequently have business models that involve monetizing data (15). Sophisticated consumer hardware and software used by individuals is provided at low cost (and for software, often free) in exchange for the user agreeing to transfer their data to the tech company and give ownership, or at least wide-ranging rights to use it for commercial purposes. The huge volumes of data thus acquired by the tech companies can be used to improve the product, but also can be sold freely, so an individual's data may be used by unknown third parties for purposes that were neither pre-defined nor specifically consented to by the user. These data-centric business models are potentially incompatible with the desire of pharmaceutical companies, healthcare providers, and regulators to ensure that patient data is carefully controlled and only used for pre-specified purposes with informed consent.

## Section: Unique challenges of DHTs › Intersection between different regulatory systems

A further challenge relates to DHTs operating at the interface between different regulatory frameworks. Many DHT devices (e.g., smartphones and smartwatches with fitness apps and activity trackers) are designed for consumer use and have limited regulatory oversight. A sub-set of DHT devices are either medical devices or contain software components that are “software as a medical device”. Use of any of these DHT devices in clinical trials adds new regulatory requirements around validation of computer systems that come from Good Clinical Practice (GCP) (16) (21CFR11 in USA, Annex 11 of the Clinical Trial Regulation in Europe). The EMA has made clear in recent publications that GCP regulations around validation and audit trail apply to mass market wearables and mobile phones (17). Some digital health companies struggle to put in place systems that are compliant with these requirements and do not see a business case for achieving compliance, given the small size of the clinical trial market for most of these companies.

The need for different models of data use, and the requirements of validation and audit trail, mean that commercial collaborations between the pharmaceutical and tech sectors can be challenging.

This further emphasizes that for DHTs to have a significant impact on the development of new treatments, new models of collaboration are needed. There is also a need to acknowledge that the price point of the technologies used in clinical trials is likely to be significantly higher than the prices that end-users are used to for consumer digital technologies.

## Section: The need for new models of collaboration to develop DHTs

In recent years, there has been significant optimism that “digital” technologies could rapidly impact drug development, and as a result, relevant industry and public organizations are investing in DHTs across various therapeutic areas. There has been an associated rapid increase in the number of clinical studies incorporating DHTs (2), particularly in chronic progressive disorders of the nervous system where the failure rate is high and there is a lack of sensitive, clinically meaningful DDTs. The application of DHTs to disorders of the nervous system is growing at a rapid rate with Parkinson's being most prominent of all (Evidence from https://www.ClinicalTrials.gov on the growth of Digital Health Technologies in neurology trials (2).

It is increasingly clear that while DHTs have great potential to positively impact drug development, the timescale of their development has not proved to be rapid in comparison to other technologies such as imaging, and at the date of writing, we have not yet seen any new drugs approved based on a DHT measurement. One DHT measure that has achieved the regulatory milestone of being qualified as a primary endpoint in Duchenne muscular dystrophy (DMD) by the EMA is the Stride Velocity 95th centile (SV95C) (18). This effort took more than a decade (19) to complete, which is not indicative of the minimum (or maximum) time required but illustrates the challenges of navigating the regulatory environment for DHTs. While most recent DMD studies have included SV95C as a secondary outcome (NCT05524883, NCT05096221, NCT06138639, NCT05982119, NCT04906460), the use of this measure has been explored for other neuromuscular diseases including Spinal Muscular Atrophy, Facioscapulohumeral muscular dystrophy, and Limb Girdle muscular dystrophy. However, it is still unclear how the learnings from the DMD qualification will be applied or whether they are fully translatable to those other diseases (20).

Many pharmaceutical companies and research institutions have been independently working on developing DHT measures, which has resulted in an explosion of proposed approaches to measuring concepts of interest such as gait (21). It is becoming increasingly clear that the challenges are too big to overcome as individual companies and organizations alone, necessitating a collaborative and harmonized approach. Increasingly, pharmaceutical companies are looking for a clear impact on their drug development programs and adapting their investment in DHTs accordingly. A consortium-based approach is therefore desirable and aligns with regulatory agency recommendations for public-private partnerships to increase their efficiency in advancing DHTs (22, 23). Some industry-led consortia have sought to develop high-impact DHT measures that are disease-agnostic or are cross-disease digital endpoints in areas such as fatigue, sleep (24), and mobility (21). Regulators, however, have consistently communicated that, just as for other (non-digital) technologies, data should be submitted for a single disease and context of use (COU).

It is therefore increasingly important that, for reasons of cost effectiveness and rate of progress, development of DHTs is undertaken collaboratively rather than in isolation, and anchored within organizations that have wide-ranging experience in development of non-DHT DDTs. Some of the DHT challenges identified above could be addressed by means of collaborative data analysis platforms such as federated learning.

## Section: The evolving DHT regulatory landscape

While DHTs have been used in clinical research for decades (25), there has been significant increase in use over the last 5 years particularly post-COVID-19 pandemic, and a rapid evolution in the regulatory landscape for DHTs as DDTs. In particular, there are recent regulatory publications specific to DHTs (3, 26) and those that can apply to DHTs including those on patient-focused drug development, use of AI in devices (27), drug development (28), and validation of computer systems (17).

Industry has proposed the use of DHTs for several applications in drug development that span a variety of different intended uses to enhance decision making in clinical trials, not only as digital endpoints (29). DHTs have potential to be used for advancing novel candidate therapies at all stages of drug development including patient subgroup characterization, optimizing trial design, patient identification and recruitment, risk assessment and adverse event prevention, remote interventions to enable decentralized clinical trials, externally controlled trials, and label indication expansion.

Up until 5 years ago, it was common to refer to all DHT measures as “digital biomarkers”. However, the DHT measures can be used for multiple purposes to support drug development, and as such, the use of DHTs might meet either the definition of a biomarker or of a clinical outcome assessment (30): •Digital Biomarker: “a characteristic or set of characteristics, collected from digital health technologies, that is measured as an indicator of normal biological processes, pathogenic processes, or responses to an exposure or intervention, including therapeutic interventions.” (31)•Clinical outcome assessment (COA): an assessment of how someone feels, functions, or survives (32).For some DHT measures, this distinction remains a matter of debate (33). For example, it is possible to argue that change in a measure of gait due to progression or treatment of PD is both “an indicator of a pathogenic process or biological response” and that it is an “assessment of how someone feels or functions”. This distinction has practical applications. For a “biomarker”, the sensitivity of the measure to the pathogenic process or biological response is the priority, with the goal of achieving a larger effect size and hence needing fewer participants and/or less time for a clinical trial for a new medicine, in which demonstration of drug efficacy is the objective. For COA, however, clinical meaningfulness is the priority, and a sensitive measure that is not meaningful to the participant or their physician would be considered inappropriate in a trial in which the objective is demonstration of clinical effectiveness. This has implications for the types of data needed to advance the regulatory maturity of DHTs. The next section discusses the regulatory focus on patient-focused drug development, which is of great relevance to the use of DHTs for COAs.

## Section: The evolving DHT regulatory landscape › Patient-focused drug development

Medicines regulators have an increasing focus on ensuring that data collected during clinical trials of new medicines takes account of the patients' voice. The FDA's recent series of guidance documents on patient-focused drug development (34–37) refer to DHTs in various places, and it is clear that regulators will treat many DHT measures as a type of Clinical Outcome Assessment (COA). The implication for the use of DHTs in clinical trials is that regulators want to see evidence that the DHT measure is relevant to a meaningful aspect of health for the patient. For example, accelerometers have become ubiquitous for tracking activity in smartphones and smartwatches. There are established ways of calculating “activity metrics” from this acceleration data, e.g., step count, cadence and amount of vigorous activity, and many novel motion-sensor-derived measures can be developed using machine learning and artificial intelligence. The focus on meaningfulness of DHT measures means that it is necessary to show that the DHT measure can be linked to a concept of interest relevant to the condition, and a meaningful aspect of patient health. This approach is being followed by consortia working in some disease areas e.g., nocturnal scratch (38). This linkage between DHT measure and meaningful aspects of health needs to be shown for each clinical condition, and regulatory agencies have similar expectations as to data required for drug development tools such as biomarkers and COAs (e.g., both observational and clinical trial data to support a defined COU).

Regulators are using the term “fit for purpose” to describe when a DHT measure is ready for use in a clinical investigation, and they make clear that a DHT measure has to be validated for a single COU,: it is considered fit-for-purpose when “the level of validation associated with a medical product development tool is sufficient to support its context of use” (30).

Whether a DHT is fit for purpose is determined by the strength of the evidence in support of interpreting the DHT measure as reflecting the concept of interest within the COU. Fit-for-purpose in the regulatory context means the same thing as valid within modern validity theory, e.g., validity is “the degree to which evidence and theory support the interpretations of test scores for proposed uses of tests” (39).

## Section: The evolving DHT regulatory landscape › FDA digital health technology guidance/framework

In 2021, the FDA published a draft guidance, “Digital Health Technologies for Remote Data Acquisition in Clinical Investigations” (40), and subsequently published a framework document that seeks to explain how DHTs fit into FDA's thinking (26); a final version of the DHT guidance was published in December 2023 (3). Key implications of this guidance are that the initial step in choosing an appropriate DHT is to “consider the clinical event or characteristic of the disease or condition of interest that is to be measured, identify appropriate technical and performance specifications of a DHT, and consider the proposed trial population”. In practice, very often innovation in DHTs has started with available DHT devices (e.g., wrist-worn accelerometers) and sought to derive from this DHT device a DHT measure that meets a drug development need. This guidance further emphasizes the need to clearly define a rationale for the selection of a particular DHT for a context of use, the need for appropriate verification, validation, usability assessment, and the consideration of risks, including confounds (they give the example of false positive detection of tremor in PD from a person traveling in a car on a bumpy road). In the framework published, the FDA acknowledged that it needs to adapt internally to be able to properly consider DHTs and provide sponsors with consistent feedback between review divisions.

## Section: The evolving DHT regulatory landscape › Machine learning and AI in drug development

Many DHT measures are calculated using machine learning (ML) or artificial intelligence (AI). Developers and users of DHTs therefore need to take account of the evolving regulatory landscape for AI. This is an area of rapid evolution in regulatory thinking and a potentially significant divergence between jurisdictions. The FDA has recently published a discussion paper “Using Artificial Intelligence and Machine Learning in the Development of Drug and Biological Products” (28), which is relevant to DHTs. Of particular relevance is the need to manage risk that arises from use of ML/AI models, which the regulators argue can be distinct from risk in traditional rules-based software. These risks include data quality risks, bias risks (e.g., selection bias, confounding variables), and data security and privacy risks (41).

## Section: The evolving DHT regulatory landscape › Recent DHT regulatory milestones

As of August 2025 there are a total of two letters of support and two full qualification opinions from the EMA on the use of DHTs as drug development tools as digital endpoints. The FDA manages a public website (41) showing it has accepted multiple digital endpoints into the COA qualification program for a range of conditions including DMD, Multiple Sclerosis (MS), chronic heart failure, sarcopenia and atopic dermatitis. By reviewing the Agency feedback provided in each case example there are common issues to be addressed even though the specific indication may be different (42). Sharing of such knowledge and learnings promises to catalyze progress and avoid redundancies and inefficiencies.

## Section: Critical path institute's 3DT initiative

C-Path is a not-for-profit organization that has nearly two decades of experience leading public-private partnerships spanning multiple diseases to advance regulatory maturity of drug development tools (Table 2) across several neurological disorders including Alzheimer's disease (AD), PD, and DMD. C-Path-led consortia have achieved regulatory milestones from full qualification opinions to Letters of Support and Fit for Purpose FDA and EMA endorsements (43).

The 3DT initiative in Parkinson's disease was launched in 2018 under the auspices of the established global consortium, CPP, as a data-driven collaborative path to share knowledge and resources. The vision of 3DT is to advance the regulatory maturity of DHTs as drug development tools for decision-making in PD trials targeting early Parkinson's disease.

CPP's 3DT initiative has provided a data-driven framework for multiple sponsors who have agreed to collaborate on optimizing the use of DHTs in PD drug development. The 3DT consortium involves sharing of patient-level digital device data (including raw data) with members. The 3DT consortium has maintained regular interaction with medicines regulators, including a Critical Path Innovation Meeting (CPIM) held with the FDA and an Innovation Task Force (ITF) meeting with EMA, both in 2019. Regular additional interactions include with FDA staff members regularly attending monthly consortium meetings, thereby providing an ongoing regulatory dialogue. These interactions with regulators have highlighted several challenges facing the field, including the need for strategies for establishing meaningful clinical endpoints, controlling sources of variability, and evaluating DHT performance in normative as well as diseased cohorts.

A key focus of CPP 3DT is the observational study WATCH-PD (Wearable Assessment in the Clinic and at Home in PD) (NCT03681015) which is focused on an early de novo PD target population. This study evaluates the ability of research-grade wearable sensors, a smartwatch and a smartphone to assess key features of PD, using a platform that maps directly onto the MDS-UPDRS. WATCH-PD aims to determine the specific disease features these digital tools can detect, whether the measures differed between individuals with early PD and age-matched controls, and how well the digital measures correlated with traditional ones (44, 45). The CPIM and ITF meetings in 2019 provided regulatory feedback that was used to refine the Watch-PD protocol, adding a normal control arm, and including more rigorous qualitative evaluation of the meaningfulness of the DHT measures to study participants, illustrating the value of early interaction with regulators. CPP recognizes that WATCH-PD is a single study that is noninterventional and has limitations.

Critical path institute (C-path) regulatory milestones to date.

Key components of C-path's CPP 3DT.

## Section: Critical path institute's 3DT initiative › 3DT progress to date

3DT has brought together a group of leading industry partners, academic key opinion leaders, patient advocacy organizations, and people living with PD from around the world.

The key components and milestones in the phases of 3DT are shown in Table 3.

Key components of C-path's CPP 3DT.

## Section: Discussions and conclusions

There is an evolving regulatory landscape for Digital Health Technologies as drug development tools, with multiple stakeholders independently approaching regulatory agencies for endorsement. Experience of many parallel initiatives approaching regulatory agencies to date suggests that navigating the regulatory path to enable DHTs to have a significant impact on drug development and defining success in addressing drug development needs remain challenging. The experiences of the 3DT consortium highlight the value of collaborative approaches involving pharma industry and academic experts, leveraging Critical Path Institute's experience of advancing the regulatory maturity of a diverse range of drug development tools, from Patient Reported Outcomes (PROs) to imaging biomarkers (46). Tackling challenges collectively by advancing data-driven solutions and sharing costs and risks, as well as embracing open science, can avoid duplication of effort and therefore improve the efficiency with which we advance the regulatory acceptance of DHTs and their use in clinical trials. While DHTs make use of different technologies from those used in other DDTs, C-Path's experience in other types of DDTs, and its existing infrastructure for legal, data, and regulatory engagement has proved valuable in enabling the 3DT consortium to progress. Specific regulatory feedback on the Watch-PD case study itself (such as the need to incorporate a control group, and to add a qualitative element to the study to assess the symptoms of most importance to patients) has informed multiple sponsors as to which considerations are essential across device platforms, both in other PD applications and in different disease areas.

The experiences to date make clear that, while digital technologies have many distinct characteristics, the use of DHT measures as drug development tools needs to fit into the same framework as other DDT technologies. It is therefore essential to precisely define: •The concept of interest (COI): a clinical event or characteristic of the disease or condition of interest that is to be measured, as either a COA or biomarker.•The application of the DHT In terms of how it will be applied for drug development decision making (COU). The way the DHT measures the COI will impact the drug development process.•The rationale for the use of a particular DHT measure relevant to that COI including why it meets the required technical and performance specifications.•How the selected DHT measure is meaningful.•The evidence that demonstrates the DHT measure is sufficiently well validated for the COU (“fit for purpose”).For much work to date on DHT- measures as DDTs, it is hard to precisely define all these elements. A diversity of stakeholders is key to success and spans technology experts, clinicians, industry, academic experts, nonprofit organizations, people with lived experience, and regulators themselves. New approaches and new models of collaboration are needed to advance the field as efficiently as possible to be able to attend to the time-sensitive needs of patients. Such collaborative approaches should learn lessons from other types of DDTs (e.g., imaging) to address challenges of standardization and collaborative implementation of analysis methods to enable convergence rather than divergence of proposed DHT measurements. Given the challenges of integrating and harmonizing legacy data collected across distinct device platforms, it is recommended that precompetitive collaborations focus on sharing risks, costs, and prospective study design and collection to optimize DHT studies for the future. We propose nine crucial next steps to advance the field, as shown in Table 4. While these recommendations are based on experience with this Parkison's disease case study, they are more generally applicable for DHTs used as DDTs in this regulatory environment.

Nine recommended next steps to take the field forward.


---

# Alzheimer's Disease: Exploring Pathophysiological Hypotheses and the Role of Machine Learning in Drug Discovery

- **Authors:** Jose Dominguez-Gortaire, Alejandra Ruiz, Ana Belen Porto-Pazos, Santiago Rodriguez-Yanez, Francisco Cedron
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2025-01-24
- **Language:** en
- **DOI:** 10.3390/ijms26031004
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39940772/
- **Licence:** CC-BY

## Page 1 (Section: Introduction)

Academic Editor: Hao Lv
Received: 31 December 2024
Revised: 19 January 2025
Accepted: 21 January 2025
Published: 24 January 2025
Citation: Dominguez-Gortaire, J.;
Ruiz, A.; Porto-Pazos, A.B.;
Rodriguez-Yanez, S.; Cedron, F.
Alzheimer’s Disease: Exploring
Pathophysiological Hypotheses and
the Role of Machine Learning in Drug
Discovery. Int. J. Mol. Sci. 2025, 26,
1004. https://doi.org/10.3390/
ijms26031004
Copyright: © 2025 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed under the terms and
conditions of the Creative Commons
Attribution (CC BY) license
(https://creativecommons.org/
licenses/by/4.0/).
Review
Alzheimer’s Disease: Exploring Pathophysiological Hypotheses
and the Role of Machine Learning in Drug Discovery
Jose Dominguez-Gortaire 1,2,3
, Alejandra Ruiz 4
, Ana Belen Porto-Pazos 1,5
, Santiago Rodriguez-Yanez 1,6
and Francisco Cedron 1,5,*
1
Department of Computer Science and Information Technologies, Faculty of Computer Science,
Universidade da Coruña, 15071 A Coruña, Spain; j.dgortaire@udc.es (J.D.-G.)
2
Faculty of Biological Sciences, Universidad Central del Ecuador, Quito 170136, Ecuador
3
Faculty of Odontology, UTE University, Quito 170902, Ecuador
4
Faculty of Medical Sciences, Universidad Central del Ecuador, Quito 170136, Ecuador
5
CITIC—Research Center of Information and Communication Technologies, Universidade da Coruña,
15008 A Coruña, Spain
6
CITEEC—Center for Technological Innovation in Construction and Civil Engineering, Universidade da
Coruña, 15008 A Coruña, Spain
*
Correspondence: francisco.cedron@udc.es
Abstract: Alzheimer’s disease (AD) is a major neurodegenerative dementia, with its com-
plex pathophysiology challenging current treatments. Recent advancements have shifted
the focus from the traditionally dominant amyloid hypothesis toward a multifactorial
understanding of the disease. Emerging evidence suggests that while amyloid-beta (Aβ)
accumulation is central to AD, it may not be the primary driver but rather part of a broader
pathogenic process. Novel hypotheses have been proposed, including the role of tau protein
abnormalities, mitochondrial dysfunction, and chronic neuroinflammation. Additionally,
the gut–brain axis and epigenetic modifications have gained attention as potential con-
tributors to AD progression. The limitations of existing therapies underscore the need for
innovative strategies. This study explores the integration of machine learning (ML) in drug
discovery to accelerate the identification of novel targets and drug candidates. ML offers
the ability to navigate AD’s complexity, enabling rapid analysis of extensive datasets and
optimizing clinical trial design. The synergy between these themes presents a promising
future for more effective AD treatments.
Keywords: pathophysiology; neuroinflammation; therapeutic target; mitochondrial
dysfunctions; machine learning; AI applications; virtual screening; molecular docking
1. Introduction
Alzheimer’s disease (AD) is a major progressive neurodegenerative disorder and
common inborn form of dementia characterized by marked deficits in memory about
other neurological features. Indeed, average global life expectancy has continued to rise in
recent times [1]. The search for an effective treatment and therapeutic target is essential
because there is no cure for AD, one of the major causes of senile dementia among about
35 million aged 60 years and above [2]. Recent progress in the pathophysiology of AD and
its relationship with the use of artificial intelligence (AI) algorithms in drug discovery has
resulted in a promising number of new AD therapeutic targets and strategies [3].
Alzheimer’s disease is an illness that involves a long period of asymptomatic progres-
sion that leads to a progressive, perhaps decade-long duration, culminating in cognitive,
social, and occupational impairment, finally resulting in death [4]. Regarding the basic
Int. J. Mol. Sci. 2025, 26, 1004
https://doi.org/10.3390/ijms26031004

## Page 2 (Section: Introduction)

Int. J. Mol. Sci. 2025, 26, 1004
2 of 25
molecular mechanisms of Alzheimer’s, it is characterized by the accumulation of abnormal
proteins in the brain that impair its function [5]. The two main proteins involved, Aβ
and tau, act as toxins inside nerve cells, disrupting communication between neurons and
eventually causing neuronal death [6]. This leads to symptoms of cognitive decline, such
as memory loss and confusion.
Traditional AD treatments target reducing symptoms but do not stop the progression
of the disease [7]; among the most accepted of these is the inhibition of acetylcholinesterase
and butyrylcholinesterase, due to the degradation of acetylcholine, which is a neurotrans-
mitter whose levels decrease in Alzheimer’s patients. This inhibition causes an increase in
the availability of this compound, which improves the cognitive capacity of the patients [8].
Some of the drugs that are used are donepezil, rivastigmine, and galantamine, although
their efficiency is limited and they have low specificity [9].
The drug discovery for AD has had a failure rate of as high as 99.6% in clinical trials of
new medications [10]. The newest class of approved drug is aducanumab and lecanemab,
which are monoclonal antibodies targeting Aβ solubility [11]. These drugs are in phase III
clinical trial on early-stage patients, which found that, regarding the progression of brain
amyloid deposits accumulating in patients, those that received aducanumab accumulated
significantly lower amounts than those that received the placebo. However, after the
approval of the medication, some controversy was made because a few experts had doubts
about whether the clinical trial was valid and whether the medicine was efficacious in real
clinics [12]. The bibliography suggests that the accumulation of Aβ is not the event causing
the disease but rather a compensatory process [13]. The initial step in the development
of the disease is a gap in the knowledge of the psychopathology of Alzheimer’s disease;
there are several hypotheses about its onset [14]. Many hypotheses have been postulated
in recent years. Some of them are the amyloid hypothesis, the cholinergic hypothesis,
the tau hypothesis, other neuroinflammation hypotheses, the mitochondrial dysfunction
hypothesis, environmental risks, and genetics. This implies that the origin of the disease is
multicentric and is not yet defined [15].
Some of the most recent developments in the pathophysiology of AD are explained by
the possible employment of new technological advancements, including AI, which now
bring with them exciting new opportunities in developing new therapeutic targets and
strategies [16]. There is, therefore, a growing interest in the targeting of Aβ plaques acting
upstream of tau pathology, very early in AD onset, i.e., before massive damage of the
neurons. It has since led to the identification of new potential therapeutic targets, such as
enzymes responsible for the production of Aβ and tau proteins, and new approaches to
modulate inflammation and mitochondrial dysfunction [17].
AI was also applied in the area of drug development and demonstrated great potential
to speed up the process of the invention and development of new treatments for AD [18].
Meanwhile, AI-assisted clinical trials make it possible to reveal the most effective population
for new therapies among the patient population. AI-based drug discovery allows for the
screening of huge numbers of compounds with a high amount of efficiency. Indeed, in
individualized medicine, AI indicates a consequence for each patient by individualizing
treatments using personal patient characteristics [19].
Since the impact of AD is very remarkable on the patients, their families, and, in
general, on society, the most emphatic discussion in this review is how to develop effective
therapies for this devastating disease [20]. It has not only identified new therapeutic targets
but also now holds new promise for the development of effective treatments for AD, using
AI in drug development [21]. This scientific review article is hence a summary of the
most recent research work on the hypothesis of AD development and new drugs for the
treatment of this devastating disease.

## Page 3 (Section: Hypothesis of the Development of Alzheimer's Disease)

Int. J. Mol. Sci. 2025, 26, 1004
3 of 25
2. Hypothesis of the Development of Alzheimer’s Disease
Alzheimer’s disease stands as one of the most intricate and distressing forms of neu-
rodegenerative disorders, marking its presence as the leading cause of dementia globally,
impacting millions [22]. The disease’s pathophysiology is notably complex and multi-
faceted, underscored by the accumulation of various abnormal proteins within the brain.
Although its etiology is not fully understood yet, extensive research has identified
several hypotheses that attempt to explain the underlying mechanisms of the disease.
The most studied hypotheses include the amyloid hypothesis, the tau hypothesis, the
neuroinflammation hypothesis, and the mitochondrial dysfunction hypothesis, among
others [23].
Recent studies have further suggested the involvement of the gut–brain axis in
Alzheimer’s disease progression and development, with research indicating that alterations
in gut microbiota composition can influence brain function and cognitive performance [24].
2.1. The Amyloid Hypothesis
The amyloid hypothesis posits that the aggregation of Aβ peptides in the brain leads
to the formation of senile plaques, subsequently triggering neuroinflammation, oxidative
stress, and synaptic dysfunction. This cascade eventually results in neuronal death and the
cognitive decline characteristic of Alzheimer’s disease, although some recent studies have
questioned this hypothesis, suggesting that Aβ accumulation might be a consequence of
other pathological processes rather than being the primary cause [25].
Emerging evidence has unveiled different forms of Aβ, implicating it in novel thera-
peutic targets. For instance, it is now believed that small soluble oligomers of Aβ, rather
than plaques, are the major toxic species in Alzheimer’s disease. Moreover, new enzymes
and pathways involved in Aβ’s production and clearance have been identified, opening
new avenues for drug development [26].
Despite being a central theory for decades, the role of the amyloid hypothesis in
Alzheimer’s disease pathology continues to evolve, revealing complex dynamics and
suggesting new potential therapeutic targets, underscored by the promising role of AI in
drug development [27].
2.2. Tau Hypothesis
The tau hypothesis suggests that the accumulation of abnormal tau protein forms in
the brain is one of the principal causes of Alzheimer’s disease. Tau, a vital protein for nerve
cell structure and function, stabilizes microtubules in healthy neurons—structures that act
as cellular highways for nutrient and molecule transport [28].
In Alzheimer’s, the tau protein becomes abnormal and forms clumps called neurofib-
rillary tangles, disrupting microtubules and leading to nerve cell death, contributing to
cognitive impairment [29].
Recent evidence has strengthened the tau hypothesis, identifying specific abnormal
tau forms linked to disease progression. Research is ongoing for treatments targeting
abnormal tau to prevent its accumulation in the brain [30]. Advances in imaging techniques
now allow for tau visualization in living patients, promising new diagnostic and treatment
tools for Alzheimer’s disease [31].
The tau hypothesis remains a promising avenue for the development of new treatments
for Alzheimer’s disease. However, further research is needed to fully understand the role of
the tau protein in the disease and to identify effective therapeutic targets for its treatment.

## Page 4 (Section: Neuroinflammation Hypothesis )

Int. J. Mol. Sci. 2025, 26, 1004
4 of 25
2.3. Neuroinflammation Hypothesis
This hypothesis highlights inflammation’s critical role in Alzheimer’s disease patho-
genesis, proposing that chronic inflammation drives the disease’s development and progres-
sion. Elevated inflammatory mediators, such as cytokines and chemokines, in Alzheimer’s
patient’s brains may damage neurons and impair cognition [32].
Microglia, the resident immune cells of the CNS, play a dual role in AD pathophys-
iology. Under normal conditions, they actively survey the CNS environment, clearing
debris and misfolded proteins. In early AD stages, they can even help to reduce Aβ and
tau pathology. Recent studies suggest that microglia have a potential protective role in
reducing Aβ plaques by phagocytosing these aggregates, thus conferring a neuroprotective
effect [33].
However, as AD progresses, sustained exposure to elevated Aβ levels, hyperphos-
phorylated tau, and other damage-associated molecular patterns (DAMPs) can induce
microglial overactivation [34]. Overactivated microglia release large quantities of pro-
inflammatory cytokines, chemokines, and reactive oxygen species, further aggravating
neuronal injury and amplifying neurodegenerative cascades [35].
Moreover, microglial reactivity in advanced AD has been associated with a dysfunc-
tional phenotype, characterized by the inefficient clearance of Aβ and increased secretion
of neurotoxic mediators [33]. This shift from a protective to a detrimental underscores
the complexity of microglial function in AD and highlights the importance of timing and
context in therapeutic interventions aimed at modulating microglia [36].
In addition, there is growing interest in the role of the gut microbiome in the pathogen-
esis of AD and its potential as a therapeutic target. Alterations in the gut microbiome can
lead to inflammation and immune dysregulation, which may contribute to the pathogenesis
of AD. Modulation of the gut microbiome through diet or the use of probiotics may have
prospects in the prevention and treatment of AD [37].
Novel therapeutic targets aimed at modulating the immune response in AD include
targeting the receptor for advanced glycation end products and specific cytokines or
chemokines that activate microglia [38].
2.4. Mitochondrial Dysfunction Hypothesis
Mitochondria are essential organelles that play a crucial role in cellular metabolism
and energy production [39]. There is increasing evidence that mitochondrial dysfunction
is a critical factor in AD pathogenesis. Studies have reported several mitochondrial ab-
normalities in cell brains, which include a reduction in mass, alterations in morphology,
and impairment in mitochondrial respiration [40]. All of these have been linked to ox-
idative stress, inflammation, apoptosis, and other cellular processes that contribute to the
neurodegeneration in AD [41].
Compounding these effects, oxidative stress, mitochondrial dysfunction, and copper
dysregulation are tightly interwoven in AD. Elevated copper levels worsen mitochon-
drial damage by disrupting electron transport, increasing reactive oxygen species (ROS),
and impairing energy metabolism. This synergy not only amplifies oxidative stress but
also promotes the aggregation of both Aβ and tau proteins, thereby hastening neurode-
generation [42]. Therefore, mitigating copper toxicity and its downstream impacts on
mitochondria holds promise as a therapeutic avenue for slowing AD progression.
Recent studies have pointed to several potential therapeutic targets for AD based on
the hypothesis of mitochondrial dysfunction. These include modulators of mitochondrial
function, e.g., antioxidants, inducers of mitochondrial biogenesis, and enhancers of mi-
tophagy. For instance, recent findings have shown that the induction of mitochondrial
biogenesis via the PGC-α pathway improved mitochondrial function and diminished Aβ

## Page 5 (Section: Other Hypotheses for the Development of Alzheimer's )

Int. J. Mol. Sci. 2025, 26, 1004
5 of 25
pathology in murine models of AD [43]; likewise, antioxidants such as MitoQ and SS-31
have been reported to protect against mitochondrial dysfunction and to diminish cognitive
decline in animal models of AD [44].
Other novel therapeutic targets include modulators of mitochondrial dynamics and
mitophagy, such as Mdivi-1 and Urolithin A, respectively. Indeed, Mdivi-1, a small molecule
inhibitor of Drp1, can regulate mitochondrial fission, reportedly improving mitochondrial
function and reducing beta-amyloid pathology in mouse models of AD [45] and Urolithin
A, a natural compound that has been reported to induce mitophagy and to improve
mitochondrial function in AD models [46].
Understanding the evidence behind and against the role of mitochondrial dysfunction
in AD as well as the development of safe and effective therapies targeting these pathways
will be necessary to further this approach to the discovery of novel AD therapeutics.
2.5. Other Hypotheses for the Development of Alzheimer’s
In the field of Alzheimer’s disease research, several hypotheses have been proposed
to account for the complex nature of Alzheimer’s disease in this field over the years: the
amyloid, the tau, the neuroinflammation, and the mitochondrial dysfunction hypotheses,
as well as the atherosclerotic plaques hypothesis, to name a few. Others have been proposed
recently to provide further insight into the underlying mechanisms driving the onset and
progression of Alzheimer’s disease [47].
One of these is the synaptic dysfunction hypothesis, which postulates that alterations
in synaptic function and communication between neurons play a crucial role in the devel-
opment and progression of AD [48]. Several studies have highlighted the involvement
of synapses in the pathogenesis of AD, suggesting that restoring synaptic function may
represent a possible therapeutic target [49].
Another hypothesis is the oxidative stress theory, which suggests that increased levels
of reactive oxygen species (ROS) and the resulting oxidative damage play a critical role in
the development and progression of the disease [50]. ROS are highly reactive molecules
that can damage essential cellular components such as lipids, proteins, and DNA, leading
to impaired neuronal function and cell death [51]. This cellular state is related to other
pathological processes, such as amyloid-beta aggregation and tau hyperphosphorylation,
further exacerbating neuronal dysfunction [52,53].
The neurovascular hypothesis claims that cerebral blood flow and vascular modifi-
cations play a role in the onset and progression of Alzheimer’s disease. This has been
corroborated by accumulating evidence demonstrating, for example, blood–brain bar-
rier dysfunction, which reduces cerebral blood flow and impairs vascular function in in
Alzheimer’s disease. Clinical studies have also shown that cerebral blood flow takes place
in Alzheimer’s disease [54].
The endoplasmic reticulum stress hypothesis concerns protein synthesis and folding.
This hypothesis posits that endoplasmic reticulum stress, brought on by the accumulation
of misfolded proteins, may cause the demise of neurons in Alzheimer’s disease [55].
There is also the hypothesis of epigenetics, which refers to changes in gene expression
that are not related to changes in the DNA sequence. This hypothesis suggests that epige-
netic modifications, such as DNA methylation and histone modification, may contribute to
the development of Alzheimer’s by altering the expression of genes that are important for
neuronal function [56].
Autophagy is a cellular process that eliminates damaged proteins and dysfunctional
organelles [57]. This hypothesis suggests that autophagy dysfunction may contribute to
the accumulation of abnormal proteins and neuronal death in Alzheimer’s disease [58].

## Page 6 (Section: Unification Hypothesis)

Int. J. Mol. Sci. 2025, 26, 1004
6 of 25
Other hypotheses are the zinc and aluminum hypotheses. Zinc is an essential metal
that plays an important role in neuronal function. At dysfunction, the metabolism of zinc
may contribute to the development of Alzheimer’s disease by increasing the production of
amyloid-beta and tau [59]. The same is argued for the exposure to aluminium, which may
increase the production of amyloid-beta and tau [60].
Lifestyle factors, such as diet, activity, and sleep, influence the risk of Alzheimer’s [61].
In summary, these emerging hypotheses add detail to the multifaceted nature of
Alzheimer’s disease and provide potentially novel therapeutic targets for drug develop-
ment. Additional research is required to fully understand the mechanisms underlying
these hypotheses and their potential implications for Alzheimer’s treatment.
2.6. Unification Hypothesis
The complexity of Alzheimer’s disease has led to the proposal of a unification hy-
pothesis that seeks to integrate various perspectives on the disease’s pathogenesis. This
hypothesis aims to explain the interactions between amyloid-β accumulation, tau protein
pathology, neuroinflammation, mitochondrial dysfunction, and other relevant factors, of-
fering a comprehensive understanding of AD (Figure 1). Recent research suggests that
these mechanisms are not mutually exclusive but are instead interconnected processes
contributing to the disease’s onset and progression [62].
Aβ accumulation has long been considered a hallmark of AD, with its aggregation
leading to plaque formation and subsequent neuronal damage. However, recent studies
indicate that Aβ may also interact with tau protein and intensify tau pathology [63]. Tau
protein, normally involved in stabilizing microtubules, becomes hyperphosphorylated
and forms neurofibrillary tangles in AD, disrupting cellular transport mechanisms and
leading to neuronal death [64]. The interplay between Aβ and tau is thought to amplify
neurodegenerative processes, creating a vicious cycle of neuronal damage.
Neuroinflammation is another critical component of the unification hypothesis.
Chronic inflammation in the brain, driven by the activation of microglia and astrocytes,
contributes to AD progression [6]. These glial cells, in response to Aβ and tau pathology,
release pro-inflammatory cytokines and reactive oxygen species, further damaging neurons
and promoting a toxic environment [65]. Additionally, recent studies have highlighted the
role of the gut microbiome in modulating neuroinflammatory responses, suggesting that
systemic inflammation might also influence AD pathogenesis.
Mitochondrial dysfunction is increasingly recognized as a significant factor in AD.
Mitochondria, the powerhouses of the cell, are responsible for energy production and
regulating apoptosis. In AD, mitochondrial abnormalities, including impaired respiratory
function and increased oxidative stress, have been observed [66]. These dysfunctions not
only contribute to neuronal energy deficits but also enhance the production of reactive
oxygen species, which can damage cellular components and promote neuroinflammation
and protein aggregation.
Emerging evidence also points to the role of vascular contributions in AD. Vascular
dysfunction, including reduced cerebral blood flow and blood–brain barrier breakdown,
may lead to hypoxia and the accumulation of neurotoxic substances in the brain [67]. This
vascular impairment can enhance Aβ deposition and tau pathology, further intertwining
with neuroinflammatory and mitochondrial pathways.
While multiple hypotheses have attempted to explain the complex pathophysiology
of AD, there remains a lack of conceptual integration that explains how these processes
interact in a single narrative. We propose a new integration hypothesis based on the
synchronization of neuroinflammatory events with mitochondrial dysfunction, which
could trigger the synaptic collapse observed in early stages of the disease [68]. Rather than

## Page 7 (Section: Unification Hypothesis)

Int. J. Mol. Sci. 2025, 26, 1004
7 of 25
viewing these pathological routes independently, we suggest that chronic inflammation
activates dysfunctional mitochondria, causing a positive feedback loop of oxidative stress
that amplifies tau and Aβ toxicity. This hypothesis posits that therapeutic interventions
designed to regulate the dialogue between microglia and mitochondria could offer a
promising pathway to slow the progression of neurodegeneration.
This unification hypothesis underscores the importance of a holistic approach to
understanding AD. By considering the interdependence of these pathological mechanisms,
researchers can develop more effective therapeutic strategies. For instance, targeting
multiple pathways simultaneously—such as mitigating neuroinflammation, improving
mitochondrial function, and reducing Aβ and tau pathology—could provide synergistic
effects in slowing or halting disease progression [67]. Additionally, novel therapeutic
approaches that address vascular health and the gut–brain axis might offer new avenues
for intervention.
Table 1 provides a comprehensive summary of the various hypotheses proposed for
the development of Alzheimer’s disease, highlighting their key mechanisms, supporting
evidence, and potential therapeutic targets. This consolidation underscores the multifacto-
rial nature of AD, suggesting that multiple interconnected pathways contribute to its onset
and progression. Recognizing the interplay between these mechanisms, as emphasized
by the unification hypothesis, is crucial for developing holistic and effective therapeutic
strategies. By targeting multiple pathways simultaneously—such as reducing amyloid
and tau pathology, mitigating neuroinflammation, and enhancing mitochondrial function—
there is potential to create synergistic treatments that more effectively slow or halt disease
progression. This integrated approach holds promise for improving clinical outcomes and
offers a more profound understanding of Alzheimer’s disease pathogenesis.
Table 1. Summary of Alzheimer’s disease hypotheses and therapeutic targets.
Hypothesis
Overview
Amyloid
Hypothesis
Key Mechanism: Accumulation of β-amyloid peptides forming senile plaques, triggering
neuroinflammation and synaptic dysfunction.
Evidence: Identification of Aβ plaques; toxic soluble oligomers [20].
Therapeutic Targets: Enzymes regulating Aβ production and clearance; targeting oligomers.
Tau Hypothesis
Key Mechanism: Abnormal tau protein forms neurofibrillary tangles, disrupting microtubules
and leading to neuronal death.
Evidence: Presence of hyperphosphorylated tau; correlation with disease progression [64].
Therapeutic Targets: Inhibitors of tau aggregation; microtubule stabilizers.
Neuroinflammation
Hypothesis
Key Mechanism: Chronic activation of microglia releases pro-inflammatory cytokines,
damaging neurons.
Evidence: Elevated cytokines and chemokines in AD brains; microglial activation [6].
Therapeutic Targets: Modulators of microglial activity; anti-inflammatory agents.
Mitochondrial
Dysfunction
Hypothesis
Key Mechanism: Impaired mitochondrial function leads to energy deficits and
oxidative stress.
Evidence: Mitochondrial abnormalities; increased oxidative damage in neurons [69].
Therapeutic Targets: Antioxidants; enhancers of mitochondrial biogenesis;
mitophagy inducers.
Synaptic
Dysfunction
Hypothesis
Key Mechanism: Alterations in synaptic function impair neuron communication, leading to
cognitive decline.
Evidence: Synaptic loss observed in AD; links to cognitive deficits [49].
Therapeutic Targets: Agents restoring synaptic function; neurotrophic factors.

## Page 8 (Section: Unification Hypothesis)

Int. J. Mol. Sci. 2025, 26, 1004
8 of 25
Table 1. Cont.
Hypothesis
Overview
Oxidative Stress
Hypothesis
Key Mechanism: Excess reactive oxygen species cause cellular damage and apoptosis.
Evidence: Presence of oxidative damage in AD brains; lipid peroxidation [50].
Therapeutic Targets: Antioxidants; compounds reducing oxidative stress.
Neurovascular
Hypothesis
Key Mechanism: Vascular dysfunction reduces cerebral blood flow, contributing
to neurodegeneration.
Evidence: Blood–brain barrier breakdown; reduced flow in AD patients [5].
Therapeutic Targets: Vascular health agents; improving blood–brain barrier integrity.
Endoplasmic
Reticulum Stress
Hypothesis
Key Mechanism: Accumulation of misfolded proteins induces ER stress and neuronal death.
Evidence: Elevated ER stress markers; unfolded protein response activation [55].
Therapeutic Targets: Modulators of protein folding; ER stress reducers.
Epigenetic
Hypothesis
Key Mechanism: Epigenetic modifications alter gene expression affecting neuronal function.
Evidence: DNA methylation changes; histone modifications in AD brains [70].
Therapeutic Targets: Epigenetic modulators; drugs targeting gene expression.
Metal
Hypotheses
(Zinc and
Aluminum)
Key Mechanism: Dysregulated metal ions contribute to protein aggregation and toxicity.
Evidence: Altered metal levels in AD brains; metals interact with Aβ and tau [59].
Therapeutic Targets: Metal chelators; normalizing metal homeostasis.
Lifestyle Factors
Hypothesis
Key Mechanism: Diet, physical activity, and sleep patterns influence AD risk.
Evidence: Epidemiological links between lifestyle and AD incidence [61].
Therapeutic Targets: Lifestyle interventions; dietary modifications.
Figure 1. In this figure, the bold lines illustrate direct relationships or causal connections between the
various pathogenic factors in Alzheimer’s disease, while the dotted lines denote feedback loops and
amplification cycles that further exacerbate existing pathological processes. Overall, this schematic in-
tegrates multiple interdependent mechanisms, highlighting how genetic, environmental, and lifestyle
factors converge to initiate mitochondrial dysfunction and oxidative stress, ultimately promoting
amyloid-beta and tau protein aggregation. These misfolded proteins trigger synaptic dysfunction and
neuronal death while also activating microglia and astrocytes that mount an inflammatory response,
which, if sustained, amplifies protein aggregation and accelerates neurodegeneration. Moreover,
vascular abnormalities and gut microbiome alterations potentiate both inflammation and oxidative
damage, and imbalances in metal ions further promote pathological protein aggregation. Impaired

## Page 9 (Section: Emerging Therapeutic Targets in Alzheimer's Disease Research)

Int. J. Mol. Sci. 2025, 26, 1004
9 of 25
autophagy and epigenetic modifications compound disease progression by hindering the clearance of
toxic species and altering gene expression, respectively. By illustrating these interconnected pathways
and feedback loops, the figure underscores the multifactorial nature of Alzheimer’s disease and the
potential benefit of targeting multiple nodes in this network for therapeutic intervention.
Pathway of Unification Hypothesis
The proposed pathway of the unified hypothesis, illustrated in Figure 1, begins with a
combination of genetic predispositions, environmental exposures, and lifestyle factors such
as diet, physical activity, and sleep patterns [61]. These factors can lead to initial metabolic
disturbances, including mitochondrial dysfunction and oxidative stress [39]. Mitochondrial
dysfunction results in impaired energy production and increased production of reactive
oxygen species, exacerbating oxidative stress [66].
Oxidative stress contributes to the misfolding and aggregation of Aβ peptides and
hyperphosphorylated tau proteins [52]. The accumulation of these abnormal proteins leads
to the formation of amyloid plaques and neurofibrillary tangles, key pathological features
of AD [64].
The presence of Aβ and tau aggregates activates microglia and astrocytes, the brain’s
resident immune cells, triggering a chronic neuroinflammatory response [32]. Neuroin-
flammation further promotes neuronal damage and synaptic dysfunction, disrupting
communication between neurons [65].
Vascular dysfunction, including reduced cerebral blood flow and blood–brain barrier
breakdown, may contribute to hypoxia and facilitate the entry of peripheral inflamma-
tory mediators and toxins into the brain, exacerbating neuroinflammation and protein
aggregation [54].
Impaired autophagy and proteasomal degradation systems hinder the clearance of
misfolded proteins and damaged organelles, allowing toxic aggregates to accumulate [58].
Epigenetic modifications may alter gene expression patterns involved in neuronal survival,
synaptic function, and protein homeostasis, further promoting disease progression [56].
Metal ions such as zinc and aluminum may influence amyloid-beta and tau pathology
by affecting protein aggregation and toxicity [59,60]. Additionally, alterations in the gut
microbiome can modulate systemic inflammation and impact brain function via the gut–
brain axis [24].
These interconnected processes create a vicious cycle of neuronal damage, synaptic
loss, and cognitive decline characteristic of Alzheimer’s disease. By understanding this
complex pathway, researchers can target multiple aspects of the disease simultaneously,
potentially developing more effective therapeutic strategies.
3. Emerging Therapeutic Targets in Alzheimer’s Disease Research
Recent years have seen an explosion of research into the underlying mechanisms of
Alzheimer’s disease, leading to new insights and potential therapeutic targets. Studies on
amyloid and tau proteins have revealed new approaches for disease-modifying therapies,
while neuroinflammation and mitochondrial dysfunction have emerged as promising
areas of research [71]. Recent studies on amyloid and tau proteins have provided new
insights into AD pathogenesis and potential therapeutic targets. Aβ and tau are the main
components of amyloid plaques and neurofibrillary tangles, respectively, which are the
hallmark pathological features of AD. Recent research has focused on identifying new ways
to reduce the accumulation of Aβ and tau in the brain [72] One strategy is to target the
enzymes responsible for the production of Aβ and tau. Beta-secretase and gamma-secretase
are enzymes involved in Aβ formation and are promising targets for drug development.
Several inhibitors have been developed and are being tested in clinical trials [11]. Similarly,
the inhibition of tau kinases, such as GSK-3β, has shown promise in reducing tau pathology

## Page 10 (Section: Emerging Therapeutic Targets in Alzheimer's Disease Research)

Int. J. Mol. Sci. 2025, 26, 1004
10 of 25
in animal models of AD [73]. Another approach is to enhance the clearance of Aβ and tau
from the brain. One way to achieve this is to act on the immune system. Microglia, the
brain’s immune cells, can engulf and eliminate Aβ and tau; however, in AD, microglia
become dysfunctional and are unable to effectively eliminate these proteins. Recent research
has focused on the development of drugs that can modulate the activity of microglia to
improve their ability to clear Aβ and tau [74]. In addition, there is growing evidence that
Aβ and tau may not act alone in the pathogenesis of AD and that other factors may be
involved. Overall, recent studies on amyloid and tau proteins have led to the identification
of new therapeutic targets for AD, including enzymes involved in the production of Aβ
and tau [20].
One area of interest has been the role of inflammation in Alzheimer’s disease. In-
flammation is a natural response of the immune system to injury or infection, but chronic
neuroinflammation may contribute to brain neurodegeneration. Recent studies have shown
that neuroinflammation is a key feature of Alzheimer’s disease [75]. Recent studies have
shown that certain immune cells, such as microglia and astrocytes, play a key role in regulat-
ing the inflammatory response in the brain. Dysregulation of these cells may contribute to
neuroinflammation and the subsequent development of Alzheimer’s disease [76]. In recent
years, new discoveries have emerged about the role of inflammation in Alzheimer’s disease.
Inflammation has been identified as a key factor in the development and progression of
Alzheimer’s disease, and it is now understood that chronic inflammation can lead to the
accumulation of Aβ plaques and tau tangles in the brain [77]. New evidence suggests
that targeting neuroinflammation may be a viable therapeutic strategy for Alzheimer’s
disease. Several anti-inflammatory drugs, such as non-steroidal anti-inflammatory drugs
(NSAIDs) and minocycline, have been investigated for their potential to slow or prevent
disease progression; however, these drugs have been limited by their side-effect profile and
lack of specificity for brain inflammation [78].
More recent research has also focused on identifying specific targets within the inflam-
matory pathway that can be selectively targeted. For example, the complement system
is involved in neuroinflammation and has been the subject of preclinical studies, with
promising results [79]. Other targets include cytokines and chemokines, small signalling
molecules involved in inflammation. In addition, research has identified specific inflamma-
tory pathways, such as the NLRP3 inflammasome, as potential targets for intervention [80].
In addition to hypotheses related to amyloid, tau, and inflammation, new research
has implicated mitochondrial dysfunction in Alzheimer’s disease [81]. Mitochondria
are organelles responsible for energy production within cells and are essential for cell
function. Dysfunctional mitochondria can cause cell damage and death, and recent evidence
suggests that mitochondrial dysfunction may play a role in the pathogenesis of Alzheimer’s
disease [82].
Studies have shown that mitochondrial dysfunction is present both in the brains of
Alzheimer’s patients and in animal models of the disease. Dysfunctional mitochondria
in AD have been shown to produce less energy, generate more ROS, and have impaired
calcium homeostasis, leading to neuronal death. In addition, studies have suggested that
amyloid and tau pathologies may directly contribute to mitochondrial dysfunction in
Alzheimer’s disease [83].
In light of these findings, treatment of mitochondrial dysfunction has emerged as
a possible therapeutic strategy for Alzheimer’s disease. Several studies have explored
the use of mitochondria-targeted antioxidants, such as MitoQ, as a potential therapy for
Alzheimer’s disease. Other studies have investigated the potential of compounds that may
improve mitochondrial function, such as the AMPK activator metformin [84].

## Page 11 (Section: The Use of Artificial Intelligence in Alzheimer's Research)

Int. J. Mol. Sci. 2025, 26, 1004
11 of 25
One of the emerging areas of research is the role of the gut microbiome in Alzheimer’s
disease, as recent studies have shown that changes in the gut microbiota can lead to
alterations in the brain associated with cognitive impairment and dementia. Other research
has focused on the role of the microbiome as a modulator of the immune system in
Alzheimer’s disease, in particular, the activation of microglia, and the potential therapeutic
benefits of modulating the immune response in the brain [85].
Other emerging areas of research include the role of epigenetic factors in Alzheimer’s
disease, as well as the potential benefits of lifestyle interventions, such as exercise and di-
etary modifications, in reducing the risk of developing the disease [70]. These findings offer
new insights into the mechanisms underlying the development of Alzheimer’s disease and
may lead to the identification of new therapeutic targets for the treatment and prevention
of the disease.
Current theories about Alzheimer’s offer a fragmented view of its etiology. By inte-
grating recent evidence, we propose that future research should focus on the link between
neuroinflammation and mitochondrial alterations as the primary drivers of the disease.
Studies in animal models suggest that regulating inflammatory activity could improve
mitochondrial function and thus preserve neuronal synapses [69]. This approach implies a
promising direction in the search for new therapeutic targets that act on multiple patho-
logical processes simultaneously, a task in which AI could facilitate the analysis of large
volumes of clinical and experimental data.
4. The Use of Artificial Intelligence in Alzheimer’s Research
The complexity of neurodegenerative diseases such as Alzheimer’s disease presents
significant challenges in biomedical research. Traditional approaches often fail to handle
the sheer volume of data generated from genetic, proteomic, and clinical studies. AI
has emerged as a powerful tool to address these challenges. Its capacity to process large
amounts of data, identify patterns, and simulate biological processes is transforming the
way that biomedical research is carried out [86]. The use of ML algorithms and deep
learning networks is particularly crucial in improving early diagnosis, identifying novel
therapeutic targets, and enhancing the efficiency of drug development.
Some of the examples of success in the early diagnosis of Alzheimer’s disease demon-
strate how ML models leverage multimodal data to enhance diagnostic accuracy and offer
insights into disease progression mechanisms.
One of them is a novel deep learning framework integrating 3D vision transformers
(3D-ViTs) and deep belief networks (DBNs) for the early detection of Alzheimer’s disease.
The model analyzes structural MRI data divided into 138 brain regions (regions of interest,
ROIs) from the ADNI dataset (532 samples: 168 cognitively normal, 247 mild cognitive
impairment, and 117 Alzheimer’s disease). It achieves high accuracy (up to 90% for AD vs.
CN classification) and interpretability, highlighting brain regions contributing significantly
to disease progression. The approach demonstrates robustness and scalability, emphasizing
its utility in clinical applications [87].
Another study has developed a multimodal machine learning model (EDAMM) com-
bining acoustic and linguistic features for Alzheimer’s disease diagnosis. Using datasets
ADReSSo (166 samples) and NCMMSC2021 (long speech: 280 training, 119 test samples),
the model applies Wav2Vec2.0, TF-IDF, and Word2Vec for feature extraction. Self-attention
and cross-modal attention mechanisms enhance feature integration, achieving accuracies
of 86.7% (ADReSSo) and 90.2% (NCMMSC2021). The study highlights the effectiveness of
combining speech and text data for non-invasive, cost-effective early AD diagnosis [88].
AI has revolutionized the study of neurodegenerative diseases through the use of
various techniques, including different types of learning: supervised, unsupervised, and

## Page 12 (Section: The Use of Artificial Intelligence in Alzheimer's Research)

Int. J. Mol. Sci. 2025, 26, 1004
12 of 25
reinforcement learning, as described in Table 2. The most commonly used techniques
are deep learning models that use the machine learning models described above; all AI
approaches are summarized in Table 3. In biomedical research, the impact of AI has
been profound, enabling better identification of disease biomarkers and new therapeutic
compounds. However, challenges such as data heterogeneity and a lack of labeled data in
the early stages of Alzheimer’s pose obstacles to the broader implementation of AI in this
pathology [89]. However, integrating AI with precision medicine holds great potential for
future therapeutic advances.
Table 2. AI training models.
AI Approach
Description
Supervised
Learning
Supervised learning involves training models on labeled data to predict outcomes such as
disease progression based on clinical data [90]. This method is useful for tasks such as prognosis
estimation in Alzheimer’s patients.
Unsupervised
Learning
Unsupervised learning is applied to analyze high-dimensional and unlabeled datasets, such as
genomic and proteomic sequences [91]. It is particularly useful in discovering novel patterns,
classifications, and subgrouping of patients without predefined labels.
Reinforcement
Learning
Reinforcement learning is used to simulate and optimize therapeutic strategies by learning from
the outcomes of previous simulations [92]. It is increasingly applied to find optimal treatment
protocols and intervention strategies for neurodegenerative diseases.
Table 3. Description of AI models applied to Alzheimer’s disease.
Model
Description
SVM (Support
Vector Machine)
A supervised learning algorithm that seeks an optimal hyperplane to separate data points of
different classes with maximal margin [93]
RF (Random Forest)
An ensemble method composed of multiple decision trees. It reduces overfitting and increases
predictive accuracy by averaging the results of numerous weak learners [93].
ANNs (Artificial
Neural Networks)
Computational models inspired by biological neural networks, capable of recognizing
complex patterns in data through interconnected layers of weighted nodes [94].
DNNs (Deep Neural
Networks)
A type of neural network with multiple hidden layers that can automatically learn hierarchical
representations, enabling the extraction of increasingly abstract features [95].
LBVS (Ligand-Based
Virtual Screening)
A computational approach that uses known active compounds to predict new molecules with
similar biological activity, facilitating the discovery of novel candidates [96].
Deep Learning
Models
A family of advanced neural network architectures (including CNNs, RNNs, and
transformers) that learn from large datasets, often without the need for manual feature
engineering [97].
AlphaFold
An AI system that predicts protein structures from amino acid sequences with high accuracy,
providing insights into molecular form and function [98].
Systems Biology
Models
Integrative computational frameworks that combine data from various biological levels
(genomes, proteomes, metabolomes) to model complex biological systems holistically [99].
Agent-Based Models
Simulation models where individual entities (agents) follow defined rules, allowing complex
global patterns to emerge from local interactions [100].
Bayesian Networks
Probabilistic graphical models that represent variables and their conditional dependencies,
enabling reasoning under uncertainty and probabilistic inference [101].
NLP (Natural
Language
Processing)
Techniques and models for analyzing, understanding, and generating human language, often
applied to tasks like sentiment analysis, machine translation, and information extraction [102].

## Page 13 (Section: Virtual Screening of Active Compounds Targeting Therapeutic Sites)

Int. J. Mol. Sci. 2025, 26, 1004
13 of 25
Table 3. Cont.
Model
Description
Sensor-Based
Monitoring
The use of wearable devices, IoT sensors, and other technologies to continuously capture data
streams (e.g., physiological signals, environmental parameters) for subsequent analysis [103].
DeepAD
A specialized deep learning approach designed for complex classification and prediction tasks,
integrating multiple data types and learning representations at various scales [104].
4.1. Virtual Screening of Active Compounds Targeting Therapeutic Sites
Virtual screening is a computational method used to search large chemical libraries
to identify potential bioactive compounds that could act as drugs or potential drugs [105].
The main goal is to reduce the number of molecules that need to be tested experimentally,
saving time and resources.
Ligand-based virtual screening (LBVS): This method uses information from known
active ligands to find compounds with similar structures or chemical properties [106]. It
assumes that molecules with similar structures will exhibit similar biological activity [107].
LBVS is particularly effective when the 3D structure of the target is unknown, and relies on
chemical fingerprints or molecular descriptors to find potential compounds.
Machine learning algorithms, such as support vector machines (SVMs), random forests
(RFs), artificial neural networks (ANNs), and deep neural networks (DNNs), are commonly
used to identify potentially active compounds [108]. These tools accelerate the identification
of key molecular features that correlate with biological activity, making them a rapid and
highly effective avenue for potential Alzheimer’s drug discovery.
AI can be used to facilitate the identification of new therapeutic targets for Alzheimer’s.
By mining data from genomic and proteomic datasets, AI tools such as DeepBind can pre-
dict protein–DNA interactions, helping to identify genes involved in Alzheimer’s pathol-
ogy [109]. Furthermore, AI models integrate vast molecular databases with advanced
neural networks, such as graph convolutional networks, to predict molecular interac-
tions [110]. These tools improve the virtual screening process by evaluating molecular
properties and interactions more comprehensively.
After the virtual screening process, the efficacy of the selected compounds must be
evaluated. First, it is important to evaluate the interaction of the ligands with the therapeutic
targets through molecular docking and molecular dynamics [111]. After that, both in vitro
and in vivo evaluations are performed. AI helps to optimize high-throughput screening
and preclinical testing by predicting the outcomes of these assessments, streamlining the
transition from virtual models to laboratory testing [112].
4.2. Advantages of AI-Assisted Molecular Docking and Molecular Dynamics
Molecular docking is a key technique in Alzheimer’s drug discovery, allowing us to
predict how ligands interact with biological targets such as acetylcholinesterase or amyloid-
beta plaques. AI has improved this process by optimizing ligand–receptor interaction
prediction and improving the accuracy of docking simulations [113].
Molecular dynamics simulations, which predict the behavior of molecular complexes
over time, have also benefited from advances in AI. Deep learning tools such as AlphaFold
enable 3D models of proteins that are not described experimentally, leading to more
accurate simulations of protein–ligand interactions by more effectively predicting protein
structures [114].
These AI-powered simulations provide deeper insights into the dynamics of molecular
complexes, critical to understanding drug efficacy in Alzheimer’s. Traditional docking
and simulation methods often fail to accurately model the flexibility of biological systems.

## Page 14 (Section: Modeling the Interaction of Key Hypotheses in Alzheimer's Development Using AI)

Int. J. Mol. Sci. 2025, 26, 1004
14 of 25
AI-powered techniques overcome these limitations by dynamically predicting changes in
protein–ligand interactions and providing more realistic simulations [115].
Notably, models such as DeepDock and AtomNet use deep learning frameworks to
improve the docking process. DeepDock improves the prediction of binding poses by
learning from large datasets of protein–ligand complexes, while AtomNet applies CNNs to
predict molecular binding affinities, considering the spatial arrangement of atoms [116,117].
Other models such as CNNScore and RF-Score integrate machine learning with tradi-
tional scoring functions to refine docking accuracy [118]. These models represent significant
advances in leveraging AI to obtain more reliable molecular docking results.
Following AI-based predictions, preclinical studies validate the findings, ensuring
that in silico models align with in vivo biological behavior.
4.3. Modeling the Interaction of Key Hypotheses in Alzheimer’s Development Using AI
Alzheimer’s disease is driven by several inter-related hypotheses, including amyloid-
beta accumulation, tau hyperphosphorylation, and neuroinflammation [119] as the unifying
hypothesis of Alzheimer’s disease development and the synchronization of neuroinflam-
matory events with mitochondrial dysfunction.
AI makes it possible to model these complex processes, integrating them into a multi-
hypothesis framework to predict disease progression and identify new therapeutic targets.
Through in silico simulations, AI tools allow researchers to explore the interactions between
these hypotheses, offering insights into disease mechanisms that would be difficult to
achieve through experimental studies alone [120].
Several AI-driven models have been developed to simulate these biological interac-
tions. Systems biology models such as EpiSim integrate various molecular and cellular
pathways to model disease dynamics [121]. Agent-based models such as Repast Simphony
simulate single entities (e.g., cells or proteins) to study their interactions over time, allow-
ing for the exploration of processes such as amyloid-beta aggregation [122]. Furthermore,
Bayesian networks have been applied to Alzheimer’s disease to infer probabilistic relation-
ships between different hypotheses, such as the interaction between tau protein pathology
and amyloid-beta accumulation [123].
In addition to these modeling approaches, AI is being integrated into clinical trials to
deliver personalized treatments tailored to individual patient profiles. For example, the trial
“Design of Personalized Supplements Based on the Gut-Brain Axis to Reduce Alzheimer’s
Disease Risk” (NCT06199193) leverages AI to optimize dietary interventions based on
gut microbiota analysis [124]. Similarly, the “BRAIN App” trial (NCT06298474) uses AI-
powered behavioral interventions to provide customized cognitive stimulation, aiming
to enhance patient outcomes through individualized care [125]. These studies underscore
the transformative potential of AI in combining biological modeling with personalized
therapeutic strategies.
For example, reinforcement learning has been employed to model oxidative stress
feedback loops, providing a deeper understanding of how oxidative damage exacerbates
tau protein pathology [126]. DeepRL has shown potential to optimize treatment strategies
by simulating how therapeutic interventions affect this positive feedback loop, as we
propose in the unification hypothesis [127].
AI-generated models should be validated using experimental data, ensuring that they
reflect the current biological processes underlying Alzheimer’s progression [128]. Once
validated, AI models can simulate the effects of various therapeutic interventions, offering
a pathway to optimize treatment strategies based on real-world data [129].
A promising approach to understanding the complex interactions between multiple
Alzheimer’s hypotheses, such as neuroinflammation, mitochondrial dysfunction, and

## Page 15 (Section: AI Applications in Patient Monitoring in Clinical Studies)

Int. J. Mol. Sci. 2025, 26, 1004
15 of 25
oxidative stress, would be to develop a multi-scale systems biology model that integrates
these processes into a cohesive framework [130]. This could be achieved using a tool such
as COPASI (Complex Pathway Simulator) version 4.39 (available at https://copasi.org/),
which allows for modeling biochemical pathways and feedback loops [131], including the
interaction between oxidative stress and mitochondrial dysfunction.
By incorporating AI algorithms such as dynamic Bayesian networks and deep rein-
forcement learning, this model could dynamically simulate how these processes influence
each other over time [132]. Specifically, it would allow for observing positive feedback loops
between neuroinflammation, mitochondrial dysfunction, and oxidative stress, helping to
identify key intervention points to disrupt these cycles.
4.4. AI Applications in Patient Monitoring in Clinical Studies
Artificial intelligence technologies have transformed medicine and the way that data
are collected and analyzed in Alzheimer’s clinical trials. Natural language processing (NLP),
sensor-based monitoring, and wearable devices enable real-time data collection, which AI
algorithms can analyze to track disease progression in a more accurate and individualized
way [133]. For example, the digital platform Altoida uses a combination of smartphone-
based cognitive assessments and AI algorithms to predict the onset of Alzheimer’s by
analyzing daily behaviors and cognitive tasks [134]. Similarly, the Neurotrack app uses eye-
tracking technology combined with AI to assess memory and cognitive function remotely,
allowing researchers to collect real-time data on cognitive decline.
By continuously monitoring cognitive function, behavior, and daily activities, AI-
powered tools generate longitudinal datasets that provide deeper insights into a patient’s
condition over time [135]. This real-time data analysis can be used to tailor treatment plans
based on a patient’s unique needs, improving the overall effectiveness of interventions and
personalized medicine. The RADAR-AD (Remote Assessment of Disease And Relapse–
Alzheimer’s Disease) project is another example of using wearables, mobile technology,
and AI to track disease progression in real-world settings [136]. RADAR-AD collects data
on movement, sleep, and other daily activities to provide insights into how Alzheimer’s
affects daily life and tailor treatments accordingly [137].
AI’s predictive capabilities are also crucial in clinical trials, allowing researchers to
forecast patient responses to treatments. Predictive models, such as survival analysis and
time series algorithms, help to identify which patients will benefit most from experimental
therapies. For example, IBM Watson for Clinical Trials uses AI to analyze clinical trial
data and predict which patients are most likely to respond to specific treatments based on
their genetic and clinical profiles [138]. AI tools also help tp monitor treatment adherence,
providing a holistic view of how patients respond to therapy and how these responses
impact their quality of life [139]. The AiCure platform, which uses computer vision and
AI to monitor medication adherence using smartphone cameras, ensures that patients
take their medications as prescribed, reducing dropout and missing data, improving the
accuracy of clinical trial data and overall patient outcomes [140].
4.5. AI-Assisted Diagnosis and Computer Vision
Artificial intelligence has significantly improved the accuracy of Alzheimer’s disease
diagnosis by automating the analysis of imaging data [141]. CNNs are routinely used
to analyze CT and MRI scans, and detecting subtle structural changes in the brain, such
as hippocampal atrophy, that are difficult to identify manually, becomes a very useful
tool for radiologists [142]. For example, a study using DeepAD, a deep learning model,
demonstrated its ability to detect hippocampal volume reduction with high accuracy,
providing early markers of Alzheimer’s long before cognitive symptoms appear [143].

## Page 16 (Section: AI Applications in Patient Monitoring in Clinical Studies)

Int. J. Mol. Sci. 2025, 26, 1004
16 of 25
AI-powered image analysis enables the early identification of structural markers asso-
ciated with Alzheimer’s, often years before symptoms manifest [144]. A notable example is
VoxCNN, a CNN-based model that analyzes 3D brain images from MRI scans to identify
Alzheimer’s-specific atrophy patterns. In clinical trials, VoxCNN has demonstrated supe-
rior performance in detecting early-stage Alzheimer’s compared to traditional diagnostic
methods [145].
When comparing AI-assisted diagnoses to traditional methods, it is clear that AI pro-
vides more accurate, consistent, and reproducible results, reducing diagnostic delays [146].
In a clinical study, the DLAD (Deep Learning for Alzheimer’s Diagnosis) system outper-
formed radiologists in detecting early signs of Alzheimer’s from MRI scans, particularly
in distinguishing between mild cognitive impairment and normal aging, which is often a
challenge in traditional diagnostics because of the similarity of morphological differential
diagnoses [147].
AI tools also support clinical decision making by providing comprehensive analytics
that combine imaging data with genetic and clinical records [148]. For example, systems
such as IBM Watson Health synthesize patient data from multiple sources, including
genomic sequences, clinical history, and imaging results, to help diagnose Alzheimer’s and
recommend the most appropriate treatments for each patient [149]. Another example is
Neuroreader, an AI-powered software that analyzes MRI data to quantify brain atrophy
and compare it to normative data, providing useful information for physicians during
diagnosis [150].
In summary, Table 4 showcases the key areas where artificial intelligence has sig-
nificantly impacted Alzheimer’s research. Each area of application utilizes specific AI
techniques to achieve notable benefits while also facing certain challenges.
Table 4. Summary of AI techniques in Alzheimer’s research.
Area of Application
AI Techniques Used
Key Benefits
Challenges
Virtual Screening
of Active
Compounds
SVM, RF, ANN,
DNN, LBVS
Accelerated identification
of potential drug
candidates, improved
screening efficiency
Data quality,
computational resources
[108]
Molecular Docking
and Dynamics
Deep Learning Models
(AlphaFold, DeepDock,
AtomNet, CNNScore,
RF-Score)
Enhanced accuracy in
predicting protein
structures and ligand
interactions
Modeling biological
flexibility, validation of
predictions [113]
Modeling Disease
Hypotheses
Systems Biology Models
(EpiSim), Agent-Based
Models (Repast Simphony),
Bayesian Networks,
Reinforcement Learning
Integrated understanding
of disease mechanisms,
identification of
therapeutic targets
Complexity of biological
systems, data integration
[120]
Patient Monitoring
in Clinical Studies
Wearable Devices, NLP,
Sensor-Based Monitoring
Real-time data collection,
personalized treatment
plans, improved adherence
Data privacy, variability in
patient data [134]
AI-Assisted
Diagnosis
Deep Learning Models
(DeepAD, VoxCNN,
CNNs)
Early detection of
structural brain changes,
increased diagnostic
accuracy
Requirement for large
datasets, potential for
overfitting [143]

## Page 17 (Section: Conclusions)

Int. J. Mol. Sci. 2025, 26, 1004
17 of 25
5. Conclusions
Recent studies on Alzheimer’s disease have shed light on new therapeutic targets
and avenues for drug development. For decades, the amyloid hypothesis has been the
cornerstone of drug development efforts, focusing on the accumulation of beta-amyloid
in the brain. However, despite numerous clinical trials aimed at reducing amyloid bur-
den, the results have been largely disappointing, raising questions about the role of amy-
loid as a primary cause of Alzheimer’s disease pathology. These results suggest that
Alzheimer’s may be the result of multiple molecular dysfunctions rather than driven solely
by amyloid accumulation.
Emerging evidence points to other critical factors, such as tau protein accumulation,
neuroinflammation, mitochondrial dysfunction, and synaptic loss, as key contributors to the
disease. Research has proposed that synaptic loss, rather than amyloid or tau accumulation,
could be a pivotal factor in the early progression of Alzheimer’s disease. Furthermore,
the discovery of new genes, such as TREM2, which is involved in microglial function and
immune response, has introduced new targets for therapeutic intervention. Furthermore,
the importance of mitochondrial dysfunction and other proteins, such as midkine and
pleiotrophin, in the pathogenesis of Alzheimer’s disease is increasingly recognized. These
findings underscore the need to explore alternative pathways in therapeutic development
and to take a more holistic view of the underlying mechanisms of the disease.
AI has the potential to revolutionize Alzheimer’s drug development by enabling a
faster and more efficient identification of drug targets and assisting in the design of clinical
trials. AI has already dramatically accelerated the drug discovery process, particularly in
identifying new targets and screening potential compounds. Advanced algorithms and
deep learning models have improved the accuracy of virtual screening and molecular
docking processes, helping to identify more effective therapies. However, challenges
remain in applying AI to drug development, such as the need for high-quality, unbiased
data and the interpretability of AI models.
Looking ahead, AI will play an increasingly important role in personalized medicine,
particularly in tailoring treatments based on a patient’s genetic and clinical profile. For
example, integrating AI with digital twin technologies has tremendous potential. Digital
twins (virtual representations of patients) could simulate the progression of Alzheimer’s
disease in real time, allowing researchers to test personalized treatments in a virtual
environment before implementing them in clinical practice. This combination of AI and
digital twins represents a promising frontier in the research and development of treatments
for Alzheimer’s disease.
To fully realize the potential of AI, multidisciplinary collaboration between researchers
in genetics, neuroscience, immunology, and AI will be essential. In addition, innovative
clinical trial designs, personalized medicine approaches, and the development of new
biomarkers for the early diagnosis and monitoring of disease progression are necessary. AI,
by identifying complex patterns in the interactions between biological systems such as the
gut microbiota, immune system, and neurons, could enable a deeper understanding of the
onset and progression of Alzheimer’s disease.
In conclusion, the field of Alzheimer’s disease research is rapidly evolving, with
emerging evidence on the underlying mechanisms of the disease and the potential for new
therapeutic targets. Advances in AI and personalized medicine offer exciting opportunities
for drug development and patient care. However, there are significant challenges, such
as data heterogeneity, model interpretability, and the integration of multiple biological
datasets, that need to be addressed to fully realize the potential of these technologies.
Future research should focus on translational approaches to bring promising therapies to
patients more quickly.

## Page 18 (Section: References)

Int. J. Mol. Sci. 2025, 26, 1004
18 of 25
As research progresses, fundamental biological questions remain: to what extent
can interactions between different systems, such as immune response, inflammation, and
mitochondrial dysfunction, explain the onset and progression of Alzheimer’s disease?
Could they be a viable alternative to AI?
Author Contributions: Conceptualization, J.D.-G., A.R., A.B.P.-P., S.R.-Y. and F.C.; methodology,
S.R.-Y. and F.C.; formal analysis, J.D.-G. and A.R.; investigation, J.D.-G. and A.R.; writing—original
draft preparation, J.D.-G., A.B.P.-P. and F.C.; writing—review and editing, J.D.-G., A.R. and F.C.;
funding acquisition, A.B.P.-P.; supervision F.C. All authors have read and agreed to the published
version of the manuscript.
Funding: This research received no external funding.
Acknowledgments: We are particularly grateful to CESGA (Galician Supercomputing Centre) for
providing access to their infrastructure. Additionally, we acknowledge the use of ChatGPT for
assisting in the translation of several sections and for conducting a grammar and spelling review.
Conflicts of Interest: The authors declare no conflicts of interest.
Abbreviations
The following abbreviations are used in this manuscript:
MDPI
Multidisciplinary Digital Publishing Institute
DOAJ
Directory of open access journals
TLA
Three-letter acronym
LD
Linear dichroism
AD
Alzheimer’s disease
Aβ
Amyloid-beta
ML
Machine learning
AI
Artificial intelligence
ROS
Reactive oxygen species
CNNs
Convolutional neural networks
LBVS
Ligand-based virtual screening
SVMs
Support vector machines
RFs
Random forests
ANNs
Artificial neural networks
DNNs
Deep neural networks
NLP
Natural language processing
References
1.
Teng, Z. Novel Development and Prospects in Pathogenesis, Diagnosis, and Therapy of Alzheimer’s Disease. J. Alzheimer’s Dis.
Rep. 2024, 8, 345. [CrossRef] [PubMed]
2.
Saw, A.M.; Hrastelj, J.; Robertson, N.P. Path from discovery to recovery: Therapeutic and diagnostic advances in Alzheimer’s
dementia. J. Neurol. 2023, 270, 4151–4153. [CrossRef] [PubMed]
3.
Cummings, J.; Lee, G.; Ritter, A.; Sabbagh, M.; Zhong, K. Alzheimer’s disease drug development pipeline: 2020. Alzheimer’s
Dement. Transl. Res. Clin. Interv. 2020, 6, e12050. [CrossRef] [PubMed]
4.
Monfared, A.A.T.; Tafazzoli, A.; Ye, W.; Chavan, A.; Zhang, Q. Long-Term Health Outcomes of Lecanemab in Patients with Early
Alzheimer’s Disease Using Simulation Modeling. Neurol. Ther. 2022, 11, 863–880. [CrossRef]
5.
Apátiga-Pérez, R.; Soto-Rojas, L.O.; Campa-Córdoba, B.B.; Luna-Viramontes, N.I.; Cuevas, E.; Villanueva-Fierro, I.; Ontiveros-
Torres, M.A.; Bravo-Muñoz, M.; Flores-Rodríguez, P.; Garcés-Ramirez, L.; et al. Neurovascular dysfunction and vascular amyloid
accumulation as early events in Alzheimer’s disease. Metab. Brain Dis. 2022, 37, 39–50. [CrossRef] [PubMed]
6.
Botella Lucena, P.; Heneka, M.T. Inflammatory aspects of Alzheimer’s disease. Acta Neuropathol. 2024, 148, 31. [CrossRef]
7.
Shi, M.; Chu, F.; Zhu, F.; Zhu, J. Impact of Anti-amyloid-β Monoclonal Antibodies on the Pathology and Clinical Profile of
Alzheimer’s Disease: A Focus on Aducanumab and Lecanemab. Front. Aging Neurosci. 2022, 14, 870517. [CrossRef]

## Page 19 (Section: References)

Int. J. Mol. Sci. 2025, 26, 1004
19 of 25
8.
Gholami, A.; Minai-Tehrani, D.; Eriksson, L.A. In silico and in vitro studies confirm Ondansetron as a novel acetylcholinesterase
and butyrylcholinesterase inhibitor. Sci. Rep. 2023, 13, 643. [CrossRef]
9.
Kumar, A.; Sudevan, S.T.; Nair, A.S.; Singh, A.K.; Kumar, S.; Jose, J.; Behl, T.; Mangalathillam, S.; Mathew, B.; Kim, H. Current
and future nano-carrier-based approaches in the treatment of Alzheimer’s disease. Brain Sci. 2023, 13, 213. [CrossRef]
10.
Zhang, P.; Hou, Y.; Tu, W.; Campbell, N.; Pieper, A.A.; Leverenz, J.B.; Gao, S.; Cummings, J.; Cheng, F. Population-based
discovery and Mendelian randomization analysis identify telmisartan as a candidate medicine for Alzheimer’s disease in African
Americans. Alzheimer’s Dement. 2023, 19, 1876–1887. [CrossRef]
11.
Imbimbo, B.P.; Ippati, S.; Watling, M.; Imbimbo, C. Role of monomeric amyloid-β in cognitive performance in Alzheimer’s
disease: Insights from clinical trials with secretase inhibitors and monoclonal antibodies. Pharmacol. Res. 2023, 187, 106631.
[CrossRef]
12.
Vaz, M.; Silva, V.; Monteiro, C.; Silvestre, S. Role of Aducanumab in the Treatment of Alzheimer’s Disease: Challenges and
Opportunities. Clin. Interv. Aging 2022, 17, 797–810. [CrossRef] [PubMed]
13.
Zyuzkov, G.; Miroshnichenko, L.; Chayikovskyi, A.; Kotlovskaya, L. Prospects for the Therapeutic Potential of Inhibitors
Targeting JNK and p53 in Alzheimer’s Disease. Adv. Life Sci. 2023, 10, 298–303.
14.
Jack, C.R., Jr.; Andrews, J.S.; Beach, T.G.; Buracchio, T.; Dunn, B.; Graf, A.; Hansson, O.; Ho, C.; Jagust, W.; McDade, E.; et al.
Revised criteria for diagnosis and staging of Alzheimer’s disease: Alzheimer’s Association Workgroup. Alzheimer’s Dement. 2024,
20, 5143–5169. [CrossRef] [PubMed]
15.
Bowirrat, A. Immunosenescence and Aging: Neuroinflammation Is a Prominent Feature of Alzheimer’s Disease and Is a Likely
Contributor to Neurodegenerative Disease Pathogenesis. J. Pers. Med. 2022, 12, 1817. [CrossRef] [PubMed]
16.
Zhu, Y.; Ouyang, Z.; Du, H.; Wang, M.; Wang, J.; Sun, H.; Kong, L.; Xu, Q.; Ma, H.; Sun, Y. New opportunities and challenges
of natural products research: When target identification meets single-cell multiomics. Acta Pharm. Sin. B 2022, 12, 4011–4039.
[CrossRef] [PubMed]
17.
Simões, J.L.; Sobierai, L.D.; Leal, I.F.; Santos, M.V.D.; Coiado, J.V.; Bagatini, M.D. Action of the Purinergic and Cholinergic
Anti-inflammatory Pathways on Oxidative Stress in Patients with Alzheimer’s Disease in the Context of the COVID-19 Pandemic.
Neuroscience 2023, 512, 110–132. [CrossRef] [PubMed]
18.
Chakraborty, S.; Chopra, H.; Akash, S.; Chakraborty, C.; Dhama, K. Artificial intelligence (AI) is paving the way for a critical
role in drug discovery, drug design, and studying drug–drug interactions–correspondence. Int. J. Surg. 2023, 109, 3242–3244.
[CrossRef]
19.
Blanco-Gonzalez, A.; Cabezon, A.; Seco-Gonzalez, A.; Conde-Torres, D.; Antelo-Riveiro, P.; Pineiro, A.; Garcia-Fandino, R. The
role of ai in drug discovery: Challenges, opportunities, and strategies. Pharmaceuticals 2023, 16, 891. [CrossRef]
20.
Zhang, Y.; Chen, H.; Li, R.; Sterling, K.; Song, W. Amyloid β-based therapy for Alzheimer’s disease: Challenges, successes and
future. Signal Transduct. Target. Ther. 2023, 8, 248. [CrossRef]
21.
Niazi, S.K. The coming of age of ai/ml in drug discovery, development, clinical testing, and manufacturing: The FDA perspectives.
Drug Des. Dev. Ther. 2023, 17, 2691–2725. [CrossRef] [PubMed]
22.
Palaniyandi, T.; B, K.; Prabhakaran, P.; Viswanathan, S.; Wahab, M.R.A.; Natarajan, S.; Moorthy, S.K.K.; Kumarasamy, S.
Nanosensors for the diagnosis and therapy of neurodegenerative disorders and inflammatory bowel disease. Acta Histochem.
2023, 125, 151997. [CrossRef] [PubMed]
23.
Lau, V.; Ramer, L.; Ève Tremblay, M. An aging, pathology burden, and glial senescence build-up hypothesis for late onset
Alzheimer’s disease. Nat. Commun. 2023, 14, 1670. [CrossRef] [PubMed]
24.
A˘gagündüz, D.; Kocaadam-Bozkurt, B.; Bozkurt, O.; Sharma, H.; Esposito, R.; Özo˘gul, F.; Capasso, R. Microbiota alteration and
modulation in Alzheimer’s disease by gerobiotics: The gut-health axis for a good mind. Biomed. Pharmacother. 2022, 153, 113430.
[CrossRef] [PubMed]
25.
Mehta, R.I.; Mehta, R.I. The Vascular-Immune Hypothesis of Alzheimer’s Disease. Biomedicines 2023, 11, 408. [CrossRef]
26.
Zyuz’kov, G.N.; Miroshnichenko, L.A.; Kotlovskaya, L.Y.; Chayikovskyi, A.V. Inhibitors of Intracellular Signaling Molecules:
New Horizons in Drug Discovery for the Treatment of Alzheimer’s Disease. Biointerface Res. Appl. Chem. 2023, 13, 1–11.
27.
Tamburini, B.; Badami, G.D.; Manna, M.P.L.; Azgomi, M.S.; Caccamo, N.; Dieli, F. Emerging Roles of Cells and Molecules of
Innate Immunity in Alzheimer’s Disease. Int. J. Mol. Sci. 2023, 24, 11922. [CrossRef]
28.
Wang, H.; Sun, M.; Li, W.; Liu, X.; Zhu, M.; Qin, H. Biomarkers associated with the pathogenesis of Alzheimer’s disease. Front.
Cell. Neurosci. 2023, 17, 1279046. [CrossRef]
29.
Atoki, A.V.; Aja, P.M.; Ondari, E.N.; Shinkafi, T.S. Advances in Alzheimer’s disease therapeutics: Biochemistry, exploring
bioactive compounds and novel approaches. Int. J. Food Prop. 2023, 26, 2091–2127. [CrossRef]
30.
Fang, L.; Jiao, B.; Liu, X.; Wang, Z.; Yuan, P.; Zhou, H.; Xiao, X.; Cao, L.; Guo, J.; Tang, B.; et al. Specific serum autoantibodies
predict the development and progression of Alzheimer’s disease with high accuracy. Brain Behav. Immun. 2024, 115, 543–554.
[CrossRef] [PubMed]

## Page 20 (Section: References)

Int. J. Mol. Sci. 2025, 26, 1004
20 of 25
31.
Ozsahin, I.; Onakpojeruo, E.P.; Uzun, B.; Uzun Ozsahin, D.; Butler, T.A. A Multi-Criteria Decision Aid Tool for Radiopharmaceu-
tical Selection in Tau PET Imaging. Pharmaceutics 2023, 15, 1304. [CrossRef] [PubMed]
32.
Wong-Guerra, M.; Maccioni, R.B.; Rojo, L.E. Revisiting the neuroinflammation hypothesis in Alzheimer’s disease: A focus on the
druggability of current targets. Front. Pharmacol. 2023, 14, 1161850. [CrossRef] [PubMed]
33.
Merighi, S.; Nigro, M.; Travagli, A.; Gessi, S. Microglia and Alzheimer’s Disease. Int. J. Mol. Sci. 2022, 23, 12990. [CrossRef]
[PubMed]
34.
Li, T.; Lu, L.; Pember, E.; Li, X.; Zhang, B.; Zhu, Z. New insights into neuroinflammation involved in pathogenic mechanism of
Alzheimer’s disease and its potential for therapeutic intervention. Cells 2022, 11, 1925. [CrossRef] [PubMed]
35.
Obukohwo, O.M.; Oreoluwa, O.A.; Andrew, U.O.; Williams, U.E. Microglia-mediated neuroinflammation in traumatic brain
injury: A review. Mol. Biol. Rep. 2024, 51, 1–13. [CrossRef] [PubMed]
36.
Fornari Laurindo, L.; Aparecido Dias, J.; Cressoni Araujo, A.; Torres Pomini, K.; Machado Galhardi, C.; Rucco Penteado Detre-
giachi, C.; Santos de Argollo Haber, L.; Donizeti Roque, D.; Dib Bechara, M.; Vialogo Marques de Castro, M.; et al. Immunological
dimensions of neuroinflammation and microglial activation: Exploring innovative immunomodulatory approaches to mitigate
neuroinflammatory progression. Front. Immunol. 2024, 14, 1305933. [CrossRef] [PubMed]
37.
Solanki, R.; Karande, A.; Ranganathan, P. Emerging role of gut microbiota dysbiosis in neuroinflammation and neurodegeneration.
Front. Neurol. 2023, 14, 1149618. [CrossRef] [PubMed]
38.
Koerich, S.; Parreira, G.M.; de Almeida, D.L.; Vieira, R.P.; de Oliveira, A.C.P. Receptors for advanced glycation end products
(RAGE): Promising targets aiming at the treatment of neurodegenerative conditions.
Curr. Neuropharmacol. 2023, 21, 219.
[CrossRef]
39.
San-Millán, I. The key role of mitochondrial function in health and disease. Antioxidants 2023, 12, 782. [CrossRef]
40.
Sultana, M.A.; Hia, R.A.; Akinsiku, O.; Hegde, V. Peripheral mitochondrial dysfunction: A potential contributor to the
development of metabolic disorders and Alzheimer’s disease. Biology 2023, 12, 1019. [CrossRef] [PubMed]
41.
Compagnoni, G.M.; Fonzo, A.D.; Corti, S.; Comi, G.P.; Bresolin, N.; Masliah, E. The Role of Mitochondria in Neurodegenerative
Diseases: The Lesson from Alzheimer’s Disease and Parkinson’s Disease. Mol. Neurobiol. 2020, 57, 2959–2980. [CrossRef]
[PubMed]
42.
Tassone, G.; Kola, A.; Valensin, D.; Pozzi, C. Dynamic interplay between copper toxicity and mitochondrial dysfunction in
alzheimer’s Disease. Life 2021, 11, 386. [CrossRef]
43.
Sousa, T.; Moreira, P.I.; Cardoso, S.
Current Advances in Mitochondrial Targeted Interventions in Alzheimer’s Disease.
Biomedicines 2023, 11, 2331. [CrossRef] [PubMed]
44.
Panes, J.D.; Godoy, P.A.; Silva-Grecchi, T.; Celis, M.T.; Ramirez-Molina, O.; Gavilan, J.; Muñoz-Montecino, C.; Castro, P.A.;
Moraga-Cid, G.; Yévenes, G.E.; et al. Changes in PGC-1α/SIRT1 Signaling Impact on Mitochondrial Homeostasis in Amyloid-Beta
Peptide Toxicity Model. Front. Pharmacol. 2020, 11, 709. [CrossRef]
45.
Li, Y.H.; Xu, F.; Thome, R.; Guo, M.F.; Sun, M.L.; Song, G.B.; lan Li, R.; Chai, Z.; Ciric, B.; Rostami, A.M.; et al.
Mdivi-1,
a mitochondrial fission inhibitor, modulates T helper cells and suppresses the development of experimental autoimmune
encephalomyelitis. J. Neuroinflamm. 2019, 16, 149. [CrossRef] [PubMed]
46.
Andreux, P.A.; Blanco-Bose, W.; Ryu, D.; Burdet, F.; Ibberson, M.; Aebischer, P.; Auwerx, J.; Singh, A.; Rinsch, C. The mitophagy
activator urolithin A is safe and induces a molecular signature of improved mitochondrial and cellular health in humans. Nat.
Metab. 2019, 1, 595–603. [CrossRef]
47.
Rudge, J.D. A new hypothesis for Alzheimer’s disease: The lipid invasion model. J. Alzheimer’s Dis. Rep. 2022, 6, 129–161.
[CrossRef]
48.
Stern, A.M.; Yang, Y.; Jin, S.; Yamashita, K.; Meunier, A.L.; Liu, W.; Cai, Y.; Ericsson, M.; Liu, L.; Goedert, M.; et al. Abundant
Aβ fibrils in ultracentrifugal supernatants of aqueous extracts from Alzheimer’s disease brains. Neuron 2023, 111, 2012–2020.
[CrossRef] [PubMed]
49.
Peng, L.; Bestard-Lorigados, I.; Song, W. The synapse as a treatment avenue for Alzheimer’s Disease. Mol. Psychiatry 2022,
27, 2940–2949. [CrossRef] [PubMed]
50.
Bai, R.; Guo, J.; Ye, X.Y.; Xie, Y.; Xie, T. Oxidative stress: The core pathogenesis and mechanism of Alzheimer’s disease. Ageing
Res. Rev. 2022, 77, 101619. [CrossRef]
51.
Sultana, R.; Perluigi, M.; Butterfield, D.A. Lipid peroxidation triggers neurodegeneration: A redox proteomics view into the
Alzheimer disease brain. Free Radic. Biol. Med. 2013, 62, 157–169. [CrossRef] [PubMed]
52.
Bhatt, S.; Puli, L.; Patil, C.R. Role of reactive oxygen species in the progression of Alzheimer’s disease. Drug Discov. Today 2021,
26, 794–803. [CrossRef]
53.
Jurc˘au, M.C.; Andronie-Cioara, F.L.; Jurc˘au, A.; Marcu, F.; ¸Tit,, D.M.; Pas,cal˘au, N.; Nistor-Cseppentö, D.C. The link between
oxidative stress, mitochondrial dysfunction and neuroinflammation in the pathophysiology of Alzheimer’s disease: Therapeutic
implications and future perspectives. Antioxidants 2022, 11, 2167. [CrossRef] [PubMed]

## Page 21 (Section: References)

Int. J. Mol. Sci. 2025, 26, 1004
21 of 25
54.
Eisenmenger, L.B.; Peret, A.; Famakin, B.M.; Spahic, A.; Roberts, G.S.; Bockholt, J.H.; Johnson, K.M.; Paulsen, J.S. Vascular
contributions to Alzheimer’s disease. Transl. Res. 2023, 254, 41–53. [CrossRef] [PubMed]
55.
Nagar, P.; Sharma, P.; Dhapola, R.; Kumari, S.; Medhi, B.; HariKrishnaReddy, D. Endoplasmic reticulum stress in Alzheimer’s
disease: Molecular mechanisms and therapeutic prospects. Life Sci. 2023, 330, 121983. [CrossRef] [PubMed]
56.
Qin, H.Y.; Liu, J.Y.; Fang, C.L.; Deng, Y.P.; Zhang, Y. DNA methylation: The epigenetic mechanism of Alzheimer’s disease. Ibrain
2023, 9, 463–472. [CrossRef]
57.
Chowdhury, S.G.; Ray, R.; Karmakar, P. Relating aging and autophagy: A new perspective towards the welfare of human health.
EXCLI J. 2023, 22, 732.
58.
Zhang, X.W.; Zhu, X.X.; Tang, D.S.; Lu, J.H. Targeting autophagy in Alzheimer’s disease: Animal models and mechanisms. Zool.
Res. 2023, 44, 1132. [CrossRef]
59.
Fan, Y.G.; Wu, T.Y.; Zhao, L.X.; Jia, R.J.; Ren, H.; Hou, W.J.; Wang, Z.Y. From zinc homeostasis to disease progression: Unveiling
the neurodegenerative puzzle. Pharmacol. Res. 2023, 199, 107039. [CrossRef] [PubMed]
60.
Doroszkiewicz, J.; Farhan, J.A.; Mroczko, J.; Winkel, I.; Perkowski, M.; Mroczko, B. Common and trace metals in Alzheimer’s and
Parkinson’s diseases. Int. J. Mol. Sci. 2023, 24, 15721. [CrossRef] [PubMed]
61.
Arora, S.; Santiago, J.A.; Bernstein, M.; Potashkin, J.A. Diet and lifestyle impact the development and progression of Alzheimer’s
dementia. Front. Nutr. 2023, 10, 1213223. [CrossRef] [PubMed]
62.
Schreiner, T.G.; Schreiner, O.D.; Adam, M.; Popescu, B.O. The roles of the amyloid beta monomers in physiological and
pathological conditions. Biomedicines 2023, 11, 1411. [CrossRef]
63.
Shi, H.; Zhao, Y. Modulation of Tau Pathology in Alzheimer’s Disease by Dietary Bioactive Compounds. Int. J. Mol. Sci. 2024,
25, 831. [CrossRef] [PubMed]
64.
Parra Bravo, C.; Naguib, S.A.; Gan, L. Cellular and pathological functions of tau. Nat. Rev. Mol. Cell Biol. 2024, 25, 845–864
[CrossRef]
65.
Thakur, S.; Dhapola, R.; Sarma, P.; Medhi, B.; Reddy, D.H. Neuroinflammation in Alzheimer’s disease: Current progress in
molecular signaling and therapeutics. Inflammation 2023, 46, 1–17. [CrossRef]
66.
Terada, T.; Therriault, J.; Kang, M.S.P.; Savard, M.; Pascoal, T.A.; Lussier, F.; Tissot, C.; Wang, Y.T.; Benedet, A.; Matsudaira, T.;
et al. Mitochondrial complex I abnormalities is associated with tau and clinical symptoms in mild Alzheimer’s disease. Mol.
Neurodegener. 2021, 16, 28. [CrossRef] [PubMed]
67.
Garbuz, D.; Zatsepina, O.; Evgen’ev, M. Beta amyloid, tau protein, and neuroinflammation: An attempt to integrate different
hypotheses of Alzheimer’s disease pathogenesis. Mol. Biol. 2021, 55, 670–682. [CrossRef]
68.
Deleglise, B.; Lassus, B.; Soubeyre, V.; Doulazmi, M.; Brugg, B.; Vanhoutte, P.; Peyrin, J.M. Dysregulated Neurotransmission
induces Trans-synaptic degeneration in reconstructed Neuronal Networks. Sci. Rep. 2018, 8, 11596. [CrossRef]
69.
Choi, E.H.; Kim, M.H.; Park, S.J. Targeting Mitochondrial Dysfunction and Reactive Oxygen Species for Neurodegenerative
Disease Treatment. Int. J. Mol. Sci. 2024, 25, 7952. [CrossRef]
70.
Castillo-Ordoñez, W.O.; Cajas-Salazar, N.; Velasco-Reyes, M.A. Genetic and epigenetic targets of natural dietary compounds as
anti-Alzheimer’s agents. Neural Regen. Res. 2024, 19, 846–854. [CrossRef] [PubMed]
71.
Rehman, M.U.; Sehar, N.; Dar, N.J.; Khan, A.; Arafah, A.; Rashid, S.; Rashid, S.M.; Ganaie, M.A. Mitochondrial dysfunctions,
oxidative stress and neuroinflammation as therapeutic targets for neurodegenerative diseases: An update on current advances
and impediments. Neurosci. Biobehav. Rev. 2023, 144, 104961. [CrossRef]
72.
van der Kant, R.; Goldstein, L.S.B.; Ossenkoppele, R. Amyloid-β-independent regulators of tau pathology in Alzheimer disease.
Nat. Rev. Neurosci. 2020, 21, 21–35. [CrossRef]
73.
Tan, X.; Liang, Z.; Li, Y.; Zhi, Y.; Yi, L.; Bai, S.; Forest, K.H.; Nichols, R.A.; Dong, Y.; Li, Q.X. Isoorientin, a GSK-3β inhibitor, rescues
synaptic dysfunction, spatial memory deficits and attenuates pathological progression in APP/PS1 model mice. Behav. Brain Res.
2021, 398, 112968. [CrossRef]
74.
Medrano-Jiménez, E.; Meza-Sosa, K.F.; Urbán-Aragón, J.A.; Secundino, I.; Pedraza-Alva, G.; Pérez-Martínez, L. Microglial
activation in Alzheimer’s disease: The role of flavonoids and microRNAs. J. Leukoc. Biol. 2022, 112, 47–77. [CrossRef]
75.
Ozben, T.; Ozben, S. Neuro-inflammation and anti-inflammatory treatment options for Alzheimer’s disease. Clin. Biochem. 2019,
72, 87–89. [CrossRef]
76.
Greenhalgh, A.D.; David, S.; Bennett, F.C. Immune cell regulation of glia during CNS injury and disease. Nat. Rev. Neurosci. 2020,
21, 139–152. [CrossRef] [PubMed]
77.
Walker, K.A.; Le Page, L.M.; Terrando, N.; Duggan, M.R.; Heneka, M.T.; Bettcher, B.M. The role of peripheral inflammatory
insults in Alzheimer’s disease: A review and research roadmap. Mol. Neurodegener. 2023, 18, 37. [CrossRef]
78.
Dailah, H.G. Potential of Therapeutic Small Molecules in Apoptosis Regulation in the Treatment of Neurodegenerative Diseases:
An Updated Review. Molecules 2022, 27, 7207. [CrossRef] [PubMed]

## Page 22 (Section: References)

Int. J. Mol. Sci. 2025, 26, 1004
22 of 25
79.
Foiadelli, T.; Santangelo, A.; Costagliola, G.; Costa, E.; Scacciati, M.; Riva, A.; Volpedo, G.; Smaldone, M.; Bonuccelli, A.;
Clemente, A.M.; et al. Neuroinflammation and status epilepticus: A narrative review unraveling a complex interplay. Front.
Pediatr. 2023, 11, 1251914. [CrossRef] [PubMed]
80.
Zhang, X.; Wang, Z.; Zheng, Y.; Yu, Q.; Zeng, M.; Bai, L.; Yang, L.; Guo, M.; Jiang, X.; Gan, J. Inhibitors of the NLRP3 inflammasome
pathway as promising therapeutic candidates for inflammatory diseases. Int. J. Mol. Med. 2023, 51, 35. [CrossRef]
81.
Reiss, A.B.; Gulkarov, S.; Jacob, B.; Srivastava, A.; Pinkhasov, A.; Gomolin, I.H.; Stecker, M.M.; Wisniewski, T.; De Leon, J.
Mitochondria in Alzheimer’s Disease Pathogenesis. Life 2024, 14, 196. [CrossRef] [PubMed]
82.
Aran, K.R. Mitochondrial dysfunction and oxidative stress in Alzheimer’s disease—A step towards mitochondria based
therapeutic strategies. Aging Health Res. 2023, 3, 100169. [CrossRef]
83.
Peggion, C.; Calì, T.; Brini, M. Mitochondria Dysfunction and Neuroinflammation in Neurodegeneration: Who Comes First?
Antioxidants 2024, 13, 240. [CrossRef] [PubMed]
84.
Galizzi, G.; Di Carlo, M. Mitochondrial DNA and Inflammation in Alzheimer’s Disease. Curr. Issues Mol. Biol. 2023, 45, 8586–8606.
[CrossRef]
85.
Seo, D.-O.; Holtzman, D.M. Current understanding of the Alzheimer’s disease-associated microbiome and therapeutic strategies.
Exp. Mol. Med. 2024, 56, 86–94. [CrossRef] [PubMed]
86.
Li, J.; Han, X.; Qin, Y.; Tan, F.; Chen, Y.; Wang, Z.; Song, H.; Zhou, X.; Zhang, Y.; Hu, L.; et al. Artificial intelligence accelerates
multi-modal biomedical process: A Survey. Neurocomputing 2023, 558, 126720. [CrossRef]
87.
Saoud, L.S.; AlMarzouqi, H. Explainable early detection of Alzheimer’s disease using ROIs and an ensemble of 138 3D vision
transformers. Sci. Rep. 2024, 14, 27756. [CrossRef] [PubMed]
88.
Yang, X.; Hong, K.; Zhang, D.; Wang, K. Early diagnosis of Alzheimer’s Disease based on multi-attention mechanism. PLoS ONE
2024, 19, e0310966. [CrossRef]
89.
Vrahatis, A.G.; Skolariki, K.; Krokidis, M.G.; Lazaros, K.; Exarchos, T.P.; Vlamos, P. Revolutionizing the early detection of
Alzheimer’s disease through non-invasive biomarkers: The role of artificial intelligence and deep learning. Sensors 2023, 23, 4184.
[CrossRef]
90.
Obaido, G.; Mienye, I.D.; Egbelowo, O.F.; Emmanuel, I.D.; Ogunleye, A.; Ogbuokiri, B.; Mienye, P.; Aruleba, K. Supervised
machine learning in drug discovery and development: Algorithms, applications, challenges, and prospects. Mach. Learn. Appl.
2024, 17, 100576. [CrossRef]
91.
Monyai, K. Unsupervised Learning Approach to Quality Control of Proteomics Studies. Ph.D. Thesis, School of Computer
Science and Applied Mathematics, Faculty of Science, University of the Witwatersrand, Johannesburg, South Africa, 2023.
92.
Terranova, N.; Venkatakrishnan, K. Machine Learning in Modeling Disease Trajectory and Treatment Outcomes: An Emerging
Enabler for Model-Informed Precision Medicine. Clin. Pharmacol. Ther. 2024, 115, 720–726. [CrossRef] [PubMed]
93.
Pedregosa, F.; Varoquaux, G.; Gramfort, A.; Michel, V.; Thirion, B.; Grisel, O.; Blondel, M.; Prettenhofer, P.; Weiss, R.; Dubourg, V.;
et al. Scikit-learn: Machine Learning in Python. J. Mach. Learn. Res. 2011, 12, 2825–2830.
94.
Prieto, A.; Prieto, B.; Ortigosa, E.M.; Ros, E.; Pelayo, F.; Ortega, J.; Rojas, I. Neural networks: An overview of early research,
current frameworks and new challenges. Neurocomputing 2016, 214, 242–268. [CrossRef]
95.
Namat¯evs, I. Deep convolutional neural networks: Structure, feature extraction and training. Inf. Technol. Manag. Sci. 2017,
20, 40–47. [CrossRef]
96.
Vázquez, J.; López, M.; Gibert, E.; Herrero, E.; Luque, F.J. Merging ligand-based and structure-based methods in drug discovery:
An overview of combined virtual screening approaches. Molecules 2020, 25, 4723. [CrossRef] [PubMed]
97.
Ahmed, S.F.; Alam, M.S.B.; Hassan, M.; Rozbu, M.R.; Ishtiak, T.; Rafa, N.; Mofijur, M.; Shawkat Ali, A.; Gandomi, A.H.
Deep learning modelling techniques: Current progress, applications, advantages, and challenges. Artif. Intell. Rev. 2023, 56,
13521–13617. [CrossRef]
98.
Varadi, M.; Anyango, S.; Deshpande, M.; Nair, S.; Natassia, C.; Yordanova, G.; Yuan, D.; Stroe, O.; Wood, G.; Laydon, A.;
et al. AlphaFold Protein Structure Database: Massively expanding the structural coverage of protein-sequence space with
high-accuracy models. Nucleic Acids Res. 2022, 50, D439–D444. [CrossRef] [PubMed]
99.
Gayathiri, E.; Prakash, P.; Kumaravel, P.; Jayaprakash, J.; Ragunathan, M.G.; Sankar, S.; Pandiaraj, S.; Thirumalaivasan, N.;
Thiruvengadam, M.; Govindasamy, R. Computational approaches for modeling and structural design of biological systems: A
comprehensive review. Prog. Biophys. Mol. Biol. 2023, 185, 17–32. [CrossRef]
100. Bandini, S.; Manzoni, S.; Vizzari, G. Agent based modeling and simulation: An informatics perspective. J. Artif. Soc. Soc. Simul.
2009, 12, 4.
101. Jordan, M.I.; Weiss, Y. Graphical models: Probabilistic inference. In The Handbook of Brain Theory and Neural Networks; MIT Press:
Cambridge, MA, USA, 2002; pp. 490–496.
102. Hirschberg, J.; Manning, C.D. Advances in natural language processing. Science 2015, 349, 261–266. [CrossRef]
103. Anikwe, C.V.; Nweke, H.F.; Ikegwu, A.C.; Egwuonwu, C.A.; Onu, F.U.; Alo, U.R.; Teh, Y.W. Mobile and wearable sensors for
data-driven health monitoring system: State-of-the-art and future prospect. Expert Syst. Appl. 2022, 202, 117362. [CrossRef]

## Page 23 (Section: References)

Int. J. Mol. Sci. 2025, 26, 1004
23 of 25
104. Deng, L. Three classes of deep learning architectures and their applications: A tutorial survey. APSIPA Trans. Signal Inf. Process.
2012, 57, 58.
105. Vincenzi, M.; Mercurio, F.A.; Leone, M. Virtual Screening of Peptide Libraries: The Search for Peptide-Based Therapeutics Using
Computational Tools. Int. J. Mol. Sci. 2024, 25, 1798. [CrossRef]
106. Hurtle, B.T.; Jana, S.; Cai, L.; Pike, V.W. Ligand-Based Virtual Screening as a Path to New Chemotypes for Candidate PET
Radioligands for Imaging Tauopathies. J. Med. Chem. 2024, 67, 14095–14109. [CrossRef] [PubMed]
107. da Rocha, M.N.; de Sousa, D.S.; da Silva Mendes, F.R.; Dos Santos, H.S.; Marinho, G.S.; Marinho, M.M.; Marinho, E.S. Ligand and
structure-based virtual screening approaches in drug discovery: Minireview. Mol. Divers. 2024, Epub ahead of print. [CrossRef]
108. Kumar, V.; Banerjee, A.; Roy, K. Machine learning-based q-RASAR approach for the in silico identification of novel multi-target
inhibitors against Alzheimer’s disease. Chemom. Intell. Lab. Syst. 2024, 245, 105049. [CrossRef]
109. Kabir, A.; Bhattarai, M.; Peterson, S.; Najman-Licht, Y.; Rasmussen, K.Ø.; Shehu, A.; Bishop, A.R.; Alexandrov, B.; Usheva, A. DNA
breathing integration with deep learning foundational model advances genome-wide binding prediction of human transcription
factors. Nucleic Acids Res. 2024, 52, e91. [CrossRef] [PubMed]
110. RadhaMahendran, S.; Dogra, A.; Mendhe, D.; Babu, S.B.T.; Dixit, S.; Singh, S.P. Machine Learning for Drug Discovery: Predicting
Drug-Protein Binding Affinities using Graph Convolutional Networks. In Proceedings of the 2024 5th International Conference
on Recent Trends in Computer Science and Technology (ICRTCST), Jamshedpur, India, 9–10 April 2024; IEEE: Piscataway, NJ,
USA, 2024; pp. 87–92.
111. Latosi´nska, M.; Latosi´nska, J.N. Serine/Threonine Protein Kinases as Attractive Targets for Anti-Cancer Drugs—An Innova-
tive Approach to Ligand Tuning Using Combined Quantum Chemical Calculations, Molecular Docking, Molecular Dynamic
Simulations, and Network-like Similarity Graphs. Molecules 2024, 29, 3199. [CrossRef] [PubMed]
112. Prajapati, V.; Verma, M.; Kumar, G.S.; Patel, J. High-Throughput Preclinical Models and Pharmacoproteomics. In Pharmacopro-
teomics: Recent Trends and Applications; Springer: Cham, Switzerland, 2024; pp. 429–468.
113. Fadahunsi, A.A.; Uzoeto, H.O.; Okoro, N.O.; Cosmas, S.; Durojaye, O.A.; Odiba, A.S. Revolutionizing drug discovery: An
AI-powered transformation of molecular docking. Med. Chem. Res. 2024, 33, 2187–2203. [CrossRef]
114. Abramson, J.; Adler, J.; Dunger, J.; Evans, R.; Green, T.; Pritzel, A.; Ronneberger, O.; Willmore, L.; Ballard, A.J.; Bambrick, J.; et al.
Accurate structure prediction of biomolecular interactions with AlphaFold 3. Nature 2024, 630, 493–500. [CrossRef] [PubMed]
115. Chen, L.; Li, Q.; Nasif, K.F.A.; Xie, Y.; Deng, B.; Niu, S.; Pouriyeh, S.; Dai, Z.; Chen, J.; Xie, C.Y. AI-Driven Deep Learning
Techniques in Protein Structure Prediction. Int. J. Mol. Sci. 2024, 25, 8426. [CrossRef] [PubMed]
116. Wang, Z.; Wang, S.; Li, Y.; Guo, J.; Wei, Y.; Mu, Y.; Zheng, L.; Li, W. A new paradigm for applying deep learning to protein–ligand
interaction prediction. Briefings Bioinform. 2024, 25, bbae145. [CrossRef]
117. Shim, H.; Allen, J.E.; Bennett, W.D. Enhancing Docking Accuracy with PECAN2, a 3D Atomic Neural Network Trained without
Co-Complex Crystal Structures. Mach. Learn. Knowl. Extr. 2024, 6, 642–657. [CrossRef]
118. Tran-Nguyen, V.K.; Camproux, A.C.; Taboureau, O. ClassyPose: A Machine-Learning Classification Model for Ligand Pose
Selection Applied to Virtual Screening in Drug Discovery. Adv. Intell. Syst. 2024, 6, 2400238. [CrossRef]
119. Nasb, M.; Tao, W.; Chen, N. Alzheimer’s disease puzzle: Delving into pathogenesis hypotheses. Aging Dis. 2024, 15, 43.
120. Salas-Nuñez, L.F.; Barrera-Ocampo, A.; Caicedo, P.A.; Cortes, N.; Osorio, E.H.; Villegas-Torres, M.F.; González Barrios, A.F.
Machine Learning to Predict Enzyme–Substrate Interactions in Elucidation of Synthesis Pathways: A Review. Metabolites 2024,
14, 154. [CrossRef]
121. Shang, J.; Xu, A.; Bi, M.; Zhang, Y.; Li, F.; Liu, J.X. A review: Simulation tools for genome-wide interaction studies. Briefings Funct.
Genom. 2024, 23, 745–753. [CrossRef] [PubMed]
122. Antelmi, A.; Caramante, P.; Cordasco, G.; D’Ambrosio, G.; De Vinco, D.; Foglia, F.; Postiglione, L.; Spagnuolo, C. Reliable and
Efficient Agent-Based Modeling and Simulation. J. Artif. Soc. Soc. Simul. 2024, 27, 4. [CrossRef]
123. Raber, J.; Pittman-Polletta, B.R.; Rastmanesh, R. Novel applications of Bayesian and other models in translational neuroscience.
Front. Neurosci. 2024, 18, 1373633. [CrossRef]
124. ClinicalTrials.gov.
Study of Personalized Treatment in Alzheimer’s Disease:
NCT06199193.
2025.
Available on-
line: https://clinicaltrials.gov/study/NCT06199193?cond=Alzheimer%20Disease&term=personalized%20treatment%20%2
6%20aI&rank=1 (accessed on 17 January 2025).
125. ClinicalTrials.gov.
Study of Personalized Treatment in Alzheimer’s Disease:
NCT06298474.
2025.
Available on-
line: https://clinicaltrials.gov/study/NCT06298474?cond=Alzheimer%20Disease&term=personalized%20treatment%20%2
6%20aI&rank=2 (accessed on 17 January 2025).
126. Segura, L.; Santos, N.; Flores, R.; Sikazwe, D.; McGibbon, M.; Blay, V.; Cheng, K.H. Exploring Tau Fibril-Disaggregating and
Antioxidating Molecules Binding to Membrane-Bound Amyloid Oligomers Using Machine Learning-Enhanced Docking and
Molecular Dynamics. Molecules 2024, 29, 2818. [CrossRef] [PubMed]
127. Tosca, E.M.; De Carlo, A.; Ronchi, D.; Magni, P. Model-informed reinforcement learning for enabling precision dosing via
adaptive dosing. Clin. Pharmacol. Ther. 2024, 116, 619–636. [CrossRef]

## Page 24 (Section: References)

Int. J. Mol. Sci. 2025, 26, 1004
24 of 25
128. Bordukova, M.; Makarov, N.; Rodriguez-Esteban, R.; Schmich, F.; Menden, M.P. Generative artificial intelligence empowers
digital twins in drug discovery and clinical trials. Expert Opin. Drug Discov. 2024, 19, 33–42. [CrossRef] [PubMed]
129. Koch, E.; Pardiñas, A.F.; O’Connell, K.S.; Selvaggi, P.; Collados, J.C.; Babic, A.; Marshall, S.E.; Van der Eycken, E.; Angulo, C.;
Lu, Y.; et al. How real-world data can facilitate the development of precision medicine treatment in psychiatry. Biol. Psychiatry
2024, 96, 543–551. [CrossRef] [PubMed]
130. Casotti, M.C.; Meira, D.D.; Zetum, A.S.S.; Campanharo, C.V.; da Silva, D.R.C.; Giacinti, G.M.; da Silva, I.M.; Moura, J.A.D.;
Barbosa, K.R.M.; Altoé, L.S.C.; et al. Integrating frontiers: A holistic, quantum and evolutionary approach to conquering cancer
through systems biology and multidisciplinary synergy. Front. Oncol. 2024, 14, 1419599. [CrossRef] [PubMed]
131. Jakubowski, H.V.; Agnew, H.; Jardine, B.; Sauro, H.M.
Use of interactive mathematical simulations in fundamentals of
biochemistry, a LibreText online educational resource, to promote understanding of dynamic reactions. Biochem. Mol. Biol. Educ.
2024, 52, 426–435. [CrossRef] [PubMed]
132. Hsiao, Y.C.; Dutta, A. Network Modeling and Control of Dynamic Disease Pathways, Review and Perspectives. IEEE/ACM Trans.
Comput. Biol. Bioinform. 2024, 21, 1211–1230. [CrossRef]
133. Ferrara, E. Large Language Models for Wearable Sensor-Based Human Activity Recognition, Health Monitoring, and Behavioral
Modeling: A Survey of Early Trends, Datasets, and Challenges. Sensors 2024, 24, 5045. [CrossRef] [PubMed]
134. Lyall, D.M.; Kormilitzin, A.; Lancaster, C.; Sousa, J.; Petermann-Rocha, F.; Buckley, C.; Harshfield, E.L.; Iveson, M.H.; Madan, C.R.;
McArdle, R.; et al. Artificial intelligence for dementia—Applied models and digital health. Alzheimer’s Dement. 2023, 19, 5872–5884.
[CrossRef]
135. Kale, M.B.; Wankhede, N.L.; Pawar, R.S.; Ballal, S.; Kumawat, R.; Goswami, M.; Khalid, M.; Taksande, B.G.; Upaganlawar, A.B.;
Umekar, M.J.; et al. AI-Driven Innovations in Alzheimer’s Disease: Integrating Early Diagnosis, Personalized Treatment, and
Prognostic Modelling. Ageing Res. Rev. 2024, 101, 102497. [CrossRef]
136. Muurling, M.; de Boer, C.; Kozak, R.; Religa, D.; Koychev, I.; Verheij, H.; Nies, V.J.; Duyndam, A.; Sood, M.; Fröhlich, H.; et al.
Remote monitoring technologies in Alzheimer’s disease: Design of the RADAR-AD study. Alzheimer’s Res. Ther. 2021, 13, 89.
[CrossRef] [PubMed]
137. Grammatikopoulou, M.; Lazarou, I.; Alepopoulos, V.; Mpaltadoros, L.; Oikonomou, V.P.; Stavropoulos, T.G.; Nikolopoulos, S.;
Kompatsiaris, I.; Tsolaki, M. Assessing the cognitive decline of people in the spectrum of AD by monitoring their activities of
daily living in an IoT-enabled smart home environment: A cross-sectional pilot study. Front. Aging Neurosci. 2024, 16, 1375131.
[CrossRef] [PubMed]
138. Shanmuga Sundari, M.; Penthala, H.R.; Mogullapalli, A.; Ammangatambu, M.M. AI-Based Personalized Drug Treatment.
In Artificial Intelligence and Machine Learning in Drug Design and Development; Scrivener Publishing: Austin, TX, USA, 2024;
pp. 369–406.
139. Batra, P.; Dave, D.M. Revolutionizing healthcare platforms: The impact of AI on patient engagement and treatment efficacy. Int. J.
Sci. Res. 2024, 13, 613–624.
140. Das, S.; Goyal, A.; Chauhan, A.; Sharma, D.; Haque, A.; Das, M.K. Artificial Intelligence Transforming Pharma Industry-Improving
Healthcare. Int. J. Pharm. Res. 2021, 13, 603.
141. Puente-Castro, A.; Fernandez-Blanco, E.; Pazos, A.; Munteanu, C.R. Automatic assessment of Alzheimer’s disease diagnosis
based on deep learning techniques. Comput. Biol. Med. 2020, 120, 103764. [CrossRef]
142. Fu’adah, Y.N.; Wijayanto, I.; Pratiwi, N.; Taliningsih, F.; Rizal, S.; Pramudito, M. Automated classification of Alzheimer’s disease
based on MRI image processing using convolutional neural network (CNN) with AlexNet architecture. J. Phys. Conf. Ser. 2021,
1844, 012020. [CrossRef]
143. Agarwal, D. DEEP-AD: The Deep Learning Model for Diagnostic Classification and Prognostic Prediction of Alzheimer’s Disease.
Ph.D. Thesis, Universidad de Valladolid, Valladolid, Spain, 2023.
144. Etekochay, M.O.; Amaravadhi, A.R.; González, G.V.; Atanasov, A.G.; Matin, M.; Mofatteh, M.; Steinbusch, H.W.; Tesfaye, T.;
Praticò, D. Unveiling new strategies facilitating the implementation of artificial intelligence in neuroimaging for the early
detection of Alzheimer’s disease. J. Alzheimer’s Dis. 2024, 99, 1–20. [CrossRef]
145. Tu, Z.; Bhattacharya, P. Fast Training of a Convolutional Neural Network for Brain MRI Classification. In Proceedings of the 2019
ACM Southeast Conference, ACMSE ’19, New York, NY, USA, 18–20 April 2019; pp. 218–221. [CrossRef]
146. Manickam, P.; Mariappan, S.A.; Murugesan, S.M.; Hansda, S.; Kaushik, A.; Shinde, R.; Thipperudraswamy, S. Artificial
intelligence (AI) and internet of medical things (IoMT) assisted biomedical systems for intelligent healthcare. Biosensors 2022,
12, 562. [CrossRef]
147. Kim, J.S.; Han, J.W.; Bae, J.B.; Moon, D.G.; Shin, J.; Kong, J.E.; Lee, H.; Yang, H.W.; Lim, E.; Kim, J.Y.; et al. Deep learning-based
diagnosis of Alzheimer’s disease using brain magnetic resonance images: An empirical study. Sci. Rep. 2022, 12, 18007. [CrossRef]
148. Najjar, R. Redefining radiology: A review of artificial intelligence integration in medical imaging. Diagnostics 2023, 13, 2760.
[CrossRef]

## Page 25 (Section: References)

Int. J. Mol. Sci. 2025, 26, 1004
25 of 25
149. Gou, F.; Liu, J.; Xiao, C.; Wu, J. Research on artificial-intelligence-assisted medicine: A survey on medical artificial intelligence.
Diagnostics 2024, 14, 1472. [CrossRef]
150. Damodaran, N. Automated segmentation of hippocampal volume: The next step in neuroradiologic diagnosis of mesial temporal
sclerosis. AJNR Am. J. Neuroradiol. 2019, 40, E38. [CrossRef] [PubMed]
Disclaimer/Publisher’s Note: The statements, opinions and data contained in all publications are solely those of the individual
author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to
people or property resulting from any ideas, methods, instructions or products referred to in the content.
