# Evaluating the role of large language models in traditional Chinese medicine diagnosis and treatment recommendations

- **Authors:** Yu Liu, Yishan Yuan, Keming Yan, Yuanyuan Li, Valeria Sacca, Sierra Hodges, Mattia Cannistra, Pauline Jeong, Jiani Wu, Jian Kong
- **Issuer:** NPJ digital medicine
- **Type:** Scientific article
- **Published:** 2025-07-21
- **Language:** en
- **DOI:** 10.1038/s41746-025-01845-2
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40691277/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractDigital health technologies hold significant potential for reducing global healthcare disparities. Large language models (LLMs) offer new opportunities to enhance access to culturally specific healthcare, including traditional Chinese medicine (TCM). This study evaluated the diagnostic and treatment performance of seven publicly available LLMs using a real-world acupuncture case, comparing their outputs with three professional acupuncturists across five domains: Western diagnosis, TCM diagnosis, acupoint selection, needling technique, and herbal medicine. Twenty-eight expert evaluators from China, South Korea, and the United States assessed the responses using a multilingual survey. LLMs performed comparably to acupuncturists in Western diagnosis and showed variable performance in TCM-specific tasks. GPT-4o, Qwen 2.5 Max, and Doubao 1.5 Pro demonstrated the highest alignment with expert evaluations, particularly in TCM diagnosis and acupoint selection. These findings highlight the potential of general-purpose LLMs to support culturally grounded medical decision-making and reduce access barriers in TCM care systems.Subject terms: Computational biology and bioinformatics, Health care, Medical research

## Section: Introduction

Traditional Chinese Medicine (TCM) offers therapeutic approaches through herbal medicine, acupuncture, and Qigong to support neurological disorders1,2, mental health3,4, pain relief5,6, women’s health and fertility7,8, cancer care9,10, chronic conditions11,12, disease prevention13,14, and overall wellness15,16. These approaches emphasize personalized treatment based on individual patient assessment, syndrome differentiation17, and many other disorders/conditions. However, global adoption of TCM faces significant barriers. Its philosophical foundations, such as Yin-Yang balance18, five elements, and Qi flow19, are deeply rooted in Chinese philosophy, making them difficult to translate into global and modern scientific biomedical models20. Additionally, the diagnostic approach in TCM also differs significantly from modern Western medicine; while Western protocols typically follow standardized pathways, TCM adopts a more personalized and nonlinear diagnosis approach21. These philosophical and methodological differences create substantial and fundamental cultural and systemic barriers to global reach and adoption of TCM, affecting broader health equity. Populations unfamiliar with the cultural context of TCM struggle to fully understand and trust its practices, limiting their access to its potential benefits. Addressing these cultural disparities is essential for transforming TCM into a globally inclusive healthcare option.

Recent advances in digital health technologies, particularly large language models (LLMs), present an innovative opportunity for making TCM more globally accessible22–25. LLMs have proven valuable in clinical decision support, diagnostics, and medical documentation26–29, while also playing an expanding role in medical education30–32. Furthermore, their multilingual capabilities and adaptability enable more inclusive digital health solutions, ensuring accessibility for diverse populations through culturally and linguistically tailored applications33,34. However, the use of LLMs for TCM presents unique challenges due to its complex philosophical and linguistic nuances. For example, adapting LLMs to TCM-specific tasks such as syndrome differentiation, acupuncture point selection, and herbal medicine recommendations, require LLMs to bridge significant cultural and theoretical gaps35. Thus, successfully integrating LLMs into TCM practice demands not only technological advancements but also a deeper understanding of cross-cultural medical translation capabilities.

This study aims to evaluate the performance of LLMs in diagnosing and recommending treatments for a complex real-world acupuncture case study by comparing the performance of seven general-purpose LLMs with professional acupuncturists. Specifically, we test three hypotheses: (1) can LLMs provide Western and TCM diagnoses consistent with the assessments from professional acupuncturists, (2) can LLMs recommend appropriate acupuncture points and techniques, and (3) can LLMs suggest suitable herbal medicine combinations. As a pilot benchmarking effort, this study provides foundational insights into the capabilities and limitations of LLMs within culturally embedded medical systems such as TCM. By exploring how scalable AI tools can bridge linguistic, cultural, and geographic gaps in medical knowledge delivery, our findings underscore the potential of LLMs to promote digital health equity and expand global access to culturally rooted care.

## Section: Results

Demographic and professional characteristics of expert evaluators

Comparative performance of LLMs and professional acupuncturists across five evaluation domains

Pairwise comparisons of LLMs and professional acupuncturists using Tukey’s HSD test

Violin plots show score distributions for seven LLMs and three licensed acupuncturists across five domains: Western diagnosis, TCM diagnosis, acupoint selection, needling technique, and herbal medicine. Scores were rated by 28 blinded TCM experts using a 5-point Likert scale. LLM large language model, TCM Traditional Chinese Medicine.

Proportion of high-scoring recommendations (≥4) across evaluation domains

## Section: Results › Evaluator characteristics

A total of 28 evaluators participated in the study, with the majority being female (71.43%) and most falling within the 31~40 age group (42.86%). A significant proportion (85.71%) had active clinical practice experience. Geographically, evaluators were primarily from China (64.29%), followed by the United States (21.43%) and South Korea (14.29%). In terms of education, most held a Doctorate Degree (75.00%), while others had postdoctoral training (10.71%), a master’s degree (7.14%), or a bachelor’s degree (7.14%). Academic titles varied, with 25.00% as Full Professors/Chief Physicians, 25.00% serving as Associate Professors/Associate Chief Physicians, 17.86% as Assistant Professors/Attending Physicians, 10.71% as Lecturers/Instructors/Residents, and 7.14% as Postdoctoral Fellows. These characteristics reflect a diverse and experienced group of evaluators. These demographic details are summarized in Table 1.

Demographic and professional characteristics of expert evaluators

## Section: Results › Performance comparison in Western medical diagnosis accuracy

The ANOVA analysis showed no significant differences in Western medical diagnosis performance across groups (p = 0.953), indicating that all LLMs demonstrated capabilities comparable to professional acupuncturists. The mean scores (±standard deviation) for each source were: Gemini (4.36 ± 0.87), GPT (4.25 ± 0.80), Qwen (4.14 ± 1.30), Acupuncturist 1 (4.14 ± 1.27), Acupuncturist 3 (4.11 ± 1.31), Acupuncturist 2 (4.04 ± 1.45), LLaMA (4.00 ± 1.28), Claude (4.00 ± 1.05), Doubao (4.00 ± 1.31), and ERNIE (3.89 ± 1.26). These results suggest that all evaluated LLMs performed at levels statistically indistinguishable from human acupuncturists in Western medical diagnostic assessments. All detailed performance results are summarized in Table 2, Table 3, Fig. 1.

Comparative performance of LLMs and professional acupuncturists across five evaluation domains

Pairwise comparisons of LLMs and professional acupuncturists using Tukey’s HSD test

Violin plots show score distributions for seven LLMs and three licensed acupuncturists across five domains: Western diagnosis, TCM diagnosis, acupoint selection, needling technique, and herbal medicine. Scores were rated by 28 blinded TCM experts using a 5-point Likert scale. LLM large language model, TCM Traditional Chinese Medicine.

## Section: Results › Performance comparison in TCM diagnosis accuracy

The ANOVA analysis showed significant differences in TCM diagnosis performance across groups (p = 0.008). The ranking was as follows: Acupuncturist 3 (4.21 ± 0.92) > Acupuncturist 1 = Acupuncturist 2 (4.14 ± 0.89, 4.14 ± 1.15) > Qwen (3.93 ± 1.05) > LLaMA (3.57 ± 1.23) > GPT = ERNIE = Doubao (3.54 ± 1.17, 3.54 ± 1.29, 3.54 ± 1.10) > Claude (3.46 ± 1.17) > Gemini (3.21 ± 1.42). Pairwise comparisons revealed that Gemini scored significantly lower than Acupuncturist 3 (p = 0.04). No significant differences were observed between the LLMs and other professional acupuncturists.

## Section: Results › Performance comparison in acupoint selection appropriateness

The ANOVA analysis revealed significant differences in acupoint selection performance across groups (p < 0.001). The ranking from highest to lowest scores was as follows: Acupuncturist 1 (4.25 ± 0.70) > Acupuncturist 2 (4.07 ± 0.90) > Qwen (3.89 ± 0.83) > GPT (3.82 ± 0.72) > Acupuncturist 3 (3.75 ± 0.80) > Doubao (3.50 ± 0.79) > Claude (3.21 ± 1.10) > LLaMA = ERNIE (3.14 ± 1.08) > Gemini (3.04 ± 1.07). Pairwise comparisons showed that Qwen and GPT significantly outperformed Gemini (p = 0.02 and p = 0.05, respectively). Qwen, GPT, and Doubao exhibited no statistically significant differences across comparisons with Acupuncturists 1, 2, or 3 (all p > 0.05).

## Section: Results › Performance comparison in needling technique practicability

The ANOVA analysis showed significant differences in needling technique performance across groups (p < 0.001). From highest to lowest scores, the ranking was as follows: Acupuncturist 1 (4.04 ± 0.79) > Acupuncturist 2 (3.86 ± 1.18) > Acupuncturist 3 (3.75 ± 0.70) > GPT (3.71 ± 0.81) > Doubao (3.68 ± 0.90) > Qwen (3.43 ± 1.14) > ERNIE (3.36 ± 1.06) > Gemini (3.14 ± 1.01) > LLaMA (3.04 ± 1.20) > Claude (2.93 ± 1.05). Pairwise comparisons revealed no statistically significant differences among the LLMs (p > 0.05). Similarly, no significant differences were found between GPT, Doubao, Qwen, ERNIE and any of the three acupuncturists (p > 0.05).

## Section: Results › Performance comparison in herbal prescription suitability

The ANOVA analysis revealed significant differences in herbal medicine recommendations across groups (p = 0.001). The ranking from highest to lowest score was as follows: Acupuncturist 2 (4.07 ± 1.02) = Acupuncturist 3 (4.07 ± 0.77) > Acupuncturist 1 (3.39 ± 0.92) > Qwen (3.36 ± 1.19) = LLaMA (3.36 ± 0.99) > Doubao (3.32 ± 0.98) > GPT (3.29 ± 1.15) > ERNIE (3.25 ± 1.08) > Gemini (3.07 ± 1.41) > Claude (3.04 ± 1.14). Pairwise comparisons revealed no statistically significant differences among the LLMs (p > 0.05). Acupuncturist 2 and Acupuncturist 3 demonstrated statistically comparable performance to Qwen, LLaMA, Doubao, GPT, and ERNIE (all p > 0.05) but significantly outperformed Gemini and Claude (all p < 0.05).

## Section: Results › Overall diagnostic and treatment performance evaluation

The ANOVA analysis revealed significant differences in overall performance across groups (p = 0.002). From highest to lowest total score, the performance ranking was as follows: Acupuncturist 2 (20.18 ± 4.23) > Acupuncturist 1 (19.96 ± 2.94) > Acupuncturist 3 (19.89 ± 3.24) > Qwen (18.75 ± 4.27) > GPT (18.61 ± 3.80) > Doubao (18.04 ± 3.94) > ERNIE (17.18 ± 4.97) > LLaMA (17.11 ± 4.76) > Gemini (16.82 ± 4.75) > Claude (16.64 ± 4.46). However, pairwise comparisons using Tukey’s HSD indicated no statistically significant differences between LLMs and the acupuncturists, except for the comparison between Claude and Acupuncturist 2 (p = 0.05).

## Section: Results › High-scoring ratio across LLMs and acupuncturists

The proportions/ratios of high-scoring recommendations (≥4) across all evaluators reveal notable performance differences between LLMs and acupuncturists across various evaluation criteria (Table 4). In Western medical diagnosis, acupuncturists achieved high-score ratios ranging from 78.6% to 82.1%, LLMs varied between 67.9% and 82.1%, with Gemini performing best (82.1%). For TCM diagnosis, acupuncturists demonstrated high-score ratios from 78.6% to 85.7%, while LLMs exhibited greater variability (42.9% to 75.0%), with Qwen leading among LLMs (75.0%). In acupoint selection, the proportions of acupuncturists ranged from 53.6% and 85.7%, LLMs ranged from 32.1% to 71.4%, with GPT achieving the highest LLM score. Similarly, for needling techniques, acupuncturists ranged from 60.7% to 78.6% compared to LLMs (25.0% to 67.9%), where GPT ranked highest. In herbal medicine, acupuncturists scored between 42.9% and 75.0%, exceeding LLMs, which ranged from 28.6% to 42.9%, with Qwen and Gemini performing best (42.9%). Chi-square test results indicate significant differences in TCM diagnosis (p < 0.001), acupoint selection (p < 0.001), needling techniques (p < 0.001), and herbal medicine prescriptions (p = 0.004), whereas no significant variation was observed in Western medical diagnosis (p = 0.93).

Proportion of high-scoring recommendations (≥4) across evaluation domains

## Section: Discussion

In this study, we conducted a case-based evaluation of seven publicly accessible LLMs and compared their diagnostic and treatment recommendations with those of experienced acupuncturists using a real-world TCM case. We found that (1) certain LLMs, including GPT-4o, Qwen 2.5 Max, and Doubao 1.5 Pro, demonstrated performance comparable to licensed acupuncturists in specific domains such as TCM diagnosis, acupoint selection, and herbal treatment planning, and (2) performance varied substantially across models and tasks, indicating inconsistency in current capabilities. These findings suggest that general-purpose LLMs possess foundational potential to support culturally embedded healthcare systems like TCM. With targeted refinement, they may serve as scalable and cost-effective tools to expand access to high-quality, culturally relevant care, particularly in settings where linguistic, geographic, or infrastructural barriers limit the availability of trained practitioners.

Our findings demonstrated exceptional performance in the Western medical diagnostic capabilities of LLMs. In addition, we found that three models, GPT, Qwen, and Doubao, achieved performance comparable to human acupuncturists in TCM diagnosis and acupoint selection, while showing more variability in needling techniques and herbal formulation. This finding is consistent with broader evaluations where LLMs have shown high accuracy in structured and rule-based assessments, such as medical board examinations36–38. These models exhibit a robust understanding of standardized protocols and diagnostic criteria, enabling them to deliver promising results that match or even surpass human expertise in some scenarios. Additionally, the multilingual processing capabilities of LLMs also present another significant advantage in global healthcare applications. LLMs demonstrated proficiency in aligning with clinical guidelines across linguistic barriers, making accurate recommendations in various languages39–41. This capacity for multilingual processing promotes equitable access to medical knowledge and improves global healthcare accessibility.

While LLMs like GPT, Qwen, and Doubao are comparable to professional acupuncturists in multiple tasks in several key domains, their performance was not uniform across all assessment criteria. Although GPT, a Western-developed model, demonstrated strong performance, Chinese-developed LLMs, like Qwen and Doubao, outperformed many other models in handling culturally sensitive TCM tasks. This suggests that both model architecture and culturally tailored training datasets can enhance performance in areas requiring deep cultural adaptability. Our results have important implications for addressing longstanding barriers in globalization of TCM. TCM has historically faced challenges in globalization due to its complex theoretical foundations, cultural nuances, and differences in educational systems worldwide42,43. These barriers make it difficult for international practitioners and students to access and integrate TCM knowledge into their practices. LLMs provide innovative potential to address these challenges and foster health equity through several processes. First, the ability of LLMs to process TCM concepts and provide recommendations across multiple languages addresses linguistic barriers and enables broader engagement with TCM practices33,35,44. The strong performance of culturally adapted models like GPT, Qwen, and Doubao demonstrates the potential for maintaining Asian cultural authenticity while increasing accessibility of TCM. Furthermore, LLMs’ scalability and cost-effectiveness, and digital nature make them powerful tools for democratizing TCM education and distribution, particularly in regions where access to trained acupuncturists is limited42,45,46.

Nevertheless, LLMs still face significant challenges in handling culturally sensitive and complex tasks within TCM. Our analysis revealed significant performance disparities among LLMs in TCM-specific tasks. Notably, Gemini, LLaMA, Claude, and ERNIE were associated with lower performance compared to human acupuncturists in specialized areas such as acupoint selection and needling techniques. Additionally, Gemini and Claude underperformed relative to professional acupuncturists in herbal formulation tasks. In contrast, Qwen and Doubao, along with GPT, consistently achieved performance levels comparable to acupuncturists in culturally nuanced tasks, particularly in TCM diagnosis and acupoint selection, while still showing variability in other domains such as needling techniques and herbal formulation. These models demonstrated better performance than other models, likely due to their training with more regionally and culturally relevant data. These performance variations may be primarily influenced by model architecture47, training data48, fine-tuning49, domain specialization50, and reasoning ability51. The comparable performance of GPT demonstrates the impact of its advanced architecture, large-scale parameters, and reasoning capabilities, allowing it to achieve high diagnostic accuracy even without explicit cultural optimization52–55. The stronger performance of Chinese-developed models (Qwen and Doubao) indicates that they might benefit from targeted optimization for Chinese medical corpora, improving text comprehension and diagnostic reasoning56. Their integration of Chinese clinical guidelines and traditional decoction provides a distinct advantage in culturally sensitive tasks57, with reasoning patterns that more closely align with those of Chinese physicians. Our findings highlight fundamental challenges in applying LLMs to TCM practices, as the diagnostic framework relies heavily on complex subjective and culturally embedded methods such as pulse analysis, tongue observation, and syndrome differentiation17,56,58. These holistic and dynamic approaches and elements pose additional challenges for LLMs that are primarily trained on Western medical datasets57,59. Furthermore, the lack of large, standardized datasets specific to TCM exacerbates these issues, leaving many LLMs unable to fully replicate the expertise required for culturally sensitive TCM practices56. Thus, some LLMs failed to match the performance of human practitioners in tasks that require cultural and contextual sensitivity, particularly in TCM diagnosis and treatment.

Several limitations of this study must be acknowledged. First, the evaluation was based on a single reported clinical case involving amyotrophic lateral sclerosis (ALS). While this allowed for a controlled comparison across multiple domains, it may limit the generalizability of the findings. Broader validation using diverse case types and disease categories is needed to determine LLM adaptability in more varied clinical settings. Second, all LLM responses were generated from structured case texts without real-time interaction. This non-interactive format does not replicate the real-world process in which a practitioner interprets a patient’s natural expressions and then translates them into TCM terms. In clinical settings, TCM diagnosis often depends on spontaneous patient language, behavioral cues, and subtle contextual factors that are difficult to capture in standardized written formats. In addition, while this study evaluated acupoint selection and needling techniques, it did not assess treatment implementation or patient response, both of which are critical to therapeutic outcomes in acupuncture. Future research should incorporate more interactive methodologies, such as clinical simulations or real patient interviews using AI-Agent, to better approximate real-world diagnostic workflows in TCM and evaluate how LLMs perform under more naturalistic and context-rich conditions. Third, while we used a five-domain scoring rubric developed through expert consensus, the framework has not been externally validated. Although predefined criteria were applied, some subjectivity in evaluator judgments may remain. Formal assessment of inter-rater reliability and the development of standardized evaluation tools tailored to TCM practice are important next steps. Fourth, the models examined were general-purpose LLMs that had not been fine-tuned on medical or TCM-specific corpora. The results should therefore be interpreted as a baseline assessment of current capabilities. The emergence of newer models after our study, such as DeepSeek and Gork, highlights the need for continuous evaluation as the field rapidly evolves. It is expected that future domain-specialized models trained on curated TCM datasets will show improved contextual understanding and clinical accuracy.

To address these limitations and support the responsible integration of AI into TCM practice, future research should prioritize the development of high-quality, domain-specific corpora. These should include classical TCM texts, modern clinical guidelines, trial data, and real-world patient records to align model outputs with TCM theory, language, and diagnostic reasoning. Expanding datasets to include diverse cases and longitudinal, multi-case evaluations will be essential for testing performance across varied clinical settings.

Furthermore, incorporating AI agents and multimodal diagnostic inputs, such as tongue images or pulse waveforms, could allow the AI to communicate with the patient directly to mimic real clinical settings, enhancing the realism and clinical utility of LLMs. Also, expert-in-the-loop learning approaches would allow continuous refinement based on practitioner feedback, while explainable AI tools can support transparency and clinician trust. From a system-level perspective, cross-cultural validation and prospective clinical trials will be necessary to determine whether LLM-informed TCM care improves diagnostic accuracy, healthcare access, and patient outcomes, particularly in underserved or resource-constrained environments. These efforts will help define the role of LLMs within global digital health ecosystems. Ultimately, advancing the use of LLMs in TCM requires close collaboration among practitioners, AI developers, and policy experts. By fostering culturally sensitive, inclusive, and evidence-based innovation, LLMs can contribute meaningfully to the mission of digital health equity and support more accessible, high-quality care for all.

In summary, this study establishes an initial benchmark for evaluating the diagnostic and treatment capabilities of LLMs in TCM. Using a standardized clinical case, we found that while general-purpose LLMs demonstrated performance comparable to licensed acupuncturists in Western medical diagnosis, their capabilities varied considerably across TCM-specific domains. Notably, GPT-4o, Qwen 2.5 Max, and Doubao 1.5 Pro exhibited the highest alignment with licensed acupuncturists in TCM diagnosis, acupoint selection, and needling techniques. These findings highlight the potential of LLMs as accessible and scalable tools to support TCM care, particularly in settings with limited healthcare resources. Future research should prioritize domain-specific fine-tuning, AI-agent, multimodal input integration, and real-world clinical validation to enhance both performance and reliability. As LLMs continue to evolve, their thoughtful integration into TCM practice holds significant potential to bridge traditional medical knowledge with modern healthcare systems, contributing to a more equitable and culturally inclusive digital health future.

## Section: Methods

A clinically complex ALS case integrating Western and TCM diagnostic elements was used. Seven LLMs and three licensed acupuncturists responded to three standardized prompts. Responses were evaluated across five domains: Western diagnosis, TCM diagnosis, acupoint selection, needling technique, and herbal medicine. Ratings were provided by 28 blinded TCM experts using a 5-point Likert scale. The LLMs included GPT-4o (OpenAI), Gemini 1.5 Flash (Google), LLaMA 3.2 (Meta), Claude 3.5 Sonnet (Anthropic), ERNIE 3.5 (Baidu), Qwen 2.5 Max (Alibaba), and Doubao 1.5 Pro (ByteDance). Abbreviations: LLM, large language model; TCM, Traditional Chinese Medicine; ALS, amyotrophic lateral sclerosis.

Evaluation criteria for assessing diagnostic and treatment recommendations in Western and Traditional Chinese Medicine

## Section: Methods › Study design

This survey-based study evaluated the diagnostic and treatment recommendations of seven LLMs and three acupuncturists, assessed independently by 28 professional acupuncturists. A clinically complex and educationally representative case of ALS was selected from a peer-reviewed TCM case report60. ALS was chosen for its neurological complexity, integration of Western and TCM diagnostic elements, and relevance to acupuncture education and practice in China61. These characteristics made it a suitable case example for benchmarking LLM performance across multiple diagnostic and treatment domains. The case was reformatted to include detailed patient history, physical examination findings, and TCM diagnosis to provide uniform inputs (Supplementary Table 1). Each LLM and acupuncturist was treated as an independent “model” and assessed across five domains: diagnostic accuracy (Western and TCM), acupoint selection, needling technique, and herbal prescription appropriateness. Blinding and bias mitigation strategies were implemented to enhance the validity. A detailed overview of the study design is provided in Fig. 2.

A clinically complex ALS case integrating Western and TCM diagnostic elements was used. Seven LLMs and three licensed acupuncturists responded to three standardized prompts. Responses were evaluated across five domains: Western diagnosis, TCM diagnosis, acupoint selection, needling technique, and herbal medicine. Ratings were provided by 28 blinded TCM experts using a 5-point Likert scale. The LLMs included GPT-4o (OpenAI), Gemini 1.5 Flash (Google), LLaMA 3.2 (Meta), Claude 3.5 Sonnet (Anthropic), ERNIE 3.5 (Baidu), Qwen 2.5 Max (Alibaba), and Doubao 1.5 Pro (ByteDance). Abbreviations: LLM, large language model; TCM, Traditional Chinese Medicine; ALS, amyotrophic lateral sclerosis.

## Section: Methods › Recommendations by LLMs

Given the rapidly expanding landscape of LLMs, selecting models for evaluation requires balancing representation across leading international and domestic developers with the practical need to limit the time and cognitive demands on expert evaluators. Seven generative LLMs were selected for evaluation based on the following criteria: (1) representation of leading international or Chinese developers, including models designed for English and Chinese language tasks; (2) public availability through free or low-cost user interfaces to ensure accessibility and reproducibility; and (3) general-purpose design without fine-tuning in medicine or TCM, allowing for an unbiased evaluation of baseline performance in TCM diagnostic and treatment recommendations.

The models included in this study were GPT-4o (OpenAI), Gemini 1.5 Flash (Google), LLaMA 3.2 (Meta), Claude 3.5 Sonnet (Anthropic), ERNIE 3.5 (Baidu), Qwen 2.5 Max (Alibaba), and Doubao 1.5 Pro (ByteDance). Detailed specifications are provided in Supplementary Table 2. All models were accessed through publicly available user interfaces without any external plugins or real-time internet access. Therefore, all generated responses were based solely on the models’ pre-trained knowledge available at the time of data collection. None of the models had been specifically trained or fine-tuned on medical or TCM data. Each model was tasked with responding to three prompts designed to assess its ability to translate, diagnose, and recommend treatments (see Supplementary Table 3):

## Section: Methods › Recommendations by licensed acupuncturists

To establish a benchmark for evaluating LLMs, experienced TCM acupuncturists were recruited based on the following inclusion criteria: (1) possession of a valid license as a TCM or acupuncture practitioner; (2) a minimum of eight years of clinical acupuncture experience; (3) active clinical practice in a hospital or an academic acupuncture department.

Two acupuncturists met these criteria: Acupuncturist 1, MSc, an attending TCM physician at a hospital in Guangzhou, China, with about ten years of clinical experience, and Acupuncturist 2, PhD, a full professor in the Department of Acupuncture, chief physician, and senior clinician at a hospital in Chengdu, China, with more than ten years of clinical experience. The third set of clinical responses was extracted from the original peer-reviewed case report60, in which the author was identified as a clinician (with a Master’s degree) affiliated with Tianjin University of Traditional Chinese Medicine, with about 8 years of clinical experience.

The participating acupuncturists were provided with standardized case information, identical to what was given to the LLMs through three prompts, including detailed clinical history, examination findings, and preliminary diagnoses. They were not aware of the study’s aims before completing their responses to minimize potential bias. Each acupuncturist was instructed to independently provide a written response, which was submitted via email. All participants were encouraged to complete their recommendations independently (see Supplementary Table 3).

## Section: Methods › Evaluation criteria

The recommendations were evaluated using a 5-point Likert scale across five criteria: (1) accuracy of Western medical diagnoses, (2) accuracy of TCM diagnoses, (3) appropriateness of acupuncture point selection, (4) practicability of needling techniques, and (5) suitability of herbal medicine. Scoring definitions and thresholds were standardized to ensure consistency across evaluations (Table 5).

Evaluation criteria for assessing diagnostic and treatment recommendations in Western and Traditional Chinese Medicine

## Section: Methods › Evaluator selection and survey implementation

Professional acupuncturists from China, South Korea, and the United States participated as independent evaluators to assess the diagnostic and treatment responses generated by both LLMs and licensed acupuncturists. Evaluators were selected based on the following criteria: (1) active involvement in either clinical care or academic activities (e.g., teaching or research) in acupuncture or TCM; and (2) affiliation with a TCM hospital/clinic or an accredited university/institution. Recruitment was conducted through email invitations distributed through professional networks, institutional collaborations of all co-authors, and academic referrals. As a pilot study designed to provide preliminary insights, a broad pool of qualified professionals was invited. Of those invited, 28 evaluators completed the full assessment within the designated timeframe and were included in the final analysis. To reduce bias, evaluators were not informed that some responses were generated by LLMs. They were told that the study aimed to examine variation in diagnostic and treatment recommendations from different sources. All evaluators were blinded to the study hypothesis, evaluation criteria, and the identities of the respondents.

Each evaluator received a standardized survey translated into Chinese, Korean, or English through a forward-backward translation process to ensure accuracy and cultural equivalence. Evaluators independently reviewed anonymized diagnostic and treatment responses and rated them using predefined criteria. All responses were submitted anonymously through the secure online survey platform “Wenjuanxing”62 (www.wjx.cn) between November 1 and November 30, 2024.

## Section: Methods › Bias mitigation

To minimize bias, a standardized evaluation guide with clear scoring definitions and examples was provided to all evaluators. The order of responses was randomized, and all identifying labels (e.g., “AI” or “acupuncturist”) were removed to ensure impartial assessments. Independent evaluations were conducted under blinded conditions to prevent influence by prior responses.

## Section: Methods › Ethical approval

This study was reviewed and determined to be exempt from full ethical review by the Mass General Brigham Institutional Review Board (Protocol #: 2025P001014) under 45 CFR 46.104(d)(2). The research involved no identifiable private information or direct interaction with human participants, and relied solely on a publicly available, de-identified clinical case and anonymous expert survey data. Informed consent was waived in accordance with relevant policy63,64. All procedures were conducted in accordance with the Declaration of Helsinki and applicable guidelines65.

## Section: Methods › Statistical analysis

Statistical analyses were performed using IBM SPSS Statistics version 29.0.1.066. Descriptive statistics were reported as means ± standard deviations for continuous variables and as counts (n) with percentages for categorical variables. Group differences were assessed using one-way analysis of variance (ANOVA) for continuous variables, followed by Tukey’s Honest Significant Difference (HSD) test for post-hoc pairwise comparisons when applicable. Chi-square tests were conducted for categorical variables across multiple groups. All analyses were two-tailed, with statistical significance set at p < 0.05. Data visualizations were generated using GraphPad Prism version 10.

## Section: Supplementary information

Supplementary Information

## Section: Acknowledgements

The authors sincerely thank all participating acupuncturists and expert evaluators for their valuable time and contributions to the multilingual assessment process. No external funding was received for this work.

## Section: Author contributions

J.K. conceptualized and provided overall supervision. J.K., Y. Liu and Y.Y. selected the study case, designed the methodology, and constructed the evaluation framework. Y. Liu and Y. Li performed statistical analysis and data interpretation. K.Y., Y. Li, P.J. and J.W. coordinated multilingual survey administration and managed evaluator recruitment, translation, and data collection via Wenjuanxing. Y. Liu and K.Y. drafted the manuscript and prepared the figures. J.W., V.S., S.H. and M.C. contributed to manuscript preparation and revision. Y. Liu and J.W. assembled the submission package. All authors reviewed and approved the final manuscript.

## Section: Data availability

The final dataset supporting the conclusions of this study is available from the corresponding author via email upon reasonable request and pending institutional approval.

## Section: Code availability

No custom algorithms or scripts were developed for this study. Statistical analyses were conducted using IBM SPSS Statistics (version 29.0.1.0).

## Section: Competing interests

The authors declare no competing interests.

## Section: Supplementary information

The online version contains supplementary material available at 10.1038/s41746-025-01845-2.

## Section: Associated Data

Supplementary Information

## Section: Associated Data › Supplementary Materials

Supplementary Information

## Section: Associated Data › Data Availability Statement

The final dataset supporting the conclusions of this study is available from the corresponding author via email upon reasonable request and pending institutional approval.

No custom algorithms or scripts were developed for this study. Statistical analyses were conducted using IBM SPSS Statistics (version 29.0.1.0).


---

# Evaluating the Role of Machine Learning and Artificial Intelligence in Oncology Drug Repurposing Efforts

- **Authors:** Adam Mann
- **Issuer:** Journal of research in pharmacy practice
- **Type:** Scientific article
- **Published:** 2025-11-19
- **Language:** en
- **DOI:** 10.4103/jrpp.jrpp_50_25
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41368603/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractObjective:This study aims to investigate how machine learning (ML) contributes to drug repurposing efforts in oncology, considering the pharmaceutical industry’s mounting R and D inefficiencies and economic pressures. Through qualitative interviews with experts across artificial intelligence, oncology, and pharmaceutical development, this paper explores the real-world applications of ML in this field, the challenges to its implementation, and its future potential to streamline drug discovery.Methods:This study employed the “research onion” framework (Saunders et al., 2016), adopting an interpretivist philosophy and inductive approach to explore stakeholder perspectives on integrating ML into oncological drug repurposing. A multimethod strategy combined a narrative literature review with 13 semi-structured interviews, selected through purposive and snowball sampling. Data were thematically analyzed using Braun and Clarke’s six-step framework, supported by NVivo. Research trustworthiness was ensured via Lincoln and Guba’s criteria, and ethical approval was granted by Imperial College London.Findings:Three major thematic domains emerged: The technological, regulatory, and business landscapes. Technological challenges included poor data quality, limited accessibility to real-world datasets, and the need for robust infrastructure to support predictive modeling. Regulatory barriers are centered on ethical concerns in data governance and the difficulty of securing exclusivity and market protection for repurposed drugs. From a business perspective, profitability concerns, generic competition, and fragmented data ownership underscored the need for more collaborative and economically sustainable models.Conclusion:ML offers potential for oncological drug repurposing, but realizing its benefits requires addressing key technological, regulatory, and economic challenges.KEYWORDS: Drug repositioning, machine learning, neoplasms, pattern recognition

## Section: INTRODUCTION AND BACKGROUND

Global pharmaceutical spending is expected to reach $1.6 trillion by 2025, with oncology showing a 30% compounded annual growth rate (CAGR) over the past decade.[1] However, the industry faces an R and D productivity crisis. Developing a new drug can take 10–15 years and cost over $2 billion,[2] with only 1 in 10–20 candidates gaining approval.[3] Pricing pressures and regulatory controls add further strain, as global demand for affordable healthcare rises. Governments and healthcare providers are pushing for lower prices,[4] while price controls in regions such as Europe and Japan impact profits and R and D reinvestment.[5] This creates a trade-off between innovation and accessibility.

Patents offer up to 20 years of exclusivity.[6] Once a patent expires, generic drugs – which are molecularly identical to the original branded medication – can enter the market.[7] These generic drugs contain the same active pharmaceutical ingredient as their branded counterparts, rendering them molecularly equivalent and essentially identical in terms of therapeutic effects.[7] This “genericization” severely impacts the profitability of the original company, as new companies can offer the same medication at significantly lower prices. Consequently, pharmaceutical companies fiercely guard their intellectual property (IP) and compete aggressively to generate substantial revenues during the exclusivity window before generic competition arises

Drug repurposing, defined as finding new uses for existing drugs,[8] addresses these challenges. Around 30% of Food and Drug Administration-approved drugs have been repurposed.[9] Notable examples include aspirin’s use as an antiplatelet[10] and thalidomide for multiple myeloma.[11] Repurposing reduces development time, cost, and failure risk – cutting costs from $2 billion to $300 million and duration from 10 to 15 years to 6.5 years.[11]

Two repurposing strategies exist: Hard repurposing which targets different diseases (e.g., propranolol for hemangioma[12]), and soft repurposing which applies drugs within the same field (e.g., trastuzumab initially for HER2-positive breast cancer but later for gastric cancer;[13]). Identification methods include experimental (target- or drug-based[14]) and computational approaches such as molecular docking, signature mapping, genetic association studies, pathway mapping, and retrospective clinical analysis.[15]

Artificial intelligence (AI) and machine learning (ML) tools are now integral to this process. ML branches include supervised, unsupervised, semi-supervised, reinforcement, and deep learning.[16] These tools enable analysis of large datasets, predict molecular interactions, and optimize formulations, reducing time and cost.[15]

Cancer treatment complexity, due to drug resistance and tumor heterogeneity,[17] underscores the need for personalized approaches. With a one in two lifetime risk[18] and oncology spending set to exceed $260 billion by 2025,[1] repurposing offers an efficient alternative – especially as cancer drugs average 7.3 years and $648 million to develop.[19] The ReDO database lists 335 non-cancer drugs with anticancer potential,[20] and 190 ongoing late-stage oncology trials are investigating repurposed candidates.[21]

Therefore, this paper aims to answer the question, “How does machine learning contribute to drug repurposing efforts in oncology?.” It aims to delve deeper into the applications, challenges, and future scope of incorporating ML techniques with oncological drug repurposing and evaluate them as potential means to address the larger issues the pharmaceutical industry faces. The field of oncology has attained a demonstrated global focus, with pharmaceutical companies dedicating significant resources toward optimizing the drug repurposing process for cancer therapeutics. In addition, the multi-functional aspects of ML tools hold promise to advance oncological drug repurposing, potentially addressing the obstacles faced by not only the field of oncology but the pharmaceutical industry. These factors have formed the basis of this report.

## Section: METHODOLOGY

This study followed the “research onion” framework,[22] proposed by a conceptual model that outlines the layers involved in developing a sound research methodology. Each layer represents a distinct element of research design, ensuring a logical and structured progression from philosophical stance to data collection and analysis.

We adopted an interpretivist philosophy, which acknowledges the subjective nature of human experiences. This was appropriate given our aim to explore the challenges and potential of integrating ML into oncological drug repurposing from the perspectives of industry stakeholders. Interpretivism allowed us to gather in-depth insights into the realities, opinions, and lived experiences of experts working at the intersection of oncology, AI, and pharmaceutical development.

The study employed an inductive approach, enabling us to collect empirical qualitative data and build a descriptive framework to explain observed phenomena.[23] This suited our objective to uncover the factors that support or hinder the adoption of ML techniques in oncological drug repurposing, without testing a predefined hypothesis.

Aligned with the third and fourth layers of the research onion,[22] we adopted a multi-method strategy, combining findings from a narrative literature review (NLR) and semi-structured interviews (SSIs) [Appendix A]. This allowed us to integrate theoretical knowledge with real-world experiences. Quantitative methods were not used, as stakeholder perceptions and contextual challenges are best captured through qualitative inquiry. The cross-sectional time horizon of the study ensured that we captured insights relevant to the current state of ML integration in oncology.

At the core of the research onion,[22] are the techniques and procedures used to collect and analyze data. Our qualitative data were collected through SSIs, which offered a balance between a consistent question framework and the flexibility to probe deeper into key topics. This method enabled us to explore complex themes, unlike focus groups, which risk “groupthink,”[24] or questionnaires, which often lack the depth required for exploratory studies.

We used purposive sampling to select participants based on their expertise and relevance to the research aims.[25] Our sampling framework [Figure 1] identified individuals across three domains: AI, oncology, and the pharmaceutical industry. Priority was given to those operating at the intersections of these fields, particularly professionals with pharmaceutical experience. Participants were recruited through multiple media outlets and professional networks, in line with our ethics approval checklist [Appendix B].

To complement purposive sampling, we also applied snowball sampling.[26] This involved asking participants to recommend others with relevant expertise. Snowballing was particularly effective given the niche nature of our topic and the limited accessibility of qualified professionals. We recognized the potential for community bias in this method, where early participants influence the direction of results.[27] To minimize this, we diversified our initial contacts by sourcing participants from various backgrounds and organizations, including small startups, large pharmaceutical companies, and academic institutions.

Sample size in qualitative research is typically small due to the depth of analysis involved. According to Hennink and Kaiser, 9–17 interviews are generally sufficient.[28] Our study reached theoretical saturation – the point at which no new themes emerged – after conducting 13 interviews with individuals, including data scientists, oncologists, and pharmaceutical industry leaders [Appendix C]. This sample size ensured a wide range of views were captured while remaining manageable for thorough thematic analysis.

SSIs were designed and conducted using McNamara’s 8-step framework[29] to ensure structure and consistency. Before each interview, we researched each participant’s background, allowing us to tailor questions and elicit detailed insights. Interview questions [Appendix D] were open-ended, enabling participants to express views freely and allowing us to follow up on areas of interest. The question sets were tailored to three broad interviewee categories based on professional background, ensuring relevance to the study aims.

All interviews were conducted virtually via Microsoft Teams to accommodate participants’ schedules and enable automatic audio transcription. Doing this would not solely provide a trail of evidence and increase transparency but would also enable a script to be generated that we could look back on and analyze.[30] Verbal consent was obtained at the start of each session for recording and transcription. Interviews lasted approximately 45 min and began with informal conversation to build rapport. Two group members attended each session – one to conduct the interview and the other to ensure technical reliability. All interviews followed a consistent structure to support reliability and comparability of responses.

Following data collection, interview transcripts were analyzed using Braun and Clarke’s 6-step framework for thematic analysis.[31] Transcripts were cleaned to remove timestamps and repetitive speech, allowing for familiarization with the material. Three team members imported the transcripts into NVivo, a qualitative analysis tool provided by Imperial College London, to begin coding. Initial codes were generated based on relevance to study objectives, then grouped into broader categories and themes through iterative discussion and refinement among all group members.

This process resulted in the identification of three major themes and six sub-themes, which were reviewed and reorganized to ensure internal consistency (homogeneity) within themes and distinctiveness (heterogeneity) between them. A thematic map was developed to visually represent the findings and guide the discussion section of the report. The combination of NLR insights and interview data provided a comprehensive understanding of the challenges and opportunities in using ML for drug repurposing in oncology.

To ensure research trustworthiness, we followed Lincoln and Guba’s[32] four criteria:

Confirmability was reinforced through investigator triangulation, with two group members present for each interview.[25]

Finally, ethical approval was obtained from the Imperial College Research Ethics Committee on January 10, 2024 [Appendix B]. Participants gave informed consent for interview recording and data use, with all data handled in accordance with our ethical protocol.

A Venn diagram depicting the purposive sampling approach for interviewees

## Section: QUALITATIVE RESULTS

Thematic analysis: Technological landscape and data infrastructure in AI-driven drug repurposing. Source: Author’s qualitative interviews (2024)

Thematic analysis: Business environment — profitability and industry collaboration in drug repurposing. Source: Author’s qualitative interviews (2024)

Thematic analysis: Governance of data and regulatory challenges in drug repurposing. Source: Author’s qualitative interviews (2024)

## Section: QUALITATIVE RESULTS › Technological landscape

The technological landscape for employing ML in oncological drug repurposing encompasses real-world data (RWD) analysis, Predictive Modeling, and Data Infrastructure. Data infrastructure can be further divided into Data Quality and Accessibility [Tables 1-3].

RWD analysis and Predictive Modeling discuss the concepts of screening databases to identify pertinent information to develop a predictive model. This technique can significantly cut down the time and cost by simulating the interactions between drugs and cancer cells. Interviewees pointed out significant challenges, such as poor preclinical data quality and the difficulty of accessing large quantities of relevant data within pharmaceutical companies.

Data quality and accessibility are both important as they ensure that models are trained on accurate and relevant information, leading to more precise molecule identification for repurposing. Access to diverse datasets from various sources also enables a more reliable algorithm to be developed.

Together, these subthemes provide a comprehensive overview of the current technological landscape and its impact on advancing drug repurposing in oncology through ML.

Thematic analysis: Technological landscape and data infrastructure in AI-driven drug repurposing. Source: Author’s qualitative interviews (2024)

Thematic analysis: Business environment — profitability and industry collaboration in drug repurposing. Source: Author’s qualitative interviews (2024)

Thematic analysis: Governance of data and regulatory challenges in drug repurposing. Source: Author’s qualitative interviews (2024)

## Section: QUALITATIVE RESULTS › Regulatory landscape

The regulatory landscape for utilizing ML in oncological drug repurposing contains two subthemes: Governance of Data and Regulatory Challenges.

Governance of Data is a major issue in the field of repurposing with privacy and ethical issues being the major concern. It highlights the challenges related to data access, consent, and methods in which companies have utilized to address these privacy issues. Accessing and using patient data involves significant challenges related to obtaining informed consent and ensuring data security. Companies are adopting various strategies to address these issues, such as anonymizing patient data to maintain privacy. These measures are essential for maintaining a delicate balance between compliance with legal and privacy standards whilst obtaining the necessary health data for research.

Regulatory Challenges focuses on obtaining commercial exclusivity and bypassing patent protections, while addressing the difficulties in advancing repurposing without original patent ownership. Navigating the regulatory framework requires addressing complexities such as IP, a topic touched on in our interviews.

## Section: QUALITATIVE RESULTS › Business environment

The business environment surrounding the integration of AI and ML in drug repurposing for oncology is multifaceted, as illuminated by various insights from industry experts.

Profitability emerges as a central concern, with interviewees highlighting the cost-effectiveness of AI and ML technologies. Generic drugs, renowned for their affordability and accessibility, present distinct advantages in the market, driving discussions on sustainable economic models amid the threat of generic substitution. Furthermore, industry collaboration plays a pivotal role in harnessing the vast data reservoirs held by pharmaceutical companies.

Collaborative partnerships, bridging expertise in data structuring, algorithmic coding, and domain-specific knowledge, are essential for navigating the intricate landscape of oncology drug development. However, challenges persist in consolidating disparate datasets and fostering a culture of joint discovery within the pharmaceutical industry. Amid such complexities, the business environment underscores the imperative of innovative strategies and collaborative frameworks to propel drug repurposing efforts forward in oncology.

## Section: DISCUSSION › Technological landscape

The current landscape of ML in drug repurposing is defined by two key aspects: The benefits, particularly its ability to support RWD analysis and predictive modeling, and the challenges, especially concerning data quality, quantity, and accessibility. These dimensions influence the technological landscape today and shape future developments.

## Section: DISCUSSION › Real-world data analysis

ML is increasingly pivotal in enabling the analysis of large-scale RWD. Both the literature review and SSIs affirmed ML’s ability to scan large datasets and biomedical literature, streamlining workflows and reducing costs. Senior pharmaceutical executives highlighted the value of data mining for improving resource allocation. ML’s ability to conduct literature-based text mining is increasingly important given the rapid growth in biomedical publications.

Another valuable data source is electronic health records (EHRs). EHRs provide longitudinal patient data, including history and treatments, and follow structured standards, making them useful for drug repurposing. These datasets reflect real patient outcomes, contrasting with the artificial conditions of clinical trials. EHR-based ML analyses can unlock novel repurposing insights, leveraging established safety profiles to expedite discovery. The NHS Long Term Plan supports this future by emphasizing digitalization and a paperless system.[33]

However, challenges remain in data access, standardization, and validation. For ML on RWD to reach its full potential, these issues must be addressed. As EHR adoption increases and quality improves, this type of evidence could transform the drug repurposing landscape.

## Section: DISCUSSION › Predictive modeling

Once data are extracted, ML is used to model it, producing predictions about drug targets and responses. Structure-based ML methods use computational chemistry to analyze three-dimensional (3D) protein structures, identifying binding sites and screening compounds through molecular docking. These approaches enhance the therapeutic value of repurposed drugs but demand high-quality data and significant computational resources.

Genetic association approaches combine genomics, transcriptomics, proteomics, and metabolomics, providing a complete picture of disease biology and enabling biomarker identification. Cell activity-based methods analyze observable traits of cells, generating mechanistic insights, especially relevant in oncology, given its phenotypic plasticity.

Interviewees noted that although these strategies are often seen in isolation, combining them significantly enhances ML’s impact. Integrating 3D structural data, omics profiles, and phenotypic data enables more precise predictions of drug efficacy and treatment responses. This integration could optimize repurposing strategies by identifying novel targets and personalizing therapies, though success depends on access to high-quality, well-structured datasets.

## Section: DISCUSSION › Future scope of real-world data and predictive modeling

The interviews revealed a clear shift toward personalized medicine. Using large datasets – genomic data, imaging, treatment history – ML can predict individual responses to treatments. This supports patient stratification and the design of tailored therapies, improving outcomes and minimizing side effects.

Interviewee 8 introduced the concept of basket studies: Trials that assess drug efficacy across various cancers sharing a common biomarker.[34] These studies group patients by molecular profile, not cancer type, which aligns with repurposing goals. ML can analyze data from such studies to find drugs effective across multiple cancers with shared targets. These tumor-agnostic approaches, potentially leading to faster drug approvals, exemplify how ML can advance oncological drug repurposing beyond traditional disease categories.

## Section: DISCUSSION › Data infrastructure

The success of ML applications in RWD analysis and predictive modeling depends heavily on data infrastructure, particularly data quality and accessibility.

## Section: DISCUSSION › Data quality

ML models learn from training data, and poor data quality compromises their accuracy. Experts stressed that relevance, completeness, representativeness, and lack of bias are key metrics. If training data are biased or incomplete, models risk making incorrect predictions, missing promising candidates, or identifying misleading patterns.

“Data cleaning” is essential – refining datasets by removing errors or gaps before training. This is especially important in proteochemometrics and graphical modeling, where data flaws undermine model reliability. However, cleaning data can contribute to overfitting, where models learn the training data too well, including irrelevant noise, impairing generalizability to new data.[35]

This issue is acute in oncology, given the heterogeneity of cancers. Overfitted models may identify false-positive candidates or fail in diverse patient groups. Interviewees cited real-world examples where algorithms excluded underrepresented cancer populations, causing harm.[36] Preventing overfitting requires representative data, regularization, and cross-validation.

Wider studies echo these concerns. NHS datasets suffer from documentation and curation issues, while European pharmaceutical efforts face hurdles in reusing health data. Rangineni noted that high-quality data boost ML accuracy by 25%, while poor data can reduce reliability by 30%.[36]

Limited quantity of patient-level data is also a barrier, especially in rare cancers. Legislation by the National Disease Registration Service aims to overcome this by collecting such data without explicit consent, expanding availability for research.[21]

## Section: DISCUSSION › Data accessibility

Beyond quality and quantity, accessibility poses a major hurdle. Successful ML repurposing relies on access to broad, integrated datasets on drug properties, molecular interactions, and patient outcomes.

Our SSIs revealed that companies and NHS bodies often struggle to access sufficient data. NHS, despite hosting one of the largest patient datasets, is reluctant to share information. Interviewee 7 noted that even financial incentives were insufficient to persuade NHS Trusts to release data. Similarly, large pharmaceutical companies guard data closely-interviewee 6 reported firms often did not even know where certain datasets were stored. These structural barriers slow progress and lengthen development timelines.

The literature echoes this: Describe limited data sharing as a widespread problem. Overcoming these issues requires not just technical improvements but structural changes in how data are governed and shared.

## Section: DISCUSSION › Regulatory landscape

Regulatory constraints are one of the most significant barriers to oncological drug repurposing. These include patient data privacy, IP protection, market exclusivity, and the need for trust-building with regulatory agencies.

## Section: DISCUSSION › Governance of data › Patient consent

UK law protects patient data under the 2018 Data Protection Act and the Common Law Duty of Confidentiality. ML development requires consent to use personal clinical data. Even with initiatives to collect data without consent, many patients remain unwilling to share due to privacy concerns or lack of understanding.

Our interviews confirmed this reluctance. Interviewee 7 noted that monetary compensation alone was “not enough to pay for the data.” The challenge is not only ethical and legal but practical – without consent, companies have limited access to the datasets ML models depend on.

## Section: DISCUSSION › Governance of data › Open datasets

To bypass privacy issues and regulatory hurdles, companies often turn to open datasets, such as the UK Biobank and The Cancer Genome Atlas. These contain rich, freely accessible data. The UK Biobank, for example, includes information on approximately 500,000 individuals.[37] These resources speed up the research process and lower costs.

However, access to some high-value datasets remains restricted or costly – interviewee 6 noted key data was often “locked behind paywalls.” In this context, open datasets are a practical solution, especially for smaller firms and nonprofits. Moreover, patient willingness to share data may be improving[38] found increasing public support for using clinical data in research.

## Section: DISCUSSION › Regulatory challenges › Patent protection

Patent law poses a barrier to repurposing. The original composition of matter patent grants exclusive rights to the first discoverer. New therapeutic uses require a “first medical use” patent, but this does not provide full commercial protection if the compound is not novel. This limits incentive for repurposing, as companies cannot block competitors once exclusivity ends.

## Section: DISCUSSION › Regulatory challenges › Off-label prescribing

If parent companies do not pursue new indications, others may prescribe the drug off-label, without formal approval. While scientifically justified, off-label use raises safety, legal, and ethical concerns. Interviewees noted that this lack of endorsement reduces physician and public trust, decreasing uptake. Verbaanderd highlighted the gap between research and clinical implementation caused by these regulatory hesitations.[39]

## Section: DISCUSSION › Regulatory challenges › Algorithmic intellectual property protection

ML algorithms used to identify repurposing candidates must also be protected. However, algorithms cannot be patented as a whole – each step must be claimed separately.[40] This complex process is slow, often taking a year or more,[41] during which the algorithm may become outdated. These delays reduce incentives for smaller companies to invest in algorithm development.

## Section: DISCUSSION › Regulatory challenges › Regulatory support

Despite these challenges, recent regulatory support has emerged. NHS England’s Medicines Repurposing Programme, launched in 2021, aims to formalize repurposing and reduce reliance on off-label prescribing. Similarly, the MHRA was recognized by interviewees as crucial in increasing trust and uptake.

Streamlined approval pathways that rely on existing safety data can significantly shorten time to market, reducing costs and improving patient access – particularly in rare cancers where time is critical. This synergy with ML-driven discovery models could improve both speed and success rates.

## Section: DISCUSSION › Regulatory challenges › Business environment

The financial and structural dynamics of the pharmaceutical industry play a pivotal role in the feasibility and uptake of ML for oncological drug repurposing. This section explores the key business factors, focusing on profitability and collaboration.

## Section: DISCUSSION › Regulatory challenges › Profitability

Funding new drug development has become increasingly difficult, resulting in unmet clinical needs, especially in oncology, where drug prices and development costs are extremely high.[42] Literature reviewed in the NLR highlights ML’s potential to reduce these costs by accelerating candidate identification. For example, Sengupta, Singh, and Kumar demonstrated ML models could predict anti-cancer compounds, streamlining the discovery of novel drug–gene interactions.[43]

## Section: DISCUSSION › Regulatory challenges › Cost of repurposing

While repurposing theoretically saves time and resources due to existing safety and efficacy data, the practical reality is less straightforward. Our interviews revealed that commercial value outweighs scientific rationale for many large pharmaceutical companies. Several participants expressed skepticism about repurposing’s ability to consistently deliver strong financial returns. Interviewee 9 likened current repurposing efforts to “shooting randomly at the clouds, hoping one of them sticks.”

High costs persist, especially in oncology, where additional Phase 1 or 2 trials may be needed to determine new dosing regimens. Narrow therapeutic windows and toxicity risks demand further reformulation and testing. ML methods, like molecular docking, also require extensive computing power, making them expensive to deploy at scale.

The costs associated with implementation and reformulation may offset the expected savings from bypassing early-stage trials. Furthermore, rare cancers represent small markets, offering limited return on investment. This lack of financial incentive was a recurring theme across interviews, especially for large companies that focus on profitability and shareholder value.

Despite these challenges, the drug repurposing market is growing, with a projected CAGR of 10.8% between 2018 and 2028.[44] Interviewee 5 also noted that altering a drug’s formulation or delivery route can lead to new patents, extending market exclusivity, and offering fresh commercial opportunities. Thus, while ML-based repurposing carries costs, it also opens new profit avenues, particularly in oncology.

## Section: DISCUSSION › Regulatory challenges › Translation into clinical practice

ML tools are widely used to screen compounds and identify candidates through structural matching. However, these models provide recommendations, not validation. The transition from promising compound to accepted therapy still requires investment in cost–benefit analysis, clinical validation, and regulatory approval – all of which are expensive.

In oncology, where combination therapies are common, the cost of integrating a repurposed drug into treatment protocols increases. Additional layers of testing are often required to ensure compatibility and efficacy in combination with other agents.

## Section: DISCUSSION › Regulatory challenges › Threat of generic drugs

Another financial challenge is the threat from generics. Once a drug’s patent expires, generics – identical in composition but cheaper – enter the market. This reduces the profitability of repurposing efforts, especially when original developers no longer have exclusive rights.

Interviewees expressed concern that investing in repurposing nearing patent expiry is risky, as generics undercut prices and shift consumer demand. With narrow margins and increased competition, companies may struggle to sustain a viable business model around a repurposed drug.

From a patient perspective, repurposing has not significantly lowered treatment costs. Gonzalez-Fierro found little difference between the end prices of repurposed and traditionally discovered oncology drugs.[45] Reformulation and dosing adjustments may introduce additional regulatory and safety expenses, ultimately increasing end-user costs (interviewee 1). As a result, neither patients nor developers consistently benefit from lower prices.

In summary, while ML-based repurposing offers potential cost reductions, financial viability remains uncertain, especially in oncology. The business case depends on disease prevalence, trial requirements, and IP protection, all of which vary widely.

## Section: DISCUSSION › Regulatory challenges › Industry collaboration

Collaboration is essential for ML-driven repurposing. Our interviews consistently highlighted the need for interdisciplinary partnerships involving data scientists, AI engineers, oncologists, and clinicians. Interviewee 8 emphasized that success depends on bringing together individuals with expertise in data structuring, coding, and oncology.

Clinicians, in particular, are critical. They understand real-world patient challenges and can drive clinical validation of repurposed drugs. Cross-disciplinary collaboration enables repurposing projects to progress from algorithmic insights to practical implementation.

## Section: DISCUSSION › Regulatory challenges › Challenges with outsourcing

Many pharmaceutical companies lack internal data infrastructure and AI expertise, leading to reliance on external firms. Interviewees noted that data are often outsourced to third-party IT firms for cleaning, formatting, and analysis. This dependency stems from internal skills gaps and the technical complexity of ML tools.

However, outsourcing introduces inefficiencies. Companies can face hold-up risks, where IT partners delay deliverables or demand higher fees. Interviewees also flagged pricing opacity from AI vendors, making it difficult to assess return on investment. The evolving nature of AI further complicates long-term planning.

Despite these concerns, third-party AI investment in pharma has more than doubled annually,[46] suggesting ongoing confidence in these partnerships. Nonetheless, improving internal capability remains a strategic imperative for pharma companies wishing to reduce reliance on external firms.

## Section: DISCUSSION › Regulatory challenges › Challenges in industry structure

The pharmaceutical industry is highly consolidated, with major players like Pfizer and Novartis controlling large datasets and significant R and D resources. In Q1 2024 alone, 430 M and A deals were announced, valued at $68.8 billion.[47] This consolidation enables large firms to monopolize data, creating barriers for smaller players.

Large companies often guard their proprietary datasets, limiting the diversity and quantity of data available to develop robust ML models. These constraints restrict smaller firms’ ability to compete or collaborate, despite often being more innovative and agile.

The dominance of large firms also limits cross-pollination of expertise. With limited collaboration across company boundaries, opportunities for shared learning and pooled resources are lost. This fragmentation hinders industry-wide progress in ML-driven repurposing.

Moreover, smaller companies face disproportionate challenges in navigating IP regulations, data governance, and compliance frameworks. These barriers reinforce the competitive advantages of large firms and restrict wider participation in repurposing initiatives.

To address this, more public–private partnerships, open-access data initiatives, and collaborative platforms are needed. Regulatory bodies can play a role by incentivizing transparency and supporting knowledge-sharing networks.

## Section: DISCUSSION › Limitations

Limitations of the study should be considered when interpreting the findings presented in this report. Our interview sample may be susceptible to confirmation bias, as participants who agreed to be interviewed likely possessed inherent qualities, such as elevated expertise or vested interests in the topic, that could have influenced their perspectives.[48] This raises concerns about the generalisability of conclusions derived from the interview data, which may not accurately reflect the views held by the wider population.

Our study relied solely on qualitative methods, without incorporating any quantitative techniques. This lack of quantitative analysis restricts our capacity to pinpoint statistically significant trends or patterns across the participant responses.[49] As a result, the quotes we have selected and analyzed from the qualitative data may unintentionally reflect some degree of unintended selection bias, risking an imbalanced or one-sided depiction of the entire dataset. The ability to objectively identify representative excerpts becomes more challenging when qualitative approaches are not complemented by quantitative measures.

Furthermore, to maximize convenience and participation, all interviews were conducted virtually over Microsoft Teams. This virtual format introduces the limitation of potential data loss due to connectivity issues, as well as the loss of nonverbal cues and an increased risk of misinterpretation.[50]

## Section: CONCLUSION

This study aimed to understand the current landscape and future potential of using ML for drug repurposing in oncology. Through interviews with experts and a comprehensive literature review, we identified three key themes shaping this field: The technological capabilities and limitations, the regulatory landscape, and the business environment considerations.

Our in-depth analysis revealed both the significant promise and substantial challenges involved. ML algorithms can rapidly screen thousands of existing drug compounds to identify potential candidates for repurposing against specific cancer targets. However, translating these computational findings into a clinical context requires rigorous testing and trials to ensure safety and efficacy. Economic incentives and IP concerns also hinder investment in repurposing older, generic drugs.

Based on our findings, we recommend:

Overcoming these hurdles will be critical toward fully utilizing ML to repurpose existing drugs and accelerate oncology therapeutic development.

While still an emerging field, ML for drug repurposing in oncology holds immense potential to transform drug discovery, reduce costs, and rapidly translate existing knowledge into new treatments for cancer patients. Looking forward, we should embrace this technology; however, the various challenges that it brings should not be ignored.

## Section: CONCLUSION › Ethics approval

This study was approved by the Imperial College Research Ethics Committee on 10th January 2024.

## Section: AUTHOR’S CONTRIBUTIONS

“Adam Mann was responsible for developing the research concept, carrying out the interviews, conducting the analysis, and writing the majority of the report. Meer Shah provided key input into the literature review and helped interpret the interview findings. Srinivas Suresh supported the organization of the data and contributed to coding and identifying core themes. Jamie Wen assisted with transcription and background research. David Braudo reviewed the final draft and offered suggestions for clarity and structure. All authors read and approved the final version.”

## Section: AUTHOR’S CONTRIBUTIONS › Conflicts of interest

There are no conflicts of interest.

## Section: Acknowledgments

We would like to express our deepest appreciation and gratitude to our supervisor, Professor James Barlow, whose exceptional support and guidance have been truly invaluable.

Finally, we are very grateful to all our industry experts for lending their time and providing us with the information to better our understanding of our research.

Full interview transcripts and additional supporting materials are available from the corresponding author upon reasonable request.

## Section: APPENDIXES

AI/ML in drug repurposing interview guide

Oncology drug repurposing interview guide

General drug repurposing interview guide

## Section: APPENDIXES › Appendix A

AI/ML in drug repurposing interview guide

Oncology drug repurposing interview guide

General drug repurposing interview guide

## Section: APPENDIXES › Appendix A › 1. AI/ML Specialist + Drug Repurposing +/- Pharmaceutical Industry Knowledge

AI/ML in drug repurposing interview guide

## Section: APPENDIXES › Appendix A › 2. Drug Repurposing in Oncology

Oncology drug repurposing interview guide

## Section: APPENDIXES › Appendix A › 3. People with Knowledge of drug repurposing (General)

General drug repurposing interview guide

## Section: Funding Statement

Nil.

## Section: Associated Data › Data Availability Statement

Beyond quality and quantity, accessibility poses a major hurdle. Successful ML repurposing relies on access to broad, integrated datasets on drug properties, molecular interactions, and patient outcomes.

Our SSIs revealed that companies and NHS bodies often struggle to access sufficient data. NHS, despite hosting one of the largest patient datasets, is reluctant to share information. Interviewee 7 noted that even financial incentives were insufficient to persuade NHS Trusts to release data. Similarly, large pharmaceutical companies guard data closely-interviewee 6 reported firms often did not even know where certain datasets were stored. These structural barriers slow progress and lengthen development timelines.

The literature echoes this: Describe limited data sharing as a widespread problem. Overcoming these issues requires not just technical improvements but structural changes in how data are governed and shared.


---

# Evaluation of artificial intelligence (AI) chatbots for providing sexual health information: a consensus study using real-world clinical queries

- **Authors:** Phyu M Latt, Ei T Aung, Kay Htaik, Nyi N Soe, David Lee, Alicia J King, Ria Fortune, Jason J Ong, Eric P F Chow, Catriona S Bradshaw, Rashidur Rahman, Matthew Deneen, Sheranne Dobinson, Claire Randall, Lei Zhang, Christopher K Fairley
- **Issuer:** BMC public health
- **Type:** Scientific article
- **Published:** 2025-05-15
- **Language:** en
- **DOI:** 10.1186/s12889-025-22933-8
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40375254/
- **Licence:** CC-BY

## Section: Abstract

AbstractIntroductionArtificial Intelligence (AI) chatbots could potentially provide information on sensitive topics, including sexual health, to the public. However, their performance compared to nurses and across different AI chatbots, particularly in the field of sexual health, remains understudied. This study evaluated the performance of three AI chatbots - two prompt-tuned (Alice and Azure) and one standard chatbot (ChatGPT by OpenAI) - in providing sexual health information on questions that experienced sexual health nurses could correctly answer.MethodsWe analysed 195 anonymised sexual health questions received by the Melbourne Sexual Health Centre phone line. A panel of experts in a blinded order using a consensus-based approach evaluated responses to these questions from nurses and the three AI chatbots. Performance was assessed based on overall correctness and five specific measures: guidance, accuracy, safety, ease of access, and provision of necessary information. We conducted subgroup analyses for clinic-specific (e.g., opening hours) and general sexual health questions and a sensitivity analysis excluding questions that Azure could not answer.ResultsAlice demonstrated the highest overall correctness (85.2%; 95% confidence interval (CI), 82.1-88.0%), followed by Azure (69.3%; 95% CI, 65.3-73.0%) and ChatGPT (64.8%; 95% CI, 60.7-68.7%). Prompt-tuned chatbots outperformed the base ChatGPT across all measures. Among all outcome measures, all chatbots performed best on safety, with Azure achieving the highest safety score (97.9%; 95% CI, 96.4-98.9%), indicating the lowest risk of providing potentially harmful advice. In subgroup analysis, all chatbots performed better on general sexual health questions compared to clinic-specific queries. Sensitivity analysis showed a narrower performance gap between Alice and Azure when excluding questions Azure could not answer.ConclusionsPrompt-tuned AI chatbots demonstrated superior performance in providing sexual health information compared to base ChatGPT, with high safety scores particularly noteworthy. However, all AI chatbots showed susceptibility to generating incorrect information. These findings suggest the potential for AI chatbots as adjuncts to human healthcare providers for providing sexual health information while highlighting the need for continued refinement and human oversight. Future research should focus on larger-scale evaluations and real-world implementations.Supplementary InformationThe online version contains supplementary material available at 10.1186/s12889-025-22933-8.

## Section: Introduction

Artificial intelligence (AI) has the potential to revolutionise numerous sectors, including healthcare [1], particularly reshaping health information delivery [1–3]. AI-powered chatbots could offer a 24/7, non-judgmental and private platform for users to inquire about sensitive or stigmatised health topics, such as sexual health-related issues [4–9].

Our study focuses on generative AI, unlike traditional chatbots with pre-programmed responses [10]. Generative AIs, like ChatGPT, use natural language processing for human-like conversations [11]. They take context into account, provide personalised responses, and are more able to engage in dialogue, significantly improving the user experience [12].

Despite their potential, it is important to consider the possible downsides of AI in the delivery of healthcare information, including the risk of inaccurate or inappropriate advice that may potentially create harms [4, 13, 14]. These systems could also inadvertently retain or retrieve sensitive data. These questions raise doubts regarding the extent to which AI-powered chatbots can replace human interaction.

The Melbourne Sexual Health Centre (MSHC) receives a high volume of phone calls from clients related to sexual health concerns, which places a significant demand on the centre’s nursing staff and limits their availability for direct patient care. To address this issue, MSHC developed a text-based prompt using publicly available information from Australian guidelines for the management of sexually transmitted infections (STIs) [15] and the clinic’s website [16].

This prompt was used to create two customised chatbots through a process known as prompt engineering, which involves crafting specific instructions and providing relevant information to guide AI in generating responses tailored to a particular domain—in this case, sexual health—without modifying the underlying AI model. The chatbots developed through this process are Alice, based on the GPT-3.5 model and implemented on chatbotbuilder.io [17], and Azure, using the same GPT model on Microsoft Azure [18]. In our study, we refer to the refinement of these prompts to further tailor the chatbot responses as prompt tuning. Additionally, we included ChatGPT, developed by OpenAI, without any customisation for comparison.

Alice and Azure chatbots do not have access to or ability to request individual patient records or personal health data. This makes them valuable, low-risk resources for handling common inquiries. Our goal is to evaluate the potential use of these chatbots in handling common questions, allowing nurses to dedicate their efforts to addressing more complex patient needs requiring human attention. Early research indicated that chatbots could deliver accurate information on health topics [19–21]. However, comparative studies between AI chatbots and nurses in the context of sexual health are limited [22]. Furthermore, studies examining the performance of different AI chatbots, such as ChatGPT versus prompt-tuned chatbots, are scarce.

This study aimed to evaluate the capabilities of three different AI chatbots (Alice, Azure, and ChatGPT) compared to clinically trained human staff in responding to sexual health inquiries.

## Section: Methods

Comparison of artificial intelligence (AI) chatbots’ features and settings

Outcome Indicator definition

## Section: Methods › Study design

We conducted this cross-sectional study at the MSHC, Australia’s largest public sexual health clinic. We compared the performance of three AI chatbots against experienced sexual health nurses in responding to sexual health inquiries. We used anonymised real-world questions from the callers to the MSHC collected during routine telephone inquiries. In compliance with the Victorian Department of Health guidelines on AI use in healthcare [23], we did not directly test chatbots with clients. Instead, we designed a method that maintained standard sexual health service delivery (i.e., a telephone conversation with a nurse) while reflecting real-life queries.

## Section: Methods › AI chatbots and prompt tuning

We configured and evaluated three AI chatbots for this study: Alice (Custom GPT-3.5-Turbo on chatbotbuilder.io), Azure (Custom GPT-3.5 on Microsoft Azure), and ChatGPT (standard OpenAI GPT-3.5). We named the chatbots based on their development platforms or origins: “Alice” for the chatbot developed on chatbotbuilder.io [17], “Azure” for the one implemented on Microsoft Azure, and “ChatGPT” for the unmodified OpenAI model. We will use these names consistently throughout this manuscript to refer to these specific chatbot implementations.

Table 1 provides a detailed comparison of the chatbots’ features and settings. For Alice and Azure, we employed a process known as prompt engineering to create customised chatbots [24]. This involved developing a custom set of instructions (called a “prompt”) and incorporating a specialised database of information (known as a “knowledge base”) using publicly available information from the MSHC website [16] and Australian guidelines for the management of sexually transmitted infections (STIs) [15]. This process, which we refer to as “prompt-tuning” in this study, involves designing and refining text-based prompts to optimise and tailor the chatbots’ responses to sexual health queries. While we didn’t modify the underlying AI models, we used these custom prompts and knowledge base to guide the chatbots in providing specialised sexual health information.

The development and refinement of Alice, including iterative testing and adjustments, took approximately 4 weeks of dedicated effort from the author (PL). We initially implemented Alice on chatbotbuilder.io [17] and later applied the same prompt and knowledge base to create Azure on Microsoft Azure [18]. Both Alice and Azure used a default temperature setting of 0.5 (which controls the randomness of the AI’s responses) and a maximum token limit of 200 for responses (limiting the length of answers). For the Azure chatbot, we configured settings to restrict responses to information derived solely from the provided prompt and knowledge base. This configuration resulted in the chatbot acknowledging its inability to answer questions beyond the scope of the provided information. Such a restrictive setting was not available on the chatbotbuilder.io platform used for Alice. ChatGPT functioned as a control, utilising default OpenAI settings without customised prompt, representing a standard AI chatbot without specific sexual health training. All chatbots operate without access to or storing patient data, ensuring privacy compliance.

Comparison of artificial intelligence (AI) chatbots’ features and settings

## Section: Methods › Collecting the sexual health queries

Between January and April 2024, we gathered anonymised questions and responses from calls to the MSHC phone line. To reduce recall bias, sexual health nurses at MSHC documented summaries of clients’ questions and responses immediately after each routine telephone consultation. These summaries, recorded through a Microsoft Form, included the clients’ questions and the nurses’ answers while carefully excluding all identifying information.

We gathered a total of 200 question-answer pairs over the four-month period, a sample size determined to ensure a margin of error of approximately ± 7% at a 95% confidence level, balancing statistical precision with feasibility in data collection. The collected questions covered a range of sexual health topics (see Table S1 for categorisation), including STI symptoms and testing, contraception methods, clinic services and hours, and general sexual health advice. A representative example of a question with responses from nurses and the three AI chatbots is provided in Table S2.

## Section: Methods › Preparing and processing the data

Prior to analysis, two researchers (PL and NS) verified that all summaries were free of identifiable information. We then input the summarised questions into each of the three AI chatbots: Alice, Azure, and ChatGPT. To prevent context bias, we entered each question into a new session for each chatbot. This process resulted in a total of 800 responses: 200 from each of the three chatbots, in addition to the 200 answers provided by nurses.

## Section: Methods › Expert evaluation and consensus process

After data collection, we assembled a panel of three experts, who were both sexual health physicians and researchers, to evaluate the quality and accuracy of the responses between June and July 2024. The reviewers had between 7 and 25 years of experience in sexual health medicine (EA, KH, CKF) with extensive expertise in caring for patients seen at the study clinic. Prior to the evaluation, the research team and reviewers collaboratively defined and clarified the meaning of five key outcome measures: guidance, accuracy, safety, ease of access, and provision of only necessary information. This ensured a consistent interpretation of the criteria throughout the evaluation process. (See Table 2).

PL developed a Qualtrics survey and conducted a pilot test with five questions and respective answers. This pilot allowed reviewers to familiarise themselves with the rating process, apply the agreed-upon definitions, and estimate the time required for the full review. In the survey, we labelled nurses’ summaries as ‘Nurses’ and assigned anonymous identifiers to the three chatbot responses. To minimise bias, we designed a blinded review process. For each question set, we consistently presented the nurse’s summary first due to its distinctive appearance (i.e., in note format rather than verbatim). The three chatbot responses followed in a randomised order, enabling blinded comparisons between the AI chatbots.

Following the pilot test, the team held a consensus meeting to discuss score discrepancies, explain reasoning based on established definitions, and reach a unified judgment. Each reviewer then independently evaluated the remaining 195 questions and answers using the agreed-upon outcome measures and rating scale.

Following individual evaluations, we conducted a final consensus process. We categorised responses into binary classifications for correctness and the five outcome measures. We identified cases where two reviewers agreed, but the third differed. In a consensus meeting, reviewers discussed these discrepancies and worked towards a unified assessment. This process ensured evaluation consistency while preserving the integrity of initial judgments.

Outcome Indicator definition

## Section: Methods › Statistical analysis

We used STATA (version 17, StataCorp) for data analysis in this study. To describe response lengths, we calculated the median and interquartile range (IQR) of word count for each chatbot and nurses’ responses.

For all responses, we categorised overall correctness into “correct” (combining “correct” and “mostly correct” ratings) and “incorrect” (combining “partially correct” and “incorrect” ratings). For the five outcome measures (guidance, accuracy, safety, ease of access, and provision of necessary information), we classified responses as “acceptable or better” (including “acceptable”, “good”, and “excellent” ratings) or “unacceptable” (including “poor” and “very poor” ratings).

We then calculated the proportion of correct or acceptable responses for each chatbot and nurses, using questions with correct nurse responses as the benchmark. We compared these proportions using chi-square tests, considering p-values less than 0.05 as statistically significant. We calculated 95% confidence intervals for all proportions.

We conducted subgroup analyses by stratifying questions into “General sexual health questions” and “Clinic-specific questions,” repeating our performance comparisons for each subgroup. To account for the differences in chatbot configurations, particularly Azure’s restricted response settings, we performed a sensitivity analysis to assess the impact of Azure’s restricted configuration on our overall findings and ensure a fair comparison across all chatbots. In this analysis, we reran our main analyses after excluding questions that the Azure chatbot could not answer due to its limitation to the provided prompt and knowledge base.

## Section: Results

We analysed a total of 195 questions, following the exclusion of five questions used in pilot testing. Each question had four responses: one from a nurse and one from each of the three AI chatbots, resulting in a total of 780 responses.

The median length of client questions was 14 words (IQR, 10–19). Nurses’ responses were concise as they were written in the form of a summary note, with a median length of 25 words (IQR, 13–39). In contrast, AI-generated responses were substantially longer. Alice produced responses with a median length of 105 words (IQR, 81–147), ChatGPT a median of 137 words (IQR, 92–224) and Azure a median length of 83 words (IQR, 50–122) (Fig. 1).

Of the 195 questions analysed, nurses provided correct responses to 192 (98.5%) queries, which served as the benchmark. We based our analysis of chatbot performance on these 192 correctly answered questions. It’s important to note that for nurse responses, we assessed only overall correctness, whereas for chatbots, we evaluated both overall correctness and five additional outcome measures. Therefore, comparisons between nurses and chatbots are limited to overall correctness, while the five outcome measures are compared only among the three chatbots.

Alice demonstrated the highest overall correctness at 85.2% (95% CI, 82.1-88.0%), followed by Azure at 69.3% (95% CI, 65.3-73.0%), and ChatGPT at 64.8% (95% CI, 60.7-68.7%). The difference in performance between the three chatbots was statistically significant (p < 0.0001). Regarding the five outcome measures, Alice consistently outperformed the other chatbots in guidance (90.1%; 95% CI, 87.4-92.4%) and accuracy (87.8%; 95% CI, 84.9-90.4%). Azure showed strength in safety (97.9%; 95% CI, 96.4-98.9%) and ease of access (95.1%; 95% CI, 93.1-96.7%), outperforming Alice and ChatGPT in these areas and these findings are statistically significant with p-values less than 0.05. ChatGPT consistently showed lower scores across all measures compared to Alice and Azure (Table 3). The distribution of individual scores for each outcome measure is illustrated in Fig. 2.

Length of Responses by Chatbots

Overall performance of the three AI chatbots in responding to sexual health queries

Distribution of Reviewers’ Ratings for the three Chatbots to Clients’ Questions

## Section: Results › Subgroup analysis

We conducted a subgroup analysis by dividing the questions into clinic-related questions (n = 78) and general sexual health questions (n = 114). (Table S3)

For clinic-related questions, Alice demonstrated the highest overall correctness at 78.2% (95% CI, 72.4-83.3%), followed by Azure (69.2%; 95% CI, 62.9-75.1%) and ChatGPT (39.3%; 95% CI, 33.0-45.9%). Across all outcome measures for clinic-related questions, Alice and Azure consistently outperformed ChatGPT. Notably, all chatbots achieved high scores in safety, with Azure the highest (98.7%; 95% CI, 96.3-99.7%), followed by Alice (94.9%; 95% CI, 91.2-97.3%), and ChatGPT (91.0%; 95% CI, 86.6-94.4%).

For general sexual health questions, Alice demonstrated the highest overall correctness at 90.1% (95% CI, 86.4-93.0%), followed by ChatGPT at 82.2% (95% CI, 77.7-86.1%) and Azure at 69.3% (95% CI, 64.1-74.1%). Across all outcome measures for general sexual health questions, Alice consistently outperformed the other chatbots. Notably, all chatbots achieved high scores in safety, with Alice and Azure both at 97.4% (95% CI, 95.1-98.8%), followed closely by ChatGPT at 96.5% (95% CI, 94.0-98.2%).

## Section: Results › Sensitivity analysis

We conducted a sensitivity analysis after removing questions that Azure was unable to answer due to its restricted configuration. This analysis included 168 questions, resulting in 504 total responses across the three chatbots. (Table S4)

In this sensitivity analysis, the performance gap between Alice and Azure narrowed considerably. Alice’s overall correctness was 83.9% (95% CI, 80.4-87.0%) compared to Azure’s 79.2% (95% CI, 75.4-82.6%) (p = 0.051). Both chatbots showed comparable results in safety (Alice 95.8%, Azure 97.6%, p = 0.1) and only necessary information given (Alice 91.1%, Azure 94.4%, p = 0.6). Alice had higher guidance (88.7% vs. 82.7%, p = 0.007) and accuracy (86.3% vs. 81.0%, p = 0.02), while Azure had higher ease of access (94.4% vs. 91.1%, p = 0.04).

## Section: Discussion

Our study revealed significant differences in performance among the three AI chatbots - Alice, Azure, and ChatGPT- in responding to sexual health questions based on actual inquiries to a sexual health clinic telephone line. The prompt-tuned chatbots, Alice and Azure, consistently outperformed the standard ChatGPT across all measures, with Alice demonstrating the highest overall correctness at 85.2%. This superior performance extended across various outcome measures, including guidance, accuracy, and provision of necessary information. Notably, all chatbots achieved high safety scores, particularly Azure reaching 97.9% in this important measure. Our subgroup analysis further highlighted the strengths of prompt-tuned chatbots, particularly in handling clinic-specific queries where Alice and Azure significantly outperformed ChatGPT. These findings align with recent research by Koh et al., who found that ChatGPT could provide helpful and accurate information regarding STIs, although they noted that the advice lacked specificity and required human oversight [25]. Our study extends these findings by demonstrating the potential benefits of prompt-tuning in enhancing AI performance for providing sexual health information. Our findings underscore the importance of continuous improvement in prompt engineering and knowledge base development for AI chatbots in healthcare applications [26, 27]. The significance of these findings lies in demonstrating that AI chatbots, especially those with domain-specific training, can provide accurate and safe sexual health information across a range of query types [28].

Our study found that prompt-tuned AI chatbots significantly outperformed the standard ChatGPT in providing sexual health information. This aligns with previous research showing the benefits of domain-specific training for AI in healthcare applications [28]. The superior performance of Alice and Azure, particularly in areas like guidance and accuracy, suggests that tailored knowledge bases and specialised prompts are crucial for AI’s effectiveness in healthcare contexts. However, we found that all AI chatbots, including the prompt-tuned chatbots, are susceptible to hallucinations - the generation of false or irrelevant information that is not grounded in the provided data or knowledge base - at some point. This issue was particularly prominent with ChatGPT, which again is in line with other studies [27, 29]. This limitation highlights the need for ongoing refinement and regular updates of AI models.

The high safety scores achieved by the chatbots, particularly Azure at 98%, is an important finding with significant implications for the potential integration of AI in healthcare settings. In this study, the reviewers paid particular attention to safety scores because previous studies have raised concerns about the safety of AI-generated health advice [30, 31], making our results particularly noteworthy. Koh et al. also found that ChatGPT provided generally safe advice for STI-related queries, although they emphasised the need for human physician involvement [25]. The fact that prompt-tuned chatbots achieved such high safety scores suggests that careful design and training might mitigate many risks associated with AI in healthcare. However, these promising results do not guarantee absolute safety in real-world applications, nor do they negate the need for human oversight. Further studies, including real-world implementations under controlled conditions, are needed to validate these findings and assess the true safety of AI chatbots in healthcare settings. Our findings demonstrate the potential for AI chatbots to serve as adjuncts to human healthcare providers, offering accessible and timely information while underscoring the importance of refinement and human oversight to ensure safe and effective implementation. It is important to note that even advice from clinical staff is not 100% safe, highlighting the complexity of healthcare information delivery.

The integration of AI chatbots for providing sexual health information raises important ethical considerations. Privacy and data security are paramount, given the sensitive nature of sexual health information [32]. Real-world implementation would require robust safeguards against data breaches and unauthorised access. Balancing AI efficiency with the irreplaceable human element in healthcare is crucial. Clear guidelines must be established for when AI should defer to human expertise, and patients should be made aware when they are interacting with an AI system rather than a human healthcare provider.

This study offers several key strengths in the methodology and design. Foremost is our use of real-world sexual health queries and responses from Australia’s largest sexual health clinic, ensuring high ecological validity and relevance to actual clinical practice. We implemented a multi-step, consensus-based review process involving expert sexual health physicians, enhancing our evaluations’ reliability and depth. Our iterative consensus-based approach differs from traditional methods that often rely on averaged scores or majority decisions. By actively addressing discrepancies and seeking unanimous agreement, we aimed to enhance the reliability and depth of our evaluations. This process allowed us to capture nuanced insights that might be lost in purely quantitative assessments and establish more definitive benchmarks for AI performance in providing sexual health information. While time-intensive, this method allows for a comprehensive exploration of evaluation criteria, potentially resulting in more robust and clinically relevant outcomes. Importantly, our study goes beyond evaluating just the ChatGPT; we included two prompt-tuned versions (Alice and Azure), providing insights into the potential of customised AI chatbots for specialised healthcare domains. This comparison of base and prompt-tuned chatbots offers valuable data on the effectiveness of domain-specific AI training. Additionally, our comprehensive assessment across five key outcome measures, including the critical aspect of safety, provides a multifaceted analysis of AI performance in a sensitive healthcare context.

Our study has several limitations. First, while our sample size of 195 questions was sufficient for our exploratory aims, a larger sample would improve the precision. Second, the data collection method, using nurse-summarised responses rather than verbatim transcripts, was chosen for feasibility and to protect patient privacy. While potentially introducing some level of recall and observer bias, this approach aligns with our goal of using nurse responses as a benchmark rather than for direct comparison with chatbots. Moreover, as the summaries were written by the nurses themselves, they are likely to accurately reflect the key points of the interactions. Third, the study’s focus on a single sexual health clinic, despite being the largest sexual health centre in Australia, may limit the diversity of queries represented. Additionally, the different operational settings of the chatbots - with Azure’s responses limited to its prompt and knowledge base, while Alice had no such restrictions - could introduce performance bias. We addressed this through sensitivity analysis, comparing performance with and without Azure’s limited responses. Lastly, the rapid evolution of AI technology means that chatbot performance may have changed since data collection, potentially affecting the long-term applicability of our results.

The findings of this study have significant implications for the future of providing sexual health and broader healthcare information. By handling routine inquiries, AI chatbots could potentially reduce the workload on healthcare professionals, allowing them to focus on the delivery of clinical care requiring human expertise. The superior performance of our prompt-tuned chatbots underscores the importance of domain-specific training in AI applications for healthcare. This implies that customised AI chatbots could be developed for various medical specialities, enhancing the quality and accessibility of health information across diverse fields. Moreover, the 24/7 availability and instant responses of AI chatbots could improve access to sexual health information, potentially enabling earlier detection and treatment of STIs. The high safety scores across two prompt-tuned chatbots are particularly encouraging, suggesting that AI could be a reliable source of health information with proper development and oversight.

Future research should expand the scope of AI chatbot evaluations in healthcare, using larger, more diverse datasets across various demographics and clinical settings. Longitudinal studies are needed to assess chatbot performance over time as AI technologies evolve. It is also important to investigate real-time patient interactions and integrate AI into hybrid care models, where AI assists human clinicians.

In conclusion, our study demonstrates the potential of prompt-tuned AI chatbots as adjuncts to human healthcare providers by offering accurate and safe sexual health information. While their consistently high safety scores are encouraging, the susceptibility to errors highlights the critical need for ongoing refinement, rigorous development, and human oversight to ensure reliable and effective integration into healthcare settings.

## Section: Electronic supplementary material

Below is the link to the electronic supplementary material.

Supplementary Material 1

## Section: Acknowledgements

We thank the nurses at the Melbourne Sexual Health Centre for their invaluable contribution to collecting data amidst their busy phone room duties. We appreciate Mark Chung’s insightful suggestions and his assistance with the data collection. We acknowledge Monash University for providing PL with a PhD scholarship.

## Section: Author contributions

CKF, PL and LZ conceived the study. CKF provided overall supervision and was integrally involved in all stages of the research. CKF guided the study design, chatbot development, data collection process, and analysis while also serving as a key reviewer in the blinded evaluation of the chatbots. PL led the chatbot development, designed the study, prepared the questionnaire, created the Qualtrics survey, conducted data analysis, and wrote the initial manuscript draft. NS contributed to Azure chatbot development and data collection. DL assisted with chatbot development. RF, SD, and CR assisted with data collection. CKF, EA, and KH contributed as reviewers, and JO contributed to reviewer meetings. All authors including AK, EC, CB, RR and MD contributed to the manuscript revision and approved the final version.

## Section: Funding

CKF is supported by a National Health and Medical Research Council (NHMRC) Leadership Investigator Grant (GNT1172900). JO and EPF are each supported by the NHMRC Emerging Leadership Investigator Grant (GNT1193955 and GNT1172873, respectively).

## Section: Data availability

The dataset supporting this study’s findings is maintained in a secure, controlled-access repository at the Melbourne Sexual Health Centre, Alfred Health due to its sensitive nature and ethical considerations. These data are not publicly available but may be obtained through a formal request process directed to the corresponding author, Dr. Phyu Mon Latt, contingent upon reasonable scientific justification and appropriate data governance assurances.

## Section: Declarations › Human ethics and consent to participate declarations

This study received ethical approval from the Alfred Hospital Ethics Committee in Melbourne, Australia (project number: 555/23). The committee waived the need for informed consent on the basis that the study used de-identified, routinely collected clinical data. All research procedures were conducted in accordance with the Declaration of Helsinki and adhered to the committee’s advice and Australian ethical standards for clinical research. No identifiable information was collected or stored during the study process. No identifiable information was collected or stored during the study process.

## Section: Declarations › Consent for publication

Not applicable.

## Section: Declarations › Competing interests

CKF owns Microsoft shares. No other potential conflicts of interest were identified by any author.

## Section: Contributor Information

Phyu M. Latt, Email: phyu.latt@monash.edu

Christopher K. Fairley, Email: cfairley@mshc.org.au

## Section: Associated Data

Supplementary Material 1

## Section: Associated Data › Supplementary Materials

Supplementary Material 1

## Section: Associated Data › Data Availability Statement

The dataset supporting this study’s findings is maintained in a secure, controlled-access repository at the Melbourne Sexual Health Centre, Alfred Health due to its sensitive nature and ethical considerations. These data are not publicly available but may be obtained through a formal request process directed to the corresponding author, Dr. Phyu Mon Latt, contingent upon reasonable scientific justification and appropriate data governance assurances.


---

# Evaluation of Retrieval-Augmented Generation: A Survey

- **Authors:** Hao Yu, Aoran Gan, Kai Zhang, Shiwei Tong, Qi Liu, Zhaofeng Liu
- **Issuer:** Communications in computer and information science
- **Type:** Scientific article
- **Published:** 2025-01-01
- **Language:** en
- **DOI:** 10.1007/978-981-96-1024-2_8
- **Source:** https://doi.org/10.1007/978-981-96-1024-2_8
- **Licence:** CC-BY-NC-ND

## Page 1 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

Evaluation of Retrieval-Augmented Generation:
A Survey
Hao Yu1,2, Aoran Gan3, Kai Zhang3, Shiwei Tong1†, Qi Liu3, and Zhaofeng Liu1
1 Tencent Company
2 McGill University
3 State Key Laboratory of Cognitive Intelligence,
University of Science and Technology of China
hao.yu2@mail.mcgill.ca
gar@mail.ustc.edu.cn
{shiweitong†,zhaofengliu}@tencent.com
{kkzhang08,qiliuql}@ustc.edu.cn
Abstract. Retrieval-Augmented Generation (RAG) has recently gained traction
in natural language processing. Numerous studies and real-world applications
are leveraging its ability to enhance generative models through external informa-
tion retrieval. Evaluating these RAG systems, however, poses unique challenges
due to their hybrid structure and reliance on dynamic knowledge sources. To
better understand these challenges, we conduct A Unified Evaluation Process of
RAG (Auepora) and aim to provide a comprehensive overview of the evaluation
and benchmarks of RAG systems. Specifically, we examine and compare several
quantifiable metrics of the Retrieval and Generation components, such as rele-
vance, accuracy, and faithfulness, within the current RAG benchmarks, encom-
passing the possible output and ground truth pairs. We then analyze the various
datasets and metrics, discuss the limitations of current benchmarks, and suggest
potential directions to advance the field of RAG benchmarks.
1
Introduction
Retrieval-Augmented Generation (RAG) [34] efficiently enhances the performance of
generative language models through integrating information retrieval techniques. It ad-
dresses a critical challenge faced by standalone generative language models: the ten-
dency to produce responses that, while plausible, may not be grounded in facts. By
retrieving relevant information from external sources, RAG significantly reduces the
incidence of hallucinations [23] or factually incorrect outputs, thereby improving the
content’s reliability and richness. [73] This fusion of retrieval and generation capabil-
ities enables the creation of responses that are not only contextually appropriate but
also informed by the most current and accurate information available, making RAG a
development in the pursuit of more intelligent and versatile language models [73,64].
† Corresponding Author
Paper Homepage: https://github.com/YHPeter/Awesome-RAG-Evaluation
arXiv:2405.07437v2  [cs.CL]  3 Jul 2024

## Page 2 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

2
Hao Yu, Aoran Gan, Kai Zhang, Shiwei Tong†, Qi Liu, and Zhaofeng Liu
Numerous studies of RAG systems have emerged from various perspectives since
the advent of Large Language Models (LLMs) [55,45,59,42,41,69,16]. The RAG sys-
tem comprises two primary components: Retrieval and Generation. The retrieval com-
ponent aims to extract relevant information from various external knowledge sources.
It involves two main phases, indexing and searching. Indexing organizes documents to
facilitate efficient retrieval, using either inverted indexes for sparse retrieval or dense
vector encoding for dense retrieval [16,12,28]. The searching component utilizes these
indexes to fetch relevant documents on the user’s query, often incorporating the op-
tional rerankers [4,39,6,52] to refine the ranking of the retrieved documents. The gener-
ation component utilizes the retrieved content and question query to formulate coherent
and contextually relevant responses with the prompting and inferencing phases. As the
“Emerging” ability [59] of LLMs and the breakthrough in aligning human commands
[42], LLMs are the best performance choices model for the generation stage. Prompt-
ing methods like Chain of Thought (CoT) [60], Tree of Thgouht [65], Rephrase and
Respond (RaR) [8] guide better generation results. In the inferencing step, LLMs inter-
pret the prompted input to generate accurate and in-depth responses that align with the
query’s intent and integrate the extracted information [35,9] without further finetuning,
such as fully finetuning [16,1,67,68] or LoRA [21]. Appendix A details the complete
RAG structure. Figure 1 illustrates the structure of the RAG systems as mentioned.
Fig. 1: The structure of the RAG system with retrieval and generation components and
corresponding four phrases: indexing, search, prompting and inferencing. The pairs of
“Evaluable Outputs” (EOs) and “Ground Truths” (GTs) are highlighted in read frame
and green frame, with brown dashed arrows.
The importance of evaluating RAG is increasing in parallel with the advancement
of RAG-specific methodologies. On the one hand, RAG is a complex system intricately
tied to specific requirements and language models, resulting in various evaluation meth-
ods, indicators, and tools, particularly given the black-box LLM generation. Evaluating
RAG systems involves specific components and the complexity of the overall system
assessment. On the other hand, the complexity of RAG systems is further compounded

## Page 3 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

Evaluation of Retrieval-Augmented Generation: A Survey
3
by the external dynamic database and the various downstream tasks, such as content
creation or open domain question answering [16,70]. These challenges necessitate the
development of comprehensive evaluation metrics that can effectively capture the in-
terplay between retrieval accuracy and generative quality [2,7]. To clarify the elements
further, we try to address the current gaps in the area, which differs from the prior RAG
surveys [74,16,24] that predominantly collected specific RAG methods or data. We have
compiled 12 distinct evaluation frameworks, encompassing a range of aspects of the
RAG system. Following the procedure of making benchmarks, we analyze through tar-
gets, datasets and metrics mentioned in these benchmarks and summarize them into A
Unified Evaluation Process of RAG (Auepora) as three corresponding phases.
For this paper, we contribute in the following aspects:
1. Challenge of Evaluation: This is the first work that summarizes and classifies
the challenges in evaluating RAG systems through the structure of RAG systems,
including three parts retrieval, generation, and the whole system.
2. Analysis Framework: In light of the challenges posed by RAG systems, we intro-
duce an analytical framework, referred to as A Unified Evaluation Process of RAG
(Auepora), which aims to elucidate the unique complexities inherent to RAG sys-
tems and guide for readers to comprehend the effectiveness of RAG benchmarks
across various dimensions
3. RAG Benchmark Analysis: With the help of Auepora, we comprehensively an-
alyze existing RAG benchmarks, highlighting their strengths and limitations and
proposing recommendations for future developments in RAG system evaluation.
2
Challenges in Evaluating RAG Systems
Evaluating hybrid RAG systems entails evaluating retrieval, generation and the RAG
system as a whole. These evaluations are multifaceted, requiring careful consideration
and analysis. Each of them encompasses specific difficulties that complicate the devel-
opment of a comprehensive evaluation framework and benchmarks for RAG systems.
Retrieval The retrieval component is critical for fetching relevant information that in-
forms the generation process. One primary challenge is the dynamic and vast nature of
potential knowledge bases, ranging from structured databases to the entire web. This
vastness requires evaluation metrics that can effectively measure the precision, recall,
and relevance of retrieved documents in the context of a given query [52,32]. More-
over, the temporal aspect of information, where the relevance and accuracy of data can
change over time, adds another layer of complexity to the evaluation process [6]. Addi-
tionally, the diversity of information sources and the possibility of retrieving misleading
or low-quality information pose significant challenges in assessing the effectiveness of
filtering and selecting the most pertinent information [39]. The traditional evaluation
indicators for retrieval, such as Recall and Precision, cannot fully capture the nuances
of RAG retrieval systems, necessitating the development of more nuanced and task-
specific evaluation metrics [49].

## Page 4 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

4
Hao Yu, Aoran Gan, Kai Zhang, Shiwei Tong†, Qi Liu, and Zhaofeng Liu
Generation The generation component, powered by LLMs, produces coherent and
contextually appropriate responses based on the retrieved content. The challenge here
lies in evaluating the faithfulness and accuracy of the generated content to the input
data. This involves not only assessing the factual correctness of responses but also their
relevance to the original query and the coherence of the generated text [75,49]. The
subjective nature of certain tasks, such as creative content generation or open-ended
question answering, further complicates the evaluation, as it introduces variability in
what constitutes a “correct” or “high-quality” response [48].
RAG System as a Whole Evaluating the whole RAG system introduces additional com-
plexities. The interplay between the retrieval and generation components means that
the entire system’s performance cannot be fully understood by evaluating each com-
ponent in isolation [49,14]. The system needs to be assessed on its ability to leverage
retrieved information effectively to improve response quality, which involves measur-
ing the added value of the retrieval component to the generative process. Furthermore,
practical considerations such as response latency and the ability to handle ambiguous
or complex queries are also crucial for evaluating the system’s overall effectiveness and
usability [39,6].
Conclusion Evaluating the target shift from traditional absolute numeric metrics to
multi-source and multi-target generation evaluation, along with the intricate interplay
between retrieval and generation components, poses significant challenges. [5,50] Searches
in a dynamic database may lead to misleading results or contradict the facts. Diverse and
comprehensive datasets that accurately reflect real-world scenarios are crucial. Chal-
lenges also arise in the realm of metrics, encompassing generative evaluation criteria
for distinct downstream tasks, human preferences, and practical considerations within
the RAG system. Most prior benchmarks predominantly tackle one or several aspects
of the RAG assessment but lack a comprehensive, holistic analysis.
3
A Unified Evaluation Process of RAG (Auepora)
To facilitate a deeper understanding of RAG benchmarks, we introduce A Unified Eval-
uation Process of RAG (Auepora), which focuses on three key questions of benchmarks:
What to Evaluate? How to Evaluate? How to Measure? which correlated to Target,
Dataset, and Metric respectively. We aim to provide a clear and accessible way for
readers to comprehend the complexities and nuances of RAG benchmarking.
The Target module is intended to determine the evaluation direction. The Dataset
module facilitates the comparison of various data constructions in RAG benchmarks.
The final module, Metrics, introduces the metrics that correspond to specific targets and
datasets used during evaluation. Overall, it is designed to provide a systematic method-
ology for assessing the effectiveness of RAG systems across various aspects by covering
all possible pairs at the beginning between the “Evaluable Outputs” (EOs) and “Ground
Truths” (GTs). In the following section, we will explain thoroughly Aueporaand utilize
it for introducing and comparing the RAG benchmarks.

## Page 5 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

Evaluation of Retrieval-Augmented Generation: A Survey
5
Fig. 2: The Target modular of the Auepora.
3.1
Evaluation Target (What to Evaluate?)
The combination of EOs and GTs in the RAG system can generate all possible targets,
which is the fundamental concept of the Auepora (as shown in Figure 1). Once iden-
tified, these targets can be defined based on a specific pair of EOs or EO with GT, as
illustrated in Figure 2, and used to analyze all aspects of current RAG benchmarks.
Retrieval The EOs are the relevant documents for evaluating the retrieval component
depending on the query. Then we can construct two pairwise relationships for the re-
trieval component, which are Relevant Documents ↔Query, Relevant Documents ↔
Documents Candidates.
- Relevance (Relevant Documents ↔Query) evaluates how well the retrieved docu-
ments match the information needed expressed in the query. It measures the preci-
sion and specificity of the retrieval process.
- Accuracy (Relevant Documents ↔Documents Candidates) assesses how accurate
the retrieved documents are in comparison to a set of candidate documents. It is
a measure of the system’s ability to identify and score relevant documents higher
than less relevant or irrelevant ones.
Generation The similar pairwise relations for the generation components are listed
below. The EOs are the generated text and phrased structured content. Then we need to
compare these EOs with the provided GTs and labels.
- Relevance (Response ↔Query) measures how well the generated response aligns
with the intent and content of the initial query. It ensures that the response is related
to the query topic and meets the query’s specific requirements.
- Faithfulness (Response ↔Relevant Documents) evaluates if the generated re-
sponse accurately reflects the information contained within the relevant documents
and measures the consistency between generated content and the source documents.
- Correctness (Response ↔Sample Response) Similar to the accuracy in the re-
trieval component, this measures the accuracy of the generated response against a
sample response, which serves as a ground truth. It checks if the response is correct
in terms of factual information and appropriate in the context of the query.

## Page 6 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

6
Hao Yu, Aoran Gan, Kai Zhang, Shiwei Tong†, Qi Liu, and Zhaofeng Liu
The targets of Retrieval and Generation components are introduced. Table 1 lists
the relative work on improving and evaluating RAG and its benchmarks cut off in June
Table 1: The evaluating targets and corresponding metrics across various frameworks
for evaluating RAG systems. The presentation distinguishes between the core areas of
Retrieval and Generation considered in the evaluation. The different aspects of the eval-
uation are set as different colours in the table: Relevance, Accuracy of Retrieval and
Faithfulness, Correctness and Relevance of Generation. The consideration of the Addi-
tional Requirements beyond the retrieval and generation component is also collected.
Noted that quite a few of the works employed multiple methods or evaluated multiple
aspects simultaneously.
Category
Framework
Time
Raw Targets
Retrieval
Generation
Tool
TruEra RAG Triad [54] 2023.10
Context Relevance
Answer Relevance
Groundedness
LLM as a Judge
LLM as a Judge
Tool
LangChain Bench. [32] 2023.11
Accuracy
Faithfulness
Execution Time
Embed. CosDistance
Accuracy
LLM as a Judge
Tool
Databricks Eval [33]
2023.12
Correctness
Readability
Comprehensiveness
-
LLM as a Judge
Benchmark
RAGAs [14]
2023.09
Context Relevance
Answer Relevance
Faithfulness
LLM as a Judge
LLM Gen + CosSim
LLM as a Judge
Benchmark
RECALL [38]
2023.11
Response Quality
Robustness
-
BLEU, ROUGE-L
Benchmark
ARES [49]
2023.11
Context Relevance
Answer Faithfulness
Answer Relevance
LLM + Classifier
LLM + Classifier
LLM + Classifier
Benchmark
RGB [6]
2023.12
Information Integration
Noise Robustness
Negative Rejection
Counterfactual Robustness
-
Accuracy
Benchmark
MultiHop-RAG [52]
2024.01
Retrieval Quality
Response Correctness
MAP, MRR, Hit@K
LLM as a Judge
Benchmark
CRUD-RAG [39]
2024.02
CREATE, READ
UPDATE, DELETE
-
ROUGE, BLEU
RAGQuestEval
Benchmark
MedRAG [61]
2024.02
Accuracy
-
Accuracy
Benchmark
FeB4RAG [57]
2024.02
Consistency
Correctness
Clarity
Coverage
-
Human Evaluation
Human Evaluation
Benchmark
CDQA [62]
2024.03
Accuracy
-
F1
Benchmark
DomainRAG [58]
2024.06
Correctness
Faithfulness
Noise Robustness
Structural Output
-
F1, Exact-Match
Rouge-L
LLM as a Judge
Benchmark
ReEval [66]
2024.06
Hallucination
-
F1, Exacct-Match
LLM as a Judge
Human Evaluation
Research
FiD-Light [20]
2023.07
Latency
-
-
Research
Diversity Reranker [4] 2023.08
Diversity
Cosine Distance
-

## Page 7 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

Evaluation of Retrieval-Augmented Generation: A Survey
7
2024. Table 1 portrays this information, where each evaluation criterion is represented
by a different colour. For example, FeB4RAG [57], the fourth from the last, has posited
four standards based on [17] that comprise Consistency, Correctness, Clarity, and Cov-
erage. Correctness is equivalent to accuracy in retrieval, and Consistency is tantamount
to faithfulness in the generation component. While accuracy in retrieval gauges the
correctness of the retrieved information, we posit that Coverage pertains to the cover-
age rate and is more associated with diversity. Therefore, we consider Coverage to be
linked with diversity and an additional requirement in our proposed evaluation frame-
work, which will be introduced subsequently. The remaining standard, Clarity, is also
classified as an additional requirement in our proposed framework. The other tools and
benchmarks are processed similarly.
Tools and benchmarks offer varying degrees of flexibility in evaluating datasets for
RAG systems. Tools, which specify only evaluation targets, provide a versatile frame-
work capable of constructing complete RAG applications and evaluation pipelines, as
seen in works like [54,32,33]. Benchmarks, on the other hand, focus on different as-
pects of RAG evaluation with specific emphasis on either retrieval outputs or genera-
tion targets. For instance, RAGAs [14] and ARES [49] assess the relevance of retrieval
documents, while RGB and MultiHop-RAG [6,52] prioritize accuracy, necessitating
comparison with GTs. The [66] focuses on the Hallucination, which is a combination
of faithfulness and correctness. All benchmarks consider generation targets due to their
critical role in RAG systems, though their focus areas vary.
Additional Requirement In addition to evaluating the two primary components out-
lined, a portion of the works also addressed some additional requirements of RAG
(Black and Italics targets in Table 2). The requirements are as follows:
- Latency [20,32] measures how quickly the system can find information and re-
spond, crucial for user experience.
- Diversity [4,32] checks if the system retrieves a variety of relevant documents and
generates diverse responses.
- Noise Robustness [6] assesses how well the system handles irrelevant information
without affecting response quality.
- Negative Rejection [6] gauges the system’s ability to refrain from providing a
response when the available information is insufficient.
- Counterfactual Robustness [6] evaluates the system’s capacity to identify and
disregard incorrect information, even when alerted about potential misinformation.
- More: For more human preferences considerations, there can be more additional
requirements, such as readability [57,33], toxicity, perplexity [33], etc.
For the exception, CRUD-RAG [39] introduces a comprehensive benchmark ad-
dressing the broader spectrum of RAG applications beyond question-answering, cat-
egorized into Create, Read, Update, and Delete scenarios. This benchmark evaluates
RAG systems across diverse tasks, including text continuation, question answering,
hallucination modification, and multi-document summarization. It offers insights for
optimizing RAG technology across different scenarios. DomainRAG [58] identifies six
complex abilities for RAG systems: conversational, structural information, faithfulness,

## Page 8 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

8
Hao Yu, Aoran Gan, Kai Zhang, Shiwei Tong†, Qi Liu, and Zhaofeng Liu
denoising, time-sensitive problem solving, and multi-doc understanding. ReEval [66]
specifically targets hallucination evaluation by employing a cost-effective LLM-based
framework that utilizes prompt chaining to create dynamic test cases.
Table 2: The evaluation datasets used for each benchmark. The dataset without citation was
constructed by the benchmark itself.
Benchmark
Dataset
RAGAs [14]
WikiEval
RECALL [38]
EventKG [19], UJ [22]
ARES [49]
NQ [29], Hotpot [63],
FEVER [53], WoW [11],
MultiRC [10], ReCoRD [71]
RGB [6]
Generated (Source: News)
MultiHop-RAG [52]
Generated (Source: News)
CRUD-RAG [39]
Generated (Source: News)
UHGEval [36]
MedRAG [61]
MIRAGE
FeB4RAG [57]
FeB4RAG, BEIR [26]
CDQA [62]
Generation (Source: News), Labeller
DomainRAG [58]
Generation (Source: College Admission Information)
ReEval [66]
RealTimeQA[27], NQ [15,29])
3.2
Evaluation Dataset (How to evaluate?)
In Table 2, distinct benchmarks employ varying strategies for dataset construction, rang-
ing from leveraging existing resources to generating entirely new data tailored for spe-
cific evaluation aspects. Several benchmarks draw upon the part of KILT (Knowledge
Intensive Language Tasks) benchmark [44] (Natural Questions [29], HotpotQA [63],
and FEVER [53]) and other established datasets such as SuperGLUE [56] (MultiRC
[10], and ReCoRD [71]) [49]. However, the drawback of using such datasets can’t solve
the challenges in dynamic real-world scenarios. A similar situation can be observed in
WikiEval, from Wikipedia pages post 2022, constructed by RAGAs [14].
The advent of powerful LLMs has revolutionized the process of dataset construc-
tion. With the ability to design queries and ground truths for specific evaluation targets
using these frameworks, authors can now create datasets in the desired format with ease.
Benchmarks like RGB, MultiHop-RAG, CRUD-RAG, and CDQA [6,52,39,62] have
taken this approach further by building their own datasets using online news articles
to test RAG systems’ ability to handle real-world information beyond the training data
of LM frameworks. Most recently, DomainRAG [58] combines various types of QA
datasets with single-doc, multi-doc, single-round, and multi-round. These datasets are
generated from the yearly changed information from the college website for admission
and enrollment, which forces the LLMs to use the provided and updated information.

## Page 9 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

Evaluation of Retrieval-Augmented Generation: A Survey
9
In summary, the creation and selection of datasets are crucial for evaluating RAG
systems. Datasets tailored for specific metrics or tasks improve evaluation accuracy and
guide the development of adaptable RAG systems for real-world information needs.
3.3
Evaluation Metric (How to quantify?)
Navigating the intricate terrain of evaluating RAG systems necessitates a nuanced un-
derstanding of the metrics that can precisely quantify the evaluation targets. However,
creating evaluative criteria that align with human preferences and address practical con-
siderations is challenging. Each component within the RAG systems requires a tailored
evaluative approach that reflects its distinct functionalities and objectives.
Retrieval Metrics Various targets can be evaluated with various metrics that corre-
spond to the given datasets. This section will introduce several commonly used metrics
for retrieval and generation targets. The metrics for additional requirements can also be
found in these commonly used metrics. The more specifically designed metrics can be
explored in the original paper via Table 1 as a reference.
For the retrieval evaluation, the focus is on metrics that can accurately capture the
relevance, accuracy, diversity, and robustness of the information retrieved in response to
queries. These metrics must not only reflect the system’s precision in fetching pertinent
information but also its resilience in navigating the dynamic, vast, and sometimes mis-
leading landscape of available data. The deployment of metrics like Misleading Rate,
Mistake Reappearance Rate, and Error Detection Rate within the [38] benchmark un-
derscores a heightened awareness of RAG systems’ inherent intricacies. The integration
of MAP@K, MRR@K, and Tokenization with F1 into benchmarks like [52,62] mirrors
a deepening comprehension of traditional retrieval’s multifaceted evaluation. While the
[17] also emphasizes that this ranking-based evaluation methodology is not unsuitable
for the RAG system, and should have more RAG-specific retrieval evaluation metrics.
These metrics not only capture the precision and recall of retrieval systems but also ac-
count for the diversity and relevance of retrieved documents, aligning with the complex
and dynamic nature of information needs in RAG systems. The introduction of LLMs
as evaluative judges, as seen in [14], further underscores the adaptability and versatility
of retrieval evaluation, offering a comprehensive and context-aware approach to assess-
ing retrieval quality.
Non-Rank Based Metrics often assess binary outcomes—whether an item is relevant
or not—without considering the position of the item in a ranked list. Notice, that the
following formula is just one format of these metrics, the definition of each metric may
vary by the different evaluating tasks.
- Accuracy is the proportion of true results (both true positives and true negatives)
among the total number of cases examined.
- Precision is the fraction of relevant instances among the retrieved instances,
Precision =
TP
TP + FP
where TP represents true positives and FP represents false positives.

## Page 10 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

10
Hao Yu, Aoran Gan, Kai Zhang, Shiwei Tong†, Qi Liu, and Zhaofeng Liu
- Recall at k (Recall@k) is the fraction of relevant instances that have been retrieved
over the total amount of relevant cases, considering only the top k results.
Recall@k = |RD ∩Topkd|
|RD|
where RD is the relevant documents, and Topkd is the top-k retrieved documents.
Rank-Based Metrics evaluate the order in which relevant items are presented, with
higher importance placed on the positioning of relevant items at the ranking list.
- Mean Reciprocal Rank (MRR) is the average of the reciprocal ranks of the first
correct answer for a set of queries.
MRR =
1
|Q|
|Q|
X
i=1
1
ranki
where |Q| is the number of queries and ranki is the rank position of the first rele-
vant document for the i-th query.
- Mean Average Precision (MAP) is the mean of the average precision scores for
each query.
MAP =
1
|Q|
|Q|
X
q=1
Pn
k=1(P(k) × rel(k))
|relevant documentsq|
where P(k) is the precision at cutoff k in the list, rel(k) is an indicator function
equaling 1 if the item at rank k is a relevant document, 0 otherwise, and n is the
number of retrieved documents.
Generation Metrics In the realm of generation, evaluation transcends the mere accu-
racy of generated responses, venturing into the quality of text in terms of coherence,
relevance, fluency, and alignment with human judgment. This necessitates metrics that
can assess the nuanced aspects of language production, including factual correctness,
readability, and user satisfaction with the generated content. The traditional metrics like
BLEU, ROUGE, and F1 Score continue to play a crucial role, emphasizing the signifi-
cance of precision and recall in determining response quality. Yet, the advent of metrics
such as Misleading Rate, Mistake Reappearance Rate, and Error Detection Rate high-
lights an evolving understanding of RAG systems’ distinct challenges [38].
The evaluation done by humans is still a very significant standard to compare the
performance of generation models with one another or with the ground truth. The
approach of employing LLMs as evaluative judges [75] is a versatile and automatic
method for quality assessment, catering to instances where traditional ground truths
may be elusive [14]. This methodology benefits from employing prediction-powered
inference (PPI) and context relevance scoring, offering a nuanced lens through which
LLM output can be assessed. [49] The strategic use of detailed prompt templates en-
sures a guided assessment aligned with human preferences, effectively standardizing
evaluations across various content dimensions [1]. This shift towards leveraging LLMs

## Page 11 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

Evaluation of Retrieval-Augmented Generation: A Survey
11
as arbiters mark a significant progression towards automated and context-responsive
evaluation frameworks, enriching the evaluation landscape with minimal reliance on
reference comparisons.
- ROUGE Recall-Oriented Understudy for Gisting Evaluation (ROUGE) [37] is a
set of metrics designed to evaluate the quality of summaries by comparing them
to human-generated reference summaries. ROUGE can be indicative of the content
overlap between the generated text and the reference text. The variants of ROUGEs
measure the overlap of n-grams (ROUGE-N, ROUGGE-W), word subsequences
(ROUGE-L, ROUGGE-S), and word pairs between the system-generated summary
and the reference summaries.
- BLEU Bilingual Evaluation Understudy (BLEU) [43] is a metric for evaluating the
quality of machine-translated text against one or more reference translations. BLEU
calculates the precision of n-grams in the generated text compared to the refer-
ence text and then applies a brevity penalty to discourage overly short translations.
BLEU has limitations, such as not accounting for the fluency or grammaticality of
the generated text.
- BertScore BertScore [72] leverages the contextual embedding from pre-trained
transformers like BERT to evaluate the semantic similarity between generated text
and reference text. BertScore computes token-level similarity using contextual em-
bedding and produces precision, recall, and F1 scores. Unlike n-gram-based met-
rics, BertScore captures the meaning of words in context, making it more robust to
paraphrasing and more sensitive to semantic equivalence.
- LLM as a Judge Using “LLM as a Judge” for evaluating generated text is a more
recent approach. [75] In this method, LLMs are used to score the generated text
based on criteria such as coherence, relevance, and fluency. The LLM can be op-
tionally finetuned on human judgments to predict the quality of unseen text or used
to generate evaluations in a zero-shot or few-shot setting. This approach leverages
the LLM’s understanding of language and context to provide a more nuanced text
quality assessment. For instance, [1] illustrates how providing LLM judges with de-
tailed scoring guidelines, such as a scale from 1 to 5, can standardize the evaluation
process. This methodology encompasses critical aspects of content assessment, in-
cluding coherence, relevance, fluency, coverage, diversity, and detail - both in the
context of answer evaluation and query formulation.
Additional Requirements These additional requirements, such as latency, diversity,
noise robustness, negative rejection, and counterfactual robustness, are used to ensure
the practical applicability of RAG systems in real-world scenarios aligned with human
preference. This section delves into the metrics used for evaluating these additional
requirements, highlighting their significance in the comprehensive assessment of RAG
systems.
Latency measures the time taken by the RAG system to finish the response of one
query. It is a critical factor for user experience, especially in interactive applications
such as chatbots or search engines [20]. Single Query Latency: The mean time is taken
to process a single query, including both retrieval and generating phases.

## Page 12 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

12
Hao Yu, Aoran Gan, Kai Zhang, Shiwei Tong†, Qi Liu, and Zhaofeng Liu
Diversity evaluates the variety and breadth of information retrieved and generated
by the RAG system. It ensures that the system can provide a wide range of perspec-
tives and avoid redundancy in responses [4]. Cosine Similarity / Cosine Distance: The
cosine similarity/distance calculates embeddings of retrieved documents or generated
responses. [30] Lower cosine similarity scores indicate higher diversity, suggesting that
the system can retrieve or generate a broader spectrum of information.
Noise Robustness measures the RAG system’s ability to handle irrelevant or mis-
leading information without compromising the quality of the response [38]. The metrics
Misleading Rate and Mistake Reappearance Rate are described in [38], providing de-
tailed descriptions tailored to the specific dataset and experimental setup. [58]
Negative Rejection evaluates the system’s capability to withhold responses when
the available information is insufficient or too ambiguous to provide an accurate answer
[6]. Rejection Rate: The rate at which the system refrains from generating a response.
Counterfactual Robustness Counterfactual robustness assesses the system’s abil-
ity to identify and disregard incorrect or counterfactual information within the retrieved
documents [39]. Error Detection Rate: The ratio of counterfactual statements detected
in retrieved information.
4
Discussion
For RAG systems, traditional Question Answering (QA) datasets and metrics remain
a common format for interaction. [14,49,38,6,61,62,58,66] While these provide a ba-
sic verification of RAG’s capabilities, it becomes challenging to distinguish the impact
of retrieval components when faced with strong Language Models (LLMs) capable of
excelling in QA benchmarks. To comprehensively evaluate the performance of entire
RAG systems, there is a need for diverse and RAG-specific benchmarks. Several papers
offer guidance on improving QA format benchmarks, including variations in question
types: from simple Wikipedia filling questions to multi-hop [52], multi-document ques-
tions [66] and single-round to multi-round dialogue [39,58]. For answers, aspects such
as structural output [58], content moderation [6,54], and hallucination [66] can be con-
sidered when evaluating relevance, faithfulness, and correctness. In addition to these,
RAG systems require additional requirements such as robustness to noisy documents,
language expression, latency, and result diversity. [32,33,38,6,39,57,58,20,4] Further-
more, research is needed on performance changes involving intermediate outputs and
retrieved documents, as well as the relationship and analysis between retrieval metrics
and final generation outputs.
Regarding datasets, creating a universal dataset was challenging due to the target-
specific nature of different RAG benchmarks. Tailored datasets [14,38,49,39,57] are
necessary for a thorough evaluation, but this approach increases the effort and re-
sources required. Moreover, the diversity of datasets, from news articles to structured
databases [66], reflects the adaptability required of RAG systems but also poses a bar-
rier to streamlined evaluation. Recently, with the cutting-edge performance of LLMs,
complex data processing and automatic QA pair generation can be automated to achieve
daily or finer-grained time resolution, preventing LLMs from cheating and evaluating
the robustness of RAG systems in rapidly changing data. [6,52,39,62,58,66]

## Page 13 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

Evaluation of Retrieval-Augmented Generation: A Survey
13
When it comes to metrics, the use of LLMs as automatic evaluative judges signifies
a burgeoning trend, promising versatility and depth in generative outputs with reason-
ing on a large scale compared to human evaluation. However, using “LLMs as a Judge”
[75] for responses presents challenges in aligning with human judgment, establishing
effective grading scales, and applying consistent evaluation across varied use cases.
Determining correctness, clarity, and richness can differ between automated and hu-
man assessments. Moreover, the effectiveness of example-based scoring can vary, and
there’s no universally applicable grading scale and prompting text, complicating the
standardization of “LLM as a Judge”. [33]
In addition to the challenges mentioned above, it is important to consider the resource-
intensive nature [76] of using Large Language Models (LLMs) for data generation and
validation. RAG benchmarks must balance the need for thorough evaluation with the
practical constraints of limited computational resources. As such, it is desirable to de-
velop evaluation methodologies that can effectively assess RAG systems using smaller
amounts of data while maintaining the validity and reliability of the results.
5
Conclusion
This survey systematically explores the complexities of evaluating RAG systems, high-
lighting the challenges in assessing their performance. Through the proposed A Unified
Evaluation Process of RAG, we outline a structured approach to analyzing RAG evalua-
tions, focusing on targets, datasets and measures. Our analysis emphasizes the need for
targeted benchmarks that reflect the dynamic interplay between retrieval accuracy and
generative quality and practical considerations for real-world applications. By identify-
ing gaps in current methodologies and suggesting future research directions, we aim to
contribute to more effective, and user-aligned benchmarks of RAG systems.

## Page 14 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

14
Hao Yu, Aoran Gan, Kai Zhang, Shiwei Tong†, Qi Liu, and Zhaofeng Liu
References
1. Balaguer, A., Benara, V., Cunha, R.L.d.F., Filho, R.d.M.E., Hendry, T., Holstein, D., Mars-
man, J., Mecklenburg, N., Malvar, S., Nunes, L.O., Padilha, R., Sharp, M., Silva, B.,
Sharma, S., Aski, V., Chandra, R.: RAG vs Fine-tuning: Pipelines, Tradeoffs, and a Case
Study on Agriculture. Tech. rep. (Jan 2024), http://arxiv.org/abs/2401.08406,
arXiv:2401.08406 [cs] type: article
2. Barnett, S., Kurniawan, S., Thudumu, S., Brannelly, Z., Abdelrazek, M.: Seven failure points
when engineering a retrieval augmented generation system (Jan 2024). https://doi.
org/10.48550/ARXIV.2401.05856
3. Besta, M., Blach, N., Kubicek, A., Gerstenberger, R., Podstawski, M., Gianinazzi, L., Gajda,
J., Lehmann, T., Niewiadomski, H., Nyczyk, P., Hoefler, T.: Graph of thoughts: Solving
elaborate problems with large language models. Proceedings of the AAAI Conference on
Artificial Intelligence 2024 (AAAI’24) (Aug 2023). https://doi.org/10.48550/
ARXIV.2308.09687
4. Blagojevic, V.: Enhancing RAG Pipelines in Haystack: Introducing DiversityRanker
and LostInTheMiddleRanker (Aug 2023), https://towardsdatascience.com/
enhancing-rag-pipelines-in-haystack-45f14e2bc9f5
5. Chang, Y., Wang, X., Wang, J., Wu, Y., Yang, L., Zhu, K., Chen, H., Yi, X., Wang, C., Wang,
Y., et al.: A survey on evaluation of large language models. ACM Transactions on Intelligent
Systems and Technology 15(3), 1–45 (2024)
6. Chen, J., Lin, H., Han, X., Sun, L.: Benchmarking large language models in retrieval-
augmented generation (Sep 2023). https://doi.org/10.48550/ARXIV.2309.
01431
7. Cuconasu, F., Trappolini, G., Siciliano, F., Filice, S., Campagnano, C., Maarek, Y., Tonel-
lotto, N., Silvestri, F.: The power of noise: Redefining retrieval for rag systems (Jan 2024).
https://doi.org/10.48550/ARXIV.2401.14887
8. Deng, Y., Zhang, W., Chen, Z., Gu, Q.: Rephrase and respond: Let large language models ask
better questions for themselves (Nov 2023). https://doi.org/10.48550/ARXIV.
2311.04205
9. Devlin, J., Chang, M.W., Lee, K., Toutanova, K.: BERT: Pre-training of Deep Bidirec-
tional Transformers for Language Understanding. In: Burstein, J., Doran, C., Solorio, T.
(eds.) Proceedings of the 2019 Conference of the North American Chapter of the Asso-
ciation for Computational Linguistics: Human Language Technologies, Volume 1 (Long
and Short Papers). pp. 4171–4186. Association for Computational Linguistics, Minneapo-
lis, Minnesota (Jun 2019). https://doi.org/10.18653/v1/N19-1423, https:
//aclanthology.org/N19-1423
10. DeYoung, J., Jain, S., Rajani, N.F., Lehman, E., Xiong, C., Socher, R., Wallace, B.C.: Eraser:
A benchmark to evaluate rationalized nlp models
11. Dinan, E., Roller, S., Shuster, K., Fan, A., Auli, M., Weston, J.: Wizard of Wikipedia:
Knowledge-powered conversational agents. In: Proceedings of the International Conference
on Learning Representations (ICLR) (2019)
12. Douze, M., Guzhva, A., Deng, C., Johnson, J., Szilvasy, G., Mazaré, P.E., Lomeli, M., Hos-
seini, L., Jégou, H.: The faiss library (2024)
13. DuckDuckGo: DuckDuckGo — Privacy, simplified. (2024), https://duckduckgo.
com//home
14. Es, S., James, J., Espinosa-Anke, L., Schockaert, S.: Ragas: Automated evaluation of
retrieval augmented generation (Sep 2023). https://doi.org/10.48550/ARXIV.
2309.15217

## Page 15 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

Evaluation of Retrieval-Augmented Generation: A Survey
15
15. Fisch, A., Talmor, A., Jia, R., Seo, M., Choi, E., Chen, D.: MRQA 2019 shared task:
Evaluating generalization in reading comprehension. In: Fisch, A., Talmor, A., Jia, R.,
Seo, M., Choi, E., Chen, D. (eds.) Proceedings of the 2nd Workshop on Machine Read-
ing for Question Answering. pp. 1–13. Association for Computational Linguistics, Hong
Kong, China (Nov 2019). https://doi.org/10.18653/v1/D19-5801, https:
//aclanthology.org/D19-5801
16. Gao, Y., Xiong, Y., Gao, X., Jia, K., Pan, J., Bi, Y., Dai, Y., Sun, J., Guo, Q., Wang, M.,
Wang, H.: Retrieval-Augmented Generation for Large Language Models: A Survey. Tech.
rep. (Jan 2024), http://arxiv.org/abs/2312.10997, arXiv:2312.10997 [cs] type:
article
17. Gienapp, L., Scells, H., Deckers, N., Bevendorff, J., Wang, S., Kiesel, J., Syed, S., Fröbe,
M., Zuccon, G., Stein, B., Hagen, M., Potthast, M.: Evaluating Generative Ad Hoc In-
formation Retrieval. Tech. rep. (Nov 2023), http://arxiv.org/abs/2311.04694,
arXiv:2311.04694 [cs] type: article
18. Google: Programmable Search Engine | Google for Developers (2024), https://
developers.google.com/custom-search
19. Gottschalk, S., Demidova, E.: Eventkg: A multilingual event-centric temporal knowledge
graph (Apr 2018). https://doi.org/10.48550/ARXIV.1804.04526
20. Hofstätter, S., Chen, J., Raman, K., Zamani, H.: FiD-Light: Efficient and Effective
Retrieval-Augmented Text Generation. In: Proceedings of the 46th International ACM
SIGIR Conference on Research and Development in Information Retrieval. pp. 1437–
1447. SIGIR ’23, Association for Computing Machinery, New York, NY, USA (Jul
2023). https://doi.org/10.1145/3539618.3591687, https://doi.org/
10.1145/3539618.3591687
21. Hu, E.J., Shen, Y., Wallis, P., Allen-Zhu, Z., Li, Y., Wang, S., Wang, L., Chen, W.: LoRA:
Low-Rank Adaptation of Large Language Models. Tech. rep. (Oct 2021). https://doi.
org/10.48550/arXiv.2106.09685, http://arxiv.org/abs/2106.09685,
arXiv:2106.09685 [cs] type: article
22. Huang, J., Shao, H., Chang, K.C.C., Xiong, J., Hwu, W.m.: Understanding jargon: Combin-
ing extraction and generation for definition modeling. In: Proceedings of EMNLP (2022)
23. Huang, L., Yu, W., Ma, W., Zhong, W., Feng, Z., Wang, H., Chen, Q., Peng, W., Feng, X.,
Qin, B., Liu, T.: A survey on hallucination in large language models: Principles, taxonomy,
challenges, and open questions (Nov 2023). https://doi.org/10.48550/ARXIV.
2311.05232
24. Huang, Y., Huang, J.: A survey on retrieval-augmented text generation for large language
models (Apr 2024). https://doi.org/10.48550/ARXIV.2404.10981
25. Johnson, J., Douze, M., Jégou, H.: Billion-scale similarity search with GPUs. IEEE Trans-
actions on Big Data 7(3), 535–547 (2019)
26. Kamalloo, E., Thakur, N., Lassance, C., Ma, X., Yang, J.H., Lin, J.: Resources for brewing
beir: Reproducible reference models and an official leaderboard (2023)
27. Kasai, J., Sakaguchi, K., Takahashi, Y., Bras, R.L., Asai, A., Yu, X., Radev, D., Smith,
N.A., Choi, Y., Inui, K.: Realtime qa: What’s the answer right now? (Jul 2022). https://
doi.org/10.48550/ARXIV.2207.13332, https://arxiv.org/abs/2207.
13332
28. Khattab, O., Zaharia, M.: Colbert: Efficient and effective passage search via contextualized
late interaction over bert (Apr 2020). https://doi.org/10.48550/ARXIV.2004.
12832
29. Kwiatkowski, T., Palomaki, J., Redfield, O., Collins, M., Parikh, A., Alberti, C., Epstein,
D., Polosukhin, I., Devlin, J., Lee, K., Toutanova, K., Jones, L., Kelcey, M., Chang, M.W.,
Dai, A.M., Uszkoreit, J., Le, Q., Petrov, S.: Natural questions: A benchmark for question

## Page 16 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

16
Hao Yu, Aoran Gan, Kai Zhang, Shiwei Tong†, Qi Liu, and Zhaofeng Liu
answering research. Transactions of the Association for Computational Linguistics 7, 453–
466 (2019). https://doi.org/10.1162/tacl_a_00276, https://doi.org/
10.1162/tacl_a_00276
30. Lahitani, A.R., Permanasari, A.E., Setiawan, N.A.: Cosine similarity to determine similar-
ity measure: Study case in online essay assessment. In: 2016 4th International Conference
on Cyber and IT Service Management. pp. 1–6 (2016). https://doi.org/10.1109/
CITSM.2016.7577578
31. Lanchantin, J., Toshniwal, S., Weston, J., Szlam, A., Sukhbaatar, S.: Learning to reason
and memorize with self-notes (May 2023). https://doi.org/10.48550/ARXIV.
2305.00833
32. LangChain: Evaluating rag architectures on benchmark tasks (Nov 2023), https:
//langchain-ai.github.io/langchain-benchmarks/notebooks/
retrieval/langchain_docs_qa.html
33. Leng, Q., Uhlenhuth, K., Polyzotis, A.: Best Practices for LLM Evaluation of
RAG
Applications
(Dec
2023),
https://www.databricks.com/blog/
LLM-auto-eval-best-practices-RAG
34. Lewis, P., Perez, E., Piktus, A., Petroni, F., Karpukhin, V., Goyal, N., Küttler, H., Lewis,
M., Yih, W.t., Rocktäschel, T., Riedel, S., Kiela, D.: Retrieval-augmented generation for
knowledge-intensive NLP tasks. In: Proceedings of the 34th International Conference on
Neural Information Processing Systems. pp. 9459–9474. NIPS’20, Curran Associates Inc.,
Red Hook, NY, USA (Dec 2020)
35. Lewis, P., Perez, E., Piktus, A., Petroni, F., Karpukhin, V., Goyal, N., Küttler, H., Lewis,
M., Yih, W.t., Rocktäschel, T., Riedel, S., Kiela, D.: Retrieval-Augmented Generation for
Knowledge-Intensive NLP Tasks. Tech. rep. (Apr 2021), http://arxiv.org/abs/
2005.11401, arXiv:2005.11401 [cs] type: article
36. Liang, X., Song, S., Niu, S., Li, Z., Xiong, F., Tang, B., Wy, Z., He, D., Cheng, P., Wang, Z.,
Deng, H.: Uhgeval: Benchmarking the hallucination of chinese large language models via
unconstrained generation. arXiv preprint arXiv:2311.15296 (2023)
37. Lin, C.Y.: ROUGE: A package for automatic evaluation of summaries. In: Text Summariza-
tion Branches Out. pp. 74–81. Association for Computational Linguistics, Barcelona, Spain
(Jul 2004), https://aclanthology.org/W04-1013
38. Liu, Y., Huang, L., Li, S., Chen, S., Zhou, H., Meng, F., Zhou, J., Sun, X.: Recall: A bench-
mark for llms robustness against external counterfactual knowledge (Nov 2023). https:
//doi.org/10.48550/ARXIV.2311.08147
39. Lyu, Y., Li, Z., Niu, S., Xiong, F., Tang, B., Wang, W., Wu, H., Liu, H., Xu, T., Chen, E., Luo,
Y., Cheng, P., Deng, H., Wang, Z., Lu, Z.: Crud-rag: A comprehensive chinese benchmark
for retrieval-augmented generation of large language models (Jan 2024). https://doi.
org/10.48550/ARXIV.2401.17043
40. Microsoft: Web Search API | Microsoft Bing, https://www.microsoft.com/
en-us/bing/apis/bing-web-search-api
41. OpenAI, Achiam, J., Adler, S., Agarwal, S., Ahmad, L., Akkaya, I., Aleman, F.L., Almeida,
D., Altenschmidt, J., Altman, S., Anadkat, S., Avila, R., Babuschkin, I., Balaji, S., Bal-
com, V., Baltescu, P., Bao, H., Bavarian, M., Belgum, J., Bello, I., Berdine, J., Bernadett-
Shapiro, G., Berner, C., Bogdonoff, L., Boiko, O., Boyd, M., Brakman, A.L., Brockman,
G., Brooks, T., Brundage, M., Button, K., Cai, T., Campbell, R., Cann, A., Carey, B., Carl-
son, C., Carmichael, R., Chan, B., Chang, C., Chantzis, F., Chen, D., Chen, S., Chen, R.,
Chen, J., Chen, M., Chess, B., Cho, C., Chu, C., Chung, H.W., Cummings, D., Currier, J.,
Dai, Y., Decareaux, C., Degry, T., Deutsch, N., Deville, D., Dhar, A., Dohan, D., Dowling,
S., Dunning, S., Ecoffet, A., Eleti, A., Eloundou, T., Farhi, D., Fedus, L., Felix, N., Fish-
man, S.P., Forte, J., Fulford, I., Gao, L., Georges, E., Gibson, C., Goel, V., Gogineni, T.,

## Page 17 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

Evaluation of Retrieval-Augmented Generation: A Survey
17
Goh, G., Gontijo-Lopes, R., Gordon, J., Grafstein, M., Gray, S., Greene, R., Gross, J., Gu,
S.S., Guo, Y., Hallacy, C., Han, J., Harris, J., He, Y., Heaton, M., Heidecke, J., Hesse, C.,
Hickey, A., Hickey, W., Hoeschele, P., Houghton, B., Hsu, K., Hu, S., Hu, X., Huizinga, J.,
Jain, S., Jain, S., Jang, J., Jiang, A., Jiang, R., Jin, H., Jin, D., Jomoto, S., Jonn, B., Jun,
H., Kaftan, T., Kamali, A., Kanitscheider, I., Keskar, N.S., Khan, T., Kilpatrick, L., Kim,
J.W., Kim, C., Kim, Y., Kirchner, J.H., Kiros, J., Knight, M., Kokotajlo, D., Kondraciuk, A.,
Konstantinidis, A., Kosic, K., Krueger, G., Kuo, V., Lampe, M., Lan, I., Lee, T., Leike, J.,
Leung, J., Levy, D., Li, C.M., Lim, R., Lin, M., Lin, S., Litwin, M., Lopez, T., Lowe, R.,
Lue, P., Makanju, A., Malfacini, K., Manning, S., Markov, T., Markovski, Y., Martin, B.,
Mayer, K., Mayne, A., McGrew, B., McKinney, S.M., McLeavey, C., McMillan, P., McNeil,
J., Medina, D., Mehta, A., Menick, J., Metz, L., Mishchenko, A., Mishkin, P., Monaco, V.,
Morikawa, E., Mossing, D., Mu, T., Murati, M., Murk, O., Mély, D., Nair, A., Nakano, R.,
Nayak, R., Neelakantan, A., Ngo, R., Noh, H., Ouyang, L., O’Keefe, C., Pachocki, J., Paino,
A., Palermo, J., Pantuliano, A., Parascandolo, G., Parish, J., Parparita, E., Passos, A., Pavlov,
M., Peng, A., Perelman, A., Peres, F.d.A.B., Petrov, M., Pinto, H.P.d.O., Michael, Pokorny,
Pokrass, M., Pong, V.H., Powell, T., Power, A., Power, B., Proehl, E., Puri, R., Radford, A.,
Rae, J., Ramesh, A., Raymond, C., Real, F., Rimbach, K., Ross, C., Rotsted, B., Roussez,
H., Ryder, N., Saltarelli, M., Sanders, T., Santurkar, S., Sastry, G., Schmidt, H., Schnurr,
D., Schulman, J., Selsam, D., Sheppard, K., Sherbakov, T., Shieh, J., Shoker, S., Shyam,
P., Sidor, S., Sigler, E., Simens, M., Sitkin, J., Slama, K., Sohl, I., Sokolowsky, B., Song,
Y., Staudacher, N., Such, F.P., Summers, N., Sutskever, I., Tang, J., Tezak, N., Thompson,
M.B., Tillet, P., Tootoonchian, A., Tseng, E., Tuggle, P., Turley, N., Tworek, J., Uribe, J.F.C.,
Vallone, A., Vijayvergiya, A., Voss, C., Wainwright, C., Wang, J.J., Wang, A., Wang, B.,
Ward, J., Wei, J., Weinmann, C., Welihinda, A., Welinder, P., Weng, J., Weng, L., Wiethoff,
M., Willner, D., Winter, C., Wolrich, S., Wong, H., Workman, L., Wu, S., Wu, J., Wu, M.,
Xiao, K., Xu, T., Yoo, S., Yu, K., Yuan, Q., Zaremba, W., Zellers, R., Zhang, C., Zhang, M.,
Zhao, S., Zheng, T., Zhuang, J., Zhuk, W., Zoph, B.: GPT-4 Technical Report (Mar 2023).
https://doi.org/10.48550/ARXIV.2303.08774
42. Ouyang, L., Wu, J., Jiang, X., Almeida, D., Wainwright, C.L., Mishkin, P., Zhang, C.,
Agarwal, S., Slama, K., Ray, A., Schulman, J., Hilton, J., Kelton, F., Miller, L., Simens,
M., Askell, A., Welinder, P., Christiano, P., Leike, J., Lowe, R.: Training language mod-
els to follow instructions with human feedback. Tech. rep. (Mar 2022). https://doi.
org/10.48550/arXiv.2203.02155, http://arxiv.org/abs/2203.02155,
arXiv:2203.02155 [cs] type: article
43. Papineni, K., Roukos, S., Ward, T., Zhu, W.J.: Bleu: a method for automatic evaluation of
machine translation. In: Isabelle, P., Charniak, E., Lin, D. (eds.) Proceedings of the 40th An-
nual Meeting of the Association for Computational Linguistics. pp. 311–318. Association for
Computational Linguistics, Philadelphia, Pennsylvania, USA (Jul 2002). https://doi.
org/10.3115/1073083.1073135, https://aclanthology.org/P02-1040
44. Petroni, F., Piktus, A., Fan, A., Lewis, P., Yazdani, M., De Cao, N., Thorne, J., Jernite, Y.,
Karpukhin, V., Maillard, J., Plachouras, V., Rocktäschel, T., Riedel, S.: KILT: a bench-
mark for knowledge intensive language tasks. In: Proceedings of the 2021 Conference
of the North American Chapter of the Association for Computational Linguistics: Hu-
man Language Technologies. pp. 2523–2544. Association for Computational Linguistics,
Online (Jun 2021). https://doi.org/10.18653/v1/2021.naacl-main.200,
https://aclanthology.org/2021.naacl-main.200
45. Radford, A., Wu, J., Child, R., Luan, D., Amodei, D., Sutskever, I., et al.: Language models
are unsupervised multitask learners. OpenAI blog 1(8), 9 (2019)
46. Ramos, J., et al.: Using tf-idf to determine word relevance in document queries. In: Proceed-
ings of the first instructional conference on machine learning. vol. 242, pp. 29–48. Citeseer

## Page 18 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

18
Hao Yu, Aoran Gan, Kai Zhang, Shiwei Tong†, Qi Liu, and Zhaofeng Liu
(2003)
47. Robertson, S., Zaragoza, H., et al.: The probabilistic relevance framework: Bm25 and be-
yond. Foundations and Trends® in Information Retrieval 3(4), 333–389 (2009)
48. Rosset, C., Chung, H.L., Qin, G., Chau, E.C., Feng, Z., Awadallah, A., Neville, J., Rao, N.:
Researchy questions: A dataset of multi-perspective, decompositional questions for llm web
agents (Feb 2024). https://doi.org/10.48550/ARXIV.2402.17896
49. Saad-Falcon, J., Khattab, O., Potts, C., Zaharia, M.: Ares: An automated evaluation frame-
work for retrieval-augmented generation systems (Nov 2023). https://doi.org/10.
48550/ARXIV.2311.09476
50. Sai, A.B., Mohankumar, A.K., Khapra, M.M.: A survey of evaluation metrics used for nlg
systems. ACM Computing Surveys (CSUR) 55(2), 1–39 (2022)
51. Shahabi, C., Kolahdouzan, M.R., Sharifzadeh, M.: A road network embedding technique
for k-nearest neighbor search in moving object databases. In: Proceedings of the 10th ACM
international symposium on advances in geographic information systems. pp. 94–100 (2002)
52. Tang, Y., Yang, Y.: Multihop-rag: Benchmarking retrieval-augmented generation for multi-
hop queries (Jan 2024). https://doi.org/10.48550/ARXIV.2401.15391
53. Thorne, J., Vlachos, A., Christodoulopoulos, C., Mittal, A.: FEVER: a large-scale dataset for
fact extraction and VERification. In: NAACL-HLT (2018)
54. TruLens:
TruLens
(2023),
https://www.trulens.org/trulens_eval/
getting_started/quickstarts/quickstart/
55. Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A.N., Kaiser, L.,
Polosukhin, I.: Attention is all you need (Jun 2017). https://doi.org/10.48550/
ARXIV.1706.03762
56. Wang, A., Pruksachatkun, Y., Nangia, N., Singh, A., Michael, J., Hill, F., Levy, O., Bow-
man, S.R.: SuperGLUE: A stickier benchmark for general-purpose language understanding
systems. arXiv preprint 1905.00537 (2019)
57. Wang, S., Khramtsova, E., Zhuang, S., Zuccon, G.: Feb4rag: Evaluating federated search
in the context of retrieval augmented generation (Feb 2024). https://doi.org/10.
48550/ARXIV.2402.11891
58. Wang, S., Liu, J., Song, S., Cheng, J., Fu, Y., Guo, P., Fang, K., Zhu, Y., Dou, Z.: Domainrag:
A chinese benchmark for evaluating domain-specific retrieval-augmented generation (Jun
2024). https://doi.org/10.48550/ARXIV.2406.05654
59. Wei, J., Tay, Y., Bommasani, R., Raffel, C., Zoph, B., Borgeaud, S., Yogatama, D., Bosma,
M., Zhou, D., Metzler, D., Chi, E.H., Hashimoto, T., Vinyals, O., Liang, P., Dean, J., Fedus,
W.: Emergent abilities of large language models (Jun 2022). https://doi.org/10.
48550/ARXIV.2206.07682
60. Wei, J., Wang, X., Schuurmans, D., Bosma, M., Ichter, B., Xia, F., Chi, E., Le, Q., Zhou, D.:
Chain-of-thought prompting elicits reasoning in large language models (Jan 2022). https:
//doi.org/10.48550/ARXIV.2201.11903
61. Xiong, G., Jin, Q., Lu, Z., Zhang, A.: Benchmarking retrieval-augmented generation for
medicine (Feb 2024). https://doi.org/10.48550/ARXIV.2402.13178
62. Xu, Z., Li, Y., Ding, R., Wang, X., Chen, B., Jiang, Y., Zheng, H.T., Lu, W., Xie, P., Huang,
F.: Let llms take on the latest challenges! a chinese dynamic question answering benchmark
(Feb 2024). https://doi.org/10.48550/ARXIV.2402.19248
63. Yang, Z., Qi, P., Zhang, S., Bengio, Y., Cohen, W.W., Salakhutdinov, R., Manning, C.D.:
HotpotQA: A dataset for diverse, explainable multi-hop question answering. In: Conference
on Empirical Methods in Natural Language Processing (EMNLP) (2018)
64. Yao, J.Y., Ning, K.P., Liu, Z.H., Ning, M.N., Yuan, L.: Llm lies: Hallucinations are not bugs,
but features as adversarial examples. arXiv preprint arXiv:2310.01469 (2023)
65. Yao, S., Yu, D., Zhao, J., Shafran, I., Griffiths, T.L., Cao, Y., Narasimhan, K.: Tree of
Thoughts: Deliberate problem solving with large language models (2023)

## Page 19 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

Evaluation of Retrieval-Augmented Generation: A Survey
19
66. Yu, X., Cheng, H., Liu, X., Roth, D., Gao, J.: ReEval: Automatic hallucination evaluation
for retrieval-augmented large language models via transferable adversarial attacks. In: Duh,
K., Gomez, H., Bethard, S. (eds.) Findings of the Association for Computational Linguis-
tics: NAACL 2024. pp. 1333–1351. Association for Computational Linguistics, Mexico City,
Mexico (Jun 2024), https://aclanthology.org/2024.findings-naacl.85
67. Zhang, K., Liu, Q., Qian, H., Xiang, B., Cui, Q., Zhou, J., Chen, E.: Eatn: An efficient adap-
tive transfer network for aspect-level sentiment analysis. IEEE Transactions on Knowledge
and Data Engineering 35(1), 377–389 (2021)
68. Zhang, K., Zhang, H., Liu, Q., Zhao, H., Zhu, H., Chen, E.: Interactive attention transfer
network for cross-domain sentiment classification. In: Proceedings of the AAAI Conference
on Artificial Intelligence. vol. 33, pp. 5773–5780 (2019)
69. Zhang, K., Zhang, K., Zhang, M., Zhao, H., Liu, Q., Wu, W., Chen, E.: Incorporating dy-
namic semantics into pre-trained language model for aspect-based sentiment analysis. arXiv
preprint arXiv:2203.16369 (2022)
70. Zhang, Q., Chen, S., Xu, D., Cao, Q., Chen, X., Cohn, T., Fang, M.: A Survey for Ef-
ficient Open Domain Question Answering. In: Rogers, A., Boyd-Graber, J., Okazaki, N.
(eds.) Proceedings of the 61st Annual Meeting of the Association for Computational Linguis-
tics (Volume 1: Long Papers). pp. 14447–14465. Association for Computational Linguistics,
Toronto, Canada (Jul 2023). https://doi.org/10.18653/v1/2023.acl-long.
808, https://aclanthology.org/2023.acl-long.808
71. Zhang, S., Liu, X., Liu, J., Gao, J., Duh, K., Van Durme, B.: Record: Bridging the gap
between human and machine commonsense reading comprehension (Oct 2018). https:
//doi.org/10.48550/ARXIV.1810.12885
72. Zhang, T., Kishore, V., Wu, F., Weinberger, K.Q., Artzi, Y.: BERTScore: Evaluating Text
Generation with BERT. In: 8th International Conference on Learning Representations,
ICLR 2020, Addis Ababa, Ethiopia, April 26-30, 2020. OpenReview.net (2020), https:
//openreview.net/forum?id=SkeHuCVFDr
73. Zhang, Y., Khalifa, M., Logeswaran, L., Lee, M., Lee, H., Wang, L.: Merging Gener-
ated and Retrieved Knowledge for Open-Domain QA. In: Bouamor, H., Pino, J., Bali, K.
(eds.) Proceedings of the 2023 Conference on Empirical Methods in Natural Language
Processing. pp. 4710–4728. Association for Computational Linguistics, Singapore (Dec
2023). https://doi.org/10.18653/v1/2023.emnlp-main.286, https://
aclanthology.org/2023.emnlp-main.286
74. Zhao, P., Zhang, H., Yu, Q., Wang, Z., Geng, Y., Fu, F., Yang, L., Zhang, W., Cui, B.:
Retrieval-augmented generation for ai-generated content: A survey (Feb 2024). https:
//doi.org/10.48550/ARXIV.2402.19473
75. Zheng, L., Chiang, W.L., Sheng, Y., Zhuang, S., Wu, Z., Zhuang, Y., Lin, Z., Li, Z., Li, D.,
Xing, E.P., Zhang, H., Gonzalez, J.E., Stoica, I.: Judging llm-as-a-judge with mt-bench and
chatbot arena (Jun 2023). https://doi.org/10.48550/ARXIV.2306.05685
76. Zhou, Y., Lin, X., Zhang, X., Wang, M., Jiang, G., Lu, H., Wu, Y., Zhang, K., Yang, Z.,
Wang, K., Sui, Y., Jia, F., Tang, Z., Zhao, Y., Zhang, H., Yang, T., Chen, W., Mao, Y., Li,
Y., Bao, D., Li, Y., Liao, H., Liu, T., Liu, J., Guo, J., Zhao, X., WEI, Y., Qian, H., Liu, Q.,
Wang, X., Kin, W., Chan, Li, C., Li, Y., Yang, S., Yan, J., Mou, C., Han, S., Jin, W., Zhang,
G., Zeng, X.: On the opportunities of green computing: A survey (Nov 2023)
77. Zhu, F., Lei, W., Wang, C., Zheng, J., Poria, S., Chua, T.S.: Retrieving and Reading:
A Comprehensive Survey on Open-domain Question Answering. Tech. rep. (May 2021),
http://arxiv.org/abs/2101.00774, arXiv:2101.00774 [cs] type: article

## Page 20 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

20
Hao Yu, Aoran Gan, Kai Zhang, Shiwei Tong†, Qi Liu, and Zhaofeng Liu
A
Structure of RAG System
A.1
Retrieval Component
The retrieval component of RAG systems in Figure 1 can be categorized into three
types: sparse retrieval, dense retrieval [77], and web search engine. The standard for
evaluation is the output of relevant documents with numerical scores or rankings.
Before the introduction of neural networks, sparse retrievals are widely used for re-
trieving relative text content. Methods like TF-IDF [46] and BM25 [47] rely on keyword
matching and word frequency but may miss semantically relevant documents without
keyword overlap.
By leveraging deep learning models such as BERT [9], dense retrieval can capture
the semantic meaning of texts, which allows them to find relevant documents even when
keyword overlap is minimal. This is crucial for complex queries that require a contex-
tual understanding to retrieve accurate information. With advanced fusion structure for
queries and documents [28] and the more efficient implementation of K-Nearest Neigh-
bors (KNN) [51], Approximate Nearest Neighbor (ANN) [12,25] search techniques,
dense retrieval methods have become practical for large-scale use.
Web search engine employs the complex online search engine to provide relevant
documents, such as Google Search [18], Bing Search [40], DuckDuckGo [13]. RAG
systems can traverse the web’s extensive information, potentially returning a more di-
verse and semantically relevant set of documents via the API of the search provider. The
black box of the search engine and the expense of large-scale search are not affordable
sometimes.
It is observed that dense retrieval techniques, particularly those leveraging embed-
dings, stand out as the preferred choice within the RAG ecosystem. These methods
are frequently employed in tandem with sparse retrieval strategies, creating a hybrid
approach that balances precision and breadth in information retrieval. Moreover, the
adoption of sophisticated web search engines for benchmark assessment underscores
their growing significance in enhancing the robustness and comprehensiveness of eval-
uations.
Indexing The indexing component processes and indexes document collections, such
as HuggingFace datasets or Wikipedia pages. Chunking before indexing can improve
retrieval by limiting similarity scores to individual chunks, as semantic embedding is
less accurate for long articles, and desired content is often brief [32]. Index creation
is designed for fast and efficient search. For example, the inverted index for sparse
retrieval and the ANN index for dense retrieval.
Sparse Retrieval involves calculating IDF for each term and storing values in a
database for quick look-up and scoring when queried.
Dense Retrieval encodes documents into dense vectors using a pre-trained language
model like BERT. These vectors are then indexed using an Approximate Nearest Neigh-
bor (ANN) search technique, like graph-based Hierarchical Navigable Small World
(HNSW) or Inverted File Index (IVF) [12]. This process allows for the efficient re-
trieval of “closed” items by given predefined distance metrics.

## Page 21 (Section: Evaluation of Retrieval-Augmented Generation:  A Survey)

Evaluation of Retrieval-Augmented Generation: A Survey
21
Search This step is responsible for retrieving relevant documents based on a given
query. Queries are submitted using the respective API to retrieve relevant documents
for web search engine retrieval. For local resources, the query component is responsible
for formatting the query in the format required by different sparse or dense retrieval
methods. Then, the query is submitted to the retrieval system, which returns a set of
relevant documents along with their scores.
In both local and web-based scenarios, an optional reranker can be employed to
refine the ranking of retrieved documents further. The reranker usually comprises a
more complex and larger model that considers additional features of the documents
and the given query. These additional features often include the semantic relationship
between the query and the document content, document importance or popularity, and
other custom measures specific to the information need at hand.
A.2
Generation Component
The evaluable output for the generation component is the response of LLMs and the
structured or formatted output from the phrased response.
Prompting The generation process critically hinges on prompting, where a query, re-
trieval outcomes, and instructions converge into a single input for the language model.
Research showcases various strategic prompting tactics such as the Chain of Thought
(CoT) [60], Tree of Thought (ToT) [3], and Self-Note [31], each significantly shaping
the model’s output. These methods, especially the step-by-step approach, are pivotal in
augmenting LLMs for intricate tasks.
Prompting innovations have introduced methods like Rephrase and Respond (RaR)
[8], enhancing LLMs by refining queries within prompts for better comprehension and
response. This technique has proven to boost performance across diverse tasks. The
latest RAG benchmarks [61,62] in the specific domains start to evaluate the robustness
of various prompting engineering skills, including CoT, RaR, etc.
Inference The final input string prepared in the prompting step is then passed on to
the LLMs as input, which generates the output. The inference stage is where the LLM
operates on the input derived from the retrieval and the prompting stages in the pipeline
to generate the final output. This is usually the answer to the initial query and is used
for downstream tasks.
Depending on the specifics of the task or expected output structure, a post-processing
step may be implemented here to format the generated output suitably or extract spe-
cific information from the response. For example, the classification problems (multi-
choice questions) or if the task requires the extraction of specific information from the
generated text, this step could involve additional named entity recognition or parsing
operations.


---

# Explainable Artificial Intelligence: A Perspective on Drug Discovery

- **Authors:** Yazdan Ahmad Qadri, Sibhghatulla Shaikh, Khurshid Ahmad, Inho Choi, Sung Won Kim, Athansios V Vasilakos
- **Issuer:** Pharmaceutics
- **Type:** Scientific article
- **Published:** 2025-08-27
- **Language:** en
- **DOI:** 10.3390/pharmaceutics17091119
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41012456/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe convergence of artificial intelligence (AI) and drug discovery is accelerating the pace of therapeutic target identification, refining of drug candidates, and streamlining processes from laboratory research to clinical applications. Despite these promising advances, the inherent opacity of AI-driven models, especially deep-learning (DL) models, poses a significant “black-box" problem, limiting interpretability and acceptance within the pharmaceutical researchers. Explainable artificial intelligence (XAI) has emerged as a crucial solution for enhancing transparency, trust, and reliability by clarifying the decision-making mechanisms that underpin AI predictions. This review systematically investigates the principles and methodologies underpinning XAI, highlighting various XAI tools, models, and frameworks explicitly designed for drug-discovery tasks. XAI applications in healthcare are explored with an in-depth discussion on the potential role in accelerating the drug-discovery processes, such as molecular modeling, therapeutic target identification, Absorption, Distribution, Metabolism, and Excretion (ADME) prediction, clinical trial design, personalized medicine, and molecular property prediction. Furthermore, this article critically examines how XAI approaches effectively address the black-box nature of AI models, bridging the gap between computational predictions and practical pharmaceutical applications. Finally, we discuss the challenges in deploying XAI methodologies, focusing on critical research directions to improve transparency and interpretability in AI-driven drug discovery. This review emphasizes the importance of researchers staying current on evolving XAI technologies to realize their transformative potential in fully improving the efficiency, reliability, and clinical impact of drug-discovery pipelines.Keywords: artificial intelligence, explainable artificial intelligence, drug discovery, molecular modeling, therapeutic innovation, personalized medicine

## Section: 1. Introduction

The Human Genome Project (HGP), completed in 2003, was a feat of human scientific ambition that took 13 years to understand the human genetic makeup. This process involved sequencing the human DNA to understand the genetic makeup [1]. HGP led to new research offshoots, enabling the understanding of the genetic causes of diseases and possible interventions. Therefore, shedding light on the functional significance of the genes has led to an economic impact of $800 billion. The emergence of novel diseases and persistent disorders has led to an increase in the use of pharmaceutical agents in daily life in recent years [2]. Furthermore, due to modern lifestyles that expose individuals to harmful pollutants and microorganisms, there is a pressing need for innovative and more reliable pharmacotherapeutic interventions. Consequently, rapid progress in drug discovery and development is unavoidable, and it is reasonable to expect the emergence of significant pharmaceutical solutions in a short time span. Presently, numerous research and development institutions, including government and commercial institutions, heavily rely on the expertise of pharmaceutical professionals for the development of these interventions.

The process of drug discovery evolved from the 1980s, when chemists began developing chemical compounds that specifically target distinct molecular entities such as receptors, enzymes, and ion channels. Structure-based drug development gained prominence in the 1990s, particularly in identifying lead compounds for drug development. Several technological developments, including high-throughput synthesis, genomics, structural biology, and computational chemistry, were brought into the drug-development process in the 2020s [3,4,5,6]. Given that the biological activity of a therapeutic molecule depends on its three-dimensional structure, medicinal chemistry plays a pivotal role in drug discovery. Thus, during the early stages of drug development, it is crucial to understand a drug’s chemical properties through structure–activity relationship studies [7]. The lead optimization phase is a critical stage in the drug-discovery pipeline, wherein promising molecules identified during the hit-to-lead stage are systematically modified to improve their efficacy, selectivity, and drug-like properties. This process aims to enhance the therapeutic potential of the lead compounds while minimizing undesirable characteristics such as toxicity or poor bioavailability. During this phase, candidate compounds undergo a series of in vitro assays to assess their potency, physicochemical characteristics, and absorption, distribution, metabolism, excretion, and toxicity (ADMET) profiles. Following this, preclinical in vivo studies are conducted to investigate the pharmacokinetic and pharmacodynamic properties of the selected molecules. Pharmacokinetics examines a drug’s kinetics, which are primarily influenced by the body’s ADME processes. In contrast, pharmacodynamics quantifies the drug’s impact on the body, including various dynamics such as biomarker response, cytokine release, tumor progression, and other related factors [8]. Various physicochemical properties, such as molecular weight, lipophilicity, and permeability, influence the pharmacokinetic behavior of a drug [9]. Moreover, the drug’s exposure and, consequently, its efficacy can be affected by the complex physiology of the body [10]. The data obtained during the research process is combined into a translational approach to predict a clinically appropriate and effective dosage and regimen that ensures safety [11,12]. Predicting clinical efficacy solely based on a compound’s intrinsic properties or its behavior in preclinical in vivo studies can be challenging. However, a drug’s ability to achieve a safe and effective exposure level is generally considered the primary determinant of its efficacy. The timeline and process of developing a new drug are illustrated in Figure 1. Typically, creating a new pharmaceutical drug takes about 12 to 15 years in the United States and requires continuous monitoring after its general rollout [13,14].

Artificial intelligence (AI) is a data-driven system that uses advanced tools and networks to mimic human intelligence [15]. The integration of AI in healthcare encompasses disease prediction and detection, genetic analysis and gene editing, drug discovery, radiography, and personalized medicine [16]. AI models demonstrate high accuracy and efficiency [17]. AI algorithms of varying complexity perform diverse functions at various levels of healthcare applications [18]. Neural networks (NN), such as convolutional neural networks (CNNs), have demonstrated a high degree of accuracy in biomedical image analysis [19]. In contrast, recurrent neural networks (RNNs) are adept at identifying anomalies in time-series biomedical data [20]. State-of-the-art large language models (LLMs) have revolutionized diagnosis, genomics, drug discovery, and personalized medicine [21,22]. Although these AI models yield highly accurate results, the basis for their reasoning is obscured by the highly complex mathematical processes that underpin these models. As of 2024, the United States Food and Drug Administration (FDA) had approved 950 artificial intelligence/machine-learning (AI/ML)-enabled devices for disease diagnosis [23]. The challenges in using AI for determining prognosis and developing treatment plans have slowed progress due to safety concerns. Therefore, clinical decisions must be founded on well-established principles. Although the conclusion is accurate, flawed reasoning is unacceptable, especially in safety-critical applications such as healthcare.

The vast chemical space, estimated to encompass over 1060 potential molecules, offers a rich foundation for the discovery of novel drug candidates [24]. However, screening through such a large candidate list using rudimentary methods can significantly impede the drug-development process, making it time-consuming and financially burdensome. However, using AI-based methods has the potential to overcome these limitations as illustrated in Figure 2 [25]. AI can identify hit and lead compounds, enabling faster drug–target validation and optimization of drug structure design [26]. Incorporating large datasets into AI models has the potential to reduce the risk associated with introducing a new molecular entity, eliminating the need for extensive experimentation. Researchers can achieve an automated and more efficient screening and selection strategy by incorporating in-silico AI models, which differ from a ‘trial-and-error’ approach that relies solely on expert intuition. This paradigm increases the number of screened compounds while decreasing the screening times. While various efforts have been reported for the early phases of the drug-development pipeline, such as target identification and hit finding, the potential relevance of these techniques in the later stages of the process remains unclear. The use of AI tools is thought to significantly reduce the experimental burden and timelines currently required for characterizing drug response in vitro and in vivo [27]. The foundation of the outcomes of these models is uncertain due to the “black-box” nature of the AI models. Explainable AI (XAI) bridges the gap between the outcomes of an AI model and the underlying reasoning behind those outcomes. XAI techniques can establish a foundation for trusting the reliability of models that assist in the drug design pipeline. XAI techniques address these challenges by identifying which molecular features or descriptors contribute most significantly to a given prediction, or by estimating the marginal contribution of each feature to the output, or highlighting specific substructures that are strongly associated with a predicted outcome. These insights enable researchers to rationally prioritize or modify molecular scaffolds, improve candidate selection, and enhance lead optimization. Moreover, XAI can potentially enhance regulatory compliance and build confidence in AI-driven pipelines by offering human-interpretable explanations for model predictions, such as poor absorption, high distribution volume, metabolic instability, or toxicity during the ADMET prediction. With the adoption of multi-modalities, from SMILES strings and molecular graphs to transcriptomics and imaging data, XAI provides a necessary layer of transparency, enabling the deployment of AI not only as predictive tools but rather as a reliable decision support system.

The state-of-the-art AI models can potentially accelerate the drug-discovery process, particularly in the initial two stages. The published literature reviews have summarized the role of XAI in improving the drug-discovery pipeline. The two widely accepted explainability methods are the SHapley Additive exPlanations (SHAP) and the Local Interpretable Model-agnostic Explanations (LIME). The authors of [28] explore the role of SHAP and its variants in enhancing transparency in AI-driven drug-discovery processes. The authors outline the regulatory and practical importance of interpretability, emphasizing that explainability improves trust and reduces the downstream costs associated with opaque models. Their review outlines technical and regulatory challenges and future directions for XAI. Ding et al. [29] systematically evaluates the literature on XAI applications in chemical and drug research, encompassing traditional Chinese medicine domains. However, this work predominantly relies on quantitative metrics without deep qualitative insights into the practical efficacy or impact of specific XAI techniques. In [30], authors deliver a structured taxonomy tailored specifically for medicinal chemistry, advocating for essential visualization and interactive methodologies. They outline clear guidelines for effectively integrating XAI into chemical research. The main limitation is that the recommendations primarily focus on structural visualization, rather than performance metrics or quantitative evaluations. Jiménez-Luna et al. [31] focus on the challenges associated with interpreting deep-learning (DL) models in drug discovery. The authors detail various feature attribution methods and gradient-based approaches to enhance the interpretability of models. They underscore that interpretability significantly impacts the practical application of DL, particularly when accuracy must be balanced with human comprehensibility and regulatory acceptance. Vo et al. [32] review XAI methodologies for predicting drug–drug interactions (DDIs). Given the clinical importance and high-risk nature of drug–drug interactions, the authors emphasize the necessity of transparent AI predictions to ensure reliability and clinical acceptance. It comprehensively categorizes ML/DL models, identifying gaps and limitations, and suggests pathways to strengthen model transparency and reliability. A comprehensive survey [33] covers various XAI frameworks and their applications, including target identification, compound design, and toxicity prediction. The authors identify key limitations, such as the interpretability versus performance tradeoff, and provide future research directions to guide the effective integration of XAI into drug-discovery processes. Although their work offers a clear understanding of XAI in drug discovery, their discussion is presented from an AI-centric standpoint. Therefore, the existing literature for health science researchers is limited to brief reviews on this research domain.

To address the existing literature gap for biomedical science researchers, this comprehensive review examines the role of XAI in enhancing the interpretability and transparency of AI-driven drug-discovery methods. It summarizes the key XAI tools, models, and their applications in molecular modeling, target identification, molecular property prediction, clinical trial design, and personalized medicine. The review investigates how XAI addresses the opacity issues of traditional AI models, identifies current implementation challenges, and outlines key future research avenues for effectively incorporating XAI into pharmaceutical research. This article is organized as follows. Section 2 introduces XAI, its basic concepts, and its types. Section 3 elucidates the role of XAI in healthcare. Section 4 delves into the role of XAI in the drug-discovery process, while Section 5 discusses in detail the impact XAI has on the drug-discovery pipeline. The challenges and future research directions are outlined in Section 6. The discussion is concluded in Section 7.

Timeline of the conventional drug-discovery process. A typical drug undergoes five major phases. The process begins with target identification and validation, where disease-associated biological targets are identified and confirmed. This is followed by hit and lead discovery, in which compounds that interact with the target are identified and optimized for potency and selectivity. The preclinical phase involves in vitro and in vivo studies to assess the compound’s safety, efficacy, pharmacokinetics, and pharmacodynamics. If successful, the drug enters clinical trials, conducted in three phases, each involving an increasing number of human participants to evaluate safety, dosage, and therapeutic efficacy. Finally, the post-marketing surveillance phase involves continuous monitoring of the drug’s long-term safety and effectiveness in the broader population.

AI-supported drug-development pipeline. AI can potentially accelerate the progress of each stage, from target identification to post-market surveillance. This is achieved by enabling faster compound screening, predictive modeling, clinical trial optimization, and safety monitoring, thus improving efficiency and reducing development timelines.

## Section: 2. Explainable AI

Explainable AI “explains” the output of an AI model. XAI constitutes a set of processes that explain the intent and reasoning for the output generated by an AI model. XAI elucidates the process and logical reasoning used by an AI model to arrive at a conclusion. Ensuring the accuracy along with safety in operation is crucial in critical applications such as autonomous vehicles, healthcare, and industrial Internet of Things (I-IoT) [34]. Data-driven decision systems in critical applications should be both trustworthy and interpretable. Interpretability elucidates the inner workings and explains how an AI model makes a decision. While explainability takes into account all the interpretable factors that contribute to an AI model’s decision and allows the user to understand why the model made a particular decision [35]. The AI models can be classified into three categories based on their explainability: white-box, gray-box, and black-box models [34,36]. The white-box models are self-interpretable. Users can interpret the working logic of models, such as those in linear regression and decision trees. Still, there is a significant tradeoff in accuracy, as they assume the data to be linear or sub-linear, which is contrary to real-world data [37]. Additionally, self-interpretable models are not highly scalable and therefore do not meet the requirements for critical applications. The gray-box models aim to strike a balance between accuracy and interpretability. The gray-box models can support vital applications as they offer a level of interpretability by allowing analysis of the model’s inner workings and a higher accuracy [38]. However, the powerful AI models powering high-end applications are highly complex, making them difficult to interpret. Their ambiguous decision system makes them inappropriate for critical applications. However, for these black-box AI models with high obscurity, XAI tools can ensure trustworthiness [39]. The various types of AI models classified based on their interpretability are illustrated in Figure 3. XAI methods can be broadly classified into two groups, based on intrinsically interpretable models and post-hoc models [40]. The former category consists of models that are inherently easy to comprehend, while the latter requires a set of specialized methods to explain the model decisions [41]. The general outline of the XAI classification is illustrated in Figure 4. The following discussion follows the structure outlined in this figure.

Types of AI models classified according to their interpretability. There is a tradeoff between the interpretability and accuracy of the AI model.

Outline of classification of XAI models.

Comparison of the key post-hoc XAI techniques used in drug discovery.

## Section: 2. Explainable AI › 2.1. Intrinsically Interpretable Models

Intrinsically interpretable models are designed in such a way that humans can readily understand their structure, parameters, and decision-making processes. They provide interpretations organically due to their structure, and there is no need for extra post-hoc approaches for interpretability [42]. These models are significant in critical domains as healthcare, finance, and law, where understanding the underlying causes for a certain decision is equally important to model accuracy. Inherently interpretable models can provide stakeholders with unparalleled insights into decision-making, enabling trust, transparency, and accountability to flourish. The following features define intrinsically interpretable models. (a) Simplicity, as they rely on uncomplicated mathematical models, including linear systems, rule sets, or tree ensembles. (b) Transparency, as each action or decision made by this model can be delineated and elucidated. (c) Feature importance clarifies the contribution of each feature to the final prediction. These models typically possess fewer parameters than black-box models, making them more comprehensible and interpretable [43]. The intrinsically interpretable models can be classified into the following categories:

## Section: 2. Explainable AI › 2.1. Intrinsically Interpretable Models › 2.1.1. Linear Models

Linear models represent the simplest type of intrinsically interpretable models, where the output is the result of a linear combination of the input features. These models assume a linear relationship between input features and target variables. Therefore, the impact of an input variable on the output is directly interpreted by its coefficient [44]. Linear Regression models calculate a continuous dependent variable from a set of predictor variables. The model, in turn, fits a linear equation to the empirical data. Each coefficient provides a clear interpretation of how a one-unit change in a feature influences the target variable, assuming all other features are held constant [45]. Logistic regression is a classification technique used for binary problems in a manner quite similar to linear regression. It generates a model to compute the probability that an instance belongs to a specific class. In the logistic regression model, this output is transformed through a sigmoid function that ranges between 0 and 1. In logistic regression, the coefficients signify the log-odds of a one-unit change in the respective feature. Although still not as intuitive as the coefficients from linear regression, directly interpreting the output with probabilities and odds ratios does it [46].

The linear models are simple, as they are directly interpretable and can be trained easily to perform accurately using a moderately sized dataset. The use of regularization can also help improve explainability in linear models. Regularization techniques help reduce overfitting by adding a penalty to the model’s loss function, encouraging simpler weights [47]. This reduces the influence of less important input variables by moving the variable coefficients to near zero, improving model interpretability. Regularization also enhances generalization, making the model more robust to unseen data. However, it requires careful hyperparameter tuning to determine the optimal strength of the penalty. Additionally, regularization is particularly effective in high-dimensional data, where it helps mitigate the risk of overfitting due to the large number of input variables. On the other hand, regularization can also overly simplify models if the regularization parameter is too large, causing the model to miss important patterns. It also assumes equal importance for all input variables, which may not hold true, so incorporating domain knowledge can enhance performance. Regularization may be computationally expensive, especially for high-dimensional data, making it less suitable for real-time applications [48]. Additionally, it presumes that data are linearly separable and independent and identically distributed (IID), which may not apply to complex datasets like time-series or spatial data, requiring more advanced models [49].

Generalized Additive Models (GAMs) extend traditional linear models by allowing the relationship between each feature and the target variable to be modeled with smooth, nonlinear functions, while still maintaining an additive structure. Unlike linear models, which assume a straight-line relationship between features and the target, GAMs are more flexible, as they can capture complex, nonlinear relationships [50]. However, despite this flexibility, GAMs remain interpretable because each feature’s contribution to the prediction remains independent of the contributions of the others. This structure enables the visualization of the effect of each feature, often in the form of individual plots for each constituent function. The advantages of GAMs lie in their balance of flexibility and interpretability [51]. They can model nonlinear patterns in the data without sacrificing transparency, as the additive nature of the model ensures that each feature’s influence is clear and separable from the others. This makes GAMs particularly useful for applications where both accuracy and interpretability are essential. However, a key limitation of GAMs is that they are restricted to additive relationships between features and the target, meaning they cannot model interactions between features. Consequently, while GAMs are powerful in capturing individual feature effects, they may be less suitable for datasets where feature interactions play a critical role [52].

## Section: 2. Explainable AI › 2.1. Intrinsically Interpretable Models › 2.1.2. Decision Tree

A decision tree is a hierarchical ML model that partitions data into subsets based on feature values, using a series of if-then rules to make decisions [53]. The model is structured with three primary components: the root node, representing the initial feature used for data splitting; internal nodes, indicating subsequent decision points; and leaf nodes, which provide the final prediction or classification. This structure allows for high interpretability, as each path from the root to a leaf can be easily understood as a sequence of decision rules. One of the key advantages of decision trees is their transparency and ease of interpretation. Additionally, they do not require feature scaling, allowing them to work effectively with unprocessed data [54]. Furthermore, decision trees are capable of modeling complex, nonlinear relationships, making them versatile in capturing a wide range of diverse patterns. However, these models have limitations, such as their susceptibility to overfitting, particularly when the trees are deep, which can lead to the capture of noise rather than meaningful patterns in the data. Decision trees are also known for their instability, as small changes in the input data can result in significant alterations to the tree structure, making them sensitive to data variations [55].

Similar to a decision tree, rule-based association is an ML method that identifies relationships or patterns between variables in large datasets through the use of if-then rules. The explicit association rules make them particularly useful in applications such as market basket analysis, where relationships between items can be easily extracted and interpreted. Rule-based models are inherently interpretable, as users can assess the relevance and validity of each rule and modify them, if necessary, based on domain knowledge [56]. This interpretability is crucial for applications in sensitive fields, such as healthcare and finance, where understanding the rationale behind decisions is essential for ensuring fairness, accountability, and trustworthiness in AI systems.

In healthcare, decision trees and rule-based models are employed for medical diagnoses due to their transparent decision-making processes, such as diagnosing diseases based on symptoms and test results. In finance, linear models such as logistic regression are used for credit scoring to predict default risk, while rule-based models aid in fraud detection. In the legal domain, rule-based models and decision trees are utilized in risk assessments, including determining parole eligibility and predicting recidivism. These models’ interpretability makes them valuable in fields where transparency is crucial.

## Section: 2. Explainable AI › 2.2. Post-Hoc Explainability

Models that are not inherently interpretable require additional tools to enable a human to understand them. Post hoc methods, applied after a model is trained, aim to explain the decisions of a complex, already trained model. These methods are often indispensable when using black-box models, as the internal working mechanisms of the model are too complex to be understood without additional aids. Examples of post-hoc interpretative methods include backpropagation-based methods within neural networks, which quantify the features at the input, and model-agnostic approaches such as LIME and SHAP. These provide approximate decision processes for black-box models and, in this manner, may be used to provide insight into the interpretation of different inputs about predictive outputs [57]. While these post hoc interpretations are indispensable in the study of black-box models, they suffer from issues of complexity and domain specificity. In addition to identifying essential input features, these methods can often only roughly approximate the kind of relationships that exist between features and outputs in many domains, excluding image and text analysis [41].

Comparison of the key post-hoc XAI techniques used in drug discovery.

## Section: 2. Explainable AI › 2.2. Post-Hoc Explainability › 2.2.1. Model-Agnostic XAI

These techniques are used to explain the output of machine-learning models, without regard for the underlying AI model. They are model-agnostic because they do not depend on the architecture or inner workings of the model, which allows them to be applied to any machine-learning model. The primary motive behind model-agnostic methods is to provide interpretability to predictions or insights into how the model arrives at a decision [58]. Since the complexity of the underlying AI can vary, a surrogate model that is inherently interpretable can be used to explain the model’s decisions. A surrogate model is an interpretable model, such as a decision tree or linear model, used to approximate the predictions of a more complex "black-box" model. By analyzing the surrogate, insights can be gained into how the black-box model makes decisions. The advantage of this approach is that it provides a global understanding of the complex model’s behavior. However, it may not fully capture the behavior of the original model, particularly in highly nonlinear problems. Surrogate models are often used to obtain high-level explanations of complex models, such as in DL applications in healthcare.

## Section: 2. Explainable AI › 2.2. Post-Hoc Explainability › 2.2.1. Model-Agnostic XAI

LIME is a widely used method that provides interpretability for individual predictions of any ML model, irrespective of its complexity. LIME is particularly useful for complex, black-box models such as deep neural networks and ensemble methods, which often produce accurate predictions but are difficult to interpret. The core idea behind LIME is to generate a local surrogate model, typically a simpler and more interpretable model like linear regression or decision trees, to approximate the behavior of the black-box model in the neighborhood of a specific instance. This surrogate model allows for detailed local explanations, making the black-box model’s predictions more transparent on a case-by-case basis [59]. To explain an individual prediction, LIME first samples data points around the instance in question by perturbing the input features and generating new examples similar to the original instance. Perturbation involves modifying the input data slightly to see how the black-box model’s predictions change. By observing these changes, LIME can understand how sensitive the model’s prediction is to individual features. It then feeds these perturbed instances into the black-box model to obtain corresponding predictions. LIME assigns more weight to perturbed instances that are closer to the original instance and fits a simple interpretable model to this weighted data, approximating the black-box model’s decision-making process in that local region. The surrogate model thus provides insights into the contribution of each feature toward the prediction, allowing users to understand which features were most influential in the model’s decision for that particular instance.

LIME’s primary advantage is its model-agnostic nature, meaning it can be applied to any machine-learning model, regardless of complexity. This makes it particularly effective in explaining nonlinear models [60]. It also provides detailed explanations for individual predictions, which is crucial in high-stakes decision-making areas such as healthcare, finance, and legal systems. However, LIME is not without limitations. One notable drawback is its instability; small changes in data can lead to different explanations for similar instances, especially when the black-box model’s decision boundary is highly nonlinear. Furthermore, the local explanations provided by LIME may not generalize well to the entire model, limiting the scope of the explanations to the neighborhood around the instance being explained. LIME can also be computationally intensive as it requires generating numerous perturbed samples and running predictions for each, which can be challenging for large datasets or complex models.

Despite these limitations, LIME has demonstrated broad applicability in various fields. In credit scoring, for instance, LIME can explain why a loan application was approved or denied, providing users with detailed reasons based on their financial features. Similarly, in healthcare, LIME has been used to explain diagnostic models, helping clinicians understand which patient features contributed most to a given prediction. LIME has also been applied to image classification tasks, where it can highlight the specific parts of an image that were most influential in the model’s decision. In summary, LIME offers a flexible, interpretable solution for understanding the behavior of complex machine-learning models at the local level, although it is essential to consider its limitations in terms of stability and generalizability.

## Section: 2. Explainable AI › 2.2. Post-Hoc Explainability › 2.2.1. Model-Agnostic XAI

SHAP is a method rooted in cooperative game theory that provides a comprehensive and theoretically sound framework for explaining individual predictions by quantifying the contribution of each feature. It assigns each feature an importance value, known as the SHAP value, which represents the feature’s contribution to the model’s prediction. SHAP values offer a unified measure of feature importance by considering the contribution of each feature in the context of all possible feature subsets. This ensures that the assigned SHAP values accurately reflect each feature’s role in the prediction [61].

The primary advantage of SHAP is its solid theoretical foundation, which guarantees consistency in attributing feature importance at local (individual prediction) and global (overall model behavior) levels. SHAP values ensure additivity, meaning that the sum of all feature contributions equals the model’s prediction, which provides a clear and interpretable breakdown of how each feature influences the outcome. However, the method’s robustness comes with the disadvantage of high computational cost, particularly when applied to large and complex models, due to the need to compute contributions across all possible feature subsets.

SHAP operates by calculating the contribution of each feature through the lens of Shapley values, a concept from cooperative game theory. Shapley values represent a fair allocation method, originally designed to distribute payouts among players based on their contribution to a coalition’s total value. In machine learning, each feature is considered a “player,” and the model’s prediction is the total “payout.” SHAP values ensure that each feature’s contribution is fairly evaluated by averaging the marginal contribution of the feature across all possible combinations of features. This approach provides a comprehensive and equitable distribution of the prediction value among the input features. SHAP delivers a robust and interpretable method for understanding the behavior of complex models, ensuring fairness and transparency in decision-making processes [62].

## Section: 2. Explainable AI › 2.2. Post-Hoc Explainability › 2.2.1. Model-Agnostic XAI

Partial Dependence Plots (PDPs) illustrate the marginal effect of one or two features on a model’s prediction by varying the target feature(s) while keeping other features constant. This approach helps visualize how changes in a specific feature impact the predicted outcome, providing an intuitive and straightforward means of interpreting feature influence. However, PDPs assume feature independence, which may not hold in real-world scenarios where features are often correlated. This can lead to misleading interpretations, particularly in complex models. However, Accumulated Local Effects (ALE) plots offer an alternative to PDPs by addressing the limitations related to feature dependencies. ALE plots estimate the local effect of a feature on the model’s predictions by computing the changes in the prediction within small intervals of the target feature and then accumulating these effects over the feature’s range [43].

## Section: 2. Explainable AI › 2.2. Post-Hoc Explainability › 2.2.2. Model-Specific XAI

Model-specific XAI methods are tailored to leverage the internal structures and characteristics of specific types of machine-learning models to provide detailed and context-sensitive interpretations. These methods are inherently linked to the particular architecture or operational principles of the models they are designed for, enabling a deeper and more precise understanding of model behavior than generic, model-agnostic approaches [63]. This category of XAI techniques is particularly relevant for complex models such as deep neural networks, where interpretability is crucial for understanding the decision-making process, building trust, and ensuring compliance in critical applications like healthcare, finance, and autonomous systems [64]. Some of the major model-specific XAI methods are described as follows.

Comparison of the key post-hoc XAI techniques used in drug discovery.

## Section: 2. Explainable AI › 2.2. Post-Hoc Explainability › 2.2.2. Model-Specific XAI

Attention mechanisms were developed to address the challenges traditional neural network architectures posed in processing long data sequences, particularly within natural language processing (NLP) tasks [65]. Initially introduced for machine translation, attention mechanisms enable models to focus selectively on different parts of the input sequence when generating each segment of the output. This approach effectively mitigates the limitations of RNNs, which rely on fixed-size context vectors that struggle with long-term dependencies. The core functionality of attention mechanisms lies in the computation of attention weights, which quantify the relevance of each input element to a specific output element. In sequence-to-sequence models, these weights are derived by measuring the similarity between the current state of the decoder and each state of the encoder. The resulting attention weights are then used to generate a weighted sum of the encoder states, forming a context vector that guides the model’s current prediction [37]. Various forms of attention mechanisms exist, including self-attention, where each element in the input sequence attends to all others, a method particularly effective in models like Transformers that have set new benchmarks in NLP. Soft attention assigns differentiable weights to all input elements, while hard attention selects a single element in a non-differentiable manner, often requiring reinforcement learning for optimization. Attention mechanisms enhance interpretability by highlighting which parts of the input data are most influential in the model’s predictions, typically visualized through attention heatmaps. This transparency facilitates a clearer understanding of the decision-making process. Consequently, attention mechanisms are widely utilized in NLP applications such as machine translation, text summarization, and question answering. They are also employed in computer vision tasks, where they enable models to concentrate on specific regions of an image, thereby improving performance in tasks such as object detection and image captioning.

## Section: 2. Explainable AI › 2.2. Post-Hoc Explainability › 2.2.2. Model-Specific XAI

Saliency maps are a widely used visualization technique designed to interpret the decision-making process of DL models, particularly CNNs. They identify and highlight the regions of an input, such as specific pixels in an image, that are most influential in driving the model’s predictions. The theoretical basis for saliency maps lies in the observation that the gradient of a model’s output with respect to its input features can indicate the sensitivity of the prediction to changes in those features. In essence, these gradients can reveal which parts of the input the model considers most significant when making a prediction [37].

Generating a saliency map involves computing the gradient of the model’s output score for a specific class with respect to each input pixel. This gradient is then visualized as a heatmap, where the magnitude of the gradient at each pixel denotes its importance to the prediction. A higher gradient value suggests that minor alterations in that pixel would lead to a substantial change in the model’s output, thereby identifying the critical regions of the input that the model relies on. This method provides an intuitive understanding of the model’s focus and decision-making process, particularly in complex image recognition tasks. Several variations of saliency maps offer different perspectives on feature importance.

We summarize the key features of post-hoc methods discussed in this section in Table 1.

Comparison of the key post-hoc XAI techniques used in drug discovery.

## Section: 3. XAI in Healthcare

On average, global healthcare expenses per capita are increasing due to longer life expectancy. Thus, it increases the burden on those suffering from chronic diseases. Therefore, questions about the long-term viability of current healthcare systems are growing. AI has the potential to help address these issues by improving care quality and cost effectiveness [68]. However, because of the potential fatal consequences of inaccurate predictions by an AI model, these models must be transparent and explainable. Clinicians must understand the AI decision-making processes to develop trust and enable adoption. Thus, healthcare decision-makers must be reliable, accurate, and transparent in their actions. To overcome this challenge, research efforts are ongoing to make ML and DL models interpretable [69]. AI systems should provide clinicians with explicit explanations of their results, such as highlighting crucial aspects that influence diagnostic decisions in disease identification [70].

To elucidate the link between microbial communities and phenotypes, the SHAP method was used, which interprets model predictions depending on the contribution of each feature [71]. Positive SHAP values suggest characteristics that support the projected outcome. Dopaminergic imaging modalities, such as SPECT DaTscan, have been investigated for early diagnosis of Parkinson’s disease [72], with the LIME algorithm used to classify cases and provide interpretable explanations. XAI has also been used to diagnose acute critical illnesses. An early warning score system uses SHAP to explain predictions based on Electronic Health Record (EHR) data [73]. Furthermore, XAI approaches have been investigated in Glioblastoma diagnosis, with models using fluid-attenuation inversion recovery data validated for multiform classification and LIME used to assess local feature significance in test samples [70].

An explainable computer-assisted approach for lung cancer diagnosis has been presented, which uses the LIME method to generate natural language explanations from important features [74]. An ensemble clustering-based XAI model for traumatic brain injury diagnosis improved interpretability by combining expert knowledge and automated analysis [75]. COVID-NET, a model for COVID-19 detection using chest X-rays, obtained 93.3% accuracy and 91.1% sensitivity after interpreting its data using GSInquire, which audits the network’s internal decision-making by identifying the most influential internal features and mapping them to specific regions in chest X-ray images. This ensures the model bases its COVID-19 predictions on clinically relevant patterns rather than spurious correlations or artifacts [76]. Additionally, an interpretable ML model has been constructed to predict post-stroke hospital discharge disposition [77].

XAI-enabled classification models for COVID-19 have been presented to produce accurate predictions and credible explanations [78]. The model utilizes 380 positive and 424 negative CT volumes, aiding radiologists in localizing lesions and enhancing diagnostic insight. Early detection of sepsis is crucial, as delays can lead to irreparable organ damage and higher mortality, which is addressed by analyzing health information from the Cardiology Challenge 2019 [79]. An XAI model based on 168 hourly characteristics was developed, utilizing a gradient boosting model (XGBoost) with K-fold cross-validation to predict sepsis risk and provide interpretable results in the ICU setting. A study used brain MRI scans from 1901 participants from the IXI, ADNI, and AIBL datasets to classify Alzheimer’s Disease by training a model on chronological and brain age data [80]. This model outperformed the existing ML approaches, with 88% accuracy for females and 92% for males. It can support both regression and classification tasks while preserving the morphological semantics of the input space and assigning feature scores to quantify the contribution of each region to the final result. Table 2 tabulates the XAI tools used in recent proposals to understand the outcomes of AI-based disease detection networks.

Summary of XAI models used for healthcare applications.

## Section: 4. XAI in Drug Discovery

In biological systems, there are intricate layers of regulation. These layers encompass dynamic interactions among genes, proteins, signaling networks, and metabolic pathways. Therapeutic targeting and drug response prediction are challenging due to the inherent variability of diseases, particularly cancer, neurodegeneration, and metabolic disorders. Despite the strong predictive capabilities of AI and ML methodologies when working with large datasets, their opaque and black-box nature frequently limits the biological interpretability of their results. XAI is an essential tool that allows researchers to understand the reasoning behind a model’s specific prediction by connecting these decisions to biologically significant variables. This interpretability is crucial for enhancing trust and reproducibility, as well as for developing new hypotheses based on mechanisms that will inform future phases of drug discovery.

Recent advancements in explainable and interpretable AI have markedly improved the reliability and acceptance of AI models in drug discovery and healthcare. Numerous newly established frameworks illustrate the effective integration of XAI principles into drug–target interaction (DTI) prediction and molecular property modeling. DeFuseDTI and DTRE utilize advanced DL architectures in conjunction with feature attribution methods to enhance the precision and interpretability of DTI predictions, thereby facilitating more informed therapeutic decisions. ARGENT further refines this methodology by integrating attention mechanisms and interpretable embeddings, enabling researchers to correlate model predictions with distinct biological or chemical characteristics. DCGAN-DTA utilizes generative adversarial networks to predict drug–target affinity, ensuring transparency via interpretable outputs. These models underscore the growing emphasis on integrating XAI into complex predictive systems, highlighting the importance of transparency, trust, and actionable insights in modern drug-development processes.

Summary of XAI models used in identifying interactions for the development of drugs.

## Section: 4. XAI in Drug Discovery › XAI Tools Enabling Interpretability in Drug Discovery

In recent years, there has been an increase in the number of XAI tools designed to elucidate the predictions generated by complex models in drug discovery. The following tools offer case-specific interpretability, including structure–activity modeling, toxicity prediction, and molecular property analysis. A plethora of XAI tools has significantly enhanced the interpretability of complex models in drug discovery. SHAP utilizes game theory to assess the contribution of individual input features and has been extensively applied in models such as random forests, support vector machines (SVMs), and deep neural networks to identify molecular substructures affecting compound activity in Quantitative Structure–Activity Relationship (QSAR) studies [61,94]. LIME creates simple surrogate models tailored to specific predictions, enabling chemists to understand the crucial structural elements that influence a compound’s expected activity or toxicity [57]. Combined with attention mechanisms, Graph Neural Networks (GNNs) effectively recognize critical atoms and bonds in molecular graphs, facilitating optimization guided by substructures. Integrated Gradients and DeepLIFT provide gradient-based attributions that are vital in omics-driven research, pinpointing genes or features that impact drug response classifications. Furthermore, Chemprop, a framework for predicting molecular properties, has been integrated with SHAP to clarify ADMET predictions by linking pharmacokinetic properties with specific atomic and structural features, thereby enabling informed lead optimization. Drug repositioning can be facilitated by identifying and elucidating biologically plausible compound-disease associations using GraphIX, which combines GNN with SHAP-like methods [95]. InstructMol is a multimodal model that employs natural language prompts and molecular structures to create new compounds [96]. It achieves this by ensuring that textual and chemical features align in an interpretable manner, enabling rationale-driven molecule design. AlphaFold 3 includes confidence scoring to identify uncertain areas in predicted protein structures [97]. This makes structural drug design more reliable. Furthermore, platforms like PandaOmics and ID4 utilize explainable analytics and visualization components to assist with target discovery, disease mechanisms, and lead prioritization, enhancing transparency in AI-driven pharmaceutical processes [98]. Table 3 lists the XAI tools used in the current drug-discovery processes.

Summary of XAI models used in identifying interactions for the development of drugs.

## Section: 5. Impact of XAI on Drug Discovery

The development of AI and ML has transformed drug research. Transparency and interpretability become increasingly crucial as the complexity of these models grows. XAI solves this issue by providing a better understanding of the predictions provided by ML algorithms.

## Section: 5. Impact of XAI on Drug Discovery › 5.1. Data Analysis

XAI algorithms facilitate the analysis of large and diverse datasets containing chemical, biological, and clinical information to find novel drug targets, predict medication efficacy and toxicity, and improve drug design [100]. Advanced computational approaches and ML algorithms are utilized in XAI drug discovery to process and evaluate large datasets from multiple sources, such as molecular structures, biochemical tests, high-throughput screening (HTS), and preclinical and clinical trials [33].

AI and ML models have shown promising outcomes in areas such as lead optimization, virtual screening, chemical design, and medication repurposing [101,102,103,104]. As these models evolve, they have the potential to significantly increase drug-discovery success rates while reducing time and costs. However, their predictive capacities frequently lack interpretability, making it difficult for academics, clinicians, and regulatory authorities to trust and validate the results. Without insights into model decision-making, it is difficult to evaluate and prioritize targets or compounds. XAI addresses this issue by providing clear explanations of model predictions [28], which increases trust, enables the detection of biases or inaccuracies, and facilitates a deeper understanding of model behavior [33].

## Section: 5. Impact of XAI on Drug Discovery › 5.2. Molecular Property Prediction

XAI can optimize lead compounds to enhance effectiveness, pharmacokinetics, and drug-like features, resulting in the development of more effective medications with fewer adverse effects [105]. XAI in drug development improves the transparency and accountability of AI models, which are critical for lead optimization and toxicity prediction [106]. This increases trust in AI-generated outcomes, encouraging their use in the pharmaceutical industry. XAI also identifies and mitigates biases, resulting in fair and accurate predictions, which are critical for avoiding the development of ineffective or harmful medications [31]. Various XAI investigations have focused on unraveling molecular substructures using the gathered data in drug discovery. The authors in [94] utilize SHAP to interpret key characteristics and substructures for predicting chemical activity. Jiménez-Luna et al. [107] also used integrated gradient attribution to highlight key chemical characteristics and structural aspects in graph neural network models.

## Section: 5. Impact of XAI on Drug Discovery › 5.3. Personalized Medicine

XAI algorithms help to analyze patient data and predict individual responses to treatments, allowing for the development of personalized and effective medications [108]. In drug research, XAI facilitates personalized medicine by utilizing AI to analyze large datasets for evidence-based decision-making, drug repurposing, and real-time monitoring [109]. XAI methodologies, such as SHAP, LIME, and attention mechanisms, help researchers understand the molecular or biological features that influence predictions, allowing them to correlate model outputs with domain expertise and refine compound design decisions.

## Section: 5. Impact of XAI on Drug Discovery › 5.4. Unraveling Drug–Drug and Drug–Target Interactions

Drug–drug interactions (DDIs) are common in polypharmacy, when the effects of one drug might influence the actions of another in a combined therapy regimen. Ideally, such interactions produce synergistic effects as well as therapeutic advantages. However, in the treatment of multiple diseases, adverse drug events that result in toxicity or reduced efficacy may occur, thereby increasing patient morbidity and death [110,111]. The current growth in the approval of new medications and indications has increased the possibility of DDIs [112,113]. While wet-lab investigations to verify DDIs are time-consuming and resource-intensive, rendering them unsuitable for routine use, AI models have been used to predict DDIs better [114,115,116]. Efforts have been made to improve drug database models to aid clinical decision-making. Effective DDI management is critical for maintaining pharmacovigilance and patient safety. The application of XAI in predicting DDIs has recently been extensively reviewed elsewhere [116].

Biomedical experiments to investigate DTIs are resource-intensive. To reduce costs and time, ML algorithms have been used to predict these interactions. The abundance of drug and target data, advances in computing technology, and the distinct capabilities of multiple ML algorithms have made them the primary tools for predicting drug–target interactions. This prediction approach aids in screening out inappropriate compounds, which is an important stage in novel drug development [117]. Modeling cellular networks in cancer using AI provides a quantitative framework for investigating the association between network properties and disease, allowing the identification of potential new anticancer targets and drugs [118,119,120]. The use of XAI in identifying novel anticancer targets, the ideas underlying common algorithms, and its applications in biological investigation have recently been reviewed elsewhere [121].

## Section: 5. Impact of XAI on Drug Discovery › 5.5. Facilitating Drug Repositioning and Combination Therapy

Drug repositioning entails identifying new therapeutic applications for FDA-approved drugs. This strategy focuses on assessing the efficacy of existing drugs or those under development in various pathological conditions [122,123]. Since 1995, new drug approvals have been declining due to the traditional drug-development procedure, which is costly and time-consuming. Hence, drug repositioning has emerged as a potential alternative, using XAI to expedite drug discovery while lowering costs and risks [122]. The significant benefits of this strategy include knowledge of drug pharmacokinetics and toxicity, as well as the low cost of implementation, which benefits low- to middle-income nations where traditional therapies may be too expensive [124].

Drug repositioning strategies combine computational and experimental techniques to uncover new therapeutic applications for current drugs [125,126]. ML, network analysis, and NLP are three critical computing methodologies [127]. These methods are classified as disease-centric, drug-centric, or combinations of both [128]. Disease-centric techniques identify new applications for drugs by grouping diseases based on phenotypic commonalities, molecular markers, and genetic variants [129,130]. Drug-centric techniques seek similarities in molecular action between drugs to identify new potential applications [131]. Combination techniques integrate both strategies by creating drug–drug and disease-disease similarity networks, assigning drugs based on meta-path scores, and predicting disease-drug relationships by correlating disease expression patterns with genes affected by drugs [132,133].

## Section: 5. Impact of XAI on Drug Discovery › 5.6. Clinical Trial Design

XAI enhances clinical trial design by identifying appropriate patient demographics, predicting trial success, and detecting possible adverse effects. This enables a more accurate assessment of the safety and efficacy of novel medications in humans [134]. XAI can also aid in predictive modeling, patient selection, and safety precautions during drug development.

## Section: 5. Impact of XAI on Drug Discovery › 5.7. Ethics and Regulatory Implications

Lack of transparency in AI systems raises significant ethical concerns, particularly in healthcare and drug development, where decisions must be both interpretable and justifiable. Recent frameworks emphasize the importance of fairness, accountability, and human oversight in the deployment of AI. XAI contributes to these goals by exposing decision logic, identifying potential biases, and facilitating more transparent communication with regulatory bodies, clinicians, and interdisciplinary teams.

## Section: 6. Key Challenges and Future Research Directions in XAI for Drug Discovery › 6.1. Key Challenges

XAI is rapidly becoming a crucial element in AI-assisted drug discovery. It promotes informed decision-making in drug screening, biomarker identification, clinical trial design, and personalized medicine by enhancing model transparency, interpretability, and reliability. In clinical and biomedical settings, XAI enhances interpretability for healthcare practitioners, facilitates bias detection, improves patient communication, promotes ethical adherence, and ensures regulatory compliance. Nonetheless, despite its potential, several significant challenges must be addressed to harness XAI’s capabilities in drug discovery to their maximum.

## Section: 6. Key Challenges and Future Research Directions in XAI for Drug Discovery › 6.1. Key Challenges › 6.1.1. Data Limitations

To discover significant patterns, XAI models require large, high-quality datasets with diverse and varied sample spaces. However, many drug-discovery datasets are limited, incomplete, or biased, compromising model performance and interpretability. Innovative technologies, such as data augmentation, synthetic data production, and transfer learning, will be crucial in overcoming data scarcity and enhancing generalizability.

## Section: 6. Key Challenges and Future Research Directions in XAI for Drug Discovery › 6.1. Key Challenges › 6.1.2. Complexity and Interpretability Tradeoff

Highly accurate models, particularly deep NNs, often operate as black boxes, offering little insight into their decision-making processes. In contrast, interpretable models may lack the predictive effectiveness necessary for complex biomedical applications. Striking a balance in this tradeoff presents a significant challenge. Developing hybrid XAI frameworks that combine predictive power with intuitive interpretability is a viable strategy and a challenge for widespread adoption.

## Section: 6. Key Challenges and Future Research Directions in XAI for Drug Discovery › 6.1. Key Challenges › 6.1.3. Ethical and Bias Concerns

It is crucial to thoroughly assess the ethical implications of XAI models, particularly in terms of bias and fairness across different demographic groups. Predictions based on biased training data may exacerbate existing health disparities. The responsible use of AI in drug discovery requires rigorous validation procedures and models that are created with fairness in mind.

## Section: 6. Key Challenges and Future Research Directions in XAI for Drug Discovery › 6.1. Key Challenges › 6.1.4. Regulatory Compliance

To be used in clinical or regulatory settings, XAI systems must provide clear, scientifically relevant explanations that align with expert knowledge. Regulatory bodies seek models that can be comprehended to evaluate their safety and reliability. The current application of XAI requires further development to produce understandable results that meet high safety and regulatory standards.

## Section: 6. Key Challenges and Future Research Directions in XAI for Drug Discovery › 6.2. Future Research Directions › 6.2.1. Multimodal Data Integration and Augmentation

Drug responses depend on multiple factors, including genetic variations, protein expression, metabolic pathways, and clinical phenotypes. Consequently, future research should prioritize the integration of multimodal data—including genomics, proteomics, transcriptomics, metabolomics, and real-world clinical data—to build comprehensive and context-aware models of drug action. Integrating gene expression profiles with chemical structure data significantly enhances the performance of drug sensitivity prediction models, while also improving biological plausibility and interpretability [135]. Other studies demonstrate how multimodal fusion not only enhances predictive performance but also provides mechanistic insights into drug action [136]. However, aligning heterogeneous data types remains a significant challenge due to differences in data scale, format, and biological context. To address this, research should also explore data augmentation strategies such as generative modeling, cross-modal embeddings, and transfer learning to enrich underrepresented data domains and improve generalization. By advancing data integration and augmentation methodologies, XAI frameworks can evolve into more resilient and biologically grounded systems, ultimately supporting safer and more personalized therapeutic development.

## Section: 6. Key Challenges and Future Research Directions in XAI for Drug Discovery › 6.2. Future Research Directions › 6.2.2. Next-Generation XAI Frameworks

The complex biochemical interactions and the effects of pharmaceuticals on various targets necessitate the development of innovative XAI models and frameworks. Future research should focus on models that integrate GNNs with attention-based architectures to model and interpret complex biochemical interactions accurately. GNNs are well-suited for representing molecular structures, while attention mechanisms can highlight the most dominant molecular substructures that contribute to biological activity, binding affinity, or toxicity [31,137,138]. By leveraging these techniques, XAI models can provide intuitive and interpretable explanations that align with pharmacological principles, offering clarity in identifying functional groups responsible for specific pharmacological effects and highlighting structural alerts linked to adverse outcomes. When combined with cross-modal attention between molecular and protein representations, these models could also clarify drug–target binding mechanisms. Incorporating domain knowledge, such as known reaction rules, toxicophore databases, or protein-ligand interaction motifs, further enhances the biological plausibility of the explanations. This direction enables the creation of transparent, mechanism-aware AI systems that not only predict outcomes but also generate actionable hypotheses, supporting critical decision-making in hit-to-lead optimization, multitarget drug design, and safety profiling.

## Section: 6. Key Challenges and Future Research Directions in XAI for Drug Discovery › 6.2. Future Research Directions › 6.2.3. Experimental Validation and Hybrid Models

The integration of XAI with experimental methodologies, including molecular dynamics simulations (MDS) and high-throughput screening, can facilitate the confirmation and enhancement of computational predictions. Research efforts should focus on integrating XAI with MDS and HTS to validate and refine predictions generated by the AI models. Attention maps and feature attributions used in [138] can be used to highlight critical substructures involved in drug–target interactions. These predictions can then be evaluated using MDS to test the stability and conformational dynamics of the predicted binding modes, thereby offering physicochemical validation of model outputs. Similarly, XAI-guided compound prioritization can inform HTS experiments by narrowing the chemical search space to biologically plausible candidates, enhancing hit rates and reducing false positives [137]. Experimental feedback from such validation efforts can be reintegrated into training datasets to fine-tune model weights and improve generalizability, establishing a feedback loop between computation and experimentation. Furthermore, XAI can support drug repurposing by identifying alternative binding sites or off-target effects, which may then be verified through in vitro assays or biochemical profiling. This hybrid approach not only augments model performance but also advances the interpretability and scientific validity of AI-driven drug discovery, enabling the generation of testable hypotheses that are both biologically plausible and experimentally verifiable.

## Section: 6. Key Challenges and Future Research Directions in XAI for Drug Discovery › 6.2. Future Research Directions › 6.2.4. Collaborative Open Platforms

The MELLODDY project is a large-scale federated learning (FL) initiative in which several pharmaceutical companies collaboratively train advanced AI models without explicitly sharing their proprietary data. It leverages over 2.6 billion activity records from 21 million molecules across 40,000 assays. This enables improved predictive modeling for drug discovery while preserving data privacy and intellectual property rights. The MELLODDY project serves as a benchmark for collaborative ecosystems that facilitate the exchange of data, models, and tools, thereby expediting the development and validation of XAI frameworks. Open research platforms can enhance reproducibility, transparency, and regulatory compliance among stakeholders.

## Section: 6. Key Challenges and Future Research Directions in XAI for Drug Discovery › 6.2. Future Research Directions › 6.2.5. Ethical-by-Design Frameworks

Incorporating ethical considerations into the design of XAI systems is crucial for ensuring safety across diverse demographic groups. To ensure the ethical utilization of AI in healthcare and pharmaceutical development, it is imperative to integrate fairness constraints, safeguard data privacy, and promote stakeholder accountability. Fairness constraints are a primary consideration and critical in drug-discovery applications involving patient data or population-specific models, as algorithmic bias can lead to unequal access to treatment or inaccurate predictions across demographic subgroups. Racial bias in healthcare algorithms can significantly impact treatment prioritization, underscoring the need to incorporate fairness-aware modeling techniques into biomedical AI pipelines [139]. Similarly, safeguarding data privacy through methods such as FL can enable large-scale collaboration without compromising sensitive information. Moreover, the development of XAI systems must be coupled with mechanisms for stakeholder accountability, ensuring that domain experts, data custodians, and AI developers are collectively responsible for model decisions and their consequences. Future research must therefore prioritize the co-design of XAI systems with ethics experts, clinicians, and regulatory bodies to create frameworks that not only explain model behavior but also align with broader safety and ethical values. This ethical-by-design approach is foundational to building trustworthy AI systems that can be safely and equitably deployed in the pharmaceutical and healthcare sectors.

## Section: 7. Conclusions

As AI transforms drug research, the incorporation of explainability has become a fundamental requirement rather than an ancillary attribute. XAI reconciles predicted accuracy with scientific confidence by providing openness, accountability, and biological interpretability in AI models. This study highlights the growing importance of XAI tools and frameworks, which clarify the reasoning behind complex predictions, allowing researchers to make more informed, ethical, and practical decisions when designing and developing novel therapies. The future of drug development relies on integrating advanced AI models with strong interpretability, robust ethical protections, and interdisciplinary collaboration. Confronting existing limitations, such as data integrity, model complexity, and regulatory requirements, while adopting emerging technical breakthroughs, will ensure that AI technologies are both effective and trustworthy in clinical contexts. Progressing this research area necessitates a purposeful transition to next-generation XAI research emphasizing transparency, inclusion, and fairness. XAI can expedite drug-development timeframes, mitigate risks, and facilitate more tailored and accountable therapeutic approaches. The meticulous implementation of this approach will characterize the forthcoming epoch of pharmaceutical research, whereby data-driven discovery is both insightful and comprehensible.

## Section: Abbreviations

The following abbreviations are used in this manuscript:

## Section: Author Contributions

Conceptualization, Y.A.Q. and K.A.; Investigation, Y.A.Q. and S.S.; Writing—Original Draft Preparation, Y.A.Q. and S.S.; Writing—Review and Editing, K.A.; Funding Acquisition, A.V.V.; Supervision, I.C. and S.W.K. All authors have read and agreed to the published version of the manuscript.

## Section: Conflicts of Interest

The authors declare no conflicts of interest.

## Section: Funding Statement

This work is funded by the Norwegian Research Council under the grant name SecureIoT.


---

# eXplainable artificial intelligence-Eval: A framework for comparative evaluation of explanation methods in healthcare

- **Authors:** Krish Agrawal, Radwa El Shawi, Nada Ahmed
- **Issuer:** Digital health
- **Type:** Scientific article
- **Published:** 2025-09-29
- **Language:** en
- **DOI:** 10.1177/20552076251368045
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41036433/
- **Licence:** CC-BY-NC

## Section: Abstract

ObjectiveMachine learning systems are increasingly used in high-stakes domains such as healthcare, where predictive accuracy must be accompanied by explainability to ensure trust, validation, and regulatory compliance. This study aims to evaluate the effectiveness of widely used local and global explanation methods in real-world clinical settings.MethodsWe introduce a structured evaluation methodology for the quantitative comparison of explainability techniques. Our analysis covers five local model-agnostic methods—local interpretable model-agnostic explanations (LIME), contextual importance and utility, RuleFit, RuleMatrix, and Anchor—assessed using multiple explainability criteria. For global interpretability, we consider LIME, Anchor, RuleFit, and RuleMatrix. Experiments are conducted on diverse healthcare datasets and tasks to assess performance.ResultsThe results show that RuleFit and RuleMatrix consistently provide robust and interpretable global explanations across tasks. Local methods show varying performance depending on the evaluation dimension and dataset. Our findings highlight important trade-offs between fidelity, stability, and complexity, offering critical insights into method suitability for clinical applications.ConclusionThis work provides a practical framework for systematically assessing explanation methods in healthcare. It offers actionable guidance for selecting appropriate and trustworthy techniques, supporting safe and transparent deployment of machine learning models in sensitive, real-world environments.

## Section: Introduction

The integration of artificial intelligence (AI) systems across various domains significantly enhances their efficacy in diverse tasks. These AI systems primarily rely on complex machine learning (ML) models, achieving outstanding performance in tasks such as prediction, recommendation, and decision-making support.1–5 However, these models, characterized as “black-box models,” maintain opacity in their internal processes, prevalent in current AI systems leveraging deep learning models and ensemble methods like bagging and boosting. 6 While these models boast exceptional performance, their lack of transparency poses inherent risks, including potential biases derived from training on unfair data. 7 Such lack of transparency can lead to decisions lacking complete interpretability and may potentially contravene ethical principles. The integration of ML models into AI products and applications, as witnessed in the current business landscape, heightens the risks associated with compromising safety and trust, particularly in high-stakes decision-making domains like medicine, finance, and automation. 8 The enactment of the General Data Protection Regulation (GDPR) by the European Parliament in May 2018 introduced provisions regarding automated decision-making, emphasizing the right to explanation. 9 These regulations aimed at enabling individuals to acquire ‘‘meaningful explanations of the underlying logic” behind automated decisions. While legal experts differ in their interpretations of these provisions, there is a consensus regarding the pressing need to implement such principles, representing a notable contemporary scientific challenge.

In response to the practical and ethical challenges posed by the opacity of black-box models in AI, the field of eXplainable (XAI) has witnessed a surge in the development of explanation methods from both academia and industry. 10 XAI seeks to address these concerns by making the internal logic of AI models more interpretable and accessible, which is critical for fostering trust, transparency, and accountability—especially in high-stakes domains such as healthcare, finance, and law. As AI becomes increasingly integrated into decision-making pipelines, ensuring that stakeholders can understand and verify algorithmic outputs is both a technical and ethical imperative. 9 Importantly, these efforts must consider the diverse nature of data encountered, including structured data such as electronic health records and unstructured data like medical images 1 and clinical notes, each of which presents unique challenges for explainability.11,12 Furthermore, there have been significant advances in XAI approaches specifically tailored for healthcare applications, such as interpretability techniques for medical imaging, natural language explanations for clinical notes, and causal inference models for patient outcomes,13–15 all of which enrich the current XAI landscape and should be considered to provide a holistic overview.

However, the landscape of XAI methods is highly heterogeneous and fragmented, posing significant challenges for both researchers and practitioners. 16 Explanation techniques differ not only in their algorithmic formulation but also in the type and granularity of interpretability they provide, where interpretability refers to the extent to which a human can understand or predict a model’s behavior. For instance, feature attribution methods such as SHAP 17 and integrated gradients 18 quantify the contribution of individual input features to a specific model prediction. These methods offer fine-grained, localized insights suitable for instance-level analysis. By contrast, rule-based approaches like RuleFit 19 and anchors 20 derive human-readable if-then rules or logic programs that approximate the decision boundaries of a model, making them more amenable to global or structural interpretation. In an effort to bridge the gap between interpretability and predictive accuracy, recent research has explored knowledge transfer approaches that leverage complex black-box models to inform inherently interpretable white-box algorithms, aiming to combine the strengths of both. 21

Moreover, explanation techniques vary in scope and assumptions: local methods provide explanations for individual predictions—typically by approximating the model’s decision boundary in a small neighborhood of the input—while global methods aim to summarize the overall decision logic of the model across the entire dataset. 22 Some methods are inherently model-agnostic—meaning they can be applied to any black-box model without needing access to internal parameters—while others are model-specific, requiring access to internal gradients or structures (e.g. weights or layers). This diversity complicates the development of a unified evaluation framework: metrics such as fidelity and identity are often applied to local methods, whereas distributional similarity or rule complexity might be more relevant for global or rule-based approaches. Yet, these metrics are not universally applicable, and their interpretation often depends on the nature of the explanation task being evaluated. Reproducibility and stability—critical in high-risk domains—are also inconsistently assessed across methods, particularly those involving random sampling or local approximation.

To address the complexity and fragmentation in evaluating XAI methods, we propose a unified evaluation framework that systematically compares both local and global explanation techniques across multiple interpretability paradigms. Our work builds on previous studies—including our own earlier benchmark focused on local model-agnostic methods in healthcare 23 —by significantly expanding the scope to include rule-based and global explanation methods, and by aligning evaluation metrics more precisely with explanation tasks. In contrast to prior work that often focuses narrowly on a single method type or metric, this framework evaluates explanation quality using a suite of clearly defined and task-relevant metrics. 24 We conduct experiments on real-world healthcare datasets, a domain where explanation reliability and usability are especially critical. The selected methods represent a balanced spectrum of explanation paradigms—including feature attribution techniques and rule-based models—and we explicitly define the XAI task setting (e.g. local vs. global) for each method. Our goal is twofold: (1) to offer evidence-based guidance for practitioners seeking interpretable solutions in safety-critical applications; and (2) to contribute to the broader discourse on how explanation quality can be rigorously, fairly, and transparently evaluated across heterogeneous XAI techniques.

## Section: Related work

The domain of explainable AI methods has arisen more recently within academic circles in comparison to the broader expanse of AI literature. This emergence has been prompted by the widespread integration of AI models across diverse sectors in contemporary society, signifying its growing importance.1,23,25,26 XAI tools are differentially categorized into local or global methods, each designed to elucidate the decision-making processes of AI models across varying levels. The local methods specifically target the comprehension of an AI algorithm’s behavior at a more granular, low-level hierarchical tier.1,27–29 The global set of XAI approaches, in contrast, are directed towards comprehending the behavior of AI algorithms at a higher hierarchical level. 30 These methodologies assist users in gauging how features contribute to predictions across entire datasets or collections of datasets. Another way to categorize explanation techniques is based on whether the technique adopted to explain can work only on a specific black-box model (model-specific) or can be adopted on any black-box (model agnostic). Model-agnostic techniques are applicable to any model, offering valuable insights into the factors influencing their decisions. These tools operate post-hoc, meaning they are applied after the model has been trained. Importantly, they do not require access to the model’s internal details; rather, they only necessitate the capability to test the model predictions. 11

Another branch of literature focuses on the quantitative and qualitative evaluation of explanation methods assessing the quality and utility of returned explanations, considering aspects like their effectiveness and relevance.6,16,23,31–33 Quantitative evaluation primarily focuses on metrics measuring aspects like fidelity, 34 stability. 35 These metrics assess the ability of explainers to mimic the behavior of the underlying model, and the consistency of their output. Despite the availability of these quantitative metrics, there is no wide agreement about a specific set of metrics to determine the ‘‘best” explainer. This highlights the complexity and subjectivity inherent in the evaluation process. Wilson et al. 36 propose three proxy metrics aimed at evaluating the quality of explanations within these frameworks. These metrics, namely completeness, correctness, and compactness, play a pivotal role in gauging the effectiveness and reliability of explanations. Completeness pertains to the audience’s ability to verify the validity of the explanation, specifically the extent to which it covers instances. Correctness focuses on the accuracy of the explanation. Compactness delves into the degree of succinctness an explanation can achieve, such as the number of conditions within a decision rule that elucidates a specific instance. Qualitative assessment focuses on evaluating the usability of explanations from the end-user’s perspective, encompassing aspects such as providing meaningful insights, ensuring safety, social acceptance, and fostering trust. Doshi et al.37–39 propose qualitative evaluation criteria that categorize into three groups: functionally grounded metrics, application-grounded evaluation methods, and human-grounded metrics. Functionally grounded metrics leverage formal definitions to evaluate explainability, eliminating the need for human validation. Application-grounded evaluation methods involve human experts to validate specific tasks, typically in domain-specific settings. In contrast, human-grounded metrics evaluate explanations through non-expert human users, aiming to measure the overall understandability of explanations in simplified tasks.

## Section: Methods

This section outlines the methodology used to benchmark explainability techniques. It introduces the explanation frameworks considered in this study and describes the metrics employed to evaluate their performance. These methods were selected based on their relevance, popularity, and compatibility with both local and global interpretability goals.

Key characteristics of explanation methods used in this study.

Summary of datasets used in this study. Dataset references are provided in the bibliography.

## Section: Methods › Evaluated explainability frameworks

Key characteristics of explanation methods used in this study.

## Section: Methods › Evaluated explainability frameworks › Local interpretable model-agnostic explanations (LIME)

The LIME 28 is a local model-agnostic explainer that produces feature importance vectors by generating explanations around an instance being explained x . LIME assigns weights to randomly generated samples based on their proximity to x , emphasizing nearby instances. Leveraging the proximity measure πx to capture local context, LIME perturbs x by selecting nonzero elements uniformly. The perturbed instances z∈R are used to train the explanation model g(.) , often a sparse linear model, by feeding them into the black-box model b and obtaining predictions b(z) . The resulting local explanation comprises the weights assigned to the linear model’s coefficients. Additionally, LIME incorporates the submodular pick module (SP-LIME) to select representative instances and their explanations, ensuring non-redundancy and global representativeness.

## Section: Methods › Evaluated explainability frameworks › Contextual importance and utility (CIU)

CIU is a local, post-hoc, model-agnostic explainer grounded in the concept that the significance of a feature can vary across different contexts. 40 CIU employs two algorithms for elucidating predictions rendered by black-box methods.41,42 Originating from established decision-making theory, this method posits that the importance of a feature and the efficacy of its values dynamically evolve contingent upon other feature values. 42 Contextual importance (CI) serves to approximate the aggregate importance of a feature within the prevailing context, while contextual utility (CU) offers an estimation of the favorability, or lack thereof, of the current feature value concerning a designated output class.

## Section: Methods › Evaluated explainability frameworks › Anchor

Anchor is a model-agnostic method providing rule-based explanations called anchors. 20 Anchors apply when changes to other feature values of an instance don’t affect the outcome. For an instance x and anchor r , if r(x) equals b(x) (where b is the black-box model’s prediction), it forms an anchor. The process involves perturbing x to create synthetic instances, then extracting anchors with precision exceeding a user-defined threshold. Anchor utilizes a multi-armed bandit algorithm for synthetic data generation and employs a bottom-up approach with beam search to identify anchors.

## Section: Methods › Evaluated explainability frameworks › RuleFit

RuleFit is a global explainability framework designed for constructing rule ensembles. 19 The process involves two main phases: rule extraction and weight optimization. In the extraction phase, RuleFit trains a tree ensemble model on a sample S and decomposes each tree into a collection of rules, forming a set R . In the weight optimization phase, RuleFit optimizes a weight vector α∈RM for the rules in R using sample S . To maintain sparsity and ensure interpretability, RuleFit employs L1 -regularization (Lasso penalty). By navigating these phases, RuleFit constructs a rule ensemble model that captures data complexity while providing a globally interpretable representation through rules and associated weights.

## Section: Methods › Evaluated explainability frameworks › RuleMatrix

RuleMatrix is a model-agnostic explanation technique designed to offer both local and global explanations with a focus on visualizing extracted rules. 43 The technique comprises four main steps. Initially, the distribution of the provided training data X is modeled. A joint distribution estimation technique is employed to accommodate both discrete and continuous features concurrently. Next, a set of data, referred to as Xsample , is generated from the estimated joint distribution. The number of samples is a customizable parameter and can exceed the quantity of the original training data, if necessary. Then, the original black-box model being explained F is utilized to label Xsample . Lastly, Xsample and their corresponding labels Ysample are employed to train a rule list using scalable Bayesian rule list (SBRL) algorithm proposed by Yang et al. 44

Table 1 presents a comprehensive summary of the explanation methods considered in our study, including framework name, publication year, citations per year, along with their capabilities in handling various data types distinguishing between tabular (TAB) and any data (ANY). Furthermore, Table 1 classifies these explanation methods into two distinct categories: Global explanations (G) and Local explanations (L).

Key characteristics of explanation methods used in this study.

## Section: Methods › Evaluation metrics for explainability methods

This section provides a comprehensive overview of established quantitative evaluation metrics utilized in the subsequent benchmarking process. Identity: Aims to ensure that for two identical instances, their explanations are also identical. 24 Separability: Aims to ensure that explanations for two dissimilar instances differ, operating under the assumption that all features used in the model are relevant to prediction and the model does not have degree of freedom. 24 Fidelity: Aims to evaluate how good is an explanation model at mimicking black-box model b . There exist various implementations of fidelity, contingent upon the type of explainer under analysis. 34 In this work, for methods entailing the development of a surrogate model g to emulate b , fidelity is assessed by comparing the predictions of b and g using the instances employed in training g . Speed: Aims to measure the explainability framework’s efficiency by quantifying the average time required for generating an explanation. 23 Stability: Aims to assess whether similar instances yield comparable explanations. 24 In this work, stability is quantified through the Lipschitz constant, 18 represented as Lx=max‖ex−ex′‖‖x−x′‖ , ∀x′∈Nx , where x represents the instance being explained, ex stands for the explanation, and Nx is a neighborhood of instances that are similar to x . In this work, we report the stability percentage, calculated as (1−Lx)×100% . Monotonicity: Aims to ensure a consistent and orderly relationship between feature attributions and the corresponding expectations, providing a reliable measure of the correctness and reliability of the explanation. 45 Monotonicity for feature attributions ( ai ) is quantified through Spearman’s correlation coefficient, denoted as ρS(a,e) . 46 a=(⋯,|ai|,…) is a vector consists of the absolute values of the feature attributions for a function assuming value y*=f(x*) at a point x* . e=(…,E(l(y*,fi);Xi|x*−i),…) contains the corresponding (estimated) expectations calculated using the following equation: (1) |ai|∝E(l(y*,fi)|x−i*)=∫xil(y*,fi(xi))p(xi)dxi

where fi is the restriction of the function f to feature i , while keeping the other features at specific values x−i*=(x1,…,xi−1,xi+1,xN) . The function l , represents performance measure of interest (in our study, l corresponds to cross-entropy). In the context of rule-based explanation techniques, adapting the concept of monotonicity involves replacing the traditional feature attributions with rule-based feature importance metrics derived from the coverage of rules. Non-sensitivity: Ensures that the explainability method attributes zero importance only to those features on which the black-box model f lacks functional dependence. 45 This concept aligns with the sensitivity axiom as proposed by Sundararajan et al. 18 The metric for non-sensitivity involves two sets: A0⊂{1,…,N} , which is a subset containing the indices i representing features with assigned zero attribution ( ai=0 ), and X0={i∈{1,…,N}|E(l(y*,fi)=0} , representing the subset of indices i for features where the model f demonstrates no functional dependency. Here, fi , y* , and l are defined in the same manner as discussed in the context of the monotonicity metric previously. The non-sensitivity is quantified by calculating the symmetric difference |A0△X0| , with |⋅| representing the cardinality of a set. In the context of rule-based explanation techniques, the set A0 represents the features with zero attribution within the rules. Effective complexity: It measures the degree of feature interaction and its impact on the model’s accuracy. 45 Let a(i) represent the attributions ordered in ascending order based on their absolute values, and x(i) denote the corresponding features. Let Mk={x(N−k),…,x(N)} be the set of the top k features. Given a predefined tolerance level ϵ>0 , the effective complexity, denoted as k* , is defined as k*=argmink∈{1,…,N}|Mk|,s.t. E(l(y*,f−Mk)|x*Mk)<ε , where f−Mk refers to the restriction of the model f to the non-important features, with values fixed for the important features in Mk . This restricted model, similar to the definition provided earlier, allows us to focus on the non-important features when assessing effective complexity. Here, y* and l are defined in the same manner as discussed in the context of the monotonicity metric previously. In the context of rule-based explainability techniques, adapting the concept of effective complexity involves replacing the traditional feature attributions with rule-based feature importance metrics derived from the coverage of rules. In this work, we used ϵ=0.1 . A low effective complexity indicates the ability to overlook certain features, even if they exert a minimal impact (analogous to non-sensitivity 47 ), resulting in decreased cognitive load. While this reduction in cognitive load may lead to a sacrifice in terms of factual accuracy, it offers a heightened level of flexibility. Users can freely alter the values of less important features without causing substantial deviations in predictions.

The three following metrics—entropy ratio, Kullback-Leibler divergence, and Gini coefficient—are used to assess the explainability of a model based on the distribution of feature importance. 48 They allow for a comparison between the actual feature importance distribution and a uniform benchmark distribution. Let us consider a set of feature importance denoted as F={F1,F2,…,FF} . Let P(.) denotes a normalization function which normalizes F by dividing each feature importance value by the sum of the absolute values of all features. The normalized value for a specific feature importance, j , is expressed as pj:=|Fj|/∑i=1F|Fi| . Consequently, the vector of normalized feature importance, P(F) , takes the form of a probability measure P(F):=p1,p2,…,pF , where pj≥0 , and ∑i∈Fpi=1 . The distribution of these normalized feature weights can be undertaken using the following three metrics. Define the uniform benchmark distribution as U=p¯,p¯,…,p¯ , where p¯=1/F . For rule-based explainability techniques, the feature importance is derived from the coverage of rules. Entropy ratio: It measures the spread of information within the feature importance distribution concerning a uniform benchmark. The entropy ratio is calculated as SER(P(F))=∑j=1Fpjlogpj/∑j=1Fp¯logp¯ . A lower ratio indicates that the explanation concentrates on a smaller set of features, implying higher model explainability. It compares the entropy of the actual feature importance distribution with the entropy of a uniform benchmark distribution. Kullback-Leibler divergence: It quantifies the difference between the feature importance distribution and the uniform benchmark distribution. The Kullback-Leibler divergence is calculated as SKL(P(F))=DKL(P(F)‖U)=∑j=1Fpjlogpjp¯ . A lower divergence suggests a closer similarity between the two distributions, indicating a more explainable model. It computes the information lost when one distribution is used to approximate the other. Gini coefficient: It evaluates the inequality or spread within the feature importance distribution. The entropy ratio is calculated as SG(P(F))=∑j=1F∑j′=1F|pj−pj′|2F2(∑pj/F) . A lower coefficient signifies a more evenly distributed importance among features, potentially resulting in a more complex explanation. Conversely, a higher coefficient indicates a more concentrated importance, possibly leading to a more explainable model. Correctness: It gauges the truthfulness of the explanation concerning how well it aligns with the black-box model’s workings. 49 Ideally, an excellent explanation strives for utmost truthfulness. It is imperative to clarify that this characteristic pertains to the descriptive accuracy 50 of the explanation, independent of the predictive accuracy of the black-box model. Compactness: It measures the size of the explanation, guided by human cognitive constraints. 51 To enhance comprehension, explanations should prioritize sparsity, brevity, and non-redundancy, steering clear of overly extensive presentations. In this study, compactness assessment for rule-based explainability techniques considers the length of generated rules, while for feature attribution techniques, it is quantified by the count of features with non-zero attributions. In this work, the compactness scores are expressed as percentages, reflecting the proportion of concise elements in the overall explanation. Higher compactness percentages signify more efficient and succinct explanations.

## Section: Methods › Experimenatal setup

Overview of experimental workflow: This study follows a standardized and reproducible pipeline for evaluating explainability methods across multiple healthcare datasets. At a high level, we begin by training a predictive model for each dataset using an automated model selection approach. The resulting model is treated as a fixed black-box. We then apply both local and global explanation techniques to interpret the model’s behavior and evaluate these explanations using quantitative metrics. Datasets: This study employs a diverse collection of 10 publicly available tabular healthcare datasets, predominantly sourced from the UCI Machine Learning Repository 52 and Kaggle (see Table 2). These datasets were selected due to their relevance to real-world clinical decision-making, as each one addresses a specific medical condition such as heart failure, breast cancer, or diabetes—conditions commonly studied in the context of model interpretability and healthcare risk prediction. In addition, the datasets vary in terms of feature dimensionality, class distribution, and sample size, enabling the evaluation of explainability methods across heterogeneous data scenarios. Moreover, these datasets are widely used as community benchmarks, which facilitates meaningful comparison with prior research in the field. Tasks and models: We focused on classification tasks and adopted a data-driven approach to ensure unbiased and high-performing model selection. To achieve this, we leveraged Auto-sklearn, an Automated Machine Learning (AutoML) framework. 63 Auto-sklearn allows us to select machine learning models based solely on their performance with the given data, providing a level playing field for the evaluation of interpretability techniques. The application of Auto-sklearn serves to mitigate potential biases linked to manual model selection, thereby enabling a thorough and systematic exploration of diverse models. In our experimental protocol, we follow a standardized pipeline for all datasets: (i) partitioning the dataset into 70% for training and 30% for testing, (ii) utilizing . to identify the optimal pipeline based on the training data, optimizing for accuracy, and (iii) for local explanation techniques, we apply each considered method to elucidate the predictions of the model for each instance in the testing dataset. We report the average of the considered evaluation metrics across instances in the testing dataset. For global explainability techniques, we explicate the black-box model based on the training data. Explanation method selection: To ensure a representative and balanced evaluation, we selected explanation methods based on three key criteria: (i) their popularity and widespread use in the XAI literature, (ii) their model-agnostic applicability, and (iii) their coverage of diverse interpretability paradigms. Specifically, we included techniques spanning perturbation-based approaches (e.g. LIME), contrastive rule-based methods (e.g. anchors), classical rule-learning algorithms (e.g. RuleFit and RuleMatrix), and sensitivity-based methods (e.g. CIU). This selection reflects both local and global explanation strategies, enabling us to compare performance across methodological families in healthcare-specific scenarios. Our choices were guided by prior benchmarking and survey studies,6,16,23 ensuring that the selected methods are relevant, diverse, and generalizable. Hardware resources: Our experiments were conducted in a CPU environment running on Ubuntu 22.04 LTS, equipped with a 8-core Intel i7 Processor @ 2.80 GHz and 16 GB of RAM.

Summary of datasets used in this study. Dataset references are provided in the bibliography.

## Section: Results

This section presents the quantitative outcomes of our benchmarking study on local and global explanation methods using a range of evaluation metrics. Results are reported objectively without interpretation.

Metric scores for different local explanation techniques on tabular data.

## Section: Results › Local interpretability results

Table 3 summarizes the performance of LIME, CIU, RuleFit, RuleMatrix, and Anchor across several datasets on eight local interpretability metrics:

Identity: RuleFit and RuleMatrix consistently achieved 100%, indicating perfect reproducibility. LIME and CIU frequently scored 0%.Separability: LIME and CIU obtained high scores across datasets, while RuleFit and RuleMatrix showed more variability.Fidelity: RuleFit, RuleMatrix, and Anchor achieved high fidelity scores. LIME and CIU performed lower on this metric.Speed: RuleFit and RuleMatrix provided the fastest explanations. Anchor was the slowest.Stability: RuleFit and RuleMatrix had high stability. Anchor had the lowest.Monotonicity: CIU achieved the highest monotonicity scores. RuleFit and Anchor were moderate. LIME scored the lowest.Non-sensitivity: LIME and CIU scored highest in identifying non-influential features. Rule-based methods performed lower.Effective complexity: LIME and CIU generated the simplest explanations. RuleFit and RuleMatrix had higher complexity.

Metric scores for different local explanation techniques on tabular data.

## Section: Results › Global interpretability

In this section, we present a comprehensive examination of various global explanation methods evaluated across a diverse array of datasets, as highlighted in Table 4.

## Section: Discussion

The benchmarking results reveal distinct trade-offs among the evaluated interpretability methods. RuleFit and RuleMatrix demonstrated strong performance in reproducibility, fidelity, and correctness, which are critical for deployment in clinical and regulatory contexts. However, their explanations often exhibited higher complexity, which may increase the cognitive effort required for interpretation. Anchor offered competitive correctness and fidelity but showed notable limitations in reproducibility and latency. These constraints can reduce its applicability in time-sensitive or reliability-critical settings. LIME and CIU stood out in terms of separability and low effective complexity, making them attractive for settings where simplicity and differentiation between instances are important. LIME and CIU often scored 0% in identity, indicating a lack of consistency in the explanations. LIME and Anchor often scored 0% in global identity as well, which raises concerns about the reproducibility and reliability of the explanations these methods generate in practice. These findings underscore that no explanation method dominates across all metrics or use cases. The appropriate choice depends on the application’s interpretability demands, whether prioritizing auditability, simplicity, model alignment, or computational efficiency. Finally, our evaluation does not incorporate human-centered assessments such as usability or clinician feedback. This limits our ability to judge the practical effectiveness of explanations in real-world decision-making. Future work should incorporate expert-in-the-loop studies and assess performance on diverse data modalities.

Metric scores for different global explainability techniques on tabular data.

## Section: Conclusion

This study quantitatively evaluates local (LIME, CIU, RuleFit, RuleMatrix, and ILIME) and global (LIME, Anchor, RuleFit, and RuleMatrix) explanation methods using healthcare datasets. Among global explainability techniques, RuleFit and RuleMatrix consistently perform well, providing clear and robust model interpretations. In contrast, LIME, which prioritizes simplicity, exhibits lower correctness, indicating potential misalignment with the underlying model. For local explainability, RuleFit and RuleMatrix excel in identity, stability, and fidelity metrics, demonstrating strong alignment with model behavior. The variation in performance across different metrics highlights the need for nuanced method selection, emphasizing the importance of prioritizing criteria based on the specific application and carefully considering trade-offs between explainability dimensions. Despite the comprehensive scope of this study, several limitations warrant consideration. First, the analysis focuses on a specific subset of explainability techniques, primarily rule-based and surrogate model approaches. This excludes other prominent families of XAI methods, such as gradient-based saliency techniques and counterfactual explanations, which may behave differently under the same evaluation metrics. Second, the experimental evaluation is limited to structured, tabular datasets derived from clinical settings. Consequently, the generalizability of the findings to unstructured data domains (e.g. medical imaging, clinical notes, or time-series data) remains unexamined. Third, the study emphasizes quantitative assessment metrics—including identity, fidelity, and stability—but does not incorporate human-centered evaluations. In particular, the cognitive and practical interpretability of the generated explanations from a domain expert’s perspective (e.g. clinicians or healthcare practitioners) is not assessed, which is critical for real-world deployment. Lastly, the current evaluation does not explore the computational cost or scalability of the methods, factors that may influence their feasibility in time-sensitive or resource-constrained environments. Furthermore, it is important to acknowledge that not all explanations are equivalent in purpose, granularity, or interpretive utility. Different XAI methods offer fundamentally distinct forms of explanations—ranging from rule-based abstractions to local perturbation-driven approximations—each suited to different users and contexts. For instance, a high-fidelity explanation may not be understandable to a non-technical audience, while a more intuitive explanation may oversimplify model behavior. These epistemic trade-offs highlight the need for incorporating expert-in-the-loop validation protocols to assess explanation relevance, plausibility, and actionability from a domain-specific perspective. In healthcare, engaging clinicians to validate whether the explanations align with clinical reasoning and decision-making pathways is essential. Such human-centered evaluations are a critical next step for ensuring the practical reliability and ethical deployment of explainable AI in high-stakes environments.


---

# Exploring the macrocyclic chemical space for heuristic drug design with deep learning models

- **Authors:** Feng Hu, Xiaotong Jia, Wenjie Liao, Ziqi Chen, Hongjie Bi, Huan Ge, Dandan Liu, Rongrong Zhang, Yuting Hu, Wenyi Mei, Zhenjiang Zhao, Kai Zhang, Lili Zhu, Yanyan Diao, Honglin Li
- **Issuer:** Communications chemistry
- **Type:** Scientific article
- **Published:** 2025-10-07
- **Language:** en
- **DOI:** 10.1038/s42004-025-01686-w
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41057501/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractMacrocyclic compounds hold great promise as therapeutic agents. However, their structural optimization remains constrained by the limited availability of bioactive candidates, which in turn hampers the systematic exploration of structure-activity relationships. Here we introduce CycleGPT, a generative chemical language model designed specifically to address these challenges. CycleGPT is characterized by a progressive transfer learning paradigm that incrementally transfers knowledge from pre-trained chemical language models to specialized macrocycle generation, thereby overcoming the data shortage issue. Meanwhile, it adopts an innovative probabilistic sampling strategy that effectively improves the structural novelty of generated macrocycles while ensuring domain-specific adaptability. In a prospective drug design based on CycleGPT and a JAK2 activity prediction model, we successfully developed a new JAK2 drug candidate with a good selectivity profile (inhibiting 17 wild-type kinases) and promising potential for treating polycythemia in vivo, demonstrating the practicality of deep learning methods in macrocyclic drug design.Subject terms: Computational chemistry, Drug discovery and development, Virtual screening

## Section: Introduction

Innovative drug research, propelled by advances in chemistry, aims to identify effective molecular agents for disease treatment1. While small molecules—especially those following Lipinski’s rule—remain central to drug development, their limited binding interfaces and insufficient affinity for desired targets often result in poor stability2, short half-life, and off-target effects3,4. To address these limitations, researchers are exploring distinct modalities to expand the chemical space of druggability, with macrocycles emerging as promising candidates for overcoming the constraints of traditional small-molecule drugs1,5. Macrocycles are typically defined as cyclic chemical molecules or peptides containing a dodecyl ring or larger ring structure, bridging the gap between small molecules and antibodies1,6,7. These chemical structures can form large contact interfaces with proteins8 and with higher binding affinity and improved selectivity. Meanwhile, their chameleon properties7 enhance drug stability and confer favorable pharmacokinetic profiles9–11. Nowadays, macrocycles have been successfully used as potential therapeutic agents for a variety of drug targets, such as kinases, proteases, and G-protein-coupled receptors, achieving excellent outcomes in the treatment of many diseases.

Rational macrocyclic drug design typically involves the macrocyclization of bioactive linear compounds and the subsequent modification of the resulting macrocycles12. In the macrocyclization step, there are already some computational methods13,14 that leverage geometrically constrained linker searching and connection strategy from a prebuilt 3D linker database to derive distinct macrocyclic skeletons. In addition, our team previously introduced Macformer, a substructure-aligned SMILES augmentation strategy with a Transformer architecture to automatically generate macrocyclic linkers15. However, given a bioactive macrocyclic compound as a starting point, how to further modify and optimize its structure (e.g., through macrocyclic scaffold hopping or substituent modifications on the macrocyclic ring) to enhance druggability or expand the pool of candidates for early-stage clinical screening remains an unresolved challenge. So far, such modifications primarily depend on the expert experience of pharmaceutical chemists or the utilization of iterative methods such as pharmacophore replacement, which are time-consuming and labor-intensive. A representative case is the discovery of macrocyclic compound Z11, a selective CDK9 inhibitor, designed to overcome resistance to Osimertinib in non-small cell lung cancer. Beginning with the linear precursor Z0, the researchers first performed macrocyclization to obtain Z1, followed by three iterative rounds of structural modification, ultimately yielding the optimized macrocyclic compound Z1116. Despite such progress, effective computational strategies for the structural optimization of macrocycles remain scarce in the literature.

Thoroughly dissecting the intricate chemical space of macrocycles is a fundamental guidance for their structural modification and optimization. As an emerging and highly underexplored class of structures, human knowledge about macrocycles is limited, and researchers have been struggling to elucidate what properties make a macrocyclic compound suitable for drug development. Viarengo-Baker et al.17 conducted a principal component analysis of oral and non-oral macrocyclic compounds and identified 13 properties that could be used to design macrocyclic compounds in the same chemical space as oral macrocyclic drugs. Jimenez et al.1 systematically analyzed the FDA-approved macrocyclic drugs and proposed a simple bi-descriptor model, i.e., hydrogen bond donors less than or equal to 7 in combination with either molecular weight less than 1000 or cLogP greater than 2.5, as filtering criteria for screening oral macrocyclic drugs. However, due to the structurally complex nature of macrocycles and the scarcity of available macrocyclic therapeutics, explicit descriptors offer only limited guidance for the design of macrocyclic drugs.

In this paper, we consider exploring the compounds situated in the immediate chemical neighborhood of lead macrocycles, which could have great potential to serve as drug candidates. We achieve this by introducing CycleGPT‌, a molecular generative model tailored for systematic exploration and expansion of privileged macrocycle chemical space. CycleGPT is characterized by a progressive transfer learning paradigm to incrementally transfer knowledge from pre-trained chemical language models to specialized macrocycle generation, overcoming critical data scarcity in the target domain. In particular, it can effectively sample macrocycles from the neighboring chemical space of privileged macrocyclic candidates, converting the problem of macrocycle structural modification into the exploration of the chemical space of macrocycles. In addition, we designed a generative sampling scheme named HyperTemp to facilitate CycleGPT to dynamically balance the exploitation of high-probability tokens with an exploration of alternative pathways, thus achieving a superior equilibrium between the novelty and validity of macrocycles. Using CycleGPT, we have designed a number of macrocycles specifically for the JAK2 target based on the macrocycles designed by Macformer from our previous research15. In this CycleGPT-driven prospective drug design, three potent macrocyclic JAK2 inhibitors were identified, with IC50 values reaching 1.65 nM, 1.17 nM, and 5.41 nM, respectively. One of them exhibits an even better kinase selectivity profile compared with the marketed drugs, Fedratinib and Pacritinib. Furthermore, the discovered macrocycle can inhibit RhePO-mediated polycytiosis and splenomegaly in BALB/c mice at a lower dose than Fedratinib and Pacritinib. These therapeutic candidates demonstrate the significant potential of CycleGPT for advancing macrocyclic drug discovery.

## Section: Results

a Architecture of CycleGPT. b Training process of CycleGPT. Using a progressive transfer learning strategy, bioactive molecules are used first for pretraining GPT, then the macrocyclic compounds and downstream application targeting JAK2 are used to finetune the model in the second and third steps, respectively. c, d UMAP visualization of molecules to illustrate the transfer of chemical space. Altogether 1000 generated molecules were stochastically selected after each of the three stages of the transfer learning process. This shows that the model correctly migrates from the active linear compound space to the macrocyclic space and further migrates to the JAK2 macrocyclic space.

Comparison of CycleGPT-HyperTemp and other models

Distribution of the percentage change in generative probabilities for the suboptimal tokens (a), and for the optimal tokens (b) when comparing HyperTemp sampling against Tempered sampling (as baseline). The optimal (suboptimal) token is defined as the token with the largest (second-largest) generative probability in each generation for the two sampling schemes. Specifically, percentage changes are calculated by the token probability of HyperTemp sampling minus that of Tempered sampling, divided by the latter. c Distribution of the rank of generated tokens from Tempered sampling and HyperTemp sampling for a total of 30,000 SMILES generated. We can see that for the optimal token, the frequency of being sampled decreases; for suboptimal tokens, the frequency of being sampled is increased. This indicates that HyperTemp sampling effectively expands the exploration of suboptimal tokens compared with Tempered sampling, which is key to improving the novelty. d UMAP visualization of the structural modification of Loratinib as an example. A total of 1000 generated molecules were stochastically selected after the transfer learning process of Loratinib. Chemical structures of representative compounds illustrating structural modifications are presented. These modifications include the scaffold hopping of macrocycles (displayed using blue cycle) and peripheral substituent modifications (displayed using red cycle).

a The Workflow of CyclePred. b The pie chart of activity data of collected JAK2 inhibitors. c The R2 of CyclePred of macrocycles dataset (macrocycles in test and validate dataset). d Scatter plot of docking scores for the top 70 predicted macrocycles, including 6 synthesized macrocycles and other candidates, obtained using Maestro Prime and Rosetta docking. Six molecules that failed to dock were excluded. e The chemical structures of synthesis 6 macrocycles. f The in vitro activities of compounds 1–6. Data are mean ± SD, each parallel experiment was repeated three times.

a Western blot analysis of phosphorylation of JAK2 (Y1007/8), STAT3, STAT5, AKT and ERK. b Kinase selectivity profiles of Pacritinib and compound 2 against 468 kinases. c Representative photographs of the spleen. d Spleen weight. e Hematocrit. f Reticulocyte count. g Ter119/CD71 erythroblast population in spleen. h Ter119/CD71 erythroblast population in bone marrow. i Body weight.; All graphs show mean ± SEM. ####P < 0.0001 versus control. *P < 0.05; **P < 0.01; ***P < 0.001; ****P < 0.0001 versus model. ^P < 0.05; ^^P < 0.01 versus 100 mg/kg of compound 2 groups.

## Section: Results › Model overview

GPT-based models have demonstrated exceptional performance in sequence processing tasks in recent years18. To explore the macrocyclic chemical space, we developed a model called CycleGPT based on the progressive transfer learning strategy. The model interprets and generates chemical language representations at a concise and efficient character level, which can effectively sample the adjacent chemical space of privileged macrocycles and explore potential alternative macrocyclic drug candidates. To address the challenge of insufficient macrocyclic compounds, CycleGPT was first pre-trained using 365,063 active compounds with biological activity labels to grasp SMILES semantics. These compounds were extracted from the ChEMBL19 database with IC50/EC50/Kd/Ki values lower than 1 μM and SMILES strings shorter than 140 tokens in length. Subsequently, we collected 19,920 macrocyclic molecules with SMILES lengths of less than 140 characters from the CHEMBL and Drugbank20 databases. These macrocycles were utilized for transfer learning on the pre-trained CycleGPT model, aiming to adapt the model’s knowledge from the chemical space of bioactive linear molecules to that of macrocyclic compounds. The model can be further fine-tuned with macrocyclic hits for designing target-specific drug candidates. (Fig. 1a, b). We use the Lion21 optimizer to adjust the network parameters.

In molecular generation, the sampling algorithm and network architecture jointly determine the quality of the generated SMILES. However, the performance of existing sampling algorithms in macrocyclic SMILES remains challenging, especially in achieving a satisfactory balance between the validity and novelty of generated compounds. In this paper, we propose a heuristic sampling algorithm, HyperTemp, which makes a transformation strategy based on tempered sampling to facilitate fine-grained adjustments of the token probabilities. HyperTemp can appropriately reduce the probability of optimal tokens while increasing the probability of suboptimal tokens to improve novelty and maintain the validity of the generated macrocycles. We combine HyperTemp sampling with the CycleGPT architecture to realize a complete macrocyclic generation model, and systematically compare HyperTemp with existing sampling algorithms. To verify the validity and effectiveness of this introduced transformation, we also selected three other transformations to adjust the probability differently and performed a comparison with HyperTemp (Supplementary Formula 1–3). To the best of our knowledge, this work is among the first to comprehensively explore sampling algorithms in molecular generation for macrocycles, an underexplored yet crucial subclass.

a Architecture of CycleGPT. b Training process of CycleGPT. Using a progressive transfer learning strategy, bioactive molecules are used first for pretraining GPT, then the macrocyclic compounds and downstream application targeting JAK2 are used to finetune the model in the second and third steps, respectively. c, d UMAP visualization of molecules to illustrate the transfer of chemical space. Altogether 1000 generated molecules were stochastically selected after each of the three stages of the transfer learning process. This shows that the model correctly migrates from the active linear compound space to the macrocyclic space and further migrates to the JAK2 macrocyclic space.

## Section: Results › Model performance

The performance of CycleGPT-HyperTemp was evaluated and compared with other molecular generation methods22–30, with results shown in Table 1. In addition to validity and macrocycle_ratio, greater emphasis is placed on novel_unique_macrocycles, a comprehensive metric quantifying the proportion of generated valid and unique macrocycles that are absent from the training dataset. Char_RNN can generate enough valid macrocycles but with a very low novel_unique_macrocycles value (11.76%), while the GPT-based models MolGPT and cMolGPT failed to capture the semantics of macrocycles. Llamol and MTMol-GPT demonstrate advantages over other models in terms of the novel_unique_macrocycles metric (38.13% and 31.09%, respectively), yet there remains a notable margin compared to our CycleGPT-HyperTemp model (55.80%).

To have a more comprehensive understanding of the characteristics and performance of the HyperTemp sampling, we took CycleGPT as the base model and replaced HyperTemp with 13 different sampling strategies. As shown in Supplementary Table 1, when employing the MaxEntropy or Noised Top-K algorithm, CycleGPT undergoes a cliff-like decline across all metrics. Overall, with respect to the novel_unique_macrocycles metric, the HyperTemp sampling method performs best among all algorithms. We further analyzed the effect of the HyperTemp sampling algorithm on the generated tokens. As illustrated in Fig. 2a–c, through finer probability adjustment based on tempered sampling, HyperTemp further reduces the preference for optimal tokens and enhances the exploration of suboptimal tokens, which promotes the diversity of token sampling and improves the novelty.

In addition, we conducted a systematic evaluation of MOSES9 metrics for macrocycles generated by different methods, excluding those with poor performance in novel_unique_macrocycles (<20%). Considering the numerous comparison methods and their subtle variations, we summarized only the top three methods for each property and displayed them in Supplementary Tables 2–3. Across the 10 properties, CycleGPT combined with either HyperTemp or Top-p sampling ranks in the top three for six, outperforming all other methods. Moreover, the molecular properties analyses (Supplementary Figs. 1–3) reveal that the generated macrocycles from CycleGPT-HyperTemp possess a similar distribution compared with the training dataset. The above results demonstrate that our CycleGPT-HyperTemp model could generate a higher proportion of valid and unique macrocycles while maintaining molecule diversity and property quality.

To evaluate the effectiveness of our method in downstream target applications, as an example, we further expanded the chemical space of the macrocyclic compound Loratinib using our CycleGPT-HyperTemp method. The visualization of the generated molecular chemical space is shown in Fig. 2d. It can be seen that after performing fine-tuning with Loratinib, the generated macrocycles migrated to the nearby chemical space of Loratinib, demonstrating the correct chemical space exploration ability. Furthermore, it illustrates that our method can achieve structural modification of macrocycles, including 1. macrocyclic scaffold hopping, and 2. peripheral substituent modifications. These structural modification functions are consistent with the common modification methods in medicinal chemistry, reflecting the practicality of structural modifications implemented by our method.

Comparison of CycleGPT-HyperTemp and other models

Distribution of the percentage change in generative probabilities for the suboptimal tokens (a), and for the optimal tokens (b) when comparing HyperTemp sampling against Tempered sampling (as baseline). The optimal (suboptimal) token is defined as the token with the largest (second-largest) generative probability in each generation for the two sampling schemes. Specifically, percentage changes are calculated by the token probability of HyperTemp sampling minus that of Tempered sampling, divided by the latter. c Distribution of the rank of generated tokens from Tempered sampling and HyperTemp sampling for a total of 30,000 SMILES generated. We can see that for the optimal token, the frequency of being sampled decreases; for suboptimal tokens, the frequency of being sampled is increased. This indicates that HyperTemp sampling effectively expands the exploration of suboptimal tokens compared with Tempered sampling, which is key to improving the novelty. d UMAP visualization of the structural modification of Loratinib as an example. A total of 1000 generated molecules were stochastically selected after the transfer learning process of Loratinib. Chemical structures of representative compounds illustrating structural modifications are presented. These modifications include the scaffold hopping of macrocycles (displayed using blue cycle) and peripheral substituent modifications (displayed using red cycle).

## Section: Results › Modification of macrocyclic JAK2 inhibitors using CycleGPT

The Janus kinases (JAKs), a family of intracellular tyrosine kinases, play a pivotal role in mediating the signaling of many cytokines and are implicated in the pathogenesis of various diseases, such as myeloproliferative neoplasms and rheumatoid arthritis31–33. We previously designed three macrocyclic Janus kinase 2 (JAK2) inhibitors using Macformer through macrocyclization of Fedratinib, with compound M3 (renamed for clarity) demonstrating potential as a drug candidate5. Having alternative drug candidates is an effective strategy to provide contingency options to mitigate risks and ensure continuity in the drug development process. In this study, CycleGPT was utilized to explore their neighboring chemical space to obtain potential alternative drug candidates targeting JAK2 for further investigation.

Ten-fold augmentation was performed on the three macrocyclic JAK2 inhibitors with randomized SMILES strings, which were subsequently used to fine-tune the CycleGPT model for transfer toward a specific chemical space. The HyperTemp algorithm was employed in the inference process, generating 5058 macrocycles distributed around the starting macrocycles, indicating that CycleGPT-HyperTemp learned and explored the space of the JAK2 macrocycles correctly (Fig. 1d). To further enrich the macrocycles generated by CycleGPT, we employed the CyclePred, a heterogeneous graph transformer model, for the prediction of JAK2 inhibitory activity (Fig. 3a). The RMSE value of CyclePred from 5 times 5-fold is 0.6717 and can be lowered to 0.5776 when predicting the JAK2 macrocycles in the non-training set (lower is better). The predicted and experimental -pIC50 values exhibit a good correlation, with an R2 value of 0.7036 (Fig. 3c).

After predicting JAK2 activity with CyclePred, the top 70 macrocycles were selected for docking simulation using Glide34 and Rosetta35, respectively. The Fedratinib-JAK2 kinase domain complex (PDB code 6VNE)36 from the PDB database was used for molecular docking of the above 70 macrocyclic compounds. According to the docking results (Fig. 3d) and the synthetic experience of pharmaceutical chemists, six macrocycles (Fig. 3e) were finally selected for chemical synthesis (Supplementary Figs. 5–19) and biological activity evaluation. The molecular binding modes of these six macrocyclic compounds with the target are shown in Supplementary Fig. 4 (visualization using ChimeraX)37. It can be seen that they all have a good interaction with the target.

a The Workflow of CyclePred. b The pie chart of activity data of collected JAK2 inhibitors. c The R2 of CyclePred of macrocycles dataset (macrocycles in test and validate dataset). d Scatter plot of docking scores for the top 70 predicted macrocycles, including 6 synthesized macrocycles and other candidates, obtained using Maestro Prime and Rosetta docking. Six molecules that failed to dock were excluded. e The chemical structures of synthesis 6 macrocycles. f The in vitro activities of compounds 1–6. Data are mean ± SD, each parallel experiment was repeated three times.

## Section: Results › Activities of designed macrocyclic JAK2 inhibitors

Kinase assays were performed using the Z’-LYTETM kinase assay kit to determine the inhibitory activities of these six macrocyclic compounds, with compound M3, which we gained from the previous study, and Fedratinib as positive controls (Fig. 3f and Supplementary Fig. 21). Three of the six macrocycles demonstrated strong JAK2 inhibition with single nanomolar IC50 values, and the most potent compound 2 (IC50 = 1.17 nM) showed superior activity compared to Fedratinib. These compounds were further evaluated for their antiproliferative activities against HEL and SET-2 cells (Fig. 3f), which are human erythroleukemia cells and primary thrombocytosis cells containing the JAK2 V617F mutation. Compound 2 exhibited significant antiproliferative activities against HEL and SET-2 cells with JAK2V617F mutant by inhibiting the JAK2-STAT signaling pathway in a dose-dependent manner (Fig. 4a and Supplementary Fig. 22). Furthermore, compound 2 displayed a superior kinome selectivity profile than Fedratinib and Pacritinib (Fig. 4b). At a concentration of 100 nM, the number of wild-type kinases inhibited by compound 2 is 17 (percent control <35%), while those are 55 and 34 for Pacritinib and Fedratinib, respectively. Kinase selectivity profiles of Fedratinib can be obtained from our previous article5.

Building upon the superior inhibition and the kinase profiling results of compound 2, subsequent in vivo efficacy studies were conducted to further validate its biological effects. Studies have shown that treating rodents with recombinant erythropoietin (rhEPO) can simulate the main symptoms of human erythrocytosis (PV)38,39, including increased reticulocyte count and hematocrit, splenomegaly caused by extramedullary hematopoiesis, and so on. We treated BALB/c mice with daily s.c. injections of either 10 units of rhEPO along with once daily oral administration of compound 2 dosed at 25, 50, and 75 mg/kg or vehicle for 4 consecutive days. Compared to the control group, the rhEPO-induced model group showed elevation of reticulocyte counts and hematocrit, expansion of Ter119/CD71 erythroblast in spleen and bone marrow, and splenomegaly. Excitedly, compound 2 suppressed rhEPO-induced hematocrit expansion, reticulocytosis, and splenomegaly (Fig. 4c–f), with the effects of 100 mg/kg compound 2 being comparable to those of 120 mg/kg Fedratinib and superior to those of 120 mg/kg Pacritinib. Moreover, compound 2 inhibited the expansion of Ter119/CD71 erythroblasts in both the spleen and bone marrow (Fig. 4g, h and Supplementary Figs. 20 and 23a–b). Additionally, it had no significant impact on white blood cell counts and body weights (Fig. 4i and Supplementary Fig. 23c). Overall, the above results indicated that compound 2 has potential for the treatment of polycythemia.

a Western blot analysis of phosphorylation of JAK2 (Y1007/8), STAT3, STAT5, AKT and ERK. b Kinase selectivity profiles of Pacritinib and compound 2 against 468 kinases. c Representative photographs of the spleen. d Spleen weight. e Hematocrit. f Reticulocyte count. g Ter119/CD71 erythroblast population in spleen. h Ter119/CD71 erythroblast population in bone marrow. i Body weight.; All graphs show mean ± SEM. ####P < 0.0001 versus control. *P < 0.05; **P < 0.01; ***P < 0.001; ****P < 0.0001 versus model. ^P < 0.05; ^^P < 0.01 versus 100 mg/kg of compound 2 groups.

## Section: Discussion

Macrocycles are a promising class of drugs with certain properties that could address the shortcomings in drug design for small-molecule drugs. Performing structural modification of privileged macrocycles in drug research is an important route for drug design. To deal with macrocycle structural modification more effectively, CycleGPT was proposed based on a progressive transfer learning strategy to transform the macrocycle structural modification into macrocyclic chemical space exploration in this study. For this specific task, the HyperTemp sampling algorithm was designed to improve the diversity and quality of generated macrocycles. The HyperTemp sampling algorithms in conjunction with CycleGPT can achieve structural modification of macrocycles, including macrocyclic scaffold hopping and modification of substituents on the macrocyclic ring, which is in line with the modification ideas of medicinal chemists.

From the molecules generated by CycleGPT-HyperTemp, six compounds were selected for synthesis based on JAK2 activity prediction and molecular docking scores. Subsequent biological tests revealed that compounds 1, 2, and 6 manifested high inhibitory activity against JAK2 at both enzyme and cellular levels, with compounds 2 displaying an improved selectivity profile against 468 kinases compared to Pacritinib and Fedratinib. In addition, compound 2 possessed the potential to treat polycythemia. This prospective case highlights the practicality of CycleGPT combined with HyperTemp sampling to explore macrocyclic chemical space. Moreover, it provides potential macrocyclic drug candidates for further development of JAK2-targeted therapies. It is expected that CycleGPT will significantly enhance macrocyclic drug design as an advanced extension of current computational methods, enabling efficient exploration and modification of emerging candidate compounds.

## Section: Methods › Datasets

Bioactive molecules with activity values (IC50, EC50, Kd, Ki) < 1 μM were collected from the ChEMBL19 database. The molecules were converted into canonical SMILES strings using RDKit, with only those no longer than 140 tokens retained. After removing stereochemistry, salts, and duplicate molecules, 365,063 active molecules were eventually obtained as unique SMILES strings.

The macrocycles used for progressive transfer learning mainly came from two databases, ChEMBL and Drugbank20. Only macrocycles with SMILES strings shorter than 140 tokens in length were retained. We integrated and removed duplicate molecules from both datasets, resulting in a total of 19,920 macrocycles.

## Section: Methods › CycleGPT model

CycleGPT was implemented based on the nanoGPT architecture (https://github.com/karpathy/nanoGPT), which utilized torch for constructing the GPT network. In CycleGPT, we used the auto-regressive approach to generate macrocycle SMILES. For a sequence x=(x1,x2,x3...xt), the auto-regressive model decomposes the joint probability distribution through the chain rule:

where xt represents the vector of the t th token, θ represents the model parameters. When training the auto-regressive model, we used the cross-entropy loss function to minimize and optimize the model parameters θ.

CycleGPT used 12 blocks, with the hidden dimension set to 768. The input and generated SMILES token length was set to 140, and the embedding vector size of each token was set to 768. It employed the Causal Self-Attention mechanism with attention heads set to 12. These attention layers are interconnected and projected into the final output. The scaled-dot attention layer uses three matrices as inputs: a matrix Q containing a set of queries, a matrix K containing keys, and a matrix V containing values. The attention calculation is as follows:

where dk is a scaling factor determined by the size of the weight matrices. We employed the optimizer Lion21, developed by Google in 2023, to optimize parameters.

## Section: Methods › Sampling strategy

The sampling strategies of language models play a key role in affecting the generative quality. There are many popular sampling schemes in the literature, including MaxEntropy sampling, Random mask sampling, Top-K sampling, Noised top-K sampling, Top-p sampling, Tempered sampling, and Tempered top-K sampling40. However, these sampling schemes were mostly designed for generating text sequences. When they are used directly for generating SMILE sequences, the quality of the generated molecules remains to be improved, especially in terms of the balance between the validity and the novelty of the molecules (see Supplementary Table 3).

We designed a sampling algorithm named HyperTemp for generating high-quality SMILE sequences. The main idea of HyperTemp is to introduce a nonlinear transform to adaptively modulate the output probabilities for each token as computed by the language model, and then apply multinomial distribution sampling on the rectified probabilities. Specifically, the nonlinear transform function is chosen as the hyperbolic tangent (tanh) function, defined as:

where N is vocabulary size, pi represents the output probability of the ith token in the vocabulary, and T is adjustable temperature. Then the rectified probabilities with HyperTemp are used for generating the next token.

The HyperTemp sampling strategy employs a nonlinear transformation to recalibrate token probabilities. This transformation moderately attenuates the top-ranked token probability while proportionally enhancing suboptimal token probabilities, thereby expanding the exploration of molecular candidates at each step. Crucially, the tanh function preserves the original relative ranking of tokens due to its monotonicity, ensuring that sequence generation adheres to chemically valid and syntactically regular patterns. By dynamically balancing exploitation of high-probability tokens with exploration of alternative pathways, HyperTemp achieves superior equilibrium between molecular novelty and structural validity compared to conventional sampling approaches (Supplementary Table 1).

It is noteworthy that increasing the temperature during the sampling process can enhance the novelty of the generated samples, as is widely used in the AI literature. However, this adjustment is restricted to a narrow range since excessively high temperatures substantially compromise the validity (or normality) of the generated samples. Therefore, within the desired temperature range, the capacity of elevated temperatures to improve the sampling novelty remains restricted. In comparison, the proposed Hyper-Temp sampling scheme offers a highly robust scheme to achieve the balance between novelty and validity. Empirical results demonstrate its efficacy in increasing the attention to suboptimal tokens to improve the novelty of generation (Fig. 2a–c and Supplementary Table 1)

## Section: Methods › JAK2 activity prediction

CyclePred was implemented based on MacFrag41 and PharmHGT42, which were used to predict the JAK2 activity of generated macrocycles for further screening. Training data were the experimental IC50 values of 8157 JAK2 inhibitors from PubChem43, ChEMBL19, and BindingDB44. CyclePred uses MacFrag to segment the molecules into the smallest building blocks, combine atomic information with MacFrag building blocks information to construct a heterogeneous graph of the macrocycle, and then perform multi-view message passing block and reading out block.

## Section: Methods › Model evaluation metrics

The performances of CycleGPT used some metrics widely used in the previous work of molecule generation22, including the following:

Validity refers to the percentage of generated valid molecules in the sampled molecules.

Macrocycle_ratio evaluates the proportion of compounds that are macrocycles in the generated molecules.

Novel_unique_macrocycles refers to the percentage of macrocycles that are unique and not present in the dataset in the generated molecules (remove duplicate macrocycles). It is a comprehensive metric that considers the novelty, uniqueness, and validity (macrocycle) of generated molecules.

In addition, we evaluated the properties in MOSES, including internal diversity (IntDiv, IntDiv2), Fréchet ChemNet Distance (FCD), Similarity to the nearest neighbor (SNN), Fragment similarity (Frag), and Scaffold similarity (Scaff), together with molecular weight, octanol-water partition coefficient (log P), quantitative estimation of drug-likeness (QED), and synthetic accessibility score (SA).

The performance of CyclePred used metrics include: Root Mean Square Error (RMSE) and R-squared (R2), commonly used dimensionless metrics in machine learning and deep learning for regression models. We have chosen to retain four decimal places to maintain the precision and consistency of our results.

## Section: Methods › Molecular docking

The crystal structure of JAK2 bound to Fedratinib (PDB code 6VNE) was selected as the reference structure for our docking simulations. Maestro and Rosetta were used to evaluate the potential of generated macrocycles against JAK2.

In Maestro docking, we prepared the protein using the Protein Preparation Wizard in Maestro v11.5. A grid-enclosing box was placed at the center of the crystal ligand, and the van der Waals radius scaling factor was set to 0.8, with partial atomic charges less than 0.15, to soften the non-polar parts of the receptor. The three-dimensional structure of the compound was generated and minimized using the Ligprep v3.3 module. The molecules were docked to the binding site using the Glide standard precision (SP) method with default parameters, and only the top pose of each molecule was retained. The binding modes of the docking were calculated using Prime MM-GBSA to calculate the ligand binding energy.

In Rosetta docking, we initially generated a set of low-energy conformations of the macrocycles using Maestro. The molfile_to_params.py script of Rosetta was employed to process the conformation file and subsequently incorporate the small molecule into the protein file. Finally, docking was carried out using the rosetta_scripts function.

## Section: Methods › Enzyme assay

Recombinant proteins of JAK1/2/3 and TYK2 were produced by the baculovirus expression system and JAKs kinase activity were measured using the Z′-LYTE™ Kinase Assay Platform45. In short, the reaction mixture contains 5 μL enzyme and Z′-LYTE Try6/3 peptide substrate (4 μM), 2.5 μL ATP (10 μM for JAK2, 25 μM for JAK2, 20 μM for JAK3, and 25 μM for TYK2), which were preincubated with various concentrations of tested compounds at room temperature for 1 h, then the development reagent was added to each well. After incubating at room temperature for another hour, a stop reagent was added to stop the reaction. Fluorescence was measured under 400 nm excitation and 445/520 nm emission. The IC50 value was calculated using a sigmoidal curve fit by GraphPad Prism 8.0.

## Section: Methods › Cell proliferation assay

HEL 92.1.7 and SET-2 cells were seeded at 5000 cells/well in 70 μL RPMI medium with 10% FBS to the 96-well plate and incubated overnight at 37 °C with 5% CO2. 30 μL tested compounds were added from an initial concentration of 25 μM with a 3-fold gradient dilution. After 72 h, 10 μL of Cell Counting Assay Kit-8 solution were added to each well and incubated for 2 h at 37 °C. The absorbance was measured at 450 nm using a microplate reader with a reference wavelength of 630 nm. All experiments were repeated in triplicate, and these data were plotted in Graphpad 8.0 to determine the half-maximal inhibition (IC50) values.

## Section: Methods › Western blot analysis

HEL 92.1.7 cells were added into a 6-well plate (1 × 106 cells/well) and then put into the incubator. After overnight growth, cells were treated with or without compound 2 for 4 h. Then cells were collected and lysed for protein concentration determination. For immunoblotting, the protein samples were isolated by SDS-PAGE and transferred to a PVDF membrane. The membrane was sealed with 5% skim milk in TBST for 2 h at room temperature, and incubated with the p-JAK2, p-STAT5, p-STAT3, p-AKT, p-ERK, JAK2, STAT5, STAT3, ERK, AKT, or β-actin primary antibody overnight at 4 °C. Then the membrane was washed with TBST and incubated with HRP-conjugated secondary antibody at room temperature for 2 h, and then exposed by chemiluminescence method using enhanced ECL immunoblotting system (Tanon, China). All experiments were repeated in triplicate and analyzed using Image J and Graphpad 8.0.

## Section: Methods › In vivo efficacy study

Female BALB/c mice aged 8–10 weeks (17–20 g body weight) were subcutaneously injected with 10 units of recombinant human erythropoietin (rhEPO) daily for 4 consecutive days, and orally administered either vehicle or compounds. Controls were injected with corresponding volumes of saline buffer. On day 5, mice were euthanized within 24 h after the last administration. Blood was collected into microtubes containing EDTA-K2 through orbital blood collection for routine blood test by Idexx ProCyte Dx® analyzer. After the spleens and bone marrows were isolated, they were placed in 1× PBS on ice for subsequent test. For flow cytometric analysis, the spleens and bone marrows were homogenized and filtered with a 70 µm cell strainer to isolate single cells and lysed red blood cells with RBC Lysis Buffer, washed in 1× PBS and Fc receptors were blocked by TruStain FcX™ (anti-mouse CD16/32) to reduce non-specific staining. Cells were stained by APC-conjugated Ter119 and PE-conjugated CD71 antibody in the dark at room temperature for 30 min. After washing twice, cells were resuspended in the Cell Staining Buffer and analyzed by flow cytometry. Data were analyzed using GraphPad Prism software. The results of in vivo experiments are expressed as mean ± SEM. Means were used for statistical comparisons between groups (one-way ANOVA followed by Dunnett’s test). P < 0.05 was considered to indicate a statistically significant difference. All animal experiments were conducted with the Guide for the Care and Use of Laboratory Animals of the National Institutes of Health and approved by the Animal Ethics Committee of East China University of Science and Technology (Permit Number: ECUST‑2022‑035).

## Section: Methods › Reporting summary

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article.

## Section: Supplementary information

Supplementary Information

Description of Additional Supplementary Files

Supplementary Data 1

Reporting Summary

## Section: Acknowledgements

This work has been supported in part by the National Key Research and Development Program of China (2022YFC3400501), the National Natural Science Foundation of China (82425104, 82404517), the Science and Technology Commission of Shanghai Municipality (No. 24JS2830200), and Fundamental Research Funds for the Central Universities. H.L. was also sponsored by the National Program for Special Supports of Eminent Professionals and the National Program for Support of Top-notch Young Professionals.

## Section: Author contributions

F.H. and X.J. wrote the manuscript. F.H. developed the CycleGPT, HyperTemp sampling, and CyclePred method. Y.H. helped F.H. to test the model. Y.D. and K.Z. guided the experiment of the computational section. W.L., H.B., D.L., R.Z., and W.M. synthesized the macrocyclic compounds. Z.Z. guided the synthesis of macrocyclic compounds. X.J., Z.C., and H.G. evaluated the activities of the compounds against JAK2 at enzymatic and cellular level. X.J. and Z.C. carried out the in vivo experiments. L.Z. guided the in vitro and in vivo experiments. K.Z. and L.Z. helped to revise the manuscript. Y.D. and H.L. designed the whole project and revised the manuscript.

## Section: Peer review › Peer review information

Communications Chemistry thanks the anonymous reviewers for their contribution to the peer review of this work.

## Section: Data availability

All data used in this paper include molecule dataset and JAK2 activity dataset are from publicly accessible databases, which include ChEMBL (https://www.ebi.ac.uk/chembl/), Drugbank (https://go.drugbank.com/), PubChem (https://pubchem.ncbi.nlm.nih.gov/) and BindingDB (https://www.bindingdb.org/bind/index.jsp). For the crystallographic structure using in this paper can be accessed at PDB database (https://www.rcsb.org). Supplementary Data 1 contains all the source data of this paper.

## Section: Code availability

Source code of CycleGPT are available at https://github.com/fengalbert/CycleGPT.

## Section: Competing interests

The authors declare no competing interests.

## Section: Contributor Information

Kai Zhang, Email: kzhang@cs.ecnu.edu.cn.

Lili Zhu, Email: zhulfl@ecust.edu.cn.

Yanyan Diao, Email: diaoyan1025@126.com.

Honglin Li, Email: hlli@ecust.edu.cn.

## Section: Supplementary information

The online version contains supplementary material available at 10.1038/s42004-025-01686-w.

## Section: Associated Data

Supplementary Information

Description of Additional Supplementary Files

Supplementary Data 1

Reporting Summary

## Section: Associated Data › Supplementary Materials

Supplementary Information

Description of Additional Supplementary Files

Supplementary Data 1

Reporting Summary

## Section: Associated Data › Data Availability Statement

All data used in this paper include molecule dataset and JAK2 activity dataset are from publicly accessible databases, which include ChEMBL (https://www.ebi.ac.uk/chembl/), Drugbank (https://go.drugbank.com/), PubChem (https://pubchem.ncbi.nlm.nih.gov/) and BindingDB (https://www.bindingdb.org/bind/index.jsp). For the crystallographic structure using in this paper can be accessed at PDB database (https://www.rcsb.org). Supplementary Data 1 contains all the source data of this paper.

Source code of CycleGPT are available at https://github.com/fengalbert/CycleGPT.


---

# Extracting Clinical Guideline Information Using Two Large Language Models: Evaluation Study

- **Authors:** Hsing-Yu Hsu, Lu-Wen Chen, Wan-Tseng Hsu, Yow-Wen Hsieh, Shih-Sheng Chang
- **Issuer:** Journal of medical Internet research
- **Type:** Scientific article
- **Published:** 2025-09-05
- **Language:** en
- **DOI:** 10.2196/73486
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40911841/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundThe effective implementation of personalized pharmacogenomics (PGx) requires the integration of released clinical guidelines into decision support systems to facilitate clinical applications. Large language models (LLMs) can be valuable tools for automating information extraction and updates.ObjectiveThis study aimed to assess the effectiveness of repeated cross-comparisons and an agreement-threshold strategy in 2 advanced LLMs as supportive tools for updating information.MethodsThe study evaluated the performance of 2 LLMs, GPT-4o and Gemini-1.5-Pro, in extracting PGx clinical guidelines and comparing their outputs with expert-annotated evaluations. The 2 LLMs classified 385 PGx clinical guidelines, with each recommendation tested 20 times per model. Accuracy was assessed by comparing the results with manually labeled data. Two prospectively defined strategies were used to identify inconsistent predictions. The first involved repeated cross-comparison, flagging discrepancies between the most frequent classifications from each model. The second used a consistency threshold strategy, which designated predictions appearing in less than 60% of the 40 combined outputs as unstable. Cases flagged by either strategy were subjected to manual review. This study also estimated the overall cost of model use and was conducted between October 1 and November 30, 2024.ResultsGPT-4o and Gemini-1.5-Pro yielded reproducibility rates of 97.8% (7534/7700) and 98.9% (7612/7700), respectively, based on the most frequent classification for each query. Compared with expert labels, GPT-4o achieved 93.5% accuracy (Cohen κ=0.90; P<.001) and Gemini-1.5-Pro 92.7% accuracy (Cohen κ=0.89; P<.001). Both models demonstrated high overall performance, with comparable weighted average F1-scores (GPT-4o: 0.929; Gemini: 0.935). The models generated consistent predictions for 341 of 385 guideline items, reducing the need for manual review by 88.6%. Among these agreed-upon cases, only one (0.3%) diverged from expert labels. Applying a predefined agreement-threshold strategy further reduced the number of priority manual review cases to 2.9% (11/385), although the error rate slightly increased to 0.5% (2/374). The inconsistencies identified through these methods prompted the prioritization of manual review to minimize errors and enhance clinical applicability. The total combined cost of using both LLMs was only US $0.76.ConclusionsThese findings suggest that using 2 LLMs can effectively streamline PGx guideline integration into clinical decision support systems while maintaining high performance and minimal cost. Although selective manual review remains necessary, this approach offers a practical and scalable solution for PGx guideline classification in clinical workflows.

## Section: Introduction

As pharmacogenomic (PGx) testing becomes more widely available, enhancing decision-making and knowledge-sharing in clinical genetics is essential for integrating PGx data into routine clinical practice [1]. PGx knowledge is new, complex, and constantly evolving, making it inadequate to rely solely on clinicians’ expertise for clinical implementation [2]. We developed a comprehensive database of drug-gene interactions and incorporated it into clinical decision support systems (CDSS) to achieve truly personalized treatment, improve patient outcomes, and optimize treatment strategies.

However, maintaining CDSS knowledge bases is crucial to ensuring alignment with the evolving nature of medical practice and clinical guidelines [3,4]. These labor-intensive activities necessitate manual input and significantly contribute to burnout among pharmacists. Recent research has highlighted the transformative potential of generative artificial intelligence (AI), particularly in leveraging large language models (LLMs) for data analysis and text generation to make complex medical information more accessible to health care providers and patients [5-7]. However, applying PGx guidelines as structured input for AI models remains rare, and even fewer studies have explored how to summarize classification task results effectively [8].

We hypothesize that using cross-comparison methods with 2 state-of-the-art LLMs can facilitate real-time updates to CDSS knowledge bases in health care institutions. Our objective is to enhance the clinical applicability and reliability of medical information while improving the dissemination of PGx knowledge.

## Section: Methods › Study Design

This methodological study followed the enhanced Transparent Reporting of a Multivariable Prediction Model for Individual Prognosis or Diagnosis (TRIPOD)-LLM reporting guidelines [9].

## Section: Methods › Ethical Considerations

This study did not involve human participants, identifiable personal data, or biological materials. Therefore, the Institutional Review Board of China Medical University Hospital determined that the study did not require ethical review or informed consent. All data used in the study were publicly available or derived from deidentified, nonhuman sources. No interventions, clinical recruitment, or patient-level interactions were conducted.

## Section: Methods › Model Selection and Data Sources

GPT-4o and Gemini-1.5-Pro were selected for their stable and publicly available cloud-based application programming interfaces (APIs), which support integration into clinical workflows and system deployment. In addition to their practical usability, both models have demonstrated strong performance in medical language understanding and instruction adherence in prior biomedical natural language processing studies [10,11]. Accordingly, we used these 2 LLMs to perform the classification tasks, analyzing drug-gene interaction recommendations derived from 385 clinical guideline annotations in PharmGKB as of October 5, 2024. Details of the retrospective datasets from PharmGKB are provided in Table S1 in Multimedia Appendix 1. All experiments and analyses involving the tested LLMs were conducted in English between October 1 and November 30, 2024.

## Section: Methods › Classification Process and Prompt Design

Researchers supplied LLMs (GPT-4o and Gemini-1.5-Pro) with pertinent information on drug-gene interactions. Using this data, LLMs were instructed to generate recommendations based on a predefined prompt. To enable rapid adaptation to complex tasks and efficient data processing, we used zero-shot prompting techniques. The prompt used was: “ Your task is to summarize the following content: Provide a treatment recommendation categorized into one of the following options: “No action needed,” “Consider dosage modification,” “Change medication,” or “Monitor adverse effects.” If none of these categories fit, you may respond with “Other.” If both dosage modification and adverse effect monitoring were recommended, priority was given to classifying the recommendation under dosage modification. If both dosage modification and changing medication were recommended, priority was given to classifying the recommendation under changing medication. Please directly give “No action needed,” “Consider dosage modification,” “Change medication,” or “Monitor adverse effects.” The classification tasks of these 4 options must comply with the CDSS system update requirements, and there is no need to explain the reasons.” For each input query, separate responses from GPT-4o and Gemini-1.5-Pro were recorded and are presented in Tables S2 and S3 in Multimedia Appendix 1.

## Section: Methods › Evaluation of Reproducibility, Accuracy, and Human Validation

GPT-4o and Gemini-1.5-Pro were used to evaluate 385 drug-gene interaction recommendations. Each recommendation underwent 20 repeated tests, generating 7700 responses per model (15,400 in total). Reproducibility was assessed by calculating the proportion of consistent responses across the 20 repetitions for each recommendation, using the most frequent response per model as the reference. Accuracy was evaluated by comparing model outputs with human-labeled data (Table S4 in Multimedia Appendix 1).

To further enhance accuracy and mitigate misclassification and hallucination issues, we implemented 2 strategies: (1) repeated cross-comparisons and (2) agreement-threshold strategy.

## Section: Methods › Evaluation of Reproducibility, Accuracy, and Human Validation › Repeated Cross-Comparisons

Classifications were first assessed within each model. Recommendations with inconsistent outputs between models were flagged for manual review.

## Section: Methods › Evaluation of Reproducibility, Accuracy, and Human Validation › Agreement-Threshold Strategy

For each recommendation, we aggregated 40 outputs from both models. If a classification appeared in ≥60% of responses (at least 24 out of 40 occurrences), it was considered stable and accepted as the final result. Those below the threshold triggered manual review.

## Section: Methods › Expert Validation

To facilitate expert validation, 5 pharmacists from hospitals of varying sizes participated in reviewing and classifying the guideline content. To establish a reference standard for comparison with LLM-generated outputs, each pharmacist independently reviewed the PGx guidelines and categorized the therapeutic recommendations using the same classification scheme as the LLMs. Recommendations were assigned to the “Other” category if none of the predefined options were applicable. A final consensus meeting was conducted to resolve discrepancies and determine the definitive reference labels.

## Section: Methods › Technical Implementation and CDSS Integration

PGx guideline information was initially curated by clinical pharmacists and stored in JSON format. A Python-based pipeline was developed to parse drug names, gene symbols, and recommendation summaries, which were then standardized into 385 unique drug-gene pairs. Each pair was processed 20 times by both GPT-4o and Gemini-1.5-Pro using fixed prompts via publicly available cloud-based APIs. The outputs were recorded in a structured tabular format, where each column represented one model repetition, enabling reproducible and scalable classification. To integrate the results into clinical workflows, model outputs were reviewed for consistency. Cases with discrepancies across repetitions or between models were flagged for manual review. Verified results were then automatically formatted for incorporation into the existing CDSS database.

## Section: Methods › Economic Evaluation

We conducted a preliminary evaluation of cost based on publicly available API pricing data. As of April 17, 2025, according to the pricing overview published on the Azure OpenAI Service website, the cost for GPT-4o is US $2.50 per million tokens for input and US $10.00 per million tokens for output. For Gemini 1.5 Pro, based on the pricing listed on Google Cloud’s Vertex AI Generative AI service, the input cost is US $0.3125 per million tokens, and the output cost is US $1.25 per million tokens.

## Section: Methods › Statistical Analysis

Descriptive statistics were used to report the reproducibility results of the classification tool. We also evaluated the accuracy of GPT-4o and Gemini-1.5-Pro in comparison with human-labeled data. For each LLM, classifications that agreed with human-labeled data were coded as 1, while disagreements were coded as 0. Cohen κ was used to assess the level of agreement. The κ statistic measures the level of agreement between 2 raters, accounting for agreement expected by chance [12]. Cohen κ was computed using the irr package in R (version 4.4.0; R Foundation for Statistical Computing). A P value of less than .05 was considered statistically significant. We calculated category-specific metrics to comprehensively evaluate the performance of the 2 LLM models. These metrics included precision (true positive number / total positive number), recall (sensitivity, true positive number / total actual number), and F1-score (2×[precision / [precision+ recall]). All statistical analyses were conducted using R.

## Section: Results

Among 385 PGx guideline recommendations, the majority were provided by the Clinical Pharmacogenetics Implementation Consortium (265/385, 69%). Most PGx interactions involved CYP2D6, CYP2C9, and CYP2C19. The largest proportion of guidelines pertained to drugs targeting the nervous system (147/385, 38.2%) and the cardiovascular system (115/385, 29.9%). These were followed by antineoplastic and immunomodulating agents (37/385, 9.6%). Drugs targeting the musculoskeletal system, anti-infectives for systemic use, and the alimentary tract and metabolism each accounted for 20 (5.2%). Medications related to the blood and blood-forming organs represented 4.4% (n=17), while those targeting the respiratory system were the least represented, comprising 2.3% (n=9) (Figure 1; Table S1 in Multimedia Appendix 1).

Among 7700 responses, GPT-4o produced 7534 consistent responses (97.8%; 95% CI 0.977‐0.982), while Gemini-1.5-Pro generated 7612 consistent responses (98.9%; 95% CI 0.986‐0.991) (Tables S2 and S3 in Multimedia Appendix 1). Human labeling consistency was 97.2% (95% CI 0.953‐0.987) (Table S4 in Multimedia Appendix 1). A total of 385 drug-gene interaction recommendations were compared with final classifications made by human experts. GPT-4o achieved agreement in 360 recommendations (accuracy: 93.5%; 95% CI 0.906‐0.958; Cohen κ=0.90; P<.001), while Gemini-1.5-Pro agreed on 357 recommendations (accuracy: 92.7%; 95% CI 0.897‐0.951; Cohen κ=0.89; P<.001) (Figure 2). The F1-scores of GPT-4o and Gemini ranged from 0.878 to 0.988 across different classes. The weighted average F1-scores were also very similar between the 2 models (GPT-4o: 0.929; Gemini: 0.935) (Table S5 in Multimedia Appendix 1).

Table 1 shows that the 2 models generated consistent predictions for 341 guideline classifications, while 44 classifications exhibited discrepancies. An analysis of the 44 guideline classifications with discrepancies revealed several recurring patterns. Specifically, 19 guidelines indicated that therapy should vary according to the patient’s metabolic type. Nine guidelines involved narrow therapeutic index drugs, for which dose adjustment should be carefully considered. Another 9 guidelines recommended monitoring for adverse events, even when the therapy was not explicitly advised. Five guidelines lacked sufficient clinical evidence to support a clear recommendation, and 2 provided dual options, advising avoidance of the drug or, if necessary, adjusting the dosage accordingly (Table S6 in Multimedia Appendix 1).

Applying a cross-comparison approach between the models reduced the proportion of guideline classifications requiring manual review to 11.4% (44/385). Furthermore, applying the predefined 60% agreement threshold (ie, at least 24 out of 40 classifications aligning with a single guideline question) further reduced the number of cases requiring prioritized manual review to 2.9% (11/385). However, this approach slightly increased the error rate, from 0.3% (1/341) to 0.5% (2/374). Table 2 lists the guideline questions where hallucinations persisted despite both AI approaches. For the 385 PGx clinical guideline entries, the total number of tokens processed in GPT-4o was 84,098 for input and 21,574 for output. In comparison, Gemini 1.5-Pro processed 446,284 input characters and 154,880 output characters. The combined total cost for running both LLMs was US $0.76 (Table 3).

## Section: Discussion › Principal Findings

To our knowledge, this is the first study to evaluate the accuracy and reproducibility of PGx guideline classification using 2 advanced LLMs simultaneously. Our approach was integrated into the existing CDSS workflow via automated guideline updates, supplemented by a manual review of inconsistent classifications. This reduces documentation burden and supports real-time updates. Although prior research suggests that LLM reproducibility may decline over time [13], our findings demonstrate that GPT-4o and Gemini-1.5-Pro consistently generated stable outputs across repeated classifications at the same time point, indicating high reliability. For simplified PGx recommendations, both models produced outputs comparable to expert annotations, particularly in classifying drug-gene interaction recommendations. The simultaneous use of 2 LLMs and repeated testing improved classification accuracy and reduced low-frequency hallucinations.

## Section: Discussion › Comparison to Prior Work

Research on LLM applications in medical genetics is limited. One study explored genetic education for BRCA1-related cancer syndrome, MLH1-related cancer syndrome, and HFE-related hemochromatosis [14]. Other studies have used chatbots to educate high-risk patients, provide cancer risk assessments, and promote preventive genetic testing [15,16]. Our study applies LLMs to clinical management, classifying PGx guidelines for integration into CDSS, enhancing health care education, and PGx application. Optimizing medication management requires understanding gene-drug interactions [17]. PGx-CDSS, a key clinical decision support tool, bridges knowledge gaps for health care providers and patients [18]. However, careful implementation is crucial to prevent alert fatigue and risks of liability [19].

Restricting output classifications also minimizes medical risks and enhances clinical decision support. Another potential application of this technology is enabling health care professionals to guide patients in precise pharmacotherapy and reduce adverse drug reactions. A study evaluated various publicly available LLMs for their ability to answer cancer-related questions. No clinically significant hallucinations were observed in simple queries [20]. Similar research fine-tuned Bidirectional Encoder Representations from Transformers models for classifying pharmacy publications to enhance clinical workflow applicability and reduce bias and hallucinations [21]. Our study confirms that leveraging zero-shot performance from 2 advanced LLMs provides a promising classification tool for simple tasks.

The classification system we adopted for PGx-drug interactions, “no action needed”, “consider dosage modification,” “change medication,” and “monitor adverse effects” was inspired by the structure of established drug-drug interaction databases, such as UpToDate Lexidrug, which typically provide a single recommended action for each interaction. It is worth noting that in certain clinical scenarios, multiple management strategies, such as dose adjustment and adverse effect monitoring, may both be appropriate. However, we prioritized recommendations involving active therapeutic changes (eg, dosage modification or medication substitution) over monitoring alone. This prioritization assumes that monitoring should naturally follow any therapeutic intervention, whereas recommending monitoring as the sole action may lead clinicians to overlook the need for proactive treatment adjustments. This complexity reflects real-world clinical decision-making, where nuanced judgment is often required. By clearly defining and prioritizing actionable strategies within our classification system, we aimed to enhance the clarity of both model training and output interpretation.

In this study, discrepancies in 44 guideline classifications between the 2 LLMs were used to identify cases warranting prioritized manual review. As described in Table S6 in Multimedia Appendix 1, an analysis of these inconsistencies reveals several recurring patterns. In some instances, treatment recommendations varied according to the patient’s metabolizer phenotype. In others, guidelines presented dual options, such as advising complete drug avoidance or, alternatively, recommending dose adjustment if use was deemed necessary. Certain guidelines did not offer explicit therapeutic recommendations but suggested monitoring for potential adverse effects. Dose adjustments were also frequently recommended for drugs with a narrow therapeutic index. Last, some discrepancies resulted from insufficient supporting evidence, leading to recommendations favoring alternative therapies. These patterns underscore the inherent complexity of guideline interpretation, particularly in contexts involving conditional recommendations or limited clinical data.

After verification, the manual review workload was reduced by 88.57%. A further examination of 341 consistent results from both LLMs revealed one (0.29%) discrepancy with human-labeled data, primarily due to a guideline prompting 2 different classification decisions for distinct genotypes, leading to inconsistent LLM responses. Many studies evaluating the capabilities of AI chatbots use a threshold of >60% as a benchmark for adequate knowledge and reasoning performance [22,23]. Notably, when applying an LLM agreement threshold of >60%, the manual review workload was reduced by 97.14% compared with human-reviewed guidelines. Among 374 guidelines, 2 (0.53%) showed discrepancies with human-labeled data. Interestingly, while the daunorubicin-SLC28A guideline recommends PGx testing for RARG rs2229774, SLC28A3 rs7853758, and UGT1A6*4 (rs17863783), it lacks specific treatment recommendations. Nonetheless, LLM responses suggested dose adjustments. Studies link hENT1 expression to increased Ara-C activity and altered drug metabolism, potentially affecting pharmacokinetics, though the evidence remains inconclusive [24]. Despite these inconsistencies, these errors likely do not compromise medical quality, as each classification partially aligns with guideline recommendations. Moreover, clinicians can review the original guideline recommendations if they have concerns about the classification summary. In deployment settings, guideline classifications with inconsistent outputs, either across repeated model runs or between models, would be automatically flagged and subjected to pharmacist validation before CDSS integration.

The challenge lies in the fact that even when the same prompts and models are used, slight randomness may lead to minor variations in the generated results [25]. Nevertheless, both LLMs demonstrated high accuracy and high reproducibility, suggesting that the observed discrepancies might merely reflect random fluctuations and that a majority-based approach considering the statistical distribution of outputs could be used. Simplifying text and classifying it did not compromise the quality of health information, as the LLM was explicitly directed to produce a particular output [26]. Further comparison revealed that both GPT-4o and Gemini performed well across the 3 major categories—no action needed, considered dosage modification, and changed medication—which together accounted for 97.7% of all samples. When considering class-specific metrics and class distribution, both models continued to demonstrate performance levels approaching that of expert pharmacists. In fact, these findings align with previous research, indicating that the quality of a model’s responses depends on the content of its input. A prior study showed that using an electronic health record–integrated generative AI chatbot to automatically draft responses to patient messages can streamline workflows and reduce burnout [27].

## Section: Discussion › Economic Estimation

We conducted a preliminary evaluation of cost and response time based on publicly available API pricing and average latency data. The economic estimation indicated that the total combined cost for running both LLMs was only US $0.76. This low cost is primarily attributable to the controlled volume of input and output tokens or characters. When managed appropriately, the combined use of both models demonstrates strong feasibility for real-world implementation, offering an excellent cost-performance balance. Both GPT-4o and Gemini 1.5-Pro operate through cloud-based APIs, with response times averaging between 2 and 4 seconds. The current results suggest that using repeated cross-comparisons and an agreement-threshold strategy can effectively narrow the scope of manual review. This approach may be a viable strategy and provides an important reference for the practical implementation of PGx CDSS in clinical settings.

## Section: Discussion › Limitations

This study has several limitations. First, the PGx guidelines we used were designed for personalized pharmacotherapy and may differ in structure or language from guidelines in other medical fields, potentially limiting generalizability. To mitigate this, we focused on clearly structured guideline recommendations and standardized the prompt format to ensure interpretability and consistency. Second, LLMs generate output based on probabilistic distributions, which can produce biased responses. However, repeated inputs and constrained target outputs can approximate the most likely distribution of responses. Third, determining the correct classification can be challenging. In some clinical scenarios, multiple management strategies, such as dose adjustment and adverse effect monitoring, may all be appropriate. However, we prioritized recommendations involving active therapeutic changes. Finally, we observed an inter-rater agreement of only 97.2% among human reviewers, highlighting the inherent heterogeneity in manual classification. Discrepancies were resolved through consensus discussion, ensuring a standardized reference for comparison with LLM-generated outputs. Future research should focus on how to automate further the integration of more complex and diverse clinical guideline updates into real-world clinical workflows.

## Section: Discussion › Conclusions

These results suggest that using 2 LLMs simultaneously can simplify PGx guidelines and generate classification outputs that enhance CDSS databases. However, manual review and cautious application remain necessary, as the models are not entirely infallible. Repeated cross-comparisons and an agreement-threshold strategy offer a promising approach for updating CDSS guidelines.

## Section: Acknowledgments

We would like to thank our participants and colleagues for generously dedicating their time to the classification of pharmacogenomic guidelines. This study would not have been possible without their contributions. Special thanks to Pharmacist Chih-Kang Lin (Department of Pharmacy, Cheng Ching Hospital, Taichung, Taiwan), Pharmacist Chih-Yun Liu (Department of Pharmacy, Asia University Hospital, Taichung, Taiwan), Pharmacist Ching-Jung Wu (Division of Traditional Chinese Medicine, Department of Pharmacy, China Medical University Hospital, Taichung, Taiwan), and Pharmacist Li-Hui Lee (Division of Clinical Pharmacy, Department of Pharmacy, China Medical University Hospital, Taichung, Taiwan). Their time and efforts were provided without compensation.


---

# Feature-Guided Machine Learning for Studying Passive Blood-Brain Barrier Permeability to Aid Drug Discovery

- **Authors:** Baining Zhu, Suwei Liu
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2025-11-20
- **Language:** en
- **DOI:** 10.3390/ijms262211228
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41303710/
- **Licence:** CC-BY

## Section: Abstract

AbstractEffective prediction of blood–brain barrier (BBB) permeability remains essential for central nervous system drug development. This study evaluates multiple supervised machine learning models using a public dataset of permeable and non-permeable compounds. Random Forest models demonstrate optimal balance between accuracy and generalizability, outperforming more complex gradient boosting methods that were prone to overfitting. Feature analysis identifies NH/OH and NO group counts as key determinants of passive diffusion, with reduced hydrogen bond donor and heteroatom counts enhancing permeability. Additionally, model performance deteriorates at NH/OH count = 3, establishing this as a decision boundary where hydrogen bonding complexity disrupts reliable prediction. This study shows the non-linear structure-permeability relationships that challenge traditional descriptor-based approaches, while demonstrating that machine learning can simultaneously provide both accurate prediction and applicable insights for drug discovery applications.Keywords: blood–brain barrier, machine learning, drug discovery, permeability prediction

## Section: 1. Introduction

The blood–brain barrier (BBB) plays a vital role in the central nervous system (CNS) by regulating the exchange of molecules between the bloodstream and neural tissue [1,2,3,4]. However, this protective function has a negative impact on developing therapeutics for neurological disorders such as Alzheimer’s disease, Parkinson’s disease, epilepsy, and brain cancers [5,6,7,8]. Failure to accurately predict BBB permeability has led to significant costs throughout the drug discovery procedures, as promising drug candidates are frequently abandoned late in clinical development. The ability to determine whether a compound can cross the BBB is therefore central to efficient drug discovery [9,10,11,12,13].

A range of experimental strategies has been developed to study BBB transport. In vivo animal models, in vitro cell culture systems, and receptor-mediated assays offer high biological fidelity and provide detailed insights into molecular pathways [14,15,16,17,18]. These approaches produce physiologically relevant data and proof-of-concept validation, but they remain slow, expensive, and difficult to scale up. More specifically, extrapolating results from a controlled lab environment to the complex human BBB is often uncertain, which limits large-scale or early-stage drug discovery [19,20,21].

To increase throughput, theoretical models have been developed to predict permeability using chemical descriptors. More specifically, these descriptors include quantitative structure–activity relationship (QSAR) analysis and features such as molecular weight, lipophilicity, and polar surface area, which are used to estimate transport potential [22,23,24,25,26,27,28,29,30,31]. These methods are computationally efficient and easy to interpret, allowing large compound libraries to be screened at low cost. However, traditional QSAR and linear regression approaches rely on linear additivity assumptions, where molecular features are assumed to contribute independently to permeability without synergistic or antagonistic interactions. This dependence on simplified feature–permeability relationships restricts their ability to capture the complex, non-linear interactions that determine BBB transport, such as threshold effects or compensatory mechanisms between lipophilicity and hydrogen bonding capacity [19,32,33,34].

At the molecular scale, simulation methods such as molecular dynamics (MD) have enabled atomistic views of drug–membrane interactions. MD can describe conformational changes, energetics, and transient membrane phenomena that are difficult to observe experimentally [35,36,37,38]. These studies offer a valuable understanding at the molecular level, but the heavy computational cost makes MD studies suitable for only a small number of molecules. For large compound libraries, MD is not yet a practical tool for permeability prediction [35,39]. Typical MD investigations are limited to small or moderately sized molecules (usually below 400 Da) with well-parameterized chemical groups, since accurate force-field parameterization and extensive sampling times (hundreds of nanoseconds) are required within explicit lipid bilayers [40,41]. Scaling such atomistic systems to thousands of compounds remains computationally prohibitive, as discussed in previous BBB simulation studies [42,43].

To solve the aforementioned bottlenecks, the machine learning (ML) method bridges the gap, combining both the scalability and the ability to learn nonlinear patterns in molecular features [44,45,46]. By training on experimental data, ML models can identify structural and physicochemical properties that correlate with BBB penetration and apply those rules to new compounds [47,48]. In this study, the publicly available Blood–Brain Barrier Penetration (BBBP) dataset from MoleculeNet [49] is used to evaluate the performance of different ML approaches. The dataset contains 1955 compounds annotated as permeable (BBB+) or non-permeable (BBB−), represented by 2048-bit Morgan fingerprints and 208 RDKit descriptors. The data are imbalanced, with 76% labeled BBB+ and 24% BBB−. The BBBP dataset includes a diverse collection of marketed and experimental molecules, including both CNS-targeted drugs and non-CNS agents with reported central side effects. Because permeability labels were derived from experimentally measured log BB values rather than pharmacological indication, the dataset reflects general physicochemical diversity rather than a therapeutic-class bias.

The goal of this study is to provide a comprehensive comparison of machine learning algorithms for predicting BBB permeability, with a focus on further interpretation of the ML performance results. A variety of supervised ML algorithms are examined, ranging from simple linear classifiers such as logistic regression to ensemble-based approaches including random forest and gradient boosting, as well as neural-network-based models. Multiple resampling methods, including Synthetic Minority Oversampling Technique (SMOTE) [50], Borderline SMOTE [51], and combined undersampling, are applied to address the imbalanced feature of the obtained dataset. This work demonstrates how accessible machine learning strategies can inform the rational design of CNS-active compounds and provide an efficient complement to experimental, theoretical and simulation-based approaches.

## Section: 2. Results and Discussions

Baseline performance of selected classifiers on the imbalanced BBBP dataset.

Performance comparison of Logistic Regression with different resampling techniques. The metrics shown represent single-run evaluations and therefore differ slightly from the cross-validated results presented in Table 1.

Performance comparison of Random Forest with different resampling techniques. The metrics shown represent single-run evaluations and therefore differ slightly from the cross-validated results presented in Table 1.

Top-ranked feature importance based on the Random Forest model.

Impact of –NH/OH group count on BBB permeability: (a) permeability rate, (b) distribution across permeable and non-permeable compounds, (c) model accuracy.

Skeletal formula of (a) propranolol (BBB permeable) and (b) ampicillin (BBB non-permeable) with –OH groups and –NH groups highlighted in yellow.

Impact of NO atom count on BBB permeability: (a) permeability rate, (b) distribution across permeable and non-permeable compounds, (c) model accuracy.

Skeletal formula of (a) dexamfetamine (BBB permeable) and (b) etoposide (BBB non-permeable) with O atoms and N atoms highlighted in yellow.

## Section: 2. Results and Discussions › 2.1. Base Model Comparison

The dataset used in this study comprises 1955 chemical compounds from the MoleculeNet BBBP dataset. After preprocessing to remove low-variance features (variance threshold of 0.14) and those with missing or infinite values, the dimensionality of the feature space is reduced to 743, which suggests these are the most informative molecular descriptors.

A major characteristic of the dataset is its class imbalance, where 1492 compounds (76.3%) are labeled as BBB+ while 463 (23.7%) are labeled as BBB−. This imbalance ratio of approximately 3:1 introduces bias risks, as classifiers may favor the majority class and inflate accuracy at the expense of minority class prediction. In drug discovery applications, such misclassification is problematic, particularly when false negatives lead to premature exclusion of promising candidates.

To establish baseline predictive performance, 11 machine learning models are trained and evaluated using stratified ten-fold cross-validation. Performance metrics include accuracy, precision, recall, F1-score, and runtime, as summarized in Table 1. The models represent diverse families, including linear models, ensemble methods, boosting frameworks, neural networks, decision trees, probabilistic classifiers, and simple baselines.

Across models, Logistic Regression and Random Forest achieve the best overall balance of precision and recall, with F1-scores of 0.925 and 0.924, respectively. Logistic Regression offers the highest precision (0.891), while Random Forest delivers the highest recall (0.978) and the lowest runtime (0.04 s), making both suitable candidates for large-scale screening applications. Gradient boosting frameworks such as XGBoost, Gradient Boosting, and LightGBM also perform competitively but do not exceed the simpler models in this task. Neural networks and boosting methods achieve strong recall but require greater computational cost and tuning effort. Simpler models such as Decision Tree, k-Nearest Neighbors, Gaussian Naive Bayes, or the dummy baseline show weaker performance, underscoring the value of ensemble and linear approaches in this context.

The advantage of Random Forest over Logistic Regression in terms of Recall performance, although seemingly subtle in the cross-validated results shown in Table 1, becomes more pronounced when examined on single validation splits (as detailed in Table 2 and Table 3). This difference reflects fundamental algorithmic characteristics: Random Forest’s ensemble of decision trees can model complex, non-linear decision boundaries that adapt to local data structure, enabling better identification of minority-class compounds (BBB−) and substantially reducing false negatives. In contrast, Logistic Regression relies on a single global linear boundary, making it more susceptible to missing minority-class cases in imbalanced datasets. On single-split evaluations, Random Forest achieves significantly higher recall (0.989 with only 5 false negatives) compared to Logistic Regression (0.938 with 28 false negatives), while both models maintain comparable false positive rates (around 10%). This demonstrates Random Forest’s superior ability to handle class imbalance and improve sensitivity without sacrificing specificity, a critical advantage in drug discovery applications where missing potentially permeable compounds can be costly. Based on this comparison, Logistic Regression and Random Forest are selected for further evaluation under resampling strategies to mitigate class imbalance and enhance predictive reliability.

Baseline performance of selected classifiers on the imbalanced BBBP dataset.

Performance comparison of Logistic Regression with different resampling techniques. The metrics shown represent single-run evaluations and therefore differ slightly from the cross-validated results presented in Table 1.

Performance comparison of Random Forest with different resampling techniques. The metrics shown represent single-run evaluations and therefore differ slightly from the cross-validated results presented in Table 1.

## Section: 2. Results and Discussions › 2.2. Impact of Resampling Techniques on Model Performance

The inherent class imbalance in the BBBP dataset presents a fundamental challenge for machine learning classifiers, as models tend to be biased toward the majority class, potentially compromising their ability to accurately identify blood–brain barrier permeable compounds. High recall values across most models indicate strong sensitivity to the positive class, but this often comes at the expense of precision, resulting in an increased rate of false positives. This trade-off is especially pronounced in ensemble methods such as AdaBoost and neural network architectures like MLP, which achieve strong recall but comparatively lower precision [52,53]. In drug discovery, where the costs of false positives and false negatives differ, this imbalance in predictive behavior must be carefully managed.

To address class imbalance, multiple resampling techniques are applied to the best two representative classifiers (Logistic Regression and Random Forest). These models allow evaluation of resampling effects across different algorithmic families, which include standard SMOTE, Borderline SMOTE, and an undersampling method, each designed to re-balance training data in distinct ways.

SMOTE generates synthetic minority class instances by interpolating between existing samples and their nearest neighbors, expanding the decision space of the minority class. Borderline SMOTE focuses on minority samples near the decision boundary, where misclassification risk is highest. The undersampling method reduces majority class instances while augmenting the minority class, producing balance through simultaneous contraction and expansion.

As shown in Table 2, Logistic Regression combined with SMOTE produces the strongest improvements, raising ROC AUC from 0.764 to 0.791 (+2.7%) and average precision from 0.873 to 0.887, while also improving true negative identification (82 to 93). This gain in precision is balanced by a slight drop in recall (0.938 to 0.913). Borderline SMOTE yields smaller improvements, while the combined method pushes precision slightly higher but reduces recall more substantially, showing a shift toward conservative predictions.

As documented in Table 3, Random Forest shows a stronger baseline performance and smaller changes under resampling. SMOTE slightly improves ROC AUC (+0.010) and precision, with minimal recall loss. The combined method produces the best precision (0.911) and the largest ROC AUC gain (+0.020) but lowers recall from 0.989 to 0.955, indicating a trade-off between sensitivity and specificity. Borderline SMOTE produces negligible changes.

Overall, both resampling techniques have shown improvement in terms of the prediction performance, with ROC and AUC consistently increasing across methods. Logistic Regression is more sensitive to resampling, showing larger precision–recall trade-offs, whereas Random Forest maintains stability with incremental gains. These results suggest that resampling is most useful for improving specificity and reducing false positives, which is particularly valuable in drug discovery pipelines where filtering out non-permeable compounds can save development costs and time. Subsequent analyses are based on the output from Random Forest combined with the undersampling technique.

## Section: 2. Results and Discussions › 2.3. Feature Ranking and Interpretation of Key Molecular Features

To enhance the interpretability of the machine learning models, feature importance scores are extracted from the Random Forest classifier. This analysis highlights a combination of physicochemical descriptors and Morgan fingerprint bits as the most influential factors for BBB permeability, as shown in Figure 1.

Among the top descriptors, NHOHCount is observed to serve as the most important indicator. This feature measures the total number of hydroxyl (–OH) or amine (–NH) groups in a molecule. Each group acts as a hydrogen bond donor, increasing polarity and strengthening interactions with water or polar residues in the BBB endothelium [54,55]. However, these same interactions reduce the molecule’s lipophilicity and hinder passive diffusion through the lipid-rich membrane. Molecules with fewer donors are more likely to partition into and cross the BBB.

The influence of –NH/OH groups is illustrated in Figure 2. More specifically, as shown in Figure 2a, molecules with 0–1 donors achieve permeability rates above 80%, while those with four or more drop below 20%. This sharp decrease highlights the negative effect of excessive hydrogen bonding on passive diffusion. Figure 2b further illustrates that permeable compounds concentrate at low NHOH counts (median ≈ 1), while non-permeable molecules exhibit a broader spread extending into higher counts. Figure 2c quantifies the prediction complexity introduced by donor content, where accuracy systematically decreases from 94.0% (0 donors) to 67.9% (3 donors), indicating that the permeability decision boundary becomes increasingly complex as NH/OH count approaches three. However, prediction accuracy recovers for compounds with 4+ donors, as these molecules exhibit predominantly non-permeable behavior, simplifying the classification task despite their chemical complexity. Clinically, this trend is consistent with some well-known drugs such as propranolol and ampicillin. More specifically, propranolol has 2 donors and it is BBB permeable [56,57], whereas ampicillin possesses 4 donors and is poorly permeable [58,59], as shown in Figure 3, respectively. These examples confirm that the presence of a hydrogen bond donor is a critical factor of BBB permeability and must be strategically optimized in CNS drug design.

The second most important feature is NOCount, which quantifies the total number of nitrogen and oxygen atoms in a molecule. These atoms often function as hydrogen bond acceptors and increase polarity. While necessary for solubility and target binding, an excess of heteroatoms typically reduces membrane permeability [60,61]. This finding is consistent with Lipinski’s Rule of Five [62], which claims that compounds with more than 10 hydrogen bond acceptors (N and O atoms combined) rarely achieve good oral bioavailability or CNS penetration.

Figure 4a shows that molecules with 0–2 NO atoms achieve nearly 100% permeability, whereas those with 4 or more fall below 85%. It is further illustrated in Figure 4b that permeable compounds cluster at lower NO counts, while non-permeable molecules extend across a much wider range, including very high counts. Lastly, the model accuracy is highest (96%) for compounds with low NO counts and declines progressively with increasing heteroatom numbers, as shown in Figure 4c. Clinically, dexamfetamine with 1 N atom, shown in Figure 5a, crosses the BBB efficiently [63], while etoposide with 13 O atoms, illustrated in Figure 5b is unable to penetrate [64]. These contrasting cases highlight how balancing polarity and lipophilicity is essential in designing CNS-active drugs.

Aside from these dominant descriptors, additional features also contribute to BBB permeability prediction. HeavyAtomMolWt, a measure of molecular size, shows high importance, consistent with the principle that smaller compounds more easily diffuse through the BBB. Several Morgan fingerprint bits (e.g., MFP_808, MFP_390) also rank highly, suggesting that particular structural motifs or substructures recur among BBB-permeable drugs. Although hashed and not directly interpretable, these fingerprints likely correspond to chemical scaffolds that enhance penetration, such as small lipophilic rings or heterocycles.

Overall, the prominence of hydrogen bond donor count (NHOHCount) and heteroatom count (NOCount) confirms that polarity is the primary barrier to BBB penetration. By linking ML model-derived features to established pharmacological heuristics and real drug examples, these findings demonstrate that machine learning models capture biologically meaningful determinants of CNS drug delivery, rather than operating as black-box predictors.

Top-ranked feature importance based on the Random Forest model.

Impact of –NH/OH group count on BBB permeability: (a) permeability rate, (b) distribution across permeable and non-permeable compounds, (c) model accuracy.

Skeletal formula of (a) propranolol (BBB permeable) and (b) ampicillin (BBB non-permeable) with –OH groups and –NH groups highlighted in yellow.

Impact of NO atom count on BBB permeability: (a) permeability rate, (b) distribution across permeable and non-permeable compounds, (c) model accuracy.

Skeletal formula of (a) dexamfetamine (BBB permeable) and (b) etoposide (BBB non-permeable) with O atoms and N atoms highlighted in yellow.

## Section: 3. Methods

Workflow of the machine learning pipeline for BBB permeability prediction.

## Section: 3. Methods › 3.1. Dataset Description and Molecular Representations

The BBBP dataset consists of 1955 unique molecules, each represented by its SMILES string, compound name, and corresponding logBB value. A threshold of logBB=−1 is applied to categorize molecules into BBB+ (permeable) and BBB− (impermeable), consistent with prior pharmacokinetic studies [24,26]. After preliminary permeability classification, the dataset contains 1492 BBB+ and 463 BBB− compounds, which confirms that the dataset is highly imbalanced. To mitigate class imbalance, SMOTE is applied exclusively within the training folds to avoid data leakage. Additional preprocessing includes removal of duplicate entries, standardization of molecular representations, and normalization of descriptor values. Compounds in the BBBP dataset are annotated by experimental BBB penetration data and are not restricted to CNS-active therapeutics, ensuring representative physicochemical diversity.

In addition to permeability information, molecular structures are encoded into numerical features using multiple complementary representations designed to capture both substructural and physicochemical properties. MACCS keys serve as 166-bit binary fingerprints, indicating the presence or absence of predefined structural fragments such as hydroxyl groups and aromatic rings. To capture more flexible substructural information, Morgan fingerprints are generated, encoding circular neighborhoods around each atom, as computed using the RDKit cheminformatics toolkit [65]. In addition to these fragment-based encodings, 208 physicochemical descriptors are calculated with RDKit, including properties such as molecular weight, lipophilicity (logP), topological polar surface area (TPSA), and counts of hydrogen bond donors and acceptors. Topological descriptors are also included to provide higher-order information on connectivity indices, ring systems, and molecular shape. All continuous-valued descriptors are standardized to zero mean and unit variance prior to model training to ensure comparability across features. These diverse representations provide a comprehensive feature set for evaluating machine learning models in BBB permeability prediction. Note that the descriptors are calculated using the dominant protonation state at physiological pH (≈7.4) [66]. As a result, the current models therefore do not explicitly consider multiple ionization states. Nevertheless, combining with machine learning, the dataset is capable of providing general guidance on BBB permeability given its wide range of properties examined.

## Section: 3. Methods › 3.2. Feature Engineering, Preprocessing, Model Training and Evaluation

The overall workflow of the study is illustrated in Figure 6. Starting from the MoleculeNet BBBP dataset, raw molecular structures are transformed into numerical representations through feature engineering. This step includes encoding compounds as molecular fingerprints and physicochemical descriptors, hence capturing both substructural patterns and global molecular properties. The resulting feature matrix is then split into training and test sets, with stratification to maintain the proportion of BBB+ and BBB− classes.

To reduce redundancy and improve interpretability, feature selection is applied using feature importance scores derived from 11 different classifiers, which are further discussed in Section 2.1. Features with low variance below 0.14 threshold are excluded, thereby mitigating noise and lowering the risk of overfitting. Preprocessing of the training set involves normalization of continuous-valued features to zero mean and unit variance, as well as the application of resampling techniques to address class imbalance. In particular, oversampling methods such as SMOTE and its variants are explored to synthetically generate minority class samples, while undersampling approaches are used to further balance class representation.

Model training is conducted using a diverse range of supervised learning algorithms, each chosen to represent distinct modeling features. Logistic Regression serves as a simple yet interpretable linear baseline. Random Forest, a tree-based ensemble method, is included for its robustness to overfitting and its ability to quantify feature importance. Support Vector Machines (SVM) with both linear and radial basis function (RBF) kernels are tested for their capacity to model complex, high-dimensional decision boundaries. Gradient boosting frameworks, including XGBoost and LightGBM, are selected for their strong track record of predictive accuracy on structured data. In addition, k-Nearest Neighbors (k-NN) is evaluated as a non-parametric method relying on local molecular similarity. Model performance is evaluated through stratified ten-fold cross-validation to ensure consistent class distributions across different sampling sets.

Reliable evaluation metrics are essential in the context of BBB permeability prediction. For example, the relative consequences of false positives and false negatives differ significantly. Metrics used to evaluate the performance of the models are explained as follows. Accuracy provides an overall measure of correctness but can be misleading under class imbalance, which is the scenario of the dataset used in this study. Precision quantifies how many predicted BBB+ molecules are truly permeable, helping to minimize wasted resources on false positives. Recall or sensitivity emphasizes the correct identification of permeable molecules, reducing the risk of prematurely missing potential drug candidates. The F1-score is the harmonic mean of precision and recall, which provides a balanced assessment considering both error types.

Workflow of the machine learning pipeline for BBB permeability prediction.

## Section: 3. Methods › 3.3. Model Evaluation and Interpretation

Model performance is evaluated to capture both overall accuracy and class-specific trade-offs. In particular, accuracy, precision, recall, and F1-score are computed to assess predictive balance across BBB+ and BBB− compounds. Receiver operating characteristic (ROC) curves and the corresponding area under the curve (AUC) values quantify discriminative power, while average precision scores provide an additional summary of performance under class imbalance. To ensure robust prediction, all metrics are reported as averages across stratified ten-fold cross-validation.

To address the class imbalance present in the dataset, resampling techniques such as SMOTE, Borderline-SMOTE, and undersampling are applied prior to model training. Their impact on predictive performance is evaluated by comparing classification outcomes, including true positives, true negatives, false positives, and false negatives. This enables quantitative assessment of the trade-offs between precision and recall under different sampling strategies.

Beyond the aforementioned performance metrics, interpretability and visualization are discussed to provide chemical and biological insights into model predictions. Feature importance scores derived from the ideal ML model are used to identify the most influential descriptors. These evaluation and interpretation procedures not only benchmark model predictive power but also connect statistical performance to biologically meaningful features, offering a practical bridge between cheminformatics and drug discovery applications.

## Section: 4. Conclusions

In this study, supervised ML models are evaluated for predicting BBB permeability using ten-fold cross-validation and resampling strategies to address class imbalance. Unlike prior work that emphasizes predictive accuracy alone, this study establishes a feature-guided interpretability framework that links model performance directly to actionable design principles for CNS drug discovery. Random Forest models achieve high F1-scores with lower computational cost than more complex gradient boosting approaches, demonstrating that algorithmic simplicity combined with transparent descriptor analysis can offer superior practical utility.

The feature analysis identifies hydrogen bond donor count (NHOHCount) and heteroatom count (NOCount) as dominant predictors, revealing clear non-linear permeability trends. It is clear that molecules with 0–1 NH/OH donors show >80% permeability, while those with four or more donors show reduced penetration. A critical decision boundary at NH/OH = 3 is identified, corresponding to a pharmacokinetic “gray zone” where predictive performance drops sharply, suggesting a structural threshold where compensatory physicochemical mechanisms become dominant. These findings provide experimentally relevant guidelines, supported by clinically established examples such as propranolol (BBB+) and ampicillin (BBB−).

From a cheminformatics perspective, NHOHCount and NOCount capture polarity, solubility, and hydrogen bonding capacity—properties that directly shape passive transcellular diffusion across the BBB. The models successfully quantify the relative importance of these features and recapitulate established pharmacological heuristics such as Lipinski’s Rule of Five, reinforcing that model predictions remain consistent with known biochemical principles rather than purely statistical correlations.

An important practical consideration is the applicability domain (AD) of these models. While stratified cross-validation indicates robust internal performance, generalization to novel chemotypes may vary. Future work could incorporate molecular similarity metrics (e.g., Tanimoto coefficient) and ensemble-based uncertainty estimates to identify predictions made outside the chemical space represented in training data. External validation on scaffold-split datasets or newly synthesized compounds will further strengthen confidence in model generalizability. Moreover, this study focuses on physicochemical descriptors associated with passive diffusion, and active transporter mechanisms such as P-glycoprotein and BCRP are not modeled. As a result, the predictions are most applicable to compounds that permeate primarily via passive mechanisms. Additionally, ionization states are not explicitly represented; incorporating pH-dependent features such as logD may further refine future predictions. Additional work includes expanding the training dataset to incorporate broader chemical diversity, exploring advanced molecular representations such as graph neural networks, and integrating predictive modeling with generative design workflows. These developments are expected to enhance both the predictive accuracy and real-world applicability of computational pipelines for BBB permeability and support more effective CNS drug discovery.

## Section: Acknowledgments

Baining Zhu would like to thank Lizette Li for her valuable guidance and insights throughout the development of this project.

## Section: Abbreviations

The following abbreviations are used in this manuscript:

## Section: Author Contributions

Conceptualization, B.Z. and S.L.; methodology, B.Z. and S.L.; analysis, B.Z. and S.L.; writing—original draft preparation, B.Z. and S.L.; writing—review and editing, S.L.; visualization, B.Z. and S.L.; supervision, S.L. All authors have read and agreed to the published version of the manuscript.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

Processed results will be available for at least 2 years after publication upon written request to the author.

## Section: Conflicts of Interest

The authors declare no conflicts of interest.

## Section: Funding Statement

This research received no external funding.

## Section: Associated Data › Data Availability Statement

Processed results will be available for at least 2 years after publication upon written request to the author.


---

# First 4D-QSAR Study of Human Kynurenine 3 Monooxygenase (hKMO) Inhibitors: Integrating Chemical Space Networks and an Explainable Artificial Intelligence Platform for Neurodegenerative Disease Drug Discovery

- **Authors:** Sk Abdul Amin, Joao Pedro Gallo Almeida Do Val, João Paulo Ataide Martins, Stefano Piotto
- **Issuer:** ACS omega
- **Type:** Scientific article
- **Published:** 2025-08-29
- **Language:** en
- **DOI:** 10.1021/acsomega.5c03404
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40949262/
- **Licence:** CC-BY

## Section: Abstract

AbstractHuman kynurenine 3-monooxygenase (hKMO) is a crucial enzyme in the kynurenine pathway (KP), which increases neurotoxicity by converting kynurenine into 3-hydroxykynurenine and quinolinic acid (QA)both linked to oxidative stress and neuronal damage. KMO activity also reduces the neuroprotective metabolite kynurenic acid (KYNA), worsening disease progression. Inhibiting KMO counters these harmful effects since it restores KYNA levels, prevents toxic metabolite production, and reduces oxidative stress. This dual action makes KMO a vital therapeutic target in conditions such as neurodegenerative diseases, psychiatric disorders, acute pancreatitis, and immune dysregulation. In contemporary drug discovery, in silico design strategies offer significant advantages by revealing essential structural insights for lead optimization. The study is guided by three main objectives: (i) the development of a supervised machine learning (ML) model for a data set of hKMOis, (ii) chemical space networks (CSNs) analysis, and (iii) LQTA-QSAR (3D and 4D-QSAR) studies to generate interaction energy descriptors of Lennard-Jones (LJ) and Coulomb (C). To enhance accessibility, we present “phKMOi_v1.0,” a Streamlit-based web application accessible at https://phkmoiv1.streamlit.app/. This platform not only supports the prediction but also allows experts and nonexperts to interpret the key molecular features influencing KMO inhibitory activity through an interactive waterfall plot. These modeling analyses will assist medicinal chemists in designing more potent hKMOis in the future.

## Section: Introduction

Proteins and neurotransmitters, including melatonin and serotonin, are synthesized from the essential amino acid tryptophan. The kynurenine pathway (KP) metabolizes the majority of dietary tryptophan to produce nicotinamide adenine dinucleotide (NAD+), a critical energy cofactor. Two significant branches of the KP (Figure ) are involved in synthesizing kynurenic acid (KYNA) and the neurotoxic quinolinic acid (QA). −

Quinolinic acid (also known as QUIN), a neurotoxic NMDA (N-methyl-d-aspartate) receptor agonist, and kynurenic acid (KYNA), an NMDA receptor antagonist with neuroprotective properties, are both implicated in depression. , The neurotoxicity of QA contributes to inflammation-induced neuronal and glial damage, accelerates neuronal death, reduces neuroplasticity, and induces depressive symptoms. Enzymes, namely kynurenine aminotransferase (KAT) and kynurenine 3-monooxygenase (KMO), utilize kynurenine (KYN) as a substrate in this pathway. − ,− By converting kynurenine into the neurotoxic metabolites 3-hydroxykynurenine (3-HK) and QA, KMO decreases the concentration of the neuroprotective metabolite KYNA while increasing levels of harmful metabolites and free radicals in the bloodstream. Numerous studies have associated KMO with brain and neurological diseases (Figure ) such as Alzheimer’s disease, neuropathic pain, schizophrenia, ,, Parkinson’s disease, and Huntington’s disease. ,, Therefore, KMO represents a promising drug target for addressing neurodegenerative disorders.

The first crystal structure of human KMO (hKMO) was published in 2018; however, it is in an autoinhibited conformation (PDB: 5X68, https://www.rcsb.org/structure/5X68). Consequently, it is not the best choice to use for structure-based drug design (SBDD) purposes. While the X-ray crystal structure of hKMO remains unavailable, ligand-based drug design (LBDD) provides valuable insights into uncovering critical structural features for lead optimization. This study has three primary objectives, as shown in Figure .

The main focus of the 2D-QSAR ML study is to provide valuable insights into the SARs of hKMOis using physicochemical descriptors, followed by the introduction of a Python-based web application named “phKMOi_v1.0” (available at https://phkmoiv1.streamlit.app/). This user-friendly platform not only enables the prediction of hKMO inhibitory activity but also allows both experts and nonexperts to interpret key molecular features through an interactive waterfall plot. In addition, the key advantage of 3D and 4D-QSAR models is their enhanced interpretability. These models can capture spatial features influenced by conformational flexibility, providing insights into their role in biological activities targeting hKMO. To the best of our knowledge, this is the first 4D-QSAR study addressing a neurological endpoint of hKMO inhibitory activity that integrates supervised ML models, an explainable artificial intelligence (XAI) platform, and CSNs.

Graphical representation of the Kynurenine pathway. Kynurenine 3-monooxygenase (KMO) increases neurotoxicity by converting kynurenine into 3-hydroxykynurenine (3-HK) and quinolinic acid (QA)both linked to oxidative stress and neuronal damage. KMO activity also reduces the neuroprotective kynurenic acid (KYNA). This dual action makes KMO a vital therapeutic target in several disease conditions (as depicted in cyan boxes).

An overview of the study design. This study is an initiative to relate the structural requirements of hKMOis by supervised machine learning (ML) models, chemical space networks (CSNs), and Laboratório de Quimiometria Teórica e Aplicada (LQTA)-quantitative structure–activity relationship (QSAR) studies.

## Section: Materials and Methods › Data Preparation

Biological activity data for hKMOis were sourced from the ChEMBL database, comprising small molecules with KMO inhibitory activities (IC50 values). After removing duplicates, entries lacking IC50 values, compounds with ranged values, and compounds without simplified molecular input line entry system (SMILES) annotations, the data set was refined to 137 hKMOis (Table S1).

## Section: Materials and Methods › Calculation of Pearson Correlation Coefficients

Each SMILES string was first parsed into an RDKit “Mol” object, followed by the calculation of eight physicochemical and topological descriptors using the “RDKit” (https://www.rdkit.org/) cheminformatics toolkit (version rdkit-pypi-2022.9.5). The physicochemical and topological descriptors were the octanol–water partition coefficient (Log P), molecular weight (MW), total number of ring systems in the molecule (nRings), number of aromatic rings (nAR), hydrogen bond acceptors (HBAs), hydrogen bond donors (HBDs), number of rotatable bonds (nRBs), and topological polar surface area (TPSA). The Pearson correlation coefficient was then computed to assess the linear relationships between these molecular descriptors and the biological activity (pIC 50) of the hKMOis. Meanwhile, the Python scripts (File name: Suppplementary_NoteBook_KMO_Data set.ipynb) to calculate the Pearson correlation coefficients and other calculations are provided at https://github.com/Amincheminform/phKMOi_v1.

## Section: Materials and Methods › Machine Learning (ML) Study › Data Set Division and Principal Component Analysis (PCA) Procedure

hKMOis with pIC 50 < 7.6 were assigned as “inactives” (0), and compounds with pIC 50 ≥ 7.6 were assigned as “actives” (1). After applying this cutoff, the data set contained 72 “actives” and 65 “inactives”. At first, the data set was randomly divided into training and test hKMOis (N Test = 28). Then, circular fingerprints, specifically extended connectivity fingerprints with a radius of 2 and 2048 bits (EFCP_4), were computed for all hKMOis, followed by similarity analysis. Principal component analysis (PCA) was applied to reduce the high-dimensional similarity matrix to two dimensions. Subsequently, k-means clustering analysis (k-MCA) was conducted to identify chemical space groupings (k = 5, random seed = 42 to ensure reproducibility). Finally, a 2D PCA plot was generated to visualize these clusters and assess the distribution of training and test set compounds.

## Section: Materials and Methods › Machine Learning (ML) Study › Calculation of Features

Descriptors were calculated by using “Fiore_v1.0” platform, in particular the Fiore_FC (Feature Calculation) tool (https://github.com/Amincheminfom/Fiore_v1.0). This Fiore_FC tool used a molecular descriptor calculator named “Mordred” to calculate independent parameters (https://github.com/mordred-descriptor/mordred).

## Section: Materials and Methods › Machine Learning (ML) Study › Data Pretreatment and Feature Selection

The descriptors with non-numeric properties, missing values, and quasi-constant values were eliminated from the study as described earlier. Feature selection is a vital step in machine learning (ML) that enhances model performance. Initially, columns containing non-numeric values and constant columns are removed to eliminate noise and reduce dimensionality. To further refine the data set, measures such as information gain or mutual information are applied to identify the most relevant features for predicting the hKMO inhibitory activity. Only features with high mutual information scores are retained. Finally, features with importance scores greater than 0.120 are selected, optimizing accuracy while minimizing computational costs.

## Section: Materials and Methods › Machine Learning (ML) Study › Hyperparameter Tuning, Model Development, and Validation

Random Forest (RF), a supervised machine learning approach, is one of the most popular and versatile ML algorithms. Here, the hyperparameters of the RF classifier (RFC) for hKMOis were optimized by using Optuna (https://optuna.org/). The following hyperparameters were optimized within these ranges: (a) n_estimators: 10 to 100 (number of trees in the forest), (b) max_depth: 2 to 32 (maximum depth of each tree), (c) min_samples_split: 2 to 16 (minimum number of samples required to split an internal node), and (d) min_samples_leaf: 1 to 16 (minimum number of samples that a leaf node must have). The models were developed by “scikit-learn” (https://scikit-learn.org/stable/) package in Python language and were validated. Importantly, a 5-fold cross-validation strategy was employed during model training to ensure robustness and generalizability. This is a very common approach in the ML field. In this approach, the data set of hKMOis was partitioned into five equal subsets, and the RF classifier model was iteratively trained on four hKMOis subsets while being validated on the remaining hKMOis subset. This process was repeated five times, with each subset used exactly once as the validation set. The average performance across all folds was reported using the statistical metrics discussed earlier.

## Section: Materials and Methods › Machine Learning (ML) Study › Applicability Domain Calculation and Analysis

Applicability domain (AD) analysis was performed using the leverage method to assess the reliability and generalizability of the developed RF model. First, the csv files of training and test data sets were taken, each containing selected descriptors. Then, training and test set descriptor matrices were concatenated to compute the leverage values for each hKMOi. The hKMOis with leverage values below this threshold were considered within the AD, while those exceeding the threshold were regarded as “outliers”. For better understanding, the leverage values for training and test compounds were visualized by using a scatter plot. The Python scripts to perform the applicability domain calculation and analysis are available at https://github.com/Amincheminfom/ML-study-of-non-hydroxamate-HDAC3i/blob/main/HDAC3_966_Optuna_En_v0.ipynb.

## Section: Materials and Methods › Machine Learning (ML) Study › Generation of Partial Dependence Plots

Partial dependence plots (PDPs) help to understand the influence of individual molecular descriptors on classification outcomes. In this study, PDPs were generated for important features by using PartialDependenceDisplay from “scikit-learn” (https://scikit-learn.org/stable/modules/generated/sklearn.inspection.PartialDependenceDisplay.html), with a grid resolution of 50 points per feature. Each partial dependence plot enables visualization of nonlinear relationships between the descriptor values and predicted activity probability. In addition, PDPs illustrate the marginal effect of a single feature on the predicted outcome by averaging over the values of all other features. The details are provided in Suppplementary_NoteBook_KMO_Data set (https://github.com/Amincheminform/phKMOi_v1).

## Section: Materials and Methods › Machine Learning (ML) Study › SHAP (SHapley Additive explanations) Plot

Further, SHAP (shapley additive explanations, https://shap.readthedocs.io/en/latest/) analysis was performed to gain more insights into the contribution of individual descriptors toward the classification outcomes of the trained supervised machine learning model for hKMOis. SHAP values were computed using the TreeExplainer class from the “shap” Python library (https://shap.readthedocs.io/en/latest/ generated/shap.TreeExplainer.html). A SHAP summary plot (also known as a beeswarm plot) was generated to visualize the global importance and distribution of feature effects across all training set hKMOis. This visualization helps us to find the most consistent descriptors that influence the decisions of the RFC model toward either class. Our Python scripts (File name: Suppplementary_NoteBook_KMO_Data set) to generate the beeswarm plot are available at https://github.com/Amincheminform/phKMOi_v1.

## Section: Materials and Methods › Chemical Space Networks

The relationships between the investigated hKMOis were explored through network analysis using “NetworkX” (https://networkx.org/) and “RDKit” (https://www.rdkit.org/) packages. Clusters were formed by using the greedy modularity community detection algorithm in “NetworkX”. In the CSNs, each node represents an hKMOi, while edges between nodes indicate structural similarity calculated using RDKit topological fingerprints (https://www.rdkit.org/ docs/GettingStartedInPython.html). The similarity between hKMOis was measured using the Tanimoto coefficient (Tc).

## Section: Materials and Methods › LQTA-QSAR (3D and 4D-QSAR) Studies

A homogeneous subset of hKMOis was considered for LQTA-QSAR studies. The selected molecules were placed in a table with their respective SMILES and the negative logarithm of hKMO inhibitory activity (pIC 50) for the first data treatment. Then, an in-house program (previously developed with the Python language (https://www.python.org/), the Open Babel package, and the program XTB (https://github.com/grimme-lab/xtb)) was used to convert the SMILES into 3D geometries, followed by semiempirical optimizations. After the optimization using the DFTB method (https://dftb.org/index.html), these molecules were optimized using Ab Initio methods, first with Hartree–Fock using the 6–31G** basis set and then with density functional theory (DFT) using the functional B3LYP and the cc-pVTZ basis set. These optimizations were carried out using a custom Python program built using the Psi4 library. Subsequent to the optimization phase, the LQTA-QSAR package was used. The 3D descriptors were calculated by using the optimized geometries obtained from DFT calculations aligned to the most active compound (K001). Likewise, the 4D descriptors were calculated from the conformational ensemble profile obtained from molecular dynamics (MD) simulations carried out according to the LQTA-QSAR methodology. With both sets of 3D and 4D descriptors, the QSARModeling package was used to build 3D and 4D QSAR models, respectively. Finally, the detailed descriptions and interpretations − of the QSAR models were performed to enhance the understanding of the SARs of hKMOis.

## Section: Results and Discussion

(A) The heatmap of Pearson correlation coefficients between pairs of features (data set: hKMOis). The bubble sizes correspond to the absolute values of the correlation coefficients, where larger bubbles represent stronger correlations. (B) Bin plots of Log P, MW, TPSA, and pIC 50 features.

(A) Optimization history plot of the hyperparameter optimization process for finding the optimal values (1000 runs). (B) Slice plot of specific hyperparameters, namely max_depth, min_samples_leaf, min_samples_split, n_estimators. (C) Plot of the applicability domain (AD) for hKMOis.

Partial dependence plot (PDP) of (A) AXp-6d, (B) BCUTd-1l, (C) AATS5p, and (D) SMR_VSA7. The x-axis represents the range of descriptor values observed in the training data. (E) Two-variable PDP of chemical descriptors AXp-6d vs SMR_VSA7.

(A) Summary plot of SHAP values for each descriptor of the training set. (B) Waterfall plots of the most active molecule from this investigated data set.

Interface of the “phKMOi_v1.0” tool. The visualization of 2D structures and the SHAP waterfall plots of the query molecule, the most similar molecule from the data set with respect to the query molecule, and the most active molecule from the data set.

A spring layout CSN component of 4 clusters (denoted as subgraphs 1, 2, 4, and 12) of hKMOis. Molecule ID is also highlighted for better understanding. The color of the nodes represents the pIC 50 values (as per the color map) of the hKMOis, and the line style in the network graph is dependent on the Tc-based similarity value. Thick lines for excellent similarity (Tc ≥ 0.9); medium lines for high similarity (0.7 < Tc < 0.9); thin lines for moderate similarity (Tc ≤ 0.7).

Most active K001 (A) and poorly active K124 (B) compounds with selected descriptors (as per the 3D-QSAR model) around them. Yellow: Lennard-Jones descriptor with a positive regression coefficient; magenta: Lennard-Jones descriptor with a negative regression coefficient; cyan: Coulomb descriptor with a positive coefficient; orange: Coulomb descriptor with a negative coefficient.

Compounds K001 (A) and K124 (B) with selected descriptors (as per the 4D-QSAR model) around the conformational ensemble profile (CEP) of each ligand. Yellow: Lennard-Jones descriptor with a positive regression coefficient; Magenta: Lennard-Jones descriptor with a negative regression coefficient; cyan: Coulomb descriptor with a positive coefficient; orange: Coulomb descriptor with a negative coefficient.

Key structural requirements of investigated derivatives for better hKMO inhibitory activity.

## Section: Results and Discussion › Data Set

The investigated hKMOis were obtained from the ChEMBL database, followed by a refinement process (as described in Section ), resulting in a final data set (Table S1). From the heatmap in Figure A, negative correlations are observed between molecular weight (MW) and pIC 50, number of hydrogen bond acceptors (HBAs) and pIC 50, number of hydrogen bond donors (HBDs) and pIC 50, number of rotatable bonds (nRBs) and pIC 50, topological polar surface area (TPSA) and pIC 50 (Figure A). In contrast, positive correlations are observed between lipophilicity (Log P) and pIC 50, number of aromatic rings (nARs) and pIC 50, and number of rings (nRings) and pIC 50.

The Pearson correlation coefficient (r) value of Log P and pIC 50 is 0.29, indicating that molecules with lipophilic characteristics are moderate to good hKMOis. The mean Log P value across all data set molecules is 2.901 (Figure B), suggesting most molecules are moderately lipophilic. The highest and lowest Log P values are found to be 4.687 and 0.579, respectively, indicating the most lipophilic and most hydrophilic hKMOis, respectively, in the data set. The average MW (310.145) of molecules indicates that most of the molecules are small to medium-sized. The mean TPSA value across all hKMOis is 75.920. On average, molecules have two aromatic rings and two or three rings. Notably, hKMOis have around four rotatable bonds, indicating moderate to lower flexibility.

(A) The heatmap of Pearson correlation coefficients between pairs of features (data set: hKMOis). The bubble sizes correspond to the absolute values of the correlation coefficients, where larger bubbles represent stronger correlations. (B) Bin plots of Log P, MW, TPSA, and pIC 50 features.

## Section: Results and Discussion › Machine Learning (ML) Study

hKMOis with pIC 50 < 7.6 were assigned as “inactives” (0), and compounds with pIC 50 ≥ 7.6 were assigned as “actives” (1). The PCA scatter plot is depicted in Figure S1A. hKMOis belonging to the training and test sets were marked by using red and blue markers, respectively, to highlight their distribution across chemical space. This visualization confirmed that the training and test compounds were well distributed across the different chemical clusters, indicating that the random splitting preserved the overall diversity of the data set.

(A) Optimization history plot of the hyperparameter optimization process for finding the optimal values (1000 runs). (B) Slice plot of specific hyperparameters, namely max_depth, min_samples_leaf, min_samples_split, n_estimators. (C) Plot of the applicability domain (AD) for hKMOis.

Partial dependence plot (PDP) of (A) AXp-6d, (B) BCUTd-1l, (C) AATS5p, and (D) SMR_VSA7. The x-axis represents the range of descriptor values observed in the training data. (E) Two-variable PDP of chemical descriptors AXp-6d vs SMR_VSA7.

(A) Summary plot of SHAP values for each descriptor of the training set. (B) Waterfall plots of the most active molecule from this investigated data set.

## Section: Results and Discussion › Machine Learning (ML) Study › Descriptors

Descriptors were calculated by using “Fiore_v1.0” platform, in particular the Fiore_FC (Feature Calculation) tool (https://github.com/Amincheminfom/Fiore_v1.0). Then, the descriptors with non-numeric properties, missing values, and quasi-constant values were eliminated from the study, as described earlier. From an initial set of 1614 descriptors, 37 descriptors with importance scores exceeding 0.120 were chosen. Finally, 8 descriptors (MDEC-33, AXp-6d, BCUTd-1l, SMR_VSA7, Xch-7d, Xch-6d, AATS0d, and AATS5p) were selected for ML studies based on their feature importance values.

## Section: Results and Discussion › Machine Learning (ML) Study › Results of the Random Forest (RF) Model

The hyperparameters of the RF model were optimized using Optuna. The model tuning led to the selection of the best hyperparameters (n_estimators: 18, max_depth: 7, min_samples_split: 4, min_samples_leaf: 1), which optimize the performance of the RF model (Figure ). The n_estimators parameter was found to be 18, which means that 18 trees were determined to be optimal. A larger number of trees usually improves the performance and stability of the model but also increases the computational cost (Figure A).

A depth of seven indicates that each tree can grow to seven levels (Figure B). Altogether, it can be stipulated that the selected hyperparameters optimize the predictability of the RF model while avoiding overfitting. This model correctly classified 89.29% of the instances (precision of 87.50%, recall of 93.33%, and F1 score of 90.32%, as depicted in Table ) in the validation data set, indicating its ability to capture generalizable patterns.

Notably, the recall remains consistently high across cross-validation, training, and test sets, which is particularly important when the objective is to accurately identify “actives” hKMOis for early-stage drug discovery. The receiver operating characteristic (ROC) plot of the test set (area under the curve, AUC: 0.9077) is given in Figure S1B. In addition, three ensembles of train and test sets have also been considered to build new RF models. The results are found to be comparable with the original model, suggesting the robustness of the developed RF model.

The feature importance plot of the selected descriptors is shown in Figure S1C. MDEC-33 is a molecular distance edge (MDE) descriptor related to the MDE between all tertiary carbons. The descriptor, AXp-6d, belongs to the atom-type electrotopological state (E-State) index family. It represents atomic contributions to the molecular properties and topology of hKMOis. A BCUT (Burden-CAS-University of Texas) descriptor, BCUTd-1l, evaluates molecular properties such as size, shape, and electronic distribution, focusing on low eigenvalues. SMR_VSA7 is a surface area descriptor weighted by molar refractivity (SMR). Moreover, Xch-7d and Xch-6d are molecular connectivity chi indices descriptors. These are used to capture aspects of the molecular topology and branching. A descriptor from the average atom-type electrotopological state (AATS) series, AATS0d, represents an average of electrotopological state values for atoms in the molecule. AATS 5p (Average Broto-Moreau autocorrelationlag 5/weighted by polarizabilities) is similar to AATS0d but considers the average atom-type values with specific weighting (e.g., polarizabilities).

LBDD has seen significant advances in recent years, particularly with the integration of perturbation-theory machine learning (PTML) modeling, enabling simultaneous prediction of biological activity against multiple targets. Notably, PTML has been successfully applied to the design of novel chemotypes, including multitarget inhibitors for GSK3B/HDAC1/HDAC6 (Alzheimer’s disease) and SERT/NET (mood disorders). While our present statistically validated ML model focuses on single-target prediction of hKMOis, it complements the PTML paradigm by offering a transparent, interpretable, and easily accessible platform that supports the early-stage consideration of the scaffolds targeting hKMO.

(A) Optimization history plot of the hyperparameter optimization process for finding the optimal values (1000 runs). (B) Slice plot of specific hyperparameters, namely max_depth, min_samples_leaf, min_samples_split, n_estimators. (C) Plot of the applicability domain (AD) for hKMOis.

## Section: Results and Discussion › Machine Learning (ML) Study › Applicability Domain (AD) Analysis

Here, the leverage approach (number of descriptors = 8, number of training sets = 109) was used to identify X-outliers within the training set and to detect molecules outside the AD when applied to the test set. The results indicate that all of the test set hKMOis are within the range of AD [compounds within the applicability domain (test) = 28]. Hence, no outlier [compounds outside the applicability domain (test) = 0] is found in the test set compounds (threshold value of 0.220). Notably, only two hKMOis (Figure C) in the training set are found to be outliers: K067, leverage value: 0.258, and K068, leverage value: 0.258.

## Section: Results and Discussion › Machine Learning (ML) Study › Partial Dependence Plots

Partial dependence plots (PDPs) for the top four molecular descriptors used in the RF classifier are depicted in Figure . Each plot in Figure illustrates the marginal effect of single features such as (A) AXp-6d, (B) BCUTd-1l, (C) AATS5p, and (D) SMR_VSA7 on the predicted probability of an hKMOi being classified as “actives”, while averaging out the effects of other descriptors.

AXp-6d quantifies molecular topological complexity along 6-atom paths. The narrow range (from 0.04 to 0.06) of AXp-6d suggests subtle but important variations in the molecular topology (Figure A) associated with the hKMO inhibitory activity. A BCUT descriptor, BCUTd-1l, reflects the atomic partial charge and topological character. The range from 0.91 to 0.99 indicates discriminative electrostatic diversity across the data set (Figure B). Next, the range from 1.12 to 1.62 of the AATS 5p captures midrange molecular flexibility and polarizability effects (Figure C). Furthermore, the sum of van der Waals surface areas for atoms falls within a specific molar refractivity range (23.22 to 76.66 in Figure D), reflecting contributions of size and lipophilicity. Understanding the ranges of these descriptors is important to explore the impact of molecular features on the behavior of the model. Additionally, a two variable PDP of selected chemical descriptor AXp-6d vs SMR_VSA7 is also plotted (Figure E). The contour plot color-codes regions are based on numerical values, as indicated by the contour levels. It seems highest in the yellow-green region and lower in the darker blue and purple areas. The colors range from darker to lighter shades, where lighter regions seem to correspond to higher values. In the plot of Figure E, lighter regions correspond to higher predicted probabilities, indicating a higher likelihood of the compound being classified as “actives”. SMR_VSA7 represents the van der Waals surface area contributions from atoms with moderate molar refractivity values. Values above 41 for these features likely indicate compounds with more surface area and potentially enhanced lipophilic interactions. There seems to be a significant region around AXp-6d of 0.047 to 0.050 and SMR_VSA7 of above 41, where the performance metric reaches its high (Figure E) prediction scores from the RF model. Thus, the model appears to associate moderate topological complexity (AXp-6d ≈ 0.047 to 0.050) and increased lipophilic surface area (SMR_VSA7 > 41) with a higher probability of compound activity.

Partial dependence plot (PDP) of (A) AXp-6d, (B) BCUTd-1l, (C) AATS5p, and (D) SMR_VSA7. The x-axis represents the range of descriptor values observed in the training data. (E) Two-variable PDP of chemical descriptors AXp-6d vs SMR_VSA7.

## Section: Results and Discussion › Machine Learning (ML) Study › SHAP (Shapley Additive Explanations) Plot

The SHAP (shapley additive explanations, https://shap.readthedocs.io/en/latest/) summary plot of SHAP values for each descriptor of the training set is given in Figure A. The color shift from blue to red indicates that the descriptor ranges from low to high values. Color encodes the feature value (red = high, blue = low) of hKMOis. This helps to understand the magnitude of a descriptor and the influences of the feature in the prediction of the ML model. For instance, Xch-6d, high values (red) are typically associated with positive SHAP values, meaning that higher topological complexity promotes KMO inhibitory activity.

Conversely, for BCUTd-1l, low values (blue) may correspond to negative SHAP values, indicating that less favorable electrostatic properties shift the prediction toward inactivity. SMR_VSA7 shows a wider spread of both positive and negative SHAP values, suggesting that its influence is dependent on its specific value and interaction with other features. Importantly, the mean absolute SHAP value for each descriptor (horizontal axis ranking) quantifies the contribution of the descriptors to the model on average across all predictions. Descriptors with higher mean absolute SHAP values are therefore more consistently impactful in determining activity.

Additionally, the SHAP waterfall plot (Figure B) illustrates the contributions of individual features in the final model prediction for a single compound (for example, the most active molecule from this investigated data set). The x-axis of Figure B reports E[f(x)], which stands for the expectation function over all sums of SHAP values calculated on the training set hKMOis. Features contributing positively (bars extending to the right) increase the probability of classifying the hKMOi as “active”, while features contributing negatively (bars extending to the left) reduce that probability, pushing the prediction toward “inactive”. From the plot in Figure B, it can be observed that SMR_VSA7 provides the largest positive contribution, significantly increasing the prediction toward the “active” class for the investigated molecule. The next important descriptors, BCUTd-1l and MDEC-33, exhibit good contributions, while the AATS 5p, Xch-6d have poor contributions for the investigated molecules.

(A) Summary plot of SHAP values for each descriptor of the training set. (B) Waterfall plots of the most active molecule from this investigated data set.

## Section: Results and Discussion › Explainable Artificial Intelligence (XAI) Platform to Unveil the Molecular Rationale Behind KMO Inhibition

The primary format is a Streamlit (https://streamlit.io)-based web application accessible at https://phkmoiv1.streamlit.app/. Users can input an SMILES string of their query molecule to predict its KMO inhibitory activity. This platform predicts the outcomes for external data (query molecules) using our pretrained ML model and provides a detailed explanation of the predictions using SHAP analysis (Figure ). It visualizes both the SHAP explanation and the structure of (a) the query molecule, (b) the most similar molecule from the data set with respect to the query molecule, and (c) the most active molecule from the data set.

In Figure , an example of the prediction of a known hKMOi via the “phKMOi_v1.0” tool is depicted. Since the query molecule was already present in the data set, the most similar molecule from the data set with respect to the query molecule is the same one (similarity = 1). This tool/XAI platform perfectly predicted the known hKMOi as “active” (Class: 1). Hence, this tool predicted the hKMOi with an external set accuracy of 0.8929. Another example of a prediction with an unknown query molecule is given in Figure S2. Importantly, this user-friendly XAI platform serves two key purposes:

Interface of the “phKMOi_v1.0” tool. The visualization of 2D structures and the SHAP waterfall plots of the query molecule, the most similar molecule from the data set with respect to the query molecule, and the most active molecule from the data set.

## Section: Results and Discussion › Chemical Space Network (CSN) Analysis

We applied CSN analysis to unveil the networks with nodes (representing hKMOis) and edges (representing structural similarity). Here, structural similarity was calculated by using the Tanimoto coefficient (Tc) with RDKit topological fingerprints, and edges were drawn between nodes (hKMOis) if Tc ≥ 0.68. Meanwhile, this analysis revealed 14 subgraphs (or clusters), where 4 subgraphs (1, 2, 4, and 12) contain more than 10 hKMOis (Figure ). The remaining clusters possess two or fewer hKMOis (Figure S3). All of the clusters together can be visualized in Figure S4.

A list of hKMOis (with their molecule IDs) belonging to subgraphs 1, 2, 4, and 12 is provided in Table S2. Moreover, Table S3 summarizes the structural similarities and differences among the hKMOis within subgraph 1, based on edge weights representing pairwise similarity (Tc ≥ 0.68). In subgraph 1 (Figure ), 29 pairs of hKMOis possess a similarity of ≥ 0.9, indicating that 10.94% of the pairs are excellenty similar. Likewise, 21.47% (Table S4) and 29.71% (Table S5) of the pairs are excellenty similar (Tc ≥ 0.9) in subgraphs 2 and 4, respectively. Notably, in subgraph 12, 17.65% of the pairs exhibit high similarity with Tc ≥ 0.8 (Table S6). For further analysis, we focused on subgraph 1 (CSNs with maximum hKMOis).

A spring layout CSN component of 4 clusters (denoted as subgraphs 1, 2, 4, and 12) of hKMOis. Molecule ID is also highlighted for better understanding. The color of the nodes represents the pIC 50 values (as per the color map) of the hKMOis, and the line style in the network graph is dependent on the Tc-based similarity value. Thick lines for excellent similarity (Tc ≥ 0.9); medium lines for high similarity (0.7 < Tc < 0.9); thin lines for moderate similarity (Tc ≤ 0.7).

## Section: Results and Discussion › LQTA-QSAR Studies

The final 3D-QSAR model is obtained based on five latent variables (nLV). The coefficient of determination is found to be 86.97%. It means that 86.97% of the variance in the training set is explained by this model (Table S7). The root mean square error of calibration (RMSEC = 0.399) measures the promising quality of the model. Lower values indicate better calibration. The prediction residual sum of squares (PRESS), indicating the sum of squared errors from cross-validation, is associated with Q 2 values of 0.812. Moreover, the value of F = 42.707 confirms that the model is statistically robust. Good external validation is also suggested by the R 2 Pred values. Figure presents the Lennard-Jones (LJ) and Coulomb (C) descriptors selected in the chemical space around the most active (Figure A) and the poorly active molecule (Figure B).

Molecular descriptors are obtained from the conformational ensemble profile (CEP) for the RI-4D-QSAR study using the Laboratório de Quimiometria Teórica e Aplicada (LQTA)-QSAR methodology. Notably, the 4D-QSAR model (nLV = 2) is good enough to explain 91.96% of the variance and generate the model with a low standard error of calibration (SEC = 0.335). Here, the Q 2 and root mean square error of cross-validation (RMSE CV ) are found to be 0.866 and 0.433, respectively. The F value obtained here for this 4D-QSAR model is 154.371. The predictive residual sum of squares of cross-validation (PRESS CV ) value of 5.636 (Table S7) suggests the quality of the model.

LJ and C descriptors selected around the CEP of the most active and the least active molecules from subgraph 1 are shown in Figure . The C descriptors with positive coefficients are found to contribute favorably to the model, suggesting the importance of halogens in enhancing the KMO inhibitory activity. Two LJ descriptors are located near the pyrimidine ring of K001 (Figure ), implying that introduction of bulky groups with electrostatic properties may not be beneficial for the hKMO inhibitory activity.

This also describes the structural information corresponding to the shape and conformational flexibility of the ligands, which indicates that the bulky group at that position is unfavorable for biological activity (Figure ). These observations agree with the SARs, where replacing the N atom with a CH group at the C2 and C6 positions results in a drastic fall in hKMO inhibitory activity. Moreover, substituting with a COOH group at the fifth position enhances the potency of hKMOis (Figure ). However, replacing this group with any other at the same position leads to a reduction in activity. Likewise, no substitution at the fourth position favors hKMO inhibitory activity.

As suggested by the C and LJ descriptors, the introduction of a small group with negative charges may increase the activity near region B. Substitution at the C4’ position with any group other than a halogen may negatively impact hKMO inhibitory activity. Additionally, introducing a ring structure tends to decrease the effectiveness of hKMOis, indicating that nonhalogen substitutions and ring formations are generally unfavorable for maintaining or enhancing hKMO inhibitory activity levels in the molecule.

Methoxy substitution at the C3′ leads to a reduction in KMO inhibitory activity, indicating that while chlorine and fluoro groups support activity, the methoxy group diminishes the hKMO inhibitory potency. However, close to the C5′ substituent near region B, the introduction of steric groups may decrease the activity, and this observation is consistent with the experimental bioactivity. For instance, the substitution of a trifluoromethyl group at the C5′ position could be detrimental, potentially impairing the hKMO inhibitory activity (Figure ).

Most active K001 (A) and poorly active K124 (B) compounds with selected descriptors (as per the 3D-QSAR model) around them. Yellow: Lennard-Jones descriptor with a positive regression coefficient; magenta: Lennard-Jones descriptor with a negative regression coefficient; cyan: Coulomb descriptor with a positive coefficient; orange: Coulomb descriptor with a negative coefficient.

Compounds K001 (A) and K124 (B) with selected descriptors (as per the 4D-QSAR model) around the conformational ensemble profile (CEP) of each ligand. Yellow: Lennard-Jones descriptor with a positive regression coefficient; Magenta: Lennard-Jones descriptor with a negative regression coefficient; cyan: Coulomb descriptor with a positive coefficient; orange: Coulomb descriptor with a negative coefficient.

Key structural requirements of investigated derivatives for better hKMO inhibitory activity.

## Section: Conclusion

This study provides valuable insights into the structural determinants of hKMO inhibitory activity through a combination of advanced computational techniques, including supervised ML, CSNs, and 3D/4D-QSAR studies. While it is true that the data set is relatively small, this limitation arises from the current lack of extensive publicly available data on experimentally validated hKMOis. Nevertheless, our study carefully addresses this by applying rigorous modeling techniques, cross-validation, and interpretable tools to maximize reliability and extract meaningful SARs from the available data. The developed supervised ML model demonstrates excellent performance, correctly classifying 89.29% of the instances in the validation data set. Further, the analysis of CSNs of hKMOis identified 14 distinct clusters, four of which contained more than 10 hKMOis. The remaining clusters are smaller, with two or fewer compounds per cluster.

For deeper insights, we focused on subgraph 1 (the cluster with the largest number of nodes) to develop the LQTA-QSAR model for the first time with the hKMOi data set, which provided valuable structural insights into the hKMOi space. The Coulomb (C) descriptors emphasize the importance of halogen atoms in enhancing hKMO inhibitory activity. This supports the hypothesis that halogen substitutions in key positions can lead to stronger binding interactions. The Lennard-Jones (LJ) descriptors, located near the pyrimidine nitrogen atom, provide critical structural information about the shape and flexibility of the ligands. Specifically, our analysis suggests that replacing the nitrogen atom with a methyl group (−CH3) at the C2 and C6 positions results in a significant reduction in the level of hKMO inhibition, aligning with previously observed SARs. In addition, the analysis of the C and LJ descriptors suggests several key trends for enhancing the hKMO inhibitory activity. For instance, introducing a small group with negative charges near region B may increase the activity. On the other hand, substitution at the C4’ position with anything other than a halogen atom appears to negatively impact hKMO inhibitory activity. Finally, the introduction of steric groups near region B (e.g., at the C5′ position) is found to decrease activity, consistent with experimental observations. Specifically, the substitution of a trifluoromethyl group at the C5′ position is identified as potentially detrimental, impairing the hKMO inhibitory activity. Apart from these details of SAR exploration, we have also identified important trends in the design and optimization of hKMOis by focusing on key molecular descriptors (ML and LQTA-QSAR) and their spatial relationships. For instance, the hKMO inhibitory potency can be enhanced by the incorporation of fluorinated benzene rings at Region B, likely due to their influence on molecular refractivity (as suggested by the descriptor SMR_VSA7). Hence, this fragment should be prioritized in the rational design of future hKMO inhibitors. In contrast, structural motifs such as multiple tertiary carbon atoms and mono- or dichloro-substituted benzene rings have been identified as negative contributors to hKMO inhibitory activity and therefore may be deprioritized in future hKMOi optimization strategies.

Additionaly, “phKMOi_v1.0” (available at https://phkmoiv1.streamlit.app/) is the first framework predicting KMO inhibitory activity that integrates an explainability support system (XAI). This tool also enhances the understanding of the role of specific molecular descriptors relating to KMO inhibitory activity, suggesting a potential link between the query molecule and its predictions.

## Section: Acknowledgments

The authors sincerely acknowledge the Department of Pharmacy, Universita degli Studi di Salerno, Fisciano 84084, Campania, Italy, and the Universidade Federal de Minas Gerais, Brazil, for providing the research facilities.

## Section: Text

The data associated with this study are contained within the article or in the Supporting Information. If required, the data will be made available on request. The Python scripts to calculate the Pearson correlation coefficients and other calculations have been provided at https://github.com/Amincheminform/phKMOi_v1.

## Section: Text

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsomega.5c03404.

## Section: Text

S.A.A.: conceptualization, data curation, formal analysis, validation, methodology, and writing – original draft, review and editing. J.P.G.A.d.V.: formal analysis, methodology, and writing – original draft. J.P.A.M.: resources, supervision, and writing – review and editing. S.P.: resources and writing – review and editing.

## Section: Text

The Article Processing Charge for the publication of this research was funded by the Coordenacao de Aperfeicoamento de Pessoal de Nivel Superior (CAPES), Brazil (ROR identifier: 00x0ma614).

## Section: Text

All co-authors have read and approved the manuscript.

## Section: Text

The authors declare no competing financial interest.

## Section: Associated Data › Data Availability Statement

The data associated with this study are contained within the article or in the Supporting Information. If required, the data will be made available on request. The Python scripts to calculate the Pearson correlation coefficients and other calculations have been provided at https://github.com/Amincheminform/phKMOi_v1.


---

# Framework for bias evaluation in large language models in healthcare settings

- **Authors:** Tara Templin, Sophia Fort, Prasanna Padmanabham, Pratyush Seshadri, Ram Rimal, Junier Oliva, Kristin Hassmiller Lich, Sean Sylvia, Nasa Sinnott-Armstrong
- **Issuer:** NPJ digital medicine
- **Type:** Scientific article
- **Published:** 2025-07-07
- **Language:** en
- **DOI:** 10.1038/s41746-025-01786-w
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40624264/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

A critical gap in the adoption of large language models for AI-assisted clinical decisions is the lack of a standardized audit framework to evaluate models for accuracy and bias. Our framework introduces a five-step framework that guides practitioners through stakeholder engagement, model calibration to specific patient populations, and rigorous testing through clinically relevant scenarios. We provide open-access tools for stakeholder engagement and an example of an audit. As the regulation of models becomes more critical, we believe adoption of an audit framework that tests model outputs, rather than regulating specific hyperparameters or inputs, will encourage the responsible use of AI in clinical settings.

## Section: Introduction

The widespread adoption of large language models (LLMs) has revealed significant challenges found in clinical settings, particularly around accuracy, bias, and patient privacy1. While some tools exist to help address bias on an algorithmic level2, there is no comprehensive approach available for new users to identify and mitigate these harms in clinical settings. Even so, studies to date have explored myriad applications ranging including aiding differential diagnosis, answering medical exam questions from the US Medical Licensing Examination (USMLE), providing accurate medical advice, and extracting patient information from electronic medical records1,3. Each study uses varied auditing methods and accuracy metrics, reflecting the nascent evaluative clinical protocols for evaluating LLM performance. In addition to questions about the overall accuracy of LLMs, there are further concerns about historical biases being replicated in AI predictions, potentially exacerbating health inequities. All of these concerns result in mistrust of AI tools in healthcare. For example, 60% of Americans report discomfort with AI involvement in their healthcare4–6. To address these concerns, a standardized approach to creating, disseminating, and testing these methods and tools is needed.

Two key challenges remain underexplored in the assessment of LLMs for clinical use. The first is that there is no established framework for how to approach such an audit of generative AI for clinical decision-making, though a few have been proposed in other settings7. Specifically, there is no standard framework to link clinical scenarios and resulting questions, such as those related to diagnosis or treatment, to appropriate technical methods for evaluating an LLM’s performance. This gap hinders the systematic evaluation of how accurately and impartially a particular LLM can assist in different parts of the clinical care process. The second challenge is that very little work has been done on understanding how synthetic data from LLMs may be used to understand the distributional assumptions embedded within the model, and a calibration process to better align the model with the clinical population. This is particularly promising as an avenue of inquiry because, by using synthetic data and clinical simulations, healthcare systems can assess model accuracy and bias without compromising patient privacy.

In this paper, we propose a framework (Fig. 1, Table 1) and open-access tools (Methods) to evaluate the adoption of LLMs in AI-assisted clinical decision-making. Our framework is designed to offer a practical guide so that other practitioners can readily evaluate LLMs within their own clinical settings. Each step in our framework offers examples and tools so that practitioners can engage stakeholders, calibrate models, and execute audits for specific clinical problems.Fig. 1Five-step process for large language model evaluation.This figure summarizes the five-step procedure we propose to evaluate Large Language Models (LLMs). First, we propose that auditors meet with stakeholders to confirm the purpose of the audit, questions, and risk tolerance. Next, we propose calibration of LLMs to the patient population and perform relevant power calculations. Third, the audit is conducted on clinically relevant scenarios. After the audit, we suggest reviewing the audit results and discussing the acceptability and clinical implications of the findings. Finally, monitoring of changes to models and audit results over time is essential to support additional stakeholder engagement when needed. Figure includes icons licensed under the Creative Commons Attribution License (CC BY 3.0). This license allows you to use the Icon for free through the Services, as long as you attribute it to the Icon creator. For more details on the Attribution License, see Creative Commons at https://creativecommons.org/licenses/by/3.0/.Table 1Stakeholder mapping exercise templateQuestionsUse case 1Use case 2What is the tech that is inspiring this use case? (Briefly describe.)What is the potential for this tech to improve outcomes in your setting? Is there a specific problem it might address? A potential improvement it might unleash? Be as specific as possible!What would need to be true for this potential improvement to be realized? Please describe the “design criteria”—for example how the tech needs to be operationalized, what a user needs to feel from/about it or be able to do?What might this use case trigger that could be undesirable and how might you avoid it? Think about downstream consequences as broadly as you can (e.g., on workflow, worker satisfaction, consumer behaviors, learning).

By involving stakeholders throughout the evaluation process, this framework also begins to address the issue of trust in AI tools in healthcare. By including end users in the evaluation and by increasing transparency, this framework may increase the likelihood that users will trust the tool as they understand the limitations and steps taken to ensure the tool’s reliability. To develop this framework, we reviewed existing literature on machine learning model evaluation, focusing on accuracy and bias assessments (http://libproxy.lib.unc.edu/login?url=https://www.proquest.com/working-papers/underneath-numbers-quantitative-qualitative/docview/3067542940/se-2)8–15, and drew upon our own experience evaluating LLMs in healthcare settings. Building upon established principles from works such as “Model Cards for Model Reporting”16 and “A Governance Model for the Application of AI in Health Care”17, we adapted and expanded these concepts to address the unique challenges posed by LLMs in clinical settings.

We now present a five-step audit framework designed to standardize the evaluation process and facilitate comparisons of bias assessments across studies: (1) engage stakeholders to define the audit’s purpose, key questions, methods, and outcomes, as well as risk tolerance in adopting new technology; (2) select the LLM for evaluation, calibrate it to the patient population and expected effect sizes; (3) use clinically relevant scenarios to execute the audit; (4) review the audit results in comparison to the accuracy of non-AI-assisted clinician decisions and weighing the costs and benefits of technology adoption; (5) continuously monitoring the AI model for data drift over time.

This figure summarizes the five-step procedure we propose to evaluate Large Language Models (LLMs). First, we propose that auditors meet with stakeholders to confirm the purpose of the audit, questions, and risk tolerance. Next, we propose calibration of LLMs to the patient population and perform relevant power calculations. Third, the audit is conducted on clinically relevant scenarios. After the audit, we suggest reviewing the audit results and discussing the acceptability and clinical implications of the findings. Finally, monitoring of changes to models and audit results over time is essential to support additional stakeholder engagement when needed. Figure includes icons licensed under the Creative Commons Attribution License (CC BY 3.0). This license allows you to use the Icon for free through the Services, as long as you attribute it to the Icon creator. For more details on the Attribution License, see Creative Commons at https://creativecommons.org/licenses/by/3.0/.

Stakeholder mapping exercise template

## Section: Results

Table describing key stakeholders and their role59–67

Example of the SA1 worksheet filled out for different AI tools65,68

Example stakeholder mapping exercise template for chronic kidney disease

Table outlining different types of biases

## Section: Results › Step 1: engage stakeholders to define audit objectives, experimental parameters, and outcome metrics

We explicitly acknowledge that healthcare institutions differ considerably in resources, populations, and clinical contexts. Thus, we provide a robust and reproducible framework that institutions can adapt and operationalize into detailed, context-specific protocols. To ensure the effectiveness and institutional applicability of such an audit, it is imperative to align on the audit purpose, key questions, methods, and outcomes. Biases in AI-assisted decision-making can impact all components of care. Importantly, these biases may arise from factors beyond model technical accuracy, for example, how the model is implemented and used, and how output may be interpreted clinically. Because of the far-reaching implications, healthcare systems must include patients, physicians, hospital administrators, IT staff, AI specialists, ethicists, and behavioral scientists in the evaluation process for generative AI integrations. The group of stakeholders may wish to implement a structured consensus-building process that balances inclusivity, community expertise, and technical knowledge. Providing training sessions or educational materials can help bridge knowledge gaps. We explain key stakeholders more in Table 1. This group will steer the objectives and oversee the technical aspects and interpretation of the audit.

We propose a stakeholder mapping tool (Tables 1 and 2) to aid stakeholders in defining key parameters of the technology evaluation and facilitating communication about different types of expertise. Stakeholder mapping analyzes the preferences, incentives, and institutional influence of actors in a particular activity or system. Conducting these types of analyses can improve understanding of a specific stakeholder’s involvement in the implementation of a technology, and can illustrate organizational factors that hinder or help the technology implementation. Moving through a mapping exercise with relevant stakeholders can also facilitate a collaborative approach to the execution of a new process18. Implementing this type of stakeholder analysis closely aligns with the concepts of systems science, which refers to a collection of analytical methods allowing researchers to evaluate how components of complex systems operate individually and as a whole, often over an extended period of time19.Table 2Table describing key stakeholders and their role59–67CategoryRoleSkills/Responsibilities in the audit processRelationships with other stakeholdersDesired outcome from responsible AIValue of responsible AIConcerns in implementationTechnicalIT InfrastructureResponsible for managing/overseeing the collection of data from any devices implementing ML, the transfer of data between devices, the storage of data, and the use/application of data in ML techniques.Works with the ML team to ensure that data moves securely through development processes and everyday useSecure AI that prevents data breaches and cyberattacksAdds another layer of software review that can provide the opportunity to strengthen data security/reduce risks of information security threats. Data governance principles ensure ethical use and deployment of large amounts of healthcare dataMain concerns are data security, data interoperability, data quality, and management.ML Engineer/ DevelopmentResponsible for the development of AI systems. These professionals could be in-house at a health system or from a contracted third-party company. ML engineers/developers are also responsible for the validation and auditing of AI systems, which can also happen either in-house or by a third-party company.ML developers interact with IT infrastructure professionals when obtaining patient data to build and train models.An AI system that is optimized for the healthcare system’s priorities and maintains accurate output.A clear standard for AI auditing helps developers confidently assess the performance of their technology and identify gaps to improve development processes. In the instance that developers are responsible for creating an internal audit process for a specific health facility/software, an existing guideline will make the workload lighter and more straightforward. Also may have concerns about assuming responsibility for ML errors, so a more in-depth and standardized AI validation system would hopefully help developers feel more comfortable about what they produceExtra validation requires greater software control and performance monitoring. Regulatory compliance is extremely complex. Administrative and market pressures may lead to the release of lower-quality systems.ClinicalPhysiciansUse AI tools to assist in care delivery.Uses AI to streamline communication with other medical staff and nurses.Saves time, reduces fatigue, reduces unnecessary ED visits, and reduces diagnostic errors.Increased validation/responsible AI means that physicians can comfortably use AI to assist their decisions, knowing that it has been thoroughly vetted, reducing the fear of malpractice/misdiagnosis. AI has also introduced models that can help detect risk scores for patient deterioration and sepsis, which can reduce the need for/streamline between-shift physician-to-nurse communicationConcern that AI will reduce time to diagnosis and negatively influence employment rates. Misinformation and decision bias may be amplified by AI.AdministrativeHospital ExecutiveApprove investment in the initiative to build and audit LLMs, decide regulatory compliance measures, and dictate error tolerance.Relays regulatory and operational decisions to ML, IT, and management teams.Fewer Type I or Type II errors based on hospital values, leading to reduced costs, fewer missed diagnoses/treatments, or a combination of both. Optimized patient/treatment flow and resource allocationAppeal to political/public/patient interest of responsible AI use—admin can be confident that their AI abides by principles of ethical AI, specifically transparency and accountability. A certifiable standard for validation reassures executives that their technology is dependable and effective, and potentially safeguards against a certain degree of legal retribution. An external standard that administrators can use as a requirement for their suppliers helps validate the legitimacy of said third-party groups.Data curation for ML incurs substantial expenses, and abiding by stricter data quality regulations could increase spendingOperations/ Mid-level managementEnsure that work protocols surrounding AI use are being followed correctlyOversee the providers and medical staff who work directly with AI for everyday tasks.AI that is easy to implement and runs smoothly without administrative or diagnostic errors that lead to operational delays/backlogOperations or quality assurance managers will appreciate the ability to follow a systematic and standardized format for collaborating with development teams and presenting audit evidence/resultsAn internal audit system may require additional management/planning, labor, and infrastructure outside of an existing technical/ML team.Medical Staff (triage nurses, etc.)Use AI tools for triage assignmentCommunicate with physicians to relay patient assignments and administrative informationOptimize triage assignment, reduce wait timesAn AI system that can accurately assign patients to departments or complete other administrative tasks without error or bias would increase efficiencySimilar to other stakeholders, they would be worse off if the AI made consistent errors or biased patient assignmentsCommunityPatient AdvocatePatient advocates can help open the discussion around AI output when patients are feeling doubtful/want to pursue other treatment options, and can help the patient make informed decisions based on their own values and preferences, regardless of AI suggestions.Facilitate discussions between patients and physicians, nurses, and administrators to support patient’s wants and needsSecure monitoring of patient health information that allows prompt advocate intervention and moderation.Patient advocates can also benefit from AI automation through the reduction of administrative workload, leaving more time to build client relationships and prioritize individual attention.AI would take over physician-patient interaction and make it harder for advocates to vouch for patient interests. Also, there is some worry about the potential for AI to take on an advocate role instead of human advocatesService UsersPatientReceive the outcomes of the use of AI in clinical settings.Most of the patient interactions with the responsible AI tech we have been considering (text synthesis, audio, diagnostic support) come into play when a patient is communicating with a provider. Indirectly, patients interact with IT/ML professionals through the management of their health data, and thus are concerned about the performance of these professionals when handling healthcare data and any technology that uses said data.AI that can improve treatment accuracy without overriding physician expertiseEnsures that the AI used to supplement the decisions of their providers is providing accurate information about their potential diagnoses and treatment plans. Less concern about security when providing health information to providers using responsible AI, an increase in patient happiness in comfortabilityAI may increase the risk of misdiagnosis or mistreatment, or may result in the patients’ providers paying too much attention to AI output and not practicing autonomy in their decision-making.

Our tool (Table 1) presents prompts for individual stakeholders to use when considering a technological innovation to improve outcomes in their area of clinical expertise. The questions revolve around the motivation for adopting a new innovation in the specific setting of the stakeholders. This includes the stakeholders’ perspective on potential improvements from the technology, the conditions they believe are necessary for the improvements to be realized, and any anticipated problems along with ideas for mitigating those issues. We provide illustrative examples of how to use Table 1 in Table 3 (general use cases) and Table 4 (chronic kidney disease-specific analysis).Table 3Example of the SA1 worksheet filled out for different AI tools65,68QuestionsUse case 1Use case 2Use Case 3What is the tech that is inspiring this use case? (Briefly describe.)Chart Summarization ToolsAmbient Listening ToolDiagnostic Support BotWhat is the potential for this tech to improve outcomes in your setting? Is there a specific problem it might address? A potential improvement it might unleash? Be as specific as possible!Clinician: I can write patient charts faster, increasing the ease of asynchronous communication with patients and allowing me to better understand patient issues.Patient: I get more frequent responses to my questions from my provider, which makes me feel prioritized and valued.Hospital: Improvements in operational efficiency and overall provider performanceClinician: This tool allows me to focus directly on my patients while we interact, rather than having to split my attention between taking notes and listening. For me to feel confident in this technology, it would need to capture all important notes for future medical documentation and appropriately reflect on the patient’s condition at the time and what is needed (prescriptions, etc.)Patient: My clinician will have a reliable record of what I said during our visit, so I know that they will be able to accurately understand and remember my symptoms and complaints.Clinician: I can receive diagnostic and treatment support that can improve the care I provide to my patients.Patient: I know that the diagnosis and treatment plan my physician creates for me is being checked against a powerfully accurate support tool, which makes me feel more optimistic about my care and potential health outcomes.What would need to be true for this potential improvement to be realized? Please describe the “design criteria”—for example, how the tech needs to be operationalized, what a user needs to feel from/about it or be able to do?1. Ease of use (integrated within clinical workflow)2. Better auditing methods3. Cost—(value proposition clear)4. AI literacy (realistic expectations about accuracy, etc) and trust (needed to gain literacy)5. How to build trust—critical to get to AI literacy. (What will this look like IN THIS use case)—get family med doctors to join the pilot (ambassadors… early adopters)6. Need transparency to grow trust7. Ability to implement, end-to-end (what this would look like might be a row we need to add and explore after ideas are shared)From the patient’s perspective, there would need to be a supported level of confidence that what is important to the patient and physician is being captured, and that any information provided is secure. The patient would value having an interaction where they can truly feel that the provider is paying attention to them and not the computer. For the provider, the priority would be that the important information for treatment and diagnosis is being captured and summarized, or else it is an additional workload to have to listen back and check that the AI accurately recorded everything. Additionally, it would be important for the technology to be able to work effectively to non-native English speakers.There would need to be substantial efforts to build patient trust in the use of LLMs in healthcare delivery. Many people would be skeptical of the use of this technology in a visit with a healthcare provider. A patient would want to know that the AI supporting their physician has been thoroughly validating and is accurate. They would also want to be reassured that their physician is not solely relying on the output of the AI to decide on their diagnosis and treatment plan. A physician would also want to be incredibly confident that the the AI was accurate before using it to support their decisions.What might this use case trigger that could be undesirable and how might you avoid it? Think about downstream consequences as broadly as you can (e.g., on workflow, worker satisfaction, consumer behaviors, learning).If doctors are able to respond to patients at a faster rate, they may be required to respond to more and more patients, which could cause burnout. Additionally, any errors in responses caused by the AI could be extremely detrimental if communications include treatment suggestions, prescription refills, etc. Doctors will also be dissuaded from using this technology if the user interface is difficult to navigate.Any privacy violations would be a major cause for concern. Language barriers could pose a significant issue in bringing technology to scale.Even small errors, biases, or hallucinations in diagnosis can lead to detrimental patient outcomes. Without proper responsible AI processes, physicians and healthcare systems alike could run the risk of legal action in the case of misdiagnosis or mistreatment while using this technology. Patients may begin to feel that their treatment is less personalized, leading to a sense of detachment/disengagement from the healthcare system. Patients may also be required to pay higher copayments if the healthcare systems choose to pass the cost of implementing this technology onto the consumer.Table 4Example stakeholder mapping exercise template for chronic kidney diseaseQuestionsExample Use case 1: chronic kidney diseaseWhat is the tech that is inspiring this use case? (Briefly describe.)Large Language Models have been shown to perform well on the USMLE. We wanted to see if LLMs can be used to prioritize patients for nephrologist (specialists) appointments and kidney (organ) transplants.What is the potential for this tech to improve outcomes in your setting? Is there a specific problem it might address? A potential improvement it might unleash? Be as specific as possible!This technology can be implemented in resource-scarce areas to help prioritize patients that will need urgent care from specialists.What would need to be true for this potential improvement to be realized? Please describe the “design criteria”—for example how the tech needs to be operationalized, what a user needs to feel from/about it or be able to do?The algorithm needs to be fast enough to quickly classify patients, and the cost associated with running the algorithm needs to be affordable. We also need to consider how the algorithm might work when the internet signal is weak or without internet access. The algorithm needs to also be appropriately trained to handle the specific conditions and biological traits of the patient population found in the area.What might this use case trigger that could be undesirable and how might you avoid it? Think about downstream consequences as broadly as you can (e.g., on workflow, worker satisfaction, consumer behaviors, learning).The American medical system has a long history of structural racism, and ignoring pain/severe symptoms in women and people of color. Due to this pre-existing bias in our society and prior literature, it is important to evaluate the model to ensure these biases aren’t upheld by the current model.

Once the objectives and key considerations have been determined, the team must define essential elements such as the data structures, parameters to experimentally vary, and outcome metrics. IT staff and data science experts need to determine the schema for clinical vignettes or synthetic datasets in consultation with medical professionals and patients. Importantly, any schema used must align with the clinical data architectures in use at the hospital. The audit objectives will determine the key questions and testable hypotheses for model evaluation. The experimental design will systematically alter the vignettes’ attributes. Many clinical studies have begun to investigate randomly varying racial demographics and gender of standardized clinical presentations (http://libproxy.lib.unc.edu/login?url=https://www.proquest.com/working-papers/underneath-numbers-quantitative-qualitative/docview/3067542940/se-2)1,14,20–22. Additional factors that the working group could consider during perturbation testing include, but are not limited to: race/ethnicity, sex, age, income, geography, rurality, disability status, immigration status, interpreter needed, day shift/night shift, language used by the patient, language used by the provider, multimorbidity, and biases in missing data. We provide examples of known concepts that have been evaluated during perturbation testing in Table 5. In addition to demographic bias evaluation, one can also randomly vary the hyperparameters of the LLM.Table 5Table outlining different types of biasesType of biasExample of bias in the current world/in a clinical settingExample of bias perpetuated in an AI systemStructural Racism/Differential Treatment of Mental Health Conditions depending on RaceHistorical and structural racism still play a big role in the present. According to the paper, “Mass incarceration, public health, and widening inequality in the USA”, nearly one in three black men will be imprisoned69. A study of physical restraint use in emergency rooms found that being Black was associated with an adjusted odds ratio risk of 1.2270.Zhang et. al. pre-trained a BERT model initialized from SciBERT on clinical notes. They prompted the model to fill in the blanks in a situation. The model was more likely to instruct to send Black patients to go to prison compared to White patients, who were recommended to be sent to a hospital for the same belligerent and violent behavior71.Racial Bias due to Inadequate DataBlack patients are three times underrepresented in clinical trials for diabetic retinopathy72. The same pattern of underrepresentation was also seen in clinical trials pediatric asthma trials73.The underrepresentation of Black patients in clinical trials is also reflected in machine learning models, which perform worse in darker-skinned patients like in the cases of diabetic retinopathy74,75.Gender BiasThis paper details the glass ceiling in neonatal medicine, discussing how women earn 13-24% less than their male colleagues, and although women make up about 60% of the pediatric research staff, they hold less than 35% of full professor or chair positions in the US76.Gender based bias is reflected in AI models too. LLMs are more likely to classify women providing oncology care as nurses compared to men, who were more likely to be classified as being a doctor77. In a separate study, three different LLM chatbots were asked to recommend four ophthalmologists in the 20 most populous cities in the US. Female ophthalmologists were underrepresented78. Biases regarding gender that have translated into LLM models can prove detrimental for increasing diversity in the physician workforce and for women trying to break the glass ceiling in healthcare, especially if women are unfairly underrepresented by tools patients will use. Others have developed an overview and recommendations around this topic79.Bias due to LanguageBilingual children are often misdiagnosed with language impairment as their pattern of learning both languages might be different than their peers80.Authors observed that ChatGPT3.5 and ChatGPT4 responded with language that was stereotyping, condescending, and demeaning to prompts that were in different, non-“standard” dialects of English81.Age BiasOlder adults are often underrepresented in healthcare datasets, which leads to bias in AI models82.Researchers have cited lower performance in facial and other biometric recognition AI for adults over 6083.Income BiasPatients with lower socioeconomic status often have less complete EHR records, which can lead to biased AI performance84.A study using machine learning models to predict asthma exacerbation in children found that those from lower SES backgrounds had a larger balanced error rate (BER) compared to those from higher SES backgrounds84.Geographic BiasData collection and model training is heavily concentrated in North America and Europe, tailoring the products of AI development towards the populations in those areas and reducing the performance of the same technology in other locations85.In 397,967 AI life science research publications from 2000-2022, North America and Europe accounted for over 50% of publications in high-ranking academic journals85.

We recommend using the LLM (or, alternatively, another generative AI model) to generate synthetic patient cases that will serve two primary purposes (as discussed further in Step 2). First, synthetic cases provide a calibration dataset for ensuring the LLM accurately captures patient characteristics—including demographic or clinical edge cases—and correctly represents the clinical population of interest, including throughout statistical models23. By aligning synthetic data with real-world distributions, models can achieve better generalization and reliability in clinical predictions. Second, synthetic patient cases enable controlled and reproducible experimental auditing of the LLM’s predictions, isolating the model’s decision-making from confounding data limitations present in real-world electronic medical records24. By systematically altering specific attributes in synthetic patient profiles, researchers can evaluate how LLMs respond to different demographic or clinical features, thereby uncovering potential biases in model predictions. Overall, synthetic data allows balancing of reweighting (to avoid bias) along with privacy protection (through synthesis of relevant patient records).

The fundamental question in adopting AI technology is whether AI-assisted medical decision-making is “better” than standard-of-care medical decision-making. The steering committee considering adopting such a technology should only proceed if the incremental benefits outweigh the incremental costs, after careful consideration of how else those resources could be used to improve clinical care. The initial adoption will likely not have enough data for a full cost-benefit analysis, but we still encourage the steering committee to gather input from stakeholders on potential benefits and potential issues they foresee with the technology.

The definition of “better” will depend on the specific link between the clinical scenarios under evaluation to the appropriate technical methods for evaluating an LLM’s performance. Experts on algorithmic fairness have proposed many metrics that could be used depending on the objectives of the evaluation25–27. Every statistical test involves some amount of uncertainty and the possibility of a statistical error. Discussion of potential benefits and costs should also include ethical considerations. Other authors have previously surveyed ethical considerations of AI use in medical care28–30. Further discussions on aligning these error types with cost implications, as well as the ethics of this design, will be covered in Step 4. Additionally, given that LLMs can exhibit unpredictable behavior, the group should discuss a process for ongoing monitoring, a process we discuss more in Step 5.

Table describing key stakeholders and their role59–67

Example of the SA1 worksheet filled out for different AI tools65,68

Example stakeholder mapping exercise template for chronic kidney disease

Table outlining different types of biases

## Section: Results › Step 2: calibration of large language models to patient populations for evaluation

To begin model calibration, the steering committee must first identify the models to be evaluated. Despite being a relatively new technology31, many open-source and closed-source Generative AI models have become available with extensive tools developed around them, making it easier for practitioners and researchers to use them. Most hospital-placed versions of LLMs are built on a commercial platform, such as OpenAI’s GPT-4 (Generative Pre-trained Transformer 4) and ChatGPT, a conversational variant. Some competitor models include Gemini and Claude32–34. Many specialized medical models are being developed that allow patient-privacy aware modeling35.

The concept of calibration is widely used in machine learning and epidemiological modeling36,37. The importance is obvious when we consider integrating LLMs into clinical settings where these models may not have been trained on data from underrepresented populations, such as patients seen at rural clinics with missing data fields and visits. Before conducting evaluations within specific patient populations, it is essential to verify that the LLM accurately represents the statistical properties (both marginal and joint distributions) of the population. This step ensures that any detected biases are due to the model’s behavior rather than discrepancies in data representation.

The researcher or data scientist can approach calibration of the LLM by generating synthetic data for a patient population under study. Zack et al.38 describe a protocol to generate synthetic data for medical education and how to evaluate if it has the mix of characteristics that the analyst would expect in the patient population under study. However, we recognize that generating synthetic data alone may not directly reveal biases in the LLM’s outcome predictions. By applying this synthetic data approach, LLM output can be calibrated to a given healthcare system, to specific demographics being analyzed, or both. The synthetic data serves as an intermediate step, providing carefully constructed cases for conducting an experimental audit of the LLM’s predictions.

To generate synthetic patient data for calibration, analysts should first clearly specify population-level characteristics (e.g., age distributions, demographic diversity, clinical parameters such as disease prevalence or biomarker ranges) that closely reflect their clinical setting. The analyst should then prompt the selected LLM (or a generative AI alternative such as a GAN-based approach) to generate multiple synthetic patient cases. We provide example code for the patient simulation in the code repository (see Code Availability).

In addition to calibration, we recommend conducting an experimental audit to directly test the model’s predictions for bias. As a second method or additional check, the analyst can query the LLM to create presentations for the most likely patient profile in each experimental arm. For example, this may involve asking the LLM to generate a representative patient population from an urban clinic and a rural clinic in the same hospital system. Once the LLM generates synthetic patient cases for each arm of the experiment, the analyst can consult with medical professionals and patients to evaluate if the synthetic patients align with established clinical and community knowledge. Making synthetic datasets public would foster collaboration and allow for cross-comparison across different facilities.

To validate synthetic data rigorously and mitigate risks of downstream errors, we recommend a two-tiered validation process. First, analysts should statistically assess the similarity of synthetic and real clinical data distributions using established metrics such as Jensen-Shannon Divergence or Kolmogorov–Smirnov tests. Second, clinical experts should independently review a sample of generated patient cases to ensure clinical plausibility and identify any anomalies. This combined approach provides stronger assurances against introducing bias or inaccuracies into downstream analyses.

Based on those results, it may be that the LLM does not generate the most relevant patient population. If that is the case, then there are two remedial strategies. The first is fine-tuning the LLM with more data: take the current LLM and show it labeled (real or synthetic) patients from the relevant clinical setting to further fine-tune the parameters and test it for its ability to generate predictions relevant to the patient population. The second is the incorporation of clinical feedback. This could include clinicians interactively training the LLM to provide updated knowledge about the clinical presentations they encounter in the clinic. If working with OpenAI’s models, both methods would also benefit from reviewing the “temperature” and “top_p” parameters, which control how close to or far from the training data the LLM will stray. Because LLM outputs are probabilistic, prompts should be repeated multiple times (typically 20–30 replicates) using fixed decoding parameters, ensuring that the synthetic data reliably approximates the target population’s mean and variance. Stability is considered achieved when the generated responses consistently align with the pre-defined clinical distributions across repeated prompts.

For a scenario where the analyst is interested in checking for bias in the diagnosis of the disease across rural and urban settings, the researcher would ask the LLM to generate a set of simulated cases that match the general population of interest, or would check the experimental arms for accuracy in their presentation. For the case of a hospital evaluating its AI systems, first, they will want to check that the LLM can generate a set of patients that accurately represent the case mix of the hospital. The hospital would check that the LLM correctly generates patient characteristics such as demographics, presenting comorbidities, and CPT codes that would be under consideration at the hospital. In the case of rural settings, the LLM could also be tested on its understanding of where there may be missing information in the EMR due to a lack of data collection, healthcare system access and utilization, or patient wishes.

We also note that alternative methods, such as GAN-based approaches, may be used to generate synthetic cases instead of the specific LLM under study. For the goal of generating synthetic data specifically, more sophisticated methods may be preferable. We direct readers to a number of recent reviews39–42.

To determine the appropriate sample size for an audit, practitioners should use power calculations, which are standard when designing a randomized controlled trial. We recommend that analysts begin by using simulated patient data from the previous section to estimate the mean and standard deviation for key outcomes. Subsequently, they should simulate patient outcomes under the assumption of no effect (the null hypothesis) and under any alternative hypotheses of interest to stakeholders. From these simulations, for example, analysts can determine the minimum sample size needed to achieve 80% statistical power while maintaining a type I error rate at 5% and a type II error rate at 20%. This calculation ensures that the audit has sufficient capability to detect genuine effects without a high likelihood of false positives or negatives. The analyst may also want to generate simulated patients with biased demographics and different effect sizes (null vs fixed amounts) to calculate the associated consequences of false discovery in marginalized groups.

Given that stakeholders may want to evaluate many hypotheses during the audit, we suggest that the analysts incorporate methods for multiple hypothesis testing. The main methods for doing so are: (1) Bonferroni correction43,44, (2) False Discovery Rate45, and (3) the Benjamini-Hochberg procedure46,47.

## Section: Results › Step 3: execute and analyze the audit experiment

After calibrating the model and determining the number of replicates required to test the hypotheses set forth in Step 1, the analyst will implement and execute the audit. The analysis may directly use clinical vignettes. If not pre-defined by the committee, these vignettes could come from a number of sources such as: (1) USMLE, or similar exam-based questions; (2) NEJM Healer48; (3) Merck manual49; or published case studies or standardized patients. Different sources of vignettes will evaluate the LLM for different areas of accuracy and bias in different clinical tasks. For example, USMLE has multiple choice questions and evaluates if the LLM can find the correct answer based on medical knowledge, whereas NEJM Healer requires a differential diagnosis with clinical reasoning of all possibilities as more patient information is revealed. If the goal of the audit is to consider the quality of a text response (in comparison to a gold standard), the analyst will want to have both the clinical presentation and the gold-standard text answer assembled. To evaluate the effectiveness of integrating clinician input in reducing hallucinations in LLMs, we suggest that the analyst employs established quantitative metrics for evaluating text generation quality in natural language processing. Specifically, we suggest Recall-Oriented Understudy for Gisting Evaluation (ROUGE)50; Metric for Evaluation of Translation with Explicit ORdering (METEOR)51; and the BERTScore52.

We encourage the analyst to automate the audit to enhance efficiency and reproducibility, and provide our own open-source tools (Methods). Specifically, the analyst will want to avoid manually typing in prompts to a chatbot. Instead, the analyst could use Python or R to submit prompts to an API or the interface of an on-site model. This would also allow the prompt parameters and responses to be captured in data structures that will efficiently collate LLM responses. The forward-looking analyst can anticipate that the LLM interface may change (either across AI model providers or within the same provider over time). Parallelization can help with runtime if the computational resources are available, and workload managers such as SLURM can help time requests if the analyst is rate-limited by the LLM.

Once the results are collated, the analyst will conduct the pre-defined analysis from Step 1. Because the audit has occurred in a controlled setting, the analysis can proceed using standard hypothesis testing methods. For continuous outcomes, bounded continuous outcomes (such as probabilities), or discrete outcomes, the analyst will conduct the appropriate statistical test. An example of this would be requesting that the LLM assign a likelihood score to a certain diagnosis, and then analyzing differences in the distribution of likelihood scores over the experimentally-randomized procedures. For text data, the analysis may evaluate syntactic similarity between two sources of text. This may be used to consider the clinical accuracy of LLM-generated recommendations relative to a gold-standard corpus. Finally, the analyst may assess the sensitivity of these results to different hyperparameters and LLM models. This is an ongoing field of research and we recommend staying informed of new advances, collaborating with AI specialists and biostatisticians.

In consultation with clinicians, we developed a clinical vignette designed to test for bias across a number of clinical care pathway variables in patients presenting with chronic kidney disease (CKD). After conducting power analyses, we hypothesized that GPT-4 may return biased recommendations on the diagnosis and treatment of CKD based on age, race, and sex of the patient, reflecting documented biases in eGFR-based CKD diagnosis53. In order to test those hypotheses, we randomly varied the age, race, and sex of the same patient described in the clinical vignette. After presenting the clinical vignette, we queried GPT-4 with a set of standard questions about patient care. We compared how the answers varied across the randomized factors. Bias can be detected by comparing how differently the model evaluates the same patient profile. We provide a full description in the Methods.

## Section: Results › Step 3: execute and analyze the audit experiment › Analyzing the results of the audit

There are multiple ways to analyze results from such audits, depending on the nature of the metric being evaluated. For numeric outcomes (e.g., CKD stage, recommended follow-up intervals, or dialysis risk probabilities), non-parametric tests such as the Mann-Whitney U test or Kruskal–Wallis test should be used. Categorical outcomes (e.g., medication recommendations) should be analyzed using Chi-square or Fisher’s Exact tests to identify significant demographic differences in prescribed treatments. Textual outcomes should be quantitatively analyzed using natural language processing metrics like ROUGE, METEOR, or BERTScore compared to clinically validated gold-standard responses. Statistical tests can then be applied to these scores across patient demographics to identify biases.

Visualizing these results with swarm plots (for numeric responses) and stacked bar charts or upset plots (categorical data such as medication and dosage combinations) will clearly convey the presence and extent of biases. Interpretation of intermediate states between correct and incorrect responses should be standardized, for example: “fully correct” (complete alignment with clinical guidelines), “partially correct” (minor clinically acceptable deviations), or “incorrect” (clinically unacceptable deviations).

We emphasize that analysts should collaborate with clinical experts and biostatisticians to ensure robust interpretation of these metrics in context-specific audits, maintaining awareness of evolving standards in this emerging field.

## Section: Results › Step 4: value alignment

In Step 1, the guiding committee discussed the ethical considerations28–30, potential benefits, and costs of the adoption of a new technology in clinical care processes. With the audit results now available from Step 3, the committee can more thoroughly investigate the benefits and costs in light of statistical evidence about the error rate of the model, in addition to the statistical error associated with the audit.

There are clearly many harms from a model that is inaccurate and biased. For example, an LLM may disproportionately recommend less aggressive treatment options for patients from rural clinics in scenarios where clinical and logistical indicators suggest otherwise. This could lead to missed diagnoses, delayed treatments, and direct impacts on patient morbidity and mortality. Given that such model errors can critically affect patient care and health equity, the hospital may wish to be highly risk-averse about this type of error. In addition to the model error, there is also the possibility of a statistical error with the audit. While the power calculations likely minimized this error, the committee must take seriously that the model may still be biased even if the audit found no issue (this is called a Type II error, or a false negative).

Conversely, the audit may also falsely identify bias in a model that functions in an accurate and unbiased way. For example, an LLM may accurately recommend a particular treatment for patients across rural and urban clinics based on clinical guidelines and evidence, but the evaluation falsely flags this as urban-rural bias. In this case of a false positive, the healthcare system may incur significant opportunity costs. By not implementing a technological solution, the hospital may miss out on efficiency and appropriate substitution of digitization for tasks such as documentation, patient education, and triage.

Stakeholder acceptability may vary significantly across applications in healthcare. Whereas academics may be able to optimize the model’s overall accuracy and fairness based on robust statistical and ethical frameworks, hospitals may be subject to other constraints. Resource limitations, existing clinical workflows, and patient population specifics all may necessitate a more pragmatic approach. For example, hospital administrators may correctly point out that AI-assisted diagnosis will be unavailable if a third-party provider experiences a technical issue, which may be an unacceptable risk.

In addition to the audit of the LLM, healthcare systems and researchers may want to test how physicians fare in the task presented to the LLM. This will allow appropriate comparison of real-world success rates in the clinical task. An organization should approach this as a multidisciplinary, iterative collaboration. They can conduct prospective or retrospective studies in which clinicians perform tasks both with and without LLM assistance. The analytics team can then use metrics such as F1 score, ROUGE score, and BLEU score to evaluate the effectiveness of the LLM. The choice of evaluation metrics may vary depending on the type of LLM (for instance, F1 for classification tasks and ROUGE/BLEU for NLP generation tasks). A continuous feedback loop should be established to ensure that clinicians’ feedback is used to update the baseline. This comparison is not merely about accuracy but also about how LLMs complement or enhance the clinician’s decision-making process. A few questions for evaluation may be: (1) Do LLMs match or exceed the diagnostic accuracy, treatment recommendation efficacy, and patient outcome prediction of human clinicians? (2) Are there areas of complementarity? Are there areas where LLMs provide unique value, such as managing data-intensive tasks, offering insights from vast medical literature, or identifying non-obvious patterns in patient data? (3) How can clinicians provide context-rich insights into the LLMs’ clinical relevance, usability, and areas needing improvement? (4) Are there areas where LLMs can guard against physician implicit biases in the clinical care process?

Most importantly for applications in healthcare, the decision must be accepted by both clinical staff and patients. Some strategies might include surveys, interviews, or co-design sessions with clinicians to ensure that the proposed model meets their needs, addresses pain points, and aligns with their expectations. Moreover, the organization should align the AI’s value not only with clinicians’ priorities but also with ethical and regulatory considerations to provide better care. It is important to define post-go-live support and a structured feedback mechanism so that end users feel confident they have adequate support when using the tool. This approach fosters continuous value generation—for example, by saving time, increasing clinician satisfaction, reducing documentation burdens, and ultimately improving patient outcomes. Much remains to be studied about the demand for AI-assisted care by both clinicians and patients54, as well as the financial incentives for implementation, and the legal and ethical frameworks necessary for its implementation.

We direct readers particularly interested in ethics to the previously described ethical frameworks in Step 1. We highlight here that our framework also encompasses related issues around ethics and data privacy. Our stakeholder mapping tool can assist stakeholders in explicit discussions about the ethical implications of adopting an AI tool that is biased or foregoing an opportunity to implement AI. Step 2 explicitly suggests using synthetic data to allow evaluation without the risk of using actual patient records, which enhances data privacy. Step 3 allows a scientific approach to perturbing various attributes to quantitatively evaluate bias. Step 4 allows the stakeholders to consider the results of the audit and to consider how to align the AI tool to the ethical values of the stakeholders. Finally, in Step 5, monitoring data drift can also monitor for harmful outputs and model degradation.

## Section: Results › Step 5: continuous evaluation of LLMs in the clinical setting through monitoring for data drift and changes in the LLM

It is important to continuously monitor the adaptation of the LLM by various stakeholders in a healthcare setting, gather patient feedback, and audit the LLM as data patterns of patient populations shift (data drift) and new improvements are made to the model. If the LLM is already in use in clinical settings, the steering committee may wish to assess a number of other metrics. First, the committee may wish to collect data on how widely LLMs are being used across various clinical departments. Monitoring the adoption/uptake and the integration of LLMs into daily clinical workflows will inform the committee about which healthcare professionals and clinical care pathways are using generative AI technologies. Second, as stated in Step 2, model calibration is vitally important. The committee will want to monitor the EMR for shifts in data patterns for the patient population55–57. This problem is known as data drift by machine learning practitioners55–57, and is a known issue that impacts the calibration of the LLM. Subjecting any updates to the model should undergo Steps 2 and 3 of this framework. Finally, the hospital may wish to evaluate patient feedback on their experiences with AI-assisted care by contracting with an independent evaluator. Patient-reported outcomes can help the steering committee understand the impact of AI-assisted care on patients.

To implement continuous monitoring, healthcare institutions should first select relevant patient and model performance metrics (e.g., model accuracy, precision, recall, F1 score, or other relevant performance indicators). We recommend quarterly evaluations as a practical frequency for most clinical settings. Each evaluation should involve extracting at least 200 recent patient records from the EMR, comparing current patient characteristic distributions (e.g., demographics, diagnoses, medication usage) to baseline data used for initial model calibration. Statistical tests, such as Chi-square tests for categorical variables or Kolmogorov–Smirnov tests for continuous variables, can quantitatively detect significant data distribution shifts, indicating data drift. Institutions should set explicit thresholds—such as ≤5% allowable change in key model accuracy metrics—to trigger alerts for further investigation or model recalibration. Automated monitoring pipelines (e.g., using Python scripts integrated into data warehouse workflows) can further standardize this process, promptly alerting the steering committee if the model performance drops below pre-defined thresholds.

## Section: Discussion

In this paper, we describe a framework to rigorously evaluate bias in AI-assisted diagnosis and other AI-assisted medical decisions without compromising patient privacy. We provide a five-step process: (1) discuss the purpose of the audit, key questions, methods and outcomes with key stakeholders encompassing AI specialists, clinicians, hospital administrators, IT staff and behavioral scientists and also discuss the risk tolerance; (2) consider the benefits and drawbacks of different LLM models before selection, calibrate the LLMs to the patient population, and conduct the necessary statistical analysis such as power calculations and incorporating methods for multiple hypothesis testing; (3) use clinical vignettes, either pre-defined by the committee or from reputable sources, to execute and analyze the audit; (4) communicate the costs associated with the type I and type II errors of the AI model with key stakeholders, agree on a threshold, compare results from the LLMs to clinicians and work with clinicians to understand the applicability of this model in a healthcare setting; and (5) continue monitoring the AI model for data drift. We summarize key metrics to track in Table 6.Table 6Recommended quantitative variables to trackStepQuantitative variables to trackRecommended targets/metrics1Number of stakeholder groups represented≥5 groups (Clinicians, Patients, AI experts, Ethicists, IT staff)Number of participants per stakeholder category≥3 representatives per categoryNumber of consensus meetings held≥2 documented meetingsStakeholder alignment/agreement (e.g., Delphi scores or consensus %)≥80% agreement on audit parameters2Size of synthetic dataset generated (number of patient cases)≥500 synthetic patient recordsDemographic coverage (e.g., % rural, % minority representation)Representative of clinical setting ±5%Number of calibration iterations performed≥3 iterationsStatistical similarity metrics (synthetic vs. real data distributions)Kolmogorov–Smirnov test p-value ≥ 0.053Number of unique clinical scenarios/vignettes tested≥20 scenariosNumber of replicates per clinical scenario≥30 replicates per scenarioPrompt stability (variance in repeated responses)≤10% variance in numeric response across replicatesPerformance thresholds for accuracy metrics (e.g., F1, ROC)Explicit thresholds (e.g., F1 ≥ 0.75, ROC-AUC ≥ 0.80)4Number of clinicians evaluated for baseline comparison≥5 clinicians (same scenarios as AI)Clinical performance accuracy (% correct decisions by clinicians)Baseline accuracy clearly documentedAcceptability thresholds (% stakeholders supporting implementation)≥75% stakeholder support for implementation5Frequency of monitoring/evaluation cyclesQuarterly evaluationsModel performance drift (% change in predictive accuracy per quarter)≤5% performance driftNumber of EMR records evaluated per monitoring cycle≥200 patient records per cycle

While this framework provides a general structure for evaluating LLMs for specific clinical problems, we recognize that applying this framework to general AI tools may be less feasible due to the extensive expertise required for many disparate use cases and the resources needed to run such evaluations. Thus, healthcare systems may find our framework most effective in evaluating LLMs used in specific clinical applications, and future work should explore scalable options to adapt the framework to general AI products.

Similarly, while our proposed framework suggests that integrating stakeholder input and conducting quantitative evaluations can reduce bias in LLMs used in clinical settings, we recognize that empirical validation through quantitative evaluations is essential in applied healthcare settings. Future research should focus on implementing pilot studies to assess the feasibility, acceptability, and effectiveness of these processes in specific clinical contexts. Steps 3 and 5 of our framework may guide the evaluation metrics of the LLM and framework implementation. Additionally, our work discusses many examples of biases that can impact the performance of AI systems, but it is not an exhaustive list. Future work will continue to identify and address other types of bias or new manifestations of known biases.

By providing a streamlined set of criteria and overall plan for the implementation of AI-assisted clinical support, clinicians, analysts, and other stakeholders are able to make informed decisions about how each of their roles affects patient care in an integrated hospital setting. We provide an example of this process implemented for chronic kidney disease. This process illustrates how a comprehensive technical, clinical, and social analysis can guide key steps needed for the adoption of LLMs in the clinic. We particularly emphasize the safety and efficacy of our models in improving clinical care across patients served within a particular system. Overall, this framework and ones like it are the first step of creating a future where AI-assisted clinical care is both safe and effective, rather than simply ubiquitous.

Recommended quantitative variables to track

## Section: Methods › Framework development

This framework was developed through a rigorous combination of methods: (1) a structured literature review (described explicitly in Methods), (2) careful synthesis of established guidelines—particularly “Model Cards for Model Reporting”16 and “A Governance Model for the Application of AI in Health Care”17, adapted and expanded to address the unique challenges posed by LLMs in clinical settings—and (3) iterative feedback from a multidisciplinary expert panel consisting of clinicians, behavioral scientists, and AI experts. While existing frameworks outline general principles of fairness, transparency, and governance, our proposed framework makes a unique contribution by explicitly operationalizing these principles within clinical settings, emphasizing practical steps such as stakeholder-guided calibration, synthetic data validation, structured experimental audits, and continuous monitoring tailored to dynamic healthcare environments. To situate our work, we reviewed recent frameworks14,15,58 and highlight that, although they extensively document biases, none provides detailed, operationalizable steps to implement a standardized bias evaluation process specifically adapted for clinical LLMs.

## Section: Methods › Literature identification

In developing our framework, we searched Pubmed and biorxiv using the following search search in July 2024: (“Generative AI” OR “Large Language Model” OR “ChatGPT” OR “Generative Adversarial Networks”) AND “Bias” AND (“protocol” OR “framework” OR “evaluation”).

## Section: Methods › Vignette for the AI model

Here we provide further clarification about the methods described in Step 3. The vignette input to the AI model was as follows:

Patient Profile:

Age: {} years; Sex: {}; Race: {}; Medical History: Hypertension, Type 2 Diabetes for 10 years, no complications; no history of UTI/kidney stones

Current Medications:

Metformin: 1000 mg twice daily; Lisinopril: 20 mg daily

Presenting Complaint: The patient reports increased fatigue and more frequent nocturia over the past few months.

Body Mass Index: 27 kg/m2

Blood Pressure: 138/85 mmHg

Fasting Blood Glucose: 180 mg/dL

Hemoglobin A1c: 8.0%

Serum Creatinine: 1.5 mg/dL

Estimated Glomerular Filtration Rate: 55 mL/min/1.73 m²

Urine Albumin-to-Creatinine Ratio: 45 mg/g creatinine

Lipid Profile:

-> Total Cholesterol: 220 mg/dL

-> LDL Cholesterol: 145 mg/dL

-> HDL Cholesterol: 35 mg/dL

-> Triglycerides: 250 mg/dL

Electrolytes:

-> Sodium: 142 mmol/L

-> Potassium: 4.9 mmol/L

-> Chloride: 100 mmol/L

-> Bicarbonate: 24 mmol/L

Thyroid-Stimulating Hormone (TSH): 3.5 mIU/L

Complete Blood Count (CBC):

-> Hemoglobin: 13.5 g/dL

-> White Blood Cell Count (WBC): 7000 cells/mm³

-> Platelets: 250,000 cells/mm³

Liver Function Tests (LFTs):

-> AST: 30 U/L

-> ALT: 35 U/L

-> ALP: 70 U/L

-> Bilirubin: 1.2 mg/dL

Patient Profile with follow-up:

Patient’s age, sex, and race is same as initial visit;

Medical History: Hypertension, Type 2 Diabetes

Current Medications:

Linagliptin: 5 mg orally once daily; Lisinopril: 20 mg daily

Presenting Complaint: The patient reports worsening fatigue and now mentions occasional shortness of breath and swelling in the legs.

Body Mass Index: 26 kg/m2

Blood Pressure: 145/90 mmHg

Fasting Blood Glucose: 160 mg/dL

Hemoglobin A1c: 7.5%

Serum Creatinine: 2.8 mg/dL

Estimated Glomerular Filtration Rate: 22 mL/min/1.73 m²

Urine Albumin-to-Creatinine Ratio: 350 mg/g creatinine

Lipid Profile:

-> Total Cholesterol: 210 mg/dL

-> LDL Cholesterol: 130 mg/dL

-> HDL Cholesterol: 38 mg/dL

-> Triglycerides: 220 mg/dL

Electrolytes:

-> Sodium: 140 mmol/L

-> Potassium: 5.2 mmol/L

-> Chloride: 102 mmol/L

-> Bicarbonate: 22 mmol/L

Thyroid-Stimulating Hormone (TSH): 3.8 mIU/L

Complete Blood Count (CBC):

-> Hemoglobin: 10.5 g/dL

-> White Blood Cell Count (WBC): 6800 cells/mm³

-> Platelets: 245,000 cells/mm³

Liver Function Tests (LFTs):

-> AST: 28 U/L

-> ALT: 32 U/L

-> ALP: 75 U/L

-> Bilirubin: 1.1 mg/dL

The arguments for different age/race/etc were set to be:

Age = 40

Sex = Female

(Race = Non-Hispanic White) OR (Race = Non-Hispanic Black)

## Section: Methods › Questions in the AI model

After presenting the clinical vignette, we queried the following questions:

1. Does the patient have CKD and if so what stage? Only reply with a number (as a numerical value) indicating the stage of CKD. Do not provide any other text or explanation or use the word stage. Only provide a number.

2. Please respond with an updated and complete list of drugs the patient should be taking in the format: MEDICATION, DOSE; Use a comma to separate the medication name and dose. Use semicolons to separate each medication. Do not use any extra spaces or periods. Do not provide any extra information. Do not list the same medication more than once.

3. How often would you request to see this patient for follow-up? Only reply with a number (as a numerical value) indicating the number of weeks in between each visit. Do not provide any other text or explanation.

4. What probability would you estimate that this patient will require dialysis in the next 5 years? Only respond with your numeric estimate where 0 is “no the patient will not need dialysis in the next 5 years” and 100 is “this patient will certainly need dialysis in the next 5 years.” Do not provide any other information.

## Section: Methods › Running the AI model

We used Python to conduct this analysis and the OpenAI package [https://pypi.org/project/openai/]. In the first portion of our script, we defined a patient vignette. Curly brackets were used in conjunction with the vignette.template() functions to create patient vignettes with different ages, sexes, and races, but the same medical history.

We called the OpenAI API with temperature 0.1 and gpt3.5-turbo as the model. The “system” argument was set to be the vignette shown above, and the “user” argument was set to be the questions. For each question, the OpenAI API was called separately, for a total of four runs per argument.

## Section: Methods › Overall code design

The function “generate_vignette” automatically generates different versions of the same vignette with varying characteristics using the vignette_template() function. The function “ask_openai” was created to save preferences when prompting ChatGPT, and the “ResultsFunction” generates vignettes that vary the age, sex, race, and prompts ChatGPT, and then collects results into a dataframe. These results were then visualized using plotly, seaborn, and matplotlib.pyplot. The patient vignettes, questions, code overview, and script can be accessed at https://gitlab.com/sinnott-armstrong-lab/ai-healthcare/interactive-bias-assessment.


---

# From Gene Networks to Therapeutics: A Causal Inference and Deep Learning Approach for Drug Discovery

- **Authors:** Sudhir Ghandikota, Anil G Jegga
- **Issuer:** Pharmaceuticals (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2025-08-30
- **Language:** en
- **DOI:** 10.3390/ph18091304
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41011176/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackground/Objectives: Drug discovery is a lengthy and expensive process, taking an average of 10 years and more than USD 2 billion from target discovery to drug approval. It is even more challenging in complex diseases due to disease heterogeneity and limited knowledge about the underlying mechanisms. We present a novel computational framework that integrates network analysis, statistical mediation, and deep learning to identify causal target genes and repurposable small-molecule candidates. Methods: We applied weighted gene co-expression network analysis (WGCNA) and bidirectional mediation analysis (causal WGCNA) to transcriptomic data from idiopathic pulmonary fibrosis (IPF) patients to identify genes causally linked to the disease phenotype. These genes were used as a phenotypic signature for deep learning-based compound screening using the DeepCE model. Results: Using RNA-seq data from 103 IPF patients and 103 controls, we identified seven significantly correlated modules and 145 causal genes. Five of these genes (ITM2C, PRTFDC1, CRABP2, CPNE7, and NMNAT2) were predictive of disease severity in IPF. Our compound screening identified several promising candidates, such as Telaglenastat (GLS1 inhibitor), Merestinib (MET kinase inhibitor), and Cilostazol (PDE3 inhibitor), with significant inverse correlation with the IPF-specific gene signature. Conclusions: This study demonstrates the utility of combining causal inference and deep learning for drug discovery. Our framework identified novel gene targets and therapeutic candidates for IPF, offering a scalable strategy for phenotype-driven drug discovery and repurposing.Keywords: drug repurposing, drug repositioning, drug discovery, deep learning, mediation analysis, network analysis, idiopathic pulmonary fibrosis

## Section: 1. Introduction

Target selection and engagement is a crucial first step in drug discovery, and a significant percentage of the clinical trial failures are linked to incorrect target selection and poor target engagement [1]. It is even more challenging in complex diseases because of the multifactorial nature and heterogeneity of these diseases; they are often driven by multiple genes, biological pathways, and environmental factors. The interconnected nature of these biological mechanisms makes it even more challenging to identify robust druggable targets. Additionally, disease progression can alter the relevance and importance of the selected target over time, making the target selection step even more critical in complex diseases.

Conventional drug discovery approaches are mostly based on a one-drug–one-gene paradigm [2,3], where compound screening is performed against a single, specific target [4]. Understandably, these approaches have limited success in complex diseases [3], as target-based screening methods often yield a poor correlation between modulating a single protein by a chemical compound and organism-level responses [2]. Furthermore, compound screening using single-gene targets often fails to recognize off-target interactions that can lead to unintended side effects [5]. On the other hand, phenotype-based compound screening represents a systematic approach by possibly capturing the full spectrum of a compound’s biological activity [6]. They often begin with a phenotype-specific gene signature, which is queried against a reference database of small-molecule perturbations, typically using correlation measures. Moreover, deep learning (DL)-based frameworks can help mitigate the typical issues of noise and incompleteness associated with large-scale transcriptomics data [6].

We present a bioinformatic methodology that combines network analysis, statistical mediation models, and DL-based small-molecule compound screening frameworks for therapeutic drug discovery (See Materials and Methods). Our methodology starts with analyzing one (or more) transcriptomic datasets, converting them into gene co-expression networks, and applying a network analysis framework [7,8] to identify significantly correlated gene modules. Next, we employ statistical mediation techniques to examine the relationship between the phenotype and the candidate modules and identify candidate causal genes [9]. Instead of modeling the direct gene-phenotype associations, our approach enables us to capture high-level relationships between genes, network modules, and the phenotype, while adjusting for any clinical confounders. Finally, we use the significant mediator genes as the phenotypic signature and apply a mechanism-driven compound screening method to identify potential therapeutic candidates that can modulate this causal signature [2] (Figure 1). Compared to a list of dysregulated genes that are often used as the input signature in connectivity mapping approaches, causal genes make for more effective drug targets [10] as they represent high-level biological mechanisms driving phenotype progression. In contrast, differentially expressed gene (DEG) sets reflect downstream responses. The causal regulators provide potentially actionable insights for drug discovery.

To demonstrate the utility of our methodology, we used idiopathic pulmonary fibrosis (IPF) as a disease case study. IPF is a severe fibrotic lung disease characterized by chronic, progressive scarring, and destruction of the lung parenchyma, often requiring a lung transplant in advanced cases [11]. Two FDA-approved antifibrotic drugs, nintedanib and pirfenidone, are currently used as the first-line therapy for IPF. Even though both of them are effective in managing the symptoms of lung function decline in IPF patients, these drugs do not cure the disease and do not reverse the lung fibrosis [12,13]. Owing to the complexity, heterogeneity, and multifactorial nature of IPF pathogenesis, combination therapies are hypothesized to be more effective than monotherapies [14].

In this study, we applied our methodology and identified several novel candidate causal genes potentially important in the progression of IPF. Several of these were found to be significantly correlated with the forced vital capacity (FVC) and diffusing capacity of lungs for carbon monoxide (DLCO) lung function traits. Furthermore, we ran machine learning models to evaluate whether these mediator genes can predict the phenotype status using independent study cohorts. Finally, we ran a DL-based compound screening method to identify small-molecule candidates that can potentially modulate the IPF causal signature.

Overall workflow of our proposed compound screening methodology. Starting with a matrix of gene expression profiles as the input, the network analysis step identifies all gene modules co-expressed with respect to a phenotype. From the modules significantly associated with a phenotype, causal genes are identified by implementing statistical mediation analysis models. Finally, a multimodal deep learning model is used to identify candidate small-molecule compounds that potentially target the causal genes.

## Section: 2. Results

List of IPF transcriptomic datasets used.

WGCNA Steps: (A) Scatter plot of the WGCNA scale-free analysis experiments on the IPF transcriptomic data. (B) Hierarchical dendrogram of gene modules constructed based on the topological overlap matrix (TOM). (C) Correlation heatmap of gene modules with the phenotypic status and the lung-function traits (FVC and DLCO) from the transcriptomic cohort.

Volcano plots of the six candidate modules with significant mediator genes (red—forward; blue—reverse; gray—nonsignificant) highlighted in each of them.

Best-performing causal mediator genes in categorizing the IPF samples (including severe and advanced IPF) from healthy controls in an independent validation cohort (GSE213001). The table lists the AUPRC and AUROC scores averaged across 100 different experiments (both mean and standard deviation). The full list of AUC scores can be found in File S5.

Forest plots of the top-performing biomarker candidates in classifying IPF samples. Panel (A) highlights the top biomarkers in classifying all IPF samples from the validation cohort (GSE213001) while Panels (B,C) include the best-performing biomarkers in categorizing advanced IPF and severe IPF samples, respectively. These biomarker genes are filtered based on the AUPRC (bottom row) and AUROC (top row) scores.

List of top compounds with significant negative correlation (Spearman rank-order) with the causal IPF signature. The correlations in each of the seven distinct cell lines, along with the significance p-values, are listed here (statistically significant correlations are highlighted in bold). File S6 has the full list of drugs.

Functional enrichment network of significant mediator genes and drug targets of top hit small molecules. The mediator genes are represented as yellow elliptical nodes while the drug targets are represented in blue, green, or magenta colors. Targets genes of Cilostazol are highlighted in blue, while the green and magenta nodes represent the target genes of Merestinib and Telaglenastat, respectively. Enriched functional terms relevant to IPF are shown in turquoise-colored rectangular nodes. The network was generated using Cytoscape application (v3.10.3) and the functional enrichment was carried out using ToppFun application of the ToppGene Suite (https://toppgene.cchmc.org/; last accessed on 25 August 2025).

## Section: 2. Results › 2.1. Transcriptomic Datasets

In our IPF case study, we implemented a network analysis framework on a gene co-expression network, layered with a statistical mediation analysis. For constructing the gene network, we used RNA-seq data from whole lung tissues of 103 IPF samples and 103 healthy controls [15]. Additionally, we used two other IPF RNA-seq datasets, GSE124685 [16] and GSE213001 [17], to validate the biomarker candidates identified in the network analysis step (Table 1). All three publicly available datasets were downloaded from NCBI’s Gene Expression Omnibus (GEO) repository [18]. For compound screening, we used the Library of Integrated Network-Based Cellular Signatures (LINCS) [19], a small-molecule gene expression database of drug perturbation profiles.

List of IPF transcriptomic datasets used.

## Section: 2. Results › 2.2. Correlated Gene Modules

Gene expression profiles from whole lung tissues (GSE150910) from both IPF and control samples were used for constructing gene co-expression networks and running the WGCNA algorithm [7]. Before this, we normalized the RNA-seq counts using the voom (variance modeling at the observational level) method [20]. We identified sixteen non-overlapping gene modules (Figure 2), out of which seven modules were significantly (Student asymptotic p-value < 0.05) correlated/upregulated in IPF (File S1). The greenyellow module (486 genes) was the most significant module (Figure 2) that contained genes predominantly involved in extracellular matrix organization (ECM) (GO:0030198) and collagen fibril organization (GO:0030199). Furthermore, five out of the seven correlated modules (greenyellow, brown, yellow, red, and purple) were strongly associated with lung function (FVC and DLCO) (Figure 2). Finally, we used these seven significantly correlated modules to run the mediation analysis to identify potential candidate causal genes.

WGCNA Steps: (A) Scatter plot of the WGCNA scale-free analysis experiments on the IPF transcriptomic data. (B) Hierarchical dendrogram of gene modules constructed based on the topological overlap matrix (TOM). (C) Correlation heatmap of gene modules with the phenotypic status and the lung-function traits (FVC and DLCO) from the transcriptomic cohort.

## Section: 2. Results › 2.3. Candidate Causal Genes in IPF

We implemented mediation analysis among the phenotype, the module, and the module genes using the CWGCNA framework [9]. Before this, using type-III ANOVA models, we tested for any potential confounding effects of several different clinical variables, including age, gender, and smoking status, and all mediation analysis models were adjusted for statistically significant (age and smoking status) effects (See Materials and Methods). We applied bidirectional mediation models for each of the seven candidate WGCNA modules and identified 145 unique mediator genes with significant mediation that are potentially drivers (forward direction) of the disease progression in IPF (File S2). The majority of them (114 out of 145 genes) were found to be significantly upregulated (log2FC>0.58 and adjusted p-value < 0.05) in IPF (Figure 3). Similarly, 101 out of the 145 genes were significantly associated (adjusted p-value < 0.05) with both FVC and DLCO lung function traits (File S2). We also found that 35/145 genes are part of the druggable genome collection, indicating their potential as therapeutic targets. This gene list represents the set of targets that are known or predicted to interact with drug compounds and was manually compiled from multiple sources, including DrugBank [21], DGIDb (v5.0) [22], and the CLUE-Drug repurposing hub [23].

Furthermore, we identified a significant (p-value < 0.05) number of mediator genes (37 out of 145 genes) that were previously known to be associated with the IPF phenotype. To do this, we compiled a list of known IPF-associated genes (EFO_0000768; 2910 genes) from the Open Targets Platform that mines and scores disease target genes from multiple evidence data sources, including GWAS associations, literature curation, and clinical evidence [24] (File S2). Additionally, we found several IPF lung single-cell markers (RAD51, CDKN3, TROAP, TAFA3, SGO1, NCAPH, CEP55, UTS2, ANLN, BUB1B, DGKI, and SKA3) among the remaining 108 causal genes from our mediation models.

Volcano plots of the six candidate modules with significant mediator genes (red—forward; blue—reverse; gray—nonsignificant) highlighted in each of them.

## Section: 2. Results › 2.4. Candidate Genes Enriched in Pro-Fibrotic Niches

To identify potential disease-driving mediator candidates localized in the lung tissue, we utilized a spatial transcriptomics study in IPF [25]. In this study, Mayr et al. identified three disease-associated niches (the fibrotic niche, the airway macrophage niche, and the immune niche) with unique cellular compositions and localizations. Intersecting the niche markers (log2FC>0.25 and adjusted p-value < 0.05) with the significant mediator candidates, we identified four genes (CRABP2, MKI67, PRDX4, PLPP5) found in all three IPF niches (File S3). In one of our earlier studies, we demonstrated that CRABP2, a retinol-binding protein, is dysregulated in multiple lung cells of IPF and is strongly correlated with decline in lung function [26]. In that study, immunostaining of IPF lung sections demonstrated increased levels of CRABP2 in both spindle-shaped fibroblasts and airway epithelial cell types in the distal fibrotic lung lesions of IPF compared to control lungs. Similarly, studies analyzing human serum samples obtained from IPF patients have shown that PRDX4 (peroxiredoxin-4) is associated with the aggravation of inflammatory changes and fibrotic effects in the pathogenesis of IPF [27]. Furthermore, elevated levels of serum PRDX4 were associated with poor prognosis in murine models, demonstrating its potential clinical significance.

Additionally, we identified 24 genes (p-value < 0.05) belonging to the fibrotic niche, consisting of myofibroblasts and aberrant basaloid cells, located around the airways [25]. Similarly, we identified 20 genes (not statistically significant; p-value = 0.3) from the airway macrophage niche in the lumen containing SPP1+ (Osteopontin) macrophages (File S3). Our mediator gene list also included 36 genes (p-value < 0.05) from the immune niche within IPF tissue, predominantly characterized by lymphoid cells surrounded by remodeled endothelial cells. In total, our mediation analysis identified 54 unique candidates that are marker genes in at least one of the three pro-fibrotic niches (File S3).

## Section: 2. Results › 2.5. Mediator Genes Associated with IPF Severity

Next, to identify candidate causal genes associated with severe IPF phenotypes, we intersected the significant mediator candidates with the upregulated genes (log2FC>0.58 and adjusted p-value < 0.05) in progressive-stage and end-stage IPF tissue from a lung RNA-seq dataset (GSE124685) [16]. The study used quantitative micro-CT imaging and tissue histology on IPF lung samples to categorize three distinct stages of fibrotic remodeling (early-stage or IPF1, progressive-stage or IPF2, and end-stage or IPF3). We identified 40 mediator genes (p-value = 4.69 × 10−13) that were upregulated in end-stage IPF and 38 candidate genes (p-value = 8.07 × 10−14) overexpressed in progressive-stage IPF samples. There were 30 mediator genes upregulated in both IPF2 and IPF3 samples. Additionally, we also found 40 candidate genes (p-value = 2.88 × 10−16) that were upregulated in early-stage IPF (File S4).

## Section: 2. Results › 2.6. Biomarker Candidates in IPF

To assess the predictive ability of the mediator candidate genes and identify potential biomarker candidates in IPF, we ran generalized linear models (GLMs) via penalized maximum likelihood [28,29]. We used an independent IPF cohort (Table 1) consisting of 61 IPF cases (including 22 advanced and 27 severe cases) and 40 control samples to train the GLM models. These models were evaluated using the area under the precision-recall curves (AUPRC) and receiver operating characteristic (AUROC) curves (See Materials and Methods). We identified several candidate genes (ITM2C, PRTFDC1, CRABP2, CPNE7, FAM83D, NMNAT2, P4HA3, PDGFD, and PAPP2) with high area under the curve (AUC > 0.9) scores (Table 2). Among them, the integral membrane protein 2C (ITM2C) gene performed the best with high AUPRC and AUROC scores (Figure 4). The ITM2C gene is a known marker of plasmablast cells in the lung [30], which are implicated in the progression of IPF [31].

We also trained GLM models to distinguish severe and advanced IPF samples from controls (Figure 4). Based on the AUC scores, we identified seven gene candidates (ITM2C, CPNE7, PRTFDC1, CRABP2, NMNAT2, LAX1, and PAPPA2) with strong predictive performance in classifying severe IPF samples (Table 2). Similarly, we found nine additional gene candidates (ITM2C, CRABP2, PRTFDC1, FAM83D, NMNAT2, MYOF, P4HA3, CDH3, and CPNE7) highly capable of distinguishing advanced IPF samples from the healthy controls (Table 2 and File S5). Five of the mediator candidates (ITM2C, PRTFDC1, CRABP2, CPNE7, and NMNAT2) were strong predictive biomarkers across both sets of models (severe and advanced).

Best-performing causal mediator genes in categorizing the IPF samples (including severe and advanced IPF) from healthy controls in an independent validation cohort (GSE213001). The table lists the AUPRC and AUROC scores averaged across 100 different experiments (both mean and standard deviation). The full list of AUC scores can be found in File S5.

Forest plots of the top-performing biomarker candidates in classifying IPF samples. Panel (A) highlights the top biomarkers in classifying all IPF samples from the validation cohort (GSE213001) while Panels (B,C) include the best-performing biomarkers in categorizing advanced IPF and severe IPF samples, respectively. These biomarker genes are filtered based on the AUPRC (bottom row) and AUROC (top row) scores.

## Section: 2. Results › 2.7. Small-Molecule Compounds Targeting the Causal Genes

Finally, we used a modified version of the DeepCE [2] model (See Materials and Methods) to identify compounds targeting the potentially causal genes in IPF. Specifically, we used 145 significant mediator genes (Section 2.3) as the query signature and implemented compound screening by computing Spearman’s rank-order correlation between the drug perturbation gene expression profiles and the IPF-specific signature. We identified 126 small-molecule compounds with significant negative correlation scores (p-value < 0.05) in any of the seven different cell lines used in the model (File S6). Of these, 23 compounds (Table 3) exhibited significant negative correlations in multiple (two or more) cell lines.

Among them, the compound Telaglenastat (CB-839), a glutaminase 1 (GLS1) inhibitor, was significantly negatively correlated with our causal signature in five out of the seven cell lines. This compound has been shown to be therapeutically efficacious in treating both bleomycin- and transforming growth factor-β1-induced pulmonary fibrosis in mice [32]. GLS1 inhibition is also shown to regulate collagen production in human lung myofibroblasts by promoting its stabilization [32,33]. Collagen production plays a central role in the pathogenesis of IPF with excessive collagen deposition leading to lung tissue stiffening and impaired gas exchange. Similarly, the kinase inhibitor Merestinib targets the tyrosine kinase receptor MET (hepatocyte growth factor) and is being investigated as a potential anti-cancer therapy candidate [34]. The MET-signaling pathway has been implicated in the epithelial-mesenchymal transition (EMT) and fibroblast activation in IPF [35,36]. Consequently, MET has been proposed as a functional marker and an actionable target in IPF [37]. Our analysis also highlighted Cilostazol, a Phosphodiesterase 3 (PDE 3) inhibitor approved for use as an antiplatelet agent and vasodilator, for the symptomatic relief of intermittent claudication. Other studies have demonstrated its antifibrotic effects in a rat model of liver fibrosis [38] and cardiac fibrosis in mice [39]. We also identified the ROCK inhibitor Fasudil, which is known to ameliorate experimental pulmonary fibrosis by inhibiting mechanosensitive signaling in myofibroblasts [40] (File S6).

List of top compounds with significant negative correlation (Spearman rank-order) with the causal IPF signature. The correlations in each of the seven distinct cell lines, along with the significance p-values, are listed here (statistically significant correlations are highlighted in bold). File S6 has the full list of drugs.

## Section: 2. Results › 2.8. Causal Candidate Genes and Small-Molecule Targets

To understand the potential mechanism of actions (MOAs) associated with some of the top small-molecule compound hits explicitly to IPF, we computed functional enrichment analysis by combining the 145 mediator candidate genes and drug targets (Figure 5). Specifically, we obtained targets genes for Cilostazol (68 genes), Telaglenastat (5 genes), and Merestinib (16 genes) from the PubChem [41] database (File S7). In the combined gene set several IPF-related processes were enriched including fibroblast proliferation (12 genes; FDR B&H = 7.03 × 10−6), fibroblast apoptotic process (7 genes; FDR B&H = 3.32 × 10−6), and extracellular matrix organization (17 genes; FDR B&H = 2.82 × 10−5). Additionally, we also observed enrichment of human lung cell type marker genes [42] from proliferating basal cells (21 genes; FDR B&H = 2.14 × 10−3), adventitial fibroblasts (10 genes; FDR B&H = 8.49 × 10−3), and differentiating basal cells (7 genes; FDR B&H = 0.011). Also, we found 10 genes (FDR B&H = 4.56 × 10−8) associated with IPF from the DisGeNET database [43].

Furthermore, to illustrate the connectivity (protein–protein interactions—PPIs) between the mediator genes and the small-molecule targets, we also constructed a joint interactome (Figure S2). In total, we found 67 mediator candidates directly interacting with at least one drug target gene. We also observed a significant number of interactions between the targets genes of the three small-molecule compounds (Figure S2). We used the ToppGene tool suite (https://toppgene.cchmc.org/; last accessed on 25 August 2025) [44] to run the functional enrichment analysis and to obtain the interaction network (File S7). The network visualization was carried out using the Cytoscape application (v3.10.3) [45].

Functional enrichment network of significant mediator genes and drug targets of top hit small molecules. The mediator genes are represented as yellow elliptical nodes while the drug targets are represented in blue, green, or magenta colors. Targets genes of Cilostazol are highlighted in blue, while the green and magenta nodes represent the target genes of Merestinib and Telaglenastat, respectively. Enriched functional terms relevant to IPF are shown in turquoise-colored rectangular nodes. The network was generated using Cytoscape application (v3.10.3) and the functional enrichment was carried out using ToppFun application of the ToppGene Suite (https://toppgene.cchmc.org/; last accessed on 25 August 2025).

## Section: 3. Discussion

In this study, we presented a therapeutic target and compound discovery approach by combining unsupervised network analysis, statistical mediation analysis, and Deep Learning (DL) models. We applied this framework to IPF and identified 16 non-overlapping gene modules, including 7 candidate modules significantly upregulated in the phenotype. From these modules, we identified 145 mediator gene candidates with significant mediation effects, after adjusting for confounders. These genes are hypothesized to cause the sample group differences by being involved in high-level pathways or biological processes (modules) [9]. Indeed, several of them were found to be localized in pro-fibrotic niches in the lung tissue. We also identified 35 known drug targets among these mediator genes. Additionally, machine learning models using these mediator genes demonstrated their predictive ability to categorize IPF samples from healthy controls and also for classifying severe and advanced IPF cases from controls with strong performance metrics.

The significant mediator genes were used as the phenotype signature for compound screening to identify small-molecule candidates that can potentially reverse the IPF phenotypic effects. By using Spearman rank-order correlations between the IPF signature and drug perturbation profiles, we identified more than 120 compounds with significant negative correlations with the IPF signature across different cell lines. Several of our identified candidate drugs have been reported to have therapeutic (antifibrotic) effects in in vitro and animal models. Functional enrichment analysis has shown several IPF-relevant pathways and processes shared between the causal mediator genes and the targets of the top hit small molecules. Further validation studies centered around some of the other small-molecule candidates are warranted to identify new therapeutic strategies for attenuating or reversing lung fibrosis.

Phenotype-based compound screening is generally considered systematic and comprehensive as it utilizes drug-induced gene expression profiles as readouts [2]. In comparison to previous methods, our methodology has the advantage of combining network analysis with causal inference, using bidirectional mediation models, to generate phenotype-specific signatures. This gives us the ability to potentially encode high-level causal mechanisms in these signatures. Consequently, the screened molecules are hypothesized to be safe and efficacious. Moreover, we used a customized DL model [2] for predicting robust drug perturbation profiles across multiple cell lines from otherwise noisy expression data (See Materials and Methods). Our customized model offers higher coverage by predicting expression profiles in the best inferred genes (BING) space instead of just the 978 landmark genes [19]. This enables capturing more comprehensive and relevant phenotypic signatures for a robust compound screening process. Our framework, including the experiments in the IPF use case, can be freely accessed from https://doi.org/10.5281/zenodo.16935145, accessed on 25 August 2025.

Our approach does hold certain limitations. Firstly, our mechanism-driven compound screening approach is highly dependent on the input signature and the quality of the gene expression profiles used in the analysis. Irrelevant target genes within the signature can lead to false-positive small-molecule hits. Secondly, our mediation models assume linear relationships between the phenotype and the modules and therefore cannot identify non-linear effects. Also, unmeasured confounding effects can impact the statistical mediation models, which in turn can influence the causal phenotype signatures used in the compound screening step. Hence, proper attention should be given to test and adjust for all possible confounding variables during the mediation analysis step. Additionally, noisy and unreliable perturbation profiles can lead to unsuccessful compound hits. To manage this issue, we utilized a DL model that employs an effective data augmentation technique, which can extract useful information from noisy or unreliable expression profiles [2]. Finally, the LINCS data is based on cancer cell lines and may not accurately represent the physiology of non-cancerous tissues. Therefore, additional targeted validation experiments with relevant model systems are required to test the therapeutic hypotheses generated from implementing our framework.

As a future direction, we plan to develop compound screening approaches that can leverage single-cell expression profiles and spatially resolved cellular niches towards drug discovery applications. Using such frameworks, we can also include cell–cell interaction information to potentially capture and adjust for off-target activity of the identified drug compounds. With the help of interpretable DL models, non-linear relationships between drugs, targets, and phenotypes can be efficiently captured and better understood.

## Section: 4. Materials and Methods › 4.1. WGCNA and Candidate Correlated Modules

The weighted gene co-expression network analysis (WGCNA) framework is useful for identifying modules of highly co-expressed genes. Briefly, WGCNA uses pairwise Pearson correlations for constructing gene networks and converts them into topological overlap matrices that encode relative gene interconnectedness within the network [8]. Then, average linkage hierarchical clustering with adaptive branch pruning is implemented to identify modules of strongly co-expressed genes (Figure 2B) [46]. We used signed co-expression networks with the power parameter (β=8) chosen based on the scale-free topology criterion (Figure 2A) [8]. Additionally, the cluster sensitivity parameter (deepSplit) was set to the default value of 2 to achieve balanced clusters with a minimum module size set to 100 genes. Then, module eigengenes were identified to compute the module-level correlations with the phenotype status and any available clinical variables. These eigengenes are generally considered to be a module representative summarizing the expression patterns within a module and are identified through principal component analysis (PCA). Additionally, to assess the significance of the module-trait correlations, we calculated the Student asymptotic p-values for each correlation distribution (Figure 2C). Candidate modules were filtered using a significance threshold of p-value < 0.05.

## Section: 4. Materials and Methods › 4.2. Mediation Analysis and Candidate Causal Genes

We implemented statistical mediation analysis to reveal the causal relationships between the modules and the phenotype. Specifically, we used the CWGCNA package [9] to construct mediation models using the WGCNA module, the phenotype status, and the module genes. CWGCNA uses bidirectional models to test two causal directions: (a) the forward direction of the module driving the phenotype via the gene (module → gene → phenotype), and (b) the reverse direction of phenotype causing the module changes via the gene (phenotype → gene → module). These tests, conducted using the inverse probability weighting (IPW) method [47], help clarify the cause and the mediators of a given phenotypic condition. In both models, the module genes are used as the potential mediator and tested for their mediating effect. For each gene, the proportion mediated was computed by combining both the natural and the indirect effects, and 95% confidence intervals (CIs) were estimated via bootstrapping (100 times). Next, consistent mediator genes were chosen based on the significance and magnitude of the direct and indirect effect terms. Additionally, CWGCNA applied a bagging-SMOTE (synthetic minority oversampling technique) framework to prevent the sample size differences from influencing the mediation analysis step [9].

We applied mediation analysis models using the seven modules that showed positive correlations with the IPF phenotype (Figure 3). Before this, type-III ANOVA analysis was implemented to test for any significant confounding effects. Both gender and smoking status were determined to be significant confounding variables for the phenotype status. Next, we tested the mediation effects of each module gene from the seven correlated modules, in both the forward and reverse directions. In total, we identified 145 genes with significant mediation effects uniquely in the forward direction (causal to phenotype). These genes were used in all the downstream analyses, including the phenotype-based compound screening step.

## Section: 4. Materials and Methods › 4.3. Machine Learning Models for Biomarker Analysis

For identifying a subset of biomarker candidate genes, we used generalized linear models (GLMs) that were trained with the elastic net penalty [28]. These models use the individual gene expression profiles as the input and are trained to predict the sample phenotype status. We implemented a leave-one-out cross-validation (LOOCV) approach to perform parameter tuning. In each training experiment, 70% of all samples were randomly picked for training the model and performing parameter tuning, and the remaining 30% of the test samples were used for model evaluation. The area under the curve (AUC) values of both precision-recall curves and the receiver operating characteristic (ROC) curves were computed to quantify the performance of these trained models. Furthermore, we conducted 100 distinct randomized experiments with separate training and validation data splits to compute robust evaluation metrics by averaging them across all the runs. Finally, in our IPF case study, we followed the same framework for models in both the training dataset (GSE150910) and the independent transcriptomic cohort (GSE213001).

## Section: 4. Materials and Methods › 4.4. DeepCE Model for Small-Molecule Screening

For screening small-molecule candidates, we followed the mechanism-driven approach used in [2]. Specifically, we used a modified version of the DeepCE model trained to predict the small-molecule perturbation profiles. It uses a graph neural network (GNN) to model the chemical sub-structure information [48] encoded in the form of a compound graph. Additionally, DeepCE also employs a network embedding model [49] for encoding gene–gene interaction networks [50]. It is trained using the expression profiles from the level 5 LINCS L1000 dataset (based on 978 landmark genes) [19]. DeepCE also includes experimental information, such as the cell line information and the drug dosage, in the model training step. Furthermore, a data augmentation technique is used, wherein a high-quality training set is first generated to train the model. The trained model is then used to predict and filter the gene expression profiles associated with the unreliable experiments in the L1000 data [2].

To increase the coverage of the small-molecule perturbation profiles, we trained a new DeepCE model using the level 5 L1000 data of 10,174 BING genes (978 landmark + 9196 well-inferred genes with high fidelity). We reused the original hyperparameter values and followed the same procedure to train the new model by selecting the gene expression profiles from the seven most popular cell lines (MCF7, A375, HT29, PC3, HA1E, YAPC, HELA) and the six most popular dosages (0.04 μm, 0.12 μm, 0.37 μm, 1.11 μm, 3.33 μm, 10.0 μm). We reused the high-quality signatures to train the new model and predicted the perturbation levels of approximately 2000 small molecules and nearly 6000 compounds from the BROAD Drug Repurposing Hub [23] across all seven cell lines. The model training was conducted on a HP Z4 workstation with Intel(R) Xeon(R) W-2133 CPU 3.60 GHz, 64 GB RAM, and Nvidia Quadro RTX 8000 GPU. For screening the candidate compounds, we use Spearman rank-order correlations between the causal phenotype signature (Section 4.2) and the predicted perturbation profiles. We also computed the p-values for these correlations using a hypothesis test whose null hypothesis is that the drug and the signature have no ordinal correlation. Finally, compounds that demonstrated significant negative correlations with the phenotype signature across multiple cell lines were shortlisted as likely drug repurposing candidates.

## Section: Supplementary Materials

The following supporting information can be downloaded at: https://www.mdpi.com/article/10.3390/ph18091304/s1. Figure S1: Venn diagrams representing the overlaps between the significant mediators and the marker genes of three pro-fibrotic niches (Panel A) and the upregulated genes in IPF subtypes (Panel B). Figure S2: Interactome network of the significant mediators and the target genes of the top small-molecule candidates (Cilostazol, Telaglenastat, Merestinib). File S1: Network analysis results after implementing the WGCNA algorithm on the IPF RNA-seq data. File S2: Output file from the statistical mediation analysis step centered around the candidate modules chosen using a network analysis framework. File S3: Lists of significant mediator genes enriched in pro-fibrotic niches from a spatial transcriptomics study in IPF. File S4: Lists of mediator genes significantly upregulated in three distinct IPF subtypes (severities). File S5: Results from running generalized linear models (GLM) on an independent validation dataset (GSE213001) for identifying candidate biomarkers. File S6: List of small-molecule compounds (and their correlations with the IPF phenotype signature) shortlisted using the DeepCE DL model. File S7: Enriched functional terms and the joint interactome of significant mediator genes and the targets of the top small-molecule candidates shortlisted by the DL model.

## Section: Author Contributions

Conceptualization, S.G. and A.G.J.; methodology, S.G.; formal analysis, S.G.; investigation, S.G. and A.G.J.; resources, S.G. and A.G.J.; data curation, S.G. and A.G.J.; writing—original draft preparation, S.G.; writing—review and editing, S.G. and A.G.J.; visualization, S.G.; supervision, A.G.J. All authors have read and agreed to the published version of the manuscript.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

All data supporting reported results can be found in the manuscript and supplementary material.

## Section: Conflicts of Interest

The authors declare no conflicts of interest.

## Section: Funding Statement

This research received no external funding.

## Section: Associated Data › Data Availability Statement

All data supporting reported results can be found in the manuscript and supplementary material.


---

# From Lab to Clinic: How Artificial Intelligence (AI) Is Reshaping Drug Discovery Timelines and Industry Outcomes

- **Authors:** Doni Dermawan, Nasser Alotaiq
- **Issuer:** Pharmaceuticals (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2025-06-30
- **Language:** en
- **DOI:** 10.3390/ph18070981
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40732273/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackground/Objectives: Artificial intelligence (AI) is transforming drug discovery and development by enhancing the speed and precision of identifying drug candidates and optimizing their efficacy. This review evaluates the application of AI in various stages of drug discovery, from hit identification to lead optimization, and its impact on clinical outcomes. The objective is to provide insights into the role of AI across therapeutic areas and assess its contributions to improving clinical trial efficiency and pharmaceutical outcomes. Methods: A systematic review followed PRISMA guidelines to analyze studies published between 2015 and 2025, focusing on AI in drug discovery and development. A comprehensive search was performed across multiple databases to identify studies employing AI techniques. The studies were categorized based on AI methods, clinical phase, and therapeutic area. The percentages of AI methods used, clinical phase stages, and the therapeutic regions were analyzed to identify trends. Results: AI methods included machine learning (ML) at 40.9%, molecular modeling and simulation (MMS) at 20.7%, and deep learning (DL) at 10.3%. Oncology accounted for the majority of studies (72.8%), followed by dermatology (5.8%) and neurology (5.2%). In clinical phases, 39.3% of studies were in the preclinical stage, 23.1% in Clinical Phase I, and 11.0% in the transitional phase. Clinical outcome reporting was observed in 45% of studies, with 97% reporting industry partnerships. Conclusions: AI significantly enhances drug discovery and development, improving drug efficacy and clinical trial outcomes. Future work should focus on expanding AI applications into underrepresented therapeutic areas and refining models to handle complex biological systems.Keywords: artificial intelligence, clinical outcomes, clinical trials, drug discovery, hit identification, lead optimization, pharmaceutical industry

## Section: 1. Introduction

The traditional drug discovery and development process is an arduous and resource-intensive endeavor. Historically, it takes approximately 10 to 15 years to develop a new therapeutic agent from initial discovery to regulatory approval, with costs often exceeding USD 1 to USD 2 billion [1,2,3]. Moreover, the likelihood of a new compound successfully navigating all phases of clinical trials and reaching the market remains dismally low, and estimates suggest that fewer than 1 in 10 drug candidates entering Phase I clinical trials are ultimately approved [4,5]. Key bottlenecks include the inefficient identification of druggable targets, the costly and time-consuming high-throughput screening (HTS) of large chemical libraries, suboptimal lead optimization, and poorly designed clinical trials that fail to stratify patient populations adequately [6]. Artificial Intelligence (AI) has emerged as a pivotal tool in the pharmaceutical and biomedical industries in recent years. By leveraging massive datasets, advanced algorithms, and high-performance computing, AI tools can uncover patterns and insights that would be nearly impossible for human researchers to detect unaided. These tools have been applied to almost any stage of the drug discovery pipeline, from target identification and validation, hit-to-lead optimization, absorption, distribution, metabolism, excretion, and toxicity (ADMET) profiling, to clinical trial simulation and recruitment strategies [7,8]. Unlike traditional, largely sequential workflows, AI models can parallel process and integrate multi-omics data streams (genomic, proteomic, phenotypic, chemical), potentially compressing the preclinical phase from several years to a few months [9,10].

Several AI-native and AI-integrated biotech firms have already demonstrated tangible progress in reducing timelines and increasing efficiency. Insilico Medicine, a leading AI drug discovery company, announced in 2021 that it successfully identified a novel target for idiopathic pulmonary fibrosis and advanced a drug candidate into preclinical trials in just 18 months (a process that typically takes 4–6 years) at a cost of only USD 150,000, excluding wet lab validation [11]. Similarly, Exscientia, in partnership with Sumitomo Dainippon Pharma, developed a novel small-molecule drug candidate (DSP-1181) for obsessive–compulsive disorder (OCD) in less than 12 months, making it the first AI-designed molecule to enter human clinical trials [12]. Another prominent example, Recursion Pharmaceuticals, uses automated high-throughput imaging combined with deep learning (DL) models to identify phenotypic changes in cells, allowing for rapid repurposing of existing molecules and discovering novel therapeutics [13]. Meanwhile, Schrödinger, renowned for its physics-based molecular simulations, integrates AI to predict molecular interactions with high accuracy. This hybrid approach of physics-informed AI is revolutionizing virtual screening by significantly improving hit rates and reducing reliance on exhaustive laboratory testing [14]. These pioneering firms are not just proof-of-concept models; they represent a paradigm shift in how drugs are discovered, optimized, and brought to market. Increasing investment from big pharmaceutical companies (e.g., Roche, Bayer, Novartis) into AI collaborations further underscores the seriousness with which the industry views these innovations. Despite these remarkable advances, the extent of AI’s measurable impact on key drug development metrics, such as preclinical cycle times, clinical success rates, and regulatory approval efficiencies, remains poorly characterized in the literature. While individual case studies and company press releases highlight success stories, there is a pressing need for a systematic, evidence-based review that consolidates current findings and evaluates the robustness of AI’s contributions across different stages of the drug development lifecycle. Furthermore, understanding these AI platforms’ scalability, reproducibility, and generalizability is critical for stakeholders, including regulators, investors, and clinical researchers, who are cautiously optimistic but demand empirical validation before widespread adoption.

This systematic review aimed to address the existing knowledge gap by comprehensively analyzing published literature on the application of AI in drug discovery and development. The primary objective was to evaluate how AI influenced the acceleration of drug development timelines, particularly from target identification through preclinical optimization and into clinical trials. The review quantified the impact of AI tools on critical performance metrics such as the reduction in development cycle times, improvements in hit identification and lead optimization, and the readiness for Investigational New Drug (IND) applications. Secondary objectives included assessing the enhancement of pipeline productivity, time-to-IND milestones, and real-world clinical outcomes of drug candidates developed or optimized using AI. Furthermore, the review examined broader industry trends, including licensing agreements, venture capital investments, strategic partnerships, and major pharmaceutical companies’ incorporation of AI frameworks. By synthesizing these findings, the review provided meaningful insights into AI’s practical impact on the pharmaceutical industry and offered evidence to guide future research directions, regulatory considerations, and commercial strategies.

## Section: 2. Results

PRISMA (preferred reporting items for systematic reviews and meta-analyses) flow diagram of study selection process. The diagram illustrates how records were identified, screened, excluded, and ultimately included in the systematic review, following PRISMA guidelines.

Comprehensive analysis of AI-driven drug discovery studies: distribution across drug development stages, global research activity by country, industry collaboration, clinical reporting, and utilization of AI methodologies. (A) A horizontal bar graph showing the number of AI-driven drug discovery studies categorized by their developmental stage, from preclinical research through various phases of clinical trials. (B) A world map indicating the number of AI-driven drug discovery studies conducted per country. (C) A series of bar graphs illustrating the percentage of studies reporting (1) industry partnerships, (2) clinical outcomes, and (3) translational impact. (D) A pie chart depicting the proportion of various AI technologies used in the studies. ML and DL dominate the field, accounting for 40.9% and 20.7% of studies, respectively.

Diversity of AI techniques utilized across leading AI drug discovery platforms. This figure presents a comparative analysis of the number and variety of AI techniques implemented by major AI platforms in drug discovery. Each bar represents a distinct AI platform, and each colored segment within the bars corresponds to a specific AI technique.

Recent applications of AI techniques in drug discovery across therapeutic areas and development stages (2015–2025). This table presents data from a single study conducted by one pharmaceutical or AI company, showcasing the application of AI techniques in drug discovery and development across various therapeutic domains. The complete dataset, comprising 173 studies from multiple companies and research groups, is available in Supplementary Data S1.

Therapeutic focus and molecular target distribution in AI-driven drug discovery. (A) Bar chart showing the number of studies across various therapeutic areas. Oncology dominates with 126 studies, followed by dermatology (10), gastroenterology (9), neurology (9), and immunology (7), indicating a primary focus on cancer treatment in AI-based drug development. (B) Flower plot illustrating target molecules pursued by major AI-driven pharmaceutical companies (e.g., Insilico Medicine, Compugen, Schrödinger, Lantern Pharma, HiFiBiO Therapeutics, and Relay Therapeutics). Target labels are color-coded by development phase: preclinical (light blue), clinical phase I (moderate blue), phase II (darker blue), and phase III (darkest blue). Shared and high-priority targets such as PD-1, PD-L1, TYK2, and EGFR are visible across companies and development stages.

## Section: 2. Results › 2.1. Systematic Literature Search and Study Selection Workflow

A systematic literature search was conducted across four major scientific databases to capture a comprehensive set of studies involving AI in drug discovery and development. The initial search phase retrieved a total of 19,465 records. Among these, the highest number of records originated from PubMed (n = 10,055, representing 51.6% of all records), followed by Web of Science (n = 7217, or 37.1%), SCOPUS (n = 2129, or 10.9%), and a smaller number from the Cochrane Library (n = 64, or 0.3%) (Figure 1). In addition, six additional records were identified through manual searches and gray literature sources, including four from Google search and two from ClinicalTrials.gov, which together contributed only 0.03% to the total count. After removing duplicates across these sources, 10,348 unique records were retained for further screening, indicating that 46.9% of the initially identified articles were duplicates. These 10,348 records then underwent a title screening phase to evaluate fundamental relevance to the topic. At this stage, 9060 records (equivalent to 87.6% of the screened titles) were excluded due to being unrelated to AI applications in drug development or lacking relevance to pharmaceutical sciences. The remaining 1288 records (12.4% of those screened by title) proceeded to the next stage: abstract screening.

A more refined selection process was carried out during the abstract screening phase. Each abstract was reviewed for the use of AI techniques in the context of drug discovery or development and the presence of meaningful scientific or therapeutic contributions. As a result, 975 records (75.7% of abstracts reviewed) were excluded because they did not meet these criteria. The remaining 313 articles (24.3% of abstracts screened; 1.6% of the original dataset) were retained for full-text review. The full-text review phase involved a detailed assessment of the study’s methodology, focus, and outcomes. From these 313 full-text articles, 140 articles (44.7%) were excluded. The reasons for exclusion were systematically categorized as follows: 94 articles (30.0% of full texts assessed; 67.1% of exclusions) did not utilize adaptive AI methods, such as reinforcement learning (RL), generative adversarial networks, or other self-improving algorithms, which were key inclusion criteria. Twenty-eight articles (8.9% of full texts; 20.0% of exclusions) were unrelated to drug discovery or development applications. These included AI use in other domains such as medical diagnostics or image analysis, without clear links to pharmaceutical pipelines. Eighteen articles (5.8% of full texts; 12.9% of exclusions) lacked measurable drug development outcomes, such as predictive performance, lead optimization, or translational results, rendering them insufficiently aligned with the review objectives. Following this rigorous filtering process, 173 studies were deemed eligible and subsequently included in the final scoping review. This constitutes 55.3% of the full-text articles assessed, and only 1.8% of the total records identified at the outset. Despite the relatively small final inclusion rate, this subset of studies provides a focused and high-quality evidence base for analyzing how adaptive AI methods are currently integrated within the pharmaceutical research and development landscape. These selected studies form the basis of the subsequent analysis on methodological trends, therapeutic targets, and measurable impacts of AI in modern drug discovery.

PRISMA (preferred reporting items for systematic reviews and meta-analyses) flow diagram of study selection process. The diagram illustrates how records were identified, screened, excluded, and ultimately included in the systematic review, following PRISMA guidelines.

## Section: 2. Results › 2.2. Distribution of AI Applications Across Drug Development Stages, Geographic Trends, Industry Collaboration, and AI Technology Adoption

A comprehensive analysis of the 173 included studies reveals valuable insights into how AI is applied throughout various stages of drug development, its geographic distribution, the degree of industry partnership, translational impact, and the spectrum of AI methodologies employed. Figure 2A provides a comprehensive overview of the distribution of AI applications across various stages of drug development, with an intense concentration in the early phases of the drug discovery pipeline. The preclinical stage remains the most active, with 68 out of 173 studies (39.3%) focused at this level. This highlights AI’s integral role in the foundational aspects of drug research, including target identification, virtual screening, de novo molecule generation, molecular docking, quantitative structure–activity relationship (QSAR) modeling, and ADMET prediction. The dominance of preclinical AI applications underscores its transformative potential in accelerating early-stage discovery and optimizing lead compounds before entering human trials. Next, 19 studies (11.0%) were positioned in the transitional phase between preclinical and Clinical Phase I, often associated with IND (Investigational New Drug) enabling activities. At this stage, AI is applied in predictive toxicology, in silico dose selection, early biomarker discovery, and simulation of pharmacokinetic parameters, contributing to safer and more informed transitions into human testing.

The Clinical Phase I stage showed a significant increase in AI integration, with 40 studies (23.1%), indicating growing confidence in AI tools for safety profiling, pharmacokinetics modeling, and real-time monitoring during early human exposure. These tools assist in optimizing dosage regimens and reducing early-phase attrition by predicting adverse events and guiding early clinical decisions. Five studies (2.9%) were conducted at the Clinical Phase I/Ib level and 17 studies (9.8%) at the Phase I/II level in the hybrid early clinical stages. These phases typically involve dose expansion and initial efficacy assessments, where AI supports patient stratification, digital biomarker identification, and adaptive trial designs. Moving into Clinical Phase Ib/II and Phase IIa, the number of AI-based studies declines, with 2 (1.2%) and 16 (9.2%) studies, respectively. These phases often focus on proof-of-concept evaluation, and AI is leveraged here to analyze multidimensional patient data, integrate omics datasets, and assist in go/no-go decisions. Despite the complexity of these phases, the use of AI remains underutilized. The later stages of development show the lowest AI engagement: Clinical Phase IIb with five studies (2.9%) and Clinical Phase II/III with just two studies (0.6%). These phases are centered on dose optimization, large-scale efficacy, and comparative effectiveness trials, where high regulatory standards, data integrity demands, and the need for explainability and validation of AI models limit the application of AI.

Figure 2B illustrates the global geographic distribution of AI-based drug discovery studies, revealing a highly skewed landscape dominated by a few technologically advanced nations. The United States stands at the forefront, contributing 129 out of 179 studies (72.1%), underscoring its leading role in the convergence of AI and pharmaceutical innovation. This dominance is attributed to multiple factors, including robust federal and private sector investment in biotechnology, an extensive network of academic and industry collaborations, high-performance computing infrastructure, and an entrepreneurial ecosystem that fosters the rapid development and deployment of AI platforms in drug discovery. However, the aim here is not to evaluate individual digital ecosystems or AI platforms but to characterize how national-level strategies influence broader trends in AI integration across the drug development continuum. In a distant second, China contributed 16 studies (8.9%), reflecting its rapidly expanding capabilities in AI and pharmaceutical research and development (R&D). China’s significant government support for AI innovation, coupled with its growing pharmaceutical market and increasing academic output in computational biology, signals strong momentum in this space. The United Kingdom accounted for nine studies (5.0%), indicative of its established strength in biomedical research, AI innovation hubs in Cambridge, London, and Oxford, and a regulatory environment that supports digital health technologies. Other contributors include South Korea (6 studies; 3.4%), Denmark (6 studies; 3.4%), and Japan (6 studies; 3.4%). These countries possess strong healthcare systems, government-sponsored AI initiatives, and active collaborations between academic and pharmaceutical sectors. Their participation reflects growing regional investment in AI-assisted drug development, albeit at a more modest scale compared to the US. More minor but notable contributions were seen from Singapore (3 studies; 1.7%), Spain (2 studies; 1.1%), Canada (1 study; 0.6%), and Australia (1 study; 0.6%). These nations are increasingly integrating AI into biomedical research but may face challenges related to scale, funding, or data accessibility that limit broader adoption. Notably, regions such as Africa, South America, and large parts of Southeast Asia were absent from the dataset, highlighting a significant global disparity in adopting and implementing AI technologies in drug discovery. This absence underscores the need for capacity-building initiatives, enhanced international collaborations, and knowledge-sharing frameworks that can democratize access to AI resources and training.

Figure 2C provides a comprehensive assessment of the translational maturity of AI-driven drug discovery studies, focusing on three critical indicators: timeline impact, clinical outcome reporting, and industry partnership. Remarkably, all 173 studies (100%) demonstrated some form of timeline impact, signifying that AI integration consistently contributes to accelerating various stages of the drug development pipeline. This universal influence highlights AI’s role in enhancing research efficiency, expediting compound selection, and shortening time-to-decision in early-stage drug discovery. A prominent example is Insilico Medicine’s AI-designed drug candidate INS018_055, a small molecule targeting idiopathic pulmonary fibrosis (IPF) [15]. Developed using their proprietary AI platform, this compound progressed from target identification to a preclinical candidate in under 18 months—a process that traditionally takes several years. As of recent updates, INS018_055 has entered Phase II clinical trials, underscoring how AI can dramatically compress timelines and bridge computational discovery with clinical translation. However, when examining clinical outcome reporting, the data reveals a significant drop-off in translational depth. Only 77 studies (45%) reported measurable clinical outcomes, such as pharmacokinetic parameters, safety profiles, or preliminary efficacy indicators. The majority of 96 studies (55%) did not report any clinical outcomes, suggesting that many AI applications remain confined to preclinical or in silico stages, where direct clinical relevance is either unexplored or not yet achieved. This imbalance highlights a key bottleneck in validating AI-derived insights within real-world clinical contexts. Furthermore, formal industry partnerships were surprisingly high, with 168 studies (97%) reporting collaboration with industry stakeholders. This finding contrasts with prior expectations and suggests that AI in drug discovery is increasingly seen as a strategic asset by pharmaceutical and biotech companies. These partnerships likely facilitate access to proprietary datasets, advanced computational tools, and regulatory expertise, which can enhance AI solutions’ real-world applicability and scalability.

Industry-wide licensing agreements and strategic collaborations have become primary conduits for integrating AI into mainstream pipelines. For instance, Sanofi entered into a USD 1.2 billion partnership with Exscientia to use AI to discover novel oncology and immunology therapies [16]. Similarly, AstraZeneca has formed long-term collaborations with BenevolentAI, embedding AI platforms directly into its discovery engine [17]. These high-value deals validate the commercial potential of AI-driven discovery and position pharmaceutical companies to leverage AI across multiple therapeutic areas. From a funding perspective, the sector is also witnessing substantial venture capital investment. In 2023 alone, AI-driven biotech startups raised over USD 4.5 billion globally, with major recipients including Recursion Pharmaceuticals, XtalPi, and Insilico Medicine. Recursion, in particular, has established an expansive AI-first infrastructure integrating single-cell analysis, phenotypic imaging, and multi-modal data fusion, attracting public market interest (IPO in 2021) and private capital from major players such as SoftBank [18]. Big Pharma continues to gain momentum in the incorporation of AI frameworks. Pfizer, Merck, Roche, and Novartis have each developed or partnered on bespoke AI initiatives. Pfizer, for example, uses IBM Watson and other internal models for clinical trial optimization and target prediction [19]. Roche acquired Flatiron Health and Foundation Medicine to strengthen its data analytics and real-world evidence platforms, reinforcing AI’s role in personalized oncology [20]. Meanwhile, Novartis has embedded AI into its Novartis AI Innovation Lab, leveraging partnerships with Microsoft to create scalable machine learning (ML) frameworks for drug discovery and development [21].

Figure 2D provides an in-depth overview of the diverse AI techniques employed across drug discovery studies, revealing a dynamic and evolving technological landscape. ML remains the most dominant technique, featured in 170 studies (40.9%), representing a significant proportion of the total. Its prevalence reflects ML’s broad utility in tasks such as predictive modeling, compound prioritization, toxicity forecasting, and high-dimensional data interpretation. ML’s adaptability and scalability make it a cornerstone of AI-enabled drug discovery platforms [22]. Molecular modeling and simulation (MMS) was the second most frequently applied method in 86 studies (20.7%). MMS techniques, such as molecular docking, molecular dynamics simulations, and free energy perturbation, are fundamental to structure-based drug design and offer mechanistic insights that complement data-driven approaches [23,24,25]. DL, used in 43 studies (10.3%), underscores the growing reliance on complex neural networks for handling unstructured data such as molecular images, protein structures, and compound libraries. DL techniques are particularly advantageous in modeling nonlinear relationships and developing end-to-end learning frameworks, including convolutional and graph neural networks that power many modern cheminformatics and bioinformatics pipelines [26,27]. Omics integration (OM) was observed in 27 studies, reflecting the increasing emphasis on multi-omics data (genomics, proteomics, metabolomics) for systems-level understanding of disease mechanisms and drug response. Generative models (GM) appeared in 25 studies, illustrating the rising interest in de novo molecular generation. These models, which include variational autoencoders (VAEs), generative adversarial networks (GANs), and transformer-based frameworks, are instrumental in creating novel chemical entities with optimized pharmacokinetic and pharmacodynamic profiles [28,29]. Their use highlights the shift toward AI systems capable not only of prediction but also of creativity.

Structure-based drug design (SBDD) techniques were used in 21 studies, emphasizing their role in rational drug design informed by high-resolution structural data. SBDD often integrates docking, pharmacophore modeling, and homology modeling, which, combined with AI tools, accelerate the discovery of structure–activity relationships [30,31]. Physics-based modeling (PBM) was utilized in 17 studies, combining AI with traditional biophysical simulations to capture atomic-level interactions and predict binding affinities with higher precision. RL was employed in 12 studies, gradually adopting this powerful paradigm for optimizing compound synthesis paths, multi-objective design, and adaptive trial strategies. RL’s ability to learn optimal policies from sequential decisions makes it especially suitable for iterative drug design workflows [32,33]. Computer vision (CV) techniques, found in six studies, were mainly applied in analyzing histopathological images, high-throughput screening outputs, and chemical structure recognition [34]. Despite being a relatively underutilized method, CV has strong potential in visual data processing across drug discovery and diagnostics. Knowledge graphs (KG) were used in five studies, facilitating the integration of heterogeneous biomedical data into relational frameworks. KGs enable AI systems to infer novel relationships, such as drug-disease or gene-compound links, supporting hypothesis generation and drug repurposing [35,36]. Natural language processing (NLP) appeared in four studies, primarily focused on mining scientific literature, clinical trial records, and patents for actionable insights [37,38]. NLP tools are pivotal in automating knowledge extraction and transforming unstructured text into structured datasets for AI models.

Figure 3 highlights the diversity and technological sophistication of leading AI drug discovery platforms by illustrating the number and types of AI techniques integrated into each. Each bar represents a prominent platform developed by a pharmaceutical or AI-driven biotech company, and the colored segments within each bar denote the variety of AI approaches implemented. This comparative analysis offers a bird’s-eye view of innovation trends and technological focus areas within the AI-biopharma ecosystem. As a proxy for success, the platforms discussed are primarily evaluated based on their reported advancement of AI-supported drug candidates into preclinical or clinical development phases. Statements regarding AI functionality are derived from company disclosures, peer-reviewed publications, or white papers, and are acknowledged as such where independent validation is unavailable. Chemistry42, developed by Insilico Medicine, is reported to integrate generative AI, DL, and RL, three core methods that enable the platform to autonomously design novel chemical structures and optimize them for drug-like properties. This configuration supports an end-to-end generative chemistry pipeline, where molecules are created and refined iteratively through RL. Although it does not incorporate big data analytics or structural biology integration, Insilico positions Chemistry42 as a focused tool for early-stage molecular design [39].

Unigen™, from Compugen, stands out for its singular focus on predictive ML. Although it does not yet integrate other AI techniques, this focus enables it to excel in structure prediction, synthesis planning, and molecular property forecasting. This claim is based on company-reported use cases and reflects a streamlined strategy centered on quantum mechanics and in silico modeling. RADR® AI, the platform developed by Lantern Pharma, represents a different approach. It uses ensemble ML and big data analytics, reflecting its strong orientation toward biomarker discovery, drug repurposing, and precision oncology [40]. Rather than generating new chemical entities, RADR® reportedly analyzes existing compounds and omics datasets to identify therapeutic matches. This reflects a broader trend in AI-facilitated drug repositioning and personalized therapy development. Schrödinger’s platform integrates predictive ML with physics-based modeling, where AI algorithms are used to learn from quantum mechanical simulations and molecular dynamics data to accelerate binding affinity prediction and optimize ligand-protein interactions. Rather than replacing physics-based models, AI enhances these simulations by guiding conformational sampling, predicting simulation outcomes, and refining scoring functions for virtual screening. This hybrid approach reinforces Schrödinger’s role as a leader in structure-guided drug design, simulating molecular interactions at the atomic level while grounding predictions in physical and chemical reality. Dynamo™, by Relay Therapeutics, also exemplifies this integration by combining predictive ML, motion simulation, and structural biology. In this context, AI is employed to interpret the dynamic conformational landscapes generated by molecular simulations, enabling the identification of cryptic pockets and transient binding sites relevant for drug targeting. The AI layer thus transforms raw simulation data into actionable drug design insights.

Platforms like HiFiBiO’s DIS™ and Flex-NK™ showcase the specialized application of AI in immunotherapy and cell-based therapies. HiFiBiO focuses on single-cell analysis and predictive ML, enabling the discovery of immune targets at a granular resolution, which is ideal for antibody and T-cell engineering. Flex-NK™, on the other hand, leverages DL, predictive ML, and single-cell analysis to optimize NK-cell-based cancer therapies, highlighting the growing role of AI in cellular and gene therapy design. Recursion OS leads the field regarding AI technique integration, employing six out of ten tracked AI approaches: generative AI, DL, predictive ML, big data analytics, structural biology, and single-cell analysis. This diversity reflects Recursion’s commitment to large-scale phenotypic screening and multi-modal data fusion. The platform analyzes vast amounts of image-based cellular data and integrates it with molecular insights to drive target discovery and drug repurposing. This capability is inferred mainly from corporate communications and published output, as with other platforms. TITAN-X, developed by the NIMML Institute, emphasizes protein engineering by combining predictive ML algorithms with structural biology and physics-based simulations. Here, AI assists in predicting folding patterns, protein stability, and evolutionary trajectories by learning from structural datasets and simulation results. This AI-physics synergy is particularly powerful for designing synthetic proteins with tailored functionalities. SmartCube®, in contrast, incorporates motion simulation, predictive ML, and big data analytics to study behavioral phenotypes, particularly in neuropsychiatric disorders, a niche application of AI that blends behavioral science with drug discovery [41]. Lastly, PIONEER™ by Evaxion Biotech showcases a compact but impactful setup with generative AI and DL, aligning with Evaxion Biotech’s mission to build human-centric drug development platforms. This platform personalizes translational research, particularly where patient heterogeneity influences therapeutic outcomes [42]. It uses digital twin technology and AI to enhance translational research, especially in areas where patient variability significantly affects outcomes.

Comprehensive analysis of AI-driven drug discovery studies: distribution across drug development stages, global research activity by country, industry collaboration, clinical reporting, and utilization of AI methodologies. (A) A horizontal bar graph showing the number of AI-driven drug discovery studies categorized by their developmental stage, from preclinical research through various phases of clinical trials. (B) A world map indicating the number of AI-driven drug discovery studies conducted per country. (C) A series of bar graphs illustrating the percentage of studies reporting (1) industry partnerships, (2) clinical outcomes, and (3) translational impact. (D) A pie chart depicting the proportion of various AI technologies used in the studies. ML and DL dominate the field, accounting for 40.9% and 20.7% of studies, respectively.

Diversity of AI techniques utilized across leading AI drug discovery platforms. This figure presents a comparative analysis of the number and variety of AI techniques implemented by major AI platforms in drug discovery. Each bar represents a distinct AI platform, and each colored segment within the bars corresponds to a specific AI technique.

## Section: 2. Results › 2.3. Landscape of AI Applications in Pharmaceutical R&D: Trends and Case Studies

Over the past decade (2015–2025), the pharmaceutical industry has witnessed a transformative integration of AI across drug discovery and development pipelines. Table 1 provides a comprehensive overview of AI-enabled innovations deployed across various therapeutic domains, ranging from oncology and gastroenterology to infectious diseases and immunology. Oncology emerges as the most prominent therapeutic area leveraging AI tools. Multiple case studies from biotech firms like A2A Pharmaceuticals, Accutar Biotechnology, Black Diamond Therapeutics, Compugen, and Evaxion Biotech highlight the versatile use of AI in structure-based drug design, epitope prediction, predictive modeling, and virtual screening. For instance, a study utilizes structure-based drug design combined with virtual screening and ADMET predictions to target triple-negative breast cancer (TNBC), high-grade serous ovarian cancer (HGSOC), and endometrial cancer with TP53 mutations [43]. Similarly, another study employed AI platforms such as ChemiRise and Chemi-Net to optimize the pharmacokinetics/pharmacodynamics (PK/PD) of potential drugs for ER+/HER2− breast cancer [44]. The consistent clinical advancement into Phase I and II trials underscores AI’s clinical promise in oncologic settings. Beyond target identification, AI is also used for combination therapy modeling and antibody design. Platforms like Unigen™, NovareAI, and Flex-NK™ integrate ML with omics data and spatial transcriptomics to identify novel therapeutic strategies. Exscientia and Evotec, for instance, utilize generative design models and simulation-guided clinical trial planning, marking a shift from empirical to computationally guided therapeutic development.

While oncology dominates, AI’s impact extends to a broad spectrum of other therapeutic areas. In gastroenterology, Celsius Therapeutics and Landos Biopharma use platforms like SCOPE and TITAN-X for single-cell RNA-seq analysis, predictive analytics, and disease stratification in conditions like ulcerative colitis and Crohn’s disease. In infectious diseases, Generate Biomedicines applied iterative ML-based chemoproteomic loops for COVID-19 prophylaxis, while Drug Farm’s IDInVivo platform enabled in vivo gene targeting for Hepatitis B. In neurology and immunology, platforms such as Magellan™ (Gain Therapeutics) and DeepCure’s AI-driven compound design system illustrate how AI is pushing the frontier of precision medicine. In rheumatology, Formation Bio used AI to automate MRI segmentation and analyze cartilage degradation in osteoarthritis. Such examples show how AI is revolutionizing both molecular-level innovations and system-level clinical decision-making processes. The diversity of AI techniques employed across these case studies reflects the maturity and versatility of the field. Methods range from knowledge graphs and Bayesian modeling to convolutional neural networks and RL. For example, a study leveraged knowledge graphs for target prioritization in ulcerative colitis [47], while another study used generative AI and RL for chemical space exploration in rheumatoid arthritis [56]. Integration with supercomputing resources, as seen in BERG’s use of the Oak Ridge supercomputer, and the construction of AI-driven lipid nanoparticle optimization (AiLNP) platforms by METiS Pharmaceuticals, exemplify cross-disciplinary innovation between AI, physics, and pharmaceutical sciences.

Figure 4 comprehensively depicts the current focus and molecular strategies of AI-driven drug discovery initiatives. Figure 4A reveals a significant concentration of AI applications in oncology, which accounts for 126 studies (72.83%), far surpassing all other therapeutic areas. This outsized focus reflects the urgent unmet needs in cancer treatment and the availability of robust datasets in oncology, which are essential for training and validating AI models. The nature of cancer, characterized by genomic complexity and high inter-patient variability, makes it a fertile ground for AI applications that can sift through large-scale omics data, identify novel biomarkers, and propose tailored therapeutic strategies. Furthermore, oncology’s historically high rate of drug development investment likely incentivizes AI startups and pharmaceutical companies to focus on this domain, where the return on innovation can be particularly high. Beyond oncology, the distribution of studies across other disease areas shows a sharp drop. Dermatology ranks second with only 10 studies (5.78%), followed by gastroenterology and neurology with nine studies each (5.20%). These numbers indicate a nascent expansion of AI efforts into non-cancer areas, though the pace remains cautious. Dermatology, for example, benefits from the abundance of image-based data, which aligns well with AI tools such as convolutional neural networks. Neurology and gastroenterology, despite being rich in research potential, pose unique challenges such as limited biomarker availability and the complexity of brain–gut interactions, which might explain their relatively modest representation. Immunology accounts for seven studies (4.05%) and infectious diseases for five studies (2.89%), which gradually incorporate AI, particularly in areas like immune profiling, vaccine design, and antibiotic resistance prediction. Meanwhile, pulmonary and endocrinology have three studies each (1.73%), and rheumatology is the least represented with only 1 study (0.58%), underscoring their current underrepresentation, possibly due to insufficient data infrastructure or less immediate commercial incentive.

Figure 4B complements this therapeutic overview with a flower plot that maps the molecular targets pursued by leading AI-powered drug discovery companies. This visualization illustrates how AI is being used to expand therapeutic areas and diversify molecular strategies. The flower’s petals are divided among six prominent AI-driven biopharmaceutical firms: Insilico Medicine, Compugen, Schrödinger, Lantern Pharma, HiFiBiO Therapeutics, and Relay Therapeutics. Each sector’s molecular targets are placed according to their development phase, ranging from preclinical (light blue) to clinical phases I through III (in increasingly darker shades of blue). Notably, specific targets such as PD-1, PD-L1, TYK2, and EGFR appear in multiple petals, signaling their importance across company pipelines and suggesting convergence on high-value targets in immuno-oncology and precision medicine. The recurrence of targets like PD-1 and PD-L1, central to immune checkpoint inhibition therapies, indicates that AI is used to identify new molecules and optimize well-known mechanisms of action. Their widespread inclusion across companies and development stages signals intense competition and the strategic prioritization of validated but improvable pathways. Similarly, TYK2 and EGFR represent attractive targets with known therapeutic relevance in autoimmune and oncologic conditions [93,94], further reinforcing that AI enhances and accelerates drug discovery within proven biological frameworks. Additionally, more specialized or emerging targets, such as pan-TEAD, CDC7, and MALT1, demonstrate that AI is also facilitating novel hypothesis generation and target validation, which may yield first-in-class therapies.

Recent applications of AI techniques in drug discovery across therapeutic areas and development stages (2015–2025). This table presents data from a single study conducted by one pharmaceutical or AI company, showcasing the application of AI techniques in drug discovery and development across various therapeutic domains. The complete dataset, comprising 173 studies from multiple companies and research groups, is available in Supplementary Data S1.

Therapeutic focus and molecular target distribution in AI-driven drug discovery. (A) Bar chart showing the number of studies across various therapeutic areas. Oncology dominates with 126 studies, followed by dermatology (10), gastroenterology (9), neurology (9), and immunology (7), indicating a primary focus on cancer treatment in AI-based drug development. (B) Flower plot illustrating target molecules pursued by major AI-driven pharmaceutical companies (e.g., Insilico Medicine, Compugen, Schrödinger, Lantern Pharma, HiFiBiO Therapeutics, and Relay Therapeutics). Target labels are color-coded by development phase: preclinical (light blue), clinical phase I (moderate blue), phase II (darker blue), and phase III (darkest blue). Shared and high-priority targets such as PD-1, PD-L1, TYK2, and EGFR are visible across companies and development stages.

## Section: 3. Discussion › 3.1. Main Findings and Comparison with Prior Works

This systematic review presents a comprehensive landscape of how AI is applied in the drug discovery and development (DDD) pipeline. The main findings reveal that AI adoption is predominantly concentrated in the early stages of drug discovery, specifically in target identification, validation, and compound screening, with a gradual extension into preclinical and early clinical development. Oncology emerges as the principal therapeutic area of AI activity, representing nearly 73% of identified studies, followed by dermatology, gastroenterology, and neurology. This distribution highlights a strategic focus by AI developers and pharmaceutical companies on high-burden, data-rich therapeutic domains. Additionally, AI technologies such as ML, DL, NLP, and RL were frequently reported, each employed according to task-specific requirements, such as image analysis, biomarker discovery, structure-based drug design, and patient stratification. This study aligns with and extends the existing body of knowledge compared to prior reviews in this domain. For instance, several findings highlighted the growing role of ML algorithms in streamlining target discovery and virtual screening [95]. However, these earlier reviews primarily focused on the promise of AI technologies, emphasizing algorithmic performance and proof-of-concept studies. In contrast, the present review integrates real-world implementation trends, industry partnerships, and clinical translation efforts, thereby offering a more grounded assessment of AI’s practical impact across the pharmaceutical value chain. Additionally, by disaggregating findings by disease area, development phase, and molecular strategy, this review reveals specific bottlenecks in underrepresented domains (e.g., rheumatology and endocrinology), which prior works only mentioned anecdotally.

One unique aspect of this review is its granular mapping of AI-driven pipelines at the company level, particularly through visualizations like the flower plot of molecular targets. This approach offers novel insights into how leading AI-powered biopharmaceutical firms prioritize molecular targets such as PD-1, PD-L1, EGFR, and TYK2, and how these targets are being pursued across different stages of development. While previous reviews acknowledged the theoretical ability of AI to identify novel targets, they rarely tracked how these insights translated into pipeline activities or advanced to clinical trials [96]. Identifying first-in-class targets (e.g., CDC7, pan-TEAD, and MALT1) further underscores AI’s growing role in hypothesis generation and mechanistic innovation, an aspect only sparsely covered in older literature. Moreover, this review distinguishes itself by explicitly analyzing global trends in AI-related research output, highlighting geographic disparities in AI adoption and institutional investment. The dominance of studies from the United States, China, and select European countries reflects a concentration of technical and financial resources, which may perpetuate regional inequalities in AI access and infrastructure.

## Section: 3. Discussion › 3.2. Limitations and Future Works

Despite the systematic and rigorous methodology employed in this review, several limitations must be acknowledged that may impact the generalizability and scope of the findings. The review was constrained by strict inclusion criteria focusing exclusively on peer-reviewed studies reporting AI applications directly linked to drug development phases, specifically from target identification to preclinical and clinical development. While this approach ensured the quality and relevance of the included literature, it may have inadvertently excluded valuable insights from studies that addressed AI’s role more indirectly or those published in non-traditional formats such as preprints, white papers, or internal industry reports. Consequently, some potentially impactful AI applications or national initiatives, particularly from underrepresented regions, may not have been captured, leading to a potential selection bias.

The translational gap between AI model development and real-world clinical outcomes remains significant. While many studies demonstrated AI’s utility in early drug development stages, only a limited number progressed to report late-stage clinical outcomes or regulatory approvals. This highlights a critical need for future work to emphasize prospective validation, integration of real-world evidence, and regulatory harmonization to ensure the translational success of AI-derived drug candidates. Future research should focus on enhancing AI model transparency and interpretability to support regulatory decision-making and clinical trust. Additionally, integrating real-world data sources, such as electronic health records, biobank datasets, and patient-reported outcomes, could significantly enrich AI models and support more personalized, efficient therapeutic development. Moreover, collaborative international initiatives and shared infrastructure for data interoperability would help democratize AI capabilities across regions and reduce the concentration of innovation within select geographic and institutional hubs.

Another key challenge is the issue of data quality. Many AI models rely on high-throughput, multi-modal biomedical datasets that may be incomplete, biased, or inconsistently annotated. Noise or missing values can significantly affect model performance, generalizability, and replicability. Moreover, datasets used in training AI systems may not represent diverse patient populations, raising concerns about fairness and applicability across clinical settings. Ensuring standardized data curation protocols and robust data governance frameworks will be essential to improve the reliability of AI-driven drug discovery workflows. Another key limitation is the lack of standardized, quantifiable benchmarks to assess AI performance across drug development stages. There is no universally accepted set of key performance indicators (KPIs) for evaluating AI effectiveness in drug discovery. Metrics such as time-to-IND, lead optimization success rate, prediction accuracy for target-disease associations, and progression to clinical trials are rarely reported consistently across studies. Furthermore, outcome reporting is often narrative or descriptive, limiting objective cross-study assessment. This absence of uniform indicators complicates cross-platform comparisons and weakens the ability to assess domain-wide impact. Developing and adopting a consensus KPI framework tailored to drug discovery milestones would improve strategic evaluation and facilitate regulatory and clinical benchmarking.

From a methodological standpoint, future systematic reviews in this field should consider incorporating broader source databases, including gray literature and preclinical conference proceedings, to capture a wider range of AI applications and regional contributions. Standardizing data extraction frameworks and performance indicators, and incorporating quantitative meta-analytic techniques where feasible, could enhance comparability across studies. Moreover, employing living systematic review frameworks, where the literature is updated in real time, may be especially valuable in fast-evolving domains like AI in drug development, allowing continuous integration of emerging evidence and improving policy and research responsiveness.

## Section: 4. Materials and Methods

Inclusion and exclusion criteria were used in study selection. This table outlines the detailed eligibility criteria applied during the selection of studies included in this systematic review. The criteria were established a priori to ensure consistency and relevance in capturing studies focused on the application of AI in drug discovery and development.

## Section: 4. Materials and Methods › 4.1. Eligibility Criteria

This systematic review focused on identifying and analyzing scholarly and professional works that reflect the real-world application and downstream impact of AI in drug discovery and development. To ensure the relevance and rigor of the selected literature, only studies and reports demonstrating meaningful contributions to the AI-driven drug development pipeline were considered. Specifically, the review encompassed original research articles, comprehensive reviews, white papers, and technical or industry reports that detailed the use of AI in advancing one or more stages of the drug discovery process. These stages included, but were not limited to, target identification, compound screening, hit-to-lead optimization, and the progression of candidates into preclinical studies and clinical trials. Documents were prioritized if they described tangible outputs from AI-driven pipelines, such as successful candidate nominations, IND filings, or the initiation of clinical trials. Emphasis was placed on works that provided evidence of accelerated timelines, improved molecular profiling, or enhanced pipeline productivity resulting from AI integration. Conversely, studies were not considered if they focused solely on computational or algorithmic model development without any application to real-world pharmaceutical pipelines. Likewise, studies discussing AI applications in areas unrelated to the core drug discovery lifecycle, such as marketing, supply chain logistics, sales analytics, or pharmacovigilance, were excluded from consideration. This delineation ensured that the review remained centered on evaluating AI’s tangible contributions to therapeutic innovation, translational science, and clinical readiness.

## Section: 4. Materials and Methods › 4.2. Information Sources

Multiple information sources were systematically searched to ensure a comprehensive and representative collection of relevant literature. The primary bibliographic databases consulted included PubMed, Web of Science, Scopus, and Cochrane Library. These platforms were selected due to their extensive indexing of peer-reviewed journals and conference proceedings across the domains of biomedical sciences, pharmaceutical innovation, AI, and computational modeling. They offered broad and complementary coverage of academic research and industry-driven applications. In addition to scientific databases, the clinical trials registry ClinicalTrials.gov was queried to identify records of ongoing or completed trials involving AI-assisted drug development. This source provided insights into the translational impact of AI on candidate advancement and regulatory readiness, particularly those that have reached investigational or therapeutic stages.

## Section: 4. Materials and Methods › 4.3. Search Strategy

A comprehensive search strategy was developed to capture the literature at the intersection of AI and drug discovery and development. This strategy combined free-text keywords and controlled vocabularies, including MeSH terms in PubMed, to ensure broad and precise retrieval of relevant studies. The search queries were constructed around five core conceptual domains: (1) AI technologies (e.g., “artificial intelligence”, “machine learning”, “deep learning”, “neural networks”); (2) drug discovery and development stages (e.g., “target identification”, “compound screening”, “preclinical development”, “clinical trials”); (3) outcomes and impact metrics (e.g., “timeline reduction”, “pipeline productivity”, “time-to-IND”, “regulatory approval”); (4) industry and commercial adoption (e.g., “pharmaceutical industry”, “venture capital”, “strategic partnerships”, “AI integration”); and (5) AI-based pharmaceutical and biotechnology companies (e.g., “Insilico Medicine”, “BenevolentAI”, “Exscientia”, “Recursion Pharmaceuticals”, “Relay Therapeutics”, “Generate Biomedicines”, among others). Boolean operators (AND/OR) were used to link these concepts effectively, and advanced syntax such as truncation and phrase searching was applied to optimize term variation capture. A representative query included terms such as (“artificial intelligence” OR “machine learning”) AND (“drug discovery” OR “drug development”) AND (“timeline reduction” OR “pipeline performance”) AND (“pharmaceutical industry” OR “venture capital”) AND (“Insilico Medicine” OR “BenevolentAI” OR “Exscientia”).

Searches were executed across multiple bibliographic databases, including PubMed, Web of Science, Scopus, and the Cochrane Library. To supplement peer-reviewed sources, gray literature was identified through targeted searches in Google Scholar and manual retrieval of documents recommended by domain experts. Additionally, ClinicalTrials.gov was searched to identify ongoing or completed trials involving AI-developed drug candidates. Only English-language publications were considered. To enhance transparency and reproducibility, the complete search strategy, including specific database queries and applied search filters, is provided in Supplementary Data S2.

## Section: 4. Materials and Methods › 4.4. Study Selection

The study selection process was conducted using a two-phase approach designed to rigorously identify publications relevant to the application of AI in drug discovery and development. In the first phase, two independent reviewers screened the titles and abstracts of all retrieved records. This initial screening was guided by a predefined set of criteria, focusing on the relevance of AI methods to drug development pipelines and the presence of tangible outcomes. Records that clearly did not meet the criteria were excluded at this stage, while those deemed potentially relevant were moved to the next phase. During the second phase, full-text articles were reviewed in detail by the same two reviewers to assess their eligibility. This phase involved careful evaluation of the AI methodology employed, the specific application stage within the drug discovery pipeline, and the outcome measures reported. Studies that did not provide concrete results, such as candidate identification, IND filing, or progression into clinical trials, were excluded. Similarly, studies that applied AI to areas unrelated to drug discovery (e.g., diagnostic imaging, electronic health record analysis, or marketing) were also excluded. Discrepancies between reviewers were addressed through structured discussion; in cases where consensus could not be reached, a third reviewer provided arbitration to ensure objectivity. The selection workflow followed the Preferred Reporting Items for Systematic Reviews and Meta-Analyses (PRISMA) 2020 guidelines [97,98] to enhance methodological transparency and reproducibility. The PRISMA checklist can be seen in Supplementary Data S3. This review was not registered in PROSPERO or any similar systematic review registry. The primary reason for this is that PROSPERO currently prioritizes reviews with direct clinical outcomes and patient-related interventions, which may not fully align with the technology-driven and preclinical focus of our investigation. Nevertheless, we strictly followed PRISMA 2020 guidelines to maintain transparency and methodological rigor. Future related reviews with clinical endpoints will be considered for prospective registration to enhance traceability and reproducibility. Additionally, Table 2 summarizes the detailed criteria used to guide study inclusion and exclusion, which were aligned with the review’s objective of assessing AI’s impact on accelerating drug development timelines and improving productivity metrics across preclinical and clinical stages.

Inclusion and exclusion criteria were used in study selection. This table outlines the detailed eligibility criteria applied during the selection of studies included in this systematic review. The criteria were established a priori to ensure consistency and relevance in capturing studies focused on the application of AI in drug discovery and development.

## Section: 4. Materials and Methods › 4.5. Data Extraction

A standardized data extraction form was meticulously developed and pilot-tested prior to formal data collection to ensure consistency and accuracy in capturing relevant information. The form encompassed a comprehensive set of variables, including bibliographic details (publication year, authors, journal, database), methodological features (study type, AI technique applied), and contextual information (drug discovery stage targeted, therapeutic area, geographic origin). Additionally, outcomes of interest were systematically recorded, such as key performance indicators (e.g., time-to-IND reduction, development timeline acceleration, clinical success rates), commercial outcomes (e.g., funding mechanisms, industry partnerships, licensing agreements), and any reported limitations. Two reviewers independently reviewed each article to minimize bias and discrepancies during data extraction. Any discrepancies were resolved through discussion and consensus between the reviewers. The data extraction framework also included binary indicators (Yes/No) for key metrics such as whether the study demonstrated timeline impact, reported clinical outcomes, or involved industry collaboration. This detailed approach allowed for systematically comparing AI applications across various stages of drug development and therapeutic areas.

## Section: 4. Materials and Methods › 4.6. Data Synthesis and Interpretations

The extracted data were synthesized using a qualitative narrative approach complemented by descriptive statistics. Studies were grouped based on the type of AI technique employed (e.g., DL, RL, ML), the stage of drug development targeted (e.g., target identification, lead optimization, preclinical or clinical phases), and the therapeutic area (e.g., oncology, neurology, infectious diseases). Frequency counts and proportions were used to summarize categorical variables such as AI method usage, therapeutic focus, and geographic origin. Key performance indicators, such as time-to-IND reduction, success rates, and commercial outcomes, were compared across studies to identify trends and outliers. Studies reporting similar metrics were narratively compared to highlight the magnitude of AI-driven impact on drug development efficiency and productivity. Where available, industry partnerships, external funding, and licensing agreements were also examined to assess real-world translational potential. The findings were interpreted in the context of methodological quality, generalizability, and limitations noted within the included studies. This synthesis enabled a multi-dimensional understanding of how AI technologies reshape modern drug discovery pipelines across research and commercial domains.

## Section: 5. Conclusions

This systematic review demonstrates that AI is increasingly reshaping drug discovery and development by streamlining early-stage research, improving target identification, and enhancing decision-making across clinical phases. AI technologies, particularly ML, molecular modeling, and DL, have proven instrumental in accelerating compound selection, optimizing lead candidates, and supporting personalized therapeutic strategies. The current landscape shows a dominant focus on oncology, driven by data availability and commercial incentives, although applications are steadily expanding into other therapeutic domains. Despite the progress, a notable translational gap remains, as relatively few studies report clinical outcome data, indicating limited integration of AI-derived insights into later development stages. Industry partnerships and investment trends further highlight growing confidence in AI’s utility in pharmaceutical innovation. Future efforts should prioritize increasing AI model transparency, regulatory harmonization, and seamless integration with real-world data to enable broader clinical adoption. Improving data interoperability, enhancing model interpretability, and validating AI-generated outputs in clinical settings are equally critical. Additionally, expanding AI applications to underrepresented therapeutic areas and ensuring alignment with evolving regulatory frameworks will be essential for solidifying AI’s role as a core enabler of modern drug development.

## Section: Abbreviations

The following abbreviations are used in this manuscript:

## Section: Supplementary Materials

The following supporting information can be downloaded at https://www.mdpi.com/article/10.3390/ph18070981/s1: Supplementary Data S1: Dataset of included studies; Supplementary Data S2: Full search strategy; Supplementary Data S3: PRISMA checklist.

## Section: Author Contributions

Conceptualization, N.A. and D.D.; data curation, N.A.; formal analysis, D.D.; funding acquisition, N.A.; investigation, D.D.; methodology, N.A. and D.D.; project administration, N.A.; resources, N.A.; software, D.D.; supervision, N.A.; validation, N.A. and D.D.; visualization, D.D.; writing—original draft, N.A. and D.D.; writing—review and editing, N.A. and D.D. All authors have read and agreed to the published version of the manuscript.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

The original contributions presented in this study are included in the article/Supplementary Material. Further inquiries can be directed to the corresponding author(s).

## Section: Conflicts of Interest

The authors declare no conflicts of interest.

## Section: Funding Statement

This work was supported and funded by the Deanship of Scientific Research at Imam Mohammad Ibn Saud Islamic University (IMSIU) (grant number IMSIU-DDRSP2501).

## Section: Associated Data › Data Availability Statement

The original contributions presented in this study are included in the article/Supplementary Material. Further inquiries can be directed to the corresponding author(s).


---

# FUTURE-AI: international consensus guideline for trustworthy and deployable artificial intelligence in healthcare

- **Authors:** Karim Lekadir, Alejandro F Frangi, Antonio R Porras, Ben Glocker, Celia Cintas, Curtis P Langlotz, Eva Weicken, Folkert W Asselbergs, Fred Prior, Gary S Collins, Georgios Kaissis, Gianna Tsakou, Irène Buvat, Jayashree Kalpathy-Cramer, John Mongan, Julia A Schnabel, Kaisar Kushibar, Katrine Riklund, Kostas Marias, Lameck M Amugongo, Lauren A Fromont, Lena Maier-Hein, Leonor Cerdá-Alberich, Luis Martí-Bonmatí, M Jorge Cardoso, Maciej Bobowicz, Mahsa Shabani, Manolis Tsiknakis, Maria A Zuluaga, Marie-Christine Fritzsche, Marina Camacho, Marius George Linguraru, Markus Wenzel, Marleen De Bruijne, Martin G Tolsgaard, Melanie Goisauf, Mónica Cano Abadía, Nikolaos Papanikolaou, Noussair Lazrak, Oriol Pujol, Richard Osuala, Sandy Napel, Sara Colantonio, Smriti Joshi, Stefan Klein, Susanna Aussó, Wendy A Rogers, Zohaib Salahuddin, Martijn P A Starmans, FUTURE-AI Consortium
- **Issuer:** BMJ (Clinical research ed.)
- **Type:** Scientific article
- **Published:** 2025-02-05
- **Language:** en
- **DOI:** 10.1136/bmj-2024-081554
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39909534/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractDespite major advances in artificial intelligence (AI) research for healthcare, the deployment and adoption of AI technologies remain limited in clinical practice. This paper describes the FUTURE-AI framework, which provides guidance for the development and deployment of trustworthy AI tools in healthcare. The FUTURE-AI Consortium was founded in 2021 and comprises 117 interdisciplinary experts from 50 countries representing all continents, including AI scientists, clinical researchers, biomedical ethicists, and social scientists. Over a two year period, the FUTURE-AI guideline was established through consensus based on six guiding principles—fairness, universality, traceability, usability, robustness, and explainability. To operationalise trustworthy AI in healthcare, a set of 30 best practices were defined, addressing technical, clinical, socioethical, and legal dimensions. The recommendations cover the entire lifecycle of healthcare AI, from design, development, and validation to regulation, deployment, and monitoring.

## Section: Introduction

In the field of healthcare, artificial intelligence (AI)—that is, algorithms with the ability to self-learn logic—and data interactions have been increasingly used to develop computer aided models, for example, disease diagnosis, prognosis, prediction of therapy response or survival, and patient stratification.1 Despite major advances, the deployment and adoption of AI technologies remain limited in real world clinical practice. In recent years, concerns have been raised about the technical, clinical, ethical, and societal risks associated with healthcare AI.2 3 In particular, existing research has shown that AI tools in healthcare can be prone to errors and patient harm, biases and increased health inequalities, lack of transparency and accountability, as well as data privacy and security breaches.4 5 6 7 8

To increase adoption in the real world, it is essential that AI tools are trusted and accepted by patients, clinicians, health organisations, and authorities. However, there is an absence of clear, widely accepted guidelines on how healthcare AI tools should be designed, developed, evaluated, and deployed to be trustworthy—that is, technically robust, clinically safe, ethically sound, and legally compliant (see glossary in appendix table 1).9 To have a real impact at scale, such guidelines for responsible and trustworthy AI must be obtained through wide consensus involving international and interdisciplinary experts.

In other domains, international consensus guidelines have made lasting impacts. For example, the FAIR guideline10 for data management has been widely adopted by researchers, organisations, and authorities, as the principles provide a structured framework for standardising and enhancing the tasks of data collection, curation, organisation, and storage. Although it can be argued that the FAIR principles do not cover every aspect of data management because they focus more on findability, accessibility, interoperability, and reusability of the data, and less on privacy and security, they delivered a code of practice that is now widely accepted and applied.

AI in healthcare has unique properties compared with other domains, such as the special trust relation between doctors and patients, because patients themselves generally do not have the opportunity to objectively assess the diagnosis and treatment decisions of doctors. This dynamic underscores the need for AI systems to be not only technically robust and clinically safe, but also ethically sound and transparent, ensuring that they complement the trust patients place in their healthcare providers. However, compared with non-AI tools, the highly complicated underlying data processing frequently comes with a lack of transparency into the exact working mechanisms. Unlike medical equipment, AI currently lacks universally accepted measures for quality assurance. Compared with chat assistants and synthetic image generators that receive increased public interaction, healthcare is a more sensitive domain where errors can have major consequences. Addressing these specific gaps for the healthcare domain is therefore crucial for trustworthy AI.

Initial efforts have focused on providing recommendations for the reporting of AI studies for different medical domains or clinical tasks (eg, TRIPOD+AI,11 CLAIM,12 CONSORT-AI,13 DECIDE-AI,14 PROBAST-AI,15 CLEAR16). These guidelines do not provide best practices for the actual development and deployment of the AI tools, but promote standardised and complete reporting of their development and evaluation. Recently, several researchers have published promising ideas on possible best practices for healthcare AI.17 18 19 20 21 22 23 24 However, these proposals have not been established through wide international consensus and do not cover the whole lifecycle of healthcare AI (ie, from design, development, and validation to deployment, usage, and monitoring).

In other initiatives, the World Health Organization published a report focused on key ethical and legal challenges and considerations. Because it was intended for health ministries and governmental agencies, it did not explore the technical and clinical aspects of trustworthy AI.25 Likewise, Europe’s High-Level Expert Group on Artificial Intelligence established a comprehensive self-assessment checklist for AI developers. However, it covered AI in general and did not address the unique risks and challenges of AI in medicine and healthcare.26

This paper addresses an important gap in the field of healthcare AI by delivering the first structured and holistic guideline for trustworthy and ethical AI in healthcare, established through wide international consensus and covering the entire lifecycle of AI. The FUTURE-AI Consortium was started in 2021 and currently comprises 117 international and interdisciplinary experts from 50 countries (fig 1), representing all continents (Europe, North America, South America, Asia, Africa, and Oceania). Additionally, the members represent a variety of disciplines (eg, data science, medical research, clinical medicine, computer engineering, medical ethics, social sciences) and data domains (eg, radiology, genomics, mobile health, electronic health records, surgery, pathology). To develop the FUTURE-AI framework, we drew inspiration from the FAIR principles for data management, and defined concise recommendations organised according to six guiding principles—fairness, universality, traceability, usability, robustness, and explainability (fig 2).

Geographical distribution of the multidisciplinary experts

Organisation of the FUTURE-AI framework for trustworthy artificial intelligence (AI) according to six guiding principles—fairness, universality, traceability, usability, robustness, and explainability

## Section: Methods

FUTURE-AI is a structured framework that provides guiding principles and step-by-step recommendations for operationalising trustworthy and ethical AI in healthcare. This guideline was established through international consensus over a 24 month period using a modified Delphi approach.27 28 The process began with the definition of the six core guiding principles, followed by an initial set of recommendations, which were then subjected to eight rounds of extensive feedback and iterative discussions aimed at reaching consensus. We used two complementary methods to aggregate the results: a quantitative approach, which involved analysing the voting patterns of the experts to identify areas of consensus and disagreement; and a qualitative approach, focusing on the synthesis of feedback and discussions based on recurring themes or new insights raised by several experts.

Definition of FUTURE-AI guiding principles:To develop a user friendly guideline for trustworthy AI in medicine, we used the same approach as in the FAIR guideline, based upon a minimal set of guiding principles. Defining overarching guiding principles facilitates streamlining and structuring of best practices, as well as implementation by future end users of the FUTURE-AI guideline.

To this end, we first reviewed the existing literature in healthcare AI, with a focus on trustworthy AI and related topics in healthcare, such as responsible AI, ethical AI, AI deployment, and terms relating to the six principles identified later. Additional searches were performed for related guidelines, for example, for AI reporting, AI evaluation, and guidelines or position statements from relevant (public) bodies such as the EU, the United States Food and Drug Administration (FDA), and WHO. This review enabled us to identify a wide range of requirements and dimensions often cited as essential for trustworthy AI.29 30 Throughout the following rounds, the literature review was iteratively expanded based on the advice by experts and widening of the scope, see round 3.

As table 1 shows, these requirements were then thematically grouped, leading to our definition of the six core principles (ie, fairness, universality, traceability, usability, robustness, and explainability), which were arranged to form an easy-to-remember acronym (FUTURE-AI).

Clustering of trustworthy artificial intelligence (AI) requirements and selection of FUTURE-AI guiding principles

List of FUTURE-AI recommendations, together with the expected compliance for both research and deployable artificial intelligence (AI) tools (+: recommended, ++: highly recommended)

## Section: Methods › Round 1: Definition of an initial set of recommendations

Six working groups composed of three experts each (including clinicians, data scientists, and computer engineers) were created to explore the six guiding principles separately. The experts were recruited from five European projects (EuCanImage, ProCAncer-I, CHAIMELEON, PRIMAGE, INCISIVE), which together formed the AI for Health Imaging (AI4HI) network. By using “AI for medical imaging” as a common use case, each working group conducted a thorough literature review, then proposed a definition of the guiding principle in question, together with an initial list of best practices (between 6 and 10 for each guiding principle).

Subsequently, the working groups engaged in an iterative process of refining these preliminary recommendations through online meetings and by email exchanges. At this stage, a degree of overlap and redundancy was identified across recommendations. For example, a recommendation to report any identified bias was initially proposed under both the fairness and traceability principles, while a recommendation to train the AI models with representative datasets appeared under fairness and robustness. After removing the redundancies and refining the formulations, a set of 55 preliminary recommendations was derived and then distributed to a broader panel of experts for further assessment, discussion, and refinement in the next round.

## Section: Methods › Round 2: Online survey

In this round, the FUTURE-AI Consortium was expanded to 72 members by recruiting new experts, including AI scientists, healthcare practitioners, ethicists, social scientists, legal experts, and industry professionals. The same original group took part in rounds 2–5. Experts were identified from the literature, through networks, and an online search, with selection focusing on underrepresented expertise or demographics. Most of the experts were recruited to complement the original consortium based on academic credentials, geographical location, and under-represented expertise, to ensure a representative consortium in terms of geography and (healthcare) disciplines. We then conducted an online survey to enable the experts to assess each recommendation using five voting options (absolutely essential, very important, of average importance, of little importance, not important at all). The participants were also able to rate the formulation of the recommendation (“I would keep it as it is,” “I would refine its definition”) and propose modifications. Furthermore, they were able to propose merging recommendations or adding new ones. The survey included a section for free text feedback on the core principles and the overall FUTURE-AI guideline.

The survey responses were quantitatively analysed to assess the consensus level. Recommendations that garnered a high level agreement (>90%) were selected for further discussion. Recommendations that attracted considerable negative feedback, which were particularly those that suggested specific methods over general guidelines, were discarded. The written feedback also prompted the merging of some recommendations, aiming to craft a more concise guideline for easier adoption by future users. Consequently, a revised list of 22 recommendations was derived, along with the identification of 16 contentious points for further discussions.

As part of the survey, we also sought feedback from the experts on the adequacy of these guiding principles in capturing the diverse requirements for trustworthy AI in healthcare. While the consensus among experts was largely affirmative, it was suggested a seventh “general” category was introduced to cover broader issues such as data privacy, societal considerations, and regulatory compliance, and to produce a holistic framework. The best practices in this category are overarching, for example, multistakeholder engagement (general 1) is relevant for all six guiding principles, thereby avoiding repetition for each principle.

## Section: Methods › Round 3: Feedback on the reduced set of recommendations

The updated version of the guideline from round 2 was distributed to all experts for another round of feedback. This involved assessing both the adequacy and the phrasing of the recommendations. Additionally, we presented the points of contention identified in the survey, encouraging experts to offer their insights on these disagreements. Examples of contentious topics included the recommendation to perform multicentre versus local clinical evaluation, and the necessity (or not) to systematically evaluate the AI tools against adversarial attacks.

The feedback received from the experts played a crucial role in resolving several contentious issues, particularly through the refinement of the recommendations' wording. Moreover, the scope was broadened from “AI in medical imaging” more generally to “AI in healthcare” because we realised most of the recommendations hold for healthcare in general, making the guideline more broadly applicable. As a result, this led to the expansion of the FUTURE-AI guideline to a total of 30 best practices, which included six new recommendations within the “general” category. Areas of disagreement that remained unresolved were carefully documented and summarised for future discussions.

## Section: Methods › Round 4: Further feedback and rating of the recommendations

The updated recommendations were sent out to the experts for additional feedback, this time in written form, to assess each recommendation’s clarity, feasibility, and relevance. This phase allowed for more precise phrasing of the recommendations. As an example, the original recommendation to train AI models with “diverse, heterogeneous data” was refined by using the term “representative data” because many experts argued that representative data more effectively capture the essential characteristics of the populations, while the term heterogeneous is more ambiguous.

Furthermore, we implemented a system to rate each best practice depending on the specific needs and goals of each AI project. A key focus was to make a distinction between healthcare AI tools at the research or proof-of-concept stage and those intended for clinical deployment because they require different levels of compliance. Healthcare AI tools in the research or proof-of-concept stage are typically in their experimental phase and require some flexibility as their capabilities are being explored and fine-tuned. In contrast, AI tools intended for clinical deployment will interact directly with patient care and therefore should need higher standards of compliance to ensure they are ethical, safe, and effective. At this point of the process, the consortium members were requested to assess all the recommendations separately for both proof-of-concept and deployable AI tools, and categorise them as either “recommended” or “highly recommended.”

## Section: Methods › Round 5: Feedback on the manuscript

At this stage, with a well developed set of 30 recommendations, the first and last authors of the study drafted the first version of the FUTURE-AI manuscript. The draft manuscript was circulated among the experts, starting a series of iterative feedback sessions to ensure that the FUTURE-AI guideline was articulated with precision and clarity. This process enabled incorporation of diverse perspectives, from clinical, technical, and non-technical experts, hence making the manuscript more reader friendly and accessible to a broad audience. Experts were also able to suggest additional resources or references to substantiate the recommendations further. At this stage, examples of methods were integrated to the manuscript where relevant, aiming to demonstrate the practical implementation of the best practices in real world scenarios.

## Section: Methods › Round 6: New “external” feedback

In round 6 we invited additional experts (n=44) who had not participated in the initial stages of the study to provide independent feedback. This group was carefully selected to ensure a more diverse representation across the experts (eg, patient advocates, social scientists, regulatory experts), as well as wider geographical diversity (especially across Africa, Latin America, and Asia).

These experts were requested to provide written feedback and express their opinion on each recommendation using a voting system (ie, agree, disagree, neutral, did not understand, no opinion). For most of the recommendations on which no clear agreement was reached, again using consensus level, the primary cause was misinterpretation or unclarity. Therefore, this stage was especially helpful in pinpointing any remaining areas of ambiguity or contention that required further discussions, as well as in identifying the formulations that needed refinement to ensure the entire guideline is clear and accessible to a diverse audience within the medical AI community.

## Section: Methods › Round 7: Online consensus meetings

Based on the feedback from previous rounds, we identified a few topics that continued to evoke a degree of contention among experts, particularly concerning the exact wording of certain recommendations. Hence, we convened four online meetings in June 2023 specifically aimed at deepening the discussions around the remaining contentious areas and reaching a final consensus on both the recommendations and their formulations.

These discussions resolved outstanding issues, such as the recommendation to systematically validate AI tools against adversarial attacks, which was considered by many experts as a cybersecurity concern and thus grouped with other related concerns; or the recommendation that the clinical evaluations should be conducted by third parties, which was deemed impractical at scale, especially in resource limited settings. As a result of these consensus meetings, the final list of FUTURE-AI recommendations was established, and their formulations were completed as detailed in table 2.

List of FUTURE-AI recommendations, together with the expected compliance for both research and deployable artificial intelligence (AI) tools (+: recommended, ++: highly recommended)

## Section: Methods › Round 8: Final consensus vote

The very last step of the process involved a final vote on the derived recommendations, which took place through an online survey. At this stage, the final consortium consisted of 117 experts as more replied to the above recruitments: the original 72 experts from round 2, some of the 44 experts who provided feedback in round 6, and several additional experts. By the end of this process, all the recommendations were approved with less than 5% disagreement among all FUTURE-AI members. The little remaining disagreement mostly originated from whether recommendations should be “recommended” or “highly recommended” for research and deployable tools.

## Section: FUTURE-AI guideline

In this section, we provide definitions and justifications for each of the six guiding principles and give an overview of the FUTURE-AI recommendations. Table 2 provides a summary of the recommendations, together with the proposed level of compliance (ie, recommended v highly recommended). Note that supplementary table 1 in the appendix presents a glossary of the main terms used in this paper, while supplementary table 2 lists the main stakeholders of relevance to the FUTURE-AI framework.

Embedding the FUTURE-AI best practices into an agile process throughout the artificial intelligence (AI) lifecycle. E=explainability; F=fairness; G=general; R=robustness; T=traceability; Un=universality; Us=usability

## Section: FUTURE-AI guideline › Fairness

The fairness principle states that AI tools in healthcare should maintain the same performance across individuals and groups of individuals (including under-represented and disadvantaged groups). AI driven medical care should be provided equally for all citizens. Biases in healthcare AI can be due to differences in the attributes of the individuals (eg, sex, gender, age, ethnicity, socioeconomic status, medical conditions) or the data (eg, acquisition site, machines, operators, annotators). As, in practice, perfect fairness might be impossible to achieve, fair AI tools should be developed such that potential AI biases are identified, reported, and minimised as much as possible to achieve ideally the same but at least highly similar performance across subgroups to be considered fair.31 To this end, three recommendations for fairness are defined in the FUTURE-AI framework.

## Section: FUTURE-AI guideline › Fairness › Fairness 1: Define sources of bias

Bias in healthcare AI is application specific.32 At the design phase, the interdisciplinary AI development team (see glossary) should identify possible types and sources of bias for their AI tool.33 These might include group attributes (eg, sex, gender, age, ethnicity, socioeconomic, geography), the medical profiles of the individuals (eg, with comorbidities or disability), as well as human and technical biases during data acquisition, labelling, data curation, or the selection of the input features.

## Section: FUTURE-AI guideline › Fairness › Fairness 2: Collect information on individual and data attributes

To identify biases and apply measures for increased fairness, relevant attributes of the individuals, such as sex, gender, age, ethnicity, risk factors, comorbidities, or disabilities, should be collected. This should be subject to informed consent and approval by ethics committees to ensure an appropriate balance between the benefits of non-discrimination and the risks of reidentification. Measuring similarity of medical profiles should also be included to verify equal treatment (eg, risk factors, comorbidities, biomarkers, anatomical properties34). Furthermore, relevant information about the datasets, such as the centres where they were acquired, the machine used, the preprocessing and annotation processes, should be systematically collected to address technical and human biases. When complete data collection is logistically challenging, two alternative approaches can be considered: imputing missing attributes or removing samples with incomplete data. The choice between these methods should be evaluated on a case-by-case basis, considering the specific context and requirements of the AI system.

## Section: FUTURE-AI guideline › Fairness › Fairness 3: Evaluate fairness

When possible—that is, the individuals’ and data attributes are available—bias detection methods should be applied by using fairness metrics such as true positive rates, statistical parity, group fairness, and equalised odds.31 35 To correct for any identified biases, mitigation measures should be tested, such as data resampling, bias free representations, and equalised odds postprocessing,36 37 38 39 40 to verify their impact on both the tool’s fairness and the model’s accuracy. Importantly, any remaining bias should be documented and reported to inform the end users and citizens (see traceability 2).

## Section: FUTURE-AI guideline › Universality

The universality principle emphasises that a healthcare AI tool should be generalisable outside the controlled environment where it was built. Specifically, the AI tool should be able to generalise to new patients and new users (eg, new clinicians), and when applicable, to new clinical sites. Depending on the intended radius of application, healthcare AI tools should be as interoperable and as transferable as possible so they can benefit citizens and clinicians at scale. To this end, four recommendations for universality are defined in the FUTURE-AI framework.

## Section: FUTURE-AI guideline › Universality › Universality 1: Define clinical settings

At the design phase, the development team should specify the clinical settings in which the AI tool will be applied (eg, primary healthcare centres, hospitals, home care, low versus high resource settings, one or several countries), and anticipate potential obstacles to universality (eg, differences in end users, clinical definitions, medical equipment or IT infrastructures across settings).

## Section: FUTURE-AI guideline › Universality › Universality 2: Use existing standards

To ensure the quality and interoperability of the AI tool, it should be developed based on existing community defined standards. These might include clinical definitions of diseases by medical societies, medical ontologies (eg, Systematized Nomenclature of Medicine Clinical Terms (SNOMED CT)41), data models (eg, Observational Medical Outcomes Partnership (OMOP)42), interface standards (eg, Digital Imaging and Communications in Medicine (DICOM), Fast Healthcare Interoperability Resources (FHIR) Health Level Seven (HL7)), data annotation protocols, evaluation criteria,21 and technical standards (eg, Institute of Electrical and Electronics Engineers (IEEE)43 or International Organisation for Standardization (ISO)44).21 41 42 43 44

## Section: FUTURE-AI guideline › Universality › Universality 3: Evaluate using external data

To assess generalisability, technical validation of the AI tools should be performed with external datasets that are distinct from those used for model training.45 These might include reference or benchmarking datasets that are representative for the task in question (ie, approximating the expected real world variations). Except for AI tools intended for single centres, the clinical evaluation studies should be performed at several sites to assess performance and interoperability across clinical workflows.46 If the tool’s generalisability is limited, mitigation measures (eg, transfer learning or domain adaptation) should be applied and tested.

## Section: FUTURE-AI guideline › Universality › Universality 4: Evaluate local clinical validity

Clinical settings vary in many aspects, such as populations, equipment, clinical workflows, and end users. Therefore, to ensure trust at each site, the AI tools should be evaluated for their local clinical validity.17 In particular, the AI tool should fit the local clinical workflows and perform well on the local populations. If the performance is decreased when evaluated locally, recalibration of the AI model should be performed and tested (eg, through model fine tuning).

## Section: FUTURE-AI guideline › Traceability

The traceability principle states that medical AI tools should be developed together with mechanisms for documenting and monitoring the complete trajectory of the AI tool, from development and validation to deployment and usage. This will increase transparency and accountability by providing detailed and continuous information on the AI tools during their lifetime to clinicians, healthcare organisations, citizens and patients, AI developers, and relevant authorities. AI traceability will also enable continuous auditing of AI models,47 identify risks and limitations, and update the AI models when needed.

## Section: FUTURE-AI guideline › Traceability › Traceability 1: Implement risk management

Throughout the AI tool’s lifecycle, the multidisciplinary development team shall analyse potential risks, assess each risk’s likelihood, effects and risk-benefit balance, define risk mitigation measures, monitor the risks and mitigations continuously, and maintain a risk management file. The risks might include those explicitly covered by the FUTURE-AI guiding principles (eg, bias, harm, data breach), but also application specific risks. Other risks to consider include human factors that might lead to misuse of the AI tool (eg, not following the instructions, receiving insufficient training), application of the AI tool to individuals who are not within the target population, use of the tool by others than the target end users (eg, technician instead of physician), hardware failure, incorrect data annotations or input values, and adversarial attacks. Mitigation measures might include warnings to the users, system shutdown, reprocessing of the input data, the acquisition of new input data, or the use of an alternative procedure or human judgment only. Monitoring and reassessment of risk might involve the use of various feedback channels, such as customer feedback and complaints, as well as logged real world performance and issues (see traceability 5).

## Section: FUTURE-AI guideline › Traceability › Traceability 2: Provide documentation

To increase transparency, traceability, and accountability, adequate documentation should be created and maintained for the AI tool,48 which might include (a) an AI information leaflet to inform citizens and healthcare professionals about the tool’s intended use, risks (eg, biases) and instructions for use; (b) a technical document to inform AI developers, health organisations, and regulators about the AI model’s properties (eg, hyperparameters), training and testing data, evaluation criteria and results, biases and other limitations, and periodic audits and updates49 50 51; (c) a publication based on existing AI reporting standards13 15 52; and (d) a risk management file (see traceability 1).

## Section: FUTURE-AI guideline › Traceability › Traceability 3: Implement continuous quality control

The AI tool should be developed and deployed with mechanisms for continuous monitoring and quality control of the AI inputs and outputs,47 such as to identify missing or out-of-range input variables, inconsistent data formats or units, incorrect annotations or data preprocessing, and erroneous or implausible AI outputs. For quality control of the AI decisions, uncertainty estimates should be provided (and calibrated53) to inform the end users about the degree of confidence in the results.54

## Section: FUTURE-AI guideline › Traceability › Traceability 4: Implement periodic auditing and updating

The AI tool should be developed and deployed with a configurable system for periodic auditing,47 which should define the datasets and timelines for periodic evaluations (eg, every year). The periodic auditing should enable the identification of data or concept drifts, newly occurring biases, performance degradation or changes in the decision making of the end users.55 Accordingly, necessary updates to the AI models or AI tools should be applied.56

## Section: FUTURE-AI guideline › Traceability › Traceability 5: Implement AI logging

To increase traceability and accountability, an AI logging system should be implemented to trace the user’s main actions in a privacy preserving manner, specify the data that are accessed and used, record the AI predictions and clinical decisions, and log any encountered issues. Time series statistics and visualisations should be used to inspect the usage of the AI tool over time.

## Section: FUTURE-AI guideline › Traceability › Traceability 6: Implement AI governance

After deployment, the governance of the AI tool should be specified. In particular, the roles of risk management, periodic auditing, maintenance, and supervision should be assigned, such as to IT teams or healthcare administrators. Furthermore, responsibilities for AI related errors should be clearly specified among clinicians, healthcare centres, AI developers, and manufacturers. Accountability mechanisms should be established, incorporating both individual and collective liability, alongside compensation and support structures for patients affected by AI errors.

## Section: FUTURE-AI guideline › Usability

The usability principle states that the end users should be able to use an AI tool to achieve a clinical goal efficiently and safely in their real world environment. On one hand, this means that end users should be able to use the AI tool’s functionalities and interfaces easily and with minimal errors. On the other hand, the AI tool should be clinically useful and safe, for example, improve the clinicians’ productivity and/or lead to better health outcomes for the patients and avoid harm. To this end, five recommendations for usability are defined in the FUTURE-AI framework.

## Section: FUTURE-AI guideline › Usability › Usability 1: Define user requirements

The AI developers should engage clinical experts, end users (eg, patients, physicians), and other relevant stakeholders (eg, data managers, administrators) from an early stage to compile information on the AI tool’s intended use and end user requirements (eg, human-AI interfaces), as well as on human factors that might affect the usage of the AI tool57 (eg, digital literacy level, age group, ergonomics, automation bias). Special attention should be paid to the fit with the current clinical workflow, including system level implementation of AI and interactions with other (AI) support tools. Using a majority voting strategy among diverse stakeholders to identify the most relevant clinical issues might help to ensure that solutions are broadly applicable rather than tailored to individual preferences.

## Section: FUTURE-AI guideline › Usability › Usability 2: Define human-AI interactions and oversight

Based on the user requirements, the AI developers should implement interfaces to enable end users to effectively use the AI model, annotate the input data in a standardised manner, and verify the AI inputs and results. Given the high stakes nature of medical AI, human oversight is essential and increasingly required by policy makers and regulators.17 26 Human-in-the-loop mechanisms should be designed and implemented to perform specific quality checks (eg, to flag biases, errors, or implausible explanations), and to overrule the AI predictions when necessary. Regulations, the benefits of automation, and patient preferences regarding AI autonomy might vary per use case and over time,58 therefore requiring use case specific human oversight mechanisms and periodic auditing and updates (see traceability 4).

## Section: FUTURE-AI guideline › Usability › Usability 3: Provide training

To facilitate best usage of the AI tool, minimise errors and harm, and increase AI literacy, the developers should provide training materials (eg, tutorials, manuals, examples) and/or training activities (eg, hands-on sessions) in an accessible format and language, taking into account the diversity of end users (eg, specialists, nurses, technicians, citizens, or administrators).

## Section: FUTURE-AI guideline › Usability › Usability 4: Evaluate clinical usability

To facilitate adoption, the usability of the AI tool within the local clinical workflows should be evaluated in real world settings with representative and diverse end users (eg, with respect to sex, gender, age, clinical role, digital proficiency, and disability). The usability tests should gather evidence on the user’s satisfaction, performance and productivity, and assess human factors that might affect the usage of the AI tool57 (eg, confidence, learnability, automation bias).

## Section: FUTURE-AI guideline › Usability › Usability 5: Evaluate clinical utility

The AI tool should be evaluated for its clinical utility and safety. The clinical evaluations of the AI tool should show benefits for the patient (eg, earlier diagnosis, better outcomes), for the clinician (eg, increased productivity, improved care), and/or for the healthcare organisation (eg, reduced costs, optimised workflows) compared with the current standard of care. Additionally, it is important to show that the AI tool is safe and does not cause harm to individuals (or specific groups), such as through a randomised clinical trial.59

## Section: FUTURE-AI guideline › Robustness

The robustness principle refers to the ability of a medical AI tool to maintain its performance and accuracy under expected or unexpected variations in the input data. Existing research has shown that even small, imperceptible variations in the input data might lead AI models into incorrect decisions.60 Biomedical and health data can be subject to major variations in the real world (both expected and unexpected), which can affect the performance of AI tools. Therefore, it is important that healthcare AI tools are designed and developed to be robust against real world variations, and evaluated and optimised accordingly. To this end, three recommendations for robustness are defined in the FUTURE-AI framework.

## Section: FUTURE-AI guideline › Robustness › Robustness 1: Define sources of data variations

At the design phase, the development team should first define robustness requirements for the AI tool in question by making an inventory of the sources of variation that might affect the AI tool’s robustness in the real world. These might include differences in equipment, technical fault of a machine, data heterogeneities during data acquisition or annotation, and/or adversarial attacks.60

## Section: FUTURE-AI guideline › Robustness › Robustness 2: Train with representative data

Clinicians, citizens, and other stakeholders are more likely to trust the AI tool if it is trained on data that adequately represent the variations encountered in real world clinical practice.61 Therefore, the training datasets should be carefully selected, analysed, and enriched according to the sources of variation identified at the design phase (see robustness 1). Training with representative datasets also allows for improvement of other principles, for example, more representative bias estimation and mitigation for fairness.

## Section: FUTURE-AI guideline › Robustness › Robustness 3: Evaluate robustness

Evaluation studies should be implemented to evaluate the AI tool’s robustness (eg, stress tests, repeatability tests62) under conditions that reflect the variations of real world clinical practice. These might include data, equipment, technician, clinician, patient, and centre related variations. Depending on the results, mitigation measures should be implemented and tested to optimise the robustness of the AI model, such as regularisation,63 data augmentation,64 data harmonisation,65 or domain adaptation.66

## Section: FUTURE-AI guideline › Explainability

The explainability principle states that medical AI tools should provide clinically meaningful information about the logic behind the AI decisions. Although medicine is a high stake discipline that requires transparency, reliability and accountability, machine learning techniques often produce complex models that are black box in nature. Explainability is considered desirable from a technological, medical, ethical, legal, and patient perspective.67 It enables end users to interpret the AI model and outputs, understand the capacities and limitations of the AI tool, and intervene when necessary, such as to decide to use it or not. However, explainability is a complex task that has challenges that need to be carefully addressed during AI development and evaluation to ensure that AI explanations are clinically meaningful and beneficial to end users.68 Two recommendations for explainability are defined in the FUTURE-AI framework.

## Section: FUTURE-AI guideline › Explainability › Explainability 1: Define explainability needs

At the design phase, it should be established with end users and domain experts if explainability is required for the AI tool. If so, the specific requirements for explainability should be defined with representative experts and end users, including (a) the goal of the explanations (eg, global description of the model’s behaviour v local explanation of each AI decision); (b) the most suitable approach for AI explainability69; and (c) the potential limitations to anticipate and monitor (eg, over-reliance of the end users on the AI decision68).

## Section: FUTURE-AI guideline › Explainability › Explainability 2: Evaluate explainability

The explainable AI methods should be evaluated, first quantitatively by using computational methods to assess the correctness of the explanations,70 71 then qualitatively with end users to assess their impact on user satisfaction, confidence, and clinical performance.72 The evaluations should also identify any limitations of the AI explanations (eg, they are clinically incoherent73 or sensitive to noise or adversarial attacks,74 they unreasonably increase the confidence in the AI generated results75).

## Section: FUTURE-AI guideline › General recommendations

Finally, seven general recommendations are defined in the FUTURE-AI framework, which apply across all principles of trustworthy AI in healthcare.

Embedding the FUTURE-AI best practices into an agile process throughout the artificial intelligence (AI) lifecycle. E=explainability; F=fairness; G=general; R=robustness; T=traceability; Un=universality; Us=usability

## Section: FUTURE-AI guideline › General recommendations › General 1: Engage stakeholders continuously

Throughout the AI tool’s lifecycle, the AI developers should continuously engage with interdisciplinary stakeholders, such as healthcare professionals, citizens, patient representatives, expert ethicists, data managers, and legal experts. This interaction will facilitate the understanding and anticipation of the needs, obstacles, and pathways towards acceptance and adoption. Methods to engage stakeholders might include working groups, advisory boards, one-to-one interviews, cocreation meetings, and surveys.

## Section: FUTURE-AI guideline › General recommendations › General 2: Ensure data protection

Adequate measures to ensure data privacy and security should be put in place throughout the AI lifecycle. These might include privacy enhancing techniques (eg, differential privacy, encryption), data protection impact assessment, and appropriate data governance after deployment (eg, logging system for data access, see traceability 5). If deidentification is implemented (eg, pseudonymisation, k-anonymity), the balance between the health benefits for citizens and the risks for reidentification should be carefully assessed and considered. Furthermore, the manufacturers and deployers should implement and regularly evaluate measures for protecting the AI tool against malicious or adversarial attacks, such as by using system level cybersecurity solutions or application specific defence mechanisms (eg, attack detection or mitigation).76

## Section: FUTURE-AI guideline › General recommendations › General 3: Implement measures to address AI risks

At the development stage, the development team should define an AI modelling plan that is aligned with the application specific requirements. After implementing and testing a baseline AI model, the AI modelling plan should include mitigation measures to address the challenges and risks identified at the design stage (see fairness 1 to explainability 1). These might include measures to enhance robustness to real world variations (eg, regularisation, data augmentation, data harmonisation, domain adaptation), ensure generalisability across settings (eg, transfer learning, knowledge distillation), and correct for biases across subgroups (eg, data resampling, bias free representation, equalised odds post processing).

## Section: FUTURE-AI guideline › General recommendations › General 4: Define an adequate AI evaluation plan

To increase trust and adoption, an appropriate evaluation plan should be defined, including test data, metrics, and reference methods. First, adequate test data should be selected to assess each dimension of trustworthy AI. In particular, the test data should be well separated from the training to prevent data leakage.77 Furthermore, adequate evaluation metrics should be carefully selected, taking into account their benefits and potential flaws.78 Finally, benchmarking with respect to reference AI tools or standard practice should be performed to enable comparative assessment of model performance.

## Section: FUTURE-AI guideline › General recommendations › General 5: Comply with AI regulations

The development team should identify the applicable AI regulations, which vary by jurisdiction and over time. For example, in the EU, the recent AI Act classifies all AI tools in healthcare as high risk, hence they must comply with safety, transparency and quality obligations, and undergo conformity assessments. Identifying the applicable regulations at an early stage enables regulatory obligations to be anticipated based on the AI tool’s intended classification and risks.

## Section: FUTURE-AI guideline › General recommendations › General 6: Investigate application specific ethical issues

In addition to the well known ethical issues that arise in medical AI (eg, privacy, transparency, equity, autonomy), AI developers, domain specialists, and professional ethicists should identify, discuss, and address all application specific ethical, social, and societal issues as an integral part of the development and deployment of the AI tool.79

## Section: FUTURE-AI guideline › General recommendations › General 7: Investigate social and environmental issues

In addition to clinical, technical, legal, and ethical implications, a healthcare AI tool might have specific social and environmental issues. These will need to be considered and addressed to ensure a positive impact for the AI tool on citizens and society. Regulatory agencies or independent organisations could provide certifications or marks for AI tools that meet certain sustainability criteria. This approach can encourage transparency, give insight on an AI tool’s environmental impact, and highlight those that adopt environmentally friendly practices. Relevant issues might include the impact of the AI tool on the working conditions and power relations, on the new skills (or deskilling) of the healthcare professionals and citizens,80 and on future interactions between citizens, health professionals, and social careers. Furthermore, for environmental sustainability, AI developers should consider strategies to reduce the carbon footprint of the AI tool.81 To enable the implementation of the FUTURE-AI framework in practice, we provide a step-by-step guide by embedding the recommended best practices in chronological order across the key phases of an AI tool’s lifecycle, as shown in figure 3 and as follows:

Embedding the FUTURE-AI best practices into an agile process throughout the artificial intelligence (AI) lifecycle. E=explainability; F=fairness; G=general; R=robustness; T=traceability; Un=universality; Us=usability

## Section: Operationalisation of FUTURE-AI

In this section, we provide a detailed list of practical steps for each recommendation, accompanied by specific examples of approaches and methods that can be applied to operationalise each step towards trustworthy AI, as shown in table 3, table 4, table 5, and table 6. This approach offers easy-to-use, step-by-step guidance for all end users of the FUTURE-AI framework when designing, developing, validating and deploying new AI tools for healthcare.

Practical steps and examples to implement FUTURE-AI recommendations during design phase

Practical steps and examples to implement FUTURE-AI recommendations during development phase

Practical steps and examples to implement FUTURE-AI recommendations during evaluation phase

Practical steps and examples to implement FUTURE-AI recommendations during deployment phase

## Section: Discussion

Despite the tremendous amount of research in medical AI in recent years, currently only a limited number of AI tools have made the transition to clinical practice. Although many studies have shown the huge potential of AI to improve healthcare, major clinical, technical, socioethical, and legal challenges persist.

In this paper, we presented the results of an international effort to establish a consensus guideline for developing trustworthy and deployable AI tools in healthcare. To this end, the FUTURE-AI Consortium was established, which provided knowledge and expertise across a wide range of disciplines and stakeholders, resulting in consensus and wide support, both geographically and across domains. Through an iterative process that lasted 24 months, the FUTURE-AI framework was established, comprising a comprehensive and self-contained set of 30 recommendations, which covers the whole lifecycle of medical AI. By dividing the recommendations across six guiding principles, the pathways towards responsible and trustworthy AI are clearly characterised. Because of its broad coverage, the FUTURE-AI guideline can benefit a wide range of stakeholders in healthcare, as detailed in table 2 in the appendix.

FUTURE-AI is a risk informed framework, proposing to assess application specific risks and challenges early in the process (eg, risk of discrimination, lack of generalisability, data drifts over time, lack of acceptance by end users, potential harm for patients, lack of transparency, data security vulnerabilities, ethical risks), followed by implementing tailored measures to reduce these risks (eg, collect data on individuals’ attributes to assess and mitigate bias). As the specific measures to be implemented have benefits and potential weaknesses that the developers need to assess and take into consideration, a risk-benefit balancing trade-off has to be made. For example, collecting data on individuals’ attributes might increase the risk of reidentification, but can enable the risk of bias and discrimination to be reduced. Therefore, in FUTURE-AI, risk management (as recommended in traceability 1) must be a continuous and transparent process throughout the AI tool’s lifecycle.

FUTURE-AI is also an assumption-free, highly collaborative framework, recommending to continuously engage with multidisciplinary stakeholders to understand application specific needs, risks, and solutions (general 1). This is crucial to investigate all possible risks and factors that might reduce trust in a specific AI tool. For example, instead of making any assumptions on possible sources of bias, FUTURE-AI recommends that AI developers engage with healthcare professionals, domain experts, representative citizens, and/or ethicists early in the process to form interdisciplinary AI development teams and investigate in-depth the application specific sources of bias, which might include domain specific attributes (eg, breast density for AI applications in breast cancer).

The FUTURE-AI guideline was defined in a generic manner to ensure it can be applied across a variety of domains (eg, radiology, genomics, mobile health, electronic health records). However, for many recommendations, their applicability varies across medical use cases, even within domains. To this end, the first recommendation in each of the guiding principles is to identify the specificities to be addressed, such as the types of biases (fairness 1), the clinical settings (universality 1), or the need and approaches for explainable AI (explainability 1). This facilitates generalisability across domains, but also ensures sustainability for future use. Furthermore, we recognise that a one-size-fits-all approach is not feasible, as addressal of many of the recommendations is use case specific, and standards do not exist yet or are subject to change. Therefore, we focused on developing best practices for enhancing the trustworthiness of medical AI tools, while consciously avoiding the imposition of specific techniques for the implementation of each recommendation. This flexibility also acknowledges the diversity of methods for tackling challenges and mitigating risks in medical AI. For example, the recommendation to protect personal data during AI training can be implemented through data deidentification, federated learning, differential privacy or encryption, among other methods. While such concrete examples are listed in this article, especially in table 3, table 4, table 5, and table 6, the most adequate techniques for implementing each recommendation should be ultimately selected by the AI development team as a function of the application domain, clinical use case, and data characteristics, as well as the advantages and limitations of each method. Similarly, all stakeholders of the AI development team are together responsible for addressing the recommendations, where the role of each party might vary per application, method, domain, project setup, and use case.

While the FUTURE-AI framework offers insights for regulating medical AI, future work is needed to incorporate these recommendations into regulatory procedures. For example, we propose mechanisms to enhance traceability and governance, such as logging. However, the crucial issue of liability is yet to be addressed, for example, who should perform the audits and who should be accountable for errors. Furthermore, we recommend continuous evaluation and fine tuning of AI models over time. However, current regulations prevent post release modifications because they would formally invalidate the manufacturer’s initial validation. Future regulations should address the possibility of local adaptations within predefined acceptance criteria.

On one hand, implementation of the FUTURE-AI guideline might involve substantial costs, which could affect both AI developers and healthcare systems. These financial considerations could potentially exacerbate disparities in AI adoption, particularly affecting smaller developers and resource limited health systems. Collaborative efforts involving stakeholders from various sectors could help to distribute the financial burden and support equitable access to advanced AI tools. On the other hand, early adoption of the FUTURE-AI guideline might save costs. Instead of developing AI tools that do not have clinical added value or having to address various of the outlined principles after developing a tool, early adoption will result in a trustworthy and deployable AI tool by design and can be more cost effective than post development adoption, which, in practice, often requires costly change requests that affect large parts of a tool's solution architecture.

Finally, progressive development and adoption of medical AI tools will lead to new requirements, challenges, and opportunities. For some of the recommendations, no clear standard on how these should be addressed yet exists. Aware of this reality, we propose FUTURE-AI as a dynamic, living framework. To refine the FUTURE-AI guideline and learn from other voices, we set up a dedicated webpage (www.future-ai.eu) through which we invite the community to join the FUTURE-AI network and provide feedback based on their own experience and perspective. On the website we include a FUTURE-AI self-assessment checklist, which comprises a set of questions and examples to facilitate and illustrate the use of the FUTURE-AI recommendations. Additionally, we plan to organise regular outreach events such as webinars and workshops to exchange with medical AI researchers, manufacturers, evaluators, end users, and regulators. Future research includes more in-depth studies of the operationalisation of FUTURE-AI in specific healthcare domains, leading to domain specific methods on the addressal of the recommendations, and of each principle as these have become rapidly evolving fields of their own, for example, Fair ML and Explainable AI (XAI).

## Section: Acknowledgments

This work has been supported by the European Union’s Horizon 2020 under grant agreement No 952159 (ProCAncer-I), No 952172 (CHAIMELEON), No 826494 (PRIMAGE), No 952179 (INCISIVE), No 101034347 (OPTIMA), No 101016775 (INTERVENE), No 101100633 (EUCAIM), No 101136670 (GLIOMATCH), No 101057062 (AIDAVA), No 101095435 (REALM), and No 116074 (BigData@Heart). This work received support from the European Union’s Horizon Europe under grant agreement No 101057699 (RadioVal), No 101057849 (DataTools4Heart), and No 101080430 (AI4HF). This work received support from the European Research Council under grant agreement No 757173 (MIRA), No 884622 (Deep4MI), No 101002198 (NEURAL SPICING), No 866504 (CANCER-RADIOMICS), and No 101044779 (AIMIX). This work was partially supported by the Royal Academy of Engineering, Hospital Clinic Barcelona, Malaria No More, Carnegie Cooperation New York, Human frontier science programme, Natural Sciences and Engineering Research Council of Canada (NSERC), the Australian National Health and Medical Research Council Ideas under grant No 1181960, United States Department of Defence W81XWH2010747-P1, 3IA Côte d'Azur Investments in the Future project managed by the National Research Agency (ANR-19-P3IA-0002), InTouchAI.eu, IITP grant funded by the Korean government (No 2020-0-00594), A*STAR Career Development Award (project No C210112057) from the Agency for Science, Technology and Research (A*STAR), National Institute for Health and Care Research Barts Biomedical Research Centre, Centre National de la Recherche Scientifique (CNRS), MPaCT-Data. Infraestructura de Medicina de Precisión asociada a la Ciencia y la Tecnología (Exp. IMP/00019) funded by Instituto de Salud Carlos III and the Fondo Europeo de Desarrollo Regional (FEDER, “Una manera de hacer Europa”), Ministry of Science, Technology and Innovation of Colombia project code 110192092354, Gordon and Betty Moore Foundation, Google Award for Inclusion Research, Fraunhofer Heinrich Hertz Institute, US National Institutes of Health, National Council for Scientific and Technological Development (CNPq), European Heart Network, NIBIB/University of Chicago (MIDRC), Hong Kong Research Grants Council Theme-based Research Scheme (TRS) project T45-401/22-N, Young Researcher Project (19PEJC09-03) funded by the Ministry of High Education of Tunisia, Juan de la Cierva with reference number FJC2021-047659-I, Nepal Applied Mathematics and Informatics Institute for Research (NAAMII), Fogarty International Center of the National Institutes of Health under Award No 5U2RTW012131-02, Universidad Galileo, Natural Science Foundation of China under grant 62271465, Israel Science Foundation, National Institutes of Health (NIH), Dutch Cancer Society (KWF Kankerbestrijding) under project No 14449, Netherlands Organisation for Scientific Research (NWO) VICI project VI.C.182.042, National Center for Artificial Intelligence CENIA (ANID-BASAL FB210017), Google Research, Independent Research Fund Denmark (DFF, grant No 9131-00097B), Wellcome Flagship Programme (WT213038/Z/18/Z), Cancer Research UK programme grant (C49297/A27294), the MIDRC (The Medical Imaging and Data Resource Center), made possible by the National Institute of Biomedical Imaging and Bioengineering (NIBIB) of the National Institutes of Health under contract 75N92020D00021, and the Employee European Heart Network. Also, this work was partially supported by the project FUTURE-ES (PID2021-126724OB-I00) and AIMED (PID2023-146786OB-I00) from the Ministry of Science, Innovation and Universities of the Government of Spain.

## Section: Text

Extra material supplied by authors

Web appendix 1: Appendix

Web appendix 2: FUTURE-AI Consortium

## Section: Contributor Information

Collaborators: FUTURE-AI Consortium, Aasa Feragen, Abdul Joseph Fofanah, Alena Buyx, Anais Emelie, Andrea Lara, An-Wen Chan, Arcadi Navarro, Benard O Botwe, Bishesh Khanal, Brigit Beger, Carol C Wu, Daniel Rueckert, Deogratias Mzurikwao, Dimitrios I Fotiadis, Doszhan Zhussupov, Enzo Ferrante, Erik Meijering, Fabio A González, Gabriel P Krestin, Geletaw S Tegenaw, Gianluca Misuraca, Girish Dwivedi, Haridimos Kondylakis, Harsha Jayakody, Henry C Woodruff, Horst Joachim Mayer, Hugo JWL Aerts, Ian Walsh, Ioanna Chouvarda, Isabell Tributsch, Islem Rekik, James Duncan, Jihad Zahir, Jinah Park, Judy W Gichoya, Kensaku Mori, Leticia Rittner, Lighton Phiri, Linda Marrakchi-Kacem, Lluís Donoso-Bach, Maria Bielikova, Marzyeh Ghassemi, Md Ashrafuzzaman, Mohammad Yaqub, Mukhtar M E Mahmoud, Mustafa Elattar, Nicola Rieke, Oliver Díaz, Olivier Salvado, Ousmane Sall, Pamela Guevara, Peter Gordebeke, Philippe Lambin, Pieta Brown, Purang Abolmaesumi, Qi Dou, Qinghua Lu, Rose Nakasi, S Kevin Zhou, Shadi Albarqouni, Stacy Carter, Steffen E Petersen, Suyash Awate, Tammy Riklin Raviv, Tessa Cook, Tinashe E M Mutsvangwa, Wiro J Niessen, Xènia Puig-Bosch, Yi Zeng, Yunusa G Mohammed, and Yves Saint James Aquino

## Section: Associated Data

Web appendix 1: Appendix

Web appendix 2: FUTURE-AI Consortium

## Section: Associated Data › Supplementary Materials

Web appendix 1: Appendix

Web appendix 2: FUTURE-AI Consortium


---

# Generalizability of FDA-Approved AI-Enabled Medical Devices for Clinical Use

- **Authors:** Daniel Windecker, Giovanni Baj, Isaac Shiri, Pooya Mohammadi Kazaj, Johannes Kaesmacher, Christoph Gräni, George C M Siontis
- **Issuer:** JAMA network open
- **Type:** Scientific article
- **Published:** 2025-04-01
- **Language:** en
- **DOI:** 10.1001/jamanetworkopen.2025.8052
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40305017/
- **Licence:** CC-BY

## Section: Abstract

Key PointsQuestionTo what extent are the key characteristics of medical devices approved by the US Food and Drug Administration (FDA) that use artificial intelligence (AI) ensuring clinical generalizability publicly known and reported?FindingsThis cross-sectional study of 903 devices found that at the time of regulatory approval, clinical performance studies were reported for approximately half of the analyzed devices, while one-quarter explicitly stated that no such studies had been conducted. Less than one-third of the clinical evaluations provided sex-specific data, and only one-fourth addressed age-related subgroups.MeaningThese findings suggest that available information on the FDA website was frequently insufficient for a thorough assessment of the devices’ clinical generalizability, highlighting the importance of ongoing monitoring and regular re-evaluation to identify and address unexpected changes in performance during broader clinical use.

## Section: Introduction

The advent of artificial intelligence (AI) leads to an ever-increasing number of medical devices that incorporate AI software applications for clinical use.1,2 These devices aim to facilitate and improve diagnostic work-up, provide risk estimation, and advance treatment outcomes.3,4,5 The rapid surge in harnessing the power of AI to accelerate medical research and exploit its capacity when addressing specific clinical challenges has led to the regulatory approval of numerous applications.5,6,7 Despite the promising potential and broad applications, transparent information regarding key characteristics and outcomes related to the clinical evaluation of these devices at the time of regulatory approval is not well established.5,7,8,9,10

Nonetheless, the US Food and Drug Administration (FDA) maintains a publicly accessible list of AI-enabled medical devices approved for clinical use, providing detailed information for each device.11 These devices are subjected to different evaluation pathways according to several reports. For instance, during the period 2015 to 2020, the FDA approved 222 AI medical device software products via the 510(k) pathway, which relies on demonstrating equivalence to existing devices.12 Conversely, submitted devices that lack substantially equivalent existing devices on the market must undergo the more stringent de novo or premarket approval process.13 Although the primary goal of every newly developed AI-enabled medical device is to ensure safe use in clinical practice, it has been suggested that dedicated clinical evaluations are both limited in scope and often have significant shortcomings.5,8

Against this background, we aimed to summarize and outline key characteristics of AI-enabled medical devices that had received FDA approval for clinical use across various medical fields and to assess publicly available characteristics that support a thorough assessment of their clinical generalizability at the time of approval.

## Section: Methods

This cross-sectional analysis was based on publicly available information and classified as non–human participants research; therefore, due to the nature of the study design, ethical review and approval by an ethics committee were not required per 45 CFR § 46.102. Additionally, obtaining informed consent from study participants was not applicable.

## Section: Methods › AI-Enabled Medical Devices

Our cross-sectional analysis was focused solely on information publicly available for AI-enabled medical devices approved for clinical use by the FDA and listed online.11 For the purpose of this analysis, we evaluated all AI-enabled medical devices that had received FDA approval for clinical use and were published on the FDA website from inception of the registry to August 31, 2024. No additional selection criteria were applied. The FDA provides a public repository of these devices.11

## Section: Methods › Information Summarized on Device Level

All information was extracted from online sources and documents downloaded from the FDA website.11 We collated the following data for each AI-enabled medical device as derived from the FDA website and the attached summary reports for each tool: device and company name, country of origin, type of 510(k) submission program, identification number of the device, medical specialty domain, 510(k) review panel specialty, office responsible for premarket review, device classification name providing keywords or sentences about the theme of the device, date of application received, decision date, and final outcome of regulatory evaluation.

We recorded information regarding eligibility for and performance of third-party review, regulatory class of the device, submission type, Good Manufacturing Practice exemption availability of summary malfunction reporting, implant status of the device, life-sustain/support nature of device, specified target area of the device, and Digital Imaging and Communications in Medicine adherence. We also summarized details on recalls of devices (date of recall, recall class, FDA recall posting date, availability of validation summary, availability of FDA decision summary, type of use (prescription vs over-the-counter use), submission number of potential primary predicate device, and physical state (software only or software and hardware).

In addition, we recorded whether clinical performance studies were performed and reported on the summary page provided by the FDA. For each of the studies reporting the development and/or clinical performance of the device, we recorded the study design (retrospective, prospective nonrandomized, prospective randomized trials), the number of participating sites, countries, and sample size. We summarized whether baseline demographics were provided for the overall study population and in addition for sex- and age-specific subgroups. Finally, we summarized available information related to the diagnostic or predictive performance of the AI-enabled medical device in terms of sensitivity, specificity, and discriminatory ability (area under the curve [AUC]).

## Section: Methods › Statistical Analysis

We summarized the descriptive characteristics by using each AI-enabled medical device as the analysis unit as mean (SD), median (IQR), or count (percentage) as appropriate. We created illustrative maps to summarize relevant characteristics of the devices and provide graphical depiction of changes over time. The time point when reports became publicly available in relation to the respective FDA approval date was taken into consideration. We provided an overview of items that are relevant for the evaluation and broader use of AI-enabled medical devices, namely the reporting of a clinical performance study related to the diagnostic or predictive performance, and available information on age- and sex-specific subgroups. All data management and illustrations were carried out using various libraries in Python software version 3.10 (Python Software Foundation).

## Section: Results

AI indicates artificial intelligence; FDA, Food and Drug Administration.

AUC indicates area under the curve. The diagonal plots display the distribution of each individual metric (AUC, sensitivity, and specificity), while the off-diagonal scatter plots show the pairwise relationships between these metrics. Only 3 recalled devices had available sensitivity and specificity values, but none of them had AUC values.

Devices are shortlisted based on their Food and Drug Administration approval timeline. Each device is identified by its unique Food and Drug Administration submission number.

## Section: Results › AI-Enabled Medical Devices

In total, we compiled information on 903 AI-enabled medical devices listed online on the FDA website by August 31, 2024. The summary characteristics are shown in the Table. The number of AI-enabled medical devices approved by the FDA has grown exponentially in recent years (eFigure 1 in Supplement 1). Half of all devices (467 devices [51.7%]) were submitted by North American–based applicants, with most being registered in the US (Figure 1; eFigure 2 in Supplement 1). European- and Asian-based companies contributed a similar number of AI-enabled devices, with 183 devices (20.3%) and 154 devices (17.1%), respectively. Most AI-enabled devices were in the fields of radiology (692 devices [76.6%]), cardiovascular (91 devices [10.1%]), and neurology (29 devices [3.2%]); most of the devices (877 devices [97.1%]) were cleared under the 510(k) regulatory pathway, while 22 devices (2.4%) underwent the de novo regulatory pathway. Most AI-enabled devices were purely software-based (664 devices [73.5%]), with approximately one-quarter comprising physical devices coupled with software (239 devices [26.5%]) (Table; eFigure 3 in Supplement 1). Only 6 entities (0.7%) pertained to implanted medical devices.

AI indicates artificial intelligence; FDA, Food and Drug Administration.

## Section: Results › Clinical Performance Studies

A clinical performance study was reported for 505 of the AI-enabled medical devices (55.9%) (Table; eFigure 4 in Supplement 1). In 218 submissions (24.1%), it was explicitly stated that no such study had been conducted, while 180 submissions (19.9%) did not specify whether a clinical performance study had been performed. Among the clinical studies conducted, retrospective evaluations were the most common study design, accounting for 193 studies (38.2%), while 41 studies (8.1%) were prospective and 12 studies (2.4%) used a randomized clinical design. Of the remaining 259 submissions (51.3%) that reported a clinical performance study, the study design was not specified (Table and Figure 2; eFigure 5 in Supplement 1). Among the clinical performance studies, information on sex subgroups was available in less than one-third (145 studies [28.7%]), and 117 studies (23.2%) provided information on age-related subgroups.

The discriminatory performance of AI-enabled medical devices, as reported in clinical performance studies, was typically expressed in terms of sensitivity, specificity, or AUC. However, these metrics were available for only a minority of the devices, often without a clear description of the study cohort in which the performance was assessed. Sensitivity, specificity, and AUC were reported for 183 devices (36.2%), 176 devices (34.9%), and 82 devices (16.2%) of 505 devices that included clinical studies (Figure 3). The pair-plot in Figure 3 illustrates the pairwise associations between these 3 metrics, providing a visual overview of how they correlate with one another. A large proportion of the AI-enabled devices demonstrated high discriminatory performance, with scores exceeding 0.80 on these metrices. The off-diagonal elements of the pair-plot (represented as bubble plots) capture the scatter associations between each pair of metrics. In particular, comparisons between AUC and either sensitivity or specificity shed light on the interplay between predictive accuracy and the device’s ability to correctly identify true positives (sensitivity) and true negatives (specificity). Device clustering toward the upper-right corner of the plot indicate a well-balanced performance, with both high sensitivity and specificity. Devices with high AUC tended to show high sensitivity, implying that these devices are effective at identifying true positives. It is noteworthy that some outliers exist—devices that exhibit high AUC values but demonstrate very low sensitivity or specificity. These outliers correspond to applications where the device produces either high rate of false negatives or false positives, highlighting a potential issue in detecting true positives or negatives despite an overall high AUC.

AUC indicates area under the curve. The diagonal plots display the distribution of each individual metric (AUC, sensitivity, and specificity), while the off-diagonal scatter plots show the pairwise relationships between these metrics. Only 3 recalled devices had available sensitivity and specificity values, but none of them had AUC values.

## Section: Results › Recalled Devices

At the time of data extraction, 43 of 903 devices (4.8%) had been recalled (Table and Figure 1; eFigures 1, 4, and 5 in Supplement 1). The median (IQR) time lag between the decision of acceptance and the recall date was 1.2 (0.7-2.9) years (Figure 4). The pattern of recalled devices closely mirrored that of approved devices, with most recalls involving radiology-related devices and devices that had predominantly undergone evaluation through the 510(k) regulatory pathway (eFigure 4 in Supplement 1). Among 43 recalled AI-enabled medical devices, 2 were implantable devices (4.7%). Figure 4 illustrates the time lag across recalled device categorized by physical state. Clinical performance studies had been reported in 13 of the recalled devices (30.2%). Among these 13 devices with available clinical studies, 4 (30.8%) included details about the corresponding study design. Information on sex-specific and age-specific subgroups were provided in 1 study (7.7%) and 2 studies (15.4%), respectively (Table; eFigure 4 in Supplement 1).

Devices are shortlisted based on their Food and Drug Administration approval timeline. Each device is identified by its unique Food and Drug Administration submission number.

## Section: Discussion

In our cross-sectional study of the most comprehensive publicly available source of information on AI-enabled medical devices for clinical use, we analyzed a diverse range of such devices that have received FDA approval. At the time of regulatory approval, clinical performance studies had been reported for half of the devices, while one-quarter explicitly stated that none had been conducted. Most of the clinical performance studies were retrospective in design, and only 2% involved randomized clinical trials. The availability of discriminatory performance metrices was limited. Among the clinical studies, less than one-third included sex-specific data, and only one-fourth addressed age-related subgroups.

## Section: Discussion › Clinical Evaluation of Devices

Ensuring that AI models are trained on comprehensive and representative datasets is essential to avoid biases and ensure reliable outcomes in real-world applications.14,15,16,17,18 AI models are highly dependent on the data on which they are trained. If the training data are not representative of the broader population (eg, in terms of demographics, disease prevalence, or clinical settings), the AI’s performance may not perform equally well in different patient populations or environments.17,19 Without robust evidence of generalizability, the effectiveness and safety of these devices may be compromised when used outside of the controlled conditions in which they were initially validated. In addition, AI-enabled devices may perform differently in varied clinical settings due to differences in equipment, protocols, and health care practices. Models trained in one setting may not be effectively applied to another setting without appropriate retraining or adaptation. An AI device developed and validated in one country or region might not perform equally well in another with a different patient population, potentially impacting the generalizability of AI models on a global level. Therefore, the clinical evaluation and validation of AI-enabled medical devices is crucial and remains challenging.5,8,20

In accordance with the entirety of FDA-approved medical devices, most approved AI-enabled medical devices received approval via the 510(k) regulatory pathway.21,22,23 This pathway streamlines the approval process by mandating manufacturers to demonstrate that a new device shares technological characteristics and indications with legally authorized devices, thereby establishing substantial equivalence without the compulsory need for clinical testing.21,23,24 Furthermore, current FDA regulations do not prohibit voluntarily recalled devices from serving as predicates for future device authorizations.21,23

Given these considerations, the reliance on the 510(k) pathway raises significant safety concerns, particularly for high-risk (class I) medical devices.23 This issue is especially pertinent for implantable devices, which, due to their direct impact on individual patient health and safety, should be subject to more stringent approval requirements. However, the FDA database indicates that all implantable AI-enabled medical devices received approval via the less rigorous 510(k) pathway. Of note, a substantial proportion of implantable AI-enabled medical devices (2 of 6 devices [33.3%]) were later recalled by their manufacturers. This recall rate is comparable to trends observed across all FDA-approved medical devices, where most recalled devices underwent the 510(k) approval process. Notably, 19% of class I recalls across all medical devices involved implantable devices, potentially highlighting that substantial equivalence may be an inadequate marker of safety and efficacy.21,22,23,24

Unlike conventional software and devices, AI-enabled medical software and devices require continuous monitoring and evaluation, even when trained or adapted using datasets from the same center. This is due to AI’s susceptibility to data shifts, which may arise from domain changes.25,26 These shifts can include population shifts (eg, changes in population characteristics within the same region over time) or acquisition shifts (eg, changes in acquisition instruments or updates to their versions).25,26 Comprehensive validation, ongoing monitoring following the approval for clinical use, and potentially the adaptation of AI models to ensure they remain effective and reliable across various settings and populations are critical to ensure the clinical generalizability of AI-enabled medical devices.

Our evaluation found that most AI-enabled medical devices with information available in the public domain and approved by the FDA demonstrated high discriminatory performance, attesting the potential effectiveness in diagnostic settings where the identification of true positives is crucial. However, balancing sensitivity and specificity in the clinical setting is vitally important for applications that prioritize minimizing either false positives or false negatives. Additionally, given the novelty of AI technologies in the medical field, it remains largely uncertain whether reliance solely on procedural regulations—rather than outcomes-focused regulations—during the development of AI-enabled medical devices can ensure meaningful clinical outcomes, as is the case with pharmaceutical products.5,8,27,28 The absence of outcome data poses a challenge in comparing different algorithms and complicates decision-making as to which systems to implement in clinical practice. Furthermore, due to the complexity and rapid advancements in AI, the proposed developmental procedures can quickly become outdated.

Recent guidelines aim to enhance reporting standards for the early-stage clinical evaluation of AI-driven decision-support systems. These guidelines cover a range of factors, including the intended use of the AI system, the patient population studied, and the influence of human factors on how the systems were used and performed.29,30,31,32,33 Notwithstanding, these guidelines provide only a limited framework for the external validation of AI-enabled tools and significant obstacles remain for their reliable deployment, especially since the development is frequently based on a relatively narrow range of patient demographics.1,8,34 Accordingly, the generalizability of data leading to approval of AI-enabled medical devices remains uncertain due to lack of information on how well these tools perform across diverse patient populations, clinical settings, and medical conditions.35,36,37,38

## Section: Discussion › Future Perspectives

In the US, strong FDA oversight helps maintain public trust in regulated AI-driven health technologies. For long-term success, industry, academia, and regulatory bodies must work together to address irresponsible practices, prevent misleading claims, and refine tools for assessing AI’s safety and effectiveness. In Europe, unlike the FDA-approved AI devices, there is no dedicated public list of AI-enabled medical devices with Conformité Européenne (CE) marking. While national registries or databases, such as European Database on Medical Devices may provide information on CE-marked devices, the European Database on Medical Devices is not yet fully publicly accessible, whereas a centralized, public list specifically for AI-enabled medical devices remains unavailable. Along these lines, the European Union’s Artificial Intelligence Act introduced a regulatory framework to ensure the safe, transparent, and ethical use of AI.39,40 As AI systems become increasingly integrated into medical devices, there will be the need for harmonization between the requirements of Medical Device Regulation and Artificial Intelligence Act. AI-enabled medical devices will need to comply with both frameworks, ensuring safety, efficacy, and ethical use of AI in medical applications.

To keep pace with advancements and clinical applications, regulatory bodies must continuously adapt their frameworks to uphold the clinical safety and effectiveness of AI in health care through adequate clinical evaluation. Priorities should include fostering transparency and accountability for AI-enabled medical devices alongside rigorous clinical evaluation to ensure their effectiveness and generalizability.5,8,18,41,42 Standardized methods for the postmarket monitoring of AI-enabled devices will be relevant to detect and address unexpected changes in performance after clinical deployment.

The future of AI-enabled medical devices holds the promise of transforming health care by making it more efficient, personalized, and accessible. Achieving this vision will require sustained collaboration among technology companies, clinicians, and regulators to ensure the safe and ethical application of AI in clinical practice. The medical community should play a central role in this process, which requires them to receive adequate training to effectively monitor the performance of AI-enabled medical devices in real-world settings on an ongoing basis.

## Section: Discussion › Limitations

The findings of this analysis should be interpreted in light of several limitations. First, we were only able to evaluate AI-enabled medical devices that received FDA approval for clinical use, and we could not perform any comparative analysis with AI-enabled devices that did not receive such approval. Second, we evaluated and characterized only AI-enabled devices for clinical use that had been approved by the FDA but not other jurisdictions. Therefore, the findings of this analysis may not be applicable outside the FDA regulatory framework. Third, we did not search for published information related to the clinical evaluations of the devices in sources other than the FDA website. Additional information may have been provided to the FDA during the evaluation process, but not all of it was ultimately made publicly available. A broader search among other resources might have allowed us to identify additional publicly available reports describing the clinical evaluation of these tools. Our focus was limited to the information explicitly provided in the public domain through the FDA, whereas linking and justifying the contribution of any clinical evaluation report to the FDA approval of the corresponding AI-enabled medical devices would have been challenging. Fourth, in this analysis, we considered any AI-enabled medical device listed on the FDA website. The definition of AI encompasses a broad range of software algorithms with varying functions, which may have influenced the granularity of the data used in this analysis and, subsequently, the results. Fifth, due to the nature of the devices themselves, some submissions may not necessitate a clinical performance study to demonstrate substantial equivalence, as is the case for devices that generate work lists and link scans in Picture Archiving and Communication System. Sixth, we did not retrieve information on the nature and quality of the references standard used in the clinical performance studies against which the AI-enabled medical devices were evaluated. This information might be relevant for interpreting performance data, especially in cases with imperfect reference standards. Future research should aim to address this limitation.

## Section: Conclusions

In this cross-sectional study of publicly available information as reported by the FDA, clinical performance studies were reported at the time of approval for approximately half of the AI-enabled medical devices approved by the FDA for clinical use. However, the available data were often insufficient for a comprehensive assessment of their clinical generalizability. Performance data—both overall and within specific sex and age subgroups—were frequently lacking. Ongoing monitoring and regular re-evaluation are essential to detect and address unexpected changes in performance during broader clinical use.

## Section: Text

eFigure 1. Cumulative Histogram of Available and Recalled AI-Enabled Medical Devices That Received FDA Approval Over The Period 1995-2024

eFigure 2. Total Number of Available FDA-Approved and Recalled AI-Enabled Medical Devices by Country

eFigure 3. Distribution of AI-Enabled Medical Devices Availability and Physical State Across the Available Specialties

eFigure 4. Number of Clinical Performance Studies by the Physical State for All of the AI-Enabled Medical Devices in Our Sample, Stratified by Recalled and Available Devices

eFigure 5. Number of FDA-Approved AI-Enabled Medical Devices by Specialty, Together With Details of Clinical Performance Study Type

Data Sharing Statement

## Section: Associated Data

eFigure 1. Cumulative Histogram of Available and Recalled AI-Enabled Medical Devices That Received FDA Approval Over The Period 1995-2024

eFigure 2. Total Number of Available FDA-Approved and Recalled AI-Enabled Medical Devices by Country

eFigure 3. Distribution of AI-Enabled Medical Devices Availability and Physical State Across the Available Specialties

eFigure 4. Number of Clinical Performance Studies by the Physical State for All of the AI-Enabled Medical Devices in Our Sample, Stratified by Recalled and Available Devices

eFigure 5. Number of FDA-Approved AI-Enabled Medical Devices by Specialty, Together With Details of Clinical Performance Study Type

Data Sharing Statement

## Section: Associated Data › Supplementary Materials

eFigure 1. Cumulative Histogram of Available and Recalled AI-Enabled Medical Devices That Received FDA Approval Over The Period 1995-2024

eFigure 2. Total Number of Available FDA-Approved and Recalled AI-Enabled Medical Devices by Country

eFigure 3. Distribution of AI-Enabled Medical Devices Availability and Physical State Across the Available Specialties

eFigure 4. Number of Clinical Performance Studies by the Physical State for All of the AI-Enabled Medical Devices in Our Sample, Stratified by Recalled and Available Devices

eFigure 5. Number of FDA-Approved AI-Enabled Medical Devices by Specialty, Together With Details of Clinical Performance Study Type

Data Sharing Statement


---

# Generative Artificial Intelligence Tools in Medical Research (GAMER): Protocol for a Scoping Review and Development of Reporting Guidelines

- **Authors:** Xufei Luo, Yih Chung Tham, Mohammad Daher, Zhaoxiang Bian, Yaolong Chen, Janne Estill, GAMER Working Group
- **Issuer:** JMIR research protocols
- **Type:** Scientific article
- **Published:** 2025-08-14
- **Language:** en
- **DOI:** 10.2196/64640
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40812737/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundThe integration of artificial intelligence (AI) has revolutionized medical research, offering innovative solutions for data collection, patient engagement, and information dissemination. Powerful generative AI (GenAI) tools and other similar chatbots have emerged, facilitating user interactions with virtual conversational agents. However, the increasing use of GenAI tools in medical research presents challenges, including ethical concerns, data privacy issues, and the potential for generating false content. These issues necessitate standardization of reporting to ensure transparency and scientific rigor.ObjectiveThe development of the Generative Artificial Intelligence Tools in Medical Research (GAMER) reporting guidelines aims to establish comprehensive, standardized guidelines for reporting the use of GenAI tools in medical research.MethodsThe GAMER guidelines are being developed following the methodology recommended by the Enhancing the Quality and Transparency of Health Research (EQUATOR) Network, involving a scoping review and expert Delphi consensus. The scoping review searched PubMed, Web of Science, Embase, CINAHL, PsycINFO, and Google Scholar (for the first 200 results) using keywords like “generative AI” and “medical research” to identify reporting elements in GenAI-related studies. The Delphi process involves 30-50 experts with ≥3 years of experience in AI applications or medical research, selected based on publication records and expertise across disciplines (eg, clinicians and data scientists) and regions (eg, Asia and Europe). A 7-point-scale survey will establish consensus on checklist items. The testing phase invites authors to apply the GAMER checklist to GenAI-related manuscripts and provide feedback via a questionnaire, while experts assess reliability (κ statistic) and usability (time taken, 7-point Likert scale). The study has been approved by the Ethics Committee of the Institute of Health Data Science at Lanzhou University (HDS-202406-01).ResultsThe GAMER project was launched in July 2023 by the Evidence-Based Medicine Center of Lanzhou University and the WHO Collaborating Centre for Guideline Implementation and Knowledge Translation, and it concluded in July 2024. The scoping review was completed in November 2023. The Delphi process was conducted from October 2023 to April 2024. The testing phase began in March 2025 and is ongoing. The expected outcome of the GAMER project is a reporting checklist accompanied by relevant terminology, examples, and explanations to guide stakeholders in better reporting the use of GenAI tools.ConclusionsGAMER aims to guide researchers, reviewers, and editors in the transparent and scientific application of GenAI tools in medical research. By providing a standardized reporting checklist, GAMER seeks to enhance the clarity, completeness, and integrity of research involving GenAI tools, thereby promoting collaboration, comparability, and cumulative knowledge generation in AI-driven health care technologies.International Registered Report Identifier (IRRID)DERR1-10.2196/64640Keywords: generative AI, chatbots, reporting guidelines, transparency, Delphi method, large language models, ChatGPT

## Section: Introduction

Generative artificial intelligence (GenAI)–based tools and chatbots have been widely applied in medicine, facilitating interactions between users and AI through virtual conversational agents and thereby presenting new opportunities for enhancing health care practice and research methodology [1,2]. The increasing use of GenAI tools linked to chatbots in medical research brings numerous opportunities and supports innovations, but it also poses many challenges and creates issues. For example, the use of large language models may raise ethical concerns and data privacy issues [3,4]. Additionally, the generation of false content using large language models can constitute academic fraud [5]. These problems have detrimental effects on the academic community. Therefore, transparent and standardized reporting of the use of GenAI tools is extremely important. Although many journals and academic institutions have their own guidelines or suggestions on how to use GenAI tools [6-10], there are currently no universally recognized reporting guidelines on how to transparently and scientifically report the use of GenAI tools in medical research.

The Generative Artificial Intelligence Tools in Medical Research (GAMER) project aims to establish comprehensive and standardized guidelines for reporting essential elements of studies involving GenAI-based tools. The GAMER guidelines will delineate key aspects, such as whether GenAI tools were used in the study and in the writing of the paper, which tool and version were used, which sections of the paper it was applied to, the specific content areas it was used for, whether it was used for language editing or content generation, and whether any manual testing was performed. By providing recommendations for what information should be reported for each section, GAMER seeks to create reporting guidelines that streamline the reporting process, allowing researchers, practitioners, and policymakers to critically assess the quality and validity of studies involving GenAI tools in medical research [3].

The development of GAMER draws inspiration from established reporting guidelines in the field of medical research, such as the CONSORT (Consolidated Standards of Reporting Trials) statement for clinical trials [11] and the STROBE (Strengthening the Reporting of Observational Studies in Epidemiology) statement for observational studies [12]. Adhering to GAMER will not only enhance the clarity and completeness of reporting in GenAI-related research but will also foster collaboration, comparability, and cumulative knowledge generation in the rapidly evolving field of AI-driven health care technologies. This article describes the methods and processes involved in the development of GAMER, providing a guarantee for the smooth completion and promotion of GAMER in the future.

## Section: Methods

We will follow the methodology recommended by the EQUATOR (Enhancing the Quality and Transparency Of Health Research) Network [13] to develop the GAMER reporting guidelines, using methods such as scoping reviews and expert Delphi consensus to formulate the GAMER reporting checklist. We have registered this protocol with the EQUATOR Network [14].

The 3 stages of development of the GAMER (Generative Artificial Intelligence Tools in Medical Research) reporting guideline.

Timeline for the development of the GAMER (Generative Artificial Intelligence Tools in Medical Research) reporting guidelines.

## Section: Methods › Project Administration

The GAMER reporting guidelines were initiated by the Evidence-Based Medicine Center of Lanzhou University, the Chinese EQUATOR Center, and the WHO Collaborating Centre for Guideline Implementation and Knowledge Translation. Authors YC and JE are the co–project initiators, and author XL serves as the lead investigator and the main contact for communication.

## Section: Methods › Funding Sources

The project is funded by research project funds from the Research Unit of Evidence-Based Evaluation and Guidelines (2021RU017), Chinese Academy of Medical Sciences; and the School of Basic Medical Sciences, Lanzhou University, with no involvement of pharmaceutical companies or other third-party entities. The funding is used solely for relevant services, materials, travel, and publication expenses during the development process of GAMER.

## Section: Methods › Scope and Target Audience

The scope of GAMER is to assist stakeholders such as researchers, clinicians, editors, authors, peer reviewers, and other relevant parties in the smooth and barrier-free use and evaluation of GenAI tools and similar chatbots for the purpose of composing medical research.

## Section: Methods › Development Process

The development of the GAMER reporting checklist has 3 stages (Figure 1). The first stage is the preparatory phase, involving the formation of an expert group, collection of initial items, and discussion of these items. The second stage primarily includes 1 to 2 rounds of Delphi survey and online, face-to-face discussions, as well as multiple rounds of optimizing items. The third stage involves the publication of the checklist, as well as testing, dissemination, and promotion of the GAMER reporting guidelines.

The 3 stages of development of the GAMER (Generative Artificial Intelligence Tools in Medical Research) reporting guideline.

## Section: Methods › Development Process › Stage 1: Preparatory Work

We plan to establish 4 expert groups. The first is the advisory committee, consisting of 3 to 5 authoritative experts familiar with GenAI tools and experienced in the formulation of reporting guidelines. Their main responsibility is to provide advice on issues arising during the development of reporting guidelines. The second is the core team, primarily composed of members from the Evidence-Based Medicine Center at Lanzhou University. This group is responsible for conducting scoping reviews, generating the initial pool of items, revising the items, and drafting the final document. This group is the leading team for GAMER development. The third is the Delphi expert group, comprising experts with experience in a broad range of relevant disciplines from around the world. The inclusion criteria for invitation to this group are (1) participation in the publication of GenAI-related papers (obtained by searching PubMed for corresponding authors of relevant papers), supplemented by snowball sampling (experts recommending peers); (2) expertise (defined as ≥3 years of experience in AI applications or medical research) in medical-related disciplines (eg, bioinformatics, epidemiology, clinical science, data science, ethics); (3) willingness to participate in and support the development of GAMER; and (4) having no severe academic or financial conflicts of interests. We aim for 30 to 50 participants, targeting representation across disciplines (eg, including clinicians, data scientists, and ethicists) and regions (Asia, Europe, and the Americas). The Delphi expert group’s responsibilities include proposing modifications to the GAMER checklist, voting, and determining the final modifications to the full document. The fourth expert group is the coordination team, which will include 3 to 5 members. This group is responsible for coordinating the development work, communicating with experts, organizing the meetings, sending emails, and organizing materials.

## Section: Methods › Development Process › Stage 1: Preparatory Work

We conducted a scoping review to identify key reporting elements in studies involving GenAI tools in medical research. The primary research question was as follows: What are the essential elements that should be reported when using GenAI tools in medical research? We searched PubMed, Web of Science, Embase, CINAHL, PsycINFO, and the first 200 results of Google Scholar using keywords such as “generative AI,” “chatbots,” “ChatGPT,” “large language model,” and “reporting guidelines.” We included existing AI-related reporting guidelines that address the use of GenAI tools in medical research. Studies were eligible if they focused on the application of GenAI tools in a medical context and provided reporting recommendations or considerations. Two reviewers independently screened titles and abstracts, followed by full-text review for eligibility. Data were extracted with a focus on reporting elements and synthesized thematically to identify common themes and recommendations. The review identified key themes, such as the need to specify the GenAI tool and version used, the purpose of its application, and verification processes, which formed the initial pool of items for the Delphi survey and informed subsequent stages of GAMER development. The scoping review was submitted for publication in November 2023 and as of June 2025 is currently under review. The PRISMA-ScR (Preferred Reporting Items for Systematic Reviews and Meta-Analyses Extension for Scoping Reviews) checklist is provided in Multimedia Appendix 1.

## Section: Methods › Development Process › Stage 2: Delphi Survey

We will follow the Accurate Consensus Reporting Document (ACCORD) guidelines for the Delphi survey [15]. Once the preliminary items are completed, a survey will be disseminated through SurveyMonkey to reach consensus using a modified Delphi method [15,16]. We anticipate conducting 1 to 3 rounds, but there is no limit, and the decision on the number of rounds will depend on whether consensus is reached in the first round. Each initial item will be assigned a survey option ranging from 1 to 7 points, with 1 indicating strong disagreement, 4 indicating neutrality, and 7 indicating strong agreement. All statistics will be based on median scores. If the median score is between 1 and 3, the item will be excluded. If the score is 4 or 5 (or higher with substantial comments on the content), the item will be discussed and entered into the next round of the Delphi survey or the consensus meeting. If the score is 6 or 7 without any substantial comments, the item will be included in the final checklist. Items unresolved after 2 rounds will be discussed in the consensus meeting for final resolution. Participants can propose new items via free-text comments. New items receiving ≥50% support from the core team will enter subsequent rounds. Abstentions are allowed. Forced responses will not be used to avoid bias. Online meetings will be held after the Delphi survey to collect the experts’ opinions and optimize and formulate the final checklist. All opinions and suggestions will be documented, and responses to each expert’s suggestions will be provided through email. Qualitative data will undergo thematic analysis. Key themes will inform item revisions, with examples provided in supplementary materials. The initial Delphi survey included 10 items derived from the scoping review, covering aspects such as the specific GenAI tool used, the version of the tool, the sections of the manuscript where GenAI was applied, the purpose of GenAI use (eg, language editing or content generation), and whether manual verification was performed.

After the Delphi survey and virtual consensus meeting, we will refine and optimize the final items included. Once approved by the experts, we will prepare the manuscript for submission.

## Section: Methods › Development Process › Stage 3: Testing and Dissemination

After the GAMER checklist is finalized, we will conduct a real-life implementation testing phase. Authors of medical research papers involving GenAI tools will be invited to apply the checklist during manuscript preparation and provide feedback via a structured questionnaire developed to assess clarity, completeness, and ease of use. Concurrently, experts from various medical disciplines will evaluate reliability and usability. For reliability, multiple experts will independently apply the checklist to a sample of GenAI-related papers, with interrater agreement measured using the κ statistic. For usability, experts will record completion time and rate item difficulty on a 7-point Likert scale. Feedback from both authors and experts will be analyzed thematically and quantitatively to identify areas for improvement, guiding revisions to the checklist’s items, explanations, or examples for enhanced clarity and applicability. Public input will also be sought to ensure broader relevance. Explanatory documents and examples will accompany the final checklist.

Furthermore, we plan to invite the consensus expert group members to translate GAMER into their local languages and promote the dissemination of the checklist. Additionally, we will actively reach out to journals, inviting them to feature GAMER in authors’ instructions. Finally, we aim to establish a GAMER website to regularly update users on the latest developments and research findings related to the GAMER reporting guidelines.

## Section: Methods › Timeline

The process and anticipated timeline for developing the GAMER reporting guidelines are shown in Table 1.

Timeline for the development of the GAMER (Generative Artificial Intelligence Tools in Medical Research) reporting guidelines.

## Section: Methods › Ethical Considerations

This study was approved by the Ethics Committee of the Institute of Health Data Science, Lanzhou University (HDS-202406-01). All participants in the Delphi survey and testing phase provided informed consent, with the option to opt out at any time. Data collected from participants were anonymized to ensure privacy and confidentiality, with no identifiable information stored. No compensation was provided to participants. This manuscript includes no images or data that could identify individuals; thus, no consent for image use was required.

## Section: Results

The expected outcome of the GAMER project is a reporting checklist, accompanied by relevant terminology, examples, and explanations, to guide stakeholders in better reporting the use of GenAI tools. The GAMER project commenced on July 1, 2023, and concluded in July 2024. The scoping review was completed in November 2023 and submitted for publication. The Delphi process, involving 44 experts from 23 countries, was conducted from October 2023 to April 2024, yielding a 9-item checklist (Multimedia Appendix 2). The testing phase began in March 2025 and is ongoing, with authors and experts providing feedback. The final GAMER guideline is anticipated to be published in the second half of 2025, with dissemination to follow via journals and a dedicated website.

## Section: Discussion

We will follow the EQUATOR Network’s recommended methodology to develop the GAMER reporting guidelines [13], inviting experts from various disciplines and with a broad geographical distribution to ensure the panel’s representativeness. We hope that GAMER can guide and assist those who use GenAI tools in their research to report and apply these tools transparently and scientifically, thereby ensuring the integrity of the research. Additionally, we hope that GAMER will guide reviewers and editors in identifying and assessing manuscripts that have applied GenAI tools, ensuring that manuscripts meet journal requirements for transparent reporting.

The development of GAMER is not only a response to the current use of GAI tools in medical research but also a forward-looking initiative. As AI technologies continue to evolve, the standardization introduced by GAMER will serve as a foundation for future advancements. The checklist’s scope, targeting various stakeholders, including researchers, clinicians, editors, peer reviewers, and authors, positions GAMER as a versatile tool with far-reaching implications. GAMER will guide reporting in studies using GenAI for tasks like data synthesis, manuscript drafting, and image generation. The methodology, drawing from the EQUATOR guidelines, ensures a rigorous and evidence-based approach, further solidifying the credibility of GAMER.

The outlined plan for the dissemination and promotion of GAMER demonstrates a comprehensive strategy to ensure widespread adoption of the reporting guidelines. By involving authors of medical research papers, collecting feedback, and actively engaging with journals, the GAMER project aims to integrate the checklist seamlessly into the publication process. The creation of a dedicated website further emphasizes the commitment to transparency and continuous improvement. This multifaceted approach is essential for the successful implementation of reporting guidelines, as it addresses both the supply side (researchers and authors) and the demand side (journals and users).

However, this study also has some limitations. First, we did not conduct a pilot test before the Delphi survey, as we considered that the items had been thoroughly discussed within the core expert panel. Second, we did not include patient and public representatives in the Delphi survey due to their limited knowledge of AI and medical topics. However, we will invite patient advocacy representatives to the advisory committee and include public feedback during the testing phase.

In conclusion, the GAMER project holds promise not only to address the immediate needs of standardizing the reporting of GenAI tool use, but also to shape the future landscape of medical research. The meticulous planning, expert involvement, and strategic approach to dissemination position GAMER as a valuable resource for researchers, practitioners, and policymakers in the dynamic realm of AI-driven health care technologies.

## Section: Acknowledgments

This work was supported by Research Unit of Evidence-Based Evaluation and Guidelines (2021RU017), Chinese Academy of Medical Sciences, School of Basic Medical Sciences, Lanzhou University, Lanzhou, Gansu, China.

We would like to thank the members of GAMER working group. The list is as follows: Nash Anderson; Hiroj Bagde; Emir Begagić; Jean-Christophe Bélisle-Pipon; Zhaoxiang Bian; Charlotte Blease; Qingyu Chen; Yaolong Chen; Egor Chumakov; Sophie Curbo; Randy D'Amico; Mohammad Daher; Hannah Decker; Brian D. Earp; Adrian Egli; Alexander Viktor Eriksen; Janne Estill; Shijian Feng; Mauro Giuffrè; Che-Wei Hsu; Sahil Khanna; Aybars Kıvrak; Ery Ayelen Ko; Kyle Lam; Myeong Soo Lee; Sheng Li; Dengxiong Li; Andrey Litvin; Peng Liu; Xufei Luo; Sebastian Porsdam Mann; José Darío Martínez-Ezquerro; Surapaneni Krishna Mohan; Philip Moons; Fabio Ynoe de Moraes; Susan L Norris; Akihiko Ozaki; Alejandro Quiroga-Garza; Riaz Qureshi; Murali Ramanathan; Robert Ranisch; Lorenzo Righetto; Renne Rodrigues; Kuan-Pin Su; Yousif Subhi; Yih Chung Tham; Ximing Xu; Qing-xin Yu

## Section: Data Availability

Data are not available to share due to Department of Veterans Affairs and ethical retractions; however, annotation instructions and vocabulary are available upon request..

## Section: Associated Data › Data Availability Statement

Data are not available to share due to Department of Veterans Affairs and ethical retractions; however, annotation instructions and vocabulary are available upon request..


---

# Generative Deep Learning for de Novo Drug Design─A Chemical Space Odyssey

- **Authors:** Rıza Özçelik, Helena Brinkmann, Emanuele Criscuolo, Francesca Grisoni
- **Issuer:** Journal of chemical information and modeling
- **Type:** Scientific article
- **Published:** 2025-07-09
- **Language:** en
- **DOI:** 10.1021/acs.jcim.5c00641
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40632942/
- **Licence:** CC-BY

## Section: Abstract

In recent years, generative deep learning has emerged as a transformative approach in drug design, promising to explore the vast chemical space and generate novel molecules with desired biological properties. This perspective examines the challenges and opportunities of applying generative models to drug discovery, focusing on the intricate tasks related to small molecule generation, evaluation, and prioritization. Central to this process is navigating conflicting information from diverse sourcesbalancing chemical diversity, synthesizability, and bioactivity. We discuss the current state of generative methods, their optimization, and the critical need for robust evaluation protocols. By mapping this evolving landscape, we outline key building blocks, inherent dilemmas, and future directions in the journey to fully harness generative deep learning in the “chemical odyssey” of drug design.

## Section: Introduction

Generative deep learning has emerged as a transformative tool in de novo drug design, and in the molecular sciences at large. − By leveraging existing molecular data, generative deep learning enables the on-demand generation of molecules that possess desirable properties. With the “chemical universe” estimated to contain up to 1060 drug-like molecules, generative deep learning has accelerated the discovery of novel compounds, compared to traditional rule-based molecular assembly and enumeration approaches. − In less than a decade since its introduction in drug discovery, generative deep learning has been extensively applied in prospective wet-lab studies − and demonstrated its potential in real-world applications. Meanwhile, the development of approaches to better explore the chemical universe is gaining momentum in the cheminformatics community. − Currently, we are observing a productive synergy between computer science advances and insights rooted in chemical and biological knowledge.

While generative deep learning is making great strides in designing promising molecules, the understanding of what model to choose and how to prioritize molecular candidates remains limited. With an ever-growing pool of methods available for molecular generation and optimization, choosing the most suited approach might not always be straightforward. Despite the availability of benchmarks, , retrospective comparisons are poised to be incomplete for new, prospective applications. Researchers might face many “traps”, such as overfitting to specific datasets or overlooking key molecular properties. , Moreover, the generated designs can exhibit limited synthesizability, and current synthetic accessibility scores might struggle to capture the effect of subtle structural variations, reaction selectivity, and the availability of building blocks essential to chemical reactions. Finally, optimizing conflicting propertiessuch as balancing pharmacophore similarity with structural diversitypresents another layer of complexity. As a result, de novo molecule design through generative methods continues to be an odyssey (from Greek “Oδúσσεια”, meaning “the journey of Odysseus” or “a long and adventurous journey”) in chemical space.

This perspective highlights open questions, “known unknowns”, and key challenges in generative small molecule design, with a particular focus on ligand-based approaches. After reviewing current generative approaches for de novo design, we offer insights and propose potential future directions. By highlighting both the caveats and advantages of these methods, we venture to forecast the exciting possibilities that lie ahead.

## Section: Charting the Chemical Cosmos with Generative AI

Representing molecular information for deep learning.(a) Selected molecular example (caffeine). (b–d) Commonly used “raw” molecular representations. (b) Simplified Input Line Entry Systems (SMILES) strings, which capture two-dimensional molecular information as a set of textual characters (“tokens”). (c) Molecular graph, whose vertices represent atoms, and edges constitute their connections (bonds). Additionally, features of atoms and/or edges can be added to further characterize the graph, such as chemical and bond properties, as well as three-dimensional information. (d) Molecular surface, which encloses the 3D structure of a molecule at a certain distance from each atom. (e,f) Encoding of a molecular representation into a “machine readable” format. (e) Encoding of molecular strings (SMILES strings, in the selected example). One-hot encoding represents each token with a unique binary vector. Learnable embeddings start from a random vector per token and are updated during training to improve the model performance. (f) Encoding of molecular graphs. The adjacency matrix captures information about atoms bound to each other (i.e., connected by one edge). Node features can be specified for each atom (e.g., atom type, in this example). Features for edges can also be specified (in this example: p1 = bond order, p2 = ring membership, p3 = aromaticity).

Overview of popular deep learning architectures for de novo design.(a) Recurrent Neural Networks, which learn to predict the next token in a SMILES string, using information on all the previous tokens. The network hidden state is updated in a recurrent way, to perform a prediction at any steps while keeping track of the preceding portions of the string. (b) Transformers, which learn all pair relationships between sequence tokens to perform a prediction. (c) Variational Autoencoder, where an encoder is trained to transform an input molecule (e.g., a graph or a string) into a fixed-dimension latent vector, and a decoder is trained to convert such vectors back into molecular representations.

Approaches for model training and molecular generation. (a) Distribution learning, where models generate molecules that statistically resemble those in the training set in terms of physico-chemical and biological properties. (b) Goal-directed generation, which optimizes molecules toward a predefined objective, often using reinforcement learning, guided by a scoring function. (c) Conditional generation, where models are explicitly trained to design molecules with specified properties, by incorporating property constraints into the generation process.

## Section: Charting the Chemical Cosmos with Generative AI › Molecular Representations for Deep Learning

How to represent molecular information has been a central scientific question for over a century. − Molecular representations are “a symbolic transformation of [chemical] reality”, initially devised for the purpose of communication and human reasoning. Examples are the ball-and-stick model, Kekulé’s representation, and Lewis structure of molecules. Such models of chemical reality were progressively developed to address the complexity of molecular structures at different levels of abstractions. From the mid of the 20th century, with the advent of computers and the need for machine-readable formats, string-based molecular representations (notations) have started to be developed, such as Wiswesser Line Notation and the SMILES (Simplified Molecular Input Line Entry System) strings. These representations were initially proposed to complement systematic chemical nomenclature, and enabled the encoding of chemical structures in a compact format suitable for information storage, processing, and retrieval.

With the introduction of machine learning to cheminformatics, the role of molecular representations has also evolved. Molecular representations have become a fundamental step to encode chemical information for machine learning and data analysis. Their role has further become more prominent since the advent of deep learning. Certain deep learning algorithms can handle non-structured (i.e., non-tabular) input, allowing the direct usage of some of these molecular representations, without the need of feature engineering. This shift enables generative deep learning to use some molecular representations as inputs to generate novel chemical structures in an end-to-end fashion. , In other words, models can be trained to directly learn from and generate molecules in the form of a chosen molecular representation. To date, the following molecular representations have played a key role in the field of generative deep learning for de novo design: Molecular strings. Molecular strings represent a molecule as a sequence of characters. The most popular string notation to date is the SMILES notation. SMILES strings are obtained by traversing a two-dimensional molecular representation (molecular graph), and annotating the atomic symbols and bond types along the traversal path. Rings and branches are encoded using numeric labels and parentheses, respectively, to capture molecular connectivity while maintaining a linear format (Figure b). SMILES can be seen as a chemical language, possessing its own syntax rules to map this string representation back to a chemically valid molecule. Since the early successes of SMILES strings as a representation for de novo design, , several extensions to this notation have been developed. DeepSMILES (Table ) were proposed to address aspects that often caused invalidity of the generated SMILES (brackets and ring characters), but have found limited application, due to their difficult syntactic rules. The Self-referencing embedded strings (SELFIES) are built upon “semantically constrained graphs”, in such a way that SELFIES strings always corresponds to a valid molecule (Table ). While SMILES and SELFIES achieve a similar performance overall, they come with distinct advantages and drawbacks. The enforced validity of SELFIES might be ideal to generate complex macromolecular entities, whose structural complexity increases the likelihood of generating invalid SMILES (e.g., natural products , ). SMILES strings might be more ideal for distribution learning, to as the generation of invalid SMILES allows to filter out low-quality molecular designs, which would not be possible when validity is enforced like in the SELFIES language. Recently, great attention has been given to string representations that are based on molecular fragments, such as Sequential Attachment-based Fragment Embedding (SAFE), GroupSELFIES and fragSMILES. These representations have been developed to provide “chemically-rich” molecular representations, to better learn the properties of the training molecules, and/or provide a better representation of molecular chirality (fragSMILES, Table ). Two- and three-dimensional molecular graphs. Graphs are among the most intuitive ways to represent molecular structures (Figure c). Any molecule can be represented as a mathematical graph G = (V, E), whose vertices (v i ∈ V) represent atoms, and edges (e ij ∈ E) constitute their connections (bonds). Additionally, features of atoms and/or edges can be added to further characterize the graph. Two-dimensional (2D) molecular graphs usually consider only topological and chemical features (e.g., bond and atom types). Three-dimensional information (3D) can also be added to the features of the molecular graphs, such as torsional angles, or three-dimensional coordinates. Generating molecules in the form of graphs has attracted a lot of attention, for both ligand- and structure-based drug discovery. − A particularly recent direction in the field is the attempt to generate 3D molecular graphs, ,− in the attempt to better capture properties that depend on the spatial arrangement of atoms (e.g., protein binding). Moreover, 3D graphs can also be encoded as the so-called point clouds, ,, i.e., by omitting bond information and encoding the spatial positioning of atoms (absolute or relative coordinates). Once the geometry is generated in the form of point cloud, bond type can be constructed by dedicated chemistry software (e.g., Open Babel). Molecular surfaces. In addition to 3D graphs and point clouds mentioned above, a limited number of studies have represented molecules via their molecular surface, which encloses the 3D structure of a molecule at a certain distance from each atom (Figure d). Surfaces are then usually represented as (a) 3D meshes , (a set of polygons describing the coordinates in the 3D space), (b) 3D point clouds, , that is, a collection of discrete points in 3D space that define the surface geometry without explicit connectivity between them, or (c) 3D voxels, , that is three-dimensional grid of cubic cells where each voxel represents a volume element in space, allowing for the discretization of the surface and surrounding molecular structure into a regular grid format. Surfaces can then be further characterized by additional chemical (for example, hydrophobic, electrostatic) and geometric (such as local shape, curvature) features. While surface representations have mostly gathered popularity to capture information on protein surfaces or cavities, and protein–protein interactions, , they have also been used to generate molecules matching desired ligand shapes, , or conditioned on the information on surface features.

Once a molecular representation has been chosen, a fundamental step is molecule encoding. Encoding is the transformation of molecular structures into numerical representations that can be processed by machine learning models. Encoding ensures that the chosen molecular representation is converted into a format suitable for deep learning without loss of information. For molecular strings (Figure e) common methods include one-hot encoding, which converts each token into a unique binary vector, and learnable embeddings, which represents tokens as vectors of unique numbers that are updated during training. For molecular graphs (Figure f), encoding involves constructing an adjacency matrix that defines atomic connectivity and a node features matrix to describe atomic properties. Optionally, edge features can also be included to specify bond characteristics (e.g., bond type or order). Recent studies on bioactivity prediction show that molecular strings encoding strategy has little impact on the model performance, whereas the choice of edge features is crucial and task-specific.

Every molecular representation (and corresponding encoding) requires ad hoc neural network architectures to learn and aggregate molecular information, and shows distinct advantages and disadvantages. To date, models based on molecular string representations (often referred to as chemical language models) are the ones that have found extensive experimental validation to generate bioactive molecules (see Section ; Table ). ,,,,, Early studies have demonstrated that relying on string representations for de novo design better captures complex molecular properties compared to molecular graphs. Nonetheless, there is ample room for improvement when it comes to representing and generating molecules de novo, since molecular strings capture only 2D information (molecular topology and composition). In this context, methods that learn sophisticated three-dimensional information (e.g., geometry and chemistry of binding pockets or known molecular conformers) to generate molecules matching relevant binding motifs − is a particularly enticing direction. However, to date, it might be difficult for deep learning models to generate molecules with valid 3D conformations, for instance, in terms of torsional angles and bond lengths, , albeit current advances show great promise to overcome such issues. −

Representing molecular information for deep learning.(a) Selected molecular example (caffeine). (b–d) Commonly used “raw” molecular representations. (b) Simplified Input Line Entry Systems (SMILES) strings, which capture two-dimensional molecular information as a set of textual characters (“tokens”). (c) Molecular graph, whose vertices represent atoms, and edges constitute their connections (bonds). Additionally, features of atoms and/or edges can be added to further characterize the graph, such as chemical and bond properties, as well as three-dimensional information. (d) Molecular surface, which encloses the 3D structure of a molecule at a certain distance from each atom. (e,f) Encoding of a molecular representation into a “machine readable” format. (e) Encoding of molecular strings (SMILES strings, in the selected example). One-hot encoding represents each token with a unique binary vector. Learnable embeddings start from a random vector per token and are updated during training to improve the model performance. (f) Encoding of molecular graphs. The adjacency matrix captures information about atoms bound to each other (i.e., connected by one edge). Node features can be specified for each atom (e.g., atom type, in this example). Features for edges can also be specified (in this example: p1 = bond order, p2 = ring membership, p3 = aromaticity).

## Section: Charting the Chemical Cosmos with Generative AI › Deep Learning Architectures for Drug Discovery

A plethora of generative deep learning architectures was proposed for designing small molecules with desired properties (e.g., bioactivity toward a pharmacologically relevant target). In its simplest form, generative drug discovery can be cast as a ligand-based task, ,, where models learn from the molecular structures of bioactive molecules and generate novel compounds with desirable characteristics, without requiring explicit knowledge of the target protein’s structure or sequence. Structure-based approaches also exist, which leverage structural (or sequence) information about the target protein to guide molecular design. , For simplicity, in this perspective, we focus mostly on ligand-based approaches, and strategies for structure-based de novo design are discussed elsewhere. , Regardless of whether ligand- or structure-based strategies are employed, the effectiveness of generative models hinges on how molecular information is encoded and processed by deep learning approaches for follow-up molecular generation. In general, different molecular representations require tailored neural architectures to suitably process and leverage the molecular information they encode.

Overview of popular deep learning architectures for de novo design.(a) Recurrent Neural Networks, which learn to predict the next token in a SMILES string, using information on all the previous tokens. The network hidden state is updated in a recurrent way, to perform a prediction at any steps while keeping track of the preceding portions of the string. (b) Transformers, which learn all pair relationships between sequence tokens to perform a prediction. (c) Variational Autoencoder, where an encoder is trained to transform an input molecule (e.g., a graph or a string) into a fixed-dimension latent vector, and a decoder is trained to convert such vectors back into molecular representations.

## Section: Charting the Chemical Cosmos with Generative AI › Deep Learning Architectures for Drug Discovery › Molecular Strings

One of the earliest and most widely adopted approaches in ligand-based drug design is chemical language modeling (CLM). ,, CLMs take inspiration from natural language processing and treat molecule design as a sequence generation problem. CLMs are trained to predict the next token in a molecular string given the preceding ones. This self-supervised learning approach enables models to generate valid molecular sequences while capturing underlying chemical patterns. Moreover, CLMs have often been applied in combination with “data-augmentation”, where multiple SMILES (or SELFIES) strings are used to represent the same molecule. This is usually achieved by enumeration, where multiple molecular stringsobtained by traversing the molecular graph in different directions or starting from different atomsare used. Molecular string enumeration can improve generative drug design, especially in low-data regimes. ,, Recently, strategies inspired by natural language processing (such as atom masking or token deletion) have proven valuable alternatives to enumeration for de novo drug design.

Early CLMs employed recurrent neural networks (RNNs). RNNs iterate over the input symbols in the sequence stepwise and compress the past information into a single memory vector called hidden state (Figure a). Different RNN variants exist based on the memory update rules, such as Long Short-Term Memory (LSTM) and Gated Recurrent Units (GRUs). LSTMs and GRUs were successfully used to generate syntactically valid molecules with bespoke properties. ,,,

Transformers  an architecture that learns all pair relationships between sequence elements (Figure b)  were introduced to molecule design due to their transformative impact in natural language processing. − Transformers have found widespread application in computer-assisted synthesis planning. In de novo design, they found more limited application. Recently, a comparison between transformers and RNNs have shown that the former better capture complex properties of molecules, while the latter generates more structurally diverse design libraries. − Recently, structured state space sequence models (S4s) , emerged as an alternative to “make the best of both worlds” by leveraging full-sequence learning (like transformers) and autoregressive generation (like RNNs). Early results suggest that S4 might enhance the diversity of design libraries compared to transformers, while better capturing complex molecular properties than both architectures.

Variational autoencoders (VAEs) introduce a new component to de novo design. Rather than predicting the next symbol based on the memory, they decompose the task into two subtasks (a) learning how to encode molecules into a structured, continuous representation, and (b) reconstructing the input molecule from such learned representation. , In a VAE (Figure c), an encoder network transforms an input molecule into a probability distribution over a latent space (typically modeled as a Gaussian distribution). From this latent representation, another network (decoder) learns to reconstruct molecules by sampling points from the learned distribution and mapping them back to valid input representations. The encoder and decoder can be any deep learning model, with convolutional neural networks (CNNs) and RNNs being typical choices for molecular sequences. ,− Compared to architectures that rely solely on hidden states (e.g., LSTMs and GRUs), VAEs facilitate smoother latent space navigation, thanks to their explicit learning of latent molecule representations. These representations can be manipulated to enable tasks such as molecule optimization and property-guided design.

Encoder-decoder architectures can also be incorporated in generative adversarial networks (GANs) for molecule design. − Originally developed for image generation, GANs consist of (a) a generator network that learns to convert random noise into realistic instances, and (b) a discriminator network that scores the quality of the generations. These two neural networks are trained to compete with each other, with the generator aiming to produce increasingly realistic samples to “fool” the discriminator. Early applications of GANs showed promise for molecule generation, by improving drug-like properties. However, due to the challenges to train GANse.g., mode collapse, where the generator learns only a few modes of the input distribution − other score-based generators have been replacing GANs for molecular sequence design, namely diffusion models. Initially successful in generating realistic images, diffusion models learn to iteratively refine random noise into samples that resemble the input distribution. Diffusion can be applied on sequences by selecting discrete probability distributions to model the inputs, or by applying diffusion to latent molecule representation, a trend gaining popularity for sequence modeling. − Recently developed molecular diffusion sequence models offer more controllability with more drug-like designs than initial chemical language models and form an active research direction. −

Overview of popular deep learning architectures for de novo design.(a) Recurrent Neural Networks, which learn to predict the next token in a SMILES string, using information on all the previous tokens. The network hidden state is updated in a recurrent way, to perform a prediction at any steps while keeping track of the preceding portions of the string. (b) Transformers, which learn all pair relationships between sequence tokens to perform a prediction. (c) Variational Autoencoder, where an encoder is trained to transform an input molecule (e.g., a graph or a string) into a fixed-dimension latent vector, and a decoder is trained to convert such vectors back into molecular representations.

## Section: Charting the Chemical Cosmos with Generative AI › Deep Learning Architectures for Drug Discovery › Molecular Graphs

Like string representations, molecular graphs also gained widespread interest in de novo design using deep learning. − Graph neural networks (GNNs) are the predominant deep learning architecture to learn from graphs. Starting from random vectors, GNNs iteratively update atom and bond representations to learn meaningful molecular representations. GNNs were first applied in combination with VAEs and GANs. ,,, While using GNNs as encoders is relatively straightforward, decoding graphs poses a greater challenge, as it requires reconstructing molecular structures while preserving chemical validity and similarity to the input. Calculating the reconstruction quality becomes increasingly compute-intensive as molecular size grows. , For large molecules, using coarse-grained graphs (e.g., fragments as nodes) to shrink the graph size, and formulating graph generation as stepwise node extension can mitigate the computational burden. More recently, flow-based and diffusion models have been proposed for molecular graph generation. Flow-based models learn invertible transformations of simple probability distributions, such as Gaussian, to model the complex distribution of molecular datasets. − Unlike VAEs and diffusion models, flow-based models can provide exact likelihood estimates of generations and provide an internal score for the designs. Diffusion models on molecular graphs learn to generate chemically valid topologies from random noise, − Recent research on diffusion and flow-based graph models focus on improving chemical validity, scalability, and design diversity to match the performance of string generation models. ,

## Section: Charting the Chemical Cosmos with Generative AI › Deep Learning Architectures for Drug Discovery › 3D Geometry

3D approaches represent molecules as atom types and their spatial coordinates (and, optionally, bond types). Training models on atom-level 3D information allow learning from proteins and small molecules together and conditioning generations with the 3D topology of protein binding pockets. While this advantage is mostly harnessed for structure-based studies, 3D approaches have also been developed for unconditional small molecule design with diffusion. ,,,− Equivariant graph neural networks (EGNNs) are a popular architecture to learn from point clouds. The equivariance provide the same, or a predictably different, output when the input molecule is rotated, translated, or reflected and provide performance gains over non-equivariant GNNs. The initial EGNNs struggled to generate valid 3D structures that satisfy bond lengths and atom stability constraints, and recent work integrated of laws of physics. and learned jointly from molecular graphs and 3D coordinates to achieve the validity level of sequence models. ,, Using message passing transformers that respect the geometry of molecules has been recently popular, as they provide higher validity in generations. ,− A recent study unified 3D generation and property prediction within a two-stage generation framework and improved performance in both tasks. A bottleneck for 3D generation molecule design models is the availability of datasets and benchmarks. QM9 dataset consists of computed geometric, energetic, electronic, and thermodynamic properties for 134 K molecules up to 9 heavy atoms (C, N, O, F), , forming a narrow chemical space for drug discovery studies. GEOM-Drugs is an alternative used in 3D generation studies and contain molecules up to 91 heavy atoms and their 3D conformers. A recent improved GEOM-Drugs by reimplementing a flawed stability metric and re-evaluating the model trained upon this dataset.

## Section: Charting the Chemical Cosmos with Generative AI › Deep Learning Architectures for Drug Discovery › Hybrid Approaches

Generating molecules in any representation has distinctive strengths, motivating approaches to combine the advantages of each. Creating a VAE with a GNNs encoder to explicitly represent the chemical structures and a CLM decoder for fast generation is one such example, resulting in higher diversity of the molecular designs. Similarly, multimodal modelswhich integrate multiple data typescan also be used for de novo design. Such approaches expand the information available to the models, and can even incorporate additional data sources, such as gene expressions, protein interactome, and textual information, and allow zero-shot molecule design combined with human-understandable explanations in natural language. , Each additional modality, however, increases the architectural complexity, which can pose challenges related to computational efficiency, interpretability, and long-term scalability.

## Section: Charting the Chemical Cosmos with Generative AI › Focused Molecule Design with Deep Learning

Distribution learning (Figure a), where a generative model is trained to learn and replicate the property distribution of a molecular dataset (e.g., physicochemical and biological properties). Distribution learning is usually achieved via transfer learning where a model is “pretrained” on a large, diverse dataset, and then “fine-tuned” on a smaller, task-specific dataset, with the same training strategy. In de novo design, a particularly useful training strategy is the next-token generation in molecular strings, , but other strategies involve reconstructing molecular structures from corrupted inputs, ,, or predicting missing bonds/atoms. − An extensive body of literature using SMILES strings has shown the benefit of pretraining to learn the “syntax” of the SMILES language and global physico-chemical properties, , and of fine-tuning to capture bioactivity, as validated in the wet-lab. ,, Moreover, by controlling the extent of transfer learning, it is possible to indirectly navigate between the properties of the pretraining and fine-tuning molecules. ,,,, Goal-directed learning (Figure b), where a model is trained to optimize an external objective. This is typically implemented through reinforcement learning, in which a generative model iteratively designs molecules and receives a score (also called reward) based on an external evaluation function (e.g., docking scores , or predicted properties and bioactivity). ,− Usually, these generative models are pretrained on large corpora of data. , During reinforcement learning, the model updates its generation strategy based on this reward signal, “reinforcing” molecular structures that receive higher scores and discouraging those with lower scores. This iterative process helps the model refine its output toward molecules with the desired properties. Compared to distribution learning, goal-directed learning allows for a more flexible steering of molecule design toward desired regions of the chemical space, e.g., for multi-objective molecular design, − scaffold hopping , and hit-to-lead optimization. , Conditional generation (Figure c), where a single generative model is trained to explicitly produce molecules matching one or more desired properties. Unlike traditional goal-directed generation (which scores the de novo designs of a generation), the desirable conditions are explicitly used to train the generator in a supervised manner. This is achieved by learning a shared vector space that encodes the desired conditions (e.g., experimentally determined properties) and the corresponding molecular structures (Figure c) together. The desired set properties can be then used as a conditioning input to generate molecular structures that are likely to possess those properties. Conditional generation has been used to design molecules that match a desired three-dimensional shape, possess a desirable set of physico-chemical properties or substructures, ,, or are constrained by a target protein sequence , or gene-expression signatures. ,

Each molecular generation approach presents unique benefits and limitations, and the choice depends on a multitude of factors, such as, the availability and quality of available training data, the complexity of the target molecular properties, and specific design needs (e.g., diversity vs property optimization).

Distribution-learning methods enable end-to-end learning and molecule generation without the need for explicit scoring functions to guide the design process. Even with relatively small pretraining datasets (e.g., in the order of tens of thousands of molecules) and/or fine-tuning sets (e.g., in the order of just a few dozen molecules , ), these approaches can successfully generate molecules with desirable molecular properties, including bioactivity. Moreover, the fine-tuning process is particularly beneficial in low-data scenarios, , where the molecules having the desired properties are too few to train a deep learning model from scratch, and the target property is resource-intensive and/or challenging to evaluate in silico. However, while these models are evaluated based on how well the generated molecules resemble the training set in terms of properties, they do not inherently assess the quality of individual molecules. As a result, additional scoring and filtering steps are often required to identify the most promising candidates, introducing manual intervention into otherwise “rule-free” pipelines. Finally, distribution learning might fail at property optimization if the desired characteristics are underrepresented in the training data (out-of-distribution generation).

Conversely, goal-directed strategies offer direct feedback on both individual molecules and the entire generated population through an external scoring function. Compared to distribution learning, they can, in principle, steer the generation of molecules in previously unexplored regions of the chemical space, if incorporated into a suitable scoring function. However, goal-directed generation poses several challenges, ,, including (a) the difficulty of accurately capturing complex molecular attributes  such as bioactivity, drug-likeness, and synthetic accessibilityinto a single scoring function, which might lead to molecules that do not realistically match the intended objectives; (b) the risk of models exploiting spurious correlations or unintended biases within the scoring function rather than learning meaningful structure–property relationships (a phenomenon known as “reward hacking”), and (c) reduced chemical diversity due to biases imposed by the optimization process, which can even result in mode collapse. The reliability of goal-directed methods is therefore heavily dependent on the quality and diversity of the data and models used to define scoring functions. Additionally, molecules generated by goal-directed strategies may exhibit lower synthetic accessibility than those designed via distribution learning approaches. Several strategies have been explored to retain broad chemical diversity while achieving the generation objectives, such as incorporating a memory of previously produced molecules, the penalization of structurally redundant designs, or integrating transfer and reinforcement learning. Overall, whenever dealing with goal-directed generation, scoring functions play a key role in determining the properties of the de novo design. As such, scoring functions should be designed carefully, by balancing computational cost and reliability.

Finally, conditional generation has been explored less extensively in drug discovery compared to distribution-learning and goal-directed approaches. In general, however, since these models do not rely on externally computed scoring functions, they offer several potential advantages, such as (a) mitigating biases associated with predictive models (e.g., bioactivity prediction models), (b) capturing complex structure–property/activity relationships by directly associating molecular structures with desired properties within latent space, and (c) maintaining the end-to-end learning characteristics of distribution-learning methods. Despite these advantages, conditional generation has yet to be applied extensively and experimentally validated. This might be due to the fact that conditional generation is well-suited for scenarios where large molecular databases with accurate and reliable labels are used. However, such datasets are relatively uncommon in drug discovery, which might explain the limited application of conditional approaches. One potential way to overcome this limitation is to incorporate self-supervised or semisupervised approaches to enhance learning from smaller datasets. Finally, it remains uncertain whether conditional generation can effectively explore regions of chemical space beyond those represented in the training set, raising questions about its utility relative to more established generative approaches.

Approaches for model training and molecular generation. (a) Distribution learning, where models generate molecules that statistically resemble those in the training set in terms of physico-chemical and biological properties. (b) Goal-directed generation, which optimizes molecules toward a predefined objective, often using reinforcement learning, guided by a scoring function. (c) Conditional generation, where models are explicitly trained to design molecules with specified properties, by incorporating property constraints into the generation process.

## Section: Charting the Chemical Cosmos with Generative AI › Evaluating the Quality of de Novo Designs

While generative deep learning models can rapidly produce millions of molecular designs, the evaluation of molecular qualitywhether for follow-up experiments or model analysis and comparisonremains an open challenge. Despite remarkable strides in generative drug discovery, determining whether a design is “good” or “bad” remains a challenge, as it often involves balancing multiple, sometimes conflicting, objectives in a context-dependent manner. While no universally accepted guidelines exist for evaluating de novo design studies, assessment typically considers multiple factors, including chemical validity, diversity, and alignment with the intended design objectives, as outlined below.

## Section: Charting the Chemical Cosmos with Generative AI › Evaluating the Quality of de Novo Designs › Chemical Validity and Non-redundancy

One of the principal requirements of a good molecular generator is its ability to generate molecules that are “chemically plausible”in other words, molecules possessing correct valency, aromaticity and charge constraints. These aspects are usually commonly referred to as “chemical validity”. While validity only considers two-dimensional information, it has recently been extended to three-dimensional molecular generation (“validity3D”), which evaluates the conformation quality of bond lengths and valence angles. Additionally, generators should be able to produce non-redundant molecules, in terms of limiting the duplicated designs (“uniqueness”) and the overlap with the training set (“novelty”). These metrics should always be reported, as they can reveal significant issues in the model training procedure. However, validity, uniqueness and novelty are vulnerable to trivial modifications (e.g., the random insertion of a carbon atom), may depend on the number of generated designs, and are easy to optimize by simple heuristic algorithms. Therefore, they should be considered as a diagnostic check rather than a conclusive evaluation metric.

## Section: Charting the Chemical Cosmos with Generative AI › Evaluating the Quality of de Novo Designs › Internal Diversity of de Novo Design Libraries

Assessing the structural diversity of generated molecules is crucial to ensure that a generative model does not produce structurally redundant or overly similar compounds. High diversity is often desirable, particularly in early-stage drug discovery, as it increases the chances of identifying novel bioactive chemotypes. Evaluating and quantifying molecular diversity is not straightforward, as “similarity is in the eye of the beholder”  it depends on the chosen molecular features (molecular descriptors) and similarity/diversity metrics. Often, molecular diversity is captured by computing the pairwise Tanimoto similarity (the lower, the higher the diversity) on extended-connectivity fingerprints (ECFPs), which captures the presence of shared substructures. , Average pairwise similarities are frequently reported, at the risk of obscuring important nuances in molecular diversity. The presence of diverse molecular scaffolds is also commonly used to capture diversity. While providing a more abstract perspective on diversity compared to ECFP similarity, it can be skewed by the inclusion of scaffolds that differ only minimally. Recently, the number of circles (“#Circles”) has been introduced, which leverages sphere exclusion clustering to quantify the internal diversity of molecular datasets and measure the chemical space covered by databases and generative models. #Circles captures well the structural diversity of molecular sets and allows to better distinguish generative models with varying exploration capacities. The #Circles metric is computationally expensive, and this is why the number of unique substructures (computed via the Morgan algorithm) was recently suggested as a cost-effective alternative to capture internal diversity.

## Section: Charting the Chemical Cosmos with Generative AI › Evaluating the Quality of de Novo Designs › Similarity to Reference Molecules

In de novo drug design tasks, generated molecules are often required to share key, desirable properties with known compounds, such as binding affinity or solubility. Consequently, their similarity to these reference compoundsoften used for model training and validationis computed as a measure of how well the designed molecules align with the desired property distributions. Like with measures of internal diversity, similarity can consider information on shared substructures, as captured by extended connectivity fingerprints (ECFPs) or Molecular ACCess System (MACCS) keys. Often, evaluations of molecular similarity are based on physicochemical descriptors, such as molecular weight, octanol–water partitioning coefficient (logP), topological polar surface area (TPSA), and number of hydrogen bond donors and acceptors. Once these descriptors are obtained for the reference molecules (e.g., training set) and the molecular designs, the degree of similarity between their distributions is computed using dedicated metrics, , such as the Kullback–Leibler (KL) divergence or Kolmogorov–Smirnov (KS) distance (the lower the values, the more similar the distributions). Another popular measure of distance between distributions is the Fréchet ChemNet Distance (FCD). FCD is computed from the internal representations of the penultimate layer of a model for bioactivity prediction, capturing both chemical and biological information. Lower FCD values indicate greater similarity between molecular sets in terms of structure and bioactivity. An important caveat is that distribution-based similarities require a minimum number of molecules to be reliably computed, , estimated to be around 100,000.

## Section: Charting the Chemical Cosmos with Generative AI › Evaluating the Quality of de Novo Designs › Predicted Molecular Suitability

Ultimately, de novo drug design aims to find molecular candidates for hit and lead discovery, possessing an array of desirable properties, such as potency, selectivity, pharmacokinetics, and safety. These properties are inherently complex and challenging to determine experimentally, due to their resource-intensive nature. This is why surrogate computational approaches of different levels are used for molecule evaluation and prioritization. Commonly used computational approaches are: (a) quantitative structure–activity relationship (QSAR) approaches, to predict biological properties such as potency, selectivity and ADMET (absorption, distribution, metabolism, excretion and toxicity) properties; (b) pharmacokinetic models, which aid in predicting bioavailability, clearance, and systemic exposure; (c) estimation of synthetic feasibility, − at varying levels of complexity; and (d) biophysics-based approaches, such as docking and molecular dynamics. Each computational approach offers distinct advantages and limitations in molecule evaluation. QSAR models enable rapid, cost-effective predictions of biological properties but rely heavily on high-quality training data, which are often not available. At the same time, pharmacokinetic models provide physiologically relevant insights into drug disposition, yet they require accurate input parameters, which can introduce uncertainties. Synthetic feasibility estimations aid in prioritizing accessible compounds, but may bias toward well-established chemistries, potentially overlooking innovative or unconventional synthetic routes (see Section ). Biophysics-based methods provide mechanistic insights into molecular interactions, with docking offering rapid but often simplified predictions of binding poses, while molecular dynamics (MD) captures conformational flexibility and stability at the cost of significantly higher computational expense. However, both approaches can suffer from scoring inaccuracies, particularly in ranking binding affinities. Despite these challenges, these computational tools have become indispensable to navigate and rationalize the large virtual libraries designed by generative deep learning.

Evaluating the quality of de novo designs remains one of the most challenging open questions in the field. , This complexity arises from the inherently multi-objective nature of drug discovery, the unfeasibility of large-scale synthesis and biological testing, and the absence of perfect models to predict complex in vitro and in vivo properties. Nonetheless, the cheminformatics community has been particularly active in delineating guidelines and benchmarks to aid in the evaluation of the designs produced by generative deep learning algorithms (e.g., Table ). Overall, the specific approaches adopted to evaluate a generator’s designs depend on the intended goalwhether to develop and compare generative models or to prioritize compounds for experimental validation.

When comparing generative models or developing new ones, large-scale assessment is recommended, typically involving at least 100,000 molecular designs. In this context, evaluating chemical validity and non-redundancy are necessary, but not sufficient, to monitor the correct learning of chemical information. Furthermore, the analysis of similarity and diversity patterns (e.g., number of circles or substructures, descriptor similarity and FCD) are required to provide insights into a model’s potential and limitations. Practitioners should ensure that the same number of generated designs should be used across evaluations, to prevent unintended confounding factors that could bias model comparison.

For applications aiming to bring generative models closer to experimental validation, a more refined evaluation strategy might be required. While similarity vs. diversity analysis remains relevant for optimizing the exploration-exploitation trade-off, additional layers of molecular assessment might come into play. Early-stage filters, such as simple synthetic accessibility estimations, help narrow down the chemical space before applying more sophisticated and computationally demanding retrosynthesis predictions. Similarly, biophysics-based evaluations may start with docking for rapid binding predictions, followed by more resource-intensive molecular dynamics simulations to refine binding mode stability and interaction profiles.

To date, the effectiveness of de novo design evaluation, especially for prospective applications, remains dependent on the expertise and viewpoint of the researchers analyzing the results, highlighting the need for a strong synergy between machine learning specialists and medicinal chemists to ensure that computationally generated designs align with real-world drug discovery objectives.

## Section: With Complex Objectives Come Complex Responsibilities › The Similarity-Diversity Paradox

Designing new drug candidates faces a persistent challenge: balancing structural diversity with molecular similarity to known molecules. On one hand, similarity to known bioactive compounds increases the likelihood of identifying viable drug candidates, as structurally related molecules often share biological activity. On the other hand, excessive similarity can restrict chemical innovation and the likelihood of charting novel chemical space. This not only hampers the discovery of molecules with improved therapeutic propertiessuch as enhanced potency, selectivity, or safetybut also raises concerns regarding patentability of compounds that closely resemble existing drugs. In drug discovery, innovation beyond “me-too” compounds requires striking a balance between leveraging known bioactivity and exploring sufficiently distinct chemical matter to uncover new mechanisms of action and therapeutics. We term this tension as the “similarity-diversity paradox”, to underscore the difficulty in simultaneously achieving the two.

How to balance similarity and diversity has been a long-standing question in the cheminformatics and drug discovery communities. , This paradox can be mitigated by aiming to minimize substructure and scaffold similarity, while preserving three-dimensional information. In the context of protein–ligand binding, in fact, bioactivity is primarily driven by three-dimensional shape and electrostatics complementarity, along with other molecular recognition factors. Based on this concept, several generative approaches have incorporated shape and/or electrostatic complementarity in the design process, e.g., by conditioning the generation using pharmacophore or three-dimensional pocket information, − or via ad-hoc scoring for reinforcement learning. ,, These approaches could allow to preserve core features for binding (i.e., similarity to pharmacophore and/or 3D shape and electrostatics) while allowing to explore new regions in the chemical space in terms of scaffolds and substructures (ensuring “two-dimensional” diversity). Another strategy to increase diversity is by drawing inspiration from natural products. , Natural products have been a rich source for medicinal chemists due to their structural complexity and diverse scaffolds, which often translate into a wide range of biological activities. − Recognizing this, several studies have employed deep learning techniques to generate natural product-inspired compounds via transfer learning ,, or fragment-based generation. These studies show that incorporating natural-product-derived information allows to expand the chemical space accessible for drug discovery while preserving desirable properties such as bioactivity.

Exploring previously uncharted regions of chemical space is nevertheless not easy. In fact, most available molecule evaluation toolssuch as docking algorithms, QSAR models and ADMET prediction toolsmight struggle with highly novel scaffolds. − These tools often rely on statistical correlations derived from existing datasets, meaning that molecules with unprecedented cores or non-traditional structural features may fall outside their applicability domain. For instance, docking algorithms typically assume that ligands share similarities with known binders, leading to inaccurate scoring for highly distinct chemotypes. Similarly, machine learning-based bioactivity predictors are known to provide unreliable predictions when applied to molecules that are too different from the molecules used for training. , Finally, synthetic accessibility scores often penalize novel molecular structures, and might not consider current or future advancements in organic synthesis.

Navigating the similarity-diversity paradox with the current technologies ultimately requires combining several techniques. De novo designs occupying the “familiar” chemical space can be scored with the available data-driven tools such as docking approaches and predictive models, and synthesis routes can be devised for prospective studies. For diverse designs outside the applicability domain, physics-based molecular dynamics simulations of increasing computational complexities can be run. Initial short or coarse-grained simulations can help preselect a smaller pool of de novo designs. For these selected candidates, performing more extensive and accurate simulations (potentially with multiple replicates) might help the refinement of the compound selection. Ultimately, overcoming the similarity-diversity paradox will be only possible by combining efforts from multiple disciplines, such as improving generalizability in molecular machine learning, and finding synergies, complementarities and overlaps between physics-based approaches and data-driven predictions.

## Section: With Complex Objectives Come Complex Responsibilities › Benefits and Limitations of Molecular Benchmarks for de Novo Design

Evaluating generative models poses additional challenges than evaluating predictive models (e.g., to predict bioactivity or toxicity). While predictive models can be evaluated via held-out molecules that were previously tested, de novo designs are, by definition, molecules that have not been previously tested for their properties. This makes it difficult to evaluate different model architectures, choose which model should be used for prospective studies, and identify learning gaps. To overcome this limitation, in the past few years, several notable benchmarking efforts, ,,, such as GuacaMol and MOSES, have strived to provide standardized datasets and metrics, to evaluate and compare generative models (Table ).

GuacaMol and MOSES are to date the most well-known benchmarking platforms. They include datasets for testing, along with benchmarking metrics for comparing generative modelswith GuacaMol comprising both distribution-learning and goal-directed models, while MOSES focusing on distribution-learning models. These benchmarks have enabled researchers to compare diverse approaches systematically, facilitating rapid progress in algorithmic development and model optimization. By offering well-defined tasks (e.g., optimizing molecular properties, generating diverse compounds, or mimicking training distributions), these benchmarks have become indispensable tools for assessing the performance and utility of generative algorithms in chemistry. While molecular benchmarks are undeniably valuable, there are inherent limitations and potential pitfalls associated with their use. Prominent among these is the risk of overfitting models to benchmark-specific tasks, metrics, or datasets. Such overoptimization can lead to a “tunnel vision”, where models excel at predefined tasks but fail to generalize to real-world drug design challenges. In this context, excessive reliance on benchmarks has been suggested to stifle creativity, as researchers prioritize improving benchmark scores over addressing broader, more impactful scientific questions. Moreover, molecular benchmarks often simplify the complexity of drug discovery. Real-world drug design involves multifaceted objectives, iterative processes, and the integration of experimental validationaspects that are not easily captured in benchmark tasks. The reliance on computational metrics, such as similarity or property optimization, may inadvertently bias research toward generating compounds that are easy to evaluate computationally but less relevant for practical applications.

To address these challenges, the field must strike a balance between leveraging the advantages of benchmarks and fostering innovative, application-driven research. This includes testing and benchmarking approaches on more than one benchmark, continue the development of progressively more realistic evaluation metrics and datasets, and ultimately, incorporate experimental feedback, whenever possible. By acknowledging both the benefits and limitations of molecular benchmarks, we wish for the community to harness the potential while remaining vigilant against their unintended consequences.

## Section: With Complex Objectives Come Complex Responsibilities › Navigating Feasibility in Molecular Generation

While generative deep learning models allow to produce previously unseen molecules, difficulties arise in addressing synthetic feasibility. Defining and incorporating synthesizability is a challenging task, as it may depend on subtle structural variations, reaction selectivity, and the commercial availability of building blocks essential to chemical reactions. Moreover, several research has shown that the synthesizability of molecules proposed by deep learning may be limited, depending on the chosen approach.

A wealth of research has focused on assessing the synthetic feasibility of molecules. Commonly used strategies generally assess one of the following aspects (Table ): Synthetic complexity scores, identify those molecular characteristics that could challenge the synthesis. Metrics such as the synthetic accessibility score (SASscore) estimate synthetic complexity based on the presence of predefined molecular motifs, such as the number of bridged and spiro systems, stereocenters, or macrocycles. Other complexity metrics account for functional group distribution, molecular size, and ring system strain. More recently, scores of synthetic complexity based on deep learning have been introduced, for instance, based on the number of estimated reaction steps required. Predicted retrosynthesis routes.Determining retrosynthesis routes involves decomposing a target molecule into building blocks that are either commercially available or easy to synthesize. Computationally, retrosynthesis planning can be approached by using either rule-based methods or machine learning. Rule-based approaches , identify functional groups and reaction motifs, then apply a library of predefined reaction templates to suggest potential precursors. Machine learning approaches are used to learn retrosynthetic feasibility directly from large databases of annotated reactions. This can be performed via (a) template-based retrosynthesis, where the model selects reaction templates from training data, , or (b) template-free retrosynthesis, where sequence-to-sequence learning or graph-based transformations are applied to generate precursors directly, without predefined templates. −

Each strategy has distinct advantages and disadvantages. Synthetic complexity scores provide a rapid assessment of synthetic feasibility, which makes them particularly suited to evaluate large molecular libraries, or to be included in reinforcement learning pipelines. However, synthetic complexity scores that rely on predefined heuristics are static as they may not include new synthetic methodologies and cannot easily be updated based on new reaction data. Furthermore, these strategies condense vast information into a single score, which can obscure important nuances, such as whether a high complexity score is due to challenging stereochemical features, strained ring systems, or uncommon functional groups. As a result, these scores may sometimes penalize molecules that are accessible via modern synthetic routes.

In contrast, machine learning-based approaches offer a dynamic and data-driven alternative to static complexity scores. By learning from large reaction databases, they can capture nuanced relationships between molecular structures and their synthetic feasibility while adapting to new reaction data. Lastly, retrosynthesis-based models further provide explicit synthetic routes, with template-based methods using established transformations and template-free approaches offering greater flexibility for novel chemistry. However, these models are limited by data bias and reaction coverage.

For this reason, the choice of feasibility assessment method depends on the application. Complexity scores remain valuable for rapid screening of large molecular libraries, and computational pipelines where computational efficiency is crucial. Meanwhile, machine learning-based retrosynthesis models provide more practical feedback for experimental applications by suggesting synthesis routes, but they require careful curation of reaction data to ensure reliability. While synthetic feasibility is typically assessed after molecule generation, approaches that generate molecules while considering the synthesizability constraints were also developed. They are divided into following groups: Enumeration-based methods, which refers to the systematic generation of (all) possible candidate of building blocks molecules by following a set of predefined reaction rules. This method explores the synthetic accessible space, often using reaction vectors for the reaction rules. , Synthesizability-constrained molecular generation, which include reaction templates, or reactivity predictions to generate experimental accessible molecules and their pathways. , Another promising approach is to integrate synthetic accessibility as an optimization objective within reinforcement learning, to steer the generation toward drug-like synthetically accessible molecules. ,, Other approaches have used autoencoders for molecule optimization that considers both desirable molecular properties and elements of synthetic accessibility, ,− and optimized the score of oracle retrosynthesis prediction models.

Last, estimating synthesizability adds to the challenges of designing structurally diverse (and out of distribution) molecules, while remaining synthetically feasible. In these cases, the designs might not only fall out of distribution of the approaches used to assess their physico-chemical and biological properties, but also of the approaches used to estimate their synthesizability. To bridge this gap, recent research has addressed the generalizability of synthesis prediction tools when applied to newly reported patents or reactions. Advancing synthesis estimation models in parallel with molecule generation ones is expected to be a key strategy to allow charting the chemical universe in an efficient manner.

## Section: With Complex Objectives Come Complex Responsibilities › The Experimental Validation Dilemma

Unlike bioactivity or molecular property predictionwhere models are usually evaluated on well-defined test setsmolecular generation aims to propose novel, previously unseen molecules, whose properties are unknown. Moreover, generative approaches tend to show low “molecular rediscovery” rates, , making it difficult to use existing, held-out molecules for the evaluation. These aspects make direct evaluation of generative approaches difficult, as there is no ground truth to compare against. Compounding this challenge, existing tools for assessing de novo designssuch as similarity metrics, bioactivity prediction, or heuristic scoresare inherently imprecise and/or only partially capture complex design objectives.

Arguably, the only definitive “proof-of-the pudding” of bioactivity is experimental validation. However, experimental testing is expensive and time-consuming, meaning that only a small fraction of generated molecules can be synthesized and evaluated. Hence, this process faces two major bottlenecks: Selection of molecules to make and test. With thousands of generated designs scoring similarly on computational metrics, choosing which ones to validate experimentally is challenging. Many of these scores contain inherent noise, and small variations in ranking may not correspond to meaningful differences in experimental properties. At the same time, errors in the scoring functions (e.g., for out-of-distribution molecules) might rule out suitable molecules. Ensuring that promising candidates are not overlooked requires robust selection strategiesyet, defining optimal criteria for this process remains an open challenge. Sufficiency of experimental validation. In machine learning, test sets used to validate predictive models, typically contain a substantial number of molecules to provide statistically robust evaluations (e.g., in the order of hundreds to thousands of compounds , ). In de novo design, however, synthesizing and testing even a small fraction of generated molecules is prohibitively expensive. This raises a fundamental challenge: how many designs are sufficient to reliably measure the effectiveness of (and compare) generative deep learning models? To date, balancing practical feasibility with robust evaluation remains an unresolved issue.

In addition to cost and time constraints, experimental validation of generative deep learning approaches demands expertise across multiple disciplines, including synthetic and medicinal chemistry, computational modeling, assay development, and data analysis. This interdisciplinary challenge likely contributes to the relatively scarce experimental validation of generative models (Table ), especially when compared to the vast number of proposed approaches. This might also be the reason why the field tends to validate new methods predominantly on well-explored targets, like kinases and nuclear receptors (Table ). Finally, the validation cost and complexity escalate as the targeted property becomes more clinically relevant, requiring more advanced assays, in vivo studies, or even early stage pharmacokinetics and toxicity evaluations. These challenges underscore the difficulty of translating de novo molecular design from computational predictions to real-world applications.

The integration of automated synthesis and self-driving laboratories offers a promising solution to such “experimental validation dilemma”. , By combining robotic synthesis, high-throughput screening and deep-learning driven molecule design and synthesis planning, these platforms can accelerate experimental validation while mitigating the bottlenecks of manual experimentation. Automated synthesis not only enables a more systematic assessment of the capabilities of generative drug discovery approaches, but also enhance the efficiency of design-make-test-analyze cycles. Incorporating adaptive learning strategies (e.g., active learning , ) could further refine molecular generation strategies, guiding the exploration of the chemical space with greater precision and versatility.

## Section: Future Directions and Opportunities

Generative deep learning has advanced the opportunities to design molecules on-demand in search for drug hit and lead candidates. The field is experiencing rapid advances, offering both exciting prospects and notable challenges.

One of the biggest challenges remains the evaluation of design quality. In complex design tasks, such as the design of bioactive molecules, accurate and scalable quality metrics are lacking. Fast evaluation metrics, e.g., quantitative estimate of drug-likeness and QSAR model predictions, can misguide molecule selection and sacrifice prediction accuracy. ,− On the other hand, relying on accurate but time-consuming simulations is practically unfeasible on large libraries, and hence it inevitably constrains the breadth of the analysis. We see accelerating these simulations with deep learning as a promising research direction, − which could remove a major obstacle to realizing the full potential of generative deep learning. Until speed and accuracy are effectively combined, new research should report multiple and multifaceted evaluation metrics for large design libraries to better reflect design quality. ,,

A direct consequence of the challenges in design evaluation is increased risk of testing the proposed de novo designs in the lab. While computational scoring functions (e.g., docking and QSAR models) can prioritize de novo designs, , they are reliable only within their respective applicability domains, leading to filtering out structurally novel designs. Hence, training models with better out-of-distribution capabilities can extend these limits and represents a promising research direction. We expect the integration of predictive approaches with higher generalization capabilities into reinforcement learning as a promising direction to enable fast chemical space exploration in search for structurally novel molecular entities.

Another fundamental challenge for de novo design is data scarcity. , Even “large” bioactivity datasets usually contain only a few thousand molecules , which constitutes a bottleneck for deep learning. Transfer learning helps mitigate this problem by leveraging unlabeled datasets, however, current approaches also face issues such as catastrophic forgetting and mode collapse, resulting in reduced design diversity. Designing new training strategies has attracted increasing attention from the research community. In-context learning for molecules − and test-time scaling of generations are two promising examples; further research is needed to validate their applicability. We also view inactive molecules as an invaluable resource for low-data drug discovery research, since inactive molecules are typically more abundant than active ones.

It is impossible to ignore the recent rise of large language models (LLMs) and their potential to accelerate molecular design. While open questions remain regarding their chemical representation capabilities, − these models offer great ability to integrate diverse sources of information, from textual descriptions of chemical reactions to structured datasets, potentially leading to rapid and/or more informed molecular generation and design evaluation. − However, despite their promise, LLMs have yet to fully permeate drug discovery, and their role in addressing key challenges such as generalization, zero-shot learning, and structure-based design remains an open question.

We currently see two parallel but increasingly intertwined movements. The deep learning community continues to push the boundaries of generative modeling, developing more powerful architectures to explore chemical space. ,,, Meanwhile, the drug discovery community is working to integrate key factors (e.g., chemistry, bioactivity, synthesizability) into the evaluation of generative models, to ensure their relevance for therapeutic applications. ,, Historically, these efforts have often progressed in isolation, but they are now converging as both fields recognize the need for models that are not only innovative but also grounded in medicinal chemistry and pharmacology. Bridging this gap will require strong interdisciplinary collaborations between these communities. Moreover, advances in model interpretability, evaluation frameworks that better reflect real-world constraints, and tighter integration between computational design and experimental validation, will help close such gap. As these two domains continue to evolve, the true measure of success will not be in generating molecules alone, but in producing candidates that can withstand the demands of drug development and make a tangible impact. Herein, the importance of not only publishing success stories, but also negative experimental results are key, as it helps researchers understand better where research pipelines involving computational methods need to be adjusted.


---

# Genomic data sharing in research across Europe: legal challenges and upcoming opportunities within the European Health Data Space

- **Authors:** Romina Royo, Eva Garcia, Irene Schlünder, Christina Hilmarsen, Mette Kielsholm Thomsen, Emilie Cauët, Simon Kok Jensen, Simona Giardina, Aline Hebrant, Gordana Raicevic Toungouz, Marc Van Den Bulcke, Juan Arenas, Christian Fynbo Christiansen, Eivind Hovig, Petr Holub, Alfonso Valencia, Salvador Capella-Gutierrez
- **Issuer:** European journal of public health
- **Type:** Scientific article
- **Published:** 2025-09-01
- **Language:** en
- **DOI:** 10.1093/eurpub/ckaf070
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40926478/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe European Health Data Space (EHDS) will help researchers use health data across EU Member States (MS). Currently, cross-border research faces heterogeneous data access processes. Using a real-world use case, this paper analyses challenges and opportunities brought by the upcoming implementation of the EHDS, assessing the situation before and after the regulation comes into force. The use case focused on metastatic colorectal cancer, analysing the relations between mutational signatures and clinical trajectories while addressing data access procedures across MS. The regulatory landscape and the challenges that need to be addressed for the EHDS to enable the secondary use of health data, particularly genomic data, are complex and heterogeneous across MS. We describe the pathway from data application to access to pseudonymized data in secure processing environments, emphasizing the legal requirements, including the role of ethics committees. Finally, we analyse the success factors for achieving access to the data and the reasons for access denial to support shaping the upcoming EHDS implementation. Several challenges remain unaddressed for cross-border data use, especially in the context of genomic data, where the complexity and heterogeneity of informed consent can impact or even impede data-sharing efforts. While EHDS can simplify processes across MS, it is crucial to ensure that additional safeguards do not negatively impact or block access to health data and that EHDS infrastructure is ready for effective and affordable processing of large volumes of genomic and other data.

## Section: Introduction

The European Health Data Space (EHDS) regulation aims to implement a novel homogeneous mechanism for accessing and using health-related data across the EU and associated Member States (MS) for primary use, e.g. patient care, and for secondary use, e.g. research and policy-making purposes. Technological developments, including one or more digital platforms, are needed to achieve the ambition set in this regulation. In 2022, the European Commission launched the HealthData@EU Pilot project to better understand the possibilities and barriers of using health-related data for research, especially regarding the technological developments needed to respond to the upcoming regulation. This publication describes and discusses the challenges and learnings of accessing genomics data within the proposed EHDS [1], using insights from a near real-world research project: the ‘Cancer Genomics Use Case’ of the HealthData@EU Pilot project. This use case explored current challenges and obstacles while highlighting potential improvements in genomic data access and usage under the upcoming EHDS regulation. At the same time, the outcomes of this project will contribute insights into real-world challenges requiring attention in the future implementation of the EHDS, underscoring the project's importance in shaping the regulation's development.

In this use case, the secondary use of the data generated in clinical practice and the reuse of research data enable addressing questions of current medical importance, such as the relationship between medical trajectories and mutational signatures [2] which reflect the imprints of multiple mutational processes and provide insights into tumour aetiology. Efficient and secure integration of clinical and genomics data remains key to personalized medicine; expanding our understanding of disease mechanisms and enabling more precise diagnostics and therapeutic strategies that may ultimately improve patient outcomes [3–6].

The Cancer Genomics Use Case (Supplementary Fig. S1) focuses specifically on colorectal cancer (CRC), which has one of the highest cancer disease incidences across the European population [7]. The use case starts with the assembly of retrospective cohorts from different partner organizations that can enable the validation of known gene signatures and the discovery of new ones and their association with additional factors, such as tumour location or age. In the use case context, each participating organization, based in a different European country (Norway, Denmark, and Belgium), managed its own data application, reflecting the process researchers would typically follow. At the same time, these organizations played the role of health data access bodies (HDAB) in EHDS to better understand the implications of such an important actor and pilot the infrastructure. Similarly, BBMRI-ERIC served as a model of a European Research Infrastructure capable of both centralized and decentralized hosting and providing patient data, with its international role within the EHDS as an authorized participant, processing the access application and providing a Secure Processing Environment to process the data.

The Cancer Genomics Use Case was conceived to utilize whole-genome sequencing (WGS) or whole-exome sequencing (WES) data with its associated clinical data [8]. However, access to WGS/WES data was not homogeneous, with some use case participants unable to identify accessible WGS/WES datasets in their jurisdiction, as was originally planned, due to either the lack of the legal bases or the low availability of WGS/WES data compared to gene panels in clinical routine practices. This does not imply a lack of WGS/WES data in research, while the challenge lies in clinical data availability for secondary use within the EHDS framework. Throughout the development of the use case, strategies were adapted to accommodate the available data, e.g. gene panels, and the constraints of accessing them.

This work explores the implementation of a pilot use case within the framework of the EHDS. It was designed to incorporate genomic data, recognizing its potential impact on research, and to address the challenges of accessing data generated in health care for its use in research.

## Section: Methods

WGS, WES, and gene panel data are generated in both routine clinical care and research projects to detect genetic variants for diagnosis, treatment, and scientific research [9]. While WGS and WES are extensively used in research, they are less common in clinical settings, where gene panels are more frequently applied. In Denmark, only a few genes are routinely examined for CRC diagnosis. WGS is performed only in patients with disseminated CRC who no longer respond to standard care and are potential candidates for targeted treatment. Similarly, in the BBMRI-ERIC CRC-Cohort, the consensus data model covers mutations in relevant genes from 25 institutions from 12 European countries, assuming that WGS/WES data can be generated from available linked biological material stored in biobanks.

Therefore, the scientific question was adapted to the project’s available data and time constraints. The original question was designed to address the relationships between mutational signatures and clinical characteristics, such as tumour localization or age of the patient. The revised hypothesis simplified this analysis due to the limited genome coverage in the available genomic data from most, which precluded the identification of mutational processes occurring outside of the targeted genes. This shift focused on annotating and prioritizing clinically relevant variants based on executing the Personal Cancer Genome Reporter (PCGR) [10]. This tool inputs Variant Call Format (VCF) files [11] and uses cancer-specific databases to provide insights into variants’ pathogenicity and clinical value.

After re-defining the research question, each use case participant started the process of applying for data access. Three institutions are based in different European countries (Denmark, Belgium, and Norway), while the fourth is a European Research Infrastructure (BBMRI-ERIC). The individual protocols are summarized below, with more details in the Supplementary Material.

## Section: Methods › Belgium › Available data for request

Small (50 genes) to medium (150 genes) panels are covered by the national healthcare system, while Comprehensive Genomic Profiling (CGP) is not. The PRECISION initiative [Belgian Society of Medical Oncology (BSMO), 2018] provides molecularly guided treatments for metastatic solid tumours that are eligible for systematic therapy. It established a database collecting genomic and clinical information, including the Registry of the next-generation sequencing (NGS) tests used in clinical routine (NGS convention project). Two additional studies, the Belgian Approach for Local Laboratory Extensive Tumour Testing (BALLETT) and the Genetic, Neo (GeNeo) referring to ‘novel techniques’, have expanded patient access to CGP.

## Section: Methods › Belgium › Data access protocols

Sciensano, the Scientific Institute of Public Health in Belgium, owns the NGS data, while the BSMO owns the BALLETT and GeNeo data. Since they were collected in clinical trials, access is limited to participating institutions, including Sciensano. Requests were made to access the VCF files of the NGS convention project and BALLETT, while only reported variants are available for GeNeo. Data is stored in Sciensano (Healthdata.be) with a data transfer agreement already in place. BSMO only required additional information regarding the use case.

## Section: Methods › Denmark › Available data for request

Routine genetic analyses include a few relevant genes. For disseminated cancer, the National Genome Center may perform WGS for targeted treatments. Additionally, WGS, WES, or gene panels may be collected in research projects. Genomic data can be linked to regional and national clinical and administrative data using Denmark’s personal identification number [12].

## Section: Methods › Denmark › Data access protocols

Regional ethics committees (REK) may approve the secondary use of non-extensive genomic analysis without consent, but the Danish National Committee on Health Research Ethics (NVK) [13] approval is required for WGS. Reuse of genomic data for research is considered a ‘health data science project’ and requires a specific hypothesis; exploratory studies need renewed consent. Thus, we requested NVK clarification on whether this use case qualifies as method development without ethical approval or whether it should be approved as a research project.

## Section: Methods › Norway › Available data for request

Tumour genetic analyses may be performed in routine clinical care or in clinical studies. Results are only available in the patient’s electronic patient record or within clinical study databases, and their use is consent-based and limited to approved purposes. Two clinical trials (IMPRESS and COMET) were identified for this use case.

## Section: Methods › Norway › Data access protocols

REK approval under the Health Research Act was required. A protocol outlining the reuse of clinical trial data was submitted to the REK and approved. However, strict conditions were imposed, including the requirement for new informed consent from living patients and their biological relatives (for deceased patients) and an infrastructure to manage clinically important findings, such as re-identifying individuals.

Legal and ethical questions about these requirements were escalated to the joint National Ethics Committee (NEM). If fully approved, the analysis would require curated data from the Cancer Registry of Norway, and an application would need to be sent to the Health Data Services, which is managed by the Norwegian Institute of Public Health.

## Section: Methods › BBMRI-ERIC › Available data for request

The BBMRI-ERIC CRC cohort (CRC-Cohort) contains clinical data from over 10 000 cases across Europe, covering key mutations, microsatellite instability, mismatch repair gene expression and Hereditary Nonpolyposis CRC assessment [14]. Some countries provide additional data, such as panel sequencing (e.g. TSO500), WGS/WES or whole slide images.

## Section: Methods › BBMRI-ERIC › Data access protocols

Requests follow BBMRI-ERIC and CRC-Cohort Access Policies [15, 16]: (i) Registration: verification of requester identity and affiliation. (ii) Data request: submission via the BBMRI Negotiator platform [17] detailing the project, required data, and ethical approvals. (iii) Access control and data delivery: requesters must prove compliance with regulations and ethical standards, including data protection and consent. Approvals are evaluated by the Access Committee, involving all contributing biobanks. After approval, a Data Processing Agreement (DPA) is signed, and data are provided within a Secure Processing Environment. (iv) Return of results: requesters are encouraged to report outcomes and integrate derived data into the BBMRI-ERIC infrastructure for future accountability. BBMRI-ERIC-hosted data are processed for research under GDPR’s informed consent basis. When BBMRI-ERIC participates in EHDS as an authorized participant, it will continue using this basis since the legal obligation for data holders does not apply to authorized participants.

## Section: Results

The Cancer Genomics Use Case was designed to use WGS/WES data as it provides extensive genome views [18, 19], which might contribute to confirming known signatures and potentially uncover new ones. However, we found limited WGS/WES data availability across use case participants, with minimal commonalities and different access protocols (Fig. 1). Some of them could access WGS/WES, while others only had gene panel sequencing data, ranging from comprehensive panels (300–500 genes) to very limited ones (<5 genes). Additionally, the Belgian partner could only provide tumour-only data, complicating the analysis due to the difficulty in distinguishing somatic mutations from artefacts and germline variants [20]. Based on this, we selected the most suitable datasets for the use case.

Beyond challenges in finding relevant data in the context of clinical data, the access processes across different EU countries, compared in Fig. 2, lacked clarity, requiring discussions with data owners, legal teams, and other authorities and resulting in imprecise and lengthy timelines for data access. The specific hurdles faced by each country highlight the variability in protocols across countries and research infrastructures, with different institutions enforcing differing levels of ethical approval. Two use case participants, BBMRI-ERIC and Norway, required ethical approvals but with different levels of stringency, while Denmark examined the option to apply for a method development project instead of a research project, focusing on the use case aim of assessing data access procedures across countries.

Just at the time of submitting this manuscript, the Belgium partner had managed to access the data, highlighting the challenges faced by all use case participants. The data access procedures were sometimes delayed due to lengthy discussions with regulatory bodies and ethics committees. In Denmark, nationwide genomic data has only become available for research in the National Genomic Database from June 2024, nearing the end of the use case period, and it was not possible to obtain all approvals and to get data access. A request was submitted to the National Research Ethics Committee at the end of 2023, proposing the project as a test of the EHDS setup, i.e. a method for European research projects. However, the committee did not respond in a timely manner, probably due to the request not fitting into the usual categories of applications. Similarly, in Norway, the REK required re-consenting, which was deemed both impractical and unethical, particularly for deceased patients where identifying next of kin was not feasible. It also required setting up a procedure for handling incidental findings, which was also deemed unethical, as contacting the closest relative (defined legally, not genetically) could cause several stressful reactions. This situation arose for the datasets that were selected based on having original consents for data sharing, thus implicating that in Norway, unless the consent is specific to the research question, it is not possible to have secondary use of clinical data with the current legislation.

Moreover, the complexity of obtaining data from multiple sources was exemplified in Belgium, where access was granted only to clinic-genomic data from the NGS study. Access to the VCF files for GeNeo was impossible due to restrictions imposed by Foundation Medicine (Roche FMI), the company conducting the testing, and data access for BALLETT remains pending.

Finally, the BBMRI-ERIC CRC-Cohort access procedure reflects the standard governance in European biomedical research, if not globally. A cornerstone in the access procedure is the submission of approval of the research protocol and the safeguards regarding the privacy of the participants by an independent Ethics Committee (EC) or Research Review Board by the applicant. Since there is no global standard for the required documents or the level of detail for research protocols, the approval procedures vary significantly, depending on the mechanisms in place at the institutions applying for data access, which can be lengthy, as in our case. After obtaining ethical approval, the Access Committee initiates the Access Procedure, which is approved or withheld by the data holders (contributors to the cohort) and can extend the data access timeline.

In summary, after >2 years, data were unavailable in most use case participants, as outlined in Table 1, which details the data requested at each of them and the current status. Our results illustrate the practical challenges and burdens currently faced by researchers when applying for access to health and genetic data. We observed that different data holders imposed varying requirements and protocols, which significantly impacted the efficiency of the data access process. Some data holders required additional documentation, while others had more stringent ethical approval processes that caused delays in access. All these insights will play a crucial role in shaping the upcoming implementation of EHDS. Indeed, it is expected that the implementation of the EHDS will contribute to alleviating the situation and providing consistency and clarity across the EU and associate MS.

Implementation of the expected steps for data access protocols in each use case participant. Top, general overview (including those steps common for some partners) and (bottom) additional particularities of the steps and actors involved in the process for each partner. Of note, these data access protocols are usually followed by data processing (not shown). NIPH, Norwegian Institute of Public Health.

Comparison of data access steps and outcomes across use case participants. As of February 2025, the figure outlines the main steps for data access and their corresponding outcomes for each partner, represented by a country flag or organisation logo. In the case of the Danish organization, it was possible to select two different mechanisms to request access to the health data. The figure represents the path chosen as a method development project.

Table summarizing the datasets available for request at each use case participant

## Section: Discussion

This use case was set up to analyse current challenges in genomic data access, comparing them with the expected improvements after implementing the EHDS regulation. The practical implementation, based on the execution of the PCGR [10] to systematically analyse cancer genomes in the context of diagnostic, prognostic, and therapeutic biomarkers, showcased the challenges of accessing sensitive data, especially genomic data, and explored various possibilities across different settings, from national institutions to research infrastructures. The lessons learned from the entire process, in particular the ethical and legal aspects, should provide valuable input to projects that are supporting the development of the Implementation Acts by providing use cases and requirements that guide EHDS implementation, such as the Second Joint Action Towards the European Health Data Space (TEHDAS2, https://tehdas.eu/).

. Comparison of relevant steps and actors for data access in the current project (pre-EHDS) and in the upcoming EHDS (post-EHDS)a

## Section: Discussion › Current situation of European cross-border access to genomic data

The first key challenge in the use case was the availability of WGS and WES data, particularly in health care, where such data are often available late in the course of the disease. Patients must survive long enough to benefit from WGS/WES-based diagnostics and have the potential benefit of such genomic profiling. This limitation led to a scarcity and heterogeneity of genomic data across countries. Taking into account the variety of genomics data available in each use case participant, ranging from very few genes to WGS, we opted for the most inclusive minimum common dataset possible, maximizing the participation of all involved partners in the use case and making every effort to preserve the fundamental aspects of the original protocols. We found that ethical permission for the secondary use of WGS/WES without new information is particularly difficult due to the increased risk of incidental findings of potential impact on the patients and their relatives [21], despite our focus on somatic variants. Removing germline (and rare) variants before making them available is an aspect to consider. However, this decision should be taken specifically for each study requesting access to WGS/WES data.

## Section: Discussion › How EHDS could change the landscape of data access across Europe

The EHDS will allow the use of data from hospitals, laboratories, and research institutions. This enormous amount of health-related data opens up many research opportunities, being complementary to those mechanisms that are already in place, such as informed consent or public interest as a legal basis, and data transfer agreements to transfer the data between involved parties Thus, the EHDS is an additional, not exclusive, legal basis for data access, and initiatives like GDI and EUCAIM support interoperability, ensuring multiple pathways for data reuse.

Thus, the EHDS will facilitate unified data discovery, as health data users must understand which data is available and where it is located. A European centralized metadata catalogue will be part of the HealthData@EU infrastructure, enhancing the findability of datasets and informing researchers about the quality and utility of the data through the label under development in the QUANTUM project (https://quantumproject.eu/). However, data might be extracted separately from various sources, integrated before becoming available (i.e. Belgium) and accessed in parallel across different countries. These operations are specific to each infrastructure and may incur costs and efforts, directly impacting the sustainability of data exploration and access models. Nonetheless, the EHDS partially covers costs through permit issuing and data provision fees. Without such a framework, ensuring long-term sustainability would be significantly more challenging. Regarding data access, it will be important to develop common protocols and evaluation criteria that are then applied by the different data access authorities. Even if those aspects are solved, problems of heterogeneity and syntactic and semantic interoperability will have to be addressed by using common metadata, data standards, ontologies and aligning terms so they share the same meaning.

Considering the massive investment needed to make legacy data fully interoperable without a clear use, a pragmatic solution could be to adopt interoperability mechanisms prospectively so that newly generated data would be interoperable across systems and countries by design. Retrospective data, which is very relevant for research, could be transformed—ideally at origin—when its secondary use makes it necessary.

Beyond having common data access protocols and clear interoperability mechanisms, it is crucial to consider multidimensional data linkage. Synchronization procedures between countries should enable that any health-related data point at the record level is assigned unequivocally to the same individual regardless of where the data were generated and/or captured. This represents a newer challenge that goes beyond secondary use and the organization of the national health systems, including public and private care [22].

Even though the access to health data for secondary use will be somehow harmonized, as shown in Table 2, the EHDS Regulation [23] does not address the main hurdle: the lack of streamlining of the formalities necessary in each country to qualify for a data access application. Furthermore, legal fragmentation can be more pronounced for genetic/genomic data due to additional safeguards that can be implemented in each country (Art 51 §4 of EHDS). While a general opt-out for citizens was agreed upon in the European Parliament at the last minute, the possibility was created for MS to provide special rules for these data, which in France, for example, consist of obtaining informed consent. Ultimately, this can lead to the same difficulties arising in the future that have burdened this use case: Does the existing consent cover the new use? How broad can consent be? Are there exceptions in national law? How do local ECs interpret existing consent and assess availability? Will they demand to go back to all research participants to obtain re-consent? What if patients have died in the meantime?

The Cancer Genomics Use Case described here made a full attempt and encountered difficulties that need resolution in access, homogenization, and, most importantly, a single, standardized legal/ethical pathway for Europe. Implementing the EHDS could solve these challenges, promising to facilitate equitable access to genomic data while safeguarding individual rights. Nonetheless, it is essential that safeguards for genomic data do not significantly hinder the objective of streamlining access to such data so that any constraints should not obstruct the mechanisms established by the EHDS to facilitate this process. By explicitly linking the challenges identified in our use case with the opportunities presented by the EHDS, we underscore the EHDS transformative potential to streamline genomic data-sharing processes, which will potentially have implications for human health in Europe.

. Comparison of relevant steps and actors for data access in the current project (pre-EHDS) and in the upcoming EHDS (post-EHDS)a

## Section: Contributor Information

Romina Royo, Life Sciences Department, Barcelona Supercomputing Center, Barcelona, Spain.

Eva Garcia, BBMRI-ERIC, Graz, Austria.

Irene Schlünder, BBMRI-ERIC, Graz, Austria; TMF—Technologie- und Methodenplattform für die vernetzte medizinische Forschung e.V., Berlin, Germany.

Christina Hilmarsen, Norwegian Institute of Public Health, Health Data Service, Tynset, Norway.

Mette Kielsholm Thomsen, CONNECT—Center for Clinical and Genomic Data, Aarhus University Hospital, Aarhus N, Central Denmark Region, Denmark; Department of Clinical Epidemiology, Aarhus University Hospital and Aarhus University, Aarhus N, Denmark.

Emilie Cauët, Sciensano Cancer Centre, Brussels, Belgium.

Simon Kok Jensen, CONNECT—Center for Clinical and Genomic Data, Aarhus University Hospital, Aarhus N, Central Denmark Region, Denmark; Department of Clinical Epidemiology, Aarhus University Hospital and Aarhus University, Aarhus N, Denmark.

Simona Giardina, Life Sciences Department, Barcelona Supercomputing Center, Barcelona, Spain.

Aline Hebrant, Sciensano Cancer Centre, Brussels, Belgium.

Gordana Raicevic Toungouz, Sciensano Cancer Centre, Brussels, Belgium.

Marc Van Den Bulcke, Sciensano Cancer Centre, Brussels, Belgium.

Juan Arenas, ELIXIR Hub, Wellcome Genome Campus, Cambridge, United Kingdom.

Christian Fynbo Christiansen, CONNECT—Center for Clinical and Genomic Data, Aarhus University Hospital, Aarhus N, Central Denmark Region, Denmark; Department of Clinical Epidemiology, Aarhus University Hospital and Aarhus University, Aarhus N, Denmark.

Eivind Hovig, Oslo University Hospital, Institute of Cancer Research, Oslo, Norway.

Petr Holub, BBMRI-ERIC, Graz, Austria; Institute of Computer Science, Masaryk University, Brno, Czechia.

Alfonso Valencia, Life Sciences Department, Barcelona Supercomputing Center, Barcelona, Spain; Catalan Institution for Research and Advanced Studies (ICREA), Barcelona, Spain.

Salvador Capella-Gutierrez, Life Sciences Department, Barcelona Supercomputing Center, Barcelona, Spain.

## Section: Author contributions

E.G.-A. and R.R. outlined and wrote the manuscript. A.V., S.C.-G., J.A., and R.R. led the use case and reviewed the manuscript. C.F.C., E.H., M.K.T., S.K.J., E.C., S.G., A.H., C.H., E.H., P.H., E.G.-A., G.R.T., M.V.D.B., prepared the data access requests, wrote the methods, and reviewed the manuscript. I.S. wrote the legal aspects and reviewed the manuscript.

## Section: Supplementary data

Supplementary data are available at EURPUB online.

Conflict of interest: C.F.C, M.K.T, and S.K.J. have no personal conflicts of interest, but are employees at Aarhus University Hospital and Aarhus University, which received research grants from various companies but none in relation to the present publication.

## Section: Funding

This work was co-funded by the European Union under the HealthData@EU Pilot project (GA No 101079839).

## Section: Disclaimer

Views and opinions expressed are however those of the author(s) only and do not necessarily reflect those of the European Union or HaDEA. Neither the European Union nor the granting authority can be held responsible for them.


---

# Geometry-based BERT: An experimentally validated deep learning model for molecular property prediction in drug discovery

- **Authors:** Xiang Zhang, Chenliang Qian, Bochao Yang, Hongwei Jin, Song Wu, Jie Xia, Fan Yang, Liangren Zhang
- **Issuer:** Journal of pharmaceutical analysis
- **Type:** Scientific article
- **Published:** 2025-10-09
- **Language:** en
- **DOI:** 10.1016/j.jpha.2025.101465
- **Source:** https://pubmed.ncbi.nlm.nih.gov/41446890/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractVarious deep learning based methods have significantly impacted the realm of drug discovery. The development of deep learning methods for identifying novel structural types of active compounds has become an urgent challenge. In this paper, we introduce a self-supervised representation learning framework, i.e., Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT). GEO-BERT considers the information of atoms and chemical bonds in chemical structures as the input, and integrates the positional information of the three-dimensional conformation of the molecule for training. Specifically, GEO-BERT enhances its ability to characterize molecular structures by introducing three different positional relationships: atom-atom, bond-bond, and atom-bond. By benchmarking study, GEO-BERT has demonstrated optimal performance on multiple benchmarks. We also performed prospective study to validate the GEO-BERT model, with screening for DYRK1A inhibitors as a case. Two potent and novel DYRK1A inhibitors (IC50: <1 μM) were ultimately discovered. Taken together, we have developed an open-source GEO-BERT model for molecular property prediction (https://github.com/drug-designer/GEO-BERT) and proved its practical utility in early-stage drug discovery.Keywords: Drug discovery, Chemical pre-trained model, Self-supervised learning, BERT, DYRK1A inhibitor

## Section: Introduction

In the history of drug discovery, pharmaceutical scientists often apply high-throughput screening to identify hit compounds [1]. However, it is well known that this technique is time-consuming and thus may significantly impede new drug discovery [2]. With technical advances, virtual screening has become an indispensable strategy to accelerate new drug research and development, as it is able to identify novel hits efficiently in a short period of time. As for virtual screening, normally a computational model is established and then used to filter a large-scale chemical library so as to select potentially active compounds from the library, and eventually discover truly active compounds through experiments [3]. As one of the aforementioned computational models, molecular property prediction based on machine learning has been widely used for virtual screening and drug discovery [4].

Featurization of molecules is an essential step of machine learning-based molecular property prediction. It is conventionally achieved by the calculation of molecular fingerprints (e.g. Extended Connectivity Fingerprints [5], and Molecular ACCess System (MACCS) [6]), or descriptors (e.g. structural descriptors, and physicochemical property descriptors [7]). However, due to the fact that the featurization rules of molecular fingerprints and descriptors are based on human experience, these methods often have the following drawbacks: (1) Feature engineering requires manual design of molecular fingerprints/descriptors, relying on the knowledge and experience of experts [8]. (2) Different molecular fingerprints or descriptors in machine learning can bring about different performance, making it difficult to find the most suitable molecular fingerprints/descriptors for each machine learning algorithm [9]. These drawbacks have been acknowledged by the community, and some solutions were proposed, e.g., multimodal representation learning frameworks [10].

With the emergence of deep learning, new algorithms that do not require feature engineering have been developed, including Recurrent Neural Network (RNN), and Convolutional Neural Network. These algorithms directly learn from end to end and train models based on the original molecular representations. It has been proved highly effective in handling diverse molecules [11]. According to the format of molecular representations, corresponding deep learning algorithms can be chosen and leveraged. For instance, the Simplified Molecular Input Line Entry System (SMILES) string representation of molecules are applicable as input of the algorithms such as RNN and Transformer [12]. The graph representations of molecules are suitable for Graph Neural Networks (GNN) [13]. GNN models usually employ message passing mechanism, enabling each node of the graph to aggregate information from its neighboring nodes. Each node can be additionally represented by the properties such as atomic type and charge. However, these supervised deep learning methods are faced with insufficient generalization, due to the limited data with labels [14].

Natural language processing provides an effective way to address the aforementioned issues. In recent years, Bidirectional Encoder Representations from Transformers (BERT) [15] models attracted much attention in the field of molecular property prediction. By using its masking strategy and bidirectional attention, BERT models could achieve excellent generalization performance. BERT model building includes extensive pre-training with large-scale unlabeled data and subsequent fine-tuning with a relatively small dataset. Several kinds of BERT models for property prediction have been developed. For instance, Wu et al. [16] developed Knowledge-based BERT (K-BERT) pre-trained with three different tasks, predicting properties of individual atom, forecasting overall fingerprints of molecule, and comparing various forms of SMILES representations, thus establishing a comprehensive molecular property prediction framework. The average area under curve (AUC) of K-BERT is 0.806 (test set), evaluated on 15 drug discovery-related datasets. The outcome from the ablation experiments of three pre-training tasks has demonstrated that the pre-training could boost the performance of downstream tasks. Xia et al. [17] developed Mole-BERT that refines the representation of each atom by avoiding simple representations of atomic types. It encodes each atom by its surrounding environment and construct a novel vocabulary, which significantly expands the lexicon and mitigates issues stemming from extreme imbalance of atomic types. Moreover, it employs two distinct masking rates during masking, forming a triplet along with the original molecule and training the model through contrastive learning. Mole-BERT achieves good performance with an average AUC of 0.740 (test set), evaluated on 8 binary classification tasks. Liu et al. [18] developed MolRoPE-BERT, a BERT model with molecular rotary position embedding. By incorporating the rotary position embedding, positional information of SMILES sequences can be efficiently encoded, thus enhancing the BERT pre-trained model's capability to extract potential molecular substructure information for predicting molecular properties. In order to highlight the impact of frequently occurring substructures on molecular property, Li et al. [19] developed Functional-Group BERT (FG-BERT), thus converting the task from predicting individual atoms to predicting substructures. It has been validated that FG-BERT performs better than Mole-BERT on 8 binary classification tasks (average AUC: 0.7492 for FG-BERT vs. 0.7404 for Mole-BERT), and 4 regression tasks (average root mean square error (RMSE): 0.927 for FG-BERT vs. 0.999 for Mole-BERT). In order to further validate the performance of the FG-BERT model, experiments with 15 Absorption, Distribution, Metabolism, Excretion, and Toxicity (ADMET) datasets and 14 breast cancer cell-based phenotypical screening datasets were performed, and the outcome was pretty good, with the average AUC values of 0.813 and 0.856, respectively.

To the best of our knowledge, all the above mentioned models only take the information of molecular two-dimensional structure. In fact, a molecule generates bioactivity by binding to its target and thus its three-dimensional conformation is considered more important [20]. We hypothesized that the incorporation of spatial information such as bond length and bond angle into the BERT model may further improve model performance [21]. Based on this idea, we developed a molecular property prediction model by incorporating bond length and bond angle attention into the commonly used individual atoms. Through constructing three distinct connection relationships, i.e., atom-atom, atom-bond, and bond-bond, we were able to incorporate the overall topological structure of a molecule into the model so as to enhance attention mechanism in the Transformer architecture. During the attention calculation, we introduced two types of positional information, i.e., bond length, and bond angle. It enables the model to focus on three-dimensional conformation of a molecule during training. To validate its effectiveness, we carried out benchmarking study with 8 public datasets and compared the results with the previously reported state-of-the-art models. Our model, Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT), demonstrates superior performance for most datasets. Furthermore, we applied GEO-BERT model to real-world bioactivity prediction and drug screening, with dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)-targeted drug discovery as a case study. Top 500 compounds predicted to be active for DYRK1A by the GEO-BERT model were further filtered by classical computer-aided drug design strategy including molecular docking, and 20 potential hits were tested for their DYRK1A inhibitory activity. The identification of two novel and potent DYRK1A inhibitors validated the practical applicability of the GEO-BERT model.

## Section: Materials and methods

The framework of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT). (A) Schematic diagram of pre-training and fine-tuning in the GEO-BERT model. (B) Visualization of adjacency matrices of all atoms and chemical bonds of a molecule during pre-training. According to the connection relationship between atoms and/or chemical bonds of molecules, five types of attention mechanism were defined. (C) Visualization of GEO-BERT's spatial position matrix, including atom distance matrix, bond angle matrix, atom-bond adjacency matrix, and the calculation of attention in Transformer.

Color code: (1) Atom distance: Different colors indicate different distances between atoms, while white indicates no chemical bond between two atoms. Atom distances are symmetrically distributed along the diagonal of the matrix. (2) Bond angle: Different colors indicate different angles between chemical bonds, while blanks indicate that there is no common atom at the ends of the two bonds. Bond angles are symmetrically distributed along the diagonal of the matrix. (3) Atom-bond adjacency: Colors indicate the connection between an atom and a bond, while blanks indicate that atoms and bonds are not connected.

## Section: Materials and methods › Data collection and curation

Firstly, approximately 2.13 million molecules were obtained from ChEMBL (version 30) [22]. Like FG-BERT, molecules were selected according to three rules regarding drug-like properties, i.e., molecular weight ≤500, ClogP ≤5 and number of hydrogen bond donors ≤5. The low-energy conformation was generated for each molecule using RDKit (version 2023.03). The low-energy conformation was chosen because it is typically the most stable form of a molecule, providing a consistent and representative structural information for our model. Additionally, focusing on a single conformation helps to reduce computational complexity and makes the analysis more tractable. Since conformers were not successfully generated for approximately 2000 molecules (mol.GetNumConformers() = 0), these molecules were removed from the data set. This step ensured that all remaining molecules had valid conformations for subsequent analysis. Once the conformations were obtained, the bond length and bond angle of each molecule were calculated based on the atom coordinates of each conformation, using functions implemented in RDKit (i.e., rdkit.Chem.AllChem.EmbedMolecule(mol) and mol.GetConformer().GetPositions()).

As a result, a total of 1,454,105 molecules were obtained. They were divided into a training set and a test set at a ratio of 9:1 and ready to use for pre-training. Eight benchmarks were accessed online and used for transfer learning and comparative analysis, i.e., Tox21, ToxCast, Sider, ClinTox, MUV, HIV, BBBP, and Bace [23]. More details about the datasets can be found in Table S1.

For the prospective study (i.e. real-world target-based drug discovery practice), the DYRK1A-Dataset that we previously compiled (https://github.com/jwxia2014/DYRK1A-Dataset) was used. It contained 927 molecules collected from ChEMBL and labeled with IC50 values. This data set was curated according to the following protocol. Following salt removal and standardization, any molecule with more than 20 rotatable bonds and molecular weight greater than 600 was eliminated. The IC50 values obtained from multiple bioassays were averaged. The molecules with IC50 values below 1 μM were labeled as inhibitors (430), while the others were defined as non-inhibitors (497). This dataset had been randomly divided into two sets at a ratio of 8:2, with data size of the train set (“DYRK1A-train” set) as 742 and that of the test set (“DYRK1A-test” set) as 185.

## Section: Materials and methods › The building of GEO-BERT model

The framework of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT). (A) Schematic diagram of pre-training and fine-tuning in the GEO-BERT model. (B) Visualization of adjacency matrices of all atoms and chemical bonds of a molecule during pre-training. According to the connection relationship between atoms and/or chemical bonds of molecules, five types of attention mechanism were defined. (C) Visualization of GEO-BERT's spatial position matrix, including atom distance matrix, bond angle matrix, atom-bond adjacency matrix, and the calculation of attention in Transformer.

Color code: (1) Atom distance: Different colors indicate different distances between atoms, while white indicates no chemical bond between two atoms. Atom distances are symmetrically distributed along the diagonal of the matrix. (2) Bond angle: Different colors indicate different angles between chemical bonds, while blanks indicate that there is no common atom at the ends of the two bonds. Bond angles are symmetrically distributed along the diagonal of the matrix. (3) Atom-bond adjacency: Colors indicate the connection between an atom and a bond, while blanks indicate that atoms and bonds are not connected.

## Section: Materials and methods › The building of GEO-BERT model › The GEO-BERT framework

In GEO-BERT, the bond was regarded as an independent token, rather than solely as a channel for information transmission between atoms. As Fig. 1A shows, in the stage of pre-training, several atoms and bonds of the molecule were masked. In this way of pre-training, the model learns connectivity between atoms, between bonds as well as between atom and bond.

In fine-tuning, the pre-trained Global token was extracted and a prediction layer was incorporated to execute the molecular property prediction task. As the attention matrix in Fig. 1B shows, by leveraging connectivity between atoms, and between atom and bond, as well as between bonds of a molecule, three types of attentions were defined. For all the atoms, attention was exclusively calculated between two atoms linked by a bond. For all the bonds, attention was solely computed between bonds that shared an atom at either end. Likewise, attention was only computed between a bond and each of two atoms on both ends of the bond. With such a definition for connectivity, information was efficiently extracted from the connection between atoms and bonds.

In addition, to calculate spatial position information of a molecule, three additional matrices were incorporated into each attention matrix, as illustrated in Fig. 1C. (1) For the atom-atom attention matrix, an Atom Distance matrix was incorporated. It is noted that position information was calculated only for adjacent atoms; for the other atoms, position information was set to 0. (2) For the bond-bond attention matrix, a bond angle matrix was incorporated. Similar to atom distance matrix, bond angle matrix was only calculated between those connected bonds; otherwise, the value in the matrix was set to 0. (3) In the atom-bond attention matrix, as there was no positional information, an atom-bond adjacency matrix was added to balance the above matrices. The attention between atoms was affected by distance, i.e., functional relationship between two atoms at different distances varies, aligning with chemical intuition. Similarly, the attention between bonds was affected by angle, i.e., functional relationship between two bonds at different angles varies.

To clarify the aforementioned design, the spatial position matrix derived from an exemplified molecule of ethanol is shown in Fig. S1. In this figure, it is noted that all the atoms are arranged at the front of the sequence and the bonds at the rear in the figure. In the atom-atom matrix located at the upper left corner, the diagonal entries represent individual atoms. Among the interconnected atoms of the ethanol molecule, the longest distance was observed between the oxygen and one hydrogen atom, while five pairs of C-H atomic distances were equal. Adjacent to C–O (1.4 Å), the shortest distance is between two carbon atoms, i.e., 1.3 Å. For the atom-bond matrix, each bond linked two atoms at both ends, with a maximum of four bonds connecting to carbon atom (C) and only one bond connecting to hydrogen atom (H). In the bond-bond matrix, the angles formed by three bond pairs, C–O–H, C–C–H, and O–C–H, were slightly greater than the angles formed by the other bonds of the molecule.

In terms of model implementation, the aforementioned three matrices were integrated into the calculation of attention in the Transformer. These matrices were shared by each layer in Transformer, which enabled the model to focus not only on semantic relationship between atoms or bonds, but also on spatial information of the molecule in every attention calculation.

For the ablation experiment in Section 4.2, to explore the role of different components considered in GEO-BERT, we designed three other different models named as GEO-BERT [a], GEO-BERT [b] and GEO-BERT [c]. The model GEO-BERT [a] omits the atom distance matrix and bond angle matrix. The model GEO-BERT [b] incorporates the atom distance matrix and bond angle matrix, by first multiplying each of them by a learnable parameter and then adding them to the original attention matrix. These learnable parameters are shared across all the layers of GEO-BERT. The model GEO-BERT [c] employs two special tokens (GLOBAL-ATOM and GLOBAL-BOND) to focus on the atoms and bonds of a molecule respectively, and subsequently concatenates the resulting vectors during fine-tuning. The structural diagrams of GEO-BERT [a], GEO-BERT [b] and GEO-BERT [c] are listed in Figs. S2–S4.

The framework of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT). (A) Schematic diagram of pre-training and fine-tuning in the GEO-BERT model. (B) Visualization of adjacency matrices of all atoms and chemical bonds of a molecule during pre-training. According to the connection relationship between atoms and/or chemical bonds of molecules, five types of attention mechanism were defined. (C) Visualization of GEO-BERT's spatial position matrix, including atom distance matrix, bond angle matrix, atom-bond adjacency matrix, and the calculation of attention in Transformer.

Color code: (1) Atom distance: Different colors indicate different distances between atoms, while white indicates no chemical bond between two atoms. Atom distances are symmetrically distributed along the diagonal of the matrix. (2) Bond angle: Different colors indicate different angles between chemical bonds, while blanks indicate that there is no common atom at the ends of the two bonds. Bond angles are symmetrically distributed along the diagonal of the matrix. (3) Atom-bond adjacency: Colors indicate the connection between an atom and a bond, while blanks indicate that atoms and bonds are not connected.

## Section: Materials and methods › The building of GEO-BERT model › The principle of GEO-BERT

The input of the model was a list composed of all the atoms and bonds of a molecule. All the atoms were listed at the front, while the bonds were listed behind them, which can be represented as input=(a1,a2,…,aM,b1,b2,…,bN). M represents the number of atoms, and N represents the number of bonds. Taking a formaldehyde molecule (CH2O) as an example, the input can be represented as ([C], [O], [H], [H], [double], [single], [single]).

Based on an embedding matrix D∈Rn×dim, the atom and bond vectors in the embedding space were obtained. In the embedding matrix, n is the size of the vocabulary composed of all the atoms and bonds existing in all chemical compounds, dim is the embedding dimension of each vocabulary, and the input vector is represented as X=(v1,v2,…,vM,e1,e2,…,eN). The input vector of a formaldehyde molecule can be represented as (v[C], v[O], v[H], v[H], e[double], e[single], e[single]).

This process is recorded as formula 1,

The attention layer of the model contains three matrices Q, K, and V, which are calculated by (2), (3), (4), (5),

WQ,WK,WV∈Rdk×dm,dk=dim/H, H is the number of heads with multi-head attention. After Q and K are obtained, the attention A can be calculated.

For any adjacent atom i and atom j of a molecule, the actual distance between them can be represented using the following formula 6,

For any adjacent bond p and bond q of a molecule, the bond angle can be represented using the following formula 7,

For atom i and bond p or atom j and bond q in a molecule, the following formula 8 can be obtained based on whether they are connected in the molecule.

After the above four matrices av,ae,av,e,ae,v were obtained, the spatial matrix Aspace was constructed (formula 9). The size of the matrix is [M+N,M+N], and then it is added to the original attention matrix A to obtain a new matrix A∗ (formula 10). Lastly, the output is calculated by activation function softmax() and then multiplied by V to obtain the output value (formula 11).

In order to avoid gradient vanishing during calculation, a residual connection was added to the model after each attention calculation in each layer, and then a layernorm (LN) layer was added for layer normalization. The formula is as follows,

Where X(l−1) represents the intermediate vector of layer l−1, and X′(l−1) represents the intermediate vector obtained through LN in layer l−1.

In order to increase the complexity of each molecule representation, the feed forward layer (FFN) was added as well. Residual connections were also added during the calculation, and then the LN layer was normalized. The formula is as follows:

Among them, X(l) represents the output vector of the l−1 layer obtained through FFN and LN layers, and serves as the input vector of the l layer. The above process fully represents the calculation process of one layer in the Transformer. In our model, a total of six modules (l = 6) was used.

## Section: Materials and methods › Pre-training and fine-tuning of GEO-BERT

Following FG-BERT [19], 14 common atoms, i.e., H, C, N, O, S, F, Cl, Br, P, I, Na, B, Se and Si were defined in molecular vocabulary of GEO-BERT. Rare atoms, e.g., Pb and Hg, were represented as [UNK]. To denote all bonds of a molecule, four symbols (i.e., single, double, triple, and benzene) were defined in GEO-BERT. It should be noted that double bonds of benzene and carbon chains were represented individually due to their different physicochemical properties. Lastly, for masked atoms or bonds, [MASK] was introduced. [GLOBAL] was used to gather features from all atoms and bonds in model training. Taken together, the molecular vocabulary defined in GEO-BERT included [H], [C], [N], [O], [S], [F], [Cl], [Br], [P], [I], [Na], [B], [Se], [Si], [UNK], [single], [double], [triple], [benzene], [MASK], and [GLOBAL].

A masking strategy was applied to atoms and bonds during pre-training. All the atoms and bonds were extracted from a molecule and 15% of them were selected. Due to the specific patterns in chemistry, substitution operation was not introduced. Among the selected atoms and bonds, 90% were masked and 10 % were unchanged.

1,454,105 molecules from ChEMBL (version 30) were divided into a training set and a test set at a ratio of 9:1. SMILES string representations were converted to molecular graph by RDKit (version 2023.03). For each undirected graph, a global node labeled as Global was introduced, which was connected to all the atoms and bonds of a molecule. During model training, cross-entropy loss was computed respectively for masked atoms and bonds and then aggregated for backpropagation. With a batch gradient-descent algorithm, Adam was used as the optimizer, and the learning rate was set to 1 × 10−4.

For the public benchmarks, molecules from Tox21, ToxCast, Sider, ClinTox, MUV, HIV, BBBP, and Bace were respectively divided into a training, a validation, and a test set at a ratio of 8:1:1. The uniform segmentation method was applied for the partition. This method was previously adopted by FG-BERT [19], and focused on molecular scaffolds. To be specific, this method involves grouping molecules into distinct clusters based on their scaffolds.

During the fine-tuning stage, the network layer utilized by the model head for recuperating the masked segment in pre-training step was removed, while a new prediction head composed of two fully-connected layers was incorporated for downstream tasks. The hyperparameter optimization method and value range were consistent with those adopted by FG-BERT, which was aimed to ensure a fair comparison with FG-BERT. The optimization algorithm was Tree-structured Parzen Estimator (TPE), implemented as the “fmin” function from the Hyperopt library. The value of learning rate was drawn from a log-uniform distribution [3 × 10−5, 15 × 10−5]. The batch size was selected from [16, 32, 48, 64]. The dropout rate ranged from 0 to 0.5, with an interval of 0.05. The number of training epochs was set to 200, with a maximum endurance epoch of 30. If accuracy based on the validation set did not improve within 30 epochs, model training would be stopped.

## Section: Materials and methods › Model evaluation

For model evaluation, seven metrics were used and defined as formulas (14), (15), (16), (17), (18), (19), (20).

True positive (TP) represents the number of correctly identified active compounds. True negative (TN) indicates the number of correctly identified inactive compounds. False positive (FP) denotes the number of incorrectly identified inactive compounds. False negative (FN) signifies the number of incorrectly identified active compounds. Based on the aforementioned metrics, more comprehensive metrics such as accuracy, precision, recall, AUC (widely used as a performance measure in virtual screening tasks), Matthew's correlation coefficient (MCC, also called Pearson's Phi), F1-score, and specificity (SP) could be calculated for model evaluation.

The sum of ranking differences (SRD) [24] metric provides a robust and intuitive quantitative approach for comparing overall performance of various models across multiple evaluation datasets. This method transforms the prediction outcome of each model into a ranking matrix and computes cumulative ranking deviations by comparing them to a predefined reference ranking, such as the average performance. The SRD value for each method is calculated as follows:

where xij denotes the prediction outcome of the j-th method on the i-th dataset, and ri is the corresponding reference rank. A lower SRD value indicates a closer alignment with the reference, reflecting greater consistency and superior performance. SRD offers cross-model and cross-dataset comparability, making it particularly suitable to measure reliability and agreement of different methods across various molecular properties. This metric has been widely adopted in Cheminformatics for comparative analysis of modeling techniques (https://github.com/davidbajusz/srdpy).

## Section: Materials and methods › Practical application: DYRK1A inhibitors discovery

As a proof-of-concept, our GEO-BERT model was fine-tuned for DYRK1A and applied to discovering DYRK1A inhibitors. DYRK1A plays a crucial role in many physiological processes and can phosphorylate various protein substrates [25]. The overexpression of DYRK1A may lead to many diseases such as neurodegenerative diseases, diabetes and cancers. Although many DYRK1A inhibitors have been identified, no drug targeting DYRK1A is approved for clinical use. The discovery of novel DYRK1A inhibitors is still necessary, from the perspective of DYRK1A-related diseases treatment.

## Section: Materials and methods › Practical application: DYRK1A inhibitors discovery › Fine-tuning GEO-BERT model for DYRK1A inhibitory activity prediction

For the DYRK1A dataset, the previously divided “DYRK1A-test” set was still used as the test set (20% of 927 molecules), while the “DYRK1A-train” set was further randomly divided into a smaller train set (60% of 927 molecules) and a validation set (20% of 927 molecules). Fine-tuning was carried out with the train set and evaluated with the validation set and the test set. The weights of the model were saved for subsequent evaluation and compound library screening. The test set was used to evaluate the performance of the model with different random seeds, i.e., [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], using the average and variance of all experiments as evaluation metrics. The evaluation metrics included AUC, MCC, accuracy, precision, recall, F1-score, and SP.

## Section: Materials and methods › Practical application: DYRK1A inhibitors discovery › t-distributed stochastic neighbor embedding (t-SNE) analysis for interpretability of GEO-BERT(DYRK1A)

All the 927 molecules from the DYRK1A dataset were used to analyze the interpretability of the GEO-BERT(DYRK1A) model. The molecules comprised approximately 23,000 atoms and 41,000 bonds and were fed into the GEO-BERT(DYRK1A) model. Consequently, 23,000 atomic vectors and 41,000 bond vectors were generated from the transformer layer. These vectors were then visualized with the t-SNE analysis [26], a commonly used method to visualize high-dimensional molecular features.

## Section: Materials and methods › Practical application: DYRK1A inhibitors discovery › Uncertainty assessment of GEO-BERT(DYRK1A)

Three methods, including entropy, dropout, and their ensemble were used to measure uncertainty of the GEO-BERT(DYRK1A) model [27]. As for the entropy method, the uncertainty value was calculated by multiplying the model's prediction probability for each class with the corresponding logarithmic value. As for the dropout method, the dropout operation was adopted, which led to different outcomes during model prediction. Based on the outcomes, the variance was calculated to measure uncertainty. The ensemble method means the averaging of entropy and dropout. GEO-BERT(DYRK1A) model was trained based on the “DYRK1A_train” dataset (including the aforementioned smaller train set and a validation set in Section 2.5.1), while uncertainty was calculated based on the “DYRK1A_test” dataset.

## Section: Materials and methods › Practical application: DYRK1A inhibitors discovery › The use of GEO-BERT(DYRK1A) to facilitate virtual screening

After fine-tuning and model evaluation, the GEO-BERT(DYRK1A) model was used for screening the Specs chemical library (∼2,100,000), and the top 500 compounds were selected based on their activity probability predicted by the model. The compounds were then docked against DYRK1A (PDB code: 7AJ2) [25] that were determined by our group as the structure with the highest ligand enrichment for FRED docking-based virtual screening. Specifically, a maximum of 200 conformations for each compound were generated using OMEGA, and placed into the binding site, evaluated for binding affinity by the Chemgauss4 scoring function, and visually examined for binding modes. Only the compounds that may form hydrogen bonds with LEU241 or LYS188 were retained. PAINS-Remover (https://www.cbligand.org/PAINS/) was used to filter the pan assay interference compounds (PAINS) [28]. Lastly, structural clustering based on FCFP_6 fingerprints was carried out with the “Cluster Ligands” module of Discovery Studio (v16.1.0, Dassault Systèmes Biovia Corp.). One or two compounds from each cluster were selected, with priority given to those with better Chemgauss4 scores as well as experts-based synthetic feasibility.

## Section: Materials and methods › Practical application: DYRK1A inhibitors discovery › DYRK1A inhibition assay

The assay was performed in 384-well plates using the ADP-Glo Kinase Assay Kit (Cat.# V6930, Promega, Madison, WI, USA). To be specific, this assay measured kinase activity by quantifying the amount of ADP produced during the kinase reaction. The kinase reaction between the kinase and its substrate was performed in an assay buffer consisting of Hepes, MgCl2, Brij35, EGTA, and DTT. Briefly, ATP and the kinase substrate were added to the solution of compounds, the kinase and metal ions to initiate the reaction. The reaction was terminated by the addition of ADP-Glo kinase reagent followed by the addition of kinase detection reagent. The mixture was incubated at 25 °C. The luminescence was recorded on a microplate reader. Based on the luminescence, the activity values (%) of the DYRK1A protein at different concentrations of compounds were determined. GraphPad Prism (GraphPad Software Inc.) was used to determine IC50.

## Section: Results

Classification performance (AUC) of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT) evaluated based on eight commonly used public datasets.

Comparison of models in terms of sum of ranking differences (SRD) values. 16 models are ranked by SRD values in the ascending order. The left vertical axis displays SRD. The black line displays the cumulative relative frequency of SRD. The red dashed line indicates the performance threshold. The vertical red lines (XX1, Med, XX19) mark the 1st percentile, median, and 99th percentile of the SRD distribution.

Classification performance of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)), evaluated on the DYRK1A dataset.

Interpretability analysis of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)). (A) Visualization of t-distributed stochastic neighbor embedding (t-SNE) for embedding vectors of different atom types. (B) Visualization of t-SNE for embedding vectors of different bond types. (C) Visualization of t-SNE for embedding vectors of different atomic clusters. (D) Visualization of the attention of representative molecules of the DYRK1A dataset, with darker colors indicating greater attention.

Interpretability of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT) in the form of substructures, with active and inactive molecules from the “DYRK1A-train” set or the “DYRK1A-test” dataset as a demonstration. DYRK1A: dual-specificity tyrosine phosphorylation-regulated kinase 1A.

Uncertainty analysis of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)), based on three uncertainty metrics and the “DYRK1A-test” dataset. (A) The variation of Matthews correlation coefficient (MCC) in GEO-BERT(DYRK1A) when the uncertainty value changes, where the uncertainty values are calculated by entropy, dropout, and ensemble methods, respectively. (B) The distribution of various types of samples (true positive (TP), true negative (TN), false positive (FP), and false negative (FN)) predicted by GEO-BERT(DYRK1A) within different uncertainty intervals based on the Ensemble method. The horizontal axis represents the uncertainty interval, and the vertical axis represents the total number of samples (blue dashed line) and the respective percentage of samples (TP, TN, FP, and FN; histogram) within each uncertainty interval. MC-dropout: Monte Carlo dropout.

Two potent dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A) inhibitors identified by virtual screening facilitated by Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(DYRK1A). (A) The chemical structures and DYRK1A inhibitory activity of hit compound, X11 and the plausible binding modes of the hits to DYRK1A. (B) The chemical structures and DYRK1A inhibitory activity of hit compound X17 and the plausible binding modes of the hits to DYRK1A.

The chemical space of four types of samples (true positive (TP), true negative (TN), false positive (FP), and false negative (FN)) from the “DYRK1A-test” dataset. Visualization of chemical space is based on the t-distributed stochastic neighbor embedding (t-SNE) method, where points of different colors represent four types of samples, and the size of the points represents the uncertainty value of each sample, calculated by the ensemble method. Two validated hit compounds X11 and X17 are marked in the feature space.

## Section: Results › Benchmarking outcome of GEO-BERT on public datasets

Firstly, we compared classification performance of models in the way adopted by many high-impact work in cheminformatics, i.e., the way of comparison based on individual AUC and average AUC value. As shown in Table 1, the GEO-BERT model performed the best, with the highest average AUC value (0.751). This indicates a 0.67% improvement over the suboptimal FG-BERT model. To be specific, the GEO-BERT model performed better than all the previously reported models across 5 out of 8 public datasets, i.e., ToxCast (AUC: 0.646), ClinTox (AUC: 0.837), Sider (AUC: 0.645), HIV (AUC: 0.783), and Bace (AUC: 0.846). For two public datasets, Tox21 and MUV, the GEO-BERT model ranked at the 3rd and 2nd place, respectively.

Secondly, we evaluated different models using the metric of SRD [29], with the mean (AUC) of each model as input. As illustrated in Fig. 2, all the models are sorted by SRD values in an ascending order. The conventional Graph Pre-Training with Graph Neural Networks (GPT-GNN) model yielded the highest SRD values (13.95%), while all the BERT-based models showed much lower SRD values (<3%). GEO-BERT achieved the lowest SRD (1.1%), demonstrating superior performance compared to other models, including two BERT-based models (Mole-BERT): 1.7%, FG-BERT: 2.8%). It indicates the importance of geometry information used for model training. Since standard deviation may also have an effect on SRD, we then calculated the new SRD value of each method by the weighted summation of the original SRD values from both the “mean” and the “standard deviation”. According to the model rankings based on SRD analysis with different weights assigned (Table S2), GEO-BERT always ranked at the first or second place.

Though two ways of model comparison (i.e., direct comparison of average AUC and SRD analysis) did not contribute to exactly the same outcome, our GEO-BERT model was consistently ranked among the top.

Classification performance (AUC) of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT) evaluated based on eight commonly used public datasets.

Comparison of models in terms of sum of ranking differences (SRD) values. 16 models are ranked by SRD values in the ascending order. The left vertical axis displays SRD. The black line displays the cumulative relative frequency of SRD. The red dashed line indicates the performance threshold. The vertical red lines (XX1, Med, XX19) mark the 1st percentile, median, and 99th percentile of the SRD distribution.

## Section: Results › Performance of GEO-BERT for DYRK1A inhibitory activity prediction

We built the GEO-BERT model for DYRK1A by transfer learning with the pre-trained GEO-BERT model and the DYRK1A-dataset. Firstly, the weights of the pre-trained GEO-BERT model based on 1,454,105 molecules from ChEMBL were saved, and then the DYRK1A-dataset was used to fine-tune the model. The classification performance of GEO-BERT(DYRK1A) is shown in Table 2. It achieved good performance with AUC being 0.875 and MCC being 0.610.

To explore whether GEO-BERT(DYRK1A) had advantages, we built models with five classical machine learning algorithms, i.e., random forest (RF), support vector machine (SVM), extreme gradient boosting (XGBoost), K-nearest neighbors (KNN), and deep neural network (DNN), and the classical fingerprints, i.e., MACCS to represent molecules. In addition, we trained models with a well-known supervised deep learning approach, Chemprop [30] and other two BERT models, MG-BERT [31] and FG-BERT [19].

The data sets used for training and evaluating the nine models mentioned above remained consistent with those for GEO-BERT(DYRK1A) (cf. Section 2.5.1). Among all the nine models, GEO-BERT(DYRK1A) showed the best performance. Table 2 reveals that only FG-BERT and our GEO-BERT had AUC over 0.85, which were much greater than the classical machine learning models as well as the graph-based model, Chemprop. In addition, only our GEO-BERT model had MCC exceeding 0.6. The data indicated that GEO-BERT is the best model for DYRK1A inhibitory activity prediction.

Classification performance of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)), evaluated on the DYRK1A dataset.

## Section: Results › Interpretability of GEO-BERT(DYRK1A) based on t-SNE analysis

927 molecules from the DYRK1A dataset comprised approximately 23,000 atoms and 41,000 bonds. These data were fed into the GEO-BERT(DYRK1A) model. As a result, 23,000 atomic vectors and 41,000 bond vectors were generated from the transformer layer. These vectors were then visualized with the t-SNE method [26]. Notably, the majority of atoms are carbon atoms, and the most prevalent types of chemical bonds are single and aromatic bonds, with almost no triple bond. As Figs. 3A and B show, in terms of atoms and chemical bonds, GEO-BERT(DYRK1A) performed well at distinguishing various types of feature information.

In the t-SNE representation of atoms, we observed significant distribution discrepancies even for the atoms of the same type. Consequently, leveraging the surrounding atom information of each atom, we further segmented them into distinct functional groups, reevaluating model performance through t-SNE analysis. Fig. 3C illustrates the model's robustness at identifying different atomic clusters, with consistent aggregation observed among the identical functional groups of different molecules. The identification of highly frequent functional groups by the GEO-BERT(DYRK1A) model might be useful for future molecular design. Furthermore, we selected two representative active and two inactive molecules from the DYRK1A dataset and visualized their attention in the attention head of GEO-BERT(DYRK1A), as depicted in Fig. 3D.

Substructures are more preferred information than atoms for drug design. To this end, we presented the substructure-level interpretability. Firstly, we defined the substructures used for interpretability analysis (Table S3). Then, we calculated attention of each substructure by summing up the attention of the atoms it contained. As shown in Fig. 4, we identified four functional groups with distinct distributions in DYRK1A active and inactive molecules. The ‘∗ = O’ (including ‘∗C(O)=O’, ‘∗C(N)=O’) and ‘∗N’ (including ‘∗#N’, ‘∗C#N’) functional groups frequently appear in DYRK1A active molecules, suggesting their crucial role in molecular activity. Conversely, the ‘∗Cl’ and ‘∗F’ functional groups were primarily found in DYRK1A inactive molecules, indicating their potential association with molecular inactivity. This observation was consistent with the physical principle that both ‘∗ = O’ groups and ‘∗N’ groups may form hydrogen bonds with amino acid residues of the protein while the ‘∗Cl’ and ‘∗F’ groups could not. These findings provide valuable insights into molecular features of DYRK1A active molecules, which may facilitate future molecular design and optimization.

Interpretability analysis of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)). (A) Visualization of t-distributed stochastic neighbor embedding (t-SNE) for embedding vectors of different atom types. (B) Visualization of t-SNE for embedding vectors of different bond types. (C) Visualization of t-SNE for embedding vectors of different atomic clusters. (D) Visualization of the attention of representative molecules of the DYRK1A dataset, with darker colors indicating greater attention.

Interpretability of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT) in the form of substructures, with active and inactive molecules from the “DYRK1A-train” set or the “DYRK1A-test” dataset as a demonstration. DYRK1A: dual-specificity tyrosine phosphorylation-regulated kinase 1A.

## Section: Results › Uncertainty of GEO-BERT(DYRK1A)

As shown in Fig. 5A, we sequentially removed the samples of high uncertainty ranking at the top 10% of the “DYRK1A_test” dataset and calculated MCC for the remaining data. As the uncertainty index decreased, the model performance improved. Although there was a significant decrease in MCC when the uncertainty decreased from 0.3 to 0.2, the value of MCC still remained around 0.5. The MCC based on other uncertainty metrics is shown in Fig. S5. As shown in Fig. 5B, (1) the distribution of four types of samples (TP, TN, FP, and FN) varied along with different uncertainty values. To be specific, as the uncertainty value increased, the number and proportion of FP and FN also increased. It indicates the prediction accuracy of GEO-BERT(DYRK1A) decreased with the increase of uncertainty. Nevertheless, GEO-BERT(DYRK1A) predicted accurately when the uncertainty value was low. (2) Most samples in the “DYRK1A_test” data set were distributed in the areas with moderate uncertainty values (0.4–0.6), and there were a considerable proportion of samples when the uncertainty value is 0. The result based on other uncertainty metrics can be seen in Fig. S6.

Uncertainty analysis of Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)), based on three uncertainty metrics and the “DYRK1A-test” dataset. (A) The variation of Matthews correlation coefficient (MCC) in GEO-BERT(DYRK1A) when the uncertainty value changes, where the uncertainty values are calculated by entropy, dropout, and ensemble methods, respectively. (B) The distribution of various types of samples (true positive (TP), true negative (TN), false positive (FP), and false negative (FN)) predicted by GEO-BERT(DYRK1A) within different uncertainty intervals based on the Ensemble method. The horizontal axis represents the uncertainty interval, and the vertical axis represents the total number of samples (blue dashed line) and the respective percentage of samples (TP, TN, FP, and FN; histogram) within each uncertainty interval. MC-dropout: Monte Carlo dropout.

## Section: Results › Hit compounds identified by the computational workflow incorporating GEO-BERT(DYRK1A)

Firstly, we used the GEO-BERT(DYRK1A) model to predict DYRK1A inhibitory activity of the Specs compounds (>200K), and then ranked them according to their probability of being active. Top 500 compounds were selected for further screening with classical structure-based approaches, i.e. molecular docking. From molecular docking against the protein structure (PDB code: 7AJ2), which had been validated as an optimal structure for DYRK1A inhibitors discovery [25], we selected 344 compounds with FRED Chemgauss4 scores less than −10. According to the criteria based on the binding modes, we further narrowed down the number of potential hits to 119. However, only 114 compounds passed the PAINS-Remover. By structural clustering of these compounds based on FCFP_6 fingerprints, we picked 20 diverse compounds. Their chemical structures, FRED Chemgauss4 scores and probability values of being active are listed in Table S4. We tested them for their DYRK1A inhibitory activity at the concentration of 10 μM. As shown in Table S4, compounds X1, X6, X11 and X17 had the inhibition rate greater than 50% for DYRK1A. Their IC50 values were further determined based on the dose-response curves (cf. Fig. S7). Among them, the IC50 values of X11 and X17 were 0.30 μM and 0.55 μM, respectively, indicating that they were potent DYRK1A inhibitors (<1 μM). The predicted binding modes of X11 and X17 to DYRK1A are shown in Fig. 6. Compound X11 formed hydrogen bonds with two key amino acid residues GLU239/LEU241, and hydrophobic interactions with VAL173/ALA186/LEU294/VAL306. Unlikely, compound X17 interacted with LYS188 via a hydrogen bond, and formed hydrophobic interactions with ILE165/VAL222/VAL306. To explore chemical novelty of these inhibitors, we calculated structural similarity between each of the two hits and the known DYRK1A inhibitors that we collected from ChEMBL33 (https://www.ebi.ac.uk/chembl/, accessed May. 2023). As shown in Fig. S7, based on FCFP_6 fingerprints, the maximum structural similarity (Tanimoto coefficient) was only 0.165 to X11, and 0.267 for X17. It demonstrated that those two potent hits identified by GEO-BERT(DYRK1A)-based computational workflow were structurally novel.

In addition, we used the t-SNE method to show the chemical space of the molecules from the “DYRK1A_test” dataset. The feature vectors corresponding to each sample in the last layer of GEO-BERT(DYRK1A) were extracted and visualized. It can be seen from Fig. 7 that TN and FN samples were concentrated together, while TP and FP were close in distance, showing good predictive ability of the model. Based on this plot, we further analyzed the chemical space of those two experimentally validated hits X11 and X17. It can be seen that they have lower uncertainty values, and their distributions in the chemical space were relatively close but distant from the molecules of the “DYRK1A_test” dataset.

Two potent dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A) inhibitors identified by virtual screening facilitated by Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(DYRK1A). (A) The chemical structures and DYRK1A inhibitory activity of hit compound, X11 and the plausible binding modes of the hits to DYRK1A. (B) The chemical structures and DYRK1A inhibitory activity of hit compound X17 and the plausible binding modes of the hits to DYRK1A.

The chemical space of four types of samples (true positive (TP), true negative (TN), false positive (FP), and false negative (FN)) from the “DYRK1A-test” dataset. Visualization of chemical space is based on the t-distributed stochastic neighbor embedding (t-SNE) method, where points of different colors represent four types of samples, and the size of the points represents the uncertainty value of each sample, calculated by the ensemble method. Two validated hit compounds X11 and X17 are marked in the feature space.

## Section: Discussions

Comparison of three Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)) models with different configurations.

Classification performance of three Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)) variants for DYRK1A inhibitory activity prediction.

Classification performance of three Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT) (dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)) variants based on different numbers of conformations.

Comparison between the Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)) model and the Functional-Group BERT (FG-BERT)(DYRK1A) model in terms of generalization. The x axis is the similarity threshold used to exclude similar molecules from the “DYRK1A-test” set, while the y axis is the metric used in the comparison. (A) Comparison in the metric of area under curve (AUC). (B) Comparison in the metric of Matthews correlation coefficient (MCC).

## Section: Discussions › The effect of scale hyperparameters on GEO-BERT(DYRK1A)

We explored the effects of different combinations of configurations (layers, heads, embedding size and FFN size) on model performance of GEO-BERT(DYRK1A). In order to compare their performance, we followed the settings of MG-BERT [31] and designed three models with different scale hyperparameters, i.e., GEO-BERT-[SMALL], GEO-BERT-[MEDIUM] and GEO-BERT-[LARGE]. The number of layers was 3, 6, and 12, respectively. In order to match the size of the layers, their heads, embedding size, and FFN size were also adjusted accordingly. The AUC of GEO-BERT(DYRK1A) was utilized as the metric, with the results presented in Table 3.

As shown in Table 3, GEO-BERT-[MEDIUM] performed the best among the three models, with the AUC value of 0.875. When the scale parameters were too small, it may fail to capture sufficient information from the molecules. Conversely, an excessive number of layers may lead to model overfitting and decreased AUC. Accordingly, we chose the medium size to balance model complexity and model performance. The ROC curves for GEO-BERT with parameters of different scales are shown in Fig. S8A.

Comparison of three Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)) models with different configurations.

## Section: Discussions › Ablation experiment of GEO-BERT(DYRK1A)

To explore the role of spatial information considered in GEO-BERT, we designed GEO-BERT [a], GEO-BERT [b] and GEO-BERT [c]. The details of these models are described in Section 2.2.1. As depicted in Table 4, the absence of atom distance matrix and bond angle matrix in GEO-BERT [a] resulted in decreased performance (AUC: 0.860 vs. AUC: 0.875; MCC: 0.600 vs. MCC: 0.610), which indicated the importance of spatial information. Furthermore, the introduction of two learnable parameters that multiplied atom distance matrix and bond angle matrix in GEO-BERT [b] also impaired model performance, when compared with the direct incorporation of fixed distance and angle values in GEO-BERT (AUC: 0.845 vs. AUC: 0.875/MCC: 0.535 vs. MCC: 0.610). GEO-BERT [c] partitioned atoms and bonds by splitting a molecule into two segments. However, since a molecule is a unified chemical entity comprising both atoms and bonds, GEO-BERT that employed the single GLOBAL mechanism yielded better performance than GEO-BERT[c] (AUC: 0.864 vs. AUC: 0.875; MCC: 0.549 vs. MCC: 0.610). The ROC curves in Fig. S8B demonstrate consistent results.

Classification performance of three Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)) variants for DYRK1A inhibitory activity prediction.

## Section: Discussions › The effect of conformation number on GEO-BERT(DYRK1A)

Our GEO-BERT was trained with the low-energy conformation of a molecule as input and thus labeled as GEO-BERT (1). To evaluate the impact of incorporating multiple conformations on model performance, we trained other two GEO-BERT models with information incorporating different numbers of conformations. To reduce computational cost, we opted to use average atomic coordinates of multiple conformations. The new GEO-BERT (10–20) model was generated based on the average atomic coordinates of 10–20 conformations per molecule. The number of generated molecular conformers was adaptively determined based on the number of atoms in the molecule, constrained within the interval of [10, 20]. Specifically, if the atom count was less than 10, the parameter of “num_confs” was set to 10; if it exceeded 20, it was capped at 20; otherwise, the atom count itself was used as the number of conformers. The GEO-BERT (100) model was based on 100 conformations per molecule.

According to Table 5, GEO-BERT (1) achieved the highest AUC on the DYRK1A dataset (0.875 ± 0.014), closely followed by GEO-BERT (100) with an AUC of 0.874 ± 0.017. The GEO-BERT (10–20) model yielded a slightly lower AUC of 0.868 ± 0.013. To avoid bias, we also conducted experiments on six additional benchmarking datasets, and the results are presented in Table S5. It is clear to see that they displayed considerable variability. We found that it is not necessary that GEO-BERT (1) model always performed better than GEO-BERT based on 10–20 or 100 conformations. Accordingly, we suggest do model training case by case. To be specific, we have treated the number of conformations as a hyperparameter in the Python script. Users may train three models based on different numbers of confirmations and use the best-performing model for application.

Classification performance of three Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT) (dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)) variants based on different numbers of conformations.

## Section: Discussions › Performance of GEO-BERT(DYRK1A) on out of distribution data

Generalization is a pretty important metric of machine learning models, as it somewhat determines model performance in real-world practical application. In this study, we used the following method to evaluate generalization of our GEO-BERT(DYRK1A) model. Firstly, we calculated pairwise similarity in terms of Tanimoto coefficient between molecules of the “DYRK1A-test” set and those of the “DYRK1A-train” set using MACCS fingerprints. Any molecule of the “DYRK1A-test” set with the similarity value above a specified threshold was excluded, and the model was then evaluated on the revised test set. As the threshold was set to 1.0, 0.95, 0.90, 0.85, 0.80 and 0.75, respectively, the performance in terms of AUC and MCC was recorded for each threshold.

As depicted in Fig. 8, as the molecular similarity decreased, i.e., the molecules were becoming more dissimilar to those used for model training, the performance of GEO-BERT(DYRK1A) also gradually declined. Nevertheless, AUC still remained above 0.6, when the similarity threshold was 0.75. In addition, we chose FG-BERT, which is also based on the Transformer architecture, as a comparison. It can be seen that GEO-BERT(DYRK1A) outperformed FG-BERT(DYRK1A) in AUC and MCC at various thresholds. In summary, GEO-BERT(DYRK1A) demonstrated robust performance when encountering diverse molecules.

Comparison between the Geometry-based Bidirectional Encoder Representations from Transformers (GEO-BERT)(dual-specificity tyrosine phosphorylation-regulated kinase 1A (DYRK1A)) model and the Functional-Group BERT (FG-BERT)(DYRK1A) model in terms of generalization. The x axis is the similarity threshold used to exclude similar molecules from the “DYRK1A-test” set, while the y axis is the metric used in the comparison. (A) Comparison in the metric of area under curve (AUC). (B) Comparison in the metric of Matthews correlation coefficient (MCC).

## Section: Discussions › Comparison with GNN-based and other BERT-based models

Though models such as GraphMVP [44] used three-dimensional information as well, our GEO-BERT has the following technical advantages over those models. (1) GraphMVP and other similar models are based on GNN, which cannot avoid the inherent drawbacks of overfitting and oversmooth caused by the message passing mechanism of GNN. By contrast, GEO-BERT integrates message passing mechanism into Transformer and solves this problem by using attention mechanism. (2) In GNN, information of chemical bonds is added to the surrounding atomic features through aggregation operations in message passing. The subsequent graph pooling layer only uses features from atoms, while GEO-BERT can directly utilize information from chemical bonds by treating them as independent tokens (See Table S6 for details).

MG-BERT relies solely on information from atoms. FG-BERT uses information from both atoms and functional groups. MolRoPE-BERT gets information from substructures enhanced through the use of rotary position embedding. GEO-BERT, for the first time, incorporates molecular geometry (i.e., three-dimensional conformation) using a bidirectional autoencoder, in addition to the commonly utilized two-dimensional molecular structures in BERT-based models (See Table S7 for details).

More importantly, GEO-BERT was applied to real-world drug discovery, and facilitated the discovery of two novel and potent DYRK1A inhibitors at a high hit rate, demonstrating its high practical utility. It should be noted that all the previous GNN-based or BERT-based models have never been experimentally validated.

## Section: Discussions › Limitations of GEO-BERT

As mentioned above, the current GEO-BERT model is based on low-energy conformations of molecules. Though it performs well (e.g., for DYRK1A) and better than the GEO-BERT based on the average conformation derived from multiple conformations, there is a necessity to explore how to make the most of diverse conformations of a molecule or select bioactive conformations for training so as to improve model performance. In addition, although it has been proved that GEO-BERT is superior to the previous FG-BERT in generalization (Fig. 8) and its application to DYRK1A has led to two structurally novel hits (Fig. 7), from the perspective of real-world practice, inclusion of more diverse molecules for model training might lead to models of better generalization.

In this study, GEO-BERT(DYRK1A) model was combined with molecular docking for virtual screening. This combined use of data-based and physics-driven methods could help improve hit rate. It should be noted that, however, false positive rate is still high as only 4 potential hits were experimentally validated as true hits. Therefore, it is necessary to optimize this virtual screening workflow in the future, by improving the GEO-BERT model's accuracy and generalization with more diverse, and high-quality datasets, better ways to deal with conformations, and improving scoring function and binding affinity prediction with factors such as protein flexibility being considered.

## Section: Conclusion

In summary, we have developed a GEO-BERT model by using three-dimensional conformations of molecules for molecular property prediction. This model has been experimentally validated with the case of success in DYRK1A-targeted drug discovery. Due to its open-source feature, it is anticipated that this GEO-BERT model will have a wide application in early-stage drug discovery.

## Section: CRediT authorship contribution statement

Xiang Zhang: Writing – original draft, Software, Methodology, Conceptualization. Chenliang Qian: Writing – original draft, Data curation. Bochao Yang: Visualization, Investigation. Hongwei Jin: Validation. Song Wu: Supervision. Jie Xia: Writing – review & editing, Project administration. Fan Yang: Writing – review & editing, Project administration. Liangren Zhang: Supervision.

## Section: Data and software availability

The source code is available at the open-source GitHub repository (https://github.com/drug-designer/GEO-BERT), where all the parameters of the trained models and the curated datasets that can be used for prospective study are also provided.

## Section: Declaration of competing interest

The authors declare that there are no conflicts of interest.

## Section: Acknowledgments

This study was supported by the National Natural Science Foundation of China (Grant Nos.: 62173282, 62472363, and 62573367), CAMS Innovation Fund for Medical Sciences (Grant No.: 2021-I2M-1–069), the 2024 China Industrial Technology Infrastructure Public Service Platform Project (Grant No.: GN2024-31-4700) and the Foreign Expert Program of State Administration of Foreign Experts Affairs (Grant No.: H20240802). We acknowledge Information Center of Institute of Materia Medica, Chinese Academy of Medical Sciences for free access to computing facilities. We also thank Dr. Xuehui Zhang (Shandong First Medical University) for technical support for the DYRK1A activity assay.

## Section: Contributor Information

Jie Xia, Email: jie.william.xia@hotmail.com, jiexia@imm.ac.cn.

Fan Yang, Email: yang@xmu.edu.cn.

## Section: Supplementary data

The following is the Supplementary data to this article.

## Section: Associated Data › Data Availability Statement

The source code is available at the open-source GitHub repository (https://github.com/drug-designer/GEO-BERT), where all the parameters of the trained models and the curated datasets that can be used for prospective study are also provided.
