# Data Quality and Benchmarking Rigor in Machine Learning for Drug Discovery: A Perspective on Aqueous Solubility Modeling

- **Authors:** W. Patrick Walters
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2026-07-07
- **DOI:** 10.20944/preprints202607.0468.v1
- **Source:** https://doi.org/10.20944/preprints202607.0468.v1
- **Licence:** CC-BY

## Section: Abstract

As machine learning (ML) becomes increasingly integrated into drug discovery, reliance on legacy datasets and superficial performance metrics threatens to stall genuine progress. This perspective examines common pitfalls in solubility modeling, specifically overreliance on flawed public datasets and insufficient similarity analysis between training and test sets. By comparing performance on "real-world" datasets with consistent experimental conditions, specifically the Biogen and ASAP Discovery sets, we demonstrate that inflated correlations can mask poor generalizability. We propose new guidelines for authors, reviewers, and journals to elevate the standard of ML validation.


---

# Development and Validation of a Deep Learning Ensemble Model to Predict Drug-resistant Tuberculosis From Initial Chest X-ray Image

- **Authors:** Vedant Phatak, Manju Mamtani, Hemant Kulkarni
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2026-09-09
- **DOI:** 10.21203/rs.3.rs-10782150/v1
- **Source:** https://doi.org/10.21203/rs.3.rs-10782150/v1
- **Licence:** CC-BY

## Section: Abstract

Abstract Early detection and prompt treatment of drug-resistant tuberculosis continue to represent the “holy grail” in tuberculosis research. Advances in molecular methods have drastically reduced turnaround times but novel strategies for early identification of drug-resistant tuberculosis (DR-TB) are still needed. We combined the diversity, representativeness and volume of the TB Portals chest X-ray image set with the power of deep learning and machine learning to develop and train an ensemble model for prediction of DR-TB. Using 7,151 chest X-ray images, confirmed drug-resistance diagnosis, our ensemble model achieved an area under the receiver operating characteristic curve (AUC) of 0.8253 and 0.8108 in the validation and held-out test subsets. This classification performance correlated with the extent of drug resistance such that extensive drug resistance patients showed a higher predicted probability than patients with multigrug resistance. The model’s predicted probabiliy also correlated with adverse treatment outcome and was robust to potential demographic confounders. Presence of comorbidities diminished the AUC of the ensemble model. SHapley Additive exPlanations-value based explainer demonstrated that the model focused accurately on the lung fields. If replicated through diverse set of external data, our ensemble model will provide a gatekeeper screening protocol for early risk stratification of drug-resistant tuberculosis.


---

# Drug or Pokémon? Large language model performance in identification of fabricated medications

- **Authors:** Kelli Henry, Brian Murray, Xingmeng Zhao, Kaitlin Blotske, Yanjun Gao, Brooke Smith, Susan E. Smith, Erin F. Barreto, Seth Bauer, Sunghwan Sohn, Tianming Liu, Tell Bennett, Mitch Cohen, Raja-Elie E. Abdulnour, Leo A. Celi, Khoa Le, Hongjian Zhou, Fenglin Liu, David A. Clifton, Andrea Sikora
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2026-01-13
- **DOI:** 10.64898/2026.01.12.26343930
- **Source:** https://doi.org/10.64898/2026.01.12.26343930
- **Licence:** CC-BY-NC-4.0

## Section: Abstract

Abstract Background Large language models (LLMs) are increasingly used in medication-related tasks despite limited evidence supporting their accuracy and safety. LLMs are vulnerable to adversarial attacks and may confabulate in response to fabricated information in the prompt. Given the substantial risk of harm from medication errors, the purpose of this study was to establish a benchmark task to evaluate LLM performance in distinguishing fabricated from real medications. Methods Two datasets (brand and generic), each consisting of 250 medication lists were developed, each including 4-6 medications and one fabricated medication (specifically a Pokémon character), with complete dosing information provided. Six LLMs were evaluated (GPT-5-Chat, GPT-4o-mini, DrugGPT, Gemma-3-27B-IT, Llama-3.3-70B-Instruct, and Qwen3-32B). For each medication list, models were queried for dosing information and disease indication across three experimental conditions: standard decoding, standard decoding with mitigation prompting, and deterministic decoding (temperature = 0). Each experiment was performed in triplicate. Outputs were deemed confabulations if the LLM failed to recognize and reject the fabricated medication. The primary outcome was the rate of confabulations. Exact paired-permutation tests were used to compare confabulation rates across LLMs and prompting approaches. Results Confabulation rates under standard conditions ranged from 2.7% to 99.6%. DrugGPT demonstrated the lowest baseline confabulation rates (2.7-6.4%), whereas other models demonstrated substantially higher rates (47.2-99.6%). Mitigation prompting significantly reduced confabulation rates compared to standard and deterministic decoding across all tasks and datasets (p &lt; 0.001): GPT-5-Chat achieved confabulation rates of 0% with mitigation prompting from baseline rates of 66.4-88.5%. Deterministic decoding did not substantially impact confabulation rates. Conclusions LLMs performing medication-related tasks are susceptible to confabulation in response to invalid or fabricated inputs, raising important safety concerns for clinical use. While mitigation prompting reduced confabulation rates, this study underscores the importance of robust safeguards when deploying LLMs in medication-related decision-making.


---

# DrugPlayGround: Benchmarking Large Language Models and Embeddings for Drug Discovery

- **Authors:** Tianyu Liu, Sihan Jiang, Fan Zhang, Kunyang Sun, Teresa Head-Gordon, Hongyu Zhao
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2026-04-07
- **DOI:** 10.64898/2026.04.04.716470
- **Source:** https://doi.org/10.64898/2026.04.04.716470
- **Licence:** CC-BY-NC-4.0

## Section: Abstract

Abstract Large language models (LLMs) are in the ascendancy for research in drug discovery, offering unprecedented opportunities to reshape drug research by accelerating hypothesis generation, optimizing candidate prioritization, and enabling more scalable and cost-effective drug discovery pipelines. However there is currently a lack of objective assessments of LLM performance to ascertain their advantages and limitations over traditional drug discovery platforms. To tackle this emergent problem, we have developed DrugPlayGround, a framework to evaluate and benchmark LLM performance for generating meaningful text-based descriptions of physiochemical drug characteristics, drug synergism, drug-protein interactions, and the physiological response to perturbations introduced by drug molecules. Moreover, DrugPlayGround is designed to work with domain experts to provide detailed explanations for justifying the predictions of LLMs, thereby testing LLMs for chemical and biological reasoning capabilities to push their greater use at the frontier of drug discovery at all of its stages.


---

# Leakage-controlled benchmarking reveals generalization limits of deep learning for protein–ligand binding affinity prediction

- **Authors:** Lyuwei Wang, Jianlin Cheng
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2026-09-23
- **DOI:** 10.64898/2026.09.17.752433
- **Source:** https://doi.org/10.64898/2026.09.17.752433
- **Licence:** CC-BY-NC-ND-4.0

## Section: Abstract

Abstract To address widespread data leakage and inconsistent evaluation in protein–ligand affinity prediction, we introduce PLABench, a leakage-controlled and target-centric benchmarking framework that enables standardized comparison across sequence- and structure-based models. We benchmark nine deep learning methods across blind CASP16 targets, leakage-controlled ChEMBL35 sets, and established Davis and KIBA datasets under rigorous data split settings, standardizing structural input via AlphaFold3 to ensure fair comparison. Although pretrained structure-based models achieve the highest overall accuracy, they show severe target-dependent variability, and increasing structural fidelity from predicted to experimental conformations yields no consistent gains. Meanwhile, sequence-based approaches surpass some structure-based methods on select targets, and protein family-level evaluations reveal uneven performance across families and substantial inter-model complementarity obscured by aggregate metrics. These findings demonstrate that training scale and structural input alone cannot guarantee cross-target generalization, highlighting the need for context-aware interaction modeling. PLABench provides an extensible open-source platform to facilitate these developments.


---

# Model Validation Protocols for Machine Learning in Small Molecule Drug Discovery

- **Authors:** Srijit Seal, Akshat Shirish Zalte, David Alencar Araripe, Renan Augusto Gomes, Deepa Korani, Mrinal Shekhar, Vishal Babu Siramshetty, Arijit Patra, Zhongyu Mou, Xiang Yu, Daniel Kuhn, Nils Weskamp, Jeremy Ash, Alan C. Cheng, Cheng Fang, Daniel Price, Matteo Aldeghi, Raquel Rodríguez-Pérez, Djork-Arné Clevert, Ola Engkvist, Kristine Deibler, David Rouquie, Michael Reutlinger, Nicola J. Richmond, Jon Ainsley, Mark Ledeboer, William H. Green, Andreas Bender, Cas Wognum
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2026-08-24
- **DOI:** 10.64898/2026.08.19.745868
- **Source:** https://doi.org/10.64898/2026.08.19.745868
- **Licence:** CC-BY-4.0

## Section: Abstract

Abstract Machine learning (ML) models for molecular property prediction are increasingly deployed in drug discovery, yet their adoption in real-world scenarios requires an understanding of the conditions in which a model succeeds or fails. While standardized benchmarks are powerful instruments to measure and unlock progress in ML research, they should not be blindly treated as the end goal. Especially static and retrospective benchmarks, in which no true unknown test set is employed, limit our ability to robustly validate a model’s performance. Building on the collective expertise of a cross-industry consortium, we present a model validation framework consisting of five recommendations that would enable the community to move beyond aggregate metrics toward understanding where and why molecular property prediction models fail. We connect evaluation choices to real-world applications and case studies encountered in pharmaceutical research. The framework proposes splitting strategies that mimic realistic distribution shifts and expose common failure modes. We apply the recommended framework on a recently released dataset of absorption, distribution, metabolism, and excretion (ADME) properties. Across two complementary model algorithms, our case studies reveal four distinct failure modes (extrapolation, interpolation, representation, and evaluation) showing that model errors arise not only from distribution shift but also from limitations in molecular representations. Our results show that commonly used evaluation protocols can significantly overestimate performance and may not detect important model failure modes. All software and data are released via https://github.com/srijitseal/polaris .


---

# NoiTox: A Machine Learning Strategy for Peptide Toxicity Prediction Reveals Label Noise in Benchmark Datasets

- **Authors:** Gustavo O. Almeida, Matheus C. Albuquerque, Bruno M. Silva, Olavo A. B. Silva, Ricardo S. Ferreira, Wagner Meira, Douglas V. Pires, Wallace Mateus Prata, Sabrina A. Silveira
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2026-10-15
- **DOI:** 10.64898/2026.10.08.757741
- **Source:** https://doi.org/10.64898/2026.10.08.757741
- **Licence:** CC-BY-4.0

## Section: Abstract

Abstract Motivation Peptide toxicity remains a major bottleneck in drug development, as small sequence variations can drastically alter cytotoxic profiles. Experimental assessment is costly and time-consuming, motivating computational predictors. Existing approaches often rely on single black-box architectures, limiting interpretability and obscuring the contribution of individual sequence features. Furthermore, benchmark datasets frequently define the negative class through annotation filters rather than direct experimental evidence, introducing structural label noise that can compromises training and evaluation. Results We present NoiTox, a multi-model strategy for peptide toxicity prediction integrating three complementary architectures, evaluated as four model variants: NoiToxML (Bo/full), an Extremely Randomized Trees classifier with Boruta-selected or complete physicochemical, compositional, and atomic descriptors; NoiToxDP, a deep learning model leveraging ESM-2 protein language model embeddings; and NoiToxGP, a graph neural network that combines ESM-2 residue embeddings, a fully connected residue graph with attention, and the Boruta descriptors as global features. Averaged over five random seeds, the models approached the state-of-the-art predictor ToxiPep on CD-HIT-controlled test sets, and on an independent dataset the interpretable NoiToxML variants and a probability-averaging consensus of the four models exceeded it, showing that physicochemical descriptors are highly informative for toxicity prediction. Cross-referencing negative-labeled sequences against curated databases of hemolytic, cytotoxic, and neurotoxic peptides flagged a small set annotated as toxic elsewhere, consistent with label noise by omission. However, removing the sequences that all models contradicted did not improve, and for some models reduced, ranking performance, indicating that such sequences carry useful information and are better treated as candidates for curation than discarded automatically. Availability and implementation https://github.com/goalmeida05/NoiTox . Contact gustavo.o.almeida@ufv.br .


---

# TB-Bench: A Systematic Benchmark of Machine Learning and Deep Learning Methods for Second-Line TB Drug Resistance Prediction

- **Authors:** Brintha VP, Saish Jaiswal, Ansh Meshram, Deepti PVS, Sidharthan S C, Manikandan Narayanan
- **Issuer:** Preprint server
- **Type:** Preprint
- **Published:** 2026-04-13
- **DOI:** 10.64898/2026.04.08.717138
- **Source:** https://doi.org/10.64898/2026.04.08.717138
- **Licence:** CC-BY-4.0

## Section: Abstract

Abstract Drug-resistant tuberculosis (TB), characterized by prolonged treatment regimens and suboptimal treatment outcomes, remains a major obstacle to global TB elimination. Advances in sequencing technologies have enabled the development of machine-learning (ML) approaches, including deep-learning (DL) methods, to predict drug resistance directly from genomic data. However, a significant gap remains in translating these advances into clinical practice. While current approaches reliably predict resistance to first-line drugs, they show consistently lower and more variable performance for second-line drugs compared with traditional drug-susceptibility testing. To characterize these limitations and assess practical utility, we conducted a comprehensive survey and standardized benchmarking of current approaches for predicting TB drug resistance using whole-genome sequencing (WGS) data. Using systematic selection criteria, we identified 20 traditional ML and DL models from 8 studies and evaluated drug-specific versions across 14 second-line drugs within a unified framework. To account for methodological heterogeneity, the models were evaluated using three distinct feature sets reflecting variability in input representations. We trained and evaluated the models on different subsets of the WHO dataset, comprising 50,801 samples, and assessed generalizability using an external validation dataset comprising 1,199 samples. In the internal evaluation on the held-out WHO test dataset, traditional ML models using binary features achieved higher predictive performance than DL models. For example, XGBoost achieved the highest area under the precision-recall curve (PRAUC) scores (46%–93%) for 10 of the 14 drugs. However, performance varied substantially across drugs. Notably, the superior performance of traditional ML models — even with limited feature sets — highlights their applicability in low-resource settings. When evaluated on the external validation dataset, the performance of traditional ML and DL models was comparable, and neither class of models demonstrated substantial improvement over catalogue-based approaches, underscoring challenges in cross-dataset generalization. Overall, this benchmarking study provides a comprehensive and systematic evaluation of current approaches, establishes a rigorous evaluation framework for future comparisons, and identifies key methodological considerations necessary to advance robust drug resistance prediction in clinical settings. To enhance reproducibility and facilitate the application of TB-Bench to additional datasets and models, we have made the source code publicly available at https://github.com/BIRDSgroup/TB-Bench .


---

# FDA perspective: generative AI-enabled digital health medical devices

- **Issuer:** FDA
- **Type:** Presentation
- **Language:** en
- **Source:** https://www.fda.gov/media/189833/download
- **Licence:** US-public-domain

## Page 1 (Section: FDA Perspective: Generative Artificial Intelligence-Enabled (GenAI) Digital Mental Health Medical 	Devices)

FDA Perspective: Generative Artificial 
Intelligence-Enabled (GenAI) Digital 
Mental Health Medical Devices
Gioia M. Guerrieri, DO, DFAPA, FASAM
Digital Health Center of Excellence (DHCoE)
Center for Devices and Radiological Health (CDRH)
November 6, 2025
2025
1
Digital Health Center of Excellence

## Page 2 (Section: Improving Mental Health by Advancing Access to Safe and Effective Medical Devices)

Improving Mental Health by Advancing Access to 
Safe and Effective Medical Devices
• Mental health diagnoses are increasing.
• Mental health treatment needs are increasing
• Timely access to mental healthcare is 
decreasing
• Development of and technological advances in 
digital mental health technologies are 
accelerating
• We have an opportunity to help facilitate 
innovative, safe and effective technologies for 
patients struggling with mental health 
conditions
2025
2
Digital Health Center of Excellence
Source: Substance Abuse and Mental Health Services Administration. Key substance use and mental health indicators in the United States: Results from 
the 2021 National Survey on Drug Use and Health, 2022 (https://www.samhsa.gov/data/report/2021-nsduh-annual-national-report)

## Page 3 (Section: Improving Mental Health by Advancing Access to Safe and Effective Medical Devices)

Accelerate the Delivery of 
Safe and Effective Medical 
Device Software to Market by 
Supporting Consistency and 
Predictability in 
Development and Review
2025
3
Digital Health Center of Excellence

## Page 4 (Section: FDA’s Risk-based Approach to Device Software Regulation)

FDA’s Risk-based Approach to Device Software 
Regulation
Not a Device
Example – an app that provides 
daily motivational tips to reduce 
stress and promote a positive 
mental outlook to support an 
individual’s general wellness
Intention to Exercise 
Enforcement Discretion
Example – an app that helps 
patients diagnosed with anxiety 
maintain their behavioral coping 
skills by providing a “Skill of the 
Day” behavioral technique that 
a user can access when 
experiencing increased anxiety
Focus of FDA’s Regulatory 
Oversight
Example – an app that provides 
computerized behavioral 
therapy for psychiatric disorders 
as an adjunct to clinician 
supervised outpatient treatment 
(21 CFR 882.5801)
Increasing Risk
2025
4
Digital Health Center of Excellence

## Page 5 (Section: Draft Guidance: Lifecycle Management and Marketing Submissions for AI-Enabled Devices)

Draft Guidance: Lifecycle Management and Marketing 
Submissions for AI-Enabled Devices
• Proposes recommendations on the 
premarket expectations for AI-enabled 
devices based on FDA’s experience with 
these devices
• Proposes a total product life cycle 
approach, including recommendations for 
the design, development, deployment, 
and maintenance of AI-enabled devices, 
including performance monitoring
Source: Draft Guidance: Artificial Intelligence-Enabled Device Software Functions: Lifecycle Management and Marketing Submission Recommendations, 2025 
(www.fda.gov/regulatory-information/search-fda-guidance-documents/artificial-intelligence-enabled-device-software-functions-lifecycle-management-and-
marketing)
2025
5
Digital Health Center of Excellence

## Page 6 (Section: Draft Guidance: Recommendations for Lifecycle Management )

Draft Guidance: Recommendations for Lifecycle 
Management 
• AI-enabled devices are sensitive to changes in input data, which 
may lead to changes in performance that create a risk to patients 
over time but can be difficult to identify​.
• Manufacturers should have a postmarket performance monitoring 
plan to help identify and respond to changes in performance in 
a postmarket setting as part of the quality system.
• The inclusion of a performance monitoring plan in the marketing 
submission may help to reduce uncertainty and support FDA’s 
evaluation of risk controls.
Source: Draft Guidance: Artificial Intelligence-Enabled Device Software Functions: Lifecycle Management and Marketing Submission Recommendations, 
2025 (www.fda.gov/regulatory-information/search-fda-guidance-documents/artificial-intelligence-enabled-device-software-functions-lifecycle-
management-and-marketing)
2025
6
Digital Health Center of Excellence

## Page 7 (Section: FDA's Digital Health Center of Excellence Seeks Comments on AI Performance in Real-world)

FDA’s Digital Health Center of Excellence Seeks 
Comments on AI Performance in Real-world  
Docket name and number: 
Measuring and Evaluating 
Performance of AI-enabled 
Medical Devices in the Real-
World (FDA-2025-N-4203) 
Public comment due date: 
December 1, 2025
Objective: To obtain comment and 
feedback on questions related to:
•
Real-world evaluation methods 
and infrastructure
•
Performance metrics and indicators
•
Postmarket data sources and quality 
management
•
Monitoring triggers and response protocols
•
Human-AI interaction and user experience
•
Additional considerations and best practices
Source: Request For Public Comment: Measuring and Evaluating Artificial Intelligence-enabled Medical Device Performance in the Real-World, 2025 
(www.fda.gov/medical-devices/digital-health-center-excellence/request-public-comment-measuring-and-evaluating-artificial-intelligence-enabled-medical-
device) 
2025
7
Digital Health Center of Excellence

## Page 8 (Section: AI Predetermined Change Control Plan (PCCP))

AI Predetermined Change Control Plan (PCCP)
Description of 
Modifications
“What” a manufacturer intends the algorithm to become as it learns
•
Identifies specific, planned modifications to AI-
enabled device software functions that the 
manufacturer intends to implement
•
Includes the specifications for the characteristics 
and performance of the planned modifications to 
the AI-enabled device software function 
Modification 
Protocol
“How” the algorithm will learn/change while remaining safe and effective
•
Describes methods that will be followed when 
developing, validating, and implementing the 
modifications to ensure the device remains safe 
and effective
•
Methods described in Modification Protocol 
should be consistent with and support the 
modifications outlined in Description of 
Modifications
Impact 
Assessment
Describes modifications’ benefits and risks, and how risks are mitigated
•
Assesses benefits and risks of each individual 
modification, as well as collective impact of 
modifications, when implementing a PCCP
•
Discusses how activities proposed within 
Modification Protocol mitigate identified risks to 
continue to reasonably ensure the safety and 
effectiveness of the device
Source: Marketing Submission Recommendations for a Predetermined Change Control Plan for Artificial Intelligence-Enabled Device Software 
Functions, 2025 (www.fda.gov/regulatory-information/search-fda-guidance-documents/marketing-submission-recommendations-predetermined-change-
control-plan-artificial-intelligence)
2025
8
Digital Health Center of Excellence

## Page 9 (Section: Considerations for PCCPs for Gen AI Enabled Digital Mental Health Medical Devices)

Considerations for PCCPs for Gen AI Enabled Digital 
Mental Health Medical Devices
• How specific can the modifications be given the nature of the 
technology?
• What boundaries or guardrails are needed in the PCCP to define the 
range of automatic updates allowed for a given device?
• How will post-market performance be monitored over time to assure 
device performance is maintained or improved?
• How will labeling will be updated to inform users when modifications 
are implemented automatically?
• What are the appropriate notification requirements if the device does 
not function as intended?
Source: Marketing Submission Recommendations for a Predetermined Change Control Plan for Artificial Intelligence-Enabled Device Software Functions, 
2025 (www.fda.gov/regulatory-information/search-fda-guidance-documents/marketing-submission-recommendations-predetermined-change-control-plan-
artificial-intelligence)
2025
9
Digital Health Center of Excellence

## Page 10 (Section: Payer Coverage for Digital Mental Health Care )

Payer Coverage for Digital Mental Health Care 
• FDA collaborated with CMS through HHS on an 
Administration priority to improve access to 
affordable and innovative treatments through 
payment pathways for digital mental 
health treatment devices
• 2025: CMS issued a rule finalizing changes for 
Medicare payments under the Physician Fee 
Schedule for computerized behavioral therapy 
devices authorized by FDA under 21 CFR 
882.5801 
• 2026: Proposed expansion for coverage of mental 
health treatment devices in CY 2026 underway
Sources: Calendar Year 2025 Medicare Physician Fee Schedule Final Rule, 2024 (www.cms.gov/newsroom/fact-sheets/calendar-year-cy-2025-medicare-
physician-fee-schedule-final-rule) and https://www.statnews.com/2025/01/17/fda-cms-dmht-code-payments-behavioral-health/ 
2025
10
Digital Health Center of Excellence

## Page 11 (Section: Engage With Us!)

Engage With Us!
Visit Digital Health Center for Excellence website:
www.fda.gov/medical-devices/digital-health-center-excellence
For informal questions about digital health 
policy, please reach out to: 
CDRH’s Digital Health Center of 
Excellence (DHCoE)
DigitalHealth@fda.hhs.gov
For general questions about CDRH, please 
reach out to:
CDRH’s Division of Industry and Consumer 
Education (DICE)
DICE@fda.hhs.gov
2025
11
Digital Health Center of Excellence


---

# AI observatory: compilation of 2024 experience

- **Issuer:** EMA
- **Type:** Report
- **Language:** en
- **Source:** https://www.ema.europa.eu/en/documents/report/2024-ai-observatory-report-compilation-2024-experience_en.pdf
- **Licence:** EMA-reuse

## Page 1

Official address  Domenico Scarlattilaan 6  ●  1083 HS Amsterdam  ●  The Netherlands 
An agency of the European Union   
Address for visits and deliveries  Refer to www.ema.europa.eu/how-to-find-us  
Send us a question  Go to www.ema.europa.eu/contact  Telephone +31 (0)88 781 6000 
© European Medicines Agency, 2025. Reproduction is authorised provided the source is acknowledged. 
 
6 May 2025 
EMA/154528/2025 
European Medicines Agency 
2024 AI Observatory 
 
 
The HMA-EMA Big Data Steering Group 2023-2028 Multi-annual AI workplan asks for the creation of an 
AI observatory, including horizon scanning, because AI requires constant monitoring both for the 
emergence of novel systems and impact of AI. 
The objective of the observatory is to capture and share experience and trends in AI to inform the 
European Medicines Regulatory Network (EMRN) for the implementation of its multi-annual AI 
workplan, in compiling experience gained within the EMRN toward use of AI for personal productivity or 
automating processes and systems, and, for increasing insights into data and supporting more robust 
decision-making to benefit public and animal health.  
The following information have been compiled as part of this observatory: 
• 
AI use for increasing insights into data and supporting decision-making in medicine life-cycle 
identified as part of Qualification of novel methodologies for medicine development, Scientific 
Advice, Innovation Task Force meetings and Portfolio and Technology meetings, 
• 
AI for personal productivity or automating processes and system, including tools available or in 
development in the Agency and in NCAs. 
It has been completed with a horizon scanning report based on a review of peer-reviewed journals, 
preprints and EU-funded research and development project to identify gaps, challenges and 
opportunities for AI implementation in the medicines lifecycles. 
The observatory is for information to the NDSG and the basis of the 2024 AI Observatory report to be 
reported to EMA Management Board and HMA, and, made public on the EMA website. It could also be 
posted on the HMA website.

## Page 2

2024 AI Observatory  
EMA/154528/2025  
Page 2/9
 
I. 
AI use for increasing insights into data and supporting decision-making in medicine 
life-cycle 
a. Qualification of novel methodologies for medicine development 
Identification 
Short description 
Statistical adjustment 
on deep learning 
prognosis covariates 
obtained from 
histological slides 
Completed Qualification Advice with public Letter of Support 
AI-Based Measurement 
of NASH in liver disease 
to determine disease 
activity 
Completed Qualification opinion published 
Confidential 
qualification advice + 
follow-up 
Artificial Intelligence for adjudication of clinical events (ML-based model 
for auto-adjudicating events e.g. cardiovascular death) 
Confidential 
qualification advice 
Method aiming to reduce the negative impact of high data variability on 
“assay sensitivity” by producing baseline prognostic covariates to be used 
in the treatment effect analyses.  
Confidential 
qualification advice 
Machine Learning Algorithms for Scoring of Radiographic Progression in 
Psoriatic Arthritis. 
Confidential 
qualification advice 
Machine Learning Algorithms for Scoring Endoscopy Videos in Ulcerative 
Colitis 
 
b. Scientific advice procedures 
Therapeutic  area 
Short description 
NASH/MASH 
Image analysis, support for histopathologists 
Multiple Myeloma 
Computerised algorithm to assess response to treatment and disease 
progression 
Dravet Syndrome 
Digital Twins (DTs)  
Autosomal dominant 
polycystic kidney 
disease 
Deep Learning (DL) based algorithm to analyse kidney segmentations 
 
c. 
ITF meetings 
Therapeutic  area 
Short description 
Retinitis pigmentosa 
and acute cardiac 
disease 
Use of AI models to automate cell analytical assessment

## Page 3

2024 AI Observatory  
EMA/154528/2025  
Page 3/9
 
Major Depression 
Disorder 
Model trained on data to predict clinical outcome 
Neurology 
Video capture and video analysis capabilities. 
d. Portfolio and Technology meetings 
Therapeutic  area 
Short description 
Various 
(Immuno-
inflammation) 
- AI digital twin modelling 
- Automated scoring methods for image and video-based endpoints  
 
Cardiovascular 
disorders 
AI for endpoint data collection and analysis. 
Ophthalmology and 
Neurodegenerative 
diseases 
AI-generated clinical trials patient selection algorithm (medical imaging) 
Oncology 
AI-based CT & PET/CT imaging solutions that automate reads and 
quantify tumour lesion count and three-dimensional size. 
Various 
AI-based read-outs of e.g., biopsies 
Various 
- Leveraging of RWE to complement clinical trials  
- Exploring the use of generative AI in event adjudication models, as well 
as in imaging (e.g. ECT, PET scans) 
Various 
AI in medical imaging (Automation of Endoscopic scores, Automation of 
arthritis scoring) 
Dermatology 
AI tools, such as computer vision algorithms, to assess skin lesions 
Various 
General use of use AI and machine learning, as well cloud-based 
computing, to help innovate and become faster and more agile. 
Clinical tials, 
Pharmacovigilance, 
CMC (finished product 
inspection) 
- Medical imaging, 
- LLMs, 
- risk prediction in subpopulation 
- AI standards 
- AI in dosing 
- Gen AI to assist generation of draft regulatory documentation 
 
Other insights from the applicants of EMA early stakeholder interactions – Portfolio and 
Technology Meetings (PTM) 
In the last call to apply for a PTM, applicants were asked to provide insights on Artificial intelligence 
use in drug development and manufacturing as this is a relevant developing area for regulators. The 
following paragraphs summarise the feedback received from the developers, including applications 
under development as well as potential challenges encountered by large pharmaceutical enterprises.

## Page 4

2024 AI Observatory  
EMA/154528/2025  
Page 4/9
 
Potential applications: 
Early drug development:  
• 
Analyse large datasets, predict drug-target interactions, and optimize drug design. This helps 
in identifying potential drug candidates more efficiently and enhancing clinical trials through 
patient stratification and predicting trial outcomes. 
 
• 
Identify potential fixed dose combinations and the role of digital twins. 
 
• 
Target identification (which falls outside EMA's remit), knowledge graphs (utilizing ML models 
to identify patterns and support clinical decision-making), and External Control Arms (ECA) or 
Synthetic Control Arms (SCA), which involve the use of external and historical patient data to 
establish comparator arms. AI/ML is considered another drug development tool, such as 
traditional statistical methods or approaches including model informed drug development.  
 
Quality, Manufacturing and Inspections:  
• 
Automated visual inspection. Guardrails inherent in GMP provide risk mitigation for many of the 
general risks of AI. 
• 
Manufacturing Processes: optimize manufacturing processes by predicting maintenance needs 
and improving quality control. This ensures consistent quality and reduces waste. 
 
Clinical phase:  
• 
Help identify candidates for clinical trials, assess DHT-derived digital endpoints, identify 
predictors of long-term clinical outcomes, and increase the statistical power of clinical trials. 
Projects under development include:  
o 
A ML approach to developing a biomarker signature linking longitudinal multi-omic 
profiles with long term clinical outcomes to optimize phase II dose-response and proof 
of concept studies. 
o 
A ML approach to covariate adjustment to increase precision and statistical power in 
RCTs for use in a phase III study with a long-term time to event outcome. 
o 
Exploratory work on a ML model to predict disease criteria/ lab parameter supporting 
patient enrolment, and primary or secondary endpoint assessment for a phase 2/3 
trial. 
 
• 
Digital therapeutics and patient monitoring devices to track health metrics and medication 
adherence, which is particularly important for chronic diseases like diabetes. 
 
Post-authorisation/pharmacovigilance:  
• 
Monitor and identify potential safety cases from social media accounts in fulfilment of 
regulatory requirements. Social media screening presents unique challenges, including the high 
volume of unstructured data. A company developed an approach with AI that may yield 
improved efficiency, faster detection of adverse events, and enhanced patient safety compared 
to traditional approaches. 
 
Increasing process efficiency:

## Page 5

2024 AI Observatory  
EMA/154528/2025  
Page 5/9
 
• 
With respect to clinical trial efficiencies, natural language processing is being used to extract 
external and internal knowledge to develop better protocols for clinical trials in less time, other 
AI tools to identify the study sites with the best chance of recruiting patients. For studies 
underway, the company is using advanced analytics and AI to predict, identify and resolve 
issues that might slow or compromise clinical trials. Tools are being investigated to streamline 
drafting of regulatory submissions, and speed access to regulatory information to facilitate 
health authority interactions and respond to information requests in a timely manner. 
 
Questions/feedback from the developers:  
“We would like to understand the regulatory oversight in the context of using AI for medicines 
development. We believe that the EU AI Act R&D exemption described in Recital 25, Articles 2.6 and 
2.8) should apply to Pharma R&D processes if treatment of patients is not directly affected. How does 
EMA define and assess the relative risk of AI (in the context of application of medicines legislation) for 
different uses in the medicine lifecycle, and the framework being used for such assessments.” 
“We encourage EMA to further develop its thinking in this area. For AI applications in drug 
development, there is increasing interest in how to use AI/ML as a lever to automate, e.g., data 
capture/verification, monitoring, use of digital tools, and potential for developing algorithms for 
diagnosis and predictive models to identify which patients would benefit most from a new treatment. 
Key principles in these areas would be useful.” 
“We believe that current regulatory frameworks for pharmaceutical oversight are generally sufficient 
for the oversight of AI/ML use across drug development and appreciated the clarity provided by EMA’s 
"Reflection paper on the use of Artificial Intelligence (AI) in the medicinal product lifecycle_240903". 
We would welcome globally aligned good machine learning principles, and a nimble approach from EMA 
to fill gaps in existing regulatory recommendations to encourage further investment in the use of AI/ML 
across drug development.” 
 
II. 
AI for personal productivity or automating processes and system 
a. EMA tools 
AI system 
Description 
Type of AI 
Status in the Agency  
 
ChatGPT@EMA 
Chat to provide GPT capabilities 
to EMA staff 
Personal productivity 
Under pilot 
Speech-to-
text 
Tool providing support with 
transcribing, translating and 
summarising the text from 
audio files and from the 
microphone input 
Speech services 
(Azure Cognitive 
Services), gen AI 
 
Under pilot 
Paralel 
Distribution 
Tool automating the 
comparison between the EPAR 
documents content and the 
Industry leaflet and labelling 
documents 
Azure AI Document 
Intelligence (Azure 
Cognitive Services) 
In production

## Page 6

2024 AI Observatory  
EMA/154528/2025  
Page 6/9
 
Anonymization 
tool 
Tool supporting anonymization 
of the personal data in the EMA 
corporate website comments 
NLP (Azure Cognitive 
Services) 
In production 
PDF Vendor 
Invoicing 
 
Tool to automate the extraction 
of EMA vendor invoice data and 
streamline the population of 
SAP.  
Azure AI Document 
Intelligence 
In production 
Automatic 
Referral 
Template 
Editor (ARTE) 
 
The ARTE application extracts 
automatically data from the 
FREUD database and inserts 
them it in the corresponding 
fields of the referral 
templates.    
Azure AI Document 
Intelligence 
In production 
Automated 
email 
distribution of 
invoices for 
OIAs 
operational 
approvals 
 
 
Azure AI Document 
Intelligence 
In production 
Commercially 
Confidential 
Information 
data 
automatic 
recognition 
tool (CCIDAR) 
The project goal for CCIDAR is 
to provide assessors (Access to 
Document team) a reliable tool 
for CCI search in all EPARs and 
public domain 
Azure AI Document 
Intelligence 
In development 
 
b. EMA Health Data Lab 
AI system 
Description 
Type of AI 
Status in the Agency  
EurEKA 
• 
Extracts and allows 
exploring ADR data from 
SmPCs 
Uses regex on top of a 
pre-trained ML model, 
LLM enabled  
EurEKA uses open data 
(EPAR/SmPC) 
Pilot, aiming to deploy 
in early 2025 
MNEMOSiNE 
• 
Structures, exposes and 
uses Signal detection 
tracking table to improve 
prioritization of signal 
review 
Discriminative and 
Generative AI (LLM) 
Pilot 
AERGIA 
• 
Automated adjudication of 
adverse reactions 
Discriminative AI  
Pilot

## Page 7

2024 AI Observatory  
EMA/154528/2025  
Page 7/9
 
ERATO 
• 
Supports screening of 
scientific literature for 
safety signals 
Generative AI 
Pilot, aiming to deploy 
in early 2025 
OWLS 
• 
Identifies case reports and 
case series in scientific 
literature to reduce 
duplicates in the EV 
database and generate case 
reports 
Discriminative AI 
Being maintained 
 
c. 
NCAs tools 
AI system 
Description 
Type of AI 
Status in owning 
Agency and others  
 
PHAIR: 
PHarmacovigilance 
by AI Real-time 
• 
All Danish health data 
from registries, EHR, 
GPs and DKMA ICSRs – 
transferred via FHIR 
and analysed on 
National Genome 
Centre HPC 
• 
Covid19 vaccine as 
initial use case 
• 
Uses technologies 
from Natural 
Language 
Processing – such 
as transformers 
and BERT 
 
DKMA 
Deploy LLama2-
chat on DKMA’s 
private cloud 
• 
Use cases for LLM: 
• 
Integrating 
datasources 
• 
Interactively search 
Docs 
• 
Build applications 
• 
Writing support 
• 
Personal assistance 
 
DKMA 
BMG-KIMERBA - 
intelligent in-
house automation 
of regulatory 
workflows 
• 
Medical information 
extraction in 
pharmacovigilance 
LLM 
PEI 
BMG-BLOODVIR - 
knowledge 
accumulation for 
AI assessment 
 
• 
Detection of viral 
contaminants in blood 
plasma 
LLM 
PEI

## Page 8

2024 AI Observatory  
EMA/154528/2025  
Page 8/9
 
BMG-RENUBIA - 
assessment and 
validation of AI-
based tools in 
medicinal products 
• 
Assessment of off-
target and neoantigen 
prediction 
LLM 
PEI 
Customized LLM 
applications to 
search from 
regulatory 
documents 
• 
The LLM based search 
engine will use both 
confidential and 
publicly available 
documents, such as 
EPAR, SmPC, AR, 
overview, Scientific 
Advice, Qualification 
opinion 
• 
Returns in addition to 
the answer, links to 
relevant documents -> 
actual documents will 
be used as reference 
and not the answer by 
the LLM 
LLM 
FIMEA 
M-RECON 
• 
As part of AI@MPA 
• 
Medicines regulatory 
context engine 
• 
Semantic matching 
between a document 
of choice and the 
openly available 
regulatory context 
• 
Currently vector 
database includes:  
o 
EMA guidelines, 
EPARs and EMA 
qualification 
opinions/letters 
o 
FDA regulatory 
guidance and product 
information 
 
MPA – in production  
PICROSS 
• 
As part of AI@MPA 
• 
Product information 
cross search 
 
MPA – in production 
PACKSIM 
• 
As part of AI@MPA 
LLM 
MPA – in production

## Page 9

2024 AI Observatory  
EMA/154528/2025  
Page 9/9
 
• 
Mock-up similarity 
search 
• 
Reducing medication 
errors by ensuring 
visual non-similarity 
among drug packages 
PhaVAI triage 
 
• 
As part of AI@MPA 
• 
AI model for triage of 
ADR reports, for 
detecting reports likely 
to be upgraded from 
non-serious to serious 
during assessment 
 
MPA – in production 
XLMeQA 
• 
Answer questions 
about medicine 
leaflets. 
LLM 
AEMPS 
NLP Platform 
• 
Development of 
components that allow 
improving the quality 
of AEMPS data sources 
LLM 
AEMPS 
MedDRA Terms 
 
• 
MedDRA terms 
discovery in AEMPS 
data sources. 
LLM 
AEMPS 
NLP approach to 
cluster text 
describing 
uncertainties 
Using an NLP approach on 
the European Public 
Assessment Reports 
NLP 
MEB


---

# Big Data Steering Group 2024 report

- **Issuer:** HMA
- **Type:** Report
- **Language:** en
- **Source:** https://www.ema.europa.eu/en/documents/report/big-data-steering-group-bdsg-2024-report_en.pdf
- **Licence:** EMA-reuse

## Page 1

Official address   Domenico Scarlattilaan 6   ● 1083 HS Amsterdam   ● The Netherlands 
 An agency of the European Union      
 
Address for visits and deliveries   Refer to www.ema.europa.eu/how-to-find-us  
Send us a question Go to www.ema.europa.eu/contact   Telephone +31 (0)88 781 6000 
© European Medicines Agency, 2024. Reproduction is authorised provided the source is acknowledged. 
 
                                     
 
13 December 2024 
EMA/471579/2024 
 
Big Data Steering Group (BDSG): 2024 report

## Page 2

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 2/17 
 
CONTENTS 
1. Introduction ......................................................................................................................... 3 
2. 2024 highlights ..................................................................................................................... 3 
3. Description of the 2024 highlights of the BDSG workplan ........................................................... 4 
4. Description of the 2024 highlights of the AI workplan .............................................................. 15

## Page 3

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 3/17 
 
1.  Introduction  
The Phase II report of the HMA-EMA joint Big Data Task Force (BDTF) and the proposal to establish a 
joint BDSG (superseding the Big Data Task Force) were endorsed by the Heads of Medicines Agencies 
(HMA) in November 2019 and EMA Management Board (EMA MB) in December 2019. The BDSG was 
established to advise HMA and EMA MB on the recommendations of the Big Data Task Force, covering 
human and veterinary medicines. The full mandate of BDSG can be found here.  
In 2024, significant progress continued to be seen in the transformation to a more data-driven 
regulation, in line with the Network Strategy to 2025 (in particular for the strategic theme 2 ‘Data 
analytics, digital tools and digital transformation’), the BDSG workplan, and the multi-annual AI 
workplan. 
The fourth BDSG workplan was published in July 2023 to progress the activities launched in 2020 and 
to address new topics. The Multi-annual AI workplan was published in December 2023. The midterm 
report of the Network Strategy to 2025 published in 2024 highlighted the good progress made during 
critical period of the pandemic. In 2024 the BDSG met 11 times virtually. 
This report provides a summary of the key activities and achievements of the BDSG in 2024 and 
includes the AI workplan delivery which falls under the BDSG’s responsibilities.  
“By delivering a regulatory system able to integrate Big Data into its assessment and 
decision making, we can support the development of innovative treatments more quickly 
and optimise the safe and effective use of medicines.” Big Data Task Force Final 
Report, January 2020 1 
2.  2024 highlights  
Figure 1 below provides a summary of the key BDSG highlights presented in the context of the priority 
recommendations of the BDSG workplan.  
  
 
 
1 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 4

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 4/17 
 
Figure 2 below provides a summary of the key BDSG highlights presented in the context of the AI 
workplan.  
  
3.  Description of the 2024 highlights of the BDSG workplan 
3.1.  Recommendation 1: DARWIN EU® 
DARWIN EU was launched in February 2022 with the establishment of the DARWIN EU ® coordination 
centre. DARWIN EU has continued to grow its real-world data (RWD) network throughout 2024. 
DARWIN EU is now instrumental in enabling EU network capacities to deliver valid and reliable 
evidence based on RWD studies to complement information from clinical trials and other sources of 
evidence and support regulatory decision making.  
DARWIN EU is now operational and can support more and more evaluation work of EMA's scientific 
committees and the national competent authorities. It can also support organisations such as 
the European Centre for Disease Prevention and Control, Health technology assessment bodies and 
payers with specific studies. 
During 2024, 10 additional data partners have been selected for on-boarding into the network, further 
expanding the network with additional geographies and data types. In total, 20 data partners are now 
providing access to 25 different data sources and to data from more 130 million patients from 13 
European countries. The list of newly onboarded data partners is published on the DARWIN EU website. 
The data partners generate real-world evidence (RWE) from sources such as hospitals, primary care 
practices, health insurances, registries and biobanks to support regulatory activities of EMA’s scientific 
committees and national regulators in the EU.  Study protocols and results of all DARWIN 
EU studies are publicly available in the new HMA-EMA Catalogue of RWD studies.   
DARWIN EU is now the main RWE generation pathway used by EMA to support regulatory decisions. In 
2024 (up to end of December), 62 research topics have been requested/offered and 18 studies have 
been completed via DARWIN EU. Since its launch, a total of 58 studies have been initiated. Of these 29 
are completed and 29 studies are ongoing. This includes 13 studies to inform vaccine safety and 
effectiveness, as well as studies in public health emergencies.

## Page 5

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 5/17 
 
The number of studies will be further scaled up with the yearly onboarding of new data partners up to 
a total of 40 data partners. The aim is to deliver close to 100 studies per year from 2025 onwards to 
enhance more data-driven decision making on medicines in the EU. 
DARWIN EU continued to be supported by the multi-stakeholder DARWIN EU Advisory Board to provide 
strategic advice and recommendations on DARWIN EU, its possible integration as a node within the 
European Health Data Space (EHDS), on how to ensure coordination and alignment with relevant 
European and EU Member State initiatives and policies, and on how to optimise communication on 
DARWIN EU with stakeholders. Agendas and minutes are published on the DARWIN EU ® webpage. 
As part of its continuous engagement with stakeholders and partners, two DARWIN EU training events 
were organised in 2024. Recordings are available on the EU Network Training Platform (EU NTC) as e-
learning for EMA and EU regulatory network only: 
• 
Darwin EU Spring School ‘Analyses conducted through the DARWIN EU Network’: to increase 
the understanding of different types of analyses conducted through the DARWIN EU Network. 
The training aimed to inform colleagues in the regulatory network, so they are better equipped 
with the knowledge and tools to support their conduct, review, and interpretation of the results 
in the context of their work. 
• 
DARWIN EU Autumn School: to give an overview of the analytics used in DARWIN EU including 
population-level disease epidemiology and cohort survival analysis. 
In 2024, DARWIN EU continue to take part in the EHDS2 pilot with a use case on coagulopathy and 
COVID-19. EMA also continued to engage with the EHDS ‘Joint Action’ to ensure alignment. 
Access to and analysis of real-world data complements evidence from randomised 
clinical trials to enable timely and reliable evidence for the development, authorisation 
and supervision of medicines for patients. Big Data Task Force Final Report, January 
20202 
3.2.  Recommendation 2: Data quality and representativeness 
The RWD quality chapter of the EU Data Quality Framework for EU medicines regulation has been 
released for public consultation in November 2024. The RWD chapter offers insights on key 
considerations for RWD quality including practical recommendations that cover characterisation of the 
systems and processes that underpin data. It also provides a set of metrics to assess data quality 
dimensions and a guideline on assessing data quality in relation to a research question. 
A chapter on Adverse Drug Reaction (ADR) data quality is in preparation for 2025. 
To support the preparation and implementation of the European Health Data Space (EHDS), BDSG also 
collaborated in 2024 with the QUANTUM project for HealthData@EU. The project aims at addressing 
the growing need for developing a data quality and utility framework to describe the characteristics 
and the potential usefulness of datasets that exist across Europe from multiple sources, and ultimately 
design and develop a data quality and utility label for the EHDS. 
 
2 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 6

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 6/17 
 
By understanding and increasing data quality, the selection of data and interpretation of 
study results is informed, and the evidentiary value of studies can be judged. Big Data 
Task Force Final Report, January 2020 3 
3.3.  Recommendation 3: Data discoverability 
HMA-EMA catalogues of real-world data sources and studies 
The new HMA-EMA catalogues of real-world data sources and studies were launched in February 2024. 
The catalogues help medicines regulators, researchers and pharmaceutical companies to identify the 
most suitable data sources to address specific research questions and support the assessment of study 
protocols and results. They promote transparency, encourage the use of good practices, and build trust 
in research based on RWD. 
The initiative builds on more than 15 years of operation of the former databases, developed by 
the European Network of Centres for Pharmacoepidemiology and Pharmacovigilance (ENCePP): 
• 
The catalogue for RWD sources enhances and replaces the ENCePP Resources Database, an 
EMA-coordinated index of resources of available research organisations, networks and data 
sources in the fields of pharmacoepidemiology and pharmacovigilance within Europe. 
• 
The catalogue for RWD studies expands and replaces the European Union electronic register of 
post-authorisation studies (EU PAS Register®). 
As part of this initiative, the ENCePP website has been renewed. While some data sources and all 
centres and networks have migrated to the new catalogues replacing the ENCePP Resource Database, 
other content, such as ENCePP Guide on Methodological Standards in Pharmacoepidemiology and the 
ENCePP Code of Conduct, remain available on the ENCePP website renewed in 2024. 
The new catalogues introduce various improvements. Aligning with ‘FAIR’ data principles for Findable, 
Accessible, Interoperable and Reusable data, they use an agreed set of metadata to describe and 
connect data sources to studies. This is based on the metadata list for real-world data sources and 
studies published by the HMA-EMA Big Data Steering group in 2022. In addition, search on a wider set 
of metadata, enhanced view, export and data submission functionalities have been implemented in the 
catalogues. 
As of October 2024, the RWD Catalogues contain 232 registered data sources and 2,943 studies 
geographically distributed across various regions of the world. Europe has the highest number of data 
source and study registrations, with Italy (60 data sources), the United Kingdom (60), Germany (59), 
and Spain (57) as the top countries leading in data sources. The United Kingdom (1,015 studies), 
Germany (880) and Spain (776) are the top three for study registrations. Outside of Europe, the most 
represented countries in data sources are the United States (16), Israel (14) and Australia (11) and for 
studies - the United States (715), Canada (207) and Japan (134). 
Stakeholder engagement continued in 2024 to collect detailed metadata on selected data sources, 
aiming to populate the catalogues with Real-World Data sources and non-interventional studies. All 
European data holders, marketing authorisation holders, networks, researchers, and institutions who 
are interested in having their data used for medicines regulation or are obligated by policy on non-
interventional post-authorisation safety studies (PASS), are continuously encouraged to register and 
keep information up to data in the catalogues.  
 
3 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 7

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 7/17 
 
These are accompanied in 2025 by the final Good Practice Guide for the use of the Metadata Catalogue 
of Real-World Data Sources and user guide.  
Patient experience data, mobile health data and social media data 
Reinforcing patient relevance in evidence generation is a key priority in the EMA’s Network Strategy 
and the realisation of a data-driven regulatory network. In 2024, BDSG discussed the reflection paper 
on the best EU approach to define, generate, collect and analyse Patient Experience Data (PED), in 
anticipation of a public consultation in early 2025.  
In 2024, to continue to keep abreast with technological and methodological changes, the BDSG 
discussed the utility of mobile health (mHealth) data and social media data to support regulatory 
decision-making. BDSG published two expert reviews exploring the utility of mobile health data and 
social media data, when collected in real-world settings, such as clinical care or the daily life of 
patients. 
Acknowledging challenges in terms of data quality and protection of patient privacy, mHealth tools 
such as smartphones, health applications, smartwatches and other wearables can generate a large 
variety of detailed patient data like heart rate and body temperature, and was found to be useful as a 
complementary source of data for EU medicine regulation in three domains: 1) to support planning and 
validity of applicant studies, 2) to support the understanding of clinical context, and 3) to investigate 
associations of products on safety and efficacy outcomes and impacts of regulatory actions. 
Despite challenges related to access, quality and ethical use of social media data, various patient data 
can be extracted from social media, including demographic data, patient experience data (PED), and 
data related to drug use and disease factors. In some specific cases, such as medicine abuse / misuse 
or misinformation, social media data might be used as a complementary source of evidence. The BDSG 
and its successor, the Network Data Steering Group (NDSG) will continue to monitor progress in this 
area.  
Finally, the reports propose a set of points for consideration for future actions to increase the utility of 
mHealth data and social media data in regulatory decision-making.  
Agreement on metadata to describe and identify data sets is enabling data 
discoverability (including through a publicly available catalogue of real-world datasets) 
and increasing the ability to judge the evidentiary value of non-interventional 
(observational) studies and real-world data sources. Big Data Task Force Final 
Report, January 2020 4 
3.4.  Recommendation 4: EU Network skills in Big Data 
The Big Data Training Signpost was updated in 2024 to provide a helpful resource listing all existing EU 
NTC trainings in biostatistics, pharmacoepidemiology, data science and pharmacogenomics (Link for 
NCAs | Link for EMA). 
After last year’s launch of the Big Data training curricula with the rollout of the first two modules 
related to the Pharmacoepidemiology and Real-World Evidence (RWE) domain, two additional modules 
have been rolled out in 2024 on ‘Study protocol and reporting’ and ‘Statistical methods applied to RWE’ 
(Link for NCAs | Link for EMA). 
 
4 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 8

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 8/17 
 
The Study protocol and reporting module covers essential aspects of pharmacoepidemiologic/real-
world studies, including research question and study feasibility, study design, statistical analysis plan, 
quality control for data extraction, transformation and analysis, scientific independence and 
transparency, and reporting of studies and publication. The Statistical methods applied to RWE module 
covers specific statistical applications for non-interventional studies, combining different real-world 
data sources and longitudinal analyses. 
The RWE curriculum is complemented by the Real-World Academy (RWA), which provides a forum for 
discussion and exchange for network experts. In 2024 four events took place, discussing a registry-
based study on SMA, data quality in RWE, data reliability in DARWIN EU ® and RWD in paediatrics.  
The first training modules of the Data Science curriculum have also been made available in 2024. The 
five modules introduce various data science topics and their application in medicines regulation, 
including big data, data management and data visualization and Artificial Intelligence.  
The Data Science curriculum is complemented by the Digital Academy, offering a collection of learning 
opportunities on AI and Data literacy (managing, collecting and analysing data) (Link for NCAs | Link 
for EMA). 
Overseen by the Methodology Working Party, all the training modules and event recordings are 
available to the EU medicines regulatory network’s staff through the EU Network Training Platform (EU 
NTC). Further training modules will be published in 2025. Work is also ongoing on the development of 
a Genomic data curriculum, its outline was agreed with MWP in December 2024. 
Training is supporting the development of an expert workforce able to advise on and 
interpret big data. Big Data Task Force Final Report, January 2020 5 
3.5.  Recommendation 5: EU Network processes  
Real world evidence 
In 2024, EMA has published a summary guide for EU regulators and decision-makers on how the 
Agency can support the delivery of regulator-lead RWE to aid decision-making. The guide includes 
descriptions of the available types of RWD studies, optimal resources for addressing research questions 
and details about the process for requesting these studies. 
The second report on conducting studies with real-world data was published in 2024, based on 
experience gathered between February 2023 and February 2024. Learnings not only from DARWIN 
EU® studies but also from other pathways used to generate RWD studies, the report highlights the 
European Medicines Regulatory Network's continued efforts to better integrate RWE into regulatory 
decisions on medicine development, authorisation and monitoring. It provides in addition a progress 
update on new studies, expanded data partners, and further recommendations and actions. 
During the reporting period, 60 new research topics were identified, of which 38 (63%) were triaged 
via the DARWIN EU pathway, 16 (27%) via the in-house study pathway, and 6 (10%) via the procured 
studies pathway. A total of 40 studies were conducted, out of which 22 have been completed while 18 
were still ongoing. These studies support an extensive range of decision-makers, including EMA’s six 
scientific committees, EMA’s working parties, national competent authorities, as well as the European 
Centre for Disease Prevention and Control (ECDC), Health Technology Assessment (HTA) and payers’ 
organisations and the European Commission. 
 
5 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 9

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 9/17 
 
For the first time studies were initiated to inform shortage prevention work of critical human 
medicines, on herbal substances, for HTA and payer organisations, and to support EMA’s geriatric 
medicines strategy.  
The report also includes a list of all new studies considered during the reporting period, an updated 
portfolio of use cases, and information on a survey on the use of RWD at national level. 
To ensure high quality decision making in this rapidly developing environment, the MWP launched in 
Q3 2024 the public consultation on the reflection paper on use of real-world data in non-interventional 
studies to generate real-world evidence  for regulatory purposes. It is aimed at all stakeholders 
involved in the planning, conduct and analysis of this type of non-interventional studies, 
including marketing authorisation holders and applicants. The final reflection paper will be published in 
2025. 
Patient experience data and genomic data use cases 
Use cases for Patient Experience Data (PED) have been discussed in the context of the reflection paper 
on the best EU approach to define, generate, collect and analyse PED, ahead of the launch of the public 
consultation in early 2025 (see section 3.3). 
Use cases for genomic data have been discussed in the context of the joint EC/HMA/EMA multi-
stakeholder workshop on pharmacogenomics held in September 2024 (see section 3.10). 
Learning from pilots is informing process improvement, guidance development and the 
establishment of evidentiary value. Enabling high quality and rapid assessment of 
medicines will improve decision making throughout the lifecycle of medicines and 
additionally support greater preparedness for health crisis response. Big Data Task 
Force Final Report, January 20206 
3.6.  Recommendation 6: EU Network capability to analyse Big Data 
Clinical study data pilot 
Launched in 2022, the clinical study data pilot (formerly known as raw data pilot) investigates the 
benefits of visualising and analysing clinical study data to support the scientific assessment of 
medicinal products. The clinical study data are submitted voluntarily by applicants or marketing 
authorisation holders as part of their respective applications. 
The interim report of the pilot was published in September 2024. It offers preliminary insights into the 
regulatory benefits of including clinical study data in the marketing authorisation application dossier, 
potentially leading to earlier opinion and authorisation of medicines. It also examines the operational 
and technical practicalities for future systematic submission of clinical study data as part of the 
marketing authorisation dossier. Particular focus is given to analyses supporting the assessment 
(clinical efficacy and safety but also pharmacokinetics and pharmacodynamics, PK-PD) and related 
decision-making. Furthermore, the pilot includes analyses to guide the selection of trial sites to verify 
compliance with Good Clinical Practice (GCP). Experience gained with submission and analysis of 
patient-level data from clinical studies conducted between September 2022 and December 2023 was 
included in the interim report. 
Based on the initial insights from the pilot including early evidence of the potential for such data 
analysis to speed up the authorisation of new medicines, EMRN has decided to extend the pilot's 
 
6 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 10

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 10/17 
 
duration and pilot participation requests from pharmaceutical industry will continue to be accepted 
until further notice. Guidance for industry has also been updated to reflect the new timelines and 
interim lesson learned. As of December 2024, nine regulatory procedures have been selected for the 
pilot.  
The pilot continues to be supported by the Network Advisory Group on Raw Data and the Industry 
Focus Group on Raw Data. Support to MAH has been important, and in 2023 EMA published the 
application of EMA’s transparency principles to the clinical study data proof-of-concept pilot. The 
Network Community on Raw Data has also been established in 2023. 
Non-Clinical raw data 
The EMA Proof of Concept (PoC) study to evaluate implementation of the Standard for Exchange of 
Nonclinical Data (SEND) was launched in 2023. The PoC is looking at how SEND could improve the 
quality and efficiency of routine assessment but also of procedures where data is complex and requires 
visualization or independent analysis. The PoC is also looking at how it could be useful for procedures 
where rapid regulatory input is needed (e.g. rolling review, accelerated procedures, PRIME) and for 
regulatory science projects or read-across activities to facilitate harmonization, policy or guideline 
recommendations. The first Marketing Authorisation Application with SEND data was received in 
September 2024. 
Additional analytics initiatives 
A survey of the EMRN was conducted in Spring 2024 to explore the type of data currently accessed and 
available to each NCA, assess the existing demands to analyse data and measure the current 
computing capabilities, including AI, across the network. The survey focused on data used for 
regulatory decision making (excluding corporate data) and on technical computing capacities 
(excluding resourcing) and applied to the Human and Veterinary medicines domains. The results 
showed an appetite within the EMRN for fostering data access and sharing between agencies and 
developing analytics capabilities at EU level. The feedback from this survey will inform the 
development of the new Network Data Steering Group workplan and revised AI workplan in 2025. 
Some of the recommendations, complementary to the Raw Data pilot report recommendations, will 
also be considered for the potential drafting of an EMRN data analytics strategy in 2025.  
An update on the AI work overseen by the BDSG is provided in section 4. 
Demonstrating value of raw data analysis and fostering knowledge and expertise within 
EU network is key to enable high quality and rapid assessment of medicines. Big Data 
Task Force Final Report, January 2020 7 
3.7.  Recommendation 7: Delivery of expert advice 
The Methodology Working Party (MWP) was established in 2022 and is now updating its 3-year 
workplan (3rd version was opened for public consultation in Q3 2024 and adopted in November 2024).  
The methodology European Specialist Expert Community (ESEC) has been established with 209 
experts from more than 21 European countries including EMA. The ESEC strengthens the MWP, 
bringing together a broad range of expertise organized in Specialised Interest areas that includes: 
• 
Ai & Data Science: 62 experts 
 
7 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 11

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 11/17 
 
• 
Biostatistics: 80 experts 
• 
Clinical Pharmacology: 77 experts 
• 
Modelling & Simulation: 59 experts 
• 
Pharmacogenomics: 28 experts 
• 
Real World Data: 88 experts 
The MWP launched in Q3 2024 the public consultation on the reflection paper on use of real-world data 
in non-interventional studies to generate real-world evidence  for regulatory purposes (refer to section 
3.5) and publish the reflection paper on the use of artificial intelligence (AI) in the medicinal 
product lifecycle in 2024 (refer to section 4.1). The development of guidance on RWE and AI will be 
initiated in 2025 as part of the delivery of the MWP workplan. 
Expert advice including on advanced analytics, real world evidence and ‘omics is 
empowering robust assessment and decision-making by regulatory committees. Big 
Data Task Force Final Report, January 2020 8 
3.8.  Recommendation 8: Governance framework 
Informed by the input of experts from the Big Data Steering Group (BDSG) and the Network Data 
Board (NDB), the Network data strategy was launched for public consultation in Q4 2024. The Network 
strategy aims to provide the vision, principles and objectives for implementing effective data 
management so that the EMRN can be transformed into a data-driven regulatory ecosystem that 
promotes innovation, efficiency, and better coordinated decision-making among national authorities 
and the EMA. They key strategic objectives of the strategy are related to data governance, data quality 
management, Interoperability, data cataloguing and metadata management, knowledge and change 
management, and analysis of data. 
In 2024, the Network data governance was also reviewed. A decision was taken to unify the two 
existing data governance groups, the BDSG and the NDB into one network data governance group, the 
Network Data Steering Group (NDSG). The mandate of the NDSG was endorsed by HMA at its 
September 2024 meeting and EMA Management Board at its October 2024 meeting. 
The NDSG will support the delivery of the EMAN Strategy to 2028 (including Theme 2: Leverage data, 
digitalization and AI) and of the EMRN Data strategy, both currently under public consultation.  
Like the BDSG, the NDSG will be a strategic advisory group established to maximise data 
interoperability, exchange and use across the EU network, the access to data and generation of 
evidence, and the beneficial utilisation of AI. The NDSG will make proposals and give advice to HMA 
and EMA Management Board for the prioritisation, planning and monitoring of actions relevant to the 
EMAN strategy to 2028 (particularly its Theme 2: Leverage Data, Digitalisation and AI) and the EMA 
multi-annual workplan. Its scope will encompass regulatory data, including supply data, and data 
supporting evidence on medicines. 
Building on the model of the BDSG, its mandate will also include stakeholders’ engagement and 
network capability/capacity activities. It will continue to be co-chaired between EMA and HMA and its 
members will represent NCAs, EMA, EC as well as key stakeholders (however interaction with Industry 
 
8 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 12

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 12/17 
 
will be via regular bilateral meetings). The group will be appointed until end of 2028, in line with 
EMANS to 2028. 
The BDSG continued to prepare for a changing policy environment with the future European Health 
Data Space (EHDS) and the revised Pharmaceutical Strategy for Europe via regular updates from the 
European Commission and participation to various fora and workshops.  
Secure and ethical data governance is an enabler for secondary use of healthcare data 
and the work of the BDSG seeks to support stakeholders to navigate and comply. Big 
Data Task Force Final Report, January 2020 9 
3.9.  Recommendation 9: International initiatives  
Progress in convergence with international partners on RWD/RWE continued in 2024 and contributed to 
establish the value of RWE and enabling its use.  
In June 2024, following a 3-month public consultation, the Council for Harmonisation of Technical 
Requirements for Pharmaceuticals for Human Use (ICH) Assembly adopted a reflection paper called 
“Pursuing Opportunities for Harmonization in Using Real-World Data to Generate Real-World Evidence, 
with a focus on Effectiveness of Medicines”.  
In November 2024 the related new topic proposal entitled “Considerations for the Use of Real-World 
Evidence (RWE) to Inform Regulatory Decision Making with a focus on Effectiveness of Medicines” was 
sent to ICH. The aim of this proposal is to harmonise RWD/RWE terminologies, metadata and establish 
general principles for assessing studies using RWD to support regulatory decision-making worldwide.  
The reflection paper as well as the proposal was co-developed by EMA, FDA and Health Canada 
following a joint statement by ICMRA calling for international collaboration in generating and using 
real-word evidence in regulatory decision making. This marks an important commitment from ICH 
towards harmonisation of regulatory RWE guidance. 
In 2024, the public consultation on the ICH M14 draft guideline on general principles on plan, design 
and analysis of pharmaco-epidemiological studies that utilize real-world data for safety assessment of 
medicines was launched. The draft guideline provides internationally harmonised guidance, 
recommendations and best practices for the conduct of pharmaco-epidemiological studies using real-
world data for the assessment of the safety of medicines. The aim is to streamline the development 
and regulatory assessment of study protocols and reports and make them more acceptable to health 
authorities worldwide. An overview of the comments received is published on EMA website. 
In addition, the former “COVID-19 Real-World Evidence Observational Studies Working Group (WG)” 
published in November the paper Collaborative Real-World Evidence Among Regulators: Lessons and 
Perspectives reflecting on 3 years of collaboration. The WG has been repurposed as “Real-World 
Evidence for Public Health Emergencies (PHE) Working Group”. It is co-chaired by EMA and Health 
Canada. The first meeting took place in July 2024 with fifteen regulatory agencies, and the second 
meeting took place in December 2024. The WG aims to be a global forum for regulators to enhance the 
efficiency and effectiveness of responses to PHEs by conducting collaborative RWD studies. The 
members are currently working on the development of general principles and operational aspects for 
conducting collaborative studies, as well as on a list of potential topics of interest to test the system. 
 
9 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 13

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 13/17 
 
The digital transformation of clinical trial information is currently being strengthened with initiatives 
such as the digital protocol (ICH M11) or the Patient Level Data Project. One critical aspect of this 
transformation is the need for global standard for passing data between systems. Fast Healthcare 
Interoperability Resources (FHIR) is currently being developed as a free and open source to enable the 
data transfer of protocol data and can be applied to summary results in the domain of interventional 
trials. Learnings from this initiative will likely benefit the technical solutions for non-interventional 
studies. 
Finally, in 2024, BDSG discussed the ICH M15 guideline on general principles for model-informed drug 
development. This guideline defines an harmonised framework for evaluating model-informed drug 
development (MIDD) evidence and provides recommendations for related planning and regulatory 
interactions, implementation, reporting, and submission. The guideline is under public consultation 
until February 2025. 
Convergence with international partners on standards and guidelines will leverage best 
expertise and minimise burden on stakeholders. Big Data Task Force Final Report, 
January 202010 
3.10.  Recommendation 10: Stakeholder engagement 
Collaborations with external stakeholders and partners continued in 2024 and informed the work of the 
BDSG. 
BDSG supported the organisation of the joint HMA/EMA ACT EU Clinical Trials Analytics Workshop in 
January 2024 to discuss use cases for analysis of data about clinical trials in the EU through clinical 
trial registries (CTIS and EudraCT) and to help guide EU decision-makers on improving access and 
usability of clinical trials data. 
The joint HMA/EMA multistakeholder workshop on patient registries was held in February 2024 to 
discuss the EMA qualification procedure for patient registries (with the aim to clarify the benefits, 
identify current limitations, and propose measures to optimise the process) and establish the value and 
enable the use of patient registries for regulatory decision-making by considering contexts of use for 
which registry data are ‘fit for purpose’, and examining tools to support data discoverability and 
assessment. Outcomes linked to qualification of registries will be implemented through the action plan 
for the future proofing Qualification of Novel Methodolgies published in September 2024. 
The joint HMA/EMA multi-stakeholder workshop on data quality framework for adverse drug 
reaction reporting was held in March 2024 to bring together experts in the field to build on their 
extensive experience and knowledge relating to ADR data quality, and inform the drafting of the next 
chapter of the data quality framework for EU medicine regulation. 
The joint HMA/EMA Big Data Steering Group workshop on real-world evidence (RWE) methods was 
held in June 2024 to collect views of stakeholders and experts on the draft RWE reflection paper and 
on priorities for further regulatory guidance development and collaboration beyond the reflection 
paper. 
The joint EC/HMA/EMA multi-stakeholder workshop on pharmacogenomics was held in September 
2024 to identify priority areas for additional regulatory action to promote the clinical implementation of 
pharmacogenomics, discuss how medicines regulators can facilitate the uptake of genomics by national 
healthcare systems, how to leverage genomic data linked to real-world data sources with examples of 
 
10 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 14

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 14/17 
 
current studies using such data, and how to increase the regulatory impact of EU-funded projects in 
personalised medicine. The outcome of the workshop will inform a roadmap towards the clinical 
implementation of pharmacogenomics in Europe. 
The joint HMA/EMA multi-stakeholder workshop on artificial intelligence (AI) - enabling the safe and 
responsible use of AI was held in November 2024 to update stakeholders on the state-of-the-art of AI 
developments, policy and legislative environment and the revision of the AI reflection paper, and 
HMA/EMA activities conducted under the multi-annual AI workplan. The outcome of the workshop will 
inform the revision of the multi-annual AI workplan and the drafting of AI network research priorities 
roadmap. 
The fifth annual joint HMA/EMA Big Data Stakeholder Forum was held in November 2024 to discuss 
progress on evidence generation, interoperability, use and exchange of medicines data across the EU 
network, and inform the future work planning of the group. 
The Methodology Working Party Interested Parties meeting took place on June 2024, including industry 
to give stakeholders the opportunity to raise and share reflections on relevant methodological topics 
and for MWP to identify gaps in its workplan with the aim of prioritising guideline development 
accordingly.  
Two dedicated BDSG industry stakeholder meetings (in May and November 2024) were organised in 
the context of EMA’s continuous endeavours to foster regular interactions with industry stakeholders 
on topics of common interest. Agenda and minutes are published on EMA website. A specific Industry 
focus group on RWE was established in 2024 to share knowledge and experience with use 
of RWD and generation of RWE to advance integration of relevant and reliable RWE 
in regulatory decision making. 
The EMA Big data newsletter, published 4 times in 2024, has provided an update on progress in 
implementing the workplan of the HMA-EMA Big Data Steering Group. 
The BDSG is assessing communication and engagement efforts with partners and stakeholders via a 
survey launched in September 2024. 
The BDSG agreed the change management strategy that includes the key changes to a more data-
driven medicines regulation, the key stakeholder groups and the approach to engage them, the change 
management activities delivery plan, and the actors responsible for executing the strategy. The 
Change management activities delivery plan was published in July 2024. 
Listening to stakeholders and leveraging their work is optimising and maximising 
transformation to data-driven regulation. Transparency and communication build trust in 
what is delivered. Big Data Task Force Final Report, January 2020 11 
3.11.  Recommendation 11: Veterinary recommendations 
The last 12 months have seen great progress in the implementation of the European Veterinary Big 
Data strategy 2022- 2027. The overall strategy implementation is on schedule, and delivery highlights 
include:  
 
11 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 15

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 15/17 
 
• 
Completion of the ‘Big Data in Veterinary Medicines Regulation: A Data Landscape Analysis’ 
study which mapped the veterinary data landscape and identified veterinary real world data 
sources.  
• 
The go-live of Data Literacy training on the EUNTC platform (Link for NCAs | Link for EMA). 
• 
The Union Product Database (UPD) Data Quality Framework has been in production for 1 year, 
reducing the number of UPD data quality issues by 40%. 
The next iteration of the EU Veterinary Big Data Workplan to 2022-2025, which details work items 
from 2025 to 2027 is being developed in partnership with the Veterinary Data Hub. The Veterinary 
data hub is a multi-disciplinary team of Network experts from Belgium, France, Germany, Portugal, 
Spain and Sweden. Industry stakeholders have also contributed thoughts on the EU Veterinary Big 
Data workplan scope.  
The fourth Veterinary big data stakeholder forum was held in October 2024. The agenda covered 
several topics of focus in the big data domain. The event highlighted the transformational opportunities 
in the lifecycle of veterinary medicinal product regulation enabled by big data.  There were active 
contributions from industry, academia and the regulatory network with presentations on the Veterinary 
Big Data strategy implementation, use of AI by the Industry and a horizon scan of themes arising in 
the big data and AI domain.  
Synergies exist in the use of data between the human and veterinary domains that can 
catalyse our transformation. Big Data Task Force Final Report, January 202012 
4.  Description of the 2024 highlights of the AI workplan  
4.1.  Guidance, policy and product support 
Guiding principles on the use of large language models (LLM) in regulatory science and for medicines 
regulatory activities were published in September 2024 and are now available for the Network staff on 
how to use large language models in their work. They can help staff in areas such as processing 
extensive documentation, automating data mining and optimising routine administrative tasks. They 
also present challenges such as providing irrelevant or inaccurate responses and posing potential data 
security risks. They focus on LLM for text generation. This document aims to promote the safe, 
responsible and effective use of this category of AI technology. The guiding principles are a living 
document that will be regularly updated.  
This has been supported by an information campaign that included the factsheet: Four principles for 
safe and responsible use of large language models and a masterclass (see section 4.3) 
Following the public consultation, the final reflection paper on the use of artificial intelligence (AI) in 
the medicinal product lifecycle  was published on 30 September 2024. This paper reflects on principles 
relevant to the application of AI and machine learning (ML) at any step of a medicines’ lifecycle, from 
drug discovery to the post-authorisation setting. 
Preparatory work to implement the AI Act and to establish an Observatory, that includes horizon 
scanning on AI, has started in 2024. 
 
12 HMA-EMA Joint Big Data Taskforce Phase II report: Evolving Data-Driven Regulation

## Page 16

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 16/17 
 
4.2.  Tools and technologies 
In 2024, BDSG continued to be a place to discuss national AI initiatives in particular two national 
initiatives from Sweeden (AI@MPA) and Belgium (ERAMET project). 
Launched in March 2024, Scientific Explorer is an AI enabled knowledge mining solution for EU 
regulators that facilitate easy, focused and precise searches of regulatory scientific information from 
network's sources. It supports scientific decision-making by providing access to relevant scientific 
information. The first release is dedicated to scientific advice procedures for human medicines.  
The AI@MPA tool is a web-based service provided by the Swedish Medicines Agency to the European 
Medicines Agency (EMA) and other national competent authorities (NCA). It uses artificial intelligence 
to help assessors to search and identify relevant guidelines, EPARs (European Public Assessment 
Reports), qualification opinions and SmPC (Summary of Product Characteristics). 
 
The survey for collecting feedback from EMRN on current and desired analytics capabilities is described 
in section 3.6 of this document. 
A survey to the EU regulatory network has been launched in December 2024 to identify potential use 
cases and national solutions/initiatives on AI, that have already been implemented or planned to be 
implemented, and for which their use could be extended to the entire regulatory network. The results 
of the survey will aid to define a collaborative framework across the network to develop and utilise AI 
tools for enhancing medicines evaluation processes. It will also inform the development of the 
Knowledge Mining network's roadmap to be completed in 2025.  
4.3.  Collaboration and change management 
Collaboration with stakeholders and partners continued in 2024 and international level and under the 
umbrella of the International Coalition of Medicines Regulatory Authorities (ICMRA). At European Union 
level, EMA has started chairing the EU Agencies Network Working Group (EUAN WG) on AI. The WG 
aims to support the agencies network on the implementation of AI fostering knowledge sharing and 
increasing the AI maturity level to provide guidance and common approaches. As main activity during 
the year, a physical workshop with all the members of the WG was held in September 2024 at EMA 
premises, onboarding new agencies and helping to shape a workplan for the coming years. The event 
primarily focused on knowledge-sharing sessions and included various exercises aimed at 
collaboratively preparing the future Community/WG AI workplan. It featured updates on current AI use 
cases, presentations from community members, and inspiring talks from external speakers. The event 
showcased the strong partnerships and unique capabilities within the Community/WG, highlighting the 
importance of collaboration among members, with all participants united in their efforts to shape the 
community’s future. 
The European Specialised Expert Community (ESEC) of the EMA Methodology Working Party (MWP) is 
now fully established and the 62 members of the Special Interest Area (SIA) on AI started to work 
together, meeting virtually for the 1st time in 2024. It now provides a Network community of practice 
as a forum for collaboration and knowledge sharing.  
In addition to the rollout of the Data Science curriculum in 2024 (see section 3.4 of this document), 
two AI Masterclasses on the use of Large Language Models (I) and Hands on with the guiding principles 
on the use of LLMs (II) were delivered for the EU network in 2024. Recording of both masterclasses 
are available on the EUNTC platform.

## Page 17

Big Data Steering Group (BDSG): 2024 report  
EMA/471579/2024  
Page 17/17 
 
The joint HMA/EMA multi-stakeholder workshop on artificial intelligence (AI) - enabling the safe and 
responsible use of AI was held in November 2024. This event was attended by approximately 1700 
online participants and by around 70 in person attendees (See also section 3.10 of this document). The 
outcome of the workshop will inform the revision of the multi-annual AI workplan and the drafting of AI 
network research priorities roadmap. 
4.4.  Experimentation 
The first AI Technical Deep Dive for the network on explainability and transparency took place in 
October 2024. 
Informed by the discussion at the joint HMA/EMA multi-stakeholder workshop on artificial intelligence 
(AI) - enabling the safe and responsible use of AI, the drafting of the AI network research priorities 
roadmap will start in 2025, and experimentation cycles will be launched in line with those priorities.


---

# EDPB: AI privacy risks and mitigations in large language models

- **Issuer:** EU institutions (other)
- **Type:** Report
- **Language:** en
- **Source:** https://www.edpb.europa.eu/system/files/2025-04/ai-privacy-risks-and-mitigations-in-llms.pdf
- **Licence:** EU-reuse

## Page 1 (Section: AI Privacy Risks and Mitigations in LLMs_FINAL2)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
 
 
  
 
 
 
AI Privacy Risks & Mitigations 
Large Language Models (LLMs) 
 
By Isabel BARBERÁ  
 
SUPPORT POOL 
OF EXPERTS PROGRAMME

## Page 2 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
2 
 
 
 
 
 
 
 
 
 
 
 
 
As part of the SPE programme, the EDPB may commission contractors to provide reports and tools on 
specific topics. 
The views expressed in the deliverables are those of their authors and they do not necessarily reflect 
the official position of the EDPB. The EDPB does not guarantee the accuracy of the information 
included in the deliverables. Neither the EDPB nor any person acting on the EDPB’s behalf may be held 
responsible for any use that may be made of the information contained in the deliverables. 
Some excerpts may be redacted or removed from the deliverables as their publication would 
undermine the protection of legitimate interests, including, inter alia, the privacy and integrity of an 
individual regarding the protection of personal data in accordance with Regulation (EU) 2018/1725 
and/or the commercial interests of a natural or legal person. 
 
 
 
 
 
 
 
 
Document submitted in February 2025, updated in March 2025

## Page 3 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
3 
 
TABLE OF CONTENTS: 
1. 
How To Use This Document ..................................................................................................................................... 4 
Structure and Content Overview .......................................................................................................................................... 4 
Guidance for Readers ........................................................................................................................................................... 5 
2. 
Background.............................................................................................................................................................. 6 
What Are Large Language Models? ...................................................................................................................................... 6 
How Do Large Language Models Work? ............................................................................................................................... 6 
Emerging LLM Technologies: The Rise of Agentic AI .......................................................................................................... 12 
Common Uses of LLM Systems ........................................................................................................................................... 15 
Performance Measures for LLMs ........................................................................................................................................ 18 
3. 
Data Flow and Associated Privacy Risks in LLM Systems......................................................................................... 24 
The Importance of the AI Lifecycle in Privacy Risk Management ....................................................................................... 24 
Data Flow and Privacy Risks per LLM Service Model .......................................................................................................... 26 
Roles in LLMs Service Models According to the AI Act and the GDPR ................................................................................ 43 
4. 
Data Protection and Privacy Risk Assessment: Risk Identification .......................................................................... 48 
Criteria to Consider when Identifying Risks ........................................................................................................................ 48 
Examples of Privacy Risks in LLM Systems .......................................................................................................................... 51 
5. 
Data Protection and Privacy Risk Assessment: Risk Estimation & Evaluation .......................................................... 57 
From Risk Identification to Risk Evaluation......................................................................................................................... 57 
Criteria to Establish the Probability of Risks in LLM Systems .............................................................................................. 58 
Criteria to Establish the Severity of Risks in LLM Systems .................................................................................................. 60 
Risk Evaluation: Classification of Risks ................................................................................................................................ 65 
6. 
Data Protection and Privacy Risk Control ............................................................................................................... 66 
Risk Treatment Criteria ....................................................................................................................................................... 66 
Example of Mitigation Measures Related to Risks of LLM Systems .................................................................................... 67 
7. 
Residual Risk Evaluation ........................................................................................................................................ 74 
Identify, Analyze and Evaluate Residual Risk ...................................................................................................................... 74 
8. 
Review & Monitor ................................................................................................................................................. 75 
Risk Management Process Review ..................................................................................................................................... 75 
Continuous Monitoring ....................................................................................................................................................... 75 
9. 
Examples of LLM Systems’ Risk Assessments ......................................................................................................... 80 
First Use Case: A Virtual Assistant (Chatbot) for Customer Queries ................................................................................... 80 
Second Use Case: LLM System for Monitoring and Supporting Student Progress.............................................................. 91 
Third Use Case: AI Assistant for Travel and Schedule Management .................................................................................. 94 
10. 
Reference to Tools, Methodologies, Benchmarks and Guidance ........................................................................ 97 
Evaluation Metrics for LLMs ............................................................................................................................................... 97 
Other Tools and Guidance .................................................................................................................................................. 99 
 
Disclaimer by the Author: The examples and references to companies included in this report are provided for illustrative purposes only and 
do not imply endorsement or suggest that they represent the sole or best options available. While this report strives to provide thorough 
and insightful information, it is not exhaustive. The technology analysis reflects the state of the art as of March 2025 and is based on 
extensive research, referenced sources, and the author's expertise. For transparency reasons, the author wants to inform the reader that a 
LLM system has been used for the exclusive purpose of improving the readability and formatting of parts of the text.

## Page 4 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
4 
 
1. How To Use This Document 
This document provides practical guidance and tools for developers and users of Large Language 
Model (LLM) based systems to manage privacy risks associated with these technologies. 
The risk management methodology outlined in this document is designed to help developers and 
users systematically identify, assess, and mitigate privacy and data protection risks, supporting the 
responsible development and deployment of LLM systems. 
This guidance also supports the requirements of the GDPR Article 25 Data protection by design and by 
default and Article 32 Security of processing by offering technical and organizational measures to help 
ensure an appropriate level of security and data protection. However, the guidance is not intended to 
replace a Data Protection Impact Assessment (DPIA) as required under Article 35 of the GDPR. Instead, 
it complements the DPIA process by addressing privacy risks specific to LLM systems, thereby 
enhancing the robustness of such assessments. 
Structure and Content Overview 
The document is structured to guide readers through key technological concepts, the risk 
management process, main risks and mitigation measures and practical examples. It aims to support 
organizations in deploying LLM-based systems responsibly while identifying and mitigating privacy and 
data protection risks to individuals. 
Below is an overview of the document’s structure and the topics covered in each section: 
2. Background 
This section introduces Large Language Models, how they work, and their common applications. It also 
discusses performance evaluation measures, helping readers understand the foundational aspects of 
LLM systems. 
3. Data Flow and Associated Privacy Risks in LLM Systems 
Here, we explore how privacy risks emerge across different LLM service models, emphasizing the 
importance of understanding data flows throughout the AI lifecycle. This section also identifies risks 
and mitigations and examines roles and responsibilities under the AI Act and the GDPR. 
4. Data Protection and Privacy Risk Assessment: Risk Identification 
This section outlines criteria for identifying risks and provides examples of privacy risks specific to LLM 
systems. Developers and users can use this section as a starting point for identifying risks in their own 
systems.  
5. Data Protection and Privacy Risk Assessment: Risk Estimation & Evaluation 
Guidance on how to analyse, classify and assess privacy risks is provided here, with criteria for 
evaluating both the probability and severity of risks. This section explains how to derive a final risk 
evaluation to prioritize mitigation efforts effectively.  
6. Data Protection and Privacy Risk Control 
This section details risk treatment strategies, offering practical mitigation measures for common 
privacy risks in LLM systems. It also discusses residual risk acceptance and the iterative nature of risk 
management in AI systems.

## Page 5 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
5 
 
7. Residual Risk Evaluation 
Evaluating residual risks after mitigation is essential to ensure risks fall within acceptable thresholds 
and do not require further action. This section outlines how residual risks are evaluated to determine 
whether additional mitigation is needed or if the model or LLM system is ready for deployment. 
8. Review & Monitor 
This section covers the importance of reviewing risk management activities and maintaining a risk 
register. It also highlights the importance of continuous monitoring to detect emerging risks, assess 
real-world impact, and refine mitigation strategies. 
9. Examples of LLM Systems’ Risk Assessments 
Three detailed use cases are provided to demonstrate the application of the risk management 
framework in real-world scenarios. These examples illustrate how risks can be identified, assessed, 
and mitigated across various contexts. 
10. Reference to Tools, Methodologies, Benchmarks, and Guidance 
The final section compiles tools, evaluation metrics, benchmarks, methodologies, and standards to 
support developers and users in managing risks and evaluating the performance of LLM systems.  
Guidance for Readers 
 For Developers: Use this guidance to integrate privacy risk management into the development 
lifecycle and deployment of your LLM based systems, from understanding data flows to how to 
implement risk identification and mitigation measures. 
 For Users: Refer to this document to evaluate the privacy risks associated with LLM systems you 
plan to deploy and use, helping you adopt responsible practices and protect individuals’ privacy.  
 For Decision-makers: The structured methodology and use case examples will help you assess the 
compliance of LLM systems and make informed risk-based decisions.

## Page 6 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
6 
 
2. Background  
What Are Large Language Models?  
Large Language Models (LLMs) represent a transformative advancement in artificial intelligence. These 
general purpose models are trained on extensive datasets, which often encompass publicly available 
content, proprietary datasets, and specialized domain-specific data. Their applications are diverse, 
ranging from text generation and summarization to coding assistance, sentiment analysis, and more. 
Some LLMs are multimodal LLMs, capable of processing and generating multiple data modalities such 
as image, audio or video.  
The development of LLMs has been marked by key technological milestones that have shaped their 
evolution. Early advancements in the 1960s and 1970s included rule-based systems like ELIZA, which 
laid foundational principles for simulating human conversation through predefined patterns. In 2017, 
the introduction of transformer architectures (see Figure 2) in the seminal paper "Attention Is All You 
Need"1 revolutionized the field by enabling efficient handling of contextual relationships within text 
sequences. Subsequent developments, such as OpenAI’s GPT series and Google’s BERT (see Figure 3), 
have set benchmarks for natural language processing (NLP)2, culminating in models like GPT-4, LaMDA3, 
and DeepSeek-V34 (see Figure 4) integrating multimodal capabilities. 
How Do Large Language Models Work? 
LLMs are advanced deep learning models designed to process and generate human-like language. They 
rely on the transformer architecture5, which uses attention mechanisms to understand context and 
relationships between words. While most state of the art LLMs rely on transformers due to their 
scalability and effectiveness, alternatives6 exist based on RNN (Recurring Neural Networks) such as 
LSTM (Long-short Term Memory) and others that are actively being researched7. For now, transformers 
dominate general-purpose language models, but innovations in architectures such as those introduced 
by DeepSeek’s models, may reshape the landscape in the future.  
 
The development8of LLMs can be divided into several key stages: 
1. Training Phase: Building the Model 
In this phase LLMs learn patterns, context, and structure in language by analyzing vast datasets. 
1. Dataset Collection: 
The foundation of LLM training lies in the use of extensive datasets (such as such as Common 
Crawl and Wikipedia) that are carefully curated to ensure they are relevant, diverse, and high-
quality. Filtering eliminates low-quality or redundant content, aligning the training data with the 
intended goals of the model. 
2. Data Pre-processing: 
                                                            
1 A.Vaswan et al., ‘Attention Is All You Need’ (2023) https://arxiv.org/pdf/1706.03762  
2 Wikipedia, ‘Natural language processing’ (2025) https://en.wikipedia.org/wiki/Natural_language_processing 
3 E.Collins and Z.Ghahramani, ‘LaMDA: our breakthrough conversation technology’ (2021) https://blog.google/technology/ai/lamda/ 
4 Github, ‘Deepseek’ (n.d) https://github.com/deepseek-ai/DeepSeek-V3 
5 Wikipedia, ‘Deep Learning Architecture’ (2025) https://en.wikipedia.org/wiki/Transformer_(deep_learning_architecture) 
6 Artificial Intelligence, ‘Why does the transformer do better than RNN and LSTM in long-range context dependencies?’ (2020) 
https://ai.stackexchange.com/questions/20075/why-does-the-transformer-do-better-than-rnn-and-lstm-in-long-range-context-depen  
7 A.Gu, T.Dao, ‘Mamba: Linear-Time Sequence Modeling with Selective State Spaces’ (2024) https://arxiv.org/pdf/2312.00752, B.Peng et al, 
‘RWKV: Reinventing RNNs for the Transformer Era’ (2023) https://arxiv.org/pdf/2305.13048 
8 Y.Liu et al., ‘Understanding LLMs: A Comprehensive Overview from Training to Inference’ (2024) https://arxiv.org/pdf/2401.02038v2

## Page 7 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
7 
 
 
Text is cleaned and normalized by removing inconsistencies (e.g., special characters) and 
irrelevant content, ensuring uniformity in the training data. 
 
Text data is broken into smaller units called tokens, which can be words, subwords, or even 
individual characters. Tokenization algorithms transforms unstructured text into manageable 
sequences for computational processing. 
 
Tokens are converted into numerical IDs that represent their vocabulary position. These IDs are 
then transformed into word embeddings9—dense vector representations that capture semantic 
similarities and relationships between words. For instance, semantically related words like 
“king” and “queen” will occupy nearby positions in the embedding space. 
 
 
Figure 1. Source: S.Anala ‘A Guide to Word Embedding’ (2020) 
https://medium.com/data-science/a-guide-to-word-embeddings-8a23817ab60f 
 
 
3. Transformer Architecture:10 
Transformer architectures can be categorized into three main types: encoder-only, encoder-
decoder, and decoder-only. While encoder-only architectures were foundational in earlier models, 
they are generally not used in the latest generation of LLMs. Most state of the art LLMs today use 
decoder-only architectures, while encoder-decoder models are still used in tasks like translation 
and instruction tuning.  
 
Encoder:11 
The encoder takes the input text and converts it into a contextualized representation by 
analyzing relationships between words. Key elements include: 
o Token embeddings: Tokens are transformed into numerical vectors that capture their 
meaning. 
o Positional encodings: Since the transformer processes words in parallel, positional 
encodings are added to token embeddings to represent the order of words, preserving 
the structure of the input. 
o Attention mechanisms: The encoder evaluates the importance of each word relative to 
others in the input sequence, capturing dependencies and context. For example, it 
helps distinguish between “park” as a verb and “park” as a location based on the 
surrounding text. 
o Feed-Forward Network: A series of transformations are applied to refine the 
contextualized word representations, preparing them for subsequent stages. 
                                                            
9 V.Zhukov, ’A Guide to Understanding Word Embeddings in Natural Language Processing (NLP)’ (2023) https://ingestai.io/blog/word-
embeddings-in-nlp 
10 See footnote 1 
11 Geeksforgeels, ‘Architecture and Working of Transformers in Deep Learning’ (2025) https://www.geeksforgeeks.org/architecture-and-
working-of-transformers-in-deep-learning/

## Page 8 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
8 
 
 
Decoder:12 
The decoder generates text by predicting one token at a time. It builds upon the encoder’s 
output (if used) and the sequence of tokens already generated. Key elements include: 
o 
Input: Combines encoder outputs with tokens generated so far.  
o 
Attention mechanisms:13 Ensures each token considers previously generated tokens to 
maintain coherence and context.  
o 
Feed-Forward Network (FFN):14 This layer refines the token representations to ensure 
they are relevant and coherent.  
o 
Masked attention: During training, future tokens are hidden from the model, ensuring 
it predicts outputs step by step without "cheating". 
 
Figure 2. Transformer architecture. 
Source: Vaswani et al. ‘Attention Is All You Need ‘ (2023) 
https://arxiv.org/pdf/1706.03762 
 
 
Figure 3. A comparison of the architectures for the Transformer, GPT and BERT. 
Source: B.Smith ‘A Complete Guide to BERT with Code’ (2024)  
https://towardsdatascience.com/a-complete-guide-to-bert-with-code-9f87602e4a11 
                                                            
12 idem 
13 The architecture of DeepSeek models contains an innovative attention mechanism called Multi-head Latent Attention (MLA) that 
compresses Key/Value vectors offering better compute and memory efficiency. 
14 DeepSeek models employ the DeepSeekMoE architecture based on Mixture-of-Experts (MoE) introducing multiple parallel expert 
networks (FFNs) instead of a single FFN.

## Page 9 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
9 
 
Mixture of Experts (MoE) is a technique used to improve transformer-based LLMs making them more 
efficient and scalable. Instead of using the entire model for every input, MoE activates only a few 
smaller parts of the model—called "experts"—based on what the input needs. This means the model 
can be much larger overall, but only the necessary parts are used at any time, saving computing power 
without losing performance 
 
Figure 4. Illustration of DeepSeek-V3’s basic architecture called DeepSeekMoE based on Mixture-of-Experts (MoE). 
Source: ‘DeepSeek-V3 Technical Report’   
https://arxiv.org/pdf/2412.19437 
 
4. Training/Feedback loop & Optimization15 
The training phase of LLMs relies on a structured optimization loop to enhance the model’s ability 
to generate accurate outputs. This iterative process consists of the following steps: 
 
Loss calculation: After generating an output sequence, the model compares it to the target 
sequence (the "correct answer"). A loss function quantifies the error, providing a numerical 
measure of how far the predicted output deviates from the desired result (the loss).  
 
Backward pass: The obtained loss value is used to compute gradients, which indicate how 
much each model parameter (e.g., weights and biases) contributed to the error. These 
gradients highlight areas where the model needs improvement. 
 
Parameter update: Using an optimization algorithm, such as Adam or SGD (Stochastic Gradient 
Descent), the model’s parameters are adjusted. This step reduces the error for future 
predictions by refining the internal model weights. 
 
Repetition: This process repeats for thousands or millions of iterations. Each cycle 
incrementally improves the model’s performance. Training stops when the model reaches a 
balance between accuracy on training data and generalization to unseen inputs.  
2. Continuous Improvement – Model Alignment (post training) 
Pre-trained models, while powerful, are generally not immediately useful in their raw form. To make 
models' behaviour align with ethical considerations and user preferences16 they need to be tuned. This 
                                                            
15  ‘PyTorch Loss.backward() and Optimizer.step(): A Deep Dive for Machine Learning’ (2025) https://iifx.dev/en/articles/315715245 
16 C.R. Wolfe, ‘Understanding and Using Supervised Fine-Tuning (SFT) for Language Models ‘ (2023) 
https://cameronrwolfe.substack.com/p/understanding-and-using-supervised

## Page 10 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
10 
 
process often involves the use of techniques such as supervised fine-tuning on domain-specific data or 
Reinforcement Learning with Human Feedback (RLHF). The most common alignment methods are: 
 
Supervised Fine-Tuning (SFT):17 This approach involves training a pre-trained model on a 
labeled dataset tailored to a specific task, with adjustments made to some or all of its 
parameters to enhance performance for that task.  
 
Instruction Tuning:18 This technique is used to optimize the LLM for following user instructions 
and handling conversational tasks. 
 
Reinforcement Learning with Human Feedback (RLHF):19 
This method uses human feedback to train a reward model (RM), which helps guide the AI 
during its learning process. The reward model acts as a scorekeeper, showing the AI how well 
it's performing based on the feedback. Techniques like Proximal Policy Optimization (PPO) are 
then used to fine-tune the language model. In simple terms, the language model learns to 
make better decisions based on the reward signals it receives. Direct Preference Optimization 
(DPO)20 is an emerging reinforcement learning approach that simplifies this process by directly 
incorporating user preference data into the model's optimization process.  
While RLHF aims to align the model with human preferences across diverse scenarios using 
human feedback, another variation of the PPO technique called Group Relative Policy 
Optimization (GRPO)21 introduced by DeepSeek researchers, takes a different approach. 
Instead of relying on human annotations, GRPO uses computer-generated scores to guide the 
model’s learning process and reasoning capabilities in an automated manner. 
 
Parameter-Efficient Fine-Tuning (PEFT):22 This technique adapts pre-trained models to new 
tasks by training only some of the model's parameters, leaving the majority of the pre-trained 
model unchanged. Some PEFT techniques are adapters, LoRA, QLoRA and prompt-tuning. 
 
Retrieval-Augmented Generation (RAG):232425 This method enhances LLMs by integrating 
information retrieval capabilities, enabling them to reference specific documents. This 
approach allows LLMs to incorporate domain-specific or updated information when 
responding to user queries. 
 
Transfer Learning:2627 With this technique, knowledge learned from a task is re-used in another 
model. 
 
Feedback loops:28 Real-world user feedback helps refine the model’s behavior, allowing it to 
adapt to new contexts or correct inaccuracies. Feedback can be collected through user 
behaviour, for instance inferring whether the user engages with or ignores a response. 
Feedback can also be collected when users directly provide feedback on the model's output, 
such as a thumbs-up/thumbs-down rating, qualitative comments, or error corrections. The LLM 
is then refined based on this feedback. 
                                                            
17 Bergmann, D. ‘What IS fine-tuning?’ (2024) https://www.ibm.com/think/topics/fine-tuning 
18 D.Bergman, ‘What is instruction tuning?’ (2024) https://www.ibm.com/think/topics/instruction-tuning  
19 S. Chaudhari et al. ‘RLHF Deciphered: A Critical Analysis of Reinforcement Learning from Human Feedback for LLMs’ (2024) 
https://arxiv.org/abs/2404.08555 
20 R. Rafailov, ’ Direct Preference Optimization: Your Language Model is Secretly a Reward Model’ (2024) https://arxiv.org/abs/2305.18290 
21 Z.Shao, ‘DeepSeekMath: Pushing the Limits of Mathematical Reasoning in Open Language Models’ (2024)https://arxiv.org/abs/2402.03300  
22 Stryker, C. et al.,  ‘What is parameter-efficient fine-tuning (PEFT)?’ (2024) https://www.ibm.com/think/topics/parameter-efficient-fine-
tuning 
23 AWS, ‘What is RAG (Retrieval-Augmented Generation)’? (2025) https://aws.amazon.com/what-is/retrieval-augmented-generation/ 
24 Wikipedia, ‘Retrieval Augmented Generation’ (2025) https://en.wikipedia.org/wiki/Retrieval-augmented_generation 
25 IBM, ‘Retrieval Augmented Generation’ (2025) https://www.ibm.com/architectures/hybrid/genai-rag?mhsrc=ibmsearch_a&mhq=RAG 
26 V.Chaba, ‘Understanding the Differences: Fine-Tuning vs. Transfer Learning ‘ (2023) https://dev.to/luxacademy/understanding-the-
differences-fine-tuning-vs-transfer-learning-370 
27 Wikipedia, ‘Transfer Learning’ (2025) https://en.wikipedia.org/wiki/Transfer_learning 
28 Nebuly AI, ‘LLM Feedback Loop’ (2024) https://www.nebuly.com/blog/llm-feedback-loop

## Page 11 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
11 
 
3. Inference Phase: Generating Outputs 
Once trained, the model enters the inference phase, where it generates outputs based on new inputs 
following these steps: 
1. Input: The user’s query is processed through tokenization and embedding, transforming it into 
a format the model can understand. 
2. Processing: The input passes through the transformer architecture, where attention 
mechanisms and decoder layers predict the next tokens in the sequence. The decoder produces 
a vector of scores (called logits) for each word in the vocabulary. These scores are then passed 
through the Softmax29 function, which converts them into probabilities. The model selects the 
most probable token as the next word in the sequence, ensuring that the generated text is 
coherent and contextually relevant. 
3. Output: The model produces probabilities for potential next words, selecting the most likely 
options based on the input and context. These predictions are combined to generate coherent 
and relevant responses. 
 
The three key stages described outline how a traditional text-only LLM is developed. Multimodal LLMs 
follow a similar process but to handle multiple data modalities, they incorporate specialized 
components such as modality-specific encoders, connectors and cross-modal fusion mechanisms to 
integrate the different data representations, along with a shared decoder to generate coherent outputs 
across modalities. Their development also involves pre-training and fine-tuning stages; however, some 
architectures build multimodal LLMs by fine-tuning an already pre-trained text-only LLM rather than 
training one from scratch. 
 
 
 
 
Figure 5. Typical Multimodal LLM (MLLM) architecture. 
Source: Y. Shukang et al. ‘A Survey on Multimodal Large Language Models’ (2024)  
https://arxiv.org/abs/2306.13549 
 
In practice, LLMs are often part of a system and can be accessed directly via APIs, are embedded within 
SaaS platforms, deployed as off-the-shelf foundational models fine-tuned for specific use cases, or 
integrated into on-premise solutions. It is important to note that while LLMs are essential components 
of AI systems, they do not constitute AI systems on their own. For an LLM to become part of an AI 
system, additional components such as a user interface, must be integrated to enable it to function as 
a complete system.30Throughout this document, we will refer to such complete systems as LLM-based 
systems or simply LLM systems to emphasize their broader context and functionality. This distinction is 
crucial when assessing the risks associated with these systems, as an LLM system inherently carries more 
risks due to its additional components and integrations compared to a standalone LLM. 
                                                            
29 Wikipedia, ‘Softmax Function’ (2025) https://en.wikipedia.org/wiki/Softmax_function 
30 Recital 97 AI Act

## Page 12 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
12 
 
Each stage of an LLM’s development lifecycle could introduce potential privacy risks, as the model 
interacts with large datasets that might contain personal data and it generates outputs based on that 
data. Some of the key privacy concerns may occur during:  
 
The collection of data: The training, testing and validation set could contain identifiable 
personal data, sensitive data or special category of data. 
 
Inference: Generated outputs could inadvertently reveal private information or contain 
misinformation. 
 
RAG process: We might use knowledge bases containing sensitive data or identifiable personal 
data without implementing proper safeguards. 
 
Feedback loops: User interactions might be stored without adequate safeguards. 
 
Emerging LLM Technologies: The Rise of Agentic AI 
According to a recent report from Deloitte,31 by 2027, 50% of companies leveraging generative AI are 
expected to have launched pilots or proofs of concept to implement agentic AI systems. These systems 
are envisioned to function as intelligent assistants, capable of autonomously managing complex tasks 
with minimal human supervision. 
AI Agents32 are autonomous systems that can be built on top of LLMs and that can perform complex 
tasks by combining the capabilities of LLMs with reasoning, decision-making, and interaction 
capabilities. AI agents are proactive, capable of goal-oriented behavior such as planning, executing 
tasks, and iterating based on feedback. They can operate independently and are designed to achieve 
specific objectives by orchestrating multiple actions in sequence. They can also incorporate feedback to 
refine their actions or responses over time. Advanced AI agents may integrate capabilities from other 
AI systems, such as computer vision or audio processing, to handle diverse data inputs.33 
The concept of agentic AI remains an evolving and not yet fully defined domain. Different organizations 
and researchers propose varying interpretations of what constitutes an agentic AI system. For example, 
at Anthropic34, they emphasize a significant architectural distinction between workflows and agents: 
 
Workflows are structured systems where LLMs and tools operate in a predefined manner, 
following orchestrated code paths.  
 
Agents, in contrast, are designed to function dynamically. They allow LLMs to autonomously 
direct their processes and determine how to use tools and resources to achieve objectives. 
An Overview of AI Agents and their Architecture35 
In systems powered by LLMs, the LLM serves as a central "brain" providing the foundational abilities 
for natural language understanding and reasoning. This ability is augmented with additional 
components that equip the agent to plan, learn, and interact dynamically with its environment, 
enabling it to handle tasks that go beyond standalone LLM capabilities. 
The architecture of an AI agent focuses on critical components that work together to enable 
sophisticated behavior and adaptability in real-world scenarios. The architecture is modular, involving 
distinct components for perception, reasoning, planning, memory management, and action. This 
                                                            
31 J.Loucks ‘Autonomous generative AI agents: Under development’ (2024) 
https://www2.deloitte.com/us/en/insights/industry/technology/technology-media-and-telecom-predictions/2025/autonomous-generative-
ai-agents-still-under-development.html 
32 C. Gadelho, ‘Building AI and LLM Agents from the Ground Up: A Step-by-Step Guide’ (2024) https://www.tensorops.ai/post/building-ai-
and-llm-agents-from-the-ground-up-a-step-by-step-guide 
33 OpenAI's Operator (2025) https://openai.com/index/introducing-operator/ 
34 Anthropic, ‘Building effective agents’ (2024) https://www.anthropic.com/research/building-effective-agents 
35 idem

## Page 13 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
13 
 
modularity allows the system to handle complex tasks, interact dynamically with their environment, 
and refine performance iteratively.  
Some of the most common modules currently used are: 
1. Perception module 
This module handles the agent’s ability to process inputs from the environment and format them into 
a structure that the LLM can understand. It converts raw inputs (e.g., text, voice, or data streams) into 
embeddings or structured formats that can be processed by the reasoning module. 
2. Reasoning module 
The reasoning module enables the agent to interpret input data, analyze its context, and decompose 
complex tasks into smaller, manageable subtasks. It leverages the LLM’s ability to understand and 
process natural language to make decisions. The reasoning mechanism enables the agent to analyze 
user inputs to determine the best course of action and leverage the appropriate tool or resource to 
achieve the desired outcome. 
3. Planning module 
The planning module determines how the agent will execute the subtasks identified by the reasoning 
module. It organizes and sequences actions to achieve a defined goal. 
4. Memory and state management 
To maintain context and continuity, the agent keeps track of past interactions. Memory allows the AI 
agent to store and retrieve context, both within a single interaction and across multiple sessions. 
o Short-Term Memory: Maintains context within the current interaction to ensure coherence in 
responses. 
o Long-Term Memory: Stores user preferences, past interactions, and learned insights for 
personalization. 
5. Action module 
This module is responsible for executing the plan and interacting with the external environment. It 
carries out the tasks identified and planned by earlier modules. The agent must have access to a 
defined set of tools, such as APIs, databases, or external systems, which it can use to accomplish the 
specific tasks. For example, an AI assistant might use a calendar API for scheduling or a booking service 
for travel reservations. 
6. Feedback and iteration loop 
The feedback loop enables the agent to evaluate the success of its actions and adjust its behavior 
dynamically. It incorporates user corrections, system logs, and performance metrics to refine 
reasoning, planning, and execution over time. 
Interaction Between AI Agent, Memory, and Environment 
The agent interacts continuously with its memory and external environment. Context from memory 
enhances task relevance and continuity while external data (e.g., user queries, sensor inputs) drives 
decision-making and task execution.

## Page 14 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
14 
 
 
 
Figure 6. Source: Z.Deng et al. AI ‘Agents Under Threat: A Survey of Key Security Challenges and Future Pathways’ (2024) 
https://www.researchgate.net/figure/General-workflow-of-AI-agent-Typically-an-AI-agent-consists-of-three-components_fig1_381190070  
 
Small Language Models (SLMs) and their role in AI Agents36 
Small Language Models (SLMs) are lightweight, task-specific models designed to handle simpler or 
more focused tasks compared to Large Language Models (LLMs). While LLMs excel at understanding 
and generating complex language, SLMs are optimized for specific applications, such as text 
classification, entity recognition, or sentiment analysis. 
SLMs can complement LLMs in agentic AI by taking on specialized tasks that do not require the 
extensive computational resources or generality of LLMs. In AI agents, SLMs can enhance efficiency 
and privacy by processing data locally, reducing reliance on centralized LLMs. This modular approach 
allows agents to allocate tasks improving overall performance and security. 
To fully leverage the capabilities of LLMs within organizations, it is essential to adapt the models to the 
organization's specific knowledge base and business processes. This customization, often achieved by 
fine-tuning the LLM with organization-specific data, can result in a domain-focused small language 
model (SLM).37  
Model Orchestration38 
For agentic AI to seamlessly integrate the strengths of both SLMs39 and LLMs, a system is needed to 
dynamically manage which model handles which task. This is where model orchestration plays a 
critical role, ensuring efficient and secure collaboration between different models. In agentic AI, 
orchestration determines the most appropriate model—LLM or SLM—for a given task, routes inputs 
accordingly, and combines their outputs into a unified response. 
Privacy Concerns40 
The growing adoption of AI agents powered by LLMs, brings the promise of revolutionizing the way 
humans work by automating tasks and improving productivity. However, these systems also introduce 
significant privacy risks that need to be carefully managed: 
                                                            
36 Cabalar, R., ‘What are small language models?’ (2024) https://www.ibm.com/think/topics/small-language-models 
37 D. Biswas, ICAART, ‘Stateful Monitoring and Responsible Deployment of AI Agents’, (2025) 
38 Windland, V. et al. ’What is LLM orchestration’ (2024) https://www.ibm.com/think/topics/llm-orchestration 
39 D. Vellante et al., ‘From LLMs to SLMs to SAMs, how agents are redefining AI’ (2024) https://siliconangle.com/2024/09/28/llms-slms-sams-
agents-redefining-ai 
40 B.O’Neill, ‘What is an AI agent? A computer scientist explains the next wave of artificial intelligence tools’ (2024) 
https://theconversation.com/what-is-an-ai-agent-a-computer-scientist-explains-the-next-wave-of-artificial-intelligence-tools-242586

## Page 15 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
15 
 
 
To perform their tasks effectively, AI agents often require access to a wide range of user data, 
such as: 
o 
Internet activity: Browsing history, online searches, and frequently visited websites. 
o 
Personal applications: Emails, calendars, and messaging apps for scheduling or 
communication tasks. 
o 
Third-party systems: Financial accounts, customer management platforms, or other 
organizational systems. 
This level of access significantly increases the risk of unauthorized data exposure, particularly if 
the agent's systems are compromised. 
 
AI agents are designed to make decisions autonomously, which can lead to errors or choices that 
users may disagree with.  
 
Like other AI systems, AI agents are susceptible to biases originating from their training data, 
algorithms and usage context. 
Privacy trade-offs for user convenience:41 As AI agents grow more capable, users will need to consider 
how much personal data they are willing to share in exchange for convenience. For example, an agent 
might save time by managing travel bookings or negotiating purchases but requires access to sensitive 
information such as payment details or login credentials42. Balancing these trade-offs requires clear 
communication about data usage policies and robust consent mechanisms. 
Accountability for Agent decisions:43 AI agents operate in complex environments and may encounter 
unforeseen challenges. When an agent makes an error, or its actions cause harm, determining 
accountability can be difficult. Organizations must ensure transparency in how decisions are made and 
provide mechanisms for users to intervene when errors occur. 
Common Uses of LLM Systems 
LLMs have become pivotal in various industries, offering advanced capabilities in natural language 
understanding and generation. The market provides a spectrum of LLM solutions, each tailored to 
specific applications and user requirements. 
 
1. Proprietary LLM Models 
Leading technology companies have developed proprietary LLM platforms that cater to diverse 
business needs. Some platforms offer customizable LLMs that can be trained on specific datasets: 
 
OpenAI's GPT44 Series (Generative Pre-Trained Transformer (GPT) models), are renowned for their 
advanced language processing capabilities. These models are accessible through APIs, enabling 
businesses to integrate sophisticated language understanding and generation into their 
applications. 
 
Google's Gemini45 models are designed to assist with various tasks, providing users with detailed 
information and facilitating complex queries. 
 
Claude’s Anthropic Models46 are developed with safety and alignment in mind. Claude specializes 
in conversational AI with a focus on ethical and secure interactions. 
Several European companies and collaborations are contributing to the LLM landscape: 
                                                            
41 Z.Zhang et al. ‘"It's a Fair Game", or Is It? Examining How Users Navigate Disclosure Risks and Benefits When Using LLM-Based 
Conversational Agents’ (2024)   https://arxiv.org/abs/2309.11653 
42 Login credentials are the unique information used to access systems, accounts, or services, typically consisting of a username and 
password, but they can also include additional methods like two-factor authentication, biometric data, or security PINs for added protection. 
43 J. Zeiser, ‘Owning Decisions: AI Decision-Support and the Attributability-Gap’ (2024). https://doi.org/10.1007/s11948-024-00485-1 
44 ChatGPT (https://chatgpt.com/) 
45 Gemini (https://gemini.google.com/) 
46 Claude (https://claude.ai/)

## Page 16 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
16 
 
 
Mistral AI,47a Paris-based startup established in 2023 by former Google DeepMind and Meta AI 
scientists offers both open source and proprietary AI models.  
 
Aleph Alpha48is based in Heidelberg, Germany, and it specializes in developing LLMs designed to 
provide transparency regarding the sources used for generating results. Their models are intended 
for use by enterprises and governmental agencies, trained in multiple European languages.  
 
Silo AI's Poro49, through its generative AI arm SiloGen, has developed Poro, a family of multilingual 
open source LLMs. This initiative aims to strengthen European digital sovereignty and democratize 
access to LLMs for all European languages.  
 
TrustLLM50is a coordinated project by Linköping University that focuses on developing trustworthy 
and factual LLM technology for Europe, emphasizing accessibility and reliability.  
 
OpenEuroLLM51 is an open source family of performant, multilingual, large language foundation 
models for commercial, industrial and public services. 
 
2. Open Source LLM Frameworks and Models  
The open source community contributes significantly to the LLM landscape. Here are some of the 
most known frameworks and models that have shaped the development and deployment of large 
language models: 
 
Hugging Face's Transformers52 is an extensive library of pre-trained models and tools, allowing 
developers to fine-tune and deploy LLMs for specific tasks. 
 
Deepseek53 is an advanced language model comprising 67 billion parameters. It has been trained 
from scratch on a vast dataset of 2 trillion tokens in both English and Chinese. 
 
Deepset's Haystack54 is an open source framework designed to build search systems and question-
answering applications powered by Large Language Models (LLMs) and other natural language 
processing (NLP) techniques.  
 
OLMo 32B55 is the first fully open model (all data, code, weights, and details are freely available). 
 
Meta's LLaMA56 models focus on research and practical applications in NLP. 
 
BLOOM57 was developed by BigScience as a multilingual open source model capable of generating 
text in over 50 languages, with a focus on accessibility and inclusivity. 
 
BERT58 was created by Google to understand the context of text through bidirectional language 
representation, excelling in tasks like question answering and sentiment analysis.  
 
Falcon59 was developed by the Technology Innovation Institute as a high-performance model 
optimized for text generation and understanding, with significant efficiency improvements over 
similar models. 
 
Qwen60 is a large language model family built by Alibaba Cloud. 
                                                            
47 Mistral (https://mistral.ai/) 
48 Aleph Alpha (https://aleph-alpha.com/) 
49 Silo AI, ‘Poro - a family of open models that bring European languages to the frontier’ (2023) https://www.silo.ai/blog/poro-a-family-of-
open-models-that-bring-european-languages-to-the-frontier   
50 TrustLLM (https://trustllm.eu/) 
51 OpenEuroLLM (https://openeurollm.eu/) 
52 Hugging Face, ‘Transformers’ (n.d) https://huggingface.co/docs/transformers/v4.17.0/en/index  
53 Deepseek (https://www.deepseek.com/) 
54 Haystack (https://haystack.deepset.ai/) 
55 Ai2, ‘OLMo 2 32B: First fully open model to outperform GPT 3.5 and GPT 4o mini’ (2025) https://allenai.org/blog/olmo2-32B  
56 Llama (https://www.llama.com/ ) 
57 Hugging Face, ‘Introducing The World’s Largest Open Multilingual Language Model: BLOOM’ (2025) 
https://bigscience.huggingface.co/blog/bloom 
58 Hugging Face, ‘BERT’ (n.d) https://huggingface.co/docs/transformers/model_doc/bert 
59 TTI, ‘Introducing the Technology Innovation Institute’s Falcon 3’ (n.d) https://falconllm.tii.ae/ 
60 Hugging Face, ‘’Qwen’ (n.d) https://huggingface.co/Qwen

## Page 17 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
17 
 
 
LangChain61 is an open source framework for building applications powered by large language 
models. 
 
3. Cloud-Based LLM Services  
Major cloud providers offer LLM services that integrate seamlessly into existing infrastructures 
providing access to proprietary and open source LLMs: 
 
Microsoft Azure OpenAI62 Service collaborates with OpenAI to provide API access to GPT models, 
enabling businesses to incorporate advanced language features into their applications. 
 
Amazon Web Services (AWS) Bedrock63 offers a suite of AI services, including language models 
that support various natural language processing tasks. 
 
Google Cloud Vertex AI64 is a platform for building, deploying, and scaling machine learning 
models, including LLMs. It provides access to models like PaLM 2 and supports customization for 
various applications, such as translation, summarization, and conversational AI. 
 
IBM Watson65 provides LLM capabilities that can be tailored to recognize industry-specific entities, 
enhancing the relevance and accuracy of information extraction.  
 
Cohere66 offers customizable LLMs that can be fine-tuned for specific tasks. 
Applications of LLMs 
LLMs are employed across various applications67, enhancing both user experience and operational 
efficiency. This list represents some of the most prominent applications of LLMs, but it is by no means 
exhaustive. The versatility of LLMs continues to unlock new use cases across industries, demonstrating 
their transformative potential in various domains. 
 
Chatbots and AI Assistants:68 LLMs power virtual assistants like Siri, Alexa, and Google 
Assistant, understand and process natural language, interpret user intent, and generate 
responses.  
 
Content generation:69 LLMs assist in creating articles, reports, and marketing materials by 
generating human-like text, thereby streamlining content creation processes. 
 
Language translation:70 Advanced LLMs facilitate real-time translation services. 
 
Sentiment analysis:71 Businesses use LLMs to analyze customer feedback and social media 
content, gaining insights into public sentiment and informing strategic decisions. 
 
Code generation and debugging:72 Developers leverage LLMs to generate code snippets and 
identify errors, enhancing software development efficiency. 
 
Educational support tools:73 LLMs play a key role in personalized learning by generating 
educational content, explanations, and answering student questions. 
 
Legal document processing:74 LLMs help professionals in the legal field by reviewing and 
summarizing legal texts, extracting important information, and offering insights. 
                                                            
61 LangChain, ‘Introduction’ (n.d) https://python.langchain.com/ 
62 Microsoft, ‘Azure OpenAI Service’ (2025) https://azure.microsoft.com/en-us/services/cognitive-services/openai-service/ 
63 AWS, ‘Bedrock’ (n.d)https://aws.amazon.com/bedrock 
64 Vertex AI Platform, ‘Innovate faster with enterprise-ready AI, enhanced by Gemini models’ (n.d) https://cloud.google.com/vertex-ai 
65 IBM, ‘IBM Watson to watsonx’ (n.d) https://www.ibm.com/watson 
66 Cohere (https://cohere.com/) 
67 N. Sashidharan, ‘Three Pillars of LLM: Architecture, Use Cases, and Examples ‘ (2024) https://www.extentia.com/post/pillars-of-llm-
architecture-use-cases-and-examples 
68 Google Assistant (https://assistant.google.com/) 
69 Jasper AI (https://www.jasper.ai/) 
70 Deepl (https://www.deepl.com/en/translator ) 
71 SurveySparrow (https://surveysparrow.com/features/cognivue/) 
72 GitHub Copilot (https://github.com/features/copilot) 
73 Khanmigo (https://www.khanmigo.ai/) 
74 Luminance (https://www.luminance.com/)

## Page 18 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
18 
 
 
Customer support:75 Automating responses to customer inquiries and escalating complex cases 
to human agents. 
 
Autonomous vehicles:76 Driving cars with real-time decision-making capabilities. 
Performance Measures for LLMs 
Evaluating the performance of Large Language Models (LLMs) is essential to ensure they meet their 
intended purpose and desired standards of accuracy, reliability, and ethical use across diverse 
applications. To effectively measure the performance of a Large Language Model (LLM), it is important 
to tailor the evaluation approach to the stage of the LLM lifecycle (e.g., training, post-processing, pre-
deployment, production) and its intended real-world applications. Performance metrics help identify 
areas where additional testing or refinements may be necessary before deployment or once the LLM 
system is in use in a production environment. 
Some of the most common LLM performance evaluation criteria are Answer Relevancy, Correctness, 
Semantic Similarity, Fluency, Hallucination, Factual Consistency, Contextual Relevancy, Toxicity, Bias 
and Task-Specific Metrics.  
 
The following metrics77 are commonly used, each offering different insights: 
 
Accuracy78measures how often an output aligns with the correct or expected results. In tasks like 
text classification or question answering, accuracy is calculated as the ratio of correct predictions to 
the total number of predictions. However, for generative tasks such as text generation, traditional 
accuracy metrics may not fully capture performance due to the open-ended nature of possible 
correct responses. In such cases, metrics like BLEU (Bilingual Evaluation Understudy) and ROUGE 
(Recall-Oriented Understudy for Gisting Evaluation) are employed to assess the quality of generated 
text by comparing it to reference texts. 
 
Precision quantifies the ratio of correctly predicted positive outcomes to the total number of 
positive predictions made by the model. In the context of LLMs, a high precision score indicates the 
model is accurate when making predictions. However, it does not account for relevant instances the 
model fails to predict (false negatives), so it is commonly combined with recall for a more 
comprehensive evaluation. 
 
Recall, also referred to as sensitivity or the true positive rate, measures the proportion of actual 
positive instances that the model successfully identifies. A high recall score reflects the model’s 
effectiveness in capturing relevant information but does not address irrelevant predictions (false 
positives). For this reason, recall is typically evaluated alongside precision to provide a balanced 
view. 
 
F1 Score offers a balanced metric by combining precision and recall into their harmonic mean. A 
high F1 score indicates that the model achieves a strong balance between precision and recall, 
making it a valuable metric when both false positives and false negatives are critical. The F1 score 
ranges from 0 to 1, with 1 representing perfect performance on both metrics. 
 
Specificity79 measures the proportion of true negatives correctly identified by a model. 
 
AUC (Area Under the Curve) and AUROC80(Area Under the Receiver Operating Characteristic Curve) 
quantify a model's ability to distinguish between classes. It evaluates the trade-off between 
                                                            
75 Salesforce (https://www.salesforce.com/eu/) 
76 Tesla Autopilot ( https://www.tesla.com/autopilot) 
77 A. Chaudhary, ‘Understanding LLM Evaluation and Benchmarks: A Complete Guide’ (2024)  
https://www.turing.com/resources/understanding-llm-evaluation-and-benchmarks 
78 S. Karzhev, ‘LLM Evaluation: Metrics, Methodologies, Best Practices’ (2024) https://www.datacamp.com/blog/llm-evaluation 
79 Wikipedia, ‘Sensitivity and Specificity’ (2025)  https://en.wikipedia.org/wiki/Sensitivity_and_specificity 
80 E.Becker and S.Soatto, ‘Cycles of Thought: Measuring LLM Confidence through Stable Explanations’ (2024) 
https://arxiv.org/pdf/2406.03441v1

## Page 19 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
19 
 
sensitivity (true positive rate) and 1-specificity (false positive rate) across various thresholds. A 
higher AUC value indicates better performance in classification tasks. 
 
AUPRC81(Area Under the Precision-Recall Curve), measures a model's performance in imbalanced 
datasets, focusing on the trade-off between precision and recall. A high AUPRC indicates that the 
model performs well in identifying positive instances, even when they are rare. 
 
Cross Entropy82is a measure of uncertainty or randomness in a system's predictions. It measures 
the difference between two probability distributions: the true labels (actual data distribution) and 
the predicted probabilities from the model (output). Lower entropy means higher confidence in 
predictions, while higher entropy indicates uncertainty.  
 
Perplexity83derives from cross entropy and evaluates how well a language model predicts a sample, 
serving as an indicator of its ability to handle uncertainty. A lower perplexity score means better 
performance, indicating that the model is more confident in its predictions. Some studies suggest 
that perplexity has proven unreliable84 to evaluate LLMs due to their long-context capabilities. It is 
also difficult to use perplexity as a benchmark between models since its scores depend on factors 
like tokenization method, dataset, preprocessing steps, vocabulary size, and context length.85 
 
Calibration86refers to the alignment between a model's predicted probabilities and the actual 
probability of those predictions being correct. A well-calibrated model provides confidence scores 
that accurately reflect the true probabilities of outcomes. Proper calibration is vital in applications 
where understanding the certainty of predictions is important, such as in medical diagnoses or legal 
document analysis. 
 
MoverScore87is a modern metric developed to assess the semantic similarity between two texts. 
 
Other metrics used for assessing the performance and usability of LLM-based systems, especially in real-
time or high-demand applications are:88 
 
 
Completed requests per minute: Measures how many requests the LLM can process and return 
responses for in one minute. It reflects the system's efficiency in handling multiple queries. 
 
Time to first token (TTFT): The time taken from when a request is submitted to when the first token 
of the response is generated.  
 
Inter-token Latency (ITL): The time delay between generating consecutive tokens in the response. 
This metric evaluates the speed and fluidity of text generation. 
 
End to end Latency /ETEL): The total time taken from when a request is made to when the entire 
response is completed. It encompasses all processing stages, including input handling, model 
inference, and output generation. 
 
                                                            
81 J. Czakon, ‘F1 Score vs ROC AUC vs Accuracy vs PR AUC: Which Evaluation Metric Should You Choose?’ (2024) https://neptune.ai/blog/f1-
score-accuracy-roc-auc-pr-auc 
82 C.Xu, ‘ Understanding the Role of Cross-Entropy Loss in Fairly Evaluating Large Language Model-based Recommendation’ (2024) 
https://arxiv.org/pdf/2402.06216v2   
83 C.Huyen ‘Evaluation Metrics for Language Modeling’ (2019) https://thegradient.pub/understanding-evaluation-metrics-for-language-
models/ 
84 L.Fang ‘What is wrong with perplexity for long-context language modeling?’ (2024) https://arxiv.org/pdf/2410.23771v1 
85 A.Morgan ‘Perplexity for LLM Evaluation’ (2024) https://www.comet.com/site/blog/perplexity-for-llm-evaluation/ 
86 P.Liang et al. ‘Holistic Evaluation of Language Models’ (2023) https://arxiv.org/abs/2211.09110 
87 PI, ’Moverscore 1.0.3’ (2020) https://pypi.org/project/moverscore/ 
88 W. Kadous et al. ‘Reproducible Performance Metrics for LLM inference’ (2023) https://www.anyscale.com/blog/reproducible-
performance-metrics-for-llm-inference

## Page 20 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
20 
 
In addition to these metrics, there are comprehensive evaluation frameworks or benchmarks89 such as 
GLUE (General Language Understanding Evaluation)90, MMLU (Massive Multitask Language 
Understanding)91, HELM (Holistic Evaluation of Language Models)92, DeepEval93 or OpenAI Evals94.  
Task-specific metrics such as BLEU95 (Bilingual Evaluation Understudy), ROUGE96 (Recall-Oriented 
Understudy for Gisting Evaluation), and BLEURT97 (Bilingual Evaluation Understudy with 
Representations from Transformers) are widely used for evaluating text generation, summarization, 
and translation.  
 
It is important to recognize that quantitative metrics alone are not sufficient. While these metrics are 
highly valuable in identifying risks, especially when integrated into automated evaluation pipelines, 
they primarily serve as early warning signals, prompting further investigation when thresholds are 
exceeded. Many critical risks, including misuse potential, ethical concerns, and long-term impact, 
cannot be effectively captured through those numerical measurements alone. 
To ensure a more holistic evaluation, organizations should complement quantitative indicators with 
expert judgment, scenario-based testing, and qualitative assessments.  
Open source frameworks like Inspect98, support an integrated approach by enabling model-graded 
evaluations, prompt engineering, session tracking, and extensible scoring techniques. These tools help 
operationalize both metric-based and qualitative evaluations, offering better observability and insight 
into LLM behavior in real-world settings. 
 
Measuring Performance in Agentic AI 
Most current metrics99 for AI agents focus on efficiency, effectiveness, and reliability. These include 
system metrics (resource consumption and technical performance), task completion (measuring goal 
achievement), quality control (ensuring output consistency), and tool interaction (evaluating integration 
with external tools and APIs).  
 
Some of the key metrics used include: 
 
Task-specific accuracy:100 Assesses how correctly the agent performs designated tasks, such as 
classification or information retrieval. Metrics like Exact Match (EM) and F1 Score are commonly 
used.  
 
End-to-end task completion:101 Evaluates the agent's ability to achieve user-defined goals through 
a series of actions. Metrics include Task Success Rate (TSR) and Goal Completion Rate (GCR). 
 
Step-Level accuracy: Assesses the correctness of individual actions taken by the agent within a 
larger workflow. This is critical in multi-step processes, such as booking a service or resolving a 
technical issue. 
                                                            
89 Benchmarks are standardized frameworks developed to assess LLMs across various scenarios and metrics (See also section 10 of this 
document). 
90 Gluebenchmark (https://gluebenchmark.com/) 
91 Papers with code, ‘MMLU (Massive Multitask Language Understanding)’ (n.d) https://paperswithcode.com/dataset/mmlu 
92 Center for Research on Foundation Models, ‘A reproducible and transparent framework for evaluating foundation models’ (n.d) 
https://crfm.stanford.edu/helm/ 
93 GitHub, ‘The LLM Evaluation framework’ (n.d) https://github.com/confident-ai/deepeval 
94 GitHub, ‘Evals is a framework for evaluating LLMs and LLM systems, and an open-source registry of benchmarks’ (n.d) 
https://github.com/openai/evals 
95 Wikipedia, ‘BLEU’ (2025) https://en.wikipedia.org/wiki/BLEU 
96 Wikipedia, ‘ROUGE(metric)’ (2025) https://en.wikipedia.org/wiki/ROUGE_(metric)  
97 GitHub, ‘BLEURT is a metric for Natural Language Generation based on transfer learning’ (n.d) https://github.com/google-research/bleurt 
98 AISI, ‘An open-source framework for large language model evaluations’ (n.d) https://inspect.aisi.org.uk/ 
99 P. Bhavsar ‘Mastering Agents: Metrics for Evaluating AI Agents’ (2024) https://www.galileo.ai/blog/metrics-for-evaluating-ai-agents 
100 https://smythos.com/ai-agents/impact/ai-agent-performance-measurement/  
101 AISERA, ‘An Introduction to Agent Evaluation’ (n.d) https://aisera.com/blog/ai-agent-evaluation/

## Page 21 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
21 
 
 
Precision and Recall: Measures how accurately the agent retrieves relevant information (precision) 
and whether it captures all necessary details (recall). These metrics are vital for tasks like document 
summarization or answering complex queries. 
 
Contextual understanding:102Measures the agent's proficiency in maintaining and utilizing context 
in interactions, crucial for coherent multi-turn dialogues. Dialog State Tracking 103 is a relevant 
metric.  
 
User satisfaction:104Measures user perceptions of the agent's performance, often through feedback 
scores or surveys and using scales to measure system and user experience usability. 
 
Evaluating AI agents with traditional LLM benchmarks presents challenges, as they often fail to 
capture real-world dynamics, multi-step reasoning, tool use, and adaptability. Effective assessment 
requires new benchmarks that measure long-term planning, interaction with external tools, and real-
time decision-making. Below are some of the most recognized benchmarks currently used: 
 
SWE-bench:105Software Engineering Benchmark dataset, created to systematically evaluate the 
capabilities of an LLM in resolving software issues. 
 
AgentBench:106107 It is designed for evaluating and training visual foundation agents based on 
LMMs. 
 
MLAgentBench:108 To evaluate if agents driven by LLMs perform machine learning experimentation 
effectively.  
 
BFCL (Berkeley Function-Calling Leaderboard):109 To evaluate the ability of different LLMs to call 
functions (also referred to as tools).  
 
τ-bench:110 A benchmark for tool-agent-user interaction in real-world domains. 
 
Planbench:111 To evaluate LLMs on planning and reasoning. 
 
Issues that can Affect the Accuracy of the Output 
Several factors can impact the accuracy of the outputs generated by LLMs. Understanding these issues 
is essential for optimizing their performance and mitigating risks in practical applications. Some of the 
more common issues are: 
 
1. Quality of training data 
 
Data bias:112If the training data contains biases (e.g., societal, cultural, or linguistic biases), the 
model may replicate or amplify these biases in its outputs. 
 
Data relevance:113Training on outdated, irrelevant, or noisy data can lead to inaccurate or 
contextually irrelevant responses. 
                                                            
102 Smyth OS, ‘Conversational Agents and Context Awareness: How AI Understands and Adapts to User Needs’ (n.d) 
https://smythos.com/artificial-intelligence/conversational-agents/conversational-agents-and-context-awareness/ 
103 Papers with code, ‘ Dialogue State Tracking’, (n.d)  https://paperswithcode.com/task/dialogue-state-tracking/codeless?page=2  
104 N. Bekmanis, ‘Artificial Intelligence Conversational Agents: A Measure of Satisfaction in Use’ (2023) 
https://essay.utwente.nl/94906/1/Bekmanis_MA_BMS.pdf 
105 Swebench (https://www.swebench.com/) 
106 Github, ‘A Comprehensive Benchmark to Evaluate LLMs as Agents (ICLR'24)’, (n.d)  https://github.com/THUDM/AgentBench 
107 Papers with code, ’Agentench’ (n.d) https://paperswithcode.com/dataset/agentbench 
108 Q.Huang et al. ‘MLAgentBench: Evaluating Language Agents on Machine Learning Experimentation’ (2024) 
https://arxiv.org/abs/2310.03302 
109 Hugging Face Dataset (https://huggingface.co/datasets/gorilla-llm/Berkeley-Function-Calling-Leaderboard) 
110 GitHub, ‘Code and Data’ (n.d) https://github.com/sierra-research/tau-bench 
111 GitHub, ‘An extensible benchmark for evaluating large language models on planning’ (n.d)  https://github.com/karthikv792/LLMs-Planning 
I. O. Gallegos et al. ‘Bias and Fairness in Large Language Models: A Survey’ (2024) https://direct.mit.edu/coli/article/50/3/1097/121961/Bias-
and-Fairness-in-Large-Language-Models-A 
113 ‘Large Language Models pose risk to science with false answers, says Oxford study’ (2023) https://www.ox.ac.uk/news/2023-11-20-large-
language-models-pose-risk-science-false-answers-says-oxford-study

## Page 22 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
22 
 
2. Model limitations 
 
Understanding context:114Despite advanced architectures, LLMs can struggle with nuanced 
contexts or multi-turn conversations where earlier parts of the dialogue must inform later 
responses. 
 
Handling ambiguities:115Ambiguous input can lead to incorrect or nonsensical outputs if the 
model cannot infer the intended meaning. 
3. Tokenization and preprocessing 
 
Tokenization errors:116Misrepresentation of input text due to tokenization issues (e.g., splitting 
words incorrectly) can distort model understanding. 
 
Preprocessing issues:117Overly aggressive cleaning or normalization during preprocessing can 
remove important contextual information, reducing accuracy. 
4. Overfitting and underfitting 
 
Overfitting:118Training for too many iterations on a limited dataset can make the model overly 
specialized, leading to poor performance on unseen data. 
 
Underfitting:119Inadequate training or overly simple models may fail to capture the complexity 
of the task, resulting in general inaccuracies. 
5. Prompt design and input quality 
 
Prompt sensitivity:120LLMs are highly sensitive to how inputs are phrased. Minor variations in 
prompt structure can lead to drastically different outputs. 
 
Garbage in, garbage out:121Poorly worded or unclear input can lead to inaccurate or irrelevant 
responses. 
6. Limitations in knowledge 
 
Knowledge cutoff:122LLMs are trained on data up to a specific point in time. They may lack 
awareness of recent developments or emerging knowledge. 
 
Factual errors: 123 LLMs can "hallucinate" information, generating plausible but factually 
incorrect responses due to the probabilistic nature of their predictions. 
7. Lack of robustness 
 
Adversarial inputs: 124 LLMs may fail when presented with deliberately manipulated or 
adversarial inputs designed to exploit their weaknesses. 
                                                            
114 J. Browning, ‘Getting it right: the limits of fine-tuning large language models’ (2024) https://link.springer.com/article/10.1007/s10676-
024-09779-1 
115 E.Jones and J. Steinhardt, ‘Capturing Failures of Large Language Models via Human Cognitive Biases’ (2022) 
https://arxiv.org/abs/2202.12299 
116 G.B.Mohan et al. ’ An analysis of large language models: their impact and potential application’ (2024) 
https://link.springer.com/article/10.1007/s10115-024-02120-8 
117 H.Naveed et al ‘A Comprehensive Overview of Large Language Models’ (2024) https://arxiv.org/abs/2307.06435 
118 P.Jindal ‘Evaluating Large Language Models: A Comprehensive Guide’ (2024) https://www.labellerr.com/blog/evaluating-large-language-
models 
119 idem 
120 J.Browning ‘Getting it right: the limits of fine-tuning large language models’ (2024) https://link.springer.com/article/10.1007/s10676-024-
09779-1 
121 H.Naveed et al. ‘A Comprehensive Overview of Large Language Models’ (2024) https://arxiv.org/abs/2307.06435 
122 University of Oxford, ‘Large Language Models pose risk to science with false answers, says Oxford study’ (2023) 
https://www.ox.ac.uk/news/2023-11-20-large-language-models-pose-risk-science-false-answers-says-oxford-study 
123 ht Ho, D.E., ‘Hallucinating Law: Legal Mistakes with Large Language Models are Pervasive’(2024) 
https://hai.stanford.edu/news/hallucinating-law-legal-mistakes-large-language-models-are-pervasive 
124 E.Jones and J.Steinhardt, ‘Capturing Failures of Large Language Models via Human Cognitive Biases’ (2022) 
https://arxiv.org/abs/2202.12299

## Page 23 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
23 
 
 
Noise and variability: 125 Spelling errors, slang, or non-standard language can lead to 
misinterpretations and lower accuracy. 
8. Inadequate calibration 
 
Overconfidence:126Poorly calibrated models may assign high confidence scores to incorrect 
predictions, misleading users. Failing to properly convey uncertainty in predictions can erode 
trust in the model. 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
                                                            
125 G.B.Mohan ‘An analysis of large language models: their impact and potential applications’ (2024) 
https://link.springer.com/article/10.1007/s10115-024-02120-8 
126 L.Li et al. ‘Confidence Matters: Revisiting Intrinsic Self-Correction Capabilities of Large Language Models’ (2024) 
https://arxiv.org/abs/2402.12563

## Page 24 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
24 
 
3. Data Flow and Associated Privacy Risks in LLM Systems 
Understanding the data flow in AI systems powered by LLMs is crucial for assessing privacy risks. This 
flow may vary depending on the phases of operation, the specific system the model integrates, and the 
type of service model in use, each of which introduces unique challenges for data protection. 
 
The Importance of the AI Lifecycle in Privacy Risk Management 
The lifecycle of an AI system, as outlined in standards ISO/IEC 22989127and ISO/IEC 5338,128provides a 
structured framework for understanding the flow of data throughout the development, deployment, 
and operation of AI systems. This lifecycle is also essential for identifying and mitigating privacy risks at 
each stage. 
 
Figure 7. Source: Based on ISO/IEC 22989 
 
 
In this document, we use this AI lifecycle as a reference framework, recognizing that each organization 
may have its own adapted version based on its specific needs. While the core stages of the lifecycle are 
generally similar across organizations, the exact phases may vary. 
 
Each one of the phases of the lifecycle involves unique privacy risks that require tailored mitigation 
strategies. Implementing Privacy by Design into each phase helps to address risks proactively rather 
than retroactively fixing them. 
 
                                                            
127 ISO/IEC 22989 (Artificial Intelligence – Concepts and Terminology) 
128 ISO/IEC 5338:2023 Information technology — Artificial intelligence — AI system life cycle processes

## Page 25 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
25 
 
AI Lifecycle Phases and their Impact on Privacy 
1. Inception and Design: In this phase, decisions are made regarding data requirements, collection 
methods, and processing strategies. The selection of data sources may introduce risks if sensitive 
or personal data is included without adequate safeguards. 
2. Data Preparation and Preprocessing: Raw data is collected, cleaned, in some cases 
anonymized129, and prepared for training or fine-tuning. Datasets are often sourced from diverse 
origins, including web-crawled data, public repositories, proprietary data, or datasets obtained 
through partnerships and collaborations. 
 
Privacy risks:  
o Training data may inadvertently include personal details, confidential documents, 
or other sensitive information. 
o Inadequate anonymization or handling of identifiable data can lead to breaches or 
unintended inferences during later stages. 
o Biases present in the datasets can affect the model's predictions, resulting in 
unfair or discriminatory outcomes. 
o Errors or gaps in training data can adversely impact the model's performance, 
reducing its effectiveness and reliability. 
o The collection and use of training data may violate privacy rights, lack proper 
consent, or infringe on copyrights and other legal obligations. 
3. Development, Model Training: Prepared datasets are used to train the model, which involves 
large-scale processing. The model may inadvertently memorize sensitive data, leading to potential 
privacy violations if such data is exposed in outputs. 
4. Verification & Validation:130 The model is evaluated using test datasets, often including real-world 
scenarios. Testing data may inadvertently expose sensitive user information, particularly if real-
world datasets are used without anonymization. 
5. Deployment: The model interacts with live data inputs from users, often in real-time applications 
that could integrate with other systems. Live data streams might include highly sensitive 
information, requiring strict controls on collection, transmission, and storage. 
6. Operation and Monitoring: Continuous data flows into the system for monitoring, feedback, and 
performance optimization. Logs from monitoring systems may retain personal data such as user 
interactions, creating risks of data leaks or misuse. 
7. Re-evaluation, Maintenance and Updates: Additional data may be collected for retraining or 
updating the model to improve accuracy or address new requirements. Using live user data for 
updates without proper consent or safeguards can violate privacy principles. 
8. Retirement: Data associated with the model and its operations is archived or deleted. Failure to 
properly erase personal data during decommissioning can lead to long-term privacy 
vulnerabilities. 
 
Throughout the AI system lifecycle, it is important to consider how different types of personal data 
may be involved at each phase. Depending on the stage, personal data can be collected, processed, 
exposed, or transformed in different ways. Recognizing this variability is essential for implementing 
effective privacy and data protection measures. 
 
 
 
                                                            
129 Important to consider the EDPB opinion 28/2024 and section 3.2 On the circumstances under which AI models could be considered 
anonymous and the related demonstration: ‘…, the EDPB considers that, for an AI model to be considered anonymous, using reasonable 
means, both (i) the likelihood of direct (including probabilistic) extraction of personal data regarding individuals whose personal data were 
used to train the model; as well as (ii) the likelihood of obtaining, intentionally or not, such personal data from queries, should be 
insignificant for any data subject.’ 
130 Testing, Evaluation, Validation, and Verification (TEVV) is an ongoing process that occurs throughout the AI lifecycle to ensure that a 
system meets its intended requirements, performs reliably, and aligns with safety and compliance standards.

## Page 26 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
26 
 
 
 
Data Flow and Privacy Risks per LLM Service Model  
It is common to encounter terms like closed models, open models, closed weights, and open weights in 
the context of LLMs. Understanding these terms is essential for assessing the risks associated with 
different model release strategies. 
 
Closed models are proprietary models that do not provide public access to their weights or source code 
and interaction with the model is restricted, typically requiring an API or subscription, while open 
models are made publicly available fully (weights, full code, training data, and other documentation is 
available) or partly (not everything is available, usually training data; or it is available under licences). 
Similarly, closed weights indicate proprietary models whose trained parameters are not disclosed, 
whereas open weights describe models with publicly available parameters, allowing for inspection, fine-
tuning, or integration into other systems.  
It is also important to distinguish the term open model from open source model. This classification of a 
model as "open source" requires it to be released under an open source license, which legally grants 
anyone the freedom to use, study, modify, and distribute the model for any purpose131. 
 
Term 
Privacy Risks 
Closed models & 
closed weights 
Often minimal external transparency. Users rely entirely on the provider’s privacy 
safeguards, making it difficult to independently verify compliance with data protection 
regulations. 
Open models & 
open weights 
Risk of personal data exposure and security breaches if training data contains sensitive 
or harmful content. Partial access may prevent full scrutiny of model training data and 
privacy vulnerabilities. 
Open source 
Open source models share the same privacy risks as open models and open weight 
models. While open source fosters transparency and innovation, it also increases risks, 
as modifications may introduce security vulnerabilities or remove built-in safety 
measures. 
 
LLMs are predominantly accessible through the following service models: 
 
                                                            
131 AI Action Summit, ‘International AI Safety Report on the Safety of Advanced AI’ , p 150, (2025) 
https://assets.publishing.service.gov.uk/media/679a0c48a77d250007d313ee/International_AI_Safety_Report_2025_accessible_f.pdf 
Figure 8. The illustration shows how different types of personal data can arise across various phases of the AI lifecycle.

## Page 27 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
27 
 
1. LLM as a Service: This service model provides access to LLMs via APIs hosted on a cloud platform. 
Users can send input and receive output without having direct access to the model’s underlying 
architecture or weights.  
Based on this service model we can usually find the different LLM model variations available: 
o 
Closed models with closed weights where the provider trains the model and retains 
control over the weights and data, offering access through an API. This approach ensures 
ease of use but requires user data to flow through the provider’s systems. Example: 
OpenAI GPT-4 API132 
o 
Customizable closed weights where deployers may fine-tune the model using their own 
data, within a controlled environment, although the underlying weights remain 
inaccessible balancing customization with security. Example: Azure OpenAI Service133 
o 
Open weights where some providers grant deployers full or partial access to the 
architecture for greater transparency and flexibility through a platform or via an API134. 
Example: Hugging Face's models in AWS Bedrock135 
 
2. LLM ‘off-the-shelf’: In this service model the deployer can customize weights and fine tune the 
model. This happens sometimes through platforms like Microsoft Azure and AWS where a deployer can 
select a model and develop their own solution with it. It is also commonly used with open weight 
models, such as LLaMA or BLOOM. While an LLM as a Service typically involves API-based interaction 
without model ownership, the LLM ‘off-the-Shelf’ service emphasizes more developer and deployer 
control. The distinction lies in this level of control and access provided, for instance, in Hugging Face 
models can be downloaded locally. 
 
3. Self-developed LLM: In this model, organizations develop and deploy LLMs on their own 
infrastructure, maintaining full control over data and model interaction. While this option may offer 
more privacy, this service model requires of significant computational resources and expertise. 
 
Each of the three service models features a distinct data flow. While there are similarities across models, 
each phase—from user input to output generation—presents unique risks that can impact user privacy 
and data protection. In this section, we will first examine the data flow in an LLM as a Service solution, 
followed by an analysis of the key differences in data flow when using an LLM ‘off-the-shelf’ model and 
a self-developed LLM system. 
 
*Note that in this section, the terms 'provider'136 and 'deployer'137 are used as defined in the AI Act, where the 
provider refers to the entity developing and offering the AI system, and the deployer refers to the entity 
implementing and operating the system for end-users. 
 
                                                            
132 Open AI, ‘The most powerful platform for building AI products, (2025) https://openai.com/api/ 
133 Microsoft, ‘Azure OpenAI Service’ (2025) https://azure.microsoft.com/en-us/services/cognitive-services/openai-service/ 
134 Wikipedia, ‘API’ (2025)https://en.wikipedia.org/wiki/API 
135 S.Pagezy, ‘Use Hugging Face models with Amazon Bedrock’ (2024)  https://huggingface.co/blog/bedrock-marketplace 
136 ‘provider’ means a natural or legal person, public authority, agency or other body that develops an AI system or a general-purpose AI 
model or that has an AI system or a general-purpose AI model developed and places it on the market or puts the AI system into service under 
its own name or trademark, whether for payment or free of charge; (Article 3 (3) AI Act) 
137 ‘deployer’ means a natural or legal person, public authority, agency or other body using an AI system under its authority except where the 
AI system is used in the course of a personal non-professional activity; (Article 3 (4) AI Act)

## Page 28 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
28 
 
1. Data Flow in a LLM as a Service System 
In our example, a user interacts with an LLM application hosted online by a provider. This data flow 
focuses solely on the phases involved during the user’s interaction with the service. Model preparation, 
deployment, and integration by the provider are outside the scope since they will be examined further 
in the self-developed LLM system example. It is important to note that each use case will have its own 
specific data flow depending on its unique requirements and context and the examples provided in this 
section are intended to be generic representations. 
In an LLM as a Service scenario we could find these general data flow phases: 
 
 User input: 
The process starts with the user submitting input, such as a query or command. This could be entered 
through a web-based interface, mobile application, or other tools provided by the LLM provider. 
 Provider interface & API: 
The input is sent through an interface or application managed by the provider (e.g., a webpage, app or 
a chatbot window embedded on a website). This interface ensures the input is formatted appropriately 
and securely transmitted to the LLM infrastructure. 
 LLM processing at providers’ infrastructure: 
The API receives the input and routes it to the LLM model hosted on the provider's infrastructure. 
The LLM processes the input using its trained parameters (weights) to generate a relevant response. 
This may involve steps like tokenization, context understanding, reasoning, and text generation. The 
model generates a response. 
* Logging: The provider may log the user input (query) along with the generated response to analyze 
the interaction and identify system errors or gaps in response quality. 
The data could be also included in a training dataset to improve the model’s ability to handle similar 
queries in the future. In this case, anonymization and filtering techniques are often applied. 
 Processed output: 
The generated output is returned via the provider's interface to the user. The response is typically in a 
format ready for display or integration, such as text, suggestions, or actionable data. 
 
 
 
 
Privacy considerations in this data flow 
The following table highlights potential privacy and data protection risks and their recommended 
mitigations. 
Figure 9. Data Flow in a LLM as a Service System

## Page 29 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
29 
 
Phases
Possible Risks & Mitigations
User input 
Risks: 
Sensitive data disclosure: Users may unknowingly or inadvertently input sensitive 
personal data, such as names, addresses, financial information, or medical details. 
Unauthorized access: If the web interface, application, databases or input tool lacks 
robust access controls, unauthorized individuals138 may gain access to user accounts or 
systems, allowing them to view previously submitted data or queries. 
Lack of transparency: Users may not be fully aware of how their data will be used, 
retained, or shared by the provider. 
Adversarial attacks: A (malicious) user might craft input designed to manipulate the 
LLM’s behavior or bypass its intended functionality, such as injecting unauthorized 
instructions into queries (prompt injection attack), or users may try to bypass safety 
restrictions139 imposed on the model by crafting specific input (jailbreaking attempt)140. 
 
Mitigations for Providers: 
- 
Implement clear user guidance and input restrictions, such as filters or warnings to 
discourage the entry of personal data. Use automated detection mechanisms141142 to 
flag or anonymize sensitive information before it is processed or logged. 
- 
Encrypt user inputs and outputs during both transmission and storage to protect 
sensitive data from unauthorized access. Insufficient encryption can expose user 
queries and data to potential breaches, especially during the user input phase. 
Ensure encryption in transit using robust protocols (e.g., TLS) and encryption at rest 
for stored data. Additionally, implement data segregation practices to isolate user 
data, preventing unauthorized individuals from accessing or compromising multiple 
accounts or datasets. 
Another mitigation to prevent unauthorized access is the implementation of secure 
password practices based on the latest NIST143 and ENISA144 recommendations: 
require a minimum password length of 8 characters, update passwords if they are 
compromised or forgotten, enforce the use of multifactor authentication (MFA), 
ensure passwords differ significantly from previous ones, check passwords against 
blacklists, enforce account lockout policies, monitor failed login attempts, discourage 
the use of password hints, and store passwords securely using hashing and salting 
techniques with robust algorithms such as bcrypt, Argon2, or PBKDF2. 
- 
Inform users about how their data will be used, retained, and processed through 
clear and easily accessible privacy policies. 
- 
Though there are currently no foolproof measures145 to protect against prompt 
injection and jailbreaking,146147some of the most common best practices include the  
                                                            
138 G. Nagli ‘Wiz Research Uncovers Exposed DeepSeek Database Leaking Sensitive Information, Including Chat History’ (2025) 
https://www.wiz.io/blog/wiz-research-uncovers-exposed-deepseek-database-leak 
139 T.S. Dutta ‘New Jailbreak Techniques Expose DeepSeek LLM Vulnerabilities, Enabling Malicious Exploits’ (2025) 
https://cybersecuritynews.com/new-jailbreak-techniques-expose-deepseek-llm-vulnerabilities/ 
140 S.Schulhoff ‘Prompt Injection vs. Jailbreaking: What's the Difference?’ (2024) https://learnprompting.org/blog/injection_jailbreaking  
141 https://www.nightfall.ai/ai-security-101/data-leakage-prevention-dlp-for-llms  
142 Some of the tools used are Google Cloud DLP, Microsoft Presidio, OpenAI Moderation API, Hugging Face Fine-Tuned NER Models and 
spaCy (links available in section 10) 
143 P.A. Grassi et al., (2017) NIST Special Publication 800-63-3 Digital Identity Guidelines 
https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-63-3.pdf 
144 ENISA, ‘Basic security practices regarding passwords  
and online identities’ (2014) https://enisa.europa.eu/sites/default/files/all_files/ENISA%20guidelines%20for%20passwords.pdf 
145 Kosinski, M., ‘How to prevent prompt injection attacks’ (2024) https://www.ibm.com/think/insights/prevent-prompt-injection 
146 A.Peng et al. ‘Rapid Response: Mitigating LLM Jailbreaks with a Few Examples’ (2024) https://arxiv.org/abs/2411.07494 
147 B.Peng et al. ‘Jailbreaking and Mitigation of Vulnerabilities in Large Language Models’ (2024) https://arxiv.org/abs/2410.15236

## Page 30 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
30 
 
validation of input, filtering to detect malicious patterns, monitoring of LLMs for 
abnormal input behavior, implementing rate-limiting, structure queries148and limiting 
the amount of text a user can input149. 
 
Mitigations for Deployers: 
- 
Limit the amount of sensitive data and guide users to avoid sharing unnecessary 
personal information through clear instructions, training and warning. Work with 
providers to ensure they adhere to data protection regulations and do not retain or 
misuse (sensitive) input data. 
- 
Require secure user authentication to restrict access to the input interface and 
protect session data. As highlighted in the provider's mitigations, deployers should 
also implement secure password practices based on the latest NIST and ENISA 
recommendations,150 encourage users to adopt password managers,151 and raise 
awareness about secure practices and internal password policies among users, such 
as employees. 
- 
Clearly communicate to users how their data is handled and processed at each phase 
of the data flow. This could be done through (internal) privacy policies, instructions, 
warning or disclaimers in the user interface. 
- 
To mitigate adversarial attacks several measures can be implemented such as adding 
a layer for input sanitization and filtering, monitoring and logging user queries to 
detect unusual patterns, and incorporating post-processing layers to validate 
outputs. Additionally, educating users on proper usage can help reduce the likelihood 
of unintentional inputs that may lead to harmful outcomes. 
Provider 
interface & 
API 
Risks: 
Data interception: Insufficient encryption during data transmission to the provider’s 
servers may expose input to interception by third parties. 
API misuse: If API access is not restricted and secured, attackers could exploit the API to 
intercept or manipulate data. Attackers could also overwhelm the API with excessive 
traffic to disrupt its availability (Denial-of-Service (DoS) Attacks). 
Interface vulnerabilities: Interface vulnerabilities refer to weaknesses in the provider's 
user interface that may expose user data to malicious actors. These vulnerabilities can 
stem from technical flaws (e.g., insufficient input validation, misconfigured API 
endpoints) or social engineering tactics such as phishing. For example, attackers could 
create fake versions of a chatbot interface (e.g., replicating the design and branding) to 
trick users into entering sensitive information such as credentials, payment details, or 
personal data. Malicious actors could develop deceptive applications claiming to be 
legitimate integrations with the provider’s API, tricking end-users into sharing sensitive 
data. 
 
Mitigations for Providers: 
- 
Enforce end-to-end encryption for all data transmissions, regularly update encryption 
protocols, and use secure key management practices. 
- 
Implement strong authentication (e.g., API keys, OAuth), enforce rate limits152, 
monitor for suspicious activity (anomaly detection), and regularly audit API security. 
- 
Perform regular security testing, apply input validation to prevent attacks, and 
implement robust session management controls. Regarding phishing, both provider 
                                                            
148 S.Cheng et al. ‘StruQ: Defending Against Prompt Injection with Structured Queries’ (2024) https://arxiv.org/abs/2402.06363 
149 Open AI Platform, ‘Safety best practices’ (n.d) https://platform.openai.com/docs/guides/safety-best-practices#constrain-user-input-and-
limit-output-tokens 
150 Trust Community, NIST password guidelines 2025: 15 rules to follow’ (2024) https://community.trustcloud.ai/article/nist-password-
guidelines-2025-15-rules-to-follow/ 
151 Wikipedia, ‘Password Manager’ (2025) https://en.wikipedia.org/wiki/Password_manager 
152 LLM Engine, (n.d) https://llm-engine.scale.com/guides/rate_limits/

## Page 31 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
31 
 
and deployer have roles in addressing this risk. The provider should implement 
platform-level protections, such as safeguarding the authenticity of their interface 
(e.g., anti-spoofing measures, branding protections, secure APIs), monitoring for 
suspicious activity, and providing tools to help deployers detect and prevent abuse. 
Mitigations for Deployers: 
- 
If the deployer is using only the provider's interface, their responsibility is limited to 
securely managing access credentials and complying with data handling policies; 
however, if the deployer integrates the provider’s API into their own systems, they 
are additionally responsible for securing the integration, including encryption, 
monitoring, and safeguarding data in transit.  
Both provider and deployer should design, develop, deploy and test applications and 
APIs in accordance with leading industry standards (e.g., OWASP for web 
applications153) and adhere to applicable legal, statutory or regulatory compliance 
obligations. 
- 
The deployer should educate employees and end users about evolving phishing 
techniques—such as fake interfaces, deceptive emails, or fraudulent integrations—
that could trick individuals into revealing sensitive information. Education should 
focus on recognizing suspicious behaviors and verifying the legitimacy of 
communications and interfaces.  
LLM 
processing at 
Providers’ 
infrastructure 
Risks: 
Model inference risks: During processing, the model might inadvertently infer sensitive 
or inappropriate outputs based on the training data or provided input. 
(Un)intended data logging: Providers can log user input queries and outputs for 
debugging or model improvement, potentially storing sensitive data154 without explicit 
user consent. If logged user queries are included in training data, in case of an adversarial 
attack, attackers might introduce malicious or misleading content to manipulate the 
model’s future outputs (data poisoning attack)155. 
Anonymization failures: Inadequate anonymization or filtering techniques could lead to 
the inclusion of identifiable user data in model training datasets, raising privacy concerns.
Unauthorized access to logs: Logs containing user inputs and outputs could be accessed 
by unauthorized personnel or exploited in the event of a data breach. 
Data aggregation risks: If logs are aggregated over time, they could form a 
comprehensive dataset that may reveal patterns about individuals, organizations, or 
other sensitive activities. 
Third-party exposure: If the provider relies on external cloud infrastructure or third-party 
tools for LLM processing, there’s an added risk of data exposure through those 
dependencies. These dependencies involve external systems, which may have their own 
vulnerabilities. 
Lack of data retention policies: The provider could store the data indefinitely without 
having retention policies in place. 
 
Mitigations for Providers: 
- 
Implement strict content filtering mechanisms and human review processes to flag 
sensitive or inappropriate outputs. 
- 
Minimize data logging, collect only necessary information, and ensure you have a 
proper legal basis for any processed data. Use trusted sources for training data and 
validate its quality. Sanitize and preprocess training data to eliminate vulnerabilities 
or biases. Regularly review and audit training data and fine-tuning processes for 
                                                            
153 OWASP, ‘OWASP Top Ten’ (2025) https://owasp.org/www-project-top-ten/ 
154 The data stored could be sensitive data such as credit card numbers, or special category of data such as health data (article 9 GDPR). 
155 Aubert, P. et al., ‘Data Poisoning: a threat to LLM’s Integrity and Security’ (2024) https://www.riskinsight-
wavestone.com/en/2024/10/data-poisoning-a-threat-to-llms-integrity-and-security/

## Page 32 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
32 
 
issues or manipulations. Implement monitoring and alerting systems to detect 
unusual behavior or potential data poisoning156. 
- 
Apply robust anonymization techniques, regularly test them for effectiveness, and 
use automated tools to identify and remove identifiable data before use in training. 
- 
Enforce strong access controls, encrypt log data, and monitor access logs for 
suspicious activity to prevent breaches.  
- 
Providers must implement a robust third-party risk management program, adhering 
to best known frameworks157 to ensure a secure environment. Key measures include 
conducting thorough vendor assessments, ensuring compliance with security 
standards, requiring strong data encryption during transmission and storage, 
conducting security audits, implementing real-time monitoring and incident response 
plans tailored to third-party dependencies.  Providers should also implement 
protections against threats such as DoS/DDoS attacks, which can disrupt operations 
and expose systems to further risks.  
- 
Clearly define retention policies, align them with legal requirements and where 
possible provide users with options to delete their data. 
Processed 
Output 
Risks: 
Inaccurate or sensitive responses: The model may generate outputs that reveal 
unintended sensitive information or provide inaccurate or misleading information 
(hallucinations)158, leading to harm or misinformation. 
Re-identification risks: Outputs could inadvertently reveal information about the user’s 
query or context that can be linked back to them. 
Output misuse159: Users or third parties may misuse the generated output. 
 
Mitigations for Providers: 
- 
Implement post-processing filters to detect and remove sensitive or inaccurate 
content, and regularly retrain the model using updated and verified datasets to 
improve response accuracy. Implement disclaimers to highlight potential limitations 
of AI-generated responses. 
- 
Apply privacy-preserving techniques to help you redact sensitive identifiers in 
outputs and minimize the inclusion of unnecessary contextual details in generated 
responses. 
- 
Provide clear usage policies, educate users on ethical use of outputs, and implement 
mechanisms to detect and prevent the misuse of generated content where feasible. 
Mitigations for Deployers: 
- 
For critical applications, ensure generated outputs are reviewed by humans before 
implementation or dissemination. 
- 
Educate end-users on ethical and appropriate use of outputs, including avoiding 
overreliance on the model for critical or high-stakes decisions without verification. 
- 
Securely store outputs and restrict access to authorized personnel or systems only. 
 
2. Data Flow in an ‘off-the-shelf’ LLM System 
The most common use case for this service model involves organizations leveraging a pre-trained model 
from a platform to develop and deploy their own AI system. Once the AI system is operational, the data 
                                                            
156 OWASP, ‘LLM10:2023 - Training Data Poisoning’ (2023) https://owasp.org/www-project-top-10-for-large-language-model-
applications/Archive/0_1_vulns/Training_Data_Poisoning.html 
157 Center for Internet Security, ’ The 18 CIS Critical Security Controls’ (2025) https://www.cisecurity.org/controls/cis-controls-list 
158 Wikipedia, ‘Hallucination Artificial Intelligence’ (2025) https://en.wikipedia.org/wiki/Hallucination_(artificial_intelligence) 
159 OWASP, ‘LLM05:2025 Improper Output Handling’ (2025) https://genai.owasp.org/llmrisk/llm052025-improper-output-handling/

## Page 33 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
33 
 
flow closely resembles that of an LLM as a Service model, particularly during user interactions and 
output generation. 
 
 
 
However, several key differences and limitations set these models apart: 
 
Roles and responsibilities: 
Organizations developing an LLM system using the ‘off-the-shelf’ model may be considered providers160, 
particularly when they intend to place the system on the market for use by others (deployers of their 
system and end-users). This introduces an additional layer of responsibility for data handling, security, 
and compliance with privacy regulations. The organization may also be developing the AI system for its 
own internal use. 
 
Hosting and processing: 
In a LLM ‘off-the-shelf’ based system, the provider hosts the model on their infrastructure or a third-
party cloud environment of their choice. This contrasts with the LLM as a Service model, where hosting 
and processing are entirely managed by the original model provider. The new provider is now 
responsible for all aspects of system integration, maintenance, and security. 
 
Customization and training: 
A notable difference is that the initial training and fine-tuning of the model were conducted by the 
original provider, which can introduce risk and limitations: 
o The new provider has often no oversight or knowledge of the contents of the dataset used during 
the model’s initial training, which may introduce biases, inaccuracies, or unknown privacy risks161. 
o The new provider remains dependent on the original provider for updates or bug fixes to the model 
architecture, potentially delaying critical improvements or fixes. 
o Fine-tuning may be limited by the capabilities of the off-the-shelf model. New providers might only 
be able to adjust certain parameters or add new layers rather than fully retrain the model, 
restricting its adaptability for highly specific use cases. 
o In such cases, retrieval-augmented generation (RAG) is a commonly used alternative. Instead of 
embedding domain-specific knowledge into the model itself, RAG connects the model to an external 
knowledge base and retrieves relevant documents at runtime to ground its responses. This enables 
dynamic, accurate, and updatable answers without modifying the base model, a key advantage for 
domains with evolving information or regulatory requirements. 
                                                            
160 According to Article 25 of the AI Act, a deployer of a high risk AI system becomes a provider when they substantially modify an existing AI 
system, including by fine-tuning or adapting a pre-trained model for new applications. In such cases, the deployer assumes the 
responsibilities of a provider under the AI Act. 
161 EDPB Opinion 28/2024 on certain data protection aspects related to the processing of personal data in the context of AI models. Adopted 
on 17 December 2024 
Figure 10. Data Flow in an ‘off-the-shelf’ LLM System

## Page 34 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
34 
 
A similar approach is cache-augmented generation (CAG) 162 which can reduce latency, lower 
compute costs, and ensure consistency in responses across repeated interactions but that is less 
practical for large datasets that are often updated. 
 
The figure below illustrates how RAG163 works: the user's query is first enhanced with relevant 
information retrieved from an external database, and this enriched input is then sent to the 
language model to generate a more accurate and grounded response. 
 
 
 
 
 
Some common privacy risks of using RAG are: 
 
 
Insecure logging or caching: User queries and retrieved documents may be stored insecurely, 
increasing the risk of unauthorized access or data leaks. 
 
Third-party data handling: If the retrieval system uses external APIs or services, user queries 
may be sent to third parties, where they can be logged, tracked, or stored without user consent. 
 
Exposure of sensitive data: The model may retrieve personal or confidential information if this 
is stored in the knowledge base. 
3. Data Flow in a Self-developed LLM System 
In a self-developed LLM system, the organization takes full responsibility for designing, training, and in 
some cases also deploying the model. This approach provides maximum control over the LLM model 
but also introduces unique challenges across the data flow.  
Since we have already explored an example of privacy risks within the AI lifecycle data flow in a 
previous section, we will take here a more general approach, focusing on some of the important 
phases for this service model. The general data flow phases could be as follow: 
 Dataset collection and preparation: 
The organization collects and curates164 large-scale datasets for training the LLM.  
 Model training: 
The training phase involves using the collected dataset to develop the LLM. This typically requires 
significant computational resources and specialized infrastructure, such as high-performance GPUs or 
                                                            
162 Sharma, R., ‘Cache RAG: Enhancing speed and efficiency in AI systems’ (2025) https://developer.ibm.com/articles/awb-cache-rag-
efficiency-speed-ai/ 
163 Theja, R., ‘Evaluate RAG with LlamaIndex’ (2023) https://cookbook.openai.com/examples/evaluation/evaluate_rag_with_llamaindex 
164 Atlan, ‘Data Curation in Machine Learning: Ultimate Guide 2024’ (2023) https://atlan.com/data-curation-in-machine-learning/ 
Figure 11. RAG Diagram – Open AI Cookbook

## Page 35 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
35 
 
distributed computing systems. Before deployment, the model undergoes rigorous evaluation and 
testing using separate validation and test datasets to ensure its accuracy, reliability, and alignment 
with intended use cases. 
 Fine-Tuning: 
After initial training, the model may be fine-tuned using additional datasets to specialize its 
capabilities for specific tasks or domains. 
 Deployment: 
The trained and fine-tuned LLM is integrated into the organization’s infrastructure, making an 
interface available for end-users. 
 User input: 
End-users interact with the deployed AI system by submitting inputs through an interface such as an 
app, chatbot, or custom API. 
 Provider interface & API: 
The input is sent through an interface or application. This interface ensures the input is formatted 
appropriately and securely transmitted to the LLM infrastructure. 
 Model processing: 
The self-developed LLM processes user inputs locally or on the organization’s (cloud) infrastructure, 
generating contextually relevant responses using its trained parameters. 
 Processed output delivery: 
The processed outputs are delivered to end-users or integrated into downstream systems for 
actionable use. Outputs may include text-based responses, insights, or recommendations.          
                         
                          
 
 
 
 
Privacy considerations in self-developed LLM systems 
Self-developing an LLM system provides significant control but also introduces privacy and data 
protection risks at each phase of the data flow. Below are some of the key risks and suggested 
mitigations: 
Phases
Possible Risks & Mitigations
Dataset 
collection and 
preparation 
Risks: 
Sensitive data inclusion: Collected datasets could (inadvertently) include personal or 
sensitive information. 
Legal non-compliance: The data could be collected unlawfully violating data 
protection regulations like GDPR. 
Dataset 
Collection 
and 
Preparation
Model 
Training & 
Fine-tuning
Deployment
Figure 12. Data Flow in a Self-developed LLM

## Page 36 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
36 
 
Bias and discrimination: Datasets could reflect societal or historical biases, leading to 
discriminatory outputs. 
Data poisoning: Datasets may be intentionally manipulated by malicious actors during 
collection or preparation, introducing corrupted or adversarial data to mislead the 
model during training.  
 
Mitigations for Providers: 
- 
Apply anonymization and pseudonymization techniques165 to minimize privacy 
risks. 
- 
In certain use cases, and after carefully weighing the potential pros and cons,166167 
the creation of synthetic data using LLMs168 could be an alternative to the use of 
real personal data. However, synthetic data might not always be suitable169, as its 
quality and utility depend on the specific requirements and context of the 
application. 
- 
Ensure data collection is compliant with regulations. 
- 
Regularly audit datasets for bias and sensitive content, removing any problematic 
entries. 
- 
Implement robust data validation and monitoring to detect and prevent malicious 
or corrupted data. Use trusted data sources, apply automated checks for 
anomalies, and cross-validate data from multiple sources.  
Model training 
Risks: 
Unprotected training environment: Training infrastructure may be vulnerable to 
unauthorized access, which could expose sensitive data or allow malicious actors to 
compromise the training process.  
Data overfitting: The model may inadvertently memorize sensitive information 
instead of generalizing patterns. 
 
Mitigations for Providers: 
- 
Cybersecurity should follow a layered approach, implementing multiple defenses 
to prevent unauthorized access and mitigate its impact. Mitigations that could be 
implemented include: using secure computing environments with strong access 
controls during training (e.g., multi-factor authentication (MFA), privileged access 
management (PAM)170, or role-based access controls (RBAC)171); applying network 
segmentation to isolate the training infrastructure from other systems and reduce 
the attack surface; monitoring and logging access to promptly detect and respond 
to unauthorized activities; and using encryption for both data at rest and in transit 
to secure sensitive training data.  
Another mitigation measure to reduce data exposure is the integration of 
differential privacy techniques, which add noise to training data to prevent 
individual data points from being re-identified, even if the model is compromised. 
                                                            
165 ENISA, ‘Pseudonymisation techniques and best practices. Recommendations on shaping technology according  
to data protection and privacy provisions’ (2019)  
https://www.enisa.europa.eu/sites/default/files/publications/Guidelines%20on%20shaping%20technology%20according%20to%20GDPR%2
0provisions.pdf 
166 Marwala, T., ‘Algorithm Bias — Synthetic Data Should Be Option of Last Resort When Training AI Systems’ (2023) 
https://unu.edu/article/algorithm-bias-synthetic-data-should-be-option-last-resort-when-training-ai-systems 
167 Van Breugel, B. et al., ‘Synthetic Data, Real Errors: How (Not) to Publish and Use Synthetic Data’ (2023) 
https://proceedings.mlr.press/v202/van-breugel23a/van-breugel23a.pdf 
168 Vongthongsri, K., ‘Using LLMs for Synthetic Data Generation: The Definitive Guide’ (2025) https://www.confident-ai.com/blog/the-
definitive-guide-to-synthetic-data-generation-using-llms 
169 Desfontaines, D., ‘The fundamental trilemma of synthetic data generation’ (n.d) https://www.tmlt.io/resources/fundamental-trilemma-
synthetic-data-generation 
170 Wikipedia, ‘Private access management’ (2025) https://en.wikipedia.org/wiki/Privileged_access_management 
171 Wikipedia, ‘Role-based access control’ (2025) https://en.wikipedia.org/wiki/Role-based_access_control

## Page 37 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
37 
 
It is important to assess the specific use case to determine whether differential 
privacy is suitable, as it may impact model accuracy in certain scenarios. 
- 
Evaluate the model for overfitting and ensure sensitive data is not exposed in 
outputs. 
Fine-Tuning
Risks:
Exposure of proprietary or sensitive data: Fine-tuning data may include sensitive or 
proprietary information, risking leakage. 
Third-party risks: If external platforms are used for fine-tuning, sensitive data may be 
exposed to additional risks. 
 
Mitigations for Providers: 
- 
Encrypt fine-tuning datasets and restrict access to authorized personnel. 
- 
Use trusted platforms with robust privacy assurances for fine-tuning. 
- 
Only include data strictly necessary for fine-tuning tasks. 
Deployment 
Risks: 
Unauthorized access: Weak access controls could allow unauthorized parties to 
interact with the model or access underlying systems. 
Unsecure hosting: Hosting the model on an unsecured server or cloud environment 
could expose sensitive data. 
 
Mitigations for Providers: 
- 
Implement strong authentication and role-based access controls for model and 
system access. 
- 
Use cloud environments with strong encryption and monitoring. 
- 
Periodically review deployment configurations for vulnerabilities. 
User input
See previous table on risks in the data flow of LLM as a Service, where this phase is 
detailed. The applicable mitigation measures primarily concern providers, but also 
extend to deployers in scenarios where developers are deploying and using their self-
developed AI systems. 
Provider 
interface & API 
Idem
LLM processing 
at Providers’ 
infrastructure 
Idem 
Processed Output
Idem 
 
4. Data Flow in LLM-based Agentic Systems 
AI Agents also encompass the data flow phases discussed so far, but they introduce additional 
complexity due to their many interactions with other systems and applications. These agents not only 
process user inputs but also engage with external applications to retrieve information, execute 
commands, or perform actions. This is often done through function calls, where the agent uses 
structured interfaces (e.g., APIs) to interact with external tools. In some cases, a Context Management 
Protocol (CMP)172 is used to manage and track these interactions, ensuring the agent has access to 
relevant context across multiple steps or tools. In this example, we explore the data flow of an AI agent 
interacting with two external applications, highlighting the most common privacy and data protection 
challenges introduced by these interactions.  
                                                            
172 Anthropic, ‘Introducing the Model Context Protocol’ (2024)  https://www.anthropic.com/news/model-context-protocol

## Page 38 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
38 
 
A simplified overview of the most common phases involved in this data flow includes: 
 User input: 
The process begins with the user providing input to the AI agent, such as a query, command, or task 
description (e.g., “Book me a flight and a hotel for my trip to Amsterdam”). 
o Actions: 
- 
Input is collected through the user interface, such as a chatbot or voice assistant. 
- 
Preprocessing may occur locally to sanitize and standardize the input. 
 Agent processing: 
The AI agent uses an integrated LLM to understand and process the user input. This includes parsing 
the request and identifying the actions required to fulfill the task. 
o Actions: 
- 
The input is tokenized and interpreted by the LLM. 
- 
The agent decides which external applications to contact and formulates queries or 
commands for them. 
 Interaction with application 1 (e.g., flight booking system): 
The agent sends a query or command to the first external application to retrieve or process 
information. For instance, it may request available flights based on the user’s travel preferences. 
o Actions: 
- 
Data (e.g., user preferences) is transmitted to the external application. 
- 
The application processes the query and returns a response, such as a list of available 
flights. 
- 
The agent receives and processes the response for integration into the overall 
workflow. 
 Interaction with application 2 (e.g., hotel booking system): 
The agent engages with the second external application to complete another part of the task. For 
example, it might request hotel options based on the destination and travel dates. 
o Actions: 
- 
Data (e.g., travel dates) is transmitted to the application. 
- 
The application provides a response, such as available hotels, which is processed by 
the agent. 
 Aggregation of responses: 
The AI agent integrates the responses from both applications to generate a cohesive result. For 
instance, it compiles the flight and hotel options into a single output for the user. 
o Actions: 
- 
Responses are validated and formatted for clarity and relevance. 
- 
Potential errors or conflicts (e.g., overlapping schedules) are resolved. 
 Output generation: 
The agent delivers the aggregated result to the user in a user-friendly format, such as a summary of 
booking options or actionable recommendations. 
o Actions: 
- 
Output is displayed via the user interface or transmitted to another system for further 
action. 
- 
If necessary, the agent provides follow-up prompts to refine the user’s preferences or 
choices. 
 Logging and continuous improvement: 
Interaction logs may be stored temporarily for debugging, system improvements, or retraining 
purposes, depending on the organization’s policies. 
o Actions: 
- 
Logs are analyzed to optimize the agent’s performance and enhance user experience.

## Page 39 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
39 
 
 
 
 
Overview of Possible Risks and Mitigations 
AI agents represent a significant advancement in leveraging LLMs for complex, multi-application tasks. 
Their data flow incorporates traditional phases seen in LLM systems, but their integration with other 
systems and their modular agentic architecture—comprising perception, reasoning, planning, memory, 
action, and feedback loops—introduces unique privacy challenges. Below is an overview of some key 
privacy risks and corresponding mitigations173 for each phase, with an emphasis on how these phases 
align with the agentic architecture. 
 
Phases 
Possible Risks & Mitigations 
Perception 
(user input 
collection and 
preprocessing)
Risks:
- 
Sensitive user input (e.g., personal, financial) or special categories of data (e.g., 
medical data) could be collected and exposed. 
- 
Lack of proper preprocessing may retain identifiable information. 
- 
Inputs entered into vulnerable interfaces may be intercepted or misused. 
- 
Lack of transparency: Users may not be fully aware of how their data will be used, 
retained, or shared with the different applications the system will integrate and 
communicate. 
 
Mitigations for Providers: 
- 
Limit data collection to only what is strictly necessary. 
- 
Anonymize and preprocess input data to remove sensitive elements.  
- 
Provide tools, interfaces, or APIs that allow deployers to collect user consent when 
necessary 
- 
Secure user interfaces with encryption and authentication mechanisms to protect 
input data. 
- 
Inform users about how their data will be used, retained, and processed through 
clear and easily accessible privacy policies. 
Mitigations for Deployers: 
                                                            
173 OWASP, ‘Agentic AI – Threats and Mitigations’ (2025) https://genaisecurityproject.com/resource/agentic-ai-threats-and-mitigations/ 
Figure 13. Data Flow in LLM-based Agentic Systems

## Page 40 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
40 
 
- 
Configure the integrations to only collect and store necessary input data. Avoid 
requesting or storing sensitive data unless explicitly required for the task. 
- 
Implement preprocessing pipelines to remove sensitive information before inputs 
are sent to the provider’s system. 
- 
When necessary, implement user-facing consent forms or interfaces when collecting 
data to use with the LLM. 
- 
Secure user interfaces with encryption and authentication mechanisms to protect 
input data and ensure data is handled properly at the deployment level through 
encrypted local storage and secure API connections. 
- 
Clearly communicate to users how their data is handled and processed. This could be 
done through (internal) privacy policies, warnings, instructions or disclaimers in the 
user interface. 
Reasoning 
(agent 
processing) 
Risks: 
- 
Sensitive data used in reasoning tasks may be misused or exposed. 
- 
Improper handling of user data during task decomposition may propagate sensitive 
information. 
- 
Inferences made during reasoning could unintentionally reveal personal insights. 
- 
Limited explainability could lead to incorrect or suboptimal outputs, reducing trust 
and reliability, especially in complex decision-making tasks. Without clear reasoning 
chains, users may struggle to understand or verify how conclusions are reached, 
increasing the probability of errors and unintended outcomes. 
 
Mitigations for Providers: 
- 
Implement mechanisms to anonymize or preprocess sensitive input data to minimize 
the risk of sensitive information being used during reasoning tasks. 
- 
Provide robust access control features that limit which entities can process sensitive 
data, even during complex reasoning tasks. 
- 
Ensure that all reasoning outputs are logged securely and are auditable by deployers, 
enabling the tracking of inferences for sensitive information leakage.  
- 
Integrate mechanisms for generating reasoning chains (e.g., Chain of Thought) to 
make the LLM's decision-making process more transparent and auditable. 
Mitigations for Deployers: 
- 
Minimize the use of sensitive data during processing and reasoning. 
- 
Ensure all inferences and intermediate data are auditable and securely stored. 
- 
Apply strict access controls and logging to monitor and limit misuse. 
- 
Implement the Chain of Thought (CoT)174 framework to enhance the reasoning 
capabilities of LLMs. This can be achieved either through user prompting, where logic 
for solving problems is provided manually, or through Automated CoT (Auto-CoT), 
which clusters questions and generates reasoning chains without human 
intervention. Auto-CoT is particularly effective for LLMs with around 100B 
parameters but may be less accurate for smaller models.175 
Planning (task 
organization 
and external 
interactions) 
Risks:
- 
Sensitive data could be transmitted to external applications without proper 
safeguards. Function calls may transmit excessive or unnecessary user data to 
external applications, especially if parameter filtering is not properly implemented. 
Third-party systems may not adhere to the same privacy and security standards. 
 
                                                            
174 Gadesha, V., ‘What is chain of thoughts (CoT)?’ (2024) https://www.ibm.com/think/topics/chain-of-thoughts 
175 Biswas, D., ‘Stateful and Responsible AI Agents’ (2024) https://www.linkedin.com/pulse/stateful-responsible-aiagents-debmalya-biswas-
runze/

## Page 41 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
41 
 
Mitigations for Providers and Deployers:176
- 
Use anonymization and encryption when transmitting data to external applications. 
- 
Monitor third-party applications to ensure that external systems interacting with AI 
agents adhere to the same privacy, security, and regulatory standards as your own 
system: conduct vendor assessments, verify that third-party providers have up-to-
date security certifications, such as ISO 27001, SOC 2, or similar, to confirm they 
meet recognized security standards, establish contracts or data processing 
agreements that include clear expectations for privacy compliance, use tools to 
monitor third-party applications in real time for suspicious activity and ensure third-
party providers have robust incident response plans to handle potential breaches 
notifying stakeholders in a timely manner. 
- 
Implement effective Identity and Access Management:177 implement a zero trust 
security model continuously verifying identity and device, and assuming no implicit 
trust; implement dynamic, context-aware access controls adjusting permissions 
based on real-time factors like location, device status, or behavior to reduce risks; 
grant just-in-time access, ensuring AI agents only have permissions for the duration 
of their tasks, minimizing privilege creep; review and update access controls during 
an AI agent's lifecycle; automate credential rotation, key management, and 
certificate updates to maintain security and reduce human error. 
- 
Obtain, when necessary, user consent for external interactions and provide policies 
transparently. 
- 
Implement filter parameters in function calls and avoid sending and retaining 
sensitive intermediate data unnecessarily. 
Memory (data 
storage and 
retention) 
Risks: 
- 
Long-term storage of user data increases the risk of unauthorized access or misuse. 
- 
Retention of sensitive data across interactions may violate privacy regulations. CMPs 
maintain context across multiple interactions, which may result in long-lived sessions 
where sensitive data accumulates. 
 
Mitigations for Providers and Deployers:178 
- 
Allow users to manage stored data (e.g., delete, edit). 
- 
Apply secure storage solutions with robust access controls and encryption. 
- 
Limit retention periods and implement automated deletion policies for sensitive 
data. 
Action 
(Output 
generation 
and delivery) 
Risks: 
- 
Generated outputs might inadvertently include sensitive or private information. 
- 
Outputs shared with external systems could be intercepted or misused. 
- 
When orchestrating multiple AI agents, the probability of hallucinations increases as 
the number of agents involved grows. 
 
Mitigations for Providers and Deployers:179 
- 
Validate and filter outputs to ensure they do not reveal sensitive information. 
- 
Secure output delivery channels with encryption and authentication mechanisms. 
- 
Monitor interactions with external systems for adherence to privacy standards. 
                                                            
176 Providers are responsible for ensuring the foundational model and platform are secure, privacy-compliant, and equipped with features for 
secure deployment that deployers can configure. Deployers are responsible for integrating, configuring, and using the LLM securely within 
their specific context. The division of responsibilities depends on the level of customization required by the deployer and the deployment 
context, with both parties sharing accountability for implementing necessary mitigations. 
177 McDougald, D., et al., ‘Strengthening AI agent security with identity management’ (2025) https://www.accenture.com/us-
en/blogs/security/strengthening-ai-agent-security-identity-management 
178 See footnote 176 
179 idem

## Page 42 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
42 
 
- 
To reduce hallucinations, though crafted prompts can be helpful, they offer limited 
effectiveness. LLMs should be fine-tuned with curated, high-quality data and 
configured to limit the search space of responses to relevant and up-to-date 
information180.            
Feedback and 
Iteration Loop 
(learning and 
improvement)
 
Risks:
- 
User feedback may be stored or used for model retraining without consent. 
- 
Sensitive feedback information may unintentionally persist in logs or datasets. 
 
Mitigations for Providers: 
- 
Ensure the platform includes clear and user-friendly mechanisms for users to opt-in 
or opt-out of having their feedback data used in model retraining. 
- 
Offer built-in tools or features to automatically anonymize or pseudonymize 
feedback data before storing or processing it for retraining purposes. 
- 
Limit log retention periods by default and provide configurable options to deployers 
to ensure compliance with privacy regulations. 
Mitigations for Deployers: 
- 
Clearly communicate to users how their feedback data will be used and ensure 
robust tracking of user consent (opt-in/opt-out) mechanisms provided by the 
platform. 
- 
Use anonymization and pseudonymization tools to securely handle feedback data. 
- 
Limit log retention periods and ensure compliance with privacy regulations. 
Considerations on External Integrations in LLM Data Flows 
Across all service models—whether SaaS-based, off-the-shelf, self-developed, or agentic AI — LLMs may 
interact with external systems, adding complexity to the data flow. These interactions can include 
retrieving information from external knowledge bases, accessing the web for real-time data, or 
integrating with other applications through APIs or plugins. Such integrations introduce additional layers 
of data flow that must be carefully mapped and understood. When designing an LLM-based system, it 
is critical to account for how external data sources and systems are accessed, how data is transmitted 
and processed, and what safeguards are in place to protect user privacy and data security.  
Filters as Safeguards and as Additional Layer for Input and Output 
Most LLM systems incorporate input and output filters as safeguards, introducing an additional layer 
into the data flow. These filters act as control mechanisms to preprocess incoming data or refine 
generated outputs, helping to enforce privacy, safety, and content standards. They can take various 
forms — including Python scripts, prompt templates, or even other LLMs.181 
Input filters function as gatekeepers, screening data before it reaches the core model. For example, 
they might block personal data, detect harmful prompts, or sanitize inappropriate language. 
Output filters ensure that system responses meet privacy, ethical, or contextual requirements before 
they are shown to users or passed to downstream systems. An output filter might, for instance, remove 
sensitive content or rephrase a response to align with organizational policies. 
 
The addition of filters introduces complexity into the system’s architecture: Filters may add 
latency/processing time, impacting response times in real-time systems. They need to be secure, as 
vulnerabilities could expose sensitive data or allow malicious inputs to bypass scrutiny. And must be 
                                                            
180 See footnote 175 
181 Inan, H. et al., ‘Llama Guard: LLM-based Input-Output Safeguard for Human-AI Conversations’ (2023) 
https://ai.meta.com/research/publications/llama-guard-llm-based-input-output-safeguard-for-human-ai-conversations/

## Page 43 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
43 
 
monitored and regularly updated to adapt to new risks, changing regulations, or evolving system 
requirements.  
Roles in LLMs Service Models According to the AI Act and the GDPR  
The roles of provider and deployer under the AI Act, as well as controller and processor under the GDPR, 
may differ based on the different service model. Below is an explanation of how these roles may apply 
and the rationale behind their assignment, categorized by each service model. Note that the 
qualification of organizations as controller or processor should be assessed based on the circumstances 
of each case, and the explanation provided here is intended for reference purposes only and does not 
imply it will always apply in the same way. 
1. LLM as a Service Model 
In this service model, all processing occurs on the provider’s infrastructure, and the user interacts with 
the LLM through APIs or cloud platforms. Providers may also use collected data for model improvement, 
fine-tuning, or research.  
 
Example Tool: OpenAI's GPT API (e.g., ChatGPT) 
Use Case: Businesses use OpenAI’s API to integrate ChatGPT into their applications for customer support 
or content generation. The processing is performed entirely on OpenAI’s infrastructure. 
Provider: OpenAI. 
Deployer: A business that integrates ChatGPT's API into its workflow. 
 
 
AI Act Roles 
 
Provider: The organization that develops and offers the LLM as a service. Providers are 
responsible for ensuring compliance with the AI Act, including risk management, transparency, 
and technical robustness (e.g., OpenAI providing GPT models via APIs). 
 
Deployer: The organization using the LLM (e.g., a business using the provided interface for any 
particular task).  
 
New provider: An organization integrating the API of an LLM as a Service model into their 
commercial AI system (e.g., a chatbot) could also be considered a provider under the AI Act if 
their system qualifies as high-risk and falls within the scope of Article 25 of the AI Act. 
 
GDPR Roles 
 
Deployer as controller: The deployer using the LLM as a Service typically acts as the data 
controller, as they determine the purposes and means of data processing (e.g., collecting 
customer queries to improve services or using an LLM tool for summarization purposes). 
 
Provider as controller: When providers collect or retain data for their own purposes (e.g., model 
fine-tuning or feature improvement), they assume the role of controller too. This is the case in 
most LLM as a Service solutions where providers have ownership of the model and the training 
data. In this scenario, a joint controllership might be the more suitable option. 
 
Processor: The provider acts as a processor when handling data strictly according to the 
deployer's instructions for specific tasks, like generating responses. This might be difficult in this 
service model due to the providers model’s ownership. 
 
In an LLM as a Service model scenario, we often talk about the concept of shared responsibility, where 
both the provider and the deployer play distinct but complementary roles in ensuring privacy, security,

## Page 44 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
44 
 
and compliance. The provider is responsible for the infrastructure, model training, and maintenance, 
while the deployer must ensure secure usage, proper integration, and adherence to applicable 
regulations within their specific deployment context. This division of responsibilities requires clear 
agreements and robust collaboration to effectively manage risks. 
 
2. LLM ‘Off-the-Self’ Service Model 
In an ‘Off-the-Shelf’ Service Model, the roles of provider and deployer are determined by the 
operational setup and specific use of the LLM system and on how the platform and the deployer interact 
with the model.  In general, the involvement of the original provider is very limited. They often do not 
have access to the deployer’s data, or the tasks being executed, and their involvement is limited to 
ensuring the model is functional, robust, and compliant with regulatory standards at the point of 
delivery. The provider may continue to offer updates, bug fixes, or improvements to the model’s base 
functionality, but this does not typically involve accessing or processing deployer data.  
The deployer operates independently, using the model provided through the platform to build their 
own LLM system. 
 
Example Tool: Hugging Face's Transformers Library 
Use Case: A deployer downloads a pre-trained language model (e.g., BERT) from Hugging Face’s 
repository and fine-tunes or integrates it into their system. 
Provider: Hugging Face (as platform) and Google (BERT developer) are responsible for the original 
model's robustness and compliance). 
Deployer: An organization that uses the model for custom purposes, such as creating a chatbot. 
 
 
AI Act Roles 
 
Provider: The organization that develops, puts in the market or into service the off-the-shelf 
LLM model. Providers are responsible for ensuring that the model adheres to the AI Act’s 
requirements182. In case of LLMs released under free and open source licenses, they should be 
considered to ensure high levels of transparency and openness if their parameters, including 
the weights, the information on the model architecture, and the information on model usage 
are made publicly available183 
o If the platform provider develops, trains, or significantly fine-tunes an LLM and makes 
it available to deployers, they would act as providers under the AI Act.  
o The platform could also just have the role of infrastructure enabler and not being 
considered then a provider but a distributor. 
 
Deployer: The organization using the off-the-shelf model to build or enhance its own services 
takes on the role of deployer. However, in cases of high risk AI systems, the deployer may also 
assume the role of provider if they significantly modify or fine-tune the model or make it 
available to others as part of their own services. This dual role is addressed under Article 25 of 
the AI Act. 
                                                            
182 Note based on recital 104 AI Act: Providers of general-purpose AI models released under a free and open source license, with publicly 
available parameters (including weights, architecture details, and usage information), should be subject to exceptions regarding 
transparency-related requirements under the AI Act. However, exceptions should not apply when such models present a systemic risk. In 
such cases, transparency and an open source license alone should not suffice to exempt the provider from compliance with the regulation's 
obligations. Furthermore, the release of open source models does not inherently guarantee substantial disclosure about the datasets used 
for training or fine-tuning, nor does it ensure compliance with copyright law. Therefore, providers should still be required to produce a 
summary of the content used for model training and implement a policy to comply with Union copyright law, including identifying and 
respecting reservations of rights as outlined in Article 4(3) of Directive (EU) 2019/790. 
183 Recital 102 AI Act

## Page 45 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
45 
 
 
 
GDPR Roles 
 
Deployer as Controller: The deployer typically acts as the controller, as they determine the 
purpose and means of processing personal data during their use of the LLM.  
 
Provider as controller: The original model provider may act as a controller in limited scenarios 
where they process data for their own purposes. If the platform provider logs, analyzes, or 
retains user or deployer data for purposes like improving platform services, debugging, or 
monitoring system performance, they could be taking on the role of controller for this specific 
data processing. 
 
Processor: This role could be carrying out cloud-based tasks explicitly instructed by the 
deployer. For example, during data inference tasks, data might be processed according to the 
deployer’s instructions. In this case, a platform providing a model could act as a processor under 
the GDPR. 
 
The provider remains accountable for the foundational model’s compliance and functionality. The 
deployer is responsible for how the model is implemented, customized, and operated within their 
specific context, especially in scenarios where data is processed locally, or cloud tasks are guided by the 
deployer. This dual-layered responsibility emphasizes the need for clear contractual agreements and 
robust governance mechanisms. 
 
3. Self-developed LLMs 
All operations, from model development, infrastructure, input collection to model processing, are 
performed under the responsibility of the provider that is often also deploying the model for own use. 
 
Example Tools: PyTorch, DeepSpeed, TensorRT-LLM 
Use Case: A company uses a collection of different tools to develop and train a custom LLM entirely on 
their infrastructure, including data preparation, training, and deployment. 
Provider: The organization developing the LLM. 
Deployer: The same organization (if it also deploys the model) or a third-party client. 
 
 
AI Act Roles 
 
Provider: The entity developing the LLM.  
 
Deployer: The organization deploying the solution and taking on most operational 
responsibilities, including monitoring, risk management, and transparency. 
In this specific service model, the organization developing the LLM system could be the same 
organization putting the system into own use. In that scenario the same organization would be 
considered a provider and deployer under the AI Act. 
 
GDPR Roles 
 
Provider as Controller: The LLM system developer, as they control and execute all data 
processing activities within their local infrastructure during development.  
 
Deployer as Controller: The deployer, as they determine the purpose and means of processing 
personal data during their use of the LLM. 
 
Processor: Any third party processing data on behalf of the controller might take this role.

## Page 46 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
46 
 
 
The controller’s full control over infrastructure and data makes them responsible for compliance with 
GDPR and AI Act requirements. 
The processor’s role is limited to any third party tool or component that the controller could be using in 
the process. 
 
4. Agentic AI Systems 
Agentic AI systems introduce unique dynamics to data flows and role allocation under the GDPR and 
AI Act due to their autonomous and dynamic behavior.  
 
Example Tool: Auto-GPT 
Use Case: Auto-GPT autonomously performs tasks such as data gathering, and planning based on high-
level instructions. A deployer can fine-tune the agent or integrate it with specific systems. 
Provider: Developers creating foundational Auto-GPT architectures. 
Deployer: Organizations using or modifying Auto-GPT for specific workflows (e.g., automating 
business operations). 
 
AI Act Roles 
 
Provider: The entity developing and supplying the LLM or core agentic architecture.  
 
Deployer: The organization implementing the agentic AI system for its own or third-party use. 
In high risk AI systems, if the deployer fine-tunes the agent, integrates it with specific systems, 
or significantly modifies its architecture, they may also assume the role of a provider under 
Article 25 of the AI Act, responsible for compliance of the modified system. 
In this service model, the deployer is often both a provider and a deployer, depending on the level of 
customization, fine-tuning, or downstream deployment of the agentic AI system. 
GDPR Roles 
 
Deployer as Controller: The deployer typically assumes the role of the controller, as they 
determine the purpose and means of processing personal data. This includes inputs, outputs, 
memory management, and interactions with external systems. 
 
Processor: When the deployer uses third-party tools, external APIs, or cloud services as part of 
the agentic AI’s operations, these third-party providers could act as processors. For example, if 
an external API or service facilitates real-time data retrieval or enhances functionality, it takes 
on a processing role under the deployer’s instruction. In some cases, third-parties could act as 
joint-controllers. 
 
Responsibility Sharing: 
The deployer bears significant responsibility for managing the AI agent’s outputs and interactions. 
However, providers supplying foundational LLMs, or modules could also share responsibility for pre-
deployment compliance.

## Page 47 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
47 
 
 
 
This table shows an overview of the possible roles per service model, always subject to an assessment 
of the circumstances at hand: 
 
 
Model 
Deployer as Controller 
Provider as Controller 
Processors 
LLMs as a 
Service 
When the deployer uses the LLM 
for application-specific purposes, 
defining the data processing goals 
and methods (e.g., handling user 
queries). 
When the provider performs fine-
tuning, training, or analytics beyond 
deployer instructions (e.g., retaining 
data for retraining or monitoring 
purposes). 
Model Provider: For processing 
data under deployer’s 
instructions, such as handling 
input/output during inference 
tasks. 
LLM ‘Off-the-
Self’  
 
For determining the use of the LLM 
system, controlling data during 
preprocessing, output handling, 
and customization of the LLM for 
specific workflows. 
When the original model provider 
retains or reuses data for its 
purposes (e.g., debugging or 
performance monitoring). 
Platform: For cloud-based 
processing tasks performed 
under deployer’s instructions 
(e.g., hosting the model for 
inference).  
Self-developed 
LLM 
Fully applicable when developer is 
also deployer, as the organization 
directly defines data processing 
goals. 
Fully applicable, as the organization 
both develops and controls the 
model. 
Not applicable, as no third-party 
model provider is involved in 
processing. There might be other 
third parties acting as processors. 
Agentic AI 
The deployer acts as the primary 
controller, managing data inputs, 
task assignments, memory storage, 
and external system interactions, 
while overseeing the agent's 
autonomy. 
When the foundational model 
provider or module supplier retains 
data from interactions for their own 
purposes, such as improving 
reasoning components or tools. 
When provider performs training 
beyond deployer instructions. 
Model and tool provider / other 
third parties: When external APIs, 
tools, or platforms are used for 
specific agent functions under 
the deployer’s instructions.

## Page 48 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
48 
 
4. Data Protection and Privacy Risk Assessment: Risk 
Identification 
Risk assessment is generally considered the first phase within risk management. It encompasses risk 
analysis, which involves identifying, estimating, and evaluating potential risks. As a starting point, risk 
analysis requires a careful identification of the risks that may arise in a given context. This section 
looks at how to approach the identification of privacy and data protection risks in LLM systems. 
Criteria to Consider when Identifying Risks 
Risk Factors 
To help identify risks associated to the use of LLMs we can make use of a variety of risk factors.  
Risk factors are conditions associated with a higher probability of undesirable outcomes. They can help 
to identify, assess, and prioritize potential risks. For instance, processing sensitive data and large 
volumes of data are two risk factors with a high level of risk. Acknowledging them in your own use case, 
can help you identify related potential risks and their severity.  
 
The risk factors shown below are the result of analysing the contents of legal instruments such as the 
GDPR184,  the EUDPR185, the EU Charter186 and other applicable guidelines related to privacy and data 
protection.187The following risk factors can help us identify data protection and privacy high level risks 
in LLM-based systems: 
 
High level Risk / Important concerns 
Examples of applicability 
Sensitive & impactful purpose of the processing 
Using a LLMS to decide on or prevent the exercise of 
fundamental rights of individuals, or about their access to a 
service, the execution or performance of a contract, or access 
to financial services is a concern, especially if these decisions 
will be automated without human intervention. Wrong 
decisions could have an adverse impact on individuals. 
Deploying an LLM to determine creditworthiness or loan 
approvals without human oversight, or to automate 
decisions about hiring, promotions, or job terminations 
without adequate safeguards could negatively impact 
individuals.  
Processing sensitive data 
When an LLM is processing sensitive data such as special 
categories of data, personal data related to convictions and 
criminal offences, financial data, behavioral data, unique 
identifiers, location data, etc. This is a reason of concern since 
processing inappropriately this personal data could negatively 
impact individuals.  
Using an LLM-based system to analyze patient records, 
diagnoses, or treatment plans or data related to criminal 
convictions, court records, or investigative reports. 
Large scale processing 
Processing high volumes of personal data is a reason of 
concern, especially if these personal data are sensitive. The 
higher the volume the bigger the impact in case of a data 
breach or any other situation that put the individuals at risk.  
An LLM deployed in a large e-commerce platform 
processing vast amounts of user data, or an LLM used in a 
social media platform.  
                                                            
184 General Data Protection Regulation (2016/679) 
185 European Union Data Protection Regulation (Reg. 2018/1725) 
186 Charter of Fundamental Rights of the European Union (2012/C 326/02) 
187 AEPD, ‘Risk Management and Impact Assessment in Processing of Personal Data’ p-79 (2021) https://www.aepd.es/guides/risk-
management-and-impact-assessment-in-processing-personal-data.pdf

## Page 49 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
49 
 
Processing data of vulnerable individuals 
This is a concern because vulnerable individuals often require 
special protection. Processing their personal data without 
proper safeguards can lead to violations of their fundamental 
rights. Some examples of vulnerable individuals are children, 
elderly people, people with mental illness, disabled, patients, 
people at risk of social exclusion, asylum seekers, persons who 
access social services, employees, etc. 
This could be the case when LLM systems are used in the 
health sector, at schools, social services organizations, 
government institutions, employers, etc. For instance, an 
LLM-based platform used in schools to assess student 
performance and provide personalized learning 
recommendations processes data about children. 
 
Low data quality 
The low data quality of the input data and/or the training data 
is a concern bringing possible risks of inaccuracies in the 
generated output what could cause wrong identification of 
characters and have other adverse impacts depending on the 
use case. 
LLMs rely heavily on the quality of both the input data 
provided by users and the data used for training the 
model. Any inaccuracies, biases, or incompleteness in the 
data can have far-reaching consequences, as LLMs 
generate outputs based on patterns they detect in their 
training and input data. The degree of risk posed by low 
data quality depends heavily on the application. In less 
critical use cases, such as content generation, inaccuracies 
may be less impactful. However, in high-stakes scenarios, 
such as healthcare, finance, or public policy, even minor 
inaccuracies can have significant negative consequences. 
Insufficient security measures  
The lack of sufficient safeguards could be the cause of a data 
breach. Data could also be transferred to states or 
organizations in other countries without an adequate level of 
protection. 
 
This could be the case if there are not sufficient safeguards 
implemented to protect the input data and the results of 
the processing. This could be applicable to any use case. 
LLMs offered as SaaS solutions involve in some cases data 
being sent for processing to servers in countries without 
adequate data protection laws, increasing exposure to 
privacy risks. 
 
Other Components of AI Risk 
The AI Act introduces essential safety concepts into the risk management process of AI systems, 
reflecting its nature as a product safety regulation. Understanding these concepts is critical when 
initiating the assessment of risks associated with an LLM based system.  
Key terms188 such as hazard, hazard exposure, safety, threats, vulnerabilities, and their interplay with 
fundamental rights are components of risk that provide a foundational framework for the evaluation of 
AI risks.  
 
A hazard refers to a potential source of harm, while hazard exposure describes the conditions or extent 
to which individuals or systems are exposed to that harm in a hazardous situation. Safety represents 
the measures implemented to minimize or mitigate harm, ensuring the system operates as intended 
without causing undue risk. Threats are external factors that may exploit vulnerabilities within the LLM 
based system, which are weaknesses that could be exploited to compromise functionality, security, or 
                                                            
188 These terms are explained here in an accessible manner to aid understanding, but they are not official definitions. The European harmonized 
standard on risk management, currently being developed by CEN/CENELEC at the request of the European Commission, will contain 
standardized definitions and provide formalized guidance on these terms. 
Figure 14. Other components of Risk

## Page 50 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
50 
 
data protection. The AI Act emphasizes the protection of fundamental rights, including privacy, to 
ensure that AI systems do not adversely impact individuals. 
 
When trying to identify the risks of an LLM based system, is important to consider all these components 
of risks189 that could have an impact on privacy and data protection. Privacy risks often stem from 
hazards, or from vulnerabilities within the system that could be exploited by external or internal threats. 
A hazard exposure in this context could refer to how individuals’ personal data is exposed to these risks 
through the use of the LLM based system, for example, during input querying. 
Understanding these interrelated concepts facilitates the risk management process of AI systems that 
need to comply with the GDPR and the AI Act having as end goal the protection of individuals. 
The Importance of Intended Purpose and Context in Risk Identification 
The GDPR, in Recital 90 emphasizes the importance of establishing the context: “taking into account 
the nature, scope, context and purposes of the processing and the sources of the risk”.  
This is a critical principle when conducting a privacy risk assessment, as it ensures that risks to the 
rights and freedoms of natural persons are evaluated in their specific operational and contextual 
settings. This aligns closely with the concept of ‘intended purpose’ in the AI Act, which emphasizes the 
need to define and assess how an AI system is expected to operate.  
The concepts of intended purpose 190 and context are foundational in the identification and 
management of risks in AI systems191. Intended purpose refers to the specific purposes and scenarios 
for which the AI system is designed, while context encompasses the environment, user base, and 
operational settings in which the system functions. Understanding these dimensions is crucial because 
risks often arise when systems are used in unintended ways or in contexts that introduce unforeseen 
vulnerabilities. 
 
By clearly defining the intended purpose, you can assess whether the design and functionalities align 
with the anticipated application’s use. This is also helpful to identify potential misuse of the system and 
harm to specific user groups. Similarly, understanding the broader context—including user 
demographics, language, cultural factors, and business models—enables you to evaluate how the 
system interacts with its environment to anticipate potential issues. 
The Role of Threat Modeling in Privacy Risk Identification 
Given the broad spectrum of risks associated with AI, methodologies like threat modeling192 play a 
pivotal role in systematically identifying privacy risks. These methodologies often leverage libraries of 
specific AI threats, hazards and vulnerabilities providing a structured evaluation of risks throughout the 
lifecycle of the AI system including those arising from both intended and unintended uses of the system.  
 
Threat modeling can assist in identifying potential attack surfaces193, misuse cases, and vulnerabilities, 
enabling a proactive approach to risk identification and mitigation. For example, by identifying data 
flows and system dependencies, threat modeling can reveal risks like unauthorized data access which 
                                                            
189 Novelli, C et al., ‘AI Risk Assessment: A Scenario-Based, Proportional Methodology for the AI Act’ (2024) https://doi.org/10.1007/s44206-
024-00095-1 
190 The AI Act requires in Article 9 (2)(a) for high-risk AI systems risk management systems ‘the identification and analysis of the known and 
the reasonably foreseeable risks that the high-risk AI system can pose to health, safety or fundamental rights when the high-risk AI system is 
used in accordance with its intended purpose; 
191 NIST, ‘Artificial Intelligence Risk Management Framework (AI RMF 1.0)’ (2023) https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf 
192 Threat Modeling Manifiesto, (n.d)  https://www.threatmodelingmanifesto.org/ 
193 Meta, Frontier AI Framework (2025) https://ai.meta.com/static-resource/meta-frontier-ai-
framework/?utm_source=newsroom&utm_medium=web&utm_content=Frontier_AI_Framework_PDF&utm_campaign=Our_Approach_to_F
rontier_AI_blog

## Page 51 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
51 
 
may not be immediately apparent. The identified threats from a threat modeling session can be 
integrated into LLM evaluations, where models are systematically tested against the threats through 
adversarial testing, red teaming, or scenario-based assessments.  
The Importance of Monitoring and Collecting Evidence 
To effectively manage risks in LLM systems, it is essential to also base your assessment on robust 
evidence194. This includes gathering data from multiple sources to ensure the analysis accurately reflects 
potential harms and vulnerabilities. After deployment, monitoring data such as logs and usage patterns, 
can provide insights into how the system is being used in practice and whether it aligns with its intended 
purpose. Throughout the whole lifecycle, evaluation results from metrics, testing, red teaming 
exercises 195 and external audits can highlight gaps in functionality, biases, or performance issues. 
Additionally, feedback from users or from whistleblowers 196 , containing complaints, reports, or 
behaviour patterns, offers valuable perspectives on real-world risks and potential areas for 
improvement. 
 
Incorporating evidence 197 from both core and enhanced sources ensures a comprehensive 
understanding of risks. Core evidence includes existing data on system characteristics and user 
interactions, while enhanced evidence might involve consulting experts, conducting targeted research, 
or using outputs from content moderation or technical evaluation systems. This multi-faceted approach 
not only aids in identifying risks but also provides a documented basis for risk management decisions. 
 
Examples of Privacy Risks in LLM Systems 
LLMs can present a wide range of privacy and data protection risks. These risks arise from various 
factors, including the specific use case, the context of application, and the risk factors and evidence 
identified during the assessment process. Recognizing and addressing these risks is critical for 
organizations aiming to procure, develop, or deploy LLM-based systems responsibly. 
 
The table below categorizes common privacy risks of LLM systems based on their applicability to the 
roles of providers and deployers. Both providers and deployers are responsible to all risks on the table, 
but the degree of responsibility depends on the level of control over the system (e.g., providers for 
infrastructure, deployers for usage and configuration).  
It is important to consider how risks differ depending on the perspective. For instance, while a provider 
may face regulatory obligations to minimize data storage, a deployer must evaluate the risks of 
entrusting a provider with sensitive information. These roles come with different responsibilities that 
require specific risk management strategies. 
 
Providers, deployers, and procurement teams must address these risks collaboratively. Procurement, 
in particular, plays a vital role in bridging the responsibilities of providers and deployers by ensuring 
that selected systems meet regulatory standards and organizational privacy requirements. Key 
                                                            
194 Ofcom, 
‘Protecting 
people 
from 
illegal 
harms 
online 
- 
Annex 
5: 
Service 
Risk 
Assessment 
Guidance 
 
(2024) 
https://www.ofcom.org.uk/siteassets/resources/documents/consultations/category-1-10-weeks/270826-consultation-protecting-people-
from-illegal-content-online/associated-documents/annex-5-draft-service-risk-assessment-guidance?v=330403 
195 Martineau, K. ‘What is red teaming for generative AI?’ (2024) https://research.ibm.com/blog/what-is-red-teaming-gen-AI 
196 Recital 172 AI Act: “Persons acting as whistleblowers on the infringements of this Regulation should be protected under the Union law. 
Directive (EU) 2019/1937 of the European Parliament and of the Council (54) should therefore apply to the reporting of infringements of this 
Regulation and the protection of persons reporting such infringements.” 
197 Ofcom, ‘Protecting people from illegal harms online - Annex 5: Service Risk Assessment Guidance  (2024) 
https://www.ofcom.org.uk/siteassets/resources/documents/consultations/category-1-10-weeks/270826-consultation-protecting-people-
from-illegal-content-online/associated-documents/annex-5-draft-service-risk-assessment-guidance?v=330403

## Page 52 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
52 
 
considerations during procurement include assessing the provider’s policies, ensuring compliance with 
relevant regulations, and embedding clauses that limit data misuse and support data subject rights.  
Deployers using LLMs need to consider the risks related to their specific use cases and context. Making 
use of the risk factors or evaluation criteria can facilitate the identification of those risks.  For instance, 
the criteria ‘low data quality’ can already trigger the identification of risky processing activities that 
could result in harm.  
Providers and developers of LLMs must implement risk management as an iterative process to identify 
and address risks, recognizing that these risks can emerge at various phases of the development 
lifecycle, as discussed in previous sections. 
 
The overview provided by the table below can serve as a practical starting point for identifying and 
analyzing privacy and data protection risks throughout the lifecycle of LLM based systems. The table 
presents a consolidated summary of privacy risks, complementing the details already provided in 
Section 3 under Data Flow and Associated Privacy Risks in LLM Systems.

## Page 53 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
 
Risk applicability
Data Protection and Privacy 
Risks 
Risk description 
GDPR potential Impact 
Examples  
Service Model 
Provider 
Deployer 
1. Insufficient 
protection of personal 
data what eventually 
can be the cause of a 
data breach. 
Safeguards for the 
protection of personal 
data are not 
implemented or are 
insufficient. 
Infringement of: 
Art. 32 Security of processing, 
Art. 5(1)(f) Integrity and 
confidentiality and Art. 9 
Processing of special categories 
of personal data 
Sensitive data disclosure in user inputs or 
during training, inference and output. 
Unauthorized access, insufficient encryption 
during data transmission, API misuse, interface 
vulnerabilities, inadequate anonymization or 
filtering techniques, third party exposure. 
 
 
 LLM as a Service 
 LLM ‘off-the-shelf’ 
 Self-developed LLM 
 Agentic LLM 
 
 
 
2. Misclassifying 
training data as 
anonymous by 
controllers when it 
contains identifiable 
information. 
Controllers may 
incorrectly assume 
training data is 
anonymous, failing to 
implement necessary 
safeguards for 
personal data 
protection. 
Infringement of: 
Articles 5(1)(a) (Lawfulness, 
Fairness, and Transparency), 
5(1)(b) (Purpose Limitation), 25 
(Data Protection by Design and 
Default) 
An LLM trained on improperly anonymized user 
logs reveals identifiable user information 
through model inference attacks. 
A deployer discovers that the third-party LLM 
they are using has been trained on non-
anonymized personal data, and the vendor fails 
to implement appropriate safeguards, exposing 
the deployer to compliance risks. 
 
 LLM as a Service198 
 LLM ‘off-the-
shelf’199  
 Self-developed LLM 
 Agentic LLM 
 
 
3. Unlawful processing 
of personal data in 
training sets. 
Personal data is 
included in training 
datasets without 
proper legal basis, 
safeguards, or user 
consent. 
Infringement of: 
Articles 5(1)(a) (Lawfulness, 
Fairness, and Transparency) 
Articles 6(1) (Lawfulness of 
Processing), 7 (Consent), 5(1)(c) 
(Data Minimization) 
An e-commerce platform uses customer 
purchase histories to train an LLM without 
informing customers or obtaining their consent. 
 
 LLM as a Service200 
 LLM ‘off-the-
shelf’201  
 Self-developed LLM 
 Agentic LLM 
 
 
 
4. Unlawful processing 
of special categories of 
personal data and data 
relating to criminal 
convictions and 
offences in training 
data. 
Training datasets 
include sensitive data, 
such as health or 
criminal records, 
without meeting GDPR 
exceptions for lawful 
processing. 
Infringement of: 
Articles 9(1) and 9(2) (Special 
Categories of Data), Article 10 
(Criminal Convictions and 
Offences). 
Medical records scraped from unsecured online 
sources are used to train a healthcare chatbot 
without applying GDPR compliant safeguards. 
 
 LLM as a Service202 
 LLM ‘off-the-
shelf’203  
 Self-developed LLM 
 Agentic LLM 
 
 
                                                            
198 This risk primarily applies to the provider; however, the deployer shares responsibility by ensuring they engage with lawful vendors. The deployer's role includes conducting due diligence to verify that the provider 
complies with legal obligations and operates within the bounds of applicable regulations. 
199 Idem 
200 Idem 
201 Idem 
202 Idem 
203 Idem

## Page 54 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
54 
 
5. Possible adverse 
impact on data 
subjects that could 
negatively impact 
fundamental rights. 
The output of the 
system could have an 
adverse impact on the 
individual. 
Infringement of: 
Art. 5(1)(d) Accuracy, Art. 
5(1)(a) Fairness, Art. 22 
Automated individual decision-
making, including profiling, Art. 
25 Data protection by design 
and by default 
A system providing output that is not accurate 
or contain bias and does not provide with 
mechanisms to amend errors. The output of an 
LLM could be used to make automatic decisions 
which produce legal effects or similarly 
significant effects on data subjects. 
 
 
 LLM as a Service 
 LLM ‘off-the-shelf’  
 Self-developed LLM 
 Agentic LLM 
 
 
 
6. Not providing 
human intervention for 
a processing that can 
have a legal or 
important effect on 
the data subject. 
Automated decisions 
that significantly 
impact individuals are 
made without human 
review, violating GDPR 
requirements for 
human oversight, or 
are based on 
inappropriate 
ground204. 
Infringement of: 
Articles 22(1) and 22(3) 
(Automated Decision-Making), 
Article 12 (Transparent 
Communication). 
A chatbot automates loan approvals based on 
user provided data, denying applications 
without involving a human reviewer. 
 
 LLM as a Service 
 LLM ‘off-the-shelf’  
 Self-developed LLM 
 Agentic LLM 
 
 
7. Not granting data 
subjects their rights. 
Data subjects’ rights 
cannot be completely 
or partially granted. 
Infringement of: 
Art. 12 – 14: Information to be 
provided when personal data is 
collected 
Art. 16 and Art. 17: Right to 
rectification and right to 
erasure 
Article 18 Right to restriction of 
processing and Article 21 Right 
to object 
Data subjects’ requests to rectify or to erase 
personal data cannot be completed. Users are 
not aware of how their data will be used, 
retained, or shared by the provider. 
 
 LLM as a Service 
 LLM ‘off-the-shelf’  
 Self-developed LLM 
 Agentic LLM 
 
 
 
8. Unlawful repurpose 
of personal data. 
Personal data is used 
for a different purpose. 
Infringement of: 
Art. 5(1)(b) Purpose limitation, 
Art. 5(1)(a) Lawfulness, fairness 
and transparency, 
Article 28(3)(a)205 and Art. 29 
Processing under the authority 
of the controller or processor 
This could be the case if the provider uses the 
input and/or output data for training the LLM 
without this being formally agreed on 
beforehand.  
 
 LLM as a Service 
 LLM ‘off-the-shelf’  
 Self-developed LLM 
 Agentic LLM 
 
 
 
                                                            
204 Under the exceptions outlined in Article 22(2) of the GDPR, automated individual decision-making is permitted only if it is based on contractual necessity, explicit consent, or if authorized by EU or Member State law. 
205 “processes the personal data only on documented instructions from the controller, including with regard to transfers of personal data to a third country or an international organisation, unless required to do so by Union 
or Member State law to which the processor is subject; in such a case, the processor shall inform the controller of that legal requirement before processing, unless that law prohibits such information on important grounds of 
public interest;”

## Page 55 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
55 
 
9. Unlawful unlimited 
storage of personal 
data. 
Input and/or output 
data is being stored 
longer than necessary. 
Infringement of: 
Art. 5(1)(e) Storage limitation 
and Art. 25 Data protection by 
design and by default 
The system could be unnecessarily storing input 
data that is not directly relevant to the LLM 
process. In some cases, the output could be 
stored by the deployer longer than necessary. 
Providers can also log user inputs and outputs 
for debugging or model improvement. 
 LLM as a Service 
 LLM ‘off-the-shelf’  
 Self-developed LLM 
 Agentic LLM 
 
 
10. Unlawful transfer 
of personal data. 
Data are being 
processed in countries 
without an adequate 
level of protection. 
Infringement of: 
Art. 44 General principle for 
transfers, Art. 45 Transfers on 
the basis of an adequacy 
decision, Art. 46 Transfers 
subject to appropriate 
safeguards 
LLM providers could be processing the data in 
countries that do not offer enough 
safeguards206. 
 
 LLM as a Service 
 LLM ‘off-the-shelf’  
 Agentic LLM 
 
 
 
11. Breach of the data 
minimization principle. 
Extensive processing of 
personal data for 
training the model.  
Infringement of: 
Art. 5(1)(c) Data minimization, 
Art. 6 to the extent that data 
minimisation has an impact on 
the most appropriate lawful 
basis (e.g., legitimate interest 
under Article 6(1)(f)) and Art. 25 
Data protection by design and 
by default
LLMs require substantial amounts of data for 
training. Similarly, deployers may use datasets 
to fine-tune the LLM based system for their 
specific use cases. 
 
 LLM as a Service 
 LLM ‘off-the-shelf’  
 Self-developed LLM 
 Agentic LLM 
 
 
                                                            
206 Garante per la Protezione dei dati personali (DPDP), ‘Intelligenza artificiale: il Garante privacy blocca DeepSeek’ (2025)  https://www.garanteprivacy.it/home/docweb/-/docweb-
display/docweb/10097450?mkt_tok=MTM4LUVaTS0wNDIAAAGYXIH0PW4qTzz-TKclqJPRoyU5yZoUVox1JLxNIcVP7RTnC_bvlu_rRyXg8hy6RdOqFw9BgFYU8wXP1XmPVVBTU7DCNt1660jK9umFkCSnLY4e#english

## Page 56 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
 
When assessing the risks associated with LLMs, it is crucial to consider broader issues linked to GDPR 
principles such as lawfulness, fairness, transparency, and accountability. In addition to privacy 
concerns, also issues related to copyright, overreliance and manipulation must be addressed. 
 
Lawfulness, Transparency and Fairness 
Transparency ensures individuals understand how their data is processed, while fairness demands that 
data is handled in a just and non-deceptive manner, avoiding methods that are detrimental, 
unlawfully discriminatory, or misleading. However, the opacity inherent in LLMs often challenges 
these principles. For instance, users may struggle to understand how LLMs generate responses, 
prioritize outputs, or make decisions, making it difficult for them to assess or challenge the results. 
The principle of fairness, closely connected to transparency, emphasizes the importance of providing 
clear, accessible, and meaningful information about data processing activities. Compliance with 
transparency obligations, as outlined in Articles 12 to 14 GDPR, involves detailing the logic, 
significance, and potential consequences of automated decision-making, including profiling. This is 
particularly critical for LLMs, given their complexity and the extensive use of data during development. 
Reliance on exceptions such as Article 14(5)(b) GDPR is strictly limited to scenarios where all legal 
requirements are fully met.207 
 
To align with these principles, LLM developers must actively monitor outputs, address potential 
biases208, by using high-quality and unbiased training data, and provide user-friendly, comprehensible 
information about the system's decision-making processes. These steps not only ensure compliance 
with GDPR but also uphold fairness and transparency, fostering trust in AI technologies and 
safeguarding individual rights. 
 
Copyright209 
LLMs trained on web-scraped or publicly available data often include copyrighted materials, raising 
concerns about intellectual property violations. Outputs generated by such models may 
unintentionally replicate protected content, creating legal risks for both providers and deployers. 
These issues highlight the importance of ensuring that data used to train LLMs is collected and 
processed lawfully and in accordance with copyright laws. 
 
Overreliance & Manipulation 
Overreliance210 can undermine user autonomy and accountability. LLMs can unintentionally influence 
user behavior through tailored recommendations or inferred preferences, reducing autonomy. Users 
may trust LLM generated outputs in critical areas, such as financial advice or healthcare decisions, 
without sufficient understanding or oversight. This overreliance can obscure errors or biases in the 
system, leading to decisions that are neither fair nor transparent. LLMs can also create realistic fake 
content, such as deepfakes, spreading misinformation or manipulating opinions. 
Some mitigation strategies include requiring human oversight for critical decisions, promoting digital 
literacy, and ensuring that outputs are clearly labeled as AI-generated recommendations. 
 
                                                            
207 EDPB, ‘Opinion 28/2024 on certain data protection aspects related to the processing of personal data in the context of AI models, 
Adopted on 17 December 2024, (2024) https://www.edpb.europa.eu/our-work-tools/our-documents/opinion-board-art-64/opinion-282024-
certain-data-protection-aspects_en 
208 Lareo, X. ‘Large Language Models’, EDPS, (n.d) https://www.edps.europa.eu/data-protection/technology-monitoring/techsonar/large-
language-models-llm_en 
209 European Innovation Council and SMEs Executive Agency, ‘Artificial intelligence and copyright: use of generative AI tools to develop new 
content’ (2024) https://intellectual-property-helpdesk.ec.europa.eu/news-events/news/artificial-intelligence-and-copyright-use-generative-
ai-tools-develop-new-content-2024-07-16-0_en 
210 Jacobi, O., ‘The Risks of Overreliance on Large Language Models (LLMs)’ (2024) https://www.aporia.com/learn/risks-of-overreliance-on-
llms/

## Page 57 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
57 
 
5. Data Protection and Privacy Risk Assessment: Risk 
Estimation & Evaluation 
From Risk Identification to Risk Evaluation 
Once risks have been identified, the next crucial steps within the risk analysis phase are the estimation 
and evaluation of the risks. This involves the classification and prioritization of risks based on their 
probability211and severity or potential impact. The actual risk level or classification will depend heavily 
on the specific use case, operational context, system monitoring, model evaluation results and the 
affected stakeholders. 
During this phase, risks are analyzed to understand their implications in greater detail. This process 
includes evaluating factors such as the probability of the risk occurring, the potential harm it could 
cause, and the vulnerabilities that make it possible.  
Stakeholder collaboration212 plays a vital role in this process, particularly given the multidisciplinary 
nature of AI, where inputs from technical, legal, ethical, security and operational perspectives are 
crucial for comprehensive risk management.  
An ethical matrix213 can be a valuable tool for identifying which stakeholders could be directly or 
indirectly impacted by the LLM based system. Mapping stakeholders based on their level of 
involvement and the potential impact on them allows organizations to incorporate the perspectives 
and concerns of those affected into the risk classification and mitigation process. This ensures that the 
ethical and practical considerations of deploying LLMs are addressed, aligning the system's 
implementation with the needs and rights of all impacted parties. 
 
After identifying risks, the next steps are:214 
 
Assessing the probability and severity of the identified risks. 
 
Evaluate if risks need to be treated to ensure the protection of personal data and demonstrate 
compliance with the GDPR and EUDPR. 
 
Various risk management methodologies are available for classifying and assessing risks. This 
document does not aim to prescribe or define a specific methodology, as the choice should be 
determined by each organization. However, for the purposes of this document, we will reference 
international standards previously highlighted in the WP29215 and the AEPD216 guidelines as well as the 
work being currently done in European AI standardization. 
 
In general risk management terms, risk can be expressed as:  
 
Risk = Probability x Severity 
 
                                                            
211 Note: In this document, we use the term "probability" instead of "likelihood" to align with terminology found in definitions like the one for 
risk in the AI Act. While in risk management, "likelihood" typically indicates a qualitative approach to managing risks, "probability" implies a 
quantitative method of risk assessment. 
212 European Center for Not-for-Profit Law, ‘Framework for Meaningful Engagement: Human rights impact assessments of AI’ (2023) 
https://ecnl.org/publications/framework-meaningful-engagement-human-rights-impact-assessments-ai 
213 O’Neil, C. ‘Algorithmic Stakeholders: An Ethical Matrix for AI’ (2020) https://blog.dataiku.com/algorithmic-stakeholders-an-ethical-matrix-
for-ai 
214 Article 29 Data Protection Working Party, ‘Guidelines on Data Protection Impact Assessment (DPIA) and determining whether processing 
is “likely to result in a high risk for the purposes of Regulation 2016/679’ (2017) https://ec.europa.eu/newsroom/article29/items/611236/en 
215 ISO 31000:2009, Risk management — Principles and guidelines, International Organization for Standardization (ISO); ISO/IEC 29134, 
Information technology – Security techniques – Privacy impact assessment – Guidelines, International Organization for Standardization (ISO). 
216 ISO 31010:2019, Risk management — Risk Assessment Techniques, International Organization for Standardization (ISO)

## Page 58 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
58 
 
This equation highlights that risk is determined by the probability of an event occurring, combined 
with the potential impact or severity of the resulting harm. 
Risk is defined in the GDPR (Recital 75) as the potential harm to the rights and freedoms of natural 
persons, of varying probability and severity, arising from personal data processing. Similarly, the AI Act 
(Article 3) defines risk as ‘the combination of the probability of an occurrence of harm and the severity 
of that harm;’. 
To evaluate the level of data protection and privacy risks when procuring, developing, or using LLMs, it 
is essential to estimate both the probability and severity of the identified risks materializing. 
 
Criteria to Establish the Probability of Risks in LLM Systems  
How to Assess Probability 
To determine the probability of the risks of LLMs we will use the following four level risk classification 
matrix: 
 
Level of 
Consequence 
Probability Definition 
Very High 
High probability of an event occurring 
High 
Substantial probability of an event occurring 
Low 
Low probability of an event occurring 
Unlikely 
There is no evidence of such a risk materializing in any case 
 
Probability determination must be tailored to the specific risks and use cases under assessment. While 
this general matrix provides a structured approach, applying more detailed criteria can enhance the 
accuracy of the probability assessment.  
In the table below, there is an example of criteria217 that can guide this process, helping to refine the 
evaluation of probability for specific scenarios. Note that some criteria relate to system-level 
attributes while other are context-specific.  
 
  
  
PROBABILITY LEVELS 
Criteria
Description
Level 1 (Unlikely)
Level 2
(Low) 
Level 3
(High) 
Level 4
(Very High) 
1. Frequency 
of Use 
How often the AI system 
is used, increasing 
exposure to potential risk 
affecting reliability 
(expected time before 
failure)
The system is 
rarely used or has 
infrequent 
interactions (e.g., 
annual or less). 
The system is 
occasionally used 
but not in critical 
operations (e.g., 
monthly). 
The system is 
frequently used and 
integrated into 
important 
operations (e.g., 
weekly).
The system is used 
continuously or in real-
time critical operations 
(e.g., daily). 
2. Exposure to 
High-Risk 
Scenarios 
The extent to which the 
AI system operates in 
sensitive or high-stakes 
environments. 
The system is not 
used in sensitive 
or high-stakes 
scenarios. 
The system 
operates in 
moderately 
sensitive 
environments 
with minimal 
stakes. 
The system is used 
in high-stakes 
environments with 
potential for 
significant impact. 
The system operates in 
highly sensitive or 
critical environments 
(e.g., healthcare, 
security). 
                                                            
217 Barberá, I. "FRASP, A Structured Framework for Assessing the Severity & Probability of Fundamental Rights Interferences in AI Systems" 
(2025)

## Page 59 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
59 
 
3. Historical 
Precedents 
Past instances of similar 
risks or failures in the 
same or comparable AI 
systems. 
No similar risks or 
failures have 
occurred in 
comparable 
systems. 
Few similar risks 
or failures have 
occurred in 
comparable 
systems. 
Similar risks or 
failures have 
occurred frequently 
in comparable 
systems. 
Frequent and 
significant risks or 
failures have occurred 
in comparable 
systems. 
4. 
Environmental 
Factors  
External, uncontrollable 
conditions affecting 
system performance or 
reliability (e.g., political 
instability, regulatory 
gaps, financial 
constraints). 
External 
conditions are 
stable and do not 
impact the 
system's 
performance. 
External 
conditions 
occasionally 
affect the 
system's 
performance but 
are manageable. 
External conditions 
often impact the 
system's 
performance, 
creating 
vulnerabilities. 
External conditions 
severely affect the 
system's performance, 
creating constant risks. 
5. System 
Robustness 
 
The degree to which the 
AI system is resistant to 
failure or unintended 
behaviour. 
The system is 
highly robust with 
multiple 
redundancies and 
safeguards. 
The system is 
moderately 
robust with some 
redundancies but 
occasional 
vulnerabilities.
The system has 
some robustness 
but contains 
significant 
vulnerabilities or 
weak safeguards.
The system lacks 
robustness, 
safeguards, or is prone 
to frequent failures. 
6. Data 
Quality and 
Integrity  
The extent to which the 
AI system relies on 
accurate, unbiased, and 
complete data. 
Modifiable through 
better dataset curation 
or validation. 
Data is highly 
accurate, 
unbiased, and 
complete with 
minimal risk of 
errors. 
Data is mostly 
accurate and 
complete but has 
occasional minor 
biases or errors. 
Data is partially 
accurate or 
complete, with 
notable biases or 
inconsistencies. 
Data is significantly 
inaccurate, biased, or 
incomplete, leading to 
high risk. 
7. Human 
Oversight and 
Expertise  
How human operators’ 
skills and decision-
making affect system 
reliability and risk 
probability. Modifiable 
through training or 
oversight improvements. 
Operators are 
highly trained, 
experienced, and 
consistently 
effective in 
decision-making. 
Operators are 
moderately 
trained and 
effective, but 
occasional errors 
occur. 
Operators are 
undertrained or 
inconsistent, 
leading to regular 
errors in decision-
making. 
Operators are 
untrained or 
ineffective, causing 
frequent and severe 
errors. 
 
To use the criteria for determining the probability of risks you can do the following: 
 
Step 1: Aggregate Scores 
 Evaluate each criterion and assign it a score based on predefined probability levels 1 to 4.  
 Add the scores of all factors and divide the total by the number of factors to calculate the 
Aggregate Probability Score. This can be done using either: 
 
o Weighted Average: Assign more importance to certain factors by weighting them before 
averaging. 
o Simple Average: Treat all factors equally and calculate the mean. 
 
Formula:  Aggregate Probability Score = Sum of All Scores / Number of Factors 
 
 Step 2: Map Aggregate Score to Probability Level 
Once the aggregate score is calculated, map it to one of the predefined probability levels from the 
matrix based on the following ranges: 
1.0 - 1.5: Unlikely 
1.6 - 2.5: Low 
2.6 - 3.5: High 
3.6 - 4.0: Very High

## Page 60 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
60 
 
This mapping provides a clear, categorized probability level for each risk, which helps prioritize risks 
based on their potential occurrence. We will explore later in this document how this framework can 
be applied in practice in one specific use case. 
Criteria to Establish the Severity of Risks in LLM Systems  
How to Assess Severity 
To determine the severity of risks of LLMs we will use a four level risk classification matrix:218 
 
Level of 
Severity 
Severity Definition 
Very Significant
Catastrophic 
Harm 
It affects the exercise of fundamental rights and public freedoms, and its consequences are irreversible 
and/or the consequences are related to special categories of data or to criminal offences and are 
irreversible and/or it causes significant social harm, such as discrimination, and is irreversible and/or it 
affects particularly vulnerable data subjects, especially children, in an irreversible way and/or causes 
significant and irreversible moral or material losses. 
Significant
Critical Harm
 
The above cases when the effects are reversible and/or there is loss of control of the data subject over 
their personal data, where the extent of the data are high in relation to the categories of data or the 
number of subjects and/or identity theft of data subjects occurs or may occur and/or significant financial 
losses to data subjects may occur and/or loss of confidentiality of data subject or breach of the duty of 
confidentiality and/or there is a social detriment to data subjects or certain groups of data subjects
Limited
Serious Harm 
Very limited loss of control of some personal data and to specific data subjects, other than special 
category or irreversible criminal offences or convictions 
and/or negligible and irreversible financial losses and/or loss of confidentiality of data subject to 
professional secrecy but not special categories or infringement penalties 
Very Limited
Moderate or 
Minor Harm
In the above case (limited) when all effects are reversible 
 
Note that the HUDERIA219 risk management methodology, developed by the Committee on Artificial 
Intelligence of the Council of Europe, also employs a four-level severity matrix. However, it uses slightly 
different terminology, as shown in this matrix (italicized): Catastrophic Harm, Critical Harm, Serious 
Harm, and Moderate or Minor Harm. 
Similar to the assessment of probability, the assessment of severity can also benefit from the use of 
different severity criteria220 to reduce subjectivity in the process. The severity criteria are related to a 
loss of privacy that is experienced by the data subject but that may have further related consequences 
impacting other individuals and/or society. 
The table below outlines different severity221 criteria. The calculation of severity can follow the same 
steps as those used for determining probability, including aggregating scores and mapping them to 
severity levels. However, for severity, certain criteria (numbers 1 to 5, and 7 & 8) act as "stoppers" This 
means that the end score will always be the highest one from those criteria no matter what the 
                                                            
218 AEPD, ‘Risk Management and Impact Assessment in Processing of Personal Data’ p - 77 (2021) https://www.aepd.es/guides/risk-
management-and-impact-assessment-in-processing-personal-data.pdf 
219 Council of Europe (CAI), ‘Methodology for the Risk and impact assessment of Artificial Intelligence Systems from the point of view of 
human rights, democracy and the rule of law (Huderia Methodology)’ (2024) https://rm.coe.int/cai-2024-16rev2-methodology-for-the-risk-
and-impact-assessment-of-arti/1680b2a09f 
220 (...) 7/ Risks, which are related to potential negative impact on the data subject’s rights, freedoms and interests, should be determined 
taking into consideration specific objective criteria such as the nature of personal data (e.g. sensitive or not), the category of data subject 
(e.g. minor or not), the number of data subjects affected, and the purpose of the processing. The severity and the probability of the impacts 
on rights and freedoms of the data subject constitute elements to take into consideration to evaluate the risks for individual’s privacy’’, p.4, 
Article 29 Working Party (WP 208) ‘’Statement on the role of risk-based approach in data protection legal frameworks’’, Adopted on 30 May 
2014, https://ec.europa.eu/justice/article-29/documentation/opinion-recommendation/files/2014/wp218_en.pdf 
221 See footnote 217

## Page 61 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
61 
 
aggregation score is. For instance, if any of these criteria are assessed at the highest level (4), the overall 
severity score is immediately assigned a level 4. This approach ensures that critical harms, such as those 
involving irreversible damage, are appropriately prioritized and flagged for immediate and 
comprehensive mitigation measures.

## Page 62 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
 
 
SEVERITY LEVELS 
Criteria 
Description 
Level 1 (Very Limited)
Level 2 (Limited)
Level 3 (Significant)
Level 4 (Very Significant)
Moderate or Minor Harm 
Serious Harm 
Critical Harm 
Catastrophic Harm 
Moderate or minor prejudices or 
impairments in the exercise of 
fundamental rights and freedoms 
that do not lead to any significant, 
enduring, or temporary 
degradation of human dignity, 
autonomy, physical, psychological, 
or moral integrity, or the integrity 
of communal life, democratic 
society, or just legal order. 
Serious prejudices or impairments 
in the exercise of fundamental 
rights and freedoms that lead to 
the temporary degradation of 
human dignity, autonomy, physical, 
psychological, or moral   integrity, 
or the integrity of communal life, 
democratic society, or just legal 
order or that harm to the 
information and communication 
environment. 
Critical prejudices or impairments in 
the exercise of fundamental rights 
and freedoms that lead to the 
significant and enduring 
degradation of human dignity, 
autonomy, physical, psychological, 
or moral integrity, or the integrity 
of communal life, democratic 
society, or just legal order. 
Catastrophic prejudices or 
impairments in the exercise of  
fundamental  rights  and  freedoms  
that  lead  to  the deprivation  of  the  
right  to  life;  irreversible  injury  to  
physical, psychological, or moral 
integrity; deprivation of   the   
welfare   of   entire   groups   or   
communities;  catastrophic harm to 
democratic society, the rule of law, 
or  to  the  preconditions  of  
democratic  ways  of  life  and just 
legal order; deprivation of individual 
freedom and of  the  right  to  liberty  
and  security;  harm  to  the  
biosphere.  
1. Nature of the 
fundamental 
right and Legal 
limitation 
alignment 
This criterion evaluates the 
nature of the fundamental 
right affected—whether it is 
absolute or subject to 
limitations—and assesses the 
extent to which the AI system's 
use case aligns with lawful and 
proportionate restrictions. 
Absolute rights are non-
derogable and cannot be 
restricted under any 
circumstances, while other 
rights may be limited only if 
the interference meets strict 
legal, proportionality, and 
necessity requirements. This 
criterion helps determine the 
severity of the impact based 
on the degree of misalignment 
or violation of the right's 
protections. 
The fundamental right affected is 
highly limited in scope and 
applicability, meaning it is 
frequently subject to lawful 
restrictions with minimal 
requirements to justify the 
interference. 
The use case clearly and fully aligns 
with permitted legal limitations, 
and the interference is routine and 
widely accepted, without causing 
significant violations of legal or 
normative frameworks. 
The fundamental right affected is 
moderately limited, meaning 
restrictions are lawful but subject 
to stricter justification 
requirements and more specific 
conditions. 
The use case aligns with legal 
limitations, but the interference 
requires a moderate level of 
justification, such as demonstrating 
proportionality and necessity, 
otherwise causing possible minor 
violations of legal or normative 
frameworks. 
The fundamental right affected is 
minimally limited, meaning 
restrictions are only lawful under 
exceptional and tightly controlled 
circumstances. 
The use case partially aligns with 
lawful exceptions, but there are 
uncertainties about the 
proportionality, necessity, or 
legitimacy of the interference, 
causing possible major violations of 
legal or normative frameworks. 
The fundamental right affected is 
absolute and non-derogable, 
meaning no lawful restriction is 
permitted under any circumstances. 
Alternatively, the use case does not 
align with lawful and proportionate 
limitations, even if the right is not 
absolute, causing severe violations of 
legal or normative frameworks. 
 
* The Charter does not explicitly 
identify the rights that are absolute. 
Based on the Charter explanations, 
the ECHR and the case law of the 
European courts, it is submitted that 
human dignity (Article 1 of the 
Charter), the prohibition of torture 
and inhuman or degrading treatment 
or punishment (Article 4 of the 
Charter), the prohibition of slavery 
and forced labour (Article 5(1) and 
(2) of the Charter), internal freedom

## Page 63 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
63 
 
of thought, conscience and religion 
(Article 10(1) of the Charter), the 
presumption of innocence and right 
of defence (Article 48 of the 
Charter), the principle of legality 
(Article 49(1) of the Charter) and the 
right not to be tried or punished 
twice in criminal proceedings for the 
same criminal offence (Article 50 of 
the Charter) can be considered 
absolute rights. 
2. Nature of 
personal data 
This criterion assesses the 
sensitivity of the personal data 
being processed, considering 
its potential to cause harm if 
misused. Special category of 
data (e.g., health, biometric, or 
genetic data) poses greater 
risks to fundamental rights like 
privacy and autonomy. 
Non-sensitive, publicly available 
data (e.g., anonymized data, public 
records). 
Moderately sensitive data (e.g., 
financial data, browsing history). 
Highly sensitive data 
The most sensitive data & special 
category of data e.g., genetic data, 
psychological profiles, biometrics or 
data revealing criminal history. 
3. Category of 
Data Subject 
(e.g., minor or 
not) 
This criterion evaluates the 
vulnerability of the individuals 
whose data is being processed. 
Vulnerable groups (e.g., 
minors, marginalized 
communities) face greater risks 
of harm from data misuse. 
Data subjects are not vulnerable 
(e.g., adults in routine, non-
sensitive contexts). 
Data subjects include some 
individuals in potentially vulnerable 
groups (e.g., employees, 
customers). 
Data subjects include individuals in 
sensitive or high-risk roles (e.g., 
journalists, activists). 
Data subjects are highly vulnerable 
(e.g., minors, persons with 
disabilities, or persecuted groups). 
4. Purpose of 
Processing 
This criterion evaluates the 
legitimacy, necessity, and 
proportionality of the purpose 
for which personal data is 
being processed. Unlawful or 
disproportionate purposes 
increase severity. 
Clearly legitimate and 
proportionate purposes with 
minimal risks (e.g., operational 
purposes). 
Legitimate purposes with moderate 
risks or indirect impacts (e.g., 
targeted marketing). 
Legitimate purposes but with 
questionable proportionality or 
necessity (e.g., profiling for credit 
scoring). 
Unlawful, unclear, or disproportional 
purposes with significant risks (e.g., 
surveillance, discriminatory 
profiling). 
5. Scale of Impact 
(Societal, Group, 
Individual) & 
Number of Data 
Subjects Affected 
The breadth of the 
infringement across societal, 
group, and individual levels. 
This criterion considers the 
scale of the impact based on 
the number of individuals 
whose data is affected.  
Impact is limited to a small, 
localized group or individual. Fewer 
than 100 individuals affected. 
Impact is limited to specific groups 
or a small societal segment. 
Between 100 and 1,000 individuals 
affected. 
Impact spans multiple groups or 
societal domains. Between 1,000 
and 100,000 individuals affected. 
Impact is widespread, affecting 
societal, group, and individual levels. 
Over 100,000 individuals affected.

## Page 64 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
64 
 
6. Contextual and 
Domain 
Sensitivity  
How specific contextual factors 
or domains intensify the 
interference's severity. 
Includes circumstantial risks 
like socio-political instability 
and if children and other 
vulnerable groups are affected. 
Context or domain does not 
amplify the severity of the 
interference with the fundamental 
right. 
Context or domain moderately 
amplifies the severity of the 
interference with the fundamental 
right. 
Context or domain significantly 
amplifies the severity of the 
interference with the fundamental 
right. 
Context or domain profoundly 
amplifies the severity of the 
interference with the fundamental 
right. 
7. Reversibility, 
recovery, degree 
of remediability  
The difficulty or feasibility of 
reversing harm and the time 
required for recovery. Includes 
prohibitive risks where harm is 
irreversible. 
Harm is fully reversible within a 
short period with minimal effort. 
Harm is reversible with moderate 
effort over a reasonable 
timeframe. 
Harm is difficult to reverse, 
requiring significant effort or 
resources. 
Harm is irreversible, with no feasible 
means of recovery. 
8. Duration and 
Persistence of 
Harm 
The length of time and 
persistence of adverse effects 
caused by the interference. 
Adverse effects are minimal and do 
not persist over time. 
Adverse effects persist briefly but 
do not result in long-term 
consequences. 
Adverse effects persist for a 
considerable period and can affect 
multiple groups. 
Adverse effects are permanent or 
persist indefinitely. 
9. Velocity to 
materialise 
The speed at which the risk 
materialises: gradual, sudden, 
continuously changing. 
Risk materialises gradually, 
providing sufficient time for 
intervention. 
Risk materialises at a moderate 
pace, allowing for corrective 
measures. 
Risk materialises suddenly, leaving 
limited time for intervention. 
Risk materialises rapidly, with no 
opportunity for intervention. 
10. Transparency 
and mechanisms 
for Accountability 
The degree of system 
transparency and mechanisms 
for accountability. 
System is highly transparent with 
clear and effective accountability 
mechanisms. 
System lacks some transparency 
but has basic accountability 
mechanisms. 
System lacks transparency and has 
weak accountability mechanisms. 
System is entirely opaque, with no 
mechanisms for accountability. 
11. Ripple and 
Cascading Effects 
The extent to which the 
interference triggers additional 
harms across systems or 
domains. 
No cascading effects; the risk is 
isolated and contained. 
Minimal cascading effects; impacts 
are mostly contained. 
Notable cascading effects; impacts 
extend across domains. 
Severe cascading effects; impacts 
propagate extensively.

## Page 65 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
 
Risk Evaluation: Classification of Risks 
Assessing probability and severity provides the foundation for determining the overall risk level of the 
identified privacy and data protection risks. Using a four-level classification matrix for both probability 
and severity, risks can be categorized into final classifications of Very High, High, Medium, or Low. 
 
A matrix, as shown below, serves as a practical tool to obtain these classifications, offering a clear and 
structured ranking to prioritize risks and guide appropriate mitigation strategies. This classification is a 
critical step in the next risk treatment process because it ensures that resources are directed toward 
addressing the most pressing risks effectively. 
 
 
 
Probability 
Very High 
Medium 
High 
Very high 
Very high 
High 
Low 
High 
Very high 
Very high 
Low 
Low 
Medium 
High 
Very high 
Unlikely 
Low 
Low 
Medium 
Very high 
 
 
Very limited 
Limited 
Significant 
Very 
Significant 
 
 
Severity 
 
Best practices in risk management suggest that the mitigation of very high and high level risks should 
be prioritized. 222 Once these critical risks are identified, the next essential step is to develop and 
implement a risk treatment plan. 
 
Risk Acceptance Criteria 
In the Risk Evaluation phase, risk criteria are used to determine whether a risk is acceptable or needs 
treatment. These criteria reflect the organization's willingness and capacity to bear risks within legal 
and operational limits and must align with applicable laws and regulations, such as GDPR and AI Act 
requirements, to ensure compliance and the protection of individuals' rights. 
Different frameworks and best practices223 can assist organizations in defining these criteria. These can 
be establish considering factors such as social norms, expected benefits, potential harms, metrics 
established thresholds, evaluation results, and comparable use cases224. Justifying these decisions is 
critical, as organizations are accountable for demonstrating how risks are managed and mitigated. This 
aligns with the GDPR principle of accountability225, which requires organizations to document and justify 
their risk mitigation and acceptance decisions. 
 
 
 
 
 
 
                                                            
222 Oliva, L., ’ Successfully managing high-risk, critical-path projects’ (2003) https://www.pmi.org/learning/library/high-risk-critical-path-
projects-7675 
223 Marsden, E. ’Risk acceptability and tolerability’ (n.d) https://risk-engineering.org/static/PDF/slides-risk-acceptability.pdf 
224 Science Direct, ‘Definition of Residual Risk’ (2019) https://www.sciencedirect.com/topics/engineering/residual-risk 
225 Article 5(2), Recital 74, GDPR 
Figure 15. Risk Evaluation Matrix

## Page 66 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
66 
 
 
6. Data Protection and Privacy Risk Control 
Risk Treatment Criteria 
i.e., mitigate, transfer, avoid or accept a risk. 
Risk treatment involves developing strategies to mitigate identified risks and creating actionable 
implementation plans. The choice of an appropriate treatment option should be context-specific, 
guided by a feasibility analysis226 such as the following: 
o Evaluate the type of risk and the available mitigation measures that can be implemented. 
o Compare the potential benefits gained from implementing the mitigation against the costs and 
efforts involved and the potential impact. 
o Assess the impact on the intended purpose of the LLM system's implementation. 
o Consider the reasonable expectations of individuals impacted by the system. 
o Perform a trade-off analysis to evaluate the impact of potential mitigations on aspects such as 
performance, transparency, and fairness, ensuring that processing remains ethical and 
compliant based on the specific use case. 
Analyzing these criteria is essential for effective risk mitigation and risk management planning, providing 
clarity on whether specific mitigation efforts are justifiable. In all cases, the chosen treatment option 
should be clearly justified and thoroughly documented to ensure accountability and compliance.  
The most common risk treatment criteria are: Mitigate, Transfer, Avoid and Accept.  
For each identified risk one of the criteria options will be selected: 
 Mitigate – Implement measures to reduce the probability or the severity of the risk. 
 Transfer – Shift responsibility for the risk to another party (e.g., through insurance or 
outsourcing). 
 Avoid – Eliminate the risk entirely by addressing its root cause. 
 Accept – Decide to take no action, accepting the risk as is because it falls within acceptable limits 
as defined in the risk criteria. 
Deciding whether a risk can be mitigated involves assessing its nature, potential impact, and available 
mitigation measures such as implementing controls, adopting best practices, modifying processes, or 
using tools to reduce the probability or severity of the risk. 
Not all risks can be fully mitigated. Some risks may be inherent and cannot be entirely avoided. In such 
cases, the objective is to reduce the risk to an acceptable level or implement risk mitigation and control 
measures that effectively manage its impact. 
It is also important to maintain a dynamic risk register, containing risk records that are durable, easily 
accessible, clear, and that are consistently updated to ensure accuracy and relevance227. 
Risks should also have clear ownership assigned, and regular reviews should be conducted to ensure 
that risk management practices remain proactive. 
                                                            
226 Centre for Information Policy Leadership, ‘Risk, High Risk, Risk Assessments and Data Protection Impact Assessments under the GDPR. 
GDPR Interpretation and Implementation Project’ (2016) 
https://www.informationpolicycentre.com/uploads/5/7/1/0/57104281/cipl_gdpr_project_risk_white_paper_21_december_2016.pdf 
227 Ofcom, ‘Protecting people from illegal harms online’ (2024) https://www.ofcom.org.uk/siteassets/resources/documents/online-
safety/information-for-industry/illegal-harms/volume-1-governance-and-risks-management.pdf?v=387545

## Page 67 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
 
Example of Mitigation Measures Related to Risks of LLM Systems 
Choosing appropriate mitigation measures should be done on a case-by-case basis. The table below contains some of the possible mitigation measures that could 
be implemented to address LLMs privacy and data protection risks. These measures are general and not tied to any specific use case’s context and intended purpose. 
Mitigation’s recommendations may apply to both provider and deployers. In some cases, mitigations also apply to the deployer if they modify the model. 
 
 
Data Protection and Privacy Risks 
Recommended Mitigations 
 
Provider 
Deployer 
1. Insufficient protection of personal 
data what eventually can be the cause 
of a data breach 
 
Specific to RAG: 
Insufficient protection in RAG systems 
what can lead to data breaches, 
indirect prompt injection, and the 
retrieval of outdated or inaccurate 
information, resulting in poor decision-
making and potential harm to 
individuals. Specific queries might also 
inadvertently disclose personal data 
included in training, violating privacy 
regulations.228 
As provider and deployer, it is important to verify229 that: 
 
APIs are securely implemented (Use API gateways with rate limiting and monitoring capabilities to control and 
monitor access) 
 
Transmission of data are protected with the adequate encryption protocols, data at rest is encrypted. 
 
There is an adequate access control mechanism implemented. 
 
There are measures implemented for anonymization and pseudonymization of personal data, or for masking of data 
or use of synthetic data.  
 
Additional technical and organizational measures (TOMs) are implemented to further enhance security. These 
measures may include, but are not limited to, ensuring a secure environment through data segregation, backups, 
regular physical and digital security audits, incident response mechanisms, awareness and training. 
 
A Defense in Depth230 approach can be implemented by layering multiple risk mitigation measures to prevent single 
points of failure. This may include model-level protections, network security, user authentication, encryption, 
PETs231, access control and continuous monitoring to detect misuse, bias, or vulnerabilities in real time. 
 
To mitigate memorization risk, implement differential privacy techniques to prevent sensitive data encoding and 
regularly test for data regurgitation. Consider also using smaller models to avoid the memorization232 effect from 
overparametrized model. 
 
Also measures for protection and identification of insider threats, measures to mitigate supply chain attacks that 
could give access to the training data and/or the data storage and encryption keys, measures implemented to 
prevent risks associated to different LLM security threats233234 such as membership inference235, model inversion236 
and poisoning attacks237.  
 
Also access and change logs are established to document access and changes to digitized records. 
 
 
                                                            
228 EDPS, ‘TechSonar 2025 Report’ (2025) https://www.edps.europa.eu/data-protection/our-work/publications/reports/2024-11-15-techsonar-report-2025_en 
229 This could be done by performing a pentest and/or requesting pentest results to the vendor. 
230 AI Action Summit, ‘International AI Safety Report on the Safety of Advanced AI’ , p - 167, (2025) 
https://assets.publishing.service.gov.uk/media/679a0c48a77d250007d313ee/International_AI_Safety_Report_2025_accessible_f.pdf 
231 Feretzakis, G et al., ‘V.S. Privacy-Preserving Techniques in Generative AI and Large Language Models: A Narrative Review’(2024). https://doi.org/10.3390/info15110697 
232 Examples of Memorization methods: https://blog.kjamistan.com/category/ml-memorization.html 
233 OWASP, ‘OWASP Top 10 for LLM Applications 2025’ (2025) https://genai.owasp.org/llm-top-10/ 
234 Shamsabadi, S.A. et al., ’ Identifying and Mitigating Privacy Risks Stemming from Language Models’ (2024) https://arxiv.org/html/2310.01424v2 
235 Shokri et al., ‘Membership Inference Attacks Against Machine Learning Models’ (2017) https://arxiv.org/abs/1610.05820 
236 Zhang et al.,’Generative Model-Inversion Attacks Against Deep Neural Networks’, (2020) https://arxiv.org/abs/1911.07135 
237 Guo, J. et al., ‘Practical Poisoning Attacks on Neural Networks’, (2020) https://www.ecva.net/papers/eccv_2020/papers_ECCV/papers/123720137.pdf

## Page 68 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
68 
 
 
Employees and users are trained on security best practices. 
 
Effective RAG systems require careful model alignment to prevent unauthorized access and sensitive data exposure. 
Integration with multiple data sources necessitates robust security measures to ensure confidentiality and data 
integrity, while adhering to data protection principles like necessity and proportionality. For outsourced RAG models 
involving personal data transfer, compliance with GDPR's data transfer rules is critical to maintaining confidentiality 
and legal obligations.238 
 
2. Misclassifying training data as 
anonymous by controllers when it 
contains identifiable information, 
leading to failure to implement 
appropriate safeguards for data 
protection. (partly relating to risk 3) 
 
Whenever information relating to 
identified or identifiable individuals 
whose personal data was used to train 
the model may be obtained from an AI 
model with means reasonably likely to 
be used239, it may be concluded that 
such a model is not anonymous.240 
 
 
Implement robust testing and validation processes to ensure that (i) personal data associated with the training data 
cannot be extracted from the model using reasonable means, and (ii) any outputs generated by the model do not 
link back to or identify data subjects whose personal data was used during training.  
 
This assessment should be done taking into account ‘all the means reasonably likely to be used’ considering 
objective factors such as:241 
o 
The characteristics of the training data, the AI model, and the training procedure. 
o 
The context in which the AI model is released or processed. 
o 
The availability of additional information that could enable identification. 
o 
The costs and time required to access such additional information, if not readily available. 
o 
Current technological capabilities and potential future advancements. 
 
Implement alternative approaches to anonymization if they provide an equivalent level of protection, ensuring they 
align with the state of the art. 
 
Implement structured testing against state of the art attacks such as attribute and membership inference, 
exfiltration, regurgitation of training data model inversion, or reconstruction attacks. 
 
Document and retain evidence to demonstrate compliance with these safeguards following accountability 
obligations under Article 5(2) GDPR. Documentation should include: 
o 
Details of DPIAs, including assessments and decisions on their necessity. 
o 
Advice or feedback from the DPO (if applicable). 
o 
Information on technical and organizational measures to minimize identification risks during the model 
design, including threat models and risk assessments for training datasets (e.g., source URLs and 
safeguards). 
o 
Measures taken throughout the AI model lifecycle to prevent or verify the absence of personal data in the 
model. 
o 
Evidence of the model's theoretical resistance to re-identification techniques, including metrics, testing 
reports, and analysis of attack resistance (e.g., regurgitation, membership inference). 
o 
Documentation provided to controllers and data subjects detailing measures to reduce identification risks 
and addressing potential residual risks. 
 
 
242 
                                                            
238 https://www.edps.europa.eu/data-protection/our-work/publications/reports/2024-11-15-techsonar-report-2025_en  
239 Membership Inference Attacks and Model Inversion Attacks. 
240 EDPB Opinion 28/2024 on certain data protection aspects related to the processing of personal data in the context of AI models. Adopted on 17 December 2024 
241 idem 
242 Deployers should verify that the provider has effectively addressed this risk. This recommendation is equally relevant in cases where deployers are involved in fine-tuning or retraining models.

## Page 69 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
69 
 
3. Unlawful processing of personal data 
in training sets 
 
Document all training data sources (e.g., book databases, websites) to ensure accountability under Art. 5(2) GDPR. 
 
Check training data for statistical distortions or biases and make necessary adjustments. 
 
Exclude training data that includes unauthorized content, such as fake news, hate speech, or conspiracy theories. 
 
Exclude content from publications that may contain personal data posing risks to individuals or groups, such as 
those vulnerable to abuse, prejudice, or harm. 
 
Remove unnecessary personal data (e.g., credit card numbers, email addresses, names) from the training dataset. 
243 
 
Employ methodological choices that significantly reduce or eliminate identifiability, such as using regularization 
methods to enhance model generalization and minimize overfitting. 
 
Implement robust privacy-preserving techniques, such as differential privacy.244 
 
When using web scraping as a method to collect data, ensure compliance with Article 6(1)(f) GDPR by conducting a 
thorough legal assessment. This includes evaluating:  
o 
(i) the existence of a legitimate interest for data processing. Interest should be lawful, clearly articulated 
and real, not speculative. 
o 
(ii) the necessity of the processing, ensuring that personal data collected is adequate, relevant, and limited 
to what is necessary for the stated purpose245, and  
o 
could not reasonably be fulfilled by other means’ 
o 
(iii) a careful balancing of interests, where the fundamental rights and freedoms of data subjects are 
weighed against the legitimate interests of the data controller.  
Consideration should also be given to the reasonable expectations of data subjects regarding the use of their 
data.246 
 
Involve the DPO in the balancing test, where applicable247. 
 
For web scraping, assess whether the exemption under Article 14(5)(b) applies, ensuring all criteria are met to justify 
not informing each data subject individually. 
Transparency: 
 
Provide public and easily accessible information that goes beyond GDPR requirements under Articles 13 and 14, 
including details about collection criteria and datasets used, with special consideration for protecting children and 
vulnerable individuals.  
 
Use innovative approaches to inform data subjects, such as media campaigns, email notifications, graphic 
visualizations, FAQs, transparency labels, model cards, and voluntary annual transparency reports.248 
 
Implement an opt-out list managed by the controller, enabling data subjects to object to the collection of their data 
from specific websites or platforms by providing identifying information before data collection begins. 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
249 
                                                            
243 Bavarian State Office for Data Protection Supervision, ‘Data protection compliant Artificial intelligence Checklist with test criteria according to GDPR’ 
244 EDPB Opinion 28/2024 on certain data protection aspects related to the processing of personal data in the context of AI models, Adopted on 17 December 2024. 
245 Recital 39 GDPR clarifies that ‘Personal data should be processed only if the purpose of the processing could not reasonably be fulfilled by other means’ 
246 EDPB Report of the work undertaken by the ChatGPT Taskforce (2024) 
247 EDPB Opinion 28/2024 on certain data protection aspects related to the processing of personal data in the context of AI models. Adopted on 17 December 2024. 
248 Idem 
249 Deployers should verify that the provider has effectively addressed this risk. This recommendation is equally relevant in cases where deployers are involved in fine-tuning or retraining models.

## Page 70 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
70 
 
4. Unlawful processing of special 
categories of personal data and data 
relating to criminal convictions and 
offences in training data. 
 
For the lawful processing of special categories of personal data, ensure that an exception under Article 9(2) GDPR 
applies250. When relying on Article 9(2)(e), confirm that the data subject explicitly and intentionally made the data 
publicly accessible through a clear affirmative action. The mere fact that personal data is publicly accessible does 
not imply that the data subject has manifestly made such data public251. 
 
Given the challenges of case-by-case assessment in large-scale web scraping, implement safeguards such as filtering 
to exclude data falling under Article 9(1) GDPR both during and immediately after data collection.  
 
Maintain robust documentation and proof of these measures to comply with accountability requirements under 
Articles 5(2) and 24 GDPR.252 
 
 
 
 
 
 
 
 
253 
5. Possible adverse impact on data 
subjects that could negatively impact 
fundamental rights:  
 
LLM outputs could contain biased and 
inaccurate information, potentially 
violating the GDPR principles of 
accuracy, transparency, lawfulness and 
fairness and misleading users into 
treating incorrect outputs as factually 
reliable. 
All this could have an adverse impact 
on data subjects and their fundamental 
rights. 
Transparency: 
 
Implement robust transparency measures to inform users about the probabilistic nature of LLM outputs and their 
potential for bias or inaccuracies. Provide explicit disclaimers that the generated content may not be factually 
accurate or real, ensuring users understand the limitations of the system.  
 
Inform deployers and users whether their personal data will impact the service provided to that specific user or 
whether it would be used to modify the service provided to all customers. 
 
Users should select LLMs with proven performance metrics and continuously monitor outputs for errors or biases, 
so transparency publishing this information could be recommended.  
Accuracy and Fairness: 
 
Developers should ensure the quality of training data through robust preprocessing techniques, such as filtering, 
validation and normalization, to prevent biased or misleading outputs, they should also assess its impact on AI 
outputs, evaluate the model's statistical accuracy for its intended purpose, and transparently communicate these 
considerations to deployers and end users to mitigate potential negative effects during deployment.254 Regularly 
review and document all steps taken to comply with the GDPR principles of transparency and accuracy under 
Articles 5(1)(a) and 5(1)(d).255 
 
For third-party platforms, effective configuration and use of available tools are essential to enhance input handling 
and ensure outputs meet accuracy and fairness standards.  
 
Regular audits and oversight mechanisms are critical to addressing risks like data leakage, bias, or unintended 
inferences. 
 
LLMs could also be fine-tuned to handle diverse linguistic and contextual variations, reducing inaccuracies in 
sensitive applications.  
 
 
 
 
 
 
 
257 
                                                            
250 EDPB Opinion 28/2024 on certain data protection aspects related to the processing of personal data in the context of AI models. Adopted on 17 December 2024: “The EDPB recalls the prohibition of Article 9(1) GDPR 
regarding the processing of special categories of data and the limited exceptions of Article 9(2) GDPR. In this respect, the Court of Justice of the European Union (“CJEU”) further clarified that ‘where a set of data containing 
both sensitive data and non-sensitive data is [...] collected en bloc without it being possible to separate the data items from each other at the time of collection, the processing of that set of data must be regarded as being 
prohibited, within the meaning of Article 9(1) of the GDPR, if it contains at least one sensitive data item and none of the derogations in Article 9(2) of that regulation applies’  . Furthermore, the CJEU also emphasised that ‘for 
the purposes of the application of the exception laid down in Article 9(2)(e) of the GDPR, it is important to ascertain whether the data subject had intended, explicitly and by a clear affirmative action, to make the personal 
data in question accessible to the general public’ . These considerations should be taken into account when processing of personal data in the context of AI models involves special categories of data.”  
251 EDPB, Report of the work undertaken by the ChatGPT Taskforce 
252 Idem 
253 Deployers should verify that the provider has effectively addressed this risk. This recommendation is equally relevant in cases where deployers are involved in fine-tuning or retraining models. 
254 Information Commissioner Officer (ICO) ‘Generative AI third call for evidence: accuracy of training data and model outputs’ (2025)  https://ico.org.uk/about-the-ico/what-we-do/our-work-on-artificial-
intelligence/generative-ai-third-call-for-evidence/ 
255 Idem 
257 Deployers should verify that the provider has effectively addressed this risk. This recommendation is equally relevant in cases where deployers are involved in fine-tuning or retraining models.

## Page 71 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
71 
 
 
To mitigate the risk of adverse impacts on data subjects and fundamental rights in the context of LLMs, accuracy256 
and reliability must be prioritized throughout the system lifecycle. 
 
Ensure that training datasets are diverse and representative of different demographic groups to reduce biases 
inherent in the data. 
 
Conduct regular audits and fairness tests and incorporate human review in sensitive decisions to ensure fairness and 
accountability. 
 
Use explainability frameworks to analyze and understand how decisions are made, what helps in identifying 
potential sources of bias. 
 
6. Not providing human intervention 
for a processing that can have a legal or 
important effect on the data subject. 
 
Human oversight should be integrated into decision-making processes where the outputs of LLMs could lead to legal 
or significant consequences for individuals258. This includes ensuring that automated decisions are subject to review 
by qualified personnel who can assess the fairness, accuracy, and relevance of the outputs. 
 
Clear escalation procedures should be in place for cases where automated outputs appear ambiguous, erroneous, or 
potentially harmful.  
 
Developers and deployers must design systems to flag high-risk outputs for mandatory human intervention before 
any action is taken259.  
 
Transparency mechanisms should also be implemented260, ensuring data subjects are informed about the use of 
LLMs, the capabilities and limitations of the model261, the processing of personal data through the model and their 
right to contest decisions or seek human review.  
 
Regular training for staff involved in oversight can further enhance compliance and accountability. 
 
Implement Article 29 Working Party (“WP29”) Guidelines on Automated individual decision-making and Profiling for 
the purposes of Regulation 2016/679, as last revised and adopted on 6 February 2018, endorsed by the EDPB on 25 
May 2018. See also, CJEU judgment of 7 December 2023, Case C-634/21, SCHUFA Holding and Others 
(ECLI:EU:C:2023:957). 
 
 
 
 
 
 
 
 
 
 
 
7. Not granting data subjects their right 
to object, rectification, and erasure. 
 
The right to object under Article 21 GDPR applies and should be ensured when the legal basis is legitimate 
interest262. In such a case, providers should implement mechanisms to grant this right. Some measures to 
implement when collecting personal data could be263: 
o 
Introduce a reasonable period between the collection of a training dataset and its use, allowing data 
subjects time to exercise their rights. 
o 
Provide an unconditional opt-out mechanism for data subjects before processing begins. 
o 
Permit data subjects to request data erasure, even beyond the specific grounds listed in Article 17(1) 
GDPR.
 
 
 
 
 
 
 
 
 
 
 
 
 
 
                                                            
256 AI Model Code, ‘Evaluating language models for accuracy and bias’ (2024) https://aimodelcode.org/tech-info/llm-eval/  
258 Lumenova, ‘The Strategic Necessity of Human Oversight in AI Systems’ (2024) https://www.lumenova.ai/blog/strategic-necessity-human-oversight-ai-systems/ 
259 Kuriakose, A.A., ’ The Role of Human Oversight in LLMOps’ (2024) https://www.algomox.com/resources/blog/what_is_the_role_of_human_oversight_in_llmops/ 
260 Garante per la Protezione dei Dati Personali (GDPD), ‘ChatGPT, il Garante privacy chiude l’istruttoria. OpenAI dovrà realizzare una campagna informativa di sei mesi e pagare una sanzione di 15 milioni di euro’ (2024) 
https://www.garanteprivacy.it/home/docweb/-/docweb-display/docweb/10085432?mkt_tok=MTM4LUVaTS0wNDIAAAGX5pUM0HSpbBgVFc2wv7uGKk23174FM2-
cFJBvVD0FDGJCM_27RuQFPm2uSB80ihorQ2e0YWwgCPRFngJDRE4b7N_pWRz873q84sJ8ZWucdQOh#english 
261 EDPB Report of the work undertaken by the ChatGPT Taskforce (2024) 
262 Note that according to Art. 21(1) GDPR, “The controller shall no longer process the personal data unless the controller demonstrates compelling legitimate grounds for the processing which override the interests, rights 
and freedoms of the data subject or for the establishment, exercise or defence of legal claims.” 
263 EDPB Opinion 28/2024 on certain data protection aspects related to the processing of personal data in the context of AI models. Adopted on 17 December 2024

## Page 72 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
72 
 
o 
Claim Handling: Enable data subjects to report instances of personal data regurgitation or memorization, 
with mechanisms for controllers to assess and apply unlearning techniques to resolve such claims. 
 
Mitigating non-compliance with GDPR concerning data subjects' rights to rectification and erasure involves exploring 
machine unlearning techniques264. These approaches aim to remove the influence of data from a trained model 
upon request, addressing concerns about data use, low-quality inputs, or outdated information. 
o 
Exact unlearning seeks to entirely eliminate the influence of specific data points, often through retraining 
or advanced methods that avoid full retraining. Techniques like Sharded, Isolated, Sliced, and Aggregated 
(SISA) training divide data into subsets, simplifying data removal while striving to maintain model 
robustness. Approximate unlearning attempts to reduce the impact of specific data points by adjusting 
model weights or applying correction factors, offering a trade-off between precision and efficiency. 
While these methods hold promise, challenges remain, including maintaining model accuracy and avoiding 
unintended biases post-unlearning. Certified removal, which provides verifiable guarantees of data removal using 
mathematical proofs, offers a rigorous but resource-intensive solution. As unlearning techniques evolve, they play a 
crucial role in enabling compliance with GDPR while preserving the integrity and fairness of machine learning 
models.265 
 
Implement mechanisms to delete personal data, such as names, ensuring their removal(block)266 is comprehensive 
and context-agnostic across the dataset. Recognize that this approach might result in the deletion of the name for 
all individuals with the same identifier, regardless of the context. To mitigate unintended consequences, use precise 
filtering techniques to differentiate between contexts where the name is personally identifiable and generic. To 
prevent misuse or reintroduction of deleted data, secure filter scripts or prompts by restricting access to authorized 
personnel only, employing encryption, and maintaining version control. Regularly audit these scripts to ensure they 
are up to date and free from vulnerabilities.  
 
It is also important to in particular with regard to Article 21 GDPR, to establish mechanisms to comply with the 
requests of users that object to the processing of their personal data based on legitimate interest.267 
 
For deletion requests under Art. 17 GDPR, assess whether personal data can be directly identified or derived from 
the AI model and implement technical deletion where feasible, such as post-training adjustments.268 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
269 
8. Unlawful repurpose of personal data 
 
Ensure compliance with Article 5(1)(c) GDPR by clearly limiting personal data processing to what is necessary for 
specific, well-defined purposes. Avoid overly broad purposes like "developing and improving an AI system." Instead, 
specify the type of AI system (e.g., large language model, generative AI for images) and its technically feasible 
functionalities and capabilities.270 
 
 
 
 
 
 
                                                            
264 Shrishak, K., ‘AI-Complex Algorithms and effective Data Protection Supervision Effective implementation of data subjects’ rights’ Support Pool of Experts Programme EDPB (2024) 
https://www.edpb.europa.eu/system/files/2025-01/d2-ai-effective-implementation-of-data-subjects-rights_en.pdf 
265 EDPS, ‘TechSonar 2025 Report’ (2025) https://www.edps.europa.eu/data-protection/our-work/publications/reports/2024-11-15-techsonar-report-2025_en 
266 Surve, D., ‘Beginner’s Guide to LLMs: Build a Content Moderation Filter and Learn Advanced Prompting with Free Groq API’ (2024) https://deveshsurve.medium.com/beginners-guide-to-llms-build-a-content-moderation-
filter-and-learn-advanced-prompting-with-free-87f3bad7c0af 
267 EDPB Report of the work undertaken by the ChatGPT Taskforce (2024) 
268 Bavarian State Office for Data Protection Supervision, ‘Data protection compliant Artificial intelligence Checklist with test criteria according to GDPR’ 
269 Deployers should verify that the provider has effectively addressed this risk. This recommendation is equally relevant in cases where deployers are involved in fine-tuning or retraining models. 
270 CNIL, ‘Artificial Intelligence (AI)’ (2025) https://www.cnil.fr/en/topics/artificial-intelligence-ai

## Page 73 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
73 
 
 
Article 6(4) GDPR provides, for certain legal bases, criteria that a controller shall take into account to ascertain 
whether processing for another purpose is compatible with the purpose for which personal data are initially 
collected.271 
 
When outsourcing AI training, verify legal guarantees (e.g., contracts, third-country transfer measures) and ensure 
training data is not used by service providers for unauthorized purposes. 
 
9. Unlawful unlimited storage of 
personal data 
As user, deployer and procurement entity make agreements with the third-party provider about how long the input data 
and output data should be stored. This can be part of the service contract, product documentation or data processing 
agreement.  
If data are being stored on your premises, establish retention rules and /or a mechanism for the deletion of data. 
 
 
 
10. Unlawful transfer of personal data 
 
As user, deployer and procurement entity, verify with the provider where the data processing is taking place.  
 
Make the necessary safeguard diligences and when necessary, perform a Data Transfer Impact Assessment.  
 
Make the necessary contractual agreements.  
 
Consider this risk when making a selection among different vendors. 
 
 
 
 
 
11. Breach of the data minimization272 
principle 
 
Regularly review and eliminate unnecessary data collection, automating data deletion when no longer needed. 
 
Replace identifiable data with anonymized or pseudonymized alternatives immediately after collection. 
 
Apply Privacy by Design principles at every development stage, integrating data minimization measures. 
 
Exclude data collection from websites that object to web scraping (e.g., using robots.txt or ai.txt files). 
 
Limit collection to freely accessible data manifestly made public by the data subjects. 
 
Prevent combining data based on individual identifiers unless explicitly required and justified for AI system 
development.273 
 
Educate users about providing only essential data in inputs and transparently communicate data use practices. 
 
Evaluate whether processing personal data is strictly necessary for the intended purpose by exploring less intrusive 
alternatives, such as the use of synthetic or anonymized data, and ensuring the volume of personal data processed 
is proportionate to the objective. 
 
 
 
 
 
 
 
 
274 
                                                            
271 EDPB Opinion 28/2024 on certain data protection aspects related to the processing of personal data in the context of AI models. Adopted on 17 December 2024. 
272 Processing personal data to address potential biases and errors is permissible only when it is explicitly aligned with the stated purpose, and the use of such data is necessary because the objective cannot be effectively 
achieved using synthetic or anonymized data. Article 10(5) AI Act provides for specific rules for the processing of special categories of personal data in relation to the high-risk AI systems for the purpose of ensuring bias 
detection and correction. 
273 CNIL, ‘The legal basis of legitimate interests: Focus sheet’ (2024)  https://www.cnil.fr/en/legal-basis-legitimate-interests-focus-sheet-measures-implement-case-data-collection-web-scraping 
274 Deployers should verify that the provider has effectively addressed this risk. This recommendation is equally relevant in cases where deployers are involved in fine-tuning or retraining models.

## Page 74 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
 
7. Residual Risk Evaluation 
Identify, Analyze and Evaluate Residual Risk 
While inherent risk assessment identifies and evaluates risks before any controls are applied, residual 
risk assessment focuses on the remaining risk after mitigation measures have been implemented. 
Evaluating residual risks helps organizations assess the effectiveness of implemented safeguards and 
understand the potential impact of unwanted events.  
 
After completing the feasibility assessment and implementing mitigation measures, it is essential to 
reassess if there are any remaining risks. Residual risks275 are the risks that persist after mitigation 
measures have been applied. 
 
To analyze residual risk, the probability and severity of the remaining risks are reevaluated, providing a 
clear overview of the risks that remain after mitigation and taking into account276: 
 
 
Findings from prior evaluations conducted before the deployment phase 
 
The effectiveness of applied mitigation measures 
 
Potential risks that may arise post-deployment obtained through monitoring 
 
New risks identified during threat modeling sessions 
 
Once residual risks are identified, organizations must decide whether these risks fall within acceptable 
levels as defined by their risk tolerance 277 and acceptance criteria. If residual risks are deemed 
acceptable, they can be formally acknowledged and documented in the risk register. However, if the 
risks exceed acceptable levels, further mitigation measures must be explored and implemented as well 
as documented. The process then returns to the risk treatment phase to identify the most appropriate 
treatment option for the risk. 
 
Residual risk evaluation also plays a role in the decision to release a system into production. It is 
therefore important to assess whether risks remain within defined safety thresholds. Organizations may 
decide then to request further testing or additional evaluations, mandate further mitigations, or 
approve the model for deployment if the residual risk is acceptable. 
 
 
 
 
 
 
 
 
 
                                                            
275 NIST, ‘Definition of Residual Risk’ (2025) https://csrc.nist.gov/glossary/term/residual_risk 
276 See footnote 193 
277 ISO 31000:2018 Risk Management

## Page 75 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
75 
 
8. Review & Monitor 
Risk Management Process Review 
Reviewing the risk management process is essential to ensure that planned activities have been 
properly executed and that risk controls and mitigations are effective. This can be done through a 
structured review of a risk management plan,278 which serves as a roadmap for identifying, assessing, 
and mitigating risks throughout a project. While not mandatory, such plans and their reviews are a 
best practice in risk management, especially in standards for products affected by safety regulations, 
such as medical devices279. 
A risk management review helps determine whether: 
 Planned risk controls were effectively implemented 
 Emerging risks have been identified and addressed 
 The plan remains aligned with project goals and regulations 
 
Regular reviews also help refine risk strategies, improve processes, and adapt to changes in legislation, 
business operations, or team structures. 
Document Risk Register 
Documenting risk assessments, mitigation measures, and residual risks throughout the lifecycle is 
essential for ensuring accountability, compliance, and continuous improvement. A key tool for this 
process is the risk register,280 a structured document that acts as a central repository for all identified 
risks, including details such as risk nature, ownership, evaluation results, thresholds and mitigation 
measures. This documentation supports regulatory compliance with frameworks like the GDPR and AI 
Act, facilitates audits, and enables informed decision-making. A well-maintained risk register can help 
teams visualize and prioritize risks effectively. Tracking risk ownership and mitigation progress helps 
ensure that no critical risks are overlooked, and that accountability is maintained throughout the risk 
management process. 
 
Continuous Monitoring 
Once risk mitigation measures281 have been implemented, ongoing monitoring is essential to assess 
their effectiveness and identify any emerging risks. After deployment, post-market monitoring282 plays 
a critical role in identifying new risks or changes in the operational environment that may impact 
privacy. This involves the systematic collection and analysis of logs and other operational data in 
compliance with GDPR requirements, ensuring transparency, accountability, and the ongoing protection 
of user data. 
 
Currently, LLMs monitoring throughout the lifecycle relies primarily on the following 
techniques: 283 model testing and evaluation, red teaming, field testing, and long-term impact 
                                                            
278 FITT Team, ‘How Oftern Should You Review Your Risk Management Plan’ (2023) https://www.tradeready.ca/explainer/how-often-should-
you-review-your-risk-management-plan/ 
279 Vn Vroonhoven, J., ‘Risk Management Plans and the new ISO 14971’ BSI, (2020) 
https://compliancenavigator.bsigroup.com/en/medicaldeviceblog/risk-management-plans-and-the-new-iso-14971/ 
280 Wikipedia, ‘Risk Register’ (2025) https://en.wikipedia.org/wiki/Risk_register 
281 ‘risk management measures’, Art.9 AI Act. 
282 Chapter IX, Section 1 Post-market Monitoring, AI Act 
283 AI Action Summit, ‘International AI Safety Report on the Safety of Advanced AI’ , p - 184, (2025) 
https://assets.publishing.service.gov.uk/media/679a0c48a77d250007d313ee/International_AI_Safety_Report_2025_accessible_f.pdf

## Page 76 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
76 
 
assessment. These methods help identify and evaluate emerging risks that may not have been apparent 
during initial development. 
 
Model testing and iterative evaluations are used before and after the model is deployed and is part 
of an LLM system. While essential, they are insufficient on their own due to the unpredictability of 
real-world scenarios and the subjectivity of certain risks. Since LLMs can be applied in numerous 
contexts, it is difficult to predict how risks will manifest in practice, and as mentioned in section 2, 
performance metrics and benchmarks may not always accurately reflect those real risks. 
 
Methodologies such as red teaming284 can be used to stress-test the model before deployment and 
the LLM system before and after it is in production by simulating adversarial attacks or misuse 
scenarios285, helping to uncover vulnerabilities that might not have been identified during the 
development phase.  
 
Field testing evaluates AI risks in real-world conditions, but its implementation remains challenging 
due to the difficulty of accurately replicating real-world scenarios and establishing clear success 
metrics. It is important to create a representative test environment and define measurable 
performance benchmarks to obtain reliable insights. 
 
Long-term impact assessments evaluate how AI systems evolve over time, aiming to identify 
unintended consequences that may emerge with prolonged deployment. Continuous monitoring 
and periodic reassessments are essential to detect shifts in model behavior, performance 
degradation, or emerging risks that may not have been apparent during initial testing. This 
technique is part of a continuous monitoring strategy and can also be part of threat modeling 
sessions. 
 
Across all these techniques, defining robust and reliable monitoring metrics is essential. However, 
current automated assessments and quantitative metrics often lack reliability and validity,286making it 
difficult to assess risks effectively. For this reason, qualitative human review also plays a crucial role in 
capturing the broader sociotechnical implications of LLMs and their associated risks. 
 
Incident Response Mechanism 
To ensure an effective risk management strategy, it is also important to implement incident response 
mechanisms that enable a timely and appropriate response to alerts and warnings generated through 
evaluations and monitoring, as these may indicate a potential privacy or data protection incident. 
 
The warnings coming from the various monitoring techniques are crucial not only for post-market 
monitoring but also throughout the entire AI lifecycle. The techniques, the scope of testing and the 
results, will vary depending on whether evaluations are conducted before or after model training, and 
before or after model and system deployment.  
While results are important to help identify new risks, they can also play a key role in assessing the 
probability of identified threats or hazards occurring. This provides a quantitative analysis that can be 
compared against established acceptable thresholds to help determine whether further risk mitigations 
are necessary. 
 
 
 
                                                            
284 Open AI, ‘Advancing red teaming with people and AI’ (2024) https://openai.com/index/advancing-red-teaming-with-people-and-ai/ 
285 Google Threat Intelligence Group, ‘Adversarial Misuse of Generative AI’, (2025) https://cloud.google.com/blog/topics/threat-
intelligence/adversarial-misuse-generative-ai 
286 Koh Ly Wey, T., ‘Current LLM evaluations do not sufficiently measure all we need’ (2025) https://aisingapore.org/ai-governance/current-
llm-evaluations-do-not-sufficiently-measure-all-we-need/

## Page 77 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
77 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Iterative Risk Management  
Effective risk management for LLMs must adopt an iterative approach that spans the entire lifecycle of 
the system—from design and development through deployment, monitoring, and eventual 
decommissioning. As risks can evolve with changes in fine-tuning, system updates, or new contexts of 
application, regular evaluation and adjustment are essential to address emerging threats. 
Human oversight, in combination with automated measures, are critical for managing risks in LLM 
systems effectively. While automated tools, such as monitoring frameworks, risk registers, and logging 
systems, provide continuous tracking and analysis, human oversight ensures accountability, fairness, 
and transparency. This hybrid approach is essential in LLM contexts where entirely manual oversight 
would be impractical due to the system's complexity and scale. 
 
To further strengthen risk management, tools like LLMOps287 (LLM Operations) and LLMSecOps288 (LLM 
Security Operations) can automate and integrate many aspects of risk management, ensuring seamless 
updates, monitoring, and response to vulnerabilities. These tools enhance risk tracking and mitigation 
workflows, reducing the manual documentation burden and improving overall security and 
governance289 of LLM systems. 
                                                            
287 Databricks, ‘LLMOps’ (2025) https://www.databricks.com/glossary/llmops 
288 Ghosh, B., ‘LLMSecOps Elevating Security Beyond MLSecOps’ (2023) https://medium.com/@bijit211987/llmsecops-elevating-security-
beyond-mlsecops-94396768ecc6 
289 All Tech is Human x IBM Research, ‘AI Governance Workshop’ (2025) 
https://static1.squarespace.com/static/60355084905d134a93c099a8/t/677c492a161e58148fc60706/1736198443181/IBM+Research+x+ATI
H+AI+Governance+Workshop.pdf 
Pre-deployment 
Post-deployment
Pre-training /Post-training 
AI Lifecycle 
Risks are identified 
through evaluation 
techniques  
Results
Evaluation techniques 
are used to assess the 
probability of identified 
risks 
Tests & Evaluations 
Red Teaming 
Field Testing 
Long-term impact assessments 
Pre-deployment
Post-deployment 
Pre-training /Post-training 
AI Lifecycle 
Results 
Tests & Evaluations 
Red Teaming 
Field Testing 
 
Threat Modeling, 
Hazard identification 
Figure 16. Risks are identified through evaluation techniques 
Figure 17. Evaluation techniques are used to assess the probability of identified risks
Risks 
Risks

## Page 78 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
78 
 
Risk Management Process Overview 
The image below provides a visual summary of the risk management process that has been outlined in 
this report. While each phase has been explained in detail, this overview helps highlight key steps and 
their interactions, offering a clearer understanding of the entire workflow. 
 
 
Figure 18. Risk Management Process

## Page 79 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
79 
 
Risk Management Lifecycle Process 
The image below illustrates a risk management framework applied across the lifecycle of an LLM-based 
system. For each phase, the diagram outlines corresponding risk management steps from the risk 
management process. These steps help ensure that risks are identified and mitigated continuously as 
the system evolves. 
 
In addition, the figure highlights instruments for quality assurance and risk identification specific to each 
phase. These include practices such as stakeholder collaboration, threat modeling, testing and AI red 
teaming. This layered approach supports a proactive and iterative risk management strategy. 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Figure 19. Risk Management Lifecycle

## Page 80 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
80 
 
9. Examples of LLM Systems’ Risk Assessments 
First Use Case: A Virtual Assistant (Chatbot) for Customer Queries  
 
Scenario: A company specialized in kitchen equipment wants to deploy a chatbot to provide general 
information about its products and services to its customers. The chatbot will have access to pre-
existing customer data through integration with the customer management system (e.g., CRM 
databases). This will allow the chatbot to recognize users based on identifiers like email or account 
credentials and provide personalized responses without requiring users to re-enter their data. This 
chatbot interface will be built using as foundation an ‘off-the-shelf’ LLM that will use RAG to acquire 
the domain specific knowledge required.  
Lifecycle phase we are now: Design & Development 
Risk Management Process 
This section provides an overview of the steps to implement privacy risk management for LLM based 
solutions. We begin by examining potential data flows and system architecture for our use case, 
followed by the steps to identify and address privacy risks effectively. 
Data Flow Overview – What are we working on? 
The expected data flow for the processing is outlined as follows: 
 
1. User input → Users will interact with the chatbot directly after logging into the company by 
providing their name, email address, and preferences through an interface (e.g., a website or mobile 
app). 
2. Data preprocessing and API interaction → User input will be validated and formatted before being 
sent to the chatbot’s API for processing. The chatbot will interact with a fine-tuned off-the-shelf LLM 
hosted on the cloud. 
3. Retrieval-Augmented Generation (RAG) → 
For queries requiring domain-specific knowledge or up-to-date context, the system performs a 
retrieval step: it searches the company’s CRM, document database, or knowledge base for relevant 
information. The retrieved content is then combined with the user input and passed to the LLM to 
generate a grounded, personalized response. 
4. Pre-Fine-Tuned LLM processing → 
The chatbot uses a fine-tuned LLM trained on enterprise-specific data to enhance general language 
understanding and tone alignment. This LLM uses the enriched input (from user + RAG) to personalize 
outputs. 
5. Data storage → Preprocessed user input (e.g., preferences) will be stored locally or in the cloud to 
enable personalized recommendations and facilitate future interactions. 
Figure 20. Source: Designed by pch.vector/Freepik

## Page 81 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
81 
 
User 
Interface 
(UI) Layer
Chatbot 
Application 
Layer
Business 
Logic
Integration 
Layer
LLM Layer
CRM 
System
Extermal 
Services
Security 
Layer
6. Personalized response generation → The chatbot will use stored user data from the CRM system 
and the fine-tuned LLM capabilities to generate tailored recommendations and responses. 
7. Data sharing → The chatbot may share minimal, (anonymized) user data with external services 
(e.g., third-party APIs for additional functionality or promotional tools). 
8. Feedback collection → Users provide feedback on chatbot interactions (e.g., thumbs-up/down, 
comments) to improve the system’s performance. This is process by the system for analytics purposes. 
9. Deletion and user rights management → Users can request access to, deletion of, or updates to 
their personal data in compliance with GDPR or similar regulations. 
 
To facilitate the risk assessment process, it is also possible to create a data flow diagram290, providing a 
graphical representation of the processes, data movements, and interactions within the system. 
Possible Architecture 
Considering that we are at the design phase of the AI lifecycle, we anticipate that the architecture of 
our LLM-based system will include the following key layers:291 
 
 
 
 User Interface (UI) Layer: The interface where users interact with the chatbot through text or 
voice input. (e.g.; Webpage, mobile app) 
 Chatbot Application Layer: Manage the flow of conversation and determines chatbot responses 
based on user input and context. Directs queries to the Business Logic Layer. 
 Business Logic Layer: Orchestrates chatbot workflows, such as checking customer profiles or 
placing orders. Crucially, it decides whether to call the LLM directly or trigger a retrieval step (RAG) 
— for example, by querying the CRM or knowledge base when additional context is needed before 
generating a response. 
 Integration Layer: Contains the API Gateway to manage the transmission between layers. 
Connects the chatbot to the LLM, the CRM system and external services and facilitates secure 
communication and data exchange between systems. It also handles data transformation, ensures 
compatibility between the chatbot and the CRM, and implements authentication and 
authorization for secure access to CRM data. For the RAG setup, this layer may also route queries 
to a retrieval component or knowledge base before passing enriched inputs to the LLM. 
 LLM Layer: Performs natural language understanding and generation. Receives either raw user 
input or input enriched with retrieved content (from the RAG step). Returns contextually relevant 
responses to the Business Logic Layer. 
 CRM System: Stores customer data, such as contact information, purchase history, preferences, 
and support tickets. It also contains CRM APIs that provide endpoints to retrieve, update, or add 
customer data and event handlers that trigger actions based on events, such as creating a support 
ticket when a customer raises an issue through the chatbot. Supplies customer data to personalize 
chatbot responses and stores data generated during interactions. 
 External Services Layer: It integrates with analytics tools to track user interactions and generate 
insights into customer behavior. It also integrates with other services, such as payment gateways, 
email services, or marketing tools. 
 Security Layer: It encrypts data during transmission using protocols like HTTPS and SSL/TLS, 
restrict unauthorized access to the chatbot, the LLM and CRM using techniques like OAuth2, 
implements security and privacy controls, vulnerability scans, threat monitoring, etc. 
                                                            
290 Wikipedia, ‘Data-flow diagram’ (2025) https://en.wikipedia.org/wiki/Data-flow_diagram 
291 This architecture is provided as a simplified example and may vary significantly depending on the specific requirements, use case, and 
technical constraints of each deployment.

## Page 82 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
82 
 
Having an overview of the possible architecture at this stage provides a clearer understanding of the 
data flows and potential risks associated with deploying the chatbot. This architectural insight sets the 
groundwork for identifying privacy and security concerns early in the process.  
Risk Analysis – Stakeholder Collaboration 
The next step involves gathering a diverse group of stakeholders to collaboratively identify potential 
risks. Inviting the right stakeholders is not an exact science, but it is critical to include individuals who 
will have decision-making authority, direct involvement in its development, deployment and use, and 
could add value to the risk identification process. Key participants could include representatives from 
engineering, security, privacy, and UX design teams. If possible, it is highly beneficial to involve 
individuals with expertise in ethics and fundamental rights, as well as members from civil society 
groups, deployers and end-users’ representatives (customers in our use case). Collecting input from a 
broader audience through a client survey can also provide valuable insights into user expectations and 
concerns. 
Stakeholder Analysis 
Before starting with the risk identification process, the group should analyze the use case to 
determine which stakeholders target group will interact with the chatbot and identify those who 
should not have access. Designing barriers where necessary, such as an age verification mechanism, 
ensures the system aligns with the intended user base. In this specific use case, the entry point for the 
interface is restricted to logged-in and recognized customers, making additional barriers possibly 
unnecessary. However, a comprehensive evaluation of all potential risks remains crucial to the 
system's success. 
Stakeholder analysis292 is a process used to identify and understand the roles, interests, and influence 
of various stakeholders involved in or affected by a project. Beyond analyzing those directly engaged 
with the system, it is equally important to assess which stakeholders could be negatively impacted by 
the tool. This includes recognizing if vulnerable groups might be involved or if the tool's impact could 
extend to a large number of individuals. Where relevant, it may be valuable to engage affected 
communities in subsequent phases of risk identification to better capture context-specific concerns 
and impacts. Participatory engagement tools293 like the ethical matrix, mentioned in a previous 
section, can help evaluate the potential consequences for different stakeholder groups. 
In our use case, we have identified our customers as the only authorized users. Given the nature of our 
business, we do not anticipate children accessing our platform. However, we remain mindful of 
implementing appropriate security measures to ensure that access is restricted, and unauthorized use 
is prevented. 
Risk Identification – Selection of Risk Factors 
Considering our data flow diagram, system architecture, and deliberations with our selected 
stakeholders, we have identified the following risk factors and key concerns from Section 4 as 
applicable to our specific use case: 
 
                                                            
292 Rodgers, A.,’ What is a Stakeholder Impact Analysis?’, Simply Stakeholders (2024) https://simplystakeholders.com/stakeholder-impact-
analysis/ 
293 Park, T., Stakeholder Engagement for Responsible AI: Introducing PAI’s Guidelines for Participatory and Inclusive AI’, Partnerships on AI’ 
(2024) https://partnershiponai.org/stakeholder-engagement-for-responsible-ai-introducing-pais-guidelines-for-participatory-and-inclusive-
ai/

## Page 83 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
83 
 
Risk factor 
Use case applicability 
Large scale processing
A significant volume of data will be processed due to our extensive customer database 
and the large amount of information stored in our CRM system. 
Low data quality 
Customer query inputs may have low quality, and the CRM database has not been 
validated, which could lead to inaccuracies or inefficiencies in processing.
Insufficient security 
measures  
 
There is a potential risk of transferring personal data to countries without an adequate 
level of protection, especially if the LLM model is hosted or maintained in such regions. 
 
We have identified several risk factors that require attention, as they indicate a higher probability of 
undesirable outcomes. While our system does not fall under the classification of a high-risk system 
under the AI Act, there is, from the GDPR perspective, sufficient evidence to justify initiating294 the 
process for creating a Data Protection Impact Assessment (DPIA). This risk assessment we are 
performing now will serve as a valuable foundation for the DPIA process.  
It is important to emphasize when a DPIA is necessary and when a Fundamental Rights Impact 
Assessment (FRIA) is required. A DPIA, under Article 35 of the GDPR, is required whenever a data 
processing is likely to result in a high risk to the rights and freedoms of natural persons.295  
 
Common scenarios that require a DPIA include: 
 
The use of new technologies that could introduce privacy risks. 
 
The tracking of individuals' behavior or location (e.g., geolocation services or behavioral 
advertising). 
 
Large-scale monitoring of publicly accessible spaces (e.g., video surveillance). 
 
Processing sensitive data categories such as racial or ethnic origin, political opinions, religious 
beliefs, genetic data, biometric data, or health information. 
 
Automated decision-making that has legal or similarly significant effects on individuals. 
 
Processing children’s data or any data where a breach could lead to physical harm. 
 
Even when a DPIA is not explicitly required by law, conducting one can be prudent for best practices in 
privacy and security. It allows organizations to preemptively address potential risks, assess the impact 
of their solutions, and demonstrate accountability. In contrast, a FRIA, as outlined in Article 27296of the 
AI Act, can be mandatory for some deployers of high-risk AI systems (bodies governed by public law, 
private entities providing public services, organisations doing creditworthiness evaluations, pricing and 
life and health insurance risk assessments. A FRIA evaluates the potential impact of such systems on 
fundamental rights like privacy, fairness, and non-discrimination. Deployers of high-risk AI systems 
must document: 
 
How the system will be used, including its purpose, duration, and frequency. 
 
The categories of individuals or groups affected by the system. 
 
Specific risks of harm to fundamental rights. 
 
Measures for human oversight and governance. 
 
Steps to address and mitigate risks if they materialize. 
 
Where applicable, a FRIA can complement a DPIA, by focusing on broader societal impacts 
beyond data protection alone. 
                                                            
294 EDPB, ‘Data Protection Guide for Small Business’ (2025) https://www.edpb.europa.eu/sme-data-protection-guide/be-compliant_en 
295 WP 29 Guidelines on Data Protection Impact Assessment (DPIA) and determining whether processing is "likely to result in a high risk" for 
the purposes of Regulation 2016/679, WP248 rev.01, (2017) endorsed by the EDPB https://ec.europa.eu/newsroom/article29/items/611236  
296 Article 27(1) AI Act: “Prior to deploying a high-risk AI system referred to in Article 6(2), with the exception of high-risk AI systems intended 
to be used in the area listed in point 2 of Annex III, deployers that are bodies governed by public law, or are private entities providing public 
services, and deployers of high-risk AI systems referred to in points 5 (b) and (c) of Annex III, shall perform an assessment of the impact on 
fundamental rights that the use of such system may produce….”

## Page 84 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
84 
 
Risk Identification – What can go wrong? 
For the process of risk identification, we will follow an approach similar to the one used in threat 
modeling methodologies. Privacy threat modeling serves as a structured way to identify potential risks 
and vulnerabilities within a system, focusing on scenarios that could impact data subjects' rights and 
freedoms. While threat modeling is not mandatory and does not replace297 the DPIA or broader risk 
management processes, it is a versatile and effective tool that enhances these efforts by generating 
valuable insights, such as risk scenarios and potential impacts.  
Collaborating closely with our stakeholder group, and after having identified the risk factors that affect 
our use case, we will now review the data flow diagram again and facilitate the process of risk 
identification by using the two lists of risk from sections 3 and 4.  
Instead of relying on external risk libraries298 contained in threat modeling methodologies such as 
LINDDUN299, LIINE4DU300 or PLOT4AI301, for our use case we will use the tailored lists of risks outlined 
in this document. It is essential to remember that using a predefined library of risks is merely a 
starting point. Organizations should think beyond these lists, considering unique aspects of their 
systems and context and asking themselves, "What else can go wrong?". 
In threat modeling, usually four foundational questions302 guide the process: 
1. What are we working on? 
2. What can go wrong? 
3. What are we going to do about it? 
4. Did we do a good job? 
 
For this use case, we will integrate these questions into the risk management process as follows: 
What are we working on? 
We are implementing an LLM based chatbot. To understand its design and architecture, we are 
leveraging for the risk identification session with our group of stakeholders, the most recent version of 
a data flow diagram. We also need to consider that we are the design and development phase of the 
AI lifecycle which means that many tests and evaluations have not yet been conducted, and we lack 
user feedback and insights from the production environment. 
 
What can go wrong? 
After examining our data flow diagram, the context of use, the intended purpose of the application, 
the characteristics of our user group and design, as well as any results obtained from evaluations and 
tests, we have identified the following risks outlined in Section 4: 
1. Insufficient protection of personal data leading to a data breach. 
2. Misclassification of training data as anonymous. 
3. Possible adverse impact on data subjects that could negatively impact fundamental rights. 
4. Not granting data subject rights. 
5. Unlawful repurposing of personal data. 
6. Unlawful unlimited storage of personal data. 
7. Unlawful transfer of personal data. 
8. Breach of the data minimization principle. 
 
                                                            
297 AEPD, ‘Technical Note: An Introduction to LIINE4DU 1.0: A New Privacy & Data Protection Threat Modelling Framework’, 2024 
298 Slattery P., et al., ‘The AI Risk Repository: A Comprehensive Meta-Review, Database, and Taxonomy of Risks From Artificial Intelligence’ 
(2024) https://arxiv.org/abs/2408.12622 
299 LINDDUN, ‘Privacy Threat Modelling’ (2025) https://linddun.org/ 
300 AEPD, ‘Technical Note: An Introduction to LIINE4DU 1.0: A New Privacy & Data Protection Threat Modeling Framework’ (2024) 
https://www.aepd.es/guides/technical-note-introduction-to-liine4du-1-0.pdf 
301 PLOT4AI, ‘Practical Library of Threats 4 Artificial Intelligence’ (2025)  https://plot4.ai/ 
302 Shostack, A., ‘The Four Question Framework for Threat Modeling’ (2024) 
https://shostack.org/files/papers/The_Four_Question_Framework.pdf

## Page 85 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
85 
 
From the potential privacy risks outlined in Section 3 for systems based on an LLM ‘off-the-shelf-
model,’ we have reviewed all risks across the standard data flow phases and identified that most of 
these risks are covered under Risk 1 (Insufficient protection of personal data leading to a data breach) 
and Risk 3 (Possible adverse impact on data subjects that could negatively impact fundamental rights) 
from Section 4. 
Phases 
Possible Risks  
User Input 
Sensitive data disclosure, unauthorized access, lack of transparency, adversarial attacks 
Provider Interface & API 
Data interception, API misuse, interface vulnerabilities 
LLM Processing at 
Providers’ Infrastructure 
Model inference risks, unintended data logging, anonymization failures, unauthorized access 
to logs, data aggregation risks, third-party exposure, inadequate data retention policies 
Processed Output 
Inaccurate or sensitive responses, re-identification risks, output misuse 
Risk Estimation and Evaluation 
We will now analyze each identified risk by assessing its probability and severity to determine which 
risks require treatment. Whenever possible, we will also consider system test results and model 
evaluations, if available, to inform our assessment. In some cases, conducting additional evaluations 
may be necessary to obtain quantitative data that can improve our risk analysis. 
 
For example, in the case of Risk 2 (Misclassification of training data as anonymous), we can already 
perform tests to detect the presence of personal data in our datasets. These results would help us 
assess the probability of the risk occurring given the current dataset conditions.  
 
At this stage of the AI lifecycle (pre-deployment phase), the available evaluations are limited. 
However, when risk assessments take place post-development, additional evaluations can be 
conducted, providing further quantitative criteria to refine risk assessment and decision-making. 
Probability 
We are going to assess the probability of identified risks, categorizing them into one of the four levels 
in the probability matrix: Very High, High, Low, or Unlikely. This categorization should be done by 
directly assigning a level to each risk based on quantitative and/or qualitative criteria and through 
collaborative decision-making with stakeholders. Alternatively, we can also employ a list of predefined 
criteria to guide our assessment.  
For a more quantitative approach calculating probability, aggregation methods can be applied to 
calculate its level. In this use case, we will use the FRASP framework to structure and refine our 
probability assessment process. 
 
 
Calculating the Total Probability Score: 
We evaluate fictitiously each identified risk and assign it a score per criteria. We add the scores of all 
factors and divide the total by the number of factors to calculate the Aggregate Probability Score. In 
our case we will treat all factors and calculate the mean. 
Once the aggregate score is calculated, we will map it to one of the predefined probability levels 
based on the following ranges: 
1.0 - 1.5: Unlikely 
1.6 - 2.5: Low 
2.6 - 3.5: High 
3.6 - 4.0: Very High

## Page 86 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
86 
 
Our Total Probability Score (TPS) per risk is:  
 
 
Probability Criteria 
Aggregate Score 
TPS 
Risk 
1 
2 
3 
4 
5 
6 
7 
Calculation 
Result 
Result 
1
3
1
3
1
2
3
2
3+1+3+1+2+3+2 / 7
2,14
Low
2 
3 
1 
4 
1 
2 
3 
2 
3+1+4+1+2+3+2 / 7 
2,28 
Low 
3 
3 
1 
2 
1 
2 
3 
2 
3+1+2+1+2+3+2 / 7 
2 
Low 
4 
3 
1 
3 
1 
2 
3 
2 
3+1+3+1+2+3+2 / 7 
2,14 
Low 
5 
3 
1 
3 
1 
2 
3 
2 
3+1+3+1+2+3+2 / 7 
2,14 
Low 
6 
3 
1 
3 
1 
2 
3 
2 
3+1+3+1+2+3+2 / 7 
2,14 
Low 
7
3
1
3
1
2
3
2
3+1+3+1+2+3+2 / 7
2,14
Low
8 
3 
1 
3 
1 
2 
3 
2 
3+1+3+1+2+3+2 / 7 
2,14 
Low 
 
Severity 
Next, we will assess the potential privacy impact and severity of these risks on data subjects, 
individuals, and society. Based on this severity assessment, we will assign one of the four levels from 
the severity classification matrix: Very Significant, Significant, Limited, or Very Limited. 
The calculation of severity will follow the same steps as those used for determining probability. 
However, for severity, the highest level obtained among criteria 1 to 5, as well as 7 and 8, will set the 
total severity score.  
 
Once the aggregate score is calculated, we will map it to one of the predefined severity levels based 
on the following ranges: 
 
1.0 - 1.5: Very Limited / Moderate or Minor Harm (Level 1) 
1.6 - 2.5: Limited / Serious Harm (Level 2) 
2.6 - 3.5: Significant/ Critical Harm (Level 3) 
3.6 - 4.0: Very Significant / Catastrophic Harm (Level 4) 
 
In this case the final score is determined by the highest score in criteria 1, 5 and 7 giving as result Level 
3 severity for all the risks. 
 
 
 
Severity Criteria 
 
 
 
 
Aggregate Score 
TSS 
Risk 
1 
2 
3 
4 
5 
6 
7 
8 
9 
10 
11 
Calculation 
Result 
Result 
1 
3 
2 
2 
2 
3 
1 
2 
2 
3 
2 
3 
3+2+2+2+3+1+2+2+3+2+3 / 11 
2,27 
Significant/ 
Critical Harm 
2
3
2
2
2
1
1
3
2
2
2
3
3+2+2+2+1+1+3+2+2+2+3 / 11
2,09
Significant/ 
Critical Harm  
3 
3 
2 
2 
2 
2 
1 
2 
2 
2 
2 
2 
3+2+2+2+2+1+2+2+2+2+2 / 11 
2 
Significant/ 
Critical Harm  
4 
3 
2 
2 
2 
2 
1 
3 
2 
1 
2 
2 
3+2+2+2+2+1+3+2+1+2+2 / 11 
2 
Significant/ 
Critical Harm  
5 
3 
2 
2 
3 
3 
1 
3 
2 
1 
2 
2 
3+2+2+3+3+1+3+2+1+2+2 / 11 
2,18 
Significant/ 
Critical Harm  
6 
3 
2 
2 
2 
3 
1 
2 
1 
1 
2 
1 
3+2+2+2+3+1+2+1+1+2+1 / 11 
1,81 
Significant/ 
Critical Harm  
7
3
2
2
2
3
1
2
1
1
2
1
3+2+2+2+3+1+2+1+1+2+1 / 11
1,81
Significant/ 
Critical Harm  
8 
3 
2 
2 
2 
3 
1 
2 
1 
1 
2 
1 
3+2+2+2+3+1+2+1+1+2+1 / 11 
1,81 
Significant/ 
Critical Harm

## Page 87 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
87 
 
By applying the classification matrix to the obtained probability and severity scores, we can determine 
the corresponding risk classification level. In our case for all the risks the combination Low Probability 
+ Significant Severity offers a result of High Risk. 
 
Probability 
Very High 
Medium 
High 
Very high 
Very high 
High 
Low 
High 
Very high 
Very high 
Low 
Low 
Medium 
High 
Very high 
Unlikely 
Low 
Low 
Medium 
Very high 
 
 
Very limited 
Limited 
Significant 
Very Significant 
Severity
 
Although high level risks always require treatment, it is considered best practice to assess whether 
classified risks need treatment evaluating predefined acceptance criteria and acceptable metric 
thresholds established by the organization. These criteria can be adjusted per use case and tailored to 
pre-deployment and post-deployment phases to ensure a context-aware risk management approach. 
 
In our specific use case, the organization's risk acceptance criteria are as follows: 
 
 A risk that can result in a violation of data protection regulations is not acceptable. 
 A risk of unauthorized access, exposure, or retention of persona data beyond what is strictly 
necessary is not acceptable. 
 Re-identification risk must remain below 1%, verified through privacy-preserving evaluations 
and testing. 
 Membership inference and model inversion attack risks must remain below a 1% success rate 
as verified through internal testing and, for sensitive data, independent external audits. 
 Inaccurate datasets are only acceptable if the error rate does not exceed 5% and all available 
data validation and cleaning processes have been applied. 
 The chatbot must clearly inform users when their data is being used and provide access to 
data usage policies. Transparency risks are not acceptable. 
 No risk is acceptable if it prevents users from exercising their data rights, unless explicitly 
justified under legal exceptions. 
Risk Control - What are we going to do about it? 
In our use case, several high-level risks have been identified. After evaluating our risk acceptance 
criteria, conducting a feasibility analysis and reviewing the treatment options, we determined that 
transferring the risks to a third party is not feasible, avoiding the risks entirely is impractical, and 
outright acceptance of the risks is unacceptable. However, since there are mitigation measures 
available that can reduce the risks to an acceptable level, we have opted for the treatment strategy of 
risk mitigation to proceed responsibly with the implementation. 
 
Note that Section 3 and Section 4 already outlined comprehensive mitigation measures for the 
identified risks. It is also worth noting that many of the specific risks identified in this use case fall under 
the broader category of Risk 1, which relates to insufficient protection of personal data. 
 
Data Flow 
Phase 
Description 
Privacy Risks 
Mitigation’s recommendations 
User input 
Users interact with the 
chatbot by providing their 
name, email address, and 
 
Input could be 
intercepted if 
 
Secure data transmission 
using adequate encryption 
protocols.

## Page 88 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
88 
 
preferences through an 
interface (e.g., a website or 
mobile app). 
transmitted over an 
insecure connection. 
 
Users might provide 
unnecessary or excessive 
personal information.  
 
Children or vulnerable 
users might share 
personal data. 
 
Apply input constraints to 
limit collected data to what 
is essential.  
 
Use age verification or 
consent mechanisms to 
protect vulnerable users 
(children not our user 
group) 
 
Clearly inform users about 
how their data is processed 
and caution them against 
sharing sensitive or 
confidential information 
when using the chatbot.
Data 
preprocessing 
and API 
interaction 
User input is validated and 
formatted before being 
sent to the chatbot’s API 
for processing. The chatbot 
interacts with a fine-tuned 
off-the-shelf LLM hosted on 
the cloud and connects to 
the CRM system both to 
retrieve or update user 
information and to fetch 
relevant content that is 
passed to the LLM as 
context (RAG).  
 
Unsecured APIs could 
allow attackers to 
intercept or manipulate 
user data. 
 
Malicious inputs (e.g., 
injections) could exploit 
system vulnerabilities.  
 
Logs might inadvertently 
store sensitive user data. 
 
Retrieved content may 
contain sensitive or 
outdated information, 
which could be exposed 
in generated outputs. 
 
Poorly configured 
retrieval logic could 
result in irrelevant or 
misleading context being 
fed to the LLM, 
increasing hallucination 
risk. 
 
If retrieval accesses 
external or third-party 
knowledge bases, user 
queries may be logged or 
monitored without 
consent. 
 
Use robust API security 
measures, including access 
controls, authentication, 
and rate limiting. 
 
Sanitize user input to 
prevent injection attacks.  
 
Minimize API logging or 
ensure logs are 
anonymized and protected 
by access controls. 
 
Restrict retrieval sources to 
approved, privacy-screened 
datasets (e.g., filtered CRM 
data). 
 
Implement relevance filters 
or scoring mechanisms to 
ensure only appropriate 
content is passed to the 
LLM. 
 
Apply post-
processing/output filters to 
remove or redact sensitive 
information from 
responses. 
 
Use internal retrieval 
systems when possible; if 
third-party search APIs are 
used, anonymize or mask 
user queries.
Pre-Fine-
Tuned LLM 
processing 
The chatbot relies on a 
fine-tuned LLM and also 
uses retrieved content from 
CRM as input context to 
generate more accurate 
responses. 
 
Hallucinations: The 
model might generate 
inaccurate or misleading 
responses. 
 
Training data biases may 
persist in outputs, 
influencing 
recommendations. 
 
Retrieved content may 
be misinterpreted by the 
LLM, leading to distorted 
or irrelevant outputs. 
 
Sensitive data from 
retrieval sources could 
 
Evaluate chatbot responses 
regularly for accuracy and 
relevance. 
 
Train the model on high-
quality, diverse datasets to 
reduce biases.  
 
Include disclaimers in 
chatbot responses to clarify 
they are AI-generated and 
not definitive advice. 
 
Apply retrieval filters and 
output sanitization to 
reduce risk of leaking 
sensitive information.

## Page 89 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
89 
 
be included in responses 
if not properly filtered. 
 
Weight or flag retrieved 
content based on source 
reliability to help the model 
contextualize correctly.
Data storage 
Preprocessed user input 
(e.g., preferences) is stored 
locally or in the cloud to 
enable personalized 
recommendations and 
facilitate future 
interactions. 
 
Weak access controls 
could expose stored user 
data.  
Retaining data longer 
than necessary violates 
privacy regulations.  
 
Adversaries could infer 
whether specific user 
data was used in 
training.
 
Encrypt stored data and 
implement access controls. 
 
Adopt clear data retention 
policies to delete data 
when no longer needed.  
 
Apply differential privacy 
techniques to prevent 
membership inference 
attacks. 
Personalized 
response 
generation 
The chatbot uses stored 
user data from the CRM 
system and fine-tuned LLM 
capabilities to generate 
tailored recommendations 
and responses. 
 
Outputs might 
inadvertently pressure 
users or contain 
inaccurate information. 
 
Responses might infer 
unintended personal 
insights about users. 
 
Implement output 
validation mechanisms to 
detect and mitigate 
harmful or inaccurate 
responses.  
 
Regularly audit chatbot 
recommendations for 
fairness and transparency.  
 
Clearly communicate to 
users how 
recommendations are 
generated. 
Data sharing 
The chatbot may share 
minimal, anonymized user 
data with external services 
(e.g., third-party APIs for 
additional functionality or 
promotional tools). 
 
Data shared with third 
parties might be used for 
purposes outside the 
agreed scope.  
 
Insufficient protection in 
third-party systems could 
expose shared data. 
 
Establish robust data-
sharing agreements with 
third parties. 
 
Anonymize and minimize 
shared data to reduce risks 
of misuse or exposure.  
 
Regularly audit third-party 
data protection practices. 
Feedback 
collection 
Users provide feedback on 
chatbot interactions (e.g., 
thumbs-up/down, 
comments) to improve the 
system’s performance. 
 
Feedback might include 
unintended personal 
details.  
 
Feedback data might 
introduce biases during 
future model retraining. 
 
Anonymize feedback data 
before storing or using it 
for model improvement. 
 
Communicate feedback 
usage policies to users and 
obtain explicit consent for 
data usage in retraining. 
Deletion and 
user rights 
management 
Users can request access 
to, deletion of, or updates 
to their personal data in 
compliance with GDPR or 
similar regulations. 
 
Failure to honor user 
requests could result in 
regulatory penalties.  
 
Data may persist in logs, 
backups, or third-party 
systems even after a 
deletion request. 
 
Implement robust data 
rights management tools 
for access, correction, and 
deletion requests.  
 
Regularly audit data 
systems to ensure 
compliance with deletion 
requests. 
 
Clearly communicate to 
users how their data is 
handled and retained.

## Page 90 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
90 
 
Evaluate Residual Risk - Did we do a good job? 
After the mitigation measures have been identified and implemented, we will assess again the 
probability and severity of each risk to obtain a new risk classification level and in this way evaluate if 
there is any remaining or residual risk.  
In our case, the risk level has been reduced to Medium what means it is not yet acceptable. 
 
Why is the risk level reduced to Medium instead of Low after having implemented all the mitigations? 
The risk remains Medium despite reducing severity to Limited (level 2) because the risk matrix combines 
probability and severity to determine overall risk. 
With the four levels matrix that we use in this example, a Low Probability and Limited Severity result in 
a Medium Risk level because, while unlikely, the consequences of a risk, though mitigated, are still non-
negligible. That means the remaining risk after mitigation measures might still be above an acceptable 
threshold for your organization. 
 
What can we do to address Residual Risk in this case? Some options that organizations can apply are: 
 
 
Reduce Probability by strengthening preventive controls (e.g., access measures, anomaly detection) 
and enhancing event prevention mechanisms. 
 
Implement extra mitigations measures to reduce severity. 
 
Implement robust monitoring and establish a clear incident response plan to minimize impact if the 
risk materializes. 
 
Explore additional mitigations: for instance, use advanced technologies (e.g., differential privacy) or 
fail-safe mechanisms to further mitigate risks. 
 
Reevaluate whether the residual risk is within organizational risk tolerance and document 
justification for maintaining it. 
 
Discuss options to share or transfer the risk (e.g., insurance, vendor agreements). 
Review & Monitor 
The "Did we do a good job?" question in threat modeling goes beyond merely addressing residual risks—
it serves as an evaluation of the entire risk management process. This phase ensures that the identified 
risks, proposed mitigations, and resulting outcomes align with the system's objectives and regulatory 
requirements. It also provides an opportunity to validate internal and external processes, assess the 
real-world applicability of mitigations, and identify any gaps or areas for improvement. 
This process is also related to the Monitoring and Review phase, where the Risk Management Plan is 
reassessed to ensure that risk mitigation efforts remain effective. As part of this phase, it is essential to 
ensure that the risk register is properly documented and continuously updated. 
 
Since we are currently in the design and development phase, we should proactively plan for continuous 
monitoring of our chatbot. This includes defining metrics for ongoing risk assessment, establishing 
adequate data logging practices, and ensuring that an incident response plan is in place to address 
potential privacy issues that may arise post-deployment.

## Page 91 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
91 
 
Second Use Case: LLM System for Monitoring and Supporting Student 
Progress 
 
Scenario: A school wants to adopt a third party LLM system to monitor and evaluate students' 
academic performance and provide tailored recommendations for improvement. The tool is an LLM-
based system developed with and LLM ‘off-the shelf’ model. This tool would analyze a combination of 
data, including test scores, assignment completion rates, attendance records, and teacher feedback, 
to identify areas where students may need additional support or resources. For example, if a student 
struggles with math, the tool could recommend targeted practice exercises, suggest online tutoring 
sessions, or notify parents and teachers about specific challenges. The goal is to create a personalized 
learning plan that helps each student achieve their full potential. 
This system would deal with sensitive information about minors, including their academic records and 
behavioral patterns, which introduces significant privacy and ethical risks.  
Lifecycle phase we are now: Inception 
Risk Management Process 
Since we have already detailed the complete risk assessment process in the first use case, including 
identifying, classifying, and mitigating risks, this section and the subsequent third use case will focus 
specifically on identifying unique privacy and data protection risks and mitigations. 
 
This table shows how the risks identified in Section 3 and 4 (Privacy Risk Library) can be aligned with the 
risks specific for this use case. 
 
Privacy Risk Library 
Privacy Risks Identified and aligned with 
Library
Recommended Mitigations 
1. Insufficient protection of 
personal data what 
eventually can be the cause 
of a data breach 
 
Weak safeguards could lead to data 
breaches, unauthorized access, or 
exposure of sensitive student data.  
 
APIs facilitating communication 
between the tool, school systems, and 
third parties could be unsecured or 
improperly configured. 
 
Inadequate access controls may allow 
unauthorized school personnel or 
external parties to view sensitive 
student data. 
 
If the vendor does not comply with 
data protection regulations, it 
increases the risk of a data breach.
 
Implement strong encryption protocols for 
data in transit and at rest (e.g., SSL/TLS, AES-
256). 
 
Regularly conduct security audits and 
penetration testing. 
 
Establish incident response plans for timely 
detection and mitigation of breaches. 
 
Use API gateways with robust security 
configurations, including authentication, 
access control, and rate limiting. 
 
Implement authentication and ensure secure 
API endpoints. 
 
Conduct regular API security reviews and 
validation.
Figure 21. Source: Designed by pch.vector/Freepik

## Page 92 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
92 
 
 
The tool might interact with third-
party services or platforms (e.g., 
online tutoring systems, analytics 
services, or cloud-based storage) for 
functionality, exposing student data to 
external entities. 
 
Enforce strict role-based access control 
(RBAC) policies. 
 
Implement multi-factor authentication (MFA) 
for all users accessing sensitive data. 
 
Regularly review and update user access 
permissions. 
 
Conduct vendor due diligence, including Data 
Protection Impact Assessments (DPIAs) and 
security certifications. 
 
Include specific data protection clauses in 
contracts with vendors, ensuring 
accountability for compliance. 
 
Require vendors to provide evidence of 
GDPR-compliant practices. 
 
Establish robust data-sharing agreements 
with third-party platforms, ensuring 
compliance with GDPR requirements. 
 
Limit data shared with third parties to 
anonymized or pseudonymized datasets. 
 
Monitor third-party systems for adherence to 
agreed data protection measures. 
2. Misclassifying training 
data as anonymous by 
controllers when it contains 
identifiable information 
Adversaries might exploit the LLM to infer 
whether specific student data was used in 
training, indicating a misclassification of 
training data. 
 
Use differential privacy techniques to 
minimize the risk of data inference. 
 
Conduct structured testing against 
membership inference and attribute 
inference attacks. 
 
Validate that the LLM provider has 
implemented safeguards to prevent such 
attacks.
3. Unlawful processing of 
personal data in training 
sets 
 
If personal data (e.g., academic 
records) is unlawfully processed in 
training datasets by the LLM provider 
 
Behavioral and academic data require 
explicit consent or another valid legal 
basis to be processed lawfully. 
 
Verify that the LLM provider’s training 
datasets exclude sensitive personal data 
without proper safeguards. 
 
Require documentation from vendors proving 
that training data was lawfully collected and 
processed. 
 
Use models trained on synthetic or 
anonymized data when possible. 
4. Unlawful processing of 
special categories of 
personal data and data 
relating to criminal 
convictions and offences in 
training data. 
If health-related or behavioral data about 
children, such as indications of mental 
health conditions, is processed—such as 
when identifying special assistance needs 
for conditions like dyslexia, ADHD, or 
similar. 
 
Ensure explicit consent is obtained from 
parents or guardians before processing 
children’s data. 
 
Conduct a DPIA and identify lawful grounds 
for processing. 
 
Provide clear, accessible information to 
parents about how data is processed. 
 
Implement stricter safeguards for sensitive 
data, including encryption and access 
controls. 
 
Limit processing to data strictly necessary for 
the intended purpose. 
 
Provide parents or guardians with 
transparency about how health-related data 
is used.
5. Possible adverse impact 
on data subjects that could 
negatively impact 
fundamental rights 
Fairness and Discrimination: 
 
Recommendations based on biased 
training data could disproportionately 
impact certain student groups. 
 
Continuous monitoring of behavioral 
patterns could lead to profiling 
students in ways that might be 
discriminatory or stigmatizing. 
Accuracy: 
 
The tool might generate inaccurate 
recommendations or reports due to 
Fairness and Discrimination 
 
Regularly audit training data to identify and 
reduce biases. 
 
Involve diverse stakeholders in testing the 
system for potential biases. 
Accuracy 
 
Establish processes for regular model 
evaluation and fine-tuning using high-quality, 
diverse datasets. 
 
Provide disclaimers with AI-generated 
recommendations, emphasizing the 
importance of human oversight.

## Page 93 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
93 
 
biases in training data or processing 
errors. 
Transparency: 
 
Teachers, parents, or students may 
not fully understand how decisions or 
recommendations are made by the AI 
tool. 
 
Enable error reporting mechanisms to 
continuously improve model accuracy. 
Transparency 
 
Provide detailed documentation303 about the 
AI tool’s decision-making processes to 
parents, teachers, and students. 
 
Implement transparency mechanisms, such as 
explainable AI (XAI) methods, to make 
decisions more interpretable. 
 
Offer training sessions for stakeholders to 
understand the tool’s capabilities and 
limitations. 
6. Not providing human 
intervention for a 
processing that can have a 
legal or important effect on 
the data subject. 
Lack of human oversight in automated 
recommendations or interventions could 
have significant adverse academic impacts 
on students.  
 
Implement mechanisms for obtaining 
verifiable parental or guardian consent. 
 
Provide parents with easy-to-understand 
information about the tool’s data collection 
and usage. 
 
Require human review of critical 
recommendations or interventions before 
implementation. 
 
Train teachers and administrators to identify 
when human intervention is needed. 
 
Define processes for escalating issues 
requiring human judgment. 
7. Not granting data 
subjects their rights 
Failure to obtain proper parental or 
guardian consent violates GDPR's 
requirements for minors. 
Students and parents may not fully 
understand how their data is processed, 
limiting their ability to exercise their rights. 
 
Create a user-friendly interface explaining 
how data is collected, processed, and stored. 
 
Offer accessible resources to help students 
and parents exercise their GDPR rights, 
including erasure, rectification, and access. 
8. Unlawful repurpose of 
personal data 
It the academic and behavioral data from 
children is used without a compatible 
purpose to the original one. 
 
Ensure data usage aligns with the original 
purpose of collection and assess any 
repurposing against GDPR principles. 
 
Document purpose compatibility assessments 
for accountability. 
9. Unlawful unlimited 
storage of personal data 
Data might be retained longer than 
necessary for its intended purpose, 
particularly behavioral or health-related 
data. 
 
Define clear data retention policies and 
automatically delete data once is no longer 
needed. 
 
Regularly audit stored data for compliance 
with retention limits. 
10. Unlawful transfer of 
personal data 
If the tool relies on cloud services or 
external platforms hosted in jurisdictions 
without adequate data protection 
standards. 
 
Verify that cloud service providers comply 
with GDPR’s data transfer rules, including 
adequacy decisions or Standard Contractual 
Clauses (SCCs). 
 
Perform Data Transfer Impact Assessments 
(DTIAs) when required. 
11. Breach of the data 
minimization principle 
Excessive data collection or processing 
beyond what is necessary infringe the data 
minimization principle. 
 
Apply strict data collection filters to gather 
only the data necessary for the tool’s 
purpose. 
 
Anonymize or pseudonymize data where 
possible to minimize risk. 
 
It is important to note that the list of risks and mitigations provided is based on generic information 
and assumptions. In a real-world scenario, a detailed risk assessment tailored to the specific 
implementation, context, and operational environment of the LLM based tool would be necessary. 
This includes collaboration with stakeholders, such as the LLM system provider, school administrators, 
teachers, parents, and students, to identify unique risks and address them effectively. 
                                                            
303 Models cards and system cards are example of information that can be provided to deployers:  
Green, N et al., System Cards, a new resource for understanding how AI systems work (2022) https://ai.meta.com/blog/system-cards-a-new-
resource-for-understanding-how-ai-systems-work/; Hugging Face, ‘Model Cards’ (2024) https://huggingface.co/docs/hub/en/model-cards

## Page 94 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
94 
 
Third Use Case: AI Assistant for Travel and Schedule Management 
 
 
 
Scenario: A personal assistant AI agent is designed to help users manage their travel plans and daily 
agendas. The agent can book flights, reserve hotels, schedule meetings, and send reminders based on 
user-provided inputs and preferences. For instance, a user might ask the agent to "book a round trip 
to Madrid next week and find a hotel near the Prado Museum." To fulfill this request, the agent 
accesses the user’s calendar, retrieves personal preferences (e.g., preferred airlines or hotel chains), 
and interacts with third-party booking platforms. This system is developed with various ‘off-the shelf’ 
LLMs and SLMs. 
 
Lifecycle phase we are now: Operations and Monitoring 
Risk Management Process 
In this use case we have identified the following privacy risks and recommended mitigations that we 
have aligned with our 11 foundational privacy risks. 
Privacy Risk Library 
Privacy Risks Identified and aligned with 
Library 
Recommended Mitigations 
1. Insufficient protection of 
personal data what eventually 
can be the cause of a data 
breach 
 
Weak safeguards could expose 
sensitive personal data, such as 
travel itineraries, calendar entries, 
and user preferences to 
unauthorized access or breaches. 
 
Unauthorized access due to poor 
access control mechanisms. 
 
Inference attacks where adversaries 
exploit vulnerabilities to infer 
personal data not explicitly 
provided. 
 
Encrypt user data during transmission and at 
rest. 
 
Implement secure APIs with rate limiting, 
authentication, and monitoring to control 
access. 
 
Use anonymization and pseudonymization 
to safeguard sensitive data. 
 
Regularly test for vulnerabilities like 
membership inference, model inversion, or 
poisoning attacks. 
 
Use robust inter-agent encryption304 to 
protect data exchange in multi-agent 
systems. 
2. Misclassifying training data 
as anonymous by controllers 
when it contains identifiable 
information 
Not applicable in this use case as the 
focus is on operational data rather than 
training data. (This use case is based on 
the Lifecycle Phase: Operations and 
Monitoring) 
 
(Not directly applicable in this case, as the 
system uses pre-trained models, but 
applicable to providers.) 
 
Ensure robust testing and validation to 
confirm training data anonymity claims. 
                                                            
304 Chen, G et al., ‘Encryption–decryption-based consensus control for multi-agent systems: Handling actuator faults.’, Automatica, Volume 
134, 109908, ISSN 0005-1098 (2021) https://doi.org/10.1016/j.automatica.2021.109908 
Figure 22. Source: Designed by pch.vector/Freepik

## Page 95 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
95 
 
 
Use threat models to evaluate risks of re-
identification techniques (e.g., attribute 
inference). 
 
Providers must document data 
anonymization methods and compliance 
with Article 5(2) GDPR. 
3. Unlawful processing of 
personal data in training sets 
Not applicable in this use case, as the 
system is already in operation and relies 
on pre-trained LLMs and SLMs. 
 
(Not directly applicable, as no training 
occurs in the operational phase.) 
4. Unlawful processing of 
special categories of personal 
data and data relating to 
criminal convictions and 
offences in training data. 
Behavioral and personal preferences 
data (e.g., specific health conditions 
inferred from travel patterns) may fall 
into special categories, requiring explicit 
consent or valid legal basis. 
Interactions with calendars or other 
sensitive tools may inadvertently process 
health-related or sensitive data. 
 
Implement explicit consent mechanisms for 
processing sensitive data like health-related 
information inferred from user interactions 
(e.g., calendar or travel preferences). 
 
Validate that sensitive data collected (if any) 
is necessary for the intended purpose. 
 
Use privacy-preserving techniques for 
sensitive data handling. 
5. Possible adverse impact on 
data subjects that could 
negatively impact fundamental 
rights 
 
Manipulation or overreliance on 
suggestions, where the agent 
prioritizes third-party interests over 
user preferences. 
 
Profiling and unfair treatment, such 
as price discrimination305 or biased 
recommendations. 
 
The agent might rely on outdated or 
inaccurate information from 
external sources, leading to errors in 
bookings or scheduling, which could 
inconvenience users. 
 
Users may not fully understand how 
the system operates, including how 
decisions are made or how their 
data is processed and shared. 
 
Monitor agent outputs for manipulative or 
biased behavior (e.g., unfair pricing or 
recommendations). 
 
Evaluate recommendations for fairness and 
ensure they do not disproportionately 
impact vulnerable groups. 
 
Implement behavioral consistency checks to 
identify and address erratic or unfair 
decision-making. 
6. Not providing human 
intervention for a processing 
that can have a legal or 
important effect on the data 
subject. 
Lack of human oversight in automated 
decisions, such as booking flights or 
scheduling, could lead to significant user 
inconvenience or adverse impacts. 
 
Require user confirmation for critical 
decisions, such as booking or payment. 
 
Implement fallback mechanisms where 
human oversight is necessary for high-stakes 
scenarios. 
 
Train users on how to interpret AI outputs 
and intervene if necessary. 
7. Not granting data subjects 
their rights 
Users may struggle to exercise GDPR 
rights (e.g., access, rectification, deletion) 
due to complex vendor dependencies or 
inadequate user interfaces. 
 
Provide clear interfaces for users to access, 
rectify, or delete their data. 
 
Maintain detailed, accessible logs of actions 
for audit purposes and compliance with 
Article 15 GDPR. 
 
Develop robust processes for handling user 
requests promptly, even when involving 
third-party integrations. 
8. Unlawful repurpose of 
personal data 
Data repurposing risks may arise if travel, 
calendar, or preference data is used for 
purposes other than intended, such as 
targeted advertising. 
 
Restrict data use to the specific purposes 
outlined in the terms of service. 
 
Ensure vendor agreements explicitly 
prohibit the repurposing of collected data. 
 
Implement consent management systems to 
track user preferences and restrict 
secondary use. 
9. Unlawful unlimited storage 
of personal data 
If data retention expands beyond 
necessity, particularly for travel 
itineraries, calendars, or personal 
preferences. 
 
Define clear retention periods for different 
data types (e.g., calendar data, travel 
history). 
 
Automate data deletion processes once the 
data is no longer necessary for the purpose. 
 
Regularly audit storage systems to ensure 
compliance with retention policies. 
                                                            
305 Zainea, A.A, ‘Automated Decision-Making in Online Platforms: Protection Against Discrimination and Manipulation of Behaviour’ (2024)

## Page 96 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
96 
 
10. Unlawful transfer of 
personal data 
Cross-border data sharing risks due to 
reliance on third-party platforms or 
services in jurisdictions without adequate 
data protection standards. 
 
Verify the location of third-party services 
and ensure compliance with GDPR cross-
border transfer rules. 
 
Perform Transfer Impact Assessments (TIAs) 
for all external vendors. 
 
Use standard contractual clauses and other 
safeguards for data-sharing agreements 
with third-party providers. 
11. Breach of the data 
minimization principle 
Excessive data collection: The system 
may collect or process more data than 
necessary for fulfilling user requests (e.g., 
unnecessary calendar details or 
preferences). 
 
Limit data collection to what is strictly 
necessary for fulfilling user requests (e.g., 
exclude unnecessary calendar details). 
 
Implement input validation and filters to 
prevent over-collection of data. 
 
Use anonymization or pseudonymization to 
minimize the risk of misuse or exposure of 
collected data. 
 
From identifying data flows to classifying risks and implementing mitigations, risk management is a 
continuous iterative journey. It requires consistent monitoring, stakeholder collaboration, and 
adjustments based on real-world observations and emerging technologies.  
Risk management should remain adaptable, incorporating feedback and evolving alongside regulatory 
and technological advancements. 
As we conclude this report, it is important to reiterate that while the risk management framework 
presented in this document provides guidance, every organization must customize its approach to 
address the specific nuances of their LLM based use cases.  
Privacy and data protection are not static goals but ongoing commitments.

## Page 97 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
97 
 
10. Reference to Tools, Methodologies, Benchmarks and 
Guidance  
 
Evaluation Metrics for LLMs 
Once an LLM is fully or partially trained, it is evaluated to assess its performance and to verify that it 
fulfills expectations in terms of accuracy, robustness and safety. This usually begins with an intrinsic306 
evaluation, which focuses on assessing the model in a controlled environment, on the tasks that it is 
designed for. This is a good way to test and improve things before deployment, when many other 
factors and confounding variables can interfere in obtaining an accurate representation of the model's 
capabilities. Extrinsic evaluation follows; by assessing the model in its ‘real-world’ implementation, it 
shows how well it generalizes to more complex data and how relevant it truly is. It is a more holistic 
way of assessing the model and the only way of observing its real impact, in the context of its 
deployment. For both types of evaluation, the choice of metrics and benchmarks must depend on the 
task the model is designed for and its intended use case. 
 
Ethical and Safety Metrics 
 Bias Evaluation 
Bias evaluation involves testing whether an LLM generates outputs that disproportionately favor, or 
disadvantage specific groups of people based on demographic factors (such as gender, race, religion, 
etc.). This often reflects bias patterns present in the training data, as well as the LLM's ability to 
overlook or neutralize them in its learned patterns. 
 
Example: Word Embedding Association Test (WEAT): This test measures how strongly certain 
words are associated with particular groups of people, aiming to detect stereotypes in the 
model’s word embeddings. For instance, comparing the proximity of words that indicate 
gender (such as names or pronouns) with various career-related words can point to gender 
bias in the word embeddings, such as 'man’ being represented as closer to 'doctor', and 
'woman’ being embedded closer to 'nurse'. This can predict bias in the model's output as well. 
 Toxicity Detection 
Toxicity evaluation assesses how often LLMs generate harmful, offensive, or inappropriate content. 
This includes hate speech, insults, or harassment. What is considered ‘inappropriate’ content can be 
context-dependent; for instance, AI systems that interact with children might have a lower threshold 
for inappropriate content than adult-only systems.  
 
Example: Toxicity Score: This metric aims to predict the probability of a piece of text being 
considered 'toxic'. Usually expressed as a percentage, the closer this score is to 0, the less 
likely it is for the text to be toxic. This metric is used in toxicity detection tools such as 
Perspective API, aiming to detect and reduce toxicity and harmful content in textual data.   
 Fairness Metrics 
Fairness evaluation focuses on evaluating the extent to which LLMs treat all user groups equitably 
without exhibiting or perpetuating systematic biases. This is of course tricky because fairness is an 
inherently complex term whose definition is debated and open to interpretation. Therefore, the 
                                                            
306 Verma, A., Plain English AI,’NLP evaluation: Intrinsic vs. extrinsic assessment’ Medium (2023)  https://ai.plainenglish.io/nlp-evaluation-
intrinsic-vs-extrinsic-assessment-ff1401505631

## Page 98 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
98 
 
chosen metrics are usually geared towards optimizing the definitions/dimensions of fairness that are 
most appropriate for each given case. 
 
Example: Demographic Parity: Initially a metric used in classification, demographic parity can 
be adapted to a text output. It measures whether the model generates text that represents all 
demographic groups equally in terms of frequency, sentiment, and associations. It can answer 
questions such as ‘are individuals of different ethnicities represented equally positively in the 
generated text?’ or ‘are women as frequently associated with high athletic performance as 
men?'. 
 
Benchmarks 
Benchmarks are standardized datasets, tasks, and evaluation protocols used to measure and compare 
the performance of various AI models, including LLMs. They provide a consistent framework to assess 
a model's capabilities, ensuring that performance can be compared across different models, tasks, and 
implementations. 
 
Here are some common benchmarks for LLMs: 
 
 General Language Understanding Evaluation (GLUE): A collection of tasks designed to evaluate 
natural language understanding, including sentiment analysis and sentence similarity. This 
benchmark is model-agnostic, meaning that it can be used to assess any system that takes a text 
input and generates a text output. Given the considerable recent progress of language models, the 
SuperGLUE benchmark has been introduced as a more challenging and nuanced version of GLUE. 
It includes more advanced language understanding tasks and a public leaderboard for state of the 
art models. https://gluebenchmark.com/ 
 Massive Multitask Language Understanding (MMLU): This benchmark evaluates the performance 
of language models across a wide range of subjects to assess their general knowledge and 
reasoning abilities. Models are tested on their ability to answer questions accurately. A higher 
score indicates better performance. https://github.com/hendrycks/test 
 ChatbotArena: (lmarena.ai) is an open source platform for evaluating AI through human 
preference, developed by researchers at UC Berkeley SkyLab and LMSYS. With over 1,000,000 user 
votes, the platform ranks best LLM and AI chatbots using the Bradley-Terry model to generate live 
leaderboards. https://huggingface.co/spaces/lmarena-ai/chatbot-arena-leaderboard 
 AlpacaEval: An LLM-based automatic evaluation based on the AlpacaFarm evaluation set, which 
tests the ability of models to follow general user instructions. https://tatsu-
lab.github.io/alpaca_eval/ 
 HellaSwag: A challenge dataset for evaluating commonsense NLI that is specially hard for state of 
the art models, though its questions are trivial for humans (>95% accuracy). 
https://rowanzellers.com/hellaswag/ 
 Big-Bench (Beyond the Imitation Game Benchmark): A set of tasks designed to evaluate the 
capabilities and limitations of LLMs on diverse and challenging tasks. These tasks are designed to 
test abilities beyond what is evaluated by standard benchmarks, assessing abstract reasoning, 
problem-solving, or the ability to handle more unconventional or complex prompts. The higher 
the BIG-bench score, the better the model performs in complex tasks. 
https://github.com/google/BIG-bench

## Page 99 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
99 
 
 AIR-BENCH 2024: A Safety Benchmark Based on Risk Categories from Regulations and Policies 
(https://arxiv.org/pdf/2407.17436v2) & 
https://huggingface.co/datasets/stanford-crfm/air-bench-2024 
 MLCommons AILuminate: benchmark for general purpose AI chat model 
(https://ailuminate.mlcommons.org/benchmarks/) & 
https://drive.google.com/file/d/1jVYoSGJHtDo1zQLTzU7QXDkRMZIberdo/view 
 ToolSandbox: A Stateful, Conversational, Interactive Evaluation Benchmark for LLM Tool Use 
Capabilities. https://machinelearning.apple.com/research/toolsandbox-stateful-conversational-
llm-benchmark 
 CYBERSECEVAL 3: Security benchmarks for LLMs. 
https://ai.meta.com/research/publications/cyberseceval-3-advancing-the-evaluation-of-
cybersecurity-risks-and-capabilities-in-large-language-models/ 
 LLM Guard (by Protect AI): It is a comprehensive tool designed to fortify the security of Large 
Language Models (LLMs). https://llm-guard.com/ 
 
Safeguards/Guardrails in LLMs 
Safeguards (or guardrails) in LLMs are mechanisms implemented to ensure that the models operate in 
a safe, ethical, and reliable manner. They can be applied to various stages of the LLM pipeline (pre-
processing, training, output…), and be focused on addressing different risks. For instance, some 
safeguards aim to avoid the generation of unethical, harmful or inappropriate content (so the 
behavior of the model), while others focus on preserving the privacy of the owners of the data (or 
other stakeholders).   
 
Here are some examples of behavioral guardrails that aim to moderate the LLM's output and mitigate 
harm that could be caused by the output without intervention:  
 
 
Content filters: moderate outputs by blocking or flagging harmful or toxic content 
 
Prompt refusals: prevent responses to dangerous or unethical prompts (like a request for 
instructions to a successful robbery) 
 
Bias mitigation: reduce stereotypical or unfair outputs during inference 
 
Human-in-the-Loop approaches: human oversight for high-risk applications, in order to not 
leave important decision-making fully in the 'hands’ of an automated system, which cannot 
truly comprehend what is at stake. 
 
Post-processing detoxification: filter or rewrite outputs to remove harmful content 
 
Adversarial testing (red teaming): evaluate and stress-test the model's ability to successfully 
deal with harmful prompts 
 
Other Tools and Guidance 
Open Source Tools 
 Open source connector for agentic AI: Anthropic Model Context Protocol (MCP): The Model 
Context Protocol is an open standard that enables developers to build secure, two-way 
connections between their data sources and AI-powered tools. 
https://www.anthropic.com/news/model-context-protocol 
 Tool for evaluation the performance of LLM APIs: https://github.com/ray-project/llmperf

## Page 100 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
100 
 
 OWASP AI Exchange: Comprehensive guidance on how to protect AI and data-centric systems 
against security threats. https://owaspai.org/ 
 OWASP Top 10 for Large Language Model Applications: Potential security risks when deploying 
and managing Large Language Models (LLMs). https://owasp.org/www-project-top-10-for-large-
language-model-applications/ 
 Five things privacy experts know about AI: Blog from Ted (Damien Desfontaines) about privacy 
and research. https://desfontain.es/blog/privacy-in-ai.html 
 
Privacy Preserving LLMS Techniques and Tools: 
 Clio: A system for privacy-preserving insights into real-world AI use: 
https://www.anthropic.com/research/clio?mkt_tok=MTM4LUVaTS0wNDIAAAGXdMNyd9wb7R_U
wjEGnaZw3fon7gu2FlLKUFOBA6PV2zTsuHYfcEeh1AJrOtEw8iVffJa-
plco04sz7_vou0k2RQ6hHf6oZbd-c3SQb8ERj8aw 
 New approach to help assess the risk of re-identification in data release: Rocher, L., Hendrickx, 
J.M. & Montjoye, YA.d. A scaling law to model the effectiveness of identification techniques. Nat 
Commun 16, 347 (2025). https://doi.org/10.1038/s41467-024-55296-6 
 RAG technique with differential privacy guarantees: https://github.com/sarus-tech/dp-rag 
 PrivacyLens - A Data Construction and Multi-level Evaluation Framework. 
https://github.com/SALT-NLP/PrivacyLens 
 SynthPAI: A Synthetic Dataset for Personal Attribute Inference. 
https://paperswithcode.com/dataset/synthpai 
 PrivacyRestore: Privacy-Preserving Inference in Large Language Models via Privacy Removal and 
Restoration. https://arxiv.org/abs/2406.01394 
 LLM-PBE: Assessing Data Privacy in Large Language Models. 
https://www.vldb.org/pvldb/vol17/p3201-li.pdf 
Tools to Help Flag or Anonymize Sensitive Information 
 Google Cloud Data Loss Prevention (DLP):  https://cloud.google.com/security/products/dlp 
 Microsoft Presidio (Data Protection and De-identification SDK): 
https://github.com/microsoft/presidio 
 https://medium.com/@parasmadan.in/understanding-the-importance-of-microsoft-presidio-in-
large-language-models-llms-12728b0f9c1c 
 OpenAI Moderation API (Identify potentially harmful content in text and images): 
https://platform.openai.com/docs/guides/moderation 
 Hugging Face NER models for Name Entity Recognition:  
o dslim/bert-base-NER: https://huggingface.co/dslim/bert-base-NER 
o dslim/distilbert-NER: https://huggingface.co/dslim/distilbert-NER 
 SpaCy: https://spacy.io/universe/project/video-spacys-ner-model-alt 
 NIST Collaborative Research Cycle on data deidentification techniques: 
https://pages.nist.gov/privacy_collaborative_research_cycle/

## Page 101 (Section: AI Privacy Risks and Mitigations in LLMs3)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
101 
 
Methodologies and Tools for the Identification of Data Protection and Privacy 
Risks 
 Practical Library of Threats (PLOT4ai) is a threat modeling methodology for the identification of risks 
in AI systems. It also contains a library with more than 80 risks specific to AI systems: 
https://plot4.ai/ 
 MITRE ATLAS™ (Adversarial Threat Landscape for Artificial-Intelligence Systems), is a knowledge 
base of adversary tactics, techniques, and case studies for machine learning (ML) systems: 
https://atlas.mitre.org/ 
 Assessment List for Trustworthy Artificial Intelligence (ALTAI) is a checklist that guides developers 
and deployers of AI systems in implementing trustworthy AI principles: https://digital-
strategy.ec.europa.eu/en/library/assessment-list-trustworthy-artificial-intelligence-altai-self-
assessment 
 
Guidance 
 OECD AI Language Models: 
https://www.oecd.org/content/dam/oecd/en/publications/reports/2023/04/ai-language-
models_46d9d9b4/13d38f92-en.pdf 
 NIST GenAI Security: https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-218A.pdf 
 NIST Artificial Intelligence Risk Management Framework - NIST AI 600-1: 
https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.600-1.pdf 
 OECD Advancing accountability in AI Governing and managing risks throughout the lifecycle for 
trustworthy AI: 
https://www.oecd.org/content/dam/oecd/en/publications/reports/2023/02/advancing-
accountability-in-ai_753bf8c8/2448f04b-en.pdf 
 FRIA methodology for AI design and development: 
https://apdcat.gencat.cat/es/documentacio/intelligencia_artificial/index.html 
 AI Cyber Security Code of Practice (gov.uk): https://www.gov.uk/government/publications/ai-
cyber-security-code-of-practice 
 
Standards 
The European Standardisation Body CEN/CENELEC is currently developing different AI harmonized 
standards following the AI Act Standardization Request307 from the European Commission. 
High-risk AI systems or general-purpose AI models that comply with these forthcoming harmonized 
standards are presumed to meet the specific requirements outlined in the AI Act308. However, this 
presumption does not extend to international standards such as ISO/IEC 42001309 and ISO/IEC 
23894.310Nevertheless, these standards provide a robust foundation and offer valuable best practices. 
                                                            
307 European Commission, ‘Implementing decision C(2023)3215 final of 22.5.2023 on a standardisation request to the European Committee 
for Standardisation and the European Committee for Electrotechnical Standardisation in support of Union policy on artificial intelligence’ 
(2023), https://ec.europa.eu/transparency/documents-register/detail?ref=C(2023)3215&lang=en 
308 Article 40 AI Act 
309 Information technology — Artificial intelligence — Management system 
310 Information technology — Artificial intelligence — Guidance on risk management

## Page 102 (Section: AI Privacy Risks and Mitigations in LLMs_FINAL2.pdf)

AI Privacy Risks & Mitigations – Large Language Models (LLMs) 
100


---

# MHRA AI Airlock phase 2 programme report

- **Issuer:** MHRA
- **Type:** Report
- **Language:** en
- **Source:** https://assets.publishing.service.gov.uk/media/6a676af523e57bd0a0ea6852/AI_Airlock_Phase_2_Programme_Report_v2.pdf
- **Licence:** OGL-UK-3.0

## Page 1

AI Airlock Sandbox Phase 2             
Programme Report                                  
Published by the Medicines and Healthcare products Regulatory Agency (MHRA) 
Published June 2026 
Updated July 2026

## Page 2

Contents  
Contents .............................................................................................................................. 2 
Executive Summary ............................................................................................................. 4 
Key insights from phase 2 ...................................................................................................... 4 
Phase 2 programme recommendations .................................................................................. 5 
Programme impact and next steps ......................................................................................... 6 
1. Introduction and Context ................................................................................................. 7 
AI Airlock regulatory sandbox in context ................................................................................. 7 
Purpose of this report ............................................................................................................. 9 
2. Regulatory challenges ................................................................................................... 10 
Scope of intended purpose and validation ............................................................................ 12 
Performance evaluation for AI-powered in vitro diagnostic (IVD) devices ............................ 13 
Predetermined change control plans and post-market surveillance ..................................... 13 
3. Key insights ................................................................................................................... 16 
Cross-cutting Insights ........................................................................................................... 16 
Scope expansion and validation ........................................................................................... 18 
AI-powered IVDs .................................................................................................................. 21 
Predetermined change control plans and Post-market surveillance ..................................... 26 
4. Recommendations ......................................................................................................... 30 
Cross-Cutting Recommendations ......................................................................................... 30 
Scope, Qualification and Validation ...................................................................................... 31 
AI-Powered IVDs .................................................................................................................. 33 
PCCPs and PMS .................................................................................................................. 34 
5. Evaluation Approach and Key insights .......................................................................... 35 
Evaluation Scope and Objectives ......................................................................................... 35 
Evaluation Methods and Evidence Base .............................................................................. 36 
Lessons Learned and Recommendations ............................................................................ 36 
6. Conclusion and Next Steps ........................................................................................... 40 
Phase 3 ................................................................................................................................ 40 
Appendices ........................................................................................................................ 42

## Page 3

Appendix 1: Sandbox Methodology ...................................................................................... 42 
Appendix 2: Programme Design and Governance ............................................................... 46

## Page 4

Page 4 of 48 
 
Executive Summary  
Artificial intelligence is transforming healthcare at pace, creating significant opportunities for 
patients, clinicians and the National Health Service (NHS). It is also raising complex 
regulatory questions that existing frameworks, designed for traditional medical technologies, 
were not built to answer. The MHRA AI Airlock regulatory sandbox was established to create 
a safe, structured environment for MHRA to work directly with AI medical device developers 
to understand how current regulation performs in practice, and where there is opportunity to 
change. 
This report presents the findings, insights and recommendations from Phase 2 of the AI 
Airlock, which ran from April 2025 to March 2026. Phase 2 built directly on the pilot programme 
(April 2024 to March 2025), deepening the programme's investigation through a structured 
cohort of seven candidates, three regulatory challenge areas and a programme of expert 
simulation workshops. Supported by the Department of Health and Social Care (DHSC) and 
the Regulatory Innovation Office (RIO), Phase 2 received 51 applications from industry and 
selected candidates representing a broad range of AI technologies, clinical areas and 
development stages. 
Phase 2 was structured around three regulatory challenge areas that the pilot identified as 
critical and unresolved:  
• Scope of intended purpose and validation: how to define, maintain and enforce the 
intended purpose of AI systems that can evolve in functionality and clinical influence 
over time 
• Predetermined change control plans (PCCPs) and post-market surveillance 
(PMS): how to manage iterative updates to AI systems safely and proportionately 
across the device lifecycle 
• Performance evaluation for AI-powered in vitro diagnostics (IVDs): how to assess 
and evidence the performance of AI-powered IVDs 
Key insights from phase 2 
1. AI medical devices benefit from a lifecycle approach, where post-market monitoring 
complements pre-market evidence. Real-world performance is not sufficiently replicated 
or represented by controlled testing alone. Therefore, it is important for pre-market 
evidence generation to be designed with realistic deployment conditions in mind, and post-
market monitoring should be designed and specified from the outset.

## Page 5

Page 5 of 48 
 
2. Adequate human oversight may look different over a device’s lifecycle and may be 
inadequate to treat as a “fixed” safety control. When AI systems demonstrate consistent 
accuracy and users become familiar with using them, users may trend toward applying 
less scrutiny to device outputs. This natural shift in user behaviour can reduce the 
effectiveness of human-in-the-loop arrangements over time. When developing and 
designing human oversight mechanisms as a risk mitigation, considering how human 
interactions with the device may change over time is an important facet of ongoing 
monitoring.  
3. Ensuring a device continues to operate within its intended purpose is important across a 
product’s lifecycle. For generative AI and large language model (LLM)-based products, 
significant shifts in device behaviour can occur through model behaviour alone. The 
Airlock found that when LLM-based systems lack active guardrails, devices may begin to 
exhibit functions beyond their intended purpose.  
4. It is important for performance thresholds for AI to be clinically meaningful and statistically 
detectable. Across all three challenge areas, the Airlock consistently found that statistically 
significant change and clinically important change are not the same thing. PMS plans and 
PCCP acceptance criteria and thresholds should be grounded in clinical relevance, 
including to set risk-proportionate and pragmatic expectations. 
5. Products that do not qualify as medical devices are outside MHRA’s regulatory remit. 
However, the Airlock surfaced a broader ecosystem consideration regarding shared 
interest across developers, deployers, commissioners and professional bodies in ensuring 
adequate safety and accountability mechanisms exist regardless of device status. 
Manufacturers are responsible for remaining diligent in maintaining their product’s 
intended purpose, as products may change over time and will need to remain compliant 
with applicable regulations if the changed product has a medical intended purpose.   
Phase 2 programme recommendations 
The recommendations follow directly from the insights. Each recommendation is grounded in 
evidence generated through the Phase 2 case studies, simulation workshops, and working 
sessions with ACE. The National Commission into the regulation of AI in Healthcare draws on 
learning from the AI Airlock and other strategy initiatives as part of its broader consideration 
on how the UK’s regulatory framework should evolve as AI becomes more widely used. The 
recommendations in this report will therefore inform the policy landscape in the UK. 
1. Develop PCCP guidance. Providing principles-based clarity on the limits of changes 
that could be included in a PCCP, expectations on the content of a PCCP for AI medical 
devices, and AI-specific guidance on when changes to a device are significant and

## Page 6

Page 6 of 48 
 
aligned to the broader medical device framework would better enable manufacturers to 
make responsible use of this change management mechanism.  
2. Update software qualification and intended purpose guidance. It is important for 
these foundational pieces of guidance to clearly address the changing device 
landscape, including AI-specific considerations and adaptive systems, and for the 
guidance to make clear how they should be applied throughout the device lifecycle.  
3. Develop guidance on performance metrics for AI-powered IVDs. These products 
face unique challenges and opportunities that would benefit from specific clarity in 
guidance. Practical worked examples addressing how and when additional metrics add 
value, and how analytical performance concepts apply to AI systems that do not rely 
on physical analyte measurement, would help advance designing successful validation 
paradigms for AI-powered IVDs. 
4. Consider ecosystem-wide approaches to ensuring responsible deployment and 
accountability for products with low or no device regulatory requirements. Risk-
proportionate and consistent governance approaches for products that may not meet 
the definition of a device but may be used in healthcare will help to ensure users and 
deploying entities have adequate visibility and clear accountability for these products.  
Manufacturers have the responsibility to provide transparency about their products and 
users and deployers need to understand how they can use appropriate products safely, 
regardless of regulatory status.  
Programme impact and next steps 
Phase 2 was independently evaluated by the research agency Woodnewton, whose findings 
confirmed strong stakeholder satisfaction with the programme's sandbox methodology, 
facilitation quality and creation of a trusted space for open regulatory dialogue. The most 
consistent feedback was a call for the programme's insights to be translated into clearer, 
system-level regulatory guidance, a priority the MHRA is currently addressing and committed 
to continue in the next phase. The AI Airlock has demonstrated that collaborative, evidence-
based regulatory sandboxing can provide MHRA with the practical insight needed to keep 
pace with a rapidly evolving technology landscape.  
Phase 3 of the AI Airlock, funded by DHSC for three years from April 2026, will build on the 
foundations of the programme to date with a focus on refining processes to ensure sustainable 
delivery of long term programme benefits and delivering tangible outputs mapped to specific 
MHRA actions and policy priorities as the next step in interrogating challenges in the AI 
medical device regulation. Its priorities will be shaped by the recommendations of the National 
Commission into the Regulation of AI in Healthcare, expected in 2026, alongside the evidence 
generated through this report and building upon learnings across prior phases of the Airlock.

## Page 7

Page 7 of 48 
 
1. Introduction and Context  
Over the past year the UK Government has strongly reaffirmed its ambition for AI in healthcare, 
aiming for the NHS to be the most AI-enabled care system in the world.  
The Regulation Action Plan (2025) aims to overhaul the regulatory system to enable growth 
and reduce investment barriers to the UK market. Key actions include tackling complexity and 
burden of regulation, reducing uncertainty, and challenging risk aversion. Within the Life 
Sciences Sector Plan the Government commits that by 2030, the UK will be one of the top 
three fastest places in Europe for patient access to medicines and MedTech. The 10 Year 
Health Plan “Fit for the Future” outlines 3 key strategic shifts for modernising the NHS, 
ensuring it is sustainable and capable of meeting future health challenges. These shifts move 
healthcare, from hospital to community, from analogue to digital and from sickness to 
prevention.  
Further, the UK Government’s AI Opportunities Action Plan is a national strategy to accelerate 
AI adoption across the UK to boost economic growth, improve public services, create future 
jobs and support everyday life. Published in January 2025, it includes recommendations 
focused on strengthening AI infrastructure, data access, skills, regulation, public-sector 
adoption and sovereign AI capability. The MHRA is committed to the UK Government’s AI 
Opportunities Action Plan by supporting safe, evidence-based AI adoption in a high-impact 
public service area: healthcare.  
To meet these ambitions and continue to ensure UK patients can safely access the most 
innovative products on the market, without unnecessary barriers, the MHRA has prioritised 
the AI Airlock regulatory sandbox programme. Backed by the Department of Health and Social 
Care (DHSC) and the Regulatory Innovation Office (RIO) in its second phase, the Airlock 
enables the MHRA to examine the existing framework through collaborative and flexible ways 
of working that can keep pace with emerging technologies like AI.  
AI Airlock regulatory sandbox in context 
The AI Airlock was established as a pilot in April 2024 and is designed to investigate and 
address the challenges experienced with regulating Artificial Intelligence (AI) as a Medical 
Device (AIaMD). When AI is intended to be used for a medical purpose, it will qualify as a 
medical device and needs to be regulated under the UK Medical Device Regulation 2002. The 
AI Airlock is a regulatory sandbox, intended as a safe, controlled space for industry and 
regulators to explore new, cutting-edge solutions to challenges experienced by innovations 
that push the limits of the current regulatory framework. Regulatory sandboxes are becoming 
well established across sectors and the AI Airlock continues to learn from well-established UK

## Page 8

Page 8 of 48 
 
sandboxes (for example the Information Commissioner’s Office) and internationally through 
initiatives including the DataSphere Initiative Global Sandbox Forum.    
Following a successful pilot programme between April 2024 to March 2025, the Department 
for Health and Social Care (DHSC) funded a second phase. The strategy for the second phase 
of the AI Airlock focused on two goals: 1) to unlock the findings from the pilot by further sharing 
our recommendations for regulation of AIaMD. These publications will ensure we meet this 
mission and we are taking forward ways we can increase our reach and accessibility, and 2) 
to increase the portfolio of the Airlock regulatory sandbox. We worked with a new, bigger 
cohort of AIaMD candidates and engaged new partners and experts across the sector.  
Building Regulatory Science Partnerships for AI Innovation                
In 2025 the MHRA established the Centres of Excellence for Regulatory Science and 
Innovation (CERSIs) to foster collaboration between academia, industry and regulators and to 
accelerate the delivery of safe innovation in human health. Two CERSIs in Digital Health and 
AI (CERSI-AI and RADIANT-CERSI) aim to maximise the potential of AI-powered healthcare 
solutions, including diagnostics and digital health technologies have been working closely with 
the AI Airlock programme in this second phase, sharing learnings and expertise across these 
complex regulatory themes. 
The National Commission into the Regulation of AI in Healthcare launched by MHRA in 
September 2025 is advising MHRA on a new regulatory framework for AI in healthcare, with 
recommendations due in 2026 that will be informed by UK-wide public, clinical, patient and 
industry engagement. The AI Airlock has engaged with the Commission during phase 2, 
sharing practical insights from its regulatory sandbox activity. In turn, the Commission’s 
recommendations will influence the design of AI Airlock Phase 3, including its priorities, focus 
areas and role in supporting implementation of the emerging framework. 
In addition, the AI Airlock works closely with the AI Airlock Committee of Experts (ACE), which 
includes representatives from UK Approved Bodies (ABs), NHS, the National Institute for 
Health and Care Excellence (NICE), the Health Research Authority (HRA), the Information 
Commissioner’s Office (ICO), the Care Quality Commission (CQC), academia and technical 
AI experts. Governance oversight is provided by the AI Airlock Governance Board, an expert 
board comprising clinicians, MHRA experts, including from the Clinical Practice Research 
Datalink (CPRD), government representatives such as DHSC, Department for Science, 
Innovation and Technology (DSIT), NHSE, academics and industry representatives.

## Page 9

Page 9 of 48 
 
Purpose of this report 
This report covers each of the 7 case studies that were carried out in phase 2 of the AI Airlock, 
across 3 key regulatory challenge areas, and includes relevant insights and recommendations. 
The sandbox methodology can be found in Appendix 1 and governance and timelines in 
Appendix 2. The audience for the report is intended to be broad, with relevance for UK 
stakeholders, the public, international regulators and partners, and AI medical device 
developers.

## Page 10

Page 10 of 48 
 
2. Regulatory challenges  
Medical devices in the United Kingdom are regulated under a combination of retained EU 
directives in Great Britain and EU regulations in Northern Ireland. While this framework 
provides a well-established foundation for assessing safety, performance, and clinical 
effectiveness, it was not developed primarily for rapidly developing software and AIaMDs and 
modern, adaptive software and AI systems. As a result, applying the existing framework to 
AIaMDs introduces several challenges. Many regulatory concepts — such as defining 
intended purpose, performance evaluation, and change management — were largely 
developed with devices in mind that are static and functionally deterministic. In contrast, AI 
systems can be adaptive, probabilistic, and highly dependent on data quality and deployment 
context. 
This creates uncertainty for manufacturers and regulators in interpreting how existing 
requirements should be applied in practice. For example: 
 
Defining and maintaining intended purpose for systems that are meant to evolve over 
time 
 
Evidencing device performance where pre-market testing may not replicate real-world 
conditions  
 
Managing iterative updates without clear thresholds for changes of regulatory 
significance 
Ongoing UK regulatory reform aims to modernise the framework to support innovation while 
maintaining patient safety. However, at the time of phase 2 of the AI Airlock, there remain 
implementation challenges between the structure of existing regulation and the practical 
realities of AI development and deployment. The AI Airlock programme provides a mechanism 
to test how current regulatory approaches perform in practice, and to identify where 
interpretation, clarification or adaptation is needed to ensure the framework remains effective 
for AI technologies. 
Phase 2 candidates  
Phase 2 of the AI Airlock was structured around 3 key regulatory challenge areas. The portfolio 
approach to selection allowed the programme to design a thematic cohort, with a tiered 
approach to a specific challenge, allowing investigation of the same challenge from multiple 
product perspectives.

## Page 11

Page 11 of 48 
 
Table 1 Overview of the candidates, regulatory challenges and key objectives explored during phase 2 of the AI Airlock 
Candidate & Product  
Challenge 
Candidate Type 
Key Objectives 
TORTUS by Tortus AI, 
Ambient Voice 
Technology 
Scope of 
Intended 
purpose 
Multi-environment 
1. Define when TORTUS shifts from documentation (speech-to-text) to clinical decision influence 
(diagnostic coding/clinical decision support) and determine regulatory trigger for reclassification. 
2. Validate LLM outputs for diagnostic impact and ensure safe human-AI workflows. 
Nu & Aegis by Numan, AI 
conversational & 
monitoring system, 
weight loss 
management 
Simulation only 
3. Borderline Qualification: When does the product move from wellness support to regulated medical 
use? Which features or claims trigger AIaMD qualification? 
4. Evidence & Documentation: What evidence and controls are needed to keep a product in compliance 
or safely expand the product’s scope? 
Safe Summarisation by 
NHSE, Patient 
Discharge summaries  
PMS & 
PCCPs 
Multi-environment 
5. How can the Federated Data Platform (FDP) be applied to performance monitoring and PMS 
activities of AIaMDs, specifically the Safe Summarisation tool? 
6. How can FDP support development and implementation of a PCCP for AIaMD? 
Eye2Gene, genetic eye 
disease detection tool 
Simulation only 
7. How should PMS plans be designed for AIaMDs in rare disease settings, where data is scarce, to 
ensure meaningful and proportionate performance monitoring metrics? 
8. What regulatory considerations arise when developing real-world performance feedback loops for 
AIaMDs? 
DeepX AI by DeepX 
Health, skin cancer 
lesion triage tool 
Simulation only 
9. How should PMS for AIaMDs be designed to monitor performance across different skin tones, 
ensuring that bias is detected and mitigated? 
10. Can data from other jurisdictions be used to support PMS activities in the UK where there is scarce 
demographic data available in the UK? 
PANProfiler Colorectal by 
Panakeia, 
histopathology slide 
review for cancer 
detection 
AI as an IVD 
Multi-environment 
11. What steps can be taken to establish clear and consistent definitions and metrics for evaluating AI 
algorithms, considering the variable definitions of positive and negative events that affect 
sensitivity and specificity results? 
12. How can we harmonise assay protocols and implement quality control measures to improve 
concordance across different labs, given the sensitivity of concordance to ground truth variability? 
Octopath, histopathology 
slide review for cancer 
detection 
Simulation only 
13. How can we develop a performance evaluation strategy which will be applicable across various AI 
algorithms? 
14. How can post-market updates and model retraining be effectively managed?

## Page 12

Page 12 of 48 
 
Scope of intended purpose and validation 
The intended purpose defines the scope of the deployed product; it is used to determine 
qualification and classification of the device, which in turn informs the nature and extent of 
the evidence required to demonstrate its safety and performance.   
 
Figure 1. The intended purpose sits at the centre of the regulatory framework, informing qualification, classification, 
clinical evidence requirements, and post-market obligations. 
The existing MDR 2002 outlines intended purpose in broad terms, placing it at the centre of 
most regulatory requirements illustrated in Figure 1. This is further reinforced by the MHRA 
SaMD guidance for crafting an intended purpose in the context of software as a medical device 
(SaMD) and MHRA Software flowchart which clarifies its role as the foundation for risk 
classification, clinical evidence generation, and post-market activitiesFigure 1. While the 
guidance recognises software-specific challenges and provides a structured approach to 
defining intended purpose, it largely assumes a static, well-bounded, and functionally 
deterministic system. 
In practice, this assumption becomes increasingly challenging for modern AI technologies. 
Despite being considered within the scope of SaMD, MHRA experience indicates that 
manufacturers can face challenges articulating and supporting a clear intended purpose with 
evidence and ensuring that devices operate within the limits of that purpose over time. It is 
important that verification and validation activities account for how AIaMD, particularly LLM-
based products, behave in real clinical contexts, where outputs may vary substantially from 
controlled, pre-market performance depending on data, user interaction, and deployment 
environment. This places particular emphasis on post-market processes, where surveillance 
and follow-up activities will need to be able to detect performance drift or other emerging risks 
over time. At the same time, ongoing change management presents an additional complexity, 
as updates such as prompt modifications, model retraining, and iterative improvements need 
to be managed in a way that maintains alignment with the intended purpose and regulatory 
requirements.

## Page 13

Page 13 of 48 
 
Performance evaluation for AI-powered in vitro 
diagnostic (IVD) devices 
At the time of writing, the regulatory framework for in vitro diagnostic (IVD) medical devices is 
under reform, and this is expected to lead to future updates to the guidance on the regulation 
of IVD medical devices in Great Britain. Alongside these regulatory changes, there is 
increasing emphasis on strengthening how performance is defined, evidenced and assessed, 
including growing focus on the selection and justification of performance metrics as part of 
performance evaluation. While these developments aim to improve consistency, transparency, 
and robustness in regulatory assessment, they are largely based on assumptions that device 
performance can be characterised using stable, well-defined metrics applied to bounded and 
controlled systems. 
In practice, AI-powered IVDs introduce complexities that this assumption does not fully 
account for. Performance is often influenced by variability in data inputs, laboratory processes 
and deployment environments, and may not be fully captured through a fixed set of traditional 
metrics. This creates uncertainty for manufacturers in selecting appropriate metrics, and for 
regulators in interpreting whether performance has been adequately demonstrated. As a 
result, it is not always clear whether existing or emerging approaches to performance metrics 
are sufficient for AI systems, or how they should be adapted to reflect the context-dependent 
nature of AI performance. A central regulatory challenge is determining how performance for 
AI-powered IVDs should be assessed in a way that captures their evolving and context-
dependent behaviour. However, it is important to simultaneously build on established metrics 
such as accuracy, precision, sensitivity, and specificity. This creates uncertainty around what 
constitutes sufficient evidence of performance over time, including how to interpret 
reproducibility, variability, and sustained performance in real-world use. 
Predetermined change control plans and post-market 
surveillance 
Predetermined change control plans  
There is growing international interest in approaches to managing iterative changes to AIaMD, 
including the emerging regulatory concept of predetermined change control plans (PCCPs). 
PCCPs aim to provide a structured framework for defining and managing anticipated 
modifications to software systems over time in a safe and effective manner. The concept 
involves engaging Approved Bodies on predefined changes during initial conformity 
assessment, reducing the need for repeated reassessment and streamlining the process for 
iterative updates. PCCPs also enhance transparency and predictability for manufacturers by 
clearly defining the scope and boundaries of changes, supporting ongoing safety and

## Page 14

Page 14 of 48 
 
performance across the device lifecycle. This approach supports innovation by enabling more 
efficient deployment of updates, particularly for AIaMD that may require frequent optimisation. 
However, PCCPs are not yet formally embedded within the UK regulatory framework, and their 
role and application in practice remain unclear. Nonetheless, guidance has been developed 
internationally and within the UK, including MHRA’s guiding principles on PCCPs and through 
collaboration with international forums such as IMDRF.  
Current regulatory approaches to change management are based on whether a modification 
is considered significant (or substantial) and therefore requires notification or regulatory 
reassessment. In the UK context, this principle is established in the conformity assessment 
annexes of the directives, and supporting guidance does exist, most notably the older NBOG 
guidance on substantial change. However, in practice this framework can be difficult to apply 
consistently, particularly for software and AI-enabled devices, where the nature of 
modifications is highly variable and understanding of what constitutes a significant change is 
still evolving. This is compounded by the fact that many manufacturers, especially those more 
familiar with EU MDR processes, are more likely to look to newer MDCG guidance than to 
older directive-based guidance that remains relevant in Great Britain. In addition, Approved 
Bodies themselves are continuing to interpret how these principles should be applied in the 
context of emerging AI technologies, which further contributes to the reliance on case-by-case 
engagement. This creates uncertainty not because the principle itself is absent, but because 
the applicable framework is fragmented, dated, and challenging to interpret consistently in 
practice. It also raises broader questions about which types of updates could be managed 
through a more structured mechanism such as a PCCP, and how regulators can ensure that 
devices remain within the scope of their original approval while continuing to be implemented 
safely. 
 
Post market surveillance  
Regulatory expectations for post-market surveillance (PMS) have recently been updated 
through The Medical Devices (Post-market Surveillance Requirements) (Amendment) (Great 
Britain) Regulations 2024, which amend the Medical Devices Regulations 2002 (MDR 2002) 
by introducing a new Part 4A for PMS requirements. These requirements apply to medical 
devices, including in vitro diagnostic (IVD) devices and active implantable medical devices 
(AIMD), within Great Britain. The updated framework places greater emphasis on continuous 
monitoring of device performance and the use of real-world evidence to identify risks across 
the product lifecycle. More broadly, manufacturers are encouraged to take a more proactive 
and systematic approach to monitoring device performance beyond initial approval.

## Page 15

Page 15 of 48 
 
However, as currently structured, PMS requirements assume that changes in device 
performance are discrete and detectable, with regulatory action typically triggered by 
identifiable incidents or adverse events such as within guidance for manufacturers on reporting 
adverse incidents involving software as a medical device under the vigilance system. In 
practice, some AI systems may change continuously and in ways that are not easily 
observable, making it difficult to determine when regulatory intervention is required. There 
remains a lack of clarity regarding which aspects of system behaviour should be monitored, 
the appropriate frequency of monitoring, and which signals should be regarded as indicative 
of meaningful changes in performance.

## Page 16

Page 16 of 48 
 
3. Key insights  
The regulatory challenges described in Section 2 formed the investigative framework for phase 
2 of the AI Airlock. The seven case studies and three simulation workshops were designed to 
test how these challenges manifest in practice, across real products and real deployment 
contexts. See Appendix 1 for full methodology. The insights that follow are drawn from that 
evidence, grounded in candidate data and validated through expert stakeholder engagement 
in simulation workshops or through technical working sessions with the Airlock Committee of 
Experts. 
Detailed Case studies 
The seven case studies generated through Phase 2 of the AI Airlock form the primary evidence 
base for the insights and recommendations set out in this report. Each case study represents 
the candidate's own exploration of the regulatory challenges identified for their product, 
documenting their testing approach, the evidence they generated, and the findings that 
emerged. They are illustrative of how manufacturers are approaching these challenges in 
practice.  
The insights and recommendations in this report have been developed through MHRA's 
analysis of the candidate-level evidence, considered alongside broader stakeholder input 
gathered through simulation workshops and working sessions with the Airlock Committee of 
Experts (ACE). Where the case studies provided product-specific exploration, this report 
synthesises what was found consistently across the cohort and identifies the regulatory 
implications. 
The case study reports will be published separately following the release of this programme 
report. Readers seeking candidate-level detail on the regulatory questions explored, the 
methodologies applied, and the findings that emerged for individual candidates are directed 
to those documents when available. 
Cross-cutting Insights 
Robust 
pre-market 
evidence 
is 
essential 
and 
should 
be 
complemented by post-market monitoring in real-world conditions 
Robust pre-market evidence is the foundation of confidence in a medical device's safety and 
performance, but a key question is what level of pre-market evidence is sufficient and 
meaningful, given the known limitations of what controlled testing can replicate.

## Page 17

Page 17 of 48 
 
The TORTUS case study tested two safety mechanisms in both a controlled virtual 
environment and in real-world conditions through a shadow-run infrastructure. In offline 
testing, both performed as designed. In production, the results diverged. The Shell, designed 
to identify and remove hallucinated content, remained consistently effective across both 
environments. The Context Guardrail, designed to prevent adversarial prompt injection, 
significantly reduced scope drift in virtual testing but had no significant effect in real-world 
deployment, because real users were not attempting to manipulate the system. While the 
guardrail addressed some foreseeable misuse, it was not reflective of the routine clinical use 
presented in the case study. This illustrates a broader point raised by the Airlock Committee 
of Experts (ACE): manufacturers may assume that synthetic or adversarial testing is sufficient 
to demonstrate real-world validation, but risk optimising for conditions that rarely materialise 
in practice while missing the variability that does. 
Candidates noted that third party foundation models can also introduce functional evolution 
that is difficult to map to discrete change events, meaning ensuring that device performance 
remains constrained to the intended purpose becomes more difficult to manage and requires 
ongoing monitoring. Stakeholder workshops also reinforced the need for performance metrics 
with clinical grounding, not merely statistical framing, and the importance of real-world testing 
and monitoring as a standard expectation. 
Taken together, these findings suggest that post-market monitoring is most effective when 
designed to complement rather than follow from pre-market testing.  Manufacturers should 
consider the appropriate balance of evidence generation, understanding that pre-market 
testing may not be sufficiently suited to demonstrate the long-term, actual performance of the 
product in practice. At the pre-market stage, manufacturers can usefully design validation 
studies with real-world deployment in mind, identifying which assumptions about user 
behaviour, data quality, and clinical context may not hold in production, and specifying from 
the outset how those assumptions will be monitored.  
Human oversight is a lifecycle variable with regulatory significance 
Human review of AI outputs featured regularly across the Airlock challenge areas as part of 
manufacturers' risk controls. The evidence raised a consistent question: how can 
manufacturers and deployers be confident that human oversight is providing the assurance 
expected, particularly as use patterns may change over time? 
TORTUS achieved a real-world precision score of 0.989, and workshop delegates noted that 
users may reduce scrutiny of outputs over time in response to consistent and reliable product 
performance. As a product becomes more trusted, human review may become less rigorous, 
making residual errors less likely to be detected. Further, these user trends are also unlikely 
to be uniform across domains. It is therefore important to consider the dynamic and variable 
nature of user interactions with a product, particularly when user oversight may be intended

## Page 18

Page 18 of 48 
 
as a risk mitigation measure. When monitoring for changes in oversight quality, monitoring 
plans will be more effective if they are designed to consider the type and severity of potential 
errors, not only their frequency, as well as other factors that may affect the potential impact of 
risks, including where and how human-in-the-loop steps intersect with device function. 
Assessing oversight in practice benefits from multidisciplinary expertise and input from both 
the AI development and clinical communities. 
However, it is important to consider AI performance and potential errors compared to clinician 
error rates in the same domain. Some ACE members noted that for automated transcription a 
performance better than 1 error in 100 might be desired, while clinicians acknowledged that 
their own transcription accuracy cannot be guaranteed to exceed 99% and, further, that error 
severity is often only assessable retrospectively. Therefore, the relevant comparator for AI 
performance should be considered in context of current practice in the same domain. A 
framework combining error frequency with severity was proposed as preferable to a single 
precision metric. Stakeholders suggested this should be tabulated consistently with DCB and 
ISO standards. In addition, delegates noted that performance metrics are most effective when 
grounded in both clinical and statistical reasoning.  
During simulation workshops, DeepX AI explored the deliberate version of oversight reduction: 
whether a PCCP could support staged reductions in clinician confirmation of AI outputs, while 
Safe Summarisation raised a less structured version: review depth declining as users become 
accustomed to high-precision outputs without any deliberate system change. In either case, 
behavioural signals such as review time and edit depth were considered as potential indirect 
indicators of engagement quality.  
Findings suggested that it is important to consider human oversight as a variable prone to 
change over the device lifecycle and, therefore, monitoring to detect meaningful changes in 
behaviour can be helpful to understand realistic device use over time. This may be particularly 
helpful when human-in-the-loop functions are intended as explicit risk controls and should be 
part of reassessment when performance or effectiveness changes just as other relevant risk 
controls would also be re-evaluated. It was also found that overarching performance metrics 
should consider both current clinical performance and statistical reasoning to develop 
proportionate performance expectations.  
Scope expansion and validation 
Intended purpose remains the reference point for regulation, but 
generative AI systems can make it harder to limit actual device 
functionality in practice

## Page 19

Page 19 of 48 
 
Intended purpose remains central to device qualification, but for generative AI products, it can 
be challenging to limit real-world use to the stated purpose. One example is identifying when 
a wellness product begins to provide medical device functions without being explicitly 
programmed to do so, or a product similarly exhibiting functionality that could move it from 
Class I to a higher device classification.  
The TORTUS case study showed empirically that without active guardrails, out-of-scope 
performance was detected in approximately 39% of real-world notes, falling to 20% with 
guardrails active. This suggests LLM behaviour alone, without appropriate design controls, 
can generate behaviour outside the product's intended purpose. TORTUS reinforced that 
while disclaimers function as passive controls; they do not prevent generative AI systems from 
producing content that constitute functionality outside of the stated intended purpose.  
During the simulation workshop, Numan illustrated a similar challenge from a different angle. 
Features that are each individually low-risk can together create a product that functions 
differently from the sum of its parts. The combination of clinician-reviewed biomarker data, 
longitudinal memory, and condition-specific personalisation within a clinical pathway shifted 
the overall impression of the product from wellness to medical device for participants. This is 
also practically significant because manufacturers develop products iteratively. Features that 
are low risk individually may together lead to additional risks that would not be anticipated 
without an impact assessment of the collective changes. As such, periodic reviews that 
consider feature interactions are more reliable than reviews of individual additions. However, 
further work is needed to provide clarity on what may constitute effective monitoring and 
reviews, and the expected response to findings from such monitoring, to ensure continued 
regulatory compliance. 
ACE members also noted that current market entry processes for Class I devices do not 
include verification of intended purpose statements. Publication of intended purpose 
statements alongside registration was suggested as a practical step. 
Qualification and classification depend on function, context and 
influence and direct diagnosis cannot be defined by language alone 
Assessment of intended purpose was found to be more reliable when grounded in 
consideration of the whole product than when focused on wording and claims in isolation. 
Workshop participants treated disclaimers and specific language as meaningful qualification 
signals when discussing intended purpose in the abstract. However, when the same 
participants assessed concrete product scenarios with functionality, user experience, and 
clinical context made explicit, their judgements depended far more on the actual use and 
functional design of the product than on how it was labelled (Figure 2).

## Page 20

Page 20 of 48 
 
Relatedly, there was persistent uncertainty about what constitutes direct diagnosis for AI 
systems generating natural language outputs that emerged across candidate discussions and 
workshop sessions, and a further challenge discussed is whether an LLM may be considered 
to provide a diagnosis when it gives information that strongly and specifically influences clinical 
or patient behaviour, even without a definitive diagnostic label. Stating that a user appears to 
have iron deficiency anaemia may be more clearly diagnostic than noting a low haemoglobin 
value, but both may direct behaviour depending on user context, follow-up advice, and the 
specificity of the output. This demonstrates that understanding the presentation of natural 
language outputs is highly context dependent. As such, it was evident that not only is it 
challenging to understand an intended purpose based upon claims and language alone, 
interpreting intended behaviour of a product can be increasingly challenged by nuanced, 
natural language outputs.  
 
Figure 2 illustrates the shift in participant judgement between abstract and scenario-based assessment of intended purpose 
during the scope of intended purpose simulation workshop. 
The Numan case study provides an additional example of the impact of data presentation and 
context. Workshop participants drew a consistent distinction between generic support and 
personalised interpretation of clinical data. General guidance on diet, movement, or habit 
formation was treated as sitting comfortably within a wellbeing boundary. Perceptions shifted 
when the product began to explain biomarkers in a patient-specific way. This illustrated that 
the same type of output may be accepted as “generic” educational information in one context 
but could be interpreted as potentially diagnostic in another, depending on whether it is 
personalised to an individual, combined with clinical data, or delivered within a healthcare 
pathway. Direct diagnosis was therefore not felt by participants to be a fixed property of the 
output itself but impacted by the intended purpose of the output as demonstrated by multiple 
factors.  
The TORTUS findings add a dynamic dimension that compounds this challenge. A product 
that is positioned away from direct diagnosis at the point of design can still provide such 
functions through hallucination. Without active guardrails, some evidence of possible out-of-

## Page 21

Page 21 of 48 
 
scope outputs was detected in approximately 39% of real-world notes. Similarly, the boundary 
between documentation support and clinical decision support can be crossed erroneously 
through features of the model behaviour alone. Responses to this challenge include structured 
provision of clinical context to the LLM, which was associated with improved precision and 
reduced hallucination, and active hallucination reduction systems, which demonstrated 
meaningful impact in testing. Neither, however, resolves the direct diagnosis question and the 
need for further regulatory clarity on this interpretation, but both point toward functional design 
and workflow choices that can help manufacturers keep products more reliably operating 
within the bounds of their intended purpose.  
Products that do not qualify as medical devices are outside MHRA’s regulatory remit. 
However, it is understood that these products may evolve over time, including potential 
addition of medical device functionality. The Numan case study illustrated how this can 
happen: semantic memory could in some configurations impact a product's perceived intended 
purpose without any deliberate change to its intended purpose statement. More specifically, 
where an AI system accumulates a longitudinal record of symptoms, biomarker trends, or 
health behaviours, the distinction between personalisation and monitoring becomes less clear. 
These two functions may be architecturally identical while potentially being regulatorily distinct, 
and the shift in practical use and understanding may be invisible to regulators until a product 
is already widely deployed.  
The Airlock surfaced a broader ecosystem consideration regarding shared interest across 
developers, deployers, commissioners, and professional bodies in ensuring adequate safety 
and accountability mechanisms exist regardless of device status. The concept of creating 
mechanisms to help drive consistent good practice and visibility was supported by ACE 
members. Nonetheless, manufacturers are responsible for remaining diligent in maintaining 
their product’s intended purpose, as products may change over time and will need to remain 
compliant with applicable regulations if the changed product has a medical intended purpose. 
AI-powered IVDs 
AI-powered In vitro diagnostics (IVDs) are a rapidly growing category of devices that apply 
machine learning to diagnostic data, most commonly histopathology. IVDs have distinct 
regulatory framework and IVD conformity assessment is primary centred around performance 
evaluation – including analytical performance, clinical performance and scientific validity.  
Currently, performance expectations are influenced by the assumption that devices remain 
static and performance will remain stable once deployed. However, AI IVD outputs can be 
more sensitive to factors such as data quality, laboratory workflows, scanner settings, staining 
variation, population characteristics, model updates and preprocessing pipelines compared to 
other IVDs. The AI Airlock programme explored this challenge through the selected candidates 
for phase 2, Panakeia’s PANProfilerColorectal and Octopath, providing the programme with 
case studies.

## Page 22

Page 22 of 48 
 
Current performance expectations for IVDs remain applicable for AI, 
though discretion is needed to determine if additional metrics may 
help provide a more comprehensive profile  
The Airlock found that existing performance expectations which include demonstrating 
adequate sensitivity, specificity, analytical performance, clinical validity, and scientific validity 
remain important and applicable to AI-powered IVDs. However, there remains an open 
question on how to apply them appropriately to AI products. AI IVD performance may benefit 
from additional metrics, as these alternatives could demonstrate more suitable data compared 
to traditional measures. A device that classifies a biomarker from a digital pathology image 
may need to demonstrate, among other things, how often it produces a definitive result, how 
it handles indeterminate cases, how performance varies across scanning and staining 
environments, how it performs in borderline cases, and how stable performance is over time. 
The PANProfiler case study showed that the choice between diagnostic accuracy metrics and 
agreement metrics is not only a technical consideration but also a regulatory one as it depends 
on whether a gold standard comparator exists. Agreement metrics may be more appropriate 
where the comparator is itself imperfect.  
The Octopath case study added a further dimension to this challenge. Within the simulation 
workshop, Octopath was described as detecting 32% more mitoses than pathologists, with 
molecular staining indicating that a high proportion of these detections aligned with biological 
markers of mitotic activity. These findings were presented as illustrative evidence to challenge 
existing validation assumptions and to raise an important point for regulatory consideration: 
where an AI system consistently detects beyond the range of human review, and where that 
detection appears biologically grounded, the appropriate comparator and the metrics used to 
assess agreement or accuracy may themselves need to be reconsidered. 
The PANProfiler case study also introduced the concept of test replacement rate: the 
proportion of cases for which the AI device provides a definitive result and could therefore 
replace additional laboratory testing. While this metric is not part of standard diagnostic 
performance evaluation frameworks, it is relevant to clinical workflow, operational impact and 
real-world value. Taken together, PANProfiler and Octopath illustrate that metric selection 
should be driven by what is relevant to the device's intended purpose, clinical role and user 
context and that for some AI IVDs, the evidence base required to demonstrate performance 
may need to go beyond what existing frameworks currently anticipate.  
In simulation workshops, participants suggested that implementing a structured justification 
process for selected metrics, in the context of the specific device’s intended purpose and risks, 
could help to address these areas.

## Page 23

Page 23 of 48 
 
Real-world variability is already within the IVD regulatory framework, 
but AI makes its management more complex 
Traditional IVD regulation already recognises that performance can vary across analytical 
conditions, laboratories and patient populations. What the Airlock found is that AI-powered 
IVDs can be particularly sensitive to variability in data inputs and deployment environments, 
and that managing this variability requires more deliberate regulatory handling. 
In digital pathology, differences in staining intensity, scanner type, image resolution or pre-
processing pipeline can affect what the model detects and how confidently it performs. 
Workshop participants identified data quality and completeness as the most important source 
of performance inconsistency for AI IVDs and for AIaMD (Figure 3, left). They also observed 
that digital pathology does not eliminate technical variation in specimen preparation; in some 
respects, it exposes that variation more clearly than traditional visual assessment. 
Simulation workshop contributions from UK National External Quality Assessment Service (UK 
NEQAS), National Pathology Imaging Co-operative (NPIC), and National Physical Laboratory 
(NPL) highlighted the importance of external quality assessment as a mechanism for detecting 
and managing image quality issues that affect AI performance, and for providing a framework 
for quality improvement across the digital pathology pathway. The PANProfiler case study 
reinforced the need for reference datasets that reflect real-world laboratory variability, 
including variation across NHS sites, borderline cases and demographic diversity. However, 
there remains open questions around who would be accountable for such datasets and their 
governance.  
Further, datasets used for model development and training serve a fundamentally different 
purpose from those used for independent benchmarking. A benchmarking dataset used for 
regulatory assessment needs to be independent of the manufacturer's development process. 
Similarly, a national benchmarking dataset may not substitute for local deployment validation, 
and a real-world evidence dataset for PMS purposes needs to reflect the deployment 
environment rather than a controlled validation setting. 
Based on a literature review, the PANProfiler case study proposed a seven-domain framework 
for a national reference dataset (Figure 3, right), encompassing intended-use alignment, 
ground truth derivation, real-world laboratory variability, borderline and challenging cases, 
demographic representativeness, statistical evaluation design, and governance. Workshop 
discussion added important practical dimensions: ownership, maintenance, curation, open 
versus restricted access, patient opt-out mechanisms, and how to ensure that datasets remain 
representative and independent over time.

## Page 24

Page 24 of 48 
 
 
Figure 3 illustrates two related findings from the AI-powered IVDs simulation workshop. Left: when asked to identify the 
most significant sources of AI performance variability, delegates ranked data quality and completeness as the leading 
factor. Right: drawing on a structured literature review, the PANProfiler case study proposed a seven-domain framework for 
a national reference dataset to support consistent AI IVD validation 
The risk of poorly governed datasets is significant. A dataset treated as a definitive standard 
may become outdated, unrepresentative, or subject to overfitting if used for both development 
and independent assessment. If used inappropriately, it could narrow innovation or fail to 
detect performance issues in underrepresented groups or difficult cases. However, there 
remains opportunity to develop shared infrastructure that improves the efficiency and 
trustworthiness of AI IVD assessment while maintaining the integrity necessary for regulatory 
confidence.

## Page 25

Page 25 of 48 
 
AI IVD updates require clearer linkage between performance 
evaluation, change control and PMS 
While PANProfiler colorectal is a general AI-powered IVD and therefore a PCCP would not be 
applicable, the case study tested directly whether iterative AI-powered IVD updates can be 
managed effectively under current regulatory frameworks. It compared two versions of their 
device, v1.0 and v1.1. The update involved dataset refinement with improved quality 
assurance criteria and model optimisation. It improved performance, but did not change the 
intended purpose, clinical claim, decision logic or risk class. This created a practical regulatory 
question that current guidance does not answer clearly: when does a performance-improving 
update remain a non-significant change? 
The case study concluded that v1.1 demonstrated meaningful performance improvement 
without a change in intended purpose or risk, illustrating a scenario where current regulation 
can in principle be applied, but where clearer guidance on classification and management of 
such changes would substantially reduce uncertainty for manufacturers and Approved Bodies. 
The case study also explored whether PCCPs could provide an appropriate framework for 
iterative AI-powered IVD updates, concluding that they offer a promising mechanism. 
However, without clearer expectations, manufacturers may default to full resubmissions for 
bounded updates, slowing beneficial improvements and increasing regulatory burden. 
Conversely, under-escalating change could risk clinically meaningful alterations being 
introduced without sufficient scrutiny.  
Explainability for AI IVDs should be designed to support safe use, 
auditability and scientific validity 
The Airlock found that explainability is important for AIaMD and AI IVDs and should 
complement usability and transparency guidance. Explainability needs to serve specific 
regulatory and clinical purposes, supporting safe clinical use, enabling regulatory assessment, 
demonstrating scientific validity, and providing auditability. 
Different audiences require different forms of explanation, a concept which was explored in 
depth during the AI Airlock pilot. Regulators may need global explainability: what the model is 
designed to do, how it was developed, what features or biological characteristics it uses, what 
its limitations are, and how its behaviour is controlled and monitored. Clinicians may need local 
explainability: why a particular result was produced in a specific case, how confident the 
system is, and when they should consider challenging or overriding the output. Patients may 
need accessible information about whether AI is being used, what role it plays, and what 
safeguards are in place.

## Page 26

Page 26 of 48 
 
The PANProfiler case study developed a quantitative explainability framework using tissue 
and tumour composition metrics to provide auditable context for diagnostic outputs. This 
approach linked AI outputs to measurable biological features, creating a more structured and 
verifiable explanation than a purely visual heatmap. The Octopath case study contributed 
additional perspectives on real-world evidence, performance instability and performance 
beyond human review. Stakeholders expressed a preference for combining quantitative and 
qualitative approaches, using global explainability for regulatory assurance and local 
explainability for clinical use. Explainability requirements were noted as most effective when 
linked to usability, risk management and scientific validity, and when designed and validated 
with clinicians and patients from the outset of development rather than as a visual feature at 
the end of development. 
Predetermined change control plans and Post-market 
surveillance 
Post-Market Surveillance and Predetermined Change Control Plans are central lifecycle 
management tools for AIaMD. Three case studies: NHS Safe Summarisation, DeepX Health, 
and Eye2Gene generated structured evidence on how these mechanisms should be designed, 
linked and governed for AI systems. At the time of AI Airlock phase 2 testing and initial 
reporting, there were no formal PCCP provisions in UK regulations. During reporting, a draft 
statutory instrument (UK Medical devices (Amendment) Regulations 2026 regulation) was 
published and contained formal PCCP provisions which applied only to products subject to 
Approved Body oversight. They do not apply to Class I devices or general IVDs. The insights 
in this section are therefore most directly relevant to products in Class IIa or self-testing IVDs 
and above, and the recommendations should be read in that context.  
PMS and PCCPs are most effective when appropriately bounded, 
evidence-linked and integrated with PMS 
PCCPs were widely supported by workshop participants and candidates as a mechanism to 
allow planned, controlled updates to AIaMD without full regulatory reassessment for each 
change. This is genuinely valuable as AI systems that cannot be updated efficiently in 
response to drift, performance signals or new clinical knowledge may become less safe and 
effective over time. 
A PCCP is intended to define the specific scope of modifications anticipated, the conditions 
under which each can occur, the evidence required before and after implementation, 
acceptance thresholds, version control arrangements, rollback routes and monitoring 
obligations. Safe Summarisation and Eye2Gene provided detailed operational examples 
within the Airlock. For example, Safe Summarisation’s PCCP covered prompt changes, 
referential data changes, foundation model changes and monitoring configuration changes,

## Page 27

Page 27 of 48 
 
each with defined triggers, evidence requirements, RAG-status governance and human sign-
off requirements.  
The Airlock consistently found that PCCPs are most effective when structurally linked to PMS. 
PMS provides the real-world evidence that should determine whether PCCP-controlled 
changes can proceed, be paused, or require the PCCP itself to be revised. The Safe 
Summarisation monitoring framework illustrates this in practice. When a planned modification 
is initiated, the relevant dimensions are flagged for review and cannot proceed until defined 
acceptance checks are passed. Where thresholds are not met, the change is blocked. The 
same performance dimensions monitored continuously by PMS (hallucinations rates, 
groundedness, completeness) are the same criteria that determine if a PCCP change can 
proceed, creating a direct procedural link between ongoing surveillance and change 
management.  
At the time of AI Airlock phase 2, the absence of formal PCCP provisions in UK regulations 
was identified by candidates as a significant barrier to operationalising the approaches 
described above, and is directly addressed in the recommendations that follow.  
Significant change for AIaMD cannot be determined by the type of 
technical change alone 
Across the PMS/PCCP workshop and all three PMS/PCCP case studies, a recurring finding 
is that the regulatory significance of a change cannot be determined from the type of change 
in isolation. The same technical modification (e.g., model retrain, prompt revision, workflow 
adjustment, interface change) may be significant in one context and not in another. DeepX AI 
illustrated this: a workflow change that reduces or removes clinician confirmation of AI outputs 
may involve no change to model architecture or clinical logic, but may alter the device's use 
and risk profile, its classification, and the assumptions underpinning conformity assessment. 
Workshop delegates confirmed that human factors and workflow changes are often at least 
as important as technical performance metrics. Safe Summarisation similarly found that the 
same level of technical change in a foundation model could represent a major or minor PCCP 
event depending on whether the model is within the same family and whether reasoning 
architecture differs. 
The practical implication is that significance assessment will need to start with intended 
purpose but extend to function, clinical role, user interaction, level of autonomy, deployment 
environment, benefit-risk impact and human oversight. A decision framework that makes these 
contextual factors explicit would support more consistent assessment by manufacturers, 
Approved Bodies and MHRA alike.

## Page 28

Page 28 of 48 
 
Performance thresholds should be clinically meaningful, not only 
statistically detectable 
PMS and PCCP governance depends on performance thresholds that can trigger meaningful 
review and action. The Airlock found that threshold-setting is one of the most practically difficult 
aspects of AI device lifecycle management, and that statistically detectable change and 
clinically meaningful change are not the same thing. 
Eye2Gene illustrated this in a rare disease context where patient populations are small, 
outcome timelines may be long, and genetic confirmation is inconclusive in many inherited 
retinal disease cases. Where clinical ground truth is uncertain, reliable PMS triggers are 
difficult to define, and statistically significant drift may not correspond to clinically important 
performance change. Safe Summarisation illustrated the challenge in an LLM context: 
automated metrics including groundedness, completeness, conciseness, readability and 
toxicity support monitoring but cannot replace clinician calibration, and LLM-as-a-judge 
evaluation was confirmed to be insufficient as a sole assurance mechanism. DeepX raised the 
further challenge of subgroup-level thresholds where overall acceptable performance may 
mask material performance gaps in specific patient subgroups. 
From another regulatory challenge area, Octopath, an AI-powered IVD raised the same point. 
Octopath presented a model with approximately 91% sensitivity but with notable week to week 
variation, attributed to real-world population shift. Discussions highlighted that statistical 
performance thresholds alone may not fully capture clinically relevant stability, prompting 
consideration of how performance variability should be monitored and interpreted. 
Subgroup performance improvement to support equity can be 
enabled by PMS and PCCPs 
AI devices may perform acceptably against overall performance metrics while 
underperforming for specific patient subgroups. These disparities may be invisible at pre-
market evidence but become apparent after deployment in a broader or different population. 
Without clear regulatory pathways for subgroup remediation, known performance disparities 
may persist without a fast and agile way for manufacturers to correct them so the product can 
continue benefiting patients.  
DeepX AI placed this issue at the centre of its PCCP and PMS investigation. It explored 
whether PMS-identified subgroup performance gaps, for example in underrepresented skin 
tones in a UK dermatology dataset, could trigger model remediation within a PCCP. Key 
questions that were discussed in simulation workshops included: what data sources are 
acceptable for subgroup remediation where UK population data is limited; how to validate

## Page 29

Page 29 of 48 
 
remediation to avoid improving one subgroup while degrading another; and whether synthetic 
or international data can be used to supplement insufficient UK evidence. 
Similarly, Eye2Gene's Airlock work explored whether PCCPs could provide a controlled 
pathway for evidence-driven use expansion – for example, validating additional genes as they 
are characterised – provided the expansion follows a predefined protocol and does not alter 
the broader intended purpose. This points to a broader need, for knowledge-based AIaMD, 
regulatory frameworks should consider mechanisms that support controlled updating to 
remain aligned with current clinical evidence. Octopath raised a parallel question from a 
different angle. Its underlying AI model demonstrated strong and broadly consistent diagnostic 
performance, correctly identifying most relevant cases across multiple tissue types, including 
breast cancer, neuroendocrine tumours and melanoma. This consistency was used to support 
discussion around whether a model that performs reliably across several cancer types could, 
under a structured validation framework, have its use extended to new indications without 
requiring a full revalidation process from the outset. This concept of a pan-cancer or modular 
approach to validation was presented as a potential mechanism for proportionate evidence 
generation. While such approaches may be conceptually feasible within a PCCP, the specific 
approach and requirements to do so successfully require further exploration.

## Page 30

Page 30 of 48 
 
4. Recommendations  
The recommendations in this section follow directly from the insights in Section 3. Each 
recommendation is grounded in evidence generated through the Phase 2 case studies, 
simulation workshops, and working sessions with ACE. For ease of reference, the key insight 
driving each recommendation is signposted where relevant. 
Cross-Cutting Recommendations 
Lifecycle considerations: pre-market evidence, post-market 
monitoring and human oversight 
For consideration by the MHRA: 
1. Provide guidance on principles/approaches for evidencing meaningful human oversight of 
AI systems and highlight when human-in-the-loop approaches are meaningful, how to 
demonstrate them, and how to evaluate when effectiveness may change over time.  
2. Establish how “State of the Art” for key AI technology areas could be defined centrally.  
3. Consider additional guidance on effective PMS reporting. In complement to this, ensure 
sufficient regulatory capacity and resource within the MHRA to meet any additional PMS 
needs. 
4. Yellow card and incident reporting serve a complementary function to PMS monitoring. 
Consider how vigilance and incident reporting mechanisms can be strengthened for 
AIaMD.  
For consideration by Manufacturers: 
5. Propose and validate appropriate human oversight arrangements for specific product and 
clinical contexts and monitor whether that oversight remains meaningful in practice as part 
of PMS obligations.  
6. Design validation studies with real-world deployment in mind, using real-world conditions 
wherever feasible. Consider post-market monitoring plans from the outset of design and 
development and address the performance factors that pre-market testing could not fully 
validate.

## Page 31

Page 31 of 48 
 
7. Document where training data or validation datasets underrepresent specific demographic 
groups or deployment contexts and specify how this will be addressed through PMS or 
PMCF. 
For consideration by Approved Bodies: 
8. Continue to assess the appropriateness of human review based on the product, its 
intended purpose and its clinical context, and consider how the adequacy of oversight can 
be evaluated and maintained across a product's lifecycle as applicable. 
9. Assess the adequacy of pre-market evidence in the context of planned real-world 
deployment, including whether the validation dataset and testing environment are 
sufficiently representative of the intended deployment context.  
Guidance hierarchy and collaborative development 
For consideration by the MHRA: 
10. Publish broad guidance that explains in practical terms how to apply the regulatory 
framework to AI medical devices specifically. 
11. Publish more detailed application guidance on specific topics, such as PCCP design, 
significant change assessment and performance metric selection. Some such guidance 
may be developed in collaboration with or primarily by other entities as appropriate, and 
the scope and utility of each guidance within the broader policy landscape would benefit 
from further clarity.  
For consideration by Team AB: 
12. Develop collective guidance on AI-specific topics, published on behalf of the sector. Such 
guidance should be consistent with MHRA's legal framework and policy but can provide 
additional, practical application detail that may benefit manufacturers. 
13. Publish best practice examples to facilitate consistency and clarity for manufacturers 
where possible, in collaboration with the MHRA where appropriate. 
Scope, Qualification and Validation 
Intended purpose as a lifecycle obligation 
For consideration by the MHRA:

## Page 32

Page 32 of 48 
 
14. Clarify further that maintaining device performance consistent with intended purpose is a 
lifecycle obligation rather than a market-entry declaration and provide AI-specific 
examples of medical intended purposes. Guidance could address how manufacturers can 
demonstrate device operation remains aligned with stated intended purpose and what 
signals should prompt a manufacturer to seek regulatory input.  
15. Provide additional resources such as training and education for other stakeholders in the 
regulatory ecosystem to support consistent interpretation and application of new or revised 
guidance.  
16. Consider whether publication of intended purpose statements alongside device 
registrations would be a practical step to improve public visibility and enable comparison 
across products. 
For consideration by Manufacturers: 
17. Treat intended purpose as evidenced through product design, output constraints, 
monitoring metrics and human oversight arrangements, not simply by a label applied at 
market entry. Where a product is developed iteratively, conduct periodic scope reviews 
that consider the impact of feature interactions, not only individual additions.  
For consideration by Approved Bodies: 
18. Specify what evidence is needed to maintain ongoing conformity with stated intended 
purpose across the device lifecycle and publish best practice examples where possible. 
Consider where example outputs and user journeys should be requested to support 
qualification assessment. 
Qualification based on function and context 
For consideration by the MHRA: 
19. Update software qualification guidance to address AI-specific features and the ways these 
functions may be used for a medical purpose. Guidance could address output 
decisiveness, clinical specificity, user population and the likelihood of influencing 
diagnosis or clinical management when describing how the nuances of a device’s intended 
purpose may be demonstrated.  
For consideration by Manufacturers: 
20. Demonstrate product function and purpose through example outputs and user journeys. 
Qualification cases cannot effectively rely on wording choices or disclaimers alone. Where

## Page 33

Page 33 of 48 
 
products sit near the qualification boundary, engage with MHRA such as via 
info@mhra.gov.uk before deployment rather than after. 
Ecosystem-wide approaches to ensuring responsible deployment 
For consideration by all Stakeholders: 
21. Consider ecosystem-wide approaches to ensuring responsible deployment and 
accountability for products that are not medical devices. Risk-proportionate and consistent 
governance approaches for products that may not meet the definition of a device but may 
be used in healthcare will help to ensure users and deploying entities have adequate 
visibility and clear accountability for these products.   
For consideration by Manufacturers: 
22. Consider how to provide transparency about products so that users and deployers can 
understand how to select and use appropriate products safely, regardless of regulatory 
status.  
AI-Powered IVDs 
Performance metric selection and validation 
For consideration by the MHRA: 
23. Provide AI-specific guidance on performance metrics and selection for AI IVDs, focusing 
on worked examples and practical approaches and addressing the circumstances in which 
additional metrics add value, and how analytical performance concepts can be adapted 
for AI systems.  
For consideration by Manufacturers: 
24. Select and justify performance metrics by reference to their device's design, clinical 
context and intended comparator. Where deviation from traditional metrics is proposed, 
provide explicit rationale.  
25. Implement change management documentation from the outset and design explainability 
approaches in close collaboration with clinical users. 
For consideration by Approved Bodies: 
26. Encourage engagement with manufacturers early on validation design, and work to pre-
agree categories of change and associated thresholds for regulatory notification. Where

## Page 34

Page 34 of 48 
 
representative validation data is difficult to obtain, consider providing clarity on what may 
be practical and sufficient. 
PCCPs and PMS 
For consideration by the MHRA: 
27. Develop statutory PCCP provisions and supplementary guidance. To be most effective, 
guidance should cover PCCP structure covering modification scope, PMS linkage, trigger 
logic, acceptance criteria, version control and rollback arrangements. 
28. Provide clarity on significant change in an AI-specific context, aligned with the broader 
MD significant change framework, which addresses context-based assessment covering 
intended purpose, clinical role, autonomy, oversight, benefit-risk and cumulative change.  
For consideration by Manufacturers: 
29. Design PCCPs from the outset of product development, integrated with risk management 
and PMS plans, rather than as a retrospective exercise. Manufacturers may want to 
consider explicit PMS-to-PCCP conditional logic: which monitored metrics, at which 
thresholds, will enable, pause or terminate planned changes.  
30. Justify performance thresholds using clinical as well as statistical reasoning. Where 
subgroup performance is clinically relevant, subgroup monitoring should be included in 
PMS plans. Further, monitoring approaches may benefit from including behavioural 
signals of oversight quality, particularly where human oversight is intended as a risk 
control. 
For consideration by Approved Bodies: 
31. Engage early with manufacturers on PCCP design as part of conformity assessment, 
with pre-agreed changes and thresholds to support efficient and consistent assessment.

## Page 35

Page 35 of 48 
 
5. Evaluation Approach and Key insights  
Evaluation Scope and Objectives 
An independent evaluation partner, Woodnewton, was appointed to evaluate phase 2 of the 
AI Airlock programme. The use of an external partner provided independent perspectives, 
supported objectivity in assessing programme performance, and enabled the programme to 
draw on specialist evaluation expertise. The scope of the evaluation was to cover all key 
aspects of the programme.  
 
Figure 4 Pictographic representation of the key areas of focus for the AI Airlock programme evaluation 
This evaluation explored the experiences of participating firms, including whether the 
programme met their expectations and how it could be improved or scaled. It assessed 
stakeholder and partner engagement, as well as patient perspectives on AI in healthcare, and 
examined the programme’s wider impact across the AI, health and MedTech sectors (Figure 
4). It also captured the views of programme team members on delivery experience and 
feedback, supporting an overall assessment of the programme’s effectiveness, maturity and 
future development needs. There were three core objectives of the evaluation exercise: 
• 
Assess delivering against objectives and areas of improvement: To understand the 
extent to which the Airlock is meeting its objectives, progressing towards a business-
as-usual model, responding to regulatory challenges, building partnerships, and 
strengthening team capacity and capability.  
• 
Evaluate continual improvement and learning: To assess how phase 2 has incorporated 
lessons from pilot, improved engagement and processes, and generated learning that 
can inform sandbox approaches within MHRA and wider regulatory settings. 
• 
Consider future scalability and development: To explore how the Airlock model, ways 
of working, frameworks and product testing environments could be scaled to respond 
to evolving needs in AI and health technology.

## Page 36

Page 36 of 48 
 
Evaluation Methods and Evidence Base 
The evaluation used a mixed-method approach, drawing on programme documentation, 
delivery data, stakeholder feedback, participant insights, patient perspectives and programme 
team reflections (Figure 5).  
 
Figure 5 Methods used in the AI Airlock programme evaluation approach 
The evidence base for the evaluation activities comprised learning from pilot, briefing materials 
on the programme participants and their technologies, topic guides, questionnaires, horizon 
scanning or challenges and risks, and programme planning documents. 
Lessons Learned and Recommendations 
Key Strength in Programme Delivery  
AI Airlock phase 2 was widely praised for its sandbox methodology, effective programme 
management, and creation of a trusted space for open, high-value engagement between 
regulators, industry and wider stakeholders, successfully meeting its objectives to both share 
pilot learning and explore new regulatory challenges. Survey and qualitative feedback show 
consistently strong satisfaction with delivery, communication and stakeholder inclusion, 
alongside clear evidence of organisational learning and capability building within MHRA. 
The main area for improvement is strengthening tangible learning on potential regulatory 
solutions, with stakeholders expecting clearer guidance and regulatory impacts to emerge as 
the programme progresses into phase 3. 
Qualitative: capture detailed insights from participants through semi-structured 
conversations tailored to each stakeholder group 
Ethnographic: observing selected programme activities to understand how 
effectively participants, stakeholders and programme teams engage, collaborate 
and co-create solutions in practice. 
Quantitative: gather broader feedback from a wider sample of stakeholders, 
combining scaled questions with open responses to evidence needs, 
expectations and experiences.

## Page 37

Page 37 of 48 
 
Focus on Simulation Workshops 
The Airlock phase 2 Simulation Workshops were a core element of the programme and were 
widely seen as a valuable forum for open, cross-disciplinary exchange between MHRA, 
industry and other experts. Survey and qualitative feedback were strongly positive on the 
quality of pre-workshop information, including the informative baseline presentations set at the 
start of each workshop, clarity of purpose and the value of joint discussion, though some 
participants felt that the sessions could be overly theoretical, unevenly facilitated, or dominated 
by those with stronger regulatory expertise.  
Stakeholder quote: 
“It’s an excellent, innovative programme of work and the team are brilliant – we are really 
pleased to be involved.” 
Stakeholders Suggestions for Improvements 
Feedback clustered around five themes: improving timelines and process efficiency, reducing 
administrative burden and improving meeting effectiveness, providing clearer terminology and 
upfront onboarding, better deployment of expertise, and strengthening the translation of 
discussions into tangible outputs.  
While participants valued the learning, engagement and clarity gained for individual use cases, 
the most consistent concern was the need for clearer, system-level regulatory guidance and 
policy change emerging from the AI Airlock. Overall, stakeholders remain supportive of the 
programme but emphasised that its long-term credibility will depend on demonstrable 
regulatory impact and clearer outputs in future phases.

## Page 38

Page 38 of 48 
 
 
Figure 6 Diagram overview of the 5 key themes of areas for improvement from the Woodnewton programme evaluation 
report 
The six-month phase 2 engagement period created delivery pressures due to the short, 
focused timing, and managing multiple workstreams in parallel. Airlock technical experts 
highlighted that testing timeframes between 6-12 months would be more appropriate. 
Stakeholders highlighted the need to reduce administrative burden and make roles and 
expectations on time and resource commitments clearer. They also called for clearer 
terminology and stronger onboarding for innovators and experts. Greater deployment of 
expertise was recommended, including more embedded technical AI capability, stronger 
senior sponsorship, and improved patient and clinician engagement. Stakeholders also 
highlighted the need for greater interaction with other sandbox participants and innovators. A 
key priority remains translating programme insights into tangible regulatory guidance, policy, 
and wider sector impact. 
Stakeholder quote: 
“Great forum for open discussion between various stakeholders. Good to dig into details and 
get perspectives across different sets of expertise – fantastic that manufacturers, consultants 
and MHRA are all in the same room to align.” 
Future Focus Areas 
Participants recommended that phase 3 should address both emerging and persistent 
regulatory challenges and technology, including generative and agentic AI, post-market 
surveillance, lifecycle management, and a range of cross cutting issues such as evidence 
standards, cybersecurity and global harmonisation. Many stakeholders emphasised the value 
Timings and process 
efficiency 
Administrative burden 
and meeting efficiency 
Terminology and 
upfront clarity 
Expertise deployment 
Tangible outputs and 
translation 
Feedback themes 
for improvement

## Page 39

Page 39 of 48 
 
of deeper exploration of learnings from pilot and phase 2 where this would generate new 
insight, alongside new topics. There was also a clear call for a more strategic, system-level 
examination of AIaMD regulation and integration, deployment and adoption challenges, 
recognising the disruptive nature of AI and the limitations of applying traditional regulatory 
approaches. 
The three-year funding for phase 3 presents a significant opportunity to consolidate learning 
from earlier phases and evolve the AI Airlock model while retaining its successful sandbox 
approach. Woodnewton’s reflections highlight several priorities for adaptation and 
improvement: 
• 
Experiment with more agile, multi-model engagement approaches, or iterative testing 
cycles across multiple environments rather than replicating previous formats. 
• 
Simplify and clarify terminology, governance structures and administrative processes. 
• 
Strengthen advisory capacity through a larger, more flexible expert committee and 
enhanced patient and public involvement. 
• 
Prioritise the translation of Airlock insights into tangible regulatory guidance and 
demonstrable impact on MHRA business-as-usual practice. 
Stakeholder quote: 
“The real value will come when the learnings from Airlock are translated into guidance and 
regulation.”

## Page 40

Page 40 of 48 
 
6. Conclusion and Next Steps 
The three regulatory challenge areas investigated in phase 2 of the Airlock: scope of intended 
purpose and validation, performance evaluation for AI-powered IVDs, and lifecycle change 
management are not isolated technical questions. They are interconnected challenges derived 
from the same underlying problem: maintaining regulatory confidence throughout the lifecycle 
of devices that have complex behaviour, outputs and risks can shift over time, intentionally or 
unintentionally. 
The evidence generated through Phase 2 suggests that the existing framework requires 
targeted clarification, practical guidance and, in some areas, formal statutory development to 
keep pace with the realities of AI deployment. The programme has identified areas where 
those developments are needed and tested practical approaches with real products and real 
stakeholders to develop its recommendations.  
In bringing together innovators, regulators, and healthcare providers, the AI Airlock has 
demonstrated how collaborative, iterative approaches can drive the safe regulation of AI. Its 
impact extends beyond individual use cases, contributing to a broader shift in how emerging 
technologies can be evaluated and governed within the UK healthcare system. 
The recommendations here represent important input for future policy and guidance 
development. Translating sandbox findings into durable regulatory change requires sustained 
effort across the MHRA and other stakeholders, and that translation is one of the defining 
challenges for Phase 3. The AI Airlock is well placed to support it, with three-year funding 
secured for the next phase to create the conditions to do so with the depth, continuity and 
ambition the task requires.  
Phase 3 
The Department for Health and Social Care has awarded the AI Airlock funding to develop the 
programme further over the next 3 years. This third phase will allow the MHRA to further 
develop the regulatory sandbox framework, addressing more complex regulatory challenges, 
in greater depth, with increasingly innovative technologies and systems.  
The AI Airlock signals a step change in how the UK approaches innovation in healthcare, 
balancing pace with safety, and ambition with accountability. As the programme matures, it 
will continue to shape not only individual technologies, but the wider ecosystem in which AI is 
developed, assessed, and adopted. Learnings from this report will influence the coming 
months of programme refinement and redesign. The programme will continuously embed the 
lessons highlighted by the stakeholder insights and candidate experiences captured by 
Woodnewton.

## Page 41

Page 41 of 48 
 
While the key insights from the regulatory analysis and innovator case studies have informed 
the work of the National Commission this year, equally the programme anticipates the 
recommendations of the Commission will influence the key priority areas that the AI Airlock 
may be best placed to address. Alongside the MHRA’s upcoming 5-year Strategy, we are well 
aligned with wider Agency priorities and objectives.  
Key pillars for the AI Airlock strategy in the next phase are to continue to refine the programme, 
become more efficient and fully effective to deliver tangible outputs to benefit the sector, 
healthcare providers, and patients. We will aim to do this in several ways. 
Enhancement: focus on key foundational needs for regulating cutting edge 
technology that are impacting innovators, regulators, and the healthcare sector and have 
been surfaced over the prior phases of work. Explore options for maturing and targeting 
the Airlock’s delivery by providing enhanced testing environments and considering the 
Airlock’s positioning to address both integration and access challenges, and international 
regulatory challenges. 
Efficiency: continuously improve the processes and methodology of the regulatory 
sandbox, balance resources in the most effective way and streamline the workflow while 
experimenting with more agile methodologies for testing. Learnings from the evaluation 
reports in key areas including timeframes for testing, information sharing and thematic 
cohesion of regulatory challenges will be implemented. Take steps to fully embed into 
business operations and envision the lasting and sustainable role the AI Airlock can serve 
within the MHRA. 
Effectiveness: Maximise the impact of the insights and the outputs of the Airlock 
testing, addressing a key learning from this phase to prioritise translation of the evidence 
into policy, resource development, and regulatory change. Use the learning from the prior 
phases of the Airlock to explore critical challenges further and at depth with purpose.   
As the UK’s National AI Strategy continues to prioritise innovation, safety, and public trust, the 
Airlock provides a critical bridge between policy intent and innovation development and 
design. Its ongoing evolution will not only accelerate future regulatory advances for the UK but 
also responsible innovation across the NHS, ensuring that the UK remains at the forefront of 
high quality, AI-enabled healthcare.

## Page 42

Page 42 of 48 
 
Appendices 
Appendix 1: Sandbox Methodology  
Applications, sifting and selection  
The application to join the second phase of the AI Airlock was open between June and July 
2025 and the programme received 51 diverse applications from developers.  
Most applications were received from micro and small enterprises (76%) with some from large 
enterprises (8%), universities (8%) and government entities, namely NHS. This is similar in 
representation to the pilot cohort and reaffirms the value of the Airlock for smaller 
organisations. Similarly, most applications were from products that were within operational 
prototype stage or pre-clinical (68%), while post market products made up 14% of the 
applications, either recently launched or within the first 3 years. The remaining applications 
were from products in concept or design verification stages.  
Represented AI technologies were predominantly Generative AI, Large Language Models 
(LLMs), Natural Language Processing (NLP), Deep learning and predictive models. AI-driven 
functions across these products including decision support, risk prediction, diagnosis and 
information retrieval and summarisation. Most of the products described in the applications 
were disease agnostic, meaning they could be applied to multiple clinical areas. Other 
prevalent clinical areas include oncology, mental health, orthopaedic and weight management. 
Applicants were asked to indicate their specific regulatory challenge as part of the application 
form and the most commonly selected challenges, of the 22 identified were clinical or 
performance evaluation (12%), Human AI interactions (13%), post-market challenges (8%), 
Scope of intended purpose (7%), and international alignment (7%). 
Applications were processed similar to the pilot programme methodology, and a longlisting 
process was carried out against specific eligibility criteria to select applicants to attend a 
selection interview. The programme team provided a review to finalise the candidates, 
applying a portfolio approach, and decision by the Governance Board before communicating 
the offer to the successful candidates.  
Portfolio Structure  
Figure 7 provides an overview of the tiered approach to the portfolio, working with multi-
environment and simulation-only candidates within multiple regulatory challenge areas. This 
has enabled an increased breadth of learning, from across multiple product types, within the 
same challenge area, allowing the Airlock to gather a rich picture of learnings. The multi

## Page 43

Page 43 of 48 
 
environment candidates worked with the AI Airlock team to test the regulatory challenge in 
more than one of the AI Airlock’s testing environments, described as follows: 
Simulation environment: a focused roundtable workshop bringing together multiple 
stakeholder perspectives to address simulated testing scenarios 
Virtual or Research environment: testing of the AI product in a controlled data environment 
to address specific research questions and generate evidence 
Real-world environment: deployment of a product in the intended purpose environment, 
separate from the clinical pathways and decision-making processes, to generate evidence of 
the product’s performance without impacting the healthcare outcomes. “Real-world testing” for 
purpose of the Airlock indicates use of retrospective or synthetic data and is not a clinical 
investigation.  
The Simulation environment candidates participated in the Simulation environment only. 
 
Figure 7 Overview of how the phase 2 AI Airlock portfolio has been structured across multiple regulatory challenges, with 
multi-environment and simulation only candidates layered throughout the portfolio 
Sandbox Testing Approach 
Following candidate selection, the programme team then worked to onboard the innovators. 
As with the pilot programme, the phase 2 projects followed a structured four-step delivery 
approach. The phase 2 cohort generated 7 case studies, across 3 key regulatory challenges. 
Three simulation workshops were held in February 2026 and each multi-environment 
candidate also carried out virtual and real-world testing.

## Page 44

Page 44 of 48 
 
 
Figure 8 Overview of the workflow for the multi-environment and simulation candidates throughout the testing phase of AI 
Airlock phase 2. 
Situation assessment and test plan development 
During onboarding of the candidates, a comprehensive situation assessment was carried out. 
This involved working collaboratively with the candidate teams to better understand the 
product and the regulatory challenge to be investigated. Testing plans were co-developed, 
detailing bespoke testing design, across various testing environments and deployment 
methods.  
Regulatory gap analysis  
Regulatory gap analysis is the structured process of identifying areas within the existing 
regulatory framework where legislation, standards, or guidance are ambiguous, incomplete, 
outdated, or insufficiently aligned with the characteristics and risks of AIaMD. This process 
was led by the AI Airlock review team, with support from regulatory specialists, technical leads, 
and relevant stakeholders, to ensure a coordinated and expert-informed assessment.  
Virtual / real world testing 
Virtual and real-world testing was conducted across the three multi-environment candidates 
over approximately 5 months of the programme period. Following the close of testing, 
candidates spent approximately one month on analysis. The programme team provided 
support to candidate teams, including ongoing regulatory and technical input at key decision 
points, supporting candidates in interpreting emerging findings in the context of their regulatory 
challenge and refining the framing of results ahead of analysis.

## Page 45

Page 45 of 48 
 
Simulation workshop collaboration  
The workshops were jointly facilitated by PHG Foundation, a not-for-profit health policy think-
tank that works with various stakeholders to understand how new technologies could 
improve healthcare and health outcomes. Each workshop was designed to cover key focus 
areas from each candidate’s testing plan.  
Table 2 Overview of the Simulation workshop's key focus areas 
Regulatory 
Challenge 
Key focus areas 
Scope of 
intended 
purpose 
• The scope of intended purpose workshop examined how to distinguish 
medical from non-medical AI products, using objective criteria such as 
indicative language and risk-based justification.  
• Sessions explored real-world signals for detecting early use and function 
changes, and how added functionality, system integration and deployment 
context can impact a product's classification, alongside the effectiveness 
and limitations of controls for managing drift and off-label use. 
PMS & 
PCCPs 
• The PMS and PCCPs workshop examined how PCCPs can be defined, 
structured and operationalised in practice, including the evidence, validation 
criteria and assurance requirements needed to support them.  
• Sessions explored the integration of PMS and PCCPs across the AIaMD 
lifecycle, the challenge of defining "significant change", and how findings 
could inform the development of future regulatory guidance. 
AI as an IVD 
• The AI as an IVD workshop examined how pre-analytical variability, 
including differences in slide preparation, staining, digitisation, scanner 
hardware and image quality, affects AI-powered IVD performance and what 
infrastructure, standards and governance mechanisms are needed to 
address this.  
• Sessions also explored the limitations of the traditional IVD framework for 
AI and considered practical regulatory approaches for managing adaptive 
AI-powered IVDs, including update triggers, drift monitoring and post-
market change management, with the aim of informing clearer expectations 
for the development, evaluation and ongoing management of these 
devices.

## Page 46

Page 46 of 48 
 
The workshops included a plenary session, for all experts to discuss focused questions in 
table discussions and interactive scenarios, followed by break out rooms that were each 
focused on a specific candidate’s product and challenge. Delegates represented a broad 
range of expertise and organisations including MHRA, Team AB, NHS clinicians, patient and 
public representatives, Information Commissioners Office, Health Research Authority, Care 
Quality Commission, academia and Centre’s of Excellence in Regulatory Science and 
Innovation, NICE, AI technical experts, and the innovators.  
Insights from the workshops were refined and used to inform the candidate case studies. Full 
reports of the simulation workshops can be found on the AI Airlock website.  
Insight generation  
Insights were extracted from candidate case study reports, simulation workshop outputs, and 
the regulatory gap analysis conducted across the cohort. Thematic analysis was applied to 
identify convergent findings within and across the three regulatory challenge areas, with cross-
cutting themes surfaced through structured comparison of evidence generated by both multi-
environment and simulation-only candidates. Key findings were validated through the 
simulation workshops, where expert delegates reviewed and stress-tested emerging 
conclusions across stakeholder perspectives. 
Appendix 2: Programme Design and Governance  
Team and Governance Structure:  
 
Figure 9 AI Airlock Phase 2 Governance Structure

## Page 47

Page 47 of 48 
 
Phase 2 adopted the same overarching governance structure as the Pilot with delivery centred 
on a core project group comprising the participating organisation and the AI Airlock team. The 
AI Airlock team includes both delivery and regulatory technical capability: the delivery team 
manages programme coordination, planning, governance, stakeholder engagement and 
delivery tracking, while the regulatory technical team provides specialist input on regulatory 
questions, testing approaches and the interpretation of evidence generated through the 
Airlock. 
This core group was supported by the Airlock Committee of Experts (ACE), previously referred 
to as the Airlock Supervisory Committee during the Pilot and rebranded in Phase 2 to more 
accurately reflect its advisory role and breadth of specialist expertise. ACE brings together 
representatives from government, other regulators, UK Approved Bodies, clinical practice, 
academia and technical AI specialists, including expertise relevant to data protection, research 
governance, care quality, clinical safety and AI assurance. Its role is to provide targeted 
challenge, specialist input and cross-sector perspectives to support project teams in exploring 
technical, regulatory and implementation questions.  
The core project group and ACE report into the AI Airlock Governance Board, a clinician-led 
strategic board with representation from DHSC, MHRA, academia, clinical practice and 
industry. The Board provides programme-level oversight, supports decision-making, and 
considers escalated risks, issues and complex technical or regulatory questions. In Phase 2, 
the governance model was also complemented by an overarching programme evaluation 
activity, delivered by independent partner Woodnewton, to assess how the programme is 
demonstrating continuous improvement and to capture learning and experience to inform the 
design of future Airlock rounds.  
Timeline and Milestones  
Phase 2 formally launched with a webinar on 19 June 2025, which announced the call for 
applications. The application window opened on 23 June 2025 and ran for three weeks, closing 
on 14 July 2025. This was followed by a structured sifting and shortlisting process across July 
and August. The 51 applications received during this period assessed against the published 
eligibility criteria. Shortlisted innovators were invited to interview and present their proposals. 
Following Governance Board ratification of the proposed portfolio and cohort in September, 
offer letters were issued to the selected candidates. Candidates started onboarding at the 
beginning of October and the AI Airlock 2 Kick-off Connect event was held on 16 October 2025 
to announce the cohort. The event provided an early opportunity for candidate and stakeholder 
engagement. Ideas for regulatory testing were also workshopped during the event. This was 
followed by orientation through situation assessment. Participants and the Airlock regulatory 
technical team subsequently co-created test plans during November and December 2025, with 
some activity extending into January 2026. Testing commenced on a staggered basis between

## Page 48

Page 48 of 48 
 
December 2025 and January 2026, supported by three in-person simulation workshops held 
in February 2026. Multi-environment candidates concluded their testing and analysis in 
between April and May 2026. In parallel, all candidates prepared case study reports to present 
their analysis, findings and learning from the programme. 
In April, the Department of Health and Social Care awarded multi-year funding to expand AI 
Airlock activities. At the point of drafting this report, the programme is drawing on learning from 
the Pilot and Phase 2 to inform the design of Phase 3.


---

# MHRA AI Airlock sandbox pilot programme report

- **Issuer:** MHRA
- **Type:** Report
- **Language:** en
- **Source:** https://assets.publishing.service.gov.uk/media/68ee1fb88427701993d5e02c/AI_Airlock_Sandbox_Programme_Report_Final.pdf
- **Licence:** OGL-UK-3.0

## Page 1

AI Airlock Sandbox Pilot Programme 
Report  
Published by the Medicines and Healthcare products Regulatory Agency (MHRA) 
 
Published October 2025

## Page 2

Page 2 of 77 
 
Contents  
Executive Summary ............................................................................................................. 3 
Applications and regulatory testing approach ................................................................. 3 
Regulatory gap key insights and recommendations ....................................................... 5 
Next steps ...................................................................................................................... 8 
1. 
Introduction and Context .............................................................................................. 9 
2. 
Programme Design and Governance ......................................................................... 12 
Sandbox Design ........................................................................................................... 12 
Programme Governance .............................................................................................. 14 
3. 
Candidates and Selection........................................................................................... 17 
Overview of applications .............................................................................................. 17 
Application review and sifting ....................................................................................... 18 
4. 
Regulatory Challenges and Projects .......................................................................... 20 
Case Study: Philips Healthcare - AutoImpression and the generation, assessment and 
validation of synthetic data ........................................................................................... 21 
Case Study: AutoMedica – SmartGuideline and mitigating risks of LLM hallucination and 
non-determinism ........................................................................................................... 32 
Case Study: OncoFlow – OncoFlow and the trade-off between explainability and clinical 
performance ................................................................................................................. 39 
Case Study: Newton’s Tree – FAMOS and continuous, real time post-market 
surveillance monitoring ................................................................................................. 47 
5. 
Simulations and regulatory gap analysis .................................................................... 52 
Regulatory mapping and gap analysis ......................................................................... 52 
6. 
Limitations and challenges ......................................................................................... 61 
7. 
Evaluation Approach and Key Insights ....................................................................... 64 
Evaluation Approach .................................................................................................... 64 
Evaluation Findings and Key Insights ........................................................................... 65 
8. 
Policy Implications and Recommendations ................................................................ 69 
9. 
Conclusion and Next Steps ........................................................................................ 72 
Plans for the next phase ............................................................................................... 72 
Acknowledgements ...................................................................................................... 73 
10.  Appendices ................................................................................................................. 74

## Page 3

Page 3 of 77 
 
Executive Summary 
The AI Airlock is the UK’s first regulatory sandbox for Artificial Intelligence as a Medical 
Device (AIaMD), developed and delivered in partnership with the NHS and the Department 
of Health and Social Care (DHSC). The pilot phase was launched in May 2024 and ran 
through to March 2025, aiming to explore the regulatory challenges faced by real-world AI 
medical devices and generate actionable insights to support the development of future 
guidance and regulatory changes. Key insights and recommendations generated through the 
AI Airlock will directly inform and support the work of the National AI Commission, ensuring 
that its outputs are grounded in real-world evidence and regulatory experience.  
Building on emerging global best practice and learnings from already well-established 
regulatory sandboxes in other sectors, we employed the sandbox mechanism to establish a 
safe space for medical device manufacturers to work directly with us.  Manufacturers also 
worked with the programme’s unique expert stakeholder network to design and execute 
bespoke testing plans to address current regulatory challenges associated with their AIaMD 
product. Regulatory sandboxes, like the AI Airlock, take regulators into uncertain areas of 
regulation. These represent the most contemporaneous regulatory problems that need 
urgent exploration, which often cannot be explored within normal business processes. 
Applications and regulatory testing approach 
Candidates were invited to join the AI Airlock via a public call for applications. The 
submissions received during this call were diverse: 31% of applications used generative AI, 
23% used machine learning, 13% predictive AI, and 10% multimodal systems. The most 
common clinical use cases were diagnostics (25%), screening/imaging (19%), and clinical 
decision support (19%). The clinical conditions spanned oncology, women’s health, 
respiratory care, and clinical workflow optimisation. Of the 40 applications received, 5 were 
taken forward to participate in the pilot and 4 successfully completed the full pilot.  
The AI Airlock testing approach was built around a four-stage delivery model: 
1. Orientation: Situation assessment to understand the pilot technologies and relevant 
regulatory context 
2. Plan: Regulatory gap review and test plan development 
3. Test: Testing conducted in different environments, including simulation, virtual, real-
world. Concurrently, in-depth regulatory gap analysis was conducted. 
4. Review: Synthesis of findings and recommendations.

## Page 4

Page 4 of 77 
 
The test plans employed 3 testing environments: Simulation, Virtual and Real-World 
Airlocks. Final outputs from each project included test plans, results from testing from 
regulatory gap analyses. 
Testing environments 
Simulation workshops involved experts across different disciplines: regulators, clinicians, 
technical experts, academics, legal representatives, and others. When testing in a virtual 
setting, candidates used a digital testing space built into or around an AI system, such as an 
AI model on a computer. Here, the AI functions were explored safely, allowing testers to 
interact with the AI, feeding it information or questions. They would then check how it 
responded and inspect how its internal processes worked. This mimicked real tasks, so 
teams could assess the accuracy, reliability, and reasoning within the AI itself. The real-world 
environment allowed testing in the setting where the AI product would be used (e.g. a 
hospital). The AI was used alongside doctors and real (anonymised) patient data, following 
the usual clinical processes, but its outputs were not used to make decisions about patients. 
Instead, the AI was observed in practice: how it fit into workflows, how accurate or helpful it 
was, and how safe and reliable it was for standard use.  
Regulatory gap analysis 
Our existing regulatory frameworks provide a strong foundation for ensuring the safety and 
effectiveness of medical technologies. However, AI introduces new characteristics such as 
continuous learning, complex data dependencies, and adaptive behaviour that challenge 
how some of these principles are applied in practice. That means parts of our framework will 
remain highly relevant, while others may need to evolve or be complemented by new 
approaches to ensure patient safety and public trust.  
Regulatory gap analyses are difficult to undertake; such analyses performed in such a novel 
field are particularly challenging. The team enlisted experts from various sectors in an initial 
regulatory mapping activity. This resulted in a collation of relevant regulatory documents and 
a list of associated challenges. To account for limited resource and programme timelines, we 
prioritised 5-10 most relevant regulatory documents for in-depth review per regulatory 
challenge.  
This foundational exercise proved extremely productive. By showing us how broad the term 
“regulatory gaps” could be in the context of novel AI devices, we could account for this in our 
definitions. We therefore used an equally broad definition to capture the gaps. This allowed 
us to capture wording gaps in existing guidance, context gaps in frameworks and even 
legislative loopholes.   
Within the AI Airlock, therefore, the term ‘gap’ is used as a shorthand term for identifying any 
areas of improvement. Recognising that many of the existing parts of the regulatory system

## Page 5

Page 5 of 77 
 
must cater for the millions of hardware and software products used in the health and care 
system. It is the objective of the AI Airlock to identify these areas for improvement and 
recommend solutions.   
Regulatory gap key insights and recommendations 
The AI Airlock pilot identified regulatory gaps that currently challenge the safe and effective 
deployment of AIaMD. While the nature of these gaps varied across use cases, some 
recurring themes emerged across all projects, particularly in areas of risk management, 
validation of text-based data from large language models (LLMs), AI errors, inaccuracies and 
non-determinism, explainability, and post-market surveillance. These gaps and challenges 
were explored in collaboration with four innovators: Philips Healthcare, AutoMedica, 
OncoFlow and Newton’s Tree. 
 
Synthetic Data and LLMs 
Current  Medical Device Regulations (MDR) 2002 and associated guidance do not define if / 
how / where synthetic data can be used to provide evidence of compliance. In addition, there 
is no guidance on quality or validation requirements for text-based synthetic data, despite 
the growing use of this data type in AIaMD. Standards such as BS/AAMI 34971 
acknowledge synthetic data as a potential input in AI model development and note the 
importance of managing privacy risks, though specific guidance for its use for privacy 
preservation is limited. During the pilot, we worked closely with the programme investigating 
the Synthetic data for development of AIaMD and therefore our recommendations are 
aligned with the findings of that report published after the AI Airlock pilot closure. The report 
addresses the AI Airlock recommendation for the MHRA to develop best practices for 
synthetic data generation, validation and assessment for fidelity and representativeness – 
particularly where the synthetic data are used to support regulatory submission in AIaMD 
development.  
In collaboration with Philips Healthcare, the AI Airlock explored the generation and 
assessment of 4,000 synthetic radiology reports which were generated using an LLM. While 
evaluation methods, including automated and human reviewers, showed promise in 
assessing quality, they also highlighted key regulatory uncertainties. Notably, the data from 
using an LLM to judge outputs from another LLM raised concerns about the errors and 
biases being reinforced rather than independently checked. This risk of ‘circularity’ means 
the system may not be fully reliable. This highlights the need for independent validation 
standards and more regulatory clarity. Given the limited timeframes of the AI Airlock pilot and 
complexity of the issues, further investigation is needed into AI validation of AI. The MHRA 
should therefore continue to investigate the use of LLMs in synthetic data pipelines (and AI 
evaluation of AI-generated data) with a focus on building an evidence base that can inform

## Page 6

Page 6 of 77 
 
future guidance on quality assurance, validation methods, and the acceptability of such data 
in regulatory contexts.   
Hallucinations, Non-Determinism and Risk Management 
The risk management framework underpinning the MDR 2002, and standards such as ISO 
14971, ISO 13485 and IEC 62304, offers a robust foundation for general medical device 
regulation. However, these frameworks were not designed to address the unpredictable and 
dynamic nature of AI systems. There is a lack of consensus on how to account for AI-specific 
risks such as hallucinations, non-determinism or model drift within existing risk management 
approaches. These risks could be viewed as falling within a manufacturer’s performance 
claims; however, outputs incorporated into the medical record are also subject to the Health 
and Social Care Act 2008, regulation 17. This creates a tension between different regulatory 
requirements, where clarity is needed on how performance considerations intersect with 
obligations relating to the accuracy of health records. 
The AI Airlock worked with AutoMedica and their product ‘SmartGuideline’ and explored how 
Retrieval Augmented Generation (RAG), could be used to ground LLM outputs in verified 
sources to reduce such risks. By anchoring responses in trusted clinical content (NICE 
guidelines), RAG added a safety layer to the system. In an experiment where 436 medical 
questions were asked, SmartGuideline (with RAG enabled) produced no hallucinations 
compared to 23 hallucinations from a baseline model. The RAG-based model also 
demonstrated consistent, deterministic outputs – returning highly similar results across 
repeated prompts. These results show how targeted AI design strategies can mitigate known 
risks. Through evidence from virtual testing and the simulation workshop discussions, the AI 
Airlock programme recommend that the MHRA should explore how such techniques could 
be accommodated within existing risk management frameworks. Safety measures such as 
retrieval augmented generation (RAG) should be encouraged in guidance, given the 
demonstrated ability to reduce hallucinations and support safer more explainable outputs. 
Guidance should also emphasise the importance of PMS, including mechanisms like the 
Yellow Card Scheme and Manufacturer’s Online Reporting Environment (MORE) as 
hallucinations may be rare during pre-market testing.   
Explainability and Transparency 
Terms such as explainability, transparency, and interpretability are not considered in the 
MDR 2002 and remain under-specified in current regulatory guidance. While standards such 
as ISO/IEC 22989 and BS/AAMI 34971 reference transparency, they do not outline specific 
explainability expectations for different user groups – such as regulators, clinicians, or 
patients. This lack of clarity is particularly important for AIaMD, which, unlike traditional 
medical devices, may adapt to data or clinical use over time. Such systems carry the risk of

## Page 7

Page 7 of 77 
 
model drift or unanticipated behaviour in situ, making explainability a mechanism to support 
trust, oversight, and safe integration into clinical practice. 
Together with OncoFlow, the AI Airlock explored multiple explainability approaches, 
interpretability and transparency. This work included plain-language explainability 
statements, model rationale outputs, and quantitative techniques for feature attribution. The 
project also tested how explainability requirements differ across stakeholder groups and use 
cases. While these methods showed promise when discussed with a range of stakeholders 
during a simulation workshop, stakeholders agreed that their application would benefit from 
clearer regulatory direction. This is particularly relevant for how explainability should be 
documented, communicated, and tailored to different audiences. The MHRA could usefully 
set out high-level expectations or best practices for explainability in AIaMD, supported by 
examples of appropriate methods and documentation formats tailored to different 
stakeholder needs.  
Post-Market Surveillance (PMS) and Real-Time Monitoring 
The PMS requirements manufacturers must meet are outlined in legislation including the 
Medical Devices (Post-market Surveillance Requirements) which amends the Medical 
Devices Regulations, 2002. Although this legislation came into force after the closure of the 
AI Airlock pilot, the workshop was based on the incoming requirements that are now in 
effect. These regulations are enacted by the MHRA via a vigilance reporting system, which 
includes the Manufacturer’s Online Reporting Environment (MORE). Additionally, the Yellow 
Card Scheme is available for medical device safety reporting more orientated towards 
reports from end users and patients. 
The sandbox confirmed that for PMS, systems such as Yellow Card and MORE offer 
reporting pathways and oversight of corrective action approaches. These are, however, not 
used enough by end users and manufacturers, and there is a clear need for AI-specific 
guidance on ongoing monitoring and preventative action. Risks such as model drift and 
automation bias are often only detected after harm has occurred, if they are detected at all. 
The FAMOS project demonstrated that real-time monitoring dashboards can help to surface 
emerging risks earlier, particularly around user behaviour. During testing, 180 reports were 
reviewed at two hospital sites and continuous real-time monitoring was used to detect data 
quality issues, model drift and automation bias. At one hospital site, the pilot identified a 
pattern of over-reliance on the AIaMD. If unaddressed, such over-reliance could increase the 
risk of harm. In this case, contributing factors included clinician fatigue, time pressure, 
distraction, and experience level. This reinforces the need for guidance on threshold setting, 
risk flagging protocols, and shared responsibilities for monitoring AI-human interaction. The 
MHRA should consider publishing supplementary guidance that supports proactive safety 
measures for AIaMD. This could include expectations on roles and responsibilities for 
monitoring across different settings.

## Page 8

Page 8 of 77 
 
Standards like BS EN 62366-1 and guidance on applying human factors to medical devices, 
cover usability but do not fully address AI-specific challenges such as explainability-driven 
over-reliance, deskilling, or automation bias. The pilot highlighted how clinician context, i.e., 
fatigue, time pressure, and experience, can affect safety outcomes, and that system design 
must account for these variables. Cross-sector collaboration is needed to ensure current 
guidance, training and support for users adequately address these challenges, particularly in 
high-risk environments. 
Next steps 
The AI Airlock pilot has underscored both the potential and the practical challenges of 
developing and deploying AIaMD. This work has culminated in recommendations for 
updates to policy and guidance, some of which have been outlined in this report. By taking 
these forwards, the MHRA can continue to bridge the gap between broad regulatory 
principles and the practical needs of deploying AI safely and effectively in healthcare. Clear, 
accessible guidance plays a crucial role in supporting innovation, safeguarding patient 
safety, and building public trust in AI-driven medical technologies.  
Next, these findings will inform the work of the National AI Commission, ensuring that its 
outputs are grounded in real-world evidence and regulatory experience. In addition, the AI 
Airlock recommendations will inform AIaMD guidance currently in development, and future 
MHRA regulatory policy including those outlined in the Software and AI as a Medical Device 
Change Programme roadmap. Areas requiring further exploration may be taken forward by 
the National Commission and MHRA partners or through the next phase of the AI Airlock 
programme.

## Page 9

Page 9 of 77 
 
1. Introduction and Context  
Background  
The independent investigation of the NHS in England highlights the critical state of health 
services. It revealed significant challenges including surging waiting lists, financial 
constraints, and a deteriorating national health profile. Emphasising the importance of 
innovation in medicines and medical devices to solve some of the healthcare system's 
problems and highlighting the potential of software and AI as a Medical Device (AIaMD) to 
enhance patient care. Only if these products are of high quality, safe, reliable, and robust.  
 
In the UK, Software as a Medical Device (SaMD) is regulated under the Medical Devices 
Regulations 2002, AIaMD is a subset of SaMD under IMDRF. Our reform of the medical 
device legislation, including the Software and AI as a Medical Device Change Programme, is 
driven by innovation in the life sciences sector, learnings from the Cumberlege review and a 
growing understanding of AIaMD products. It aims to deliver balanced regulation which 
ensures products meet the necessary standards for patient safety and efficacy, without 
hindering or blocking the path for innovation and growth. balanced regulation which ensures 
products meet the necessary standards for patient safety and efficacy, without hindering or 
blocking the path for innovation and growth.  
 
After all, AIaMDs have the potential to help solve a broad range of challenges facing the 
NHS. In radiology, for example, AIaMDs could analyse x-rays or scans for abnormalities and 
make recommendations, saving clinician time. In surgery, AI-powered robotic systems could 
assist in minimally invasive procedures by analysing real-time imaging to guide surgical 
instruments with sub-millimetre precision, reducing operating times and complications. 
Meanwhile, AI-enabled wearable devices could continuously analyse physiological data, 
detect early signs of disease exacerbation, and provide personalised alerts to patients and 
clinicians, supporting chronic disease management and potentially reducing the need for 
frequent laboratory tests. 
 
These innovative products also hold unique risk profiles. We, alongside AI developers and 
the government, must protect UK citizens from the most significant risks presented 
by AI.  Fostering public trust in the technology and particularly considering the interests of 
marginalised groups. To ensure a safe, efficient, and robust route to market for these 
innovative products, key regulatory challenges need to be identified and addressed 
systematically. 
 
The Government’s AI Opportunities Action Plan sets a clear priority to ensure AI 
development through regulation, safety, and assurance hopes to fuel a fast, wide, and safe 
deployment and adoption of AI. Regulatory frameworks must support the development and 
implementation of these innovative solutions. One of the best ways to deliver safe and 
effective regulatory transformation is through regulatory sandboxes.   
 
The regulatory sandbox model is an internationally recognised mechanism to help address 
novel regulatory challenges in many sectors. These include financial services, data and 
information and healthcare sectors. This mechanism tests innovative products, business

## Page 10

Page 10 of 77 
 
services and/or frameworks, often in a virtual environment separate from the market or 
sector they are influencing, ensuring safe and responsible product testing at pace. 
 
Regulatory sandboxes are increasingly used in the UK. Sandboxes can be utilised by a wide 
range of companies, from early start up developers to large scale organisations. Some 
notable examples include the NHS England test beds programme and the CQC’s using 
machine learning in diagnostic services. The Information Commissioner’s Office offers a 
regulatory sandbox service for products that utilise personal data in innovative ways, and the 
Financial Conduct Authority works with firms that want to test products with real consumers 
in a controlled environment.  
 
Sandbox offerings vary. Operational sandboxes can offer access to virtual controlled 
environments and data sets or alternative routes to market. Regulatory sandboxes bring 
together regulators and organisations to understand regulatory gaps and address 
challenges. The Data Institute published a comprehensive report analysing the use of 
regulatory sandboxes in the complex data space. The report highlights how sandboxes can 
reduce regulatory uncertainty and build capability. Further highlighting the opportunities in 
emerging, cross-border sandboxes, and notes the high resource requirements and 
difficulties to scale.   
 
Regulatory sandboxes provide the opportunity to address challenges often experienced by 
innovations. Naturally, applying an existing regulatory framework to innovative products, 
developers with lower regulatory knowledge, regulators with lower product knowledge, and 
general inexperience regarding the life cycle of innovation makes regulation and product 
development challenging. Regulatory sandboxes are well placed to drive the development of 
well-designed regulation that is proportionate, agile and offers clarity to developers and 
users, a key priority we share with the UK government. The AI Airlock regulatory sandbox 
has been developed to address the regulatory challenges and promote a pro-innovation 
approach to learning and experimentation as outlined in the Pro-innovation regulation of 
technology review .  
 
AI Airlock  
In May 2024, we announced the AI Airlock to test real world products and prototypes of 
innovative AI medical devices, in collaboration with Team AB (a coalition of UK Approved 
Bodies), the NHS AI Lab and Department of Health and Social Care (DHSC). 
 
Team AB brings expertise from Approved Bodies to increase consistency of interpretation of 
GB medical device regulatory requirements. It was integral to collaborate with Team AB on 
the AI Airlock project to uncover and navigate medical device regulatory challenges for 
AIaMD using our collective regulatory knowledge to inform and standardise policy positions 
in this rapidly evolving area. 
The NHS AI Lab provides connections and expertise within our healthcare system. Many 
AIaMD products are deployed via NHS infrastructure making NHS England and the health 
services in the devolved nations crucial to regulatory discussions such as deployment and 
post market surveillance.

## Page 11

Page 11 of 77 
 
This pioneering and unique work helps us to further understand the detailed challenges of 
regulating AIaMD products to ensure new regulations and guidance facilitate their rapid and 
safe deployment into the NHS. AI Airlock helps us to support UK innovators achieve 
regulatory compliance. 
 
Purpose of this report 
This report provides the outcomes from the AI Airlock pilot programme that ran between April 
2024 – March 2025. It will offer insights for key audiences across the UK healthcare, 
regulatory and digital technology sectors and international partners. Learnings from the pilot 
fall into 2 main categories:  
 
a) how to implement regulatory sandboxes to investigate and improve regulation  
 
b) suggested changes to the current regulatory framework, both for the MHRA and 
stakeholders across the healthcare system

## Page 12

Page 12 of 77 
 
2. Programme Design and Governance  
 The pilot had 4 key objectives for its first year: 
• to work with real world products or prototypes to evidence and investigate regulatory 
challenges with AIaMD  
• to use these case studies to generate recommendations for regulatory framework 
changes 
• to carry out a formal programme evaluation and learn lessons from the regulatory 
sandbox way of working  
• to secure future year funding streams 
To achieve these objectives, the dedicated MHRA programme team was created with two 
main work streams: operational programme management [governance, stakeholder 
management, risk management] and regulatory / technical case management 
Sandbox Design 
The AI Airlock pilot programme was intentionally designed to provide opportunities to explore 
all regulatory challenges for AIaMD, therefore needed to be agile enough to be able to work 
with candidates and products at any stages of their developments.  
The AI Airlock focused primarily on the GB medical devices regulatory framework. This 
framework of legislation and guidance is within the MHRA remit to amend and therefore it 
was a key priority for us to focus the sandbox on this key area where action could be taken 
rapidly.  
The MHRA ran a call for applications to the public, industry and academia for AIaMD 
developers to submit proposals to join the AI Airlock, with key eligibility criteria and testing 
environments used to design the pilot cohort. 
Eligibility Criteria 
Applicants needed to be aiming for the product to be a medical device, as defined by the 
MDR 2002, which utilised AI or Machine Learning. They needed to be a legal entity with the 
rights to market their product in the UK. Most critically, there needed to be a commitment to 
working with us throughout the sandbox testing. All applicants needed to meet these 
conditions for their application to be eligible.

## Page 13

Page 13 of 77 
 
Further criteria were then applied to the applications to shortlist the most eligible applicants. 
These criteria were: 
- 
The product has potential to deliver benefits for patients 
- 
The product or prototype is innovative or a novel application 
- 
The product presents a regulatory challenge 
- 
The proposal is ready to be trialled 
These criteria ensured that the candidates selected were most able to deliver results through 
the pilot programme rapidly, an important consideration given the condensed timelines for 
testing. 
 
Sandbox testing environments 
As a result of the broad testing opportunity, we established three key testing environments to 
be used in the sandbox.  
 
 
Simulation Airlock is a workshop or roundtable-based activity used to address focused 
questions and gather various perspectives on a challenge. This type of testing can be 
tailored specifically to a set of key challenge areas. During the pilot the simulation workshops 
begun with a short presentation to set the scene and a facilitate discussion was held along 
with some focused breakout sessions. We looked across our broad stakeholder network and 
brought together a unique cast list of colleagues to bring their unique perspectives to each 
problem area. This type of testing environment is very flexible and can be applied to 
challenges experienced by products maybe at concept or early development stage or those 
without access or the need for data or a testing environment.  
Figure 1 Overview of the three testing environments designed for the AI Airlock pilot: Simulation, Research/Virtual and Real World

## Page 14

Page 14 of 77 
 
Virtual Airlock is testing a model with real or synthetic data to address research scenarios 
to gather insights of how the model works. This mechanism is like a “test bed” function used 
to validate and verify AI models and products using specific data access through the testbed. 
During the pilot AI Airlock these virtual environments were provided by the candidates.  
Real world environment involves deploying a product in a hospital or trust without 
impacting patient care, that way it protects clinical pathways while gathering evidence from 
clinicians or hospital deployment. It is imperative that the products testing in the real-world 
sandbox are done so with appropriate oversight in order to protect patient safety and clinical 
pathways.  The real world environment is not a clinical investigation.  
Each of these testing environments have been tested as part of the pilot programme and will 
continue to be refined throughout subsequent phases of the AI Airlock.  
Programme Governance  
To support the AI Airlock pilot programme a new governance structure was established that 
included a Governance Board and Supervisory Committee. Each pilot candidate, upon 
onboarding, formed a project team with a dedicated case manager from the MHRA Airlock 
team. The project teams reported progress against the delivery plan, key technical 
information and regulatory challenges, via their case manager, to the Supervisory 
Committee and Governance Board. 
➢ Governance Board: ensure that a coherent strategic approach is adopted to manage 
successful delivery to time, cost and sufficient quality, of the AI Airlock programme 
outputs. Throughout the design and testing phases of the programme the 
Governance Board also provide a wealth of expert input to the AI Airlock technical 
case studies.  
➢ Supervisory Committee: oversee the operational and technical activity of the AI 
Airlock programme by providing an expert advisory function to the AI Airlock 
programme and the project teams within the cohort. Provide regulatory and scientific 
advice to the AI Airlock project teams in relation to specific regulatory sandbox testing 
plans, through active engagement at the Supervisory Committee meeting and 
correspondence from the AI Airlock technical team.

## Page 15

Page 15 of 77 
 
 
Figure 2 AI Airlock Governance Structure 
All members of these groups were bound by signed confidentiality agreements and 
declarations of interest which increased assurance to the candidates and MHRA of the 
integrity of the sandbox governance. The core team, governance groups and key partners 
enabled multidisciplinary expertise and collaboration from across the MHRA, government 
departments, devolved administrations, Approved Bodies and the wider healthcare sector.   
Timelines and Milestones 
The pilot programme ran in the 2024-2025 financial year. It was publicly announced that the 
MHRA would be developing the regulatory sandbox in May 2024 and work began to rapidly 
design and build the sandbox in parallel to building the team.  
 
Figure 3 Timeline of the AI Airlock pilot activity 
The design of the sandbox involved a comprehensive literature review of current and historic 
regulatory sandboxes. A network of stakeholders and experts from the AI technology and 
healthcare sectors alongside other government departments was established. Following the 
UK general election the AI Airlock held its first public webinar in July and shortly after, 
established its Governance Board and Supervisory Committee. Throughout Autumn 2024, 
we opened the call for applications for industry to join the sandbox, ran an intense and

## Page 16

Page 16 of 77 
 
comprehensive sifting and shortlisting mechanism and in November we designated the first 
cohort of candidates.  
Candidates were brought onboard into the AI Airlock, after signing non-legally binding terms 
of engagement and dedicated case managers were assigned.  The teams then worked 
together to design the sandbox testing plan. Throughout the winter, the project teams met at 
least weekly, to discuss the progression and developments of the testing plans in the 
Simulation, Virtual and Real-World testing environments. In March 2025 the pilot testing 
formally concluded, and candidates worked rapidly to produce their case study reports.  
The following chapters of this report will provide additional details behind the AI Airlock, 
candidate selection, regulatory sandbox testing methodologies, insights from the case 
studies including evaluation of lessons learned.

## Page 17

Page 17 of 77 
 
3. Candidates and Selection  
Overview of applications 
The call for applications to the AI Airlock was open from 23 September to 7 October 2024. 
Approximately 40 applications were received, assessed and underwent a structured sifting 
process. Of the products applying: 
• 31% used generative AI, 23% used machine learning, 13% used predictive AI  
• The most common clinical uses were diagnostics (25%), screening or imaging (19%), 
and clinical decision support (19%).  
• Clinical areas included oncology (15%), clinical workflows (12%), women’s health 
(9%), chronic respiratory disease (9%), and health monitoring (9%).  
 
Reflecting the complexity and evolving nature of the regulatory landscape for AI 
technologies, applicants identified regulatory challenges across the full product lifecycle, with 
most applications highlighting more than one area of uncertainty. The most cited challenge 
was borderline classification. Determining whether the product’s intended purpose and 
functionality would qualify as a medical device was specifically challenging. Other areas of 
focus included risk classification, product training and validation, bias, explainability, 
reliability, post-market surveillance, and change control. Notably, most applications came 
from the micro and small SME sector, reflecting a strong presence of early-stage innovators, 
or a greater willingness within this group to engage with regulatory challenges. Fewer 
applications were received from large enterprises and academic institutions, perhaps due to 
the more complex and time-consuming internal approval processes typically required in 
these institutions exceeding the short application window. 
 
Figure 4. Applications by organisation size and type. Around 44% of applications were submitted by micro-SMEs with fewer 
than 10 employees, 33% by small SMEs with 10-50 employees, and the remaining 23% were split between medium and 
large enterprises and academia. 
Micro SME <10 
employees: 17
Small SME 10-50 
employees: 13
Medium SME >50 -250 
employees: 4
University of academic 
institution: 3
Large Enterprise 
>250 employees: 2
Organisation size and type

## Page 18

Page 18 of 77 
 
Application review and sifting 
Each application was assigned to two reviewers from within the AI Airlock programme team: 
a lead reviewer and a second reviewer. The lead reviewer assessed the application against 
the eligibility criteria outlined in the application form, while the second reviewer conducted an 
independent review using the same criteria. If both reviewers agreed that an application met 
the required standards, it progressed to the next stage. If both reviewers agreed it did not, 
the application was deemed unsuccessful. Where there was disagreement between the 
reviewers the application was discussed in a group setting to reach a decision. This could 
result in the candidate being invited for a follow-up interview or being informed that their 
application was unsuccessful.  
 
 
Figure 5. Application review and sifting. Each application was reviewed by members of the AI Airlock team and followed the 
same decision-making process which culminated in progression to interview or an unsuccessful application.  
Aside from the eligibility criteria, other mandatory success criteria were measured. 
Applicants needed access to their own data and testing environment (if utilising a virtual or 
real-world Airlock), and the product had to be ready for testing. Reviewers also considered 
the focus of the regulatory challenge to be explored, the type of technology proposed, and 
the level of resource commitment available from both the applicant and the Airlock team. 
Through this process, a shortlist of nine candidates was selected.  
A final pilot cohort of five candidates were chosen following interviews with the shortlisted 
candidates, considering deeper insight into their technologies, applicant readiness and 
resource availability. This was reduced to four candidates following the withdrawal of one 
participant after the organisation went into administration (an insolvency process).  
The pilot cohort regulatory challenge areas spanned the product lifecycle. The Airlock team 
selected challenges related to data generation for training and validation, AI hallucinations, 
AI explainability, and post-market surveillance. While the majority (three out of four), had 
initially expressed interest in also exploring the borderline qualification question, time and 
resource constraints limited the feasibility of addressing such a broad spectrum of

## Page 19

Page 19 of 77 
 
challenges. The Airlock team, aware that other regulatory partners would be exploring these 
areas in greater depth, decided to prioritise the novel and unexplored challenges.  
Table 1. Overview of candidates, regulatory challenges and key objectives to be explored 
during the pilot programme 
Candidate & 
Product Details 
Regulatory challenge 
Key Objectives 
PACS Radiology 
AutoImpression 
Philips Medical Systems 
Large language model 
Radiology 
• 
Validation of synthetic 
datasets generated by an 
LLM 
• 
Use of LLMs to validate 
synthetic data 
1. Understand the parameters that 
define good quality synthetic data 
2. Challenges involved in using an 
LLM to generate synthetic data  
3. Use of LLM to validate synthetic 
data  
SmartGuideline 
by AutoMedica 
Large language model 
Clinical workflows 
• 
Reducing hallucinations and 
non-determinism in LLMs 
4. Evaluate LLM technology to 
establish how retrieval augmented 
generation (RAG) performs in 
reducing hallucinations  
5. Explore how to enhance quality of 
recall 
OncoFlow by OncoFlow 
Large language model 
Oncology 
• 
Assessing approaches to 
LLM explainability and any 
trade-off with clinical 
performance 
6. Compare clinical performance, and 
explainability of traditional NLP 
models vs LLMs on unstructured 
oncology data 
7. Explore methods to make AI 
models explainable 
Federated AI Monitoring 
Service (FAMOS) 
by Newtons Tree 
Virtual Environment 
Radiology 
• 
Improving AIaMD safety 
through real-time monitoring 
of key metrics (model drift, 
data quality and automation 
bias) 
8. Assess the effectiveness of a real-
time monitoring system in 
enhancing the monitoring of third-
party AI medical devices to 
improve their safety  
9. Understand reporting 
responsibilities of different 
stakeholders when a trend that 
may lead to harm is identified

## Page 20

Page 20 of 77 
 
4. Regulatory Challenges and Projects  
This section of the pilot programme report provides an in-depth look at the approach used to 
address the selected regulatory challenges within the AI Airlock. It is followed by individual 
case studies – Philips AutoImpression, AutoMedica SmartGuideline, OncoFlow, and 
Newton’s Tree FAMOS. Each case study outlines the specific regulatory challenge explored, 
the underlying hypotheses and objectives, the testing methodologies used, and key findings 
from testing in virtual or real-world hospital settings. 
Overview of regulatory challenges and technologies 
Approach and activities overview 
The AI Airlock projects followed a structured four-step delivery approach. 
1. Orientation: Situation assessment to understand the pilot technologies and relevant 
regulatory context 
2. Plan: Regulatory gap review and test plan development 
3. Test: Testing through simulation, virtual, real-world, or hybrid environments; deeper 
regulatory gap analysis conducted 
4. Review: Synthesis of findings and recommendations 
In the first step, the AI Airlock team undertook a situation assessment to understand the 
candidate technologies. Together, the AI Airlock and candidate teams (referred to hereafter 
as project teams) collaboratively examined the current regulatory landscape. This review 
drew on regulatory documents identified by the project teams, and supervisory stakeholders, 
particularly Team AB (Team Approved Body). Once the relevant documents were selected, 
the project teams began selecting the most important ones. At the same time, testing plans 
were co-developed to address each project’s regulatory challenges. These plans defined key 
hypotheses, objectives, methodologies, timelines, and anticipated risks.  
Following agreement on the testing plans, projects entered the testing phase. Most were 
conducted through a combination of simulation, virtual and real-world Airlocks. While testing 
was underway, the AI Airlock team continued prioritising regulatory documents, followed by 
a detailed review of the prioritised guidance to identify areas requiring improvement for 
AIaMD regulation. In parallel, the AI Airlock team ran simulation workshops with cross-
disciplinary experts. Insights from these activities were produced to inform the key findings 
and recommendations of the AI Airlock programme. A final meeting with all project teams 
marked the close of the delivery phase, followed by the completion of final reports.

## Page 21

Page 21 of 77 
 
Case Study: Philips Healthcare - AutoImpression and the generation, 
assessment and validation of synthetic data  
DISCLAIMER: Methods,results of testing, verification and validation discussed in this report 
are for regulatory science exploration purposes only. They DO NOT imply or confer any 
product deficiency, nor do they imply additional requirements on Philips’ processes or 
products. 
 
Introduction 
Radiologists and healthcare professionals face increased workloads due to staff shortages 
and the growing number of imaging studies. This can lead to burnout, longer wait times for 
patients, delayed diagnoses, and potentially missed diagnoses, compromising patient safety 
and outcomes. Auto Impression leverages Large Language Model (LLM) technology to 
automate the creation of the "Patient Impression" section in radiology reports. This 
automation aims to reduce errors, minimise omissions, and speed up radiology reporting, 
ultimately enhancing productivity for radiologists. The functionality is still at an early 
development stage. 
AIaMDs which perform summarisation of patient health data like Auto Impression require 
testing against a broad spectrum of rich and representative data. Philips aimed to use an 
LLM to generate synthetic radiology reports to improve representation of demographics with 
abnormal radiology findings within the dataset. The synthetic data would then be assessed 
for its suitability in testing an AIaMD, aligning well with the AI Airlock objective to understand 
what constitutes high quality text-based synthetic data from a regulatory perspective, and 
what approaches can be used to assess it.  
The assessment involved confirming that the data was truly synthetic rather than a direct 
reproduction of the original real-world or “ground truth” data. Given the large volume of data 
required, Philips proposed using established automated mathematical methods to carry out 
most of the assessment, complemented by a small sample of human-reviewed data. Once 
the reports were confirmed as synthetic, a “Patient Impression” would be generated by an 
LLM for both the synthetic and real data. These impressions would be evaluated for quality 
against criteria such as clarity, groundedness, accuracy, and completeness. To manage 
scale, an LLM would act as the primary assessor with human validation used on a small 
sample to cross-check the reliability of the LLM’s judgement.  
Regulatory challenges 
Two broad categories of regulatory challenges were considered. The first relates to 
describing regulatory requirements for GenAI-enabled devices. The second, for those 
devices that do fall under regulatory oversight, involves determining the types of valid 
scientific evidence needed to evaluate their safety and effectiveness across the Total

## Page 22

Page 22 of 77 
 
Product Lifecycle (TPLC). These challenges are particularly relevant for GenAI-enabled 
devices that use open-ended input and output formats. These differ from the more structured 
formats typically found in other AIaMD and may require new evaluation approaches.   
Synthetic data may create a more robust dataset and evaluation if accurate and 
representative. Evaluating that accuracy and representativeness is essential, considering 
elements including:  
• 
the diversity of the initial clinical dataset (different geographies, modalities, users, etc.) 
• 
the real world or ground truth data that is adequate for generation of synthetic data 
• 
how to measure the quality of synthetic text data given the lack of standardised 
evaluation metrics/scores 
• 
addressing both clinical similarity/differences and linguistic similarity/differences. 
The AI Airlock pilot generated a large volume of data and scoring outputs that were difficult 
for humans to evaluate manually. The Philips and MHRA team worked on the assumption 
that these software enhancements are designed not to replace radiologists, but to improve 
efficiency and support the quality of their work. As such, it was important to strike the right 
balance between automating the analysis of this data and including human evaluation to 
ensure accuracy and clinical alignment. The proportion of automated versus human 
validation should be determined on a case-by-case basis, accounting for the specific use 
case, the associated risk, and the added value of human input. 
 
 
 
Hypotheses 
 
• 
There will be no significant difference between synthetic data and real data in the 
quality of impressions generated in Radiology reports 
• 
There will be no significant difference in the errors identified between synthetic 
and real data using the automated evaluation Evaluation of the performance and 
safety can be performed using LLMs as Judges. 
• 
An LLM Judge will correctly identify errors introduced into real and generated 
impressions 
• 
An LLM Judge will correctly ignore nonclinical counterfactual differences between 
reports and their generated impressions.

## Page 23

Page 23 of 77 
 
Methods 
Synthetic data generation 
Philips used the MIMIC-IV,  a large, publicly available database of de-identified health data 
from over 280,000 patients who stayed in critical care units at the Beth Israel Deaconess 
Medical Centre between 2008 and 2019. The dataset includes patient measurements, 
orders, diagnoses, procedures, treatments, and free-text clinical notes. MIMIC-IV is widely 
used for research and education, helping to reduce barriers to conducting clinical studies. 
Philips used an LLM to create new, structured reports based on existing examples to support 
the generation of synthetic radiology reports. The goal was to maintain the structure and 
modality and clinical indication of the original reports while introducing new, randomised 
clinical content. A prompt was developed to generate a new structured report that used the 
format of the source (MIMIC report), but with different findings. The generated reports 
excluded introductory or summary text, such as impressions. The model used was 
configured to encourage diverse outputs. The model was chosen for its advanced language 
capabilities and suitability for generating clinically relevant synthetic text. The resulting 
synthetic reports enabled a broader range of testing scenarios while maintaining realism and 
structural consistency. 
Generating synthetic impressions 
To complement the generation of synthetic radiology reports, Philips also focused on 
creating the impression section, a critical component of radiology documentation that 
summarises the key findings and provides clinical interpretation. Care was taken to ensure 
that only reports without existing impressions were selected for generation of a synthetic 
impression. Using tailored prompts, the LLM generated impressions based on either the 
original findings from the MIMIC-IV dataset or the synthetic reports created earlier. The 
prompt used for LLM-generated impressions was designed to promote clarity, conciseness, 
and clinical relevance. It instructed another large language model (with a temperature to 
encourage more focused and deterministic outputs) to read the full body of the report and 
write a corresponding impression. The model was prompted to exclude normal findings and 
instead highlight critical abnormalities, incidental findings, and suggested follow-up actions; 
elements that improve the clinical utility of the output. 
The full reports (including impressions) were processed in batches to ensure scalability and 
consistency across the dataset. These LLM-generated impressions were designed to 
summarise the most important content from each report. They were later assessed using 
another LLM acting as a “judge”, and selected samples were earmarked for further human 
evaluation within the sandbox environment.

## Page 24

Page 24 of 77 
 
Generating reports with counterfactuals 
Philips manually introduced counterfactuals - small, controlled changes - to both original 
(ground truth) and synthetic reports to evaluate how reliably the LLM-judge distinguished 
genuine findings from altered or noisy content.  Twenty representative samples were 
selected, and for each one, five counterfactual variants were generated, resulting in a 
balanced set of altered reports. The goal was not to maintain clinical realism in these 
modified reports, but to introduce noise in a structured way to test the robustness of the 
LLM-judge. 
Seven types of counterfactuals were used, ranging from subtle character-level edits to 
changes in key clinical details such as organ, laterality, or gender references. Some 
counterfactual types relied on specific linguistic features (e.g. anatomical terms or gendered 
language) and could therefore not be applied equally across all samples. As a result, 
counterfactuals involving simple textual modifications were more frequent than those 
requiring specific clinical terminology. Care was taken to apply counterfactuals consistently 
across both synthetic and original reports despite this variation. This allowed for a fair and 
controlled comparison of the LLM-judge's behaviour across the two datasets. 
Generating reports with errors 
Philips manually applied deliberate errors to a consistent set of radiology reports to evaluate 
the reliability of the LLM-judge. Twenty reports were selected from both the original and 
synthetic datasets and five different types of clinically relevant modifications were applied, 
producing a total of 100 altered samples in each dataset. 
Error types considered most clinically relevant were focused upon, following consultation 
with radiologists. These included changes that could meaningfully affect clinical 
interpretation such as laterality swaps, organ swaps, negations, insertions, deletions etc.  
 
 
 
 
 
 
 
 
LLMs can produce slightly different responses each time they are run, even when given 
the same input. To manage this non-determinism and improve the reliability of the LLM-
judge, two strategies were used: 
Measuring consistency: For each evaluation, the same prompt was run 10 times, and the 
standard deviation of the results was calculated. This helped quantify how much the 
model's outputs varied and ensured that the results were stable enough to be trusted. 
Prompt refinement: The prompt given to the LLM-judge was reviewed and adjusted to 
improve performance. By refining the wording and structure of the prompt, the model’s 
responses became more focused and clinically aligned. 
These steps were essential to ensure that the LLM-judge could be used reliably within the 
sandbox setting. More work on mitigating non-determinism can be found in the 
SmartGuideline case study.

## Page 25

Page 25 of 77 
 
Comparison of real and synthetic reports: clinical similarity 
Philips used two complementary approaches to assess the clinical similarity between real 
and synthetic radiology findings: ICD-10 code comparison and semantic similarity analysis 
using BioBERT. 
ICD-10 codes are internationally standardised alphanumeric codes, used to classify 
diseases and health conditions in clinical documentation and billing. Maintained by the World 
Health Organisation, each code begins with a letter representing a broad disease category 
(e.g. “E” for endocrine disorders), followed by numbers that specify the diagnosis (e.g. “11” 
for type 2 diabetes), and sometimes a decimal for additional detail (e.g. “.9” for “without 
complications”). To analyse how real and synthetic findings differ, Amazon Comprehend 
Medical Service was used to extract ICD-10 codes from both sets of findings. Philips 
included only codes that Comprehend Medical marked as present in the text (non-negated), 
and with a high confidence in the match (>0.75). 
BioBERT, a deep learning model fine-tuned on biomedical texts, was used to assess clinical 
similarity beyond coded terms, a deep learning model fine-tuned on biomedical texts. Unlike 
general-purpose models, BioBERT is designed specifically for medical and life sciences 
language, allowing it to capture clinical nuance more effectively. It generates vector 
embeddings, a type of mathematical representation, of each findings section. 
Comparison of real and synthetic reports: linguistic similarity & human evaluation 
Linguistic similarity analysis was performed to ensure synthetic reports maintained the same 
linguistic style as original reports. This was evaluated using the following metrics: GLEU, 
ROUGE, Parts-of-Speech Overlap and Automated Readability Index (ARI) (see appendix for 
details). To ensure that the BioBERT, ARI and ROUGE scores effectively evaluated the 
similarity between synthetically generated reports and their original counterparts, a 
calibration step with human expert input was performed as follows: 
1. Data Collection: A diverse subset of 20 original reports and their corresponding 
synthetically generated versions was collected. The dataset covered various topics, 
clinical domains, and writing styles to provide a comprehensive evaluation. 
2. Initial Human Scoring: A set of 2 clinical experts from the Philips Clinical team, with 
experience in reading radiology reports (U.S. board certified Radiologists), blindly 
reviewed each original and synthetic report. They then scored the reports on a Likert 
scale from 1 to 5 for readability and similarity to verify that the linguistic structure, 
grammar, and terminologies used (focusing on clinical terms) were similar to ground 
truth radiology reports. 
For each report, the experts scored the following points: Clinical Content Similarity, Linguistic 
Style Similarity, Understandability compared to the original report.  In addition, an 
independent analysis for each report was carried out. The experts scored the following 
points: Language, Structure, Completeness, Clinical Soundness (see appendix for details)

## Page 26

Page 26 of 77 
 
Results 
ICD-10 Code Comparison 
Figure 6 shows the distribution of ICD-10 codes across all real and all synthetic findings. The 
distributions differ noticeably, with several ICD-10 codes appearing only in the synthetic 
dataset. This suggests that the underlying pathologies and clinical content of synthetic 
findings differ from real ones, which aligns with the goal of introducing variation in synthetic 
data generation. 
Figure 6. ICD10 Code Distribution Comparison. This chart compares the distribution of ICD-10 codes in real and synthetic 
findings. The blue dots represent ICD-10 codes from real radiology reports in the MIMIC dataset, while the red dots 
represent codes from the synthetic dataset. The x-axis shows individual ICD-10 codes (not legible due to density), and the 
y-axis indicates the frequency of each code across the respective datasets. 
Semantic Similarity with BioBERT 
Cosine similarity was used, a common measure of how similar two vectors are, to compare 
the embedding of each real finding with its paired synthetic version. Scores close to 1.0 
indicate strong similarity, while scores near 0.0 reflect major differences. Most synthetic 
reports had similarity scores between 0.6 and 0.8, indicating high, but not identical, clinical 
similarity. This moderate distance was taken as a reflection of intentional changes 
introduced through prompting, such as replacing organs or conditions to increase variety. A 
small number of pairs scored extremely high or low. These were often due to very short 
reports, or errors in text parsing or generation. Further investigation of this subset could not 
be investigated due to resource constraints.

## Page 27

Page 27 of 77 
 
Human evaluation results 
Once the human evaluation had been carried out, there was a feedback session. One 
observer mentioned that the task was notably easier when dealing with shorter reports. The 
same observer suggested that using a three-level scale would simplify the task, as the 
current five-level scale was challenging and often led them to revisit previous assessments. 
Additionally, one of the observers noted that they could not distinguish between synthetic 
and actual reports. 
 
 
Figure 7. Inter-observer High level Analysis - Frequency distribution of scores for comparative analysis per question. 
 
After further data processing, no significant correlation was found between the grading 
scores of the two observers, with one exception: a statistically significant negative correlation 
of -0.52 (95% CI: -0.78 to -0.11) was observed in their assessments of the professionalism 
of the “Language” used in the original (real-world) MIMIC report. This suggests a notable 
disagreement between the observers on this criterion. 
There are two plausible explanations for these findings: 
• 
underpowered multiple testing – the number of samples assessed may have been too 
small to detect reliable agreement across multiple dimensions. 
• 
insufficient rater training and alignment – the observers may not have received 
adequate calibration or guidance on how to apply the scoring criteria consistently prior 
to completing the task. 
0
2
4
6
8
10
12
14
1
2
3
4
5
1
2
3
4
5
1
2
3
4
5
Report count
Score
Observer 1
Observer 2
How similar are these two reports 
in terms of clinical context?  
How similar are these two reports 
in terms of linguistic style?  
How similar are these two reports 
in terms of understandability?

## Page 28

Page 28 of 77 
 
The average score was used for the calibration analysis with the mathematical target 
metrics. 
Table 2 - Correlations in between the objective metrics and observer ratings (see appendix 
for metric descriptions) 
 Question 
 Metric 
Correlation 
Count 
Lower C.I. 
Upper C.I. 
1. How similar are 
these two reports are 
in terms of clinical 
content? 
BIOBERT 
0.390 
20 
-0.064 
0.710 
2. How similar are 
these two reports are 
in terms of linguistic 
Style? 
ARI MIMIC 
Report 
-0.342 
20 
-0.681 
0.119 
ARI Synthetic 
Report 
-0.069 
20 
-0.497 
0.385 
Difference ARI 
score (Synthetic-
MIMIC) 
-0.315 
20 
-0.665 
0.148 
Average 
sentence length 
MIMIC Report 
-0.481 
20 
-0.762 
-0.049 
Average 
sentence length 
Synthetic Report 
-0.025 
20 
-0.462 
0.422 
3. How similar these 
two reports are in 
terms of 
understandability? 
ROUGE 
0.444 
20 
0.002 
0.741 
Missing value handling was conducted using pairwise exclusion, and a 95.0% confidence 
interval was applied. Significance was determined at the 0.05 level, with bold indicating 
significant correlations. 
 
The only statistically significant correlation was found between average sentence length in 
synthetic findings and similarity scores. This indicates that shorter sentences were 
associated with greater similarity, suggesting that simpler and more concise language may 
improve alignment with reference data. Question 3 showed a statistically significant 
correlation with ROUGE scores indicating that reports with similar phrasing have similar 
understandability (see appendix Table s1). 
Question 1 showed a weak positive relationship with BioBERT similarity scores, suggesting 
a possible relationship between this metric and semantic similarity in the findings. This 
relationship was not statistically significant, so it should be interpreted with caution. If the 
relationship is underpinned by an undetected correlation, it would indicate that, when 
radiologists rated pairs of reports as more similar in their clinical context, BioBERT scores 
tended to be higher.

## Page 29

Page 29 of 77 
 
Question 2 showed a weak negative relationship with the Automated Readability Index 
(ARI). This relationship was also not statistically significant. If the relationship is underpinned 
by an undetected correlation, it implies that radiologists rated pairs of reports as more similar 
in their linguistic context as readability decreased (i.e. as text becomes more complex).  
 
LLM as a judge results 
To investigate the quality and reliability of the synthetic reports and impressions generated, 
Philips employed LLMs in an evaluative role, referred to as "LLM-as-a-Judge", to investigate 
the accuracy, clarity, groundedness and completeness of the synthetic records and 
impressions generated. These metrics would be used to assess the quality of the synthetic 
reports. The generated content was assessed using four metrics: accuracy, completeness, 
clarity, and groundedness. Each metric was scored on a scale from 0 to 10, accompanied by 
a motivation explaining the given score. Philips used an LLM model with a temperature 
setting of 0.6 for this evaluation. The same system prompt was used for each metric: clarity, 
accuracy, completeness and groundedness. The LLM judge evaluated all impressions, those 
generated by humans, the synthetic impressions based on real reports and synthetic 
impressions based on synthetic reports. 
To assess the quality of impressions generated by the LLM, a human evaluation was 
conducted using a subset of radiology reports. A random sample was selected from two test 
sets: 15 original MIMIC reports with original impressions and 20 original MIMIC reports with 
LLM-generated impressions. Each impression was assessed using four key evaluation 
metrics (see appendix for details): 
• Accuracy: The extent to which the impression is factually correct, including accurate 
values, details, and the absence of errors or misrepresentations. 
• Groundedness: Whether the impression is anchored in the original findings, avoiding 
hallucinations and clearly distinguishing between facts and opinions. 
• Completeness: Whether the impression captures all relevant information, including 
clinical context and necessary detail. 
• Clarity: How well the impression is structured, including the use of appropriate, 
concise, and logically organised language. 
These same metrics were applied by both the LLM Judge and certified radiologists, who 
independently reviewed the same set of impressions. Radiologists also evaluated the LLM 
Judge’s scores, offering a human perspective on the model’s performance.

## Page 30

Page 30 of 77 
 
The resulting scores were analysed to compare evaluations from the radiologists and the 
LLM Judge, identifying levels of agreement and pinpointing discrepancies. In addition to 
numerical scoring, qualitative comments from the radiologists were reviewed to uncover 
recurring strengths and weaknesses, offering practical insights into areas where LLM 
evaluation methods either align with or diverge from expert human judgement. 
Agreement between the certified radiologist observers  
Evaluators were asked to grade their agreement with the LLM judge score, for each metric, 
with a binary agree/disagree. All 70 pairs of Report-Impressions and LLM Judge scoring 
were assessed by two blinded certified radiologists.  
Table 3 - Count of agreements and disagreement for the observers on the LLM judge scores 
per metric. 
Metric 
Decision 
Observers count of agreement / disagreement with LLM judge 
Obs1 
Obs2 
Total 
Accuracy 
Agree 
52 
53 
105 
Disagree 
18 
17 
35 
Clarity 
Agree 
63 
54 
117 
Disagree 
7 
16 
23 
Groundedness 
Agree 
53 
56 
109 
Disagree 
17 
14 
31 
Completeness 
Agree 
46 
45 
91 
Disagree 
24 
25 
49 
Agreement in between Human scores and LLM judge score 
Evaluators were asked to grade their assessment on a scale from 0-10 for each metric 
across all 70 reports-Impressions pairs. Overall, Observer 2 had higher agreements to LLM 
scoring than Observer 1 for all metrics, ranging from fair to good. Observer 1 had fair 
agreements with the LLM scoring. Weighted kappa demonstrated higher agreement (all fair) 
between the two Observers, suggesting that the 10-point scale was too granular, and should 
be reduced to 5 or 3 levels.

## Page 31

Page 31 of 77 
 
Feedback on Observers Recommendations  
The radiologists stated that some recommendations were deemed valuable and could be 
incorporated by a human radiologist; however, others were inappropriate. Recommendations 
for surgery, for example, were seen as beyond the scope of what a radiologist would 
typically suggest. 
The LLM Judge scored higher when the impressions included recommendations, regardless 
of their appropriateness. It may be necessary to fine tune the LLM Judge to avoid favouring 
recommendations that are deemed incorrect or irrelevant by human experts. 
Conclusion 
When generating synthetic radiology reports for evaluation purposes, it important to preserve 
linguistic similarity to real reports while introducing sufficient clinical variation. Metrics such 
as BioBERT similarity and ICD-10 distribution effectively captured clinical differences, while 
ROUGE-L, POS tag overlap, and ARI scores helped confirm stylistic alignment. Together, 
these metrics provided a practical framework for assessing the quality of synthetic data. 
Linguistic similarity is important for using synthetic data to supplement real clinical data; 
without it, the rationale for supplementation may be weakened. 
This case study also offers insights into the evaluation of generated impressions by both 
human radiologists and an LLM Judge. Human observers aligned reasonably well with each 
other and with the LLM Judge, with Observer 2 showing stronger agreement. The LLM 
Judge applied less granularity in scoring, however, consistently favouring high scores (e.g., 
9). Agreement metrics such as weighted kappa helped compensate for these differences 
and supported the overall validity of comparisons. 
A key issue identified was the interpretation of “groundedness” and “completeness”. The 
LLM Judge tended to conflate the two, treating omissions as a failure of groundedness.  
whereas radiologists interpreted groundedness as the extent to which impressions are 
derived from report content, with omissions affecting completeness instead. This divergence 
likely contributed to lower agreement scores and highlights the need for clearer definitions 
and evaluator guidance. 
While the LLM Judge shows promise in assessing radiology impressions, its interpretation 
and evaluation of groundedness, completeness, and recommendation relevance requires 
improvement, especially when distinguishing between human- and machine-generated 
reports. Future work should prioritise the refinement of scoring frameworks, clearer 
evaluation definitions, and more detailed guidance for automated evaluators to support 
consistency, interpretability, and alignment with clinical reasoning in the assessment of 
synthetic radiology data.

## Page 32

Page 32 of 77 
 
Case Study: AutoMedica – SmartGuideline and mitigating risks of 
LLM hallucination and non-determinism 
Introduction 
Guideline adherence improves health outcomes by promoting interventions with proven 
benefit, discouraging ineffective ones, and supporting greater consistency in care.  Clinicians 
deviate from guidelines due to several factors: lack of access to guidelines at the point of 
care; awareness and access; clinician perception that their own experience outweighs 
guideline recommendations; lengthy, complex, or ambiguous guidelines.   
SmartGuideline is an AI clinical decision support (CDS) tool designed to help healthcare 
professionals in both primary and secondary care follow best-practice recommendations. It is 
designed to provide real-time access to summarised clinical guidelines, answering 
management questions quickly and referencing the original guideline sources. The tool has 
potential to offer support across the full spectrum of clinical decision-making: diagnosis, drug 
selection, dosing, contraindications, investigations, treatments, and referral criteria.  
SmartGuideline aims to reduce unwarranted variation in care, improve safety, and increase 
clinician productivity by making guideline information more accessible and usable at the 
point of care. 
Large language models (LLMs) are a type of AI algorithm that predict the next most likely 
word or part of a word based on previous context. This is achieved through creating 
mathematical representations of words and training the deep learning algorithms on huge 
volumes of textual data that pre-compute probabilities for the next most likely word. This 
means that AI produces plausible-sounding output but does not guarantee factual accuracy 
(i.e. the ground truth) which can result in plausible sounding inaccuracies (known as 
hallucinations or fabrications). LLMs are becoming more common in healthcare, from 
summarising clinical encounters and patient records to supporting clinical decisions. While 
this technology has great potential, the associated risks present key regulatory challenges. 
Even well-trained AI systems that use LLMs can confidently generate these plausible 
sounding inaccuracies, which in healthcare could lead to patient harm. The Medical Device 
Regulations 2002, which apply in Great Britain, require the benefits of the product to 
outweigh known and reasonably foreseeable risk. These risks should be mitigated primarily 
through safety by design.  Retrieval-Augmented Generation (RAG) is a technique that 
enhances LLMs by grounding their outputs in curated external knowledge sources. By 
combining the conversational fluency of LLMs with the factual accuracy of retrieved content, 
RAG aims to address AI hallucinations. In this architecture, the LLM generates outputs using 
information drawn from a validated knowledge base, bridging “retrieval” and “generation.” 
AutoMedica’s clinical decision support tool applies an adaptation of RAG in a healthcare 
context. Built using a curated knowledge graph, it applies its proprietary Tree-anchored 
Graph-RAG (TaG-RAG) to a structured database of National Institute for Health and Care

## Page 33

Page 33 of 77 
 
Excellence (NICE) resources, including clinical guidelines, knowledge summaries, patient 
leaflets, and a selection of medications from the British National Formulary (BNF). 
Regulatory hypotheses & challenges 
The team identified four primary regulatory hurdles that currently limit the safe and effective 
use of LLMs in regulated healthcare applications: 
• Hallucination: The model may generate plausible sounding but factually incorrect or 
clinically unsafe content 
• Non-determinism: Given the same input, LLMs can produce different outputs, which 
can undermine consistency and predictability 
 
In addition to exploring how these risks can be mitigated, the AI Airlock programme 
examined how SmartGuideline is positioned within the broader UK regulatory landscape. A 
further key objective was to assess the clinical relevance of SmartGuideline through 
engagement with a group of practising clinicians.  
 
 
Methodology 
To evaluate the safety and performance of SmartGuideline, AutoMedica tested the tool in 
the AI Airlock sandbox.  
AutoMedica obtained test licences and data access from NICE, the Pharmaceutical Press, 
and the Medusa database. This allowed SmartGuideline to be built and tested using 
authoritative UK guidance, including the BNF, BNFC and NICE clinical guidelines. 
• 
Training data and bias: The quality and representativeness of training data affect 
how well the model performs across different populations. Poor or 
unrepresentative data can lead to harmful inequities. More work on assessing and 
validating training data can be found in the Philips AutoImpression case study. 
• 
Explainability: Regulatory expectations increasingly require AI systems to 
demonstrate how they reach a conclusion. A lack of transparency can reduce trust 
in AI-generated advice. More work on explainability can be found in the OncoFlow 
case study. 
Hypothesis 
 
The AI Airlock programme set out to test the hypothesis that key regulatory 
concerns surrounding the use of large language models (LLMs) in medical devices 
could be addressed through a safety-by-design approach by using RAG.

## Page 34

Page 34 of 77 
 
Testing took place in three phases. First, SmartGuideline’s responses were compared 
directly to the baseline model (ChatGPT-4o), to assess hallucination and omission rates. 
Next, reproducibility was tested by running 1,000 clinical queries through the model ten 
times each (n=10,000), allowing the developers to evaluate the consistency of responses. 
Finally, 19 GP trainees from Surrey participated in a live session where they explored the 
tool’s usability, trustworthiness, and how it handled clinical complexity. 
SmartGuideline usability 
During the development of SmartGuideline, two detailed rounds of patient and public 
involvement (PPI) were undertaken with 30 healthcare professionals from Imperial College 
London and Imperial College healthcare trust. Sessions were recorded and a qualitative 
analysis was undertaken which highlighted several key themes: clinical utility, usability, staff 
compatibility and guideline comprehensiveness.  
It was highlighted that to be a truly useful tool for doctors, local trust guidance must also be 
incorporated. Usability was addressed by redesigning the user interface during the AI 
Airlock. 
Virtual and real-world Airlock testing 
Two versions of the system were evaluated: an early proof-of-concept (PoC) version, was 
tested in a virtual environment to identify technical risks, and an alpha version, tested in a 
real-world setting Airlock. The study was designed to simulate real-world clinical scenarios 
and involved licensed UK medical doctors. Each doctor was randomly assigned a clinical 
question derived from NICE guidance or the BNF and provided an answer using either 
SmartGuideline or a baseline model, without being told which system they were using. 
The core safety question was: how often does the model generate a clinically meaningful 
error?  
The primary efficacy outcome was the rate of accurate query responses, and the primary 
safety outcome was the rate of hallucination .Hallucinations were classified as either major 
or minor, depending on whether they could or could not influence diagnosis or treatment 
decisions (as described in the CREOLA framework). Any major hallucination automatically 
triggered a root cause analysis, ensuring that lessons could be drawn to further improve the 
system. 
Omissions were documented as a secondary outcome, in which the model failed to produce 
a response.  
Non-determinism tests 
The reproducibility of SmartGuideline was measured across a dataset of 1,000 queries, each 
submitted 10 times. This amounted to 10,000 responses, analysed using a range of natural 
language processing similarity metrics. These included BLEU and ROUGE (which assess 
word and phrase similarity for models with short textual outputs), and BERT and SBERT 
(which capture semantic meaning for longer outputs). The goal was to understand how 
variable the model was in its output, and whether such variability might pose a risk in a 
clinical setting. Initial results showed high internal consistency, with most variation occurring 
in phrasing rather than content.

## Page 35

Page 35 of 77 
 
Clinician workshop 
Beyond technical performance, user trust and usability were also explored. In a live 
workshop, 19 GP trainees interacted directly with the model, using real clinical queries and 
assessing the tool’s usefulness in real-time. Participants were asked to comment on 
explainability, potential biases, and overall user experience. Their feedback helped identify 
areas where SmartGuideline’s interface and response style could be improved, for example, 
summarising information more succinctly or highlighting where decisions were based on 
national vs local guidance 
While time and resource constraints limited full evaluation of all metrics, comprehensive 
analysis was completed for the primary outcome and overall response quality. Bias and 
explainability were assessed qualitatively in the GP trainee session, and reproducibility was 
evaluated across the full test dataset. 
The study was conducted in February 2025, with statistical analysis and reporting finalised in 
March. The study was powered using the primary safety outcome; from pilot work, no 
hallucinations were expected with SmartGuideline and about 5% from chatGPT-4o. Using a 
power of 90% at an alpha of 0.05, a minimum of 406 responses (203) in each arm were 
required. 
Results 
PoC testing results 
In 493 tests, all of which were manually evaluated (n=413 SmartGuideline vs n=80 
chatGPT4o) there were no (0%) hallucinations with SmartGuideline vs 6 (7.5%) major 
hallucinations with chatGPT4o (P<0.0001). 
In the PoC model, there was limited question rephrasing and access was restricted to NICE 
guidelines alone. Many of the clinical questions posed related to drug prescribing or adverse 
effects. As a result, once a subset of drug data from the BNF was incorporated, performance 
improved significantly. Moreover, to ensure the SmartGuideline model gave consistent 
answers, it always chose the most likely next word (a method called greedy decoding).  
Strong safety rules meant the model struggled to understand slightly different wording, which 
led to higher omission rates with SmartGuideline. Omissions were defined as failure to 
generate any response, or the model stating it does not have adequate information for a 
response when all the information needed for a response is present. Table 4 demonstrates 
comparative omission and hallucination rates with the SmartGuideline PoC and the baseline 
model. SmartGuideline omissions were significantly higher (P<0.001) whilst rates of 
hallucination were significantly lower (P<0.001) in the PoC testing.

## Page 36

Page 36 of 77 
 
Table 4 - Comparative omission and hallucination rates with the SmartGuideline PoC and 
chatGPT4o 
Hallucinations 
Omissions 
SmartGuideline 
0/413 
(0.0%) 
35/413 
(8.5%) 
ChatGPT-4o 
6/80 
(7.5%) 
0/80 
(0.0%) 
Alpha testing results 
A total of 872 manual human evaluations were undertaken on the outputs of SmartGuideline 
(n=436) vs baseline GPT (n=436). There were no hallucinations and 5 omissions with 
SmartGuideline. There were 3 omissions (failures to generate a response) with the Chat 
GPT4o model, and 23 (5.3%) hallucinations. Root cause analysis divided the sources of 
these hallucinations as follows: n=12 faithfulness hallucinations (correct information but 
untrue based on underlying source material); n=7 factuality hallucinations; n=8 incorrect 
guideline sources. These categories were not mutually exclusive, multiple types of 
hallucination were present in some responses. 
There were no differences in the rates of omission (P=0.725). SmartGuideline displayed 
statistically significant lower rates of hallucination (P<0.0001) (Table 5). Some 
SmartGuideline omissions were dependent on the phrasing of the question. For example, 
the model performed well when asking “signs that indicate need for referral for venous leg 
ulcer disease” but generated no response (omission) when asked about the “referral criteria 
for venous leg ulcer disease”. Strategies to mitigate these residual omission events are in 
development.  
Table 5 - SmartGuideline alpha testing vs baseline GPT 
  
Hallucinations 
Omissions 
SmartGuideline 
0/436 
(0.0%) 
5/436 
(1.1%) 
ChatGPT-4o 
23/436 
(5.3%) 
3/436 
(0.7%) 
In all omission cases, no data were generated by the models, meaning there was no 
information available on which to base a clinical decision and, therefore, no associated 
clinical risk. The omission rates for SmartGuideline and the baseline model (1.1% and 0.7% 
respectively) were considered to be of low likelihood, with a likelihood score of 2 and a 
severity score of 1, according to ISO 14971.

## Page 37

Page 37 of 77 
 
The rate of hallucinations with SmartGuideline was (0), resulting in both a likelihood and 
severity score of 1. In contrast, hallucinations generated by ChatGPT included both 
faithfulness hallucinations - where information was broadly correct despite referencing non-
existent sources - and factuality hallucinations, which were assessed as having a moderate 
severity (score = 3). Given an observed hallucination rate of 5%, the likelihood was also 
scored as moderate (score = 3). 
When combining hallucinations and omissions, the maximum scores for likelihood and 
severity were used. ChatGPT's outputs resulted in an aggregate risk score of 9 (3 x 3), 
constituting high clinical risk. By comparison, SmartGuideline achieved an aggregate risk 
score of 2 (2 x 1), indicating low clinical risk for the primary outcome measure. 
Table 6 – table of total risk score, using likelihood and severity as per ISO 14971.  
 
Non-determinism 
Consistency in responses is critical for AI healthcare models. 
Semantic entropy was relatively high at 7, indicating low exact word match consistency. 
However, the BLEU score (short phrase lexical similarity) was 0.58 (high), the ROUGE score 
(long phrase lexical similarity) was 0.69 (very high), and the BERT and SBERT scores 
(which assess semantic similarity) were 94% and 97% respectively. For SmartGuideline, 
generating ten outputs per input was judged sufficient to capture variability in a meaningful 
and efficient way. The range of benchmarking scores reported here provides a promising 
foundation for standardising reproducibility metrics for regulatory consideration. 
Secondary outcomes (Goodness of response, training data, bias and explainability) 
The primary method for reducing poor-quality training data and bias within the model was 
the use of a proprietary information retrieval graph structure, combined with high-quality, 
information sources, to generate responses.

## Page 38

Page 38 of 77 
 
Explainability and the potential for bias were assessed during in-person user testing with 19 
GP trainees. For a subset of SmartGuideline responses, participants evaluated the system 
using structured criteria. All (100%) of participants felt the SmartGuideline answers were 
moderately or strongly supported by scientific and clinical consensus; 94% felt that answers 
demonstrated understanding of the proposed clinical question; 100% felt that answers 
demonstrated correct knowledge recall; 83% felt there was moderate or strong explainability 
within the answers presented; 72% felt that the model answers contained unbiased 
information, (i.e., 28% felt there was potential for bias). Qualitative insights gathered through 
group discussion indicated that these concerns were less about the model itself and more 
about the underlying clinical guidelines, which participants felt were not always 
representative of diverse populations. 
Importantly, this evaluation did not establish a definitive threshold for explainability required 
for clinician trust. The findings do suggest that perceptions of "sufficient" explainability are 
likely to vary between individuals, depending on their baseline clinical knowledge, familiarity 
with the patient in question, and comfort with digital tools. This variability underscores the 
importance of designing AI systems that offer layered or customisable levels of explanation 
to meet diverse user needs.  
Conclusion 
 
This case study highlights the value of structured, real-world testing to assess the clinical 
safety, reliability, and usability of AI tools designed to support clinical decision-making. It 
particularly demonstrates how targeted evaluation methods – such as hallucination rate 
assessment, deterministic decoding, and ISO 14971-based clinical risk scoring – can be 
applied in practice to interrogate system behaviour in a controlled environment. 
The use of comparative testing against baseline models provided a clear framework for 
identifying specific safety gains (e.g. hallucination reduction) and trade-offs (e.g. increased 
omission rates). This underlines the importance of context-specific evaluation: techniques 
that improve safety may impact completeness or usability, and decisions on deployment 
should consider these trade-offs explicitly. The application of semantic similarity, 
BLEU/ROUGE scores, and risk-adjusted metrics enabled a multi-dimensional view of 
performance, which is likely to be more informative than any single indicator. These 
techniques could inform future guidance on performance benchmarking and validation. 
Finally, qualitative testing with clinicians surfaced important insights into explainability and 
trust, underscoring that user perception of AI tools cannot be separated from technical 
performance, and may vary according to training or expectations. 
Together, these techniques offer a toolkit for regulators and developers seeking to evaluate 
AIaMD products in a way that is robust, transparent, and proportionate to clinical risk.

## Page 39

Page 39 of 77 
 
Case Study: OncoFlow – OncoFlow and the trade-off between 
explainability and clinical performance 
Introduction 
OncoFlow aims to transform cancer care by tackling key inefficiencies in clinical workflows, 
especially those surrounding Multi-Disciplinary Teams (MDTs) and their meetings (MDTMs). 
Cancer treatment decisions must bring complex clinical data from multiple sources together 
and align it with the latest medical guidelines and best practices. Any delays in gathering this 
information or inconsistencies in interpreting it can negatively affect patient outcomes and 
delay critical care. 
OncoFlow aims to improve the efficiency, accuracy, and transparency of cancer decision-
making by integrating AI into cancer care workflows. Acting as an AI-powered co-pilot and 
decision-support tool for MDTs, OncoFlow helps clinicians by: 
1. Enhancing consistency and transparency in patient care pathways. 
2. Optimising the time spent discussing complex patient cases. 
3. Ensuring the efficient use of clinical and diagnostic resources to support better 
decisions. 
OncoFlow’s automates key tasks that typically demand considerable clinician time and effort. 
The platform allows oncology teams to concentrate on critical decisions that require their 
expertise by providing clinicians with structured, evidence-based patient information. 
OncoFlow consists of two main AI-driven components: 
• 
Data Extraction System: This algorithm processes unstructured diagnostic and 
medical reports, converting raw data into clear, structured clinical summaries that can 
be rapidly reviewed and acted upon. 
• 
Treatment Matching System: This algorithm aligns the extracted clinical data with 
current, evidence-based treatment guidelines, ensuring that MDTs have access to 
personalised and up-to-date treatment options for each patient. 
Designed as a clinical decision-support tool that supports rather than replaces clinicians. 
OncoFlow maintains human oversight and accountability throughout the decision-making 
process.  The platform seeks to enable more effective, personalised, and timely oncology 
care by standardising patient data and treatment pathways, ultimately improving outcomes 
for patients and healthcare systems alike.

## Page 40

Page 40 of 77 
 
Regulatory challenges 
 
With AI-powered decision-support tools like OncoFlow operating in an evolving regulatory 
landscape, key regulatory considerations include compliance with the MDR 2002, adherence 
to Good Machine Learning Practice (GMLP) principles, and ensuring strong explainability to 
gain clinician trust and meet regulatory scrutiny. 
A primary challenge for OncoFlow was defining and implementing explainability and 
transparency within its AI systems. Many AI models, particularly those based on LLMs, are 
often described as “black boxes.” This means it can be difficult for clinicians and regulators 
to understand how the AI arrives at specific decisions.  Therefore, OncoFlow had to 
demonstrate how AI models could deliver traceable, evidence-based justifications for 
treatment recommendations. Whilst aligning with current regulatory expectations for safety, 
reliability, and clinical validity of AI medical devices. Successfully addressing these 
challenges was essential for building understanding of structured approaches to improving 
explainability, regulatory compliance, and strategies for clinical validation and trust. 
 
The primary objective of this study was to evaluate and compare the performance, 
explainability and clinical utility of different AI models when applied to unstructured breast 
cancer data, in the context of the OncoFlow use case. Breast cancer was chosen as the 
focus due to the availability of data, high prevalence, and burden within the NHS MDTs, and 
existing expertise within the OncoFlow team. Performance metrics included accuracy, 
precision, recall, F1 score, and computational efficiency (Graphics Processing Unit, (GPU) 
usage). Explainability metrics were focussed on assessing decision traceability, 
transparency in recommendations, and user comprehension. Clinical performance would be 
measured through factors such as ease of use, processing speed, and alignment with 
clinician needs to ensure a more seamless integration into MDT workflows.  
The performance and explainability metrics were selected to ensure that the AI system 
meets the technical, clinical, and regulatory requirements necessary for safe and effective 
use in healthcare settings. 
 
 
Hypotheses 
• Explainability of an AI system (in this case, OncoFlow) can be verified by 
assessing its ability to provide clear, comprehensible, and consistent justifications 
for its outputs, using predefined explainability metrics and evaluation framework. 
• Simpler models (such as traditional Natural Language Processing, (NLP), 
approaches) may enhance explainability, while more advanced LLM-based 
models may improve clinical performance.

## Page 41

Page 41 of 77 
 
Methodology 
 The team explored multiple AI configurations for two key tasks:  
• extracting structured clinical data and  
• matching patient information to treatment guidelines,  
specifically for use in breast cancer MDT meetings.  Three AI approaches were compared: 
• A rule-based NLP system 
• A fine-tuned LLM trained on clinical data 
• A hybrid method, combining rule-based NLP for straightforward data (such as dates 
and patient demographics) with LLMs for more complex clinical features (like lymph 
node status or evidence of metastasis) 
Testing followed a standard train-test-validate cycle. A real-world dataset was sourced from 
Barts Health NHS Trust, containing 9,000 histopathology reports and 3,000 radiology reports 
from breast cancer patients. These reports were extracted from the hospital’s Electronic 
Patient Record (EPR) system, anonymised by the Barts Life Sciences IT team, and clinically 
labelled to establish a ground truth for validation. The dataset was split 80% for training, 10% 
for testing, and 10% for validation.  OncoFlow used current breast cancer guidelines, 
including the NICE Guidelines, ESMO (European Society for Medical Oncology) Guidelines, 
and SACT Protocols from the Clatterbridge Cancer Centre NHS Foundation Trust to guide 
the treatment matching process. 
Performance of each AI approach was assessed using standard metrics: accuracy, 
precision, recall, and F1 score. This formed part of the clinical utility evaluation to determine 
how well each model performed in extracting relevant information and supporting decision-
making. 
Explainiability was tested using SHAP (SHapley Additive exPlanations), SHAP-IQ, and LIME 
(Local Interpretable Model-Agnostic Explanations). These methods helped to visualise which 
parts of the clinical text the AI model focused on when generating its output, essentially 
showing clinicians why the AI reached its conclusions. Outputs were reviewed by clinicians 
to assess whether the extracted information was meaningful, trustworthy, and fit for use in 
real-world practice. This testing was carried out securely on OncoFlow’s AWS Cloud 
infrastructure, simulating the conditions of how OncoFlow would be used during actual MDT 
meetings. This allowed the technical and AI teams to conduct rigorous, controlled 
evaluations in a setting that reflected real-world clinical use.

## Page 42

Page 42 of 77 
 
To complement technical testing and model validation, a structured survey was conducted 
with a sample of clinicians to assess attitudes and expectations around explainability in AI-
powered clinical decision support tools. The responses provided critical context for 
simulating how OncoFlow would be perceived and utilised in real-world settings, especially 
within MDT environments. The findings informed the fine-tuning of explainability 
features after initial testing of all the possible explainability approaches in the context of 
OncoFlow  
Results 
Data Extraction: NLP vs. LLMs 
Both traditional NLP methods (e.g., regex-based rule extraction) and advanced LLMs were 
tested (Figure 2) during OncoFlow’s Data Extraction System design. Traditional NLP 
methods worked well for pulling out structured information such as dates and numbers, but 
they struggled with more complex clinical reasoning, for example, linking tumour 
characteristics with diagnostic findings in varied report formats. As such, the NLP model 
performed poorly. The LLM models were better able to interpret these complex relationships, 
adapt to different document styles, and scale across large volumes of data. The final model 
configuration achieved up to 90% accuracy in extracting relevant clinical data information. 
 
Figure 8. Comparative accuracy of NLP and LLM models for data extraction. This chart shows the performance of 
traditional rule-based NLP (Regex) versus multiple instruction-tuned LLMs. The NLP model underperformed significantly, 
while LLMs demonstrated higher accuracy, with DeepSeek R1 emerging as the top-performing model for extracting 
complex clinical information from unstructured texts.

## Page 43

Page 43 of 77 
 
A series of pre-defined clinical rules were integrated into the model's prompt design to 
improve the accuracy and consistency of OncoFlow’s Data Extraction System. These rules 
were tailored to help the AI extract essential diagnostic details from unstructured medical 
reports, particularly in radiology and histopathology. Embedding these rules enabled the 
system to exceed the 80% accuracy benchmark, helping to ensure that relevant clinical 
information was correctly identified, interpreted, and standardised across different data 
sources. 
Explainability tools such as SHAP (SHapley Additive exPlanations) and SHAP-IQ helped 
better understand how the AI evaluated inputs. These tests showed that 'distant metastasis' 
and 'HER2 status' were the most influential features affecting AI outputs. Other factors such 
as tumour size, lymphovascular invasion, and the presence of ductal carcinoma in situ (i.e., 
an early form of breast cancer where abnormal cells are found in the milk ducts but have not 
spread into surrounding breast tissue) also had a strong impact, while features like laterality 
(the side of the body) and biomarker presence had a more moderate effect on the system’s 
performance. 
The team observed a significant benefit from incorporating a “reasoning” feature into the 
model, which required the AI to explain the steps taken in generating outputs, thus providing 
insight into the logic used. This approach improved transparency, making it easier to trace 
potential sources of error.  
Treatment Matching: LLM + RAG Architecture 
A traditional NLP approach was initially tested but proved ineffective (Figure 9). An LLM 
integrated with Retrieval-Augmented Generation (RAG) was trialled. This approach was 
necessary to handle the complexity and frequent updates associated with clinical guidelines 
such as ESMO, NICE, and the SACT guidelines used in this case study. A standalone LLM 
(without RAG) posed a higher risk of hallucinations and reduced explainability. The RAG 
configuration ensured that treatment recommendations were explicitly grounded in retrieved 
sections of the guidelines. This improved both the traceability of outputs and alignment with 
regulatory expectations around safety and transparency. Retrieval efficiency was strongly 
influenced by the embedding model and chunking strategy used, both of which affected the 
accuracy and relevance of the content retrieved. The best-performing retrieval method 
combined PubMedBERT embeddings and a vector database (Qdrant) for optimised query 
expansion. The most effective model achieved 92% accuracy in retrieving relevant ESMO 
and NICE guidelines, and 100% accuracy in matching Systemic Anti-Cancer Therapy 
(SACT) protocols. Challenges were observed when guidelines included overlapping 
recommendations or lacked clear criteria for patient sub-groups.

## Page 44

Page 44 of 77 
 
 
Figure 9. Accuracy comparison of language models for Treatment Matching. This chart compares the performance of 
various LLMs and NLP in retrieving and aligning cancer treatment recommendations with clinical guidelines. Traditional 
NLP again failed to handle complex guideline reasoning, while Mistral 7B v0.2 achieved the highest accuracy, 
outperforming other models in the Treatment Matching task. 
 
 
Figure 10. LIME Feature Importance in Response Generation (NICE/ESMO). This chart shows how different clinical 
features influenced AI-generated treatment suggestions, as measured by LIME. Lymph node involvement, location of 
suspicious lymph nodes, and tumour size had the highest impact on decision-making. 
 
 
Clinician testing results 
To complement model testing, a structured survey was conducted with 16 clinicians to 
explore expectations around explainability in AI clinical decision support tools, particularly 
within MDT environments. The survey provided critical context for refining the explainability 
features of OncoFlow based on real-world preferences. 
Despite maintaining a low hallucination rate (3.4%), testing identified overgeneralisation 
risks, particularly when the AI encountered gaps in guideline data. This underscores the 
necessity for clinician validation prior to any final, definitive decisions being made. More 
work on mitigating hallucinations can be found in the SmartGuideline case study.

## Page 45

Page 45 of 77 
 
There was a strong consensus on the importance of explainability: 75% of respondents rated 
understanding AI reasoning as “extremely important”, with the remainder identifying it as 
“somewhat important” or “neutral”. Clinicians preferred transparency around 
recommendation generation, with 44% wanting a full breakdown of data inputs and 
algorithmic logic, 38% preferring step-by-step reasoning, and only 19% satisfied with brief 
summaries. Presentation style was also consistent – all respondents preferred a 
combination of text and visuals (e.g., graphs or decision trees) to enhance comprehension. 
Additionally, 94% valued understanding how clinical features were weighted in the model, 
validating the relevance of tools like SHAP and LIME. 
Uncertainty communication was considered essential: 56% preferred detailed explanations 
of uncertainty or limitations, and 44% supported flagging uncertain outputs. None supported 
omitting uncertainty information, indicating that clinicians expect AI to reflect the inherent 
limitations of medical decision-making. Only one respondent was comfortable accepting 
recommendations without supporting reasoning. Most preferred either detailed or partial 
reasoning to maintain transparency and clinical trust. 
Clinicians also favoured a flexible, context-sensitive approach to explainability. Higher levels 
of detail were expected for high-risk or acute scenarios, with lower-stakes settings permitting 
simpler outputs. This supports the use of explainability tiers aligned with risk classification 
(e.g., medical device class I–III). These insights informed the design and refinement of 
explainability features within OncoFlow, including the use of visual aids, confidence 
indicators, and transparent reasoning outputs. They also shaped how explainability was 
simulated in the testing environment to better reflect real-world clinical expectations. 
Conclusion  
In the treatment matching task, traditional NLP tools unable to handle the complexity of 
clinical guidelines. An LLM combined with a RAG approach proved more effective. This 
allowed the AI to find and quote relevant sections of guidelines when making treatment 
suggestions, improving both traceability and alignment with safety expectations. The model 
achieved high accuracy in identifying relevant guidance, although some challenges 
remained in cases where guidelines were ambiguous or overlapping. 
Throughout the study a strong emphasis was placed on explainability. Tools such as SHAP 
and LIME helped to clarify which clinical factors most influenced the AI’s decisions. The 
addition of a “reasoning” feature gave users a clearer view of how the system arrived at its 
outputs. This was especially important in building confidence among clinicians. 
Feedback from a survey of healthcare professionals reinforced this point. Clinicians placed 
high value on transparency, with most wanting detailed explanations of how AI 
recommendations were made. There was broad support for using a mix of text and visuals to

## Page 46

Page 46 of 77 
 
communicate this information, and for adapting the level of explanation based on the clinical 
context. The findings also highlighted the importance of acknowledging uncertainty, 
particularly in higher-risk decisions. 
From a regulatory perspective, this case study highlights several promising techniques for 
improving the safety, reliability, and explainability of AI systems used in clinical settings. It 
also underlines the value of early engagement with users, to ensure that new technologies 
align with the expectations and needs of those who will use them in practice. While the 
results are encouraging, further work is needed to ensure these methods are robust across a 
broader range of clinical scenarios. Continued testing, guidance development, and cross-
disciplinary collaboration will be key to supporting the safe and effective use of AI in 
healthcare.

## Page 47

Page 47 of 77 
 
Case Study: Newton’s Tree – FAMOS and continuous, real time post-
market surveillance monitoring 
Introduction 
 
Over time, the performance of an AI system can decline. This may happen due to shifts in 
the environment, such as the introduction of new types of patients, the use of different 
medical scanners, or other unforeseen changes in the clinical environment. This is called 
drift and presents a significant barrier to AI safety, and therefore its uptake.  
A common mitigation strategy for model drift is to involve humans in the loop, for example by 
having clinicians verify AI outputs. Clinicians are, however, susceptible to automation bias, 
which leads them to agreeing with the AI output without thought and makes human-in-the-
loop an ineffective mitigation strategy. To maintain safety, trustworthiness and regulatory 
compliance, continuous monitoring of deployed AI systems is essential. Continuous 
monitoring can detect issues that develop too slowly or too quickly to be captured through 
scheduled reviews and periodic audits. 
The FAMOS Dashboard was designed to support this continuous oversight. It presents three 
real-time metrics to users: each selected through a clinical risk management approach. 
Potential hazards associated with AI use are identified and data are selected to most 
effectively signal those hazards. The three metrics align with ISO guidance on risk 
management for medical devices incorporating machine learning. The three metrics are: 
• Data Input Quality: This metric tracks how the data fed into the AI system changes 
over time, identifying any outliers or anomalies. Ensuring high-quality data input is 
crucial because poor data can lead to inaccurate AI outputs. 
• AI Inference Values: This metric monitors the AI's output over time to detect any drift.  
Detecting drift early helps recalibrate the AI system to maintain its accuracy. 
• AI/Human Agreement: This metric measures how often NHS staff members agree 
with the AI's output. High agreement rates might indicate automation bias, where 
clinicians might accept AI recommendations without critical evaluation. Monitoring this 
helps identify and mitigate this bias. 
Trends in these metrics can be monitored so preventative action can be taken before a 
safety incident occurs. The dashboard can be viewed by three types of organisations: 
• The AI manufacturer can view the anonymised data trends in the dashboard, ensuring 
privacy is maintained. This can be viewed for their products across all sites they are 
deployed.

## Page 48

Page 48 of 77 
 
• The NHS organisation can view trends across all AI products deployed at their site. 
Additionally, the dashboard provides the ability to drill down into specific data, 
allowing for detailed investigation of particular trends.  
• Oversight bodies, such as the MHRA or NHS England, can view combined trends 
across all AI products and sites. However, like manufacturers, they cannot access 
individual-level data, ensuring that privacy is maintained 
 
The AI Airlock programme aimed to assess how real-time monitoring can enhance a 
product’s risk management strategy by enabling earlier identification of performance or 
safety issues. An unresolved challenge was the lack of clear methods for defining thresholds 
for these monitoring metrics. Without robust, evidence-based thresholds, it is difficult to 
determine when deviations in performance should trigger interventions or regulatory actions. 
Establishing methods for setting these thresholds is crucial to making continuous monitoring 
actionable and compliant and remains a key area for further regulatory and research 
development. 
Regulatory challenge 
Annex 2, clause 3.1 of the Medical Device Directive (1993) placed an obligation on 
manufacturers to conduct post market surveillance (PMS), a key part of the risk 
management strategy. This obligation continues and grows broader as medical device 
regulation is updated with The Medical Devices (Post-market Surveillance Requirements) 
(Amendment) (Great Britain) Regulations 2024. 
Following the existing methods for PMS, which relies on NHS data sharing and reporting, 
which may not provide enough data. One potential solution is a path that automates the 
sharing of information whilst preserving privacy. Further, for AI as a Medical Device, such a 
path could enable manufacturers to meet the 10th Good Machine Learning Practice (GMLP) 
principle, produced by the International Medical Device Regulators Forum (IMDRF): 
“deployed models are monitored for performance”, and the 7th GMLP principle “Focus is 
placed on the performance of the human-AI team”. 
FAMOS offers automated continuous monitoring of AI and its (and other such platforms) use 
may offer a means for meeting these regulatory requirements.

## Page 49

Page 49 of 77 
 
 
Methodology 
The study involved a retrospective observational trial employing federated evaluation of AI 
models. FAMOS was implemented at two NHS hospitals: Leeds Teaching Hospitals NHS 
Trust and Greater Glasgow and Clyde Health Board. The AI technologies evaluated included 
chest X-ray algorithms from Qure.ai and Annalise. 
A stratified random sampling method was required to ensure a representative sample of the 
hospital’s patient population while meeting the study’s data requirements. The sample size 
was predicted to be close to 3,000 patients across both sites. For the statistical analysis a 
two-sided p-value of less than 0.05 will be considered statistically significant. 
For the primary objective: 
Descriptive statistics summarised the number and percentage of chest X-rays successfully 
monitored by FAMOS at each site to evaluate the effectiveness of FAMOS in monitoring AI 
performance across different hospitals. Metrics including data capture rate (proportion of 
eligible chest X-rays monitored), timeliness (mean and median time delays in data capture), 
and monitoring accuracy (comparison of FAMOS-monitored data with source data) were 
calculated. 
Comparative analyses between sites were conducted using chi-squared tests for proportions 
and t-tests or Mann-Whitney U tests for continuous variables, depending on data distribution. 
Visualisation tools such as flowcharts and bar charts will illustrate data flow and data capture 
rates. The effectiveness of FAMOS was assessed based on its ability to provide effective 
and timely monitoring and any discrepancies or delays in data capture.  
 
 
Hypotheses 
A real-time monitoring system can improve product safety by providing trends that can 
be fed into an organisation’s Risk Management System. By identifying variations in data 
quality, AI performance and human agreement, risk can be mitigated enabling regulatory 
compliance. 
• Trends can reliably be presented in a real-time monitoring dashboard. 
• Trends exist that indicate risk. 
• There is a place for trends in a risk management system. 
• There is a way to address the risks identified by trends.

## Page 50

Page 50 of 77 
 
Results 
 
At the time of writing, the final analysis was still ongoing; however, an interim analysis had 
produced some early findings. 
Data attributes 
At NHS Greater Glasgow and Clyde (GGC) and Leeds Teaching Hospitals (LTH), chest X-
rays were processed. The data attributes included comparable age ranges across the two 
sites, similar male-to-female ratios, and similar proportions of winter versus non-winter 
patient data; however, the Glasgow site had twice as many image artefacts in X-rays 
compared with Leeds. There was minimal time delay between image processing and display 
on the monitoring dashboard, supporting the first AI Airlock hypothesis: that trends can be 
reliably presented through a real-time monitoring dashboard. 
An initial review identified that dataset outliers were primarily associated with: 
• image artefacts (e.g. jewellery worn by the patient) 
• variations in patient positioning 
• differences in image orientation (e.g. posteroanterior vs lateral view) 
At NHS Greater Glasgow and Clyde, four distinct data clusters were observed. This likely 
reflects the fact that GGC receives data from four separate hospital sites. These clusters 
highlight heterogeneity in the data, which could influence AI performance and suggests that 
further principal component analysis is needed to confirm the source and characteristics of 
each cluster. 
Human-AI agreement 
To ensure robust comparisons, the study design included a matched case mix across sites: 
there was equal distribution of normal and abnormal findings, and a balanced demographic 
profile (gender and age, above and below 60). Each site employed four readers, two per 
target disease, and used multiple AI vendors. Most major identified confounders were 
controlled for, such that the only meaningful differences between sites were the reader skill 
mix and the conditions under which readings were conducted.  
Results showed that reader agreement with AI suggestions at NHS Greater Glasgow and 
Clyde increased over time, while remaining relatively stable at Leeds Teaching Hospital. The 
increase in positive findings over time observed in Glasgow was statistically significant 
compared to Leeds and may suggest a susceptibility to automation bias. This may be 
attributable to differences in reader experience. At Leeds Teaching Hospital, Newton’s Tree

## Page 51

Page 51 of 77 
 
recruited three reporting radiographers (each with over 10 years of experience) and one 
radiology trainee (ST3). However, at NHS Greater Glasgow and Clyde, Newton’s Tree 
recruited four radiology trainees. Furthermore, Leeds reading sessions took place during 
standard working hours (9am–5pm), whereas Glasgow sessions were spread across 
irregular hours, including night shifts and early mornings - conditions more prone to fatigue, 
distraction, and time pressure. These are known contributors to automation bias; however, 
aggregating results by site or by disease may mask individual effects. It is plausible, for 
example, that a single reader could be disproportionately influencing overall trends, 
reinforcing the importance of scrutinising individual-level data for aberrant patterns. These 
early results support the hypotheses that trends exist that indicate risk and that trends can 
reliably be presented in a real-time monitoring dashboard.   
Conclusion 
This case study explored the use of real-time monitoring techniques to assess the 
performance of AI in medical imaging across two NHS sites. The study aimed to test the 
hypothesis that useful insights about AI performance and risk can be surfaced by monitoring 
data trends in real-time. 
Initial findings suggest this is both possible and practical. The study was able to monitor AI 
performance across hospital sites with different infrastructure and staff profiles, capturing 
trends in data quality and human-AI agreement. It showed how differences in staffing, 
experience levels, and working conditions can shape how AI is used and interpreted – 
factors often missed in controlled testing environments. These insights underscore the value 
of techniques like federated evaluation, structured sampling, and human-AI agreement 
monitoring in post-deployment settings. The study also highlighted the need to look beyond 
headline metrics and examine underlying trends, including at the level of individual users, to 
identify potential risks or changes in behaviour over time. 
While the analysis is ongoing, early results suggest that real-time monitoring methods can 
surface subtle patterns that may inform both safety surveillance and product improvement. 
Further work is needed to explore how these methods might be used in practice, including 
how to respond to emerging risks and what infrastructure would be required to scale these 
approaches more broadly.

## Page 52

Page 52 of 77 
 
5. Simulations and regulatory gap analysis  
In parallel with testing conducted by candidates in virtual and real-world hospital settings, the 
Airlock team undertook a regulatory mapping and gap analysis exercise. This was 
complemented by a series of simulation workshops, which brought together stakeholders 
from across sectors and disciplines – including clinicians, regulators, academics, technical 
specialists, and innovators – to explore key regulatory challenges identified through the AI 
Airlock. This section outlines the methodology used and summarises the key findings from 
both the regulatory analysis and simulation activities.  
Regulatory mapping and gap analysis  
Regulatory gap analyses are difficult; such analyses performed in such a novel field are 
doubly difficult. The team enlisted experts from various sectors in an initial regulatory 
mapping activity. This resulted in a collation of regulatory documents and associated 
challenges. To account for limited resource and programme timelines, we prioritised 5-10 
most relevant regulatory documents for in-depth review per regulatory challenge.  
This foundational exercise proved extremely productive. By showing us how broad the term 
“regulatory gaps” could be in the context of novel AI devices, we could account for this in our 
definitions. We therefore used an equally broad definition to capture the gaps. This allowed 
us to capture wording gaps in existing guidance, context gaps in frameworks and even 
legislative loopholes.   
Within AI Airlock, therefore, the term ‘gap’ is used as a shorthand term for identifying any 
areas of improvement, recognising that many of the existing parts of the regulatory system 
must cater for the millions of hardware and software products used in the health and care 
system. It is the objective of the AI Airlock to identify these areas for improvement and 
recommend solutions.   
The AI Airlock pilot identified regulatory gaps that currently challenge the safe and effective 
deployment of AIaMD. While the nature of these gaps varied across use cases, some 
recurring themes emerged across all projects, particularly in areas of validation of text-based 
data from large language models (LLMs), risk management, non-determinism, explainability, 
and post-market surveillance (PMS). These gaps and challenges were explored in 
collaboration with four innovators: Philips Healthcare, AutoMedica, OncoFlow and Newton’s 
Tree. 
Methodology 
 
The scope of the review was primarily GB-focused, referencing the MDR 2002 and 
supplementary guidance either authored in the UK or developed through UK collaboration 
with international partners. Relevant international standards were also considered.

## Page 53

Page 53 of 77 
 
The process began with regulatory mapping. Each challenge was broken down into 
subcomponents / questions for consideration. Next, a broad range of relevant documents 
were identified  specific to each regulatory question explored in each project. This list was 
expanded in collaboration with stakeholders, including members of the supervisory 
committee, Team AB, and the candidate organisations. This initial mapping resulteds in 
approx. 30 to 40 documents mapped per project. Where regulatory information was scarce, 
such as text-based synthetic data, the broader topic (synthetic data) was considered. 
Following this initial mapping, the documents were reviewed at a high level and a subset of 5 
to 10 documents was selected for in-depth analysis. Prioritisation was based on relevance to 
the specific regulatory challenges being addressed, as well as practical considerations such 
as availability and scope. Once selected, the documents were reviewed in detail, with 
relevant clauses and sections extracted and evaluated against the needs and risk profiles of 
AIaMD. 
This deeper review focused on identifying areas where existing guidance may need to 
improve. These included where there were missing provisions related to challenges, 
insufficient detail, and unclear expectations for managing risk in adaptive, continuously 
learning systems. The analysis also considered whether existing guidance provided clear, 
enforceable requirements for real-world performance monitoring and the safe deployment of 
AI in dynamic clinical environments. 
Figure 13. Regulatory mapping and gap analysis process 
Where relevant, the identified gaps were thematically grouped and considered in terms of 
their likely regulatory impact. Particular attention was given to instances where regulations 
do not adequately address emerging risks or are impractical to implement. In doing so, the 
analysis sought not only to highlight gaps, but to build a clearer picture of where current 
regulation may require strengthening to ensure that AIaMD can be developed and deployed 
safely and effectively.

## Page 54

Page 54 of 77 
 
The analysis compared the coverage provided by existing documents against the level of 
detail needed to manage AI-specific risks in clinical settings for each challenge. Where gaps 
were identified, either through absence of guidance or insufficient detail, these were flagged 
for further consideration. 
Findings from the MHRA and candidate teams were discussed collaboratively over a series 
of virtual meetings before being consolidated into final project reports. This process helped 
highlight shared gaps across projects and areas where future regulatory development or 
clarification may be required to ensure AI medical devices can be safely and effectively 
managed in real-world environments. 
Results: Identification of key themes and gaps 
The regulatory gaps identified in this pilot vary depending on the challenge being explored. 
Most gaps apply across different candidates, given the overlaps in technology types and 
challenges.  
For the synthetic data case study, the primary focus was on unstructured text data. Synthetic 
data and the use of LLMs are not adequately addressed within current regulatory 
frameworks, including PCCP guidance and existing risk management standards, While 
documents, such as BS/AAMI 34971 acknowledge the potential of synthetic data to address 
privacy concerns and provide some guidance on its use and quality evaluation, there 
remains no clear direction on when the synthetic data should be generated, what 
prerequisites must be met beforehand, or how such data should be validated. In addition, 
there is ambiguity surrounding how “ground truth” should be determined, what metrics are 
appropriate for evaluating synthetic data, and when human validation is required. These 
issues are particularly relevant when synthetic data are used in place of real data for testing 
or training purposes. Additionally, the boundaries between synthetic and real-world data 
need clearer definition to determine whether synthetic datasets are exempt from GDPR and 
to ensure they cannot be linked back to individuals. For validating unstructured text data, 
there is a need for regulatory clarity on the use of LLMs in generating and validating such 
data. This includes the quality criteria that must be met for such data to support regulatory 
and clinical decisions.  
Thiry-one documents were identified in the regulatory gap analysis exploring challenges 
posed by AIaMDs that are prone to errors such as hallucinations. Of these, six were 
prioritised for in-depth review based on relevance and access. These included the MDR 
2002, ISO13485, ISO14971, AAMI/BS 34971:2003, IEC62304, IEC62366-1. While these 
documents provide a foundational framework, the analysis identified notable gaps relating to 
hallucinations, non-determinism and explainability, indicating that current regulations can be 
bolstered by additional guidance to support the safe and effective deployment of AIaMD. 
Several standards, including ISO14971 and ISO13485 were not developed with the dynamic

## Page 55

Page 55 of 77 
 
and opaque nature of AI in mind. Guidance around specific approaches for detecting and 
managing unpredictable outputs and validation of non-deterministic behaviour are needed. 
Including AI specific guidance, companion standards or best practice frameworks to bridge 
the gap between high level regulatory expectations and demands of implementing AI safely 
in healthcare. In addition, risks such as hallucinations could be viewed as falling within a 
manufacturer’s performance claims; however, outputs incorporated into the medical record 
are also subject to the Health and Social Care Act 2008, regulation 17. This creates a 
tension between different regulatory requirements, where clarity is needed on how 
performance considerations intersect with obligations relating to the accuracy of health 
records. 
Testing and simulation workshops consistently highlighted the critical importance of 
explainability in AIaMD, while also revealing persistent gaps in the current regulatory 
guidance. It was noted that many medical devices currently in use, including some in high-
risk settings, are not fully explainable yet are accepted within existing frameworks. This 
underscores that explainability requirements cannot be considered in isolation, but rather in 
relation to device type, risk classification, and intended use. During the AI Airlock pilot, 
explainability was therefore explored more holistically, including different stakeholder 
expectations and the absence of clear criteria for selecting appropriate metrics. While some 
relevant direction exists in standards such as ISO 13485, ISO/IEC 22989, and BS/AAMI 
34971, these do not define explainability requirements for AIaMD. Questions around the role 
of human involvement, the risks posed by non-explainable outputs, implications for usability, 
and appropriate approaches to transparency remain largely unresolved. Importantly, these 
standards do not cover the tailored approach required for different stakeholders such as 
clinicians, regulators, developers, patients, and others. Similarly, methods for implementing 
traceability and transparency to ensure usability need to be covered. Some of these 
regulatory gaps were addressed through virtual testing.  OncoFlow, for example, introduced 
confidence scoring, traffic light indicators, and human-in-the-loop validation to help clinicians 
understand and validate outputs. In addition, traceability was enabled by logging AI 
recommendations, interactions, and source documents, each with unique identifiers. 
Simulation testing also demonstrated the varying explainability needs of different users, 
reinforcing the importance of intended use in designing explainability approaches.  
 
 
 
 
 
Figure 14. Example regulatory mapping and gap analysis results

## Page 56

Page 56 of 77 
 
Collaboration between the MHRA and OncoFlow led to the development of an explainability 
statement outlining the product’s functionality, risks, and underlying AI. Guidance on content 
and structure for such documentation is still needed for innovators and products for which 
such statements are relevant. The approaches implemented as part of AI Airlock can be 
used by other AIaMD manufacturers, depending on the context of their product, its risks, 
intended use and intended population.  
A regulatory gap analysis was conducted to identify areas needing additional support for 
AIaMD PMS. The reviewed documents included the MDR 2002 PMS SI 2024 (since updated 
to The Medical Devices (Post-market Surveillance Requirements) (Amendment) (Great 
Britain) Regulations 2024 amends the Medical Devices Regulations (MDR) 2002)), Yellow 
Card system, MORE system, ISO14971, ISO13485, AAMI/BS34971, BS EN62366-1, 
ISO27001. The analysis highlighted the need to additional AI specific guidance addressing 
changes in AI model performance over time and potential for preventative action to be taken 
before patient harm has occurred. In addition, there is a need to address shifts in human 
performance and reliance on AI when interacting with AIaMD. While the existing frameworks 
provide a good foundation, and the new PMS legislation addresses many of the gaps 
surrounding trend detection and the potential for AI model drift, specific guidance would help 
strengthen current regulations. When reviewing risk management frameworks such as 
ISO14971 and AAMI/BS34971, detailed requirements and threshold setting guidance were 
lacking. BS EN 62366-1 does not fully address the usability challenges introduced by AI 
systems such as explainability and how that could feed into over-reliance or automation bias.  
An overarching challenge is the focus on corrective, reactive actions across regulatory 
documents. There is limited support for trend analysis which leads to early intervention and 
prevents an incident occurring. During testing in the AI Airlock pilot, continuous real-time 
monitoring was used to detect trends in data quality, model drift and automation bias. At one 
hospital site, the pilot identified a pattern of over-reliance on AIaMD. Given that AIaMD can 
produce errors, such over-reliance could lead to patient harm in a real-world setting.  If 
trends are detected early, by contrast, there is potential to investigate and take preventative 
or corrective action, such as patient recall. Further analysis revealed that in this case study 
example, contributing factors to automation bias included clinician fatigue, distraction, time 
pressure, and level of experience. These findings highlight the need for AI-specific 
supplementary guidance on proactive safety measures, including best practices for 
threshold-setting, monitoring AI-human behaviour, and assigning reporting responsibilities. 
Simulations methodology 
Simulation workshops gathered cross-functional input on the regulatory challenges 
associated with AIaMD. These sessions provided a forum for discussion and collaboration, 
allowing participants to explore different perspectives and work towards consensus on 
complex issues. The workshops centred on three primary themes:

## Page 57

Page 57 of 77 
 
1) evaluating current risk management frameworks regarding LLM-specific risks e.g. 
hallucinations 
2) evaluating the explainability needs of diverse stakeholders and negative 
consequences of limited explainability  
3) evaluating the responsibilities surrounding continuous monitoring of AIaMD in real-
world settings. 
 
Figure 15. Simulations methodology illustration 
Participants were selected based on their subject-matter expertise. The invitee list included 
technical experts from the NHS AI team, academic researchers, clinicians, representatives 
from approved bodies, and regulators from organisations such as the MHRA and DHSC. It 
also included clinical safety officers, data specialists from the CPRD, representatives from 
NICE with expertise in health technology assessment, and data governance experts from the 
ICO. 
Each workshop began with a set of introductory presentations to ensure that all attendees 
shared a common understanding of the AI topic under discussion and the relevant regulatory 
landscape. These presentations outlined the current regulatory frameworks, including 
applicable laws, standards and guidance. A structured discussion was then facilitated to 
address specific regulatory challenges and known gaps. The aim was to explore these 
challenges from multiple angles and to identify areas where further regulatory clarity, 
development or alignment might be needed. 
The workshops were not recorded to encourage open and candid dialogue.  MHRA team 
members took detailed notes throughout the discussions. These notes formed the basis for 
the simulation reports and informed the final synthesis of findings from the AI Airlock 
programme. These workshops have been published as an output from AI Airlock and the 
recommendations incorporated with those from virtual and real-world testing during the pilot 
programme. The simulation reports, including an overview of the key discussion points and 
insights have been published separately.  
Simulations summary results 
Considerations for hallucination evaluation  
The group explored hallucinations as a key safety risk in medical settings. Severity depends 
on both the nature of the error and its clinical context, with high-impact settings like

## Page 58

Page 58 of 77 
 
diagnosis or emergency care requiring particular scrutiny. To strengthen risk management in 
the deployment of AI, some members of the group suggested a three-tiered approach to 
categorising its use.  
At the highest level, "No-Go Areas" were identified as contexts deemed too high-risk for 
autonomous use LLMs. These could include use cases where the consequences of errors 
could be severe. In such cases, the group advised that AI should not operate without human 
oversight. In the middle tier, "Caution Zones," the group highlighted use cases such as 
clinical documentation and summarisation as areas where LLMs could be used under 
human supervision. These use cases carry moderate risk and require close human 
monitoring to ensure safety and reliability. Finally, the group defined "Safe Zones" as 
applications where the risk is relatively low, and the benefits of AI adoption are potentially 
high. These include administrative support, assistance with clinical research, and patient 
engagement, where LLMs can provide meaningful efficiencies with minimal risk to patient 
safety. This risk-based approach would help prioritise regulatory attention and clarify where 
autonomous vs. supervised AI use is appropriate based on the risks associated. 
This could help guide regulatory focus and clarify the need for human supervision. The 
group emphasised that AI should support, not replace, clinical judgement, with explainability 
features (e.g. uncertainty scores, data citations) seen as important safeguards. 
Detecting hallucinations is challenging; even clinicians may miss subtle errors. A hybrid 
approach combining explainability tools with human review was recommended, alongside 
improved awareness of reporting systems like Yellow Card and MORE. Participants also 
raised the issue of "faithfulness hallucinations", factually correct outputs outside the AI’s 
intended use. Faithfulness hallucinations are difficult to identify and can still influence clinical 
decisions or documentation, even when the AI system is not qualifying as a medical device. 
This revealed a potential regulatory blind spot with the group calling for clearer guidance on 
“function creep” and how users can identify the boundaries of appropriate use. 
Current standards (e.g. ISO 14971) provide a base safety framework, but tailored metrics for 
hallucinations are needed. These should consider not just frequency, but detectability and 
clinical impact. The group also highlighted a key trade-off: reducing hallucinations too 
aggressively could increase omission risk. Model cards summarising known failure modes 
were suggested to support informed use. 
Explainability requirements for different stakeholders 
The group agreed that different stakeholders need different types of explanations: 
developers need to debug systems, regulators need evidence of safety, clinicians need to 
judge whether to trust a recommendation, and patients need reassurance in plain language. 
The group supported tailoring explainability to each user’s needs, distinguishing between

## Page 59

Page 59 of 77 
 
global explanations (for understanding overall model behaviour) and local ones (for 
individual decisions). Too much or too little detail can both be unhelpful – interactive, layered 
explanations may offer a balanced solution. 
Current standards such as BS/AAMI 34971 and GMLP offer a foundation, but the group 
called for clearer criteria specific to different roles. They also highlighted challenges: 
complex models are hard to explain, some explainability methods add confusion, and 
simpler models may be both interpretable and effective. 
Explainability supports safety, accountability, and early error detection, especially critical 
where clinicians rely on AI. However, explainability must be human-interpretable. The group 
warned against relying on AI to check other AI, especially where models are too complex for 
meaningful human oversight. 
Participants explored techniques to improve understanding of how AI tools generate outputs, 
both for clinicians and regulators. Three core approaches were discussed: explainability 
statements, model reasoning, and quantitative methods. 
Explainability statements aim to clarify how a tool works in plain language. Participants noted 
that many current examples lack detail on how users interpret or act on outputs. A shared 
template, tailored by audience (e.g. patient, regulator), could improve consistency. Model 
reasoning, such as showing the steps a model takes from input to output, was seen as 
valuable for understanding edge cases and building clinician trust. It must be aligned with 
intended use and supported by post-market surveillance. Interfaces should offer layered 
access to detail depending on user needs. Quantitative approaches like SHAP and LIME 
can highlight which inputs most influenced an output. However, they require users to 
interpret both the model, and the method used. Participants emphasised that in most cases, 
these tools should supplement – not replace – clinical judgement. Familiar visual formats 
and summaries could support usability and trust. 
Across all methods, participants stressed the importance of surfacing missing context (e.g. 
patient preferences or lifestyle) and maintaining transparency about model limitations. 
Finally, the group stressed that insufficient explainability can lead to blind trust, automation 
bias, or unsafe decisions. Tools like model cards and confidence scores could help users 
understand what the model considered - and what it didn’t. Upskilling users and designing 
for varied levels of AI literacy were seen as essential to safe deployment. 
Post-market surveillance roles and responsibilities 
Effective post-market surveillance (PMS) of AI-enabled medical devices depends on strong 
collaboration between manufacturers and clinical teams. Understanding how these systems 
perform over time, or how they might be affected by changes in their environment, requires 
input from both those who design the technology and those who use it day-to-day in clinical

## Page 60

Page 60 of 77 
 
settings. While there is broad support for this kind of collaboration in theory, in practice it 
often falls short. Manufacturers and healthcare providers both report frustration about a lack 
of engagement from the other side. 
One area where this becomes especially important is in automating parts of the risk 
management process. AI dashboards can flag potential issues, but uncertainty around roles 
and responsibilities means it’s not always clear who should act on these signals. This 
creates a risk that problems may go unaddressed – not because they aren’t seen, but 
because it’s unclear who is accountable for responding. 
As data volumes grow, these systems could provide even greater insight into performance 
and safety. But making good use of that data requires skilled analysts and carefully 
calibrated thresholds to help distinguish important warning signs from background noise. 
Without this, there is a real possibility that existing safety reporting systems could be 
overwhelmed with low-value alerts, making it harder to identify real issues or take meaningful 
action. Crucially, monitoring alone isn’t enough. When concerns are flagged, there must be 
clear and timely follow-up. There must be agreed protocols in place so that when 
performance dips or safety risks arise, there is a shared understanding of what steps to take 
– both to prevent harm and to ensure regulatory reporting requirements are met. 
Finally, there remains uncertainty around what kinds of issues involving AI tools should be 
formally reported. Manufacturers are required to report incorrect diagnostic outputs. 
Healthcare professionals are encouraged to flag concerns through systems like the Yellow 
Card Scheme. Some are concerned that disagreements between clinicians and AI systems, 
especially if they become frequent, could flood these reporting systems – making it more 
difficult to focus on the most important risks.

## Page 61

Page 61 of 77 
 
6. Limitations and challenges  
Throughout the AI Airlock programme, a range of limitations and challenges were identified 
by both the candidates and the Airlock team. This section focuses on those relating 
specifically to the regulatory gap analysis, simulation workshops, and technical testing. 
Broader programme-level challenges are addressed in the evaluation section that follows. 
Gap analysis 
The regulatory gap analysis followed a pragmatic rather than predefined approach, with 
documents selected based on team and stakeholder input. While not systematic in the 
formal sense, the method was informed by expert judgement and evolved iteratively as the 
most relevant materials and techniques became clearer. Philips, AutoMedica, OncoFlow, 
Newton’s Tree and the MHRA reviewed different sets of documents, so some divergence in 
findings was anticipated. Prioritising a subset of the regulatory mapping documents is a 
limitation, as it may have led to the omission of relevant information in the gap analysis. 
Simulation workshops 
The simulation workshops generated useful insights, but due to the absence of a structured 
analytic framework, findings should be treated as exploratory. Time constraints prevented 
non-determinism simulation or exploration, despite the able assembled stakeholders. 
Virtual testing 
The Airlock team did not review candidate technical files. In several cases, these were not 
yet available due to the early development stage of the products. Given the exploratory 
nature of the Airlock, this was considered consistent with the programme’s objectives. 
The Airlock team did not access the datasets used for testing and therefore could not verify 
whether they met the definition of appropriate clinical data under the MDR 2002. As the 
purpose of the Airlock was to surface regulatory challenges and generate insights rather 
than to assess conformity, this approach was regarded as appropriate. 
Philips AutoImpression 
 
The regulatory mapping revealed significant gaps, as no specific guidance, standards, or 
acceptance criteria were found for generative AI, synthetic data, or large language models 
(LLMs). A notable limitation was the overlap in data use: the MIMIC-IV dataset served both 
as training data for the Claude Sonnet 3.5 LLM and as the basis for testing synthetic reports 
and impressions, contravening best practices that require strict separation of training and 
validation datasets. The clinical accuracy of the “Auto Impression” feature was not assessed

## Page 62

Page 62 of 77 
 
due to time constraints and the volume of data, restricting insights into its safety and real-
world performance. 
The LLM judge demonstrated challenges when evaluating low-quality human-written text. 
Resulting in inconsistent scoring, and its assessment methods needing refinement to better 
identify clinically significant errors. While the LLM judge showed promise, the findings must 
be validated by human experts to ensure reliability, particularly in comparing synthetic and 
real data and detecting errors. Finally, the evaluation primarily focused on the quality of 
summarisation rather than clinical correctness, meaning the potential for harmful errors in 
generated impressions remains insufficiently explored. 
SmartGuideline 
The SmartGuideline model supported only limited simultaneous users, and clinicians 
stressed that speed is essential for decision support tools designed for point-of-care use. 
The short timeframe and limited resources of the AI Airlock programme meant the team were 
unable to test economic evaluation, whether this approach works across different AI models, 
or compare the tool with manual clinical workflows. Planned semantic similarity testing using 
GPT-4o was also deferred due to cost but is intended for future work. 
The clinician sample was skewed towards trainees, which may limit generalisability. More 
experienced practitioners may interact with AI outputs differently, affecting results and 
revealing different patterns of trust or bias. 
OncoFlow 
Explainability testing of the OncoFlow AI models revealed several important challenges. The 
data extraction model, which pulls information from different clinical documents, sometimes 
produced unclear outputs when those documents contained conflicting or incomplete data.  
For example, if a radiology report suggested metastasis but the pathology report did not 
confirm it, the AI might struggle to interpret the case. When key information like tumour 
grade was missing, the system chose not to infer values, instead marking them as “Not 
Reported.” While this avoided incorrect assumptions, it also reduced the completeness of 
summaries. 
The treatment matching model information retrieval from clinical guidelines was one of the 
main challenges. If documents were poorly structured, the AI could miss key 
recommendations. In cases where retrieval failed or data was sparse – such as rare tumour 
types or experimental treatments – the model risked generating confident but unsupported 
suggestions. To reduce this risk, uncertain outputs were flagged for human review, rather 
than presented as clinical recommendations. Stakeholders also suggested allowing the

## Page 63

Page 63 of 77 
 
system to "learn" from difficult or unusual cases discussed in multidisciplinary team (MDT) 
meetings. 
Several mitigation strategies were proposed. These included traffic-lighting low-confidence 
outputs, improving how guidelines are broken into searchable sections, and using 
explainability tools like SHAP and LIME to help users understand how AI decisions were 
made. Clinicians remained in full control, with the AI acting only as a support tool. All 
decisions made with AI assistance were logged and traceable, ensuring a clear audit trail. 
Understanding which explainability approach would be optimally aligned with end-user 
needs, particularly in the live, fast-paced MDT settings remains an ongoing challenge. 
OncoFlow addressed this as part of a formal feedback discussion and simulation session 
with end-users to further inform regulatory frameworks for AI-assisted decision support 
systems. 
FAMOS 
The sample size may not provide sufficient power to detect small effects as a feasibility 
study. Results may not be generalisable beyond the participating sites due to potential site-
specific factors. Limitations inherent to retrospective studies, such as selection bias and 
missing data, may affect the findings. 
 
.

## Page 64

Page 64 of 77 
 
7. Evaluation Approach and Key Insights  
Evaluation Approach 
The University of Nottingham were commissioned to independently evaluate the AI Airlock 
pilot programme, working closely with the MHRA to understand the practices, strategies and 
challenges of conducting the pilot. The evaluation was led by Professor Carl Macrae. The 
evaluation was designed to be constructive and continuous, enabling periodic feedback to 
the AI Airlock team throughout the pilot. This chapter summarises key insights and findings 
from the independent evaluation, reflecting the MHRA’s commitment to ongoing learning and 
improvement from the AI Airlock pilot.  
Multiple sources of data were used throughout the evaluation including observations and 
attendance at governance board meetings, supervisory committee meetings, simulations 
and other events. It includes analysis of AI Airlock documentation and event feedback 
surveys. Evaluation evidence also includes the notes and feedback generated from an in-
person evaluation workshop during the Airlock Connect event.  
The data also includes detailed set of interviews conducted with many of the participants 
involved in the AI Airlock. These interviews allowed participants to feedback and report on 
experiences constructively and anonymously. 29 interview sessions were conducted 
throughout the process, engaging with a total of 25 individuals who were involved in the AI 
Airlock in different roles. These interviews were primarily conducted in two phases: towards 
the end of the testing design work, and towards the end of the AI Airlock pilot. Three focus 
groups were conducted with the MHRA AI Airlock team, supplemented by individual 
interviews with each team member. Interviews were conducted with each candidate 
organisation at two time points and included two members of each AI Airlock candidate 
organisation. Wider stakeholders were interviewed including representatives from Team AB, 
the governance board, the supervisory committee, and attendees at the simulation 
workshops.  
A key commitment of the formative evaluation is to create a safe and protected space to 
gather feedback and insight from all of those involved in the process of the AI Airlock. All 
feedback has therefore been suitably anonymised during the evaluation process.  
Insights have been themed into four broad areas;  
• Motivations, Expectations and Experiences,  
• Engagement, Exploration and Collaboration,  
• Outputs, Impact and Value and  
• Management of the Sandbox.

## Page 65

Page 65 of 77 
 
Evaluation Findings and Key Insights  
Motivations, Expectations and Experiences 
Expectations going into the novel pilot AI Airlock varied. Candidates had different 
assumptions but were all motivated by the aim of deepening their understanding of 
regulation, regulatory challenges whilst engaging with regulators and technical experts 
directly in a meaningful way. Many candidates shared a commitment to safety and risk 
management with a strong commitment to build safe technologies and systems whilst 
utilising the opportunity to engage with the regulator on shaping future regulation in this 
sector. Motivations were often linked to organisation and strategic goals, including building 
regulatory knowledge, developing robust assurance processes, and building organisational 
legitimacy. Candidates indicated that the regulatory sandbox model allowed them to engage 
in a unique process of regulatory science, by rigorously and scientifically generating new 
knowledge in a challenging and novel area with the regulator.  
The application process was seen as fair, as was the emphasis in the selection process on 
‘Airlock readiness’ which included access to data sets, virtual environments and real-world 
deployments, as required for the testing plan execution. This emphasis was driven by the 
need to identify candidates that could participate effectively with the time constrained pilot.  It 
was also evident that these candidates were already well developed in their thinking and 
capability to address a regulatory challenge and, if there had been more time available for 
the pilot testing, would have welcomed more ambitious projects.  
Some candidates found the development of testing plans more time-consuming than 
originally expected. All understood the need to focus on clearly defined regulatory 
challenges given the compressed timeline. Clearer guidance on the expectations of the 
important stages of candidate onboarding would enhance the experience for candidates. 
 
Time and resource demands were challenging and at times constrained candidates’ 
ambition for the depth of testing. They were broadly considered manageable and 
proportionate to the benefits of insight, learning, and influence on future regulatory thinking. 
It was highlighted that the testing and development activities carried out in the AI Airlock 
were well aligned with activities the candidate organisations would have expected to conduct 
at some point, and the programme accelerated and prioritised this work with associated 
accountability, resource and time commitments. The AI Airlock regulatory sandbox 
mechanism can both accelerate important regulatory work and provide structure to maintain 
focus and attention on otherwise deprioritised issues.  
“Yes, it's difficult and time consuming, but I suppose the second part is it's something we 
need to do anyway and it's sort of gives us a focus on where we spend that time” 
(candidate interview)

## Page 66

Page 66 of 77 
 
Engagement, Exploration and Collaboration  
Candidates and stakeholders consistently reported that the AI Airlock created a constructive 
environment for exploring and understanding the key regulatory challenges associated with 
AI medical devices. The AI Airlock process was generally experienced as open, exploratory, 
and highly collaborative. Candidates were actively engaged, proactive and aligned with the 
programme objectives throughout. Sandbox activities were experienced as genuinely 
collaborative, and this approach which was viewed as essential to delivering a successful AI 
Airlock pilot.  
Candidates particularly valued the range of expertise and stakeholder input facilitated by the 
AI Airlock, though many would have welcomed closer and deeper interaction with the 
broader expert network, particularly through in-person or direct conversations. The diversity 
of perspectives was widely recognised as one of the key strengths of the AI Airlock. 
Candidates felt that the short timescales limited the depth of exploration, and several 
candidates felt the involvement had prepared them for more in-depth work in future but had 
not provided the length of time or exploration that was truly needed to develop their analyses 
and address the regulatory challenge fully. 
Simulation events were understood as a learning opportunity given the high stakeholder 
engagement involved. Candidates and stakeholders felt they were the centre piece of the 
testing noting these events were especially useful because they enabled candidates to 
present detailed work and explore practical cases with diverse stakeholders and experts.  
Features such as real-world examples, small-group discussions, and relevant expertise were 
viewed as being particularly supportive of learning. The importance of balancing the breadth 
and depth of the simulation workshops was highlighted. As was the need for carefully 
curating the knowledge, expertise and representation for each activity, ensuring there is 
space for everyone to have an effective voice and avoid discussion tangents.  
There was a general preference for in-person, or single modality, meetings to support 
learning and relationship-building, though it was appreciated that the compressed timelines 
made this challenging.  
Outputs, Impact and Value  
“With some workshops… it seemed to be a very open invitation. There were a lot of 
people, but not all people were contributing. So again, being clear about — do you want 
people who are interested, or just curious about it? Is that the right thing for them to be 
invited to these workshops? Or is it that you want people who are representing different 
groups? Because if you have too many, then maybe some people had relevant things to 
say, but maybe they didn't” (Stakeholder interview)

## Page 67

Page 67 of 77 
 
The regulatory challenges addressed within the AI Airlock were viewed by candidates and 
stakeholders as important and relevant, and represented priority areas for regulatory 
attention.  It was understood that the scope of these problems was necessarily constrained 
by the AI Airlock’s tight timelines, meaning there was a focus on feasible aspects of these 
problems. Participants recognised this as a pragmatic trade-off. Some stakeholders believed 
that it would be valuable to define a key focus area or agenda for future Airlock phases to 
clarify a set of priorities from the outset and to inform the cohort design. Future Airlocks 
could be streamlined by supporting the ‘economies of attention’ that can result from all 
candidates focusing on a particular technology, application or set of closely related 
regulatory challenges. It was also noted that there may be benefit in bringing other 
regulators across the system into discussions in a more detailed and structured way, noting 
that the challenges often span multiple regulators.  
There was widespread agreement that the key outputs of the AI Airlock should be regulatory 
guidance that is practical, public, and informative. Outputs should take a range of engaging 
formats and both articulate future regulatory principles and share the regulatory sandboxing 
methods and insights so that these can be learnt from and built on by others. Stakeholders 
indicated that the outputs needed to balance being general and widely applicable, while also 
being detailed enough to move the field forward and contribute to a clearer understanding of 
the regulatory problems being addressed. Interest was shown in the sharing of the key 
regulatory challenge areas that the MHRA may look to prioritise and transparency of the 
current regulatory gaps that the MHRA would be addressing in future Airlocks or change 
programmes.  
Candidates reported a range of broader benefits of their involvement in the AI Airlock, 
including increased knowledge and deeper understanding around regulatory gaps, 
strengthened approaches to assurance and validation, and secondary gains such as raised 
public profile and enhanced legitimacy. Candidates noted that engaging in the sandbox had 
helped their organisations expand and develop their thinking and practices, particularly 
regarding the developing systematic approaches to safety testing and evaluation.. The AI 
Airlock testing allowed them to learn more clearly about which problems they should be 
approaching and how clarifying these questions and the areas of uncertainty, with a wide 
range of experts and stakeholders, was viewed as beneficial. 
Management of the Sandbox  
Managing and organising the AI Airlock required a broad skillset and at times involved 
managing an intensive workload. The AI Airlock team was able to effectively embed 
information sharing mechanisms, ongoing cycles of learning and iterative improvements 
throughout the process. This iteratively improved processes and created a collaborative 
“…the goal was to expose the challenges and needs, and it did so” (Candidate interview).

## Page 68

Page 68 of 77 
 
environment that facilitated mutual learning among all stakeholders. Several stakeholders 
and candidates highlighted the AI Airlock’s openness to learning and improvement and 
emphasised the constructive sense of experimentation that was perceived to exist 
throughout the process.  
 
The AI Airlock team needed to carefully manage and facilitate relationships between 
stakeholders and candidates, and there was a focus on ongoing two-way learning between 
the Airlock team and candidates, with support and input from expert stakeholders. Significant 
effort was put into building and maintaining relationships with key stakeholders such as 
Team AB. As with many regulatory sandbox initiatives, there were inherent tensions in 
balancing working on specific cases and organisations, with the wider aim of generating 
broadly applicable regulatory insights. Managing these tensions of critical independence and 
constructive guidance is key to an effective regulatory sandbox.  
 
These findings illustrate the importance of the MHRA’s AI Airlock management approach 
and the styles of interaction that supported and encouraged learning, that should be carried 
forward into future Airlocks: building a space for learning within a regulatory sandbox 
requires regulators themselves to acknowledge and engage in learning processes and 
acknowledge and accept uncertainties.  
“often what regulators do is, they know the law and then they will paraphrase law in all 
their guidance… and that’s not that helpful, it doesn’t really fill in the grey areas, and it’s a 
very safe playing field for the regulator, and what’s nice about this is that we can actually 
venture into the grey, and think about, ok, what is a good method?” (Candidate interview)  
“We have an Airlock firewall between us and the companies in the form of the committee, 
in the form of the Airlock group themselves, which I think has been important that's 
allowed us to maintain independence” (Stakeholder interview)

## Page 69

Page 69 of 77 
 
8. Policy Implications and Recommendations  
Approach to recommendations 
The following recommendations draw on findings from the AI Airlock pilot and are intended 
to inform the MHRA’s development of targeted regulatory guidance for AIaMD, as well as 
contribute evidence to the National AI Commission. They reflect recurring challenges 
observed across multiple projects and highlight areas where existing regulation could benefit 
from greater clarity. 
Each recommendation was developed through a structured process that involved: 
• 
Assessing the underlying evidence and the level of confidence in that evidence – for 
example, insights supported by candidate testing data from virtual or real-world 
settings, and by simulation workshop discussions had high confidence. 
• 
Determining whether the recommendation related to updates in existing policy or 
identified an area for future research or collaboration with AI Airlock partners. 
The recommendations cover key regulatory challenges, including: 
• 
AI generation and validation of synthetic unstructured text data 
• 
Managing risks associated with AI inaccuracies such as hallucinations and omissions 
• 
Reducing misuse and mistrust through explainability 
• 
Mitigating patient harm through proactive monitoring and intervention 
Addressing these areas will support the MHRA in advancing a regulatory framework that 
promotes the safe, effective, and trustworthy development and deployment of AIaMD. 
Product development: Data validation 
• 
Develop guidance on expectations for good quality synthetic data and how it should 
be assessed during development and regulatory evaluation. Guidance is also needed 
on the responsible use of synthetic data in the validation of AIaMD. This should 
include outlining appropriate use cases, minimum quality requirements for synthetic 
data in terms of fidelity, utility, and relevance of data features. These validation 
techniques may also be applicable to verifying reliability of text-based LLM outputs. 
• 
Introduce guidance for the use of LLMs in training and testing AIaMD. Consider 
covering best practices for using open-source LLMs and the quality of prompts used 
during development. Guidance should outline approaches for prompt safety, for 
example having pass/fail criteria for prompts in case significant clinical errors have 
been generated by the LLM (rather than only scoring the quality of the outputs).

## Page 70

Page 70 of 77 
 
• 
Form a position on approaches to evaluating the quality of text outputs, including 
considerations when outputs statistically significantly differ from human written reports 
but have been scored as better than human written reports (mathematical or human). 
Risk management: hallucinations and omissions 
• 
Provide clear guidance on evaluating and mitigating LLM risks such as hallucinations 
and omissions in AIaMD. This should include support for end users with clear 
information on identifying and reporting safety events. Guidance should also 
emphasise the importance of PMS, including mechanisms like the Yellow Card 
scheme and MORE as hallucinations may be rare during pre-market testing.  
• 
Encourage, in guidance, safety measures such as retrieval augmented generation 
(RAG) given the potential to reduce hallucinations and support safer, more 
explainable outputs. As part of this guidance, it is important to highlight the 
importance of holistic safety testing after any model adjustments in case other errors, 
e.g., omissions, increase. 
Risk management: Explainability 
• 
Emphasise in regulatory guidance the importance of developers adopting context-
aware explainability approaches that account for the clinical question, associated risk 
and time constraints on the end user. Different stakeholder groups may require 
different types of explanations: global explanations may be most useful for regulators 
and policymakers while local case-specific explanations may be more important for 
clinicians and patients. 
• 
Strengthen in guidance transparency and training requirements for AIaMD and warn 
against the risks of insufficient user training. Structured outputs such as confidence 
indicators or other visual aids should be encouraged. Context-specific clarity around 
the human-AI teaming expectations should be promoted to improve shared decision-
making. Training should be implemented with clear accessible user-facing 
communication about AI-specific risks. 
• 
Emphasise, in guidance, the importance of explainability in conjunction with good 
machine learning principles and other safety and risk management approaches. 
Where appropriate, AI models should communicate both what has informed a 
decision and what has been excluded to reduce the risk of automation bias, defensive 
medicine, and risks to patient safety. Developers can implement various approaches 
such as model reasoning and model cards to make these factors transparent to the 
end user.  
Post-market surveillance

## Page 71

Page 71 of 77 
 
• Promote greater awareness and use of reporting tools such as MORE and Yellow 
Card among clinicians, patients, and the obligations on manufacturers. This should be 
supported by educational initiatives and stronger collaboration between 
manufacturers and healthcare organisations to improve reporting and ensure PMS 
data are complete and meaningful. 
• Provide guidance which supports the development and implementation of continuous 
monitoring for AIaMD. These mechanisms should track key metrics to detect issues 
such as automation bias. Proactive monitoring enables early detection of safety 
concerns and should be accompanied by clear follow-up protocols for investigation 
and action. 
• Develop guidance which provides examples of approaches for threshold setting for 
continuous monitoring. Manufacturers should determine thresholds through a socio-
technical approach, combining clinical and technical expertise which balance early 
warnings with minimising false alarms. A tiered system may be useful for triggering 
additional monitoring before requiring intervention. 
• Emphasise the importance of follow-up protocols for threshold breaches in the post-
market surveillance process. Monitoring alone may be insufficient to ensure safety; 
breaches should be investigated and where appropriate acted upon. Guidance needs 
to be clear on regulatory requirements for reporting preventative and corrective action 
taken.

## Page 72

Page 72 of 77 
 
9. Conclusion and Next Steps 
The AI Airlock pilot explored the potential and the practical challenges of developing and 
deploying AIaMD. Our synthetic radiology case study demonstrated that large language 
models can generate diverse, clinically relevant text data, provided that rigorous automated 
and human evaluation methods are employed to confirm data fidelity, clarity, accuracy and 
completeness. The standardisation of these evaluation methods needs to be outlined in 
guidance.  
Our data extraction and treatment-matching studies demonstrated that retrieval-augmented 
architectures and rule-based prompting can be effective while maintaining high accuracy on 
complex tasks. Holistic testing helped to minimise omissions and other safety risks. 
Explainability mechanisms enhanced user trust and understanding, though these must be 
complemented by ongoing user education and continuous monitoring. Our real-time 
surveillance case study demonstrated that a monitoring dashboard can be effective at 
identifying trends in data quality, model drift and automation bias, enabling early intervention 
before patient harm could occur. Our regulatory gap analyses and simulation workshops 
identified key areas where AI-specific supplementary guidance is needed to strengthen 
existing frameworks. 
Through the AI Airlock pilot, we have identified a series of key challenges that illustrate the 
novel regulatory considerations posed by AI in healthcare. This work has culminated in 40 
recommendations, covering both areas for immediate implementation and those requiring 
further exploration. These findings will inform the AIaMD guidance currently in development, 
as well as future MHRA policy. 
The AI Airlock directly supports the work of the National AI Commission in establishing a 
credible, international regulatory framework for the safe and effective use of AI in health. The 
pilot will provide the practical evidence base and operational insights needed to address 
complex regulatory questions. 
Building on this foundation, the next phase of the Airlock will generate further evidence and 
test solutions to these challenges. Its findings will be fed directly into the Commission’s work, 
ensuring that the Commission’s recommendations are informed by robust, real-world 
evidence and implementation experience. 
Plans for the next phase 
The government confirmed in its Regulatory Action Plan on 17 March 2025 that the AI 
Airlock will continue into Phase 2 for the FY 25/26.  
Our strategy for Phase 2 will have two main missions: Unlock and Expand.

## Page 73

Page 73 of 77 
 
Our Unlock mission includes the sharing of the learnings from the pilot phase, both 
regulatory and the use of sandboxes. We are also developing a programme of activity to 
boost the impact of the insights in the sector alongside policy changes.  
Our Expand mission involves our work with a new cohort and looking to identify areas across 
the MHRA, healthcare academic and international regulatory sectors for collaboration 
opportunities to expand the scope of regulatory challenges the AI Airlock can investigate.  
Phase 2 will run until end of March 2026. We will work with a new cohort of candidates and 
test a new set of regulatory challenges for these innovative devices to improve regulations, 
guidance and, ultimately, patient outcomes.  
Acknowledgements  
The MHRA would like to acknowledge the hard work of the pilot programme candidates at 
Philips Healthcare, AutoMedica, OncoFlow and Newton’s Tree. Each organisation dedicated 
their time and motivation to the pilot testing phase and their experience will not only shape 
the next phase of the AI Airlock sandbox but also inform future guidance and policy within 
the MHRA. 
 
We would also like to thank our expert stakeholder network, starting with the members from 
the Governance Board and Supervisory Committee. Representatives within these groups 
have included throughout the pilot, Royal Derby Hospital, Department for Health and Social 
Care, NHS AI Lab, Brunel University, University of Birmingham, Health Research Authority, 
Information Commissioner’s Office, Team AB, Scottish Government, Health Technology 
Wales, Department of Health Northern Ireland, National Institute for HealthCare Excellence 
(NICE), University of Nottingham, University of Oxford, and across the MHRA. 
 
Thank you to our partners within the Team AB Software and AI working group who have 
been open to a new way of working throughout the AI Airlock regulatory sandbox, 
responsive and engaged when asked to support throughout the testing and regulatory 
mapping activities. We look forward to continuing to work with these partners in the future 
phase.       
 
Thank you to our pilot phase sponsors at the NHS AI Lab team and the Department of 
Health and Social Care.

## Page 74

Page 74 of 77 
 
10. Appendices  
AI Airlock Candidates  
 
Philips Healthcare: Results 
 
Linguistic similarity 
 
To make sure that the synthetic reports maintained the same linguistic style as original 
reports, Philips evaluated linguistic similarity using the following metrics: GLEU, ROUGE, 
Parts-of-Speech Overlap and Automated Readability Index (ARI). 
 
Table s1. Linguistic similarity metrics 
 
Metric 
What it 
measures 
What it means for 
comparing radiology 
reports 
Limitations 
GLEU 
Balanced n-
gram precision & 
recall 
Could be used to 
measure sentence-level 
similarity of real and 
synthetic reports 
Sentence-level metric, not 
informative for texts with 
multiple sentences and no 
direct sentence-to-
sentence mapping  
ROUGE-L 
Longest 
common 
sequence (LCS) 
overlap 
High ROUGE score 
indicates that reports 
have similar phrasing but 
slight variations 
Doesn’t capture deep 
semantics 
POS Tag 
Overlap 
Part-of-speech 
usage 
Ensuring similar 
grammatical structure 
Doesn’t capture semantics 
ARI 
Automated 
Readability 
Index (ARI)** 
estimates 
understandability 
of English texts 
based on 
evaluating 
chars/words and 
words/sentences 
ratios. 
Similar ARI scores 
indicate that real and 
synthetic findings have 
similar length of words 
and sentences => have 
similar writing style.  
Non-robust with respect to 
slight variations in 
punctuation and numbers 
 
For each report, the experts scored the following points: Clinical Content Similarity, Linguistic 
Style Similarity, Understandability compared to the original report.

## Page 75

Page 75 of 77 
 
Evaluation dimensions of the Impression section using LLM as a judge 
 
The Impression section was evaluated against four metrics: accuracy (faithfulness to the 
content of the findings), completeness (coverage of important findings), clarity (readability 
and interpretability of the test), and groundedness (ensuring statements are justified by 
underlying findings).  
 
Accuracy was measured as alignment between “Findings” and “Impression,” quantified on a 
0-10 scale, and justified with structured text explanations. 
 
• Definition of accuracy: whether the IMPRESSION section correctly reflects the key 
findings and conclusions from the clinical report. 
• Scoring method: LLM judge was asked to give a numerical score from 0 to 10. 
o A score of 0 is required if there is no IMPRESSION section at all. 
o Other scores (1–10) depend on how well the IMPRESSION matches the 
findings. 
• Justification: the LLM judge must provide two kinds of written reasoning: 
o "motivation" ➔ general reasoning. 
o "scoremotivation" ➔ reasoning tied to why that specific score was given. 
• Format: output must be structured JSON with the fields "motivation", 
"scoremotivation", and "score", following strict formatting rules. 
 
Completeness was measured as coverage of all relevant findings in the IMPRESSION, 
expressed on a 0-10 scale, with structured justifications. 
• Definition of completeness: whether the IMPRESSION section contains all relevant 
information from the findings and does not leave out any critical details. 
• Scoring method: the LLM judge must assign a numerical score between 0 and 10. 
o A score of 0 must be given if there is no IMPRESSION section at all. 
o Scores 1-10 reflect the extent to which the IMPRESSION covers all key details. 
• Justification: the LLM judge must provide written reasoning in two parts: 
o "motivation" ➔ overall explanation. 
o "scoremotivation" ➔ specific justification for the chosen score. 
• Format: output must be structured JSON with the fields "motivation", 
"scoremotivation", and "score", following strict formatting rules. 
 
Clarity was measured as how understandable and well-written the IMPRESSION is, 
expressed on a 0–10 scale, with structured justifications. 
• Definition of clarity: whether the IMPRESSION section is clearly written and easy to 
understand.

## Page 76

Page 76 of 77 
 
• Scoring method: the LLM judge must assign a numerical score from 0 to 10. 
o A score of 0 is required if no IMPRESSION section is present. 
o Scores 1-10 indicate the degree to which the text is understandable and clearly 
expressed. 
• Justification: the LLM judge must provide explanations in two fields: 
o "motivation" ➔ general explanation of the assessment. 
o "scoremotivation" ➔ specific reasoning for the numerical score chosen. 
• Format: output must be structured JSON with the fields "motivation", 
"scoremotivation", and "score", following strict formatting rules. 
 
Groundedness was measured as the extent to which the IMPRESSION is supported by 
evidence in the findings, expressed on a 0-10 scale with structured justifications. 
• Definition of groundedness: whether the IMPRESSION section is based on, and 
supported by, the evidence and findings in the clinical report. 
• Scoring method: the LLM judge must assign a numerical score between 0 and 10. 
o A score of 0 is mandatory if there is no IMPRESSION section. 
o Scores 1-10 reflect how well the IMPRESSION is tied to the underlying findings 
(e.g., not introducing unsupported statements). 
• Justification: the LLM judge must explain their assessment in two fields: 
o "motivation" ➔ general explanation of their reasoning. 
o "scoremotivation" ➔ specific justification tied to the numerical score. 
• Format constraint: assessment must be returned in JSON with the required fields, 
following strict formatting rules.

## Page 77

Page 77 of 77 
 
Table s2. Example of scoring system for comparative analysis 
 
 
Not 
similar at 
all 
Slightly 
similar 
Moderately 
similar 
Very 
similar 
Extremely 
similar 
 
1 
2 
3 
4 
5 
Clinical Content Similarity  
 
 
 
 
Linguistic Style Similarity 
 
 
 
 
 
Understandability 
 
 
 
 
 
 
In addition, an independent analysis for each report was carried out. The experts scored the 
following points: Language, Structure, Completeness, Clinical Soundness 
The scale for the reports was as follows: 
 
0: Not Professional / Not Expected in Radiology Report 
1: Minimally Professional / Below Clinical Standards 
2: Somewhat Professional / Needs Improvement 
3: Moderately Professional / Meets Basic Clinical Standards 
4: Professional / Above Clinical Standards 
5: Highly Professional / Fully Expected in Radiology Report


---

# MHRA Software and AI as a Medical Device Change Programme roadmap

- **Issuer:** MHRA
- **Type:** Report
- **Language:** en
- **Source:** https://www.gov.uk/government/publications/software-and-ai-as-a-medical-device-change-programme/software-and-ai-as-a-medical-device-change-programme-roadmap
- **Licence:** OGL-UK-3.0

## Section: Software and AI as a Medical Device Change Programme roadmap

Updated 14 June 2023

## Section: Introduction

Software (including Artificial Intelligence (AI)) plays an essential part in health and social care. In the UK, many of these products are regulated as medical devices. Last year, the MHRA announced the Software and AI as a Medical Device Change Programme, a programme of work to ensure regulatory requirements for software and AI are clear and patients are protected. This Programme builds upon wider reforms for medical devices as a whole detailed in the Government response to consultation on the future regulation of medical devices in the United Kingdom. Set out below is further information on each work package of the Change Programme, including deliverables to meet each set of broad objectives, and further information on how the broad Change Programme will be implemented.
The Change Programme will deliver bold steps to provide a regulatory framework that provides a high degree of protection for patients and public, but also makes sure that the UK is recognised globally as a home of responsible innovation for medical device software looking towards a global market. Broadly, to achieve this aim, we will focus on ensuring that:
**A.**The requirements for software and AI as a medical device provide assurance that these devices are acceptably safe and function as intended, thereby protecting patients and public.
**B.**The requirements for manufacturers are clear, supported by both clarificatory guidance and streamlined processes that work for software, as well as bolstered with the tools to demonstrate compliance, for instance, via the designation of standards.
**C.**The friction is taken out of the market by working with key partners such as the National Institute for Health and Care Excellence (NICE) and NHS England to align domestically, de-duplicate, and combine requirements, ultimately providing a joined-up offer for digital health within the UK. Internationally, we will work with other regulators both bilaterally, and multilaterally through the International Medical Device Regulators Forum (IMDRF) to strengthen international convergence and consensus on software and AI products.
This programme includes eleven work packages across two workstreams. The first stream contains eight work packages to make key reforms across the software as a medical device (SaMD) lifecycle, the second stream has three work packages and considers the challenges that AI as a medical device (AIaMD) can pose over and above classically programmed software.

## Section: Legislative change

Some (but not the majority) of the changes intended will be in the form of secondary legislation, these have been consulted upon as a part of a consultation on the future regulation of medical devices in the United Kingdom. Much of the programme builds upon legislation through guidance, for instance, by clarifying what medical device requirements mean in the context of software and AI.

## Section: Developed across government

This programme of work has been developed with support and input across government and the NHS as well as with targeted engagement with devolved administrations, trade associations, academia, and industry partners. Much of the work below will continue to be developed in collaboration with partner organisations in the Multi Agency Advisory Service, namely NICE, Care Quality Commission (CQC), and Health Research Authority (HRA).

## Section: Patient centred, supported by industry

We will also announce plans for patient/public and industry engagement to support this work programme. We recognise that the use of AIaMD raises broader societal questions and that the public voice needs to be heard in establishing how the MHRA regulates these devices to ensure safety. The new regulatory framework must also be pragmatic and attract responsible innovation to the UK. Building on the existing MHRA Patient and the Public Engagement Strategy, we will engage patients, public, and the wider sector (including healthcare and industry) throughout this change programme and most of these deliverables will be released first as drafts for wider comment and input before being published.

## Section: Inclusive innovation

The MHRA recognises that SaMD and AIaMD must perform across all populations within the intended use of the device and serve the needs of diverse communities. We will build on wider work examining health inequalities in medical device regulation, ensuring specific work on SaMD and AIaMD builds on that foundation, focusing on specific issues that AIaMD can pose over and above medical devices.

## Section: Leading regulatory innovation that drives international harmonisation

We are sensitive to the fact that regulatory innovation that departs from international consensus can create an additional burden for the market. We want to see effective products brought to patients quickly, supported by the evidence for their safe use and to facilitate safety surveillance. Accordingly, we intend to drive forward international consensus in this area and redouble our contributions to groups such as the IMDRF as well as through wider bilateral and multilateral efforts that accelerate regulatory innovation and harmonisation to minimise that burden on industry.

## Section: Tools to demonstrate conformity

We recognise that many of the deliverables below require the development of standards and tools to help manufacturers clearly demonstrate that their device meets the requirements set. We are therefore working closely with British Standards Institute (BSI) in its role as the UK national standards body, to ensure that there is a wide set of standards to help manufacturers meet the regulatory requirements. Together with BSI, we will jointly publish opportunities for existing and future standards mapped against the work packages. Additionally, we are collaborating with groups in the wider setting of standards for study reporting and assurance frameworks.

## Section: Principled but practical

We recognise that there are key elements of SaMD and AIaMD that we do not directly regulate but must not ignore. For instance, SaMD and AIaMD often process personal data and so we are working in partnership with both the Information Commissioner’s Office and the National Data Guardian to consider these elements as they relate to patients, such as data leaks and trust in products. We recognise broadly agreed ethical principles for AI in health and social care and are cognizant of those principles as well as complementary principles such as the Office of AI’s Establishing a pro-innovation approach to regulating AI when developing our regulatory framework.

## Section: Work packages

The major work packages in the Software and AI as a Medical Device Change Programme are set out below, and other work packages, for example WP 8 on Mobile Health and Apps, are nested within or spread over multiple work packages. We describe the problem that work packages seek to address, the objectives that break down that problem, and the specific deliverables that meet the ambition.
Many work packages build on the conclusions of other work packages and so we identify the key links between work packages wherever possible.
Finally, the below work packages have one primary aim: to protect patients and public whilst ensuring that we accelerate responsible innovation.
We will publish the below deliverables in a stepped manner: the first tranche (WP1-02, WP4-01, WP9-02, WP9-05, WP11-01) are currently intended to have first drafts published before the end of 2022. Further tranches shall be announced in due course.

## Section: WP 1 Qualification

**Problem statement:** There is currently a lack of clarity as to what qualifies as SaMD<sup>\[footnote 1\]</sup> and software in a medical device; this clarity is required to ensure appropriate, effective and proportionate regulation of these devices.

## Section: Objectives

1. Ensure medical device regulations capture sufficient breadth of software to protect patients and public
2. Ensure there is sufficient clarity yet flexibility of qualification to effectively and proportionately regulate SaMD
3. To improve the wider regulation of digital health, through supporting and working with other regulators and processes where software does not qualify as a medical device

## Section: What qualifies as SaMD?

It can be difficult to establish what qualifies as SaMD or software in a medical device.
We will publish guidance that brings clarity to a range of issues that have become evident as SaMD has evolved. Over time, this guidance will seek to clarify the following distinctions with respect to software:
- SaMD versus wellbeing and lifestyle software products
- Medical device software versus IVD software
- Medical devices versus medicines and companion diagnostics
- Any requirements that might apply to ‘in house’ SaMD
- Research use only ‘exemption’ for SaMD
- Custom made devices
- Requirements for software in a kit / software system / software in procedure pack / software as a service<sup>\[footnote 2\]</sup>
- Accessories to a medical device or IVD
- Devices with no medical function
We will also link this work with separate work on Classification of SaMD and to the UK Borderlines Manual, ensuring industry is provided with ample examples to illustrate key boundaries.

## Section: Crafting an intended purpose in the context of SaMD

The cornerstone to almost any activity required by medical device regulation is having a well-crafted and defined intended purpose. Failure to adequately define the intended purpose of SaMD will impair any subsequent efforts to comply with medical device regulation. For instance, designing a robust quality management system becomes much more difficult, ambiguity will impede the generation of sufficient clinical evidence, and the implementation of an adequate post market surveillance system will be hampered.
The MHRA will develop guidance assisting manufacturers to:
- Define the intended purpose of their medical device with adequate specificity
- Avoid common pitfalls when defining intended purposes, for instance, the issue of ‘hydra devices’, devices with many specific intended purposes but no overarching intended purpose
- Clearly articulate what populations are within scope of the intended purpose, linking this to clinical evidence
- Understand how intended purposes link to quality management systems, risk management, and other processes
- Indicate when and how intended purposes should be revisited and how to expand intended purposes

## Section: Clarifying the concept of ‘manufacturer’ for SaMD

We recognise that software can be deployed and modified in such a way that it can be uncertain what entity – if any – counts as a manufacturer. For instance, one issue is open-source code. If the code is written and made available, then subsequently modified, the entity making the modified version may take on the responsibilities of the manufacturer of this modified code if it qualifies as a medical device. We will also seek to clarify the status of those that deploy SaMD via third party websites.
The MHRA will develop and publish a policy position on the implications for the ‘manufacturer’ and associated guidance to help guide to the appropriate route to market.

## Section: WP 2 Classification

**Problem statement:** Currently, the Medical Device Regulations 2002 (as amended) do not classify software proportionate to the risk it might pose to patient and public safety.

## Section: Objectives

1. Ensure classification rules closely follow the risk that specific SaMD poses to patient and public safety where this is known
2. Ensure classification rules impose safety and performance requirements proportionate to the risk which SaMD applications pose
3. Ensure that classification rules provide sufficient flexibility so that the risk profile of novel devices can be addressed without needlessly restricting innovation.

## Section: Reform of classification rules for SaMD

We will bring forth secondary legislation to implement rules more closely aligned to the IMDRF Software as a Medical Device: Possible Framework for Risk Categorization and Corresponding Considerations.
We are working with NICE on its Evidence Standards Framework to ensure this aligns with SaMD classification rules wherever possible.

## Section: Exploration of an ‘airlock process’ for SaMD

Some manufacturers of innovative products that meet a critical unmet clinical need may struggle to generate evidence in the premarket phase. Accordingly, this process will allow software to generate real world evidence for a limited period of time while being continuously monitored.
If we decide to proceed with this proposal, we will consult further on how to develop an approach to allow for heightened monitoring of a SaMD in the early stages of its lifetime, whilst a better understanding of the risk profile is generated.
We will undertake further work to develop and implement an ‘airlock process’ (akin to a regulatory sandbox) for SaMD. This process will be applied:
- According to set of criteria applied by MHRA and / or Approved Bodies
- Allow for heightened monitoring of the device
- Have a clear set of entry and exit criteria.
We propose that manufacturers will be able to gain access to the UK market earlier, and in a controlled manner to generate the evidence to better understand the risk profile and the final risk classification of the device.

## Section: Guidance on classification rules for SaMD

New classification rules will require robust guidance to ensure sensible and consistent interpretation.
We will publish guidance outlining key terms not defined in secondary legislation, ensuring this guidance is supported by a robust set of examples to clarify any borderline issues.

## Section: WP 3 Premarket requirements

**Problem statement:** Clearer premarket requirements that fit software are needed to ensure a smoother path to market for manufacturers and better protection for patients and the public.

## Section: Objectives

1. Ensure SaMD is supported by adequate data on safety, effectiveness, and quality prior to being placed on the market, ensuring these requirements are proportionate to the risk the device presents
2. Ensure that premarket requirements, especially clinical evidence and clinical investigation requirements, are clear in how they apply to and are appropriate for SaMD
3. Ensure that any premarket submission includes all necessary information to support the safe use of SaMD.

## Section: Review of essential requirements for software

The essential requirements in the Medical Devices Directive are no longer in line with international best practice.<sup>\[footnote 3\]</sup> An update is needed to ensure they provide robust assurance that software meets its intended purpose and is safe for patients and users.
We have already reviewed the current essential requirements, considering:
- Necessary modifications to existing essential requirements to reflect the nature of SaMD and AIaMD
- The need for additional essential requirements that relate to SaMD and AIaMD
- Ease of use changes, such as sub-dividing those essential requirements for software in particular
The results of this review are detailed in the government response to the Consultation on the future regulation of medical devices in the United Kingdom.

## Section: Best practice SaMD development and deployment

Best practice for SaMD development requires the best of both software development and medical device development.
We will work with BSI as the UK national standards body to review existing best practice development and deployment activities for SaMD as outlined by designated standard IEC 62304, amongst others. This assessment will look for areas of improvement across the lifecycle from the regulator’s perspective with particular focus on safety by design and deployment strategies.
The new MHRA guidance will not replace IEC 62304 or other key standards utilised by manufacturers of SaMD, but it will serve to highlight areas where current best practice may not meet regulatory requirements or regulatory definition of the ‘state of the art’.<sup>\[footnote 4\]</sup> This work will be useful in seeking to align the expectations of manufacturers and the standards community with regulatory requirements and we will provide updated guidance as the state of the art advances. We will also highlight current state of the art with respect to avoiding bias and ensuring adequate representation of populations within the intended purpose.

## Section: The position of retrospective non-interventional studies

Currently it is unclear whether retrospective non-interventional performance studies for SaMD might require notification to MHRA as a clinical investigation or registration with MHRA as an IVD undergoing performance evaluation.
We will update existing guidance to indicate when these studies qualify as clinical investigations or an IVD undergoing performance evaluations, thereby clarifying what needs to be notified or registered with us.

## Section: Data-driven SaMD: Research, Development, and Governance

We will work with the Health Research Authority (HRA) to produce joint regulatory guidance that highlights:
- The main points of consideration from both the perspective of governance of research as well as medical device development
- The major processes that need to be undertaken and the key points at which these processes begin.
- The key pieces of existing guidance to support all of the above
It is expected that this joint guidance will clarify how the medical device and research governance process relate to one another and how best to address both sets of requirements.

## Section: Human-centred SaMD

‘Human-centred’ here refers to the concept of ‘human-centred design’ that is ‘an approach to interactive systems that aims to make systems usable and useful by focusing on the users, their needs and requirements, and by applying human factors/ergonomics, and usability knowledge and techniques.’<sup>\[footnote 5\]</sup>
The risk that users will systematically misinterpret the outputs of software or be otherwise adversely influenced by using the software is often not effectively mitigated against or addressed in existing evidence, leading to safety concerns.
We will produce regulatory guidance clarifying the importance of human factors, usability, ergonomic, or behavioural science evidence, linking this literature to essential requirements, and expanding upon the earlier deliverable Best practice SaMD development and deployment.
It is also anticipated that there will be a complementary programme of work to support and expand upon this initial guidance.

## Section: Registration and nomenclature for SaMD

Existing nomenclature as it applies to software can be broad and imprecise, thereby impairing effective signal detection for these devices.
We will work to advance nomenclature for software (as a medical device), towards sufficient granularity to better enable signal detection and post-market trending. Wherever possible we will work with existing bodies such as the Global Medical Device Nomenclature (GMDN) Agency to improve alignment with other regulators.

## Section: WP 4 Post Market

**Problem statement:** The safety signal for SaMD that MHRA receives needs to be stronger. The post market surveillance system needs to be adapted so that signals are received and not lost to noise. This is needed to enable stronger vigilance by manufacturers and to detect and mitigate the risk of patient safety incidents. Additionally, change management requirements also require review given the challenges seen in the software, including but not limited to rapid updating.

## Section: Objectives

1. Strengthen our post market surveillance system to support quicker and more comprehensive capture of adverse incidents for SaMD, enabling better detection of safety signals,
2. Consider how to utilise real world evidence to provide further assurance that SaMD functions as intended, maintains performance, and continues to provide assurance with respect to safety by supporting investigation of signals
3. Articulate clear change management requirements for SaMD

## Section: Review of adverse incident signal detection for SaMD

We have already conducted a preliminary analysis of the individual case reports identified for SaMD and the processes that analyse and flag concerns. We will:
- Consider what additional sources of data would support detection of safety signals to better identify the potential risks SaMD poses
- Consider how best to highlight the benefits of reporting adverse events via the Yellow Card Scheme
- Consider how to better curate and analyse the totality of data to generate safety signals for SaMD
- Consider revision to standard operating procedures and processes so that the MHRA recognises SaMD risks early and responds swiftly, monitoring the impact of risk mitigation measures
All of this together will ensure that we identify safety signals sooner, have the tools to distinguish between signal versus noise, and act swiftly in response to signals of concern, improving patient and public safety.

## Section: Adverse incidents in the context of use of SaMD

Currently, we receive relatively few reports of adverse incidents from manufacturers and users in relation to SaMD; investigations indicate that adverse incidents considered reportable by MHRA are often not reported. One reason is the failure to recognise the potential ‘indirect harm’ that SaMD might cause.
We will produce guidance clarifying:
- What constitutes a reportable adverse incident, emphasising ‘indirect harm’ in the context of SaMD use
- The requirements for reporting,providing an overview of different examples of reportable incidents
- Emphasise that harm may occur because of a medical decision, action taken or not taken based on the information or results provided by the device
- Indication of appropriate next steps, depending on the incident in question, for instance, how to report the incident to MHRA
- Emphasis on ensuring populations within the intended purpose are considered within the vigilance process

## Section: Change management for SaMD

Change management requirements and how they apply to SaMD must be clearer, this clarity being required to ensure these devices maintain performance over time and that patients as well as public are protected.
We will produce guidance that makes plain:
- The key principles of change management in software and how change management links to the earlier deliverable Best practice SaMD development and deployment
- How change management links to quality management systems, risk management, and other requirements
- That change should be anticipated, planned, and documented
- That there is an obligation to actively monitor and collect information to avoid degradation in performance over time
- We will distinguish between intentional change anticipated by the predetermined change control plan, intentional or unintentional change not anticipated by that plan, and changes to the intended purpose of the device.
This guidance will have a necessary link to the development of predetermined change control plans outlined below.

## Section: Predetermined change control plans and change protocols

More often than not, change in SaMD is to be expected and should be anticipated but current change management procedures can be cumbersome to keep pace with such change.
We will make provision in secondary legislation for predetermined change control plans (PCCPs) for SaMD. Additionally, we will craft a procedure that:
- Details a change management process to anticipate change in software over time and detail how this process links to existing quality management and risk management procedures
- This change management process will be likely to include two primary elements: SaMD Pre-Specification and Algorithm Change Protocol
- Provide details on how to define what metrics to track and how to agree performance ‘bands’, such that change inside those bands does not have to be reported to MHRA or the Approved Body
- Outline how the change management process itself links to aspects of the product lifecycle to maximise operational effectiveness whilst minimising product risks
We will work with Approved Bodies to jointly develop these plans and procedures. Additionally, wherever possible, we will work with international regulators to develop this into a globally harmonised process.

## Section: Expansion of intended purposes of SaMD

It is common for SaMD to expand the intended medical purpose, intended population, or intended users over time. However, this expansion in the intended purpose of a device must be supported by corresponding expansion in clinical evidence, proper documentation, and reporting.
We will produce regulatory guidance linking to both the previous work package outputs on defining SaMD intended purpose and best practice development guidance, that details how expansion of SaMD intended purpose should occur supported by evidence and the proper processes that should be undertaken.

## Section: WP 5 Cyber Secure Medical Devices

**Problem statement:** Existing medical device regulations do not currently consider the evolving state of the art for mitigating the risks presented by cyber security vulnerabilities and the operational issues presented by legacy software medical devices and systems.

## Section: Objectives

1. Articulate how cybersecurity issues translate to SaMD issues
2. Ensure that cybersecurity is adequately reflected in SaMD requirements and in post market surveillance requirements
3. Work closely with other bodies, for instance, through the Connected Medical Device Security Steering Group to ensure SaMD cybersecurity policy capitalises on synergies

## Section: Cybersecurity requirements for medical devices and IVDs

Increasingly, many medical devices and IVDs include software and are often networked, meaning that non-malicious or malicious interference with the device can lead to malfunction of the device, loss or tampering with personal data, damage to the device, and ultimately injury to the patient.
As outlined in the government response to the consultation on the Medical Devices legislation, we intend to develop secondary legislation to impose cybersecurity and IT requirements to guard against the above risks. This secondary legislation will:
- Align with the Connected Medical Device Security Steering Group principles
- Be consistent with and build upon complementary requirements such as the Department of Culture, Media, and Sport’s Product Security and Telecommunications Infrastructure Bill, NHS DCB (Data Coordination Board) standards, and NHS Digital Technology Assessment Criteria requirements
- Be harmonised with international best practice

## Section: Guidance elucidating cybersecurity requirements for medical device and IVDs

Future requirements in legislation will require supporting guidance to interpret and make clear what the legislative positions require.
We will produce guidance on cybersecurity and related requirements for medical devices and IVDs; this guidance will:
- Position cybersecurity issues in the context of lifecycle management processes
- Make plain that cybersecurity and related issues constitute shared responsibilities, most often between the manufacturer, systems manufacturers, and local deploying organisation
- Clarify specific requirements and responsibilities that primarily fall to the manufacturer of the device
- Clarify necessary reporting of cybersecurity vulnerabilities for medical devices and IVDs
We will develop this guidance with the Connected Medical Device Security Steering Group and other relevant stakeholders.

## Section: Management of unsupported software devices

Manufacturers may not have a plan to exit the market for their products. This fact in the context of software produces unique risks, unsupported devices that are no longer maintained by their manufacturer still being in service, despite the security and safety risk they might pose. These risks must be more effectively managed.
We will produce best practice guidance for manufacturers, system providers, and local deploying organisations on how best to manage the risks that unsupported devices might present. This guidance will link to previous guidance on cybersecurity requirements more generally and emphasise the shared responsibilities between the various actors identified.
We will work with key stakeholders, primarily through the joint NHS Digital and MHRA Connected Medical Device Security Steering Group to develop this guidance.

## Section: Reporting of relevant cybersecurity vulnerabilities

Currently, we receive relatively few reports of cybersecurity vulnerabilities connected to medical devices, but as these vulnerabilities can lead to serious adverse incidents, we should improve reporting procedures to enable proactive mitigation of harm.
We will work closely with industry to clarify, bolster, and make consistent reporting of cybersecurity incidents and any vulnerability identified from manufacturers. In addition, we will also make plain the requirements to report these vulnerabilities, as outlined in earlier guidance on cybersecurity requirements.
Please note that work packages 6, 7 and 8 do not have discrete deliverables assigned to them in this programme. The content of these work packages has been absorbed into wider SaMD and AIaMD deliverables outlined in this programme.

## Section: WP 9 AI RIG (AI Rigour)

**Problem statement:** There is a lack of clarity on how to best meet medical device requirements for products utilising artificial intelligence, to ensure these products achieve the appropriate level of safety and meet their intended purpose.

## Section: Objectives

1. Utilise existing regulatory frameworks to ensure AIaMD placed on the market is supported by robust assurance that it is safe and effective
2. Develop supplementary guidance to better ensure AIaMD placed on the market is supported by robust assurance with respect to safety and effectiveness
3. Outline technical methods to test AIaMD to ensure the device is safe and effective

## Section: Good machine learning practice for medical device development

Delivered October 2021
The basic principles of good machine learning practice (GMLP) published in October 2021 in collaboration with FDA and Health Canada, can be overlooked and it may not be obvious how these might apply to medical devices.
These 10 guiding principles are intended to lay the foundation for developing Good Machine Learning Practice that addresses the unique nature of these products. They will also help cultivate future growth in this rapidly progressing field.
The 10 guiding principles identify areas where the International Medical Device Regulators Forum (IMDRF), international standards organizations and other collaborative bodies could work to advance GMLP. Areas of collaboration include research, creating educational tools and resources, international harmonization, and consensus standards, which may help inform regulatory policies and regulatory guidelines.

## Section: Good machine learning practice for medical device development mapping

Manufacturers can find it difficult to identify how GMLP links to existing legal requirements. This document will map how the identified GMLP principles can be tied to key responsibilities outlined in the Medical Device Regulations 2002 (as amended) and relevant guidance.

## Section: Good machine learning practice for medical device development standards mapping

Standards are key in meeting regulatory requirements and aligning state of the art at an international level. We will work with BSI as the UK national standards body and other international partners to map relevant standards to consider when meeting the GMLP principles. This document will be complementary to the GMLP regulatory mapping work (WP9-02) in providing a current snapshot of the standards landscape as it relates to meeting the internationally agreed GMLP principles.

## Section: Best practice AIaMD development and deployment

This document will outline high-level best practice AIaMD development and deployment methods, supplementing and expanding upon the earlier deliverable Best practice SaMD development and deployment. This guidance will also outline best practice methods to assess the performance of AIaMD across the lifecycle. We expect that this guidance will draw upon related work such as medical algorithmic audits.

## Section: AIaMD for all

This guidance will clarify and expand upon GMLP 3 “Clinical Study Participants and Data Sets Are Representative of the Intended Patient Population”, going beyond the Good machine learning practice mapped guidance. Broadly, this guidance will break down bias in AIaMD into three broad challenges:
- Performance of AIaMD across populations and different real-world conditions
- Ensuring data are properly contextualised to avoid AIaMD perpetuating inequalities or leading to poorer performance in subpopulations
- Working to ensure that AIaMD meets the needs of the communities in which it is deployed in terms of verification and validation.
In addition, with respect to the first challenge, this guidance will provide a high-level framework to identify, measure, manage, and mitigate bias. We will endeavour to work with international partners to advance this work wherever possible.

## Section: Tools to identify bias

We will assist in the development of standards, frameworks, and tools to assist with the identification and measurement of bias. For example, we will work with the STANDING Together project which aims to establish standards for data inclusivity and generalisability via an international consensus process to ensure that datasets underpinning AI systems are representative and do not risk leaving underrepresented and minority groups behind through data gaps.

## Section: Bias detection and mitigation

We will consider statistical and machine learning methods to detect, measure, and correct for bias in datasets. An approach will be developed to identify under-represented features in data and then use synthetic data to oversample the under-represented features and achieve a better overall distribution of features. This new approach will be compared to existing approaches like Synthetic Minority Oversampling TEchnique (SMOTE) and Adaptive Synthetic Sampling (AdaSyn) which are used to detect rare events, to rebalance imbalances in the data. These approaches will be tested using at least two different case studies involving risk prediction. We will ensure this experimental work is linked with associated work mentioned previously and use this experimental work to also inform regulatory policy.

## Section: WP 10 Project Glass Box (AI Interpretability)

**Problem statement:** Current medical device requirements do not take into account adequate consideration of human interpretability and its consequence for safety and effectiveness for AIaMD.

## Section: Objectives

1. Articulate how opacity of AIaMD translates into safety, effectiveness, or quality concerns
2. Develop guidance regarding interpretability of AIaMD to ensure that AI models are sufficiently transparent to be reproducible and testable
3. Develop guidance regarding interpretability of AIaMD to ensure that the relationship of interpretability to usability is made plain and emphasised in relation to safety and effectiveness

## Section: Human-centred AIaMD

This guidance will build upon Human-centred SaMD guidance, considering the further challenges that AI can pose, especially human uninterpretable AI. This guidance will emphasise that it is the performance of the human-AI team not just the performance of the model that is key to ensuring AIaMD is safe and effective.
Broadly, this document will consider:
- The importance of being transparent about the intended user population
- The importance of updating the intended user population when changes are made to the model
- A description of how uninterpretable AI (global or local) might impact the performance of the human-AI team
- Consideration of the various methodologies that might be used to consider whether any given AIaMD is human interpretable or not; this might build upon existing standards such as IEEE 7001-2021

## Section: Trustworthy AIaMD

We will support wider work on tools and a framework to assure that AI is trustworthy. We will work with a range of bodies, including the Trustworthiness Auditing for AI project but also Health Education England, the General Medical Council, and patient groups (via the engagement strategy) to ensure that AIaMD is trustworthy for healthcare professionals and patients.

## Section: WP 11 Project Ship of Theseus (AI Adaptivity)

**Problem statement:** Existing requirements and processes surrounding the notification and management of change need to fit and be streamlined for AIaMD.

## Section: Objectives

1. Articulate problems of fit with medical device regulation for adaptive AIaMD, distinguishing between models that are locked, batch-trained, or continuous learning on streaming data
2. Clarify how adaptive AIaMD of each type might fit within existing change management processes required by medical device regulations
3. Where appropriate, craft new guidance for adaptive AIaMD that does not fit within existing change management processes

## Section: Adaptivity and change management in AIaMD

Building on updates to managing change in SaMD and AIaMD (see WP4-04 and WP11-03 respectively), this paper will breakdown the types of change management issues currently seen into categories of product adaptivity. These will be reviewed, and the challenges seen in each case identified and linked to existing or developing regulatory approaches to address such challenges.
The broad adaptivity categories of change type are:
- Static AIaMD - these AIaMD are static and not updated, presenting the challenge of data drift, the performance degrading over time
- Batch-trained – this class of AIaMD are trained periodically in batches, akin to SaMD product updates this change would fall within existing regulatory processes. The challenge here is to clarify change management requirements and streamline processes to reduce administrative burden.
- Individualised models – these changes result models that may share challenges seen in custom made devices due to the highly personalised nature of each iteration.
- Continuous learning on streaming data – this fully adaptive model presents novel challenges in managing change over time and continuously ensuring performance is maintained as each data point is a new training point and that data are input continuously.

## Section: Concept drift and significant/substantial change

We will explore the use of concept drift in determining when a significant or substantial change in performance has occurred. Specifically, this work looks to explore methods to detect when change, including change beyond manufacturers’ control e.g., in the product environment and/or in the intended population can be reliably detected and informative to quality and regulatory processes for managing change post-market. Data that have been highly volatile to change (e.g. data collected on COVID) and assumed to be more stable (such as longitudinal cardiovascular data) will be utilised along with a range of AI models and analysis techniques with the aim of developing a methodology to determining significant change in AIaMD.

## Section: Pre-determined change control plans for AIaMD

Proposals to implement predetermined change control plans (PCCP) for SaMD (WP4-04) will be reviewed for AIaMD. The suitability and applicability of this approach to change management will be reviewed in the context of common challenges for AIaMD such as poor interpretability and data bias. This process review seeks to ensure that PCCPs are a beneficial tool for managing often rapid and complex change events in AIaMD. Additionally, this review will be to ensure that PCCP in AIaMD are also in alignment with best practice guidance.


---

# Network Data Steering Group workplan 2026-2028: data and AI in medicines regulation

- **Issuer:** HMA
- **Type:** Report
- **Language:** en
- **Source:** https://www.ema.europa.eu/en/documents/other/network-data-steering-group-workplan-2026-2028-data-artificial-intelligence-medicines-regulation_en.pdf
- **Licence:** EMA-reuse

## Page 1 (Section: Slide 1: NDSG workplan 2026-2028 )

NDSG workplan 2026-2028
Joint HMA/EMA Network Data Steering Group
VERSION 2.0 – February 2026
NDSG@ema.europa.eu
Data and AI in 
medicines regulation

## Page 2 (Section: Slide 2)

Trusted medicines 
by unlocking the 
value of data
OUR VISION

## Page 3 (Section: Slide 3: Contents)

Contents
NDSG workplan 2026-2028
3
Introduction
Workstreams
Workplan
4
5
6
• Strategy and governance
• Data analytics
• Artificial intelligence
• Data interoperability
• Stakeholder engagement and change management
• Guidance and international initiatives
7
10
17
22
27
32

## Page 4 (Section: Slide 4: Introduction)

Introduction
4
The joint HMA/EMA Network Data Steering Group (NDSG) is the 
strategic advisory group established to maximise data 
interoperability and exchange, to improve access to data and 
evidence generation, and to leverage Artificial Intelligence (AI) for 
the benefit of public and animal health in the European Union (EU).
The NDSG vision is ‘Trusted medicines by unlocking the value of 
data’.
The first NDSG workplan was adopted in March 2025. This current 
document constitutes the first annual revision. It introduces the 
NDSG workplan, covering activities until 2028. It was adopted by 
NDSG in February 2026 and will be updated annually, informed by 
feedback from stakeholders and EU network experts.
The NDSG workplan provides a major contribution to the 
implementation of the EMAN strategy to 2028 to leverage data, 
digitalisation and AI (Theme 2) and support its other themes.
Throughout the implementation of the workplan, the NDSG will 
ensure that data are managed and used within an ethical framework 
and in compliance with the EU data protection legislation and all 
other applicable EU legislative data requirements. 
The scope of most activities under the workplan covers human and 
veterinary medicines. Specific veterinary aspects are also 
highlighted where relevant.

## Page 5 (Section: Slide 5: Workstreams)

Workstreams
5
Strategy and governance:
•
Strategy
•
Governance
Data interoperability:
•
Data asset discovery, cataloguing 
and metadata management
•
Data quality management
•
Organisational and semantic 
interoperability
Data analytics:
•
Review of innovative 
methodologies and of new data 
types for evidence generation
•
Real-world data, clinical study 
data, non-clinical data, 
EudraVigilance data, genomic data
Artificial Intelligence: 
•
Guidance, policy and product 
support 
•
Tools and Innovation
•
Collaboration and change 
management
Stakeholder engagement and 
change management:
•
Change management strategy
•
Network skills and knowledge
•
Stakeholder engagement and 
communication
Guidance and international 
initiatives:
•
Guidance 
•
International initiatives 
The NDSG workplan is organised in six workstreams:

## Page 6 (Section: Slide 6: Workplan)

Workplan
Strategy and governance
Data analytics
Artificial intelligence
Data interoperability
Stakeholder engagement and change management
Guidance and international initiatives

## Page 7 (Section: Slide 7: Strategy and governance)

Strategy and governance
WORKSTREAM OVERVIEW
Timeframe
Deliverable/activity
2026
Strategy
Governance
2027
Q1/Q2 - 2027
Q3/Q4 - 2027
Q1/Q2 - 2028
Q3/Q4 - 2028
2028
Publish updated veterinary 
bigdata workplan
Support EHDS and its implementation projects
Support preparation for revised pharmaceutical legislation
NDSG recommendation on use of 
PMS for cross border healthcare
Support TEHDAS2
Support QUANTUM project
Monitor progress in European level regulatory science research projects on data
DARWIN EU data partners, Health Data Access Bodies, TEHDAS2 
and EMRN workshop on EHDS2 preparation
EMRN data standardisation framework (v) 
Monitor implementation
EMRN data strategy (v) 
EMRN data analytic framework (v) 
Monitor implementation
Publish updated veterinary 
big data strategy
(v): Specific veterinary aspects are included
Support Interoperable Europe Act (v)
Share best-practices and report on interoperability 
impact assessments conducted
Support analytics capabilities for EMRN + change management
Review Horizon Scanning on 
data/tools for medicine regulations 
NDSG workplan 
prioritisation (v)  
NDSG workplan 
prioritisation (v)  
Q1  2026
Q2 2026
Q3 2026
Q4 2026
NDSG workplan prioritisation (v)  
EMRN data strategy (v) implementation monitoring 
EMRN data standardization framework (v), 
incl. SDO collaborative model 
Publish
EMRN data analytic framework (v) 
Publish
Support UNIWIDE IDMP joint action
Advise on data related aspects on implementation of revised pharmaceutical legislation
Stakeholders’ workshop on 
horizon scanning
TEHDAS2 third public consultation
Updates on other key legislative initiatives
Discuss European Biotech Act implications and opportunities on data
7

## Page 8 (Section: Slide 8: Strategy)

NDSG workplan 2026-2028
8
Strategy
A coordinated strategic approach to data management and 
utilisation across the network is essential.
•
The EMRN data strategy and data standardisation framework will 
ensure the EMRN data assets meet high quality standards, are 
appropriately managed, standardised and easy to share. 
•
The EMRN data analytic framework will guide the network 
investment in data and analytics to maximise the utility of EMRN 
data assets for the benefit of human and animal health. 
•
The EU veterinary big data strategy and the EU veterinary big 
data workplan will be reviewed to progress activities specific to 
the veterinary domain.
To keep abreast with advances in data and tools and make 
recommendations on future network engagement and priorities, the 
NDSG will horizon scan and monitor progress in European level 
regulatory science research projects on data. Insights and priorities 
for the future will be shaped together with stakeholders, whose 
feedback will be gathered during a dedicated workshop in 2027.
Informed by stakeholders and network expert input, the NDSG will 
update and prioritise its workplan annually.
Key dates:
Q1 2026
NDSG workplan prioritisation (v) 
Q2 2026
Publish updated veterinary bigdata workplan
Q4 2026
Publish updated veterinary big data strategy
Review Horizon Scanning on data/tools for medicine 
regulations 
Publish EMRN data standardization framework (v), incl. 
SDO collaborative model 
Publish EMRN data analytic framework (v) 
2026-2028
Monitor progress in European level regulatory science 
research projects on data
2026-2028
EMRN data strategy (v) implementation monitoring 
2027-2028
Support analytics capabilities for EMRN + change 
management
Q1 2027
Stakeholders’ workshop on horizon scanning

## Page 9 (Section: Slide 9: Governance)

NDSG workplan 2026-2028
9
Governance
Over the coming years, key European Union legislative initiatives 
will be implemented. They will reinforce the framework for 
accessing and exchanging data, and for generating evidence to 
support regulatory decision making.
To support stakeholders and the Network, the NDSG will contribute 
to the implementation of:
•
The revised pharmaceutical legislation for Europe. NDSG may 
provide advice on RWD, clinical study data, Annex 1 revision, 
environmental risk assessment, OneHealth, ePI.
•
The European Health Data Space (EHDS), its joint action 
TEHDAS2 and the related implementation projects (e.g. 
HealthData@EU projects and the health data quality label 
QUANTUM project, the UNIWIDE IDMP joint action).
•
The Interoperable Europe Act and the related European 
Interoperability Framework, specifically in the domain of 
semantic interoperability (for EMRN critical data assets) by 
sharing best-practices and report on interoperability impact 
assessments conducted.
NDSG will continue to follow and discuss progress in other key 
legislative initiatives, notably the forthcoming European Biotech Act 
and its implications and opportunities on data. Additional area of 
focus may include the Medical Device regulation, the Data Union 
strategy and the EU digital omnibus, ensuring the Network remains 
aligned with the evolving EU policy landscape.
Key dates:
Q2 2026
Discuss European Biotech Act implications and 
opportunities on data
Q3 2026
NDSG recommendation on use of PMS for cross 
border healthcare
TEHDAS2 third public consultation
Q4 2026
DARWIN EU data partners, Health Data Access 
Bodies, TEHDAS2 and EMRN workshop on EHDS2 
preparation
Q4 2026-2027
Support UNIWIDE IDMP joint action
Q4 2026
Share best-practices and report on interoperability 
impact assessments conducted
2026
Support QUANTUM project
2026-2028
Advise on data related aspects on implementation of 
revised pharmaceutical legislation

## Page 10 (Section: Slide 10: Data analytics)

2026
2027
Q1/Q2 - 2027
Q3/Q4 - 2027
Q1/Q2 - 2028
Q3/Q4 - 2028
2028
Q1  2026
Q2 2026
Q3 2026
Q4 2026
Data analytics
WORKSTREAM OVERVIEW
Clinical study data
EudraVigilance data
Transition to systematic submission of clinical study data for CAPs
Stakeholders’ change management support, incl. guidance development and business processes and training
Publish clinical study data follow up report
Network workshop 
Roll out new signal detection 
capabilities for authorised products
Roll out new SUSAR screening 
capabilities for investigational products
Publish report on POC on non-clinical raw data analysis
Non-clinical data
Review of innovative 
methodologies for 
evidence generation
(applicable to all data types below)
Real World Data / 
Real-World Evidence
DARWIN EU - yearly conduct of studies and onboarding 
of data partners
Start of DARWIN EU 2 
Support NCAs with national initiatives on RWE
Continued engagement and conduct of studies with key stakeholders, e.g. ECDC, HTA bodies, payers, patients 
and healthcare professionals’ organisations, Health Data Access Bodies
Genomic data
Publication of pharmacogenomic 
information based on the SmPC 
of CAPs 
Genomic (v)
mHealth
Synthetic data
& Digital twins (v)
Social media
AI analytics for 
regulatory use (v)
Biostatistics
Modelling & 
simulation
Enhancing Pharmacovigilance 
signal detection and evaluation (v)
Review of new data types 
for evidence generation
Pharmacoepidemiology
Annual update
Annual update
Annual report
Annual report
Annual 
report
Business requirement collection and delivery of tools for clinical study data collection, management and analysis 
for the Network 
Multistakeholder workshop
Patient Experience 
Data
Continue voluntary submission of SEND data + prepare EMRN for wider-uptake
Conduct open tender for coordination centre for DARWIN EU
Event
DARWIN EU ®
Routine generation of RWE for EMRN, EMA scientific committees and downstream decision makers
Timeframe
Deliverable/activity
(v): Specific veterinary aspects are included
10

## Page 11 (Section: Slide 11: Review of innovative methodologies and data types for evidence generation)

NDSG workplan 2026-2028
11
Review of innovative 
methodologies and data types for 
evidence generation
Data and methods are intricately linked, working together to 
generate evidence to support decision-making.
To enable regulatory decision-making to benefit from evolving 
methods and clinical evidence generated from a spectrum of data 
types, the NDSG will review innovative methodologies (including 
biostatistics, signal detection, modelling & simulation data, AI and 
pharmacoepidemiology) and data types that can complement 
established clinical data (e.g. genomic data, synthetic data, digital 
twins data, patient experience data (PED), mobile health data and 
social media data). 
This will allow NDSG to discuss the current progress, opportunities, 
challenges and applications of such methods and data types for 
evidence generation for regulatory decision-making. Ultimately 
NDSG will be able to agree common Network positions and actions 
that the group will take or sponsor to enable the use of such 
methods and data types. Over time, informed by NDSG strategic 
review, pilot studies will be conducted, and learnings will be shared 
with the EMRN. 
Gradually the use of such evidence will be enabled, and its value 
will be established to support regulatory decision-making.
Key dates:
Q1 2026
Review of methodologies: Biostatistics
Q2 2026
Review of methodologies: Modelling & simulation
Review of new data types: genomic data (v)
Q3 2026
Review of new data types: synthetic data & digital twins 
(v)
Review of methodologies: AI analytics for regulatory use, 
e.g. novel clinical trial designs, AI-driven patient 
evaluation, clinical data analysis (v)
Q4 2026
Review of methodologies: enhancing Pharmacovigilance 
signal detection (v)
Review of new data types: Patient Experience Data (PED)
Q1 2027
Review of methodologies: Pharmacoepidemiology
Q2 2027
Review of new data types: mobile Health (mHealth) data
Q3 2027
Review of new data types: social media data

## Page 12 (Section: Slide 12: Real World Data / Real-World Evidence)

NDSG workplan 2026-2028
12
Real World Data / Real-World 
Evidence
The Data Analysis and Real-World Interrogation Network (DARWIN 
EU®) is the EMRN’s federated network to enable access and 
analysis of real-world data (RWD). It is now fully operational and 
routinely supports the evaluation work of EMA's scientific 
committees. Learnings and experiences are shared regularly with 
stakeholders and the EMRN. 
Each year, additional data partners will be onboarded and 
increasing numbers of studies will be conducted. 
National competent authorities' initiatives on real-world evidence 
(RWE) will be supported and cooperation with the European Centre 
for Disease Prevention and Control (ECDC), bodies responsible for 
Health Technology Assessments (HTA), payers, Health Data Access 
Bodies, as well as patients and healthcare professionals’ 
organisations, will continue.
Following an open tender in 2026, DARWIN EU 2 will be launched in 
2027, as an extension of DARWIN EU . 
Key dates:
2026
DARWIN EU ® - yearly conduct of studies and 
onboarding of data partners
Conduct open tender for coordination center for 
DARWIN EU
Q3 2026-2028
Annual report
2026-2028
Continued engagement and conduct of studies with 
key stakeholders, e.g. ECDC, HTA bodies, payers, 
patients and healthcare professionals’ organisations, 
Health Data Access Bodies
Support NCAs with national initiatives on RWE
Q2 2027
Start of DARWIN EU ® 2

## Page 13 (Section: Slide 13: Clinical study data)

NDSG workplan 2026-2028
13
Clinical study data
Analysis of patient level clinical study data will strengthen 
regulatory decision-making for faster and better authorisation of 
medicines.
In light of the finalisation of the revised pharmaceutical legislation 
for Europe, the CHMP clinical study data pilot will transition to 
systematic submission of clinical study data for CAPs. 
The pilot results will advise EMRN on optimal way to rollout of 
clinical study data analysis and for managing changes (including 
business requirement and delivery of tools, business process, 
organisational aspects, guidance development and training for the 
different types of EMRN assessors).
Collaboration with key stakeholders will be essential, notably 
through the organisation of workshops and sharing of the pilot 
learnings and experience.
Key dates:
2026-2028
Transition to systematic submission of clinical study 
data for CAPs
Stakeholders’ change management support, including 
guidance development and business processes and 
training
Business requirement collection and delivery of tools for 
clinical study data collection, management and analysis 
for the Network 
Q2 2026
Network workshop 
Q2 2027
Publish clinical study data follow up report
Q3 2027
Multistakeholder workshop

## Page 14 (Section: Slide 14: Non-clinical data)

NDSG workplan 2026-2028
14
Non-clinical data
After completion of the Proof of Concept (PoC) study to evaluate 
implementation of the Standard for Exchange of Nonclinical Data 
(SEND) in 2025, voluntary submission of SEND data by MAHs will 
continue and preparatory work for wider uptake with the Network 
and stakeholders will start. 
The analysis of non-clinical data can improve the quality and 
efficiency of routine assessment but also of procedures where data 
is complex and requires visualization or independent analysis. 
It can also be useful for procedures where rapid regulatory input is 
needed (e.g. rolling review, accelerated procedures, PRIME) and for 
regulatory science projects to facilitate harmonization, policy or 
guideline recommendations. 
Key dates:
Q3 2026
Publish report on POC on non-clinical data analysis
2026-2028
Continue voluntary submission of SEND data + prepare 
EMRN for wider-uptake

## Page 15 (Section: Slide 15: EudraVigilance data)

NDSG workplan 2026-2028
15
EudraVigilance data
Improved (human) pharmacovigilance signal detection capabilities 
for EMRN assessors, marketing authorisation holders (MAHs) and 
the general public will be delivered. 
These includes:
•
new signal detection capabilities for the EU network for 
authorised products, 
•
new clinical trial Suspected Unexpected Serious Adverse Reports 
(SUSAR) screening capabilities for the EU network.
Key dates:
Q2 2026
Roll out new signal detection capabilities for authorised 
products
Q2 2027
Roll out new SUSAR screening capabilities for 
investigational products

## Page 16 (Section: Slide 16: Genomic data)

NDSG workplan 2026-2028
16
Genomic data
In 2024, the joint EC/HMA/EMA multi-stakeholder workshop on 
pharmacogenomics recommended to optimise the availability of 
pharmacogenomic information for approved medicines to better 
inform pharmacogenomic-guided treatments. 
In 2026, pharmacogenomic information based on the Summary 
Product Characteristics (SmPC) of centrally authorised medicinal 
products (CAPs) will be published and updated annually for the 
Network and its stakeholders. 
In the future, other steps will be taken to enable the use of genomic 
data for regulatory decision-making. Pilot studies might be 
conducted, and experience will be shared with the EMRN. 
Additional activities on genomic data are also captured under the 
‘review of new data types for evidence generation’ in this 
workstream and under the ‘Guidance and international initiatives’ 
workstream.
Key dates:
Q2 2026
Publication of pharmacogenomic information based on 
the SmPC of CAPs 
2027-2028
Annual update

## Page 17 (Section: Slide 17: Artificial Intelligence)

Timeframe
Deliverable/activity
(v): Specific veterinary aspects are included
2026
2027
Q1/Q2 - 2027
Q3/Q4 - 2027
Q1/Q2 - 2028
Q3/Q4 - 2028
2028
Q1  2026
Q2 2026
Q3 2026
Q4 2026
Artificial Intelligence
WORKSTREAM OVERVIEW
Continued support to the evaluation of AI in medicines lifecycle (v) 
Guidance, policy and 
product support
Tools and Innovation
Collaboration and 
change management
Compliance with the AI Act and EUDPR/GDPR, including sharing good practice on AI Risk Management and associated ethical issues (v) 
Revise AI Tools 
Framework
Engage in international collaborations, including with ICMRA (v)
Foster EU-wide collaborations, including EU Agencies Network’s AI WG
Stakeholder communications on AI
Support a growing community on AI, building on AI SIA and IncreaseNet 
Develop AI Guidance in the Medicines Lifecycle, with MWP (including AI in clinical development and AI in Pharmacovigilance) (v)
Publish AI research priorities (v)
Revise AI research priorities
Publish Guiding 
Principles for Good AI 
Practice (v)
EMRN Masterclass on 
AI, with ESEC 
Support to Scientific Committees delivery of AI-related activities
Deliver AI training, through EU NTC framework in collaboration with IncreaseNet (v)
Explore additional opportunities for international harmonisation (v) 
Deliver a coordinated roadmap of further AI Guidance Development, in alignment with the Biotech Act (v)
Revision of EMRN’s Guiding principles for the use of LLMs, with ESEC
Expand Scientific Explorer to 
initial Public AR
Execute Change Management Strategy for EMRN (v)
Yearly Observatory publications 
Publish AI Glossary (v)
Explore opening EU NTC AI literacy to external stakeholders and international partners
AI public workshops (v) 
Transition to routine use of the AI Tools Framework
Pilot of an EMRN Prompt Community
Roadmap on continued support to the deployment of AI solutions across the EMRN, incl. REGULUS and Scientific Explorer (v) 
Hackathon
Promote Network sharing of AI solutions with IncreaseNet
Endorse AI training strategy
Launch of SPC Reader & 
SPC Search (v)
AI literacy training 
roll out to EMRN
Expand Scientific Explorer and 
deploy AI Assistants
AI Sandbox Simulation Hackathon
Event
17
Deliver AI solutions for the EMRN
Innovation cycles

## Page 18 (Section: Slide 18: Artificial Intelligence)

Artificial Intelligence
18
WORKSTREAM OVERVIEW
Artificial Intelligence (AI) systems are becoming a central tool supporting intellectual work 
and powering automation across many walks of life. 
The European medicines regulatory network’s (EMRN) vision for AI is for a regulatory 
system leveraging AI to harness systems efficiency, increased insights into data and 
strengthened decision-making, for the benefit of public and animal health. 
The increasingly sophisticated nature and the pace of change of AI bring opportunities but 
also challenges. The application of AI requires a collaborative, coordinated strategy to 
maximise the benefits from AI while ensuring that uncertainty is adequately explored, and 
risks are mitigated. 
This plan focuses on three critical dimensions to facilitate the development and use of safe 
and responsible AI across human and veterinary medicines, by including an ethical 
dimension across all deliverables, and by focusing on enabling the development of beneficial 
AI that delivers for public and animal health. 
AI is fast evolving: this plan will therefore be regularly updated to reflect technological, 
regulatory and scientific developments.
Throughout the execution of the plan, stakeholders will be consulted, engaged and 
informed.
NDSG workplan 2026-2028

## Page 19 (Section: Slide 19: Guidance, policy and product support)

NDSG workplan 2026-2028
19
Guidance, policy and product 
support
Continued support will be provided for the development and 
evaluation of AI throughout the medicines lifecycle, including 
dedicated contributions to Portfolio and Technology Meetings (PTM), 
the Innovation Task Force (ITF), Scientific Advice, and Qualification 
procedures.
Support will also be given to EMA Scientific Committees in 
delivering their AI-related activities, including work on AI literacy, 
development of AI tools, and the preparation of guidance.
A coordinated roadmap for future AI-related guidance, aligned with 
the proposed Biotech Act, will be developed. This will ensure that all 
guidance activities proceed in a consistent and strategically aligned 
manner.
Compliance with the AI Act and the EU-DPR/GDPR will be ensured, 
and good practices on risk management will be shared across the 
Network.
Information on activities, trends, and emerging AI domains will be 
published annually under the Network AI Observatory.
Guiding principles on responsible AI and an accompanying 
terminology document -including mapping of glossaries - will be 
developed. This work may serve as a foundation for future 
international harmonisation efforts.
Key dates:
Q1 2026
Publish Guiding Principles for Good AI Practice (v)
Q2 2026
Deliver a coordinated roadmap of further AI 
Guidance Development, in alignment with the 
Biotech Act
Q4 2026
Publish AI Glossary (v)
Yearly Observatory publications 
Q4 2026 - 
2028
Explore additional opportunities for international 
harmonisation (v) 
2026-2028
Continued support to the evaluation of AI in 
medicines lifecycle (v) 
Support to Scientific Committees delivery of AI-
related activities
Develop AI Guidance in the Medicines Lifecycle, with 
MWP (including AI in clinical development and AI in 
Pharmacovigilance) (v)
Compliance with the AI Act and EUDPR/GDPR, 
including sharing good practice on AI Risk 
Management associated ethical issues (v) 
Q3 2027
Revision of EMRN’s Guiding principles for the use of 
LLMs, with ESEC

## Page 20 (Section: Slide 20: Tools and Innovation)

NDSG workplan 2026-2028
20
Tools and Innovation
Core AI capabilities will continue to be strengthened, and new 
collaborative approaches will be piloted across the Network. 
Several existing AI solutions will be further supported and 
expanded, including REGULUS and Scientific Explorer - Scientific 
Explorer will be extended to initial Public assessment reports - while 
new tools will be deployed, including SPC Reader and additional AI 
assistants.
To build Network-wide expertise in prompting and generative-AI 
practices, an EMRN Prompt Community will be piloted from Q1 to 
Q3 2026, supporting the effective delivery and use of AI assistants.
AI research priorities will be published in Q2 2026 and subsequently 
revised in 2028 to incorporate new developments and emerging 
needs.
The AI Tools Framework will be implemented in late 2026 to foster 
collaboration and sharing of AI tools across the European Medicines 
Regulatory Network. 
In parallel, IncreaseNet’s initiative to promote cross-network 
sharing of AI solutions will be supported and will inform the 2028 
update of the AI Tools Framework, ensuring strong coordination and 
collaboration across European agencies.
Key dates:
Q1 2026
Expand Scientific Explorer to initial Public AR
Q2 2026
Publish AI research priorities (v)
Q4 2026
Launch of SPC Reader & SPC Search (v)
Q1 2026 - 
Q3 2026
Pilot of an EMRN Prompt Community
Q4 2026
Transition to routine use of the AI Tools 
Framework
Q4 2026 – 
2027
Promote network sharing of AI solutions 
with IncreaseNet
2026-2028
Roadmap on continued support to the 
deployment of AI solutions across the 
EMRN, incl. REGULUS and Scientific Explorer 
(v) 
Q2 2027
Expand Scientific Explorer and deploy AI 
Assistants
Q1 2028
Revise AI Tools Framework
Q4 2028
Revise AI research priorities

## Page 21 (Section: Slide 21: Collaboration and change management)

NDSG workplan 2026-2028
21
Collaboration and change 
management
AI literacy remains a critical priority (and a legal obligation under the 
AI Act). Therefore, the EU-Network Training Centre will roll out AI 
literacy initiatives across the European Medicines Regulatory Network 
while expanding and delivering training on AI. Opening the training to 
external stakeholders will be explored.
The Network will continue to collaborate closely with international and 
European partners, including the International Coalition of Medicines 
Regulatory Authorities (ICMRA), EU Agencies through the EU Agencies 
Network AI working group, and other relevant stakeholders.
The AI Special Interest Area will collaborate with the IncreaseNet to 
support a growing community of practice on AI, extending knowledge 
sharing to a broader range of staff. 
The Network-wide change management strategy will continue to be 
implemented to ensure support for AI organisational transformation.
Topic-specific public workshops, masterclasses and hackathons will 
further strengthen upskilling efforts and enhance engagement with 
stakeholders and the wider data science community. Stakeholder 
feedback will guide the selection of topics to ensure relevance and 
impact.
In Q2 2027, a regulatory sandbox simulation hackathon will be 
conducted to explore challenges and regulatory considerations in 
hypothetical AI use-case scenarios.
Key dates:
Q1 2026
AI literacy training roll out to EMRN
Q3 2026
EMRN Masterclass on AI, with ESEC 
Explore opening EU NTC AI literacy to external 
stakeholders and international partners
Hackathon
Q4 2026
Endorse AI training strategy
AI public workshops (v) 
2026 - 
2028
Deliver AI training, through EU NTC framework in 
collaboration with IncreaseNet  (v)
Engage in international collaborations, including 
with ICMRA (v)
Foster EU-wide collaborations, including EU 
Agencies Network’s AI WG
Support a growing community on AI, building on AI 
SIA and IncreaseNet 
Stakeholder communications on AI
Execute Change Management Strategy for EMRN (v)
Q2 2027
AI Sandbox Simulation Hackathon

## Page 22 (Section: Slide 22: Data interoperability)

2026
2027
Q1/Q2 - 2027
Q3/Q4 - 2027
Q1/Q2 - 2028
Q3/Q4 - 2028
2028
Q1  2026
Q2 2026
Q3 2026
Q4 2026
Catalogue EMRN data assets, in preparation of EHDS and EMRN use cases (v)
Data interoperability
WORKSTREAM OVERVIEW
Data asset discovery, 
cataloguing and metadata 
management
HMA EMA catalogues of real-world data sources & non-interventional studies 
Engage with stakeholder to further populate HMA EMA catalogues (v) and continuous technical improvements
Discuss place of catalogues in 
prep. of EHDS Data Catalogue
Integration of veterinary data sources 
into the catalogue (v)
Agree EMRN data assets + make recommendation for cataloguing, incl. minimum metadata
Population of EMRN Data Assets catalogue (v) + engagement with stakeholders
Data Quality Management
Conduct data quality 
maturity assessment  
Publish PMS 
quality chapter
Publish ADR data 
quality chapter
Publish RWD 
quality chapter
Develop data quality approach (including quality indicators)  for Network critical data assets (v)  
Implement improvement actions, 
e.g. new data quality chapter
Publish data quality maturity assessment in 
EMRN Data Assets catalogue 
Organisational and 
Semantic interoperability
Continuous engagement with industry and key stakeholders (e.g. use cases, timelines, processes, tools), incl. EHDS
Agree model for EMRN working arrangements for PMS data 
management (joint NDSG / ROG)
Support PMS implementation through Network portfolio and ROG
Continued support and advice to EMRN for the development and implementation of international data standards, in 
line with Data Standardisation Framework
Explore partnerships and contribution with upcoming EU interoperability initiatives 
NDSG recommendation 
on clinical trial data 
submission format
Discuss ROG PMS 
data qualification 
feasibility study 
report
Publish data glossary for medicines regulation
Define roles and responsibilities for data trustees and data stewards
Publish NDSG 
recommendation to promote 
API first architecture 
NDSG position on PHPID (EU, Global, 
and involvement in GIDWG)
Develop data quality maturity 
assessment approach
Pilot public release of PMS data to stakeholders (via API)
Medicinal product PMS master data
Agree NDSG recommendations for 
SMS and EU-SRS
Phase 3 of vet UPD Data Quality 
enhancements published (v)
Strengthen use of vet UPD master 
data with roll out of new analytic 
capability for UPD Data Portal’ (v)
Timeframe
Deliverable/activity
(v): Specific veterinary aspects are included
22

## Page 23 (Section: Slide 23: Data asset discovery, cataloguing and metadata management)

NDSG workplan 2026-2028
23
Data asset discovery, cataloguing 
and metadata management
Complementary to increasing data quality, data cataloguing and 
metadata management of EMRN critical data assets are essential to 
enable efficient discovery, access, and utilisation of data assets 
across the Network to support regulatory decision-making.
A comprehensive approach to data cataloguing and metadata 
management for the Network critical data assets will be developed 
and rolled-out. This will be supported by the definition of clear roles 
and responsibilities for data trustees and data stewards, as well as 
a data glossary for medicines regulation. This will also consider the 
preparation of the European Health Data Space (EHDS).
After the launch of the EMA-HMA catalogues of real-world data 
sources and non-interventional studies, integration with the 
veterinary domain and interface with the EHDS data catalogue will 
be explored. Engagement with stakeholder will also continue to 
promote population of the catalogues.
Key dates:
Q1–Q2 2026
Integration of veterinary data sources into the 
catalogue (v)
Q2 2026
Agree EMRN data assets + make recommendation 
for cataloguing, incl. minimum metadata
Define roles and responsibilities for data trustees 
and data stewards
Q3 2026-2028
Population of EMRN Data Assets catalogue (v) + 
engagement with stakeholders
Q4 2026
Publish data glossary for medicines regulation
Discuss place of catalogues in prep. of EHDS Data 
Catalogue
2026-2028
Engage with stakeholder to further populate HMA 
EMA catalogues (v) and continuous technical 
improvements

## Page 24 (Section: Slide 24: Data Quality Management)

NDSG workplan 2026-2028
24
Data Quality Management
To inform the selection of data for evidence generation and increase 
interoperability, data quality of the Network critical data assets 
should be understood and efforts should be made to strengthen 
data quality.
A data quality approach will be developed, informed by and aligned 
with the relevant EU data quality initiatives, notably the data quality 
framework for EU medicines regulation and the veterinary Union 
Product Database (UPD) data quality framework. 
Specific quality chapters will be published for selected data 
domains, starting with Real-world data (RWD), Adverse Drug 
Reaction (ADR) and Product Master System (PMS) data. Additional 
enhancements to the veterinary UPD data quality framework will be 
published.
Data quality maturity assessments will be performed and published 
via the EMRN data asset catalogue to ensure the data quality of the 
Network’s critical data assets is well understood.
Key dates:
Q1 2026
Publish RWD quality chapter
Q2 2026
Phase 3 of vet UPD Data Quality enhancements 
published (v)
Q3 2026
Publish ADR data quality chapter
Q4 2026
Publish PMS quality chapter
Develop data quality maturity assessment approach
Q1-Q2 2027
Conduct data quality maturity assessment 
Q3-Q4 2027
Publish data quality maturity assessment in EMRN 
Data Assets catalogue 
2028
Implement improvement actions, e.g. new data 
quality chapter

## Page 25 (Section: Slide 25: Organisational and Semantic interoperability)

NDSG workplan 2026-2028
25
Organisational and Semantic 
interoperability
Master data is essential to strengthen interoperability of the 
Network data assets and systems. By enabling the linkage of 
multiple data sources, it increases efficiency, reduces duplication 
and benefits evidence generation. 
One of the essential master datasets relates to relates to medicinal 
product data. NDSG recognised the PMS system as common source 
of product master data for all EU medicinal products supporting EU-
wide use cases. NDSG will therefore work to progress and 
harmonise its implementation within the Network. 
The HMA Regulatory Optimisation Group (ROG) PMS data 
qualification feasibility study will explore the practicalities of the 
Network validation (alternatively referred to as qualification) of PMS 
data submitted by MAHs and managed in the PMS system.
Informed by this pilot, the NDSG and the ROG will jointly agree a 
model for the working arrangements within the Network for product 
master data management, including roles and responsibilities. 
Additional PMS master data will be made available to stakeholders 
via the launch of a public API. More generally, the NDSG will 
promote API first architecture for the development of the Network 
tools. 
Key dates:
Q1 2026
Discuss ROG PMS data qualification feasibility 
study report
Q2 2026
Pilot public release of PMS data (via API) to 
stakeholders
Publish NDSG recommendation to promote API 
first architecture 
Q3 2026
Agree model for EMRN working arrangements for 
PMS data management (joint NDSG / ROG)
Agree NDSG recommendations for SMS and EU-
SRS
Q4 2026-2028
Support PMS implementation through Network 
portfolio and ROG
Q4 2026
NDSG position on PHPID (EU, Global, and 
involvement in GIDWG)
NDSG recommendation on clinical trial data 
submission format
2026-2028
Continuous engagement with industry and key 
stakeholders (e.g. use cases, timelines, processes, 
tools), incl. EHDS

## Page 26 (Section: Slide 26: Organisational and Semantic interoperability)

NDSG workplan 2026-2028
26
Organisational and Semantic 
interoperability
NDSG will also discuss recommendations for substance master data 
in the SMS and EU-SRS systems.
NDSG will provide continuous support and advice to the EMRN for 
the development and implementation of international data 
standards (e.g. HL7, ISO, ICH…) for the ERMN, in line with Data 
Standardisation Framework. 
Partnerships and contributions with broader EU funded initiatives on 
interoperability will also be explored. 
Key dates:
2026-2028
Explore partnerships and contribution with upcoming 
EU interoperability initiatives 
Continued support and advice to EMRN for the 
development and implementation of international data 
standards, in line with Data Standardisation 
Framework
Q4 2027
Strengthen use of vet UPD master data with roll out of 
new analytic capability for UPD Data Portal’ (v)

## Page 27 (Section: Slide 27: Stakeholder engagement and change management)

2026
2027
Q1/Q2 - 2027
Q3/Q4 - 2027
Q1/Q2 - 2028
Q3/Q4 - 2028
2028
Q1  2026
Q2 2026
Q3 2026
Q4 2026
Stakeholder engagement and change management
WORKSTREAM OVERVIEW
Network skills and knowledge
Stakeholder engagement and 
communication
Maintain data protection training modules (v) 
Support Network knowledge sharing activities, e.g. through ESEC and SIAs
Continued interaction with Industry through groups focused on RWE, clinical study data, AI, and with ROG on 
Master data
Support delivery and maintenance of the data training in collaboration with EU NTC and IncreaseNet programme (v)
Change management 
strategy
Multiplicity and platform trial 
guidance workshop (MWP)
Network and stakeholder communications (v), e.g. newsletters, targeted emails, website update, public consultations
Annual multi-stakeholder data forum, annual veterinary big data forum and ad-hoc specialised workshops 
Discuss Network data change management implementation plans 
NDSG/industry meeting (v)
Multistakeholder registry workshop on 
Duchenne Muscular Dystrophy
2nd HMA/EMA EV and Signal 
Management Stakeholder Forum
PMS info day 
9 June
PMS
AI
RWE
Clinical 
study data 
Align data training strategy with EU NTC framework
NDSG/ROG 
industry 
engagement on 
PMS
NDSG/ROG industry 
engagement on PMS
Workshop on good 
pharmacogenomic practice (MWP)
MWP Annual 
interested 
parties’ meeting 
(virtual) 
Workshop on Patient 
Experience Data
Workshop on patient registries with ERNs
IncreaseNet AI conference 
for regulators
Timeframe
Deliverable/activity
(v): Specific veterinary aspects are included
Event
27

## Page 28 (Section: Slide 28: Change management strategy)

NDSG workplan 2026-2028
28
Change management strategy
Change management is essential to support a data-driven culture 
across the Network, to build trust amongst stakeholders and 
partners and prepare them to adopt the changes delivered under 
the NDSG workplan.
All stakeholders and partners should be equipped with the 
necessary knowledge and skills and consulted on changes when 
needed.  Learnings and experiences should be shared, business 
processes optimised and tailored training programs on tools and 
skills rolled out. Additionally, good practices and guidance, including 
on methods, should be made available.
NDSG will oversee the implementation of the Network change 
management plans (on data) to ensure effective communication, 
engagement and knowledge-building for high-priority topics, such 
as real-world evidence, artificial intelligence, clinical study data 
analysis and Product Master System (PMS) data.
Key dates:
Q2 2026
Discuss Network data change management 
implementation plan on PMS
Discuss Network data change management 
implementation plan on Clinical study data
Q3 2026
Discuss Network data change management 
implementation plan on AI
Q4 2026
Discuss Network data change management 
implementation plan on RWE

## Page 29 (Section: Slide 29: Network skills and knowledge)

NDSG workplan 2026-2028
29
Network skills and knowledge
To support the development of an expert workforce in the Network 
able to advise on data and interpret evidence, training programs 
will be rolled out to the Network and relevant stakeholders when 
appropriate via the EU Network Training Centre (EU NTC) and in 
collaboration with the IncreaseNet programme.
Training programs cover at least biostatistics, 
pharmacoepidemiology/real world evidence, data science, 
pharmacogenomic, AI and data protection. 
Skills will be further enhanced on the basis of a review of the 
training strategy, in line with the EU NTC framework. 
The Methodology European Specialised Expert Community (ESEC) 
and its Specialised Interest Areas (SIAs) will continue to serve as 
the forum for knowledge transfer for European experts on scientific 
and methodological topics. 
Key dates:
Q4 2026
Align data training strategy with EU NTC framework
2026-2028
Support delivery and maintenance of the data training 
in collaboration with EU NTC and IncreaseNet 
programme (v)
Maintain data protection training modules (v) 
Support Network knowledge sharing activities, e.g. 
through ESEC and SIAs

## Page 30 (Section: Slide 30: Stakeholder engagement and communication)

NDSG workplan 2026-2028
30
Stakeholder engagement and 
communication
Listening to stakeholders, increased transparency and excellent 
communication are critical to build trust in what is delivered and 
maximize the Network transformation to data-driven regulation. 
A multi-stakeholder forum on data will be organised annually and 
will be complemented by specialised workshops (e.g. AI, registries, 
Patient Experience Data, signal detection and PMS…) and workshops 
supported by the EMA Methodology Working Party (MWP) held 
throughout the period of this workplan. 
Interaction with industry will be organised through groups focused 
on RWE, clinical study data, and AI, and, in collaboration with the 
Regulatory Optimisation Group (ROG) on master data.
Key dates:
2026 - 
2028
Network & stakeholder communications (v), e.g. newsletters, 
targeted emails, website update, public consultations
Annual multi-stakeholder data forum, annual veterinary big 
data forum and ad-hoc specialised workshops 
Continued interaction with Industry through groups focused 
on RWE, clinical study data, AI, and with ROG on Master data
Q2 2026
NDSG/ROG industry engagement on PMS
PMS info day 9 June
MWP Annual interested parties’ meeting (virtual) 
Q3 2026
Multistakeholder registry workshop on Duchenne 
Muscular Dystrophy
Workshop on Patient Experience Data
Multiplicity and platform trial guidance workshop (MWP)
NDSG/industry meeting (v)
Q4 2026
2nd HMA/EMA EV & Signal Management Stakeholder Forum
NDSG/ROG industry engagement on PMS
Q1 2027
IncreaseNet AI conference for regulators
Workshop on patient registries with ERNs
Q3 2027
Workshop on good pharmacogenomic practice (MWP)

## Page 31 (Section: Slide 31: Guidance and international initiatives)

2026
2027
Q1/Q2 - 2027
Q3/Q4 - 2027
Q1/Q2 - 2028
Q3/Q4 - 2028
2028
Q1  2026
Q2 2026
Q3 2026
Q4 2026
Guidance and international initiatives
WORKSTREAM OVERVIEW
Guidance
Publish CHMP 
reflection paper on 
PED
NDSG consultation on MWP workplan
NDSG consultation on ACT EU workplan and CHMP working party workplans
International initiatives 
Support ICH guidelines
Continue support the ICMRA expert working on RWE for Public Health Emergencies
Contribute to ICH E23 guideline RWE terminologies, metadata, and assessment principles
Implement & develop training material for ICH M14 guideline
Contribute to ICH M11 HL7 
FHIR implementation guide
Contribute to training development for ICH M15 for MIDD
Roll out ICH training 
material for ICH M11
Contribute to EU implementation of ICH M15 for MIDD
Contribute to draft ICH M16 guideline on SPQS
Drafting (MWP) of:
•
reflection paper on use of Bayesian methods 
•
reflection paper on platform trials
•
revision of guideline on multiplicity issues in clinical trials 
•
Q&A on the use of RWD for regulatory purposes
Initiate drafting (MWP) of:
•
Concept paper on the use of the evidence assessment 
framework for decision making
•
Q&A on the use of synthetic data
Contribute ICH E24 on natural history studies and registry data to advance rare disease drug 
development 
Publish recommended list 
of data elements to be 
collected by Alzheimer 
disease registries
Develop EU implementation 
guide ICH M11
Contribute to EU implementation of ICH E11A Guideline on pediatric extrapolation
Timeframe
Deliverable/activity
(v): Specific veterinary aspects are included
Initiate drafting (MWP) of:
•
guidance on assessment and reporting on mechanistic models
•
reflection paper on external controls
•
Q&A to be read in conjunction with the baseline covariates guideline to 
take into account the use of synthetic covariates
•
revision of GPP guideline
•
revision of guideline on registry-based studies
31

## Page 32 (Section: Slide 32: Guidance)

NDSG workplan 2026-2028
32
Guidance
Expert guidance is needed to deliver robust assessment and 
decision-making by EMA regulatory committees and to guide 
stakeholders and partners.
The CHMP Methodology Working Party (MWP) is responsible for the 
drafting of methodology guidance and to support their 
implementation. Activities referred in the NDSG workplan follow the 
workplan of the CHMP MWP for the development of guidance (e.g. 
reflection paper, concept paper and Q&A) across data and methods. 
To ensure integration with the totality of clinical evidence 
generation for decision-making, NDSG will also provide its expert 
input on the ACT EU workplan and CHMP working parties workplan.
Key dates:
2026-
2028
NDSG consultation on MWP workplan
NDSG consultation on ACT EU workplan and CHMP working 
party workplans
2026
Drafting (MWP) of:
•
reflection paper on use of Bayesian methods 
•
reflection paper on platform trials
•
revision of guideline on multiplicity issues in clinical trials 
•
Q&A on the use of RWD for regulatory purposes
Initiate drafting (MWP) of:
•
guidance on assessment and reporting on mechanistic 
models
•
reflection paper on external controls
•
Q&A to be read in conjunction with the baseline 
covariates guideline to take into account the use of 
synthetic covariates
•
revision of GPP guideline
•
revision of guideline on registry-based studies
Q2 2026
Publish recommended list of data elements to be collected 
by Alzheimer disease registries
Q3 2026
Publish CHMP reflection paper on PED
2027
Initiate drafting (MWP) of:
•
Concept paper on the use of the evidence assessment 
framework for decision making
•
Q&A on the use of synthetic data

## Page 33 (Section: Slide 33: International initiatives )

NDSG workplan 2026-2028
33
International initiatives 
To foster international collaboration, alignment on data use in 
medicines regulation and increase interoperability, NDSG will 
facilitate stakeholder engagement and listen to their needs and 
support implementation of international consensus guidelines and 
standards. 
The Network collaboration at ICH will continue and progress will be 
made on implementation at EU level when relevant, e.g. in the area 
of RWD, clinical trial study protocol, Structured Product Quality 
Submissions, model-informed drug development and pediatric 
extrapolation. Further guidelines will be developed and new ICH 
topics will be considered. Activities referred to in the NDSG 
workplan follow the workplan of the CHMP MWP for the contribution 
to the development and implementation of methodological ICH 
guidelines. 
International collaboration on RWE will continue throughout the 
workplan under the umbrella of ICMRA and its working group on 
RWE for Public Health Emergencies.
Key dates:
2026-2028
Support ICH guidelines
Contribute to ICH E23 guideline RWE terminologies, 
metadata, and assessment principles
2026
Implement & develop training material for ICH M14 
guideline
Q1-Q2 2026
Contribute to ICH M11 HL7 FHIR implementation guide
Q2-Q4 2026
Roll out ICH training material for ICH M11
Q2 2026-
2028
Contribute ICH E24 on natural history studies and 
registry data to advance rare disease drug 
development 
2026
Contribute to training development for ICH M15 for 
MIDD
Contribute to EU implementation of ICH E11A Guideline 
on pediatric extrapolation
2026-2028
Contribute to draft ICH M16 guideline on SPQS
Continue support the ICMRA expert working group on 
RWE for Public Health Emergencies
2027
Develop EU implementation guide ICH M11
2027-2028
Contribute to EU implementation of ICH M15 for MIDD

## Page 34 (Section: Slide 34)

www.ema.europa.eu/contact
edit link
European Medicines Agency
Official address  Domenico Scarlattilaan 6  ●  1083 HS Amsterdam  ●  The Netherlands
Telephone +31 (0)88 781 6000
Send us a question  Go to www.ema.europa.eu/contact
Visit edit link
Visit Data in regulation: Big data and other sources

## Page 35 (Section: Slide 35: Acronyms)

35
Acronyms
ACT EU 
Accelerating Clinical Trials in the EU
ADR
Adverse Drug Reaction reports 
AI
Artificial Intelligence
API
Application Programming Interface
AR
Assessment Report
CAP
Centrally Authorised medicinal Products 
CHMP
Committee for Medicinal Products for Human Use
DARWIN
Data Analysis and Real-World Interrogation Network
EC
European Commission
ECDC
European Centre for Disease Prevention and Control
EHDS
European Health Data Space
EMA
European Medicines Agency
EMAN 
European Medicines Agencies Network
EMRN
European Medicines Regulatory Network
ePI
Electronic Product Information
ERN
European Reference Network
ESEC
European Specialised Expert Community
EU
European Union
EUDPR
European Union Data Protection Regulation
EU NTC
EU Network Training Centre 
EU-SRS
European substance reference system
GDPR
General Data Protection Regulation
GIDWG
Global IDMP working group
HMA
Heads of Medicines Agencies
HTA
Health Technology Assessments 
ICH
International Council for Harmonisation
ICMRA
International Coalition of Medicines Regulatory 
Authorities 
ITF
Innovation task force 
LLM
Large Language Model
MAH
Marketing Authorisation Holders

## Page 36 (Section: Slide 36: Acronyms)

36
Acronyms
MIDD
Model-Informed Drug Development
mHealth
Mobile Health
MWP
Methodology Working Party
NDSG
Network Data Steering Group
PED
Patient Experience Data
PHPID
Pharmaceutical Product Identification
PMS
Product Management Service
POC
Proof of Concept 
PRAC
Pharmacovigilance Risk Assessment Committee
PRIME
PRIority MEdicines
PTM
Portfolio and technology meetings 
ROG
Regulatory Optimisation Group
RWD
Real World Data
RWE
Real World Evidence
SDO
Standards Development Organisations 
SEND
Standard for Exchange of Nonclinical Data 
SIA
Special Interest Area 
SmPC
Summary Product Characteristics 
SMS
Substance Management Service
SUSAR
Suspected Unexpected Serious Adverse Reports 
SPQS
Structured Product Quality Submissions
TEHDAS
Towards the European Health Data Space
UNIWIDE
UNIWIDE IDMP Joint Action: UNIque Widespread 
IDentification for medicines in Europe


---

# Real-world evidence framework to support EU regulatory decision-making: 4th report (2025-2026)

- **Issuer:** EMA
- **Type:** Report
- **Language:** en
- **Source:** https://www.ema.europa.eu/en/documents/report/real-world-evidence-framework-support-eu-regulatory-decision-making-4th-report-experience-gained-regulator-led-studies-february-2025-february-2026_en.pdf
- **Licence:** EMA-reuse

## Page 1 (Section: Cover page RWE report 4 (1).pdf)

Real-world evidence 
framework to support 
EU regulatory 
decision-making
4th report on the experience gained 
with regulator-led studies from 
February 2025 to February 2026
An agency of the European Union

## Page 2 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

Table of Contents 
 
Executive Summary ..................................................................................... 2 
List of abbreviations .................................................................................... 3 
Highlights .................................................................................................... 4 
1. Introduction ............................................................................................ 5 
2. Real-world evidence generated for the European Medicines Regulatory 
Network and other stakeholders ................................................................. 6 
2.1. Research topics assessed .................................................................................... 6 
2.2. Completed and ongoing studies ............................................................................ 9 
2.3. Studies by requester......................................................................................... 10 
3. Usefulness and impact of RWE .............................................................. 12 
3.1. Survey on perceived value of RWE by the requesters ............................................ 12 
3.2. Areas of improvement ....................................................................................... 12 
3.3. Illustrative use cases ........................................................................................ 13 
4. Methodological support on relevance of RWD sources and study designs 
for regulatory purposes ............................................................................. 15 
5. Progress made on operational aspects .................................................. 16 
Annex 1 List of EMA-led RWD studies initiated in the period ..................... 21 
Annex 2 List of EMA-led RWD studies finalised in the period ..................... 26

## Page 3 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

2 
 
Executive Summary 
This fourth annual report outlines the progress in integrating real-world evidence (RWE) into regulatory 
decision-making, aligned with the European Medicines Regulatory Network (EMRN) strategy to 2028 and 
in anticipation of the provisions from the new pharmaceutical legislation. It comprises two RWE 
generation pathways coordinated by the European Medicines Agency (EMA): DARWIN EU®, and studies 
commissioned via framework contracts. 
Covering the period from 8 February 2025 to 7 February 2026, 108 research topics were assessed, with 
48 new topics identified. The vast majority (88%) were addressed through DARWIN EU®, highlighting 
the increased capability and capacity of this pathway. Feasibility assessments showed a high success 
rate, with 77% of assessed topics deemed feasible, resulting in 43 completed and 45 ongoing studies by 
February 2026 – a 49% increase compared with the previous year. 
Research focused primarily on drug utilisation, disease epidemiology, medicines safety and studies 
addressing the design and feasibility of planned studies, a category which increased considerably in the 
period.  
Nervous system disorders, oncology, immunology, anti‑infectives, and cardiovascular diseases remained 
the most frequently addressed therapeutic areas. 
Research topics were identified across a diverse range of regulatory and public health decision-makers: 
EMA scientific committees and working parties, EMA internal functions, European Centre for Disease 
Prevention and Control (ECDC), HTA bodies/payers and the European Commission (EC). 
DARWIN EU® demonstrated both maturity and increased capacity. The number of complex studies 
nearly doubled, two very complex studies were initiated for the first time (in pregnancy and oncology), 
and the median number of data partners per study increased from three to six. Studies conducted by 
consortia under the EMA framework contracts, most of them complex, continue to add value, particularly 
for very complex topics, special populations and rare diseases. 
The median study duration of 4.8 months remained compatible with most regulatory timelines, enabling 
timely integration of RWE into regulatory processes. Such rapid results are a key benefit from the 
regulator-led approach being advanced by the EMRN. 
Operationally, significant progress was made in expanding and consolidating the network. DARWIN EU® 
grew to 40 data partners across 18 European countries, covering over 250 million European patients. 
Improvements were implemented in feasibility assessment, data quality, analytical pipelines, reporting, 
transparency, and governance.  
During the period, a survey to investigate the value of the evidence generated was conducted among 
study requesters and 30% of respondents reported direct use of RWE in formal regulatory decisions, 
while others highlighted its value for preparedness, methodological learning, and future decision-making. 
Overall, the report confirms that regulator-led RWE generation through DARWIN EU® is increasingly 
impactful, scalable, and strategically aligned with EU regulatory priorities, while continued efforts are 
needed to enhance data harmonisation, quality, and interpretability to maximise its potential.

## Page 4 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

3 
 
List of abbreviations  
Acronyms/term 
Description  
ADHD 
Attention-deficit hyperactivity disorder 
ATC 
Anatomical Therapeutic Chemical classification  
AWaRe 
Access, Watch, Reserve 
CAT 
Committee for Advanced Therapies 
CDM 
Common data model 
CHMP 
Committee for Medicinal Products for Human Use 
CMDh 
Coordination Group for Mutual Recognition and Decentralised Procedures - 
Human 
COMP 
Committee for Orphan Medicinal Products 
DARWIN EU 
Data Analysis and Real-World Interrogation Network EU 
ECDC 
European Centre for Disease Prevention and Control 
EHDS 
European Health Data Space 
EMA 
European Medicines Agency 
EMRN 
European Medicines Regulatory Network 
FWC 
Framework contract 
HMPC 
Committee on Herbal Medicinal Products 
HTA 
Health technology assessment 
MAA 
Marketing authorisation application 
MSSG 
Medicines Shortages Steering Group 
NSCLC 
Non-small cell lung cancer 
OD 
Orphan Designation 
OMOP 
Observational Medical Outcomes Partnership 
OTS 
Off-the-shelf 
PAH 
Pulmonary Arterial Hypertension 
PDCO 
Paediatric Committee 
PIP 
Paediatric Investigation Plan 
PRAC 
Pharmacovigilance Risk Assessment Committee 
PSUSA 
Periodic safety update single assessment 
RWD 
Real-world data 
RWE 
Real-world evidence 
SAWP 
Scientific Advice Working Party 
SPOC 
Medicine Shortages Single Point of Contact Working Party 
US 
United States of America 
VMP 
Vaccine Monitoring Platform 
WHO 
World Health Organisation

## Page 5 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

4 
 
Highlights  
Demand for EMA-led RWE remains strong but more focused 
• 
108 research topics assessed and 88 studies completed or ongoing (an increase of 49% 
versus previous reporting period). These were conducted via the two RWE generation pathways 
available: DARWIN EU® and the framework contracts for scientific studies 
• 
A shift toward feasibility-driven, higher-value questions has led to fewer new topics being 
initiated 
• 
Close to 80% feasibility rate, indicating better alignment between regulatory questions and 
available data 
DARWIN EU is maturing rapidly in scale, scope, and research question complexity 
• 
The network has grown to reach 40 data partners across 18 European countries, covering 
over 250 million patients, with additional inclusion of US data 
• 
More complex analyses are being executed, with:  
o 
Nearly doubling of the number of complex studies compared to last period. 
o 
Launch of the first two “very complex” studies (in pregnancy/mother-child and 
oncology) 
o 
Median number of data partners participating per study doubled (from 3 to 6) 
The value of RWE extends beyond “yes/no” decisions — it builds regulatory 
knowledge, preparedness, and confidence 
• 
30% of studies directly supported a formal regulatory decision in an active procedure 
• 
In addition, 44% improved clinical or methodological understanding and 15% supported 
preparedness (shortages, public health, antimicrobial resistance, future procedures) 
• 
Timing constraints and data granularity remain the main barriers to even higher procedural 
impact 
Operational efficiency has improved and speed is maintained 
• 
Median DARWIN EU study duration: ~5 months, compatible with many (but not all) regulatory 
timelines 
• 
Blanket/umbrella protocol approvals at 8 data partners significantly reduce study duration 
• 
Further speed improvements are anticipated to be limited; focus is now on an ever greater, 
quality of outputs, including clarity of reports, and improved data quality with increased breadth 
of mapping and harmonisation

## Page 6 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

5 
 
1.  Introduction  
Well‑informed decisions on medicines - spanning development, authorisation, reimbursement, use, and 
monitoring - depend on excellence in clinical evidence (Clinical Evidence 2030). Europe’s shifting policy 
environment, marked by the EHDS and pharmaceutical legislation reform, is opening new opportunities 
for excellence in evidence generation through greater access to healthcare data, more innovative study 
designs, advanced analytics, and more patient‑centred approaches to medicines development. Notably, 
the pharmaceutical legislation reform supports the use of real‑world evidence (RWE) to complement 
clinical trial data in regulatory decision‑making1. It also emphasises that the Agency should be able to 
use such data, through current frameworks that are in place, including the Data Analysis and Real-World 
Interrogation Network (DARWIN EU) and the European Health Data Space interoperable infrastructure. 
These provisions in the new Pharma Regulation result from inter-institutional negotiations and are still 
pending formal adoption later this year.  
Covering the period from 8 February 2025 to 7 February 2026, this report on the experience gained in 
RWE generation marks the fourth year of DARWIN EU and the second operational year following its 
establishment phase in 2022-2024 (see the Report on regulatory-led studies using real-world data 
section). As with previous reports, the focus is on RWE generation via mostly two pathways established 
by the European Medicines Agency (EMA): DARWIN EU® and studies commissioned via the framework 
contracts for scientific studies. The report also covers the value of EMA-generated RWE for regulatory 
decisions, progress made on operational aspects since the last report, as well as methodological advice 
provided on the use of real-world data (RWD) within regulatory submissions. Research topics originated 
from evidence gaps identified during scientific assessment of EMA committees and divisions or EMA's 
collaborative work with other EU network stakeholders (e.g., Health Technology Assessment (HTA) 
bodies, European Centre for Disease Prevention and Control (ECDC)). The report does not cover RWE 
generated at the national competent authority level or by other EU agencies without EMA involvement 
or those submitted by industry. 
This report highlights how EMA-led RWE generation aligns with the focus areas of the European Medicines 
Regulatory Network (EMRN) strategy to 2028, by focusing on generating strong scientific evidence, which 
is incorporated into decision making processes or can inform, for instance, strategies for prevention of 
medicine shortages or antimicrobial resistance.   
 
 
 
 
 
1 Recital (60) and Article 169 of the Regulation laying down Union procedures for the authorisation and supervision of 
medicinal products for human use and establishing Rules governing the European Medicines Agency, as agreed in 
interinstitutional negotiations on 11 December 2025

## Page 7 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

6 
 
2.  Real-world evidence generated for the European 
Medicines Regulatory Network and other stakeholders 
2.1.  Research topics assessed  
A total of 108 research topics were assessed, out of which 48 (44%) were identified in the reporting 
period from 8 February 2025 to 7 February 2026, (i.e., ‘new research’ topics), and 60 (56%) were 
identified before 8 February 2025 and carried over (i.e., ‘carried over’ topics). The vast majority of the 
research topics (88%, 92) were addressed via the DARWIN EU pathway, while 15 were addressed via 
EMA’s framework contract for scientific studies (‘Quality, safety and efficacy studies of medicines’) and 
only one was conducted in-house, a pathway which is being phased out.(Figure 1) 
There were 43 studies completed (41 via DARWIN EU and two via framework contract) and 45 ongoing 
studies (32 via DARWIN EU and 13 via FWC) by 7 February 2026. In addition, some research topics 
assessed were not initiated (6) at requester recommendation, despite being feasible.  
 
Figure 1. Research topics identified or addressed during the reporting period  
This flowchart includes research topics identified during the reporting period (8 February 2025 to 7 February 2026) 
or addressed during the reporting period but identified before 8 February 2025. ‘Not initiated’ are studies that were 
feasible, however after additional discussions with the requester were not considered needed at the moment.  
 
Considering only the new research topics assessed during the reporting period (N=48), which were all 
handled via DARWIN pathway, 41 were feasible, leading to a feasibility percentage similar to that 
reported in 2025 (77% vs 76%, respectively).   
Most of the new research topics requested during the reporting period were requested by PRAC (N=12, 
25%) and EMA internal teams (N=11, 23%), followed by CHMP (N=6, 12%) and SAWP (N=4, 8%) (Figure 
2). No new requests were received during the reporting period from PDCO, ECDC and CAT.

## Page 8 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

7 
 
 
Figure 2. New research topics by requester (n=48) 
All assessed research topics (108) focused on 12 therapeutic areas. The most common were nervous 
system treatments (23, 21%), antineoplastic and immunomodulating agents (16, 15%), anti-infectives 
(14, 13%) and cardiovascular system (14, 13%) (Figure 3). As in the previous report they remain the 
most frequent therapeutic areas for which RWE generation is requested. However, research on the 
anti-infectives declined from position 1 to 4, while studies on the nervous system increased from 
position 3 to 1. 
Referring to the most recent research topics requested in the period (N=48), these were, in decreasing 
order of frequency: nervous system, cardiovascular system and antineoplastic and immunomodulating 
agents.

## Page 9 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

8 
 
 
Figure 3. Feasibility of research topics by Anatomical Therapeutic Chemical (ATC) classification (n=108) 
The ATC main group was assigned to each research topic based on the medicinal product under evaluation which 
triggered the research topic, or the substance studied in the study if there is no procedure applicable. ‘Not yet 
classified/Multiple products/No product involved’ category includes research topics for which the medicine has not 
yet been classified in the ATC system, the research topics which comprises several medicinal products or research 
topics which do not include medicinal products (e.g., disease epidemiology studies). 
 
Regarding regulatory procedures that triggered studies, which was the case for 17 of the new research 
topics, 6 were related to safety signal evaluation followed by procedures to inform upcoming MAAs and 
PSUSA (5 each) (Figure 4). 
 
 
Figure 4. New research topics identified during the reporting period, by type of regulatory procedure  
MAA = Marketing authorisation application; PSUSA= Periodic safety update single assessment

## Page 10 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

9 
 
2.2.  Completed and ongoing studies  
A total of 88 studies were conducted during the reporting period (43 completed and 45 ongoing), 
representing a 49% increase from the previous reporting period.   
Of the 88 studies (addressing a total of 101 use case types), most aimed at generating evidence in 
relation to drug utilisation (N=34, 34%), followed by disease epidemiology (N=18, 18%), design and 
feasibility of planned studies (N=17, 17%) and medicines safety (N=16, 16%) (Figure 6). In comparison 
to the previous reporting period, the proportion of studies addressing the design and feasibility of planned 
studies increased considerably (from 4% to 17%). 
 
Figure 5. Number of conducted studies by use case type during the reporting period 
Depending on the scope, a research topic may be assigned to one or more categories (e.g., a study aiming to 
describe incidence of a disease and prevalence of related prescribed treatments could represent both categories: 
disease epidemiology and drug utilisation). Therefore, the values presented in the bars sum up more than 88. 
 
The median study duration within DARWIN EU was 4.8 months (IQR: 4–6 months) from protocol 
approval to study results. An off-the-shelf (OTS) study had a median duration of 4.6 months while a 
complex study a median of 5.5 months. The current operational pace allows DARWIN EU to be 
effectively incorporated into the timelines of most regulatory procedures, although exceptions remain. 
While efforts to enhance efficiency are ongoing, substantial additional gains in speed, while maintaining 
quality of studies and its deliverables, are becoming increasingly challenging to achieve.  
Regarding studies conducted via DARWIN EU, the number of complex studies almost doubled in the 
period (from 18 to 35), including for the first time the conduct of two very complex studies (as per 
DARWIN EU classification), initiated in pregnancy and oncology areas. The median number of data 
partners used per study also doubled from three in the previous reporting period to six during this 
reporting period. These indicators reflect the increased maturity of the network that can now tackle more 
complex questions.  
All 15 FWC studies were considered complex and focused mostly on assessing fitness for use of RWD for 
specialised disease areas (Chimeric Antigen Receptor T‑cell therapy, Duchenne Muscular Dystrophy) or 
exploring methodological topics such as target trial emulation (TTE) and estimand frameworks.  
The first two very complex studies started in the period are described below: 
Enabling pregnancy and mother-child research in DARWIN EU® - PeriNet 
This study aims at assessing and improving the readiness of the DARWIN EU® Data network to support 
research involving maternal and child health, through the following five specific objectives: (1) to 
identify data partners in the DARWIN EU® Data Network with available data on pregnancy, pregnancy

## Page 11 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

10 
 
start and end dates, pregnancy outcomes, and mother and child linkage; (2) to optimise and validate 
OMOP pregnancy algorithms for DARWIN EU® data partners with pregnancy-related data; (3) to 
establish a convention for the mapping of pregnancy-related data and parent-child linkage data to the 
OMOP Common Data Model (CDM), exploring the use of the Perinatal Extension Table (PET); (4) to 
characterise pregnancies and mother-child linkage over time for DARWIN EU® data partners with 
pregnancy-related data; (5) to create a database with aggregate counts related to pregnancy and 
mother-child linkage to better support feasibility assessment in this population. The project utilises data 
from 17 data sources across 12 European countries.  
Optimising Oncology - Enhanced Preparedness of the DARWIN EU® Network - OncoNET 
The DARWIN-OncoNet project aims to strengthen the DARWIN EU® Network’s ability to generate high-
quality RWE for regulatory questions in oncology. The initiative focuses on improving oncology‑related 
data quality, especially for treatment, grade and stage variables, oncology specific outcomes, and 
enhancing analytical pipelines such as treatment patterns, to enable future studies in the field of 
oncology. It will also create a database with aggregate counts related to oncology to better support 
feasibility assessment in this population. The project focuses on 10 different cancers and utilises data 
from 17 data sources across 14 European countries.  
2.3.  Studies by requester 
As in the previous reporting period, there was a broad range of requesters for studies (Figure 6).  
 
 
Figure 6. Number of ongoing or completed studies (n=88) during the reporting period by requester  
 
EMA Committees 
PRAC: During the reporting period, nineteen studies were conducted (either still ongoing or completed 
by the end of the reporting period) to support PRAC assessments, of which four were related to safety 
signal procedures, nine conducted in the context of PSUSAs, one evaluating the impact of risk 
minimisation measures, two drug utilisation studies (paracetamol and opioids) and the remaining five 
contributing to preparedness in the areas of pregnancy, feasibility of future safety studies and 
pharmacogenomics.  
The process for identifying evidence gaps for which RWE generation would be needed continued as 
agreed last year for both signal and PSUSA procedures. The decision of study’s initiation is made during

## Page 12 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

11 
 
the PRAC plenary, results are then published once the final version of the report is approved by the 
committee, and the concerned company(ies) is informed about the study, including results. 
CHMP and SAWP: Within the context of CHMP activities, five studies were ongoing or completed. Two 
were linked to initial MAAs and aimed to generate evidence directly in the procedure while three were 
preparatory studies in the areas of Duchenne Muscular Dystrophy and Alzheimer’s disease. More 
specifically, the study on Alzheimer’s disease provided contextual information on the incidence and 
prevalence of this disease in the general adult population in six European countries, as well as 
demographic and clinical characteristics of individuals diagnosed with this disease. The study on 
Duchenne Muscular Dystrophy is a complex framework contract study aimed to evaluate the fitness for 
use of registries in this disease area and assess their data quality. 
In addition, four studies were ongoing in the context of SAWP, regarding Angiotensin II receptor blockers 
(ARBs) prescribing in children and acute myeloid leukaemia natural history and treatment patterns. 
PDCO: In collaboration with PDCO, three studies were completed and one ongoing. The completed 
studies referred to the use of antiretroviral therapies in paediatric patients and characterisation of 
individuals diagnosed with paediatric pulmonary arterial hypertension. The ongoing study is a neonatal 
study, the first one ever conducted via DARWIN EU, studying seizures and treatments thereof in 
neonates.  
COMP: Two studies were completed and one ongoing in the period: description of tetanus 
immunoglobulin use and tetanus-prone wounds in Europe, treatments in women diagnosed with ovarian 
cancer, and one methodological study on methods to estimate prevalence of selected cancers.  
 
Other stakeholders 
HTA bodies/Payers: In collaboration with HTA bodies and payer organisations, one complex study 
estimating the overall survival in patients with advanced or metastatic non-small cell lung cancer 
(NSCLC) treated with selected immunotherapies as first line of treatment was completed (see Section 
3.3). The other ongoing studies addressed the following topics: characterisation of patients with multiple 
myeloma, including treatments and survival, and capacity and capability of the DARWIN EU network to 
capture appropriately information on obesity. 
MSSG: Five studies (out of which four completed) were performed during the reporting period to support 
the MSSG and the SPOC Working Party in monitoring the demand and stock levels of critical human 
medicines. These requests examined trends in the use of ADHD medications, salbutamol inhalation 
products and their alternatives, essential medicines in intensive care units and medicines likely to be 
used during public health emergencies. These efforts aim to monitor availability and effective 
management of critical medications in different healthcare settings and can be regularly rerun to 
continuously inform the team on utilisation trends and upcoming shortages in Europe.  
VMP: Two studies were conducted to inform vaccine safety and effectiveness topics identified in the VMP 
Research Agenda. The studies investigated: brand-specific influenza vaccine effectiveness in the Nordic 
countries (framework contract study) and vaccine coverage and incidence of influenza-related outcomes 
to inform preparedness for annual seasonal influenza vaccine effectiveness studies.  
ECDC: In collaboration with ECDC, three drug utilisation studies on antibiotics part of the WHO 
Watch/Access and reserve use categories were conducted (see section 3.3).  
European Commission: In collaboration with the European Commission, a study on prescription of 
antipsychotic drugs in children in Europe was conducted.

## Page 13 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

12 
 
Patient organisations: In collaboration with Cystic Fibrosis Europe, a pan‑European patient 
organisation that represents people with cystic fibrosis and their families across Europe, a drug utilisation 
study and a study to characterise patients diagnosed with cystic fibrosis in Europe were completed. The 
two studies aimed to generate evidence on the clinical characteristics and monitoring of patients with a 
cystic fibrosis diagnosis in routine clinical care.  
3.  Usefulness and impact of RWE 
3.1.  Survey on perceived value of RWE by the requesters  
To understand the value of the evidence generated, the study requesters were asked about the impact 
of the DARWIN EU study results, whether they were helpful for decision making. The response rate was 
67.5% (27 out of 40 surveys sent, only for DARWIN EU completed studies).   
Approx. 30% of the responders indicated that the study results were used to support a formal regulatory 
decision. Although direct immediate regulatory impact in ongoing procedures is important and the easiest 
to measure, the value of RWE goes beyond immediate impact, being also used to prepare for future 
procedures, to monitor shortages, to enhance collaboration with other stakeholders, or for 
methodological improvements, as highlighted by 59% of the respondents. 
Even with a very ambitious study duration offered by DARWIN EU, the regulators require the results to 
be delivered in weeks, which is incompatible with the current model in which approval from institutional 
scientific boards is needed before obtaining and analysing data, and in fact, with any model that requires 
a protocol based access to the data. Further work is necessary to guarantee delivery within timelines 
and maximise impact.  
A second reason identified in some cases, is the lack of adequate data, specifically data which is granular 
enough to answer the question precisely, and this can be partially addressed by increasing data quality, 
extending mapping to the CDM and onboarding of dedicated, more specialised data sources such as 
disease registries.  
 
Table 1. The regulatory impact of DARWIN EU studies (N=27 responses) 
Impact category  
(%) 
Translated into regulatory decisions1 
30% 
Preparedness for shortages, public health emergencies or other domains 
15% 
Helped to improve clinical or methodological knowledge 
44% 
Unknown  
11% 
 
1 - For example: supporting labelling changes (or no need for change), scientific advice, signal procedures, feasibility of future imposed 
studies requested by committees 
3.2.  Areas of improvement  
When asked for areas of improvement for RWE generation, a strong and recurring theme concerned 
heterogeneity of results which was seen as a barrier for comparability and interpretability of results. 
There was a clear call for improved data harmonisation, including more consistent coding, shared 
definitions, and aligned analytical approaches across countries in order to reduce methodological 
heterogeneity. In addition, there is some inherent clinical heterogeneity arising from different 
populations, and healthcare systems which should not be corrected but rather considered in 
interpretation.

## Page 14 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

13 
 
Respondents working in complex and rare disease areas (e.g., cystic fibrosis) emphasised the gap 
between routine healthcare data and disease‑specific registries, noting challenges related to missing 
information which made drawing conclusions difficult.  
Some respondents called for study objectives to be more closely matched with regulatory needs, while 
others requested more clear outputs or clearer methodological explanations. An improved discussion and 
interpretation section was requested.  
Other respondents noted that early feasibility studies should be more informative and clarify population 
size, exposure patterns, and outcome frequencies before committing to more resource‑intensive 
investigations. Of note, enhanced feasibility studies started to be implemented towards the end of the 
reporting period.  
3.3.  Illustrative use cases  
DARWIN EU® - Overall survival in patients with locally advanced or metastatic non-small cell lung cancer 
treated with selected immunotherapies as first line of treatment 
This DARWIN EU® study aimed to understand NSCLC treatment outcomes in a real-world setting and 
provides insights into the (comparative) effectiveness of first-line treatments of advanced or metastatic 
NSCLC with selected immunotherapies (alone or in combination with chemotherapy) versus 
chemotherapies alone.  
This was the first study to compare effectiveness in oncology performed via DARWIN EU®. The study 
was performed at the request of HTA bodies and Payers.  
Patients treated with selected immunotherapies were matched 1:1 to patients treated with 
chemotherapies based on propensity scores using age, sex, index year, tumour stage, and WHO 
performance status. The results of the study indicated an overall survival benefit associated with the use 
of pembrolizumab (which was the most frequently used immunotherapy) over chemotherapies when 
used as first-line treatment in patients diagnosed with locally advanced or metastatic NSCLC. The 
survival benefit found for pembrolizumab in this observational study (based on RWD) is in line with 
results from pivotal clinical trials (KEYNOTE-024, KEYNOTE-189, KEYNOTE-042) as well as with a 
nationwide observational study conducted in Norway (Hektoen et al., 2025). The results for other 
immunotherapies (nivolumab and the combination nivolumab+ipilimumab) suggest also improved 
survival compared to chemotherapies, but the results should be interpreted with caution due to the 
limited size of these two treatment cohorts; the use of other immunotherapies could not be studies due 
to paucity of data.  
DARWIN EU® - Clozapine and the risk of agranulocytosis - updated risk-minimisation measures 
This study investigated the incidence and timing of agranulocytosis and neutropenia in new users of 
clozapine, a medication used for treatment-resistant schizophrenia and Parkinson’s disease associated 
psychosis. Despite its effectiveness, clozapine is thought to be underused due to the risk of severe blood-
related side effects and the burden of long-term monitoring to prevent the side-effects.  
The study included over 40,000 patients from five European databases and aimed to provide RWE on 
how often and especially when these side effects occur after the start of clozapine treatment. The 
incidence of agranulocytosis and neutropenia was very low across all data sources, with most events 
occurring within the first two months of treatment. The risk remained minimal throughout the follow-up 
period, and there were no significant differences by age or sex. The median time to event varied by 
country however, overall, the probability of not developing these conditions remained high.

## Page 15 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

14 
 
PRAC used the results, alongside other evidence in its assessment, to update its recommendations for 
clozapine monitoring, including less frequent blood count monitoring and focusing solely on the absolute 
neutrophil count (ANC), which were shown by the current evidence to be more specific and the most 
relevant marker for the risk of neutropenia.  
DARWIN EU® - Incidence, period prevalence, and characterisation of individuals with paediatric 
pulmonary arterial hypertension 
The study was initiated as part of the paediatric investigation plan (PIP) for an endothelin receptor 
antagonist used for the treatment of pulmonary arterial hypertension (PAH). Its scope was subsequently 
broadened to address a wider question about paediatric PAH that could support future regulatory 
decisions. The objectives were to estimate the incidence and prevalence of PAH in children and to 
characterize paediatric patients at the time of first PAH diagnosis in terms of demographics, underlying 
aetiology, comorbidities, treatment patterns (including endothelin receptor antagonists and 
phosphodiesterase-5 inhibitors as mono- or combination therapy), and to calculate the occurrence of 
clinical outcomes such as hospitalisation and mortality over a five-year follow-up. The study received 
positive feedback from PDCO, since it filled an existing knowledge gap in the area and helped to address 
some of the issues raised by the applicant. 
DARWIN EU® - Drug Utilisation Study of Antibiotics of the WHO AWaRe classification of antibiotics for 
evaluation and monitoring of use 
The WHO 2023 AWaRe classification (who.int) categorizes 258 antibiotics into three groups of ‘Access’, 
‘Watch’, and ‘Reserve’ based on their role in the treatment and impact on antimicrobial resistance. This 
study has been conducted in conjunction with the European Centre for Disease Prevention and Control 
(ECDC), building on the knowledge of a previous study conducted in 2022/2023 (DARWIN EU® P1-C1-
003 study), which focused only on the ‘Watch’ category, and expanding its initial scope to the other 
categories (Access and Reserve) when repeating the ‘Watch’ category with more recent data and more 
data sources. 
Results were presented per Access, Watch and Reserve lists, reporting most prescribed classes and 
individual substances, including seasonal trends with duration of use and indication. In Access category, 
across all data sources, penicillins (led by amoxicillin–clavulanic acid) were the most frequently 
prescribed 
antibiotics. 
In 
Watch category, 
the 
most 
prescribed 
classes 
were 
macrolides, 
fluoroquinolones, 2nd- and 3rd-generation cephalosporins. Reserve category antibiotic use was generally 
low but varied widely across data sources, with the highest usage observed for oxazolidinones, 
lipopeptides and polymyxins. Reserve antibiotics, including linezolid and daptomycin, showed increasing 
but still limited use, reflecting their restricted role in managing resistant infections.  
Overall, these findings may support optimising antibiotic use across Europe and through harmonised 
stewardship strategies, and the detailed outputs for individual antibiotics provide additional insights that 
can inform policy and antimicrobial resistance activities. 
DARWIN EU® - Trends in utilisation of Attention-Deficit Hyperactivity Disorder (ADHD) medications 
Attention-Deficit/Hyperactivity Disorder (ADHD) is a chronic neurodevelopmental disorder affecting both 
children and adults. In recent years, demand for ADHD medicines has increased markedly in Europe, 
accompanied by reports of constrained supply, regulatory approvals, and market changes. A first study 
was completed during the previous reporting period, and then repeated with additional data partners 
and more recent data during this reporting period, aiming to characterise trends in ADHD medication 
use in Europe from 2010 to 2024. 
The repeated study was conducted using six data sources from five European countries (Denmark, 
Germany, Norway, Spain and Sweden) and included individuals aged ≥3 years using any approved ADHD

## Page 16 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

15 
 
medication. A total of 973,816 individuals initiated at least one ADHD medication during the study period, 
with prevalence and incidence that increased across all data sources during the period, with greater use 
in Scandinavian countries than in Spain and Germany. Methylphenidate was the most frequently used 
medication throughout. Atomoxetine was the second most common in earlier years but was gradually 
overtaken by lisdexamfetamine between 2015 and 2019. Guanfacine use, indicated only for children, 
also increased steadily in later years. 
Stratified analyses showed higher use among boys than girls in all paediatric age groups, although the 
gap narrowed among older adolescents after 2020 due to a steeper rise girls. Among adults, use 
increased in both sexes, with a more pronounced rise among females since 2020, leading to higher 
prevalence and incidence among females in Denmark, Germany, Norway, and Sweden by the end of the 
study period. Initiators the Scandinavian data sources were older on average than those in Spain and 
Germany, and males predominated overall (54%-68%).  
ADHD medication use increased consistently across five European countries from 2010 to 2024. These 
trends align with previous evidence and may reflect greater awareness, improved diagnosis, and evolving 
clinical guidelines. Continued monitoring is needed to support optimal ADHD management across Europe. 
DARWIN EU® - Prescription trends of ketamine and esketamine 
Ketamine and esketamine are authorised for use in anaesthesia and for sedation in medical procedures, 
as well as for managing treatment-resistant depression. The non-medical use of ketamine has become 
a growing concern within the European Union, prompting law enforcement actions to monitor its illicit 
trafficking and misuse. To better understand the scope of this issue, a DARWIN EU study has been 
conducted to examine legitimate prescription trends for ketamine and esketamine in collaboration with 
European Union Drug Agency (EUDA). 
The results showed distinct patterns of ketamine and esketamine prescriptions across different 
healthcare settings. Ketamine prescriptions were consistently infrequent in primary care settings, with 
little variation over time. In contrast, hospital-based data sources showed a gradual increase in ketamine 
prescribing in the later years of the study. Esketamine prescriptions remained rare across all data sources 
(with highest use in Finland). Overall, ketamine and esketamine utilisation at the population level in 
Europe remained limited over the past decade, with slightly increasing trends for ketamine observed in 
hospital settings since 2021. 
These findings provide important baseline information for ongoing monitoring of ketamine and 
esketamine utilisation in clinical practice, and supported the EUDA in contextualising these results within 
its monitoring of non‑medical use.  
4.  Methodological support on relevance of RWD sources and 
study designs for regulatory purposes 
EMA can provide methodological input on the relevance of RWD sources, study designs, and analytical 
approaches to address specific research questions for regulatory purposes. This support is delivered 
through established regulatory pathways, including early interactions and advice mechanisms, as well 
as regulatory evaluations conducted by EMA committees. 
In this context, the EMA RWE team is involved in the review of requests related to the use of RWD for 
regulatory purposes raised by marketing authorisation applicants or holders, as well as by non-for-profit 
organisations.

## Page 17 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

16 
 
The aims of this activity are to: 
• 
Support regulatory feedback to applicants in the frame of early interactions and advice mechanisms, 
such as Innovation Task Force (ITF), portfolio and technology meetings (PTM), qualification of novel 
methodologies (QoNM), PRIME, scientific advice (SA) and other non‑binding exchanges including 
interaction with patient registries. This input supports the preparation of evidence packages by 
improving their quality, completeness, and relevance in view of future submission within regulatory 
procedures, such as e.g., a marketing authorization application or post approval commitment 
• 
Support regulatory evaluation by the EU Regulatory Network through active participation in peer-
review activities. Members of EMA working parties and committees, as well as assessors from 
national competent authorities, can seek methodological input across all stages of product 
development and evaluation, procedures and therapeutic areas. 
The scope of the support offered include the exploration of existing RWD sources and their fitness-for-
purpose in a specific context, comparison against data sources known to EMA, discussion on the 
feasibility of applicant-proposed study designs, or exchanging views on protocols or reports of a study 
using RWD. 
Between February 2025 and January 2026, the team was involved in 52 requests that included at least 
one question related to RWD. Of these, 49 were raised during early interactions and advice mechanisms, 
including 32 scientific advice procedures, representing an increase compared to the previous year, and 
3 related to regulatory evaluations. Examples of these requests included cases where historical data was 
used as benchmark for clinical trials endpoints, or where patient registry data were used as comparator 
in an externally controlled clinical study. Portfolio and technology meetings, aimed at discussing and 
anticipating future scientific and regulatory needs, addressed recurring topics such as the use of RWD to 
inform benefit-risk of medicines, innovative study designs and methodologies including pragmatic trials 
and target trial emulation. Figure 8 shows the number of methodological support requests by ATC 
classification and pathway. 
 
Figure 7. Number of requests for methodological advice by Anatomical Therapeutic Chemical (ATC) 
classification and pathway (n=52) 
5.  Progress made on operational aspects  
This section reports on the progress made so far in the implementation of the recommendations made 
by the advisory board and other stakeholders since the last report in five key areas, as listed below.

## Page 18 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

17 
 
The activities which became routine are only briefly listed, while the focus is on achievements in the 
reporting period and newly started activities to address these recommendations.   
 
• 
Widened access to additional data partners to complement the existing network, with a larger 
range of diverse and complementary data, including additional European countries to 
increase geographical representativeness. During this reporting period, the DARWIN EU® network 
expanded from 30 to 40 data partners, across 18 European countries, covering over 250 million 
patients in Europe (Figure 8). In line with the recommendation from the Advisory Board, the fourth 
and last wave of data partners focused on covering areas of special interest such as paediatric 
population and cancer registries. Two new European countries (Poland and Lithuania) were added to 
the network as well as three US data sources (adding close to 230 million patients from the US). 
The list of new data partners can be found here.  
 
Figure 8. DARWIN EU Network as of February 2026 
This network composition refers to the reporting period. Any post reporting updates are published in the Factsheet: DARWIN EU - 
Making health data count at: Data Analysis and Real World Interrogation Network (DARWIN EU) | European Medicines Agency (EMA)

## Page 19 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

18 
 
Enhancing access to and use of more diverse data sources will be further facilitated via Lot 5 – 
Pharmacoepidemiological research of the new EMA FWCs, which covers the period 2026-2030. With 
capacity for both secondary use of data and primary data collection, 10 research organisations and 
academic institutions will provide access to multiple data sources, complementary to DARWIN EU’s data 
partners. This pathway also has capability to address research questions that may not be feasible via 
DARWIN EU, for example when very specialised data or expertise is needed, such as on studies on rare 
diseases. More information on the technical specifications of the new contracts and the description of 
services that can be delivered by Lot 5 is available on the EU Funding & Tenders Portal. 
 
 
 
All previously described strategies to accelerate study conduct such as phenotype standardisation, 
obtaining blanket protocols for faster approvals, improvement of processes and templates are continuing 
and considered routine activities. 
As of now, eight data partners have blanket or umbrella approval for study protocols, allowing faster 
study start-up and reduced administrative burden, by avoiding submitting a full, new approval application 
each time the data partner is selected for a specific study. This significantly shortens timelines from 
study conception to execution — critical in fast‑moving or time‑sensitive research — and improves 
efficiency. Overall, for the network, the protocol approval by the local Institutional Review Boards ranges 
from 14 to 78 days (approximately 2.5 months), with a median of 23 days. 
While additional efforts to enhance efficiency are ongoing, substantial additional gains in speed are 
becoming increasingly challenging to achieve. Future development efforts will therefore prioritise the 
consolidation of both data quality and the quality of study deliverables, especially of study reports. 
• 
Revise periodically and improve the standard analytical pipelines: In 2025, three new 
additions or updates to the analytical pipelines were made: treatment patterns updated module, the 
meta-analysis module, and the incidence/prevalence rates with external denominator.  
• 
Streamline, harmonise and improve processes and templates: New protocol and report 
templates were developed and applied during the study period to improve quality and readability of 
deliverables. Redundancies have been also reduced to limit risks of errors, discrepancies and 
protocol/report writing and review time. Additional efforts will be undertaken to streamline and 
substantially shorten the report template, to be possibly used for “simple” OTS studies. 
• 
Improve feasibility process: The feasibility process was revised and now includes a fitness-for-
use assessment, that considers, beyond presence of key variables and their counts, also their 
reliability, the relevance of the setting covered and representativeness and coverage of the data 
source. The development of feasibility process is still ongoing.  
• 
Increase transparency on data source description and justification for data source 
selection for RWD studies: Standardised text related to each data partner was developed to 
address content and key information for each data source, but also data reliability as verified at 
onboarding and at each new CDM update release A section on justification for data source selection 
(the relevance component of the Data Quality Framework) is now a standard part of protocols and 
reports, and together with standardised database descriptions aims to increase transparency on 
feasibility and fit-for-use processes and help interpretation of results.

## Page 20 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

19 
 
• 
Improve data quality, increase breadth of mapping and harmonisation: Data partners 
undergo a comprehensive quality check at onboarding and at each new CDM update, which occurs 
on average every 6 months. In addition, a tracker of quality issues is maintained, and each issue is 
addressed as soon as possible as well as their impact on study results documented. The Data Quality 
Framework for EU medicines regulation: applications to Real-World Data was published in March 
2026 and the DARWIN EU Coordination Centre is currently adhering to its recommendations.  
 
 
All previously reported strategies to anticipate RWE needs such as review of portfolio of upcoming initial 
marketing authorisation applications, screening of PSUSAs and signal assessment procedures and 
involvement of the EMA RWE team in EMA Portfolio and Technology meetings are now part of standard 
practice. As well as the screening of research needs outlined in the VMP research agenda and/or triggered 
by research needs outlined in the VMP research agenda and/or triggered by EMA's Emergency Task Force 
(ETF) and the EMA’s Public Health Threats team. 
 
 
 
Development of educational material and tools specifically designed for regulatory decision makers such 
as Pharmacoepidemiology and RWE curriculum (with release of the last two modules end of 2025) 
continued alongside Real-World Academy events (4 events in 2025 addressing the following topics: 1) 
RWE use cases in collaboration with CHMP, 2) RWE in pregnancy, 3) Target trial emulation framework, 
and 4) Feasibility assessment). 
In addition, multi-stakeholder workshops related to RWD and RWE were organised during this reporting 
period, such as on Patient Registries for Alzheimer's disease (in December 2025) to enable the 
generation of meaningful safety and efficacy/effectiveness data using existing patient registries.  
 
 
 
• 
Interactions with the Committees, SAWP and CMDh members, circulation of a quarterly RWE 
newsflash to the regulatory network, publication of study protocols and reports in the Catalogue of 
RWD studies are now routine activities. These will be supported shortly by the addition of links to 
the study analysis code packages; and visual abstracts, for even more transparency.

## Page 21 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

20 
 
• 
Inteaction with data partners: In March 2025, EMA held its first meeting with the DARWIN EU 
data partners to show how DARWIN EU studies are integrated into the regulatory work, followed by 
a face-to-face event in autumn discussing achievements and challenges. We aim for this to be a 
regular opportunity to enhance collaboration.  
• 
Industry involvement: Regular dialogue with industry representatives started in 2024 and 
continued in 2025 in the form of quarterly meetings in which industry and EMA representatives 
brainstorm about DARWIN EU and RWE developments in general. Industry is also involved in 
reviewing selected study protocols, for example for complex studies where their product is 
concerned.

## Page 22 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

21 
 
Annex 1 List of EMA-led RWD studies initiated in the period   
 
Topic 
Pathway  
Study 
Requester 
Study 
Status 
Procedure 
HMA/EMA 
Catalogue 
identifier 
Descriptive study of tetanus 
immunoglobulin use and 
tetanus-prone wounds in 
Europe 
DARWIN 
EU 
COMP 
Completed 
New OD 
EUPAS1000000685 
Treatment patterns in 
postmenopausal women in 
European countries: A real-
world observational study 
 
DARWIN 
EU 
EMA internal 
Ongoing - 
Results 
N/A 
EUPAS1000000821 
RR2 Drug utilisation study of 
prescription opioids 
DARWIN 
EU 
PRAC 
Completed 
PSUSA 
EUPAS1000000615 
Capturing obesity in DARWIN 
EU 
DARWIN 
EU 
HTA/Payers 
Ongoing - 
Results 
N/A 
EUPAS1000000820 
Antipsychotic prescribing in 
children in Europe: a descriptive 
analysis of trends and patient 
characteristics 
DARWIN 
EU 
Other 
Completed 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000592 
Trends in utilisation of 
Attention-Deficit Hyperactivity 
Disorder (ADHD) medications 
DARWIN 
EU 
CMDh/NCA 
Completed 
Other 
EUPAS1000000678 
RR Childhood hypertension and 
sartans prescribing in children 
DARWIN 
EU 
SAWP 
Completed 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000714 
Assessment of immunoglobulin 
use in clinical practice 
 
DARWIN 
EU 
Other 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000823 
Drug Utilisation Study of 
terbinafine-containing products 
DARWIN 
EU 
PRAC 
Completed 
PSUSA 
EUPAS1000000790 
DARWIN EU® - Enhanced 
Preparedness of the DARWIN 
EU Network for regulatory 
questions in oncology – 
DARWIN OncoNet 
DARWIN 
EU 
EMA internal 
Ongoing - 
Protocol 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000824 
Characterisation of aliskiren 
users 
DARWIN 
EU 
PRAC 
Completed 
PSUSA 
EUPAS1000000768 
Alzheimer’s disease: Incidence, 
prevalence, and individual’s 
characteristics 
DARWIN 
EU 
CHMP 
Completed 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000826

## Page 23 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

22 
 
Topic 
Pathway  
Study 
Requester 
Study 
Status 
Procedure 
HMA/EMA 
Catalogue 
identifier 
Encephalitis risk in pediatric 
varicella vaccine recipients 
DARWIN 
EU 
PRAC 
Completed 
Signal 
EUPAS1000000813 
RR Childhood hypertension and 
sartans prescribing in children 
DARWIN 
EU 
SAWP 
Completed 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000714 
Characterisation of individuals 
with cystic fibrosis in Europe 
DARWIN 
EU 
Other 
Completed 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000710 
Time to onset of 
thromboembolic events in 
patients with selected types of 
cancer 
DARWIN 
EU 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
 
EUPAS1000000814 
Drug utilisation study in 
individuals with cystic fibrosis in 
Europe 
DARWIN 
EU 
Other 
Completed 
Not linked 
to an 
ongoing 
procedure 
 
EUPAS1000000708 
Characterisation of individuals 
with cystic fibrosis in Europe 
DARWIN 
EU 
Other 
Completed 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000709 
Capturing obesity, obesity-
related variables, and changes 
in weight over time across the 
DARWIN EU® network (4 
studies) 
DARWIN 
EU 
HTA/Payers 
Ongoing - 
Results 
N/A 
EUPAS1000000820 
Characterization of data capture 
related to suicidality in DARWIN 
EU network 
DARWIN 
EU 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000825 
Characteristics of individuals 
with acute graft vs. host disease 
with intestinal involvement 
DARWIN 
EU 
CHMP 
Ongoing - 
Results 
MAA 
EUPAS1000000878 
Potential association between 
beta blockers and breast cancer 
DARWIN 
EU 
PRAC 
Ongoing - 
Protocol 
Signal 
To be published 
Treatment characterisation and 
post-diagnosis outcomes in 
individuals with Alzheimer’s 
disease 
DARWIN 
EU 
CHMP 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000827 
Background incidence rates of 
selected vaccine adverse events 
of special interest (AESIs) in 
European data sources 
DARWIN 
EU 
Other 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
To be published

## Page 24 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

23 
 
Topic 
Pathway  
Study 
Requester 
Study 
Status 
Procedure 
HMA/EMA 
Catalogue 
identifier 
Estimating the incidence of 
myocarditis among young males 
across Europe 
DARWIN 
EU 
EMA internal 
EMA 
internal 
Ongoing - 
Protocol 
To be published 
Population demographics and 
disease frequency across the 
DARWIN EU® network (3 
studies) 
DARWIN 
EU 
EMA internal 
Ongoing - 
Protocol 
Not linked 
to an 
ongoing 
procedure 
To be published 
Assessing the potential 
association between venlafaxine 
and incident heart failure in 
adult patients with depression 
or anxiety disorder 
DARWIN 
EU 
PRAC 
Ongoing - 
Results 
Ongoing - 
Results 
To be published 
Drug utilisation study of 
intramuscular depot olanzapine 
DARWIN 
EU 
MSSG 
Ongoing - 
Protocol 
Other 
EUPAS1000000980 
Characterization of data capture 
related to suicidality in DARWIN 
EU network (2 studies) 
DARWIN 
EU 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000825 
Multiple myeloma: patient 
characterisation, treatments, 
and survival in the period 2012–
2024 
DARWIN 
EU 
HTA/Payers 
Ongoing - 
Results 
Other 
EUPAS1000000757 
Neonatal seizures: Incidence, 
prevalence, patient 
characterisation, and 
treatments in European 
countries 
DARWIN 
EU 
PDCO 
Ongoing - 
Results 
PIP 
EUPAS1000000822 
Assessing feasibility of 
investigating acute myeloid 
leukaemia: incidence, patient 
characteristics, treatments, and 
survival in the period 2015–
2024 (2 studies) 
DARWIN 
EU 
SAWP 
Ongoing - 
Results 
Other 
EUPAS1000000773 
Description and assessment of 
fitness-for-purpose of real-world 
data (RWD) sources on 
Duchenne Muscular Dystrophy 
for regulatory decision-making 
Funded 
(FWC) 
CHMP 
Ongoing - 
Protocol 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000748 
Characterisation of systemic 
treatments for the management 
of ovarian cancer 
 
DARWIN 
EU 
COMP 
Ongoing - 
Results 
N/A 
EUPAS1000000815 
TARGET-EU: Effectiveness of 
BNT162b2 mRNA COVID-19 
vaccine in healthy individuals or 
Funded 
(FWC) 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
To be published

## Page 25 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

24 
 
Topic 
Pathway  
Study 
Requester 
Study 
Status 
Procedure 
HMA/EMA 
Catalogue 
identifier 
with stable pre-existing medical 
conditions against SARS-CoV-2 
infection 
ongoing 
procedure 
TARGET-EU: Nivolumab plus 
ipilimumab with chemotherapy 
versus pembrolizumab with 
chemotherapy in patients with 
non-oncogenic metastatic non-
small-cell lung cancer with <1% 
PD-L1 tumour expression 
 
Funded 
(FWC) 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
To be published 
TARGET-EU: Dapagliflozin and 
major adverse cardiovascular 
events in type 2 diabetes  
 
Funded 
(FWC) 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
To be published 
TARGET-EU: Rivaroxaban and 
risk of major gastrointestinal 
bleeding in elderly patients with 
non-valvular atrial fibrillation 
 
Funded 
(FWC) 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
To be published 
TARGET-EU: Comparison of 
single-device 
vilanterol/fluticasone furoate 
with other single-device inhaled 
corticosteroid and long-acting 
beta agonist combinations in 
the risk of pneumonia in 
adolescents with asthma 
 
Funded 
(FWC) 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
To be published 
TARGET-EU: The risk of 
angiooedema and other safety 
events in heart failure patients 
treated with sacubitril/valsartan 
compared to angiotensin-
converting enzyme inhibitors 
 
Funded 
(FWC) 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
To be published 
TARGET-EU: Risk of adverse 
birth and neurodevelopmental 
outcomes in children born alive 
to fathers exposed to valproate 
versus levetiracetam for 
generalised epilepsy 
 
Funded 
(FWC) 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
To be published 
TARGET-EU: Tolvaptan and risk 
associated to hepatotoxicity in 
Funded 
(FWC) 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
To be published

## Page 26 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

25 
 
Topic 
Pathway  
Study 
Requester 
Study 
Status 
Procedure 
HMA/EMA 
Catalogue 
identifier 
autosomal dominant polycystic 
kidney disease 
 
ongoing 
procedure 
TARGET-EU: Clinical benefit of 
bevacizumab in metastatic 
colorectal cancer 
Funded 
(FWC) 
EMA internal 
Ongoing - 
Results 
Not linked 
to an 
ongoing 
procedure 
To be published 
Coverage of meningococcal 
vaccines by the target 
population in Europe 
DARWIN 
EU 
PRAC 
Completed 
PSUSA 
EUPAS1000000675 
Characterisation of acute renal 
outcomes and diabetic 
complications among patients 
with concomitant use of 
metformin and iodinated 
contrast agents 
DARWIN 
EU 
PRAC 
Completed 
PSUSA 
EUPAS1000000662 
Incidence, period prevalence, 
and characterisation of 
individuals with paediatric 
pulmonary arterial hypertension 
DARWIN 
EU 
PDCO 
Completed 
Not linked 
to an 
ongoing 
procedure 
EUPAS1000000716 
Feasibility of studies on early 
(pre-symptomatic) stages of 
type 1 diabetes in DARWIN EU 
network 
DARWIN 
EU 
EMA internal 
Completed 
MAA 
EUPAS1000000756 
Proof-of-concept: Preparedness 
for annual seasonal influenza 
vaccine effectiveness studies - 
Vaccine coverage and incidence 
of influenza-related outcomes 
DARWIN 
EU 
VMP 
Completed 
Other 
EUPAS1000000803 
Clozapine and the incidence of 
agranulocytosis over time 
DARWIN 
EU 
PRAC 
Completed 
Signal 
EUPAS1000000549 
Prevalence of selected cancers 
DARWIN 
EU 
COMP 
Completed 
Other 
EUPAS1000000715 
Paracetamol prescribing and 
paracetamol overdose in 
Europe: a descriptive analysis 
of trends and patient 
characteristics 
DARWIN 
EU 
COMP 
Completed 
N/A 
EUPAS1000000584

## Page 27 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

26 
 
Annex 2 List of EMA-led RWD studies finalised in the period   
Topic 
Pathway  
Study 
Requester 
Procedure 
HMA/EMA 
Catalogue 
identifier 
Descriptive study of tetanus 
immunoglobulin use and tetanus-prone 
wounds in Europe 
DARWIN EU 
COMP 
New OD 
EUPAS1000000685 
RR2 Drug utilisation study of 
prescription opioids 
DARWIN EU 
PRAC 
PSUSA 
EUPAS1000000615 
Antipsychotic prescribing in children in 
Europe: a descriptive analysis of trends 
and patient characteristics 
DARWIN EU 
Other 
Not linked to 
an ongoing 
procedure 
EUPAS1000000592 
Trends in utilisation of Attention-Deficit 
Hyperactivity Disorder (ADHD) 
Medications 
DARWIN EU 
CMDh/NCA 
Other 
EUPAS1000000678 
RR Childhood hypertension and sartans 
prescribing in children 
DARWIN EU 
SAWP 
Not linked to 
an ongoing 
procedure 
EUPAS1000000714 
Drug Utilisation Study of terbinafine-
containing products 
DARWIN EU 
PRAC 
PSUSA 
EUPAS1000000790 
Characterisation of aliskiren users 
DARWIN EU 
PRAC 
PSUSA 
EUPAS1000000768 
Alzheimer’s Disease: Incidence, 
Prevalence, and Individual’s 
Characteristics 
DARWIN EU 
CHMP 
Not linked to 
an ongoing 
procedure 
EUPAS1000000826 
Encephalitis Risk in Pediatric Varicella 
Vaccine Recipients 
DARWIN EU 
PRAC 
Signal 
EUPAS1000000813 
RR Childhood hypertension and sartans 
prescribing in children 
DARWIN EU 
SAWP 
Not linked to 
an ongoing 
procedure 
EUPAS1000000714 
Characterisation of individuals with 
cystic fibrosis in Europe (including 2 
studies) 
DARWIN EU 
Other 
Not linked to 
an ongoing 
procedure 
EUPAS1000000709 
EUPAS1000000710 
Drug utilisation study in individuals 
with cystic fibrosis in Europe 
 
DARWIN EU 
Other 
Not linked to 
an ongoing 
procedure 
EUPAS1000000708 
ADEPT: The utilisation of antiseizure 
medications in pregnant women, other 
women of childbearing potential, and 
men: a multi-database study from 7 
European countries 
Funded 
(FWC) 
PRAC 
Other 
EUPAS1000000212 
Overall survival in patients with 
advanced or metastatic non-small cell 
lung (NSCLC) cancer treated with 
selected immunotherapies as first line 
of treatment 
DARWIN EU 
HTA/Payers 
Other 
EUPAS1000000112 
Drug Utilisation Study on Antibiotics in 
the ‘Watch’ category of the WHO 
DARWIN EU 
ECDC 
N/A 
EUPAS1000000665

## Page 28 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

27 
 
Topic 
Pathway  
Study 
Requester 
Procedure 
HMA/EMA 
Catalogue 
identifier 
AWaRe classification of antibiotics for 
evaluation and monitoring of use 
Incidence rates of venous 
thromboembolic events in patients with 
selected cancers 
DARWIN EU 
EMA internal 
Signal 
EUPAS1000000440 
Characterising the use of JAK inhibitors 
in Europe: a Drug Utilisation Study 
DARWIN EU 
PRAC 
Not linked to 
an ongoing 
procedure 
EUPAS1000000424 
Trends in utilisation of Attention-Deficit 
Hyperactivity Disorder (ADHD) 
Medications 
DARWIN EU 
MSSG 
Other 
EUPAS1000000219 
Association between genetic 
polymorphisms of interest and risk of 
myopathy among statin users 
DARWIN EU 
PRAC 
N/A 
EUPAS1000000369 
Association of venous 
thromboembolism with non-steroidal 
anti-inflammatory drug use in women 
15-49 years using hormonal 
contraceptives 
DARWIN EU 
PRAC 
PSUSA 
EUPAS1000000443 
Characterisation of exposure to 
acitretin and purpura and related 
conditions 
DARWIN EU 
PRAC 
PSUSA 
EUPAS1000000429 
Impact of risk minimisation measures 
related to the risk of meningioma in 
women using nomegestrol and 
chlormadinone 
DARWIN EU 
PRAC 
N/A 
EUPAS1000000455 
Brand-specific influenza vaccine 
effectiveness in the Nordic countries 
Funded 
(FWC) 
VMP 
N/A 
EUPAS1000000481 
Drug Utilization of salbutamol products 
for inhalation and therapeutic 
alternative inhalation products 
DARWIN EU 
MSSG 
N/A 
EUPAS1000000403 
Prescription trends of ketamine and 
esketamine 
DARWIN EU 
Other 
N/A 
EUPAS1000000436 
Prevalence of hypertrophic 
cardiomyopathy (HCM) and obstructive 
hypertrophic cardiomyopathy (oHCM) 
in six European countries 
DARWIN EU 
CHMP 
MAA 
EUPAS1000000430 
Use of antiretroviral therapies in 
paediatric patients 
DARWIN EU 
PDCO 
PIP 
 
EUPAS1000000545 
Drug utilisation and patient 
characterisation of statin usage 
 
In-house 
EMA internal 
 
N/A 
EUPAS1000000764 
Monitoring prescription of essential 
medicines administered in ICU 
DARWIN EU 
MSSG 
N/A 
EUPAS1000000534

## Page 29 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

28 
 
Topic 
Pathway  
Study 
Requester 
Procedure 
HMA/EMA 
Catalogue 
identifier 
Eye disorders in women with breast 
cancer treated with anastrozole, 
letrozole or tamoxifen 
DARWIN EU 
CMDh/NCA 
PSUSA 
EUPAS1000000599 
Monitoring prescription of medicines 
for public health emergencies at risk of 
shortages 
DARWIN EU 
MSSG 
N/A 
EUPAS1000000473 
Coverage of meningococcal vaccines by 
the target population in Europe 
DARWIN EU 
PRAC 
PSUSA 
EUPAS1000000675 
Characterisation of acute renal 
outcomes and diabetic complications 
among patients with concomitant use 
of metformin and iodinated contrast 
agents 
DARWIN EU 
PRAC 
PSUSA 
EUPAS1000000662 
Incidence, period prevalence, and 
characterisation of individuals with 
paediatric pulmonary arterial 
hypertension 
DARWIN EU 
PDCO 
Not linked to 
an ongoing 
procedure 
EUPAS1000000716 
RR1 Drug Utilisation Study of 
prescription opioids 
DARWIN EU 
PRAC 
PSUSA 
EUPAS1000000479 
Feasibility of studies on early (pre-
symptomatic) stages of type 1 diabetes 
in DARWIN EU network 
DARWIN EU 
EMA internal 
MAA 
EUPAS1000000756 
Proof-of-concept: Preparedness for 
annual seasonal influenza vaccine 
effectiveness studies - Vaccine 
coverage and incidence of influenza-
related outcomes 
DARWIN EU 
VMP 
Other 
EUPAS1000000803 
Clozapine and the incidence of 
agranulocytosis over time 
DARWIN EU 
PRAC 
Signal 
EUPAS1000000549 
Prevalence of selected cancers 
DARWIN EU 
COMP 
Other 
EUPAS1000000715 
Paracetamol prescribing and 
paracetamol overdose in Europe: a 
descriptive analysis of trends and 
patient characteristics 
DARWIN EU 
PRAC 
N/A 
EUPAS1000000584 
DUS of Antibiotics of the WHO Access 
classification of antibiotics for 
evaluation and monitoring of use 
DARWIN EU 
ECDC 
Not linked to 
an ongoing 
procedure 
 
EUPAS1000000663 
DUS of Antibiotics of the WHO Reserve 
classification of antibiotics for 
evaluation and monitoring of use 
DARWIN EU 
ECDC 
Not linked to 
an ongoing 
procedure 
EUPAS1000000664

## Page 30 (Section: 4th RWD study report - Feb 2025 to Feb 2026 FINAL.pdf)

European Medicines Agency
Domenico Scarlattilaan 6 
1083 HS Amsterdam 
The Netherlands
Telephone +31 (0)88 781 6000   
Send a question www.ema.europa.eu/contact
www.ema.europa.eu 
Real-world evidence framework to support EU regulatory decision-
making: 4th report on the experience gained with regulator-led studies from 
February 2025  to February 2026
EMA/66577/2026
© European Medicines Agency, 2026.
Reproduction is authorised provided the source is acknowledged.
