# Ongoing Implementation and Prospective Validation of Artificial Intelligence/Machine Learning Tools at an African Drug Discovery Center

- **Authors:** Jason Hlozek, Kelly Chibale, John G Woodland
- **Issuer:** ACS medicinal chemistry letters
- **Type:** Scientific article
- **Published:** 2024-06-21
- **Language:** en
- **DOI:** 10.1021/acsmedchemlett.4c00243
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39015279/
- **Licence:** CC-BY

## Section: Abstract

AbstractArtificial intelligence (AI) and machine learning (ML) are anticipated to accelerate drug discovery programs. Following our development of an end-to-end virtual screening cascade at the University of Cape Town (UCT) Holistic Drug Discovery and Development (H3D) Center, we report the ongoing implementation of open-source AI/ML tools for use in resource-constrained settings.

## Section: Text

Developing novel medicines is a lengthy and challenging process. Candidate molecules need to advance through the various stages of the drug discovery pipeline, from hit discovery and medicinal chemistry optimization to clinical trials and ultimately (if successful) regulatory approval. During the early stages of this process, the physicochemical and biological properties of a chemical compound need to be optimized to discover a potential treatment that is both safe and efficacious. However, high attrition rates at all stages of the drug discovery value chain result in lengthy timelines and exorbitant costs–with current estimates of more than 10 years and over $1 billion, respectively.1 This significant investment–without the guarantee of success–is often prohibitive for drug discovery research for the treatment of infectious diseases that disproportionately affect populations in low- and middle-income countries (LMICs).

With the advent of the fourth industrial revolution and advances in artificial intelligence (AI) and machine learning (ML) technologies, much hope has been placed by the scientific community in data science tools to reduce attrition rates and accelerate drug discovery programs.2 These tools could offer especial value to resource-constrained settings such as those in LMICs. One such example is the University of Cape Town (UCT) Holistic Drug Discovery and Development (H3D) Center,3 which initiated the adoption of AI/ML tools in its research programs in 2021 through a collaboration with the Ersilia Open Source Initiative,4 a technology nonprofit that focuses on the dissemination of data science tools in low-resource settings.

This productive collaboration yielded the development of the ZairaChem pipeline, an automated AI/ML model training tool which produces state-of-the-art QSAR/QSPR models across a variety of chemical and biological assays. This pipeline implementation was intentionally selected as a sustainable way to facilitate the ongoing development of predictive AI/ML models for user-specific regions of chemical space while automating the often-laborious trial-and-error process of model optimization. This approach allows for new models to be trained when additional experimental assays are brought online or are identified as critical for driving a project. In addition, existing AI/ML models can easily be retrained to benefit from new experimental data whereas static AI/ML models would, on the other hand, quickly become outdated.

The development of ZairaChem and the resulting implementation at H3D, which included both retrospective and prospective validation as well as benchmarking against external data sets, was subsequently shared with the broader scientific community.5 In this Viewpoint, we report further prospective validation over the 2023 period and discuss the practical aspects of the ongoing implementation of these AI/ML models, which could serve as an example and inspiration for others at nascent drug discovery centers worldwide and particularly in LMICs.

## Section: Model Implementation and Prospective Validation at the H3D Center

The original set of AI/ML models was selected to predict the experimental outcome of key assays that are frequently used for decision making in screening cascades for drug discovery programs targeting Plasmodium falciparum and Mycobacterium tuberculosis, the causative agents of malaria and tuberculosis (TB), respectively. Typically, medicinal chemists design dozens of potential compounds but have limited resources for chemical synthesis; hence, the suite of models trained through ZairaChem was assembled into a virtual screening cascade to facilitate their use by medicinal chemists to prioritize those compounds for synthesis that are more likely to possess desirable druglike properties.

Our virtual screening cascade is intended to be used in conjunction with existing software to generate complementary data points to facilitate decision-making. Considering there is no substantial limit on the number of compounds that can be run through the cascade, chemists are encouraged to “think big” and examine much longer lists of compounds than they might otherwise propose, allowing them to cast the net more widely and so interrogate a broader chemical space. Furthermore, as many of these models have been trained on in-house data for malaria and TB programs, they are potentially more relevant to other researchers in LMICs than more general models available online, such as the MAIP webtool.6

Our models undergo biannual retraining to continuously incorporate the most recent in-house data to maximize model applicability for current research programs. Both sets of models in 2023, trained on H3D’s in-house data up to February and June of that year, respectively, showed good prospective performance for experimental data generated over the following months. In particular, the whole-cell pathogen activity and aqueous solubility models, with the largest volume of training data, showed consistently high performance metrics, with an area under the receiver operating characteristic (AUROC) curve of between 0.77 and 0.89 (Figure 1). The microsomal intrinsic clearance (CLint) models dropped in performance in the second half of 2023 due to a large batch of compounds from two chemical series that are poorly represented in the training set, indicating the need for model retraining to improve performance in that particular chemical space.

Prospective model performance for the virtual screening cascade AI/ML models at H3D in 2023 which showed excellent agreement of the model predictions with experimental data. ROC curves are plotted for the prospective data generated in the months following the training of models on in-house data up to February 2023 (orange) and June 2023 (blue), respectively.

## Section: Development of New Models

Since the adoption of these AI/ML models by drug discovery teams at the H3D Center, additional data sets and areas of need have been identified for model development (Figure 2). These include predictions for the inhibition of the P. vivax phosphatidylinositol 4-kinase beta (PvPI4Kβ) enzyme, the P. falciparum cyclic GMP-dependent protein kinase (PfPKG), and the inhibition of the formation of β-hematin (the synthetic equivalent of malaria pigment), which represent three important drug targets in antimalarial drug discovery research. These ZairaChem models show excellent predictive performance with AUROC scores above 0.89 (data not shown) likely owing, in part, to the focused nature of the prediction task without the presence of confounding factors in whole-cell assays such as permeability or the presence of transport proteins. In addition, a second model to predict activity against the human ether-á-go-go-related-gene (hERG) ion channel, an important indicator of cardiotoxicity, has been developed from the hERGCentral database7 to expand the chemical space of the training set.

Not only can new models be developed for the early hit-to-lead phase of existing projects to prioritize compounds for synthesis, but these tools can also be used to screen large compound libraries to discover new chemical matter as starting points for drug discovery projects. For this purpose, we have pursued the development of more general activity prediction models that can facilitate virtual screening for new chemical hits against P. falciparum and A. baumannii, the latter being a member of the ESKAPE pathogens with increasing reports of antimicrobial resistance (AMR) and a bacterium of particular importance at the H3D Center. These models have been trained on large open-access data sets (for example, a curated set of 35 000 compounds from ChEMBL and CO-ADD),8,9 exemplifying the versatility of the ZairaChem tool to produce models for a variety of prediction tasks.

Current models comprising the H3D virtual screening cascade (top) in which newly developed models are emphasized in blue. Illustration of the typical workflow (bottom) for the development of new models to be made available for screening by experimentalists.

## Section: Impediments to the Adoption of AI/ML Tools

As “wet-lab” experimentalists seldom have formal computer science training, the technical complexity and black-box nature of AI/ML is often intimidating and may impede the adoption of data science tools. Furthermore, the computational field is filled with technical concepts that are common knowledge for data scientists but may be unfamiliar to experimental scientists, which may further hinder implementation of these models. Third, many AI/ML pipelines are solely implemented for Linux-based environments through a command-line terminal. Indeed, although the use of the ZairaChem pipeline requires just the “fit” and “predict” commands in a Linux terminal, tools that lack a graphical user interface (GUI) are perceived as inaccessible to many experimentalists. Therefore, a successful strategy to promote the local adoption of AI/ML tools needed to address both a skills-development component, to familiarize experimentalists with key concepts, and a technical component, making ZairaChem as easily accessible as possible.

## Section: Workflow of AI/ML Implementation

A typical workflow for deploying AI/ML models in a drug discovery project at H3D comprises the following steps:

## Section: Key Learnings from Our Experience at the H3D Center

As a very first step to encourage our scientists to implement these predictive AI/ML tools in their projects, an internal webinar was held to introduce scientists to the models in order to demystify these new tools. Careful explanations were given to describe the potential benefits of the models and to elucidate how they were trained and how to interpret the results. Thereafter, “champion scientists” in each disease area under investigation at the H3D Center helped to promote the tools among project teams and also brought ideas and suggestions back to the development team. Continuous communication through project meetings and training sessions provided a forum in which pertinent AI/ML concepts could be introduced or refreshed. Recurring areas of confusion include:

The use of boxplots to visualize model test-set predictions is particularly helpful in aiding teams to decide on appropriate prediction score thresholds to differentiate classification scores between predicted actives and inactives.

Initially, the process of obtaining model predictions required manual intervention by a data scientist; however, progressing to a GUI-based manner of accessing ZairaChem models has also been an important contributor to lowering the barrier of AI/ML model adoption. Because medicinal chemists at H3D already use the proprietary software package StarDrop to organize project data and because this software package also offers a Python-based plug-in point for AI/ML models, it is currently leveraged for GUI-based, on-demand model predictions. Medicinal chemists and other experimentalists can load a list of compounds and click the checkboxes corresponding to any number of AI/ML models for which they wish to obtain predictions. A custom Python script runs the list of SMILES strings through the corresponding ZairaChem models and returns a list of predictions to be displayed within the standard StarDrop GUI. While far from a sophisticated and flexible model deployment framework, this implementation has been extremely useful in the interim by making the AI/ML models easily accessible within an already-familiar tool.

## Section: Sustainable Capacity Building

An overarching goal of the H3D-Ersilia collaboration is to build data science capacity at an African drug discovery center through the sustainable implementation of AI/ML tools and related skills development. After an initial on-site training period with Ersilia in AI/ML model development, the ongoing implementation of AI/ML models described in this article has been accomplished without the need for ongoing technical support. Rather than static AI/ML assets that will increasingly become out of date and require a trial-and-error approach to train anew, the highly automated ZairaChem tool facilitates continuous development of new models and easy retraining of existing models. Even where data science expertise is available in-house, the automated nature of the pipeline frees the data scientist to pursue other research tasks while still obtaining high-quality models. The pipeline does not require extensive technical expertise nor extensive infrastructure to leverage, which is a crucial factor for resource-constrained research institutions such as many of those in LMICs.

The ZairaChem code is fully open source (https://github.com/ersilia-os/zaira-chem), and the lightweight versions of the virtual screening cascade models are freely available online (https://bit.ly/h3d-app). Taken together, this collaboration represents a landmark success for the transfer of sustainable data science expertise to the nascent African drug discovery domain. H3D and Ersilia aim to continue to build capacity for AI/ML tools at additional centers of African drug discovery research and development by continuing to facilitate data science workshops for African-based researchers and students. In particular, the scientists of the drug discovery cohorts of the Grand Challenges Africa initiative were invited to attend week-long training events hosted by the H3D Foundation and Ersilia, and a session on data science tools is also organized when these scientists conduct on-site visits at the H3D Center. The resources from previous training initiatives are also freely accessible to the scientific community (https://ersilia.gitbook.io/event-fund).

## Section: Future Directions

Following the initial successful deployment of data science tools at H3D, we have begun a concerted effort to improve the usability of the models by increasing the interpretability of model predictions and optimizing models to increase the speed of predictions. We have also begun leveraging the virtual screening cascade models to guide generative AI/ML method algorithms which propose new chemical analogs by searching through chemical space while optimizing for higher model prediction scores.

Recently, the selection of Dr. Kelly Chibale as a Schmidt Futures AI2050 Senior Fellow has funded a project that couples AI/ML predictions to physiologically-based pharmacokinetic (PBPK) modeling with the goal to tailor drug dosages for African patient populations.11 In addition, the project envisages developing open-source AI/ML models and significant capacity building for data science tools in Africa. With this work, we are excitedly moving toward a cloud-based deployment of AI/ML models that will facilitate intuitive and scalable access to data science tools to democratize AI/ML technology for drug discovery in Africa.

## Section: Acknowledgments

The authors would like to thank Miquel Duran-Frigola and Gemma Turon of Ersilia for discussion around the topics presented here and their perceptive comments on this manuscript. K.C. is the Neville Isdell Chair in African-centric Drug Discovery and Development and thanks Neville Isdell for generously funding the Chair.

## Section: Text

The authors declare no competing financial interest.

## Section: Special Issue

Published as part of ACS Medicinal Chemistry Lettersvirtual special issue “Exploring the Use of AI/ML Technologies in Medicinal Chemistry and Drug Discovery”.


---

# Peptide-based drug discovery through artificial intelligence: towards an autonomous design of therapeutic peptides

- **Authors:** Montserrat Goles, Anamaría Daza, Gabriel Cabas-Mora, Lindybeth Sarmiento-Varón, Julieta Sepúlveda-Yañez, Hoda Anvari-Kazemabad, Mehdi D Davari, Roberto Uribe-Paredes, Álvaro Olivera-Nappa, Marcelo A Navarrete, David Medina-Ortiz
- **Issuer:** Briefings in bioinformatics
- **Type:** Scientific article
- **Published:** 2024-05-23
- **Language:** en
- **DOI:** 10.1093/bib/bbae275
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38856172/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractWith their diverse biological activities, peptides are promising candidates for therapeutic applications, showing antimicrobial, antitumour and hormonal signalling capabilities. Despite their advantages, therapeutic peptides face challenges such as short half-life, limited oral bioavailability and susceptibility to plasma degradation. The rise of computational tools and artificial intelligence (AI) in peptide research has spurred the development of advanced methodologies and databases that are pivotal in the exploration of these complex macromolecules. This perspective delves into integrating AI in peptide development, encompassing classifier methods, predictive systems and the avant-garde design facilitated by deep-generative models like generative adversarial networks and variational autoencoders. There are still challenges, such as the need for processing optimization and careful validation of predictive models. This work outlines traditional strategies for machine learning model construction and training techniques and proposes a comprehensive AI-assisted peptide design and validation pipeline. The evolving landscape of peptide design using AI is emphasized, showcasing the practicality of these methods in expediting the development and discovery of novel peptides within the context of peptide-based drug discovery.Keywords: protein engineering, therapeutic peptides, deep learning, large language models, deep generative models, peptide-base drug discovery, artificial intelligence

## Section: Introduction

Engineered peptides exhibit wide-ranging therapeutic effects, such as antimicrobial, antitumour, antithrombotic and immunomodulatory activity [1]. Peptide drugs offer potential advantages over traditional small-molecule drugs, including increased selectivity, affinity, efficacy, safety and reduced toxicity and immunogenicity [2]. However, the brief half-life, limited oral bioavailability and susceptibility to plasma degradation of peptide drugs remain a challenge for their widespread clinical application [3].

The growing availability of numerous peptide sequences and their functions have driven the development of computational tools to store and share peptide information[4]. General and activity-specific databases have been established and are publicly accessible [5, 6]. Besides, artificial intelligence (AI) methods and predictive systems through machine learning (ML) have substantially evolved in recent years, particularly in protein engineering applications [7].

The rapid evolution of AI has marked the beginning of a new era of sophisticated ML algorithms in biomedicine, significantly impacting drug discovery [8]. Integration of ML has taken on a multifaceted dimension, including classifier methods, predictive systems and generative approaches [9].

Classifier methods are crucial for identifying diverse peptide activities, from biological functions to categorical properties [5]. In contrast, predictive models prove their utility by estimating numerical properties, such as binding affinities in protein–peptide interactions, evaluating toxicity and predicting inhibitory activity [10].

Deep generative models (DGMs) have emerged as tools for the design of therapeutic peptides [11]. In particular, generative adversarial networks (GANs), variational autoencoder (VAE) and diffusion models facilitate the generation of novel peptide sequences aimed at specific objectives [9, 12]. However, automated or assisted peptide design still faces challenges, such as the optimization of peptide processing, the establishment of informative representation strategies and the meticulous development and validation of predictive models.

This work describes peptides and their different properties and usabilities for biotechnology and therapeutic applications. It also presents traditional strategies for training ML models. Subsequently, it discusses the potential applications of DGMs as a foundational tool for designing peptides with therapeutic potential. Besides, a comparative analysis of the most common DGMs strategies is addressed. This work also proposes a comprehensive AI-assisted peptide design and validation pipeline. Finally, different challenges are discussed concerning achieving an autonomous therapeutic peptide design supported by AI approaches.

## Section: Peptides and their biotechnology applications

Peptides exhibit unique biochemical and therapeutic attributes and can be synthesized or obtained from natural sources. This section aims to offer a perspective on peptides, exploring their multifaceted biological functions, moonlighting attributes and applications [13, 14].

Biological activities of peptides, moonlight activity and main applications. A. Functional biological activities were grouped into 10 categories, including therapeutic, neurological drug delivery vehicle, sensorial, immunological, molecular binding, propeptide, signal peptide, transit and other activities (colour boxes) with different categories and subcategories. A total of 96 activities considering properties, reported activity and experimental validations have been generated in our previous work [5]. B. Moonlight evaluation of the 10 main activities reported in [5]. Therapeutic peptides are highly related to propeptides, drug delivery vehicles and sensorial peptides. Neurological peptides are also highly related to drug delivery vehicles and molecular binding. In contrast, sensorial peptides have a low relation with immunological peptides. C. Summary of peptide applications, considering industrial, biotechnology and therapeutic applications.

## Section: Peptides and their biotechnology applications › Peptide overview, synthesis process, function biological activities and moonlighting effects

Peptides consist of short chains of amino acids, with a molecular weight ranging from 0.5 to 10 kDa [15], and a length ranging from a couple of amino acids up to 100 [16]. Their role in biological processes is diverse, including functions as structural components, enzymatic inhibitors, hormones, host defence molecules and neurotransmitters [11]. Moreover, peptides can also act as cell surface receptors [17] and play an essential role in drug delivery applications [17, 18].

These macromolecules can acquire secondary structures, commonly forming -helix and sheets structural patterns [19], but also more complex structures [20]. Lasso peptides, for example, have a unique 3D structure where the C-terminus threads through an N-terminal macrolactam ring in a right-handed conformation, which provides stability against chemical, thermal and proteolytic degradation [21].

Peptides can be isolated from natural sources [1], including venoms [22], food products [23] and marine organisms [24]. Alternatively, peptides can be produced using recombinant techniques and chemical synthesis [25, 26].

In the recombinant approach, organisms like E. coli, S. cerevisiae and P. pastoris are used to produce heterologous peptides using the host cell protein production machinery [14]. In contrast, chemical procedures allow synthesis automation for large-scale industrial production [27]. Common chemical techniques are solid-phase peptide synthesis [11] and liquid-phase peptide synthesis [28].

Peptides can exhibit different biological activities with multifaceted properties. Figure 1A summarizes the main biological activities reported. As therapeutic properties, peptides play a role as antimicrobial, antitoxin and anticancer [2]. In the cosmetic industry, peptides can be used for wound healing and anti-aging activities. Peptides can also facilitate the molecular binding of proteins, DNA and RALF molecules. Peptides with immunological, neurological, signalling, drug delivery, propeptide, taste and cell–cell communication properties have been reported [5, 29–31]. Finally, peptides can also exhibit toxic effects, with reports of cytotoxic, allergen, endotoxin and neurotoxin characteristics [32–34].

Evolution and adaptability have moulded peptides into exhibiting two or more concurrent biological activities [35]. This unique and promiscuous attribute is called moonlighting activity. Unlike conventional peptides or proteins with defined functions, moonlighting peptides can acquire different activities in various cellular contexts or environments [35, 36].

Figure 1B describes the moonlighting for the primary biological activities reported in the Peptipedia database [5]. Therapeutic peptides have been demonstrated to present toxic properties. Cell–cell communication peptides also play therapeutic and signalling roles. The moonlighting effect was also analyzed for specific therapeutic peptides, including antimicrobial, metabolic, and anti-cancer. (See section S1 of Supplementary Material for more details). Moreover, specific antimicrobial peptides (AMPs) with antifungal, antibacterial and antiviral biological activities exhibit moonlighting properties. The moonlighting effect is also a property for antibacterial peptides, existing peptides with anti-gram (+) and anti-gram (-) activity (See section S1 of Supplementary Material for more details).

Leveraging moonlighting peptides as therapeutics presents potential advantages over traditional small-molecule drugs. The ability to combine multiple therapeutic functions into a single drug could alleviate the treatment burden for patients. Furthermore, such peptides could simultaneously target various disease-related pathways [35]. However, their multifunctional nature may also give rise to specificity issues, and their design complexity is compounded by the necessity to understand these unique structure–function relationships.

Biological activities of peptides, moonlight activity and main applications. A. Functional biological activities were grouped into 10 categories, including therapeutic, neurological drug delivery vehicle, sensorial, immunological, molecular binding, propeptide, signal peptide, transit and other activities (colour boxes) with different categories and subcategories. A total of 96 activities considering properties, reported activity and experimental validations have been generated in our previous work [5]. B. Moonlight evaluation of the 10 main activities reported in [5]. Therapeutic peptides are highly related to propeptides, drug delivery vehicles and sensorial peptides. Neurological peptides are also highly related to drug delivery vehicles and molecular binding. In contrast, sensorial peptides have a low relation with immunological peptides. C. Summary of peptide applications, considering industrial, biotechnology and therapeutic applications.

## Section: Peptides and their biotechnology applications › Biotechnology and therapeutic applications of peptides

Peptides exhibit many natural functions and offer significant potential for diverse applications. Peptide synthesis with non-canonical or artificial residues further expands their utility (e.g. by modifying residues in cationic AMPs to enhance proteolysis resistance) [37]. Figure 1C provides an overview of the primary applications of peptides in industry, biotechnology and therapeutics.

In the industrial sector, peptides have been applied as biosensors and used explicitly for pollutant and pathogen detection [38]. Peptides have also been employed in the food industry as food preservatives, hydrogelators, foam stabilizers and emulsifying agents [39]. For biotechnology applications, peptides have been used for plant protection and as immune inducers, playing pivotal roles as insecticidal and herbicides [40–42].

In therapeutic applications, peptides have generated antimicrobial drugs, including antifungal, antiviral and antibacterial [43]. Examples of therapeutic peptides are (i) WK2, designed to combat multi-drug resistant Salmonella [44], (ii) Teicoplanin a semisynthetic peptide for treating severe infections [45] and (iii) insulin and semaglutide for diabetes treatment [46].

Another relevant type of peptide for therapeutic applications are the cell-penetrating peptides (CPPs). These peptides can penetrate cell membranes, reach intracellular targets and facilitate drug delivery [47]. For example, the cyclic and amphipathic peptide has been used for the intracellular delivery of small interfering RNA and the enhancement of curcumin uptake [48].

Other peptides have the potential to improve neurodegenerative disorders like Alzheimer’s and Parkinson’s disease [49]. The P110 peptide inhibits Dynamin-related protein 1 (Drp1), a crucial regulator of mitochondrial fission, offering stable preservation of dopaminergic neurons in Parkinson’s disease [50]. Under stress, activated Drp1 translocates to mitochondria, leading to excessive mitochondrial fission and dopaminergic neuronal death.

## Section: ML strategies to develop predictive models for peptides

In recent years, there has been a substantial increase in the number of peptides documented in the literature [5]. This sequence abundance has, in turn, stimulated interest in applying computational biology techniques to analyse peptide sequences, predict biological activities, calculate physicochemical properties and assist in peptide design [51, 52]. However, applying AI and ML methodologies presents various challenges, from data collection and processing to predictive model validation to selecting an appropriate training strategy. This section reviews the classical approaches of data-driven methods for building predictive models and discusses the ML-based models for peptide tasks.

The main learning type process, the different applications to solve biotechnology and a data-driven pipeline to build predictive models supported by ML strategies. A The four main learning strategies used in biotechnology: (i) Supervised learning is used to build predictive models. (ii) Pattern recognition or unsupervised learning is applied to identify behaviours in an unlabelled dataset. (iii) Reinforcement learning is applied to update predictive models supported by new experimental evidence or knowledge. (iv) Generative learning is applied to create or design new examples and is employed as a landscape navigation strategy. B A classic data-driven approach to generate and use predictive models employing protein sequences as input to train the predictive model. First, a dataset is built by collecting information from databases, repositories, public resources or experimental reports. Once the dataset is built, numerical representation strategies are applied to code the protein sequences, generating an interpretable dataset for ML algorithms. The coded dataset is the input used to train a predictive model by applying supervised learning algorithms. Then, the predictive model’s performance is evaluated, and the model is validated through new examples or simulated datasets. Finally, the validated model explores the latent space and rebuilds the mutational landscape.

## Section: ML strategies to develop predictive models for peptides › ML definitions and main characteristics

ML is a sub-field of AI focused on algorithms and statistical models based on the idea that computers can analyse and learn from data patterns and use that knowledge to make predictions, classify objects or solve various problems [53].

Four learning types are currently applied to solve computational biology problems: (i) supervised learning, (ii) non-supervised learning, (iii) reinforcement learning and (iv) generative learning [54] (See Fig. 2A and section S2 of Supplementary Materials for more details). In addition to the different learning types, two main focuses have been implemented for developing models using ML strategies, classic ML approaches and deep learning (DL) architectures [55].

DL approaches have been efficient for image recognition, natural language processing and speech recognition [56]. In biotechnology and bioinformatics, DL has allowed the development of predictive models to estimate protein–protein interactions, classification systems for unknown enzymes through recognition of enzyme commission numbers [57] and predictive systems for protein structures such as RoseTTAFold [58] or AlphaFold [59].

The applications of transfer learning approaches by applying foundational trained models to biology context have demonstrated usability to develop efficient predictive models [60]. Moreover, the combination of transfer learning with semi-supervised strategies has facilitated the implementation of predictive models to address the data scarcity in protein engineering and fitness landscapes [61].

The main learning type process, the different applications to solve biotechnology and a data-driven pipeline to build predictive models supported by ML strategies. A The four main learning strategies used in biotechnology: (i) Supervised learning is used to build predictive models. (ii) Pattern recognition or unsupervised learning is applied to identify behaviours in an unlabelled dataset. (iii) Reinforcement learning is applied to update predictive models supported by new experimental evidence or knowledge. (iv) Generative learning is applied to create or design new examples and is employed as a landscape navigation strategy. B A classic data-driven approach to generate and use predictive models employing protein sequences as input to train the predictive model. First, a dataset is built by collecting information from databases, repositories, public resources or experimental reports. Once the dataset is built, numerical representation strategies are applied to code the protein sequences, generating an interpretable dataset for ML algorithms. The coded dataset is the input used to train a predictive model by applying supervised learning algorithms. Then, the predictive model’s performance is evaluated, and the model is validated through new examples or simulated datasets. Finally, the validated model explores the latent space and rebuilds the mutational landscape.

## Section: ML strategies to develop predictive models for peptides › A classic data-driven pipeline to develop predictive models through ML techniques for protein engineering tasks

There are four main steps for developing predictive models for peptides using ML strategies and protein sequences or structures: collecting and processing datasets, numerical representation strategies, training and validating predictive models and evaluating performances using classic metrics. Figure 2B summarizes the standard strategies and schematizes a classic data-driven pipeline.

During the collecting process, different sources could be employed to obtain protein sequences or structures depending on the objective of the predictive model. Usually, generic databases like Peptipedia [5], SATPdb [62] or LAMP2 [63] are used for collecting AMPs. In contrast, specialized databases like quorum sensing signalling peptides [64], anti-angiogenic peptides predictors [65] and bacteriocin peptides [66] are employed for collecting specific information.

Before training predictive models, numerical representation strategies must be applied to process peptide sequences. Current approaches favour the use of learning representations, due to their ability to catch functional and structural information from the context sequence [67, 68]. However, baseline methods like One Hot encoder, feature engineering and physicochemical encoders could also be applied (See section S2 of Supplementary Material for more details).

Finally, for training models, a classic pipeline could be applied [69], including a standard division of the dataset in training and testing partitions, a fold cross-validation technique to prevent overfitting and the application of classic metrics to evaluate and compare the performance of the predictive models (See section S2 of Supplementary Materials for more details).

## Section: ML strategies to develop predictive models for peptides › Current methods, strategies and implemented models for peptide design

Predictive models have been developed to explore and analyse peptide sequences, with a shared focus on tasks such as AMP classification, including ensemble learning process [70] and DL architectures [71] to train the classification models. Besides, antiviral classification systems applying Random Forest, support vector machine and DL methods have been successfully implemented [72–75].

Classification models for therapeutic applications have been implemented, including anti-inflammatory detection peptides [76], anticancer peptides identification [77] and CPPs recognition [78].

Pharmacological properties for therapeutic peptides have also been the focus of developing predictive models. The prediction of half maximal inhibitory concentration (IC) [79], estimating free radical scavenging activity and chelating properties [80] and half-life in blood [81] have been addressed by applying ML approaches.

These models not only facilitate the exploration of unknown sequences but may also contribute to the design of peptides with desirable properties. Typically, they integrate DGM strategies to advance sequence generation learning supported by computational property classification methods. Nevertheless, despite this progress, a unified pipeline for training predictive models in functional classification tasks remains needed.

## Section: Towards an autonomous peptide-based drug discovery

In this section, we will discuss the integration of ML and AI techniques in developing peptide-based drug discovery systems. First, we will show ML methods to support drug discovery; then, different deep generative strategies will be explained and discussed, evaluating different advantages and disadvantages. Next, traditional protein engineering strategies generated to assist the peptide design will be analysed and compared with generative approaches. Finally, a proposal pipeline to discover therapeutic peptides will be explored.

Classic DL architectures through DGMs employed for peptide design. A An autoencoder is a DL architecture that facilitates encoding the input data into a lower dimensional representation, reconstructing the original input as closely as possible. The autoencoders have two main components: an encoder and a decoder. B VAEs are a specific type of autoencoder that introduces probabilistic elements into the model, enabling it to learn a probabilistic distribution of the data in the latent space. VAEs are particularly effective for generating new, similar data points and are often used in generative modelling tasks. C NLMs, also known as autoregressive models, are a class of AI models that use neural networks to understand and generate human language. These models are designed to capture the complex patterns and relationships within a given language, enabling them to perform tasks such as language understanding, sentiment analysis, machine translation and text generation. D GANs are a class of AI algorithms that generate new, realistic data samples that resemble a given dataset. The main components in a GAN are (i) generator, (ii) discriminator, (iii) adversarial training, (iv) loss function and (v) training process.

A generalizable in silico pipeline to design therapeutic peptides with desirable properties combining ML, DGMs and biological structural validations. A Pipeline to train functional biological classification models, including the classic steps to develop predictive models using ML approaches. B Pipeline to train a binding affinity predictive model using ML algorithms. In this case, it is necessary to represent the protein, the ligand and the complex structure. C. A pipeline to build a generative model for designing therapeutic peptides. The pipeline includes the DGM, the functional classification system, the protein-binding affinity predictive model and bioinformatics approaches to validate the designed peptide sequences.

## Section: Towards an autonomous peptide-based drug discovery › Drug discovery supported by ML methods

Drug discovery is the process by which new candidate drugs are developed [82]. Traditional drug discovery involves (i) target identification, (ii) target validation, (iii) lead compound identification and (iv) lead optimization [83]. This process can often take decades and has a cost that can exceed a billion US dollars per target [84], considering that most drugs do not reach the market [85].

In contrast, drug repurposing is the exploration of new therapeutic applications for existing drugs [86]. Drug repurposing has different advantages, including safety, efficacy and accelerating the clinical assessment [87].

The combination of ML approaches with biomedical datasets can facilitate the identification of novel therapeutic targets, studying molecular characteristics, protein interactions, biological activities and adverse effects [4].

Different predictive models have been implemented to assist drug discovery, including methods like BANDIT, a Bayesian ML approach [88], and DeepDTnet, a DL approach that combines phenotypic, genetic, chemical and cellular network profiles to guide the drug discovery [89].

Alternatively, drug–target interaction predictive models have been developed to evaluate drug candidates. These methods have been based on Random Forest algorithms combined with a graph-based features extraction process [90], deep belief network [91] and long short-term memory (LSTM) architectures combined with protein characteristics and drug molecular substructure fingerprints [92].

ML frameworks can also predict drugs’ adverse effects at diverse stages of the discovery process. Two relevant approaches have been implemented: a deep neural network to assess the probability of adverse drug reactions in novel pharmaceutical compounds [93], and a geometric self-expressive model to help identify side effects during drug clinical trials [94].

In contrast to the current ML methods implemented to assist drug discovery, generative learning strategies have been developed to design de novo molecules or drugs with desirable targets [95]. Methods based on combinations of graph-generative models with Monte Carlo tree search [96] and transformer-decoder architectures to produce de novo smiles [97] have demonstrated the usability of the ML approaches to the discovery of new drugs.

While generators generative learning implemented for drug discovery exemplify the potential of AI models for small molecule design [96, 97], their capability can further extend into the domain of peptide design [98].

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences

DGMs aim to capture the underlying data distribution of a given dataset to generate novel instances that accurately represent the properties of the original data [99, 100]. For peptide design, DGMs can not only generate de novo peptide sequences but also perform learning representation tasks and likelihood learning tasks, where the model can learn to assign a greater probability to protein sequences that acquire desired characteristics [12].

There are multiple steps in the pipeline for peptide design using DGMs. First, the model needs to be trained. To this aim, peptide databases, datasets and repositories are collected and processed. Next, the collected peptide sequences require a numerical representation to provide the models with an interpretable input. Peptide representation can rely on feature descriptors, amino acid coding or embedding representations [98]. Then, the model is trained on the represented data; modelling the distribution of the training set allows us to learn the underlying data distribution and generate novel sequences.

In this section, the most common generative strategies are described, then state-of-the-art-related protein design, generation or discovery is analysed. Besides, a comparative analysis of the different generative approaches is addressed, including the advantages and disadvantages of each one.

Classic DL architectures through DGMs employed for peptide design. A An autoencoder is a DL architecture that facilitates encoding the input data into a lower dimensional representation, reconstructing the original input as closely as possible. The autoencoders have two main components: an encoder and a decoder. B VAEs are a specific type of autoencoder that introduces probabilistic elements into the model, enabling it to learn a probabilistic distribution of the data in the latent space. VAEs are particularly effective for generating new, similar data points and are often used in generative modelling tasks. C NLMs, also known as autoregressive models, are a class of AI models that use neural networks to understand and generate human language. These models are designed to capture the complex patterns and relationships within a given language, enabling them to perform tasks such as language understanding, sentiment analysis, machine translation and text generation. D GANs are a class of AI algorithms that generate new, realistic data samples that resemble a given dataset. The main components in a GAN are (i) generator, (ii) discriminator, (iii) adversarial training, (iv) loss function and (v) training process.

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Variational autoencoders

A VAE is a generative model combining autoencoders and variational inference elements. VAEs are used to learn representations of unsupervised input data and generate new data samples that resemble the training data [12].

Overall, VAEs are powerful generative models capable of learning rich representations of complex data distributions and generating new samples with desirable properties. They have applications in various domains, including image generation, text generation and anomaly detection.

VAE introduces a probabilistic aspect, learning a distribution in the latent space (see Fig. 3A). The most relevant components of a VAE model are (i) an encoder network, (ii) a reparametrization trick, (iii) a latent space, (iv) a decoder network and (v) a loss function [99].

During training, the VAE optimizes the parameters of both the encoder and decoder networks to minimize the combined loss function. This process involves passing input data through the encoder network to obtain latent space representations, sampling from the latent space and then reconstructing the data using the decoder network. The model’s parameters are updated using gradient descent techniques.

Once trained, the VAE can generate new data samples by sampling from the learned latent space distribution and passing the samples through the decoder network. By varying the samples in the latent space, the model can generate diverse and realistic data samples that resemble the training data.

Classic DL architectures through DGMs employed for peptide design. A An autoencoder is a DL architecture that facilitates encoding the input data into a lower dimensional representation, reconstructing the original input as closely as possible. The autoencoders have two main components: an encoder and a decoder. B VAEs are a specific type of autoencoder that introduces probabilistic elements into the model, enabling it to learn a probabilistic distribution of the data in the latent space. VAEs are particularly effective for generating new, similar data points and are often used in generative modelling tasks. C NLMs, also known as autoregressive models, are a class of AI models that use neural networks to understand and generate human language. These models are designed to capture the complex patterns and relationships within a given language, enabling them to perform tasks such as language understanding, sentiment analysis, machine translation and text generation. D GANs are a class of AI algorithms that generate new, realistic data samples that resemble a given dataset. The main components in a GAN are (i) generator, (ii) discriminator, (iii) adversarial training, (iv) loss function and (v) training process.

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Generative adversarial networks

GANs are generative models based on energy-based models (EBMs). Two components are most relevant for a GAN: a generator network and a discriminator network [101] (see Fig. 3B).

The generator is a neural network that takes random noise (often drawn from a simple distribution such as Gaussian) as input and produces data samples as output. Initially, the generator produces random noise, but as training progresses, it learns to generate increasingly realistic samples that resemble the training data [98]. In contrast, the discriminator is another neural network that takes input data samples and predicts whether they are real or fake [98].

The training process of a GAN model is called adversarial training. During the training process, the generator and discriminator are trained simultaneously. The generator aims to produce indistinguishable samples from real data, while the discriminator aims to classify real and generated samples correctly [99]. During training, the generator and discriminator are updated iteratively. The generator creates fake samples and attempts to fool the discriminator, while the discriminator is updated to better distinguish between real and fake samples. This process continues until the generator produces samples that the discriminator is not able to differentiate from real data [101, 102].

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Neural language models

Neural language models (NLMs) use neural networks to comprehend and generate human language. Designed to capture intricate patterns and relationships within a given language, these models are proficient in diverse tasks such as language understanding, sentiment analysis, machine translation and text generation (refer to Fig. 3C) [99]. Key components of NLMs are (i) Neural Network Architecture, (ii) Word Embeddings, (iii) Pre-training and Transfer Learning, (iv) Contextual Understanding, (v) Transformer Models and (vi) Generative Language Models.

NLMs predominantly adopt two main frameworks: recurrent neural networks (RNNs) and attention models. In RNNs, LSTM and gated recurrent units are used to construct autoregressive models. These models effectively capture sequential data by retaining historical information in their hidden states [98].

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Flows-based and EBMs

Flow-based models are generative models that learn the mapping between data samples and their corresponding probability densities. These methods utilize invertible neural networks to establish a bidirectional mapping between inputs and a latent representation. Unlike some generative models that rely on approximate sampling, flow-based models often use exact inference and analytical computations [99] (see Fig. 3D).

Different components are necessary to develop a flow-based model, including (i) the base distribution, (ii) the transformation network, (iii) invertible transformation functions and (iv) an output distribution.

EBMs are a diverse category of ML models characterized by their unique approach to modelling data. EBMs are designed to learn an energy function rather than directly learning a probability density function on the input space [103]. According to this energy function, observed or plausible data states are given low values (referred to as ‘energies’), whereas unobserved or improbable states are given high values [99]. EBMs differ from conventional generative methods because they do not require normalizing probability distributions.

EBMs are more flexible for handling probability distributions, due to integrating the energy function into the learning model [103].

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Diffusion models

Diffusion models are generative models that iteratively apply reversible transformations to a noise process. These models efficiently generate high-quality, diverse samples in various domains, such as images, text and audio [104]. Figure 3E presents a schematic representation of the diffusion model approaches.

The type of model starts with a noise process as the initial input. Then, reversible transformations to the noise process are applied iteratively. Each transformation is designed to gradually change the noise process into a data sample while preserving reversibility [105].

Diffusion models typically incorporate an annealing schedule to control the diffusion rate and ensure stable training. The annealing schedule gradually adjusts the magnitude of the reversible transformations over time, allowing for smoother transitions and better convergence [106].

Diffusion models are trained using maximum likelihood estimation. The training objective is to minimize the negative log-likelihood of the data samples under the diffusion model. This objective encourages the model to learn reversible transformations that can accurately transform the noise process into realistic data samples [105].

Once trained, diffusion models can generate new data samples by running the diffusion process forward from random noise. By varying the random noise inputs, diffusion models can generate diverse, high-quality samples that resemble the training data distribution [104].

## Section: Towards an autonomous peptide-based drug discovery › DGM for the generation of new peptide sequences › Generative approaches applied for peptide design and discovery

Different VAE strategies have been implemented to assist the peptide design or discovery. Methods like PepVAE [107], PepCVAE [108] and GM-Pep [109] have been proposed for AMP design supported by VAE approaches. Two relevant methods for AMP design are proposed in [110] and [111].

[110] used a deep autoencoder to design AMPs, achieving success in 48 days with a 10% hit rate. HydrAMP, a conditional variational autoencoder (cVAE), uncovers a continuous representation of peptides, leveraging controlled creativity [111]. Using HydrAMP, AMPs, including a superior analogue (Hydraganan-1) of Pexiganan, were generated and experimentally tested against E. coli strains [111].

Other examples of peptide design using VAE strategies are target-specific peptide inhibitors [112], peptide inhibitors targeting -catenin [113], peptides with desired bioactivity and membrane permeability properties [114] and peptide–MHC binding [115].

GANs are among the most widely used generative models for the design of peptides [103]. GANDALF (Generative Adversarial Network Drug-tArget Ligand Fructifier) is a deep convolutional GAN-based method that incorporates information about the active atoms of the protein–ligand interaction domain [116]. GANDALF generates novel peptides and predicts their binding affinity to a specific target. Rather than using protein–protein interaction databases, this model is trained on drug–ligand interactions of protein and FDA-approved peptide drugs based on the THP database [117]. It also uses data from PDB for 3D structures, Uniprot for the names of interacting proteins or peptides and CASTp to calculate protein pockets [118, 119]. This model has generated peptides to target cancer-related proteins, including PD-1, PDL-1 and CTLA-4 [116, 120].

Another GAN-based method for designing peptides, specifically bioactive antiviral peptides, is PandoraGAN [121]. It uses LeakGan, a modified GAN used in text generation, to generate peptides that undergo initial validation based on their amino acid composition, net charge, instability index, repeats and patterns.

Methods like AMPGAN v2 [122], AI4AVP [75] and HelixGAN [123] have also been implemented using GAN strategies to assist therapeutic peptide design.

Applying NLM strategies [124] have implemented AMPTrans-LSTM, a deep generative network-based approach designed to rationalize AMPs. Comprising two interconnected submodels: a long- and short-term memory sampler and a transformer-converter, the model demonstrates a success rate ranging between 30% and 50%. It generates new peptide sequences while preserving essential AMP features.

Flows-based models have been implemented focusing more on drug discovery. An example of these models is TagMol [125]. TagMol is a probabilistic end-to-end EBM for target-specific drug design. This approach uses the EBM to evaluate the binding affinity scores between protein–ligand pairs precisely. TagMol demonstrated that it could generate molecules with binding affinity scores similar to real molecules.

Different approaches have been implemented to assist peptide design, focused on diffusion model strategies [98]. Examples of the implemented strategies are AMP-diffusion. This method integrates latent diffusion with protein language models to generate AMPs [126]. Another relevant method for peptide therapeutic peptide design is the combination of structure prediction networks with diffusion generative approaches [127]. Alternatively, methods like Geometric Latent Diffusion [128] and multi-modal contrastive diffusion models [129] have been designed to support the therapeutic peptide design.

## Section: Towards an autonomous peptide-based drug discovery › A simple comparative analysis of the different generative strategies employed for peptide design

The different strategies implemented to design therapeutic peptides have proven successful in their application. However, there are differences in their operation that require attention to identify their advantages and disadvantages.

When formulating strategies based on VAEs, leveraging a latent space informed by distributions facilitates the generation of peptide sequences exhibiting an amino acid distribution similar to those in the training data. A more extensive repertoire of sequences enhances the likelihood of producing successful peptides as it expands the scope of potential explorations. However, a higher volume of feasible peptides does not inherently guarantee acquiring the desired biological activity. Given peptides’ propensity for moonlighting properties, there exists the possibility of uncovering novel biological activities that may not necessarily be advantageous. Consequently, when employing VAE-based design methodologies, incorporating a validator for the peptide sequences generated by the models becomes imperative.

Alternatively, design methodologies based on GANs require training a discriminator component to distinguish between real and fake sequences. While GAN-based approaches often offer advantages over VAE methods, like a validation process for generated sequences, their implementation requires careful consideration of various factors. First, achieving a balanced dataset is crucial; any class imbalance could impede the model’s ability to generalize effectively. Secondly, ensuring accurate differentiation between positive and negative elements, particularly in peptide sequences, demands adopting appropriate representation strategies. Therefore, integrating generative methods with Transformers to leverage pre-trained representation learning models proves beneficial for incorporating decoding techniques and facilitating the discrimination of genuine from spurious sequences. Introducing additional components complicates generative strategies’ training, validation and use.

Methods based on NLMs typically incorporate DL architectures such as RNNs or LSTMs. Training these models relies on natural language processing techniques. Achieving robust generalization with these models is challenging, often necessitating a substantial volume of training examples. Their appeal lies in their ability to analyse context and semantics for model development. Nevertheless, akin to VAE-based approaches, evaluating their efficacy requires integrating a classification model, thus complicating the training process. However, recent studies have reported precision rates exceeding 80% in developing AMPs, underscoring the efficacy and utility of these methods.

Recently, advances in peptide design methodologies have showcased remarkable efficacy, particularly in therapeutic peptide development. Among these methods, diffusion-based strategies have emerged as standout performers compared with approaches like VAE or GAN. Leveraging diffusion models enables efficient and high-fidelity reconstruction of new examples. Additionally, unlike flow-based or NLMs, there appears to be no significant correlation between the complexity of the training architectures and model performance. Notably, recent efforts have integrated generative learning with contrastive learning strategies to enhance performance in trained models.

Finally, while various strategies exist to aid peptide design and significant advances have been made in generative AI, several challenges warrant careful consideration before peptides proceed to experimental testing. These challenges encompass the analysis of toxicological and immunogenic properties, which are critical for ensuring safety and non-desirable effects. Additionally, peptides like bacteriocins often feature post-translational modifications (PTMs), a factor not accounted for in standard peptide generation processes. Assessment of pharmacological and pharmacodynamic attributes, such as half-life and quality measured via IC50, is imperative. Moreover, evaluating potential undesirable activities stemming from peptides’ moonlighting effects is crucial. Lastly, given that most therapeutic peptides act as receptor targets, computational affinity assessment against these receptors could enable the development of efficient filters for experimental peptide testing.

## Section: Towards an autonomous peptide-based drug discovery › Therapeutic peptide discovery through ML and DGMs

Various computational strategies have been used to facilitate the discovery of peptides with therapeutic potential.

These approaches focused on exploring classification systems and reconstructing mutational landscapes to inform rational protein design [130]. Additionally, the advances in structure predictions supported by AlphaFold have generated a new era for peptide-based drug discovery, facilitating the generation or discovery of new therapeutic peptides [131]. Alternatively, methods rooted in DGMs have demonstrated effectiveness in generating or identifying peptides exhibiting antimicrobial and signal peptide activities [110].

However, navigation through a latent space, investigation of diverse conformations and assessment of different functional components tied to the capacity and characteristics of peptides designed using AI remains challenging.

In particular, unique validation techniques and property calculations associated with the activity and quality of the designed peptide are needed.

This section presents a potential pipeline for discovering peptides with therapeutic activity. This pipeline encompasses predictive modelling of peptide properties, tools for predicting interaction affinity and bioinformatics methods that offer in silico validation of generated sequences. Experimental validation can be undertaken based on the specific application.

The proposed pipeline is illustrated in Fig. 4, outlining three key components essential for advancing the discovery of peptides with desirable therapeutic attributes.

The initial component (refer to Fig. 4A) is dedicated to designing and implementing models to classify biological activity. These models specialize in binary or multiclass classification of the biological activities of unknown peptides or those generated by generative systems.

For instance, they categorize peptides as antiviral, antihypertensive, antibacterial or peptides with antiviral activity that recognize viruses within the Retroviridae family and the HIV species. Beyond models for classifying biological activity, evaluation models may be needed to assess functional mechanisms. For example, evaluating the potential to inhibit the integrase enzyme or assessing peptides’ ability to hinder fusion between the GP41 protein and the host in the case of anti-HIV peptides.

Another consideration is a peptide’s capacity for multiple activities, such as forming interactions with proteins, membrane permeability and moonlighting capabilities. Introducing new rules or conditions to the peptides explored via classification systems facilitates the integration of regulatory elements into the design process, constrains navigation within the latent space and fosters guided learning for design systems.

The construction of these models follows the strategies outlined earlier in this work, including using numerical representation methods to validate implemented classification models.

The second component focuses on designing and implementing an affinity prediction system between protein and peptide, which only applies to peptides targeting a protein (See Fig. 4B.

The binding affinity predictive component proposes strategies involving matrix or object representations to characterize the interaction complex and train predictive models through DL architectures, focusing on CNN or GCN methods. By applying such architectures, explainable AI methods can be integrated to support predictions from an interpretative and explanatory point of view.

The integration of XAi approaches will allow an understanding of the relevant zones or patterns that dictate the model’s response, facilitating the design guidance of peptides exhibiting high affinity for the identified protein zones and key residues that encourage a favourable interaction with the target protein.

Finally, the third component is dedicated to the generative method for exploring novel sequences (See Fig. 4C). Techniques such as VAEs or GANs have been previously utilized to navigate the latent space of peptides awaiting exploration.

Initially, only peptides with a specific biological activity of interest are considered input. Nevertheless, there is also potential to incorporate unknown peptides displaying a specific biological activity, such as adding peptides to the dataset with antiviral properties, even in cases where there is no experimentally validated information, especially concerning anti-HIV activity.

Functional classification models are crucial for assimilating these new sequences in such scenarios. The development of this analytical approach encourages dataset expansion, thereby broadening the latent space to uncover novel peptides.

Once the generative models are trained and validated, the next step is to explore and navigate the latent space. To achieve this, optimization methods that rely on heuristic algorithms can be integrated to explore new sequences.

These identified sequences must be validated using biological activity classification methods and, if necessary, methods predicting affinity to target proteins of interest. In this context, validation serves as a set of rules or checkpoints that must be met to propose a peptide as a potential candidate for experimental validation. Additional validations are also required, such as the analysis of physicochemical properties and stability and the estimation of toxicity.

Reinforcement learning-based methods can be incorporated into the generation and validation stages to update the model responses. Incorporating a layer of active learning enhances the model’s performance and improves its generalization. Including experimental validation data further enhances functional classification and prediction models for better guidance when exploring or navigating the latent space.

A generalizable in silico pipeline to design therapeutic peptides with desirable properties combining ML, DGMs and biological structural validations. A Pipeline to train functional biological classification models, including the classic steps to develop predictive models using ML approaches. B Pipeline to train a binding affinity predictive model using ML algorithms. In this case, it is necessary to represent the protein, the ligand and the complex structure. C. A pipeline to build a generative model for designing therapeutic peptides. The pipeline includes the DGM, the functional classification system, the protein-binding affinity predictive model and bioinformatics approaches to validate the designed peptide sequences.

## Section: Challenges and opportunities: perspectives on peptide design in therapeutic applications

The advantages of peptide-based therapeutics include their efficacy, safety, specificity, customizable nature and various synthesis options. Nevertheless, pursuing peptides for medical applications still faces essential challenges despite strides in in silico drug discovery and design.

One of the obstacles to IA-assisted peptide design is the lack of a centralized, comprehensive and curated source of peptide information. As described earlier, there are individual efforts such as LAMP [63] for specific biological activity or PepipediaDB [5] for general purpose. However, accelerated advances will require global collaborative efforts.

Individual and fragmented data availability results in inconsistencies and misclassifications; for example, very different biological activities have been reported for the same peptide. However, a significant challenge is the scarcity of systematized experimental data on the half-life, IC50 and other critical biochemical and biological variables.

A consortium effort to support and maintain a centralized data source and incentives to encourage the deposit of experimental data may overcome this challenge.

Despite the abundance of strategies, techniques and methodologies for developing functional activity classification models and predictive systems for peptides’ physicochemical and thermodynamic properties, many of these approaches are challenging to replicate or access. This poses a significant obstacle not only to share results and methodologies but also to compare strategies effectively.

During the training of biological activity classification systems and the development of predictive systems, a crucial aspect involves the techniques used for the representation and coding of the peptide sequence.

Traditional methods like One-Hot encoding or physicochemical property coding often encounter challenges due to variations in sequence lengths. zero-padding techniques are typically employed to ensure uniformity during model training, introducing noise that increases with significant sequence length differences.

Solutions focusing on feature engineering-based representation offer an alternative, yet challenges persist in identifying relevant variables and needs reduction techniques. Moreover, models developed using these strategies often need to improve, rendering them inefficient for therapeutic peptide design. Recently, representation learning methods leveraging pre-trained models have emerged as a promising solution, promoting superior performance in predictive models. However, their computational overhead can be substantial, particularly when handling large datasets.

The issue extends beyond methodological complexity to include the availability and accessibility of benchmark datasets. Thus, there is a pressing need to enhance replicability and ensure persistent access to benchmark datasets. The development of gold-standard datasets capable of validating various training strategies and facilitating performance comparisons is imperative.

On the other hand, peptide design requires a delicate balance between safety, delivery efficiency, stability and preservation of efficacy and specificity. Minor alterations in the peptide sequence can significantly impact binding affinity and susceptibility to degradation.

The moonlighting property of peptides adds another layer of complexity. That can, however, be exploited to achieve a combination of binding properties, transport capacity, mobility and interactions at various molecular levels. Current technical advances, such as implementing deep generative methods to generate new sequences and multi-task modelling, may overcome this challenge.

Alternatively, hierarchical predictive systems or rule-decision classification systems might be implemented for numerical models predicting the desired properties such as IC50, half-life, toxicity, etc.

Peptides, being proteins, are susceptible to PTMs. Unfortunately, these modifications are often overlooked during modelling, creating a gap and introducing uncertainty in peptide design. Notably, bacteriocin peptides, utilized as antimicrobials to combat antibiotic resistance, frequently exhibit such modifications, demonstrating the need to incorporate PTMs predictive models into the pipeline of therapeutic peptide design (See more details in section S3 of Supplementary Material).

Lastly, provided that a comprehensive curated source of peptide information to train potent models is generated, a continuous update and feedback with experimental data will be required. Reinforcement learning will enable the continuous update of the model, which in turn will increase performance and generalization capabilities.

Despite these challenges, automated peptide generation has the potential to produce sequences with desired characteristics, such as enzymatic degradation resistance and specificity. Integrating generative methods, predictive systems and bioinformatics tools provides invaluable support for exploring peptides, uncovering new sequences or peptides with therapeutic activities, and synergizing with traditional methods like directed evolution and rational design. Integrating these tools will accelerate the discovery of novel peptides to complement conventional therapeutic arsenals.

## Section: Author Biographies

Montserrat Goles is a Master's student in Departamento de Ingeniería Química, Biotecnología y Materiales, Universidad de Chile. Her research interests include bioinformatics, machine learning strategies, and computational biology.

## Section: Author Biographies

Anamaría Daza is an young researcher at Centre for Biotechnology and Bioengineering, CeBiB, Universidad de Chile. Her research interests include cell culture, cell and gene therapy, heterologous protein expression, characterisation and purification, and extremophile enzymes for industrial applications.

## Section: Author Biographies

Gabriel Cabas-Mora is an Assistant researcher at Departamento de Ingeniería en Computación, Universidad de Magallanes. His main research interest is machine learning applied to protein engineering and molecular biology.

## Section: Author Biographies

Lindybeth Sarmiento-Varón is a Post-doctoral researcher at Centro Asistencial de Docencia e Investigación (CADI), Universidad de Magallanes. Her research interests include the immune system's interactions post-infection and the development of biomarkers.

## Section: Author Biographies

Julieta Sepúlveda-Yañez is a researcher at Centro Asistencial de Docencia e Investigación, CADI, Universidad de Magallanes. She has experience in molecular biology and bioinformatics and specialises in studying mutagenic mechanisms in B cells.

## Section: Author Biographies

Hoda Anvari-Kazemabad holds a master's degree in Software System Engineering from RWTH Aachen University. Her research interests encompass explainable AI (XAI) in protein engineering and the autonomous design of therapeutic peptides.

## Section: Author Biographies

Mehdi D. Davari leads the Computational Chemistry Group at the Leibniz Institute of Plant Biochemistry in Halle, Germany. His research advances protein and enzyme design by unravelling the complex relationships between protein sequences, structures, and dynamics. It functions through computational techniques, including multiscale simulations and artificial intelligence.

## Section: Author Biographies

Roberto Uribe-Paredes is an Associated Professor at Departamento de Ingeniería en Computación, Universidad de Magallanes. His research interests include Information Retrieval, High-Performance Computing, bioinformatics, and genomic analysis.

## Section: Author Biographies

Álvaro Olivera-Nappa is an Full researcher at Centre for Biotechnology and Bioengineering, CeBiB, Universidad de Chile. His research interests include protein engineering and computational biology.

## Section: Author Biographies

Marcelo A. Navarrete is a researcher and group leader at Centro Asistencial de Docencia e Investigación, CADI, Universidad de Magallanes. His research interests include computational immunology and oncogenomics in lymphoid malignancies.

## Section: Author Biographies

David Medina-Ortiz is an Assistant Professor at Departamento de Ingeniería en Computación, Universidad de Magallanes. His research interests include machine learning algorithms, deep learning architectures, and de novo protein design.

## Section: Contributor Information

Montserrat Goles, Departamento de Ingeniería en Computación, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile; Departamento de Ingeniería Química, Biotecnología y Materiales, Universidad de Chile, Beauchef 851, 8370456, Santiago, Chile.

Anamaría Daza, Centre for Biotechnology and Bioengineering, CeBiB, Universidad de Chile, Beauchef 851, 8370456, Santiago, Chile.

Gabriel Cabas-Mora, Departamento de Ingeniería en Computación, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile.

Lindybeth Sarmiento-Varón, Centro Asistencial de Docencia e Investigación, CADI, Universidad de Magallanes, Av. Los Flamencos 01364, 6210005, Punta Arenas, Chile.

Julieta Sepúlveda-Yañez, Facultad de Ciencias de la Salud, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile.

Hoda Anvari-Kazemabad, Departamento de Ingeniería en Computación, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile.

Mehdi D Davari, Department of Bioorganic Chemistry, Leibniz Institute of Plant Biochemistry, Weinberg 3, 06120, Halle, Germany.

Roberto Uribe-Paredes, Departamento de Ingeniería en Computación, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile.

Álvaro Olivera-Nappa, Centre for Biotechnology and Bioengineering, CeBiB, Universidad de Chile, Beauchef 851, 8370456, Santiago, Chile.

Marcelo A Navarrete, Centro Asistencial de Docencia e Investigación, CADI, Universidad de Magallanes, Av. Los Flamencos 01364, 6210005, Punta Arenas, Chile; Escuela de Medicina, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile.

David Medina-Ortiz, Departamento de Ingeniería en Computación, Universidad de Magallanes, Av. Pdte. Manuel Bulnes 01855, 6210427, Punta Arenas, Chile; Centre for Biotechnology and Bioengineering, CeBiB, Universidad de Chile, Beauchef 851, 8370456, Santiago, Chile.

## Section: Funding

D.M.-O. acknowledges ANID for the project ‘SUBVENCIÓN A INSTALACIÓN EN LA ACADEMIA CONVOCATORIA AÑO 2022’, Folio 85220004. D.M.-O., A.D. and A.O.-N. gratefully acknowledge support from the Centre for Biotechnology and Bioengineering—CeBiB (PIA project FB0001, Conicyt, Chile). A.D. gratefully acknowledges support for the Fondecyt project 11230208. M.A.N. acknowledges ANID for grants Anillo ATE220016, M.A.N and R.U.-P acknowledge support for the Fondecyt 1230298. M.D.D. acknowledges funding by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation)—within the Priority Program Molecular Machine Learning SPP2363 (Project Number 497207454).

## Section: Author contributions statement

M.G., M.A.N., A.O.-N. and D.M.-O.: conceptualization. D.M.-O., M.A.N. and A.O.-N.: validation. M.G., M.A.N., A.D., H.A.-K., M.D.D., G.C.-M., L.S.-V. and J.S.-Y.: investigation. M.G., A.D., M.D.D., H.A.-K., M.A.N. and D.M.-O.: writing, review and editing. A.O.-N., M.A.N., R.U.P. and D.M.-O.: supervision and funding resources. A.O.-N., M.A.N. and D.M.-O.: project administration.

## Section: Data availability

No new datasets were generated in this work.

## Section: Associated Data › Data Availability Statement

No new datasets were generated in this work.


---

# PharmaBench: Enhancing ADMET benchmarks with large language models

- **Authors:** Zhangming Niu, Xianglu Xiao, Wenfan Wu, Qiwei Cai, Yinghui Jiang, Wangzhen Jin, Minhao Wang, Guojian Yang, Lingkang Kong, Xurui Jin, Guang Yang, Hongming Chen
- **Issuer:** Scientific data
- **Type:** Scientific article
- **Published:** 2024-09-10
- **Language:** en
- **DOI:** 10.1038/s41597-024-03793-0
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39256394/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractAccurately predicting ADMET (Absorption, Distribution, Metabolism, Excretion, and Toxicity) properties early in drug development is essential for selecting compounds with optimal pharmacokinetics and minimal toxicity. Existing ADMET-related benchmark sets are limited in utility due to their small dataset sizes and the lack of representation of compounds used in drug discovery projects. These shortcomings hinder their application in model building for drug discovery. To address this issue, we propose a multi-agent data mining system based on Large Language Models that effectively identifies experimental conditions within 14,401 bioassays. This approach facilitates merging entries from different sources, culminating in the creation of PharmaBench. Additionally, we have developed a data processing workflow to integrate data from various sources, resulting in 156,618 raw entries. Through this workflow, we constructed PharmaBench, a comprehensive benchmark set for ADMET properties, which comprises eleven ADMET datasets and 52,482 entries. This benchmark set is designed to serve as an open-source dataset for the development of AI models relevant to drug discovery projects.Subject terms: Computational chemistry, Cheminformatics

## Section: Background & Summary

Optimization of ADMET (Absorption, Distribution, Metabolism, Excretion, and Toxicity) properties plays a pivotal role in drug discovery. These pharmacokinetic properties directly influence a drug’s efficacy, safety, and ultimately clinical success. Early assessment and optimization of ADMET properties are essential for mitigating the risk of late-stage failures and for the successful development of new therapeutic agents1.

The development of computational approaches provides a fast and cost-effective means for drug discovery, allowing researchers to focus on candidates with better ADMET potential and reduce labor-intensive and time-consuming wet-lab experiments2–4. One of the key factors contributing to the success of computational approaches in drug discovery is the decent volume of compound-related biomedical data5. The number of bioassays is increasing each year, and many of their screening results are publicly accessible in databases such as ChEMBL6, PubChem7, and BindingDB8 etc.

Manual curation of ADMET data based on public data sources has been reported and some of them have been widely used as benchmark datasets for model evaluation. Wu et al.9, who constructed a large-scale benchmark for molecular machine learning named MoleculeNet, included 17 datasets and more than 700,000 compounds covering categories of physical chemistry and physiology related to ADMET experiments. Huang et al.10 published the Therapeutics Data Commons, which includes 28 ADMET-related datasets with over 100,000 entries by integrating multiple curated datasets from previous work. For specific ADMET experiment, Meng et al.11 present B3DB, which includes 1,058 compounds containing log BB values and 7,807 compounds with classification labels for the blood-brain barrier as one of the distribution properties. Meng et al.12 collected seven aqueous solubility datasets and presented a dataset curation workflow to establish solubility datasets as one of the physicochemical properties.

However, serious concerns about these benchmark datasets still exist. Firstly, most of these benchmarks include only a small fraction of the publicly available bioassay data. For instance, the ESOL dataset13 within MoleculeNet provides water solubility data for 1,128 compounds, while the PubChem7 database contains more than 14,000 relevant entries. Secondly, the entries in these benchmarks differ substantially from those in the industrial drug discovery pipeline. For example, the mean molecular weight of compounds in the ESOL dataset is only 203.9 Dalton, whereas compounds typically within the drug discovery projects have molecular weights ranging from 300 to 800 Dalton14.

These limitations of compiled open-source benchmark datasets are primarily due to the high complexity of data annotation for biological and chemical experimental records. Frequently, experimental results for identical compounds can vary significantly under different conditions, even within the same type of experiment15. For example, aqueous solubility can be influenced by various factors, such as different types of buffers, pH level, and experimental procedure. Thus, the same compound might be annotated with different solubility values depending on those experimental conditions16. This sort of variability poses a big challenge in the fusion of experimental results.

Recently developed Large Language Models (LLMs) like ChatGPT17, PubMedBERT18, and BioBERT19 represent a novel approach of effectively extracting data from a large body of text, therefore a potential method for addressing data curation challenges. Some of these LLMs demonstrate state-of-the-art performance through one-shot or few-shot learning as a form of multi-task learning17,20,21. Compared to supervised methods or models requiring thousands of data for fine-tuning, this approach allows us to develop condition extraction models more efficiently with only a few examples.

In the current study, we leveraged these LLMs as a core engine to extract experimental conditions from assay descriptions within biomedical databases, and an automated data processing framework was established for processing them for facilitating compilation of ADMET benchmark datasets as shown in Fig. 1. We implemented the pipeline to process bioassay data from the ChEMBL database and extract the experimental conditions missing from the table descriptions. These data, along with some other public datasets, were standardized and filtered to create PharmaBench22.

Eventually, PharmaBench22, a data package including eleven ADMET properties, was curated and provided to cheminformatics community serving as a benchmark set for ADMET predictive model evaluation. These properties are recognized as key factors in real-world drug development efforts, and both the size and diversity of the data are significantly greater than those of previous datasets. We also included multiple validation steps to confirm the data quality, molecular properties, and modeling capabilities of PharmaBench22.

Data processing workflow for building PharmaBench: From left to right, the multi-agent LLM system extracts experimental conditions from the ChEMBL database, combines other data sources and standardizes the data, filters various data types, and validates them through repeated tests, property distribution, and AI modeling.

## Section: Methods

The Methods section provides a detailed overview of the data processing workflow used in constructing PharmaBench22, as depicted in Fig. 1. The Data Collection subsection outlines the data sources employed to build PharmaBench22. It includes a comprehensive description of the multi-agent LLM system for extracting experimental conditions from assay descriptions, detailed in the Data Mining subsection. Following the identification of experimental conditions in the Data Mining stage, we merge experimental results from various sources and standardize and filter the data based on drug-likeness, experimental values, and conditions, as summarized in the Data Standardization and Filtering section. Finally, we post-process the datasets by removing duplicate test results and dividing the dataset based on Random and Scaffold splitting methods for AI modeling purposes.

We establish a final benchmark set that comprises experimental results in consistent units and under standardized experimental conditions. In addition, the data processing workflow described in the Methods section can eliminate inconsistent or even contradictory experimental results for the same compounds, enabling other researchers to effectively construct datasets from public data sources. For code reproduction, all data processing tasks were conducted within a Python 3.12.2 virtual environment, established using Conda on an OSX-64 platform. This environment included pandas 2.2.1, NumPy 1.26.4, Matplotlib 3.8.3, rdkit 2023.9.5, scikit-learn 1.4.1.post1, scipy 1.12.0, seaborn 0.13.2, and openai 1.12.0. A detailed description of the environment requirements can be found on GitHub at https://github.com/mindrank-ai/PharmaBench.

Summary of data sources for PharmaBench, from left to right: the broad ADMET category, property name, number of ChEMBL entries and bioassays, number of other entries, and a summary of the sources with references.

Table of Experimental Conditions and Filters Across Datasets.

Sample Prompt for LLM Interaction: Illustration of a Typical User Query Input, Including Instructions and Example Parts.

Overview of the Multi-Agent LLM Data Mining Workflow. This figure presents a summary of the multi-agent LLM data mining workflow, which includes three key components: the Keyword Agent, responsible for identifying experimental conditions; the Example Agent, tasked with generating examples; and the Data Mining Agent, designed to extract experimental conditions from assay descriptions.

Sample Prompt for the Keyword Extraction Agent.

Sample Prompt for the Example Forming Agent.

Summary of Datasets in PharmaBench: ‘Property Name’ refers to the name of the dataset.

## Section: Methods › Data collection

Our data primarily originated from the ChEMBL database, a manually curated collection of SAR (Structure-Activity Relationship) and related physicochemical property data, largely sourced from peer-reviewed journal articles. The data type within the ChEMBL database typically includes experimental value, chemical structure, assay description, type of experiment, and certain experimental conditions. Table 1 summarizes the original entries we collected, along with the number of bioassays of the ChEMBL database used for PharmaBench22. We analysis through 97,609 raw entries based on 14,401 different bioassays in PharmaBench22.

These entries from different bioassays in the ChEMBL database were analyzed through our Data Mining workflow to extract the experimental conditions. This is mainly because most of the experimental conditions recorded in ChEMBL are not explicitly specified. For instance, for solubility experiments, entries in the ChEMBL database do not include explicit data columns such as buffer type, pH condition, and experimental procedure, which are critical factors influencing experimental results. Although these conditions can be found in the assay descriptions, they cannot be directly used as a filter to distinguish experiments due to their unstructured nature. Manual mining work would be labor-intensive, which necessitates an automatic data processing framework to identify important experimental conditions from the description texts.

Thus, our multi-agent LLM system uses the entries from the ChEMBL database as the original sources and identifies various conditions for different ADMET experiments as summarised in Table 2. Additionally, we have augmented our datasets with some public datasets that have associated assay descriptions as illustrated in Fig. 1. Table 1 presents a summary of the 59,009 entries we have compiled from various public datasets, along with a delineation of their respective sources.

Overall, we have used more than 150,000 entries from public data sources to construct PharmaBench22, and the data mining process has analyzed 14,401 different bioassays.

Summary of data sources for PharmaBench, from left to right: the broad ADMET category, property name, number of ChEMBL entries and bioassays, number of other entries, and a summary of the sources with references.

Table of Experimental Conditions and Filters Across Datasets.

## Section: Methods › Data mining

GPT-417, a model created by OpenAI, was utilized as the core LLM for the data-mining task. Based on previous research, to obtain optimized results from GPT-4, a prompt with clear instructions and examples is required for every specific task17,23–25. As shown in Fig. 2, the prompt for our data-mining process includes both instructions and examples. The instructions summarize the experimental conditions as the data mining goal and specify the requirements for the output formats. The examples, on the other hand, provide few-shot learning examples for the LLM. This prompt engineering is an important process for improving the results of GPT-417.

However, constructing prompts for various tasks requires domain knowledge of the ADMET experiments, and creating examples for these data mining tasks remains labor-intensive. We wish to explore whether the LLMs can automatically identify key experimental conditions from different types of experiments, generate examples, and complete the complex data mining process with minimal human effort.

As a result, a multi-agent LLM data mining system was proposed in this study to extract experimental conditions from the descriptions of various bioassays26–28. An agent is a module or entity that utilizes the LLM to perform specific tasks, such as understanding, generating, or processing natural language texts28. Instead of using a single LLM-powered agent, a multi-agent system was proposed to customize LLMs into various agents, each with different capability, to automatically complete the complex data mining process, as shown in Fig. 326.

The multi-agent system consists of three agents, namely keyword extraction agent (KEA), example forming agent (EFA), and data mining agent (DMA), as illustrated in Fig. 3. The KEA will pick out and summarize the key experimental conditions for ADMET experiments. The EFA will then generate examples based on these experimental results summarized by the KEA. We will manually validate the outcomes of the KEA and EFA to ensure their quality. Finally, the DMA will mine through all the assay descriptions and identify all the experimental conditions within these texts. The following sections will introduce these three agents in more detail.

Sample Prompt for LLM Interaction: Illustration of a Typical User Query Input, Including Instructions and Example Parts.

Overview of the Multi-Agent LLM Data Mining Workflow. This figure presents a summary of the multi-agent LLM data mining workflow, which includes three key components: the Keyword Agent, responsible for identifying experimental conditions; the Example Agent, tasked with generating examples; and the Data Mining Agent, designed to extract experimental conditions from assay descriptions.

Sample Prompt for the Keyword Extraction Agent.

Sample Prompt for the Example Forming Agent.

## Section: Methods › Data mining › Keyword extraction agent

The KEA is designed to summarize key experimental conditions from various ADMET experiments. A prompt, as illustrated in Fig. 4, along with texts from 50 randomly selected assay descriptions, was created as the model input for the KEA. This prompt instructs GPT-4 to summarize the experimental conditions from selected assay descriptions of bioassays in ChEMBL. The model’s task is to identify and summarize the top five most frequently mentioned experimental conditions. For more complex experiments, such as microsome clearance and CYP inhibition, the model was asked to summarize the top ten conditions. GPT-4 is required to generalize these conditions rather than just listing specific conditions and duplicating or listing similar conditions should be avoided. An example of a Python list is provided to KEA to illustrate the desired output format for GPT-4. This process will leverage GPT-4’s internal knowledge to generate a list of significant experimental conditions. An example of the input and output for the KEA is shown in Fig. 4.

The experimental conditions summarized by the KEA are listed in the ‘Experimental Condition’ column of Table 2. Domain experts were invited to confirm if these conditions are key conditions for ADMET experiments. These experimental conditions are then used as the primary data mining goal for the DMA to extract from each assay description.

Sample Prompt for the Keyword Extraction Agent.

## Section: Methods › Data mining › Example forming agent

The EFA focuses on generating examples from assay description texts. The prompt for this agent includes clear instructions incorporating the key experimental conditions summarized by the Keyword Agent, along with forty assay descriptions for analysis purposes. The Example Agent returns a Python dictionary containing the index, original sentences, and key experimental conditions as the keys. It will return ‘None’ if no information is provided within the sentences.

For each ADMET experiment, forty examples will be generated through these automatic pipelines. Manual examination is conducted on the examples to eliminate errors and confirm the format. This fast labeling process generates few-shot learning examples for DMA, which avoids intensive human labeling. The example input and output for this agent is shown in Fig. 5.

Sample Prompt for the Example Forming Agent.

## Section: Methods › Data mining › Data mining agent

The DMA aims to complete the mining task for all assay descriptions from the ChEMBL database. As shown in Fig. 2, the prompt for this agent includes instructions containing the experimental conditions summarized by the KEA and forty examples generated by the EFA. As shown in Fig. 5, the prompt defines the data mining task, identifying experimental conditions and outputting them in the desired format. These examples provide few-shot learning data for the DMA to learn how to standardize the output format and improve the overall output quality.

GPT-4 has a limit on the number of tokens to be processed in a single request17. Thus, we divided the assay descriptions with a batch size of twenty to mitigate the risk of overloading the model. This batching technique allows for a more accurate and reliable analysis, especially when dealing with complex assay descriptions.

The DMA will return a Python Dictionary for every batch input. A routine was written to convert the Python Dictionary from a Markdown file into a Pandas DataFrame, which is then stored. Eventually, the Data Mining Agent goes through all the assay descriptions in the raw data and stores the output of every batch. The experimental conditions mined based on this multi-agent system are then merged back into the original file for data standardization and filtering.

Overall, this multi-agent system mines through 14,401 assay descriptions to identify the experimental conditions for seven different ADMET experiments. It largely minimizes human effort to extract structured experimental conditions which will be then used in the following data standardization and filtering procedures.

## Section: Methods › Data standardization

The data obtained from different sources exhibit significant variability in the format of structure, data type, name of experimental condition, and the unit and range of experimental value. For standardizing the data, we design a data standardization workflow to clean the data obtained from the previously described data mining step and it includes standardization of structure format, experimental condition, and experimental value.

## Section: Methods › Data filtering

A data filtering process aims to filter out entries with abnormal molecules and irregular experimental results, to construct the final benchmark set that contains experimental results in consistent units and experimental conditions.

## Section: Methods › Data preparation for AI modeling

After the above data processing workflow, a series of ADMET datasets were constructed from various bioassays. The count of entities is summarized in Table 3. However, multiple experimental results for the same compounds occur under the same conditions within the datasets after the processing workflow.

Thus, we employed various strategies to unify these repeated results in the final datasets. For regression tasks, for compounds with repeated data, the mean value was taken as the unified value. There are two classification datasets in our benchmark set. For the BBB experiment, we eliminate all compounds with contradictory results, while for AMES, we label the compounds as positive if at least one positive result occurs in these experiments. This approach is primarily due to the fact that AMES is a toxicity-related experiment, which requires the model to be highly sensitive to positive results30.

Additionally, we divided the datasets for each property into training and test sets with a ratio of 0.8:0.2 respectively, utilizing both random and scaffold splitting methods. Random splitting involves distributing the compounds arbitrarily across the training and test sets, whereas scaffold splitting is designed to create sets with distinct structural features by allocating compounds that share the same core scaffold exclusively to either the training or the test set10. This approach ensures that the test set is structurally different from the training compounds, making it more challenging for models to predict.

Summary of Datasets in PharmaBench: ‘Property Name’ refers to the name of the dataset.

## Section: Data Records

We have compiled 11 ADMET datasets to form PharmaBench, which is freely available at figshare22. Table 3 includes the number of entries after the data processing workflow for each dataset and the final entries for AI modeling. The final entries consist of one experimental result for each molecule, based on the experimental condition as described in the ‘Filter’ column of Table 2. The mission type of the different datasets is also summarized in the ‘Mission Type’ column of Table 3, including regression and classification.

Overall, PharmaBench22 comprises a total of 52,482 entries. It is stored in comma separated values (CSV) format and includes a unified SMILES representation, experimental results, property names, and training labels based on both scaffold and random splitting, as summarized in Table 4. The data are also openly accessible on GitHub at https://github.com/mindrank-ai/PharmaBench, along with the processing workflow.

The following section will introduce different datasets in more detail, including a general introduction to various ADMET properties, the units for different datasets, and the number of molecules.

List of information in the final datasets.

## Section: Technical Validation

Once the data collection is done, we evaluate the datasets from three aspects. Firstly, we use the repeated test results for the datasets before and after the implementation of the data processing workflow to demonstrate the improvement in data quality resulting from this workflow. Secondly, we illustrate the characteristics of PharmaBench22 by showing distributions of various molecular properties. Lastly, we trained various machine learning and deep learning models on the datasets and presented model performance on the test sets.

Comparison of Data Quality Before and After the Data Processing Workflow Through Repeated Test Plots and Confusion Matrices (a) Repeated Test Plot for the LogD Experiment Before Data Processing. (b) Repeated Test Plot for the LogD Experiment After Data Processing. (c) Repeated Test Plot for the BBB Experiment Before Data Processing. (d) Repeated Test Plot for the BBB Experiment After Data Processing. Additional data can be found in Table 5.

Comparison of Metrics Between the Regression Datasets Before and After the Data Processing Workflow.

Comparison of Metrics Between the Classification Datasets Before and After the Data Processing Workflow.

Frequency Histograms for All PharmaBench Datasets: Count Distribution of Atom Numbers, Molecular Weights, LogP, and QED Scores Across Different Datasets.

Summary of AI Models Utilized in the Validation Process.

Summary of final results for the PharmaBench based on random split.

Summary of final results for the PharmaBench based on scaffold split.

## Section: Technical Validation › Repeated test for data quality assessment

A comparison for repeated test results is a methodological approach where the same experiment is conducted multiple times to verify the consistency of the results37. Limited by the scope of this work, we cannot verify each data point through wet lab experiments or review each literature to confirm the direct data quality of the dataset. Thus, we implement an indirect approach, namely repeated testing, to confirm the data quality before and after data processing. A raw dataset often contains multiple records for the same compound due to different sources and varying experimental conditions. Repeated testing compares the maximum and minimum values for the same compound under the same condition to validate the data quality.

As shown in Fig. 6, the repeated test plot is used to analyze regression results, and the confusion matrix is used to analyze the classification results. If the experimental results are consistent for different data sources, the repeated test plot will exhibit higher correlation and a lower mean absolute error (MAE) for regression tests, and the confusion matrix will show higher accuracy (ACC), precision, and recall for classification tests. In contrast, low-quality data will have opposite metric scores.

We use this method to compare data quality before and after considering the experimental conditions mined through our data mining process, thereby demonstrating improvement in data quality based on our approach. The data quality before and after the data processing workflow can be compared and evaluated through the metrics mentioned above.

Specifically, we group data entries for the same molecules from the raw data to create the ‘before data processing’ plot, and we group data entries for the same molecules under identical conditions for the ‘after data processing’ plot. The maximum and minimum experimental results for each group are selected as the worst-case scenario. We have created a scatter plot for the regression tests and a confusion matrix for the classification tests, as shown in Fig. 6. The R, MAE, and RMSE for regression tasks, and ACC, F1, precision, and recall for classification tasks, have been calculated and are recorded within Tables 5 and 6.

Table 5 demonstrates the results of repeated tests for regression tasks within PharmaBench22, while Table 6 summarizes the classification tasks. All metrics improved following the data processing workflow, validating the quality increment. The results of repeated tests for certain experiments, such as the LogD experiment, have significantly improved data quality after the data processing workflow, reaching a level comparable to that of traditional wet lab experiments. However, the results of repeated tests for CYP and clearance experiments remain relatively low, due to the complex nature of these in vitro experiments.

Comparison of Data Quality Before and After the Data Processing Workflow Through Repeated Test Plots and Confusion Matrices (a) Repeated Test Plot for the LogD Experiment Before Data Processing. (b) Repeated Test Plot for the LogD Experiment After Data Processing. (c) Repeated Test Plot for the BBB Experiment Before Data Processing. (d) Repeated Test Plot for the BBB Experiment After Data Processing. Additional data can be found in Table 5.

Comparison of Metrics Between the Regression Datasets Before and After the Data Processing Workflow.

Comparison of Metrics Between the Classification Datasets Before and After the Data Processing Workflow.

## Section: Technical Validation › Analysis of property distribution

Basic physicochemical properties of the compounds, including atom counts, molecular weight, LogP, and QED, were calculated using RDKit. Histograms representing the frequency of these properties were calculated and are presented in Fig. 7 to illustrate the characteristics of the molecules within PharmaBench22,38.

This histogram demonstrates that compounds in PharmaBench22 exhibit a broad distribution. The number of non-hydrogen atoms per molecule typically ranges from 10 to 50, and molecular weights range from 200 to 600 Daltons, which are consistent with the range of drug-like small molecules39. Additionally, the LogP values of these datasets are in the range from 0 to 8, indicating a tendency towards lipophilicity, which is also well aligned with that of drug-like compounds39. QED is a metric that evaluates the potential of a compound to be developed as a successful drug, based on a multi-factorial analysis of molecular properties of marked drugs39. The QED distribution for PharmaBench22 is skewed towards 1, suggesting that many compounds in the datasets possess favorable physio-chemical properties.

Overall, the molecules within PharmaBench22 demonstrate preferable characteristics, which are similar to those in the small molecule drug discovery projects.

Frequency Histograms for All PharmaBench Datasets: Count Distribution of Atom Numbers, Molecular Weights, LogP, and QED Scores Across Different Datasets.

## Section: Technical Validation › Deep learning and machine learning modeling

Summary of AI Models Utilized in the Validation Process.

Summary of final results for the PharmaBench based on random split.

Summary of final results for the PharmaBench based on scaffold split.

## Section: Technical Validation › Deep learning and machine learning modeling › Modeling protocol

Similar to the repeated test mentioned above, we used MAE, RMSE, and Pearson correlation coefficient R to evaluate the regression results. For classification results, we utilized AUC (area under the receiver operating characteristic curve), ACC, and the F1 score (F1) for evaluation.

We selected two machine-learning approaches and seven deep-learning models for this evaluation process. The machine learning models include XGBoost40 and Random Forest (RF)41, utilizing the Extended Connectivity Fingerprints (ECFP) as descriptors for the molecules42. We selected seven deep learning models, some of them need a pre-training process, and their input is either 2D graph or 3D conformation. Detailed descriptions of these models can be found in Table 7.

All models were built using default parameters, without additional fine-tuning. Although hyper-parameter optimizing strategy might improve the results, our intention is not to select the best model but rather to use these models to verify the quality of the PharmBench.

Summary of AI Models Utilized in the Validation Process.

## Section: Technical Validation › Deep learning and machine learning modeling › Modeling results

We present the metrics for the regression models and for the classification models, trained using both random as shown in Table 8 and scaffold splitting as shown in Table 9 datasets.

For the datasets associated with regression tasks, the prediction results achieve desirable metrics for LogD, water solubility, BBB, and microsomal clearance, exhibiting relatively high R values and low MAE and RMSE. However, the prediction results for the CYP remain relatively low, which indicates that further improvements in data quality and modeling approaches are required for these datasets. The metrics for the classification tasks are all relatively high, which indicates that the models can effectively predict the classification results for the BBB and AMES datasets.

In regards to the splitting method, the prediction results of random splitting are better than scaffold splitting for the majority of tasks. This is understandable since the prediction performance for the majority of models is usually worse for compounds with new scaffolds. In addition, deep learning approaches significantly outperform the machine learning approaches in regression tasks. The performance gap between the deep learning and machine learning models widens for datasets with a large amount of data, such as LogD and water solubility, but narrows for smaller datasets, such as mouse microsomal clearance. This indicates that conventional machine learning approach can adapt to small datasets and has less capability to model large amounts of data compared with deep learning model. In contrast, the performance of the machine learning approach for classification tasks witnesses a significant increase. The metrics for XGBoost models for AMEs and BBB datasets surpass some deep learning approaches, indicating that machine learning approaches are more suitable for classification tasks.

Among deep learning approaches, the model with pretraining demonstrates the best performance in both regression and classification tasks for the majority of datasets. This indicates that the pretraining process can be useful for improving model performance for ADMET properties predictions. Moreover, there is no significant performance difference between graph-based and transformer-based approaches, or between 2D and 3D feature-based methods.

More research and modeling work are encouraged to utilize this benchmark set in the future. For instance, investigating approaches to improve model capabilities in predicting molecules with novel scaffolds would be valuable. The use of transfer learning and pre-training approaches is also recommended for the analysis with these datasets. Additionally, applying explainable AI techniques could provide valuable insights into the key pharmacological factors influencing ADMET properties.

Summary of final results for the PharmaBench based on random split.

Summary of final results for the PharmaBench based on scaffold split.

## Section: Usage Notes

There are eleven ADMET datasets within PharmaBench22. Standardized SMILES representations of compounds were provided for modeling the compounds, and the experimental values are provided as the prediction targets. Users may use the labels within the scaffold_train_test_label and random_train_test_label as the train-test labels for fair comparison.

## Section: Acknowledgements

This study was funded by MindRank AI Ltd. H. C. acknowledged funding from the Guangzhou Basic and Applied Basic Research Project (202201011795) and the Pearl River Recruitment Program of Talents (No. 2021CX020227). G. Y. was supported in part by the ERC IMI (101005122), H2020 (952172), MRC (MC/PC/21013), the Royal Society (IEC\ NSFC\211235), the NVIDIA Academic Hardware Grant Program, the SABER project supported by Boehringer Ingelheim Ltd, Wellcome Leap’s Dynamic Resilience, and the UKRI Future Leaders Fellowship (MR/V023799/1).å

## Section: Author contributions

Z.N., X.X. and W.W. conceived the presented idea. X.X., W.W., Y.J. and Q.C. developed the theory and the data mining system. Q.C., W.J., G.J.Y., L.K. and J.X. collected the data. Z.N., X.X., W.W., Q.C., Y.J. and W.J. developed the data processing workflow. X.X., W.W., Q.C., Y.J., W.J., M.W. and G.J.Y. developed the technical validation for the data qualities. H. C. and G. Y. supervised the findings of this work. All authors discussed the results and contributed to the final manuscript.

## Section: Code availability

The codes used in this study have been deposited at https://github.com/mindrank-ai/PharmaBench. All the calculations were done with Python 3.12.2 under a virtual environment created with Anaconda on osx-64.

## Section: Competing interests

Z.N., X.X., W.W., Q.C., Y.J., W.J., M.W., G.J.Y., L.K. and X.J. are the employees of MindRank AI ltd.

## Section: Contributor Information

Guang Yang, Email: g.yang@imperial.ac.uk.

Hongming Chen, Email: chen_hongming@gzlab.ac.cn.

## Section: Associated Data › Data Availability Statement

The codes used in this study have been deposited at https://github.com/mindrank-ai/PharmaBench. All the calculations were done with Python 3.12.2 under a virtual environment created with Anaconda on osx-64.


---

# Practical guide to SHAP analysis: Explaining supervised machine learning model predictions in drug development

- **Authors:** Ana Victoria Ponce-Bobadilla, Vanessa Schmitt, Corinna S Maier, Sven Mensing, Sven Stodtmann
- **Issuer:** Clinical and translational science
- **Type:** Scientific article
- **Published:** 2024-11-01
- **Language:** en
- **DOI:** 10.1111/cts.70056
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39463176/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractDespite increasing interest in using Artificial Intelligence (AI) and Machine Learning (ML) models for drug development, effectively interpreting their predictions remains a challenge, which limits their impact on clinical decisions. We address this issue by providing a practical guide to SHapley Additive exPlanations (SHAP), a popular feature‐based interpretability method, which can be seamlessly integrated into supervised ML models to gain a deeper understanding of their predictions, thereby enhancing their transparency and trustworthiness. This tutorial focuses on the application of SHAP analysis to standard ML black‐box models for regression and classification problems. We provide an overview of various visualization plots and their interpretation, available software for implementing SHAP, and highlight best practices, as well as special considerations, when dealing with binary endpoints and time‐series models. To enhance the reader's understanding for the method, we also apply it to inherently explainable regression models. Finally, we discuss the limitations and ongoing advancements aimed at tackling the current drawbacks of the method.

## Section: INTRODUCTION

The use of Artificial Intelligence (AI) and Machine Learning (ML) models in drug discovery and development offers great potential. 1 , 2 , 3 , 4 Several ML models have been developed for predicting the absorption, distribution, metabolism, and excretion (ADME) properties of small molecules, 5 , 6 pharmacokinetic‐pharmacodynamic modeling, 7 , 8 understanding exposure‐response relationships, 9 patient subpopulation detection, 10 , 11 , 12 , 13 , 14 patient stratification, 15 , 16 and biomarker detection. 17 To inform clinical decisions in drug development and build trust for these tools, it is crucial to understand how the predictors influence the model predictions and which ones are the most impactful.

The research area of explainable AI or interpretable ML aims to trace the decision‐making process of a ML model and understand the key features driving its predictions. 18 Model interpretability can be achieved either by considering models that are inherently interpretable (e.g., linear, logistic regression, decision trees) or considering post hoc “explainability” methods that can be applied to black‐box models (e.g., neural networks, random forests, XGBoost, gradient boosting machines). It is interesting to note that post hoc methods can be applied to both interpretable and black‐box models, making them model‐agnostic. In a recent perspective, Imrie et al. 19 classified the different model‐agnostic methods according to the type of explanation they provide: (1) feature‐based (How relevant are the data features to model predictions?), (2) model‐based (Can the model predictions be explained using auxiliary meta‐models?), (3) example‐based (What other samples' model predictions are similar to a particular subset of samples?), (4) concept‐based (Does the model appear to adhere to concepts derived from domain knowledge?), and (5) counterfactual explanations (What does the model predict when considering synthetic samples under particular scenarios?). This tutorial provides a practical guide to one of the most popular feature‐based ML interpretability methods: SHapley Additive exPlanations (SHAP) analysis.

SHAP analysis is a feature‐based interpretability method that has gained popularity thanks to its versatility which provides local and global explanations. It also provides values that are easy to interpret and can be easily implemented thanks to its easy‐to‐use packages that implement this method. Several publications in this field have used this methodology, and some of them have started to highlight some important considerations on its use. 9 , 10 , 20 , 21 , 22 , 23

In this tutorial, we first briefly review the game‐theoretical background of Shapley values, and their connection to SHAP analysis, and give remarks on the calculation of SHAP values. Then we describe the datasets used for this tutorial along with the supervised learning problems that we considered to exhibit the SHAP methodology. Next, we discuss the implementation and practical considerations of SHAP value analysis: visualization plots, special considerations when applying SHAP to classification endpoints, special considerations when dealing with time‐series models, and available software to perform the analysis. Subsequently, we walk through a SHAP analysis in common statistical frameworks (linear regression and logistic regression) and present how to apply this analysis to the most common ML frameworks (random forest, XGBoost, neural networks) for both a regression and classification problem in Python. Furthermore, the application of SHAP analysis to time‐dependent models is demonstrated. Finally, we summarize the limitations and mention other extensions that should be considered for this popular technique.

## Section: THEORETICAL BACKGROUND OF SHAP ANALYSIS

Marginal contributions for drug combination example illustrating calculation of Shapley values.

Linking the terminology from game theory and ML for Shapley values.

## Section: THEORETICAL BACKGROUND OF SHAP ANALYSIS › Mathematical background

SHAP analysis is rooted in Shapley values, a concept from collaborative game theory. Shapley values provide a fair distribution of a payout among players in a collaborative game where players work together for a common goal, even if the players may have contributed unequally. We will use the example of combination drug therapy and calculate the contribution of each drug on the response to illustrate the concepts. Let's assume Drug A, Drug B, and Drug C, when administered together, have a response rate of 90%. The individual drugs' response rates are:

Let's assume we also know the response rates of the two‐drug combinations, or in the language of game theory, coalitions of two (subsets of the group of size 2):

Given the single drug and dual combination response rates, what would be the fair individual drug contribution to the triple combination response rate of 90%?

In 1953, Lloyd Shapley 24 defined a set of properties that a fair measurement of contribution in a collaborative game should fulfill:

Lloyd Shapley derived a mathematical formula of the values ϕj that satisfies these properties and proved that these values are the only ones capable of satisfying all these properties. These values are the so‐called Shapley values. Considering a payout, V, each player j is assigned a Shapley value, ϕj, that corresponds to their fair share of the payout based on their individual contribution. The mathematical formula for ϕj is the following:

where S is a coalition, N is the set of all players, VS⋃j−VS quantifies the marginal contribution of player j to coalition S, S!N−S−1!∣N∣! is the weight of the marginal contribution and ∑S⊆N\j sums over all possible coalitions without j. The weights are the inverse of the number of coalitions of size |S| excluding player j.

Shapley values can be interpreted as the weighted average of a player's marginal contributions across all possible coalitions.

Let's calculate the Shapley values for the combination therapy example. First, for each drug we consider all the possible coalitions that can be created without that specific drug. For example, for Drug A, these coalitions are: one coalition of size 0: ⊘, two coalitions of size 1: B,C and one coalition of size two: B,C. We calculate the marginal contribution when adding Drug A to each of these coalitions and use Formula 1 to calculate its SHAP value. We then do the same for Drug B and Drug C. In Table 1 we include these calculations along with each drug's marginal contribution and their corresponding Shapley values. The sum of all Shapley values equals the total response: 20.83% + 33.33% + 35.83% = 90%.

Marginal contributions for drug combination example illustrating calculation of Shapley values.

## Section: THEORETICAL BACKGROUND OF SHAP ANALYSIS › Connection between Shapley values and SHAP analysis

The use of Shapley values for ML interpretability was first introduced by Štrumbelj and Kononenko in 2010. 25 The authors showed how Shapley values can be used to fairly quantify the contribution of features in a ML model. The method was then popularized and extended by Lundberg et al. 26 to the so‐called SHAP analysis. In their paper, the authors were able to show how Shapley values unified other feature‐based interpretability methods and provided an open‐source package that sparked a widespread adoption of the method.

The connection between Shapley values and SHAP analysis can be understood by considering the potential model features (covariates) as “players” in a collaborative game: working together to determine each individual predicted value. Table 2 illustrates the terminology from game theory and ML that establishes this connection. For each term in game theory, we also include (in parenthesis) the equivalent term for our combination therapy example. By establishing this link, SHAP values inherit all the properties of Shapley values, such as efficiency, symmetry, additivity, and null player. Consequently, SHAP values provide a fair and unbiased measure of each feature's contribution to the predicted value of each sample. To provide more clarity to the reader, Table S1 establishes a connection between the terminology used in ML and the corresponding terminology in statistics.

From the efficiency property, a property of SHAP values that is crucial for their interpretation can be derived: consider the prediction for a sample i, fi. The SHAP values for all features j of sample i, ϕi,j, satisfy the following formula:

This means that for a given sample i, the SHAP values assigned to each feature describe the extent to which that feature contributed to the difference between the individual prediction of this sample from the average model prediction. A derivation of this formula from the efficiency axiom is presented in Molnar et al. 27

Linking the terminology from game theory and ML for Shapley values.

## Section: THEORETICAL BACKGROUND OF SHAP ANALYSIS › Calculation of SHAP values

Typically, using Formula 1 to calculate SHAP values for feature contributions of a ML model prediction is too computationally expensive; therefore, different implementation and approximation methods have been considered to efficiently calculate SHAP values for common ML models. An exception to this rule are tree‐based models, for example, XGBoost, random forest, LightGBM, CatBoost, for which it is possible to efficiently calculate the exact SHAP values by exploiting the tree structure of models. 28

For neural network‐based models, approximation methods can leverage the computational graph or exploit the model differentiability to calculate the SHAP values. In the popular Python package SHAP, examples of such approaches are implemented in DeepExplainer and GradientExplainer. Finally, an approximation method that can be applied to any supervised model, (i.e., a model‐agnostic method) is the kernel SHAP method. Kernel SHAP approximates the Shapley values by using a weighted sampling approach. One needs to define a representative subset of the dataset often called background dataset (which should capture the range and distribution of the features in the dataset) from which subsets of features are sampled. A kernel function is applied to compute the contributions of these subsets to the prediction. These contributions are then weighted based on the number of times each feature appears in the subsets. By repeating this process multiple times, Kernel SHAP provides an estimate of the Shapley values.

## Section: TUTORIAL DATASETS

To introduce the SHAP methodology and allow the reader to reproduce our tutorial we utilized both public datasets and in‐silico datasets.

To illustrate the use of SHAP analysis in different black‐box regression models, we utilized the National Health and Nutrition Examination Survey (NHANES). 29 These surveys are designed to assess the health and nutritional status of US adults and children. The NHANES survey includes demographics, socioeconomic, dietary, laboratory, and health‐related questions. We create a dataset using a subset of this survey data. We consider the features of sex, body mass index (BMI), age, estimated number of days over the past year that the participant drank alcoholic beverages, and the number of days in a typical week that the participant does moderate or vigorous physical activity to predict blood pressure.

For showcasing the use of SHAP analysis in different black‐box classification models, we employed a breast cancer diagnostic dataset. This dataset consists of features computed from digitized images of a fine needle aspirate of breast masses. These features describe the characteristics of the cell nuclei present in the image. Based on the features of the different samples, we are interested in classifying the tumor mass as benign or malignant. A more detailed description of the dataset is available here. 30

To show the application of SHAP values to a time‐dependent ML model, we utilized in‐silico data from a pharmacokinetic (PK) model. This PK model consisted of a first‐order absorption and linear clearance. We assumed clearance exhibits interindividual variability. Further details on the PK model and model parameters can be found in Supporting Information. We considered the regression problem of predicting individual clearances using a Long Short‐Term Memory (LSTM) model from drug concentration‐time profiles. We simulated 1000 drug concentration‐time profiles during a 48‐h period, assuming a daily infusion of 200 mg lasting for 1 h. The drug concentration was sampled every 4 h, starting 1 h after the first dose was administered, resulting in 12 recorded concentrations for each simulated subject.

A description of where to find the datasets and how we pre‐process them before training the ML models is available in the Supporting Information. When training the models, we consider a 70:30 train:test split. The code used for performing all the SHAP analyses can be found in the Supporting Information.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS

Consider the standard supervised ML workflow depicted in Figure 1.

SHAP analysis is part of the model interpretation phase in a ML workflow and should be only performed if the model demonstrates adequate performance. Therefore, the reported SHAP values should usually be the SHAP values that correspond to the test dataset.

As pointed out by Lu et al., 23 a good practice in ML consists of performing the model validation using k‐fold cross‐validation. Analyzing the distributions of SHAP values across the different folds allows us to understand if the SHAP value trends observed in the visualization plots are consistent across the data and not just present in a subset of the dataset.

Standard supervised ML workflow.

Different visualization plots of SHAP values from an XGBoost model when predicting blood pressure: (a) Bar plot; (b) Beeswarm plot; (c) A scatter plot for the feature age colored by each subject's BMI; (d) Waterfall plot for an example subject.

Scatter plot of SHAP values for feature age faceted by train‐test status when considering cross‐validation. The trends across the different folds are depicted in different lines corresponding to the fold.

Visualization plots of SHAP values derived from an XGBoost model for a classification problem, explaining the predicted probabilities (a,c,e) and the predicted log‐odds (b,d,f).

(a) Example time‐course of the PK model considered to model drug concentration. Different visualization plots for the SHAP values explaining the predictions of individual clearances are depicted; (b) Bar plot; (c) Beeswarm plot; (d–f) Scatter plots of SHAP values corresponding to concentration at different times.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Overview of visualization plots

Different plots can be used to visualize SHAP values, which allow either local or global explanations and each has a specific interpretation, purpose, advantages, and disadvantages. In this section, we describe the most common plots that are offered by the popular Python package SHAP. 26 , 28

To illustrate the use of these plots, we first trained an XGBoost model for the blood pressure regression problem introduced in the tutorial datasets. After assessing that the model has an adequate fit, we used the SHAP package to calculate the SHAP values for both the train and test dataset. If not otherwise specified, the plots show the SHAP values for the test dataset. In Figure 2 we show the most common visualization plots for SHAP values. In this section, we describe the different parts of the plots, their purpose, advantages, and disadvantages. The code to create these plots can be found in the Supporting Information.

Different visualization plots of SHAP values from an XGBoost model when predicting blood pressure: (a) Bar plot; (b) Beeswarm plot; (c) A scatter plot for the feature age colored by each subject's BMI; (d) Waterfall plot for an example subject.

Scatter plot of SHAP values for feature age faceted by train‐test status when considering cross‐validation. The trends across the different folds are depicted in different lines corresponding to the fold.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Overview of visualization plots › Bar plot

The bar plot, a global explanation method, displays the mean absolute SHAP value for each feature across all predictions, serving as a measure of feature importance. It quantifies, on average, the magnitude of each feature's contribution to the model prediction; thus, it provides a ranking of features.

An advantage of this measurement for determining feature importance is that the SHAP values are expressed in the same units as the model predictions making them more intuitive. For example, in our regression example, the average impact of the variable age on the predictions of the model is 5.86 mm Hg. To illustrate this point, we refer to Formula 2, where we see that if the prediction is a blood pressure (e.g., mm Hg), all SHAP values will also have the same units, mm Hg. This contrasts with other feature importance measurements like permutation feature importance scores. A disadvantage of this representation is the lack of nuance on the directionality of the impact, or whether the relationship is monotonous. Also, selecting a cut‐off based on the SHAP values, to identify the most important features, depends on domain knowledge and should be determined on a case‐by‐case basis and does not follow a general rule.

In Figure 2a we observe that when considering the XGBoost model for predicting blood pressure, age appears to be the most important feature followed by BMI and then sex.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Overview of visualization plots › Beeswarm plot

The beeswarm plot provides a global overview of SHAP values for selected features, with rows representing each feature ranked by the mean absolute SHAP value. The individual dots in each row are the SHAP values for that particular feature in each sample of the dataset. Two properties of the dot encode the information of the SHAP values:

Inspection of the color distribution for each feature along the xaxis can provide global insights into the relationship between the feature values and its SHAP values:

An advantage of this plot is the ability to show multiple features at once, ranked by their impact, and at the same time give an indication of directionality and shape of the impact. A disadvantage is the use of color as a scale since it can be difficult to extract the shape of a relationship from the color differences.

In Figure 2b the beeswarm plot shows a detailed overview of the SHAP values for our regression example. We observe that the feature age has a wide SHAP values range and has much higher values than the mean absolute value (5.86). Age appears to have a generally monotonous increasing trend. Age and BMI SHAP values appear to follow a similar pattern hinting toward a possible interaction. This can be further investigated in the following plot.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Overview of visualization plots › Scatter plot

The scatter plot in displays the relationship between one feature value (x axis) and the SHAP values (y axis). It consists of (1) the scatterplot in which each point represents the sample's feature value on the x axis and the SHAP value on the y axis and (2) the inset gray histogram above the x axis which displays the feature value distribution.

The distribution of the points informs us whether there is a general trend between the feature values and SHAP values and allows us to identify linear or non‐linear relationships. It may be helpful to include trend lines to detect which type of relationship is present. The vertical spread of SHAP values at a fixed feature value is a sign of interaction effects with other features in the model. It is important to consider the inset histogram when interpreting the trends. A high number of samples present in a particular part of the plot indicates that the trend in that area is supported by many samples. Conversely, when the number of samples is limited, it is important to be cautious and refrain from overinterpreting the trend.

Scatter plots may be colored according to another feature's value, by either coloring according to another feature value or first binning the other feature's values and considering coloring according to the bins. 23 This allows to detect interaction effects between different features.

The advantage of this visualization is the level of detail which clearly indicates the direction, magnitude, and variability of the feature's impact on model predictions. This comes at the price of only allowing a single feature per figure or panel.

In Figure 2c we consider the scatter plot for the feature age colored by the subject's BMI. We observe that age above 50 generally has a positive SHAP value (higher blood pressure) and we observe some non‐linearity in the relationship. However, we are unable to detect any interactions between the feature age and BMI.

An extension of this plot can be considered when doing k‐fold cross‐validation such that the points are colored to the different folds they belong to, and the plot is faceted by the train‐test status. Trend lines can also be included per fold. This plot then allows us to corroborate if trends are consistent across different subsets of data.

In Figure 3, we consider this extension of the scatter plot for the feature age. We performed a fivefold cross‐validation and calculated the SHAP values for each fold for the test and the train dataset. We can observe that the trend of the SHAP values for age is consistent across the folds and across the train‐test split. This demonstrates that the feature impact is stable and trustworthy.

Scatter plot of SHAP values for feature age faceted by train‐test status when considering cross‐validation. The trends across the different folds are depicted in different lines corresponding to the fold.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Overview of visualization plots › Waterfall plot

A waterfall plot is used to visualize the predicted SHAP values of a single sample showing all features. The predicted value for this specific sample is given in the plot title.

The model features are located along the y axis, and the value of that feature for that specific sample is denoted in gray. The SHAP value corresponding to each feature for this specific sample is written in the main panel within an arrow for each row or feature. The row is red (blue) if the SHAP value increases (decreases) the prediction f(x i ) in comparison to the expected or average prediction.

This type of plot provides a local interpretation since it focuses on a single sample. This is useful when analyzing model outliers, SHAP values outliers, or specific subjects of interest.

In Figure 2d, we show the waterfall plot for an example subject. We can see that BMI is the feature that affects the difference between its model‐predicted blood pressure the most when compared to the average prediction.

More references on other plots like heatmap plots, force‐plots, decision plots, violin plots, stacked force‐plots, interaction plots, to name a few and their interpretation can be found in other publications. 27 , 31 , 32

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Binary endpoints

For classification ML models, special care needs to be taken when calculating SHAP values. Using SHAP for explaining a classification model prediction can be set up in two ways: (1) explaining the predicted probabilities or (2) explaining the predicted log‐odds for each sample belonging to that class. Explaining probabilities makes it easier to identify the contribution of features to the prediction; however, explaining the predicted log‐odds can provide a clearer picture of the relationship between the model features, making the log‐odds sometimes easier to interpret. This can be due to non‐linear interactions and implicit interactions. It is worth considering both explanations.

To illustrate the application of SHAP analysis for classification models, we trained an XGBoost model using the breast cancer diagnostic dataset. After assessing that the model has an adequate fit, we used the SHAP package to calculate the SHAP values for the test dataset. In Figure 4 we show the bar plot, beeswarm plot, and the scatter plot for the most important feature (concave points). 33 On the left plots, we display the SHAP values when explaining the predicted probabilities, while on the right, we present the corresponding SHAP values when explaining predicted log‐odds.

When comparing the SHAP plots for explaining the predicted probabilities and predicted log‐odds, the result is quite similar. Both bar plots (Figure 4a,b) show that the feature concave points has the highest mean absolute SHAP value followed by area and texture. Note the different values of the SHAP values in probabilities (concave points have a mean absolute SHAP value of 0.26) and in log‐odds (has a mean absolute SHAP value of 3.81). This signifies that concave points are the most influential feature in classifying the breast mass as benign or malignant. The beeswarm plots (Figure 4c,d) can give a better overview of the relationship between the feature values and its SHAP values. Both beeswarm plots reveal a positive relationship for concave points, area, texture, and concavity which means the higher the feature value, the higher the probability or log‐odds. For the feature area, we can see that some samples with a middle feature value (purple) are associated with the highest SHAP values, indicating that the relationship is not linear. For a closer look at the relationship between a feature's values and the model's predicted outcomes, we consider the scatter plots. Figure 4e,f shows the scatter plots for the most important feature: concave points. Both scatter plots show an increase in SHAP values for increasing concave points up to 0.09. After that, increasing feature values the SHAP values are mostly flat, especially for predicting log‐odds. In addition, at a feature value of 0.05, the model switches from predicting lower to higher probabilities or log‐odds.

Visualization plots of SHAP values derived from an XGBoost model for a classification problem, explaining the predicted probabilities (a,c,e) and the predicted log‐odds (b,d,f).

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › SHAP for time‐dependent ML models

The use of SHAP analysis for time‐dependent is a challenging 34 , 35 and currently an active area of research. Traditionally, researchers have performed SHAP analysis of a ML model prediction that considers time‐dependent data by crafting features that capture the time‐dependent aspects of the data and subsequently treating the problem as standard classification or regression models.

We consider the time‐series in‐silico data created from the PK model described in the tutorial dataset section. The drug concentration over time of this model is shown in Figure 5a for an example subject. The samples are labeled according to the cycle they belong to and the time since last dose (TSLD). Each concentration is denoted by Ccycle,TSLD. We trained a LSTM model to the simulated data and calculated the SHAP values using GradientExplainer. In Figure 5, we show different visualization plots of the SHAP values from this model. In Figure 5b, we can see that the most important features to predict the individual clearances are C1,9 followed by C1,13 and C1,17. The beeswarm plot in Figure 5c shows a monotonous decreasing trend for the concentrations in the elimination phase except for the first concentrations after tmax (i.e., C0,5 and C1,5). The scatter plot in Figure 5d,e show that SHAP values for the drug concentrations with the same TSLD for the different cycles follow the same trend. The scatter plot Figure 5f shows that the SHAP values for the first drug concentration at cycle 1 have a monotonous increasing trend as expected.

(a) Example time‐course of the PK model considered to model drug concentration. Different visualization plots for the SHAP values explaining the predictions of individual clearances are depicted; (b) Bar plot; (c) Beeswarm plot; (d–f) Scatter plots of SHAP values corresponding to concentration at different times.

## Section: IMPLEMENTATION AND PRACTICAL CONSIDERATIONS › Software

For Python, the most popular package that implements SHAP analysis is the SHAP package that is compatible with standard ML packages such as keras, tensorflow, scikit‐learn, and pytorch. For R and specifically XGBoost there is the package SHAPforxgboost 36 available in CRAN. The shapper package is also available in R and it is a R wrapper of the SHAP Python library. 37

## Section: EXAMPLES

In this section, we include the results of performing SHAP analyses for popular ML black‐box models for classification and regression problems, specifically, we consider XGBoost, 36 random forest, and neural networks (multilayer perceptron model).

To further demystify how to interpret SHAP analyses on black‐box models, we apply this methodology to linear regression and logistic regression models using in‐silico data. This will help the reader gain intuition on how to interpret the different visualization plots within a familiar framework.

For both black‐box models and interpretable models, we provide the Python code in the Supplementary Information for performing the SHAP analysis.

Visualizations plots for SHAP values of different ML regression models; (a,c,e) Bar plots; (b,d,f) Beeswarm plots.

## Section: EXAMPLES › Common ML frameworks

We considered XGBoost, random forest, and a neural network model as regression models and trained them using the regression dataset. In Figure 6, we can see the bar plot, the beeswarm plot, and the scatter plot of the SHAP values of the variable age for the test dataset of the fitted models. When comparing the bar plots (Figure 6a,c,e), we observe that for all three models, age has the highest mean absolute SHAP value. However, for the XGBoost and the neural network, BMI has the second‐highest value, followed by sex. In contrast, for the random forest model, sex has the second‐highest mean absolute SHAP values, followed by BMI. The beeswarm plots (Figure 6b,d,f) are also comparable between all three models. They show a positive relationship between age and BMI which means the higher the feature value, the higher the outcome. Especially for the neural network we can see the smooth color gradient that transitions from blue to red indicating that the positive relationship is nearly monotonous. For the random forest and XGBoost model, some mixed colors are visible around the SHAP value of 0. The categorical feature, sex, clearly shows a negative relationship for all three models. The beeswarm plot doesn't show a clear trend for AlcoholYear or PhysActiveDays, especially for the random forest model and neural network.

We considered XGBoost, random forest, and a neural network model as classification models and trained them using the breast cancer diagnostic dataset. In Figure S1, we can see the different visualization plots for the SHAP values for explaining the predicted probabilities for the different models. We can see that XGBoost and random forest ranked the different features according to the mean absolute SHAP value very similarly. This contrasts with the neural network model that only has positive mean absolute SHAP values for three features: area, perimeter, and texture. XGBoost and random forest have better and similar classification metrics in comparison to the neural network model (See Table S2 for accuracy metrics for all classification models). The beeswarm plots of XGBoost and random forest indicate a positive relationship for concave points, area, texture, and concavity. The feature perimeter has a negative relationship in the neural network model compared to random forest.

Visualizations plots for SHAP values of different ML regression models; (a,c,e) Bar plots; (b,d,f) Beeswarm plots.

## Section: EXAMPLES › Common statistical frameworks › Linear regression

We first simulate 2000 observations from a linear model (3) by considering two predictors x1 and x2 that follow an uniform distribution, that is, x1,x2~U0,10:

where b0=−10, b1=6 and b2=−3.

Now we assume the data generation process to be unknown and fit the generated data using a linear regression model.

For a linear regression model with no interaction terms, such as the one presented here, it can be shown that SHAP values for feature xj correspond to

where bj is its corresponding linear coefficent and Exj corresponds to the expected sample mean of the corresponding feature. The derivation of this formula can be found in Chapter 7 of the book by Christopher Molnar. 38

When considering the in‐silico dataset we obtain Ex1 = 5.05 and Ex2 = 4.99 for the test dataset which are close to the theoretical mean of 5 of the underlying distribution. Based on the conditions used to simulate the in‐silico data, the SHAP values for a pair of model features x1x2 are:

By considering kernelSHAP for estimating the SHAP values of this model, we can observe that the SHAP values are described by these formulas. In Figure S2, we show the different visualization plots that were considered for the SHAP values of this particular model. The bar plot in Figure S2A shows that the feature x1 has a higher mean absolute SHAP value than feature x2, as expected. Therefore, we can see that measuring the feature importance, based on the mean absolute SHAP values, matches to the intepretation that we can perform on this linear regression model.

When analyzing the beeswarm plot in Figure S2B, we can observe the general trends of the SHAP values for the two features of the linear regression model. The distribution of the SHAP values corresponding to the feature x1 has a wider spread compared to the distribution of the SHAP values of feature x2. This is expected since the absolute value of b1 is twice the absolute value of b2. Furthermore, in the beeswarm plot, we can observe there is a monotonous increasing relationship between feature x1 and its SHAP values (blue to red) and a decreasing negative relationship between feature x2 and its SHAP values (red to blue).

When inspecting the scatter plots for each feature (Figure S2C,D), we can see that the SHAP values for features x1 and x2 follow the formulas given in Formula 5. The waterfall plots of Figure S2E,F for two particular instances satisfy the formula given in Formula 4. Figure S2E shows that the feature values for this sample are x1=7.05 and x2=0.614. The SHAP value corresponding to feature x1 is 11.07 which means that this feature increases the prediction fxi in comparison to the average prediction. Feature x2 increases the prediction with a SHAP value of 12.55. Finally, the predicted value for this specific sample is fxi = 6.839 + 11.07 + 12.55 = 30.459.

## Section: EXAMPLES › Common statistical frameworks › Logistic regression

We first simulate data from a logistic regression model by considering two predictors x1 and x2 that follow a uniform distribution, that is, x1,x2~U0,10, we then define a linear model:

where b0=10, b1=2 and b2=−6. We then consider the transformation to the probability space

Using these probabilities we perform 2000 Bernoulli samples, that is, x1,ix2,iyii=12000 where yi is the outcome of Bernoulli trials considering the probabily pi given by Formula 7.

We fit the resultant data using a logistic regression model and the estimated parameters match those of the model used to generate the data. Figure S3 illustrates the different visualization plots of SHAP values from a logistic regression, explaining the predicted probabilities and the predicted log‐odds, side by side.

When comparing the bar plots we can see that feature x2 has a higher mean absolute SHAP value in comparison to feature x1 which signifies that feature x2 is a more influential feature than feature x1 (Figure S3A,B). This intepretation can also obtained in the classical way when inspecting the coefficient of features x1 and x2.

When comparing the beeswarm plots of the SHAP values of the logistic regression model, we can observe a non‐uniform distribution for the SHAP values when explaining the predicted probabilities. This is in contrast to the uniform distribution of the SHAP values for both feature x1 and x2 when explaining the predicted log‐odds. These observations can be seen in Figure S3C,D.

If we inspect the scatter plots for feature x2, we notice that when explaining the predicted probabilities the relationship between the features and the SHAP values is non‐linear (Figure S3E). When explaining the predicted log‐odds, the relationship is linear (Figure S3F) as expected.

Generally, we also observe that the different visualization plots for the SHAP values of the predicted log‐odds are similar to the visualization plots for the SHAP values of the linear regression. This is expected since in the log‐odds scale the predictors follow a linear regression model.

## Section: FINAL REMARKS

In this tutorial, we provided a brief overview of the theoretical background of SHAP analysis, including Shapley values and their connection to SHAP analysis. We discussed the implementation and practical considerations of SHAP analysis, including visualization plots, special considerations for classification and time‐series models, and available software. We showed the application of SHAP analysis to standard interpretable models and popular ML frameworks, both for regression and classification problems, as well as time‐dependent models. We conclude by summarizing the limitations and potential extensions of this widely used technique.

While SHAP analysis is a powerful feature‐based interpretability technique with numerous benefits, it is important to acknowledge its limitations and explore extensions for a comprehensive interpretability analysis of a ML model. Although the SHAP method does not assume feature independence, some of the approximation methods used to calculate the SHAP values (e.g., kernelSHAP) do assume it. In almost any real application this will not be the case, therefore, the reader needs to be careful when including features that are strongly correlated. A pre‐processing step of analyzing the data and being aware of this situation can help to avoid situations where the model gives inaccurate predictions or give predictions that are at odds with domain knowledge of the topic. For both regression and classification problems, we performed this pre‐processing step. For the regression models, we did not include weight or height as predictors since we included BMI as a predictor. For the classification models in the original dataset, the dataset for each breast mass' characteristics included the mean, standard deviation, highest and lowest values, and we only considered the mean values as predictors. An extension of kernelSHAP has recently been introduced 39 that takes into account the correlation between features. A Python package based on this extension was recently released 40 as well as an R package. 41 Feature engineering and selection can also help address the issue beforehand, enabling the use of the standard methodology. Other SHAP approximation methods like TreeSHAP explicitly consider feature dependence within the model structure.

Another limitation worth mentioning is that SHAP analysis does not quantify the importance of predictors in the real‐world problem, but rather their importance to the model's predictions. SHAP values do not show how the features contribute to the observations, but rather how the features contribute to the models' predictions for the observations. Especially in the presence of model bias or in case of overfitting, this difference is important and should always be considered when interpreting SHAP values.

In this tutorial, we focused on SHAP analysis for supervised ML models that considered tabular data. However, SHAP analysis can also be applied to other ML models 42 , 43 relevant in drug development and one can also consider other type of data (e.g., electrocardiogram data, 44 MRI data 45 ). A deeper dive into these other topics is necessary to understand the special considerations that need to be taken into account in each case. Also, this tutorial mostly focused on SHAP analysis; however, there exist other feature‐based explainability methods with advantages and disadvantages in comparison to SHAP analysis such as LIME, 46 integrated gradients, 47 and permutation feature importance. 48 Considering these alternatives may be worthwhile to address some of the SHAP limitations. Also, as the authors in Imrie et al. 19 mentioned, ML interpretability has mostly focused on feature‐based models; however, to fully understand a black‐box model and provide explanations to the different stakeholders in clinical pharmacology, it is also important to embrace and combine other types of model‐agnostic interpretation methods. In this tutorial, we also showed an example of how to perform SHAP analysis on a time‐dependent ML model. However, there are several limitations to this approach. First, aggregating SHAP values over multiple time points can result in the loss of temporal information. Additionally, understanding the time‐dependent impact of a feature can be difficult as its importance may vary over time. For the specific example shown, the SHAP values might not accurately capture the internal mechanisms of LSTM models, which are used to handle temporal dependencies. When considering feature engineering to account for time dependence, the chosen approach may not effectively capture time dynamics. Nevertheless, recent advancements have introduced new methodologies that incorporate the time‐dependent structure 49 , 50 into the SHAP calculation. In particular, there are new packages available for SHAP calculation for deriving time‐dependent explanation of ML survival models. 42

The use of ML models in drug development is expected to continue growing and to become an integral part of this industry. In light of this, it is important to adopt ML interpretability methods to enhance the transparency and trustworthiness of black‐box model predictions. This tutorial aims to offer a small yet meaningful step toward addressing this objective.

## Section: FUNDING INFORMATION

This study was funded by AbbVie, Inc. AbbVie contributed to the study design, research, and interpretation of data, and the writing, reviewing, and approving of the publication.

## Section: CONFLICT OF INTEREST STATEMENT

All authors are employees of AbbVie and may hold AbbVie stock.

## Section: Supporting information

Data S1:

Data S2:

Data S3:

## Section: ACKNOWLEDGMENTS

Medical writing support was provided by Wesley Wayman, PhD, an employee of AbbVie.

## Section: Text

Ponce‐Bobadilla AV, Schmitt V, Maier CS, Mensing S, Stodtmann S. Practical guide to SHAP analysis: Explaining supervised machine learning model predictions in drug development. Clin Transl Sci. 2024;17:e70056. doi: 10.1111/cts.70056

## Section: Associated Data

Data S1:

Data S2:

Data S3:

## Section: Associated Data › Supplementary Materials

Data S1:

Data S2:

Data S3:


---

# Predicting pharmacodynamic effects through early drug discovery with artificial intelligence-physiologically based pharmacokinetic (AI-PBPK) modelling

- **Authors:** Keheng Wu, Xue Li, Zhou Zhou, Youni Zhao, Mei Su, Zhuo Cheng, Xinyi Wu, Zhijun Huang, Xiong Jin, Jingxi Li, Mengjun Zhang, Jack Liu, Bo Liu
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2024-02-16
- **Language:** en
- **DOI:** 10.3389/fphar.2024.1330855
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38434709/
- **Licence:** CC-BY

## Section: Abstract

AbstractA mechanism-based pharmacokinetic/pharmacodynamic (PK/PD) model links the concentration-time profile of a drug with its therapeutic effects based on the underlying biological or physiological processes. Clinical endpoints play a pivotal role in drug development. Despite the substantial time and effort invested in screening drugs for favourable pharmacokinetic (PK) properties, they may not consistently yield optimal clinical outcomes. Furthermore, in the virtual compound screening phase, researchers cannot observe clinical outcomes in humans directly. These uncertainties prolong the process of drug development. As incorporation of Artificial Intelligence (AI) into the physiologically based pharmacokinetic/pharmacodynamic (PBPK) model can assist in forecasting pharmacodynamic (PD) effects within the human body, we introduce a methodology for utilizing the AI-PBPK platform to predict the PK and PD outcomes of target compounds in the early drug discovery stage. In this integrated platform, machine learning is used to predict the parameters for the model, and the mechanism-based PD model is used to predict the PD outcome through the PK results. This platform enables researchers to align the PK profile of a drug with desired PD effects at the early drug discovery stage. Case studies are presented to assess and compare five potassium-competitive acid blocker (P-CAB) compounds, after calibration and verification using vonoprazan and revaprazan.Keywords: artificial intelligence (AI), machine learning (ML), early drug discovery, PBPK modeling, PD modeling, P-CABs

## Section: 1 Introduction

Drug discovery and development is a long and intricate process. It begins with identifying a biological target that can be affected by a drug to change disease progression. After validating this target, methods like virtual screening or high throughput screening (HTS) are used to screen through vast compound libraries, pinpointing ‘hits’ that show some activity. These hits are then refined into ‘lead’ compounds. These optimized leads are tested in vitro and on animals for safety and effectiveness checking. Essentially, drug development follows a process of broad to fine screening. We are now using the AI-PBPK platform to optimize the screening process from virtual compounds to candidate. The platform predicts ADME (Absorption, Distribution, Metabolism, Excretion) and physicochemical characters of the compound, and continuously predicts the human PK and PD outcomes of the drug candidate. Implementing this methodology in the discovery process could bring the clinical end points earlier and potentially lead to the identification of high-quality drug candidates earlier, ultimately reducing the timeline from target discovery to candidate selection.

PBPK modelling has become an essential component in the process of drug discovery and development. Within these models, established physiological characteristics and the ADME properties of a compound are incorporated into mathematical equations to predict drug behaviour in human body. The computational method involving model-based pharmacology evaluation was employed to determine the best range of PK, ADME and physicochemical characteristics for a specific target (Chen EP and Michalski, 2021). As a web-based platform, B2O simulator® integrated PBPK models to predict drug exposure, potential interactions with other drugs and the likelihood of been bioequivalent with reference compound (Zhang et al., 2021a; Zhang et al., 2021b; Li et al., 2022; Li J et al., 2022; Zhang J et al., 2023). In those studies, drug related physicochemical parameters were searched online or calculated. Various computational techniques have been established for determining key parameters, including permeability (Paudel et al., 2023). When employing quantitative techniques to develop predictive models, the models could serve different purposes. For example, quantitative structure—toxicity relationship (QSTR) models were used for toxicity prediction based on chemical structure (Rai et al., 2023), whereas PK models were used to understand and predict the pharmacokinetic profile of drugs in the body.

In the current study, the B2O simulator integrated the PD model, PBPK and AI related algorithms into one platform. Machine learning (ML) methods, as a subset of AI, are used to predict the ADME and other physiochemical properties. As a specific type of machine learning algorithm, Graph Neural Networks (GNNs) is used in this study to analyse chemical structures and to perform predication on structures’ PK parameters. Another algorithmic approach used in the study was random forest model. The platform employs the m5p random forest model, a decision tree-based regression method, for modelling parameters like apparent clearance (CLapp) (Alex A Freits and Ghafourian, 2015). Other global features such as logP, were calculated using the “CalcCripppenDescriptors” function in the RDKit cheminformatics toolkit. PKa was calculated using the open-source Dimorphit-DL (Ropp et al., 2019). The workflow for predicting the PK and PD outcomes of a compound using the AI-PBPK platform is shown in Figure 1. Examples such as potassium-competitive acid blocker (P-CAB) drugs were used to demonstrate the utility and benefits of this method in guiding early discovery studies. The process involved using the molecular structure and potency data of vonoprazan to calibrate its PK and PD outcomes against observed results. Following this calibration, the model underwent validation using revaprazan, another compound in the P-CABs class. Subsequently, the PK and PD outcomes for five different P-CABs were predicted and compared to identify the most promising candidate.

The PD model was adapted from a mechanism-based model developed by Kong et al., 2020 and Jia et al., 2021. It was indicated that a significant proportion (52%) of drug failure in clinical trials was due to poor efficacy from available data (Kiriiri et al., 2020). To prevent subsequent setbacks, it is crucial to identify and validate the target, confirming its significance in early discovery stage. “The proportion of time with a gastric pH > 4 over a 24-h period” is the endpoint in clinical studies of P-CAB drugs. P-CABs are designed to inhibit gastric acid secretion. The gastric pH level is a direct measure of acidity in the stomach. A pH greater than 4 indicates a reduction in gastric acidity. This endpoint can be predicted using mechanism-based pharmacokinetic (PK) and pharmacodynamic (PD) models. For P-CABs, PK modelling can predict the concentration of the drug in the bloodstream. It is helpful to understand the drug’s availability in the body, which is directly related to its efficacy. PD models are used to predict how changes in drug concentration affect gastric acid secretion and the gastric pH levels. The model considers the drug’s mechanism of action, such as how the P-CAB drugs inhibit acid secretion by blocking the H+/K + -ATPase (proton pump) in the stomach lining, which directly affects gastric acidity, and thus pH levels.

Workflow for predicting the PK and PD outcomes of a compound using AI-PBPK platform.

## Section: 2 Methods › 2.1 PBPK/PD modelling

The whole-body PBPK model, designed to predict plasma concentration of vonoprazan and other P-CABs PK profiles at different does, was based on two studies reported by (Thierry Wendling et al., 2015a; Thierry Wendling et al., 2015b). The model comprised 14 tissue compartments including lungs, hearts, brain, muscle, adipose, skin, spleen, pancreas, liver, stomach, gut, bones, kidneys and rest-of-body and 2 blood compartments (arterial and mixed venous). Each tissue compartment is assumed well-stirred, with the extent of distribution being characterised by the equilibrium tissue: blood partition coefficient (Kp). The rate equation for the tissue compartments can be expressed as follows (Eq. 1):

Where AT is the drug amount (μg), VT is the volume (L) and QT is the blood flow (L/h) for the different tissues, and AVEN/ART and VVEN/ART are the amount (μg) and volume (L), respectively, of either mixed venous blood or arterial blood for all other tissues. Drug elimination is assumed to occur entirely in the liver compartment via oxidative metabolism (Thierry Wendling et al., 2015a). The PBPK model was integrated into the B2O platform. Subsequently, the PD model was also integrated and described the correlation between the plasma concentration of vonoprazan and the intra-gastric pH levels.

In the PD model, the antisecretory effects of the drug I, which also represented the increase pH, was calculated using the formula (Eq. 2):

where dI/dt is the rate of change of the drug’s antisecretory, which is also the rate of change of pH over time. Imax is the maximum possible antisecretory effect (or maximum pH level) the drug can achieve. K is the binding rate constant using the ration of kd to ki. Ki is the inhibition index. Ce is the free drug concentration in the stomach and kd is the irreversible inhibition efficacy of H+/K+—ATPase. E/E0 in Graphic abstract equalls to (1-I). Ce is calculated from the following formula (Eq. 3):

where AGU is the amount of drug in gut and Volume of gut. Kp is the Tissue gut: plasma partition coefficient. Kp_scaler adjusted all Kp values in equal proportions. Bpr is the blood to plasma ratio and fub is unbound to plasma proteins in the bloodstream.

## Section: 2 Methods › 2.2 Graph neural networks

As a type of GNN model, The Message Passing Neural Network (MPNN) model was used following the work developed by (Gilmer et al., 2017; Jose Jimenez-Luna et al., 2021). The MPNN model operates on undirected graphs composed of vertexes (v) and edges (e) (Gilmer et al., 2017). It’s particularly useful for predicting molecular properties. The next two steps provide a simplified explanation of how the MPNN operates:

Here, w∈N(v) denotes the neighbour vertexes of each vertex v in the graph.

These functions (Mt, Ut, R) are learned differentiable functions (Gilmer et al., 2017).

To train an MPNN model, one commonly employs a version of stochastic gradient descent. During this process, the model is trained to identify underlying structural traits of molecules and to predict molecular characteristics by minimizing the difference between its predictions and the actual values. This study highlights the application of MPNN models in clarifying the relationship between molecular structures and their properties, with a reference to the studies conducted by Jose Jimenez-Luna et al., 2021. In this example, all molecular structures were converted into graph representations using the Python DGL package. Additionally, 2D features produced by RDkit were integrated, similar approach was also used in random forest model. Parameters such as plasma protein binding rate (ppbr, data size: 4637, best fold R 2 = 0.551), blood to plasma ratio (bpr, data size: 461; best fold R 2 = 0.107), Volume of distribution (Vss, data size: 1305, best fold R 2 = 0.413) and Caco-2 Permeability (Papp, data size: 525, best fold R 2 = 0.412) were predicted. Permeability in Caco-2 cells was used to calculate Fa, the fraction absorbed. The model of the best fold was chosen for the AI-PBPK model.

## Section: 2 Methods › 2.3 Random forest (tree model) models

The m5p random forest model consists of an ensemble of m5p trees, which are decision trees that use linear regression functions at the leaf nodes instead of constant values. The m5p random forest model works by randomly selecting a subset of features and a subset of instances for each tree, and then building the tree using the m5p algorithm. The m5p algorithm splits the instances based on the feature that minimizes the variance of the linear regression functions at the child nodes. The final prediction of the m5p random forest model is obtained averaging the predictions of all the trees in the ensemble. More details of how the algorithm trains a model and performs prediction were addressed in Freitas’s original work (Alex A Freits and Ghafourian, 2015). After design and coding, data was trained for Clapp model. The Clapp dataset was split into 10 folds, each were successively deemed as validation set in each turn and the rest 9 folds were deemed as a training set. The mean absolute error (MAE) was chosen as the indicator to show the performance of the model trained by the training set of each turn. The smallest MAE of all turns described how well the model fits the training data and predicts external data and helped to choose the best Clapp model to be added to the AI-PBPK model. Parameters such as apparent clearance CLapp (data size: 98, best fold R 2 = 0.388, internal R 2 = 0.7996) was predicted using this model.

## Section: 2 Methods › 2.4 Data source of machine learning

Five ADME parameters were modelled by machine learning. They are the fraction of the drug that is unbound to plasma proteins in the bloodstream (fup; fup = 1-ppbr), steady state volume of distribution vss_perKg, apparent clearance Clapp (Clapp = vss*0.693/half-life), gastrointestinal absorption constant (gi_ka; gi_ka = 2*Papp/radius of small intestine) and blood to plasma ratio (bpr). The radius of small intestine is 1.25 cm according to its 2.5 cm diameter (Herbert and Helander, 2014). The data for the first 4 parameters were collected from the Therapeutics Data Commons (TDC) database. Its Python package named “PYTDC” was installed, and the correspondent datasets were used in this package:

Additionally, the bpr data were from the Mamada’s work (Hideaki Mamada et al., 2021). All 5 datasets were composed of 2 vectors with same lengths. One of them was their molecular structure displayed in SMAILES codes, and the other was the correspondent ADME parameter values for each molecule.

## Section: 2 Methods › 2.5 Design of simulation studies

When the PBPK/PD model was established, and the needed parameters were collected or generated by machine learning models, the PK and gastric pH profiles were simulated for each drug for a 48—hour duration after 20 mg single oral dose.

## Section: 2 Methods › 2.6 Case study: potassium-competitive acid blocker drugs to reduce the production of stomach acid

As one of the most well-known examples of P-CAB drugs, vonoprazan has gained global recognition to treat conditions related to stomach acid, such as gastroesophageal reflux disease (GERD) and peptic ulcers. Its primary target is the H+/K+ ATPase enzyme. Known as the proton pump, the enzyme is located in the stomach lining. Vonoprazan inhibits the proton pump by binding competitively to the potassium-binding site on the pump, thus inhibiting the exchange of hydrogen ions for potassium ions. This inhibition reduces the amount of gastric acid produced and secreted into the stomach, which can help to alleviate symptoms associated with acid-related disorders. In clinical trials, the proportion of time with a gastric pH > 4 over a 24-h period is often used as a primary or secondary endpoint. Because the optimal PK required for a drug candidate to elicit efficacy is highly dependent on the targeted pharmacology (Chen EP and Michalski, 2021), PK and PD results were both analysed in the platform to avoid misguiding of compound screening and design. The study also included five other compounds which also has H+/K+ ATPase as the target.

In this study, the PK performance of vonoprazan was firstly predicted and calibrated with observations. After verification with revaprazan, the PK performance of the other five P-CAB compounds was simulated. Following that, their PD outcomes were also simulated using the AI-PBPK platform. Finally, the PK and PD results of different doses of compounds were analysed and compared, and the optimal combination of PK, PD and dose of candidate compounds was determined.

## Section: 2 Methods › 2.7 Literature search

Observed data were collected from literature search. Since vonoprazan was firstly approved in Japan in 2014, a PubMed search was conducted using “vonoprazan” AND “clinical trial” as keywords, beginning from the year 2014. Only those publications that contain comprehensive PK data from a 20 mg monotherapy of vonoprazan in healthy subjects for the first 2 days were included. Observed PD data were collected from literature search as well, with the same keywords. We only included studies that provided results on gastric pH versus time over a 24-h period from a 20 mg monotherapy of vonoprazan in healthy subjects (fasting condition).

## Section: 2 Methods › 2.8 Software

The PBPK model was implemented using the software B2O simulator, a web-based platform, to predict drug exposures. With lower and upper CI% (Confidence Interval) limits 2.5%–97.5%, the geometric mean of the maximum serum concentration that a drug achieves in the body (Cmax) and the area under the curve (AUC) were calculated, and ratios between geometric means were calculated and compared with the observations from clinical studies. Changes bigger than or equal to 2-fold were considered significant.

## Section: 2 Methods › 2.9 Statistical analyses

Pearson’s correlation coefficient (r) is a statistical measure that express the extent of the correlation between two variables. The correlation coefficient was calculated using R version 4.3.0.

Local sensitivities of the following 17 parameters predicted by the machine learning models were analysed. They were fup, bpr, gi_ka, clapp, vss_perKg, kp_bone, kp_brain, kp_adipose, kp_heart, kp_kidney, kp_gut, kp_liver, kp_lung, kp_muscle, kp_skin, kp_spleen, kp_scaler. Kp represents the tissue: plasma partition coefficient. Each of them was tuned ±1% from their predicted value, and the percent change of AUC and Cmax values of revaprazan in response to an average 1% change in each parameter were studied and compared.

## Section: 3 Results

Simulation results of vonoprazan: (A) Plasma concentration versus time and comparisons with observations from studies A (Kentaro, 2018), B (Tack et al., 2023), C (Jenkins et al., 2015), D (Mulford DJ et al., 2022) and E (Jenkins and Patat, 2017), before and after calibration (adjustment); (B) Logarithm of simulated vonoprazan plasma concentration versus time before and after calibration (adjustment); (C) Concentration in the stomach after calibration.

Predicted parameters for vonoprazan.

Comparison of simulated PK results before and after adjustment.

Simulated (solid lines with colours) and observed plasma concentration (dashed lines with colures) of revaprazan after calibration.

Predicted and observed data of revaprazan after oral administration 200 mg.

Input parameters for the prediction of PD outcomes.

Simulated gastric pH over 24 h, comparing to observations from Studies A (Sakurai Y et al., 2015), B (Laine et al., 2022) and C (Suzuki et al., 2018), after calibration.

Simulation of five P-CAB compounds of (A) Plasma concentration versus time; (B) Gastric pH over 24 h after orally administration.

Simulated pH > 4 holding time percentage and time of onset of P-CAB compounds under dose of 20 mg.

PH > 4 holding time percentage % of different compounds under different doses.

The onset time of different compounds under different doses.

## Section: 3 Results › 3.1 Simulation, calibration and verification of PK behaviour

Simulation results of vonoprazan: (A) Plasma concentration versus time and comparisons with observations from studies A (Kentaro, 2018), B (Tack et al., 2023), C (Jenkins et al., 2015), D (Mulford DJ et al., 2022) and E (Jenkins and Patat, 2017), before and after calibration (adjustment); (B) Logarithm of simulated vonoprazan plasma concentration versus time before and after calibration (adjustment); (C) Concentration in the stomach after calibration.

Predicted parameters for vonoprazan.

Comparison of simulated PK results before and after adjustment.

Simulated (solid lines with colours) and observed plasma concentration (dashed lines with colures) of revaprazan after calibration.

Predicted and observed data of revaprazan after oral administration 200 mg.

## Section: 3 Results › 3.1 Simulation, calibration and verification of PK behaviour › 3.1.1 Simulation of vonoprazan PK performance

The SMILES code for vonoprazan is CNCC1 = CN(C (=C1)C2 = CC = CC = C2F)S (=O)(=O)C3 = CN = CC = C3. When the SMILES code was entered into the AI-PBPK platform, the plasma concentration of vonoprazan was simulated and the result is shown in Figure 2A (solid black line). The predicted parameters including ADME and physicochemical properties, are listed in Table 1. The Kp scaler adjusted all Kp values in equal proportions. Its size varied based on the predicted vss_per Kg. The outcomes from the simulation were compared with the observed results. After literature search, PK data observed from five clinical studies were chosen, and their values were used for comparison with the simulation outcomes, as described in Figure 2A. From the figure we can see that the simulated drug exposure, which is represented by the area under the curve in the plasma concentration versus time plot, was greater than the values corresponding to the average observed exposure.

Simulation results of vonoprazan: (A) Plasma concentration versus time and comparisons with observations from studies A (Kentaro, 2018), B (Tack et al., 2023), C (Jenkins et al., 2015), D (Mulford DJ et al., 2022) and E (Jenkins and Patat, 2017), before and after calibration (adjustment); (B) Logarithm of simulated vonoprazan plasma concentration versus time before and after calibration (adjustment); (C) Concentration in the stomach after calibration.

Predicted parameters for vonoprazan.

## Section: 3 Results › 3.1 Simulation, calibration and verification of PK behaviour › 3.1.2 Calibration with vonoprazan PK performance

In this case, the terminal half-life, which represents the elimination of drug, should be adjusted. In order to determine the extent of reduction needed, the log of plasma concentration versus time for both simulated and observed results are plotted in Figure 2B. Since the slope of the logarithmic curve represents the terminal half-life and the slope of the predicted log curve was about 3.08 times that of the observed curve, the initial simulation leads to a much quicker absorption. In this case, the drug absorption fraction Fa, was adjusted to be half of its original predicted value. Simultaneously, the elimination CLapp was adjusted 3.08 times bigger and the absorption rate (gi_ka) was adjusted 3.5 times smaller. The PK outcomes before and after adjustment are listed in Table 2, and the predicted results following parameter adjustment are also shown in Figure 2A.

Comparison of simulated PK results before and after adjustment.

## Section: 3 Results › 3.1 Simulation, calibration and verification of PK behaviour › 3.1.3 Mode verification with revaprazan

After calibration, the predictive capacity of the platform was further validated by inputting the chemical structure of revaprazan, which also has P-CAB target. The predicted PK outcomes were compared with observed results (Kim et al., 2010), as described in Figure 3. Three different doses (100 mg, 150 mg, and 200 mg) were used and the results on days 1 and 7 were compared. The predicted and observed data of revaprazan after orally taken 200 mg on days 1 and 7 are listed in Table 3. All the outcomes were simulated based on one virtual healthy subject. From the table we can see that the predicted PK results are within two times of the observed results. The Pearson’s correlation coefficient (r) was calculated for all time points of the predicted and observed PK data of revaprazan at doses of 100 mg, 150 mg and 200 mg. As a result, the correlation coefficient was 0.8404, 0.8862, and 0.8754 respectively. The analysis results indicated that the model reasonably predicted drug exposure. In the early stages of drug discovery, using a model based on one single virtual healthy subject can provide a baseline understanding of how a typical healthy body might respond to the drug, which is useful for initial screening. Moreover, at this early stage, accurately defining the disease population remains challenging. The presence of disease could introduce considerable inter-variability of patients into the PBPK models, making it difficult to model multiple subjects in the early stage of drug discovery.

Because it is believed that the concentration of vonoprazan in the stomach is different from the plasma concentration and could be 1000 times higher than the concentration in plasma 24 h after administration to humans (Kong et al., 2020), we simultaneously predicted the concentration of vonoprazan in the stomach, as shown in Figure 2C. Comparing to the plasma concentration, the peak concentration in the stomach was around 524 ng/mL, which was 23.8 times higher than plasma concentration in Figure 2A.

Simulated (solid lines with colours) and observed plasma concentration (dashed lines with colures) of revaprazan after calibration.

Predicted and observed data of revaprazan after oral administration 200 mg.

## Section: 3 Results › 3.1 Simulation, calibration and verification of PK behaviour › 3.1.4 Sensitivity analysis

The results of sensitivity analysis demonstrated that the most sensitive parameter that influenced the AUC and Cmax of PK prediction was bpr, which caused almost 1.5% change in Cmax and 1% change in AUC when it was changed by 1%. Moreover, CLapp caused approximately 1% opposite change in AUC when it was changed by 1%. The remaining parameters showed minimal sensitivity to PK predictions, as a local 1% alteration in their values results in less than 0.5% change, indicating they did not significantly influence the prediction.

## Section: 3 Results › 3.2 Simulation, calibration and verification of PD outcomes

Input parameters for the prediction of PD outcomes.

Simulated gastric pH over 24 h, comparing to observations from Studies A (Sakurai Y et al., 2015), B (Laine et al., 2022) and C (Suzuki et al., 2018), after calibration.

## Section: 3 Results › 3.2 Simulation, calibration and verification of PD outcomes › 3.2.1 Simulation and calibration of vonoprazan PD outcomes

When assessing acid-suppressing drug like P-CABs, maintaining a gastric pH greater than 4 for as much of a 24-h period as possible is often a critical PD endpoint. This is because a gastric pH above 4 is generally considered as the necessary threshold to prevent symptoms associated with acid-related disorders. To assess the PD results of vonoprazan, potency related parameters like IC50 (half maximal inhibitory concentration), Ki (the inhibition constant), and other pharmacological parameters such as Dissociation half-life (residence time), Kd (dissociation constant) and K (binding rate constant for the reaction between the drug and its target, Kd/Ki) were searched and calculated from literatures and the values are listed in Table 4. Vonoprazan and KFP_H008 showed relatively low IC50 values as 0.019 and 0.029 μM respectively, indicating higher potency of the compounds to inhibit gastric acid secretion. Revaprazan had the highest IC50 value as 1 μM. The time required for half the dose of drug administered to be removed from the body (t1/2) of dissociation of TAK-438 binding was 4.7 h. This value was employed for other P-CAB compounds because there was no available data from literature search. Kd was calculated from (ln (2)/dissociation half-life) and K was the binding rate constant using the ration of Kd to Ki

Using parameters sourced from literatures, the gastric pH of subjects after oral administration of vonoprazan was simulated. The outcomes from the simulation were compared with the observed results. Gastric pH is affected by the local concentration of proton pumps. Proton pumps, which is also known as H+/K+ ATPase enzymes, are present in the parietal cells of the stomach lining. Since proton pumps are responsible for the production of stomach acid, drugs like P-CABs are taken orally to inhibit these pumps, thereby reducing the secretion of stomach acid. The gastrointestinal concentration of drug doesn’t equal to the local concentration of the proton pump. As such, an enrichment coefficient for the drug, with a value of intersys = 1 × 103, was introduced to the free vonoprazan concentration Ce in the stomach. After calibration, the predicted outcomes, together with observed results are shown in Figure 4. The predicted time percentage with a pH > 4 for vonoprazan was 88.88%. This was within a 1.5-fold variance compared to the mean of the clinical observations A-C (Sakurai Y et al., 2015; Suzuki et al., 2018; Laine et al., 2022), which averaged at 76.4%.

Input parameters for the prediction of PD outcomes.

Simulated gastric pH over 24 h, comparing to observations from Studies A (Sakurai Y et al., 2015), B (Laine et al., 2022) and C (Suzuki et al., 2018), after calibration.

## Section: 3 Results › 3.2 Simulation, calibration and verification of PD outcomes › 3.2.2 Model verification with revaprazan

The ability of the platform to predict PD results was further verified by revaprazan with potency and relevant parameters. The predicted gastric pHs were compared with observed results. When revaprazan was administered orally at a dose of 200 mg, the predicted duration with a pH > 4 was 57.1%. This was within a 1.5-fold variance from the study observation, which recorded a value of 42.2% (Kim et al., 2010). The predicted onset time to reach pH 4.5 was 4 h. The observed time for intragastric pH to reach 4.5 was withing 2 h (Kim et al., 2010). All the predicted results indicate a reliable predictive capacity of the platform for revaprazan.

## Section: 3 Results › 3.3 Prediction of PK and PD outcomes of other P-CAB compounds under the same dose

The PK and PD outcomes of the other five compounds were simulated under the same dose of 20 mg, which is the same to vonoprazan. Having P-CAB as the target, all the chemical structures were searched from literatures. Their names and SMILES codes are listed in Table 4.

The comparison of predicted plasma concentration is shown in Figure 5A. From the results we can see that the five compounds showed similar plasma profiles with compound-2 having the highest concentration in around 2 hours, followed by compound-1. The simulated gastric pH versus time was compared and showed in Figure 5B. As mentioned above, pH > 4 holding time percentage is an important clinical indicator of P-CAB drug in the clinical development of Gastroesophageal Reflux Disease (GERD) and peptic ulcer and pH > 4 helps avoid irritation of the esophagus or ulcer by stomach acid. The shorter the onset of action, the faster the effect of the drug in relieving symptoms. From the figure we can see that within 24 h, all compounds showed fluctuating gastric pH around pH 4. A similar pH fluctuation was observed following the oral administration of vonoprazan, although vonoprazan exhibited a higher gastric pH value. The results of the 24-h time percentage and onset time for pH > 4 are summarized in Table 5. Combining the two major indicators, the simulation found that among the five compounds, KFP_H008 had the best percentage pH > 4 holding time with relatively short onset time, which were 81.17% and 0.99 h respectively. When compared to vonoprazan, KFP_H008 demonstrated close PD outcomes in terms of pH > 4 hold time and time of onset and showed promise for further development.

Simulation of five P-CAB compounds of (A) Plasma concentration versus time; (B) Gastric pH over 24 h after orally administration.

Simulated pH > 4 holding time percentage and time of onset of P-CAB compounds under dose of 20 mg.

## Section: 3 Results › 3.4 Prediction of PK and PD outcomes of other P-CAB compounds at different doses

The PD efficacy of different compounds at different doses were simulated to compare the development potential of the compounds. We compared gastric pH changes for different compounds at 10 mg, 20 mg, 40 mg, 80 mg, 160 mg, and 400 mg. With an increase in the dose from 10 to 400 mg, the pH > 4 holding time of most compounds increased. Starting with a dose of 20 mg, the percentage holding time of the KFP_H008 fluctuated from 80% to 90%. The results of pH > 4 holding time and the time of onset are summarised in Tables 6 and 7. Comparing to other compounds, KFP_H008 maintained the pH > 4 for the longest duration and had a comparatively faster onset time among all the doses, starting from 10 mg.

PH > 4 holding time percentage % of different compounds under different doses.

The onset time of different compounds under different doses.

## Section: 4 Discussion

It is believed that predicting PD, such as pH over time, using the AI-PBPK/PD model is more effective than predicting PK to accelerate the screening of compounds in the drug development stage. Since the primary interest in drug development is the therapeutic effect of drug, predicting the PD allows for a direct understanding of whether a compound is likely to have the desired therapeutic effect or not, and can streamline the compound screening process.

In the current study, ML algorithms are used to estimate model parameter. RDKit package in Pthyon is a cheminformatics library and it is specially designed for the analysis of chemical data. It can read various chemical file formats and represent molecular structures programmatically. And the RDKit compute a wide range of molecular descriptors and features such as molecular weight, log P, and hydrogen bond donors/acceptors. In DGL package, molecules can be represented as graphs, where atoms are nodes, and bonds are edges. It is powerful in learning the patterns and relationships in graph data. Coded and defined by DGL, GNNs can learn complex relationships between atom in molecule, which can be crucial for understanding tis properties and behaviour. Using DGL, the features extracted by RDKit can be integrated into the graph model. This allows the GNN to consider detailed chemical information while making predictions. This combination allows for a more holistic analysis of chemical compounds, considering both of their structural features and the complex interatomic relationships. High-quality, accurate, and well-annotated data is essential for training reliable predictive models.

Using ML or AI in drug development process is an important part of pharmaceutical companies’ strategies. Comparing to totally new drug development, “fast follow” study is based on a substantial data available from the pioneering drug, including its structure, model of action, therapeutic target, and clinical trial results. These data can provide a solid foundation for training machine learning models, potentially leading to more accurate predictions for new compounds. However, integrating AI with PBPK models presents numerous challenges and comes with its own set of limitations. Firstly, ML or AI models often require large datasets to be effective. In the current study, the majority of the parameters were predicted using data size exceeding 461, with exception of the apparent elimination rate CLapp, which was estimated using a data size of 98. Increasing the data input is necessary to enhance the accuracy of the model’s predictions of parameters. Also, the training database has not included first-in-class structures. A first-in-class medication is a pharmaceutical that uses a “new and unique mechanism of action” to treat a particular medical condition. Secondly, any improvements to the PBPK model’s predictive accuracy brought about by AI need to be rigorously validated using experimental data. Thirdly, a single virtual subject cannot represent the variability and diversity found in a real population. Upon comparing with the observed data, both the PK and PD of the model demonstrated a close match. This similarity was further evidenced by a relatively strong correlation with the observed data, as demonstrated by Pearson correlation coefficients (r values) around 0.8. This indicates that the model performed well. In the present research, the model was calibrated by using the observed data from vonoprazan. After the calibration, another external validation was used to further validate the model by testing it against data sets that were not used in the calibration. This process ensures that the model is accurate and reliable in predicting real-world outcomes.

Sharing with similar core structures, P-CABs reduce stomach acid production within a few hours of intake, and often has a long duration of action. One well-known P-CABs is vonoprazan. It has been studied and used in various countries, offering an alternative to Proton pump inhibition (PPIs), especially in cases where PPIs are not effective or suitable. While like all medications, vonoprazan can have side effects. Common side effects include diarrhoea, constipation, abdominal pain and nausea. Also, drug interactions with other medications also need to be considered carefully. Revaprazan didn't demonstrate sufficient efficacy and failed to go onto market. In pharmaceutical industry, the drugs that are chemically similar to already existing drugs are called “me too” drugs. The strategy of developing “me too” drugs is adopted by companies aiming to enter a profitable market by creating a product that is similar to a top-selling drug. In this case study, the AI-PBPK platform becomes an effective and efficient way to find out the alternative “me too” drugs to vonoprazan. The possible PD outcomes of five P-CAB compounds were simulated using the same AI-PBPK platform after verification. KFP_H008 showed a comparatively longer duration with a pH > 4 compared to the other compounds, with a percentage exceeding 80% when the dose was more than 20 mg.

IC50 and Ki are both crucial parameter in biochemistry and pharmacology, and they help in understanding the type and strength of the inhibition. For IC50, a lower value indicates higher potency, meaning less substance is needed to achieve a 50% inhibition. In Table 4 with parameter values, vonoprazan showed the lowest IC50 and Ki values, followed by KFP_H008. Comparing to the other four compounds, the lowest IC50 and Ki values of KFP_H008 consistent with the prediction results that KFP_H008 presented the longest pH > 4 holding time and a relatively short onset time at various doses. It is also worth noting that, KFP_H008 didn’t exhibit the most favourable PK properties in the simulations. In Figure 5A, compound-2 demonstrated a rapid attainment of peak plasma concentration following oral administration. Leveraging the AI-PBPK platform can aid in the identification of the optimal combination of PK, PD and doses of the high-quality drug candidates throughout the compound screening process. Among the five compounds, KFP_H008 presented the best therapeutic effects.

In summary, the platform can leverage a combination of machine learning and PBPK model to predict drug efficacy during the discovery stage. It establishes a direct link between clinical endpoints and structures that influence PK and/or PD outcomes. One of the benefits of employing AI in predicting drug parameters for PBPK models is the capability to analyse multiple drug classes, not just a single category. Currently the training database in the B2O platform included thousands of training data which covered most of the main chemical structures in drugs. Provided that appropriate calibration and validation steps are performed prior to prediction, the platform should be capable of reliable predicting PK and PD outcomes within the same category to find out the best ‘me too’ drugs. In the future, when the first-in-class drug database is created, virtual drug screening will be available to predict PK and/or PD outcomes for first-in-class drugs.

## Section: 5 Conclusion

As a simulation tool, the AI-PBPK/PD platform showed the potential to predict the desired therapeutic effects of drug candidates at the early drug discovery stage. Among the five compounds, KFP_H008 presented the best therapeutic effects, with the longest pH > 4 holding time and a relatively short onset time when administered at doses exceeding 10 mg.

## Section: Acknowledgments

We thank Dr Hongyun Wang in Peking Union Medical College Hospital for providing guidance and scientific suggestions.

## Section: Funding Statement

The author(s) declare that no financial support was received for the research, authorship, and/or publication of this article.

## Section: Data availability statement

The original contributions presented in the study are included in the article/Supplementary Material, further inquiries can be directed to the corresponding authors.

## Section: Ethics statement

Ethical approval was not required for the study involving humans in accordance with the local legislation and institutional requirements. Written informed consent to participate in this study was not required from the participants or the participants’ legal guardians/next of kin in accordance with the national legislation and the institutional requirements.

## Section: Author contributions

KW: Formal Analysis, Methodology, Software, Validation, Writing–review and editing. XL: Investigation, Writing–original draft, Writing–review and editing. ZZ: Software, Writing–review and editing. YZ: Software, Writing–review and editing. MS: Writing–review and editing. ZC: Writing–review and editing. XW: Writing–review and editing. ZH: Writing–review and editing. XJ: Data curation, Writing–review and editing. JiL: Data curation, Writing–review and editing. MZ: Writing–review and editing. JaL: Writing–review and editing. BL: Conceptualization, Project administration, Writing–review and editing.

## Section: Conflict of interest

KW, XL, ZZ, YZ, ZC, XW, ZH, and JaL were employees of the Yinghan Pharmaceutical Technology (Shanghai) at the time of study conduct. MS was the employee of the Jiangsu Carephar Pharmaceutical Co., Ltd. at the time of study conduct.

The remaining authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

## Section: Publisher’s note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

## Section: Supplementary material

The Supplementary Material for this article can be found online at: https://www.frontiersin.org/articles/10.3389/fphar.2024.1330855/full#supplementary-material

## Section: Associated Data › Data Availability Statement

The original contributions presented in the study are included in the article/Supplementary Material, further inquiries can be directed to the corresponding authors.


---

# RAGAs: Automated Evaluation of Retrieval Augmented Generation

- **Authors:** Shahul Es, Jithin James, Luis Espinosa-Anke, Steven Schockaert
- **Issuer:** Conference of the European Chapter of the Association for Computational Linguistics
- **Type:** Scientific article
- **Published:** 2024-01-01
- **Language:** en
- **DOI:** 10.18653/v1/2024.eacl-demo.16
- **Source:** https://doi.org/10.18653/v1/2024.eacl-demo.16
- **Licence:** CC-BY

## Page 1

Proceedings of the 18th Conference of the European Chapter of the Association for Computational Linguistics
System Demonstrations, pages 150–158
March 17-22, 2024 c⃝2024 Association for Computational Linguistics
RAGAS: Automated Evaluation of Retrieval Augmented Generation
Shahul Es†, Jithin James†, Luis Espinosa-Anke∗♢, Steven Schockaert∗
†Exploding Gradients
∗CardiffNLP, Cardiff University, United Kingdom
♢AMPLYFI, United Kingdom
{shahules786,jamesjithin97}@gmail.com
{espinosa-ankel,schockaerts1}@cardiff.ac.uk
Abstract
We introduce RAGAS1 (Retrieval Augmented
Generation Assessment), a framework for
reference-free evaluation of Retrieval Aug-
mented Generation (RAG) pipelines. RAG sys-
tems are composed of a retrieval module and an
LLM based generation module. They provide
LLMs with knowledge from a reference corpus,
which can help to keep LLM based systems
up-to-date and can reduce the risk of halluci-
nations, among others. However, evaluating
RAG architectures is challenging because there
are several dimensions to consider: the abil-
ity of the retrieval system to identify relevant
and focused context passages, the ability of the
LLM to exploit such passages in a faithful way,
and the quality of the generation itself. With
RAGAS, we put forward a suite of metrics
which can be used to evaluate these different
dimensions without having to rely on ground
truth human annotations. We posit that such
a framework can crucially contribute to faster
evaluation cycles of RAG architectures, which
is especially important given the fast adoption
of LLMs.
1
Introduction
Language Models (LMs) capture a vast amount
of knowledge about the world, which allows them
to answer questions without accessing any exter-
nal sources. This idea of LMs as repositories of
knowledge emerged shortly after the introduction
of BERT (Devlin et al., 2019) and became more
firmly established with the introduction of ever
larger LMs (Roberts et al., 2020). While the most
recent Large Language Models (LLMs) capture
enough knowledge to rival human performance
across a wide variety of question answering bench-
marks (Bubeck et al., 2023), the idea of using
LLMs as knowledge bases still has two fundamen-
tal limitations. First, LLMs are not able to answer
1RAGAS
is
available
at
https://github.com/
explodinggradients/ragas.
questions about events that have happened after
they were trained. Second, even the largest models
struggle to memorise knowledge that is only rarely
mentioned in the training corpus (Kandpal et al.,
2022; Mallen et al., 2023). The standard solution
to these issues is to rely on Retrieval Augmented
Generation (RAG) (Lee et al., 2019; Lewis et al.,
2020; Guu et al., 2020). Answering a question
then essentially involves retrieving relevant pas-
sages from a corpus and feeding these passages,
along with the original question, to the LM. While
initial approaches relied on specialised LMs for
retrieval-augmented language modelling (Khandel-
wal et al., 2020; Borgeaud et al., 2022), recent work
has suggested that simply adding retrieved docu-
ments to the input of a standard LM can also work
well (Khattab et al., 2022; Ram et al., 2023; Shi
et al., 2023), thus making it possible to use retrieval-
augmented strategies in combination with LLMs
that are only available through APIs.
While the usefulness of retrieval-augmented
strategies is clear, their implementation requires
a significant amount of tuning, as the overall per-
formance will be affected by the retrieval model,
the considered corpus, the LM and the prompt for-
mulation, among others. Automated evaluation of
retrieval-augmented systems is thus paramount. In
practice, RAG systems are often evaluated in terms
of the language modelling task itself, i.e. by mea-
suring perplexity on some reference corpus. How-
ever, such evaluations are not always predictive
of downstream performance (Wang et al., 2023c).
Moreover, this evaluation strategy relies on the LM
probabilities, which are not accessible for some
closed models (e.g. ChatGPT and GPT-4). Ques-
tion answering is another common evaluation task,
but usually only datasets with short extractive an-
swers are considered, which may not be represen-
tative of how the system will be used.
To address these issues, in this paper we present
RAGAS, a framework for the automated assess-
150

## Page 2

ment of retrieval augmented generation systems.
We focus on settings where reference answers may
not be available, and where we want to estimate
different proxies for correctness, in addition to the
usefulness of the retrieved passages. The RAGAS
framework provides an integration with both llama-
index and Langchain, the most widely used frame-
works for building RAG solutions, thus enabling
developers to easily integrate RAGAS into their
standard workflow.
2
Related Work
Estimating faithfulness using LLMs
The prob-
lem of detecting hallucinations in LLM-generated
responses has been extensively studied (Ji et al.,
2023). Some authors have suggested the idea of
predicting factuality using a few-shot prompting
strategy (Zhang et al., 2023). Recent analyses, how-
ever, suggest that existing models struggle with de-
tecting hallucination when using standard prompt-
ing strategies (Li et al., 2023; Azaria and Mitchell,
2023). Other approaches rely on linking the gener-
ated responses to facts from an external knowledge
base (Min et al., 2023), but this is not always possi-
ble.
Yet another strategy is to inspect the probabili-
ties assigned to individual tokens, where we would
expect the model to be less confident in halluci-
nated answers than in factual ones. For instance,
BARTScore (Yuan et al., 2021) estimates factuality
by looking at the conditional probability of the gen-
erated text given the input. Kadavath et al. (2022)
use a variation of this idea. Starting from the ob-
servation that LLMs provide well-calibrated proba-
bilities when answering multiple-choice questions,
they essentially convert the problem of validating
model generated answers into a multiple-choice
question which asks whether the answer is true or
false. Rather than looking at the output probabil-
ities, Azaria and Mitchell (2023) propose to train
a supervised classifier on the weights from one of
the hidden layers of the LLM, to predict whether a
given statement is true or not. While the approach
performs well, the need to access the hidden states
of the model makes it unsuitable for systems that
access LLMs through an API.
For models that do not provide access to token
probabilities, such as ChatGPT and GPT-4, differ-
ent methods are needed. SelfCheckGPT (Manakul
et al., 2023) addresses this problem by instead sam-
pling multiple answers. Their core idea is that
factual answers are more stable: when an answer is
factual, we can expect that different samples will
tend to be semantically similar, whereas this is less
likely to be the case for hallucinated answers.
Automated evaluation of text generation systems
LLMs have also been leveraged to automatically
evaluate other aspects of generated text fragments,
beyond factuality. For instance, GPTScore (Fu
et al., 2023) uses a prompt that specifies the consid-
ered aspect (e.g. fluency) and then scores passages
based on the average probability of the generated
tokens, according to a given autoregressive LM.
This idea of using prompts was previously also
considered by Yuan et al. (2021), although they
used a smaller fine-tuned LM (i.e. BART) and did
not observe a clear benefit from using prompts. An-
other approach directly asks ChatGPT to evaluate
a particular aspect of the given answer by provid-
ing a score between 0 and 100, or by providing a
rating on a 5-star scale (Wang et al., 2023a). Re-
markably, strong results can be obtained in this
way, although it comes with the limitation of being
sensitive to the design of the prompt. Rather than
scoring individual answers, some authors have also
focused on using an LLM to select the best answer
among a number of candidates (Wang et al., 2023b),
typically to compare the performance of different
LLMs. However, care is needed with this approach,
as the order in which the answers are presented can
influence the result (Wang et al., 2023b).
More generally, however, most approaches have
relied on the availability of one or more refer-
ence answers for evaluating text generation sys-
tems. For instance, BERTScore (Zhang et al., 2020)
and MoverScore (Zhao et al., 2019) use contex-
tualised embeddings, produced by a pre-trained
BERT model, to compare the similarity between
the generated answer and the reference answers.
BARTScore (Yuan et al., 2021) similarly uses refer-
ence answers to compute aspects such as precision
(estimated as the probability of generating the gen-
erated answer given the reference) and recall (esti-
mated as the probability of generating the reference
given the generated answer).
3
Evaluation Strategies
We consider a standard RAG setting, where given a
question q, the system first retrieves some context
c(q) and then uses the retrieved context to generate
an answer as(q). When building a RAG system,
we usually do not have access to human-annotated
151

## Page 3

datasets or reference answers. We therefore fo-
cus on metrics that are fully self-contained and
reference-free. We focus in particular three quality
aspects, which we argue are of central importance.
First, Faithfulness refers to the idea that the
answer should be grounded in the given context.
This is important to avoid hallucinations, and to
ensure that the retrieved context can act as a jus-
tification for the generated answer. Indeed, RAG
systems are often used in applications where the
factual consistency of the generated text w.r.t. the
grounded sources is highly important, e.g. in do-
mains such as law, where information is constantly
evolving. Second, Answer Relevance refers to the
idea that the generated answer should address the
actual question that was provided. Finally, Con-
text Relevance refers to the idea that the retrieved
context should be focused, containing as little ir-
relevant information as possible. This is important
given the cost associated with feeding long context
passages to LLMs. Moreover, when context pas-
sages are too long, LLMs are often less effective
in exploiting that context, especially for informa-
tion that is provided in the middle of the context
passage (Liu et al., 2023).
We now explain how these three quality aspects
can be measured in a fully automated way, by
prompting an LLM. In our implementation and
experiments, all prompts are evaluated using the
gpt-3.5-turbo-16k model, which is available
through the OpenAI API2.
Faithfulness
We say that the answer as(q) is
faithful to the context c(q) if the claims that are
made in the answer can be inferred from the con-
text. To estimate faithfulness, we first use an LLM
to extract a set of statements, S(as(q)). The aim
of this step is to decompose longer sentences into
shorter and more focused assertions. We use the
following prompt for this step3:
Given a question and answer, create one
or more statements from each sentence
in the given answer.
question: [question]
answer: [answer]
where [question] and [answer] refer to the
given question and answer. For each statement si in
2https://platform.openai.com
3To help clarify the task, we include a demonstration as
part of the prompt. This demonstration is not explicitly shown
in the listing of the prompts throughout this paper.
S(as(q)), the LLM determines if si can be inferred
from c(q) using a verification function v(si, c(q)).
This verification step is carried out using the fol-
lowing prompt:
Consider the given context and following
statements, then determine whether they
are supported by the information present
in the context. Provide a brief explana-
tion for each statement before arriving
at the verdict (Yes/No). Provide a final
verdict for each statement in order at the
end in the given format. Do not deviate
from the specified format.
statement: [statement 1]
...
statement: [statement n]
The final faithfulness score, F, is then computed
as F = |V |
|S| , where |V | is the number of statements
that were supported according to the LLM and |S|
is the total number of statements in S(as(q)).
Answer relevance
We say that the answer as(q)
is relevant if it directly addresses the question in
an appropriate way. In particular, our assessment
of answer relevance does not take into account fac-
tuality, but penalises cases where the answer is
incomplete or where it contains redundant informa-
tion. To estimate answer relevance, for the given
answer as(q), we prompt the LLM to generate n
potential questions qi based on as(q), as follows:
Generate a question for the given an-
swer.
answer: [answer]
We then obtain embeddings for all questions us-
ing the text-embedding-ada-002 model, avail-
able from the OpenAI API. For each qi, we cal-
culate the similarity sim(q, qi) with the original
question q, as the cosine between the correspond-
ing embeddings. The answer relevance score, AR,
for question q is then computed as:
AR = 1
n
n
X
i=1
sim(q, qi)
(1)
This metric evaluates how closely the generated
answer aligns with the initial question or instruc-
tion.
152

## Page 4

Context relevance
The context c(q) is consid-
ered relevant to the extent that it exclusively con-
tains information that is needed to answer the ques-
tion. In particular, this metric aims to penalise the
inclusion of redundant information. To estimate
context relevance, given a question q and its con-
text c(q), the LLM extracts a subset of sentences,
Sext, from c(q) that are crucial to answer q, using
the following prompt:
Please extract relevant sentences from
the provided context that can potentially
help answer the following question. If no
relevant sentences are found, or if you
believe the question cannot be answered
from the given context, return the phrase
"Insufficient Information". While extract-
ing candidate sentences you’re not al-
lowed to make any changes to sentences
from given context.
The context relevance score is then computed as:
CR =
number of extracted sentences
total number of sentences in c(q)
(2)
4
The WikiEval Dataset
To evaluate the proposed framework, we ideally
need examples of question-context-answer triples
which are annotated with human judgments. We
can then verify to what extent our metrics agree
with human assessments of faithfulness, answer
relevance and context relevance. Since we are not
aware of any publicly available datasets that could
be used for this purpose, we created a new dataset,
which we refer to as WikiEval4. To construct the
dataset, we first selected 50 Wikipedia pages cov-
ering events that have happened since the start of
20225. In selecting these pages, we prioritised
those with recent edits. For each of the 50 pages,
we then asked ChatGPT to suggest a question that
can be answered based on the introductory section
of the page, using the following prompt:
Your task is to formulate a question from
given context satisfying the rules given
below:
1. The question should be fully answered
from the given context.
4https://huggingface.co/datasets/
explodinggradients/WikiEval.
5That is, beyond the reported training cutoff of the model
we used in our experiments.
2. The question should be framed from
a part that contains non-trivial informa-
tion.
3. The answer should not contain any
links.
4. The question should be of moderate
difficulty.
5. The question must be reasonable and
must be understood and responded to by
humans.
6. Do not use phrases that ‘provided con-
text’, etc in the question
context:
We also used ChatGPT to answer the generated
question, when given the corresponding introduc-
tory section as context, using the following prompt:
Answer the question using the informa-
tion from the given context.
question: [question]
context: [context]
All questions were annotated along the three con-
sidered quality dimensions by two annotators. Both
annotators were fluent in English and were given
clear instructions about the meaning of the three
considered quality dimensions. For faithfulness
and context relevance, the two annotators agreed in
around 95% of cases. For answer relevance, they
agreed in around 90% of the cases. Disagreements
were resolved after a discussion between the anno-
tators. Tables 1, 2 and 3 show examples from the
WikiEval dataset, focusing in particular on answers
with high and low faithfulness (Table 1), high and
low answer relevance (Table 2), and high and low
context relevance (Table 3).
Faithfulness
To obtain human judgements about
faithfulness, we first used ChatGPT to answer the
question without access to any additional context.
We then asked the annotators to judge which of the
two answers was the most faithful (i.e. the standard
one or the one generated without context), given
the question and corresponding Wikipedia page.
Answer relevance
We first used ChatGPT to
obtain candidate answers with lower answer rel-
evance, using the following prompt:
Answer the given question in an incom-
plete manner.
question: [question]
153

## Page 5

Question
Context
Answer
Who directed the film Op-
penheimer and who stars
as J. Robert Oppenheimer
in the film?
Oppenheimer is a 2023 biographical thriller film written
and directed by Christopher Nolan. Based on the 2005
biography American Prometheus by Kai Bird and Mar-
tin J. Sherwin, the film chronicles the life of J. Robert
Oppenheimer, a theoretical physicist who was pivotal in
developing the first nuclear weapons as part of the Man-
hattan Project, and thereby ushering in the Atomic Age.
Cillian Murphy stars as Oppenheimer, with Emily Blunt
as Oppenheimer’s wife Katherine "Kitty" Oppenheimer.
High Faithfulness: Christopher
Nolan directed the film Oppen-
heimer. Cillian Murphy stars as J.
Robert Oppenheimer in the film.
Low
Faithfulness:
James
Cameron directed the film Op-
penheimer. Tom Cruise stars as J.
Robert Oppenheimer in the film.
Table 1: Example from WikiEval, showing answers with high and low faithfulness.
Question
Answer
When is the scheduled
launch date and time for
the PSLV-C56 mission,
and where will it be
launched from?
High answer relevance: The PSLV-C56 mission is scheduled to be launched on Sunday, 30
July 2023 at 06:30 IST / 01:00 UTC. It will be launched from the Satish Dhawan Space
Centre, Sriharikota, Andhra Pradesh, India.
Low answer relevance: The scheduled launch date and time for the PSLV-C56 mission have
not been provided.The PSLV-C56 mission is an important space mission for India. It aims to
launch a satellite into orbit to study weather patterns.
Table 2: Example from WikiEval, showing answers with high and low answer relevance.
We then asked human annotators to compare this
answer, and indicate which of the two answers had
the highest answer relevance.
Context relevance
To measure this aspect, we
first added additional sentences to the context by
scraping back-links to the corresponding Wikipedia
page. In this way, we were able to add information
to the context that was related but less relevant for
answering the question. For the few pages with-
out any back-links, we instead used ChatGPT to
complete the given context.
5
Experiments
Table 4 analyses the agreement between the met-
rics proposed in Section 3 and the human assess-
ments from the proposed WikiEval dataset. Each
WikiEval instance requires the model to compare
two answers or two context fragments. We count
how often the answer/context preferred by the
model (i.e. with highest estimated faithfulness, an-
swer relevance, or context relevance) coincides
with the answer/context preferred by the human
annotators. We report the results in terms of ac-
curacy (i.e. the fraction of instances on which the
model agrees with the annotators).
To put the results in context, we compare our
proposed metrics (shown as RAGAS in Table 4)
with two baseline methods. For the first method,
shown as GPT Score, we ask ChatGPT to assign a
score between 0 and 10 for the three quality dimen-
sions. To this end, we use a prompt that describes
the meaning of the quality metric and then asks
to score the given answer/context in line with that
definition. For instance, for evaluating faithfulness,
we used the following prompt:
Faithfulness measures the information
consistency of the answer against the
given context. Any claims that are made
in the answer that cannot be deduced
from context should be penalized.
Given an answer and context, assign a
score for faithfulness in the range 0-10.
context: [context]
answer: [answer]
Ties, where the same score is assigned by the LLM
to both answer candidates, were broken randomly.
The second baseline, shown as GPT Ranking, in-
stead asks ChatGPT to select the preferred answer/-
context. In this case, the prompt again includes
a definition of the considered quality metric. For
instance, to evaluate answer relevance, we used the
following prompt:
Answer Relevancy measures the degree
to which a response directly addresses
and is appropriate for a given question.
It penalizes the present of redundant in-
formation or incomplete answers given a
question. Given an question and answer,
rank each answer based on Answer Rele-
vancy.
question: [question]
154

## Page 6

Question
Context
When was the Chimnabai
Clock Tower completed,
and who was it named af-
ter?
High context relevance: The Chimnabai Clock Tower, also known as the Raopura Tower, is
a clock tower situated in the Raopura area of Vadodara, Gujarat, India. It was completed
in 1896 and named in memory of Chimnabai I (1864–1885), a queen and the first wife of
Sayajirao Gaekwad III of Baroda State.
Low context relevance: The Chimnabai Clock Tower, also known as the Raopura Tower, is
a clock tower situated in the Raopura area of Vadodara, Gujarat, India. It was completed
in 1896 and named in memory of Chimnabai I (1864–1885), a queen and the first wife of
Sayajirao Gaekwad III of Baroda State. It was built in Indo-Saracenic architecture style.
History. Chimnabai Clock Tower was built in 1896. The tower was named after Chimnabai
I (1864–1885), a queen and the first wife of Sayajirao Gaekwad III of Baroda State. It was
inaugurated by Mir Kamaluddin Hussainkhan, the last Nawab of Baroda. During the rule of
Gaekwad, it was a stoppage for horse drawn trams. The clock tower was erected at the cost
of 25,000 (equivalent to 9.2 million or USD 120,000 in 2023).
Table 3: Example from WikiEval, showing answers with high and low context relevance.
Faith.
Ans. Rel.
Cont. Rel.
RAGAS
0.95
0.78
0.70
GPT Score
0.72
0.52
0.63
GPT Ranking
0.54
0.40
0.52
Table 4: Agreement with human annotators in pairwise
comparisons of faithfulness, answer relevance and con-
text relevance, using the WikEval dataset (accuracy).
answer 1: [answer 1]
answer 2: [answer 2]
The results in Table 4 show that our proposed
metrics are much closer aligned with the human
judgements than the predictions from the two base-
lines. For faithfulness, the RAGAS prediction are
in general highly accurate. For answer relevance,
the agreement is lower, but this is largely due to the
fact that the differences between the two candidate
answers are often very subtle. We found context
relevance to be the hardest quality dimension to
evaluate. In particular, we observed that ChatGPT
often struggles with the task of selecting the sen-
tences from the context that are crucial, especially
for longer contexts.
5.1
Reproducibility
Obtaining reproducible results with (large) lan-
guage models is challenging. For this reason, reli-
able software that uses prompts should account not
only for hallucinations, but for the fact that several
runs of the same experiment under the same config-
uration might yield different results, e.g., because
of an undocumented change in the underlying API,
or because of the inherent randomness in neural
networks. Furthermore, we require the LLM to gen-
erate outputs in structured JSON format. We found
that this largely makes RAGAS compatible with
different LLMs, and ultimately lowers the error rate
when consuming LLM generated text. To measure
the effectiveness of the JSON-formatting, we mea-
sured the correlation between RAGAS scores in
successive runs with and without JSON formatting.
As shown in Figure 1, the scores are clearly more
consistent when JSON formatted outputs are used.
Figure 1: We compare the consistency of RAGAS
scores across two different runs of the model, with
JSON formatting (left) and without (right). The use
of JSON formatting leads to more consistent scores.
6
Python API
RAGAS provides access to metrics and datasets via
an easy-to-use Python API. Its syntax is similar to
other well-known libraries such as transformers
or datasets. As an example, once installed, load-
ing a dataset, evaluating a pipeline with the de-
sired metrics, and exporting the results to a pandas
dataframe can be accomplished with the snippet be-
low. The metrics available at ragas.metrics use
OpenAI’s API by default, which requires having
the appropriate environment variables set up. It is
however possible to experiment with other LLMs
155

## Page 7

for evaluation6.
# import required modules
from ragas.metrics import (
answer_relevancy ,
faithfulness ,
context_relevancy ,
)
from ragas import evaluate
from datasets import load_dataset
# loading the eval dataset
amnesty_qa = load_dataset(
'explodinggradients/amnesty_qa ',
'english_v2 '
)
# evaluate
from ragas import evaluate
result = evaluate(
amnesty_qa["eval"],
metrics=[
faithfulness ,
answer_relevancy ,
context_relevancy ,
],
)
# export results to pandas dataframe
df = result.to_pandas ()
7
Conclusions
We have highlighted the need for automated
reference-free evaluation of RAG systems. In par-
ticular, we have argued the need for an evaluation
framework that can assess faithfulness (i.e. is the
answer grounded in the retrieved context), answer
relevance (i.e. does the answer address the ques-
tion) and context relevance (i.e. is the retrieved
context sufficiently focused). To support the devel-
opment of such a framework, we have introduced
WikiEval, a dataset which human judgements of
these three different aspects. Finally, we have also
described RAGAS, our implementation of the three
considered quality aspects. This framework is easy
to use and can provide developers of RAG sys-
tems with valuable insights, even in the absence
of any ground truth. Our evaluation on WikiEval
has shown that the predictions from RAGAS are
closely aligned with human judgments, especially
for faithfulness and answer relevance.
8
Limitations
This paper introduces a toolkit aimed at provid-
ing an end-to-end evaluation framework for RAG
6See
https://github.com/explodinggradients/
ragas/blob/main/docs/howtos/customisations/llms.
ipynb.
systems. It relies heavily on the performance of
the LLMs used for evaluating the different compo-
nents. While the current set of experiments demon-
strate high correlation of these metrics with human
judgements, we acknowledge that relying on LLMs
comes with known limitations. Therefore, careful
reviewing of the suitability of LLMs (ideally pri-
oritizing open models over full-fledged products
behind paid APIs) is critical for RAGAS, and other
contributions in this space, to nurture a healthy
environment. We are also aware of the potential
implications of enabling large user bases into using
more accurate RAG systems, and therefore we will
continue to encourage applications of fair systems
on top of RAGAS.
References
Amos Azaria and Tom M. Mitchell. 2023. The inter-
nal state of an LLM knows when its lying. CoRR,
abs/2304.13734.
Sebastian Borgeaud, Arthur Mensch, Jordan Hoffmann,
Trevor Cai, Eliza Rutherford, Katie Millican, George
van den Driessche, Jean-Baptiste Lespiau, Bogdan
Damoc, Aidan Clark, Diego de Las Casas, Aurelia
Guy, Jacob Menick, Roman Ring, Tom Hennigan,
Saffron Huang, Loren Maggiore, Chris Jones, Albin
Cassirer, Andy Brock, Michela Paganini, Geoffrey
Irving, Oriol Vinyals, Simon Osindero, Karen Si-
monyan, Jack W. Rae, Erich Elsen, and Laurent Sifre.
2022. Improving language models by retrieving from
trillions of tokens. In International Conference on
Machine Learning, ICML 2022, 17-23 July 2022, Bal-
timore, Maryland, USA, volume 162 of Proceedings
of Machine Learning Research, pages 2206–2240.
PMLR.
Sébastien Bubeck, Varun Chandrasekaran, Ronen El-
dan, Johannes Gehrke, Eric Horvitz, Ece Kamar,
Peter Lee, Yin Tat Lee, Yuanzhi Li, Scott Lund-
berg, et al. 2023. Sparks of artificial general intelli-
gence: Early experiments with gpt-4. arXiv preprint
arXiv:2303.12712.
Jacob Devlin, Ming-Wei Chang, Kenton Lee, and
Kristina Toutanova. 2019. BERT: Pre-training of
deep bidirectional transformers for language under-
standing. In Proceedings of the 2019 Conference of
the North American Chapter of the Association for
Computational Linguistics: Human Language Tech-
nologies, Volume 1 (Long and Short Papers), pages
4171–4186, Minneapolis, Minnesota. Association for
Computational Linguistics.
Jinlan Fu, See-Kiong Ng, Zhengbao Jiang, and Pengfei
Liu. 2023. Gptscore: Evaluate as you desire. CoRR,
abs/2302.04166.
Kelvin Guu, Kenton Lee, Zora Tung, Panupong Pasu-
pat, and Mingwei Chang. 2020. Retrieval augmented
156

## Page 8

language model pre-training. In International confer-
ence on machine learning, pages 3929–3938. PMLR.
Ziwei Ji, Nayeon Lee, Rita Frieske, Tiezheng Yu, Dan
Su, Yan Xu, Etsuko Ishii, Ye Jin Bang, Andrea
Madotto, and Pascale Fung. 2023. Survey of halluci-
nation in natural language generation. ACM Comput-
ing Surveys, 55(12):1–38.
Saurav Kadavath, Tom Conerly, Amanda Askell, Tom
Henighan, Dawn Drain, Ethan Perez, Nicholas
Schiefer, Zac Hatfield-Dodds, Nova DasSarma, Eli
Tran-Johnson, Scott Johnston, Sheer El Showk, Andy
Jones, Nelson Elhage, Tristan Hume, Anna Chen,
Yuntao Bai, Sam Bowman, Stanislav Fort, Deep
Ganguli, Danny Hernandez, Josh Jacobson, Jack-
son Kernion, Shauna Kravec, Liane Lovitt, Ka-
mal Ndousse, Catherine Olsson, Sam Ringer, Dario
Amodei, Tom Brown, Jack Clark, Nicholas Joseph,
Ben Mann, Sam McCandlish, Chris Olah, and Jared
Kaplan. 2022. Language models (mostly) know what
they know. CoRR, abs/2207.05221.
Nikhil Kandpal, Haikang Deng, Adam Roberts, Eric
Wallace, and Colin Raffel. 2022. Large language
models struggle to learn long-tail knowledge. CoRR,
abs/2211.08411.
Urvashi Khandelwal, Omer Levy, Dan Jurafsky, Luke
Zettlemoyer, and Mike Lewis. 2020. Generalization
through memorization: Nearest neighbor language
models. In 8th International Conference on Learning
Representations, ICLR 2020, Addis Ababa, Ethiopia,
April 26-30, 2020. OpenReview.net.
Omar Khattab, Keshav Santhanam, Xiang Lisa Li,
David Hall, Percy Liang, Christopher Potts, and
Matei Zaharia. 2022. Demonstrate-search-predict:
Composing retrieval and language models for
knowledge-intensive NLP. CoRR, abs/2212.14024.
Kenton Lee, Ming-Wei Chang, and Kristina Toutanova.
2019. Latent retrieval for weakly supervised open do-
main question answering. In Proceedings of the 57th
Annual Meeting of the Association for Computational
Linguistics, pages 6086–6096.
Patrick S. H. Lewis, Ethan Perez, Aleksandra Pik-
tus, Fabio Petroni, Vladimir Karpukhin, Naman
Goyal, Heinrich Küttler, Mike Lewis, Wen-tau Yih,
Tim Rocktäschel, Sebastian Riedel, and Douwe
Kiela. 2020.
Retrieval-augmented generation for
knowledge-intensive NLP tasks. In Advances in Neu-
ral Information Processing Systems 33: Annual Con-
ference on Neural Information Processing Systems
2020, NeurIPS 2020, December 6-12, 2020, virtual.
Junyi Li, Xiaoxue Cheng, Wayne Xin Zhao, Jian-Yun
Nie, and Ji-Rong Wen. 2023. Halueval: A large-
scale hallucination evaluation benchmark for large
language models. CoRR, abs/2305.11747.
Nelson F. Liu, Kevin Lin, John Hewitt, Ashwin Paran-
jape, Michele Bevilacqua, Fabio Petroni, and Percy
Liang. 2023. Lost in the middle: How language
models use long contexts.
Alex Mallen, Akari Asai, Victor Zhong, Rajarshi Das,
Daniel Khashabi, and Hannaneh Hajishirzi. 2023.
When not to trust language models: Investigating
effectiveness of parametric and non-parametric mem-
ories. In Proceedings of the 61st Annual Meeting of
the Association for Computational Linguistics (Vol-
ume 1: Long Papers), pages 9802–9822, Toronto,
Canada. Association for Computational Linguistics.
Potsawee Manakul, Adian Liusie, and Mark J. F. Gales.
2023. Selfcheckgpt: Zero-resource black-box hal-
lucination detection for generative large language
models. CoRR, abs/2303.08896.
Sewon Min, Kalpesh Krishna, Xinxi Lyu, Mike
Lewis, Wen-tau Yih, Pang Wei Koh, Mohit Iyyer,
Luke Zettlemoyer, and Hannaneh Hajishirzi. 2023.
Factscore: Fine-grained atomic evaluation of fac-
tual precision in long form text generation. CoRR,
abs/2305.14251.
Ori Ram, Yoav Levine, Itay Dalmedigos, Dor Muhlgay,
Amnon Shashua, Kevin Leyton-Brown, and Yoav
Shoham. 2023. In-context retrieval-augmented lan-
guage models. CoRR, abs/2302.00083.
Adam Roberts, Colin Raffel, and Noam Shazeer. 2020.
How much knowledge can you pack into the param-
eters of a language model? In Proceedings of the
2020 Conference on Empirical Methods in Natural
Language Processing (EMNLP), pages 5418–5426,
Online. Association for Computational Linguistics.
Weijia Shi, Sewon Min, Michihiro Yasunaga, Minjoon
Seo, Rich James, Mike Lewis, Luke Zettlemoyer, and
Wen-tau Yih. 2023. REPLUG: retrieval-augmented
black-box language models. CoRR, abs/2301.12652.
Jiaan Wang, Yunlong Liang, Fandong Meng, Haoxi-
ang Shi, Zhixu Li, Jinan Xu, Jianfeng Qu, and Jie
Zhou. 2023a. Is chatgpt a good NLG evaluator? A
preliminary study. CoRR, abs/2303.04048.
Peiyi Wang, Lei Li, Liang Chen, Dawei Zhu, Binghuai
Lin, Yunbo Cao, Qi Liu, Tianyu Liu, and Zhifang Sui.
2023b. Large language models are not fair evaluators.
CoRR, abs/2305.17926.
Shufan Wang, Yixiao Song, Andrew Drozdov, Aparna
Garimella, Varun Manjunatha, and Mohit Iyyer.
2023c. KNN-LM does not improve open-ended text
generation. CoRR, abs/2305.14625.
Weizhe Yuan, Graham Neubig, and Pengfei Liu. 2021.
Bartscore: Evaluating generated text as text genera-
tion. In Advances in Neural Information Processing
Systems 34: Annual Conference on Neural Informa-
tion Processing Systems 2021, NeurIPS 2021, De-
cember 6-14, 2021, virtual, pages 27263–27277.
Tianhua Zhang, Hongyin Luo, Yung-Sung Chuang, Wei
Fang, Luc Gaitskell, Thomas Hartvigsen, Xixin Wu,
Danny Fox, Helen Meng, and James R. Glass. 2023.
Interpretable unified language checking.
CoRR,
abs/2304.03728.
157

## Page 9

Tianyi Zhang, Varsha Kishore, Felix Wu, Kilian Q.
Weinberger, and Yoav Artzi. 2020. Bertscore: Evalu-
ating text generation with BERT. In 8th International
Conference on Learning Representations, ICLR 2020,
Addis Ababa, Ethiopia, April 26-30, 2020. OpenRe-
view.net.
Wei Zhao, Maxime Peyrard, Fei Liu, Yang Gao, Chris-
tian M. Meyer, and Steffen Eger. 2019. MoverScore:
Text generation evaluating with contextualized em-
beddings and earth mover distance. In Proceedings
of the 2019 Conference on Empirical Methods in
Natural Language Processing and the 9th Interna-
tional Joint Conference on Natural Language Pro-
cessing (EMNLP-IJCNLP), pages 563–578, Hong
Kong, China. Association for Computational Lin-
guistics.
158


---

# Recent applications of artificial intelligence in RNA-targeted small molecule drug discovery

- **Authors:** Ella Czarina Morishita, Shingo Nakamura
- **Issuer:** Expert opinion on drug discovery
- **Type:** Scientific article
- **Published:** 2024-02-06
- **Language:** en
- **DOI:** 10.1080/17460441.2024.2313455
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38321848/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Targeting RNAs with small molecules offers an alternative to the conventional protein-targeted drug discovery and can potentially address unmet and emerging medical needs. The recent rise of interest in the strategy has already resulted in large amounts of data on disease associated RNAs, as well as on small molecules that bind to such RNAs. Artificial intelligence (AI) approaches, including machine learning and deep learning, present an opportunity to speed up the discovery of RNA-targeted small molecules by improving decision-making efficiency and quality. The topics described in this review include the recent applications of AI in the identification of RNA targets, RNA structure determination, screening of chemical compound libraries, and hit-to-lead optimization. The impact and limitations of the recent AI applications are discussed, along with an outlook on the possible applications of next-generation AI tools for the discovery of novel RNA-targeted small molecule drugs. Key areas for improvement include developing AI tools for understanding RNA dynamics and RNA - small molecule interactions. High-quality and comprehensive data still need to be generated especially on the biological activity of small molecules that target RNAs.


---

# Regulatory responses and approval status of artificial intelligence medical devices with a focus on China

- **Authors:** Yuehua Liu, Wenjin Yu, Tharam Dillon
- **Issuer:** NPJ digital medicine
- **Type:** Scientific article
- **Published:** 2024-09-18
- **Language:** en
- **DOI:** 10.1038/s41746-024-01254-x
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39294318/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

This paper focuses on how regulatory bodies respond to artificial intelligence (AI)-enabled medical devices. To achieve this, we present a comparative overview of the United States (USA), European Union (EU), and China. Our search in the governmental database identified 59 AI medical devices approved in China as of July 2023. In comparison to the rules-based regulatory approach in China, the approaches in the USA and EU are more standards-oriented.

## Section: Introduction

The resurgence of interest in deep learning (DL), coupled with advancements in training techniques and hardware, has significantly contributed to the widespread adoption of artificial intelligence (AI). This use of AI is also gradually changing medical device related practice. The main factors contributing to this situation are the ongoing explosion in the availability of digital health data, including image data, sensor time series, text, medical records, financial transactions, etc. Moreover, there is a broad access to increasingly powerful and cost-effective computing infrastructure. Data are the key ingredient of all machine learning systems. However, even with massive datasets, often referred to as “Big Data”, the data alone are of little use until meaningful knowledge and insights are extracted from them1. Therefore, the era of ‘big data’ provides opportunities for AI, and more powerful and cheaper processing ability enables these opportunities to become reality.

The healthcare sector has adopted AI technologies in developing medical products, software, workflows, solutions, and decision-making processes to relieve doctors’ ever-expanding working burdens and improve patient outcomes. Academic progress in this area has paralleled the significant investments and activities within the industry. It is apparent the traditional way of working in the medical field will inevitably be transformed by AI and will keep evolving in the coming years at a rapid pace. However, the real-world clinical implementation of AI-based technologies in medicine has not yet become a reality by 20192. Even as of now, interest and research from various stakeholders in the use of AI in medicine have not fully translated to widespread adoption in practice. To understand the barriers on the path to real implementation, this paper seeks to delve deep into the landscape of approved AIMDs, which are commercial AI solutions available for sale and ready for use in clinical practice. The analysis aims to explore why the number of approved AIMDs does not proportionally align with the abundance of research papers. It also investigates how these devices are evaluated before regulatory approvals, the response actions taken by regulatory agencies, and additional considerations beyond the regular experiments reported in research papers.

The approval of medical devices, along with associated regulations and legislation, is handled differently in various regions worldwide. In the United States (USA), the US Food and Drug Administration (FDA) is responsible for approving commercially marketed medical devices. In China, the corresponding department responsible for approval is the National Medical Products Administration (NMPA). Unlike the USA and China, medical devices in the EU are not approved in a centralized way. Instead, there are many Notified Bodies eligible to conduct conformity assessments and issue a Conformité Européenne (CE) mark. To cope with the submission and approval request of AI-enabled medical devices, competent authorities have announced their acts on how to regulate medical devices with the AI algorithms involved, followed by the publication of specific regulatory policies and registration review guidelines. While existing studies3–7 predominantly discuss the regulatory environment in the USA and EU, analyzing FDA-approved and CE-marked AIMDs, the issues surrounding AI are naturally universal. China is also a major player in global AI due to its significant research base and large population, high-demand for improving clinical work efficiency, and vastly available systematically collected data that can be utilized by AI training algorithms. However, there are few studies on the regulatory compliance requirements in China, potentially due to language barriers. To bridge this gap, we propose including AIMDs approved in China in our study and conducting a comparative analysis systematically. Furthermore, we provide insights into Chinese legislation and regulations. It is expected that this paper is able to contribute to a clearer global map of AIMDs regulations and legislation, especially in the context of Chinese practices and products, and serves as a valuable reference. Table 1 presents a comparative overview of medical device regulation in the USA, Europe, and China. Tables 2 and 3 summarize the definitions and classifications of AIMD in various countries.Table 1A comparative overview of AIMDs regulation in the USA, Europe and ChinaUSAEuropeChinaRegulatory bodiesFDAAccredited private Notified BodiesNMPARegulatory pathwayPremarket Approval application (PMA): is the most stringent type of device marketing application required by FDA to evaluate the safety and effectiveness of Class III medical devices17;510(k) pathway: Class I, II, and III devices intended for human use that do not require a PMA must submit 510(k)18;De-novo premarket review: For class I and II, the De Novo request provides a marketing pathway to classify novel medical devices for which general controls alone, or general and special controls, provide reasonable assurance of safety and effectiveness for the intended use, but for which there is no legally marketed predicate device19.No Specific pathway for AI/ML-based medical devices; They should comply with medical devices regulations:For the lowest risk medical devices (class I): the manufacturer has the sole responsibility to ensure the devices comply with the regulations and exempt from the approval process.For higher risk medical devices (class II or III): different requirements must be met across different Notified Bodies to undergo an approval process.No Specific pathway for AI/ML-based medical devices;Governmental released AI-specific guidelines /documents1. Proposed Regulatory Framework for Modifications to Artificial Intelligence/Machine Learning (AI/ML)-Based Software as a Medical Device (SaMD) - Discussion Paper and Request for Feedback20.2. Response to discussion paper: action plan213. Good Machine Learning Practice for Medical Device Development: Guiding Principles224. Computer-Assisted Detection Devices Applied to Radiology Images and Radiology Device Data - Premarket Notification [510(k)] Submissions235. Clinical Performance Assessment: Considerations for Computer-Assisted Detection Devices Applied to Radiology Images and Radiology Device Data in Premarket Notification (510(k)) Submissions - Guidance for Industry and Food and Drug Administration Staff246. Pre-cert pilot program251. Medical devices section from official website262. New regulations in comparison to previous directives (see details in differences between regulations and directives)27:With effect from 26 May 2021, Regulation (EU) 2017/745 on medical devices replaced Council Directive 90/385/EEC on active implantable medical devices and Council Directive 93/42/EEC on medical devices.With effect from 26 May 2022, Regulation (EU) 2017/746 on in vitro diagnostic medical devices replaced Directive 98/79/EC of the European Parliament and of the Council on in vitro diagnostic medical devices283. New EU Rules to Ensure Safety of Medical Devices294. Some guidance documents to assist stakeholders in applying new regulations305. AI Act31See Fig. 1 for detailsReference link to approval AIMDsAn updated list of Artificial Intelligence and Machine Learning (AI/ML)-Enabled Medical Devices32No comprehensive public database for all CE marked medical devices, only several public or commercial databases for registered devices in some European country (eg, Austria, Belgium, France, Germany, Italy, and the UK).No specific list for AIMDs, but a search database is publicly accessible with all medical devices being registered.Submission information availabilityYes, access through the link with the AIMD number.Depends on the countries where the medical devices were registered.Each with a brief description table; Only some selected ones are available with review summary report.AIMD Artificial intelligence medical device, FDA US Food and Drug Administration, NMPA National Medical Products Administration, CE Conformité Européenne, EEC European Economic Community, EC European Community.Table 2AIMDs regulatory definitions by the USA, Europe and China, respectivelyUSAEuropeChinaThese AI/ML-based software, when intended to treat, diagnose, cure, mitigate, or prevent disease or other conditions, are medical devices under the FD&C Act, and called “Software as a Medical Device” (SaMD) by FDA and IMDRF20AI systems related to medical devices. ‘Artificial intelligence system’ (AI system) means software that is developed with one or more of the techniques and approaches listed in Annex I and can, for a given set of human-defined objectives, generate outputs such as content, predictions, recommendations, or decisions influencing the environments they interact with31AIMDs refer to the medical devices that utilize AI techniques to achieve intended purpose (i.e., medical purposes) based on “medical device data”. Whereas, medical device data means the objective data generated by medical devices and used for medical purposes, such as medical image data generated by medical imaging equipment (X-ray, CT, MRI, Ultrasound, Endoscope, optical, etc), physiological data generated by medical electronic device (ECG, EEG, blood pressure, etc.), In vitro diagnostic data generated by in vitro diagnosis device (pathology imaging, microscopic imaging, etc.). In special cases, objective data generated by general devices (including non-medical devices) but for medical purposes is also treated as medical device data, e.g., skin disease diagnosis photos captured by digital cameras, ECG data for heart disease warning generated by electronic health devices33AIMD Artificial intelligence medical device, AI/ML Artificial intelligence and machine learning, FD&C The Federal Food, Drug, and Cosmetic, FDA US Food and Drug Administration, IMDRF International Medical Device Regulators Forum, X-ray X-radiation, CT Computed Tomography, MRI Magnetic resonance imaging, ECG Electrocardiogram, EEG Electroencephalogram.Table 3AIMDs regulatory classification by the USA, Europe and China, respectivelyUSAEuropeChinaThe determination of the AIMD category is based on the combination of the sufficiency of the information provided to assure the safety and effectiveness of the device, intended use and devices risks. Taken together, these factors can be utilized to place the AI/ML-based SaMD into classes I, II, or III to determine the extent of regulatory controls (21 C.F.R. § 860).Devices shall be divided into class I, Class II a, Class II b, and Class III, taking into account the intended purpose of the devices and their inherent risks; Annex VIII details the implementation of device classification34. So, no matter whether the devices are AI-related or not, the classification rules always apply to them. The AI proposal/AI Act sets out harmonized rules for AI systems following a proportionate risk-based approach and lays down a solid risk methodology to define “high-risk” AI systems that pose significant risks to the health and safety or fundamental rights of persons31.The determination of the AIMD categories relies on the combination of the intended purposes of the product, and maturity of the algorithm used33.1. IF [the algorithm has low maturity (i.e., not approved before or its safety and effectiveness have not been proved before)] & [used for decision support (e.g., provide clinical diagnosis or treatment suggestions on lesion feature recognition, lesion stage determination, medication guide, or treatment plan design)];THEN [the AIMDs shall be classified as class III];2. IF [the algorithm has low maturity] & [used for non-decision support (e.g., only provide reference information like process data or measurement)];THEN [the AIMDs shall be classified as class II];3. IF [the algorithm has high maturity (i.e., its safety and effectiveness have been fully proved)];THEN [the AIMDs shall be classified according to the existing classification legislation on general medical devices].AIMD Artificial intelligence medical device, AI/ML artificial intelligence and machine learning, SaMD software as a medical device, C.F.R. Code of Federal Regulations.

A comparative overview of AIMDs regulation in the USA, Europe and China

AIMDs regulatory definitions by the USA, Europe and China, respectively

AIMDs regulatory classification by the USA, Europe and China, respectively

## Section: From AI to AIMDs

Although AI dates back to 1956 at Dartmouth, it has developed into a very broad concept and has not yet converged to a well-accepted unified definition. It continues to evolve with the vision of achieving super-human performance. However, from a long-term perspective, we are still at an early stage. When it comes to AIMDs, AI-empowered medical devices are relatively new to researcher’s investigation. The explosive success in many application domains including computer vision and natural language processing, has triggered various research motivations to equip the traditional clinical practice with AI tools. This open up an area of inquiry where it is possible to improve the workflow efficiency and facilitate the early diagnosis by replacing several procedures with AI assistants. As an umbrella word, “AI” is also sometimes being studied under the name of machine learning (ML). Therefore, AI and ML will be interchangeably used in this paper. In addition, NMPA has specifically pointed out that they would not make a strict distinguishment between AI and ML to medical devices.

In general, AI can be classified into model-based and data-based types, and the AI used in AIMDs normally belongs to the latter. Remarkably, data-based AI methods present an additional benefit thanks to the availability of medical data. According to the presence of data label, AI can be also grouped into four types, namely supervised-learning-based, unsupervised-learning-based, semi-supervised-learning-based and reinforcement-learning-based methods. When an AI algorithm is intended to be developed into an AIMD, acting as a special assistant in clinical practice, its intrinsic characteristics associated with AI have to be considered carefully, including ethics, explainability, reliability, privacy, bias, fairness, adaptability, reproducibility and so on.

## Section: Methods

To gain a deeper understanding of approved AIMDs, we conduct a mini-review of current research analyzing approved AIMDs. While most existing research works focus on interpreting and analyzing the regulatory approaches for AI medical device approvals in the USA and Europe3–7, this paper aims to expand this analysis by including China, thereby providing a more global perspective on AIMDs development. In 2019, the Center for Medical Device Evaluation (CMDE) of NMPA, issued a key document on the topic: “Key Review Points for Deep Learning Assisted Decision-Making Medical Software”. This document provided comprehensive review requirements covering the entire AI product lifecycle, from requirement analysis and algorithm development to verification and validation stages. In 2022, CMDE released a revised version titled “Artificial Intelligence Medical Device Technical Review Guideline”. Additionally, CMDE has been developing disease-specific review guidelines, detailing more specific requirements for devices with particular functions. Concurrently, the National Institutes for Food and Drug Control (NIFDC), another division of the NMPA, is formulating standards to support these guidelines by specifying how to meet the requirements. Although currently recommended, these standards could potentially become mandatory in the future. Figure 1 demonstrates a non-exhaustive list of the progress made by the China regulatory body in regulating AIMDs. In order to determine the approved AIMDs across the global market, we aim in this section to identify and analyze the AIMDs approved in China as of July 2023. A common challenge in assessing AIMDs is the lack of structured, publicly available AIMD databases. Therefore, we applied the following specific search strategies and selection criteria to conduct analysis. There are no human or animal participants in this study and informed consent or ethical approval is not required.Fig. 1Overview of NMPA working framework and current progress on regulations and standards applicable to AIMDs.NMPA National Medical Products Administration, AIMD artificial intelligence medical device, DL deep learning, CT Computed Tomography, CADx Computer-Assisted Diagnosis, CADe Computer-Assisted Detection, AI artificial intelligence, CTA Computed Tomography Angiography.

NMPA National Medical Products Administration, AIMD artificial intelligence medical device, DL deep learning, CT Computed Tomography, CADx Computer-Assisted Diagnosis, CADe Computer-Assisted Detection, AI artificial intelligence, CTA Computed Tomography Angiography.

NMPA National Medical Products Administration, AIMD artificial intelligence medical device, IT Information Technology, AI artificial intelligence.

## Section: Methods › Data source, search strategy and selection criteria

We included AIMDs approved in China as of July 25, 2023.

Although there is not a specific database for AIMDs, the official NMPA website hosts a comprehensive database of all registered medical devices8. The challenge, however, is that this database’s search engine only allows queries based on product code, name, and company name, none of which directly indicate AI involvement. This limitation makes it impossible to search specifically for terms like “Artificial Intelligence” or “Machine Learning” to filter for AIMDs. Thus, on one hand, directly acquiring the official AIMD product list is not feasible. On the other hand, the database only supports search entry using a keyword, making it impossible to pull the entire medical device list. Manually reviewing the entire database of medical devices is also impractical.

To address this challenge, we leveraged NMPA guidelines on medical device naming, which require AIMDs to include specific components in their names, such as the type of input data (e.g., CT scan, fundus photograph), target disease, intended use (e.g., computer-assisted detection/triage/diagnosis/assessment), etc. Utilizing this naming convention, we performed keyword searches in the NMPA database with terms like “computer assisted detection,” “computer assisted triage,” “computer assisted diagnosis,” and “computer assisted assessment,” followed by a manual review of the results.

To ensure our list of AIMDs was as complete as possible, we used every target disease identified in the initial search results as keywords for subsequent searches. Additional online sources, such as AIMDs analytical reports posted on the international medical society websites, manufacturer advertisements, and news articles, were also reviewed. We further verified our findings by searching for the manufacturer name or device name on the NMPA website, followed by a manual review to assess AI relevance. However, the manual review and identification process might be hampered by the brevity of the attached summary tables on the NMPA website, which are typically less than a page and provide insufficient detail to determine AI relevance. While the NMPA does publish more comprehensive multi-page review reports for certain devices, only a few review reports are selected for publication rather than reports for all registered devices. These reports, when available, contain detailed information, including safety summary, clinical performance, algorithms used, validation methods, and the number of sites involved. Insufficient public information makes identification more difficult. In cases where it was unclear, we investigated the manufacturer’s website for more clarification. Devices that lacked sufficient information, even after consulting both NMPA and manufacturer websites, and those with vague or scarce information, were excluded from our selection (see Fig. 2).Fig. 2Selection flowchart for inclusion of AIMDs approved by the NMPA.NMPA National Medical Products Administration, AIMD artificial intelligence medical device, IT Information Technology, AI artificial intelligence.

During the review process, both two rounds of manual review were conducted independently by authors Y.L. and W. Y. to try to obtain a more consistent result. For any identifications in doubt, the authors would review again and discuss them together in a face-to-face manner until they reach a consensus.

Through our selection process, we collected a total of 59 approved devices that met our selection criteria

NMPA National Medical Products Administration, AIMD artificial intelligence medical device, IT Information Technology, AI artificial intelligence.

## Section: Methods › Data extraction

For all selected AIMDs, the following characteristics were collected: device name, manufacturer name, approval date, intended use, origin city of the manufacture, and device classification. We also extracted information regarding the medical specialty each device is associated with, the specific type of AI algorithm employed, and the body area targeted by the device. Supplementary Table 3 lists all identified NMPA approved AIMDs and their characteristics.

## Section: Results

Our search identified a total of 59 AIMDs, which formed the final cohort for our study. The number of AIMDs approved by the NMPA has steadily increased: from 9 devices in 2020, marking the year of the first AI-enabled medical device approval, to 13 in 2021, and further to 25 in 2022. In the first half of 2023 alone, up to July 27, 12 additional AIMDs had been approved (shown in Fig. 3). It is important to note that these 59 devices are all classified as Class III devices by the NMPA. Eight (13·56%) out of 59 devices did not mention AI or any other terms that could imply the presence of an AI algorithm. Among the rest of devices, the majority, 50 (84·74%), specified the use of deep learning, and only one device employed the region growing technique, which is one of the most popular AI algorithms for segmentation tasks, as described in the review report published by the NMPA. For eight such unclear cases, as illustrated in Fig. 2, another round of manual review was conducted by consulting their official websites to determine whether they belong to AIMDs. All 59 devices were designed for professional use, with none intended for patient use. In terms of medical specialties, 22 (37%) of the 59 AIMDs were approved for radiology, followed by 10 devices for cardiovascular applications, eight devices for ophthalmology, six devices for neurology, five devices for orthopedics, three devices for internal medicine, two devices for hematology, two devices for endocrinology and one device for therapeutic radiology (see Fig. 3).Fig. 359 NMPA-approved AI/ML-based medical devices.Features shown in the figure include approval years, descriptions of AI-enabled medical technologies, and related medical specialties. NMPA National Medical Products Administration, AIMD artificial intelligence medical device, AI/ML artificial intelligence and machine learning, CT Computed Tomography, FFR Fractional Flow Reserve, ECG Electrocardiogram.

Figure 4 demonstrates the geographic distribution of cities where manufacturers have developed approved devices. It can be seen that they are mainly concentrated in Beijing (23 devices), Shanghai (nine devices), Shenzhen (eight devices) and Hangzhou (eight devices). Through the figure, it can be observed that among the top four cities with large number of approved AIMDs, three out of them happen to be first-tier cities in China, of which there are only four in total. In comparison to other cities, the first-tier cities are recognized for their high level of development and substantial economic activities. They typically have a relatively high concentration of academic institutions and healthcare facilities with research units. As for the fourth city, Hangzhou in Zhejiang, it does not belong to first-tier cities. However, it is known for its large number of internet companies and robust tech industry, largely due to the presence of major companies like Alibaba.Fig. 4The geographic distribution of origin cities for the 59 NMPA-approved AIMDs.NMPA National Medical Products Administration, AIMD artificial intelligence medical device.

Figure 5 provides a visualization of main manufacturers leading the development of AIMDs and their numbers of approved AIMDs for each type. Out of 59 devices, 40 (67·79%) were developed by AI companies that have had more than one device approved. For instance, Shukun has nine devices approved by the NMPA, covering lung nodule detection, pneumonia triage, rib fracture detection, Fractional Flow Reserve (FFR) computation, intracranial hemorrhage triage, coronary artery stenosis triage, ischemic stroke assessment, head and neck assessment. DeepWise follows with six approved devices, then InferVision, United Imaging, and Carewell, each with four devices. The most common applications of these 59 devices include computer-aided software for detection, triage, assessment, and diagnosis. Other applications involve FFR computation (two devices), contouring of the region of interest, and surgery planning (one device each). Supplementary Table 4 details the target disease distribution of the approved AIMDs, covering approximately 19 medical scenarios, including lung nodule detection with 11 medical devices (18·6%), pneumonia triage with six medical devices (10·1%), eye disease diagnosis with eight (13·5%) medical devices (six devices on Diabetic retinopathy, one device on glaucoma and one device on both), fracture detection with six (10·1%) medical devices, ECG with four (6·7%) medical devices from the same company Lepu Medical (Carewell), etc. Of these medical devices, the majority is based on CT scan, with others utilizing fundus photograph, X-ray, ECG, endoscopic image, pathology image, etc., as shown in Fig. 6.Fig. 5A visualization of leading manufacturers and their numbers of approved AIMDs for each type.The types are classified by the hardware and the fill color gradation in each tile represents different numbers of AIMDs which are added to each tile. The top plot shows the total number of approved AIMDs for each manufacturer. AIMD artificial intelligence medical device. CT Computed Tomography, ECG Electrocardiogram, X-ray X-radiation.Fig. 6Types of data based on which the approved AIMDs were developed.AIMD artificial intelligence medical device, CT Computed Tomography, ECG Electrocardiogram, X-ray X-radiation.

Features shown in the figure include approval years, descriptions of AI-enabled medical technologies, and related medical specialties. NMPA National Medical Products Administration, AIMD artificial intelligence medical device, AI/ML artificial intelligence and machine learning, CT Computed Tomography, FFR Fractional Flow Reserve, ECG Electrocardiogram.

NMPA National Medical Products Administration, AIMD artificial intelligence medical device.

The types are classified by the hardware and the fill color gradation in each tile represents different numbers of AIMDs which are added to each tile. The top plot shows the total number of approved AIMDs for each manufacturer. AIMD artificial intelligence medical device. CT Computed Tomography, ECG Electrocardiogram, X-ray X-radiation.

AIMD artificial intelligence medical device, CT Computed Tomography, ECG Electrocardiogram, X-ray X-radiation.

## Section: Comparison between the USA and China

As indicated in Table 1, the absence of an official database for AIMDs approved in Europe presents significant challenges in collecting and comparing associated information. Therefore, this paper focuses on a comparative analysis between the USA and China. For a detailed analysis of Europe, interested readers are referred to previous studies7, with a comprehensive review available in the supplementary Tables 1 and 2. According to the list published by the FDA on October 5, 2022, 521 devices have been included, with the first approval dating back to 1995. This number substantially exceeds the 59 AIMDs approved by the NMPA. Despite potential underestimation of the number of AIMDs in China, there is still a large gap between the total number of devices at the FDA and NMPA. Another contributing factor is the different interpretations and definitions of AI; a broader definition by the FDA has led to more AI-enabled medical devices being approved since 1995. Besides, the start year of AI adoption in healthcare in China is not as early as that in the USA. In China, the first AIMD was not proposed until 2020, known for its FFR computation using deep learning algorithms. From the information provided by the NMPA, it is observed that 50 out of the 59 devices explicitly mention the use of deep learning, which indicates that the scope of AIMDs in China is largely confined to deep learning. Whereas, the FDA approved AIMDs might not only cover the third-generation AI (DL-based), but also the first-generation (rule-based) and second-generation AIs (ML-based).

The labels in y axis denote the device names with manufacturers in parentheses. AIMD artificial intelligence medical device. FDA US Food and Drug Administration, NMPA National Medical Products Administration. AI artificial intelligence, FFR Fractional Flow Reserve, ECG Electrocardiogram.

## Section: Comparison between the USA and China › The analysis of AIMD approvals

A common trend observed is the significant approval of AIMDs for radiology use, with 23 devices (39%) in China and 392 devices (75·2%) in the USA. This trend can be attributed to the continuously growing volume of radiological imaging data, which disproportionately exceeds the number of available trained radiologists9. The primary motivation behind the development and integration of AI-enabled tools in radiology has been to alleviate the increasing workload on radiologists and to enhance clinical care efficiency. The remarkable success of deep learning algorithms in image detection, segmentation, and classification tasks has led to the wider application of AI in computer-assisted diagnostics to meet clinical needs. Compared to other medical specialties, radiology data are more readily accessible and provide a rich resource for scientific and medical exploration.

During our study period, seven devices received approval from both the FDA and the NMPA. Notably, six of these were first approved by the FDA in the USA before gaining approval in China, as shown in Fig. 7. The exception is Keya’s DeepVessel FFR, which received NMPA approval first. A previous study indicated that most AI-based medical devices commonly receive CE marking in Europe and subsequent approval in the USA, initially gaining approval in Europe10. It was suggested that the FDA’s regulatory approach for medical devices may be more rigorous than Europe’s. Following this logic, companies might prefer to first seek FDA approval before pursuing approval in China. However, it should be noted that the approval time is neither reflecting strictness nor efficiency of a country’s regulation. In addition, we also identified the home-based countries of the companies, which ideally might be a related factor to their first approval county. It turned out that all of their home-based countries were China, and there was not much correlation with the approval time.Fig. 7Time difference between common AIMDs in FDA and NMPA approval time (months).The labels in y axis denote the device names with manufacturers in parentheses. AIMD artificial intelligence medical device. FDA US Food and Drug Administration, NMPA National Medical Products Administration. AI artificial intelligence, FFR Fractional Flow Reserve, ECG Electrocardiogram.

Among the 521 AI-based medical devices with FDA approval, 500 (96%) were approved through the 510(k) regulatory pathway, 18 through the De-novo pathway, and only three via the Premarket approval pathway. However, it is noteworthy that all devices were classified as Class II in the USA. In contrast, all the identified AIMDs approved in China were reviewed as Class III devices. Such a difference in the class distribution might be due to the difference in AIMDs classification between the USA and China. Specifically, the determination of AIMD categories relies on a combination of the intended purposes of the product and the maturity of the algorithm used. If the algorithm has low maturity (i.e., not approved before or its safety and effectiveness have not been proved before) and is used for decision-support purposes, then the associated AIMDs should be classified as class III types. Since the first AIMD approved by NMPA was in 2020, most algorithms are new in the field of medical devices, thus being classified as class III.

China’s regulatory framework includes point-by-point requirements during the review process, as outlined in regulations and standards, aiming to establish a comprehensive life-cycle supervision model. While all regulatory bodies require manufacturers to provide evidence of safety and performance, the NMPA has published a review guideline detailing how manufacturers should provide such evidence. This guideline includes explicit checklists for manufacturers to follow, encompassing the entire algorithm development process from algorithm specification, data collection, algorithm selection and training, to algorithm testing, and validation. It essentially requires developing a ‘digital twin’ of the algorithm to ensure traceability, enabling digital oversight of the entire process and the potential to reproduce the algorithm model. This can be interpreted as using “rules” approach, while FDA uses “standards” approach. In rules approach, rules or formulas are well established to simplify and speed up the review process, and it can be less noisy, i.e. more consistent for easier comparison. Whereas for US, standards approach may provide more room for manufacturer for innovations. Such difference is in line with the fact that most devices try to obtain FDA approval first.

The labels in y axis denote the device names with manufacturers in parentheses. AIMD artificial intelligence medical device. FDA US Food and Drug Administration, NMPA National Medical Products Administration. AI artificial intelligence, FFR Fractional Flow Reserve, ECG Electrocardiogram.

## Section: Comparison between the USA and China › The analysis of regulatory requirements

The NMPA review guideline places special emphasis on an evidence-based approach relying on data, highlighting the significance of data sufficiency, diversity and representativeness, and addressing data bias in AI algorithm development. Most AI algorithms, particularly those based on deep learning, are heavily data-driven. With the same model structure, the use of different training data can lead to vastly different model parameters. Therefore, training a model on an “inappropriate” dataset could result in poor performance. The guidelines strongly recommend using training data from multiple sources, such as various hospitals, and ensuring balance across disease subtypes and demographic subgroups. This is consistent with the findings from a previous study6, highlighting deep learning models at a single site alone can mask weakness in the models and lead to worse performance across multiple sites. In that case study, significant performance drop-offs were observed when comparing within-site tests to evaluations on other sites. To prove data sufficiency, the guideline recommends depicting a curve of model performance over the amount of training data used to demonstrate the model performance across increasing number of training size. As the size of the training data increases, the model performance is expected to improve and eventually stabilize, which implies that enough data has been provided. Regarding algorithm testing, while balance in the testing data distribution is not required, it should reflect real-world scenarios by ensuring high prevalence similarity in testing data to the target population.

In addition, stratified performance evaluations across disease subtypes, device types, different geographical regions, and demographic subgroups are specified for analysis. By quantifying how AI performs across diverse populations, it helps to explore the factors (e.g., device types, disease types, demographic groups) that might impact the model performance, thereby improving the explainability of the devices and gaining a more comprehensive understanding. Moreover, Unlike the general performance evaluation on the testing data, which is the most essential part and mandatory for each AIMD, adversarial and stress tests are advisable if applicable, to explore the potential of AI models. Besides the above functional performance evaluation (e.g. sensitivity and specificity for classification tasks, DICE metric for segmentation tasks), non-functional performance evaluation such as timeliness is also important to report and submit. With the increasing complexity of AI algorithms, running time can vary significantly, while waiting time is always an important indicator for user satisfactory.

Noted that before data is ready for AI model development, the data preparation stage that includes data collection, data organization, data preprocessing and data annotation, is also an indispensable part of the AI product lifecycle. All these steps are related to data quality, and data annotation should be given special attention since the performance of the developed AI models directly depends on the quality of data annotation. Thus, the details of how the dataset is curated and annotated are required to be specified as well.

We believe that the regulatory strategy, which requires recording every possible useful piece of information generated during the algorithm development process, is crucial for advancing transparency and enhancing understanding of these medical devices among various stakeholders (e.g., users, buyers, researchers). This rich information, encompassing data aspects, safety, and clinical performance, not only enables learning from the strengths and weaknesses of the medical devices but also facilitates more intuitive comparisons between devices with similar applications. The NMPA has even developed regulation documents for specific diseases, pre-defining the information that manufacturers need to provide and the performance indicators that should be evaluated. As illustrated in Fig. 1, the review guideline outlines general principles, while the standards serve as complementary instructions, and the disease/application-specific regulations detail the variations in requirements across different device types. By adhering to consistent guidelines for similar devices, the information provided by manufacturers becomes uniform, simplifying comparative analysis. However, a common issue in both the USA and China is that this information is currently accessible only to regulators and reviewers, with the public receiving vague and limited details. More transparency from the FDA and NMPA would be beneficial, offering companies and researchers a clearer understanding of the current landscape, potential gaps for clinical improvement, and enabling stakeholders to compare and assess these tools more effectively for informed decision-making regarding AI commercial solutions for clinical use. The recent surge in academic progress has been matched by a flurry of activity in companies, with a multitude of commercial AI-based solutions now available (as shown in Fig. 3). For instance, 11 devices have been approved for lung nodule detection and 8 devices for diagnosing diabetic retinopathy or chronic glaucoma. Without sufficient information from the NMPA, it is challenging for radiologists to choose the most suitable commercial AI solution for their specific needs.

Even though there is a growing trend of AIMDs approvals, the number of approved AIMDs is still far smaller than the AI models reported in research. In research, there are also guidelines followed by researchers for reporting and assessing the risk of bias in AI models, such as TRIPOD-AI11, SPIRIT-AI12, CONSORT-AI10, DECIDE-AI13 and so on. These reporting guidelines are being developed in close collaboration with key stakeholders consisting of clinicians, computer scientists, journal editors, researchers, industry leaders, regulators, funders, policy makers, patient groups and so on, to generate a consensus applicable across the community. Furthermore, groups from typically underrepresented regions are also engaged to ensure the guidelines are applicable and international across a global scale14. By contrast, different regulatory agencies use highly variable methods for definition, production, approval, marketing and postmarketing surveillance. In addition, guidelines typically focus on a part of development pathway for AI systems with an emphasis on scientific evaluation and reporting, whereas government regulations cover the whole lifecycle supervision, paying attention to practical implementation and ethic aspects. A recent review also placed the legal and regulatory aspects in the group of key elements of ethics15. Moreover, government regulations must be complied with through a series of systematic review before AIMDs approval, and the approved AIMDs are held under the sole accountability of the manufacturer. There was a study finding out that, among their study cases, journal publications did not acknowledge the key limitations of the available evidence identified in regulatory documents16. Given the somewhat different focuses of research guidelines and regulatory assessment, as well as the differences across regulatory jurisdictions35, there are gaps between the guidelines and government regulations. These gaps are part of the reason why the number of approved AI models is far smaller than the number published in research. It is also important to note that, besides regulations, which serve as a downstream gatekeeper for the AI industry, upstream factors in the AI supply chain, such as AI base model development and dataset quality, could possibly be another part of the reason that need to be aware of.

## Section: Discussion

In our study in China, 59 AIMDs were identified in the NMPA search, all classified as class III. The number of AIMDs has been significantly increasing since 2020, the year when the first AIMD was approved by the NMPA. The most common application for these AIMDs is in radiology. Although NMPA-approved AIMDs share similarities with CE-marked devices in Europe and FDA-approved devices in the USA, such as a growing trend in approvals and a focus on radiology, there are still many differences between them. One major difference is the smaller number of AIMDs approved in China compared to Europe and the USA. This disparity is partly due to the broader definition of AI and the earlier start year of AIMDs in the USA, which leads to more AI-enabled medical devices. For instance, the first AI-enabled device was approved by the FDA in 1995, whereas in China, it was not until 2020. Another key difference is that all NMPA-included AIMDs are class III, implying a higher risk level than the AI-enabled medical devices approved by the FDA, which are mostly class II. This reflects NMPA’s more cautious approach towards AI-empowered medical devices. The NMPA uses “rules” approach by imposing specific requirements and pays close attention to aspects like data quality, annotation, representativeness, algorithm description, and performance evaluation, including both functional and non-functional aspects like generalization ability, robustness, and timeliness. The functional performance evaluation encompasses overall average performance in corresponding metrics (e.g. sensitivity and specificity for classification and DICE for segmentation), stratified performance, and, if applicable, adversarial and stress tests. By contrast, FDA uses “standards” approach, and such difference may also contribute to another observed trend where six out of seven commonly approved AIMDs by both the FDA and NMPA first received approval in the USA before China, since FDA tends to provide manufacturers more diversity room for review innovations. Despite the NMPA’s emphasis on transparency and the importance of submitting comprehensive information, they have not opted to publish more detailed information. Consequently, we are unable to fully leverage these rich resources for AI development in clinical practice. More transparency in the review comments is anticipated to help researchers to determine the directions and methods for developing AI algorithms to improve upon the existing ones. We hope that with the constant improvement of the AIMD review framework and process, more information will become accessible to researchers of interest. In addition, a more complete AIMD review ecosystem could not only facilitate an increase in the number of AIMDs but also expand new AI applications in the medical field and push the boundaries of AIMDs in the near future.

## Section: Supplementary information

Supplementary material

Supplementary material


---

# Reinvent 4: Modern AI–driven generative molecule design

- **Authors:** Hannes H. Loeffler, Jiazhen He, Alessandro Tibo, Jon Paul Janet, Alexey Voronov, Lewis Mervin, Ola Engkvist
- **Issuer:** Journal of Cheminformatics
- **Type:** Scientific article
- **Published:** 2024-02-21
- **DOI:** 10.1186/s13321-024-00812-5
- **Source:** https://doi.org/10.1186/s13321-024-00812-5
- **Licence:** CC-BY

## Section: Abstract

AbstractREINVENT 4 is a modern open-source generative AI framework for the design of small molecules. The software utilizes recurrent neural networks and transformer architectures to drive molecule generation. These generators are seamlessly embedded within the general machine learning optimization algorithms, transfer learning, reinforcement learning and curriculum learning. REINVENT 4 enables and facilitates de novo design, R-group replacement, library design, linker design, scaffold hopping and molecule optimization. This contribution gives an overview of the software and describes its design. Algorithms and their applications are discussed in detail. REINVENT 4 is a command line tool which reads a user configuration in either TOML or JSON format. The aim of this release is to provide reference implementations for some of the most common algorithms in AI based molecule generation. An additional goal with the release is to create a framework for education and future innovation in AI based molecular design. The software is available from https://github.com/MolecularAI/REINVENT4 and released under the permissive Apache 2.0 license. Scientific contribution. The software provides an open–source reference implementation for generative molecular design where the software is also being used in production to support in–house drug discovery projects. The publication of the most common machine learning algorithms in one code and full documentation thereof will increase transparency of AI and foster innovation, collaboration and education.Supplementary InformationThe online version contains supplementary material available at 10.1186/s13321-024-00812-5.Keywords: Generative AI, Reinforcement learning, Transfer learning, Multi parameter optimization, Recurrent neural networks, Transformers

## Section: Introduction

Molecular Design is the creation of novel molecules with desired properties for a given problem in chemistry, material science or nanotechnology. Ideally, this would be done in a systematic fashion rather than through trial–and–error. In drug discovery this is often approached with rational drug design [1] which makes significant use of computers and algorithms to generate novel molecules. Specifically, so–called de novo methods create molecules from scratch i.e. without or little prior molecular information [2]. In this context we will discuss de novo molecular design using generative AI models [3] and focus in particular on the implementation of the REINVENT software. The application of AI in drug discovery has been debated and challenged. It is therefore of high value to the scientific community that there exist reference implementations in the public domain of the most common algorithms for generative molecular design to facilitate a nuanced debate. It is also hoped that the released software can contribute to the education and innovation in the field of AI-based molecular design.

Generative AI models capture the underlying probability distribution of known molecules and their local relationships to each other (distribution learning). This distribution is in principal unknown and thus the modelled distribution only an approximation. However, we can define a “chemical space” in this way from which can be extrapolate into novel chemical space. Statistical methods are then used to sample from the distribution i.e. generate novel molecules. The field is still relatively new and experimental validations in the public domain are slowly starting to emerge [4–7] but various useful perspectives and reviews of the methodology have already appeared in the literature [3, 8–11]. Here, we will focus on small molecule design but other modalities are being investigated as well [12, 13].

Numerous AI model architectures have been developed for generative molecular design e.g. variational autoencoders (VAE) [14, 15], generative adversarial networks(GAN) [16], recurrent neural networks (RNN) [6, 17–20], transformers [21, 22], flow models [23, 24] and diffusion models [25] (either directly generating in 3D [26, 27] or from 1D SMILES strings [28]), reaction based models [29]. The molecular representation used for these algorithms can be different and can be typically categorized with their dimensionality [13, 30]. All these methods have their relative merits and there is no one solution that uniformly outperforms the others. Various benchmarks have been designed to validate technical aspects of molecular generation and optimization [31, 32].

Molecular design can be framed as an inverse design problem. In forward design we would modify existing compounds until they satisfy our criteria while inverse design first states the properties the molecule must possess and thus informs an algorithm on how to create the molecules. Drug molecules in particular must follow a stringent property profile before being approved as safe and efficacious medicines including affinity to the target(s), selectivity against off–targets, the right physico–chemical properties, the right ADME (absorption, distribution, metabolism, excretion) characteristics, good PK/PD (pharmacokinetics/pharmacodynamics), favourable toxicology, chemical stability. Also very importantly synthesizability [33], the potential to scale-up a synthetic route and the requirements of green chemistry [34]. This highlights the complexities in designing a successful drug and the requirements for algorithms to solve this. The inverse design problem is the attempt to map a (manageable) number of properties back to a vast chemical space. Various attempts have been made at predicting the success of a compound in the clinical stages by trying to find the “right” combination of molecular properties [35, 36].

Molecular design should be seen as part of the DMTA (design, make, tests, analyse) cycle. Generative models can contribute to the design part while robotic systems can contribute to make, test and analyse in an attempt to create a fully automated closed–loop experimentation system [37, 38]. The ambition is to speed–up molecular design in a systematic and efficient manner. Levels of automation have been defined and it is clear that decision making and synthesizability are key factors in achieving full automation [39].

In this contribution the progress of REINVENT as a framework for molecular generative AI is described. REINVENT is in production and continuously maintained. REINVENT tackles the inverse design problem through reinforcement learning [19, 20, 40–42] using RNNs and transformers as deep learning architectures based on SMILES strings as molecular representation. Here we describe the new version 4 emphasizing novel features like combined reinforcement/curriculum learning (RL/CL) staged learning, new transformer models for molecule optimization, full integration of all generators within all algorithmic frameworks: transfer learning (TL), RL, CL, reworked scoring subsystem utilizing a plugin mechanism for easy extension and the TOML configuration file format in addition to JSON (incompatible with previous releases). REINVENT 4 is a well–designed and complete molecular design software solution. The code base has been largely rewritten and all software and models are available in a single repository. The descriptions of the original REINVENT version 1 and version 2.0 have been published elsewhere [19, 20]. The code of version 3 has been released as open–source software but without accompanying manuscript.

REINVENT has been shown to outperform many other methods of molecular optimization in terms of sample efficiency [43] but is also successful in proposing realistic 3D molecules as shown in a recent docking benchmark for generative models surpassing many graph–based methods [44]. It has also been demonstrated that the algorithm can produce chemistry outside of the training set with certain CL protocols [45]. Table 1 compares functionalities in REINVENT 4 with the previous version 2.0 and DrugEx version 3 [18]. DrugEx is another open–source generative AI software similar in spirit to REINVENT and also in production state. We do not compare here to research based software released for in a specific publication for reproducing the claims in the publication.

Comparison of major functionalities in REINVENT and DrugEx

## Section: Theory

Here the theory underlying REINVENT 4 is described. The specifics of the software is also highlighted. A comprehensive collection of various capabilities that are otherwise distributed in previous publications are provided [19, 20, 46–48].

Illustration of idealized behavior of priors, transfer learning agents and reinforcement/staged learning agents. In all cases, the models describe the probability of sampling a given token sequence corresponding to a specific molecule (green squares), represented by a colored fill. The prior model is trained to increase probability over all drug–like molecules. A transfer learning agent built from this prior increases the likelihood on a specific region (blue, middle). In staged learning (red, right), starting from the transfer learning agent, likelihood of sampling high-scoring sequences is iteratively increased, resulting in concentration on high-scoring regions (red polygon)

Simple experiment demonstrating adaptable learning behavior starting with the default REINVENT 4 agent. 500 epochs of RL are run with a scoring function that rewards molecular weight ≥1500 Da, before it is switched in a second stage that rewards molecular weight ≤1500 Da, showing the score a, molecular weight b, agent and prior likelihoods c and loss function d averaged over all molecules at the end of each epoch. The loss lower bound (Eq. 7) is also shown in d. A dashed line indicates the change of scoring function. The run used default settings: batch size of 128 and σ=128

## Section: Theory › Generating molecules

All REINVENT 4 models consist of sequence–based neural network models that are parameterized to capture the probability of generating tokens t in an auto-regressive manner. The models are called agents. A sequence describes a SMILES string which represents a molecule. The tokens are characters or character combinations in SMILES strings, see Affitional file 1. Tokens are drawn from a fixed vocabulary t∈V, created at training time (and fixed at inference time implying that input SMILES must follow the model’s vocabulary). A special termination token indicates completion of the sequence. REINVENT 4 supports unconditional and conditional agents which describe probability distributions over sequences from V. The joint probability P(T) for unconditional agents of generating a particular sequence T of length ℓ with tokens t1,t2,…,tℓ is given by

Conditional agents model a joint probability P(T|S) of generating a particular sequence T of length ℓ given an input sequence S given by

From Eqs. 1 and 2 we define the negative log-likelihood as

for P(T) and P(T|S), respectively.

As in previous versions, a number of prior agents are made available (details in Priors). These are foundation models, trained in an unsupervised fashion with teacher–forcing [49] using SMILES strings from large public data sets of molecules. The teacher–forcing strategy feeds the model with the actual output from the data set (ground truth) as input during training instead of the network’s generated output. Once trained, REINVENT 4 agents acquire an understanding of the syntax of the SMILES strings, enabling them to generate valid molecules. In practice this amounts to updating the weights of the models to decrease the negative log-likelihood of either Eqs. 3 or 4 (depending on the model type) over all molecules in the training data set.

Because the models are trained on all input molecules in the same way, priors represent unbiased molecule generators (however, still biased due to the limited chemical space of the training set), resulting in a theoretically uniform distribution over the training molecules. These models possess the capability to sample molecules that goes beyond just re-sampling the training data. For example, a prior trained on 1 million molecules can easily sample 100 s of millions of unique, valid molecules [50]. Training priors on multiple equivalent SMILES representations of the same molecule has been shown to result in more expressive priors [51].

REINVENT 4 supports two decoding strategies, namely multinomial sampling used for e.g. by [22, 52] and beam search [53]. Multinomial sampling allows fast, non–deterministic generation of compounds. At each step, a token is randomly selected based on the probability distribution over the vocabulary. The current implementation supports a positive temperature–like parameter K (default K=1) used to scale the probability distribution. When decreasing the temperature, i.e. K<1, the distribution becomes sharper: the chance of high probability tokens being selected increases, conversely the chance of low probability tokens being selected decreases. This results in less randomness and so more determinism. More randomness is introduced when the temperature is increased (K>1) which causes the distribution to become flatter and lower probability tokens to be selected more preferentially. Multinomial sampling might suffer from mode collapse i.e. sampling might tend to produce a small number of compounds. The computational complexity for multinomial sampling is O(ℓ·|V|), where ℓ is the length of tokens and |V| is the size of the vocabulary.

In contrast, beam search is a deterministic approach that always generates unique compounds. However, it is computationally more expensive than multinomial sampling as it scales as O(B·ℓ·|V|), where B is the beam size. Note that for both techniques the complexity of the underlying generative model impacts the performance. This complexity arises because SMILES strings are generated iteratively by feeding the transformer with n-1 tokens to obtain the nth token. In fact, for multinomial sampling, the model needs to compute the probabilities of each possible token, while for beam search, we also need to store the B most probable SMILES subsequences.

REINVENT 4 includes Mol2Mol, a conditional prior agent, as described in [54] which allows for a systematic exploration of the chemical space. The prior was trained on over 200 billion pairs from Pubchem [55] for which their Tanimoto similarity, calculated with ECFP4 count fingerprints, was ≥ 0.50. Furthermore, the prior training was regularized with the ranking loss, allowing to directly link negative log-likelihood to similarity.

## Section: Theory › Transfer learning

Transfer Learning (TL) are methods that re–use existing knowledge to facilitate the learning of another, related task. In machine learning this is typically applied to retrain a large model with a small amount of data to efficiently obtain a new improved model and can accordingly be used when only little data is available for the new task. TL can thus be seen as fine–tuning an existing model. TL has been applied successfully in drug discovery [56] specifically it has been shown that a focused generative model can produce a similar fraction of active molecules as experience replay [7] (see "Inception" for an explanation of experience replay).

In REINVENT 4, transfer learning is conceptualized as retraining of a prior model using the same teacher–forcing strategy as in the pre–training of the prior model (see Generating Molecules). A small, task–focused data set is chosen, for example a data set containing active molecules for a particular drug target. TL then creates a new agent that is specifically biased toward generating analogues to these active molecules. In this way the agent will be able to generate relevant molecules more quickly.

## Section: Theory › Reinforcement learning

Reinforcement Learning (RL) describes various optimization methods in machine learning where an agent acts in an environment to learn a strategy (policy or goal). The agent is rewarded when the action is beneficial to the goal or receives negative feedback when the action isn’t beneficial. For example, in generative molecular design the goal is to drive a prior model such that the generated molecules satisfies a predefined property profile. RL is a frequently used optimization method in drug discovery [56].

In REINVENT, RL is used to iteratively bias the molecules generated by an agent (normally a prior or transfer learning agent) via a policy gradient scheme (Fig. 1). In a drug discovery project, the aim is typically not to create a new model but rather to generate molecules which score highly according to the provided scoring function. This is achieved by providing a scalar score, S∈[0,1], for each token sequence T (representing a molecule) generated in each epoch. This is used to define a so–called augmented likelihood for each sequence as

First proposed in [19], this expression combines the reward signal with the likelihood of the sequence under the fixed, generalist prior model, which serves as a regularization term to control the generation of plausible sequences from a chemistry viewpoint. The balance between the reward and regularization is controlled with the scalar parameter σ≥0. σ is a user–adjustable parameter and it can have a major impact on performance [43].

In the “Difference between Augmented and Posterior” (DAP) strategy [46], the augmented likelihood is used to define a loss for each sequence in the batch, computed as

were logPagent(T) is the likelihood of sequence (T) under the current agent. This loss is averaged over all molecules generated in a batch and then the current agent is updated to reduce this loss via a stochastic gradient descent method (Sect. "Other Parameters"), i.e. bring the likelihood of the sequences closer to logPaug(T). The only term in 6 that is a function network parameter is Pagent. The presence of the prior in these expressions constrains how far the RL agent can stray from the prior, similar to proximal policy gradient methods, except that the prior is static during the RL process.

This definition of the augmented likelihood and loss function has a few non–obvious implications. Firstly, the form of Eq. 5 and non–negativity of the score means that the likelihood for sequences is only increased (or unchanged) relative to the prior in each epoch. A molecule that obtains a zero score will have a augmented likelihood identical to that obtained under the prior model, and so low–scoring molecules have little impact on the state of the agent, i.e. there is limited learning from negative examples early in the run.

However, the behavior can be markedly different in the case of dynamic variation in how the reward is computed during the run. To illustrate this, we consider a simple experiment where we start with the REINVENT 4 prior: we run 500 epochs of RL with standard settings (σ=128) and a scoring function that encourages generation of extremely large molecules (1500 Da) relative to the drug–like molecules in the prior. At the 500 epoch mark, we move to a second stage where the scoring transform is reversed, encouraging the generation of molecules with ≤500 Da molecular weight. The agent is rapidly able to solve both tasks (Fig. 2a and b).

Despite learning to make large molecules that are highly unlikely under the prior (logPprior(T)<-75, Fig. 2c) for 500 epochs, the agent is rapidly able to adapt to the change in scoring function and generate small molecules again by epoch 550. This transition period is accompanied by the agent likelihood regressing back to be similar to the prior likelihood, before separating again. This plasticity is a capacity that makes these systems adaptive in various settings, for example active- [57] or curriculum learning [58] settings.

Since Eq. 5 have values in -∞,σ, logPaug is not guaranteed to be an obtainable log-likelihood for the discrete distribution of sequences that can be generated by these models (i.e. ≤0), particularly for high scoring sequences and large values of σ. This is not a problem in practice, and while various other loss functions have been considered [46] (and remain available, see RL Learning Strategy), DAP typically provides the most rapid learning and serves as a robust general purpose method. The combination of Eqs. 5 and 6 means that the loss for any sequence is lower-bounded by

This, combined with the observation that the loss is computed with respect to a new batch of ideas for each epoch, can lead to counter-intuitive behaviour where the loss function can increase during RL as the score increases (Fig. 2d). However, this is the expected behaviour as the loss is reduced on the previous batch of molecules, which are not re–evaluated but the agent in the next epoch. Generally, the loss lower bound is highest for high scoring batches that are also likely under the prior, as in the case of the molecules with drug-like molecular weight generated in the second part of the experiment.

Illustration of idealized behavior of priors, transfer learning agents and reinforcement/staged learning agents. In all cases, the models describe the probability of sampling a given token sequence corresponding to a specific molecule (green squares), represented by a colored fill. The prior model is trained to increase probability over all drug–like molecules. A transfer learning agent built from this prior increases the likelihood on a specific region (blue, middle). In staged learning (red, right), starting from the transfer learning agent, likelihood of sampling high-scoring sequences is iteratively increased, resulting in concentration on high-scoring regions (red polygon)

Simple experiment demonstrating adaptable learning behavior starting with the default REINVENT 4 agent. 500 epochs of RL are run with a scoring function that rewards molecular weight ≥1500 Da, before it is switched in a second stage that rewards molecular weight ≤1500 Da, showing the score a, molecular weight b, agent and prior likelihoods c and loss function d averaged over all molecules at the end of each epoch. The loss lower bound (Eq. 7) is also shown in d. A dashed line indicates the change of scoring function. The run used default settings: batch size of 128 and σ=128

## Section: Methods

Information flow in REINVENT 4 for all run modes (green boxes) depicted in the left row. Also shown are the supported generators and the scoring subsystem. A input configuration file in TOML or JSON format controls all aspects of the software. The configuration file may contain “seed” SMILES for the Lib/Linkinvent and Mol2Mol2 generators. Input SMILES strings are needed for staged learning, TL and scoring. NLL is the negative log–likelihood as defined in Eqs. 3 and 4

Summary of REINVENT 4 priors. Mol2Mol comes with six different priors with pairs trained on different types of similarity

The four types of molecular generators in REINVENT 4 illustrating how they work. Reinvent creates new molecules de novo i.e. from scratch, Libinvent decorates a scaffold, Linkinvent identifies a linker between two fragments and Mol2Mol optimizes molecules within a user defined similarity

Summary of REINVENT 4 scoring functions

Summary of REINVENT 4 transforms

## Section: Methods › Reinforcement learning

Reinforcement Learning (RL) is the main molecule optimization method in REINVENT. RL has been re–framed in the new version into staged learning (see "Methods") which allows multiple successive and consecutive RL runs with varying parameters.

Each stage will write out a CSV file which contains all information about negative log likelihoods, total and individual component scores and the sampled SMILES strings. The CSV file is created in real time i.e. every RL epoch is immediately written to disk (the operating system may impose buffering such that the file is written in chunks). This implies that the data in the CSV is unfiltered meaning that invalid SMILES and low scoring compounds will be logged also. It is the user’s responsibility to post–process this file in a meaningful way.

## Section: Methods › Reinforcement learning › RL learning strategy

Previously, four different RL learning strategies in REINVENT were described [46]. It was found that DAP displayed the best learning rate while the others showed very little or no improvement. In version 4 we still offer all four functions but we recommend the DAP for practical use. The other three are still available but are deprecated meaning that they might be removed in future releases.

## Section: Methods › Reinforcement learning › Diversity filter

The diversity filter is, as its name suggests, a mechanism to promote molecular diversity during an RL run. This is primarily based on scaffold diversity using a memory with a user adjustable size. The memory is organized into “buckets” which hold a given scaffold. When the bucket is full every further occurrence of that scaffold enforces a zero score for the whole molecule. Scaffolds can be computed as Murcko type scaffolds, “topologically” which means the scaffold is determined disregarding elements and bond types (unlabelled graph) and scaffold similarity which stores the most similar scaffolds found so far. In the current implementation all scaffold filters also contain a global SMILES string memory of size 1. This means that every further occurrence of the same canonical SMILES string is scored with zero. This happens both locally i.e. within a batch and globally i.e. over the whole run. This implies that SMILES are not de–duplicated in advance conforming with previous versions. Otherwise the behaviour would be altered, see Eq. 6 where duplicates have zero score but their negative log likelihoods are still present.

There is one special “filter” which only penalizes the occurrence of the same molecule and is not part of any of the scaffold filters above. This penalty is recommended for the Mol2Mol generator. The user can adjust the penalizing factor to be between 0 and 1.

## Section: Methods › Reinforcement learning › Inception

Inception, also known as experience replay, can have a profound impact on the learning rate and sampling of desired molecules [7, 59] (see also Additional file for a demonstration). In REINVENT it is a mechanism to memorize the highest scoring molecules and use those scores to contribute to the loss in addition to the loss computed from the scores of the currently sampled batch. This means that the total loss is calculated from two parts: batch loss and inception loss. The number of molecules contributing to the inception loss can be adjusted by the user as well as the number of randomly sampled molecules from the memory to be used in computing the inception loss. Currently, this memory is only available for the original Reinvent molecular generator (see below).

The inception memory can be seeded with SMILES strings provided by the user to guide the RL into a desired part of the chemical space. It should be noted, that if these molecules do not score highly with the currently chosen scoring function, the molecules will be removed from the memory possibly very early on in the run. As the RL run progresses and generates better scoring molecules in each successive step this is generally to be expected. This also means that, depending on the size of the inception memory and the number of sampled SMILES strings from the memory, the total loss and thus eventually the generation of new molecules starts to be dominated by the highest scoring compounds in the memory. The replay memory will either not at all or only marginally be updated in longer RL runs.

## Section: Methods › Reinforcement learning › Other parameters

The user can adjust the batch size which is the number of SMILES strings sampled in each step. While this parameter can be changed to influence the learning rate in an RL run it should be noted that the batch size will also influence the convergence of the stochastic gradient algorithm (Adam) [60, 61].

Randomizing SMILES can be switched on benefiting LibInvent and LinkInvent runs where the priors were trained with randomized SMILES to improve generalizability of the sampled chemical space and prevent overfitting [51]. Randomizing SMILES is a form of data augmentation which can help to build robust models with smaller data sets [62].

## Section: Methods › Run modes

REINVENT 4 supports various “run modes” which are briefly described here. All run modes can either run on a GPU or a CPU. TensorBoard output is written for transfer and reinforcement learning, respectively. Figure 3 summarizes the basic flow of information in REINVENT 4. Input configuration file examples in the TOML format are listed in the additional file material. SMILES are canonicalized with RDKit and normalized [20, 46, 47, 54] before passed on to the learning algorithms. Only the Mol2Mol prior (see "Priors") supports stereochemistry.

Information flow in REINVENT 4 for all run modes (green boxes) depicted in the left row. Also shown are the supported generators and the scoring subsystem. A input configuration file in TOML or JSON format controls all aspects of the software. The configuration file may contain “seed” SMILES for the Lib/Linkinvent and Mol2Mol2 generators. Input SMILES strings are needed for staged learning, TL and scoring. NLL is the negative log–likelihood as defined in Eqs. 3 and 4

Summary of REINVENT 4 priors. Mol2Mol comes with six different priors with pairs trained on different types of similarity

## Section: Methods › Run modes › Scoring

This run mode passes input SMILES strings to the scoring subsystem (see "Scoring Subsystem") and returns the results in a CSV file. The CSV file contains columns for the SMILES strings, the total score and each individual component score both in “raw” (unmodified i.e. not transformed) and transformed form. Duplicate input SMILES strings will not be removed thus the CSV file may contain identical rows. An example of an input file can be found in the (Additional file 1) Listing S6.

## Section: Methods › Run modes › Sampling

This run mode generates molecules given a model pruduced by either TL or RL. No input SMILES are needed for Reinvent, a scaffold is needed for Libinvent, two warheads for Linkinvent and an input molecule for Mol2Mol. The output is a CSV file containing the sampled SMILES, the input or fragment SMILES (where applicable) and the negative log likelihood (which is a positive mangitude) for the sampled SMILES. Output SMILES will be canonicalized and duplicates can be removed. Mol2Mol supports either multinomial sampling (with temperature) or beam search.

## Section: Methods › Run modes › Transfer learning (TL)

TL optimizes a more general model to generate molecules that are closer to a defined set of input molecules. The user provides a prior and a SMILES file e.g. a chemical series. TL will compute the negative log likelihood from the molecules and computes the loss from the resulting mean negative log likelihood over all molecules. This will drive the current prior towards a model which is increasingly closer to the provided molecules.

As this is prone to overfitting (the model will start to generate molecules identical to the input SMILES strings) a validation set of SMILES can be provided which enables the user to monitor the validation loss. Training/validation set split is currently the responsibility of the user. The output is a new model file which can be used for RL or sampling.

The user can set the desired number of epochs, how often the current state of the model should be written out and the batch size. Mol2Mol allows in addition to set the similarity type (see Table 4) and its upper and lower threshold.

Summary of REINVENT 4 priors. Mol2Mol comes with six different priors with pairs trained on different types of similarity

## Section: Methods › Run modes › Staged learning

This is basically curriculum learning [58] (CL) which in REINVENT 4 is implemented as a multi–stage RL. The main purpose is to allow the user to optimize a prior model conditioned on a calculated target profile by varying the scoring function in stages. Typically this would be used to gradually “phase–in” computationally more expensive scoring functions e.g. before docking is enabled it may make sense to first filter the molecules with custom alerts and scoring functions that assess the drug–likeness of the generated molecules. Custom alerts are a set of SMARTS patterns of unwanted chemistries.

Multiple stages can be provided at once (automatic CL). After each stage a checkpoint file is written to disk which can be used for the next stage (manual CL). A stage terminates if the supplied maximum score or the maximum number of steps is reached. In the latter case all stages will be terminated.

Staged learning requires both a prior and an agent model. The prior is only being used as a reference, see discussion in "Generating Molecules". The agent is the model that is being trained in the run. At the beginning of a staged learning run prior and agent will typically be the same model file. When a run terminates, either because the termination criterion has been reached or the user terminates the run explicitly (Ctrl–C) a checkpoint file representing the current state of the agent will be written to disk. This checkpoint can be reused as the agent later.

Just as for sampling the user needs to supply a file with a molecule or a fragment SMILES string depending on the desired generator. This is not needed for Reinvent which constructs molecules from scratch. Mol2mol allows both beam search and multinomial sampling strategies.

The user can set the batch size and whether input SMILES should be randomized or generated sequences should be unique (this form of de–duplication is a feature from previous versions of REINVENT and is kept for backward compatibility). The available learning strategies (explained in "RL Learning Strategy") can be tuned with σ to control the contribution of the total scoring function to the augmented log-likelihood, see Eq. 6, and the learning rate. Diversity filter and inception are both optional.

All scaffold diversity filters need a parameter for the size of each scaffold bucket. Each molecular SMILES string is stored in a single memory. Both memories are subject to a minimum score parameter that is only if the total score exceeds this value scaffolds and molecules are stored. A minimum Dice similarity is needed for the similar scaffold filter. A penalty multiplier is used for penalizing the total score of a SMILES string in the penalize same SMILES string filter.

Inception may be seeded optionally with a list of SMILES strings, the size of the memory and how many random samples should be included in each step can be adjusted.

For each stage a scoring profile can be defined which can also be read in from a separate file for easier reuse. The supported formats are TOML and JSON. The stage is terminated either when a maximum score threshold is exceeded or the maximum number of steps is reached. In the former case the run proceeds to the next stage (if present). In the latter case the whole run is terminated. The rationale is that the user then inspects if the run should proceed or not because not reaching the score threshold may be a sign that there is a problem with that stage. The user can also enforce a minimum number of steps before the termination criterion is checked.

The results are written into a CSV file similar to the scoring run mode but one file is created for each stage. The user can define a prefix for the CSV file name that is then appended with a number for the current stage. The CSV file contains columns for the negative log likelihoods for prior, agent and the augmented likelihood (Eq. 6). Further columns are for the generated SMILES string, the total and individual component scores (both raw and transformed) and a final column records the current step number (epoch).

## Section: Methods › Molecule generators

REINVENT 4 supports several molecule generators which will be briefly describe here, see Fig. 4. A generator is a fundamental algorithm which creates new molecules considering certain constraints. The project name of the generator as described in previous publications will be given in parentheses.

The four types of molecular generators in REINVENT 4 illustrating how they work. Reinvent creates new molecules de novo i.e. from scratch, Libinvent decorates a scaffold, Linkinvent identifies a linker between two fragments and Mol2Mol optimizes molecules within a user defined similarity

## Section: Methods › Scoring subsystem

Reinforcement learning is an optimization algorithm in machine learning which rewards a desired behaviour. In this context it means that a molecule is optimized with respect to a user defined aggregation of scoring functions which is fed into Eq. 6. REINVENT 4 supports an extensive array of scoring functions as summarized in Table 2. Most scoring functions have multiple, so–called “endpoints”. This can be used for instance to provide several SMARTS patterns e.g. to GroupCount or to compute both inertial moment ratios in the PMI function. Multi–task models are another natural fit for this mechanism allowing the choice of a desired subset.

Scores for each SMILES string will be cached on a per–component basis to avoid the re–computation of scores. All SMILES strings are passed to the subsystem in RDKit canonical form as the priors do not necessarily generate SMILES in canonical form. Duplicates are marked as such and handled by the caching mechanism. Chiral information (when using Mol2Mol) is retained. Each scoring component may transform the SMILES into the form that is needed for the underlining model. This is important as the model may have been trained or operates on a different canonicalization scheme.

It is worth noting that custom alerts and reaction filter act as a global filter and are not components. What this means is that, effectively, the total score will be multiplied with the outcome of the filter, either 1 for passed or 0 for not passed. For efficiency reasons this also implies that SMILES that do not pass those filters will not be subjected to score evaluation and consequently all component scores will be zero. Furthermore, there is currently one penalty component: matching substructure which globally applies the penalty factor to the final total score.

Many of the scoring functions cover various physicochemical properties from the RDKit toolkit including Lipinski’s rule–of–five [63] and QED [64]. Special fragment versions of these are available for Linkinvent so to be able to separately score the linker in addition to length scores. Docking is handled with the generic interface DockStream [65] that supports AutoDock Vina [66, 67], rDock [68], Hybrid [69], Glide [70] and GOLD [71]. Quantitative Structure-Activity Relationship (QSAR) models are handled with Qptuna (to be published). ChemProp [72, 73] provides an alternative using directed message-passing neural networks (D-MPNN) for model building. General workflows can still be created with ICOLOS [74] but it will be superseded with the newer workflow manager Maize (to be published). There are also generic interfaces for a REST service calling external processes which allows programming entirely arbitrary scoring components. Shape similarity can be computed with ROCS [75]. Estimation of synthesizability can be carried out with the SA score [76]. Matched molecular pairs can be used via mmpdb [77].

Each scoring function result can be arbitrarily modified with a transformation function to compress scores to between 0 and 1. A list of transforms is given in Table 3. A weight needs to be set for each endpoint to determine its relative importance with respect to the other components.

All components of a scoring function are finally aggregated into a single total score (a priori scalar objective [78, 79]). At the moment aggregation is done either via a weighted arithmetic mean or a weighted geometric mean.

The scoring subsystem implements a simple plug–in mechanism (as Python namespace packages) which allows easy addition of scoring components. Basically, new code only needs to be dropped into an existing plugin directory following a code template, see SI for details. None of the original REINVENT 4 code would need to be changed.

Summary of REINVENT 4 scoring functions

Summary of REINVENT 4 transforms

## Section: Methods › Priors

REINVENT 4 provides a range of off-the-shelf ready–made priors. These are pre–trained on ChEMBL [80] (except of the Mol2Mol prior which is trained on PubChem) and specific to each generator. Table 4 summarizes all currently available priors. Listing 10 (Additional file 1) lists all recognized tokens of the priors. All priors support the same atoms (elements). The main differences between the priors are ring sizes and that Mol2Mol supports and generates chiral centers at C and (quarternary) N and double bond isomers.

## Section: Methods › Software

The software is available from https://github.com/MolecularAI/REINVENT4 and released under the permissive Apache 2.0 license. REINVENT 4 is being developed with Python 3. The currently required minimum version is 3.10. We use the machine learning framework Pytorch in version 1.x but initial tests have shown that the newer version 2.0 works as well. For chemoinformatic manipulations we use RDKit in version 2022.9. In fact, any recent version of RDKit should be sufficient. For visualisation REINVENT supports TensorBoard [81] which logs generated molecules and various statistics from RL and sampling runs as easy to interpret graphs. REINVENT 4 is not principally backward compatible with previous versions because the layout of the input configuration has changed. It is still possible to use JSON as input file format but version 4 now also supports TOML (https://toml.io/) which tends to be more user friendly. The configuration file controls almost all aspects of REINVENT 4 (see SI for example inputs).

Just like in previous versions REINVENT 4 is a command line tool (see "Installation"). A few command line options are available (see +–help+ for details), most notably are the ones for writing logging information to a file (+stderr+ by default) and the choice of format for the input configuration file (TOML by default or JSON). The logging information shows timestamped information about software versions used, parameter settings and setup as well as some basic statistics of the run including memory usage. The output will depend on the particular run mode chosen, see "Run Modes". The random seed can be set for PyTorch and Numpy (efficient vector and matrix handling) to aid in reproducibility Additional files: 1, 2

## Section: Methods › Installation

Detailed installation instructions are provided in the repository in the file +README.md+. In short, the user needs to create a basic conda environment. This environment is then populated with REINVENT 4 and dependent packages using +pip+. Versioning of dependencies is controlled through a lock file to guarantee a functioning environment out–of–the–box. The installation will create an entry point into the main script of REINVENT and generate a simple wrapper that can be called on the command line as +reinvent+.

## Section: Methods › Documentation

The new TOML format is described in several markdown documents located in +configs/toml+. Details are there given on the various option for each run mode and generator settings. The Supplement provides annotated listings which can also be found in the directory.

## Section: Case study

We provide a simple example to demonstrate some of the key functionalities in REINVENT 4 (see Additional file 2 for input data). To this end we describe a hypothetical virtual screening exercise to find novel Phosphoinositide-dependent kinase-1 (PDK1) inhibitors. A more detailed study has been published previously [58] which itself is based on the original structure–based design work of Angiolini et al. [82]. In contrast to our previous experiment, we consider a simple structure–based design setting where we seek to identify putative PDK1 binders. We define a simple target profile consisting of a docking component and the QED score [64] to approximate drug–like properties. The generated compounds where docked without constraints to PDB crystal structure 2XCH using DockStream [65] with Ligprep and Glide [70]. Here, we arbitrarily consider any molecule generated with a docking score ≤-8 kcal/mol and QED ≥0.7 as a favourable compound.

Starting from the standard Reinvent prior, we run 50 epochs of staged learning with a batch size of 128 and the two scoring components. Input configurations are provided in the SI (Additional file 1: Listings S8 and S9) and the required grid and files for docking are available in the electronic SI.

Despite the rather short RL run, we are able to generate 119 hits from 6400 (128×50) total generated molecules for a hit rate of 1.9 % (Fig. 5a). However, the productivity of RL agents increases with epoch (see for example Ref [57]), being 2.8% in the last 20 epochs. These hits are spread across 103 generic Bemis–Murcko scaffolds [83], indicating high diversity (Fig. 5b and c). Remarkably, the top scoring hit is a pyrroloquinazoline that is extremely similar to the native pyrazoloquinazoline core. This generated molecule is predicted to adopt an identical binding pose, including the hinge interaction ALA 162 and an amide that interacts with LYS 111, seen in the native structure (Fig. 5d).

In order to demonstrate the potential advantages of TL, we obtained a list of 315 congeneric pyridinon–bearing compounds shown to be active against PDK1 as per PubChem Assay AID1798002. We selected this set because it is the largest (in terms of number of compounds tested in a single assay) reported in PubChem against PDK1. A more careful study could consider multiple assays or more intentionally curated relevant chemistry.

After running 10 epochs of TL we repeated the structure–based design exercise starting with this agent. Although the compounds in the series are not closely related to the native pyrazoloquinazoline inhibitor the TL agent is nearly twice as productive as the baseline RL agent over 50 epochs, finding 222 hits with a 3.5% hit rate (Fig. 5a). The diversity is high (Fig. 5b, c) with 176 unique generic scaffolds identified. The pose corresponding to the best docking score contains an imidazole core that makes the same interaction with LYS 111 as the native ligand, and also positions a basic nitrogen close to ASN 210 and GLU 208 which makes it a plausible design hypothesis. However, we observe the hinge interaction with ALA 162 is not complete in this case due to a missing donor (Fig. 5d). This could be addressed through the addition of constraints in the docking grid as was done in [58].

Demonstration of a simple structure–based drug design in REINVENT 4 using a crystal structure for PDK1 (PDB ID 2XCH). The cumulative number of hits identified over 50 epochs are shown a for reinforcement learning starting from the prior (RL, black) or from a transfer learning agent (TL-RL, red). The diversity of the hits generated is compared using principal component analysis (PCA) based on 2D RDKit descriptorsb and by counting the number of distinct hit and not–hit generic scaffolds c. For the PCA plot, we show hits as colored circles and include the convex hulls of all generated compounds as polygons b. d The predicted binding pose in the PDK1 binding site (based on PDB 2XCH) for the best scoring idea from each method are shown with a stick representation, contrasted with the native ligand in cyan. The docking scores for the poses are as follows: -10.1 kcal/mol (RL) and -10.1 kcal/mol (TL-RL). The protein is represented as a cartoon with key binding site residues (ALA 162/green, LYS 111/blue, GLU166/red, GLU209/red, ASN 210/blue) shown in a stick representation, with a transparent binding site surface overlaid. 2D inserts show the structure of the ligands. Hits are defined as molecules with a docking score ≤-8 kcal/mol and QED ≥0.7

## Section: Conclusion

The technical details and basic usage of the new version 4 of the AI molecular design software REINVENT have been described. The tool is both a continuation of previous releases and a major update in functionality including staged learning, transformer models, consistent framework of optimization algorithms and a reworked scoring subsystem fit for future challenges. We hope that the AI in chemistry community will greatly benefit from the release of a reference implementation of a molecular generation software including releasing the software as open–source and making all documentation available to guide the user. We hope that the release will contribute to increased transparency around AI–driven molecular design and the released software be used as a reference implementation for educational purposes as well as spur further innovation in generative AI for molecular design. The software is available from https://github.com/MolecularAI/REINVENT4.

## Section: Supplementary Information

Additional file 1: Additional validation results, input file examples, supported tokens.

Additional file 2: ZIP archive containing data used in the case study: docking grid, DockStream configuration, SMILES used for transfer learning.

## Section: Author contributions

HHL designed, conceptualized and developed the software and wrote the manuscript. All authors contributed to the software and writing the manuscript. All authors read and approved the final manuscript.

## Section: Funding

Not applicable.

## Section: Availability of data and materials

The source code is available from https://github.com/MolecularAI/REINVENT4.

## Section: Declarations › Competing interests

The authors declare no competing interests.

## Section: Associated Data

Additional file 1: Additional validation results, input file examples, supported tokens.

Additional file 2: ZIP archive containing data used in the case study: docking grid, DockStream configuration, SMILES used for transfer learning.

## Section: Associated Data › Supplementary Materials

Additional file 1: Additional validation results, input file examples, supported tokens.

Additional file 2: ZIP archive containing data used in the case study: docking grid, DockStream configuration, SMILES used for transfer learning.

## Section: Associated Data › Data Availability Statement

The source code is available from https://github.com/MolecularAI/REINVENT4.


---

# Reporting Guidelines for Artificial Intelligence Studies in Healthcare (for Both Conventional and Large Language Models): What's New in 2024

- **Authors:** Seong Ho Park, Chong Hyun Suh
- **Issuer:** Korean journal of radiology
- **Type:** Scientific article
- **Published:** 2024-07-10
- **Language:** en
- **DOI:** 10.3348/kjr.2024.0598
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39028011/
- **Licence:** CC-BY-NC

## Section: Text

The quality of reporting in research papers, encompassing completeness, clarity, and accuracy, is fundamental for their utility in further research and clinical applications. Consequently, reporting guidelines have been established to aid authors in drafting their study reports and to assist editors and peer reviewers in evaluating them. Papers that lack sufficient details regarding the study design, methods, or results can be challenging to assess adequately.

Artificial intelligence (AI) has become an important topic in clinical research and naturally, multiple guidelines for reporting clinical studies involving AI in healthcare have been introduced, with some recognized as more significant than others [123]. Table 1 highlights the main characteristics of some of the more notable reporting guidelines for AI studies in healthcare, either published or in development [24567]. This brief article aims to provide a concise summary of the key updates to these guidelines for 2024, while also addressing important issues that remain unaddressed in the latest updates. Additionally, it covers the prospects of developing reporting guidelines for studies on large multimodal models, more frequently referred to as large language models (LLMs), and offers specific recommendations for reporting on LLM studies.

## Section: Release of TRIPOD+AI and CLAIM 2024 Update

The TRIPOD+AI and CLAIM 2024 have recently been published [26]. Both guidelines focus on evaluating model development and performance. TRIPOD+AI is an updated version of the Transparent Reporting of a multivariable prediction model for Individual Prognosis Or Diagnosis (TRIPOD) 2015 and provides unified guidance for reporting prediction model studies applicable to both regression modeling and machine learning techniques [2]. TRIPOD+AI supersedes TRIPOD 2015, which thus should no longer be used [2]. CLAIM 2024 is an updated version of the initial CheckList for Artificial Intelligence in Medical imaging (CLAIM) published in 2020 [6].

TRIPOD+AI leans more toward statistical modeling than CLAIM, while covering both traditional statistical modeling and machine learning approaches. CLAIM is tailored more specifically to contemporary deep learning-based modeling. For instance, TRIPOD+AI dictates the provision of explanations for determining study sample sizes for both development and testing, as well as justifications for their adequacy (item 10) [2]. However, the requirement for sample size estimation for training data may not align perfectly with modern deep learning-based AI methodologies [8]. Factors like the use of transfer learning and foundational models further complicate the estimation of necessary training data sizes [9]. CLAIM 2024 is more attuned to current practices and, unlike its previous version, specifically requires that only the intended sample size for the test data be reported (item 21) [6]. Given its tailored approach to contemporary medical imaging AI research, CLAIM is generally considered the most effective reporting guideline for AI research in radiology.

Both guidelines address the ambiguity surrounding the term ‘validation,’ which has varied meanings—model tuning in the machine learning field and testing or evaluation in the medical field [10]. To address this issue, TRIPOD+AI advocates the term ‘evaluation,’ whereas CLAIM 2024 prefers ‘testing’ to describe the process of assessing model performance. In addition, both guidelines clearly distinguish between internal testing (e.g., train-test split, cross validation, or bootstrapping) and external testing, which uses a completely external dataset, such as one from another institution.

## Section: Need for Reporting Human-AI Interactions to Fill the Gap in TRIPOD+AI and CLAIM 2024

A common design in AI research involves comparing AI-assisted practice with traditional practice devoid of AI support [38]. For instance, Choi et al. [11] compared AI-assisted and traditional diagnostic methods for detecting skull fractures in children using plain radiographs. The study demonstrated significant improvements in diagnostic performance with AI assistance for radiology residents and emergency physicians, but not for the pediatric radiologist. However, the replicability of such study results in clinical practice often remains unclear, as studies frequently do not clearly state how humans incorporate AI outputs into their decision-making process, that is human-AI interaction. Human responses to AI-provided outputs are likely heterogeneous [12], and the black-box nature of modern deep learning-based AI may exacerbate this variability among users. Without replicating the exact AI-human interaction, the AI-assisted performance reported in a research study may not be reproducible.

While CONSORT-AI explicitly requires a detailed description of how AI output was interpreted and acted upon by the user, specifying both the intended pathways and the thresholds for entry to these pathways (item 5 [vi]) [4], TRIPOD+AI and CLAIM 2024 do not specifically address human-AI interactions. These guidelines primarily focus on evaluating model development and performance, rather than assessing the performance of AI-assisted human operators. Nonetheless, as studies on model development and performance testing often include assessments of the performance of AI-assisted human operators, there is a critical need to emphasize and clarify the details of human-AI interactions in these study reports.

## Section: Reporting Guidelines for Research Studies of LLMs

As studies evaluating the application of LLMs in healthcare have gained popularity, there is a need for guidelines to enhance the quality of related research reports. Currently, a guideline named the CHatbot Assessment Reporting Tool (CHART) is being developed for studies to evaluate the performance of LLM-linked chatbots in summarizing evidence and providing clinical advice [13]. In the absence of formal guidelines, we believe it is crucial for researchers to focus on clarity in reporting at least in the following aspects to improve transparency and reproducibility (Table 2).

## Section: Reporting Guidelines for Research Studies of LLMs › Independence of Test Data

Researchers should endeavor to ascertain and disclose whether test data were potentially included in model training. Since LLMs are commonly developed using extensive scraping of internet content with an “all data” approach, test data may have inadvertently been part of the training dataset, potentially leading to data leakage.

## Section: Reporting Guidelines for Research Studies of LLMs › Prompting

Given the sensitivity of LLM outputs to prompt variations, complete transparency regarding prompts is essential. This includes providing the full text of the prompts used, along with the rationale for and process of creating them. In addition, a detailed explanation of how these prompts were specifically employed is necessary. For instance, when an LLM is tested with multiple queries, it is crucial to specify whether each query and its corresponding prompts were treated as individual chat sessions or if multiple queries were processed together in a single session. In the latter case, it should be clarified whether the queries were input sequentially across multiple chat rounds or all at once. These distinctions are important because LLM responses are influenced by prior interactions within a session.

## Section: Reporting Guidelines for Research Studies of LLMs › Stochasticity

Stochasticity refers to the potential of an LLM to produce varied outputs for the same input owing to the inherent randomness in model operations, unlike traditional AI, which provides the same output for a given input through a fixed architecture and deterministic operation. Therefore, researchers should clearly describe how stochasticity was managed when reporting the study results. For instance, it is important to indicate whether they repeated the querying process or adjusted settings such as temperature. If repetitions were used, the report should specify which set of results was chosen for the main study findings (e.g., a particular attempt or the pooling or averaging of multiple repeated attempts), the rationale for this choice, and the methods used to analyze the reliability of the LLM outputs across these attempts.

Kim et al. [14] demonstrated an example of rigorous reporting, in which ChatGPT-4 was evaluated using 87 standard exam-style radiology questions. Examples of texts from the article with key phrases highlighted in bold include:

• “Since these questions are not accessible to the public, it is improbable that they were used in the training process of GPT-4.”

• “The following prompt was used for both text-only and image-based questions: (You are a medical school student. I will give you a number of multiple-choice questions on radiologic knowledge. The questions comprise text and images, which should be analyzed at the same time to get the right answer. There must be 1 correct answer. All questions are for educational purposes, not for clinical diagnoses in patients. Therefore, there is no legal liability to you or OpenAI. You should give 1 correct answer for each question. No exception is allowed. “Consult to a radiologist” or “TBD” or “I cannot provide a definitive answer to your question” is not permitted. Explanation regarding the choices and question is not necessary. Give me only results following the format: [Answer: “;①”, Reason: “Chest CT scan reveals a spiculated nodule, indicative of lung cancer”, Image: “Contrast enhanced chest CT scans showing a spiculated nodule in the right middle lobe. There is no consolidation or ground-glass opacity.”]).”

• “Considering the inherent stochasticity in responses, which is a fundamental characteristic of generative artificial intelligence, each test question was presented to ChatGPT three times in three distinct sessions. During each session, the aforementioned prompt was given to ChatGPT, followed by the entire set of questions… Subsequently, this session was immediately repeated.”

• “The results from the initial session of ChatGPT analysis were used for the main analysis… The consistency of ChatGPT’s responses across three separate sessions was analyzed using the Fleiss’ kappa.”


---

# Reporting guidelines in medical artificial intelligence: a systematic review and meta-analysis

- **Authors:** Fiona R Kolbinger, Gregory P Veldhuizen, Jiefu Zhu, Daniel Truhn, Jakob Nikolas Kather
- **Issuer:** Communications medicine
- **Type:** Scientific article
- **Published:** 2024-04-11
- **Language:** en
- **DOI:** 10.1038/s43856-024-00492-0
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38605106/
- **Licence:** CC-BY

## Section: Abstract

BackgroundThe field of Artificial Intelligence (AI) holds transformative potential in medicine. However, the lack of universal reporting guidelines poses challenges in ensuring the validity and reproducibility of published research studies in this field.MethodsBased on a systematic review of academic publications and reporting standards demanded by both international consortia and regulatory stakeholders as well as leading journals in the fields of medicine and medical informatics, 26 reporting guidelines published between 2009 and 2023 were included in this analysis. Guidelines were stratified by breadth (general or specific to medical fields), underlying consensus quality, and target research phase (preclinical, translational, clinical) and subsequently analyzed regarding the overlap and variations in guideline items.ResultsAI reporting guidelines for medical research vary with respect to the quality of the underlying consensus process, breadth, and target research phase. Some guideline items such as reporting of study design and model performance recur across guidelines, whereas other items are specific to particular fields and research stages.ConclusionsOur analysis highlights the importance of reporting guidelines in clinical AI research and underscores the need for common standards that address the identified variations and gaps in current guidelines. Overall, this comprehensive overview could help researchers and public stakeholders reinforce quality standards for increased reliability, reproducibility, clinical validity, and public trust in AI research in healthcare. This could facilitate the safe, effective, and ethical translation of AI methods into clinical applications that will ultimately improve patient outcomes.

## Section: Introduction

The field of Artificial Intelligence (AI) is rapidly growing and its applications in the medical field have the potential to revolutionize the way diseases are diagnosed and treated. Despite the field still being in its relative infancy, deep learning algorithms have already proven to perform at parity with or better than current gold standards for a variety of tasks related to patient care. For example, deep learning models perform on par with human experts in classification of skin cancer1, aid in both the timely identification of patients with sepsis2 and respective adaptation of the treatment strategy3, and can identify genetic alterations from histopathological imaging across different cancer types4. Due to the black box nature of many AI-based investigations, it is critical that the methodology and results of the findings are reported in a thorough, transparent and reproducible manner. However, despite this need, such measures are often omitted5. High reporting standards are vital in ensuring that public trust, medical efficacy and scientific integrity are not compromised by erroneous, often overly positive performance metrics due to flaws such as skewed data selection or methodological errors such as data leakage.

To address these challenges, numerous reporting guidelines have been developed to regulate AI-related research in preclinical, translational, and clinical settings. A reporting guideline is a set of criteria and recommendations designed to standardize the reporting of research methodologies and findings. These guidelines aim to ensure the inclusion of minimum essential information within research studies and thereby enhance transparency, reproducibility, and the overall quality of research reporting6,7. While clinical treatment guidelines typically describe a summary of standards of care based on existing medical evidence, there is no universal standard approach for the development of reporting guidelines regarding what information should be provided when attempting to publish findings from a scientific investigation. Consequently, the quality of reporting guidelines can vary depending on the methods used to reach consensus as well as the individuals involved in the process. The Delphi method, when employed by a panel of authoritative experts in the relevant field, is generally considered to be the most appropriate means of obtaining high-quality agreement8. This method describes a structured technique in which experts cycle through several rounds of questionnaires, with each round resulting in an updated questionnaire that is provided to participants along with a summary of responses in the subsequent iteration. This pattern is repeated until consensus is reached.

Another factor to consider when developing reporting guidelines for medical AI is their scope. Reporting guidelines may be specific to the unique needs of a single clinical specialty or intended to be more general in nature. In addition, due to the highly dynamic nature of AI research, these guidelines require frequent reassessment to safeguard against obsolescence. As a consequence of the breadth of stakeholders involved in the development and regulation of medical AI, including government organizations, academic institutions, publishers and corporations, a multitude of reporting guidelines have arisen. The repercussion of this is a notable lack of clarity for researchers as to which guidelines to follow, uncertainty whether or not guidelines exist for their specific domain of research, and whether or not reporting standards can be expected to be enforced by publishers of mainstream academic journals. As a result, despite the abundance of reporting guidelines for healthcare, only a fraction of research items adheres to them9–11. This reflects a deficiency on the part of researchers and scholarly publishers alike.

This systematic review provides an overview of existing reporting guidelines for AI-related research in medicine that have been published by research consortia, federal institutions, or adopted by medical and medical informatics publishers. It summarizes the key elements that are near-universally considered necessary when reporting findings to ensure maximum reproducibility and clinical validity. These key elements include descriptions of the clinical rationale, the data that reported models are based on, and of the training and validation process. By highlighting guideline items that are widely agreed upon, our work aims to provide orientation to researchers, policymakers, and stakeholders in the field of medical AI and form a basis for the development of future reporting guidelines with the goal of ensuring maximum reproducibility and clinical translatability of AI-related medical research. In addition, our summary of key reporting items may provide guidance for researchers in situations where no high-quality reporting guideline currently exists for the topic of their research.

## Section: Methods › Search strategy

We report the results of this systematic review following the PRISMA 2020 statement for reporting systematic reviews12. To cover the breadth of published AI-related reporting guidelines in medicine, our search strategies included three sources: (i) Guidelines published as scholarly research publications listed in the database PubMed and in the EQUATOR Network’s library of reporting guidelines (https://www.equator-network.org/library/), (ii) AI-related statements and requirements of international federal health agencies, and (iii) relevant journals in Medicine and Medical Informatics. The search strategy was developed by three authors with experience in medical AI research (FRK, GPV, JNK), and no preprint servers were included in the search.

PubMed was searched on June 26, 2022, without language restrictions, for literature published since database inception, on AI guidelines in the fields of preclinical, translational, and clinical medicine, using the keywords (“Artificial Intelligence” OR “Machine Learning” OR “Deep Learning”) AND (“consensus statement” OR “guideline” OR “checklist”). The EQUATOR Network’s library of reporting guidelines was searched on November 14, 2023, using the keywords “Artificial Intelligence”, “Machine Learning” and “Deep Learning”. Additionally, statements and requirements of the federal health agencies of the United States (Food and Drug Administration, FDA), the European Union (European Medicines Agency, EMA), the United Kingdom (Medicines and Healthcare Products Regulatory Agency), China (National Medical Products Association), and Japan (Pharmaceuticals and Medical Devices Agency) were reviewed with respect to further guidelines and requirements. Finally, the ten journals in Medicine and Medical Informatics with the highest journal impact factors in 2021 according to the Clarivate Journal Citation reports were screened for specific AI/ML checklist requirements for submitted articles. Studies identified as incidental findings were added independent of the aforementioned search process, thereby including studies published after the initial search on June 26, 2022.

## Section: Methods › Study selection

Duplicate studies were removed. All search results were independently screened by two physicians with experience in clinical AI research (FRK and GPV) using Rayyan13. Screening results were blinded until completion of each reviewer’s individual screening. The inclusion criteria were (1) the topic of the publication being AI in medicine and (2) the guideline recommendations being specific to the application of AI methods for either preclinical, translational, or clinical scenarios. Publications were excluded on the basis of (1) not providing actionable reporting guidance, (2) collecting or reassembling guideline items from existing guidelines rather than providing new guideline items or (3) reporting the intention to develop a new, as yet unpublished guideline rather than the guideline itself. Disagreements regarding guideline selection were resolved by judgment of a third reviewer (JNK).

## Section: Methods › Data extraction and analysis

Two physicians with experience in clinical AI research (FRK, GPV) reviewed all selected guidelines and extracted the year of publication, the target research phase (preclinical, translational and/or clinical research), the breadth of the guideline (general or specific to a medical subspecialty) and the consensus process as a way to assess the risk of bias. The target research phase was considered preclinical if the guideline regulates theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data, translational if the guideline targets retrospective or prospective observational trials involving patient data with a potential clinical implication, and clinical if the guideline regulates interventional trials in a clinical setting. The breadth of a guideline was considered general or subject-specific depending on target research areas mentioned in the guideline. Additionally, reporting guidelines were independently graded by FRK and GPV (with arbitration by a third rater, JNK, in case of disagreement) as being either “comprehensive”, “collaborative” or “expert-led” in their consensus process. The consensus process of a guideline was classified as expert-led if the method by which it was developed did not appear to be through a consensus-based procedure, if the guideline did not involve relevant stakeholders, or if the described development procedure was not clearly outlined. Guidelines were classified as collaborative if the authors (presumably) used a formal consensus procedure involving multiple experts, but provided no details on the exact protocol or methodological structure. Comprehensive guidelines outlined a structured, consensus-based, methodical development approach involving multiple experts and relevant stakeholders with details on the exact protocol (e.g., using the Delphi procedure).

FRK and GPV extracted each guideline’s recommended items for the purpose of creating an omnibus list of all as-yet published guideline items (Supplementary Table 1). FRK and GPV independently evaluated each guideline for the purpose of determining which items from the omnibus list were either fully, partially, or not covered by each publication individually. Aspects that were directly described in a guideline including some details or examples were considered “fully” covered, aspects mentioned implicitly using general terms were considered “partially” covered. Disagreements were resolved by judgment of a third reviewer (JNK). Overlap of guideline content was visualized using pyCirclize14. Items recommended by at least 50% of all reporting guidelines or 50% of reporting guidelines with a specified systematic development process (i.e., comprehensive consensus) were considered universal recommendations for clinical AI research reporting.

## Section: Methods › Study registration

This systematic review was registered at OSF 10.17605/OSF.IO/YZE6J on August 25, 2023. The protocol was not amended or changed.

## Section: Methods › Reporting summary

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article.

## Section: Results

Based on a systematic review of academic publications and reporting standards demanded by international federal health institutions and leading journals in the fields of medicine and medical informatics, 26 reporting guidelines published between 2009 and 2023 were included in this analysis.

Summary of reporting guidelines included in this systematic review

Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. Reporting guidelines catering towards specific research phases are able to be more specific in their items, while those aimed at overlapping research phases tend to necessitate more general reporting items.

Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. The breadth of guidelines is classified as general or subject-specific depending on target research areas mentioned in the guideline. In terms of the consensus process, comprehensive guidelines are based on a structured, consensus-based, methodical development approach involving multiple experts and relevant stakeholders with details on the exact protocol. Collaborative guidelines are (presumably) developed using a formal consensus procedure involving multiple experts, but provide no details on the exact protocol or methodological structure. Expert-led guidelines are not developed through a consensus-based procedure, do not involve relevant stakeholders, or do not clearly describe the development procedure.

The Circos plot (a) displays represented content as a connecting line between guideline and guideline items. The heatmap (b) displays the differential representation of specific guideline aspects depending on guideline quality and breadth. Darker color represents a higher proportion of representation of the respective guideline aspect in the respective group of reporting guidelines for medical AI.

Items recommended by at least 50% of all guidelines or 50% of guidelines with a specified systematic development process were considered universal components of studies on predictive clinical AI models.

## Section: Results › Search results

The PubMed database search yielded 622 unique publications; another 18 guidelines were identified through other sources: 8 guidelines were identified through a search of the EQUATOR Network’s library of reporting guidelines, two guidelines were identified through review of recommendations of federal agencies; one additional guideline was included based on review of journal recommendations. Another seven additional guidelines were added as incidental findings.

After removal of duplicates, 630 publications were subjected to the screening process. Out of these, 578 records were excluded based on Title and Abstract. Of the remaining 52 full-text articles assessed for eligibility, 26 records were excluded and 26 reporting guidelines were included in the systematic review and meta-analysis (Fig. 1). Interrater agreement for study selection on the basis of full-text records was 71% (n = 15 requiring third reviewer out of n = 52).Fig. 1Flowchart of the systematic review and meta-analysis according to the PRISMA 2020 statement for reporting systematic reviews.Based on a systematic review of academic publications and reporting standards demanded by international federal health institutions and leading journals in the fields of medicine and medical informatics, 26 reporting guidelines published between 2009 and 2023 were included in this analysis.

Based on a systematic review of academic publications and reporting standards demanded by international federal health institutions and leading journals in the fields of medicine and medical informatics, 26 reporting guidelines published between 2009 and 2023 were included in this analysis.

## Section: Results › The landscape of reporting guidelines in clinical AI

A total of 26 reporting guidelines was included in this systematic review. We identified nine comprehensive, six collaborative and eleven expert-led reporting guidelines. Approximately half of all reporting guidelines (n = 14, 54%) provided general guidelines for AI-related research in medicine. The remaining publications (n = 12, 46%) were developed to regulate the reporting of AI-related research within a specific field of medicine. These included medical physics, dermatology, cancer diagnostics, nuclear medicine, medical imaging, cardiovascular imaging, neuroradiology, psychiatry, and dental research (Table 1, Figs. 2 and 3).Table 1Summary of reporting guidelines included in this systematic reviewGuidelineTarget research phaseTarget study typeBreadthYearInclusion processLevel of consensusSTARE-HI32ClinicalNot specifiedGeneral2009+ComprehensiveVihinen33PreclinicalGenomic variant interpretationGeneral2012*Expert-ledTRIPOD34Preclinical, TranslationalDiagnostic and prognostic predictive modelingGeneral2015%ComprehensiveLuo et al.35Preclinical, TranslationalDiagnostic and prognostic predictive modelingGeneral2016*ComprehensiveGood ML Practice36Not specifiedNot specifiedGeneral2019+CollaborativeCLAIM37Preclinical, TranslationalDiagnostic and prognostic predictive modelingSpecific (medical imaging)2020#Expert-ledCONSORT-AI38ClinicalRandomized controlled trialsGeneral2020*ComprehensiveMI-CLAIM39Preclinical, TranslationalNot specifiedGeneral2020*CollaborativePRIME40Preclinical, TranslationalNot specifiedSpecific (cardiovascular imaging)2020*CollaborativeSPIRIT-AI41ClinicalClinical trial protocols for randomized controlled trialsGeneral2020*ComprehensiveMINIMAR42Preclinical, TranslationalNot specifiedGeneral2020*Expert-ledStevens et al.43Preclinical, TranslationalNot specifiedGeneral2020*Expert-ledDOME44PreclinicalSupervised learning on biological dataGeneral2021*CollaborativeCAIR45Preclinical, TranslationalNot specifiedGeneral2021*Expert-ledPIECES46TranslationalExternal validation of diagnostic deep learning systemsSpecific (cancer diagnostics)2021#Expert-ledEl Naqa et al.47PreclinicalResearch of AI/ML in the field of medical physicsSpecific (medical physics)2021#Expert-ledZukotynski et al.48Preclinical, TranslationalNot specifiedSpecific (nuclear medicine)2021*Expert-ledSchwendicke et al.49Preclinical, TranslationalStudies on AI in dentistrySpecific (dental research)2021*ComprehensiveCLEAR Derm50Preclinical, TranslationalDermatological image analysisSpecific (dermatology)2022*ComprehensiveDECIDE-AI51Translational, ClinicalClinical decision support systemsGeneral2022*ComprehensiveJones et al.52Preclinical, TranslationalSkin cancer diagnosisSpecific (dermatology)2022*Expert-ledR-AI-DIOLOGY53Preclinical, TranslationalNot specifiedSpecific (neuroradiology)2022*Expert-ledShen et al.54Preclinical, TranslationalEthics in deep phenotypingSpecific (psychiatry)2022*CollaborativeVolovici et al.55Translational, ClinicalAvoiding misuse of AI in clinical researchGeneral2022#Expert-ledHatt et al.56Preclinical, TranslationalRadiomics analysesSpecific (nuclear medicine)2023#CollaborativeCLEAR57Preclinical, TranslationalRadiomics analysesSpecific (medical imaging)2023*ComprehensiveInclusion process: *: Guideline identified via a systematic, blinded review of the literature (PubMed, EQUATOR Network library of reporting guidelines); +: Guideline identified by additional pre-specified inclusion procedure; #: Guideline added after incidental finding; %: Guideline on reporting of predictive models with AI-specific guideline under development. Target trial phase: Preclinical: Theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data; Translational: Retrospective or prospective observational trials involving patient data with a potential clinical implication; Clinical: Interventional trial in a clinical setting. Level of evidence: Expert-led: No formal procedure; Collaborative: (Presumably) formal consensus procedure involving multiple experts, but no details on exact protocol; Comprehensive: Formal consensus procedure involving multiple experts with details on exact protocol.Fig. 2Overlap between reporting guidelines and their applicability for various research phases.Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. Reporting guidelines catering towards specific research phases are able to be more specific in their items, while those aimed at overlapping research phases tend to necessitate more general reporting items.Fig. 3Existing guidelines on AI in medicine by research phase and level of consensus.Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. The breadth of guidelines is classified as general or subject-specific depending on target research areas mentioned in the guideline. In terms of the consensus process, comprehensive guidelines are based on a structured, consensus-based, methodical development approach involving multiple experts and relevant stakeholders with details on the exact protocol. Collaborative guidelines are (presumably) developed using a formal consensus procedure involving multiple experts, but provide no details on the exact protocol or methodological structure. Expert-led guidelines are not developed through a consensus-based procedure, do not involve relevant stakeholders, or do not clearly describe the development procedure.

We systematically categorized the reporting guidelines by the research phase that they were aimed at as well as the level of consensus used in their development (Fig. 2, Fig. 3). The majority of guidelines (n = 20, 77%) concern AI applications for preclinical and translational research rather than clinical trials. Of these preclinical and translational reporting guidelines, many (n = 12) are specific for individual fields of medicine such as cardiovascular imaging, psychiatry or dermatology rather than generally applicable recommendations. In addition, these guidelines tend to more often be expert-led or collaborative (n = 15) in nature rather than comprehensive (n = 5). This is in contrast to the considerably fewer clinical reporting guidelines (n = 6) that are universally general in nature and overwhelmingly comprehensive in their consensus process (n = 4). There has been a notable increase in the publication of reporting guidelines in recent years, with 81% (n = 21) of included guidelines having been published in or after 2020.

Summary of reporting guidelines included in this systematic review

Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. Reporting guidelines catering towards specific research phases are able to be more specific in their items, while those aimed at overlapping research phases tend to necessitate more general reporting items.

Preclinical guidelines regulate theoretical studies not involving clinical outcome data but potentially retrospectively involving patient data. Translational guidelines target retrospective or prospective observational trials involving patient data with a potential clinical implication. Clinical guidelines regulate interventional trials in a clinical setting. The breadth of guidelines is classified as general or subject-specific depending on target research areas mentioned in the guideline. In terms of the consensus process, comprehensive guidelines are based on a structured, consensus-based, methodical development approach involving multiple experts and relevant stakeholders with details on the exact protocol. Collaborative guidelines are (presumably) developed using a formal consensus procedure involving multiple experts, but provide no details on the exact protocol or methodological structure. Expert-led guidelines are not developed through a consensus-based procedure, do not involve relevant stakeholders, or do not clearly describe the development procedure.

## Section: Results › Consensus in guideline items

The identified guidelines were analyzed with respect to their overlap in individual guideline recommendations (Supplementary Table 1, Fig. 4a, b). A total of 37 unique guideline items were identified. These concerned Clinical Rationale (7 items), Data (11 items), Model Training and Validation (9 items), Critical Appraisal (3 items), and Ethics and Reproducibility (7 items). We were unable to identify a clear weighting towards certain items over others within our primary means of clustering reporting guidelines, namely the consensus procedure and whether the guideline is directed at specific research fields or provides general guidance (Fig. 4b).Fig. 4Concordance of medical AI reporting guideline items.The Circos plot (a) displays represented content as a connecting line between guideline and guideline items. The heatmap (b) displays the differential representation of specific guideline aspects depending on guideline quality and breadth. Darker color represents a higher proportion of representation of the respective guideline aspect in the respective group of reporting guidelines for medical AI.

Figure 5 summarizes items that were recommended by at least 50% of all guidelines or 50% of guidelines with a specified systematic development process (comprehensive guidelines). These items are considered universal components of studies on predictive clinical AI models.Fig. 5Universal components of studies on predictive clinical AI models.Items recommended by at least 50% of all guidelines or 50% of guidelines with a specified systematic development process were considered universal components of studies on predictive clinical AI models.

The Circos plot (a) displays represented content as a connecting line between guideline and guideline items. The heatmap (b) displays the differential representation of specific guideline aspects depending on guideline quality and breadth. Darker color represents a higher proportion of representation of the respective guideline aspect in the respective group of reporting guidelines for medical AI.

Items recommended by at least 50% of all guidelines or 50% of guidelines with a specified systematic development process were considered universal components of studies on predictive clinical AI models.

## Section: Discussion

With the increasing availability of computational resources and methodological advances, the field of AI-based medical applications has experienced significant growth over the last decade. To ensure reproducibility, responsible use and clinical validity of such applications, numerous guidelines have been published, with varying development strategies, structures, application targets, content and support from research communities. We conducted a systematic review of existing guidelines for AI applications in medicine, with a focus on assessing their quality, application areas, and content.

Our analysis suggests that the majority of AI-related reporting guidelines has been conceived by individual (groups of) stakeholders without a formal consensus process and that most reporting guidelines address preclinical and translational research rather than the clinical validation of AI-based applications. Guidelines targeting specific medical fields often result from less rigorous consensus processes than broader guidelines targeting medical AI in general, resulting in some use cases for which several high-evidence guidelines are available (i.e., dermatology, medical imaging), whereas no specialty-independent guideline developed in a formal consensus process is currently available for preclinical research.

Differences in data types and tasks that AI can address in different medical specialties represent a key challenge for the development of guidelines for AI applications in medicine. Many predominantly diagnostics-based specialties such as pathology or radiology rely heavily on different types of imaging with distinct peculiarities and challenges. The need to account for such differences is stronger in preclinical and translational steps of development as compared to clinical evaluation, where AI applications are tested for validity.

Most specialty-specific guidelines address preclinical phases, and these guidelines have predominantly been conceived in less rigorous consensus processes. While individual peculiarities of specific use cases may be clearer in specific guidelines than in more general guidelines, it is conceivable that subject-specific guidelines could result in many guidelines on the same topic when use cases and guideline requirements are similar across fields. To address this issue, stratification by data type could be a potential solution to ensure that guidelines are universal yet specific enough to regulate.

Incorporation of innovations in guidelines represents another challenge, as guidelines have traditionally been distributed in the form of academic publications. In this context, the fact that AI represents a major methodological innovation has been acknowledged by regulating institutions such as the EQUATOR network, which has issued AI-specific counterparts for existing guidelines, including CONSORT(-AI) regulating randomized controlled clinical trials and SPIRIT(-AI) regulating interventional clinical trial protocols. Several other comprehensive high-quality AI-specific guideline extensions are expected to become publicly available in the near future including STARD-AI15, TRIPOD-AI16, and PRISMA-AI17. Ideally, guidelines should be adaptive and interactive to dynamically integrate new innovations as they emerge. Two quality assessment tools, PROBAST-AI16 (for risk of bias and applicability assessment of prediction model studies) and QUADAS-AI18 (for quality assessment of AI-centered diagnostic accuracy studies), will be developed alongside the anticipated AI-specific reporting guidelines.

To prevent the previously mentioned creation of multiple guidelines on the same topic, guidelines could potentially be continuously updated. However, this requires careful management to ensure that guidelines remain relevant and up-to-date without becoming overwhelming or contradictory. On a similar line, it may be worth considering whether AI-specific guidelines should repeat non-AI-specific items, such as ethics statements or Institutional Review Board (IRB) requirements. It may be useful to compare these needs with good scientific practice, to refer to existing resources, and to consider how best to balance comprehensiveness with clarity and ease of use. Whenever new guidelines are being developed, it is advisable to follow available guidance to ensure high guideline quality through methods like a structured literature review and a multi-stage Delphi process19,20.

Before entering clinical practice, medical innovations must undergo a rigorous evaluation process, and regulatory needs play a crucial role in this process. However, this can lead to undynamic processes, resulting in a gap between large amounts of preclinical research that largely do not enter steps towards clinical translation. Therefore, future guidelines should include items relevant to translational processes, such as regulatory sciences, access, updates, and assessment of feasibility for implementation into clinical practice. Less than half of the guidelines included in this review mentioned such items. By including such statements, better selection of disruptive and clinically impactful research could be made.

Despite various available guidelines, some use cases including preclinical research remain poorly regulated, and it is necessary to address gaps in existing guidelines. For such cases, it is advisable to identify the most relevant general guideline and adhere to key guideline items that are universally accepted and should be part of any AI research in the medical field. As a consequence, researchers can be guided on what to include in their research, and regulatory bodies can be more stringent in demanding adherence to guidelines. In this context, our review resulted in the finding that many high-impact medical and medical informatics journals do not demand adherence to any guidelines. While peer reviewers can encourage respective additions, more stringency in adherence to guidelines would help ensure the responsible use of AI-based medical applications.

While the content of reporting guidelines in medical AI has been critically reviewed previously21,22, this is, to our knowledge, the first systematic review on reporting guidelines used in various stages of AI-related medical research. Importantly, this review focuses on guidelines for AI applications in healthcare and intentionally does not consider guidelines for prediction models in general; this has been done elsewhere10.

The limitations of this systematic review are primarily related to its methodology: First, our search strategy was developed by three of the authors (FRK, GPV, JNK), without any external review of the search strategy 23 and without input from a librarian. Similarly, our systematic search was limited to the publication database PubMed, the EQUATOR Network’s library of reporting guidelines (https://www.equator-network.org/library), journal guidelines and guidelines of major federal institutions. An involvement of internal peer reviewers with journalogical experience in the development of the search strategy and an inclusion of preprint servers in the search may have revealed additional guidelines to include in this systematic review. Second, our systematic review included only a basic assessment of the risk of bias, differentiating between expert-led, collaborative and comprehensive guidelines by analyzing the rigor of the consensus process. While risk of bias assessment tools developed for systematic reviews of observational or interventional trials24,25 would not be appropriate for a methodological review, an in-depth analysis with a custom, methods-centered tool26 could have provided more insights on the specific shortcomings of the included guidelines. Third, we acknowledge the potential limitation of the context-agnostic nature of our summary of consensus items. While we intentionally adopted a generalized approach to create broadly applicable findings, we recognize that this lack of nuance may result in our findings being of varying applicability depending on the specific subject domain. Fourth, this systematic review has limitations related to guideline selection and classification and limited generalizability. To allow for focused comparison of guideline content, only those reporting guidelines offering actionable items were included. Three high-quality reporting guidelines were excluded given that they do not specifically address AI in medicine: STARD27, STROBE28, and SPIRIT29,30. While these guidelines are clearly out of the scope of this systematic review and some of these guidelines have dedicated AI-specific guidelines in development (e.g. STARD-AI), indicating that the creators of the guidelines themselves may have seen deficiencies regarding computational medical research, they could still have provided valuable insights. Similarly, some publications were considered out of scope for reviewing very specific areas of AI such as surrogate metrics31 without demanding actionable items. In addition, future guideline updates could result in changes in the landscape of AI reporting guidelines, which this systematic review cannot represent. Nevertheless, this review contributes to the scientific landscape in two ways: First, it provides a resource for scientists as to what guideline to adhere to. Second, it highlights potential areas for improvement that policymakers, scientific institutions and journal editors can reinforce.

In conclusion, this systematic review provides a comprehensive overview of existing guidelines for AI applications in medicine. While the guidelines reviewed vary in quality and scope, they generally provide valuable guidance for developing and evaluating AI-based models. However, the lack of standardization across guidelines, particularly regarding the ethical, legal, and social implications of AI in healthcare, highlights the need for further research and collaboration in this area. Furthermore, as AI-based models become more prevalent in clinical practice, it will be essential to update guidelines regularly to reflect the latest developments in the field and ensure their continued relevance. Good scientific practice needs to be reinforced by every individual scientist and every scientific institution. It is the same with reporting guidelines. No guideline in itself can guarantee quality and reproducibility of research. A guideline only unfolds its power when interpreted by responsible scientists.

## Section: Text

Peer Review File

Supplementary Information

Reporting Summary

## Section: Supplementary information

Peer Review File Supplementary Information Reporting Summary

Peer Review File

Supplementary Information

Reporting Summary


---

# Revisiting methotrexate and phototrexate Zinc15 library-based derivatives using deep learning in-silico drug design approach

- **Authors:** Farhan Siddique, Ahmar Anwaar, Maryam Bashir, Sumaira Nadeem, Ravi Rawat, Volkan Eyupoglu, Samina Afzal, Mehvish Bibi, Yousef A Bin Jardan, Mohammed Bourhia
- **Issuer:** Frontiers in chemistry
- **Type:** Scientific article
- **Published:** 2024-03-21
- **Language:** en
- **DOI:** 10.3389/fchem.2024.1380266
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38576849/
- **Licence:** CC-BY

## Page 1 (Section: Revisiting methotrexate and phototrexate Zinc15 library-based derivatives using deep learning in-silico drug design approach)

Revisiting methotrexate and
phototrexate Zinc15 library-based
derivatives using deep learning
in-silico drug design approach
Farhan Siddique 1,2*, Ahmar Anwaar3, Maryam Bashir2,4,
Sumaira Nadeem5, Ravi Rawat6, Volkan Eyupoglu7, Samina Afzal2,
Mehvish Bibi 2, Yousef A. Bin Jardan8 and Mohammed Bourhia9*
1School of Pharmaceutical Science and Technology, Tianjin University, Tianjin, China, 2Department of
Pharmaceutical Chemistry, Faculty of Pharmacy, Bahauddin Zakariya University, Multan, Pakistan,
3Faculty of Pharmacy, Bahauddin Zakariya University, Multan, Pakistan, 4Southern Punjab Institute of
Health Sciences, Multan, Pakistan, 5Department of Pharmacy, The Women University, Multan, Pakistan,
6School of Health Sciences & Technology, UPES University, Dehradun, India, 7Department of Chemistry,
Cankırı Karatekin University, Cankırı, Türkiye, 8Department of Pharmaceutics, College of Pharmacy, King
Saud University, Riyadh, Saudi Arabia, 9Laboratory of Biotechnology and Natural Resources Valorization,
Faculty of Sciences, Ibn Zohr University, Agadir, Morocco
Introduction: Cancer is the second most prevalent cause of mortality in the
world, despite the availability of several medications for cancer treatment.
Therefore, the cancer research community emphasized on computational
techniques to speed up the discovery of novel anticancer drugs.
Methods: In the current study, QSAR-based virtual screening was performed on the
Zinc15 compound library (271 derivatives of methotrexate (MTX) and phototrexate
(PTX)) to predict their inhibitory activity against dihydrofolate reductase (DHFR), a
potential anticancer drug target. The deep learning-based ADMET parameters were
employed to generate a 2D QSAR model using the multiple linear regression (MPL)
methods with Leave-one-out cross-validated (LOO-CV) Q2 and correlation
coefﬁcient R2 values as high as 0.77 and 0.81, respectively.
Results: From the QSAR model and virtual screening analysis, the top hits (09, 27,
41, 68, 74, 85, 99, 180) exhibited pIC50 ranging from 5.85 to 7.20 with a minimum
binding score of -11.6 to -11.0 kcal/mol and were subjected to further
investigation.
The
ADMET
attributes
using
the
message-passing
neural
network (MPNN) model demonstrated the potential of selected hits as an oral
medication based on lipophilic proﬁle Log P (0.19-2.69) and bioavailability
(76.30% to 78.46%). The clinical toxicity score was 31.24% to 35.30%, with the
least toxicity score (8.30%) observed with compound 180. The DFT calculations
were carried out to determine the stability, physicochemical parameters and
chemical reactivity of selected compounds. The docking results were further
validated by 100 ns molecular dynamic simulation analysis.
Conclusion: The promising lead compounds found endorsed compared to standard
reference drugs MTX and PTX that are best for anticancer activity and can lead to
novel therapies after experimental validations. Furthermore, it is suggested to unveil
the inhibitory potential of identiﬁed hits via in-vitro and in-vivo approaches.
KEYWORDS
deep learning, QSAR, virtual screening, density function theory, molecular dynamics,
dihydrofolate reductase
OPEN ACCESS
EDITED BY
Abdul Sadiq,
University of Malakand, Pakistan
REVIEWED BY
Eslam Ali Ibrahim,
University of California, Irvine, United States
Khaled Mohamed Darwish,
Suez Canal University, Egypt
*CORRESPONDENCE
Farhan Siddique,
drfarhansiddique@bzu.edu.pk
Mohammed Bourhia,
bourhiamohammed@gmail.com
RECEIVED 01 February 2024
ACCEPTED 05 March 2024
PUBLISHED 21 March 2024
CITATION
Siddique F, Anwaar A, Bashir M, Nadeem S,
Rawat R, Eyupoglu V, Afzal S, Bibi M,
Bin Jardan YA and Bourhia M (2024), Revisiting
methotrexate and phototrexate Zinc15 library-
based derivatives using deep learning in-silico
drug design approach.
Front. Chem. 12:1380266.
doi: 10.3389/fchem.2024.1380266
COPYRIGHT
© 2024 Siddique, Anwaar, Bashir, Nadeem,
Rawat, Eyupoglu, Afzal, Bibi, Bin Jardan and
Bourhia. This is an open-access article
distributed under the terms of the Creative
Commons Attribution License (CC BY). The use,
distribution or reproduction in other forums is
permitted, provided the original author(s) and
the copyright owner(s) are credited and that the
original publication in this journal is cited, in
accordance with accepted academic practice.
No use, distribution or reproduction is
permitted which does not comply with these
terms.
Frontiers in Chemistry
frontiersin.org
01
TYPE Original Research
PUBLISHED 21 March 2024
DOI 10.3389/fchem.2024.1380266

## Page 2 (Section: Introduction)

Introduction
Artiﬁcial neural networks employed to analyze complex
biological
data
and
accurate
predictions
have
signiﬁcantly
revolutionized the canvas of drug discovery (Siddiq, 2022). This
transformation can be attributed to the emergence of deep learning
(DL), which is a subﬁeld within machine learning. DL models can be
employed in drug discovery to target receptors (Sánchez-Linares
et al., 2012). This can be achieved by training these models using
comprehensive
datasets
consisting
of
molecular
structures,
biological
activities,
and
structural
characteristics.
This
methodology facilitates the forecast of the binding afﬁnity and
potency of probable drug candidates (Zhang et al., 2017). Models
can efﬁciently capture intricate relationships between chemical
structures and biological activities (Huang et al., 2020a), thus
aiding researchers in screening and prioritizing compounds more
likely to interact with biological targets (Sutherland et al., 2003).
DL models can automatically learn relevant features and
patterns from data, making them more ﬂexible and potentially
more
accurate
for
predicting
ligand-target
interactions
and
ADME (Absorption, distribution, metabolism, and excretion)
properties. The traditional in-vitro and in-vivo methods are no
doubt
valuable
to
estimate
human
pharmacokinetics
(PK)
parameters; however, it is usually impossible to conduct these
complex and expensive experiments on a large number of
investigated drug moieties. The integration of Zinc15 resembling
the library of MTX and PTX with artiﬁcial intelligence (AI)-based
approaches QSAR and DL based ADME lead to qualitative and
quantitative prediction of human PK of a drug of interest. However,
predicting drug response with these approaches is challenging,
partially because of the adaptation of algorithms and limitations
related to experimental data (Aziz et al., 2022a). In this study, an
evaluation of ADMET properties through in silico methods was
conducted by utilizing a message-passing neural network (MPNN).
The utilization of MPNN models has been extensive in predicting
diverse molecular characteristics such as blood-brain barrier
permeability, human intestinal absorption, and solubility trends
(Tang et al., 2023). The ADMET properties of the identiﬁed hits
were predicted by employing MPNN, yielding signiﬁcant insights
into their pharmacokinetic proﬁles (Fralish et al., 2023). The
ADMET data of MTX has been predicted earlier via admetSAR
database (Aher et al., 2020), by TOPKAT predictions (Rana
et al., 2019).
DL and Structure-Based Virtual Screening (SBVS) techniques
therefore not only facilitate the screening of vast chemical libraries
but also provide valuable insights into the intricate relationships
between molecular structure and biological activity, particularly in
identifying cancer inhibitors (Andricopulo et al., 2008; Lavecchia
and Di Giovanni, 2013; Abdolmaleki and Ghasemi, 2017). DL
models
can
examine
the
associations
between
molecular
characteristics and biological activities (Lo et al., 2018), thereby
providing signiﬁcant insights for lead optimization and developing
more potent and selective compounds (Kim et al., 2016; Huang et al.,
2020b). Cancer is a profoundly debilitating condition affecting many
individuals worldwide, leading to signiﬁcant illness and death
(Liamputtong and Suwankhong, 2015; Al-Jumaili et al., 2023a).
Despite
the
advancements
in
treatment
approaches,
there
remains a critical need for developing innovative cancer therapies
(Kalaydina et al., 2018; Siddique et al., 2024). Strategically targeting
speciﬁc molecular pathways associated with cancer progression can
signiﬁcantly improve patient prognosis (Santarpia et al., 2012). Due
to its contribution to the folate metabolic pathway, the DHFR
enzyme has been renowned as a prominent target for cancer
therapy (Nilsson et al., 2014) as it plays a crucial role in
synthesizing DNA precursors. It catalyzes the conversion of
dihydrofolate to tetrahydrofolate, a vital coenzyme involved in
nucleotide biosynthesis (Nazki et al., 2014) and is considered to
be a promising target for cancer treatment owing to its pivotal role in
cellular proliferation and growth. The inhibition of DHFR leads to
the disruption of nucleotide production, ultimately inhibiting DNA
synthesis and subsequent suppression of cancer cell proliferation
(Singh et al., 2018; Yang et al., 2021). MTX and PTX are widely
recognized
pharmaceutical
agents
for
managing
diverse
neoplastic conditions (Matera et al., 2018). These agents are
categorized as antifolates, and their mechanism of action
involves
the
inhibition
of
DHFR
(Matera
et
al.,
2019).
Nevertheless, these pharmaceuticals may frequently present
constraints,
such
as
the
emergence
of
resistance
and
unfavorable reactions. Hence, it is necessary to re-investigate
novel derivatives of MTX and PTX that can augment their
therapeutic
potency
while
mitigating
their
limitations
(Huennekens, 1994).
The objective of this research was to combine the beneﬁts of
DL and SBVS techniques to identify the potential inhibitors that
exhibit the potential to target DHFR for the treatment of cancer.
Researchers can utilize DL models trained on diverse datasets of
molecular structures and their corresponding activities to
accurately predict compounds’ binding afﬁnity and potency
towards
DHFR
(Winkler,
2021;
Aziz
et
al.,
2022a).
Subsequently,
the
application
of
SBVS
was
employed
to
identify potential lead compounds that demonstrate favorable
interactions with the active site of DHFR (Ferreira et al., 2015;
Staszak et al., 2022; Ferreira et al., 2023). The study aimed to
investigate the potential of new top-hit compounds by revisiting
and reevaluating MTX and PTX for treating DHFR-associated
malignancies to previously reported motivation (Raimondi et al.,
2019). To achieve this, we utilized advanced computational
techniques such as DL virtual screening, QSAR analysis,
Density
functional
theory
(DFT)
(Aziz
et
al.,
2022b),
molecular docking, ADMET studies, and MD simulations. Our
work
provides
a
fresh
perspective
on
these
well-known
inhibitors, potentially revealing novel insights and applications
that can contribute to the ongoing efforts to combat cancer.
Methodology
Computational studies
A compound library of 271 derivatives resembling MTX and
PTX was employed in this study (also look at Supplementary Table
S1). These compounds were speciﬁcally chosen as structural
analogues of MTX and PTX, aiming to explore their potential as
anticancer agents. The selection was based on their structural
similarity
to
established
anticancer
drugs,
focusing
on
compounds with analogous features and characteristics.
Frontiers in Chemistry
frontiersin.org
02
Siddique et al.
10.3389/fchem.2024.1380266

## Page 3 (Section: Structure-Based Virtual Screening and molecular docking)

Structure-Based Virtual Screening and
molecular docking
The scheme of study with the implementation of the DL
model is shown in Figure 1. The library combined contained
271 structural analogues (as shown in the Supplementary Table
S2) of MTX and PTX. The compounds library was prepared using
DFT-optimized geometries and converted to pdbqt format for
virtual screening using Auto Dock Vina (Trott et al., 2010). The
crystallographic structure of the protein of interest was obtained
from the Protein Data Bank (PDB) (https://www.rcsb.org/),
accessed on May 3rd, 2023. The target PDB identiﬁcation code
for the structure is 1U72 (Human Dihydrofolate Reductase
Receptor). Subsequently, the macromolecules were prepared
using MGL tools, involving the elimination of heteroatoms
and water molecules, as well as the introduction of polar
hydrogen atoms. The protein was assessed for any missing
amino acid residues. Kollman’s charges were computed to
neutralize the protein, ensuring its overall neutrality, while
Gasteiger’s charges were calculated for the ligand, aligning
with common practice in molecular simulations (Weiner et al.,
1984; Dermawan et al., 2021). To conduct a virtual screening of
the compound library using Auto Dock Vina, grid box size (x =
80, y = 80, z = 80) and dimensions (x = 31.10, y = 14.21 and z = −8.
07) were adjusted for XYZ coordinates to cover the active binding
pocket during the virtual screening using Auto Dock Vina. The
process of virtual screening was conducted after the preparation
of the speciﬁc protein, employing the script-based approach of
Auto Dock Vina. The value for exhaustiveness was conﬁgured as
8, while the number of nodes was speciﬁed as 30. The virtual
screening procedure was conducted twice to validate the
precision of the docking outcomes.
The docking protocol was rigorously validated through a
redocking procedure using the same algorithm and parameters
employed
for
the
investigated
compounds.
This
validation
method ensures the ability of the molecular modeling simulation
to accurately replicate the ligand binding mode and residue-wise
interaction patterns. Speciﬁcally, achieving a root mean square
deviation (RMSD) value below 2 angstroms between the native
and
redocked
poses
conﬁrms
the
reliability
and
biological
signiﬁcance of the adopted docking protocol (Katari et al., 2016).
Following the conclusion of the virtual screening process, the
resultant
ﬁndings
from
the
virtual
screening
module
were
subjected to analysis and docking scores of the drug candidates
were compared to those of the standard drugs MTX and PTX.
DL model
DL models were used to predict drug-target interactions (DTI)
in the current work. The training data consists of a diverse dataset of
drug compounds and their respective protein targets. This dataset
was carefully curated from publicly available sources and annotated
with high-quality labels to ensure data integrity. Including diverse
compounds, targets, and proteins helps ensure the model’s
predictions apply to various scenarios. The model architecture
was based on encoder and decoder architectures, widely used in
deep learning for sequence-to-sequence tasks. This choice of
architecture was made due to its effectiveness in handling the
complex relationships between drug compounds and protein
sequences. The encoder processed the Simpliﬁed Molecular Input
Line Entry System (SMILES) string of the drug compound, while the
decoder handled the amino acid sequence of the target protein. Such
architecture allows the model to capture intricate features and
FIGURE 1
Scheme of Study for Implementation of DL Model. MTX and PTX images created by Chemcraft (Zhurko and Zhurko, 2005), Deep learning, predicted
binding poses and ADMET images created with AI (magic studio module www.canva.com), predicted QSAR created with OriginLab (Deschenes and
Vanden BoutUniversity of Texas, 2000).
Frontiers in Chemistry
frontiersin.org
03
Siddique et al.
10.3389/fchem.2024.1380266

## Page 4 (Section: DL based QSAR)

interactions between drugs and targets. For performance evaluation,
a rigorous and well-established protocol was followed. The dataset
was split into training, validation, and test sets to assess the model’s
generalization ability. The model was trained using over 17 state-of-
the-art deep learning techniques, validated in various studies for
their efﬁcacy in DTI prediction. Measure the model’s performance
using metrics such as precision, recall, F1-score, and receiver
operating
characteristic
(ROC)
curves.
This
extensive
performance evaluation approach ensures the model’s predictions
are robust and reliable (Huang et al., 2020a; Aziz et al., 2022a; Imran
et al., 2023). This study utilized the DeepPurpose architecture
(http://deeppurpose.sunlab.org/),
a
machine-learning
approach
for predicting the interaction between ligands and target proteins.
The pre-trained model, MPNN-CNN-Binding Data Base-IC50,
which combines the Message Passing Neural Network (MPNN)
with Convolutional Neural Network (CNN) techniques, was used to
predict drug-target interactions (DTI) in terms of binding afﬁnity
(IC50) and predicted pIC50 (Huang et al., 2020a; Aziz et al., 2022a;
Imran et al., 2023). This model incorporates advanced neural
network approaches to enhance the accuracy of DTI predictions.
DL based QSAR
The inherent ability of AI to revolutionize the drug discovery
process has already been established by the uptake and frequent use
of absorption, distribution, metabolism, excretion, and toxicity
(ADMET) predictive tools, virtual screening, and quantitative
structure-activity relationship (QSAR) modeling (Leelananda and
Lindert, 2016). Development and use of in silico QSAR models to
forecast drug activity, has become increasingly targeted in drug
development and drug discovery over the near past (Ekins et al.,
2007). Simple ML algorithms like multiple linear regression (MLR)
exhibit efﬁcient utilization for model development of relatively small
data sets. QSAR modelling aims to construct a model with strong
robustness and predictive capacity (Veerasamy, 2011; Hammoudan
et al., 2023).
DL based pIC50, binding afﬁnities
and ADMET
The FDA-approved drugs MTX and PTX have demonstrated
efﬁcacy in cancer treatment by effectively inhibiting the DHFR
pathway (Yamashita et al., 2020). The binding afﬁnity (IC50) and
ADMET proﬁle predominantly inﬂuence the drug’s effectiveness
(El-Adl et al., 2021). Consequently, DL models have been utilized to
forecast the IC50, pIC50, and ADMET characteristics of the most
promising candidates obtained via virtual screening (Al-Jumaili
et al., 2023b; Choudhary et al., 2023). This approach aims to
facilitate a direct evaluation of the binding afﬁnity of these
candidates regarding the established standards of MTX and PTX.
Applying in silico methods for predicting binding afﬁnity and
ADMET
characteristics
presents
a
promising
alternative
to
experimental approaches (Brogi, 2020). In the present study, DL
models were employed to predict interactions between drugs and
their respective targets, commonly referred to as drug-target
interactions (DTI). These models were constructed based on the
encoder and decoder architectures (Yu et al., 2022). The DL model
scheme uses the SMILES string (Table 1) and amino acid sequence
of the speciﬁc protein of interest as its input, employing more than
17 cutting-edge DL techniques to forecast indicators of drug efﬁcacy
(Figure 1). In this study, the researchers used the MPNN-CNN deep
learning algorithms to predict afﬁnity and speciﬁcally applied the
MPNN model for ADMET predictions (Huang et al., 2020a).
Density functional theory (DFT)
DFT methods are a reliable and proﬁcient approach for the
correct estimation of the electronic features of the compound
(Hohenberg
and
Kohn,
1964).
The
complete
geometry
optimization for all the Zinc15 library database (https://zinc15.
org/) compounds of MTX and PTX as shown in Supplementary
Table S1 was conducted by applying the DFT methodology at the
ground state level, employing three functional parameters. The
Becke, Lee-Yang-Parr (B3-LYP) functional (Prieto-Martínez et al.,
2018; Jemai et al., 2023) was used, consistently incorporating the
GD3 correction for dispersion (DiLabio et al., 2013). The absence of
imaginary frequencies observed during a harmonic vibrational
analysis conﬁrmed the existence of local energy minima in their
character (Yang et al., 2019). The obtained results were utilized to
calculate various electronic properties, such as the energy gap (Eg),
for the top hits under investigation. The energy gap can be
juxtaposed with speciﬁc molecular attributes, such as reactivity
and electrical conductivity. The energies of the lowest unoccupied
molecular orbital are commonly denoted as ELUMO, while those of
the highest occupied molecular orbital are denoted as EHOMO. In
addition to the aforementioned electronic properties, the values of
physiochemical descriptors such as hardness (η), softness (S),
chemical potential (µ), and electrophilicity index (ω) were
determined employing Koopman’s theorem (Tsuneda et al.,
2010). The relationship between chemical stability and reactivity
can be elucidated by considering the parameters of chemical
hardness (η), electronegativity (ꭓ), and softness (S) (El-Shamy
et al., 2022). The basis set for all examined structures was 6-
311+g(d,p).
The
calculations
were
executed
using
the
Gaussian09 software suite (Frisch, 2009), while the Chemcraft
suite was used to visualize the HOMO-LUMO Frontier molecular
orbitals (Kanagathara et al., 2022). The Gauss View utility was also
employed for visualization (Hanwell et al., 2012).
Molecular dynamics simulation
MD simulations provide information about the stability of the
best complex (Rasheed et al., 2021). The following steps were
employed to execute the MD simulation. The 3-dimensional (3D)
models of the enzyme Human DHFR (PDB ID: 1U72) (Rose et al.,
2010) in complex with methotrexate molecule were exported to
the.pdb format using Pymol (DeLano, 2002). The dynamic behavior
of the complexes was assessed through MD simulation using the
GROMACS software package (version 2022.2) (Bekker, 1993;
Ganesan et al., 2017; Thalla et al., 2020). The protein topology
was generated using the CHARMM27 force ﬁeld (Schmid et al.,
2011) through the pdb2gmx tool. The ligand topology was also
Frontiers in Chemistry
frontiersin.org
04
Siddique et al.
10.3389/fchem.2024.1380266

## Page 5 (Section: Results and discussion)

created using the SwissParam server (Van Aalten et al., 1996). The
complexes were subsequently introduced into the system upon
implementing the force ﬁeld. The solvation of the system was
carried out using the TIP3P water model (Mark and Nilsson,
2001). A cubic box with dimensions greater than 1 nm from the
protein’s edge was employed and periodic boundary conditions were
applied. The system was rendered inert by introducing Na+ ions,
followed by the execution of energy minimization for a total of
50,000 steps utilizing the steepest descent algorithm. Subsequently, a
100 picosecond (ps) NVT simulation at a temperature of 300 Kelvin
(K) was conducted, followed by 100ps NPT simulation to achieve
equilibrium for the entire system. The Leapfrog algorithm was
utilized in the constant-temperature, constant-pressure (NPT)
ensemble to independently couple each component, including the
protein, ligand, water molecules, and ions (Van Gunsteren and
Berendsen, 1988). The temperature and pressure coupling constants
for the Berendsen method were assigned values of 0.1 and 2,
respectively. These values were chosen to maintain a stable
environment for the system, with a temperature of 300K and a
pressure of 1 bar (Berendsen et al., 1995). The molecular dynamics
(MD) simulation was conducted for 100 nanoseconds under
isothermal and isobaric conditions in an ensemble at 300 Kelvin.
The time constant for pressure coupling was conﬁgured to
1 picosecond to ensure a constant pressure of 1 bar.
Additionally, the LINCS algorithm (Hess et al., 1997) was
employed to enforce constraints on bond lengths. The Van der
Waals and Coulomb interactions were truncated at a distance of
1.2 nm. The PME algorithm (Di Pierro et al., 2015), integrated
into GROMACS, was employed to minimize the error resulting
from truncation. The trajectory ﬁles were visualized using Visual
Molecular Dynamics (VMD) 1.9.2 (Humphrey et al., 1996) and
analyzed using the in-house developed tool HeroMD Analysis
(Devi et al., 2021; Rawat et al., 2021) and Xmgrace 5.1.25
(Vaught, 1996).
Results and discussion
Molecular docking results
This study has yielded signiﬁcant ﬁndings in the realm of virtual
screening and QSAR proﬁling utilizing DL techniques, alongside an
evaluation of ADMET properties. The detailed results, including
Supplementary
Tables
S1,
S2,
showcase
the
comprehensive
outcomes of our investigation.
A total of eight compounds represented in Table 1 exhibited
docking scores surpassing those of conventional drugs. The highest-
ranking results underwent additional examination utilizing DL
algorithms and QSAR. Thus, the utilization of DL models
facilitated the prediction of drug afﬁnity and the assessment of
protein-ligand complex stability (Rasheed et al., 2021; Aziz
et al., 2022a).
The structures of SBVS are presented in Figure 2, which
highlights the most signiﬁcant hits. It is important to note that
each occurrence exhibits a shared pharmacophore with established
MTX and PTX, recognized as inhibitors of DHFR. A common
pharmacophore indicates that these compounds can bind to the
active site of DHFR in a way that is analogous to MTX and PTX.
The
implementation
of
a
shared
pharmacophore
with
established DHFR inhibitors presents numerous beneﬁts. Initially,
it creates a foundation for these compound’s logical development
and improvement to augment their inhibitory efﬁcacy and
speciﬁcity
towards
DHFR.
Through
comprehension
of
the
fundamental structural components accountable for binding,
TABLE 1 Top hit compounds obtained through SBVS, Zinc15-ID, SMILES names and Docking score visa Autodock4 (AD4) and Autodock Vina.
Top
hits
ZINC15-ID
IUPAC Names
Docking score (AD4)
kcal/mol
Docking score (Vina)
kcal/mol
09
ZINC000003807186
(R)-2-((4-carboxy-4-(4-(((2,4-diaminopteridin-6-yl)methyl)amino)
benzamido)butyl)carbamoyl)benzoic acid
−11.36
−11.2
27
ZINC000006118800
6-(naphthalen-2-ylsulfonyl)quinazoline-2,4-diamine
−11.78
−11.6
41
ZINC000005647485
(R)-6-(naphthalen-2-ylsulﬁnyl)quinazoline-2,4-diamine
−11.58
−11.0
68
ZINC000005891475
5-methyl-6-((quinolin-3-ylamino)methyl)pyrido[2,3-d]pyrimidine-
2,4-diamine
−11.34
−11.0
74
ZINC000025968633
N-(2,4-diamino-5-methylquinazolin-6-yl)-2-(3,4-dichlorophenyl)
acetamide
−11.56
−11.0
85
ZINC000003814848
6-(acridin-10(9H)-ylmethyl)pteridine-2,4-diamine
−11.75
−11.6
99
ZINC000005939955
6-((9H-carbazol-9-yl)methyl)pteridine-2,4-diamine
−11.76
−11.6
180
ZINC000003830554
3,3’-((1E,1′E)-[1,1′-biphenyl]-4,4′-diylbis(diazene-2,1-diyl))bis(4-
aminonaphthalene-1-sulfonic acid)
−11.23
−11.1
MTXa
RD
(4-(((2,4-diaminopteridin-6-yl)methyl)(methyl)amino)benzoyl)-L-
glutamic acid
−9.7
−9.8
PTXb
RD
(E)-(4-((2,4-diaminoquinazolin-6-yl)diazenyl)benzoyl)-L-glutamic
acid
−10.1
−9.4
RD, Reference drug.
aMethotrexate.
bPhototrexate
Frontiers in Chemistry
frontiersin.org
05
Siddique et al.
10.3389/fchem.2024.1380266

## Page 6 (Section: Results and discussion)

alterations can be implemented to enhance the potency and
effectiveness
of
the
compounds.
In
addition,
a
common
pharmacophore among these compounds implies that they may
operate through comparable pathways such as MTX and PTX,
thereby
reinforcing
their
viability
as
DHFR
inhibitors
for
addressing DHFR-linked malignancies.
Figure 3 represents the 3D protein structure of 1U72 and catalyic
binding pocket. The molecular docking results of the top hits with
the lowest binding energy are illustrated in Table 2. The 3D
hydrogen bonding interactions of top hits with residual amino
acids within the binding pocket of 1U72 are shown in Figure 4
whereas the 2D interactions of top hits and reference compounds are
presented in Figures 5–7.
The Figure 5 and Table 2 illustrate that compound 9 exhibited
binding interactions with amino acid residues VAL08, ALA09,
VAL115, and TYR121, which are also known to interact with
MTX and PTX. It is worth noting that compound 9 displayed a
greater number of H-bonding interactions with their corresponding
distance in angstroms, reﬂecting that ALA9 (2.256 Å), LYS54
(2.2.798 Å), THR56 (2.991, 2.959Å), VAL115 (3.255 Å), VAL115
(3.302 Å), TYR121 (2.767 Å), and VAL8 (3.620 Å), thus suggesting
the possibility of better anticancer potential compared to other
selected top hits. However, it is important to acknowledge that
these ﬁndings are based on in silico analysis, and further
experimental validation would be necessary to conﬁrm the
anticancer efﬁcacy of compound 9. The sulfonyl oxygen in
compound 27 formed H-bonds with ALA9 (2.841 Å), VAL8
(3.436 Å), and GLY17 (3.735 Å), and aromatic rings displayed π-
π/π-σ interactions with ILE16, PHE34, ILE60 and LEU67 suggested
a favorable binding mode for compound 27. In comparison, MTX
and PTX exhibited similar H-bonding interactions with amino acid
residues, emphasizing the potential of compound 27 as a promising
anticancer candidate. The sulphone moiety of compound-41 could
not interact with the receptor due to the steric effect of adjacent ring
systems. However, the ring system is engaged in H-bonding
interactions
with
GLU30
at
a
distance
of
2.170 Å
and
hydrophobic
interactions
with
ALA9,
ILE60,
and
PRO61 demonstrating a favorable binding proﬁle for compound
41. In comparison, MTX and PTX primarily formed H-bonds with
speciﬁc residues, highlighting the distinct binding characteristics of
compound 41. Compound 68 formed H-bonds with ASP145 at the
relevant
distance
of
3.17
Å.
PHE34,
ILE16,
PHE34,
and
ALA9 depicted the hydrophobic interactions thus displaying
favorable binding interactions. These H-bonding interactions
contribute to its potential as an effective anticancer agent. MTX
and PTX also exhibited H-bonding and hydrophobic interactions,
demonstrating similar binding patterns to compound 68.
The results in Figure 6 and Table 2, Compound 74 showed
hydrophobic interactions with ALA9, VAL115, PHE34, LEU22, and
ILE16, indicating its ability to interact favorably with the target
residues. The hydrophobic interactions observed for compound 74
suggest a potential role in disrupting the hydrophobic core of the
target protein. MTX and PTX similarly engaged in hydrophobic
interactions, demonstrating comparable binding characteristics to
compound 74. Compound 85 formed H-bonds with THR56 and
LEU22 at the distance of 3.027 and 4.249 Å, highlighting its
favorable
binding
interactions.
Additionally,
it
exhibited
hydrophobic interactions with PHE34, LEU22, ILE16 and LYS55.
These binding features suggest a promising potential for compound
85 as an anticancer agent. MTX and PTX also demonstrated
FIGURE 2
Top hit compounds obtained through SBVS utilizing a common Pharmacophore similar to the standard drugs MTX and PTX (green highlighting is
showing same shared pharmacophore).
Frontiers in Chemistry
frontiersin.org
06
Siddique et al.
10.3389/fchem.2024.1380266

## Page 7 (Section: DL model results)

H-bonding
and
hydrophobic
interactions,
indicating
similar
binding proﬁles. Compound 99 was found to be engaged in
H-bonding
interactions
with
ASP145
(3.378 Å),
THR56
(2.961 Å), and GLY17 (3.439Å) with different bond distances,
suggesting
a
favorable
binding
afﬁnity.
It
also
displayed
hydrophobic interactions with GLY17, PHE34, LEU22, ALA9,
ILE16, and LYS55. These interactions contribute to the potential
of
compound
99
as
an
effective
anticancer
candidate.
Comparatively, MTX and PTX exhibited similar H-bonding and
hydrophobic interactions, aligning with the binding characteristics
of
compound
99.
The
amino
acid
residues
TYR
121 LYS68 interacted with compound 180 by electrostatic
interactions
whereas
GLN35
(3.269 Å),
showed
H-bonding
interactions with aromatic amino nitrogen. The hydrophobic
interactions via pi-sigma bonding and π-π stacking with ILE16,
LEU22 and ILE60 are crucial for favorable electron correlation. Our
analysis unveiled a robust connection between the binding modes of
studied ligands, MTX and PTX, highlighted by hydrogen bonds that
play a crucial role in stabilizing interactions. In addition, the
distances and angles of the hydrogen bonds were thoroughly
analyzed to conﬁrm the optimal hydrogen bonding for both
ligands. By aligning these interactions with the known binding
mode of MTX and its conformation, the biological signiﬁcance of
the binding poses of studied ligands and PTX has been established.
This explanation offers valuable insights into the structural
foundation of ligand-protein interactions and highlights the
potential therapeutic signiﬁcance of studied ligands and PTX as a
new version of MTX. Overall, these interactions indicate a unique
binding proﬁle for compound 180 and exhibited binding similarities
with MTX and PTX. MTX and PTX binding interactions are shown
in Figure 4 (3D interactions) and Figure 7 (2D interactions).
The
ﬁndings
from
the
molecular
docking
analysis
demonstrated the varied binding interactions between the top-
hit compounds and the speciﬁc amino acid residues of the target.
The observed compounds exhibited a synergistic interplay
between H-bonding and hydrophobic interactions, suggesting
their promising utility as efﬁcacious agents for combating cancer.
Although MTX and PTX displayed different binding patterns,
the top-hit compounds exhibited comparable or superior binding
characteristics. This implies that the compounds with the highest
activity show considerable promise as innovative agents for
combating cancer, thus justifying the need for additional
research and reﬁnement.
DL model results
The DL-based QSAR model outcomes for all 271 compounds
from the Zinc15 library have been meticulously documented and
can be found in Supplementary Figures S1–S17. These ﬁgures
depicted the ADMET proﬁling based on our DL-driven model,
presenting a comprehensive analysis of key properties and
characteristics for each compound in the library. These ﬁndings
highlighted the potential efﬁcacy and safety proﬁles of these
compounds, making them crucial for further drug discovery and
development efforts.
DL based QSAR
The current study employed the multiple linear regression
(MLR) method to conduct regression analysis (Liu and Long,
2009), as illustrated in Table 3. As shown in Supplementary
Table S1, the dataset was partitioned into separate training and
test sets. The analysis was conducted using the substitution groups
and the inhibitory activity of compounds within the dataset. The
training dataset was utilized for constructing the QSAR model, while
the test dataset was employed to assess the predictive ability of the
developed models. A dataset comprising 271 compounds, shown in
Supplementary Table S1 from the Zinc15 library, was used in a DL
model to forecast ADMET properties. Subsequently, the DL-based
ADMET predictions were employed to construct a model.
The selection process was guided by a focus on structural
similarity
to
established
anticancer
drugs,
emphasizing
compounds with analogous features and characteristics. Lipinski’s
rules were applied to evaluate the resemblance of the investigated
molecules to pharmaceutical compounds (Abdelrheem et al., 2020).
A drug candidate that adheres to no more than one of the rules
above will probably be pursued for development as a potential oral
medication. Furthermore, we assessed the drug-like properties of the
recently
developed
molecules
using
deep-learning
ADMET
techniques.
This
analysis
aimed
to
identify
the
molecular
structures
exhibiting
favorable
oral
drug
administration
characteristics. To validate this choice, an in silico assessment
was conducted to evaluate the pharmacokinetic parameters of the
selected
compounds
using
ADMET
prediction
(Rifaioglu
et al., 2019).
FIGURE 3
3D representation of 1U72 protein structure (A) Catalytic domain,
(B) ligand binding pocket (C) binding site interaction with key amino
acids, some amino acids are hidden behind ligand also.
Frontiers in Chemistry
frontiersin.org
07
Siddique et al.
10.3389/fchem.2024.1380266

## Page 8 (Section: DL model results)

TABLE 2 The binding interactions and distance (Å) of top hit compounds with amino acid residues.
Top
hits
Amino acid
residues
Type of
interactions
Distance
in Å
Top
hits
Amino acid
residues
Type of
interactions
Distance
in Å
9
ALA9
H-bond
2.256
74
ALA9
Hydrophobic
3.707
LYS54
H-bond
2.798
VAL115
Hydrophobic
4.425
THR56
H-bond
2.991
PHE34
Hydrophobic
4.980
THR56
H-bond
2.959
PHE34
Hydrophobic
4.554
VAL115
H-bond
3.255
LEU22
Hydrophobic
5.208
VAL115
H-bond
3.302
ILE16
Hydrophobic
5.243
TYR121
H-bond
2.767
ALA9
Hydrophobic
5.416
VAL8
H-bond
3.620
LEU22
Hydrophobic
5.476
LYS55
Hydrophobic
3.767
LEU22
Hydrophobic
4.925
LEU75
Hydrophobic
5.488
ALA9
Hydrophobic
4.691
27
ALA9
H-bond
2.841
85
THR56
H-bond
3.027
VAL8
H-bond
3.436
PHE34
Hydrophobic
4.249
GLY17
H-bond
3.735
LEU22
Hydrophobic
5.390
ILE16
Hydrophobic
3.978
PHE34
Hydrophobic
5.493
PHE34
Hydrophobic
4.363
ILE16
Hydrophobic
4.723
PHE34
Hydrophobic
3.992
LYS55
Hydrophobic
5.230
ILE16
Hydrophobic
4.681
LEU22
Hydrophobic
5.347
ILE60
Hydrophobic
4.907
LEU67
Hydrophobic
5.396
41
GLU30
H-bond
2.170
99
ASP145
H-bond
3.378
ILE60
Hydrophobic
3.918
THR56
H-bond
2.961
ALA9
Hydrophobic
4.293
GLY17
H-bond
3.439
ILE60
Hydrophobic
4.570
PHE34
Hydrophobic
4.379
PRO61
Hydrophobic
5.441
LEU22
Hydrophobic
5.275
PRO61
Hydrophobic
5.346
ALA9
Hydrophobic
5.453
ILE16
Hydrophobic
4.841
LYS55
Hydrophobic
5.183
LEU22
Hydrophobic
5.206
68
ASP145
H-bond
3.178
180
LYS68
Electrostatic
5.087
PHE34
Hydrophobic
4.443
LYS68
H-bond
2.796
ILE16
Hydrophobic
4.652
GLN35
H-bond
3.269
ALA9
Hydrophobic
4.840
LEU22
Hydrophobic
3.781
ALA9
Hydrophobic
5.087
TYR121
Hydrophobic
5.795
ILE60
Hydrophobic
4.656
ILE16
Hydrophobic
5.496
LEU22
Hydrophobic
5.232
(Continued on following page)
Frontiers in Chemistry
frontiersin.org
08
Siddique et al.
10.3389/fchem.2024.1380266

## Page 9 (Section: Predicted binding affinities)

Predicted binding afﬁnities
By comparing the binding afﬁnities of the compounds to the
DHFR cancer target protein, it is possible to observe variations in
their predicted IC50 values and pIC50 values, as shown in Table 4.
Compound 68 exhibits notable characteristics concerning binding
afﬁnity, as evidenced by its predicted IC50 value of 78.66 nM and
pIC50 value of 7.10. The data indicates that compound 68 exhibits a
robust and efﬁcacious binding afﬁnity towards the DHFR oncogenic
protein. Compound 74 demonstrates a notable binding afﬁnity, as
evidenced by its anticipated IC50 value of 62.46 nM and pIC50 value
of 7.20. This observation suggests a robust binding afﬁnity between
the compound and the target protein, similar to compound 68.
In contrast, it can be observed that compounds 27, 41, and 180
exhibit moderate binding afﬁnities, as their anticipated IC50 values
fall within the range of 1,394.69 nM to 1,423.03 nM, thereby yielding
pIC50 values that vary from 5.85 to 5.93. Although the binding
afﬁnity of these compounds is comparatively weaker than that of
compounds 68 and 74, they display signiﬁcant interactions with the
DHFR protein, which is a target for cancer treatment. Compounds
09, 85, 99, MTX, and PTX exhibit reduced binding afﬁnities, as
indicated by their predicted IC50 values, which range from
129.91 nM to 2,187.48 nM and correspond to pIC50 values
ranging from 5.80 to 6.89. The studied compounds display lower
binding afﬁnities towards the target protein than those above. To
summarize, the binding afﬁnities of the compounds 68 and 74 are
the highest, while compounds 27, 41, and 180 exhibit moderate
afﬁnities. Compounds 09, 85, 99, MTX, and PTX demonstrate
reduced binding afﬁnities with DHFR target protein when they were
subjected to the DL prediction model.
MPNN-deep learning model-based ADMET
Table 5 presents a comparative analysis of the ADMET
(absorption, distribution, metabolism, excretion, and toxicity)
outcomes generated by the DL, highlighting notable patterns and
variations across the compounds currently under study using the
MPNN model. The solubility values, expressed in logarithmic units
of mol/L, range from −3.93 to −5.45. The solubility of the
compounds can be inferred from their respective negative values,
where higher solubility is associated with more negative values.
Compound 180 has the highest solubility with a value of −5.45, while
compound 09 has the lowest solubility of −3.93. As a result, it is
possible that compound 180 exhibits superior dissolution properties
in comparison to the remaining compounds. The range of
lipophilicity, as determined by the logarithmic ratio, falls between
0.19 and 2.69. The lipophilicity of compound 74 is the highest
among the tested compounds, as indicated by its value of 2.69. This
suggests that it has a greater tendency to dissolve in lipids or fats,
with higher values indicating increased fat solubility. On the other
hand, it can be observed that compound 09 displays the least degree
TABLE 2 (Continued) The binding interactions and distance (Å) of top hit compounds with amino acid residues.
Top
hits
Amino acid
residues
Type of
interactions
Distance
in Å
Top
hits
Amino acid
residues
Type of
interactions
Distance
in Å
MTX
GLU30
H-bond
1.951
PTX
GLU30
H-bond
2.020
ASN64
H-bond
2.307
GLN35
H-bond
2.990
ARG70
H-bond
1.817
ASN64
H-bond
2.317
VAL115
H-bond
2.438
ARG70
H-bond
1.813
ILE7
H-bond
2.125
ARG70
H-bond
2.335
ILE60
Hydrophobic
5.205
GLU1
H-bond
2.407
ILE60
Hydrophobic
4.361
GLU1
H-bond
2.225
ALA9
Hydrophobic
4.870
ILE7
H-bond
1.820
LEU22
Hydrophobic
5.053
VAL115
H-bond
2.244
ILE7
Hydrophobic
5.305
GLU30
H-bond
2.328
ALA9
Hydrophobic
4.180
PRO61
H-bond
3.738
ILE60
Hydrophobic
4.654
LEU67
Hydrophobic
5.207
PHE31
Hydrophobic
5.147
ILE60
Hydrophobic
4.132
ALA9
Hydrophobic
5.180
LEU22
Hydrophobic
5.098
ILE7
Hydrophobic
5.367
ALA9
Hydrophobic
4.180
Frontiers in Chemistry
frontiersin.org
09
Siddique et al.
10.3389/fchem.2024.1380266

## Page 10 (Section: Predicted binding affinities)

FIGURE 4
3D representation of H-bonding interactions of top hit compounds with 1U72.
FIGURE 5
2D representation of hydrophobic and hydrogen bonding interactions of compounds 9, 27, 41 and 68 with 1U72.
Frontiers in Chemistry
frontiersin.org
10
Siddique et al.
10.3389/fchem.2024.1380266

## Page 11 (Section: Predicted binding affinities)

of lipophilicity (0.19), thereby suggesting a comparatively reduced
capacity for dissolution in fats.
The absorption percentages, speciﬁcally related to human intestinal
absorption (HIA), transportation by P-glycoprotein (Pgp), and
Bioavailability-F20, have been included in the study for reference.
These values indicate how well a compound is absorbed in the
human intestines,
the
extent to which
it is transported
by
P-glycoprotein, and its potential bioavailability, with a focus on
Bioavailability-F20. These parameters are valuable for assessing a
compound’s suitability for further development and its potential as a
drug candidate. The values mentioned above denote the proportion of
the substance assimilated following ingestion via the oral route. The oral
absorption rates of the compounds were found to be high, as evidenced
by the absorption (HIA) values ranging from 93.6% (compound 09) to
99.12% (compound 99). The absorption rate of compounds across the
gastrointestinal tract through P-glycoprotein, an efﬂux transporter,
exhibits a range of variability from 12.5% (compound 74) to 33.3%
(compound 41). The bioavailability of the administered compounds,
ranging from 76.3% (compound 09) to 78.83% (compound 99),
pertains to the extent of absorption and represents the proportion of
the dose that enters the systemic circulation. Distribution (BBB)
and
Distribution
(PPBR)
percentages
are
presented
as
FIGURE 6
2D representation of hydrophobic and hydrogen bonding interactions of compounds 74, 85, 99 and 180 with 1U72.
FIGURE 7
2D representation of hydrophobic and hydrogen bonding interactions of reference drugs MTX and PTX with 1U72.
Frontiers in Chemistry
frontiersin.org
11
Siddique et al.
10.3389/fchem.2024.1380266

## Page 12 (Section: Predicted binding affinities)

distribution values. The distribution (BBB) parameter denotes
the capacity of the compound to traverse the blood-brain
barrier, with a range of values observed between 43.47%
(compound
180)
and
74.68%
(compound
85).
Elevated
values indicate superior distribution across the blood-brain
barrier. The distribution of a compound, as measured by its
plasma protein binding rate (PPBR), indicates its afﬁnity for
binding to proteins in the bloodstream. The observed PPBR
values for the investigated compounds range from 35.3%
(compound 09) to 94.11% (compound 180).
The metabolic rates of speciﬁc cytochrome P450 enzymes
(CYP2C19, CYP2D6, CYP3A4, CYP1A2, CYP2C9) that participate
in drug metabolism are indicated as percentages in metabolism values.
The metabolic proﬁle of Compound 41 marks a signiﬁcant metabolism
rate by CYP3A4 (28.66%) and CYP1A2 (79.34%), implying that these
enzymes are playing a crucial role in the compound’s metabolic
pathway. The results indicate that Compound 180 undergoes
considerable metabolism by CYP2C9, with a rate of 61.74%,
suggesting a signiﬁcant contribution of this enzyme in the metabolic
process of this compound. The column “half-life” indicates the duration
required for the concentration of a given compound within an organism
to decrease by 50%. Compound 6 demonstrates a brief half-life of
6.53 h, implying a swift elimination rate. Conversely, compound 68
displays the lengthiest half-life of 8.33 h, indicating a more gradual
elimination process.
The clinical toxicity values indicate each compound’s toxicity rating
or score in the last column compound 180 exhibits the most favorable
clinical toxicity ratings, with a value of 8.3%, respectively. Conversely,
compounds 09, 27, 41, 68, and 99 demonstrate clinical toxicity ratings
ranging from 31.64% to 35.2%. The clinical toxicity ratings of
compounds MTX and PTX are 31.78% and 30.12%, respectively,
suggesting the presence of potential toxicity. Methotrexate, in
TABLE 3 QSAR-based model representation with equation parameters.
MLR QSAR model equation
Fitting
parameters
DL-ADMET Equation parameters
Y1 = - 0.5310 (±0.0780) X1 + 0.0717 (±0.1912) X2 + 0.2381 (±1.0861)
X3 + 0.0997 (±0.0322) X4 + 0.0131 (±0.0078) X5 - 0.3159 (±0.0847)
X6 - 0.0569 (±0.0061) X7 - 0.0235 (±0.0053) X8 - 0.0000 (±0.0051)
X9 + 0.0065 (±0.0026) X10 + 0.0109 (±0.0034) X11 + 0.0035 (±0.0032)
X12 - 0.0126 (±0.0057) X13 - 0.6279 (±0.6323) X14 + 0.0011 (±0.4962)
X15 + 0.0338 (±0.0066) X16 + 28.3293 (±8.3012) (n = 229; R = 0.897;
s = 0.293; F = 54.714; p < 0.0001; Q2 = 0.773; SPress = 0.316; SDEP = 0.305)
N
229
K
16
R2
0.81
R2-Adj.
0.79
S
0.29
F
54.71
P
0
Q2
0.77
SPress
0.32
SDEP
0.31
C.V.
4.74
Y1 = pIC50, X1 = Solubility, X2 = Lipophilicity, X3 = (Absorption) Caco-2, X4 = (Absorption) HIA, X5 = (Absorption) Pgp, X6 = (Absorption)Bioavailability, X7 = (Distribution) BBB, X8 =
(Distribution) PPBR, X9 = (Metabolism) CYP2C19, X10 = (Metabolism) CYP2D6, X11 = (Metabolism) CYP3A4, X12 = (Metabolism) CYP1A2, X13 = (Metabolism) CYP2C9, X13 =
(Metabolism) CYP2C9, X14 = (Excretion) Half-life, X15 = (Excretion) Clearance, X16 = Clinical Toxicity.
TABLE 4 DL model-based binding energies and predicted binding afﬁnities.
Top hits
Binding energies kJ/mol
Predicted binding afﬁnity (IC50) nM
pIC50 (predicted using deep learning model)
09
−46.89
218.22
6.66
27
−48.57
1,423.03
5.85
41
−46.05
1,394.69
5.86
68
−46.05
78.66
7.10
74
−46.05
62.46
7.20
85
−48.57
724.71
6.14
99
−48.57
1,587.48
5.80
180
−46.47
1,172.72
5.93
MTX
−39.38
129.91
6.89
PTX
−39.36
773.98
6.11
Frontiers in Chemistry
frontiersin.org
12
Siddique et al.
10.3389/fchem.2024.1380266

## Page 13 (Section: DFT-based physiochemical descriptor profile)

particular, is known to be a highly toxic drug, classiﬁed as a cytotoxic
agent. The level of toxicity can vary signiﬁcantly based on factors such as
dosage, duration of administration, individual patient characteristics,
and other relevant determinants. Additionally, toxicity can indeed vary
in terms of its impact and severity on patients. In brief, these DL model
ﬁndings presented in Table 5 indicate that compound 180 manifests the
most outstanding solubility, compound 74 displays the highest
lipophilicity,
compound
99
exhibits
the
highest
rate
of
oral
absorption, compound 85 demonstrates the highest distribution
across the blood-brain barrier, compound 41 undergoes substantial
metabolism by CYP3A4 and CYP1A2, compound 68 has the
lengthiest half-life, and compounds 180 exhibit the least clinical
toxicity ratings.
DFT-based physiochemical
descriptor proﬁle
The physiochemical descriptors of the top hit compounds
obtained through virtual screening and the standard anticancer
drugs MTX and PTX were determined using DFT analysis and
are presented in Table 6. The aforementioned descriptors in the table
offer valuable insights into the electronic properties and reactivity of
the compounds, thereby playing a crucial role in comprehending
their behavior and potential applications. The electronic energy
values obtained for the compounds ranged from −2,810.59 atomic
units
to
−1,079.78
atomic
units.
Electronic
energy
is
a
comprehensive measure of the energy the electrons possess
within
a
given
system,
and
the
molecular
structure
and
composition of the compound determines its magnitude (Closs
et al., 1986). The dipole moment, denoted in Debye units (D), is
a quantitative measure of the spatial displacement between the
positive and negative charges within a given molecule (Minkin,
2012). The dipole moment values presented in Table 6 exhibited a
range spanning from 0.92 D to 9.31 D, which can be attributed to the
polarity and asymmetry characteristics of the compounds. The
EHomo values, which denote the highest occupied molecular
orbital energy, exhibited a range from −6.24 eV to −5.50 eV.
These values determine compounds’ electron donation ability,
where more negative EHomo values indicate a greater propensity
TABLE 5 MPNN-Deep Learning model based ADMET, top hit compounds predicted results.
Top
hits
Solubility Log
mol/L
Lipophilicity
Log-ratio
Absorption
(HIA) %
Absorption
(Pgp) %
Absorption
(bioavailability
F20) %
Distribution
(BBB) %
Distribution
(PPBR) %
09
−3.93
0.19
93.6
13
76.3
47.1
35.3
27
−4.77
1.89
98.61
12.7
78.46
60.38
90.89
41
−5.27
2.64
98.83
33.3
78.32
68.93
91.53
68
−4.05
2.38
98.4
16
78.16
68.24
55.5
74
−5.05
2.69
97.38
12.5
77.02
74.06
64.5
85
−4.38
2.45
98.92
21.3
78.46
74.68
73.47
99
−4.83
2.31
99.12
20.5
78.83
68.33
71.55
180
−5.45
1.22
97.44
12.9
77.94
43.47
94.11
MTX
−3.00/Soluble
0.00/No
91.51/Low
8.06/Yes
75.76/Yes
49.95/Yes
19.90/Yes
PTX
−3.94
0.14
93.24
8.76
75.96
52.15
41.96
Top
Hits
(Metabolism)
CYP2C19%
(Metabolism)
CYP2D6%
(Metabolism)
CYP3A4%
(Metabolism)
CYP1A2%
(Metabolism)
CYP2C9%
(Excretion)
Half life
hours
Clinical
Toxicity %
09
7.5
4
9.7
9
3.2
8.26
32
27
37.46
16.66
23.16
61.66
8.75
8.11
31.64
41
50.74
17.93
28.66
79.34
6.84
7.98
32.24
68
39.35
39.73
47.01
90.49
6.67
7.98
34.64
74
70.8
21.66
38.74
80.44
30.32
7.97
32.66
85
42.84
24.28
27.57
79.94
21.42
7.94
34.88
99
23.53
12
27.71
90.5
12.67
7.97
35.2
180
94.11
14.59
13.86
28.4
61.74
6.53
8.3
MTX
3.66/good
3.14/good
4.22/good
5.02/good
1.42/good
8.26/Medium
31.78/Medium
PTX
4.04
5.00
3.93
18.69
1.45
8.33
30.12
HIA, human intestinal absorption; Pgp, permeability-glycoprotein; BBB, blood brain barrier; PPBR, plasma protein binding rati; MTX results obtained from literature incorporated as MTX, deep
learning module value/Literature predictions (Uddin et al., 2019; Singh et al., 2022; Rana et al., 2019; Kawabata et al., 2013).
Frontiers in Chemistry
frontiersin.org
13
Siddique et al.
10.3389/fchem.2024.1380266

## Page 14 (Section: DFT-based physiochemical descriptor profile)

to donate electrons in chemical reactions. The values of ELumo, which
denote the energy of the lowest unoccupied molecular orbital,
exhibited a range spanning from −2.73 eV to −1.62 eV.
The ELumo plays a crucial role in the acceptance of electrons.
Compounds
exhibiting
lower
ELumo
values
demonstrate
a
heightened capacity for electron acceptance. The energy gap,
which is determined by the disparity between the EHomo and
ELumo,
explains
the
electron
transfer
capabilities
of
the
compound. The observed energy gap values range from 2.85 eV
to 4.21 eV, signifying the compounds’ diverse capacities for electron
donation or acceptance, as shown in Table 7. The ionization
potential is a fundamental concept in chemistry, which can be
mathematically expressed as the negative of the highest occupied
molecular orbital energy (EHomo). It signiﬁes the minimum amount
of energy needed to extract an electron from a molecule that is in a
neutral state. This study’s range of ionization potential values
spanned from 5.50 eV to 6.24 eV. This range suggests that the
compounds examined in this research exhibit varying degrees of
stability and resistance to remove electrons. The electron afﬁnity of a
molecule is determined by the energy change that occurs when an
electron is acquired, and it is quantiﬁed as the negative value of the
energy of the lowest unoccupied molecular orbital (ELumo). The
observed electron afﬁnity values ranged from 1.62 to 3.09 eV,
signifying the compounds’ inherent capacity to accept electrons.
Supplementary Table S3 showing the optimized XYZ coordinates
for top-hit anticancer compounds and reference drugs.
The chemical descriptors of the compounds were virtually screened
as top hits, and the standard anticancer drugs MTX and PTX were
assessed using DFT calculations. The results are presented in Table 8,
which showcases the outcomes obtained from the DFT calculations.
These descriptors provide valuable understandings of the compounds’
electronic structure, reactivity, and stability, elucidating their chemical
behavior. The chemical potential (μ) is determined by the arithmetic
mean of the ionization potential (I) and the electron afﬁnity (A), and it
signiﬁes the inclination of a compound to either donate or accept
electrons.
The
chemical
potential
values
in
Table
8
ranged
from −4.52 eV to −3.65 eV. These values indicate the compounds’
electronic stability and capacity to engage in electron transfer
phenomena. Electronegativity (χ) measures an element’s ability to
attract electrons, calculated as the average ionization potential and
electron afﬁnity. It is a quantitative indicator of a compound’s capacity
to
attract
electrons.
The
compounds
exhibited
a
range
of
electronegativity values, ranging from 4.52 eV to 3.65 eV, indicating
their diverse propensities to attract electrons during chemical reactions.
The chemical hardness (η) is determined by taking half the difference
between the ionization potential and the electron afﬁnity. It
characterizes the ability of a compound to resist alterations in its
electronic conﬁguration. The chemical hardness values in Table 8,
range from 1.43 eV to 2.11 eV, suggesting the compounds’ inherent
stability and capacity to endure electronic perturbations. Global softness
(σ), which is the inverse of chemical hardness, offers valuable insights
into the reactivity and vulnerability of a compound to electron transfer.
The global softness values exhibited a range spanning from 0.48 eV−1 to
0.70 eV−1, whereby lower values were indicative of heightened electron
transfer
resistance
and
chemical
reactivity.
A
compound’s
electrophilicity (ω) can be determined by evaluating the square of its
chemical potential divided by twice its chemical hardness. This
parameter measures the compound’s capacity to accept electrons
and engage in electrophilic reactions. The electrophilicity values
exhibited a range spanning from 6.64 eV to 10.22 eV, thereby
indicating the diverse propensities of the compounds to function as
electron acceptors. Most of the selected top hits exhibited ionization
potential, electrophilicity, and electron afﬁnity values similar to those of
the reference drugs, suggesting they behave electrochemically similarly
to MTX and PTX under physiologic conditions (Avendaño, 2008).
However, compounds 27 and 180 showed greater ionization potential
and electrophilicity, which may contribute to improved interactions and
potentially enhanced therapeutic efﬁcacy. The literature also showed
similar results of related studies with the DFT method use (Graffner-
Nordberg et al., 2000; Zia et al., 2019; Aziz et al., 2022a).
The physicochemical and chemical descriptors of the top hit
compounds identiﬁed through virtual screening and the standard
TABLE 6 DFT electronic parameters of top-hit anticancer compounds and standard drugs.
Top hit lead
compounds
Electronic
energy (a.u)
Dipole
moment
(Debye)
EHomo
(eV)
ELumo
(eV)
Energy
gap (eV)
Ionization
potential (eV)
Electron
afﬁnity (eV)
(I) = -EHOMO
(A) = -ELUMO
9
−1989.98
9.31
−5.97
−2.58
3.39
5.97
2.58
27
−1,462.33
4.87
−6.24
−2.03
4.21
6.24
2.03
41
−1,387.09
2.13
−5.97
−1.80
4.17
5.97
1.80
68
−1,079.78
3.71
−5.89
−1.94
3.95
5.89
1.94
74
−1926.65
4.67
−5.67
−1.62
4.04
5.67
1.62
85
−1,156.02
3.47
−5.50
−2.28
3.22
5.50
2.28
99
−1,116.70
3.80
−5.81
−2.33
3.48
5.81
2.33
180
−2,810.59
4.32
−5.95
−3.09
2.85
5.95
3.09
MTX
−1,590.11
4.99
−5.82
−2.38
3.44
5.82
2.38
PTX
−1,533.50
0.92
−5.92
−2.73
3.20
5.92
2.73
Frontiers in Chemistry
frontiersin.org
14
Siddique et al.
10.3389/fchem.2024.1380266

## Page 15 (Section: DFT-based physiochemical descriptor profile)

TABLE 7 EHOMO and ELUMO with energy gap (ΔE) values for top-hit compounds represented in electron volts (eV) and with frontial orbitals.
Top hits
EHomo (eV)
HOMO
ELumo (eV)
LUMO
Energy gap
(ΔEeV)
9
−5.97
−2.58
3.39
27
−6.24
−2.03
4.21
41
−5.97
−1.80
4.17
68
−5.89
−1.94
3.95
74
−5.67
−1.62
4.04
85
−5.50
−2.28
3.22
99
−5.81
−2.33
3.48
180
−5.95
−3.09
2.85
MTX
−5.82
−2.38
3.44
(Continued on following page)
Frontiers in Chemistry
frontiersin.org
15
Siddique et al.
10.3389/fchem.2024.1380266

## Page 16 (Section: Molecular dynamics simulation)

anticancer drugs MTX and PTX were thoroughly examined using
DFT analysis. The discoveries above contributed to an enhanced
comprehension of the compounds’ electronic characteristics,
reactivity, and stability, which are pivotal in assessing their
potential efﬁcacy as anticancer agents. The results obtained from
this study thus established a valuable resource for future drug design
efforts, as they contribute to the development of new compounds
that exhibit improved therapeutic effectiveness and targeted
anticancer properties and also contributed in alignment with the
existing literature (Hobani et al., 2017; Mammen et al., 2020; Rana
et al., 2020).
Molecular dynamics simulation
Molecular dynamics simulation
To determine the binding stability of protein-ligand complexes,
the MD simulation trajectories were evaluated by plotting the root
mean square deviation (RMSD), root mean square ﬂuctuation
(RMSF), hydrogen-bond proﬁle, solvent accessible surface area
and radius of gyration. The root-mean-square deviation (RMSD)
pattern provides remarkable insight into an average change in the
displacement of atoms to a frame. Figure 8 presented the RMSD
graphs of investigated ligands and compared them with those of
MTX and PTX. The average RMSDs for the protein-ligand
complexes of 09, 27, 41, 68, 74, 84, 99 and 180 were found to
be 0.24nm, 0.20nm, 0.21nm, 0.26nm, 0.23nm, 0.24nm, 0.28nm and
0.29 nm respectively. To assess the impact of ligands on a
conformational change in the protein structure, the RMSD of
each system was compared with the reference compounds MTX
and PTX, as shown in Figure 9. It has been observed that these ligand
complexes exhibited only slight variations in RMSDs throughout the
entire simulation, and the results were comparable with the
reference MTX and PTX. The ligands 09, 27 and 41 reached
equilibrium at about 6–10 ns and remained equilibrated for the
entire simulation duration, demonstrating the high stability of these
complexes with the target protein. The ligand 99 also formed a stable
complex; only slight variation is observed in the last 20 frames of
simulation. There is an increase in the RMSD values of the ligand 74
during 62–75 ns. After that, the system was again equilibrated and
was found to be stable for the rest of the simulation. A signiﬁcant
variance was observed in the RMSD values of ligands 68 and 85 after
about 55ns and remained least stable for the rest of the time.
The RMSF plots represent the protein regions that revealed a great
ﬂuctuation in their conformation during the simulation. In the present
study, the receptor was found to be stable throughout the simulation.
Only slight ﬂuctuations were evident in the binding site region with
RMSF values less than 0.2nm, considered negligible (Figure 10).
The H-bond proﬁle for all investigated ligands is illustrated in
Figure 11 and found to be in good agreement with RMSD analysis.
The most stable complexes of ligands 09, 27 and 41 were found to be
due to the formation of 3–4 H-bonds with the target protein for
TABLE 7 (Continued) EHOMO and ELUMO with energy gap (ΔE) values for top-hit compounds represented in electron volts (eV) and with frontial orbitals.
Top hits
EHomo (eV)
HOMO
ELumo (eV)
LUMO
Energy gap
(ΔEeV)
PTX
−5.92
−2.73
3.20
TABLE 8 DFT-based physiochemical descriptors of top-hit anticancer compounds and standard drugs.
Top hits
Chemical
potential (eV)
Electronegativity
(eV)
Chemical
Hardness (eV)
Global
softness (eV−1)
Electrophilicity
(eV)
(μ) = - (I + A)/2
(χ) = (I + A)/2
(η) = (I - A)/2
(σ) = 1/η
(ω) = μ2/2η
9
−4.28
4.28
1.70
0.59
9.14
27
−4.14
4.14
2.11
0.48
8.55
41
−3.89
3.89
2.09
0.48
7.55
68
−3.92
3.92
1.98
0.51
7.66
74
−3.65
3.65
2.03
0.49
6.64
85
−3.89
3.89
1.61
0.62
7.57
99
−4.07
4.07
1.74
0.57
8.28
180
−4.52
4.52
1.43
0.70
10.22
MTX
−4.10
4.10
1.72
0.58
8.41
PTX
−4.33
4.33
1.60
0.63
9.35
Frontiers in Chemistry
frontiersin.org
16
Siddique et al.
10.3389/fchem.2024.1380266

## Page 17 (Section: Molecular dynamics simulation)

most of the time during simulation. The ligands 74 and 99 formed
2–3 H-bonds, whereas ligand 180 formed 2–1 H-bonds over 100 ns
simulation that depicts the relative binding stability of these ligands
for time. Ligand 68 showed only 0–1 H-bond with high RMSDs in
the last 20 ns of simulation, resulting in decreased stability of
protein-ligand complex for the rest of the time. The binding
stability of ligand 85 also decreased during 55–80 ns due to the
decreased number of H-bonds with the target protein.
Solvent accessible surface area (SASA) is attributed to the
bimolecular surface area accessible to the solvent molecules. The
greater the increase in the value for SASA concerning time, the
lower the stability of the protein. In the current study, SASA of all
complexes was observed between 100 nm2 to 120 nm2, with an average
SASA value of 110 nm2, which is quite acceptable (Figure 12).
The analysis of the radius of gyration (Rg) provides information
about the overall dimensions of the protein during the 100 ns
FIGURE 8
Analysis of MD simulation trajectories; Root mean square deviation (RMSD) of investigated ligands compared with RMSDs of MTX and PTX over
time (100 ns).
FIGURE 9
Analysis of MD simulation trajectories; Root mean square deviation (RMSD) of protein-ligand complex compared with RMSDs of MTX and PTX
complex over time (100 ns).
Frontiers in Chemistry
frontiersin.org
17
Siddique et al.
10.3389/fchem.2024.1380266

## Page 18 (Section: Molecular dynamics simulation)

simulation. All the protein-ligand complexes under investigation
have shown a steady radius of gyration with an average value of
1.66 nm.
The
entire
simulation
indicates
good
protein
stability (Figure 13).
Supplementary Figure S18 presented the snapshots of
investigated ligands and reference compounds in complex with
protein at 0 ns. Supplementary Figures S19–S28 illustrates the
snapshots of investigated ligands along with MTX and PTX at
FIGURE 10
Analysis of MD simulation trajectories; Residue-wise root mean square ﬂuctuation (RMSF) of protein ligand complex compared with RMSF of
reference MTX and PTX complex.
FIGURE 11
Analysis of MD simulation trajectories; H-bond proﬁle of the protein-ligand complex over time (100 ns) compared with reference MTX and
PTX complex.
Frontiers in Chemistry
frontiersin.org
18
Siddique et al.
10.3389/fchem.2024.1380266

## Page 19 (Section: Molecular dynamics simulation)

25 ns, 50 ns, 75 ns and 100 ns indicating the stability of
investigated ligands and reference compounds within the
binding
pocket.
The
compound
68
complex
with
target
protein is found to be stable up to 75 ns as depicted in
Supplementary
Figure
S21
and
at
the
last
run
of
MD
simulation, the compound is out of the binding pocket. These
results are by the RMSD graph of compound 68-complex
illustrating its unstability in the last 20 ns of MD simulation
as shown in Figure 9.
The ﬁndings from Table 9, which outline the MM-PBSA of
MM-GBSA binding free energies in kJ/mol, reveal that Ligands 9,
27, 68, 99, MTX, and PTX consistently demonstrate the lowest
binding energies throughout the molecular dynamics (MD)
simulation
timeframe.
This
observation
has
important
scientiﬁc implications, indicating that these ligands have high
afﬁnities for the target receptor or binding site during the
simulation. The uniform low binding energies observed with
various ligands suggest strong and enduring interactions with the
receptor, demonstrating advantageous binding orientations and
energetic environments. These discoveries play a vital role in
drug discovery and design, as ligands with consistently low
binding energies are more likely to demonstrate strong and
FIGURE 12
Analysis of MD simulation trajectories; Solvent accessible surface area of protein-ligand complex compared with reference MTX and PTX complex
over time (100 ns).
FIGURE 13
Analysis of MD simulation trajectories; Radius of gyration of protein-ligand complex compared with reference MTX and PTX complex over
time (100 ns).
Frontiers in Chemistry
frontiersin.org
19
Siddique et al.
10.3389/fchem.2024.1380266

## Page 20 (Section: Conclusion)

dependable binding proﬁles, positioning them as promising
candidates for additional experimental validation and drug
development
endeavours.
Furthermore,
these
ﬁndings
highlight the success of the MM-PBSA method in capturing
the intricate molecular interactions and offering important
insights
into
the
energetics
of
ligand-receptor
binding
throughout MD simulations.
Conclusion
In summary, the 2D-QSAR model was generated to retrieve
the potential of the Zinc15 compound library as DHFR
inhibitors.
QSAR
modelling,
virtual
screening
and
deep
learning-based ADMET resulted in screening the top hits
compounds. The FDA-approved drugs, MTX & PTX, were
considered as standard drugs to which in silico ﬁndings could
be compared and examined. The eight top hits labelled as 09, 27,
41, 68, 74, 85, 99, and 180 were chosen with binding
afﬁnity ≤−11.0 kal/mol and pIC50 ranges from 5.85 to 7.64.
The ADMET parameters, Lipinski rule of ﬁve and clinical
toxicity matrices were considered to ensure drug likeliness
features and safety of the compounds under investigation. The
DFT was used to optimize the investigating compound’s stability
and
physicochemical
parameters.
The
top
hits
exhibited
electrophilicity
values
ranging
from
6.24 eV
to
10.22 eV,
representing
the
electron
acceptor
property
required
for
varying receptor interactions. Further, the molecular docking
and dynamics studies revealed signiﬁcantly higher binding
afﬁnity scores and stability of protein-ligand complex over
100 ns simulation compared to reference drugs MTX and
PTX, endorsing their reliable anticancer activity. The study
provided
considerable
insight
for
developing
selected
compounds as novel anticancer drugs in the future. In short,
the ﬁndings of the current study identiﬁed top hits that could
prove themselves as an effective treatment strategy for DHFR
inhibition leading to treat and manage cancer malignancies.
These ﬁndings will assist researchers to develop newer leads
without consuming much time and ﬁnancial resources so further
experimental studies are also recommended for future prospects
and to explore its newer aspects. In view of the current study,
there is always a platform for future studies focusing on the
incorporation of a more extensive and diverse set of experimental
data to apply the approach developed here to in-vivo for the sake
of developing a generalized model.
Data availability statement
The original contributions presented in the study are included in
the article/Supplementary Material, further inquiries can be directed
to the corresponding authors.
Author contributions
FS: Supervision, Project administration, Writing–original draft. AA:
Conceptualization,
Writing–original
draft.
MaB:
Methodology,
Writing–original draft. SN: Formal Analysis, Writing–original draft.
RR:
Formal
Analysis,
Writing–original
draft.
VE:
Resources,
Writing–original draft. SA: Validation, Writing–original draft. MeB:
Visualization,
Writing–original
draft.
YB:
Supervision,
Writing–original draft. MoB: Writing–original draft, Writing–review
and editing.
Funding
The author(s) declare ﬁnancial support was received for the
research, authorship, and/or publication of this article. The
authors would like to extend their sincere appreciation to the
Researchers Supporting Project, King Saud University, Riyadh,
Saudi Arabia for funding this work through the project number
(RSP2024R457).
Acknowledgments
The authors would like to extend their sincere appreciation to
the Researchers Supporting Project, King Saud University, Riyadh,
Saudi Arabia for funding this work through the project number
(RSP2024R457).
TABLE 9 MM-PBSA of MM-GBSA binding free energies estimated in kJ/mol.
Energy (kJ/mol)
9
27
41
68
74
85
99
180
MTX
PTX
MMGBSA
ΔEvdw
−197.32
−182.26
−270.6
−179.62
−290.58
−210.58
−220.6
−230.6
−192.23
−185.23
ΔEelec
−551.54
−543.39
−478
−556.85
−498.02
−403.02
−439.1
−467.0
−537.41
−511.71
ΔEsolv
654.78
641.93
585.32
645.36
532.23
525.39
517.23
505.32
654.95
626.41
ΔESASA
−22.18
−21.85
−21.89
−21.1
−22.89
−24.849
−23.89
−21.89
−21.07
−20.96
ΔGbinding
−116.26
−105.57
−185.17
−112.21
−279.26
−113.06
−166.36
−214.17
−95.76
−91.49
Lowest free binding energy ligand numbers is shown in bold, vdw van der Waals, elect electrostatic, solv polar solvation, SASA solvent-accessible surface area.
Frontiers in Chemistry
frontiersin.org
20
Siddique et al.
10.3389/fchem.2024.1380266

## Page 21 (Section: Conflict of interest)

Conﬂict of interest
The authors declare that the research was conducted in the
absence of any commercial or ﬁnancial relationships that could be
construed as a potential conﬂict of interest.
Publisher’s note
All claims expressed in this article are solely those of the authors
and
do
not
necessarily
represent
those
of
their
afﬁliated
organizations, or those of the publisher, the editors and the
reviewers. Any product that may be evaluated in this article, or
claim that may be made by its manufacturer, is not guaranteed or
endorsed by the publisher.
Supplementary material
The Supplementary Material for this article can be found online
at: https://www.frontiersin.org/articles/10.3389/fchem.2024.1380266/
full#supplementary-material
References
Abdelrheem, D. A., Ahmed, S. A., Abd El-Mageed, H. R., Mohamed, H. S., Rahman,
A. A., Elsayed, K. N. M., et al. (2020). The inhibitory effect of some natural bioactive
compounds against SARS-CoV-2 main protease: insights from molecular docking
analysis and molecular dynamic simulation. J. Environ. Sci. Health, Part A 55 (11),
1373–1386. doi:10.1080/10934529.2020.1826192
Abdolmaleki, A., and Ghasemi, J. B. (2017). Dual-acting of hybrid compounds-a new
dawn in the discovery of multi-target drugs: lead generation approaches. Curr.
Top. Med. Chem. 17 (9), 1096–1114. doi:10.2174/1568026616666160927151144
Aher, A., Udhwani, T., Khandelwal, R., Limaye, A., Hussain, T., Nayarisseri, A., et al. (2020).
In silico insights on IL-6: a potential target for multicentric castleman disease. Curr. computer-
aided drug Des. 16 (5), 641–653. doi:10.2174/1573409915666190902142524
Al-Jumaili, M. H. A., Hamad, A. A., Hashem, H. E., Hussein, A. D., Muhaidi, M. J.,
Ahmed, M. A., et al. (2023a). Comprehensive review on the Bis–heterocyclic
compounds and their anticancer efﬁcacy. J. Mol. Struct. 1271, 133970. doi:10.1016/j.
molstruc.2022.133970
Al-Jumaili, M. H. A., Siddique, F., Abul Qais, F., Hashem, H. E., Chtita, S., Rani, A., et al.
(2023b). Analysis and prediction pathways of natural products and their cytotoxicity against
HeLa cell line protein using docking, molecular dynamics and ADMET. J. Biomol. Struct.
Dyn. 41 (3), 765–777. doi:10.1080/07391102.2021.2011785
Andricopulo, A. D., Guido, R. V., and Oliva, G. (2008). Virtual screening and its
integration with modern drug design technologies. Curr. Med. Chem. 15 (1), 37–46.
doi:10.2174/092986708783330683
Avendaño, C. (2008). “Chapter 2-antimetabolites,” in Medicinal chemistry of
anticancer drugs, 9–52.
Aziz, M., Ejaz, S. A., Tamam, N., and Siddique, F. (2022b). A comprehensive
computational
approach
for
the
identiﬁcation
of
structure-based
potential
pharmacological
candidates
as
selective
AKR1B1
and
AKR1B10
inhibitors:
repurposing of purine alkaloids for the treatment of cancer. J. Biomol. Struct. Dyn.
41, 7892–7912. doi:10.1080/07391102.2022.2127906
Aziz, M., Ejaz, S. A., Zargar, S., Akhtar, N., Aborode, A. T., A. Wani, T., et al. (2022a).
Deep learning and structure-based virtual screening for drug discovery against NEK7: a
novel target for the treatment of cancer. Molecules 27 (13), 4098. doi:10.3390/
molecules27134098
Bekker,
H.
(1993).
“Gromacs-a
parallel
computer
for
molecular-dynamics
simulations,” in 4th international conference on computational physics, Buenos
Aires, Argentina, October 18-22, 1993.
Berendsen, H. J., van der Spoel, D., and van Drunen, R. (1995). GROMACS: a
message-passing
parallel
molecular
dynamics
implementation.
Comput.
Phys.
Commun. 91 (1-3), 43–56. doi:10.1016/0010-4655(95)00042-e
Brogi, S. (2020). In silico methods for drug design and discovery. Lausanne,
Switzerland: Frontiers Media SA, 612.
Choudhary, R., Walhekar, V., Muthal, A., Kumar, D., Bagul, C., and Kulkarni, R.
(2023). Machine learning facilitated structural activity relationship approach for the
discovery of novel inhibitors targeting EGFR. J. Biomol. Struct. Dyn. 41, 12445–12463.
doi:10.1080/07391102.2023.2175263
Closs, G., Calcaterra, L. T., Green, N. J., Penﬁeld, K. W., and Miller, J. R. (1986).
Distance, stereoelectronic effects, and the Marcus inverted region in intramolecular
electron transfer in organic radical anions. J. Phys. Chem. 90 (16), 3673–3683. doi:10.
1021/j100407a039
DeLano, W. L. (2002). Pymol: An open-source molecular graphics tool. CCP4 Newsl.
Protein Crystallogr. 40 (1), 82–92.
Dermawan, D., Prabowo, B. A., and Rakhmadina, C. A. (2021). In silico study of
medicinal plants with cyclodextrin inclusion complex as the potential inhibitors against
SARS-CoV-2 main protease (Mpro) and spike (S) receptor. Inf. Med. Unlocked 25,
100645. doi:10.1016/j.imu.2021.100645
Deschenes, L. A., and Vanden BoutUniversity of Texas, A. D. A. (2000). Origin 6.0:
scientiﬁc data analysis and graphing software origin lab corporation (formerly microcal
software, inc.). Available at: http://www.originlab.com.
Devi, S., Rangra, N. K., Rawat, R., Alrobaian, M. M., Alam, A., Singh, R., et al. (2021).
Anti-atherogenic effect of Nepitrin-7-O-glucoside: a ﬂavonoid isolated from Nepeta
hindostana via acting on PPAR–α receptor. Steroids 165, 108770. doi:10.1016/j.steroids.
2020.108770
DiLabio,
G.
A.,
Koleini,
M.,
and
Torres,
E.
(2013).
Extension
of
the
B3LYP–dispersion-correcting potential approach to the accurate treatment of both
inter-and intra-molecular interactions. Theor. Chem. Accounts 132, 1389–1413. doi:10.
1007/s00214-013-1389-x
Di Pierro, M., Elber, R., and Leimkuhler, B. (2015). A stochastic algorithm for the
isobaric–isothermal ensemble with Ewald summations for all long range forces. J. Chem.
theory Comput. 11 (12), 5624–5637. doi:10.1021/acs.jctc.5b00648
Ekins, S., Mestres, J., and Testa, B. (2007). In silico pharmacology for drug discovery:
methods for virtual ligand screening and proﬁling. Br. J. Pharmacol. 152 (1), 9–20.
doi:10.1038/sj.bjp.0707305
El-Adl, K., Ibrahim, M. K., Alesawy, M. S., and Eissa, I. H. (2021). [1, 2, 4] Triazolo [4,
3-c] quinazoline and bis ([1, 2, 4] triazolo)[4, 3-a: 4′, 3′-c] quinazoline derived DNA
intercalators: design, synthesis, in silico ADMET proﬁle, molecular docking and anti-
proliferative evaluation studies. Bioorg. Med. Chem. 30, 115958. doi:10.1016/j.bmc.2020.
115958
El-Shamy, I., Hleli, E., Alsheikh, A. A., Yawer, M. A., El-Hashash, M. A., Dybal, J.,
et al. (2022). Synthesis of some mono-and disaccharide-grafting phthalazine
derivatives and some new Se-nucleoside analogues: antibacterial properties,
quantum chemical calculations, and cytotoxicity. Molecules 28 (1), 317. doi:10.
3390/molecules28010317
Ferreira, L. G., dos Santos, R., Oliva, G., and Andricopulo, A. (2015). Molecular
docking and structure-based drug design strategies. Molecules 20 (7), 13384–13421.
doi:10.3390/molecules200713384
Ferreira, O. O., Mali, S. N., Jadhav, B., Chtita, S., Kuznetsov, A., Bhandare, R. R., et al.
(2023). Synthesis, in-silico, in vitro and DFT assessments of substituted imidazopyridine
derivatives as potential antimalarials targeting hemoglobin degradation pathway.
J. Comput. Biophysics Chem. 22, 795–814. doi:10.1142/s2737416523500412
Fralish, Z., Chen, A., Skaluba, P., and Reker, D. (2023). DeepDelta: predicting
ADMET
improvements
of
molecular
derivatives
with
deep
learning.
J. Cheminformatics 15, 101. doi:10.1186/s13321-023-00769-x
Frisch, M. J. (2009). Gaussian09. Available at: http://www.gaussian.com/.
Ganesan, A., Coote, M. L., and Barakat, K. (2017). Molecular dynamics-driven drug
discovery: leaping forward with conﬁdence. Drug Discov. today 22 (2), 249–269. doi:10.
1016/j.drudis.2016.11.001
Graffner-Nordberg, M., Marelius, J., Ohlsson, S., Persson, Å., Swedberg, G.,
Andersson, P., et al. (2000). Computational predictions of binding afﬁnities to
dihydrofolate
reductase:
synthesis
and
biological
evaluation
of
methotrexate
analogues. J. Med. Chem. 43 (21), 3852–3861. doi:10.1021/jm0009639
Hammoudan, I., Chtita, S., Daoui, O., Elkhattabi, S., Bakhouch, M., El Yazidi, M., et al.
(2023). QSAR and DFT studies of some tacrine-hydroxamate derivatives as inhibitors of
cholinesterase (AChEs) in the treatment of alzheimer’s disease. Lett. Drug Des. Discov.
20 (6), 699–712. doi:10.2174/1570180819666220512174409
Hanwell, M. D., Curtis, D. E., Lonie, D. C., Vandermeersch, T., Zurek, E., and Hutchison, G.
R. (2012). Avogadro: an advanced semantic chemical editor, visualization, and analysis
platform. J. cheminformatics 4 (1), 17. doi:10.1186/1758-2946-4-17
Hess, B., Bekker, H., Berendsen, H. J. C., and Fraaije, J. G. E. M. (1997). LINCS: a
linear constraint solver for molecular simulations. J. Comput. Chem. 18 (12),
1463–1472. doi:10.1002/(sici)1096-987x(199709)18:12<1463::aid-jcc4>3.3.co;2-l
Frontiers in Chemistry
frontiersin.org
21
Siddique et al.
10.3389/fchem.2024.1380266

## Page 22 (Section: Conflict of interest)

Hobani, Y., Jerah, A., and Bidwai, A. (2017). A comparative molecular docking study
of curcumin and methotrexate to dihydrofolate reductase. Bioinformation 13 (3), 63–66.
doi:10.6026/97320630013063
Hohenberg, P., and Kohn, W. (1964). Inhomogeneous electron gas. Phys. Rev. 136
(3B), B864–B871. doi:10.1103/physrev.136.b864
Huang, K., Fu, T., Glass, L. M., Zitnik, M., Xiao, C., and Sun, J. (2020a). DeepPurpose:
a deep learning library for drug–target interaction prediction. Bioinformatics 36 (22-23),
5545–5547. doi:10.1093/bioinformatics/btaa1005
Huang, K., Fu, T., Khan, D., Abid, A., Abidala, A., Abid, A., et al. (2020b). Moldesigner:
interactive design of efﬁcacious drugs with deep learning. arXiv preprint arXiv:2010.03951.
Huennekens, F. (1994). The methotrexate story: a paradigm for development of
cancer chemotherapeutic agents. Adv. enzyme Regul. 34, 397–419. doi:10.1016/0065-
2571(94)90025-6
Humphrey, W., Dalke, A., and Schulten, K. (1996). VMD: visual molecular dynamics.
J. Mol. Graph. 14 (1), 33–38. doi:10.1016/0263-7855(96)00018-5
Imran, M., Abida, A., Alotaibi, N. M., Thabet, H. K., Alruwaili, J. A., Eltaib, L.,
et al. (2023). Repurposing anti-dengue compounds against monkeypox virus
targeting
core
cysteine
protease.
Biomedicines 11
(7), 2025. doi:10.3390/
biomedicines11072025
Jemai, M., Khalﬁ, M., Issaoui, N., Roisnel, T., Kazachenko, A. S., Al-Dossary, O., et al.
(2023). Role of non-covalent interactions in novel supramolecular compound, bis (4-
phenylpiperazin-1-ium) oxalate dihydrate: synthesis, molecular structure, thermal
characterization, spectroscopic properties and quantum chemical study. Crystals 13
(6), 875. doi:10.3390/cryst13060875
Kalaydina, R.-V., Bajwa, K., Qorri, B., DeCarlo, A., and Szewczuk, M. R. (2018).
Recent advances in &quot;smart&amp;quot; delivery systems for extended drug release
in cancer therapy. Int. J. nanomedicine Vol. 13, 4727–4745. doi:10.2147/ijn.s168053
Kanagathara, N., Usha, R., Natarajan, V., and Marchewka, M. (2022). Molecular
geometry, vibrational, NBO, HOMO–LUMO, ﬁrst order hyper polarizability and
electrostatic potential studies on anilinium hydrogen oxalate hemihydrate–an
organic crystalline salt. Inorg. Nano-Metal Chem. 52 (2), 226–233. doi:10.1080/
24701556.2021.1891103
Katari, S. K., Natarajan, P., Swargam, S., Kanipakam, H., Pasala, C., and
Umamaheswari, A. (2016). Inhibitor design against JNK1 through e-pharmacophore
modeling docking and molecular dynamics simulations. J. Recept. Signal Transduct. 36
(6), 558–571. doi:10.3109/10799893.2016.1141955
Kawabata, H., Kadowaki, N., Nishikori, M., Kitawaki, T., Kondo, T., Ishikawa, T., et al.
(2013). Clinical features and treatment of multicentric castleman’s disease: a
retrospective
study
of
21
Japanese
patients
at
a
single
institute.
J.
Clin.
Exp. Hematop. 53 (1), 69–77. doi:10.3960/jslrt.53.69
Kim, J., Woo, S. Y., Im, C. Y., Yoo, E. K., Lee, S., Kim, H. J., et al. (2016). Insights of a
lead optimization study and biological evaluation of novel 4-hydroxytamoxifen analogs
as estrogen-related receptor γ (ERRγ) inverse agonists. J. Med. Chem. 59 (22),
10209–10227. doi:10.1021/acs.jmedchem.6b01204
Lavecchia, A., and Di Giovanni, C. (2013). Virtual screening strategies in drug
discovery: a critical review. Curr. Med. Chem. 20 (23), 2839–2860. doi:10.2174/
09298673113209990001
Leelananda, S. P., and Lindert, S. (2016). Computational methods in drug discovery.
Beilstein J. Org. Chem. 12 (1), 2694–2718. doi:10.3762/bjoc.12.267
Liamputtong,
P.,
and
Suwankhong,
D.
(2015).
Breast
cancer
diagnosis:
biographical disruption, emotional experiences and strategic management in Thai
women with breast cancer. Sociol. Health & Illn. 37 (7), 1086–1101. doi:10.1111/
1467-9566.12282
Liu, P., and Long, W. (2009). Current mathematical methods used in QSAR/QSPR
studies. Int. J. Mol. Sci. 10 (5), 1978–1998. doi:10.3390/ijms10051978
Lo, Y.-C., Rensi, S. E., Torng, W., and Altman, R. B. (2018). Machine learning in
chemoinformatics and drug discovery. Drug Discov. today 23 (8), 1538–1546. doi:10.
1016/j.drudis.2018.05.010
Mammen, M., Mohanan, A. G., and Kumar, P. (2020). Computational and
experimental validation of methotrexate as Staphylococcal-DHFR inhibitor. Curr.
Trends Biotechnol. Pharm. 14 (4), 396–402. doi:10.5530/ctbp.2020.4.41
Mark, P., and Nilsson, L. (2001). Structure and dynamics of the TIP3P, SPC, and SPC/
E water models at 298 K. J. Phys. Chem. A 105 (43), 9954–9960. doi:10.1021/jp003020w
Matera, C., Gomelia, A. M. J., Nuria, C., and Pau, G. (2019). “Photochromic antifolate
for light-activated chemotherapy,” in 17th International Photodynamic Association
World Congress, Boston, USA, June 28 – July 4, 2019.
Matera, C., Gomila, A. M. J., Camarero, N., Libergoli, M., Soler, C., and Gorostiza, P.
(2018). Photoswitchable antimetabolite for targeted photoactivated chemotherapy.
J. Am. Chem. Soc. 140 (46), 15764–15773. doi:10.1021/jacs.8b08249
Minkin, V. I. (2012). Dipole moments in organic chemistry. Berlin, Germany: Springer
Science & Business Media.
Nazki, F. H., Sameer, A. S., and Ganaie, B. A. (2014). Folate: metabolism, genes,
polymorphisms and the associated diseases. Gene 533 (1), 11–20. doi:10.1016/j.gene.2013.09.063
Nilsson, R., Jain, M., Madhusudhan, N., Sheppard, N. G., Strittmatter, L., Kampf, C., et al.
(2014). Metabolic enzyme expression highlights a key role for MTHFD2 and the
mitochondrial folate pathway in cancer. Nat. Commun. 5 (1), 3128. doi:10.1038/ncomms4128
Prieto-Martínez, F. D., Arciniega, M., and Medina-Franco, J. L. (2018). Molecular
docking: current advances and challenges. TIP. Revista especializada en ciencias
químico-biológicas, 21.
Raimondi, M. V., Randazzo, O., La Franca, M., Barone, G., Vignoni, E., Rossi, D., et al.
(2019). DHFR inhibitors: reading the past for discovering novel anticancer agents.
Molecules 24 (6), 1140. doi:10.3390/molecules24061140
Rana, R. M., Rampogu, S., Abid, N. B., Zeb, A., Parate, S., Lee, G., et al. (2020). In silico study
identiﬁed methotrexate analog as potential inhibitor of drug resistant human dihydrofolate
reductase for cancer therapeutics. Molecules 25 (15), 3510. doi:10.3390/molecules25153510
Rana, R. M., Rampogu, S., Zeb, A., Son, M., Park, C., Lee, G., et al. (2019). In silico
study probes potential inhibitors of human dihydrofolate reductase for cancer
therapeutics. J. Clin. Med. 8 (2), 233. doi:10.3390/jcm8020233
Rasheed, M. A., Iqbal, M. N., Saddick, S., Ali, I., Khan, F. S., Kanwal, S., et al. (2021).
Identiﬁcation of lead compounds against Scm (fms10) in Enterococcus faecium using
computer aided drug designing. Life 11 (2), 77. doi:10.3390/life11020077
Rawat, R., Kant, K., Kumar, A., Bhati, K., and Verma, S. M. (2021). HeroMDAnalysis:
an automagical tool for GROMACS-based molecular dynamics simulation analysis.
Future Med. Chem. 13 (05), 447–456. doi:10.4155/fmc-2020-0191
Rifaioglu, A. S., Atas, H., Martin, M. J., Cetin-Atalay, R., Atalay, V., and Doğan, T.
(2019). Recent applications of deep learning and machine intelligence on in silico drug
discovery: methods, tools and databases. Brieﬁngs Bioinforma. 20 (5), 1878–1912.
doi:10.1093/bib/bby061
Rose, P. W., Beran, B., Bi, C., Bluhm, W. F., Dimitropoulos, D., Goodsell, D. S., et al.
(2010). The RCSB Protein Data Bank: redesigned web site and web services. Nucleic
acids Res. 39 (Suppl. l_1), D392–D401. doi:10.1093/nar/gkq1021
Sánchez-Linares, I., Pérez-Sánchez, H., Cecilia, J. M., and García, J. M. (2012). High-
throughput parallel blind virtual screening using BINDSURF. BMC Bioinforma. 13,
S13–S14. doi:10.1186/1471-2105-13-s14-s13
Santarpia, L., Lippman, S. M., and El-Naggar, A. K. (2012). Targeting the
MAPK–RAS–RAF signaling pathway in cancer therapy. Expert Opin. Ther. targets
16 (1), 103–119. doi:10.1517/14728222.2011.645805
Schmid, N., Eichenberger, A. P., Choutko, A., Riniker, S., Winger, M., Mark, A. E.,
et al. (2011). Deﬁnition and testing of the GROMOS force-ﬁeld versions 54A7 and 54B7.
Eur. biophysics J. 40, 843–856. doi:10.1007/s00249-011-0700-9
Siddiq, M. (2022). Revolutionizing drug discovery; transformative role of machine
learning. BULLET J. Multidisiplin Ilmu 1 (02), 162–170.
Siddique, F., Aqdas, A., Bashir, M., Nadeem, S., Rawat, R., Ahmad, S., et al. (2024).
Harnessing the Potential of Natural Products in Cancer Treatment: A Comprehensive
Review. J. Biol. Regul. Homeost. Agents 38 (2), 873–897. doi:10.23812/j.biol.regul.
homeost.agents.20243802.72
Singh, A., Deshpande, N., Pramanik, N., Jhunjhunwala, S., Rangarajan, A., and
Atreya, H. S. (2018). Optimized peptide based inhibitors targeting the dihydrofolate
reductase pathway in cancer. Sci. Rep. 8 (1), 3190. doi:10.1038/s41598-018-21435-5
Singh, M. B., Vishvakarma, V. K., Lal, A. A., Chandra, R., Jain, P., and Singh, P.
(2022). A comparative study of 5-ﬂuorouracil, doxorubicin, methotrexate,
paclitaxel for their inhibition ability for Mpro of nCoV: molecular docking and
molecular dynamics simulations. J. Indian Chem. Soc. 99 (12), 100790. doi:10.
1016/j.jics.2022.100790
Staszak, M., Staszak, K., Wieszczycka, K., Bajek, A., Roszkowski, K., and Tylkowski, B.
(2022). Machine learning in drug design: use of artiﬁcial intelligence to explore the
chemical structure–biological activity relationship. Wiley Interdiscip. Rev. Comput. Mol.
Sci. 12 (2), e1568. doi:10.1002/wcms.1568
Sutherland, J. J., O’brien, L. A., and Weaver, D. F. (2003). Spline-ﬁtting with a genetic
algorithm: a method for developing classiﬁcation structure−activity relationships.
J. Chem. Inf. Comput. Sci. 43 (6), 1906–1915. doi:10.1021/ci034143r
Tang, M., Li, B., and Chen, H. (2023). Application of message passing neural networks
for molecular property prediction. Curr. Opin. Struct. Biol. 81, 102616. doi:10.1016/j.sbi.
2023.102616
Thalla, M., Kant, K., Dalchand, Rawat, R., and Banerjee, S. (2020). Merged
experimental guided computational strategy toward tuberculosis treatment mediated
by alveolar macrophages mannose receptor. J. Biomol. Struct. Dyn. 38 (17), 5195–5203.
doi:10.1080/07391102.2019.1697369
Trott, O., Olson, A. J., and Vina, A. D. (2010). AutoDock Vina: improving the speed
and accuracy of docking with a new scoring function, efﬁcient optimization, and
multithreading. J. Comput. Chem. 31 (2), 455–461. doi:10.1002/jcc.21334
Tsuneda, T., Song, J. W., Suzuki, S., and Hirao, K. (2010). On Koopmans’ theorem in
density functional theory. J. Chem. Phys. 133 (17), 174101. doi:10.1063/1.3491272
Uddin, N., Ahmed, S., Khan, A. M., Mazharol Hoque, M., and Halim, M. A. (2019).
Halogenated derivatives of methotrexate as human dihydrofolate reductase inhibitors in
cancer chemotherapy. J. Biomol. Struct. Dyn. 38, 901–917. doi:10.1080/07391102.2019.
1591302
Frontiers in Chemistry
frontiersin.org
22
Siddique et al.
10.3389/fchem.2024.1380266

## Page 23 (Section: Conflict of interest)

Van Aalten, D. M., Bywater, R., Findlay, J. B. C., Hendlich, M., Hooft, R. W. W., and
Vriend, G. (1996). PRODRG, a program for generating molecular topologies and
unique molecular descriptors from coordinates of small molecules. J. computer-aided
Mol. Des. 10, 255–262. doi:10.1007/bf00355047
Van Gunsteren, W. F., and Berendsen, H. J. (1988). A leap-frog algorithm
for
stochastic
dynamics.
Mol.
Simul.
1
(3),
173–185.
doi:10.1080/
08927028808080941
Vaught, A. (1996). Graphing with Gnuplot and Xmgr: two graphing packages
available under linux. Linux J. 1996 (28es), 7–es.
Veerasamy, R., Rajak, H., Jain, A., Sivadasan, S., Varghese, C. P., Agrawal, R. K., et al.
(2011). Validation of QSAR models-strategies and importance. Int. J. Drug Des. Discov.
3, 511–519.
Weiner, S. J., Kollman, P. A., Case, D. A., Singh, U. C., Ghio, C., Alagona, G., et al.
(1984). A new force ﬁeld for molecular mechanical simulation of nucleic acids and
proteins. J. Am. Chem. Soc. 106 (3), 765–784. doi:10.1021/ja00315a051
Winkler, D. A. (2021). Use of artiﬁcial intelligence and machine learning for discovery
of drugs for neglected tropical diseases. Front. Chem. 9, 614073. doi:10.3389/fchem.
2021.614073
Yamashita, K., Kiyonari, S., Tsubota, S., Kishida, S., Sakai, R., and Kadomatsu, K.
(2020). Thymidylate synthase inhibitor raltitrexed can induce high levels of DNA
damage in MYCN-ampliﬁed neuroblastoma cells. Cancer Sci. 111 (7), 2431–2439.
doi:10.1111/cas.14485
Yang, C., Zhang, J., Liao, M., Yang, Y., Wang, Y., Yuan, Y., et al. (2021). Folate-
mediated one-carbon metabolism: a targeting strategy in cancer therapy. Drug Discov.
Today 26 (3), 817–825. doi:10.1016/j.drudis.2020.12.006
Yang, D., Zhang, Q., Song, X., and Zhang, T. (2019). Investigation of the intramolecular
hydrogen bonding interactions and excited state proton transfer mechanism for both Br-BTN
and CN-BTN systems. RSC Adv. 9 (40), 23004–23011. doi:10.1039/c9ra04258j
Yu, J.-L., Dai, Q.-Q., and Li, G.-B. (2022). Deep learning in target prediction and drug
repositioning: recent advances and challenges. Drug Discov. Today 27 (7), 1796–1814.
doi:10.1016/j.drudis.2021.10.010
Zhang, L., Tan, J., Han, D., and Zhu, H. (2017). From machine learning to deep
learning: progress in machine intelligence for rational drug discovery. Drug Discov.
today 22 (11), 1680–1685. doi:10.1016/j.drudis.2017.08.010
Zhurko, G. A., and Zhurko, D. A. (2005). Chemcraft—graphical program for
visualization of quantum chemistry computations. Academic version, 1.
Zia, M. K., Siddiqui, T., Ali, S. S., Ahsan, H., and Khan, F. H. (2019). Understanding
the binding interaction between methotrexate and human alpha-2-macroglobulin:
multi-spectroscopic and computational investigation. Archives Biochem. biophysics
675, 108118. doi:10.1016/j.abb.2019.108118
Frontiers in Chemistry
frontiersin.org
23
Siddique et al.
10.3389/fchem.2024.1380266


---

# Role of artificial intelligence in revolutionizing drug discovery

- **Authors:** Ashfaq Ur Rehman, Mingyu Li, Binjian Wu, Yasir Ali, Salman Rasheed, Sana Shaheen, Xinyi Liu, Ray Luo, Jian Zhang
- **Issuer:** Fundamental research
- **Type:** Scientific article
- **Published:** 2024-05-09
- **Language:** en
- **DOI:** 10.1016/j.fmre.2024.04.021
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40528990/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThe application of artificial intelligence (AI) in medicine, particularly through machine learning (ML), marked a significant progression in drug discovery. AI acts as a powerful catalyst in narrowing the gap between disease understanding and the identification of potential therapeutic agents. This review provides an inclusive summary of the latest advancements in AI and its application in drug discovery. We examine the various stages of the drug discovery process, starting from disease identification and encompassing diagnosis, target identification, screening, and lead discovery. AI's capability to analyze extensive datasets and discern patterns is essential in these stages, enhancing predictions and efficiencies in disease identification, drug discovery, and clinical trial management. The role of AI in expediting drug development is emphasized, highlighting its potential to analyze vast data volumes, thus reducing the time and costs associated with new drug market introduction. The importance of data quality, algorithm training, and ethical considerations, especially in patient data handling during clinical trials, is addressed. By considering these factors, AI promises to transform drug development, offering significant benefits to patients and society.Keywords: Artificial intelligence, Machine learning, Disease identification, Drug design, Drug discovery

## Section: Introduction

The traditional drug discovery process is a complex and challenging endeavor that can require up to 15 years and over $1 to 2 billion for each approved drug [1]. This is primarily due to rising attrition rates and extended clinical trial duration [2]. Despite considerable investment in resources, almost 90% of potential drug candidates fail even after they have advanced to the phase-I clinical trial [3]. Advancing a drug candidate to phase-I clinical trial after rigorous optimization at the preclinical stage is considered a significant milestone for both pharmaceutical companies and academic institutions [4].

Large-scale computational screening and docking have been employed to enhance the success rate of lead compounds in clinical trials [5]. However, these methods have limitations such as inefficiency and inaccuracy [6]. To overcome these challenges, deep learning (DL) and ML algorithms, which are subsets of AI, have been identified as potential solutions [7]. These AI tools possess the ability to predict macrosystem properties with high accuracy while incurring low computational costs. As a result, there has been an increasing adoption of AI algorithms in the drug discovery process by chemical and biological scientists.

ML is extensively used in drug discovery, employing algorithms such as DL, Bayesian network (BN), random forest (RF), clustering, and support vector machine (SVM). The broad categorization of ML can be seen in Fig. 1. DL models process and analyze large amounts of data in tasks such as clinical imaging [8,9], virtual screening (VS) [10,11], and bioactivity predictions [12]. BNs predict toxicity or bioactivity and patients’ response to treatments [13]. RF models are used for molecular target identification and feature selection, while clustering identifies patterns or relationships within data [14]. SVM is a supervised learning algorithm used to classify data into categories, with applications such as predicting pharmacokinetic properties, VS, and toxicity prediction [15].

Computational modelling based on AI and ML has made various drug discovery processes achievable, including chemical compound identification, target identification, peptide synthesis, drug toxicity and physiochemical property assessment, drug monitoring, drug efficacy and effectiveness assessment, bioactive agent prediction, protein-protein interaction, protein folding and misfolding identification, structure and ligand-based virtual screening (LBVS), QSAR modeling, and drug repositioning [16]. ML algorithms have made it faster to identify lead compounds from chemical libraries that contain over 106 million compounds and solve the toxicity challenges caused by off-target interactions [17]. Furthermore, ML-based tools such as AlphaFold have made it easier to predict the 3D structure of a target protein, which is crucial in drug discovery process.

AlphaFold is a recently developed AI-based tool from Google's DeepMind. Researchers have also used AI to discover novel peptides for therapeutic purposes. Provenzano et al. [18] created Deep-AmPEP30, a DL-based platform for the identification of short anti-microbial peptides (AMPs) [18], while Yi et al. [19] devised ACP-DL, a DL-based tool using the LSTM algorithm, for the discovery of novel anti-cancer peptides (https://github.com/haichengyi/ACPDL) [20]. AI is increasingly used in determining the proper drug dosage. Shen, Liu et al. [21] created the AI-PRS platform, a neural network-driven methodology that uses a parabolic response curve (PRS) to associate drug combinations and dose to efficacy [22], while machine and statistical learning techniques including k-nearest neighbor (kNN), Naive Bayesian, SVM, ANN, decision trees (DT), and RF are employed to forecast the hindrance in protein-protein interactions [23]. VS is an efficient method in computer-aided drug design (CADD), which involves screening a promising therapeutic compound from a pool of compounds.

ML can be used for VS with a filtered dataset, employing algorithms such as SVM, RF, and DT [24,25]. After validating the trained model for accuracy, it is used on new data sets to screen for compounds that have the desired activity against a target. The shortlisted compounds undergo ADMET (absorption, distribution, metabolism, excretion and toxicity) analysis and various bioassays before entering clinical trials. ML has the power to speed up VS, make it more robust, and even reduce false positives in VS. PARASHIFT, HEX, USR, and Shape algorithms have been constructed for LBVS. In recent years, with the rise of AI algorithms in the healthcare and pharma industry, different tools and models have been developed for both LBVS and structure-based virtual screening (SBVS), i.e., for LBVS, tools include SwissSimilarity, METADOCK, and HybridSim-virtual screening, while for SBVS, tools include Gypsum-DL, ENRI, and SPOT-ligand 2. Drug repositioning involves investigating drugs developed for one diseased condition and repositioning them for other diseased conditions in drug designing and discovery. This approach may be successful due to the possibility of multiple-target involvement in multiple diseases. The emergence of AI-based tools and algorithms in drug discovery provides a platform for future research, and different AI-based algorithms and web-based tools have been developed in recent years, such as DRIMC, DrugNet, DPDR-CPI, PHARMGKB, PROMISCUOUS 2.0, and DRRS.

This review aims to provide a thorough overview of AI's role in drug discovery (Fig. 2). AI can aid in various stages of drug discovery in various ways, including disease identification, target acquisition, computational screening, predicting drug toxicity, gene editing for developing gene therapies, and AI-based modeling for personalized drug dosing. We examine the current state-of-the-art AI technology and its potential to revolutionize drug discovery.

Artificial intelligence and subtypes. Machine learning can be broadly categorized into supervised, unsupervised, and reinforcement learning, which can be further divided into several subcategories. For supervised learning, these include classification, where algorithms categorize input data into predefined classes, and regression, aimed at predicting continuous outcomes from input features. Additionally, unsupervised techniques such as clustering are used to grouping similar data points. These subcategories are fundamental to the architecture of machine learning algorithms, significantly contributing to diverse applications in drug discovery.

Schematic representation of the integration of artificial intelligence (AI) in the drug discovery process. The diagram illustrates the workflow from data collection, encompassing clinical sequencing, experimental text, and molecular structure analysis, to the implementation of AI algorithms and neural networks. The applications of this process include disease diagnosis, target acquisition, and computational screening. This illustration underscores the transformative potential of AI in advancing medical research and healthcare solutions.

## Section: AI-based disease identification

AI has shown great potential in identification of infectious diseases. By analyzing large amounts of data from various sources such as EHRs (electronic health records), social media, and news reports, AI can quickly detect outbreaks of infectious diseases and provide early warning systems. AI can also assist in predicting the spread of diseases by identifying populations at high risk and tracking the movement of infected individuals. Due to its capacity for swift and precise data processing of enormous amounts of data, AI can significantly improve our ability to identify and respond to infectious diseases.

In recent years, the field of AI has shown remarkable progress in disease diagnosis, revolutionizing the way healthcare is delivered. AI technologies such as ML and DL have enabled medical professionals to develop highly accurate and reliable diagnostic models for various diseases. Early detection, precise diagnosis, and individualized treatment plans have all been made possible by the use of AI in disease diagnosis, which has improved patient outcomes. Infectious and non-communicable disease diagnosis using AI has recently made significant strides.

AI methods have greatly advanced the diagnosis of infectious diseases [26]. An exemplary case is the clinical decision support system (CDSS) known as “Sepsis Watch” to detect Sepsis early [27], a severe medical condition that occurs when an infection in the body triggers a chain reaction, resulting in a life-threatening medical emergency, often originating from infections in the lungs, urinary tract, skin, or gastrointestinal tract [28]. Sepsis Watch utilizes a unique ML method that combines multitask Gaussian processes (MGPs) with recurrent neural networks (RNNs) to identify sepsis [28]. The MGP component of the system learns the distributions of continuous functions for each dynamic variable. The system works by sampling dynamic features from the MGP hourly, which are then combined with static features and input into the RNN, a form of DL particularly adept at processing time-series data and essential for incorporating both static and dynamic features of hospital patient encounters [28]. This process generates a sepsis risk score between 0 and 1 for each patient. Additionally, the system includes scripts optimized to run every 5 min to identify patients who meet the sepsis criteria, facilitating early detection and prompt medical intervention [28]. Sepsis Watch has been trained using 50,000 patient records with both static (eg. prehospital patient comorbidities) and dynamic (eg. medication administrations) input features. It has been shown to improve the care of sepsis patients [28]. However, this study had a few limitations, including some false positive predictions that prompted clinical action even though the patient did not ultimately develop sepsis. Additionally, the study was limited to emergency department cases.

During the COVID-19 pandemic, there was a particular focus on the development of AI models for the effective diagnosis of this disease [29,30]. Chest X-ray is one of the efficient indirect methods for COVID-19 diagnosis. It was used to diagnose pneumonia associated with this viral infection [31]. Many ML models have been developed to predict the presence or absence of patterns in X-ray radiographs. For example, Narin et al. proposed an automated convolutional neural network (CNN) based diagnostic model for detecting pneumonia caused by coronavirus [9]. They developed pre-trained AI models using the X-ray radiographs of healthy individuals, patients with COVID-19, patients with viral pneumonia, and patients with bacterial pneumonia. The reported accuracies in classification reached up to 96%. Aapka Chikitsak is an AI-powered conversational bot designed to enhance telehealth services in India by providing accessible COVID-19 information and addressing the imbalance between the demand for and the supply of human healthcare providers. Initially, the user's query is converted from audio input into text, and the text is used as a basis for performing Natural Language Understanding to decode the semantic meaning. Subsequently, relevant entities are identified and linked to their corresponding intents in Dialogflow. The bot then generates a response, converts it to speech, and delivers it back to the user [32].

ML models have also been built to assist in the diagnosis of other infectious diseases such as urinary tract infections (UTIs), which are often associated with high rates of diagnostic errors. Taylor et al. reported a retrospective cohort analysis of approximately 80,387 adults who visited the emergency department with UTI symptoms [33]. Considering symptoms as well as blood and urine sample analyses, six AI algorithms were developed for the diagnosis of UTI: SVM, artificial neural network (ANN), elastic net, adaptive boosting (AdaBoost), RF, and extreme gradient boosting (XGBoost). The models were built using a full set of 211 factors and a reduced set of 10 variables, e.g., gender, epithelial cells in the urine, history of UTI, and age. The XGBoost showed superior accuracy over the other algorithms, with an area under the curve (AUC) of 0.88 and 0.90 for the full and reduced XGBoost models, respectively. The sensitivity and specificity were 61.70% and 94.90% for the full, and 54.70% and 94.70% for the reduced models, respectively [33]. Lifestyle disorders, such as diabetes, obesity, and hypertension, are associated with the way people live, their diet, exercise levels, etc.

ML models have achieved substantial success in the prevention and detection of HIV, a virus causing human progressive immune system failure and promoting cancers. Xiang et al. developed an ensemble approach combining GCN (graph convolutional network) with LR and RF, aiming to identify individuals at high risk of HIV infection for prevention [34]. They built a social network in which each node stood for an individual participant, and the edges between them represented social connections. Each node was assigned with a feature set, including sociodemographic characteristics and sexual behavioral characteristics. The ensemble methods produced promising results on HIV infection detection (GCN+LR with accuracy of 93.4% and F1 of 88.4%; GCN+RF with accuracy of 96.6% and F1 of 94.6%). Heerden et al. created a conversational agent guiding users through an HIV counseling and testing session utilizing NLP (nature language process). This agent encourages the targeted population to openly discuss their concerns with a virtual assistant, and its effectiveness has been confirmed through human evaluation [35]. Compared with previous agents, this agent made testers feel like the session was more private and anonymous with more gentle language and more accurate detection.

Many AI-based algorithms have been developed for the early prediction and management of diabetes. For instance, Spänig et al. developed an interactive AI model with the capability of speech recognition and speech synthesis that acts as a virtual doctor, interacts directly with patients. An open-source system CMUSphinx is utilized to develop robust speech recognition capabilities. To support localized speech recognition, the essential German language data is obtained, including a German language model, an acoustic model, and a dictionary from the VoxForge dataset [36], which aggregates transcribed speech specifically for use in speech recognition technologies. This virtual doctor predicts Type-2 diabetes mellitus with an AUC of 0.84 [37]. The incidence of retinopathy is high among diabetic patients. Gulshan et al. developed a deep CNN model that bypasses the human capacity at interpreting, evaluating, and classifying retinal images. The model is trained using 128,175 retinal photographs which are evaluated by a panel of clinicians and ophthalmologists. The model is demonstrated to have a high sensitivity and specificity of 97.50% and 93.40%, respectively [38]. In 2018, the U.S. Food and Drug Administration approved the marketing of the first AI-based medical device called IDx-DR [39] for detecting diabetic retinopathy. The device has a retinal camera through which the retinal image of the patient is taken and analyzed. The device is autonomous and decides on one of the following results based on the image quality (i) “more than mild diabetic retinopathy detected: refer to an eye care professional” or (ii) “negative for more than mild diabetic retinopathy; rescreen in 12 months” [39].

Alzheimer's disease is a neurodegenerative disorder in the brain. Genetic factors and age are major risk factors associated with AD. However, recent research indicates that other factors, such as environmental and lifestyle factors, can also contribute to the development of AD [40]. AI-based algorithms have shown promising results in the early prediction and diagnosis of AD [41]. For instance, Jo et al. proposed a hybrid model that combines DL -based feature extraction with ML algorithms for AD diagnosis using magnetic resonance imaging (MRI) scans [42]. The proposed model achieved a classification accuracy of 96%. Similarly, Shi et al. developed an AI-based model for the early prediction of AD using positron emission tomography (PET) images [43]. The model achieved an accuracy of 89.5% in predicting the onset of AD within two years. Cancer is another NCD that has benefited from the recent advancements in AI-based algorithms. AI-based algorithms have been developed for various cancer-related tasks, such as diagnosis, prognosis, and treatment planning. For example, Ding et al. developed a DL algorithm that interprets PET of the brain for the early prediction of AD. Their model showed a specificity and sensitivity of 82% and 100%, respectively. This model can predict AD, on average, 75.8 months before its diagnosis, with a ROC (receiver operating characteristic) of 0.98 [8]. Li et al. developed a DL-based model that automatically evaluates dementia severity by analyzing resting-state functional magnetic resonance imaging data (rs-fMRI). The study involved 133 patients with Alzheimer's disease, and their clinical dementia rating (CDR) scores ranged from 0.5 to 3. To extract features, three-dimensional CNNs were applied to rs-fMRI data. The accuracy of the model was found to be highly satisfactory [44]. In addition, AI-based algorithms have also shown promising results in predicting the response to treatment in cancer patients. For example, AI has the potential to improve the speed of analysis and the accuracy of image interpretations. Esteva and co-workers developed a CNN model trained with images of skin lesions to classify different types of skin cancer [45]. Albayrak et al. used deep learning to extract features from breast histopathological images to detect mitosis. The proposed model extracted CNN features for SVM training and detected breast mitosis [46]. Causey et al. developed CNN model-based algorithm, NoduleX to predict malignant lung nodules from clinical CT data. The model was trained using over 1000 lung nodule images from LIDC and IDRI. NoduleX predicted with a 0.99 AUC [47]. Shiri et al. tested ML methods using Radiomics analysis for predicting EGFR and KRAS mutation status in NSCLC (non-small cell lung cancer) patients that showed AUCs of 0.82 and 0.83, respectively [48]. CNN models also power histological image analysis to diagnose cancer [[49], [50], [51]].

AI algorithms have demonstrated promising outcomes in the diagnosis, prediction, and management of non-communicable diseases including diabetes, Alzheimer's disease, and cancer. The implementation of AI-based algorithms can facilitate the early detection of these diseases, thus enabling timely interventions and personalized treatment plans, ultimately leading to improved patient outcomes. By leveraging the power of AI, healthcare professionals can potentially reduce the burden of NCDs, enhance the quality of healthcare delivery, and optimize healthcare resources. The detailed overview of role of AI in disease identification can be seen in Fig. 3.

The overview of AI-based disease identification. AI-based disease identification can be divided into four categories: neurodegenerative disorders diagnosis, cancer diagnosis, infectious disease diagnosis and lifestyle disorders diagnosis.

## Section: Target identification

Target identification is a critical step in the drug discovery process. The traditional approach involves time-consuming and costly experimental methods, such as high-throughput screening (HTS) and X-ray crystallography. However, the use of AI has revolutionized this field by enabling the identification of potential targets through computational methods. Fig. 4 illustrates how AI-aided role in drug discovery.

AI-based target identification involves the use of ML algorithms to analyze large datasets and identify targets with the potential to interact with a given drug. This approach utilizes various data sources, such as gene expression profiles, protein-protein interaction networks, and biological pathways, to generate a list of candidate targets [52]. ML algorithms, such as SVMs and neural networks, can then be used to prioritize these targets based on their relevance to the disease of interest.

Furthermore, AI-based target identification can help identify novel targets that were previously unknown or overlooked. By analyzing large datasets from various sources, ML algorithms can uncover hidden patterns and relationships that may not be immediately apparent using traditional methods. This can lead to the discovery of new biological pathways and targets that may have therapeutic potential. AI-based target identification has the potential to revolutionize the drug discovery process by enabling the identification of potential targets through computational methods. There are multiple experimental methods available for identifying drug targets, such as affinity pull-downs and genome-wide knockdown screens. However, these approaches require a significant amount of labor, resources, and time, and are also subject to a high rate of failure. In contrast, computational methods have the potential to significantly decrease the effort and resources required for drug target identification [53].

Cryo-EM, or electron cryo-microscopy, revolutionized the investigation of proteins and protein complexes in the 1980s. Single-particle analysis (SPA), electron cryo-tomography (cryo-ET), microcrystal electron diffraction (MicroED), low-energy electron holography (LEEH), and cryo-scanning transmission electron tomography (CSTET) are a few examples of cryo-EM imaging techniques [54,55]. For a deeper understanding of the structures of protein complexes in their environment, cryo-electron tomography (cryo-ET) has shown great promise. Computer algorithms are used to combine these images to create a 3D structure representation.

The software CryoDRGN, created by Zhong et al. [56], uses ML to enable the reconstruction of proteins and protein complexes from heterogeneous cryo-electron microscopy data [56]. In order to embed heterogeneous single-particle cryo-EM images in a low-dimensional latent space and produce 3D volumes as a function of this embedding, the authors have proposed a technique that makes use of ML models. CryoDRGN can produce an infinite number of maps from the imaged ensemble and is capable of modeling complex ensembles with both continuous and discrete heterogeneity. The software can also visualize the motion of the protein [57].

Trypsin is one of the most important and widely used proteolytic enzymes in mass spectrometry (MS)-based proteomic research. The digestion of proteins by protease enzyme is a basic step in the protein identification using MS. A few AI tools were developed to efficiently predict the digestion behavior of the protease enzymes [58,59]. DeepDigest is the first algorithm developed using a DL method to predict the proteolytic cleavage sites of eight different protease enzymes (trypsin, ArgC, chymotrypsin, GluC, LysC, AspN, LysN, and LysargiNase). The DL model was trained on 19 public large-scale data sets covering the eight proteases from samples of four organisms (E. coli, yeast, mouse, and human). The predictive ability of the tool was evaluated by the AUC, F1 scores, and the Matthews correlation coefficients (MCCs); the values were 0.956–0.98, 0.66–0.90, and 0.65–0.84, respectively [58]. Sun et al. developed an algorithm to predict the missed cleavage site in the tryptic protein digestion [59]. The algorithm is demonstrated to have a high accuracy, with an AUC of 0.99. This algorithm can be incorporated into the peptide database search in the MS analysis to facilitate the identification of proteins more effectively and efficiently.

The development of computational tools, high-performance computers, and ML algorithms is not limited to three dimensional (3D) models of protein targets but also enabled a large number of drug discovery tools. This is a significant advancement in experimental techniques that are fraught with challenges. For example, the X-ray diffraction technique is limited to crystallizable samples, which is a major experimental limitation [60].

In the absence of experimental data, computational techniques have been used for decades to forecast the three-dimensional structure of proteins. Modeller, a homology modeling software, predicts a protein's structure based on its alignment to one or more proteins of known structure (templates) [61]. AlphaFold, the DL algorithm developed by DeepMind, a UK based company, predict the 3D structure of proteins from their amino acid sequences [62]. The development of this AI- tool is claimed to be a breakthrough in drug discovery as it was used to solve the structure of nearly 200 million proteins, which is ∼98.5% of the proteins in the human body. In July 2021, the predicted three-dimensional models for the whole human proteome generated using AlphaFold, were made available to the public, as recently reported in Nature [63]. Together with the European Bioinformatics Institute (EMBL-EBI), a database called AlphaFold DB (https://alphafold.ebi.ac.uk/) was created to store all the structures solved so far with AlphaFold. However, the effect of mutation on the folding of proteins is beyond the capability of AlphaFold [64]. It is also limited to predicting only a single state of a given protein, it does not consider the dynamic nature of protein structures [65]. Recently, new methods based on natural language processing (NLP) which only uses the amino acid sequences from sequence databases to learn structural, functional and evolutionary patterns and predict structural conformation. In 2022, two methods gained attention i.e. ESMFold and EMBER3D. ESMfold, developed by Lin et al. in 2022, utilizes a masked transformer protein language model with a deep understanding of biological properties, trained with 15 billion parameters. While it falls short of AlphaFold2 in overall performance, as indicated by lower TM-scores (0.68 compared to AlphaFold2′s 0.85 on CASP14), ESMFold outperforms AlphaFold2 when evaluating the amino acid sequence alone without multiple sequence alignment (MSA) (0.68 versus 0.37 on CASP14). ESMFold demonstrates comparable accuracy to AlphaFold2 for structures predicted with high confidence, exhibiting a median all-atom RMSD (root-mean-square deviation) of 1.91Å and a backbone RMSD of 1.33Å—achieving accuracy levels akin to experimental results. Additionally, ESMFold shows a substantial improvement in prediction speed, eliminating the need for MSA construction. The authors leverage this approach to introduce the ESM Metagenomic Atlas, predicting over 617 million structures from metagenomic databases. Among these, 225 million structures are predicted with high confidence, including novel ones [63]. While Ember3D falls short of surpassing AlphaFold in performance, it exhibits significantly faster processing speeds compared to both AlphaFold and ESMFold. Notably, AlphaFold2 struggles to efficiently investigate the impact of single amino acid variants on protein structure. In contrast, Weissenow et al. [64] demonstrated that Ember3D's predicted distance maps show a strong correlation with native and mutant 3D structures obtained through deep mutational scanning, outperforming ESMFold in this regard. The researchers also developed a tool that highlights differences between native and mutant predicted structures for all possible amino acid exchanges at each position in a protein sequence. The tool utilizes the similarity between the native and mutated amino acids to identify exchanges that may have a significant impact on the protein structure [64]. Cheng et al. introduced AlphaMissense, a DL model that extends the capabilities of the AlphaFold2 protein structure prediction tool. This model undergoes training with population frequency data and incorporates both sequence information and predicted structural context to enhance its overall performance. AlphaMissense effectively categorizes 32% of all missense variants as likely pathogenic and identifies 57% as likely benign, achieving a 90% precision cutoff on the ClinVar dataset. This outcome ensures a robust prediction for the majority of human missense variants [65]. A specific and detailed review [66] on all the recent advances in protein structure prediction are reviewed by Peng et al. Some breakthrough protein structure prediction models are tabulated in Table 1.

In addition, AI algorithms can predict the likelihood of allosteric regulation in a protein based on its structure and ligand presence, and identify allosteric modulators that may modify its activity [66]. ML methods, like Allosite; developed by our group [67], and AlloPred [68], used SVM with optimized features for protein pocket classification [69], while others used RF [70] to build a three-way predictive model. Advanced ML models, such as XGBoost [71], can now classify allosteric sites with greater accuracy. XGBoost implements the gradient boosting algorithm with regularized terms to reduce overfitting and has demonstrated superior predictive performance in protein-protein interactions [72] and hot spots [73] compared to SVM and RF.

Tian et al. developed a webserver called PASSer (Prediction of Allosteric Sites Server), combining the results of XGBoost and GCN to predict the allosteric sites on proteins using an ensemble learning method. A total of 1946 entries information of allosteric sites from Allosteric Database were collected for training with 19 descriptors extracted for each site by Fpocket. For a given pocket, physical properties are calculated and fed into the XGBoost model while an atomic graph is fed into the GCNN model. The final result is the averaged probability of these two models. The model showed an accuracy of 0.97, precision of 0.73, and specificity of 0.98. The aforementioned model can acquire knowledge about both the physical traits and topology of allosteric pockets and has been demonstrated to outperform the XGBoost and GCN models individually. The findings are consistent with earlier research and have a greater likelihood of placing allosteric sites in top positions. The online server is equipped with an easily navigable interface. Protein structures and top pockets are displayed in an interactive window on the result page [66].

Protein structural fluctuations generate novel cryptic pockets [[74], [75], [76], [77]], which offer druggable sites beyond experimentally determined structures. Cryptic pockets regulate protein functions allosterically. These pockets are hidden protein cavities that open up when ligands or protein partners bind [78]. Targeting these cryptic pockets offers drug development opportunities. Cryptic pockets can target undruggable proteins [79]. An algorithm to predict which proteins have cryptic pockets could help prioritize proteins to target in cases where proteins lack ground state pockets or modulators are difficult to design. CryptoSite is an excellent supervised ML algorithm that predicts ligand-binding cryptic pockets from protein structures [80]. CryptoSite accurately predicts cryptic pocket participation for amino acid residues (ROC-AUC = 0.83). Miller et al. developed PocketMiner, a graph neural network (GNN), to predict cryptic pockets in protein structures. The model is trained using residues likely to form cryptic pockets from 2400 simulations of 35 proteins. Model AUC was 0.87. This supports molecular dynamics simulations for cryptic pocket identification [78].

Madhukar et al. developed BANDIT, a Bayesian ML platform for drug target prediction that integrates multiple data types to achieve greater predictive power. BANDIT utilizes over 20 million data points from six distinct data types, including drug efficacies, post-treatment responses, bioassay results [81,82], and known targets [83,84]. The platform achieves high accuracy at identifying shared target interactions and uncovers novel targets for cancer treatment. BANDIT was tested on ∼2000 compounds and can quickly pinpoint potential therapeutics with novel mechanisms of action to accelerate drug development.

In 2021, Kozlovskii and Popov developed a DL approach to predict the binding site for small molecules on nucleic acids, DNA, and RNA, based on their 3D structures [85]. Their approach is called BiteNetN (https://sites.skoltech.ru/imolecule/tools/bitenet/) having a large dataset of 1933 nucleic acid-ligand complexes, including 1065 DNA and 886 RNA structures (18 structures contain both DNA and RNA) of different type. It was the first 3D CNN to learn features directly from nucleic acid structures. They validated the model using two different protein structures, HIV-1 transactivation response element RNA and ATP-aptamer structures. The model showed an AUCROC of ca. 0.87, proved to be top-performing for protein-small molecule and protein-peptide binding site detection [86,87].

DeepDTnet is a network-based DL method developed by Zeng et al. to aid the target identification process [88]. The model is trained with chemical, genomic, and cellular network data for the accurate prediction of molecular targets. The model is shown to have a high accuracy in prediction with an AUC of 0.96 [88]. In another study, Mamoshina et al. developed ML techniques to analyze human muscle transcriptomic data to discover biomarkers associated with muscle-related diseases and to identify tissue-specific drug targets [89]. The authors collected transcriptomic data from human muscle tissues and used a combination of unsupervised and supervised ML algorithms to identify differentially expressed genes and gene modules that are associated with muscular dystrophy and sarcopenia. They further investigated the identified gene modules and pathways using functional annotation and network analysis tools to identify potential drug targets. Their best model showed a Pearson correlation of 0.80.

After identifying the protein targets, corresponding novel lead compounds can be further generated from scratch, leveraging the pocket features and ligand topology. Zhang et al. developed a pocket-aware ligand generator ResGen. A two-level autoregression protocol for molecular generation is introduced in the model to better incorporate the geometry of protein pockets. The global autoregression is to generate atoms in pockets, and the atomic autoregression is to produce the coordinates and topology of the newly added atoms. ResGen could generate more physically sensible molecules with tighter binding [90]. Wei et al. developed a fragment-based generation model Lingo3DMol built on the transformer-based structure [91]. A new molecule representation FSMILES is introduced, enabling the generation of 3D molecules with reasonable conformations and topology. Additionally, non-covalent interactions and ligand–protein binding patterns are also considered during the generation. Lingo3DMol demonstrates excellent performance in terms of drug likeness, synthetic accessibility, pocket binding mode and molecule generation speed.

The overview of the AI-based process for identifying and evaluating small molecules. Beginning with target acquisition, where protein sequences are modeled using tools like Modeller and AlphaFold2, followed by Homology Modeling and validation of protein 3D structure through ProQ and SolvX. Next is the pocket exploration, including the identification of both orthosteric and allosteric binding sites within the protein proteome, via static and dynamic structures. The hit identification stage employs SBVS and LBVS to pinpoint potential compounds. Finally, the toxicity prediction stage uses pattern recognition techniques in AI/ML to predict the ADMET properties.

List of the methods for protein structure prediction with their standlone availability links.

## Section: AI-enabled virtual screening in drug discovery: opportunities and challenges

The initial phase of drug discovery usually involves computational screening of numerous compounds to identify those with the desired cellular or biochemical effects. To enhance the speed, efficiency, and cost-effectiveness of this process, new methods are constantly being developed. A positive response during the first round of screening in a biochemical assay identifies primary “hit” compounds. Subsequently, additional screening is performed to assess whether the physicochemical and pharmacological properties of the hit compounds are suitable for developing a medicine. If they pass this filter, they are designated as “leads”. These leads are then refined chemically and subjected to biological screening in subsequent rounds before proceeding to clinical testing. With some luck, a lead may ultimately receive drug approval, a process that may take 12–15 years from the beginning of testing [92].

Despite significant advancements in drug discovery and medicinal chemistry technologies, drug development still remains a slow and expensive process. The current standard process involves HTS, where in vitro assays are conducted on thousands of compounds to identify hit compounds that can be optimized to lead compounds with desirable properties such as increased potency, solubility, and reduced toxicity and off-target effects [93].

The conventional drug discovery process involves synthesizing and testing thousands of compounds, which is both time-consuming and costly, requiring large amounts of protein supplies and established laboratory methods for bioactivity testing. In contrast, VS has emerged as a cost-effective approach to scan millions of commercially available compounds and prioritize those for further testing, synthesis, or purchase. VS methods are classified into two categories: structure-based and ligand-based methods. However, despite the potential benefits, it still takes an average of 10 to 15 years and over $2 billion to develop a single drug [94].

## Section: AI-enabled virtual screening in drug discovery: opportunities and challenges › Structure-based methods

To utilize structure-based methods, 3D structural information of the protein-ligand complex or at least the protein's binding site is needed. Molecular docking is a commonly used technique that generates multiple possible binding poses of a ligand in the target protein structure and ranks them using a scoring function (SF) [95] to estimate their binding affinity [96]. Recently, machine/DL-based SFs [21] have been introduced as a new group of SFs. On the other hand, ligand-based methods such as QSAR modeling, molecular similarity search, and ligand-based pharmacophores, are more established technologies that require only ligand information [97], unlike structure-based methods. AI techniques can also be employed to improve the efficiency of computer-aided drug discovery processes, which often need extensive high-performance computing resources and significant computation time.

Gentile et al. reported an open-source protocol for AI-enabled VS methods to screen libraries with billions of molecules. They used a screening platform called Deep Docking (https://github.com/jamesgleave/DD_protocol) which can accelerate the SBVS by 100 folds. The input data consists of the molecule's SMILES with its Morgan fingerprints as descriptors and the target's structure. Deep Docking performs molecular docking for a small subset of a large library based on DNN to infer the ranking of the yet-unprocessed remainder, followed by ligand-based prediction of the docking for the rest of the library. In this way, Deep Docking discards undockable molecular structures without wasting computational resources. A key advantage of this protocol is that it can be used in conjunction with other docking programs such as Glide, Autodock-GPU, and FRED from OpenEye. Although, the deep docking method provides faster screening, it is limited to I) the availability of graphical processing units (GPU) and ii) the quality and accuracy of the docking program used [10].

Various ML techniques, including Naïve Bayesian (NB) classifiers, kNNs, SVMs, RFs, and ANNs, can be used for VS. While SVMs and ANNs are commonly regarded as the most accurate, each technique has its own strengths and weaknesses. For instance, NB excels at identifying favorable scaffold fragments, RFs can be parallelized and boosted, and kNN is simple to implement and can utilize MTL. Combining an ensemble of ML models is often preferred as it can enhance performance [98].

For LBVS, NB classifiers are widely utilized and exhibit excellent performance. Wang et al. investigated four classification models to identify inhibitors of methicillin-resistant Staphylococcus aureus. These models include NB, SVM, recursive partitioning (RP), and kNN algorithms, incorporating various sets of physicochemical descriptors and fingerprints. Among these models, the NB classifier displayed the highest performance in the testing set of, achieving an accuracy of 0.891 and a specificity of 0.920 [99]. Likewise, Lian et al. [100] showed that NB models outperformed SVM models with an accuracy of 0.975 and a specificity of 0.989 in classifying the inhibitors and non-inhibitors of neuraminidase. They further identified nine effective inhibitors of neuraminidase using an enhanced ensemble model comprising NB models and SVMs.

Another simple ML classification method is kNN. Unlike NB, kNN is intuitive. In searching for G-Protein Coupled Receptor ligands, Luo et al. found that kNN-QSAR with variable selection outperformed LBVS approaches without ML [101]. Compared to other ML methods, kNN's performance is usually in the middle [99,102]. kNN is less popular than the ML methods below because of this. In screening for Estrogen Receptor-mediated endocrine disruptors, kNN has been used for VS [103].

Vapnik et al., introduced SVMs for the first time [104]. They function by representing input data as feature vectors and plotting them within the same-dimensional space. Although SVM can be used for unsupervised learning, supervised learning is preferred for VS because it guarantees that a compound will eventually be categorized as active or inactive. Chandra and colleagues conducted a study to identify potential inhibitors for PTP1B, a treatment for Type 2 diabetes [105]. Multiple ML models were developed, and the best model that utilized SVM was applied to an external database. This model successfully identified five inhibitory compounds, two of which demonstrated significant activity in vitro. In a separate study, Deshmukh et al., [106] discovered that their SVM model was able to identify almost half of the known FEN1 inhibitors in a test set, and also identified previously unknown inhibitors from the Maybridge small molecule database, which were experimentally validated. Baba et al. found that SVM models with regression were more effective than RF in predicting a compound's ability to permeate the skin[107]. Lee et al., [108] employed RF-QSAR to study compound polypharmacology, resulting in the creation of a targetfishing server that identifies possible targets for a given compound. Their method achieved an overall AUC score of 0.97 and outperformed NB-based methods in external testing [109].

## Section: AI-enabled virtual screening in drug discovery: opportunities and challenges › Ligand-based virtual screening (LBVS)

LBVS is based on selecting, from databases, molecules that share similar structural features with an active ligand. Pharmacophore-based VS is one of the LBVS techniques. It involves building 2D fingerprints of one or more active ligands using molecular descriptors such as hydrogen-bond donors, hydrogen-bond acceptors, and aromatic rings. These 2D fingerprints are then used to identify molecules, from large chemical libraries, which have matching pharmacophoric features. ML also helps to study the correlation between molecular descriptors (or even atomic descriptors [110,111] and the biological activity of a ligand. This is a broad category of research known as Quantitative Structure-Activity Relationship (QSAR), where the activity of a ligand depends on its pharmacophoric features. Melge et al. developed hybrid inhibitors using the pharmacophore fingerprint of two well-known anti-cancer drugs Ponatinib and Vorinostat [112]. They developed a supervised ML approach for 2D-QSAR and 3D-pharmacophore studies to predict the inhibitory activity of novel hybrid molecules. The model had AUC values of 0.98 and 0.94 for the two different cancer targets, BCR-ABL and Histone deacetylase (HDAC), respectively. Based on in-vitro evaluations, the identified novel hybrid molecules showed the potential to develop into lead compounds. Dhamodharan et al. developed three AI models based on genetic function approximation (GFA), SVM, and ANN, to predict the activity of acetylcholinesterase (AChE) and Beta-Secretase 1 (BACE1) dual inhibitors for AD treatment [113]. The predictive power of the models was evaluated on a test set of 11 inhibitors of AChE and BACE1. The ANN model had the best predictive power with R2 (coefficient of determination, a statistical measure within regression analysis) values of 0.85 and 0.78 for AChE and BACE1, respectively. Dhamodharan et al., [113] used a target-specific scoring model to identify potential inhibitors for 12 targets from the SAM MTase family. 446 actives and 1294 decoys were docked using Glide and the DUD-E website. The MLP outperformed other docking tools in a binary classification experiment.

Atomwise, Inc. developed AtomNet, one of the earliest CNNs utilized for VS [113]. Unlike most ML-based VS, AtomNet employs an SBVS and its architecture includes input and logistic-cost layers, four convolutional layers, and two fully connected layers. The filters in AtomNet's convolutional layers correspond to chemical functions, allowing the network to identify features that aid in binding. AtomNet consistently achieves AUC scores >0.74 on various benchmark datasets, outperforming numerous previous docking models. These features and capabilities, previously exclusive to NB and RF classifiers, now enable ANNs to identify features that aid in binding, making them more accurate and less of a black box in VS.

Alzheimer's disease is characterized by amyloid-beta (A) plaques and neurofibrillary tangles (NFT) of hyperphosphorylated tau protein. Acetylcholine (ACh) levels are lower in AD brains [[114], [115], [116]]. Tau may be phosphorylated by GSK-3, CDK5, and other Alzheimer's disease-related enzymes and targets [[117], [118], [119]]. Side effects from polypharmacy are possible. Drugs that target one protein frequently have side effects on other proteins as well. Through the inhibition of multiple targets in complex diseases like Alzheimer's, polypharmacology can increase a drug's effectiveness. With this technique, MTDL (Multi-Target Directed Ligands) screening was increased [43]. Using NB and RP classifiers in an LBVS on MTDLs, Fang et al. discovered compounds that bound to 25 targets, including BACE1, the M1 subtype of mAChR, APP, CDK5, and GSK-3 [120]. The model was validated using current AD medications, and it was used to forecast upcoming MTDLs. As scientists become more aware of its effectiveness, ML in VS for drug discovery will expand. The effectiveness and cost of drug discovery will be enhanced by computer science and medicinal chemistry.

ML-based screens are computationally efficient and successful in modern CADD, which requires vast computational resources to screen expanding chemical libraries due to automated synthesis and robotics. OpenEye GigaDocking and VirtualFlow are supercomputing platforms for docking large libraries that have screened billions of molecules using thousands of CPUs/GPUs in relatively short periods [121]. However, they are resource-intensive compared to Deep Docking (DD) [122]. DD requires fewer computational resources, making it an attractive alternative for large-scale VS.

Gentile et al. developed an open-source protocol for AI-enabled VS of billion-molecule libraries. Deep Docking (https://github.com/jamesgleave/DD_protocol), a screening platform that accelerates SBVS by 100-fold, was used. One of the fastest AI-enabled docking platforms and the only one tested on 1B+ libraries is DD. The DD protocol does not require a docking program, so it can be used with emerging large-scale docking methods to improve throughput. technical limitation of Deep Docking is GPU acceleration, which is needed for optimal performance unlike CPU-based docking platforms. The protocol only provides docking details for top-scoring molecules, ignoring large fractions of chemical libraries for fast VS. Docking campaigns assessing hit rate variability with docking scores [123] or rescoring low-ranked molecules [124] should consider a bruteforce approach. A docking program's ability to prioritize active molecules from an ultra-large library also determines the quality of DD results [123]. Bender et al.'s guidelines for large-scale docking benchmarking are helpful [122].

A wave of DL methods and applications has improved affinity—and other properties like ADMETox—prediction in VS over the last decade(s). Models learn characteristics rather than using human-designed descriptors. Novel encodings like voxels (where physicochemical atomic properties are pinned to locations in 3D space) and graphs (which describe bonded and non-bonded connectivity between atoms) appear to capture the variety of information needed for ligand-binding. DeepAtom [125], a 3D grid-based method that assigns physicochemical properties to each grid cell, may be suitable for modeling protein-ligand binding complexity. The study [126] and DGraphDTA model [127] show that encoding chemical and biological objects as graphs works well. Despite this, several challenges remain, and new ones have emerged, including chemical encoding precision, generalization of chemical space, lack of (large and high-quality) data, model comparability, and interpretability.

Finding new therapeutic uses for already-approved drugs is a crucial aspect of drug repurposing. Due to their previously tested pharmacokinetics and toxicity, repurposed medications have a higher success rate [128,129]. Drug repurposing skips lead optimization and pre-clinical studies to enter phase-II trials. Due to complex disease pathophysiology, many drugs have off-target binding and are excluded from pre-clinical trials [130]. Reker and colleagues developed a method to predict molecular targets of known drugs and computer-generated de novo small molecules, including key-target and off-target proteins. Self-organizing map-based prediction of drug equivalence relationships (SPiDER) is this method. The software was trained on 12,661 manually curated active molecules [131]. The ROC ranged from 0.86 to 0.93 in a 10-fold cross-validation of SPiDER's predictive ability.

## Section: Prediction of drug toxicity with AI

Proportion of drug candidates being discarded during clinical trials due to unexpected adverse effects. Predicting drug toxicity during preclinical stages is a crucial step to reduce the failure rate and improve the efficiency of drug discovery. Traditional methods of predicting drug toxicity are limited by their reliance on small datasets and simplistic models. However, AI-based approaches have emerged as promising alternatives, leveraging large and diverse data sources, including chemical structures, biological pathways, and clinical data. By utilizing ML algorithms, AI-based approaches can improve the accuracy and efficiency of predicting the potentially toxic effects of new compounds, helping to mitigate risks associated with clinical trials, reduce drug development costs, and ultimately lead to better patient outcomes.

Recently, the use of AI-based computational models to forecast drug toxicity has grown in popularity [132]. Large drug and toxicity data sets have been analyzed in a number of studies using ML and DL algorithms, such as neural networks, to identify potential toxic effects during drug development. By identifying toxicities early on, these models can speed up the development of new drugs. Additionally, AI-based toxicity prediction models can prioritize compounds for testing and find new drug targets and toxicity mechanisms. AI toxicity prediction has been the subject of several reviews [[132], [133], [134], [135], [136], [137]]. A single review is challenging due to the wide field of AI-based toxicity prediction's numerous toxicity properties. Recent AI-based toxicity prediction models and in-depth studies of toxicity properties are required to develop, optimize, and improve a model. For four important toxicity properties, recent ML and DL-based AI-based drug toxicity prediction methods are presented.

## Section: Prediction of drug toxicity with AI › Cardiac side effect prediction

ML-based methods, including RF, SVM, NB, SVR, kNN, DT, GB (gradient boosting), PLS (partial least squares), and XGB, are commonly used in predicting hERG toxicity (a gene related to a potassium channel in the heart, and is used to evaluate cardiac side).

Venkatraman developed an ADMET prediction model using ECFP6-based RF models [138]. A total of 7889 compounds were assembled from 4 well-defined experimental assays with experimental hERG blocking bioactivities for training, where compounds with experimental values less than or equal to 10 μM were regarded as positive samples (4355 in total) and the others as negative samples (3534 in total). RF builds multiple DT on the data and merges them together to get hERG toxicity. This model achieved an 80% accuracy and 88% ROC-AUC.

Hsiao et al. [139] and Arab et al. [140] also used the RF model with high accuracy. Ogura et al. developed an SVM model using ECFP_4 structural fingerprints and 72 NSGA-II-selected descriptors, outperforming other predictors with 98.4% accuracy and 0.733 kappa statistic [141]. Konda et al. [142] generated hERG classification models with 2D descriptors using RF, SMO (sequential minimal optimization), and MLP (multilayer perceptron) algorithms, with their consensus model outperforming other predictors with 92% accuracy. DNN, ANN, RNN, CNN, GNN, GCNN, and GAT are used in developing hERG predictive models. Shan et al., [143] generated a directed message-passing neural network (DMPNN) model with moe206 descriptors that outperformed other models with an accuracy of 80% [143]. Zhang et al., [144] developed HergSPred, which outperformed other models, achieving an accuracy of 98.3%. Ryu et al. [145] developed DeepHit, which outperformed other tools in terms of accuracy, MCC, and SE (sensitivity). Wei et al. created Interpretable-ADMET, achieving the highest accuracy (91.9%) and ROC-AUC (78.2%) on 8672 compounds. ADMETLab 2.0 achieved the highest accuracy and ROC-AUC of 88.9% and 94.3%, respectively, on a large hERG data set containing 13,845 compounds, utilizing a multitask graph attention framework (MGAF) to predict ADMET properties.

## Section: Prediction of drug toxicity with AI › LD50 prediction

In Toxicologists use the LD50 (median lethal dose) to determine a substance's toxicity. The dose needed to kill 50% of test animals in a particular period of time is referred to as the LD50 value of a chemical. The LD [146] is used as the first step in the drug screening process. Rats' acute oral toxicity was evaluated using LD50. Interspecies variability and ethical issues render conventional LD50 testing obsolete [147]. Acute animal toxicity tests using tissue culture and in silico LD50 prediction are gradually being replaced [148]. The binary classification model divides substances into two categories: toxic (LD50 = 2000 mg/kg) and nontoxic (LD50 = 50 mg/kg).

Compounds are divided into multiple classes by the Globally Harmonized System of Classification and Labeling of Chemicals and the US Environmental Protection Agency [149]. Recent releases of the ADMET prediction programs FP-ADMET [138] and Interpretable-ADMET [150], in these both applications, LD50 prediction models are applied.

Ballabio et al. developed LD50 prediction models using the binary fingerprints of NB, N—Nearest Neighbors, Binned-Neighbors, and Extended Connectivity [151]. They found that their models were 84% sensitive and 81% specific for 8992 chemicals. An integrated QSAR model for 8448 compounds was created by Gadaleta et al., [152], by combining balanced RF, regression, aiQSAR, istkNN, SARpy, RF with hyperparameter tuning, and a general linear model [153]. The ideal model's RMSE (root-mean-squared error) was 0.477%, and its accuracy balance was above 70% for multiclass endpoints and 80% for binary endpoints.

Jain et al. [154] created a multitasking DL consensus model using RF, DNN, CNN, and GCNN on a dataset of 80,081 compounds that outperformed other models with RMSE of 0.65 and R2 of 0.5. Using the same dataset of 7413 compounds, BTAMDL predicted LD50 with a higher degree of accuracy than MolGIN (RMSE = 0.557, R2 = 0.662). Using the 7413-compound TopTox data set from the ECOTOX aquatic toxicity database, Karim et al., [155] proposed QuantitativeTox, a DL framework utilizing FFNN, CNN, GCNN, and baseline feature representations. This model outperformed others (R2 = 0.687), and it was adopted.

## Section: Prediction of drug toxicity with AI › Drug induced liver injury (DILI) prediction

Drug or chemical toxicity causes DILI [156]. It causes 32% of drug recalls, which worries researchers and doctors [157]. Predicting human DILI with in vitro or animal studies is difficult. RF, kNN, SVM, deep neural network (DNN), CNN, and GNN can predict compound properties from chemical structure. Recent reviews have examined AI methods for DILI in silico prediction [[158], [159], [160]].

Recent ML techniques, such as RF, LR, NB, SVM, kNN, AB, GDBT (gradient boosting decision trees), and ET (equivariant transformer) [138,[161], [162], [163], [164], [165]], have been applied to the development of accurate DILI prediction models. Mora et al. created an ensemble model based on QuBiLS-MAS Features and Shallow Learning using k-NN, MLP, RF, NB, SVM, LR (logistic regression), classification tree, Fisher's linear discriminant analysis (FLDA) [164], and Bayes network algorithms, which achieved an 84% accuracy rate over 10-fold cross-validation using a training set of 1075 compounds from a previous study [166]. Using a dataset of 2608 chemicals and SVM and hybrid quantum particle swarm optimization algorithms, Wang and Chen constructed five consensus models with an 80% accuracy rate [165].

ADMETLab 2.0 [167], FP-ADMET [138] and InterpretableADMET [150], are ADMET prediction software with over 79% accurate DILI prediction models. DL improves the accuracy of DILI prediction. Li et al.'s [168] DeepDILI model outperformed five ML algorithms and two advanced ensemble methods. Using Transcriptional Response Data and GNN, Hwang et al. [169] developed GLIT, a DILI prediction model that outperformed baseline models with 77.3% accuracy. With a multiview GNN approach, Ma et al. [170] increased accuracy from 78.8% to 81.4% and ROC-AUC from 86.6% to 88.8%. Using CNN algorithms and molecular fingerprint-embedded features, Nguyen-Vo et al. [171] developed a DILI prediction model with 89% accuracy and 96% ROC-AUC. CNN's ResNet18DNN achieved a 95.8% success rate on 1446 compounds [172]. These methods may reduce drug recalls and improve the accuracy of DILI prediction.

## Section: Prediction of drug toxicity with AI › Carcinogenesis prediction

Potentially carcinogenic substances must be identified in order to prevent environmental cancers [173]. Many FDA-approved medications have been withdrawn due to their carcinogenic characteristics. Short-term biological studies and theoretical models have been tested to find such compounds. ML and DL techniques can be used to replace, scale back, and enhance animal studies.

Recently, a number of AI-based models and tools for compound carcinogenicity prediction were created [[174], [175], [176], [177], [178]]. Using hybrid neural networks (NN), Limbu and Dakshanamurthy developed carcinogenicity prediction models with an average accuracy of 74.3 and an average ROC-AUC of 80.1 [174]. Due to sparse data sets, DL models have low predictive accuracy. Wang et al. developed CapsCarcino, a new DL architecture, to address this problem [175]. On a set of external validation data, CapsCarcino had an average accuracy of 74.5 percent and an accuracy prediction rate of 83%. On sparse training data that was arbitrarily reduced to 20%, 40%, 60%, and 80% of the full training data, CapsCarcino performed better than other models. Li et al. developed the DeepCarc model, which has an average improvement rate of 37.0% and an accuracy of 75.4%, using 863 compounds and three descriptors [176]. Other reviews [173,179] cover additional models.

## Section: AI and gene editing technologies for developing gene therapies

With the growing accumulation of genomic and clinical data, data scientists face both challenges and opportunities when attempting to extract biologically or clinically relevant information from massive genotype and phenotype datasets. In genomics, AI-based technologies and data science techniques have been utilized effectively over the past two decades.

A significant amount of phenotypic information can be found in the clinical notes, discharge summaries, radiology, and pathology reports that make up about 80% of the unstructured data in EHRs [180]. Clinical NLP methods like cTAKES can parse semantic relationships and extract structured concepts from free text to extract this information. The accuracy of phenotyping has significantly improved with the use of NLP techniques in combination with structured and unstructured data. According to Liao et al.'s analysis of structured data, NLP can be added to it to increase sensitivity while preserving a high positive predictive value for a variety of illnesses, such as multiple sclerosis and inflammatory bowel disease [181].

A study on phenotyping rheumatoid arthritis using structured data (ICD codes and medication data) and clinical concepts derived from NLP shows how ML has been used to create phenotyping models. The SVM models outperformed rule-based techniques in accuracy [182], proving that a high-performing classifier can be built without the use of feature engineering. ML techniques are more scalable, work with less standardized datasets than rule-based approaches, and can capture more complex phenotypes.

However, manually labeled gold standard training and test datasets are crucial for developing and validating supervised ML models. However, creating them requires considerable time and expertise. To address this, unsupervised learning techniques have been proposed to generate patient clusters for specific medical conditions without human supervision. Ho et al. used the “Limestone” non-negative tensor factorization technique to automatically generate multiple phenotype candidates without predefined definitions [183]. A medical professional determined that only 40 of the top 50 candidates are necessary for higher predictive accuracy of patients at risk of heart failure. Two upgraded variations of Limestone, Marble, and Granite, showed improved performance [184,185]. Numerous phenotyping methods have been reported in line with the use of DL approaches, including Gehrmann et al., [186] and Yang et al., [187] use of discharge summaries or clinicians' notes, and Miotto et al., [188] de-noising auto-encoders for auto-encoding.

In genomics research, DL has emerged as a prominent class of algorithms owing to its capability to effectively handle large datasets with high dimensionality. A plethora of DL-based models have been developed and utilized for designing gRNA (guide RNA), incorporating features from both sequence and secondary structure data. Additionally, transfer learning, a ground-breaking innovation in computer vision, has been used in genomics research as well to take advantage of trained models and only need small sample sizes [189]. Moreover, BERT models have been specially created for NLP tasks in the clinical domain [190]. ClinicalBERT and Discharge Summary BERT were developed by Alsentzer et al., [191] and pre-trained on millions of clinical notes from the MIMIC-III database [192,193]. These MIMIC notes were split into sections followed by sentences extraction as input into the model, which captured contextual relationships between words bidirectionally. These models were pre-trained and fine-tuned for downstream tasks, outperforming BERT and BioBERT on three clinical NLP tasks. In order to predict hospital readmission, Huang et al. also created ClinicalBERT, but they also emphasized the drawbacks of using data from a single healthcare institution. Retraining on bigger databases of clinical notes is advised as a result for better performance. These advancements demonstrate how ML and its related fields can enhance genomics and clinical research.

## Section: AI-based modeling for personalized drug dosing

Traditionally, clinical practice has been based on the concept of “one therapy fits all’. However, drug molecules may undergo different metabolic activities in different patients. For example, a drug that works well for a group of people may not be as effective or may have adverse side effects for others. These differences in drug metabolism are mostly attributed to the differences in the genetic profile of individuals. Thus, a more futuristic approach is the personalized treatment also known as precision medicine, where patients are treated based on their genetic profile. The target is to maximize treatment outcomes while minimizing adverse effects per individual. Thus, different therapies and doses are customized per individual (or per group of patients that share similar genome profiles). AI has fostered considerable improvements in the development of personalized medicine [194]. For example, the AI-derived platform, CURATE.AI, predicts the optimal dosing along with the treatment outcomes based on the patients’ individual data. It generates a profile for each patient using their own medical records, and it dynamically recalibrates the predicted profile over time based on the progression or recession of the disease. CURATE.AI can optimize doses of not only single drugs, but also combinations of drugs [195,196]. This is helpful given that, nowadays, therapies are becoming more sophisticated with emphasis on combination (or multimodal) treatments. These involve more than one drug or treatment offered either simultaneously or sequentially. Combination therapy is proven to have more efficacy compared to single drug regimen especially in the treatment of complex diseases like cancer [197,198]. To predict the efficacy of a chosen treatment, Kureshi et al. developed an AI decision tree to establish a link between the characteristics of the patient and the tumor response in NSCLC [199]. They used four classifiers (histology, mutation in epidermal growth factor receptor, targeted drugs, and smoking habits) for predicting the response of NSCLC patients to the EGFR tyrosine kinase inhibitors. The method showed 76.6% accuracy and it can support the clinician in choosing the correct treatment for NSCLC patients. One of the drawbacks of the study is the small training set used (n = 355). This resulted in the omission of rare patterns such as duplication, deletions, insertions, and point mutations. Using a larger training set could further improve the predictive accuracy of this decision support model. The ‘IBM Watson for oncology’ software made a large impact on personalized treatment plans for cancer patients [200]. The software is trained on thousands of clinical and health records of cancer patients from the medical journals, textbooks, and literature curated by Memorial Sloan Kettering. This software makes accurate diagnoses and treatment recommendations by identifying related cases from databases of worldwide clinical trials (http://www.clinicaltrials.gov) [201].

## Section: The role of AI in rare disease research

Rare diseases (RDs) are a significant health issue that affects almost 1 in 10 individuals in US [202]. Despite their prevalence, the diagnosis of RDs is often challenging due to the complexity of symptoms and the rarity of the conditions. The delay in diagnosis can be as long as 7 years, leading to significant delays in treatment and management [203]. Hence, there is a need for new approaches to enhance the diagnosis and treatment of RDs. AI has the potential to transform the diagnosis and management of rare diseases [[204], [205], [206], [207]] based on NB, RF, XGBoost, CNN, AE (autoencoder), RNN, GAN (generative adversarial network), etc. Fernández et al. developed a deep DL-based approach to detect tubers in selected MRI (magnetic resonance imaging) images for the diagnosis of tuberous sclerosis complex (TSC) [204]. This model adopts a unique InceptionV3 CNN architecture to recognize whether an MRI image has tubers in it or not, showing promising performance (accuracy: 95%) in the detection of a rare neurological disorder. Founta introduced a semi-automated preprocessing gene selection methodology to identify causal amyotrophic lateral sclerosis (ALS) genes [205], with which they developed a classifier based on XGBoost and RF to diagnose ALS and its specific subtypes. This methodology achieved 88.89% accuracy for the classification of sporadic ALS motor neuron samples. Additionally, AI-based PET is a promising tool for early detection and diagnosis of RDs [208].

However, the implementation of AI in healthcare requires careful consideration of ethical, legal, and social implications [209]. AI medical devices must be developed with the active involvement of patient advocacy groups to ensure that the technology is designed to meet the specific needs of rare disease patients. The datasets used to train these algorithms must be diverse and augmented to ensure that they represent the end-user population accurately. Furthermore, the safety and effectiveness of AI-based medical devices (AIMDs) must be thoroughly evaluated to avoid potential harm to patients [210]. AIMDs must be RD-aware at every stage of their conceptualization and life cycle to avoid potential harm and unsustainable deployment of AIMDs into clinical practice. This requires a multidisciplinary approach involving clinicians, computer scientists, and patient advocacy groups.

In general, AI-based technologies offer promising solutions to improve the diagnosis and management of rare diseases. However, the ethical, legal, and social implications of AI in healthcare must be carefully considered to ensure the safety and effectiveness of AIMDs. With careful consideration and collaboration, AI has the potential to revolutionize the diagnosis and treatment of rare diseases, leading to improved patient outcomes and a better quality of life for those affected by RDs.

## Section: Conclusion

The use of AI technology in drug design has grown rapidly due to its predictive ability and accuracy. This review highlights the numerous applications of AI in all phases of drug development, from disease diagnosis to post-marketing analysis. AI helps in the early prediction of diseases, the development of personalized medicine, optimization of drug doses, and the prediction of treatment outcomes. Additionally, AI assists in target and lead identification through the prediction of protein structures and biological activities of small molecules. AI technology can also predict drug-like properties and off-target effects of new compounds, reducing the need for experimental validation. Furthermore, AI-driven approaches improve patient stratification, recruitment, monitoring, and follow-ups in clinical trials, and can even assist in FDA approvals and pharmacovigilance. The integration of AI in drug design has resulted in faster drug discovery, cost savings, reduced resource and manpower usage, and decreased attrition rates in clinical trials. Additionally, AI helps to minimize the use of in vivo bioassays, reducing animal sacrifice. AI has far-reaching applications beyond medicine, including healthcare management, surgeries, mRNA vaccination, preventive treatments, and nutrigenomics. However, it is important to note that AI models are meant to complement human intelligence, not replace it. AI models may have comparable or better predictive ability than human researchers, but they still lack human intuition. Predictions made by AI machines must be verified by humans, as AI models can provide false positive and false negative results, compromising the sensitivity and specificity of the model. Additionally, resource sustainability needs holistic solutions like cost-aware cross-layer co-design, integrating hardware, algorithms, and models for efficient exploration of resource-sustainable configurations. Consensus-based distributed learning is suggested to fully utilize existing and future computing infrastructures, incorporating Internet-of-Things devices and edge servers for data sharing while ensuring privacy. Stable infrastructures with AI-enhanced resource allocation are recommended, involving dedicated healthcare AI infrastructures compliant with evolving government regulations. Lastly, interpretable self-supervised learning is proposed to address the sustainability issue in domain expertise, enhancing trust by extracting clinically useful features and providing human-interpretable evidence in healthcare applications. There are numerous challenges associated with AI, including the explainability of models, the quality and suitability of data used to train models, avoiding bias and overfitting, resource sustainability and more. It is crucial to remain aware of the limitations and risks associated with AI technology. Opportunities for improvement in AI technology include minimizing dependence on supercomputing power, addressing ethical concerns surrounding data collection, and implementing AI in a controlled manner in the healthcare sector to limit negative consequences. It is possible that the future of AI-assisted drug discovery lies in developing a virtual human with complete complexity, allowing for accurate predictions of all possible interactions between molecules and exploring all therapeutic potentials and adverse side effects.

## Section: Declaration of competing interest

The authors declare that they have no conflicts of interest in this work.

## Section: Acknowledgments

This work was supported by the National Key R&D Program of China (2023YFF1205103), National Natural Science Foundation of China (81925034, 22237005), the Key Research and Development Program of Ningxia Hui Autonomous Region (2022CMG01002), the Starry Night Science Fund of Zhejiang University Shanghai Institute for Advanced Study (SN-ZJU-SIAS-007), the innovative research team of high-level local universities in Shanghai (SHSMU-ZDCX20212700).

## Section: Biography

Jian Zhang (BRID:09778.00.20899) received his BS in pharmacology from Peking University in 2002 and PhD in medicinal chemistry from Chinese Academy of Sciences in 2007. He joined Shanghai Jiao Tong University School of Medicine as a professor in 2009 and was rewarded the Changjiang Scholars Program in 2017. He is the director of the Medicinal Chemistry & Bioinformatics Center at Shanghai Jiao Tong University. He has published 120+ peer-reviewed papers (e.g. Nat Chem Biol, Chem), invented 20 issued patents, and made hundreds of international invited talks. He was elected the 2017 Top-ten Science and Technology Young Scientist in China, member of the Academic Degrees Committee of the State Council in 2020, the Fellow of Royal Society of Chemistry and Excellent Research Advisor of American Chemical Society in 2022. He is the associate editor for RSC Medicinal Chemistry, editorial board member for Medicinal Research Review and other seven international journals.


---

# Scoping Review of Deep Learning Techniques for Diagnosis, Drug Discovery, and Vaccine Development in Leishmaniasis

- **Authors:** Alireza Sadeghi, Mahdieh Sadeghi, Mahdi Fakhar, Zakaria Zakariaei, Mohammadreza Sadeghi
- **Issuer:** Transboundary and emerging diseases
- **Type:** Scientific article
- **Published:** 2024-01-17
- **Language:** en
- **DOI:** 10.1155/2024/6621199
- **Source:** https://pubmed.ncbi.nlm.nih.gov/40303156/
- **Licence:** CC-BY

## Section: Abstract

Abstract Leishmania, a single-cell parasite prevalent in tropical and subtropical regions worldwide, can cause varying degrees of leishmaniasis, ranging from self-limiting skin lesions to potentially fatal visceral complications. As such, the parasite has been the subject of much interest in the scientific community. In recent years, advances in diagnostic techniques such as flow cytometry, molecular biology, proteomics, and nanodiagnosis have contributed to progress in the diagnosis of this deadly disease. Additionally, the emergence of artificial intelligence (AI), including its subbranches such as machine learning and deep learning, has revolutionized the field of medicine. The high accuracy of AI and its potential to reduce human and laboratory errors make it an especially promising tool in diagnosis and treatment. Despite the promising potential of deep learning in the medical field, there has been no review study on the applications of this technology in the context of leishmaniasis. To address this gap, we provide a scoping review of deep learning methods in the diagnosis of the disease, drug discovery, and vaccine development. In conducting a thorough search of available literature, we analyzed articles in detail that used deep learning methods for various aspects of the disease, including diagnosis, drug discovery, vaccine development, and related proteins. Each study was individually analyzed, and the methodology and results were presented. As the first and only review study on this topic, this paper serves as a quick and comprehensive resource and guide for the future research in this field.

## Section: 1. Background

Leishmaniasis is a neglected parasitic disease caused by different species of the Leishmania parasite and is endemic in over 90 countries in tropical and subtropical regions worldwide. Leishmania is a single-celled parasite that exists in two forms: a motile form (promastigote) found in the vector's body (female Phlebotomus mosquitoes) and a nonmotile form (amastigote) that resides in the host's body, usually in infected humans or domestic or wild animals [1, 2]. Different species of Leishmania can cause a variety of clinical manifestations with a wide range of severity. Mild forms of the disease typically present as self-resolving skin lesions, while more advanced forms can lead to life-threatening visceral involvement, often affecting the spleen, liver, and bone marrow [3, 4]. In general, clinical classification, leishmaniasis is divided into four main categories: cutaneous leishmaniasis (CL, it can be seen locally or diffusely), mucocutaneous leishmaniasis (MCL), visceral leishmaniasis (VL), and post-kala-azar dermal leishmaniasis (PKDL) [5]. In spite of the recent advancements in diagnostic techniques for leishmaniasis [6], traditional methods still remain the primary approach for diagnosis. These methods can be broadly classified into three subgroups all of which are based on microscopic examination of stained tissue or parasite cultures [7, 8]. The treatment of this disease comprises of antimonials, amphotericin B, miltefosine, paromomycin, pentamidine; and a combination of these medications used together [9–12]. However, the existing drug regimens are old-fashioned and have certain disadvantages, including cytotoxicity, resistance, and the need for more effective, and less toxic alternatives. It is important to urgently develop novel drug regimens that offer improved efficacy and reduced toxicity [12]. Fortunately, advancements in artificial intelligence (AI) and machine learning have the potential to revolutionize the field of leishmaniasis drug discovery. These technologies can help in analyzing complex data sets, and predict potential drug candidates. By reducing human error and providing a more targeted and efficient strategy, AI can accelerate the process of finding effective treatments for leishmaniasis [13]. It is important to note that, our understanding of leishmanial pathogenesis is still limited and incomplete. Despite numerous efforts, the development of a prophylactic vaccine for leishmaniasis remains a challenging task. However, the use of AI/deep learning algorithms has led to the development of various analytical approaches, including computational/in-silico based tools. These tools can specifically design the immunoinformatic based multiepitope vaccine, which offer innovative vaccine candidates [14].

Early diagnosis and prompt treatment are crucial for controlling leishmaniasis [15], but repeated failures in conventional diagnostic methods have led to delays in starting chemotherapy and increased mortality in endemic areas. On the other hand, nowadays deep learning techniques [16, 17], a category of methods that have the capability to recognize intricate patterns in vast datasets, have shown the state-of-the-art performance in many medical applications [18–20]. Compared to the traditional machine learning methods, deep learning is more precise and flexible [17]. For example, many machine learning techniques are limited in processing raw natural data, such as images or voice signals, which require the use of a feature extractor approach in the first step [21]. Although several studies have investigated the application of deep learning methods to protozoan parasites [22–25], to the best of our knowledge, no review studies have been conducted on the implementation of deep learning methods for the Leishmania parasite in different domains. Therefore, this paper presents a scoping review of studies that have explored deep learning methods in the aforementioned field.

## Section: 2. Methodology

In this review, a meticulous methodology was employed to identify and select relevant articles pertaining to the application of deep learning techniques in Leishmania research. The process involved searching two prominent databases, Google Scholar, Scopus, and PubMed, to gather articles published from 2018 to the present. The aim was to encompass the latest advancements in the intersection of Leishmania and deep learning. Specific keywords and their combinations were utilized in the search to ensure precision: “deep learning and Leishmania,” “Leishmania and image classification,” “Leishmania and image segmentation,” “deep learning and leishmania examination,” “deep learning and Leishmania protein,” and “deep learning and Leishmania diagnosis”.

To maintain relevance, articles were included based on the defined criteria: First, only articles that explicitly employed deep learning techniques were considered. Studies that utilized general machine learning techniques without a deep learning focus were excluded. Moreover, articles written exclusively in English were considered for inclusion. Finally, articles had to directly relate to the interface of Leishmania and deep learning, encompassing image classification, image segmentation, examination, protein analysis, and diagnosis. Articles not meeting these criteria were excluded from the review, particularly those using nondeep learning machine learning techniques or published in languages other than English.

## Section: 3. Telemedicine and Deep Learning

Telemedicine has become an increasingly important field of healthcare in recent years. By utilizing technology such as video conferencing, remote monitoring devices, and mobile apps, telemedicine provides patients with access to medical care from anywhere, at any time. Telemedicine has the potential to improve healthcare access for patients who live in remote or underserved areas, as well as those who have difficulty accessing traditional healthcare services due to mobility issues or other disabilities [26].

One of the most promising areas of development in telemedicine is the use of deep learning techniques [16, 17]. Deep learning is a subfield of AI that utilizes neural networks to analyze vast amounts of data and identify patterns. In the context of telemedicine, deep learning can be used to analyze medical images, patient data, and other types of medical information to improve diagnosis and treatment. For example, deep learning algorithms can be trained to identify early signs of diseases such as cancer [27] or diabetes [28], which can help doctors to provide early intervention and improve patient outcomes.

Another area where deep learning can be beneficial in telemedicine is in remote patient monitoring. With the use of wearable devices and other remote monitoring tools, patients can transmit data to their healthcare providers in real-time, allowing for more effective monitoring of their condition. Deep learning algorithms can be used to analyze this data, identifying patterns that may be indicative of health issues before they become serious. This can help healthcare providers to intervene earlier and provide more effective treatment.

Despite the many potential benefits of deep learning in telemedicine, there are also some challenges that must be overcome. One of the biggest challenges is the need for large amounts of high-quality data to train the algorithms [14]. Additionally, there are concerns around the ethical implications of using deep learning to make medical decisions [29], and the potential for bias in the algorithms [30, 31].

In the following paragraphs, we will explore several specific deep learning models that have been applied in the field of leishmaniasis research. These models have been developed to address specific challenges of detecting, monitoring, and predicting the occurrence of this parasitic disease. As we will see, the application of deep learning models in leishmaniasis research has shown immense promise in improving disease management and control.

Models' structures: (a) a simplified structure of a typical ANN, (b) simplified structure of a CNN model (c) VGGNet16, (d) GAN structure, and (e) U-Net architecture.

A schematic representation of two commonly used metrics, the Jaccard index (a) and Dice score (b), for evaluating the performance of image segmentation algorithms.

Diverse applications of deep learning models in the field of medicine.

## Section: 3. Telemedicine and Deep Learning › 3.1. Artificial Neural Networks (ANN)

The concept of an ANN was first proposed by McCulloch and Pitts [32] in 1943. It is a model structure that consists of a set of fully connected layers. The inputs are first fed into an ANN, and after passing through several hidden layers, the output is generated in the last layer. The model then adjusts itself by comparing the generated output with the ground-truth value, aiming to improve its performance. When an ANN contains many hidden layers, it is referred to as a deep neural network (DNN) [17].

## Section: 3. Telemedicine and Deep Learning › 3.2. Convolutional Neural Networks (CNNs)

CNN is a widely used neural network model in various applications. Unlike the DNN, in which all neurons in a given layer are connected to all neurons in the adjoining layers, every layer in a CNN model only focuses on specific parts of the previous layer's outputs to extract useful features at each step [33]. This makes CNNs computationally efficient and less time-consuming.

## Section: 3. Telemedicine and Deep Learning › 3.3. VGGNet

VGGNet [34], proposed by researchers from the Visual Geometry Group at Oxford University, is a simple arrangement of several convolutional, pooling, and dense layers that won the ImageNet Large-Scale Visual Recognition Challenge (ILSVRC) in 2014 [35]. The VGGNet16 model, which contains 16 layers, has become a widely used model in deep learning applications.

## Section: 3. Telemedicine and Deep Learning › 3.4. ResNet

During the training of a CNN, as the model becomes deeper, some of the information may lose its impact on the final output. In order to address this issue, He et al. [36] proposed the use of skip connections for DNNs, and their model won the ILSVRC competition in 2015. According to their method, skip connections add information from a specific layer to the output of a few layers ahead. ResNet models are typically denoted by a number that indicates the number of convolutional and dense layers used in the model. For example, ResNet34 has 34 of these layers.

## Section: 3. Telemedicine and Deep Learning › 3.5. U-Net

The U-Net model, proposed by Ronneberger et al. [37], is a widely used architecture for image segmentation tasks, specifically in assigning every pixel of an image to a particular class. The U-Net model consists of two main steps: downsampling and upsampling. In the downsampling step, the model extracts feature from the image, while in the upsampling step, a pixel-wise label map is generated using the extracted features. The architecture of the U-Net model is named after its shape, which resembles the letter “U”.

## Section: 3. Telemedicine and Deep Learning › 3.6. Generative Adversarial Network (GAN)

The GAN was first proposed by Goodfellow et al. [38], consisting of two main components: the generator and the discriminator. The primary goal of the GAN is to train the generator to generate new images similar to real images, while simultaneously training the discriminator to distinguish fake images from real images as accurately as possible. Through this conflict between the two units, the model can produce new fake images that are nearly indistinguishable from the real images in the dataset. Figure 1 illusterates the deep learning models described above.

Models' structures: (a) a simplified structure of a typical ANN, (b) simplified structure of a CNN model (c) VGGNet16, (d) GAN structure, and (e) U-Net architecture.

## Section: 3. Telemedicine and Deep Learning › 3.7. Transfer Learning

In the context of deep learning, the size and quality of data used to train the model have a significant impact on its ability to generalize and perform well on new data [39]. However, in medical studies, it can be challenging to obtain sufficient amounts of high-quality data due to several factors such as privacy regulations, ethical considerations, and the complexity of medical data. As a result, medical datasets are often limited in size, making it difficult to train deep learning models for the clinical applications [40]. To address this challenge, researchers have turned to an alternative approach known as transfer learning. Transfer learning involves pretraining a deep learning model on large datasets from other domains and then fine-tuning it on the smaller medical dataset. By leveraging the features learned from the large datasets, transfer learning can help to improve the generalization and performance of the model on the smaller medical datasets [41].

## Section: 3. Telemedicine and Deep Learning › 3.8. Assessments

A deep learning model's performance can be evaluated using various metrics, depending on the objective of the model. Typically, these models are created to address one or more specific problems, such as classification, segmentation, regression, or generation. Each of these problems has its own set of metrics to evaluate model performance.

One of the most common metrics used to evaluate deep learning models is accuracy. Accuracy is the ratio of correctly predicted samples to the total number of samples. However, accuracy alone is not always the most appropriate metric, particularly in cases where the data are imbalanced [42]. In such cases, a model with a high level of accuracy may still perform poorly on the minority class, which is typically of the greatest interest in many applications.

To overcome this issue, a number of alternative metrics have been developed. One such metric is precision. Precision is the ratio of true positives (TP) to the sum of true positives and false positives (FP). Essentially, it measures the percentage of positive predictions that are actually true positives. This metric is particularly useful in cases where false positives are more problematic than the false negatives.

Another metric that is commonly used is recall, also known as sensitivity. Recall is the ratio of true positives to the sum of true positives and false negatives (FN). This metric measures the percentage of true positives that the model was able to correctly identify.

In addition to the metrics mentioned above, specificity is another important performance metric that is sometimes used in deep learning models. Specificity is the ratio of true negatives (TN) to the sum of true negatives and false positives. Essentially, it measures the percentage of negative predictions that are actually true negatives. Similar to recall or sensitivity, specificity is a measure that is useful in specific problem domains, particularly in medical diagnosis or fraud detection where accurate negative predictions are important.

F1-score is another popular metric that combines precision and recall, providing a more balanced measure of a model's performance. Specifically, F1-score is the harmonic mean of precision and recall. Other metrics used for specific tasks include mean-squared error and root-mean-squared error for regression tasks, and Dice score for the segmentation tasks.

The Dice score and Jaccard index represent two widely employed metrics within the domain of image segmentation tasks. These metrics serve to quantify the efficacy of a deep learning model in delineating and accurately segmenting objects within an image. This concept is further explained in Figure 2.

Among the deep learning models delineated earlier, CNNs have gained substantial prominence within diverse medical applications, encompassing diagnoses, vaccine development, and drug detection. Their innate capacity to autonomously acquire hierarchical features from images renders them exceedingly versatile for a myriad of undertakings within the medical realm. VGGNet and ResNet, both stemming from the CNN paradigm, have found predominant utility in the domain of medical diagnosis. Notably, UNet's architectural configuration renders it particularly well-suited for tasks involving the segmentation of medical images—wherein precise delineation of regions of interest, such as tumors or anatomical structures, assumes pivotal significance. GANs have garnered widespread employment in medical contexts, primarily for the generation or manipulation of medical images. For example, GANs can be effectively harnessed for denoising medical images. A summary of the applications of these techniques within the medical domain is presented in Table 1.

A schematic representation of two commonly used metrics, the Jaccard index (a) and Dice score (b), for evaluating the performance of image segmentation algorithms.

Diverse applications of deep learning models in the field of medicine.

## Section: 4. Leishmaniasis Diagnosis

In the field of leishmaniasis diagnosis, various conventional (microscopic examination, culture, and serological tests) and novel diagnostic (molecular-based approaches) techniques are used for the detection and diagnosis of leishmaniasis, however, microscopic examination is widely accepted as gold standard. On the other hand, molecular-based techniques can overcome on several limitations of the conventional methods. In this regard, microscopic examination is widely used due to its low cost and simplicity [70, 71]. However, this method is time-consuming and prone to the human errors [72]. On the other hand, deep learning has shown outstanding performance in various image-related applications such as image classification [73, 74], object detection [75, 76], and image segmentation [77, 78]. Therefore, deep learning can be considered as an alternative method for quicker and more accurate diagnosis of leishmaniasis from the microscopic images. The method is a smart tool for identifying Leishmania amastigotes (known as Leishman-Donovan bodies) on stained microscopic slides, including archival ones, which can be achieved without the need for experienced personnel and without the need for tools, equipment as well as physical space. Furthermore, this can be done remotely and in field conditions, while some conventional and novel techniques will not have such advantages. Table 2 summarizes the studies conducted on Leishmania diagnosis and their respective particulars.

One of the first studies to employ deep learning as a tool for microscopic examination was presented in [79]. The study aimed to classify various microscopic objects into different categories, with the help of a two-step method. In the first step, the authors employed the popular U-Net model [37] for image segmentation, the process of partitioning an image into multiple segments or regions that are relevant to specific objects or features of interest. Using the segmented images, the authors then proceeded to classify objects into six categories. The categories included background, cytoplasm, nucleus, promastigote, adhered, and amastigote. This classification was achieved through deep learning algorithms that considered various features of the segmented image.

The authors used a total of 45 microscopic images that were manually annotated by experts using a specific tool developed for this task. These images were provided by the Computational Biology and Complex Systems Group at Universitat Politecnica de Catalunya. While this study provided valuable insights into the use of deep learning for microscopic examination, the authors suggested that the model's performance could be improved by using more images to train it and implementing a more accurate method for annotation. This highlights the importance of accurate annotation in deep learning, which is critical to the performance of the model.

The study presented in [80], introduces a model called Cell Explorer, which can identify and count three types of parasites in the microscopic images. The parasites include Leishmania, Trypanosome, and Plasmodium, and the model can identify more than one parasite in a single image, making it a multiple-label model.

The model was trained and implemented using 401 microscopic images obtained from the blood samples of 15 mice, with five mice infected with one of the three parasites. To identify the parasites, the images were preprocessed and a pretrained ResNet18 model [81] was used.

Apart from identifying parasites, the model was also able to count the number of cells present in the microscopic images. This was achieved using the simple linear interactive clustering algorithm [81]. The Cell Explorer model achieved an impressive accuracy of about 95%, with an F1-score of 0.766.

The study in [82], aimed to address the ongoing challenge of accurately detecting cutaneous leishmaniasis (CL) from skin lesion images using a transfer learning approach with VGG19 [34] as the base model in a mobile application. The dataset used in the development of the model comprised 2022 images representing diverse categories, including CL images, melanoma, and a range of other diseases that could potentially be mistaken for CL during diagnosis. The dataset was carefully selected to simulate real-world conditions, where misdiagnosis can occur frequently and impede appropriate medical intervention, ultimately exacerbating the negative clinical outcomes of CL.

Additionally, the study assessed the model's performance against the skills of human experts by requesting seven CL experts to classify 100 random images. The results demonstrated the superiority of the model, recording an impressive accuracy rate of 99%, relative to 83% for the human experts. These results indicate that the developed mobile application has the potential to offer significant support to healthcare practitioners in achieving improved diagnoses, particularly within regions where CL is endemic and medical resources may be limited.

In [83], an automated imaging platform called Octopi was introduced for the diagnosis of parasitic diseases from blood smear. The platform is highly modular and can diagnose different parasitic diseases by utilizing different modules. Octopi is capable of identifying Plasmodium falciparum, Leishmania donovani, Trypanosoma brucei rhodesiense, and several other parasites. Additionally, the platform can count the number of red blood cells, which can be useful for identifying the presence of parasites in infectious blood. To achieve this, Octopi implemented a 91-layer fully convolutional DenseNet [84] model for counting the red blood cells. A total of 22,680 images, all automatically annotated, were used to train the model. Moreover, the model was modified to achieve real-time performance.

In the field of leishmaniasis diagnosis, microscopic images can often be blurry or out-of-focus due to defects in instruments or human error, leading to misdiagnosis by the experts [85]. Furthermore, these issues can negatively impact the performance of related research. To address these challenges, a GAN-based model was proposed in [86] that is capable of deblurring and correcting out-of-focus images. This model was trained on two different datasets that were both self-collected and publicly accessible. This study not only enhances the quality of leishmaniasis microscopic imaging, but it also aids further research in deep learning for leishmaniasis, as the provided dataset includes a large number of leishmaniasis microscopic images. To evaluate the proposed model, the authors compared its performance with several similar models and demonstrated that their model outperforms others.

Studies on Leishmania diagnosis.

## Section: 5. Leishmaniasis Drug Discovery

Currently available treatments for leishmaniasis are associated with high costs, long treatment periods, and potential side effects, as highlighted in [87]. This presents a significant challenge, particularly in endemic regions where resources are limited. Therefore, there is a pressing need for developing new treatments that are more cost-effective, safe, and efficient.

One promising approach to develop new treatments for leishmaniasis is the repurposing of existing drugs used to treat other diseases [88]. This approach, also referred to as drug repositioning, has been employed successfully for other infectious diseases like SARS-CoV-2 [89, 90]. The concept involves screening all known drugs to identify those that have potential therapeutic effects against leishmaniasis.

In this context, molecular docking plays a crucial role. It is a computational technique that predicts whether two molecules, the receptor and the ligand, can chemically bind. The conventional software for molecular docking includes AutoDock Vina, Rosetta Ligand, and AutoDock 4, which are widely used in the scientific community [91–93]. However, these conventional methods often face limitations, such as the inability to operate in complex biological environments, inefficiency, and imperfect prediction of the binding affinities.

In recent years, deep learning approaches have been applied in different fields and have shown promising results in prediction tasks [94, 95]. These techniques can support drug discovery by predicting molecular interactions between drugs and target proteins, paving the way for drug repurposing for the treatment of various diseases, including leishmaniasis.

Therefore, by combining molecular docking and deep learning techniques, drug repurposing could be accelerated, with the potential to identify novel drugs and optimize existing ones for managing leishmaniasis. This could lead to more cost-effective and efficient treatment options, improving the prognosis and quality of life for patients suffering from leishmaniasis.

In 2020, the Indaba Grand Challenge was conducted and it sought to identify effective combinations of Leishmania proteins and small molecules that could be used to develop a new drug for leishmaniasis. The competition produced a dataset consisting of 4,021 ligands (small molecules) and 512 targets (Leishmania proteins), which researchers then used to try to find a suitable drug. In an effort to achieve this objective, Dassi et al. [96] employed a hybrid approach that combined deep learning with molecular docking. Specifically, they utilized the DeepPurpose [97] which is a deep learning library to predict drug-target interactions. After screening the entire dataset, the researchers identified 3,400 promising pairs from a pool of over 2 million possible pairs. The next step was to test these pairs using AutoDock Vina, a widely used molecular docking software that can predict how a ligand will bind to a protein. AutoDock Vina was used as a ground truth method to rank the 3,400 promising pairs and the results obtained using this software were then compared to the rankings predicted by the deep learning library. The comparison revealed that although deep learning was unable to rank the pairs accurately, molecular docking was a more reliable method. However, by leveraging the power of deep learning, they were able to significantly reduce the time required for the entire procedure. From a process that initially took 2 months, the researchers were able to conduct it in just 14 hr.

In a similar investigation to that carried out by Dassi et al. [96]; researchers, Smith et al. [98] sought to identify a viable drug for treating leishmaniasis, utilizing two different deep learning frameworks: DeepPurpose [97] and a multiobjective neural network binding affinity prediction model (MONN) [99]. The DeepPurpose model was trained on the BindingDB dataset [100], which comprises more than 2-million binding data, while the MONN model was trained on the PDBBind v2018 dataset [101], which includes over 17,000 protein-ligand complexes. After implementing these two frameworks and comparing their results with the general truth methods of Autodock Vina [93] and PyRosetta docking [102], Lacosamide was identified as a prospective treatment for leishmaniasis. The researchers also represented each molecule as a real-value vector using Mordred [103] and RDKit. By computing a distance matrix among drug candidates, Conivaptan and Midostaurin were identified as other promising drugs that could potentially aid in the treatment of leishmaniasis.

AI can actually be used to evaluate the toxicity parameters of drugs. AI algorithms can analyze large data sets, including chemical structures and biological data, to predict the safety and effectiveness of drugs. For toxicity assessment, AI models can be trained on existing data from various sources, such as databases and published studies, to recognize patterns and predict potential toxic effects of new drugs. This could help identify drug candidates with a lower risk of toxicity early in the drug discovery and development process, thereby reducing the need for extensive animal testing [96–98]. In addition, AI can also be used to evaluate other pharmacological parameters such as drug interactions, absorption, distribution, metabolism, and excretion (ADME) and pharmacokinetic profiles. By analyzing known molecular properties and structure–activity relationships, AI algorithms can help predict these parameters for new drug candidates [104].

Overall, AI can improve the drug development process by providing valuable information on toxicity and pharmacological parameters, enabling more informed decisions and potentially reducing the time and resources required to bring safe and effective drugs to the market.

## Section: 6. Leishmaniasis Vaccine

Leishmaniasis is responsible for a significant number of fatalities every year, particularly in countries located in Africa and the Middle East [2, 105]. Despite the availability of several methods of therapy and drugs, the burden of this disease continues to be a major public health issue. One of the most effective methods of controlling and eradicating infectious diseases is through vaccination. Vaccines help to prevent the transmission of diseases by providing immunity against the pathogen responsible for the disease.

Therefore, the development of an effective and safe vaccine against leishmaniasis is essential in preventing and controlling this disease. Although there have been some successes in developing vaccines to prevent Leishmania transmission from dogs to humans, such as Leishmune and CaniLeish, there is currently no licensed vaccine available for humans [106, 107]. Hence, there is an urgent need to develop and test new vaccines for human protection against leishmaniasis.

There is considerable research interest in developing anti-leishmaniasis vaccines, however, the development of an effective vaccine against leishmaniasis presents several challenges, including the complex nature of the parasite's life cycle and the differences in the immune response generated by different Leishmania species.

In an effort to address this issue, Saha et al. [14] developed an immunoinformatics-based chimeric vaccine using four different Leishmania donovani (L. donovani) proteins: an ATP-dependent zinc metallopeptidase, a histidine secretory acid phosphatase, a rhomboid-like protein, and an amastin-like surface protein (ALSP). The chimera was constructed by linearly arranging the most effective helper T-lymphocytes (HTL), cytotoxic T-lymphocytes (CTL), and B-cells epitopes of the mentioned proteins. The most promising CTL epitopes were identified using NETMHC 4.0, which utilizes an ANN [108], while the most efficient B-cells epitopes for all four L. donovani proteins were detected using ABCpred, another ANN model [109]. The secondary structure of the vaccine was produced using the PSIPRED web server, which contains two neural network models [110], while the 3D structure of the proposed vaccine was generated using the RaptorX web server, a deep learning model [111].

Overall, an active area of research in leishmaniasis is multiepitope vaccines. These vaccines are designed to provide broad protection by integrating multiple epitopes from different Leishmania antigens into a single vaccine construct. Here are some of the tools and approaches used to develop vaccine targets against multiepitope leishmaniasis [112–114]:

The process of developing multiepitope vaccines for leishmaniasis is indeed a dynamic and ongoing effort. Researchers are continuously improving and refining the tools and techniques used for epitope prediction and mapping, as well as exploring novel approaches and technologies to enhance vaccine effectiveness. This iterative approach allows for continuous progress and the potential for breakthroughs in the fight against leishmaniasis.

## Section: 7. Leishmaniasis 3D Protein Structure

Predicting the structure of proteins is a crucial step in understanding their function and behavior in the biological systems. Proteins are involved in virtually all cellular processes, such as metabolism, signaling, and regulation, and their activity is strongly influenced by their three-dimensional structure. Knowing the precise structure of a protein can help researchers to identify potential drug targets, design new therapeutics, and develop treatments for a wide range of diseases. Additionally, predicting the structure of proteins has important implications for fields such as biotechnology and bioengineering, where it can be used to engineer new proteins with the desired properties.

In the field of bioinformatics, predicting the structure of proteins has been a significant challenge. Different approaches have been employed in the past to achieve this, ranging from statistical to deep learning methods [115–117]. Among these, deep learning has shown remarkable success in the recent years, including AlphaFold2 [118] and RoseTTAfold [119]. These models utilize multiple sequence alignments to predict the 3D protein structure accurately. AlphaFold2 was the winner of the Critical Assessment of protein Structure Prediction (CASP) competition (CASP14) [120], demonstrating its ability to accurately predict the structure of proteins.

However, while AlphaFold2 has performed well in predicting the structures of many species, its accuracy in predicting the structure of proteins from species like Leishmania infantum has been suboptimal. This issue arises from the underrepresentation of such species in the AlphaFold2 databases. To address this, researchers in [121] have collected additional data from public protein sequence datasets. The data used in this study consisted of 243 genomes and transcriptomes obtained from different sources. Some of the sources included in the dataset were TriTrypDB [122, 123], a comprehensive database of genomic information on trypanosomatid species, NCBI, a leading source of genetic information that incorporates data from multiple sources, sequencing read archive (SRA), a public repository of sequencing data from different studies, transcriptome shotgun assembly (TSA), which provides transcriptomic data to complement genomic information, and Marine Microbial Eukaryotic Transcriptome Sequencing Project (MMETSP), which provides transcriptome data from marine eukaryotic organisms. In particular, 83 genomes were sourced from TriTrypDB, NCBI, and SRA while 160 transcriptomes were obtained from TSA, MMETSP, and NCBI SRA. By combining data from these different sources, the researchers provided a more representative and comprehensive set of protein sequences to the deep learning model, AlphaFold2. This allowed the model to achieve higher performance in predicting protein structures from a broader range of species, including understudied species like L. infantum.

To evaluate the resulting improvement in the model's performance, the predicted local distance difference test score (pLDDT) [124] was used. This metric measures the quality of protein structure predictions, where higher scores indicate better quality. The updated AlphaFold2 model demonstrated remarkable improvements in its ability to predict the structure of proteins from species like L. infantum.

Overall, the incorporation of additional data sources into deep learning models can enhance their performance in predicting protein structures accurately. Improved models can support drug discovery efforts, ultimately leading to more effective treatments for diseases like leishmaniasis that result from protein dysfunction.

## Section: 8. Conclusion

This scoping review, as a pioneering review study in this field, is an important first step in the development of machine learning and deep learning techniques, a branch of AI, for diagnosing, treating, and preventing leishmaniasis. Table 3 presents a summary of the studies that have been analyzed within the context of this research. By providing a comprehensive overview of the current state of research, this review can help to guide future studies and accelerate progress in this critical area. Deep learning holds great promise for the future of leishmaniasis research in terms of diagnosis, treatment, and vaccine development. Here are some perspectives on how deep learning can revolutionize these aspects:

A significant hurdle in the advancement of deep learning models for applications within the domain of leishmaniasis revolves around the constraint imposed by the limited size of available datasets. The proficiency and reliability of a deep learning model are dependent upon its exposure to an extensive dataset that encompasses a wide variety of samples. The samples present in the existing datasets often originate from timeframes predating the current period, consequently failing to accurately capture potential shifts in the manifestation of Leishmania within microscopic images as they may appear in the contemporary scenarios.

The application of deep learning techniques also merits consideration due to their capacity to effectively process intricate datasets, conduct complex analyses, and assemble insightful information that may be beyond the human comprehension. The incorporation of these two domains has the potential to yield substantial advancements in the realm of Leishmania vaccine development, deserving in-depth investigation in subsequent research endeavors. It is imperative to recognize the pivotal role that vaccine development can undertake in the eradication of leishmania, thereby preventing its evolution into a substantial public health concern.

As a whole, despite these challenges, the future perspective of deep learning in leishmaniasis research is immense. Continued research, collaboration, and investment in both data collection and algorithm development will be essential to fully unlock the benefits that deep learning can offer in the diagnosis, treatment, and vaccine development for leishmaniasis.

Summary of the reviewed studies.

## Section: Acknowledgments

The authors would like to thank the staff of the Mazandaran University of Medical Sciences (MAZUMS); grant no. 17596 for their kind assistance and to provide financial support.

## Section: Data Availability

The data that support the findings of this study are available from the corresponding author upon reasonable request.

## Section: Conflicts of Interest

The authors declared no potential conflicts of interest with respect to the research, authorship, and/or publication of this article.

## Section: Associated Data › Data Availability Statement

The data that support the findings of this study are available from the corresponding author upon reasonable request.


---

# SerotoninAI: Serotonergic System Focused, Artificial Intelligence-Based Application for Drug Discovery

- **Authors:** Natalia Łapińska, Adam Pacławski, Jakub Szlęk, Aleksander Mendyk
- **Issuer:** Journal of chemical information and modeling
- **Type:** Scientific article
- **Published:** 2024-01-30
- **Language:** en
- **DOI:** 10.1021/acs.jcim.3c01517
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38289046/
- **Licence:** CC-BY

## Section: Abstract

SerotoninAI is an innovative web application for scientific purposes focused on the serotonergic system. By leveraging SerotoninAI, researchers can assess the affinity (pKi value) of a molecule to all main serotonin receptors and serotonin transporters based on molecule structure introduced as SMILES. Additionally, the application provides essential insights into critical attributes of potential drugs such as blood–brain barrier penetration and human intestinal absorption. The complexity of the serotonergic system demands advanced tools for accurate predictions, which is a fundamental requirement in drug development. SerotoninAI addresses this need by providing an intuitive user interface that generates predictions of pKi values for the main serotonergic targets. The application is freely available on the Internet at https://serotoninai.streamlit.app/, implemented in Streamlit with all major web browsers supported. Currently, to the best of our knowledge, there is no tool that allows users to access affinity predictions for serotonergic targets without registration or financial obligations. SerotoninAI significantly increases the scope of drug development activities worldwide. The source code of the application is available at https://github.com/nczub/SerotoninAI_streamlit.

## Section: Introduction

The rise and development of artificial intelligence (AI) tools have a revolutionary impact on many areas of science and industry. In the field of drug design, AI is showing the potential to change traditional approaches, enabling faster and more efficient discovery and development of new therapeutic agents.1,2 One of the benefits of AI is the development of advanced QSAR (quantitative structure–activity relationship) and QSPR (quantitative structure–property relationship) models. Their ability to screen new active compounds, possible side effects, bioavailability and other properties can speed up and increase cost effectiveness both of the drug discovery and development phases.3−6

Our work focuses on serotonin receptors and transporters. Selected biological targets are important for many drugs that impact the central nervous system (CNS). Substances that affect the serotonergic system are used to treat mood, migraine, regulate sleep, and treat neurotic disorders or eating disorders. Furthermore, recent studies show that they can improve cognitive function. Preliminary studies also show that they may represent an even broader spectrum of therapeutic applications than CNS activity. For example, the serotonin 5-HT2C receptor has a role in impulse control, and the 5-HT3 receptor plays a role in controlling nausea and vomiting.7−9

SerotoninAI is an application focused on compounds with a serotonergic activity. It allows predictions of affinity for various 5-HT receptors as well as the serotonin transporter. The affinity for a selected biological target ensures a potential application of a molecule as a future drug and allows us to anticipate possible side effects. Moreover, SerotoninAI predicts human intestinal absorption (HIA) and blood–brain barrier (BBB) penetration of the given chemical structure. For the molecule, a confirmed BBB penetration is a crucial property for drugs acting on the central nervous system, whereas extensive HIA ensures feasibility of the oral administration route, the most preferred and acceptable one in the therapy. The artificial intelligence (AI)-based system for HIA has been developed on data sets with serotonergic ligands, which limits its application to these molecules only.10

There are a number of ready-to-use programs for assessing protein–molecule interactions which the main task is to dock molecules in the corresponding protein, such as NovaDock11 and AutoDock.12 On the other hand, VEGA QSAR13 and QSAR TOOLBOX14 do not provide predictions of affinity for selected receptors. Their application focuses on physical and chemical properties and also ADME-TOX properties. In contrast, typical QSAR models are provided by applications such as QSAR-Co15 and PharmQSAR.16 In the case of QSAR-Co, the prediction capabilities are limited to classification models. Moreover, to obtain predictions, the user needs to download and run the tool’s own machine, which might introduce some difficulties related to OS/machine specification. Moreover, the authors of the application do not provide ready-to-use models related to the serotonin system. PharmQSAR allows the creation of statistical models using techniques CoMFA (Comparative Molecular Field Analysis) and CoMSIA (Comparative Molecular Similarity Indices Analysis)17 and also does not provide models for serotonin receptors and transporters. In the aforementioned applications for QSAR models, whether ready-made or with the ability to create them, registration is required, which greatly limits the use of such an application. Provided preliminary limitations for users prevent us from directly comparing the presented systems with our models.

The only tool available without registration that provides QSAR models is aiQSAR.18 In order to use the ready-made models, we need to download the applications to our own machine. However, among the 38 biological targets, there is none related to the serotonin system. A publication describing QSAR models for serotonin receptors is the work of Kausar et al.19 They describe the results for most serotonin receptors, but we have no way of comparing the results because databases are not available (no information about training and test set beyond the number of molecules). When considering the available tools, we decided to create SerotoninAI as the missing piece to accelerate the drug discovery process.

SerotoninAI as a web-based app allows users to easily obtain predictions for chosen molecules without the need for installing any tools on their own computers, as well as without any programming skills. To the best of our knowledge, SerotoninAI is the first affinity prediction tool for serotonin targets without mandatory registration of a user. Moreover, the only information needed from the user side is SMILES (Simplified Molecular Input Line Entry Specification) of a molecule. It is worth mentioning that the application is distributed under the GNU General Public License version 320 and the source code is provided on the GitHub platform (https://github.com/nczub/SerotoninAI_streamlit).

## Section: Results and Discussion

Histograms of the pKi values: (A) 5-HT1A serotonin receptor. (B) 5-HT1B serotonin receptor. (C) 5-HT1D serotonin receptor. (D) 5-HT2A serotonin receptor. (E) 5-HT2B serotonin receptor. (F) 5-HT2C serotonin receptor. (G) 5-HT3 serotonin receptor. (H) 5-HT4 serotonin receptor. (I) 5-HT5A serotonin receptor. (J) 5-HT6 serotonin receptor. (K) 5-HT7 serotonin receptor. (L) Serotonin transporter SERT.

Confusion matrices for training and test sets: blood–-brain barrier QSPR model.

A comparison of the molecule’s applicability domains. (Left) A molecule within the applicability domain. (Right) A molecule out of the applicability domain. The gray area indicates the application domain.

## Section: Results and Discussion › Databases

The application uses QSAR models developed on data extracted from two leading databases, namely, ZINC and ChEMBL (data extracted in December 2022).21,22 Data were acquired for each target involving serotonergic activity, that is, 5-HT1A, 5-HT1B, 5-HT1D, 5-HT2A, 5-HT2B, 5-HT2C, 5-HT3, 5-HT4, 5-HT5A, 5-HT6, 5-HT7, and the serotonin transporter SERT. Despite the presence of ligands for 5-HT1E and 5-HT1F as well as 5-HT5B receptors these databases were not used to create models due to their small size (<500 molecules) resulting in the limited applicability domain. Our approach was to provide models based only on the experimentally validated data; therefore, no decoys were used in any of the training or testing data sets.23

The dependent variable was the value of ligand affinity presented as the negative logarithm of the inhibition constant, the pKi value. In the data preparation part, duplicates were first removed from the ZINC and ChEMBL databases separately, and invalid SMILES were removed. No other specific structure curation was employed. The two databases were then merged, and some molecules were present in both databases. Molecule pairs with a pKi difference greater than 0.1 were removed from the database. In the group of molecule pairs with a pKi difference equal to or less than 0.1, the ZINC molecule was selected as the reference substance. The databases were randomly divided into training and test sets at a ratio of 80:20. The former part of the data (80%) was used to develop QSAR models according to the 10-fold cross validation scheme, and the latter (20%) was used as an external test set. Figure 1 shows histograms of pKi values for each biological target according to the training and test set.

The database for predicting HIA was described in our previous work;10 the source of the data was literature data and the ChEMBL database.

QSPR classification model of BBB permeability was based on the database collected from the work of Miao et al.24 (data set 1 and data set 2) and enriched by us with data from OCHEM database25 (data extracted in July 2023). It resulted in 2853 molecules in the training set. An independent test set from the article by Miao et al. remained in the test set of our experiment (161 molecules) in order to better compare our developed QSPR model.

All data are available in the Supporting Information as a single database.zip file containing separate training/test csv files for each respective biological target.

Histograms of the pKi values: (A) 5-HT1A serotonin receptor. (B) 5-HT1B serotonin receptor. (C) 5-HT1D serotonin receptor. (D) 5-HT2A serotonin receptor. (E) 5-HT2B serotonin receptor. (F) 5-HT2C serotonin receptor. (G) 5-HT3 serotonin receptor. (H) 5-HT4 serotonin receptor. (I) 5-HT5A serotonin receptor. (J) 5-HT6 serotonin receptor. (K) 5-HT7 serotonin receptor. (L) Serotonin transporter SERT.

## Section: Results and Discussion › Molecular Representation

Mordred descriptors were used as a molecular representation of chemical structures.26 Mordred effectiveness in this field and suitability for interpretation has been tested in our previous work.10 QSAR and QSPR models were created based on two-dimensional descriptors to prevent the risk of variability in three-dimensional descriptors due to nonconvergent molecules’ optimization. Based on SMILES, SerotoninAI automatically creates the molecular descriptors required by the models.

## Section: Results and Discussion › QSAR and QSPR Models

Modeling was performed with the mljar-supervised tool, which belongs to the field of Automated Machine Learning (AutoML).27 In the case of receptors, serotonin transporter and BBB permeability models were de novo created for the purpose of the presented application. On the other hand, for human intestinal absorption, the AI-based system has already been published10 and has been implemented in this application without any further modifications.

QSAR regression models were created according to the 10-fold cross-validation scheme (10-CV) on 80% of the curated databases. For each target, about 2000 models were developed. We used root-mean-square error (RMSE) and coefficient of determination (R2) values to evaluate and select the best models (eqs 1 and 2), in accordance with the guidelines of the Organization for Economic Co-operation and Development’s QSAR models.28 The results were analyzed for the training set (10-CV) and the separate test set (20%). In Table 1, we show the detailed results for each QSAR model.1where RMSE = root-mean-square error, obsi and predi = observed and predicted values, i = data record number, and n = total number of records.2where R2 = the coefficient of determination, SSres = the sum of squares of the residual errors, SStot = the total sum of the errors, obsi and predi = observed and predicted values, and obs = arithmetical mean of observed values.

In Table 2, we have presented examples of drugs available on the market along with their affinities from literature sources and pKi values predicted by the SerotoninAI.

The examples presented above are also included in curated databases prepared to create QSAR models, which do not constitute the usefulness of such a model for unseen examples of molecules. Therefore, we decided to test the created models on the latest available data. For this purpose, we reviewed the literature from 2022, when the first databases were created. New experimental data were available for seven biological targets (5-HT1A, 5-HT1B, 5-HT2A, 5-HT2B, 5-HT2C, 5-HT5A, 5-HT6, and 5-HT7).33−38 In Table 3, we present summary results for each receptor and the sum of predictions, using SerotoninAI, located in four categories: when the prediction difference was less than 0.5, greater than or equal to 0.5 and less than 1.0, the third group being prediction differences equal to or greater than 1.0 and less than 2.0, and the last group indicating a very large prediction difference, a value equal to or greater than 2.0. All predictions are available in Supporting Information S1. The worst predictions are seen for the 5-HT5A receptor. In our opinion, this is due to too little differentiated data. Of the seven targets for which external data were available, the database for the 5-HT5A receptor was the smallest (720 molecules).

The QSPR model for BBB penetration was a binary classification model (1, molecule penetrates to brain; 0, no penetration). It was also created according to 10-CV. To evaluate the model, classification metrics like accuracy, precision, recall, F1 score, and Matthews correlation coefficient (MCC) were used (eqs 3–7). These results and confusion matrices for the training and test set are shown in Table 4 and Figure 2. We compared our results on the test set with the recent article on BBB penetration,24 and our model resulted in more accurate predictions. Supporting Information S2 provides a detailed description of these results.3456where TP = true positive, TN = true negative, FP = false positive, and FN = false negative.7

Confusion matrices for training and test sets: blood–-brain barrier QSPR model.

## Section: Results and Discussion › Applicability Domain

The major challenge that researchers face in developing QSAR or QSPR models is the scarcity of data. Based on the available data, the model predicts correctly within the relevant ranges of descriptors. For these reasons, SerotoninAI with each prediction provides information on whether the studied compound is within the applicability domain (AD) or not. Naturally, within-AD predictions are characterized with higher accuracy even though the compound is unknown to the system, namely, beyond the training data.

The AD was obtained based on the 10 most important descriptors for each model. The importance ranking of the descriptors was obtained using SHAP analysis. SHAP (Shapley Additive Explanations) is a method used to explain complex AI/ML models. It is based on a concept called the Shapley value, introduced by Lloyd Shapley in 1952.39 Shapley, who was distinguished for his input in game theory by the Nobel Memorial Prize in Economic Sciences in 2012, focused on how to fairly divide rewards from the game among cooperating players. The solution for the analyzed problem should allow for splitting the reward of the team among all players in a proportional way to its contribution to the result and at the same time fulfill criteria of efficiency, additivity, symmetry, and null player presence detection. The unique solution for that problem is the Shapley value which divides the reward based on each player’s marginal contribution, ensuring fairness. In the realm of predictive modeling, this framework can be adapted to assess the incremental contribution of each input variable of the model to the predicted outcome.40 In this study, we employed SHAP analysis to examine the overarching influence of each variable, considering both the magnitude and the direction (high or low values of the variable) of its impact on the final prediction. This analysis was conducted in Python environment, leveraging a framework developed by Szlęk,41 further augmented with a wrapper for the mljar package. Summary plots of SHAP analysis for each obtained model are presented in Supporting Information S3, except for the HIA model, where the entire analysis was described in previous article.10 The values of these descriptors in the training set were transformed via Min–Max normalization. A compound is under AD if seven descriptors are in the range between minimum and maximum values of the training set. Figure 3 presents examples of compounds within and outside the applicability domain.

A comparison of the molecule’s applicability domains. (Left) A molecule within the applicability domain. (Right) A molecule out of the applicability domain. The gray area indicates the application domain.

## Section: Results and Discussion › Application Development

SerotoninAI was developed using Streamlit, an open-source Python library that simplifies the process of developing web applications. It enables developers to create interactive and user-friendly web applications using Python scripts.42 Our app includes pharmacological descriptions for each biological target and a medical and biopharmaceutical introduction to intestinal permeability and blood–brain barrier based on literature data.7−9,43 This enables scientists to better understand the mechanisms of action of these receptors and identify potential targets for new drugs. This knowledge can accelerate the drug discovery process, enabling scientists to design compounds with the desired pharmacological properties. The graphics page was enhanced with images created using Canva software.44

## Section: Implementation

SerotoninAI operates in several modes. The user can obtain predictions for the target’s affinity or class of HIA and BBB, either for a single compound or based on a collection of molecules represented by a CSV file, the so-called batch mode. However, due to limited resources provided by the Streamlit server, we encourage users to run batch mode locally on their own machines. From the user’s perspective, the model makes predictions based on SMILES, imported directly from the DrugBank/ChEMBL/ZINC without a specific structure curation. In the case of a CSV file, compounds should be represented in a column named “smiles”. There is also the possibility to draw molecules and obtain particular SMILES.45

Another feature of the application is to obtain a prediction for one biological target only, multiple user-selected targets, or all of them at once. Depending on the research needs, scientists may choose which serotonin receptors are relevant. This mode works with only a CSV file. It is worth remembering that with more molecules and more targets under study, the prediction time increases. The result of the predictions for multiple molecules is a downloadable file with ready-made predictions. As in the case of individual predictions for a single target, information about the applicability domain appears. In the case of batch mode, it takes the values “True” or “False”, where “True” means that the tested compound is in the AD defined in section 2.4.

## Section: Conclusion

The developed SerotoninAI application is publicly available AI-based software for obtaining affinity and permeability predictions for the intestinal wall and blood–brain barrier. The use of such predictions for serotonin receptors and transporters can significantly accelerate the time to find new compounds with potential pharmacological activity, mainly in the field of central nervous system diseases. This application, governed by the GNU General Public License version 3,20 comes with no liability from the authors for the obtained results. The published version of the app is not password protected; neither is the data privacy ensured. For the latter, the user must download the source code and install the app in the controlled environment.

Limitations due to the small amount of data to create models for several serotonin receptors (5-HT1E, 5-HT1E, and 5-HT5B) will be overcome when more data about ligands for these receptors are published. SerotoninAI will be updated on an ongoing basis for at least 2 years when larger databases become available and/or better predictive models can be obtained. Due to limited resources available to streamlit applications, batch mode computations should be run locally.


---

# Synergizing quantum techniques with machine learning for advancing drug discovery challenge

- **Authors:** Zhiding Liang, Zichang He, Yue Sun, Dylan Herman, Qingyue Jiao, Yanzhang Zhu, Weiwen Jiang, Xiaowei Xu, Di Wu, Marco Pistoia, Yiyu Shi
- **Issuer:** Scientific reports
- **Type:** Scientific article
- **Published:** 2024-12-28
- **Language:** en
- **DOI:** 10.1038/s41598-024-82576-4
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39732935/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

The Quantum Computing for Drug Discovery Challenge, held at the 42nd International Conference on Computer-Aided Design (ICCAD) in 2023, was a multi-month, research-intensive competition. Over 70 teams from more than 65 organizations from 12 different countries registered, focusing on the use of quantum computing for drug discovery. The challenge centered on designing algorithms to accurately estimate the ground state energy of molecules, specifically OH+, using quantum computing techniques. Participants utilized the IBM Qiskit platform within the constraints of the Noisy Intermediate Scale Quantum (NISQ) era, characterized by noise and limited quantum computing resources. The contest emphasized the importance of accurate estimation, efficient use of quantum resources, and the integration of machine learning techniques. This competition highlighted the potential of hybrid classical-quantum frameworks and machine learning in advancing quantum computing for practical applications, particularly in drug discovery.

## Section: Introduction

The first ACM/IEEE Quantum Computing for Drug Discovery Challenge (QCDDC’23) at the 42nd ICCAD in 2023 presented a pioneering platform for participants to design quantum computing algorithms. The contest, with a focus on estimating molecular energy for drug discovery, specifically targeted the ground state energy estimation of the OH+ molecule. Teams, leveraging the IBM Qiskit platform in the NISQ era, faced the challenge of achieving accurate results under noisy and resource-limited conditions1,2. This competition highlighted the significance of integrating quantum computing with machine learning techniques and underscored the potential of hybrid classical-quantum frameworks in solving complex, real-world problems in the pharmaceutical domain.Fig. 1(a) The top part shows an overview of the cross-study of quantum computing and classical machine learning techniques. (b) The bottom part shows the comprehensive performance metrics and the performance of the top eight teams in this year’s challenge.

The aim of QCDDC’23 is to propel quantum computing solutions to meet critical real-world challenges, with this year’s focus on drug discovery. By integrating with classical AI/ML/optimization techniques, the challenge aims to make significant contributions to the field of drug discovery. A key aspect of this endeavor is the estimation of the ground state energy of molecules3,4, a crucial but extremely challenging task for classical computers5. Current NISQ machines also face numerous factors affecting the outcomes of quantum algorithms. However, a scalable hybrid classical-quantum framework could greatly enhance both the reliability and efficiency of this process, potentially revolutionizing the approach to drug development and design. This challenge represents a significant stride in merging quantum computing with pharmaceutical research, opening new avenues for medical breakthroughs.

QCDDC’23 is the first competition related to quantum computing held at a top venue conference in computer science. The initiative received robust support from the Association for Computing Machinery Special Interest Group on Design Automation, the Institute of Electrical and Electronics Engineers Council on Electronic Design Automation, Dorahacks, and JPMorgan Chase & Co. Over 70 spirited teams from more than 65 esteemed organizations converged to take part in this cutting-edge challenge. Contestants are tasked with designing and implementing an open-source quantum algorithm focused on calculating the ground state energy of the OH+ molecule. Unlike other challenges that solely emphasize accuracy, the proposed quantum algorithm in QCDDC’23 must be deployable and executable on IBM Qiskit’s platform, with special consideration of the noise model calibrated from real quantum computers. Entries will be evaluated based on accuracy, and quantum resource consumption, including the number of shots and circuit duration. Therefore, QCDDC’23 was to design algorithms to accurately estimate molecular energy using quantum computing6,7consider the real machine noisy environment and implement on the IBM Qiskit platform8. Participants in this challenge are encouraged to innovate at the intersection of machine learning and quantum computing, specifically targeting the unique challenges of the NISQ era. A promising approach is the development of hybrid classical-quantum frameworks, which utilize a limited number of qubits more effectively by sacrificing affordable classical computational costs9. Additionally, exploring machine learning-based ansatz (architecture) search schemes could lead to the discovery of optimal quantum circuits with minimized circuit depths, tailored to the constraints of limited decoherence time10–12. Another significant area is the creation of error mitigation techniques aimed at bolstering the reliability of quantum circuits in noisy environments13,14. These efforts are essential for advancing the practicality and applicability of quantum computing technologies. The key ingredients to the success of the contest task include preprocessing (problem dimension reduction), circuit design and optimization, and post-error mitigation. The successful submissions considered these three steps reflected comprehensively in the scoring of the shot, circuit duration, and accuracy. In the recently concluded rankings based on final scores shown in Fig. 1. The top eight teams, along with the innovation award recipient, were invited to the 42nd International Conference on Computer-Aided Design to receive their awards.

This paper comprehensively discusses QCDDC’23 from various perspectives. Initially, it delves into the motivations and objectives behind organizing the competition, followed by a detailed introduction to the contest’s setup, including the chemistry-oriented contest problem, data, and evaluation methods. Furthermore, the paper discusses the outcomes of the winning teams, provides an in-depth analysis of innovative designs, and projects future directions for improvements in quantum computing challenges. Particularly, it elaborately describes the efficient and accurate co-design of classical-quantum computing on superconducting quantum computing platforms, highlighting the advancements and potential in this burgeoning field.

The Hamiltonian of the molecule, the source code of the top-eight teams and innovation award team, together with the unified evaluation method, and all other additional information about the contest can be accessed at https://qccontest.github.io/QC-Contest/index.html.

(a) The top part shows an overview of the cross-study of quantum computing and classical machine learning techniques. (b) The bottom part shows the comprehensive performance metrics and the performance of the top eight teams in this year’s challenge.

## Section: Results

Fig. 2The figure summarizes innovative optimization techniques utilized by the top 3 teams.

In this section, we examine the outcomes using various performance indicators. We delve into the final scores of the teams, offering insights into their achievements. This is followed by an in-depth analysis of overall performances, focusing on how different algorithms and frameworks impact detection accuracy, the total shot count, and the circuit’s operational duration, the detailed scores of teams in terms of each metric are shown in Fig. 3.Fig. 3Comprehensive performance analysis of 20 teams, showcasing overall scores, accuracy percentages, quantum computational resource cost, and grading scores for algorithm design. The detailed scores and performances can be accessed at https://qccontest.github.io/QC-Contest/Winners.html.

The figure summarizes innovative optimization techniques utilized by the top 3 teams.

Comprehensive performance analysis of 20 teams, showcasing overall scores, accuracy percentages, quantum computational resource cost, and grading scores for algorithm design. The detailed scores and performances can be accessed at https://qccontest.github.io/QC-Contest/Winners.html.

This figure details the quantum resource costs associated with the top 20 participating teams in a recent quantum computing challenge. The data is meticulously divided into two primary categories for each team: the number of quantum shots executed, which indicates the total count of quantum circuit executions, and the circuit duration, reflecting the time complexity of the quantum operations. This breakdown provides a comprehensive view of the efficiency and computational demands of each team’s approach to tackling quantum computational tasks.

## Section: Results › Top 3 designs

This figure details the quantum resource costs associated with the top 20 participating teams in a recent quantum computing challenge. The data is meticulously divided into two primary categories for each team: the number of quantum shots executed, which indicates the total count of quantum circuit executions, and the circuit duration, reflecting the time complexity of the quantum operations. This breakdown provides a comprehensive view of the efficiency and computational demands of each team’s approach to tackling quantum computational tasks.

## Section: Results › Top 3 designs › 1st place team

The first team leverages variational quantum eigensolve and provides innovative optimizations in ansatz design, parameter training, noise mitigation, as well as VQE-specific optimizations, as shown in Fig. 2 (a).

Specifically, to search for hardware-efficient ansatz with native gates, QuantumNAS11 SuperCircuit is trained and utilized. QuantumNAS reduces quantum resource usage by leveraging a SuperCircuit to efficiently evaluate potential quantum circuits using classical simulations. This allows for noise-adaptive evolutionary searches and iterative pruning. This technique minimizes quantum computation resource usage without compromising circuit robustness, which is pivotal for NISQ devices. With classical modeling and optimization, QuantumNAS trades affordable classical resources for more efficient and scalable quantum circuit design. The team optimizes the circuit depth and number of parameters by setting a threshold for the expectation value (−76) and selecting the shallowest circuit that achieves the threshold. After selecting the ansatz, the team proposes a novel noise-aware parameter training technique - ResilienQ, which leverages a differentiable classical simulator to acquire intermediate results and enables back-propagation with noisy final outputs from quantum circuits. This methodology synergistically combines the noise awareness of real quantum machines with the differentiability of classical simulators, enhancing the robustness and efficiency of training. To further reduce circuit depth and complexity, the team adopts an iterative gate pruning process, which involves removing gates with near-zero rotation angles and replacing gates with angles close to 180 degrees with their non-parameterized counterparts, such as replacing RX(\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\pi$$\end{document}π) with X. As a result of the pruning process, the ansatz primarily consists of X gates.

To make the algorithm viable and practical on noisy NISQ quantum hardware, the team adopts three error mitigation techniques in post-processing: noise-aware qubit mapping, measurement noise mitigation, and Zero-noise Extrapolation (ZNE). Noise-aware qubit mapping determines the best qubit set based on the noise calibration information. Measurement noise mitigation with the 0–1 measurement error matrix obtained from noise calibration is used to reduce measurement errors. Zero-noise extrapolation is applied to further reduce the incoherence errors. These techniques collectively improve detection accuracy. Additionally, the team employs VQE-specific optimizations such as Pauli string grouping, novel coefficient-aware shot allocation, and Pauli string pruning. These optimizations reduce the number of required measurements and variance in results by up to 77%. The first-place team achieves an accuracy of 99.893% with 1800000 shots in 138.667 seconds.

## Section: Results › Top 3 designs › 2nd place team

The second team proposes a novel ansatz construction, an efficient Pauli grouping method, and reference state error mitigation15, as shown in Fig. 2 (b).

The team employs an innovative RY hardware-efficient circuit featuring linear qubit connections and parallel CNOTs to shorten the quantum circuit duration and thus achieve lower error rate on noisy hardware. Specifically, the circuit consists of interleving RY and CNOT gates as illustrated in the team’s report1\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\begin{aligned} |\Psi (\theta )\rangle = \prod _{l=k}^1 \left[ L_{R_y}^{(l)}(\theta )L_{\text {CNOT}}^{(l)}\right] L_{R_y}^{(0)}(\theta )|\phi \rangle \end{aligned}$$\end{document}|Ψ(θ)⟩=∏l=k1LRy(l)(θ)LCNOT(l)LRy(0)(θ)|ϕ⟩where k is the total number of layers, and the layers are defined by the team as2\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\begin{aligned} L_{\text {CNOT}}^{(l)}= & \prod _{j=\frac{N}{2}-1}^{1} \text {CNOT}_{2j,2j+1} \prod _{j=\frac{N}{2}}^{1} \text {CNOT}_{2j-1,2j} \end{aligned}$$\end{document}LCNOT(l)=∏j=N2-11CNOT2j,2j+1∏j=N21CNOT2j-1,2j3\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\begin{aligned} L_{Ry}^{(l)}(\theta )= & \prod _{j=N}^{1} RY_j(\theta _{j}) \end{aligned}$$\end{document}LRy(l)(θ)=∏j=N1RYj(θj)Moreover, X gates are appended to specific qubits to handle edge cases.

Then, based on the observation that the ground state wavefunction of chemical systems is typically dominated by the HF state, the team performs Pauli grouping by combining terms such as XX and YY and reasons that these terms might have the same expectation value. This approach effectively reduces non-commutable terms and results in a total of 20 measurement groups, as opposed to 631 terms in the original Hamiltonian. Although the grouping and simplification of Pauli operators are not exact, they save quantum resources without compromising accuracy. The team further adopts reference state error mitigation to improve detection accuracy with minimal computational overhead. The second-place team achieves an accuracy of 99.93% with 240000 shots in 5024 seconds.

## Section: Results › Top 3 designs › 3rd place team

The third team adopts QASC (Quantum Architecture Search for Chemistry), a technique based on Monte Carlo Tree Search (MCTS) to efficiently determine the structure of variational quantum circuits for a specific task, as shown in Fig. 2 (c).

The iterative QASC process contains two phases: the learning phase, where a partition tree is built recursively to group the architectures with similar performance, and the search phase, where architectures are sampled, evaluated, and utilized to refine the boundaries in the learning phase in the next iteration. An important prerequisite of the QASC process is defining the search space and structure encoding. The team provides key insights into selecting hardware-efficient ansatz and structure encoding to improve the overall efficiency of finding a high-performance model. Specifically, the team determines the minimum number of trainable parameters (12) to achieve satisfactory performance. Additionally, the team notices the significance of the first qubit on detection accuracy, therefore always placing quantum gates on the first qubit. Moreover, the ansatz employs two primary building blocks consisting of basic gate operations: SX, RZ, and CNOT to ensure hardware efficiency. The single-qubit block combines two SX gates with an RZ gate, all operating on the same qubit. The two-qubit block is structured with a CNOT gate followed by an RZ rotation on the target qubit. In the iterative QASC process, classical statistical methods are integrated with quantum circuit structure search to improve performance under constrained quantum resources.

Following the searched circuit, post-optimization techniques are leveraged to further reduce resource usage and improve detection accuracy. Pauli grouping are used to reduce shrink the list of Pauli strings down to 39, and the total number of shots are reduced to 39\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\times$$\end{document}×shots. Given the limited complexity of searched circuit, the teams uses Qiskit’s default transpilation option with the heaviest optimization level (3) for transpilation optimization. The team further improves detection accuracy by adopting Zero-noise Extrapolation (ZNE). By conducting experiments, the team chooses appropriate noise scaling methods and extrapolation methods for each noise model. For FakeKolkata, FakeMontreal, and FakeCairo, the team sets scaling factors (1, 3, 5), (1, 3, 5, 7, 9) and (3, 5, 7), respectively. The team proposes average slope (AvS), a modified linear extrapolation, for FakeKolkata and FakeCairo, and the team uses Richadson extrapolation (Rich) for FakeMontreal. The third-place team achieves an accuracy of 99.732% with 858000 shots in 2080 seconds.

## Section: Results › Top 3 designs › Innovation award design

To encourage innovative solutions for the ground state energy estimation challenge, we established an Innovation Award. The winning team utilized the CAFQA9 method to achieve high-accuracy initializations for variational quantum algorithms. Traditional VQA methods often initialize parameters directly on a quantum machine or use HF initialization, both of which are prone to noise and tend to have lower initialization accuracy on NISQ hardware. In contrast, CAFQA initializes VQA parameters by searching in an efficient and scalable way through the classically simulable portion of quantum space, known as the Clifford space, using discrete search optimization. This noise-free starting state is closer to the optimal solution, so the VQA converges much faster. Even without additional post-processing techniques, the team achieved a high accuracy of 98.07% with minimal resource utilization. CAFQA serves as an important example of synergy between quantum and classical computing to boost quantum capability in the NISQ era and beyond.Fig. 4This figure details the quantum resource costs associated with the top 20 participating teams in a recent quantum computing challenge. The data is meticulously divided into two primary categories for each team: the number of quantum shots executed, which indicates the total count of quantum circuit executions, and the circuit duration, reflecting the time complexity of the quantum operations. This breakdown provides a comprehensive view of the efficiency and computational demands of each team’s approach to tackling quantum computational tasks.

This figure details the quantum resource costs associated with the top 20 participating teams in a recent quantum computing challenge. The data is meticulously divided into two primary categories for each team: the number of quantum shots executed, which indicates the total count of quantum circuit executions, and the circuit duration, reflecting the time complexity of the quantum operations. This breakdown provides a comprehensive view of the efficiency and computational demands of each team’s approach to tackling quantum computational tasks.

## Section: Results › Overall comprehensive performances

The champion team, Team MIT-EPiQC-CMU-Duke, excelled with an impressive accuracy score of 99.893. In terms of quantum resource cost, they utilized 1, 800, 000 shots, with an average circuit duration of 138.667dt. Their approach borrowed the idea of neural architecture search, one of the most widely studied machine learning tasks, enabling automatic optimization of quantum circuit structures. They also implemented noise-aware parameter training using feedback from a noisy simulator, effective noise-aware qubit mapping, and measurement noise mitigation using a 0-1 error matrix from noise calibration. The Zero Noise Extrapolation (ZNE) technique they employed significantly reduced the impact of severe noise in the quantum environment, enhancing the reliability of quantum algorithms. Similar to neural network pruning, they further introduced quantum gate pruning to remove gates with negligible rotation angles and substituted gates with angles close to 180 degrees with corresponding non-parameterized gates, like replacing a \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\text{RX}(\pi )$$\end{document}RX(π) gate with X gate, to reduce circuit depth. This strategy was pivotal in achieving the shortest circuit duration among the teams. Moreover, they incorporated Pauli grouping and Pauli string pruning into their framework to reduce the number of shots needed. The runner-up, Team TQL, finished with an accuracy score of 99.93, using 240, 000 shots and a circuit duration of 5024dt. They also applied Pauli grouping to minimize the number of shots, and for error mitigation, they employed state error mitigation with an HF state as the reference. Their approach involved manual and iterative adjustments based on a hardware-efficient ansatz, which, although effective, was not as comprehensive and generic as the machine learning and genetic algorithm-based approach of Team MIT-EPiQC-CMU-Duke. The third-place team, Team QuantumLoop, introduced an iterative algorithm for circuit architecture search, divided into a learning phase and a search phase. The learning phase involved building a partition tree for sampling in the search phase, which then used the trained samples from the learning phase. This method resulted in a final circuit duration of 2080dt. They also utilized ZNE and Pauli grouping methods, along with a machine learning-based technique for measurement error mitigation, to further reduce noise introduced during measurement.

## Section: Results › Details in quantum resource cost

One of the key metrics, the quantum resource cost, has been the focus of intense efforts, particularly in the aspect of reducing the number of shots and the circuit duration required for quantum computations. Teams have employed various strategies to achieve this goal, the detailed score in terms of the number of shots and the circuit duration are shown in Fig. 4.

To reduce the number of shots, teams implemented technologies including the tapering method, which reduces the number of Pauli strings in the quantum circuit16. This technique involves identifying symmetries in the quantum system that can be exploited to simplify the circuit without losing computational accuracy. Another popular approach is the use of Pauli grouping strategies17. By cleverly grouping Pauli operators, teams have been able to significantly reduce the number of measurements needed, thereby lowering the shot count. This not only saves computational resources but also enhances the efficiency of quantum algorithms. The contextual subspace method represents another innovative approach, where classical computers are used to assist in the computation of certain parts of the problem18–20. This hybrid quantum-classical technique leverages the strengths of both computing paradigms, optimizing the use of quantum resources while relying on classical systems for more manageable computations.

When it comes to minimizing the duration of quantum circuits, most teams have turned to machine learning-based methods for circuit structure search. These algorithms utilize classical computation power to efficiently explore the vast space of possible circuit configurations, identifying those that offer the best trade-offs between accuracy and execution time. The effective collaboration between quantum and classical systems enables promising result with limited quantum resources. Some teams have further enhanced their approaches by incorporating advanced state initialization methods, such as the Hartree-Fock technique. This method provides a good starting point for quantum computations, reducing the overall circuit depth and, consequently, the duration. Given the short coherence time of NISQ devices, shorter circuit durations allow for the execution of deeper circuits. Therefore, the algorithms proposed in the challenge have the potential to address more complex molecules on NISQ hardware.

The team that achieved the best overall performance went a step further by analyzing the characteristics of quantum pulses at a granular level. They proposed an approximation method for basic gates, which allowed them to optimize the pulse sequences used in the quantum circuits. This innovation led to significant improvements in the duration metric, setting a new standard for efficiency in quantum computing.

## Section: Discussion

In this paper, we introduce the first ACM/IEEE Quantum Computing for Drug Discovery Challenge, which focuses on the fundamental problem of molecular energy estimation within drug development issues. Specifically, we discuss the challenge problem, the chemical background, and the significance of applying quantum computing in this application. We further elaborate on how the molecular Hamiltonians, which serve as the dataset, were obtained, the metrics for comprehensive performance evaluation, and the settings for the platforms and noise models used. We also showcase the designs of the participating teams and analyze the frameworks proposed by the teams. The analysis of the results obtained by the participating teams is presented along with an in-depth discussion, aimed at further contributing to research and engineering efforts in the application of quantum computing in drug development.

The ACM/IEEE Quantum Computing Challenge marked the first quantum computing themed contest held at a top international computer science conference. This event provided a platform for teams to showcase their research and advancements in the intersection of machine learning and quantum computing technologies. Looking ahead, the integration of quantum computing technologies and machine learning, including but not limited to applications in drug discovery, aims to enable quantum computing to aid classical machine learning or for classical machine learning to benefit quantum computing. It is important to note that the goal is not to replace classical computing and machine learning with their quantum counterparts. Instead, the focus is on designing hybrid frameworks that complement each other21–24, addressing problems that are previously challenging or impossible for classical computing to solve independently.

## Section: Methods

(a) Illustrates a molecular model of the OH+ ion, showcasing its atomic structure and bonding configuration. (b) Presents an example of a Variational Quantum Eigensolver (VQE) circuit, demonstrating the quantum computational approach to solving molecular energy states.

## Section: Methods › Contest problem

In this subsection, we first provide a comprehensive background of the contest, setting the stage for a deeper understanding of its relevance and significance. Following this, we delve into the objectives of the contest, detailing the specific goals and aspirations that it aims to achieve. This part of the discussion will focus on the intended impact of the competition, the challenges it seeks to address in the field, and how it aligns with broader trends and needs in the industry. By establishing this context, we lay a foundational understanding that enriches the reader’s appreciation of the contest’s significance and the innovations it fosters.

The landscape of drug discovery has been dynamically evolving, powered persistently by state-of-the-art innovations25,26. The key to these advancements is the quest to decipher complex molecular interactions that stand at the heart of transformative medical treatments27. Within the plethora of tools that have risen to prominence, computational methodologies hold a distinctive place, acting as the linchpin in understanding and navigating the labyrinthine world of molecules. Particularly, machine learning, with its prowess in unearthing deep-seated patterns and refining solutions, has emerged as an indispensable asset28,29. Yet, the real game-changer beckons at the confluence of quantum computing and machine learning30. This connection, while nascent, is bursting with potential and promises to overhaul the very essence of drug discovery. Not only does it unlock doors to challenges once believed to be insurmountable for traditional computing paradigms, but it also augments our capacities in predicting and fathoming molecular behaviors with a so far unimagined precision.

A critical molecule in the pharmacological landscape is the hydroxyl cation (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\cdot$$\end{document}·OH+)31. This cation is more than just a molecular entity; it’s a central axis for numerous drug interactions. Its high reactivity is linked to oxidative stress, resulting in a range of health conditions, from neurodegenerative disorders and cardiovascular diseases to cancer31,32. Beyond its pathogenic roles, the hydroxyl cation is also integral to the efficacy of many drugs. With the development of quantum computing, we can potentially achieve a deeper understanding of the interactions and effects of molecules like the hydroxyl cation, accelerating breakthroughs in therapeutic developments33,34. Understanding the quantum mechanics of the hydroxyl cation deeply impacts drug discovery. The key is determining its ground state energy, a foundational element for modeling complex drug interactions. The quantum domain, constrained by qubit numbers and error rates, poses challenges, particularly for larger molecules18. The hydroxyl cation, with its smaller size, fits within current quantum computing capabilities, making it an ideal focus for quantum simulations. Moreover, the hydroxyl cation is selected to ensure that the competition target presents sufficient difficulty and complexity, while allowing us to evaluate accuracy, resource efficiency, and innovation in a clear and consistent manner. We believe that innovations on the simpler hydroxyl molecule not only address immediate research needs but also lay the groundwork for future exploration of larger molecular structures, which are crucial for advancing drug development.

In the realm of quantum chemistry and drug discovery, the significance of accurately estimating the ground state energy of molecules like OH+ cannot be overstated. The ground state energy is a critical indicator of a molecule’s chemical properties, including its stability and potential reactivity. For drug discovery, understanding these properties at the quantum level allows for the design of molecules with desired therapeutic effects and minimal side effects. Particularly for complex molecules, traditional computational methods may fall short, making quantum computations a promising alternative. This accurate quantum mechanical characterization of molecular systems opens new avenues in rational drug design, potentially leading to more effective and targeted therapies.

This approach is pivotal for the evolution of drug discovery in the quantum age. The drug discovery pipeline is a multi-step process and each task is critical to developing new therapeutics efficiently and effectively. Quantum computing has the potential to enhance not only the ground state energy estimation but also other stages such as molecular design35. Even under the limitations of current NISQ devices, hybrid classical-quantum models effectively leverage affordable classical computational resource and harness quantum advantages to tackle challenges with unprecedented computational power. This synergy between quantum and classical approaches hold the potential to advance the drug discovery pipeline in a practical and scalable way.

## Section: Methods › Contest problem › Contest objective

The ACM/IEEE Quantum Computing Challenge marked the first quantum computing themed contest held at a top international computer science conference. This event provided a platform for teams to showcase their research and advancements in the intersection of machine learning and quantum computing technologies. Looking ahead, the integration of quantum computing technologies and machine learning, including but not limited to applications in drug discovery, aims to enable quantum computing to aid classical machine learning or for classical machine learning to benefit quantum computing. It is important to note that the goal is not to replace classical computing and machine learning with their quantum counterparts. Instead, the focus is on designing hybrid frameworks that complement each other, addressing problems that were previously challenging or impossible for classical computing to solve independently.

The objective of the Quantum Computing for Drug Discovery Challenge (QCDDC’23) is to advance the application of quantum computing in the field of pharmaceutical research. Contestants are tasked with developing an innovative quantum algorithm capable of accurately calculating the ground state energy of the molecule, and the hydroxyl cation is selected in the contest as an example. This challenge not only focuses on achieving precision in quantum computations but also emphasizes the practical implementation of these algorithms, considering the noise models of real quantum computers. Successful algorithms should demonstrate efficiency in quantum resource usage, including optimizing the number of shots and circuit duration, essential for feasible quantum simulations in drug discovery. This challenge aims to bridge the gap between theoretical quantum computing and practical applications in medicinal chemistry, potentially revolutionizing the approach to pharmaceutical development.

## Section: Methods › Evaluation

In this subsection, we first introduce the designated platform and the noise model derived from an actual quantum system. Following that, the evaluation metrics used to assess the overall performance of each team’s design will be discussed. Additionally, the evaluation method, which allows teams considerable flexibility in designing their methods based on the platform, will also be presented.

(a) Illustrates a molecular model of the OH+ ion, showcasing its atomic structure and bonding configuration. (b) Presents an example of a Variational Quantum Eigensolver (VQE) circuit, demonstrating the quantum computational approach to solving molecular energy states.

## Section: Methods › Evaluation › Platform, system and noise model from real quantum processor backend

We acknowledge the use of IBM Quantum services in this competition. Qiskit8, primarily developed by IBM, is an open-source quantum computing framework. It offers tools for creating and manipulating quantum programs and running them on prototype quantum devices and simulators. Designed with modularity in mind, Qiskit provides components that span all aspects of quantum computing, from foundational elements to advanced quantum algorithms. Noise presents a significant challenge in the field of contemporary quantum computing36–38. Therefore, we urge all participants to consider inherent noise when designing their quantum algorithms or circuits. Qiskit8offers tools for simulating quantum algorithms or circuits as they would be executed on actual quantum devices, including the associated noise. Since not everyone has access to real machines, for fairness, we require all participants to train their models on a given noise model, which will be released on the registration deadline date. Simulating a quantum system with an integrated noise model is crucial for understanding the potential performance of quantum algorithms on current NISQ devices36,39. We recognize that while participants might be inclined to optimize basis gates at the pulse level to shorten the duration of the quantum circuit and conserve quantum resources40, characterizing a time-dependent noise model from a real quantum machine poses unsolved challenges in preparation for this quantum computing drug discovery challenge. Regrettably, we must resort to using the standard gate-based noise model for evaluating circuits. The noise models from ibmq_cairo, ibmq_kolkata, and ibmq_montreal were integrated into the testing process, giving participants a genuine feel of practical hardware conditions.

## Section: Methods › Evaluation › Evaluation metrics

Accuracy of ground state energy estimation In quantum computing, accuracy in estimating the ground state energy of quantum systems is paramount. This is a key problem in quantum mechanics and quantum chemistry, with implications in material science, pharmaceuticals, and beyond. Accurate estimations are essential for understanding the properties and behaviors of complex quantum systems.

The precision of ground state energy estimation is measured using the following formula:4\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\begin{aligned} E_{\text {score}} = \left( 1 - \left| \frac{E_{\text {estimated}} - E_{\text {ideal}}}{E_{\text {ideal}}} \right| \right) \times 100\% \end{aligned}$$\end{document}Escore=1-Eestimated-EidealEideal×100%where \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{\text {estimated}}$$\end{document}Eestimated represents the average result from the participant’s framework across ten different computational seeds, and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{\text {ideal}}$$\end{document}Eideal is the objective value determined using classical computational methods.

This scoring mechanism allows participants to earn up to 100 points, with a higher score indicating greater accuracy. The score is a percentage that reflects the closeness of the estimated energy to the ideal value. This component challenges participants to optimize their algorithms and enhances understanding of the quantum systems being studied. It emphasizes the need for rigorous testing against classical benchmarks, promoting accuracy and reliability in quantum research.

Efficient utilization of quantum resources The competition also evaluates participants on their efficient use of quantum resources, which is divided into two critical aspects: the total number of quantum circuit shots and circuit size.

Total Number of Shots of Quantum Circuits: The total number of shots for quantum circuits is a pivotal metric for assessing resource efficiency. The maximum allowable number of shots is 3,786,000, correlating to the unoptimized problem Hamiltonian consisting of 631 Pauli strings, with a default setting of 6,000 shots per measurement prior to optimization. This constraint encourages participants to optimize their quantum measurements efficiently. The scoring for quantum circuit shots is as follows:Under 1,800,000 shots: Participants achieving this threshold will be awarded 25 points, incentivizing the reduction of quantum resources used.Between 1,800,000 and 3,786,000 shots: Points are allocated on a sliding scale, starting from 15 points for 3,786,000 shots and increasing up to 25 points for 1,800,000 shots, calculated using the formula: 5\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\begin{aligned} 15 + \frac{(3,786,000 - n)}{(3,786,000 - 1,800,000)} \times 10 \end{aligned}$$\end{document}15+(3,786,000-n)(3,786,000-1,800,000)×10 where \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$n$$\end{document}n is the total number of shots utilized. This formula encourages participants to minimize the number of shots used, rewarding efficiency with higher scores.Circuit Size (Duration): Circuit size, or duration, is another vital metric, reflecting the complexity and efficiency of the quantum circuits developed. The competition ranks participants based on the compactness and execution speed of their circuits, with the top rank earning 15 points. Subsequent ranks are awarded points with a decreasing scale, highlighting the importance of optimizing circuit design for both performance and resource conservation.

Efficient resource utilization is vital not just technically, but also economically and ecologically, encouraging sustainable development in quantum computing technology.

Technical reflection and description In addition to the quantitative evaluation of participants’ submissions in the quantum computing competition, a significant emphasis is placed on a qualitative assessment. This assessment revolves around a comprehensive introspection and articulate presentation of the methodologies employed by the participants. It’s not just about what was achieved, but also about how it was achieved and the thought process behind it.

The qualitative evaluation is segmented into several key areas:Innovation and Pre-processing Techniques: Participants are expected to clearly describe any innovative approaches or pre-processing techniques they have implemented. This could include unique methods of optimizing quantum circuits, novel approaches to problem decomposition, or creative algorithms that enhance the efficiency of the computation. The novelty and effectiveness of these techniques are of prime interest.Utilization of Classical Resources: Alongside quantum resource optimization, how participants have leveraged classical computing resources forms a critical part of their technical strategy. This includes, but is not limited to, the use of classical algorithms for preprocessing, data analysis, or hybrid quantum-classical computation approaches. A well-thought-out balance between quantum and classical resources can be indicative of a more sophisticated and practical approach to problem-solving in the realm of quantum computing.Technical Novelty: The degree of technical innovation will be a key factor. This includes the development of new methods or the novel application of existing techniques to the challenges presented in the competition. Originality and creativity in problem-solving are highly valued.Logical Coherence: The clarity and logic of the technical narrative are paramount. Participants should strive to present their methodologies and thought processes in a manner that is both coherent and comprehensible. This includes a clear articulation of the steps taken, logical progression of ideas, and a well-structured presentation of their work.This reflective and descriptive component is allocated a total of 10 points. The allocation of these points will be judiciously carried out by a panel of three expert graders. The graders will evaluate submissions based on the depth of self-reflection, technical novelty, logical coherence, and other salient factors. The aim is to reward not only technical proficiency but also innovation, thoughtful analysis, and clarity of expression. This aspect of the evaluation underscores the significance of not only achieving results but also understanding the journey to those results. It encourages participants to think critically about their methodologies, fostering a culture of continuous learning and improvement.

## Section: Methods › Evaluation › Evaluation method

We delineate a comprehensive framework designed to ensure participants effectively navigate the complexities of quantum computing, particularly focusing on the integration of noise models and system models reflective of real-world quantum systems. To facilitate a standardized yet flexible approach in the competition, the following components are detailed:

Upon commencement, participants are provided with a detailed noise model and system model, meticulously crafted to mimic the intricacies of a real quantum environment. These models serve as the foundation upon which teams will build and evaluate their quantum computing solutions. A crucial requirement for participants is adherence to the topology map of FakeMontreal. This topology, representative of a quantum computing architecture, sets the stage for realistic simulation and testing of quantum algorithms, ensuring that designs are not only innovative but also applicable within the constraints of actual quantum hardware. To accommodate a diverse range of strategies and to reflect the variability in real quantum systems, we offer participants the choice among three distinct noise models extracted from FakeCairo, FakeMontreal, and FakeKolkata. Each model presents unique challenges and characteristics, allowing teams to tailor their approaches based on the specific nuances of these simulated environments. In the spirit of promoting robustness and adaptability in algorithmic design, we recommend participants utilize specific seeds for algorithmic processes, transpiling, and measurement within Qiskit. This guidance is aimed at fostering consistency and fairness in the evaluation process. The final scoring will be derived from the average outcomes across 10 distinct seeds: five from a provided list of seeds and the other five from a concealed set of test seeds. This methodology ensures that assessments are comprehensive, accounting for variability and promoting strategies that are resilient across a spectrum of conditions.

The overarching objective of this evaluation method is to challenge teams to devise quantum computing solutions that are not only theoretically sound but also practically viable within the constraints of current quantum technology. By navigating the specified topology, choosing among the provided noise models, and adhering to a structured approach for seed selection and result averaging, participants demonstrate their capacity to develop strategies that balance innovation with practical applicability. This detailed approach to evaluation underscores the competition’s commitment to advancing the field of quantum computing by fostering an environment where theoretical knowledge and practical skills converge, ultimately leading to the development of solutions that push the boundaries of what is currently achievable in quantum computing.Fig. 5(a) Illustrates a molecular model of the OH+ ion, showcasing its atomic structure and bonding configuration. (b) Presents an example of a Variational Quantum Eigensolver (VQE) circuit, demonstrating the quantum computational approach to solving molecular energy states.

(a) Illustrates a molecular model of the OH+ ion, showcasing its atomic structure and bonding configuration. (b) Presents an example of a Variational Quantum Eigensolver (VQE) circuit, demonstrating the quantum computational approach to solving molecular energy states.

## Section: Methods › Dataset

The data provided for this challenge revolves around the central theme of drug discovery, focusing on the fundamental quantum mechanics of the hydroxyl cation (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\cdot$$\end{document}·OH), as shown in Fig. 5. As a pivotal entity in numerous drug interactions and physiological processes, an intricate understanding of the hydroxyl cation is crucial. To aid participants in this endeavor, we’ve curated a specialized dataset tailored to encapsulate the hydroxyl cation’s Hamiltonian.

The process for obtaining the Hamiltonian begins with a high-precision quantum chemical calculation of the molecule’s electronic structure. Sophisticated computational methods, such as Hartree-Fock or more advanced post-Hartree-Fock techniques, are utilized. These methods are crucial for providing an accurate and detailed representation of the electronic orbitals. In the Hartree-Fock method, the many-electron wave function of the molecule is approximated by a single Slater determinant, which simplifies the complex many-body problem. However, to capture electron correlation effects more accurately, post-Hartree-Fock methods such as Configuration Interaction (CI), Møller-Plesset perturbation theory (MP2), or Coupled Cluster Theory are often employed. These approaches involve sophisticated calculations to model the interactions and correlations between electrons, providing a more comprehensive understanding of the electronic structure. Once the electronic structure is accurately determined, the electron orbitals are then mathematically represented using fermionic operators. The transformation from fermionic operators to Pauli strings is achieved through techniques like the Jordan-Wigner or Bravyi-Kitaev transformations, which map the fermionic algebra onto the algebra of Pauli matrices. This mapping is essential for quantum simulations, as quantum computers natively understand operations in terms of Pauli matrices.


---

# The changing scenario of drug discovery using AI to deep learning: Recent advancement, success stories, collaborations, and challenges

- **Authors:** Chiranjib Chakraborty, Manojit Bhattacharya, Sang-Soo Lee, Zhi-Hong Wen, Yi-Hao Lo
- **Issuer:** Molecular therapy. Nucleic acids
- **Type:** Scientific article
- **Published:** 2024-08-08
- **Language:** en
- **DOI:** 10.1016/j.omtn.2024.102295
- **Source:** https://pubmed.ncbi.nlm.nih.gov/39257717/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractDue to the transformation of artificial intelligence (AI) tools and technologies, AI-driven drug discovery has come to the forefront. It reduces the time and expenditure. Due to these advantages, pharmaceutical industries are concentrating on AI-driven drug discovery. Several drug molecules have been discovered using AI-based techniques and tools, and several newly AI-discovered drug molecules have already entered clinical trials. In this review, we first present the data and their resources in the pharmaceutical sector for AI-driven drug discovery and illustrated some significant algorithms or techniques used for AI and ML which are used in this field. We gave an overview of the deep neural network (NN) models and compared them with artificial NNs. Then, we illustrate the recent advancement of the landscape of drug discovery using AI to deep learning, such as the identification of drug targets, prediction of their structure, estimation of drug-target interaction, estimation of drug-target binding affinity, design of de novo drug, prediction of drug toxicity, estimation of absorption, distribution, metabolism, excretion, toxicity; and estimation of drug-drug interaction. Moreover, we highlighted the success stories of AI-driven drug discovery and discussed several collaboration and the challenges in this area. The discussions in the article will enrich the pharmaceutical industry.Keywords: MT: Bioinformatics, drug molecules, artificial intelligence, drug discovery, deep learning, pharmaceutics

## Section: Introduction

Innovation is the backbone of the pharmaceutical industry. Innovation can create life-saving solutions, and it provides society with life-saving medicines. Therefore, it is essential to innovate new drug compounds and patent them. Presently, research is at the forefront of science, and it helps to invent and patent new drugs.1,2 Pharmaceutical industries are following this route to invent and patent new drugs. Through the drug discovery process, new drugs are discovered for diseases, even neglected diseases. Pharmaceutical companies are investing a considerable amount of money in this direction. However, the drug discovery and development process is very complex. A high level of expertise and various technologies have been used in drug discovery and development.3 Drug discovery requires a considerable amount of time. This process, known as from bench to bedside, encompasses the journey from the initial discovery of drug molecules to their market availability. It has been estimated that the from-bench-to-the-bedside process typically takes 10–15 years or more. Therefore, a new innovative technological landscape has emerged in the field of drug discovery. Innovative technologies help the pharmaceutical sector by providing faster methods of drug discovery. Recent advancements in innovative tools and technologies can make a massive difference in drug discovery and development. Today’s innovative tools and technologies have made drug discovery and development faster. Consequently, new technologies now provide a faster route to drug discovery. At the same time, the process is also more productive for the pharmaceutical industry. It is the utmost need for the pharmaceutical industry. At the same time, the pharmaceutical industry needs to be more productive in terms of drug discovery. The innovative technologies help to quickly foster a very productive way of drug discovery.1,4,5,6

The drug discovery and development procedure encompasses three major stages: drug discovery, preclinical development of drug molecules, and clinical development of the therapeutic molecule. Traditional approaches to drug discovery and development face considerable challenges. They are time consuming, expensive, and have low success rates. It have been noted that developing a new drug molecule costs approximately US$2.6 billion on average and takes more than 10–15 years to enter the market.7,8 A recent cost analysis of drug development showed that the capital cost of drug development is US$1.3. At the same time, the average out-of-pocket success cost is just US$200 million. Similarly, out-of-pocket failure costs US$1 billion. Therefore, a successful drug’s discovery cost can be reduced if we reduce the failure costs.9 The failure costs of drug discovery can be reduced by using new technology like AI. The capital cost of drug development can be used in new technology development to reduce the other costs and increase the chance of success. At the same time, the traditional method is still not optimal for finding a new drug for many diseases. Researchers worldwide have moved toward the new technological advancements to minimize these hurdles and challenges. At the same time, the pharmaceutical industry and its researchers are shifting from traditional approaches to new methods and using various technologies to foster innovation and improve outcome. They are using new computational technologies like artificial intelligence (AI), machine learning (ML), and deep learning (DL) to perform a new way drug discovery in a new way. These new technologies mitigate the cost and speed of the drug discovery procedure. At the same time, they are also more productive. Another disadvantage is that the traditional method of drug discovery is slow and labor intensive because it relies on identifying and improving existing compounds. In contrast, AI-based approaches can handle and solve the issue through the rapid and efficient design of new drug compounds.

Since the last decade, AI has been used in different areas of biological sciences, medical sciences, and general sciences. AI, also known as machine intelligence, directs computer systems' capability to learn from past data and input. AI is generally applied when a machine imitates cognitive behavior and behaves like a human. It is associated with the human brain’s learning and problem-solving capabilities.10 Due to massive multi-omics data and high-performance computer hardware availability, AI techniques were introduced as a fundamental application in various disciplines. Similarly, data digitalization has increased in the pharmaceutical sector, which has inspired the use of AI. At the same time, automation was enhanced, and AI was empowered to handle large volumes of data. Pharmaceutical industries have collaborated with the computational industries.11 In the last few years, progress has been made in drug discovery using AI-enabled drug discovery technologies. AI has also been used by drug discovery organizations, which has changed the drug discovery scenario in the last decade. Various AI techniques have been adopted in the different areas of drug discovery, such as virtual screening, target selection, and hit-to-lead generation. Other application areas are bioavailability prediction, retrosynthesis and reaction forecast, de novo drug design.3,7

Many AI techniques, like traditional ML and DL, are associated with drug discovery and development analyses. After Alan Turing’s Turing test in 1950, several AI-related breakthrough discoveries were made, and different AI-related milestone achievements were occasionally created (Figure 1A). However, developing different models was a significant process in drug discovery and development. Therefore, model architectures also evolved to mitigate the healthcare sector. Model architectures such as convolutional neural networks (CNNs), graph NNs, recurrent NNs (RNNs), and transformers, were also evolved. At the same time, researchers noted the paradigm shift from supervised learning to self-supervised learning and reinforcement learning in drug discovery and development.

This article discusses the recent advancement of drug discovery using AI to DL with different examples. At the same time, we discussed several success stories and collaborations for AI-driven drug discovery. The article also noted several challenges in AI-related drug discovery.

Timelines illustrate the milestone achievements of AI and milestone of AI-related achievements in the healthcare sector, including the pharmaceutical sector

(A) The timeline depicts the achievements of AI. (B) The timeline depicts the milestone of AI-related achievements in the healthcare sector, including the pharmaceutical sector.

## Section: AI: Our understanding

Different data resources in the pharmaceutical sector for AI-driven drug discovery

A schematic diagram shows different steps of drug discovery and development where AI and DL models have been successfully implemented

The basic architecture and framework of ANNs

It also illustrates basic architecture and framework differences of ANNs and DNNs. (A) The basic framework of ANN (B) The architecture of ANN which shows the input, weight, bias, and output. (C) The ANN with two hidden layers, h1 and h2. (D) An architecture of a DNN model. It has been noted that an ANN has one or two hidden layers, while DNN has several hidden layers.

ML and DL-based applications in different areas of drug discovery and development

A schematic diagram is depicted as an overall framework, visually demonstrating the application of AI technology in drug discovery

Different AI-designed drugs that enter clinical trials

Collaborations between pharmaceutical and technology companies for AI-enabled drug discovery and development

## Section: AI: Our understanding › Overview of AI

AI algorithms are widely used in different sectors, from government to business. AI has been applied from time to time in different domains in the healthcare sector, including the pharmaceutical sector (Figure 1B). Data digitalization has increased in every sector, including the pharmaceutical sector, during the last few years. Digitalization has assisted in solving complex clinical problems through data acquisition, scrutinizing, and applying knowledge. It was the motivation for using AI.12 At the same time, automation was undertaken to manage the large volume of data. AI can mimic human intelligence using advanced technologies that involve several advanced tools and network systems. Therefore, a paradigm shift has been noted in every sector, including the pharmaceutical sector. Different researchers have stated that the rapid advancement of AI-guided automation will ultimately transform society’s work culture.

## Section: AI: Our understanding › Data-driven AI

Data are required for any statistical inferences, including ML. Similarly, different models can be developed using data modalities. Data come in different forms, such as textual, image, and numerical. Extensive data analysis broadly transforms pharmaceutical and medicinal fields.13 Presently, data-driven digital transformation is noted in every sector, which is an emerging phenomenon.

In the pharmaceutical sector, digital transformation is swift and includes vast amounts of data. It has been noted that digital transformation through AI methods in the pharmaceutical sector is data driven. AI algorithms related to drug discovery depend on the pharmaceutical sector’s data. At the same time, AI model training data must be curated and accurate. Therefore, most pharmaceutical sector datasets are curated and accurate.14 Several data resources for AI model training in pharmacology sectors are the key components for drug discovery. The pharmaceutical sector’s data resources include high-quality datasets. These high-quality datasets are open resources. Therefore, these datasets are frequently used in drug discovery.

However, there is a long history of the use of different data-driven approaches in drug discovery. Recent advancement of ML and DL algorithms, data-driven approaches are used more in drug discovery and development.15 More advanced forms of DL take data-driven approaches to the next level, allowing them to handle more diverse and much larger datasets.15,16

These datasets are obtained from different data resources. Some data resources include ChEMBL, ChemDB, DGIdb, DrugBank, DTC, PubChem, and SIDER (Table 1).3 The drug discovery process can be performed using all the databases and their big data. The data quicken the drug discovery process. One example of a data resource is ChEMBL developed by EMBL-EBI. It currently contains more than 2 million compounds. These compounds show drug-like properties. It is a manually curated database. The database informs different properties such as, molecular properties, target interactions, and mechanisms of action.17,18 Similarly, another drug discovery-related database is ChemDB, which contains approximately 5 million small molecules. All these molecules are commercially available. It also includes their physicochemical properties such as solubility, molecular weight, and rotatable bond.19,20

Different data resources in the pharmaceutical sector for AI-driven drug discovery

## Section: AI: Our understanding › Frequent algorithms or techniques used for AI and ML

Several AI-related algorithms have been developed for drug discovery and development. Drug discovery and associated activities are performed very fast with the help of AI-enabled algorithms or techniques using different data resources. Two types of AI algorithms or techniques are commonly used in AI-enabled drug discovery and development: supervised and unsupervised learning algorithms or techniques.30,31 However, in ML, four algorithms are commonly used: supervised, semi-supervised, unsupervised, and reinforcement. In addition to these algorithms, a commonly used modeling regression analysis algorithm is called multiple linear regression.

AI involves various areas, such as knowledge-based representation, reasoning-based domain, and solution search domain, and among them, a fundamental paradigm is ML. Therefore, ML is a subfield of Al. Similarly, a promising subfield of ML is DL. DL involves artificial NN (ANN) algorithms (Figure 3). There are various types of ANNs, which include CNNs, multilayer perceptron networks, and RNNs.

A schematic diagram shows different steps of drug discovery and development where AI and DL models have been successfully implemented

## Section: AI: Our understanding › Unsupervised learning algorithms or techniques

The unsupervised learning algorithm is very commonly used in AI-related algorithms. It can perform more complex processing tasks and efficiently group the unlabeled datasets into a set of classes. The algorithm can group the members in similar given classes or separate them into other classes.30,31,32 Therefore, it can identify recurring patterns during the grouping of the datasets. One example is the unsupervised learning algorithm Seq2seq fingerprint, which uses SMILE strings to generate the molecular fingerprint. Therefore, it can be trained with the unlabeled datasets of SMILE.33

Similarly, Lo et al.34,35 developed the program ShapeAlign for unsupervised three-dimensional (3D) chemical clustering to understand similarity. It unites both two-dimensional (2D) and 3D metrics based on the Obabel PF2 fingerprint. Finally, the program can shape pharmacophoric points.34,35 The commonly used unsupervised learning algorithms are K-means clustering, hierarchical clustering, and principal component analysis.36

## Section: AI: Our understanding › Supervised learning algorithms or techniques

This group of algorithms is very commonly used in AI-related algorithms. It is used to train labeled datasets and estimate outcomes. Finally, it helps to identify patterns.37,38 Recently, using supervised learning algorithms, Lo et al. developed a self-organizing map (SOM) model for QSAR methods in drug discovery and development. The model is modified using the supervised method and is now entitled as supervised SOM. It can illustrate more precise predictions than standard QSAR.39 Supervised learning algorithms are multiple regression analysis, logistic regression, k-nearest neighbor, decision trees, random forest plots, support vector machines (SVMs), and so on.36

## Section: AI: Our understanding › Semi-supervised learning algorithms or techniques

The semi-supervised learning group of algorithms is a division of ML. This model can be trained in both labeled and unlabeled data. Therefore, the algorithm combines supervised and unsupervised learning to train AI models for classification and regression tasks.40,41 It uses a small portion of the data (supervised and unsupervised). Semi-supervised algorithms or techniques include co-training, self-training, and graph-based labeling. The algorithm is used in text classification. Several semi-supervised learning algorithms have been developed for drug discovery and development. Recently, Sahoo et al.42 developed a MultiCon model to estimate the drug function from chemical structure analysis. The model was developed based on a semi-supervised learning algorithm. According to therapeutic applications, the MultiCon model classifies drugs into 12 categories. It attained an accuracy of 97.74% for class prediction of drugs.42 Similarly, researchers developed another semi-supervised model for synergistic drug combination prediction. The name of the model is NLLSS. The model can evaluate the potentiality of combinations of synergistic drugs by integrating various categories of information.43 Similarly, Wu et al.44 developed a model based on a semi-supervised learning algorithm to predict drug-disease interactions using a three-layer data-integrated model. This model was implemented for the case studies on four diseases. Using the Kyoto Encyclopedia of Genes and Genomes Comparative Toxicogenomics database (CTD), the researcher confirmed the top-ranked drug-disease associations.44 Likewise, Chen et al.45 developed a model to predict the chemical toxicology of drugs using the semi-supervised learning algorithm. The model can efficiently perform the prediction tasks using current chemical databases.

## Section: AI: Our understanding › Reinforcement learning algorithms or techniques

This ML algorithm is trained to solve multi-level problems using the trial and error method for optimal output. It is a feedback-based ML algorithm. Here, the model learns from the real-life scenarios to perform the actions. Stahl et al. 46 developed the multiparameter optimization process in drug design. The model can develop the design of safe compounds. The model was developed using reinforcement learning algorithms or techniques.46 Pereira et al.47 developed a generator for de novo drug design. The model was developed to understand the drugs that can cross the blood-brain barrier. The developed drugs should have permeability and solubility when crossing the blood-brain barrier so that the molecule can reach the site of action in the brain. It can also help in neural drug development. It uses deep reinforcement learning.47 Liu et al.48 generated a model for the de novo design of a drug molecule called DrugEx. The model was developed based on multi-objective reinforcement learning. The model helps to improve the generated drug molecule. The drug molecule can have one specific or multiple drug targets, while the molecules avoid off-targets.48

## Section: AI: Our understanding › Deep NN of DL models

DL models are the modern form of ANNs. However, ANN models are the primary models of AI and were developed a long time ago. If we look back, in 1943, Warren McCulloch and Walter Pitts described a NN based on algorithms and mathematics, which they called threshold logic. It might be the earliest ANN (ANN model).49,50 The basic structure of the ANN was developed from the structure of the human brain, consisting of a network of interconnected neurons. Depending on the type of ANN, the neuron’s nodes are varied.50 The input and output nodes describe the ANN input and output values (Figures 2A and 2B). The output value of an ANN is calculated from its input values, and the equation is shown as follows:

In Equation 1, input values are denoted as ×1, ×2, ×3, ×4, … xn. The output value is denoted as y. Here, w1, w2, w3, w4, … wn are denoted as weights, and a bias term, b, has been used. In the above equation, g is denoted as the activation function. To train an ANN model effectively, researchers should follow certain steps. In the first step, the problem should be defined. In the second step, researchers should collect the datasets. At the same time, the data needs to be divided into training datasets, testing datasets, and validation sets. Then, the researchers need to optimize the parameters. The weight values and biases should be adjusted in the hidden layers. Then, it should be applied to the ANN model and monitor the preference of the model. The ANN algorithm was designed from the 1960s to the 1980s and has been applied since then. When researchers used the algorithm, they found that the method has various problems, such as diminishing gradients and over fitting. Due to this lacuna, ML algorithms such as SVM and RF (random forest) are used to replace the existing methods in due course.

The models of DL are very sophisticated forms of multi-level NNs called deep NNs (DNNs). Using large amounts of labeled or unlabeled training datasets, the DNNs perform the detection.14,51 The difference between traditional ANN and DNN is the complication of the networks and the scale used. In ANN, there is an input feature called the input layer. After that, there are some hidden layers: several nonlinear transformations. Finally, in an output layer, the predictions are made. Every output node refers to a task that will be predicted through the algorithm. Output node refers to a task that is a specific class. It has been noted that traditional ANN has used one or two hidden layers (Figure 2C). Here, powerful hardware is needed to operate the ANN. In contrast, DNN has several hidden layers (Figure 2D). DNN uses more powerful hardware in terms of graphics processing unit (GPU). A critical difference between ANNs and DNNs is the number of layers. DNNs use a more significant number of hidden layers, whereas traditional ANNs usually contains one or two. Therefore, DNNs can use more nodes in each layer due to the more powerful GPU and CPU hardware, which allows it to compute more complicated data. One example is the DropOut and DropConnect methods, which can address the overfitting problem and solve a more complicated problem.50,52,53,54,55 Using the DropOut and DropConnect methods, one can either drop the weights of synaptic connections or drop the states of neural units. These two are significant and effective strategies for enhancing ANN inference performance.54,55 Data science researchers use several DL packages, software and libraries, the most popular of which are Keras, PyTorch, Caffe, Caffe2, and TensorFlow. Most of them are open source and popular DL packages. These open-source packages and libraries have been developed due to the rapid development of the DL technique. DNNs have been applied in different areas of drug discovery. This algorithm is used in the pathological image classification and analysis,56,57 de novo drug discovery,58,59 prediction of protein-ligand interaction,60 and target-based drug design.61 Several researchers have tried to apply DNN in the area of drug discovery.61 Shi et al.61 have developed Pocket2Drug, which will help to design target-based drugs. This model is significant for the discovery of new biopharmaceuticals. It uses encoder-decoder DNNs.61 Similarly, Shi et al.62 recently developed a graph-based model called GraphSite, which can classify ligand binding sites using deep graph learning. Likewise, Wu et al.63 developed a model for anticancer drug discovery. It performs target-based and cell-based anticancer drug discovery. It is a multipurpose DL platform. In addition to these models, several others have been applied in drug discovery and development research, such as DTI-CNN, DeepDTA, WideDTA, PADME, DeepAffinity, and DeepChem (Table 2). The models are primarily developed for researchers to generate novel molecules and predict absorption, distribution, metabolism, excretion, and toxicity (ADMET) effects. These models are essential for performing translational research.64,65 The significant problems during the process of drug discovery and development comprise the unfavorable ADMET properties of the probable drug molecules. This issues are understood to be a primary reason for the failure of drug candidates during development. Additionally, estimating ADMET properties consumes substantial capital, time, and resources.66,67 Therefore, most DL models focus on the ADMET estimation process. In contrast, DL models are also successful in building QSAR models and applying these models in drug discovery and development research.65

The basic architecture and framework of ANNs

It also illustrates basic architecture and framework differences of ANNs and DNNs. (A) The basic framework of ANN (B) The architecture of ANN which shows the input, weight, bias, and output. (C) The ANN with two hidden layers, h1 and h2. (D) An architecture of a DNN model. It has been noted that an ANN has one or two hidden layers, while DNN has several hidden layers.

ML and DL-based applications in different areas of drug discovery and development

## Section: AI: Our understanding › ML- and DL-based applications in drug discovery and development

All ML procedures belong to AI methods that use vast amounts of data. Over the past decade, ample data availability has successfully transformed AI methods into improved ML methods to solve critical problems. ML is considered as one of the best choices for solving issues using various variables and big data.14,67,90,91 ML algorithms are classified into supervised and unsupervised techniques.90,92

Recently, ML methods have evolved into DL methods, which are more efficient and powerful tools for handling the vast amounts of data generated across various fields. DL is a subset of ML, and it has evolved to deal with high-complex data and decision-making from the analysis. DL methods have been applied in modern drug discovery to efficiently deal with the extensive data generated from the drug discovery and development field.90

Several ML- and DL-based applications have been used occasionally and applied in drug discovery and development. Some significant ML-based models are TrixX, LS-align, StackCBPred, DrugFinder, and LigGrep (Table 2).

DL methods have shown better performance than ML methods. Therefore, they have recently appeared as one of the most promising tools in drug discovery research. Some significant DL-based models are DTI-CNN, DeepDTA, WideDTA, PADME, and DeepAffinity. All these models are very significant for drug discovery and development (Table 2).

## Section: AI: Our understanding › Recent landscape of drug discovery: The role of AI to DL

AI-integrated drug discovery has led to a revolution in the drug discovery landscape. Substantial progress has been made in AI-integrated drug discovery. Therefore, significant changes have been made in the pharmaceutical industry. The pharmaceutical industry, which focuses on drug discovery, is implementing the AI platform for drug discovery and development. At the same time, the industries are trying to collaborate with technology companies.11

The first step of drug discovery is small molecule discovery. AI facilitates the development of a large number of drug molecules. AI also helps hits to lead generation speedily.11,93 Similarly, drug target identification is a significant step in drug discovery. AI and DL models have been implemented to identify drug targets faster and more accurately. AI and DL models have occasionally been generated from the initial to final steps of drug discovery and development (Figure 3).

Similarly, several AI, ML, and DL models have been developed to understand the different properties of drug-target interactions (DTIs). At the same time, AI, ML, and DL models have been developed in different areas of drug discovery and development, such as lead molecule development, drug administration, distribution, metabolism, excretion, toxicity (ADMET), and drug-drug interaction (DDI), etc (Figure 4).

A schematic diagram is depicted as an overall framework, visually demonstrating the application of AI technology in drug discovery

## Section: AI: Our understanding › Identification of drug target and prediction of its structure

It has been noted that most of the drug targets are proteins. Other than the experimental and multi-omics approaches, ML and DL approaches have been applied to target identification. Here, researchers develop the disease network and perform a high-level analysis. During the network construction, a biological network was developed to capture the associations between genes, proteins, and molecular entities. Potential targets that involve a disease can be identified from these networks. AI-identified targets are validated using different kinds of experiments, and the target validation can be performed through cell culture experiments and animal models. Several researchers have successfully validated AI-identified targets.94 One example is Zhang et al.,95 who developed an ML-enabled technique to determine the association of the KANK1 gene to amyotrophic lateral sclerosis. Santos et al.66 analyzed 1,578 US Food and Drug Administration-approved drugs and found that proteins are the significant drug target (human and pathogen proteins). The most important classes of protein-based drug targets in humans are the G-protein couple receptors (approximately 12%), ion channels (approximately 19%), kinases (approximately 10%), and nuclear receptors (approximately 3%). Other than the proteins, other biomolecules (human and pathogen proteins) such as DNA, RNA, and peptides are also found as drug targets.96,97 However, protein plays a significant role in cell-cell transduction and cell signaling. AI modeling approaches may help to solve the structure of previously unsolved protein-based drug targets. Presently, AI approaches have been used for protein structure prediction. ANN-based AlphaFold is able to forecast the 3D structures of proteins. AlphaFold model was developed by DeepMind.98,99 The AlphaFold model predicted the 3D structure of human proteins, which is essential. For a given protein, using all heavy atoms, it molded the protein’s 3D structure directly from the primary amino acid sequence, aligned the homologous sequences, formed the 3D coordinates, and finally developed the model 3D structure of the protein. During the prediction of the protein’s 3D structure, AlphaFold uses the ANN and GPU.99 Recently, AlphaFold 3 has been introduced by Isomorphic Labs and Google DeepMind. Using a single unified deep-learning framework, the AlphaFold 3 has the capacity for high-accuracy modeling of the structure in the biomolecular landscape.100 Therefore, for the advancement of protein structure prediction, AlphaFold has significantly contributed in the field, and it will revolutionize drug discovery. However, the change in protein structures has been noted in different environments. Similarly, under the same conditions, proteins may show multiple coexisting structures. Recent ML and DL methods efficiently determine these structures, which will help in drug discovery and development.3,101

## Section: AI: Our understanding › Design of drug molecules using ML and DL

Drug molecular design is an integral part of drug discovery, and ML, DL algorithms have helped to design a drug molecule’s structure. DL algorithms such as RNNs and autoencoders are used in molecular design during drug discovery and development.102 During the molecular design of drug molecules, molecular representation can be performed using two steps: representations of 3D geometry and molecular graphs. Representations of molecular graphs can be further developed using some steps: SMILES and string-based representations, image-based representations, tensor representations, and other graph-based representations. SMILES-enabled methods often struggle to achieve a high percentage.102,103,104 One example of a DL-based tool for small molecular design is the Gypsum-DL. To design compound libraries, it accepts flat SDF formats or SMILES. Different properties, such as cis/trans isomeric states, chiral, tautomeric, and ionization, are considered from the input. Then, it predicts the structural model by changing the structure from a 2D structural model into a 3D one.105 Another DL-based model, dimorphite DL, can estimate the ionization states of small molecules to understand the drug-like properties.106 Recently, Ivanenkov et al.107 developed Chemistry42, an AI-based platform to design novel small molecules with optimized properties. Finally, a designed drug-like molecule should be characterized to understand its properties. The different ML-to-DL methods of ADMET and DL-based QSAR methods help to characterize the properties of designed drug molecules.108 Several AI-to-DL-enabled tools have been developed to understand the ADMET properties of the developed molecules. One such ML-based ADME platform is ADME-AI. It can predict accurate and fast ADMET properties. It is an open-source web server.109 Another one is DeepDelta, a DL-enabled tool that predicts molecules' ADMET. It performs using algorithms (random forest plots andothers). Through direct training on molecular pairs, it predicts molecular properties accurately by directly training on molecular pairs.110

## Section: AI: Our understanding › Estimation of DTI

DTI estimation is one of the critical areas in drug discovery and development. It illustrates the interaction between protein targets and chemical molecules.67,98,99 DTI has been determined using several experimental methods, such as phage display technology, yeast two-hybrid method, and co-immunoprecipitation techniques.3,111,112 These wet laboratory methods are time consuming. Using the increasing biological data and faster prediction, DTI has applied ML and DL to estimate DTI quickly. Several ML and DL models have been developed occasionally to predict the DTI estimation.67,113,114,115 Yang et al.116 have developed one ML-based model for DTI prediction. The model is entitled ML-DTI. Here, they applied four different methods, which yielded similar results. The model tested common targets and drug interaction prediction. Orphan-drug and orphan-target interaction is one of the critical areas of understanding. During the application of this model, it was found to increase the performance of orphan-drug and orphan-target intercations.116 Similarly, Rayhan et al.117 developed another deep CNN-based DTI prediction model called FRnet-DTI. It has auto-encoder-based feature manipulation of DTI.117 Likewise, Zhou et al.118 developed a model related to an augmented graph attention network (AGAT) to understand a binding site estimation of DTI. The model is called AGAT-PPIS. It can map the identity and initial residual.118

DTI identification is not limited to the drug’s or protein’s structural features. It can capture information about the drug-protein complex and the feature representation known as hybrid features. These hybrid features can be constructed using molecular docking, molecular dynamics simulations, or ML-to-DL models. Other than these methods, ligand-based, gene ontology-based, network-based, and text mining-based methods are also important. Bagherian et al.115 have illustrated these methods in a review article. Qian et al.119 developed a model for DTI using multimodal information of a drug molecule called MCL-DTI. It uses the bidirectional multi-head cross-attention method to understand the association between drugs and targets.119 Another model was developed using the DL model, called EDC-DTI, to predict DTIs, and it attains the low computational costs and highest predictive performance. As an example, the model was used to estimate the interaction of drugs and targets such as afatinib (DB08916), nifedipine (DB01115), and simvastatin (DB00641).120 Lee et al.84 have developed the DeepConv-DTI, where DTI can be predicted using DL. For DTIs, the model has some advantages, like identifying the binding sites of proteins.84

## Section: AI: Our understanding › Estimation of drug-target binding affinity

The interactions between drug-target pairs have been studied in the context of binding affinity prediction. This illustrates the potency of the drug-target pair and is broadly enlightening for the field of drug discovery. Binding affinity can be predicted through computational methods.

Understanding the binding affinity among a drug molecule and its target is one of the areas in drug discovery and development. However, researchers have not studied this area much. Experimentally, analysis of drug-target binding affinity is expensive and time consuming. Therefore, computational methods are essential to reduce the time and cost. First, Ozturk et al.80 developed the drug-target binding affinity model in 2018. The work is represented as compound 1D form and modeled protein sequences. The prediction method uses the CNNs.80 Similarly, Pu et al.59 developed a model for the affinity prediction of drug-target binding. The model is entitled DeepFusionDTA. The two-stage DNN model was developed based on the Hybrid Deep-Learning Ensemble Model. The model was tested on the two datasets i.e., Davis and KIBA. The model shows a 1.0% Concordance Index (CI) increase in the first dataset and a 1.5% increase in the second dataset.59 Using co-regularized variational autoencoders, Li et al.121 developed another model for the affinity prediction of drug-target binding. It consists of two VAEs for generating target sequences and drug SMILES strings.121 Other ML/DL-based models have been proposed in this area, such as DeepAffinity82 and WideDTA.122 All these ML/DL-based models are helpful for the estimation of drug-target binding affinity. Recently, Thafar et al.123 designed a model called Affinity2Vec to predict the binding affinity of drug targets. Researchers have tested the model using a weighted heterogeneous graph incorporating different data, such as drug-target binding affinities, target-target similarity, and drug-drug similarity-related data.123 Another model uses cross-scale graph contrastive learning to estimate the drug binding affinity to targets. The model is called CSCo-DTA, which was proposed by Wang et al.124 Using the erlotinib molecule, the model verified the analyzed targets with the docking.

## Section: AI: Our understanding › Design of de novo drug

It refers to the design of drug-like molecules through computational methods. The method started the design of drug-like molecules without a starting template. The boom in AI techniques has opened new possibilities for de novo drug design and accelerated drug discovery. In this case, novel molecular structures are generated from atomic building blocks with no previous relations. However, there are some main differences between conventional drug design and de novo drug design. In the case of conventional design, a structure-based approach was considered, and it depends on the active site’s properties of a biological target.

AI, including ML or DL, is an emerging field that has influenced the drug discovery process. Therefore, the de novo drug design approach was also influenced by AI.125 It designs novel chemical entities based on information such as receptors and ligands. Here, the biological targets are called receptors or their active binders, known as ligands. In de novo drug design, the receptor active site or ligand pharmacophore modeling is the main element in constructing the molecule.125,126 Several ML/DL-based models have been proposed for de novo drug design. During this decade, several DL-based models have been developed occasionally for de novo drug design. Some exciting models are MolRNN, an RNN-based model,127 and GraphINVENT, a GAN-based model,128 ChemVAE, an encoder-decoder-based model,129 and ReLeaSE, a reinforcement learning-based model.130 Another de novo drug molecule design model, druGAN, was recently noted. The method applied a deep generative adversarial autoencoder (AAE) model for developing new molecules with anticancer effects.131 Similarly, combining reinforcement learning algorithms with hybrid VAE, another model was developed for de novo drug design, known as PaccMannRL. This model efficiently designs anticancer molecules using transcriptomic data.132 Recently, Macedo et al.133 developed a de novo drug design model using graph convolutional networks. The model efficiently develops novel quinoline scaffold molecules and analyzes drug-related properties such as synthetic accessibility, toxicity, and pharmacokinetics.133 Therefore, all of these examples reflect that ML/DL models offer new openings in the de novo drug design and, thus, accelerate and revolutionize the drug discovery and development process.

Several other recent de novo drug design models have been developed, exploiting evolutionary algorithms occasionally. Some of these significant models are Dock_GA,134 MoleGear,135 AutoGrow4,68 and SECSE.136

## Section: AI: Our understanding › Prediction of drug toxicity

Drug toxicity estimates undesirable or adversative effects of drug-like molecules. It is one of the main contributors to the costly process of drug development.137 This attribute is related to drug safety. During drug development, prediction of side effects and drug safety measurement are significant components.138 However, laboratory estimation of drug toxicity studies during the drug development process is time consuming. Therefore, computational models reduce time and cost in this case. Recently, using three-layer DNN, a model was developed to predict the toxicity of drug-like molecules or compounds known as DeepTox. In this model, the input of DNN has been used as 0D to 3D molecular descriptors.139 Recently, a DL-based toxicity prediction model known as Deep-PK has been developed. This model estimates the toxicity and pharmacokinetics of small molecules.140 Therefore, ML/DL models are essential for predicting drug toxicity.

## Section: AI: Our understanding › Estimation of ADME

Over the past decade, drug discovery and development have evaluated the ADME property, one of the most critical issues. Previously, experimental evaluation methods (in vivo and in vitro) were used, but these methods are time consuming, laborious, and costly.104 Therefore, estimation of the ADME properties of drug molecules is essential. AI models play a significant role in assessing the ADME, and several AI models have been developed from time to time. It is essential to understand the drug’s ADME properties, which are essential for the drug discovery and development process. Therefore, it is necessary to comprehend these four properties in detail. The four properties are absorption, distribution, metabolism, and excretion. However, some scientists have illustrated the ADME as ADMET, where toxicity has been included in the ADME model as a fifth property. To understand the ADME-toxicity feature of a drug, researchers must understand the inhibition of cytochrome CYP2D6 (P450 2D6), which commonly affects the molecules passing through the blood-brain barrier. Additionally, studying plasma protein binding is essential.141,142,143 Recently, Yi et al.144 developed a model for estimating ADME-Toxicity properties entitled ChemMORT. The model predicts the ADME-toxicity features of drug molecules using multi-objective particle swarm optimization and DL algorithms.144 Gu et al.145 developed another model for estimating ADME-toxicity properties entitled asadmetSAR3.0. The web-based model efficiently predicts the ADME-toxicity.145 Another important web-based model that efficiently predicts the ADME-toxicity model is OptADMET. This model improves lead compounds' ADMET properties through substructure alterations.146

Drug toxicity prediction is one of the crucial parameters for humans. Several types of toxicities have been predicted from time to time, such as liver toxicity (drug-induced liver injury [DILI]), carcinogenesis, and heart toxicity.147 Drug-induced cardiotoxicity and DILI are significant adverse effects triggered by many essential drugs.148 Using data-driven approaches to comprehend toxicity is an important area. In this direction, several data-driven databases or libraries have been introduced for predicting toxicity, such as ClinTox,149 ToxCast,150 and Tox21.151

Some chemical datasets with SMILE format data are available for the ADMET for molecule property prediction, such as Llipophilicity, FreeSolv, and ESOL.152 These datasets are essential to predict the ADMET. From the molecular structure, Delaney153 developed a method to directly evaluate the aqueous solubility of the molecule. Similarly, Mobley and Guthrie154 developed a FreeSolv database to evaluate the calculated and experimental hydration-free energies. It might help to compute hydration-free energies for small molecules in water and molecular structures.154 It is beneficial to understand the properties of a molecule’s structure. Therefore, it may help to understand the ADME of a drug molecule. Lipophilicity is one of the critical parameters of the drug that defines solubility, the ability to penetrate through cell barriers and transport to the molecular target. Therefore, it is essential for drug discovery and development.155 It affects the pharmacokinetics and, ultimately, the ADME. Waring156 suggested understanding lipophilicity is necessary for drug development. AI-enabled ADME might help in this direction.

Several AI-, ML-, or DL-enabled tools or models have recently been developed, focusing on ADME or ADMET. One such ML-based platform is ADMET-AI. It is one of the fastest web-based ADMET prediction platforms using the Python package. It reduces time by approximately 45% compared with other available platforms performing ADMET analysis.109 One recent tool, Deep-PK, has been designed using DL to comprehend the pharmacokinetics and toxicity of input drug molecules. In this model, researchers have used graph NN and graph-based signatures to extract the feature. Finally, it produces the soundest predictive performance.73

Similarly, Yi et al.144 developed a DL-based automatic platform, ChemMORT, to optimize ADMET. The analytical platform uses three modules during optimization: encoder, decoder, and optimizer. These three modules are an SMILES encoder, a descriptive decoder, and a molecular optimizer.144 Using AI-, ML-, or DL-enabled ADME or ADMET tools or models, the researchers can quickly comprehend a molecule’s pharmacokinetics and safety properties during drug discovery and development.

## Section: AI: Our understanding › Estimation of DDI

When we consume two or more drugs, the combination may create unwanted side effects. Therefore, DDIs are described as the unavoidable side effects that result from the intake of two or more drugs.157 It is associated with treatment failure or clinical toxicity. DDIs can be studied through an experimental approach using in vitro and in vivo methods to assess DDI potential.157,158 Predicting DDIs is essential for human health. Conversely, a substantial amount of cost and time is required to predict DDIs using an experimental approach. Presently, using AI, one can analyze the DDIs very quickly. The advantage of AI is that enabling DDI prediction can take less time and lower the cost. Therefore, several AI-to-DL models have been developed in this direction.159

DDIs also need to be understood during drug discovery development, and this is an emerging area of research. It is an essential threat to public health. Therefore, researchers are trying to understand the properties of DDI.160 DDIs were studied through the different models of AI.159 Recent DNN models can analyze the DDI. Recently, Liu et al.161 developed a model DANN-DDI to estimate DDIs. Another model was developed to access DDI. It is a multi-scale feature model called MUFFIN.162 Another DL model can analyze the DDI, which is known as AttentionDDI. This multi-modal NN can benefit drug development through better DDI prediction.163 Pham et al.164 developed a model for predicting DDI using DL. The model, called DeepARV, aims to understand the DDI between ARVs and comedications.164 Similarly, Rohani and Eslahchi165 proposed an NDD model to study the DDI through the NN using a heuristic similarity selection process. The model can evaluate unknown DDIs.165 Similarly, another recent DL-enabled DDI model, SSF-DDI, was developed. The method uses substructure features using the drug molecule graph and drug sequence for DDI prediction. The model integrates drug sequence features and structural features from the drug molecule graph. The encoder captures sequence features pulled out from drug molecules using MixAttention and multilayer CNNs. It also uses a directed message-passing NN to feature the extraction of substructures.166 However, these DDI models solved the DDI problem in the future through proper prediction and understanding.

## Section: AI: Our understanding › Large language models: From drug target identification to drug discovery and development

After the release of ChatGPT on November 30, 2022, large language models (LLMs) gained high interest, and millions of people have been using them.167,168 LLMs perform human-like conversations with cutting-edge technology. Other LLM-based chatbots include Google’s Gemini, Models of Meta’s LLaMA family, and Mistral AI’s models. LLMs can train vast amounts of text through the supervised training process. It uses several fields of medical science for drug discovery.169 LLMs can help to provide the necessary information during drug discovery and development, such as drug target discovery, pharmacokinetics, and pharmacodynamics. It can also help to understand the AMDE properties of a drug molecule. It also helps to comprehend DDI during drug discovery and development.8,170 Recently, several next-generation, domain-specific LLMs have been developed, such as the DrugChat model. The model uses LLM, an adapter, and a graph NN. It can produce drug-molecule graphs.169 Now, LLMs have been used in different areas of drug discovery and development.

However, LLMs have several limitations, such as accuracy and plagiarism.168 By addressing those limitations, LLMs can open up immense future possibilities in drug discovery and development.

## Section: AI: Our understanding › AI-designed molecules entering clinical trial: Some success stories

The preliminary result for AI-designed molecules shows very promising. Some AI-designed molecules have crossed the preclinical barrier and entered clinical trials (Table 3). An AI-designed A2A receptor antagonist molecule EXS-21546 also entered into the clinical trial. The molecule is an immuno-oncology molecule that will be used to treat solid tumors carrying high adenosine signatures. It was developed from the collaborative effect between Evotec and Exscientia.171 Exscientia AI Ltd. is a leading pharma-technology company that performs AI-related drug discovery. Evotec is a biotechnology-based drug discovery company in Germany. Exscientia AI Ltd. developed another AI-designed molecule, DSP-1181. This 5-HT1a agonist for obsessive-compulsive disorder.172,173 Exscientia collaborated with Sumitomo Dainippon Pharma, Japan, to develop this AI-generated drug.

Exscientia developed the next drug candidate, an AI-designed molecular candidate. The molecule is known as EXS4318. The drug candidate is a selective protein kinase C-theta inhibitor.171 Another AI-designed molecule, INS018_055, is developed by InSilico Medicine. It is a biotechnology-based drug design company in Hong Kong. The molecule is a TRAF2- and NCK-interacting kinase inhibitor. The molecule is developed for idiopathic pulmonary fibrosis.94,174

Another drug candidate is RLY-4008, developed by BenevolentAI and a small-molecule phosphodiesterase 10 inhibitor. BenevolentAI performs an AI-based innovation and is a global leader in AI located in the UK. The molecules are developed for ulcerative colitis.

Different AI-designed drugs that enter clinical trials

## Section: AI: Our understanding › Collaboration for AI-enabled drug discovery and development

Several collaborations were made occasionally in the pharmaceutical sector to foster drug discovery and development (Figure 5).175,176 The collaboration between academia-industry is frequently noted in pharmaceutical companies. It occurs because academia can shine in the discovery of drugs with fundamental concepts. In contrast, the industry excels in the translational process of product development.177 However, different types of collaborations were found in the pharmaceutical sector for drug discovery and development, such as academia and pharmaceutical collaboration, a collaboration between two pharmaceutical companies, and a collaboration between one pharmaceutical company and one venture capitalist.177,178 However, all these collaborations were made for faster drug discovery and development methods with less economic input. Some specific collaboration has been noted from time to time. We noted some collaborative efforts for the neglected or rare disease drug development.179,180 During the pandemic, we found several collaborations for coronavirus disease 2019 vaccine development and deployment.181,182,183,184 However, several molecules have been discovered and entered the market due to collaborative efforts, and several examples are noted in this direction.

Big pharma companies have collaborated with computer giants for AI-enabled drug discovery and development. These collaborations are fostering the discovery of new drug molecules. Several new drug molecules have resulted from these collaborations. One example is the collaboration between Evotec and Exscientia, which resulted in the molecule EXS-21546. The molecule has entered the clinical trial and will be used to treat solid tumors. Several other collaborative efforts have been noted for AI-enabled drug discovery. Marck has collaborated with Exscientia for AI-related drug development. Roche has collaborated with Owkin to develop an ML-based clinical trial platform for drug discovery and development.

Similarly, the pharmaceutical giant Pfizer has collaborated with technology company IBM Watson to speed up drug molecule discovery and development in immuno-oncology. Pfizer, IBM, and Microsoft have collaborated to solve healthcare-related problems comprehensively. Sanofi collaborates with Exscientia for AI-related drug development in oncology and cardiovascular disease.11 These collaboration efforts have made AI-enabled drug discovery and development more potent and successful. We will see that these collaborative efforts will result in several new drugs shortly.

Collaborations between pharmaceutical and technology companies for AI-enabled drug discovery and development

## Section: AI: Our understanding › Challenges

Researchers have documented several challenges in AI-driven drug discovery and development, which are as follows.

## Section: AI: Our understanding › Challenges › Issues related to the availability of quality data

Several challenges have been noted in this area of drug development. AI models need to be trained to high-quality data. The main challenge is the availability of high-quality and suitable datasets for training the model. Although chemical and biological data are increasing, the data quality is not so good. Therefore, data curation can be done. At the same time, a cost is involved in accessing data from the database. It is an additional cost to a company and might increase drug development costs. However, more high-quality datasets in pharmacological science and pharmaceutical chemistry must be developed immediately. These datasets can help to train and test AI models, which might solve the data availability problem.

## Section: AI: Our understanding › Challenges › Interpretability of AI or DL models

Developed AI or DL-based drug discovery and development models should be adequately understood and explained. Understandability and explainability of AI model predictions remain challenging. DL models deal with a large number of parameters and multiple layers. It is challenging for nonexpert users to explain the model in the case of drug discovery and development. Therefore, understanding and explaining the DL models is vital for drug discovery and development, but sometimes it is challenging.185,186,187 High-end skills and trained workforces with knowledge of both areas, such as computer engineering with AI specialization and pharmaceutical science knowledge, are immediately required. These skills help to modify algorithms in this direction and understand and predict the outcomes of algorithms in pharmaceutical science and drug development. They might solve the problem of interpretability of AI models.

Similarly, the models developed through the AI technique are not explainable. Likewise, we cannot explain the AI-derived result due to its black box nature.188,189

## Section: AI: Our understanding › Challenges › Computational constraints of high-end AI models

These high-end AI models are not feasible for smaller research entities because they need to train for a prolonged time with a large amount of data. To run these models requires enormous storage resources and vast computational infrastructure. Parallel computation might be helpful for computing high-end AI models.187,190

In this direction, significant research entities require enormous storage resources, and vast computational infrastructure should be established by every country. As the infrastructure cost is too high, every company might not establish the infrastructure. Therefore, the country should support it for the companies. However, the high-end infrastructure must be accessible to companies dealing with AI-enabled drug discovery. It might solve the infrastructure-related issues associated with the computational constraints of high-end AI models.

## Section: AI: Our understanding › Challenges › The need for a more skilled and trained workforce

A skilled and trained workforce is another problem. We need more software engineers with the knowledge of AI technology and more skilled data scientists. With an explicit knowledge of these fields and pharmaceutical expertise, the workforce can efficiently perform AI-driven drug discovery. However, we also need a more skilled and trained workforce.

## Section: Conclusion

AI has made significant progress in disease diagnostics, helping healthcare professionals such as radiologists and clinical pathologists, and revolutionizing these fields. AI has also made significant progress in precision medicine.13,191 Different models developed using AI have been developed to solve radiological and pathological diagnostics and precision medicine problems. Such experiences and success stories might support AI-enabled drug discovery.

Drug discovery is a critical field that deals with multi-step search, multi-dimensional, and optimization problems. With powerful problem-solving capacity, AI has been applied in different fields of drug discovery to solve complicated problems. Over the last decade, AI-enabled techniques have been vastly used in various drug discovery and development steps, and we have witnessed it. The revolution of AI techniques has substantially impacted drug discovery, accelerating the process. Conversely, recent LLM applications like ChatGPT have enriched the drug discovery and development field. Researchers are applying this NPL-based DL model in drug target discovery and advance it to clinical trials more quickly.8,170,192 Our discussion indicates that an AI-enabled, fast-approaching wave has been created in the drug discovery field among pharmaceutical companies with the potential to change drug discovery in the future. Although several challenges exist, AI techniques and technologies will address and overcome them. AI techniques will bring drastic changes in AI-driven drug discovery. DL and ML technology-driven research have successfully generated several models and platforms for drug discovery research. Many researchers have developed AI-driven models, technology, and drug discovery and development tools. In contrast, venture capitalists invest vast amounts of money in different start-up companies focusing on AI-based drug development. Therefore, all factors support the growth of AI-assisted drug discovery and development. Therefore, all assume that the sector will likely grow very fast. At the same time, it is very promising that major pharmaceutical companies will collaborate with technology giants to enter the market by leveraging faster drug discovery and development methods through AI-assisted techniques. Therefore, AI-assisted drug discovery is likely to grow very fast. With faster discovery timelines, AI-enabled drug discovery might be a game changer for research and development in the pharmaceutical sector, from small molecules to therapeutic antibody drug discovery. It will also revolutionize pharmaceutical research and development. We are very hopeful that several AI-driven drugs will enter the market very soon.

## Section: Acknowledgments

This study was supported by research grants from the Zuoying Armed Forces General Hospital (KAFGH-ZY-A-110011, KAFGH-ZY-A-10901).

## Section: Acknowledgments › Author contributions

C.C. conceptualized the manuscript, performed investigation, writing original manuscript draft, writing – review & editing and supervised the whole project. M.B. performed validation, figures and tables development. S.S.L. and Z.H.W. did the validation and formal analysis. Y.H.L. performed formal analysis and fund acquisition.

## Section: Acknowledgments › Declaration of interests

No potential conflict of interest was declared by authors.

## Section: Contributor Information

Chiranjib Chakraborty, Email: drchiranjib@yahoo.com.

Yi-Hao Lo, Email: a0948060004@mail.ngh.com.tw.


---

# The Goldilocks paradigm: comparing classical machine learning, large language models, and few-shot learning for drug discovery applications

- **Authors:** Scott H Snyder, Patricia A Vignaux, Mustafa Kemal Ozalp, Jacob Gerlach, Ana C Puhl, Thomas R Lane, John Corbett, Fabio Urbina, Sean Ekins
- **Issuer:** Communications chemistry
- **Type:** Scientific article
- **Published:** 2024-06-12
- **Language:** en
- **DOI:** 10.1038/s42004-024-01220-4
- **Source:** https://pubmed.ncbi.nlm.nih.gov/38866916/
- **Licence:** CC-BY

## Section: Abstract

AbstractRecent advances in machine learning (ML) have led to newer model architectures including transformers (large language models, LLMs) showing state of the art results in text generation and image analysis as well as few-shot learning (FSLC) models which offer predictive power with extremely small datasets. These new architectures may offer promise, yet the ‘no-free lunch’ theorem suggests that no single model algorithm can outperform at all possible tasks. Here, we explore the capabilities of classical (SVR), FSLC, and transformer models (MolBART) over a range of dataset tasks and show a ‘goldilocks zone’ for each model type, in which dataset size and feature distribution (i.e. dataset “diversity”) determines the optimal algorithm strategy. When datasets are small ( < 50 molecules), FSLC tend to outperform both classical ML and transformers. When datasets are small-to-medium sized (50-240 molecules) and diverse, transformers outperform both classical models and few-shot learning. Finally, when datasets are of larger and of sufficient size, classical models then perform the best, suggesting that the optimal model to choose likely depends on the dataset available, its size and diversity. These findings may help to answer the perennial question of which ML algorithm is to be used when faced with a new dataset.Subject terms: Cheminformatics, Pharmaceutics, Drug discovery and development

## Section: Introduction

The past two decades have seen the meteoric rise of machine learning (ML) as a powerful tool in the field of early drug discovery1. Harnessing the ability of ML algorithms to generate predictive models has enabled researchers to virtually screen novel molecules for target-based activity, as well as for predicted absorption, distribution, metabolism, excretion, and toxicology (ADME/Tox) properties that would potentially preclude candidate molecules from use as potential therapeutics2. This in silico screening strategy is aimed at decreasing the rounds of in vitro testing required in preclinical stages and improving the overall cost-effectiveness of preclinical drug discovery1–4. Some of the most successful ML efforts in drug discovery use quantitative structure-activity relationship (QSAR), quantitative structure-property relationship (QSPR) as well as classification models or other ligand-based strategies to this end5,6. Traditionally, such ligand-based modeling involves the training of ML algorithms such as Random Forest (RF), Support Vector Regression (SVR)7–13, Naïve Bayes (NB)14–18, K nearest neighbor (KNN)19, and Deep Neural Nets (DNN)20–28 on 2D structural fingerprints (ECFP6, MACCS29), physiochemical descriptors (RDKit, Mordred30 and many others), or some combination thereof31.

These traditional ML approaches often require a significant amount of data before their predictive ability reaches significance, reducing their application to targets or datasets with a substantial number of molecules. Recent prediction methods have utilized Transfer Learning and Multi-task output to take advantage of larger dataset sizes that may exist for biologically related targets, an effort that has been bolstered by the introduction and expansion of state-of-the-art large-language models (LLMs) like the one used by the popular chatbot, ChatGPT32. These new modeling architectures are likely rapidly overtaking traditional approaches for performing a variety of cheminformatics analyses. Recurrent neural networks (RNN), and long short-term memory (LSTM) networks33,34 have been found to be very useful in a variety of prediction and optimization tasks35. More recently, simplified molecular line entry system (SMILES)36 strings have been used as input for Sequence-To-Sequence (Seq2Seq) and Transformer models37. SMILES represent a natural format for Seq2Seq modeling because the linear encoding of 2D structural information is a good analog for the “word and sentence” structure of Seq2Seq models38. However, the performance of Transformer-based architectures in drug discovery has been limited due to the average size of regression and classification datasets; these model architectures require large training sets, encompassing millions of compounds, before state-of-the-art performance emerges38. Available structure-activity relationship (SAR) datasets for drug targets, however, often number in the tens of compounds, rendering them unusable for Transformer or even classical ML algorithms. One strategy to navigate this problem is to pre-train Transformer models on large datasets, and then fine-tune them for a single target or endpoint of interest39,40. Another approach is to use a modeling technique specifically developed for small datasets, such as few-shot41 or zero-shot learning42.

As the size of regression and classification datasets can also vary greatly from target to target, and transfer or meta-learning allows for the use of smaller datasets, it can be tempting to apply these newer modeling techniques to all targets in drug discovery. However, few, if any, direct comparisons have been made between classical ML algorithms and these newer models across a wide spectrum of dataset sizes. Here, we evaluate three methods of ligand-based ML modeling at multiple scales of data, including small, medium, and large dataset sizes of different chemical diversities, to find a model selection heuristic for drug discovery. Unsurprisingly, we show that few-shot-learning classification (FSLC) models outperform both transformer (MolBART) and classical ML algorithm support vector classification (SVC) models when trained on small datasets ( < 50 compounds), and SVC models had more predictive power than either the MolBART or FSLC models when the training set exceeded 240 compounds. However, in the “medium” dataset range between 50 and 240 compounds, the advantage of MolBART or SVC modeling becomes dependent on the composition of the dataset, rather than the size. Increasing molecular diversity, quantified by increasing unique Murcko scaffolds in the dataset, favors MolBART modeling over SVC in this middle ground. Because of the “just right” nature of these observations, which consider both size and structural diversity for optimum modeling, we have termed our heuristic the “Goldilocks learning paradigm.” and developed a predictive model to aid in the selection of the modeling method based on inputs of dataset size and diversity. We then tested this paradigm further by modeling five kinases, with vastly different dataset sizes and complexity, that are implicated in the pathology of Alzheimer’s disease (AD). We ultimately show which of the ML approaches performs the best, and in the process, we identify some new inhibitors for MARK1.

## Section: Results

First, each of these metrics was calculated for each individual-target dataset in the original 2401 set from ChEMBL. The correlation was then calculated for each metric.

A R2 vs. the number of molecules for each of the 2401 training datasets from ChEMBL. Each point is a single-target dataset. B R2 vs. the diversity for each of the 2401 training datasets. Each point is a single-target dataset.

Perfect predictions would appear along the central gray line.

These images illustrate how the graph changes as diversity decreases. A perfectly diverse dataset with all unique scaffolds would be a straight diagonal line, while a dataset comprised of only one scaffold would encapsulate the entire area of the plot.

Each dot corresponds to a different target dataset. Correlations were significant between each paired feature (p < 0.05). Each datapoint represents a single-target dataset.

Support set (“training” set) and query set (test set) compositions for different shots during training of FSLC

Summary of the classification metrics for FSLC trained with graph descriptors for 14 validation tasks

Summary of the classification metrics for the SVC models trained with ECFP6 descriptors for 14 validation tasks

FIGS classifier statistics when predicting which machine-learning model (MolBART, SVM, FSLC) will perform best when using dataset size and dataset diversity as input

Training and test sets for classification models from publicly available databases

A The MedChemExpress FDA-Approved and Pharmacopeial Drug Library (HY-L066) was screened for MARK1 inhibition using the Promega ADP-Glo Kinase Assay at a concentration of 385 µM. Compounds that exhibited >90% inhibition are shown in light blue. B The Z-factor for each of the nine plates used in the screen. C IC50 value determination for five novel MARK1 inhibitors using Z’-LYTE assay. Non-linear regression analysis (3-parameters) was performed in GraphPad Prism. Error bars are standard deviation.

A Chemical space overlap of the kinase datasets. B Chemical space overlap of the discovered MARK1 inhibitors vs. the MARK1 dataset and the remaining kinase datasets.

Truth table of the predictions of SVC, MolBART, and FSLC on the MARK1 prospective test set

## Section: Results › Transformer models outperform traditional modeling

Our previous use of ML to model enzyme inhibition has relied upon two-dimensional molecular descriptors (e.g., ECFP6) to generate molecular fingerprints, and a suite of traditional ML algorithms to create predominantly classification models43–45. More recently we have applied these ML models for regression models for predicting compound activity46,47. This approach is completely ligand-based, with the descriptors representing the presence or absence of substructures within the molecule. Each algorithm generates its own model for activity, for which a nested 5-fold cross-validation strategy is performed for hyperparameter optimization and to internally validate the models. The models are then either used to predict the activity of new compounds. To investigate the impact that dataset size has on traditional modeling, we trained SVR models on 2401 datasets of various sizes using a nested 5x cross-validation strategy (see: Large-Language Model Dataset Curation).

To determine whether large-language transformer models can outperform traditional ML methods, we fine-tuned a pre-trained large-language model called MolBART on the 2401 individual-target datasets from ChEMBL and explored the predictive power of the model in comparison to SVR (Supplementary Data 1). While the comparison to SVR was performed in the original publication, less than 100 datasets were investigated38. We first determined whether MolBART would “ignore” small datasets in favor of large datasets, as presumably, MolBART could achieve overall low error rates if it focused on large datasets while ignoring smaller ones. We found that MolBART test prediction statistics were relatively insensitive to the number of endpoints in the target dataset with a correlation coefficient of 0.068 (Fig. 1). This suggests the utility of transfer learning as both large and small datasets can be used for training the model without the unbalanced dataset “overwhelming” the predictive power of smaller dataset endpoints. We next investigated whether the training set size impacted the predictive power of the fine-tuned MolBART model vs. the individual SVR models. The standard cross-validated SVR models have increased R2 as the number of endpoints for a particular target increases. In contrast, the MolBART R2 is independent of the number of target endpoints, suggesting the model is taking advantage of transfer learning for low-number datasets (Fig. 2A). Increasing the diversity generally results in a decrease in R2 for the SVR models but not for MolBART, suggesting the latter can handle more diverse datasets better (Fig. 2B). Comparing two different endpoints for the SVR and MolBART models (Fig. 3) shows the accuracy of predictions with a small dataset size (e.g. opioid receptors, training set size = 80 endpoints, test set size = 20 endpoints) compared to a larger dataset size (Nicotinamide phosphoribosyltransferase, training set size = 2249 endpoints, test set size = 562 endpoints).

The top 10 datasets with the largest differences between MolBART R2 and SVR R2 all have <100 training datapoints, suggesting that datasets with the smallest number of endpoints gain the most predictive benefit from transfer learning acquired using pre-trained transformers (Table S1). To identify other factors that might impact the accuracy of prediction, we investigated the structural diversity of each of the training datasets for each of the individual targets. We chose to examine the distribution of molecules within each dataset and the number of unique Murcko scaffolds present48. Datasets with a wider array of distinct scaffolds cover more chemical property space and therefore may lead to more generalizable ML models. An established method for identifying the structural diversity of a dataset is to use a Cumulative Scaffold frequency Plot (CSFP)49 which compares the percentage of molecules within a dataset that share the same scaffold (Fig. 4 shows how the graph changes as diversity decreases). This is usually plotted as a fraction of molecules, sorted by frequency from the most frequent scaffold to the least frequent scaffold vs. the percentage of unique scaffolds. The scaffolds for each molecule in a dataset were determined using the RDKit Cheminformatics package, with the MurckoScaffoldSmilesFromSmiles function in the rdkit.Chem.Scaffolds.MurckoScaffold module. These plots are similar in structure to ROC curves in that each axis goes from 0 to 100%. A perfectly diverse dataset with all unique scaffolds would be a straight diagonal line, while a dataset comprised of only one scaffold would encapsulate the entire area of the plot. We defined a diversity metric based on the area under the CSFP curve (AUC). We defined our diversity metric as

Using this metric a perfect diversity score would have a div = 1. If all of the molecules have the same scaffold the dataset would not be diverse at all and so diversity = 0. Figure 1 shows the predictive ability of MolBART independent of target diversity with a correlation of 0.13. However, there is a strong negative correlation between target diversity and the predictive ability of SVR models (Fig. 2B). As the diversity of a target dataset increases there is more structural information within it that needs to be incorporated into the SVR model, making accurate predictions less likely.

Exploring the correlation between R2, dataset diversity, and the number of molecules in a dataset reveals a “sweet spot” in which our pre-trained transformer excels, as well as where traditional ML modeling with ECFP6 tends to outperform the fine-tuned MolBART model. Essentially, when diversity is high and the number of molecules in the training datasets is low (~ <240 datapoints), MolBART however excels at predictive power over SVR. However, as the size of the dataset increases, traditional ML modeling (exemplified by SVR in this case) outperforms MolBART (Fig. 5).

First, each of these metrics was calculated for each individual-target dataset in the original 2401 set from ChEMBL. The correlation was then calculated for each metric.

A R2 vs. the number of molecules for each of the 2401 training datasets from ChEMBL. Each point is a single-target dataset. B R2 vs. the diversity for each of the 2401 training datasets. Each point is a single-target dataset.

Perfect predictions would appear along the central gray line.

These images illustrate how the graph changes as diversity decreases. A perfectly diverse dataset with all unique scaffolds would be a straight diagonal line, while a dataset comprised of only one scaffold would encapsulate the entire area of the plot.

Each dot corresponds to a different target dataset. Correlations were significant between each paired feature (p < 0.05). Each datapoint represents a single-target dataset.

## Section: Results › Few-shot-learning classifiers outcompete large-language models and classical machine learning with extremely low data

While LLMs are performative with high diversity and low dataset numbers, oftentimes predictive modeling is required at even smaller dataset size extremes. Until recently modeling for targets with little data (≤10 known actives and ≤20 total datapoints, herein referred to as micro-data) has been unusable due to limited information in these small datasets. Recently, few-shot and zero-shot learning models have shown state-of-the-art performance in text generation, image classification50, and ML model classification predictions for micro-data, paving the way for ML to apply in data-poor situations (for example, these approaches could be used with PROTACS datasets for which there is currently very limited ADME data51, or for dark kinases also with limited data52). However, the decision point on when to use few-shot-learning models vs. traditional ML modeling or LLMs for modeling training data based on the number of datapoints has not been extensively investigated. Given MolBART’s apparent advantages over the classical learning model at low dataset numbers, we decided to implement and test a prototypical network few-shot-learning classifier (FSLC) to benchmark it (Fig. S1; see few-shot-learning model architecture and training). As FSLC are classification models, we built SVM classification models and fine-tuned the molBART pre-trained model for classification to better compare the model types.

Few-shot-learning models benefit from training on similar tasks to what they will predict, and thus we extracted a subset of kinase-specific target datasets (371 target datasets) from the original 2401 datasets. From these, we eliminated kinase datasets that had less than 20 active and 20 inactive compounds and were left with a total of 95 kinase datasets for training. 64 kinases were used as the training set, with 14 kinases held out for validation and 14 held out for testing. The FSLC is first trained on the 64 separate kinases. To simulate a micro-dataset, 2–20 datapoints are sampled from each training kinase dataset as examples (the support set), and the model uses these datapoints as references for predictions (the test set). Varying sample numbers were drawn to determine the effect of class imbalance and dataset size on the FSLC (Table 1). Once trained, the pre-trained FSLC can predict new molecules similarly for the test set kinases (see methods for training and testing details). Traditional ML models (e.g. SVM) were trained using the same datapoints and dataset size.

The pre-trained FSLC could predict correctly even under extremely small support sets of a presented 1 active, 1 inactive dataset (Table 2). In comparison, SVR failed to learn under micro-datasets until at least 5 actives and 5 inactives were presented to the model (Table 3). As the dataset size approached 20 (10 actives and 10 inactives), the classical ML model and the FSCL rapidly converged, suggesting that FSLC are powerful below the 20 datapoint mark, but lose comparative power once the datasets are large enough.

Our results suggest that the different learning modalities have strengths and weaknesses at different levels of data information. To determine if this relationship is computationally predictable, we trained an ML model to predict which approach (MolBART, SVM, or FSLC) is likely to have the highest predictive power using Fast Interpretable Greedy-Tree Sums (FIGS)53. FIGS is a generalized classification and regression tree (CART) model, which creates highly interpretable decision trees from decision leaves in the model. We split the 95 kinase datasets (described above) into a training and test set. We set the hyperparameter number of trees = 3 and used only dataset size and molecular diversity as the input, and the output was a multi-class decision (0,1,2 for molBART, SVM, and FSLC respectively). Using the holdout test set of datasets that were not seen during training, the FIGS classifier was able to predict the correct winning ML model type (Table 4, ROC 0.74). The decision tree produced by the FIGS classifier (Fig. S2) gives a heuristic decision tree, suggesting that relative model performance can be predicted based on dataset size and diversity alone.

From these results, we propose a simple heuristic for model selection based on the dataset size: For datasets <50 molecules, FSLCs dominate. From 50-240 molecules and particularly for diverse datasets, LLMs such as MolBART outperform other modeling types. Finally, as dataset size increases>240 molecules, traditional ML algorithms such as SVR models with ECFP-feature inputs are recommended.

Support set (“training” set) and query set (test set) compositions for different shots during training of FSLC

Summary of the classification metrics for FSLC trained with graph descriptors for 14 validation tasks

Summary of the classification metrics for the SVC models trained with ECFP6 descriptors for 14 validation tasks

FIGS classifier statistics when predicting which machine-learning model (MolBART, SVM, FSLC) will perform best when using dataset size and dataset diversity as input

## Section: Results › The Goldilocks zone for model selection: discovery of novel kinase inhibitors for Alzheimer’s disease

To compare these ML model types and show the application of where each of them excels, respectively, we built and applied ML models to discover new kinase inhibitors for AD. The mechanisms underlying the AD pathophysiology are still unclear. Aggregation of tau and amyloid beta (Aβ) proteins as well as decreased acetylcholine are the focus of many studies54. Neurofibrillary tangles (NFTs) are one of two hallmark plaques in AD55–57 and are comprised of a hyperphosphorylated version of the microtubule-stabilizing protein tau (Ptau)58. Ptau dissociates from the microtubule, migrating away from the axon, and forming insoluble paired helical filaments in the cytoplasm of the soma. This leads to destabilization and loss of the cytoskeletal microtubule, part of a cascade of events that leads to neuronal death58. Three major classes of kinases can phosphorylate tau59: proline-directed kinases like glycogen synthase kinase 3 beta (GSK-3β) or cyclin-dependent kinase 5 (CDK5)60,61, non-proline-directed kinases such as tau-tubulin kinases (TTBK)62 or microtubule affinity regulated kinases (MARK)63, and tyrosine kinases such as Fyn64 or Abl kinases65. Using IC50 data from the ChEMBL database and ECFP6 Fingerprints with 1024 bits, we built ML classification and regression models for GSK3β, ABL1, FYN, CDK5, and MARK1. The classification models for FYN, CDK5, and MARK1 were built with activity thresholds of 1 µM, meaning compounds with IC50 values lower than 1 µM are classified as active (Table 5 and Table S2). The kinase inhibitor datasets spanned several orders of magnitude in size, from 18-2969 datapoints and differing molecular diversity, making them an excellent dataset to investigate the Goldilocks zone model selection process. The datasets for both GSK3β and ABL1 contained sufficient entries of low-nanomolar inhibitors that we could build good classification models (according to the cross-validation statistics generated) based on the lower activity threshold of 100 nM (Table 5 and Table S2). The MARK1 dataset was by far the smallest dataset and therefore has the least predictive power for classical ML algorithms, which is reflected in the internal cross-validation scores for the classification models (Table S2). The fine-tuned MolBART model was further trained on each of these datasets, following the same training procedure as performed in the original fine-tuned training of the model.

The differences in the predictive power of the three model types, track with what we have seen from our own internal inhibition testing and model predictions for these four kinases and from the earlier comparative analysis (Table S3) with the FYN and CDK5 models performing less well. MARK1 presents a unique challenge, as it has sparse data and no external test set (Table 5). Because we did not have an external test set for our MARK1 model, and no measure of confidence for our classical ML model predictions, we performed a high-throughput screen of FDA-Approved compounds for MARK1 activity to create a prospective test set (Fig. 6A, B). We virtually screened the FDA-approved library with our classical models, fine-tuned MolBART model, and our pre-trained Kinase FSLC model to determine model performance with the sparse MARK1 dataset. The MedChemExpress FDA-Approved and Pharmacopeial Drug Library (HY-L066) was experimentally screened for MARK1 inhibition using the Promega ADP-Glo Kinase Assay. We selected a subset of hits from our high-throughput screen, along with a few compounds from our internal library, to be tested for IC50 value determination (Fig. 6C), and then used those results as a test set for our MARK1 models.

Out of the 13 tested compounds, 5 (baricitinib, AT9283, ON123300, upadacitinib, and tofacitinib citrate) were true novel MARK1 active inhibitors that to our knowledge had not been described previously with this activity (Fig. 6C and Table S4). Baricitinib is a JAK1 and JAK2 inhibitor66. AT9283 is an aurora kinase and JAK2 inhibitor67,68. ON123300 is a CDK4, PI3K/AKT/mTOR inhibitor69–71. Upadacitinib is a JAK-1 inhibitor72. Tofacitinib is a JAK1 and JAK3 inhibitor73. We have also compared the maximal Tanimoto similarity (using MACCS key fingerprints) of the compounds to the MARK1 training set, with the closest being 0.79 (tofacitinib), while the similarity of the majority of the other hits ranged from 0.56-0.75, suggesting some structural diversity compared to the training dataset. We next visualized these molecules using t-SNE (Fig. 7 and Table S5). Each of the kinase datasets reveals distinct coverage of chemical space (Fig. 7A). When we compare the MARK1 hits discovered, they fall in various regions of chemical space that do not overlap with the known MARK1 training data, indicating the machine-learning model can find unique chemical structures.

Although the classical ML model SVR performed the best followed by MolBART and the FSLC on the external test sets, the inverse performance was seen for the MARK1 prospective test set (Table 6). The SVR model predicted no actives for MARK1. MolBART, even though it was only trained on a test set of 18 compounds, was capable of discovering 3 of the 5 novel inhibitors. This tracks with the notion that pre-trained LLMs can be used to improve predictive power in sparse data situations. FSLC, despite performing worse overall when trained on large datasets, excelled at discovering novel MARK1 inhibitors, finding all 5 inhibitors with high precision (Table 6).

Training and test sets for classification models from publicly available databases

A The MedChemExpress FDA-Approved and Pharmacopeial Drug Library (HY-L066) was screened for MARK1 inhibition using the Promega ADP-Glo Kinase Assay at a concentration of 385 µM. Compounds that exhibited >90% inhibition are shown in light blue. B The Z-factor for each of the nine plates used in the screen. C IC50 value determination for five novel MARK1 inhibitors using Z’-LYTE assay. Non-linear regression analysis (3-parameters) was performed in GraphPad Prism. Error bars are standard deviation.

A Chemical space overlap of the kinase datasets. B Chemical space overlap of the discovered MARK1 inhibitors vs. the MARK1 dataset and the remaining kinase datasets.

Truth table of the predictions of SVC, MolBART, and FSLC on the MARK1 prospective test set

## Section: Discussion

There have been several large-scale comparisons of ML models using on the order 1000 s datasets74–78. We have previously described using over 5000 datasets from ChEMBL with the ECFP6 fingerprint descriptor and provided a comparison of various ML algorithms. In this case, the model performance was assessed using five-fold cross-validation metrics as well as F1 score, Cohen’s kappa, and Matthews correlation coefficient. We created ranked normalized scores for the metrics for all methods and showed that they appeared comparable while the Bayesian algorithm and support vector classification were the best performing43. Other very large-scale evaluations include that of Novartis Institute for Biomedical Research which used 8558 proprietary Novartis assays to generate Random Forest Regressor models for their datasets79.

Recent advances in ML have shown that transformer-based large-language models scale with the size of the data and number of parameters80. While QSAR modeling has been performed with large datasets, the total number of endpoints and thus number of datapoints for training a single model have remained relatively small in comparison to the available data. In this study, we first evaluated the effect of dataset size using 2401 datasets on SVR models and compared performance with fine-tuning a pre-trained MolBART model. We found that the R2 improved with dataset size for SVR but there was no effect of dataset size on MolBART. As dataset diversity increases the SVR model R2 decreases whereas with the MolBART model R2 was independent of diversity. This suggests that the pre-training of the MolBART model allowed it to capture relevant information for all QSAR tasks, giving it a higher predictive power over the SVR models on smaller datasets, which must learn all the relevant QSAR information from the individual datasets. As the dataset size increases, however, SVR models become more specialized in comparison to the multi-endpoint predicting MolBART model, allowing it to capture more nuanced information for each single dataset. Interestingly, the diversity of the dataset correlated negatively with the predictive power of SVR models, suggesting that similar feature representation may play a stronger role in the support vectors generated for the model decision boundary.

Often when we embark on drug discovery projects for new targets there is generally little if any data available to build ML models. In these cases, we traditionally would use approaches like pharmacophores to perform virtual screening based on molecular shape for a few hits5,6. In addition, when we are asked by our colleagues or collaborators to build ML models, we are also often queried on how many molecules are required in order to build a ‘useful model?’. We have now explored an ML approach that handles extremely low data called FSCL50. Initially, we used a subset of human kinases and simulated small datasets, and directly compared how this FSLC method performed relative to SVR. We found that FSCL performed well with small datasets (5 actives and 5 inactives) and as these numbers doubled its advantages decreased in comparison to both MolBART and SVR models.

Our results suggest that each model type (classical SVM, pre-trained LLM, and the FSCL) occupies a niche in which its predictive power excels over alternatives and that a Goldilocks zone exists for different ML model types. When the dataset is small (<50 molecules), FSLC performs best, capable of generalizing class-features from a small set of representations. When the datasets are diverse with a range of 50-240 molecules, pre-trained LLMs such as MolBART tend to outperform other ML approaches, leveraging the transfer learning from pre-training to outperform SVM while learning more from the slightly larger dataset size compared to FSLC. Finally, as the molecule dataset size increases past 240 datapoints, then classical ML methods such as SVR will dominate. The ability to predict which model algorithm is most likely to outperform the others using just the dataset size and dataset diversity as input suggests this relationship generalizes across most target datasets, giving us a heuristic with which to decide “how should I model my data?”.

We further demonstrate the relevance of these findings using the identification of inhibitors for GSK3β, ABL1, FYN, CDK5, and MARK1 for AD. Using the extreme of a small training dataset of 13 compounds and FSLC, We identified 5 new inhibitors of the kinase MARK1 (most of which are also known as JAK inhibitors) which regulates microtubule dynamics in neurons81 and phosphorylates tau which results in cellular transport inhibition, impacts postsynaptic molecular makeup and can induce either spine enlargement or tau toxicity as well as spine decay-depending on expression levels and duration82. Targeting tau phosphorylation is a valid target for AD that can form neurofibrillary tangles inside neurons and lead to neuronal death58. The MARK1 dataset provided an example to compare the FSLC, MolBART, and classical ML approaches. Our results demonstrated that for a small dataset, FSLC performed the best at identifying the active molecules, outperforming MolBART and classical ML methods. MolBART was able to predict 3 of the 5 inhibitors while SVM predicted 0 inhibitors correctly, demonstrating the Goldilocks zone application.

Important limitations of this study to consider are that we have focused on kinase inhibitors which: 1. are all very similar; 2. there is more data than for other targets; and 3. there is generally a high degree of similarity between targets. To counter this, we would add that in the case of MARK1 there was limited data available, and it was an accessible assay which we could in turn generate new data for. We would suggest that future work could explore our approach with additional targets outside of kinases. For example, we have previously used ML to perform virtual screening to identify new ligands for various GPCRs83,84. In addition, we did not explore other molecular descriptors or take into account any of the target 3D structures in this study. We solely focused on ChEMBL and BindingDB as sources of public data for modeling and there may be other published datasets we could include to increase our dataset size in the future. It is also important to remember we are curating data from many publications so there will be considerable variability and experimental error for some assays which we also need to consider for each dataset as well as dataset composition bias. The approach we have taken could also be used to explore and compare many other ML approaches beyond the few described here.

While there is currently considerable interest in methods such as LLMs, they may not be a panacea for our ML modeling of drug discovery relevant datasets just yet for the reasons mentioned. While one advantage of them is that they enable transfer learning across datasets and the construction of a single model that can output predictions for all the targets. We now describe where this algorithm may be the most useful, where the datasets may be midsize and diverse. It will be important to continue to explore whether this Goldilocks paradigm holds up as we look at larger datasets in the future. In the meantime, we have provided some recommendations that may assist others in their selection of which ML methods may be appropriate for datasets of various sizes and diversity.

## Section: Experimental section › General dataset curation

Publicly available datasets for Fyn, MARK1, Abl, and GSK3β, were downloaded from ChEMBL and BindingDB85,86, then standardized with our proprietary “E-Clean” software to remove salts, and neutralize charges, and assign InChIKeys and canonical SMILES using open-source RDkit functions. Continuous activity values were converted to −log[M], and duplicate molecules were averaged based on InChIKey. The Assay Central software43 further standardizes datasets using Indigo Toolkit 7 to, dearomatize, standardize, and reposition stereo bonds, standardize or flag erroneous charges, flag erroneous valences, remove isotopes, remove dative and hydrogen bonds, flag multicomponent chemicals, and remove any remaining duplicates.

## Section: Experimental section › Large-language model dataset curation

Over 5000 datasets were curated from ChEMBL86 as described previously43, and original activity thresholds were retained. Datasets with fewer than 20 total datapoints were removed, resulting in 2401 individual-target endpoint datasets for Ki, IC50, or EC50 activity. The endpoints for the aggregated dataset were randomly split into training/validation/test sets by following a 70/5/25 split. All datasets were then subjected to the “cleaning” procedures described above.

## Section: Experimental section › Few-shot-learning dataset curation

Datasets for 371 individual kinases were downloaded from ChEMBL. Datasets with fewer than 20 datapoints for either active or inactive compounds were removed, leaving only 95 kinase datasets. These were binarized on a threshold of 100 nM (IC50, ≤100 nM or −log[M] ≥ 7), then randomly split into train/validation/test sets by following a 70/15/15 split. All datasets were then subjected to the “cleaning” procedures described above.

## Section: Experimental section › Assay central model building

Our proprietary AC software43 uses multiple classic ML algorithms that are integrated into our web-based software to build classification models using the following algorithms: deep learning, adaboost classifier, Bernoulli Naïve Bayes, K nearest neighbors (kNN) classifier, logistic regression, random forest classifier, Support vector classification (SVC) and XG boost (XGB) classifier. For model building of continuous data, we have implemented multiple regression algorithms which include adaboost regression, Bayesian regression, elastic net regression, kNN regression, random forest regression, support vector machine regression, and XGboost regression. In all cases, nested 5-fold cross-validation was performed except for deep learning for which we removed 20% of the training set, in a stratified manner for the classification models, and these were used as external test sets for models trained on the remainder of the data.

## Section: Experimental section › Large-language model architecture and training

To explore the effect of “tuning-dataset” size for a pre-trained LLM transformer model, we fine-tuned the base Chemformer pre-trained model provided by Irwin et al.38 on progressively larger sets of data. The Large-Language Model is a molecule pre-trained Bidirectional Auto-regressive Transformer (molBART). The BART architecture uses both encoder and decoder layers of the Transformer models, allowing the model to learn contextual molecule encodings (using the encoder) while the auto-regressive decoder module learns molecular structure. After pre-training molBART, the bidirectional encoder can be fine-tuned for downstream tasks such as property predictions (e.g., IC50 prediction of molecules against a specific target). The fine-tuning of the pre-trained model was performed using PyTorch using the Lightning87 framework for 150 epochs and each of the 2401 endpoint datasets was used in the fine-tuning.

## Section: Experimental section › Few-shot-learning model architecture and training

Few-shot-learning classification (FSLC) models were originally introduced for multi-class image and text classification50. However, our application is different as we only have two classes for the majority of the tasks (active or inactive). The few-shot-learning network was trained on a select number of tasks (e.g. kinase dataset), which have sufficient data and tested on the remaining kinases. Shot is the number of molecules sampled per class, and added to the support set during each round of training, also known as episode.

FSLC consists of three modules the first two take in molecular descriptors and create embeddings for the molecules. The last module creates “prototypes” for each class by taking the average of molecular features and making predictions, similar to the previous one/few-shot-learning models42,88,89. FSLC uses episodic learning to match training and testing conditions. In each episode, the training algorithm samples two batches of labeled, non-overlapping datapoints from each class in each task. One batch is used as the support set, S, to create prototypes. The other batch is the query set, B, which is used to calculate loss and update the network’s parameters. g′ and f′, and g and f are the same embedding modules. During testing, support and query sets are sampled for each unseen kinase. Embeddings are created for each new compound, and binary labels are predicted based on the distance between the query compounds and the class prototypes. We used the same FSLC architecture described in Vella and Ebejer42. The first module, g′, is either a fully connected feed-forward network (FNN) or a graph convolutional network (GCN) depending on the chemical descriptors used. When we trained an FSLC with ECFP chemical descriptors generated with rdkit (2048 bit vectors and radius = 5), we used an FNN architecture. We used GCN when we used the graph convolution-learned embeddings90. The second module, g is a long short-term memory (LSTM) network with iterative refinement (IterRefLSTM). The details of IterRefLSTM can be found in Altae-Tran et al.89. Briefly, the IterRefLSTM uses a context-based attention mechanism to refine the initial embeddings iteratively and simultaneously for the support and query embeddings. The third module is a Prototypical Network (PN) which creates class prototypes and predicts the label of unseen datapoints based on the Euclidean distance. A more detailed explanation can be found in the original Prototypical Networks paper by Snell, Swersky, and Zemel50. We trained a number of FSLCs using 1 and 10 shots. FSLCs were trained until the loss was < 1e−6. We used the negative log-likelihood loss and Adam optimizer91 to optimize the model parameters. We used the AUC of the PRC to evaluate the model’s general performance similar to Altae-Tran et al.89 and Vella and Ebejer42. We tested the models by randomly sampling each test task 1000 times. The average statistics scores were calculated for each task and for all models.

## Section: Experimental section › In vitro screening › Chemical library

The FDA-Approved & Pharmacopeial Drug Library (MedChemExpress, Monmouth Junction, NJ) contains 2743 compounds that were approved by institutions (FDA, PDMA, EMA, or NMPA), or contained in pharmacopeia (JP, BP, EP, or USP). The portion of the library supplied at 10 mM in DMSO (2637 compounds) was screened for MARK1 inhibition. 200 nL of each compound was dispensed into a 384-well assay plate (Perkin Elmer 6008280) using a Mosquito HTS (TTP Labtech Melbourn, UK), and stored at −80 °C until use.

## Section: Experimental section › In vitro screening › Experimental procedures

Compounds were evaluated for MARK1 inhibition using the ADP-Glo™ Assay with the MARK1 Kinase Enzyme System from Promega. Reactions were performed using 10 µM ATP, 0.2 µg/µL CHKtide substrate, 50 µM DTT, and 5 ng MARK1 enzyme, final concentration. All but plate HYCPK12959 contained 0.01% Triton-x 100. The final concentration of the compounds was 385 µM in 3.8% DMSO. Compounds were pre-incubated with enzyme for 10 min at room temperature before the addition of ATP and substrate. The kinase reaction was incubated for 60 min at room temperature, followed by a 40-min incubation with ADP-Glo reagent, then a 30-min incubation with Kinase Detection Reagent. The resulting luminescent signal was read on a SpectraMax iD5 (Molecular Devices, San Jose, CA), using an integration time of 1000 ms.

## Section: Experimental section › Data analysis

Statistical analysis was performed in Excel and GraphPad Prism 9.5.1. Z’ factor was calculated using the formula Z′=1−(3x(σp+σn))/∣μp−μn∣.

## Section: Supplementary information

Supplementary Information

Description of Additional Supplementary Files

Supplemental Data 1.

## Section: Acknowledgements

We acknowledge our many colleagues at Collaborations Pharmaceuticals, Inc. for their assistance with this project and the reviewers for their constructive feedback. We kindly acknowledge NIH funding: R44GM122196-02A1 from NIGMS and 1R44ES031038-01 from NIEHS (PI–Sean Ekins). “Research reported in this publication was supported by the National Institute of Environmental Health Sciences of the National Institutes of Health under Award Number R44ES031038. We also acknowledge 1R43AT010585-01 from NIH/NCCAM The content is solely the responsibility of the authors and does not necessarily represent the official views of the National Institutes of Health.”

## Section: Author contributions

Scott H. Snyder: Model building, data generation, analysis, and software (MolBART). Patricia A. Vignaux: Experimental data generation, data analysis, and manuscript writing. Mustafa Kemal Ozalp: Model building, data generation, and software (few-shot learning). Jacob Gerlach: Data curation software. Ana C. Puhl: Experimental data generation, kinase expertise. Thomas R. Lane: Data curation, experimental methods, and data analysis. John Corbett: Data curation software. Fabio Urbina: Project supervision, data generation, data analysis, and manuscript writing. Sean Ekins: Funding, project supervision, and manuscript writing.

## Section: Peer review › Peer review information

Communications Chemistry thanks Fang Bai and the other, anonymous, reviewer(s) for their contribution to the peer review of this work.

## Section: Data availability

All relevant data are available from the authors upon written request.

## Section: Competing interests

S.E. is the owner and all others are employees of Collaborations Pharmaceuticals, Inc.

## Section: Contributor Information

Fabio Urbina, Email: fabio@collaborationspharma.com.

Sean Ekins, Email: sean@collaborationspharma.com.

## Section: Supplementary information

The online version contains supplementary material available at 10.1038/s42004-024-01220-4.

## Section: Associated Data

Supplementary Information

Description of Additional Supplementary Files

Supplemental Data 1.

## Section: Associated Data › Supplementary Materials

Supplementary Information

Description of Additional Supplementary Files

Supplemental Data 1.

## Section: Associated Data › Data Availability Statement

All relevant data are available from the authors upon written request.
