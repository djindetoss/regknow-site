# Applications of machine learning in computer-aided drug discovery

- **Authors:** Sm Bargeen Alam Turzo, Eric R Hantz, Steffen Lindert
- **Issuer:** QRB discovery
- **Type:** Scientific article
- **Published:** 2022-09-01
- **Language:** en
- **DOI:** 10.1017/qrd.2022.12
- **Source:** https://pubmed.ncbi.nlm.nih.gov/37529294/
- **Licence:** CC-BY-NC-SA

## Section: Introduction

The field of drug discovery and design is one of the most vibrant areas of research, with many groups from academic and industrial settings contributing to its advancement. The identification of small molecules binding to protein or RNA targets, and the related structural and functional information is of fundamental importance to modern drug discovery. One way to identify small molecule binders is high throughput screening (HTS), where millions of compounds are tested for the desired biological activity (Martis et al., 2011). However, HTS is time-consuming and expensive (DiMasi et al., 2003; Workman, 2003; Hopkins, 2009). An alternative to HTS is computer-aided drug design (CADD) or virtual HTS (Leelananda and Lindert, 2016). CADD provides the capability of screening millions of compounds virtually. This significantly reduces the number of molecules that need to be tested biochemically. Therefore, this approach can cut cost and accelerate the preliminary stage of drug development. CADD has been successfully applied to numerous disease-related target systems advancing research in treatments for congestive heart failure (Lindert et al., 2015a; Cai et al., 2016; Aprahamian et al., 2017; Coldren et al., 2020), several types of cancer (Lee et al., 2010; Ravindranathan et al., 2010; Chuang et al., 2015; Lee et al., 2019; Fratev et al., 2021; Hantz and Lindert, 2022), and various infectious diseases (Durrant et al., 2011; Zhu et al., 2013; Sinko et al., 2014; Lindert et al., 2015b; de Sousa et al., 2020).

In practice, commonly utilised CADD approaches may vary depending on the availability and type of experimental information. The two main methods being employed are structure-based drug design (SBDD) and ligand-based drug design (LBDD). In the structure-based approach, the 3D structures of targets are known. They are generally elucidated using techniques such as X-Ray crystallography, nuclear magnetic resonance spectroscopy and cryogenic electron microscopy and can be further supplemented with molecular dynamic simulations (Salsbury, 2010), computational structure prediction (Dorn et al., 2014; Seffernick and Lindert, 2020) and design (Huang et al., 2016) methods. These structures are then used for generating or screening potential small molecule ligands by predicting interactions with the target. On the other hand, ligand-based approaches are utilised when the 3D structure of the target is unknown. However, LBDD relies on the existence of a large set of ligands whose potency against a biological target of interest is known. Using such information, a correlation between the structures and properties of known ligands and their experimentally determined biological activities can be derived. This structure–activity relationship may in turn be used to design new drugs. Over the last decade, there has been a rapid shift in the field of drug development aimed at improving CADD approaches using a variety of machine learning (ML) techniques (Cao et al., 2018). Recently, others have reviewed the general role of artificial intelligence throughout the drug discovery pipeline (Hessler and Baringhaus, 2018; Patel et al., 2020; Carracedo-Reboredo et al., 2021; Gallego et al., 2021; Paul et al., 2021; Dara et al., 2022). Notably, in this work, we provide an overview of recent applications of deep learning (DL) in CADD methods, with a specific focus on SBDD.

## Section: Structure-based drug design

SBDD is the most commonly utilised approach when the three-dimensional structure of the drug target is known. In SBDD, one first identifies the structural data of the target either experimentally or through computational modelling. Next, a docking algorithm is used to position compounds from a database into the selected region of the target. These compounds are then scored and ranked using a score function and top hits are tested experimentally. Over the past few years, SBDD methodologies have gone through significant improvements in speed and accuracy. The introduction of ML techniques to SBDD approaches has also enhanced performance (Cao et al., 2018). DL techniques, a subdivision of ML with multi-layered neural network architectures, are increasingly utilised in drug discovery to capture complex data patterns and predict outcomes (Schmidhuber, 2015). Reinforcement learning (RL) is yet another subdivision of ML, where a computer model is trained by rewarding desired outcomes and penalised for undesired ones (Botvinick et al., 2019). The combination of DL and RL techniques (DRL) in the field of drug design has also been revolutionary and has led to several breakthroughs in recent years (Olivecrona et al., 2017; Neil et al., 2018; Popova et al., 2018; Ståhl et al., 2019; Zhou et al., 2019). Applications of these techniques in SBDD can be categorised into three main areas of focus: de novo drug design, binding site prediction, and binding affinity prediction.

## Section: De novo drug design

De novo drug design refers to the exploration of a broad chemical space and creation of new chemical compounds without the need for a starting template and was first introduced by Danziger and Dean (1989). The chemical search space for identifying novel compounds is virtually infinite and sufficiently sampling this space is a primary challenge in de novo drug design. In order to resolve this issue, a set of restraints is typically incorporated. For instance, the physical and chemical properties of a target’s active site are key constraints for ligand design. Structural and chemical information plays an immense role in reducing the search space to prevent the sampling of generations of compounds that might be synthetically unobtainable. Two sampling methods, atom-based and fragment-based, are primarily used for compound generation in de novo drug design (Gillet et al., 1993; Wong et al., 2011; Schneider and Fechner, 2022). In atom-based sampling (Fig. 1a), an initial atom is used as a seed inside the active site of the target. From this seed, a diverse set of compounds are grown by varying the number of atoms and hybridization states of each atom (Nishibata and Itai, 1991). Compounds generated from atom-based sampling have high structural diversity. However, the computational cost in narrowing down the lead compound with the atom-based method can increase exponentially with the size of the compound being designed (Hartenfeller and Schneider, 2011). Alternatively, fragment-based sampling (Fig. 1b) circumvents this issue by exploring a database of fragments. These fragments are then used as a seed in the active site to build the rest of the compound. This approach significantly narrows the chemical search space while maintaining good structural diversity (Böhm, 1992; Gillet et al., 1993; Pearlman and Murcko, 1996; Clark et al., 2022).Fig. 1.Illustration of computational de novo drug design. (a) In atom-based drug design, the small molecule is built atom by atom by sampling additions of many different types of atoms. (b) In fragment-based drug design, the small molecule is built by sampling additions of a library of fragments.

DL and deep reinforcement learning techniques have been used in numerous cases to improve the performance of de novo drug design. Common DL architectures utilised in de novo drug design include recurrent neural network (RNN), graph neural network (GNN), and graph convolutional neural network (GCNN). RNNs make use of sequential data or time series data and are known for their internal memory which takes information from prior inputs to influence the current input and output. In contrast, traditional deep neural networks assume that inputs and outputs are independent of one another (Dupond, 2019). RNNs have been recently expanded with long short-term memory (LSTM) networks. Introduced by Hochreiter and Schmidhuber (1997), LSTM are used as the building blocks for the layers of a RNN and enable RNNs to remember inputs over a long period of time. This memory is commonly referred to as a gated cell, meaning the cell decides whether to store or delete information based on the importance or weight it assigns to the information. GNNs are a class of artificial neural networks used for processing data that can be depicted as graph structures. GNNs operate on an information diffusion mechanism, meaning a graph is processed by a set of units which are linked according to the graph connectivity. The units exchange information in a pairwise fashion until a stable equilibrium is reached (Scarselli et al., 2009). This behaviour is similar to an RNN as weights are shared in each recurrent step. In contrast to RNNs and GNNs, GCNNs do not share weights between hidden layers. GCNNs generalise classical convolutional neural networks (CNNs) to graph-structured data. In this representation, structural information can be incorporated to model connections among entities and create further insights in the data. GCNNs can utilise the graph structure and aggregate node information from the neighbourhoods in a convolutional fashion (Zhang et al., 2019). Deep reinforcement learning (DRL) combines artificial neural networks with a framework of reinforcement learning (RL) that helps agents (i.e. the algorithm making decisions/actions) learn how to reach their goals. RL considers the problem of an agent learning to make decision based on trial-and-error from rewards or punishments. DRL incorporates DL by allowing the agent to make decisions from unstructured data or domain heuristics. We will review several notable recent examples of these architectures below.

Jeon and Kim (2020) created an atom-based de novo method to design novel compounds named Molecule Optimization by Reinforcement Learning and Docking (MORLD). MORLD is a deep generative model that uses binding affinities, obtained from docking simulations, as rewards in the reinforcement learning. In MORLD, a compound is optimised by Molecule Deep Q-Networks (MolDQN) (Zhou et al., 2019), based on reinforcement learning and chemistry domain knowledge. Compounds are optimised in single action steps, meaning either an addition or removal of an atom or bond in a chemically valid manner. This is controlled by the user as atom types for modification need to be specified. The modified molecule is then evaluated with different score functions such as the synthetic accessibility (SA) (Ertl and Schuffenhauer, 2009) and quantitative estimate of drug-likeness (QED) (Bickerton et al., 2012). The SA score is a metric that is used to estimate the ease of synthesis of drug-like molecules. SA score ranges from 1 (easy to synthesise) to 10 (difficult to synthesise). QED provides a quantitative metric for assessing druglikeness of target (and/or predicted) compounds. This value ranges between 0 and 1. A compound QED score of 0 indicates that all properties of that compound are unfavourable and vice-versa. These scores are weighted and used to guide compound modification with MolDQN in the next state. This process is repeated until the compound reaches a terminal state. In the terminal state, the modified compound is docked to the target with QuickVina2 (Alhossary et al., 2015). The resulting docking score is given to MolDQN as a reward and a compound is generated. This is repeated until a specified number of training episodes are reached. MORLD was shown to significantly decrease the time needed to design a novel inhibitor for the target discoidin domain receptor 1 kinase (DDR1) compared to the deep generative model GENTRL (Zhavoronkov et al., 2019). GENTRL took approximately 46 days (with training data) to successfully design a novel inhibitor against DDR1, whereas MORLD achieved the same result in less than 2 days without any training data. MORLD was also successfully able to generate agonists for D4 dopamine receptor (D4DR) without any initial lead compound information. MORLD can be used in situations where the lead compound is available, or when the lead compound must be identified from virtual screening or from scratch. MORLD has a free web server and source code open to the public. While MORLD is a successful tool for drug design, it has a few limitations: (a) the MORLD algorithm is trained on Q-value. Q-value is the expected future rewards, that is a p-value that has been adjusted for the false discovery rate. For example, a q-value of 2% means that 2% of significant results will result in false positives. This limits the diversification of optimised compounds, (b) as an atom-based model it is unable to explore a large chemical space, and (c) the SA and QED scores are not perfect. Therefore, generated compounds are sometimes chemically inaccurate. Additionally, MORLD is also not a suitable method for drug design when the target protein is disordered or does not have a druggable binding pocket. While a relatively new program, MORLD has been cited in many studies to acknowledge the usefulness of DRL in the field of drug discovery. To date, this algorithm has been applied to only the DDR1 system as mentioned previously.

Ma et al. (2021) created the Structure-Based de Novo Molecular Generator (SBMolGen), another DL method for de novo drug design based on Monte Carlo tree search (MCTS) (Browne et al., 2012a, 2012b) and docking simulations. Molecular generation in SBMolGen is done by ChemTS (Yang et al., 2017), and rDock (Ruiz-Carmona et al., 2014) is employed for docking generated compounds to the target. In the SBMolGen methodology, ChemTS first generates compounds with MCTS and a recurrent neural network (RNN) (Kaur and Mohta, 2019). These generated models are then docked using rDock and evaluated. Based on the top scoring model from the docking simulation, SBMolGen reweights the search tree in ChemTS. Additional molecules are then generated by ChemTS with the new weights. By repeating this process with a RNN, SBMolGen is able to generate compounds that are aware of the target it is binding to. The RNN model in SBMolGen was trained on 250,000 molecules from the ZINC database (Irwin et al., 2012). The results of SBMolGen were benchmarked with four target proteins: cyclin-dependent kinase 2 (CDK2), epidermal growth factor receptor erbB1 (EGFR), adenosine A2A receptor (AA2AR), and beta-2 adrenergic receptor (ADRB2). For each target, the generated molecules were evaluated against known actives from the Database of Useful Decoys: Enhanced (DUD-E) (Mysinger et al., 2012). Molecules generated with SBMolGen covered a larger chemical space than the ZINC data set, had an SA score of less than 3.5 and generally many of these compounds had QED scores greater than 0.8. Furthermore, SBMolGen was also able to find compounds that had a better docking score (as compared to known compounds) for all four target proteins. Fragment molecular orbital (FMO) (Kitaura et al., 1999) analysis of the target protein and generated molecules suggested that SBMolGen designed molecules with high binding affinity. Benchmark results of SBMolGen were compared against GENTRL and showed that SBMolGen was able to produce molecules that had better docking scores. While SBMolGen is faster than GENTRL, it is still limited by computation time. In addition, docking scores of SBMolGen were based on SA score, Lipinski’s rule of five (Lipinski et al., 2001) and PubChem (Kim et al., 2021) filters. While these are useful filters, comprehensive drug discovery still requires the optimization of a large number of molecular properties (Winter et al., 2019). SBMolGen has been employed as benchmark in several other method development studies.

Li et al. (2021b) created DeepLigBuilder, another atom-based DL method for de novo drug design. The deep generative model in DeepLigBuilder is able to design and optimise the 3D structures of ligands directly inside the binding pocket of the target. This method combines a graph convolutional neural network (L-Net) and MCTS, a common technique in reinforcement learning. L-Net iteratively generates and refines molecules by using a state encoder and policy network. During this stage, the state encoder analyses the state of the molecules and passes it to the policy network. The policy network then decides the type, bond order, coordinates, and the number of new atoms to be added. This combination allows the DeepLigBuilder to generate molecules with high binding affinity within the binding pocket. Benchmarking results indicated that L-Net had an overall validity of 96% compared to G-SchNet (Gebauer et al., 2022) which had an output validity of only 77%. The average RMSD of the generated compounds to optimised structures of the generated models with MMFF94 (Halgren, 1996) was only about 0.61 Å. The QED score was above 0.5 for 83.9% of the generated compounds and it was possible to correctly predict the overall distribution of molecular properties. L-Net was also able to re-create the chemical space of the training set almost identically. While L-Net’s performance was highly remarkable, it struggled to generate ring structures as observed by the high standard deviations for bond lengths and torsion angles for aromatic rings. DeepLigBuilder was also tested to generate 3D structures of compounds (as well as lead optimization of known inhibitors) inside the binding pocket of SARS-CoV-2 main protease. The MCTS (as opposed to random search) in DeepLigBuilder successfully lowered the smina scores (Koes et al., 2013) during lead optimization. Furthermore, DeepLigBuilder was able to generate compounds for SARS-CoV-2 main protease with novel chemical structures and high predicted binding affinity and had a success rate of 78.1%. DeepLigBuilder has been cited in several other studies for its use in generating lead compounds for SARS-CoV-2 as discussed above. However, to date, this algorithm has not been applied to other systems.

DeepScaffold is another DL tool for scaffold-based (can also be thought of as fragment-based) drug discovery created by Li et al. (2020). DeepScaffold is able to design compounds from cyclic skeletons, classical molecular scaffolds, and pharmacophore queries. DeepScaffold uses three different methods to enable these different inputs. When the input is a cyclic skeleton, DeepScaffold uses a graph convolutional neural network and variational autoencoder (VAE) (Kingma and Welling, 2014) to complete atom and bond types and generate a scaffold. However, if the input is a molecular scaffold, then the program uses a generative model (Li et al., 2018), from the authors’ previous study, to build the side chains. DeepScaffold can also filter out generated molecules that do not match the input pharmacophore query. DeepScaffold was trained on a dataset that contained 914,464 molecules from the ChEMBL databases with QED larger than 0.5. DeepScaffold was then evaluated for chemical validity and diversity, distribution of molecular properties and side chains. The performance of DeepScaffold to produce chemically valid and unique scaffolds was remarkable with an average of 98.9 and 69.1%, respectively. Molecular properties (molecular weight, solubility, and QED) of the test set molecules against the generated molecules indicate good correlation for scaffolds with more atoms. The model also demonstrated a diversified substitution pattern of side chains and was biased towards adding more atoms to nitrogen atoms. Finally, DeepScaffold model was tested on GPCRs. The model was able to produce chemically valid molecules, however, performed rather poorly to produce unique molecules with increasing structural complexity of scaffolds. The model was also able to reproduce known actives for the GPCRs reasonably well. DeepScaffold has been mentioned in several studies. This algorithm has not yet been applied to other target systems. However, it was referenced for successful scaffold hopping during compound design (Zhang et al., 2022). Additionally, DeepScaffold has one of the highest percentages for validity of generated compounds as compared to other scaffold-based de novo methods (Joshi et al., 2021).

MolAICal, created by Bai et al. (2021), is another fragment-based drug design algorithm. The two modules in MolAICal are trained with a DL model on fragments from the food and drug administrations (FDA) approved drugs and drug-like ligands from the ZINC database. MolAICal can directly generate 3D structures of drug-like compounds in the protein pockets. It employs a sequence-based generative model and a GNN for fragment generation and the fragment is then grown stochastically. A total of 21,064 fragments of FDA-approved drugs and 1,060,000 drug-like ligands from the ZINC database were used to train the generative model. When the grown ligand reaches a certain length, a genetic algorithm is employed to optimise the ligand into the protein pocket based on the ligand-receptor binding score. The docking score used by MolAICal is the Vinardo score (Quiroga and Villarreal, 2016) from AutoDock Vina (Trott and Olson, 2010). The Vinardo score is a summation of several energetic terms. These are Gaussian steric attractions, quadratic steric repulsions, Lennard-Jones potentials, electrostatic interactions, hydrophobic interactions, non-hydrophobic interactions, and non-directional hydrogen bonds. Vinardo scores are reported as the Gibbs free energy (ΔG) of binding in the unit of kcal mol−1. Therefore lower Vinardo scores are more favourable. However, in MolAICal, the coefficients of the Vinardo score were optimised based on a set of 2,903 protein-ligand complexes with experimental data from the PDBbind database (Wang et al., 2005). MolAICal was then tested to design drugs for glucagon receptor (GCGR) and SARS-CoV-2 main protease. For both the GCGR and the SARS-CoV-2 main protease, MolAICal was able to generate compounds that were diversified and had good theoretical binding affinity. In a recent study, MolAICal was employed to calculate the molecular synthetic accessibility score of traditional Chinese medicines in attempts to inhibit the SARS-CoV-2 nucleocapsid protein (Chen et al., 2022). In another application, MolAICal was utilised to calculate the relative binding energy of compounds from the ZINC database to inhibit carbonic anhydrase as a treatment for altitude sickness (Ali et al., 2022).

Finally, Arús-Pous and co-authors describe a fragment-based method that employs DL architecture to generate scaffolds based on SMILES string (Arús-Pous et al., 2020). In this drug-design architecture, a scaffold is generated through an RNN, that is composed of three LSTM cells (Hochreiter and Schmidhuber, 1997), from a SMILES string. Next, the scaffold is ‘decorated’ with side-chains at each attachment point in the scaffold exhaustively. The generated molecules are then filtered based on drug-like properties such as molecular weight, QED, SA, and/or user-specified properties. The decorator model was trained on a set of 4,211 Dopamine Receptor D2 active modulators. Following the training phase, the authors evaluated their generative model and the model was able to produce a diverse set of scaffolds and obtain a large amount of actives. The architecture implemented by Arús-Pous and co-authors is extremely versatile and can be combined with molecular generative architectures. This work by Arús-Pous and co-authors has been highlighted primarily in reviews of artificial intelligence in drug design.

A brief summary of all the previously mentioned methods, along with the respective links to the freely accessible code or webserver, can be found in Table 1. The methods mentioned here capture many of the key areas of how DL has influenced de novo drug design. Nonetheless, this is still an active area of research with novel applications of DL algorithms continuously being developed.Table 1.Summary of de novo drug design methodsDe novo drug designMethodArchitectureSampling methodBenchmark againstYearCode/WebserverMORLDDRLAtom-basedGENTRL2020http://morld.kaist.ac.kr SBMolGenRNN and MCTSAtom-basedGENTRL2021http://github.com/clinfo/SBMolGen DeepLigBuilderGCNN and MCTSAtom-basedG-SchNet2021Not publicly availableDeepScaffoldGCNN and VAEFragment-basedNone2020https://github.com/deep-scaffold MolAICalGNN and Genetic AlgorithmFragment-basedNone2021https://molaical.github.io SMILES-based deep generative scaffold decoratorRNN with LSTM cellsFragment-basedNone2020https://github.com/undeadpixel/reinvent-scaffold-decorator

Illustration of computational de novo drug design. (a) In atom-based drug design, the small molecule is built atom by atom by sampling additions of many different types of atoms. (b) In fragment-based drug design, the small molecule is built by sampling additions of a library of fragments.

Summary of de novo drug design methods

## Section: Binding site prediction

Ligand binding sites in proteins (Fig. 2) encode necessary chemical and structural information for the successful execution of SBDD. Correct identification of these binding sites may help in the understanding of protein function and aid in the design of better drug-like small molecules. While these functional sites can be experimentally determined, the time and cost required to perform such experiments are quite significant. In contrast, computational prediction of protein-ligand binding sites is relatively inexpensive and significantly faster, thus expediting the drug development process. Several computational methods have been proposed over the years for structure-based binding site prediction (Huang, 2009; Le Guilloux et al., 2009; Yu et al., 2010; Tsujikawa et al., 2016; Dias et al., 2017; Wu et al., 2018). These methods can be roughly categorised as geometry-based, energy-based, and templated-based (Mylonas et al., 2021). Geometry-based methods analyse the geometry of the molecular surface of a target protein in order to locate surface cavities. Common approaches to find surface cavities within geometry-based methods include grid system scanning (Weisel et al., 2007), probe sphere filling (Yu et al., 2010) and alpha spheres (Le Guilloux et al., 2009). Energy-based binding site prediction methods involve searching for energetically favourable interactions between protein atoms and a chemical probe with the aid of a force field (Kozakov et al., 2015; Tsujikawa et al., 2016). Schrodinger’s SiteMap (Halgren, 2007, 2009) program combines geometry and energy-based properties to identify potential protein–ligand and protein–protein binding sites. Finally, template-based binding site prediction relies on the assumption that proteins that share structural similarity to the target protein also share functional similarity (Dey et al., 2013). One of the first ML-based binding site prediction algorithms was CryptoSite (Cimermancic et al., 2016). CryptoSite uses as support vector machine (SVM) to classify residues belonging to a binding site on a score range of 0 (not likely)–1 (most likely). Efforts in DL-based binding site prediction methods are fairly new and date back to as early as 2017.Fig. 2.Illustration of computational binding site prediction. In this methodology, 3D voxels are used to identify regions of the protein as potential binding sites (shown as yellow rectangles in the figure). Next, these sites are ranked from most to least probable for a ligand to bind.

Convolutional neural networks (CNNs) are a popular DL architecture for identifying potential binding sites. CNNs are regularised versions of fully connected networks, meaning each neuron in one layer is connected to all neurons in the next layer (Albawi et al., 2017). In a 2D-CNN, the kernel or filter used to extract features from images moves in two directions (x and y) and the input/output data is three-dimensional. 2D-CNNs are typically used on image data. A region-based CNN (R-CNN), is a type of 2D-CNN that implements a selective search algorithm that generates region proposals that are then provided to the CNN architecture to compute the features (Girshick et al., 2014). Region proposals are small regions of the image that potentially contain objects of interest in the input image. The benefit of this method is that the algorithm generates approximately 2,000 region proposals which greatly reduces the computational cost compared to computing CNN features for the entire input image. In a 3D-CNN, the kernel moves in three directions (x, y, and z) and the input/output of the model are four-dimensional. These algorithms are typically used on three-dimensional image data (Hedegaard et al., 2022). A popular 3D-CNN architecture is U-Net (Ronneberger et al., 2015) which has been shown to outperform traditional sliding window convolutional networks. The model provides many advantages over patch-based segmentation approaches as it preserves the full context of the input image through an end-to-end pipeline process for the entire image and requires few training samples. One increasingly popular CNN architecture is ResNet (He et al., 2016). ResNet overcomes the vanishing gradient problem, which occurs when the neural network training algorithm attempts to find weights that bring the loss function to a minimal value. If the network has too many layers, the gradient becomes increasingly small until it disappears and optimization cannot continue. ResNet overcomes this problem by creating a deep residual learning framework. This framework consists of shortcut connections that add intermediate inputs to the output of a group of convolution blocks. The shortcut connections perform identity mapping, allowing for smoother gradient flow and ensures important features are carried until the final layers. We review several notable recent examples of these architectures below.

Jiménez et al. (2017) developed the first DL-based protein-ligand binding site prediction algorithm, DeepSite. Based on a 4-layer convolutional neural network (DCNN) architecture, DeepSite treats the target protein as an image on a 3D grid. Each atom within the voxels of the grid is defined by atom-based physicochemical properties obtained from AutoDock 4 (Morris et al., 2009). Next, the entire grid is divided into subgrids in order to defined the local properties of smaller protein areas. These subgrids are then scored by the DCNN as potential sites for ligand binding. The DCNN architecture in DeepSite was trained on 7,622 proteins from the sc-PDB (Desaphy et al., 2015) database. Pocket prediction performance was evaluated by distance and shape of the predicted binding site to that of the real binding site. To accomplish this, the authors make use of two metrics, distance to centre of binding site (DCC) and discretized volumetric overlap (DVO). These metrics were also used to benchmark DeepSite against Fpocket (Le Guilloux et al., 2009) and Concavity (Capra et al., 2009) (binding site prediction algorithms). Based on the binding site analysis metrics, DeepSite was able to provide a more accurate binding site prediction compared to Fpocket and Concavity. Further analysis of DeepSite on proteins with diverse folds in the SCOPe database showed no bias towards any specific protein fold. However, there is still room for improvement as DeepSite does not have descriptors for atom-based polarizability effects or descriptors for water molecules. Since its release, DeepSite has been a highly successful tool and has been referenced in several studies. A few notable applications are its use to study the binding process and interaction of antibiotic drugs and lysozymes (Rial et al., 2022), analysis of the potential interaction mechanism of sweeteners with aroma compounds in passion fruit juice (Xiao et al., 2022), and identifying binding pockets for drug candidates for Hepatocellular carcinoma (predominant subtype of liver cancer) (Tang et al., 2022).

FRSite, introduced by Jiang et al. (2019), is another binding site prediction method based on a region-based convolutional neural network (R-CNN), an object-detection DL architecture (Ren et al., 2015). In this methodology, the target protein is treated as a 3D image and the binding site is treated as the object within the image to be detected. Similar to DeepSite, FRSite also treats each atom in the target protein on a grid with eight descriptors from high-throughput molecular dynamics (HTMD) (Doerr et al., 2016). Next, the entire grid is fed into a region proposal network-3D (RPN-3D) module in FRSite to detect potential binding sites. Once these potential binding sites are found by RPN-3D, FRSite uses its classifier to score the binding site. FRSite was trained on the same training dataset as DeepSite. Following the training, FRSite was evaluated for DCC and DVO as well as compared to those of other prediction methods. Compared to Fpocket and DeepSite, FRSite outperformed the other algorithms in predicting more accurate binding sites of proteins. Additionally, FRSite is also able to predict the receptor grid of the binding site (which can be used to estimate the size of the pocket). The authors further showed that the DVO estimated by FRSite was more accurate than that of Fpocket. FRSite has been referenced in several review articles and as benchmark in other method development studies.

Stepniewska-Dziubinska et al. (2020) introduced another DL-based binding site prediction method called Kalasanty. Similar to DeepSite, Kalasanty also treats the target protein as a 3D image. However, Kalasanty uses a DL model that is more similar to U-Net (Ronneberger et al., 2015) to treat the problem as a 3D image segmentation problem. In this approach, each featurized segment (by atomic properties) of the protein is assigned a certain probability of being a part of a pocket where a small molecule can dock. The DL model in Kalasanty was trained on 15,860 structures with binding site data from sc-PDB dataset. Prediction results from Kalasanty were then evaluated for correct DCC and DVO as well compared to those from DeepSite. Kalasanty correctly predicted binding sites two times better than DeepSite. Furthermore, Kalasanty had DCC values lower (i.e. closer to centre of the actual binding site) than DeepSite. Additionally, the binding sites predicted by DeepSite were bigger (lower DVO) and not accurately modelled when compared to that of Kalasanty (higher DVO). While Kalasanty is a successful binding site prediction model, the dataset used to train the DL model is based on proteins with deep cavities. Therefore this model may not be suitable for cases where the binding sites are located on flat surfaces. While being a newly released method, Kalasanty has already been subjected to many benchmarks in other method development studies. In addition, relevance of Kalasanty in enzyme engineering has been discussed in this review (Singh et al., 2021).

Following the works of DeepSite (Jiménez et al., 2017), FRSite (Jiang et al., 2019), and Kalasanty (Stepniewska-Dziubinska et al., 2020), Mylonas et al. (2021) developed DeepSurf. DeepSurf uses a variant (Dimou et al., 2019) of the DL network architecture known as residual network (ResNet) (He et al., 2016). The authors propose an 18-layer ResNet to which the surface representation of the target protein is passed in the form of a 3D grid with physiochemical features. The network then predicts a binding site score for the surface presenting points. These points are then clustered and ranked to predict the binding site. The network was trained on a set of 15,182 structures from the sc-PDB database. The distance between the predicted and the real binding site centre and other metrics were used to evaluate DeepSurf. Furthermore, DeepSurf was benchmarked against DL-based methods such as DeepSite, FRSite and Kalasanty as well non-ML methods. The authors showed that compared to DeepSurf, Kalasanty was unable to predict binding sites for a large number of proteins. Interestingly, DeepSite with its shallow neural network layer performed similarly to DeepSurf. While the non-ML methods such as Fpocket (geometry-based) and AutoSite (energy-based) (Ravindranath and Sanner, 2016) performed poorly, COFACTOR (template-based) (Roy et al., 2012) performed similarly when compared to DeepSurf. However, all ML methods generally tend to predict a smaller number of binding sites that are closer to the actual binding sites compared to non-ML methods. DeepSurf has been mentioned in several other studies. In most of these cases, DeepSurf was used as benchmark for other method development and/or other reviews.

Kandel et al. (2021) developed PUResNet where the protein structure is also treated as a 3D image and the binding site as the object within the image. PUResNet employs variants of two DL architectures, ResNet and U-Net, to address this issue. PUResNet was trained on a set of 5,020 protein structures from the sc-PDB database, and evaluated with DCC, DVO and proportion of ligand inside binding pocket (PLI). The authors also benchmarked their method against Kalasanty, developed by Stepniewska-Dziubinska et al., with a k-fold cross-validation and accuracy test. Briefly, k-fold cross-validation is a method employed to estimate the predictive power of the model on new data. From the benchmarking results, it was observed that PUResNet exhibited slightly better performance during the cross-validation and accuracy test than Kalasanty, despite the fact that PUResNet was trained with only a fraction (1/3) of the dataset used to train Kalasanty. PUResNet has been referenced in several other method development studies as well as other review articles, including a review about pharmacological chaperones for rare diseases (Scafuri et al., 2022).

Along with primary binding site prediction, allosteric site prediction has also been an active area of study (Goncearenco et al., 2013; Panjkovich and Daura, 2014; Greener and Sternberg, 2015; Song et al., 2017; Tian et al., 2021). The term allosteric binding site refers to a site other than a protein’s primary (orthosteric) active site where a compound can bind, resulting in conformational and dynamic changes (Srinivasan et al., 2014). The incorporation of these dynamic changes is critical to accurately predict allosteric sites. The main difference between orthosteric and allosteric ligand binding site prediction algorithms is the inclusion of protein dynamics. Additionally, the algorithms may differ based on the dataset that the DL model was trained on, as the quality and robustness of the data significantly impacts the algorithms’ features and results. Here we review BiteNet (Kozlovskii and Popov, 2020), a DL-based method for detecting allosteric sites of target proteins from their dynamic ensembles. Similar to other site prediction methods, this work is also inspired by the applications of DL in computer vision (Islam et al., 2016). In BiteNet, the input structure of the target protein is placed on a grid and processed with a neural network composed of 10 3D convolutional layers. BiteNet then outputs the centre of the predicted allosteric binding sites, assigns scores and identifies the neighbouring residues within 6 Å radius. BiteNet captures protein dynamics through an ensemble of protein structures gathered from molecular dynamic simulations. When the input is an ensemble of protein structures, BiteNet employs three different clustering algorithms to group the predicted binding site centres and their neighbouring residues and ranks the clusters from most to least probable. The convolutional neural network in BiteNet was trained on 5,946 structures from the PDB. To test for efficiency and accuracy, the authors tested BiteNet’s predictive power on the P2X3 receptor of the ATP-gated cation channel family, the epidermal growth factor receptor of the kinase family, and the adenosine A2A receptor of the G-protein coupled receptor family. In all three cases, it was observed that BiteNet was able to detect conformation-specific allosteric binding sites. Furthermore, BiteNet was benchmarked against FPocket (Le Guilloux et al., 2009), MetaPocket (Huang, 2009), DeepSite (Jiménez et al., 2017), SiteHound (Hernandez et al., 2009) and P2Rank (Krivák and Hoksza, 2018) for precision and computational speed on an independent benchmark dataset. In terms of speed and precision, BiteNet outperformed all other methods. BiteNet has been referenced in several other method development studies.

From this summary, it is evident that DL-based methods for binding site prediction have continuously outperformed traditional methods. A summary of the DL-based binding site prediction methods reviewed in this article is presented in Table 2. While these methods are highly successful, they are also limited. For instance, the dataset used to train most of these methods ignores noncanonical amino acids and heavy metals. Thus, these models are still not generalised enough to encompass the astronomical complexities in drug discovery and there is still a huge potential for improvement in the future.Table 2.Summary of binding site prediction methodsBinding site predictionMethodArchitectureType of siteBenchmark againstYearCode/WebserverDeepSite3D-CNNActiveFpocket and Concavity2017www.playmolecule.org/deepsite/ FRSiteR-CNNActiveFpocket and DeepSite2019Not publicly availableKalasanty3D-CNN (variant of U-Net)ActiveDeepSite2020https://gitlab.com/cheminfIBB/kalasanty DeepSurf3D-CNN (variant of ResNet)ActiveDeepSite, FRSite, Kalasanty, Fpocket, AutoSite and COFACTOR2020https://github.com/stemylonas/DeepSurf PUResNet3D-CNN (variant of ResNet and U-Net)ActiveKalasanty2021https://github.com/jivankandel/PUResNet BiteNet3D-CNNAllostericFPocket, MetaPocket, DeepSite, SiteHound, and P2Rank2020https://github.com/i-Molecule/bitenet https://sites.skoltech.ru/imolecule/tools/bitenet

Illustration of computational binding site prediction. In this methodology, 3D voxels are used to identify regions of the protein as potential binding sites (shown as yellow rectangles in the figure). Next, these sites are ranked from most to least probable for a ligand to bind.

Summary of binding site prediction methods

## Section: Binding affinity prediction

In SBDD, an accurate prediction of protein-ligand binding affinity can facilitate the discovery of novel drug-like compounds (Fig. 3). In order to achieve such a prediction, a small molecule is typically docked to the target protein (Fig. 3a) with a molecular docking program. Then a score function (SF) is employed to predict the protein-ligand binding affinity (Fig. 3b). Such SFs (if accurate and fast) allow researchers to screen a large number of compounds to identify potential drug-like small molecules. Over the years, several SFs have been developed to approximate the interaction energy between protein and ligand (Jones et al., 1997; Jain, 2003; Friesner et al., 2004; Shivakumar et al., 2010; Trott and Olson, 2010; Wang et al., 2015). These can be classified into physics-based, empirical, and knowledge-based SFs. Physics-based methods include scoring functions based on force fields, solvation models and quantum mechanics (QM) methods. In physics-based SFs, interactions between the protein and the ligand are calculated based on terms such as van der Waals interaction, electrostatic interaction, torsion entropy, solvent effects and others. Due to the limited accuracy of these terms, QM methods hybridised with molecular mechanics (QM-MM) methods have also been utilised to address covalent interactions, polarisation and charge transfer processes (Hayik et al., 2010). While QM-MM methods are more accurate, they are also computationally expensive and impractical for screening large number of compounds. Empirical SFs estimate binding affinity by making simplistic approximations to the physics-based energy terms such as hydrogen bonds, hydrophobic effects, steric clashes and other important interactions in a protein-ligand system (Böhm, 1994). These terms are usually associated with weights that are optimised using experimental binding affinity data. Due to the simplicity of the energy terms, empirical score functions are typically less computationally expensive. Knowledge-based SFs are derived based on a statistical analysis of protein-ligand complexes from available 3D structures. In knowledge-based SFs, the frequency of different atom pairs occurring within different distances is assumed to play a key role in the interaction of the atoms. These frequencies are then converted to a distance-dependent potential of mean force (Muegge, 2006). Knowledge-based SFs are also computationally inexpensive and have similar accuracies compared to physics-based methods. However, since knowledge-based SFs do not directly account for experimental binding affinity data, discrepancies between predicted and experimental binding affinity are frequently observed (Stahl and Rarey, 2001). Recently, DL-based SFs have also been developed to predict binding affinity and have been shown to outperform traditional SF methods. These models are usually trained on a large dataset with known protein-ligand binding affinity. In DL-based SFs, feautrizing the protein-ligand system plays a key role in its ability to correctly predict the binding affinity. Here, we briefly summarise some of the DL-based methods that have been successful in predicting protein-ligand binding affinity.Fig. 3.Illustration of computational binding affinity prediction. (a) Small molecule is docked into a target protein. (b) The binding site and the small molecule are then characterised with many features in order to predict the binding affinity. The atoms in the small molecule are shown in grey, blue and red for carbon, nitrogen and oxygen, respectively. The carbon, nitrogen, oxygen and sulphur of the binding site residues are shown in blue, purple, red and yellow, respectively. Bonds in the small molecule ligand are shown in black.

CNNs also serve as popular architectures in binding affinity prediction. Recent examples include variants of traditional 3D-CNNs and ResNet algorithms. Additional CNN-based architectures developed to solve binding affinity prediction are SqueezeNet (Iandola et al., 2016) and ShuffleNet (Zhang et al., 2018). SqueezeNet is a convolution neural network that utilises a design strategy aimed at reducing the number of parameters. Fewer parameters offer several advantages such as: more efficient distributed training, smaller memory storage requirements, and less communication required for over-the-air model updates. SqueezeNet accomplishes its smaller size via Fire modules which replace traditional 3 × 3 filters (kernels) with 1 × 1 filters. ShuffleNet is a CNN architecture that was designed for mobile devices with very limited computing power. In order to reduce computational cost and maintain accuracy, ShuffleNet employs pointwise group convolution and channel shuffle. Grouped convolution makes use of a multiple kernels (filters) per layer, resulting in multiple channel output per layer. This technique led to wider networks helping learn low- and high-level features (Xie et al., 2017), and it has been shown to improve classification accuracy (Xie et al., 2017). Channel shuffle is an operation that helps information flow across feature channels. We review several notable recent examples of these architectures below.

Jiménez et al. (2018) developed K DEEP, a DL-based method that relies on 3D-convolutional neural network (3D-CNN), to predict protein-ligand binding affinity. The DL architecture in K DEEP is designed based on the image classification DL architecture SqueezeNet (Iandola et al., 2016). In K DEEP, residues of the target protein at the binding site and the ligand are placed on a grid. Next, each atom of these interacting residues and the ligand are featurized by eight pharmacophoric-like properties. These descriptors were used to train the K DEEP network on a training dataset that was composed of 3,767 protein-ligand complexes from the PDBbind (Wang et al., 2005) database. Once the network was trained, K DEEP was benchmarked against RF-Score (Ballester and Mitchell, 2010), X-Score (Wang et al., 2002), and CyScore (Cao and Li, 2014) (three other non-DL-based binding affinity prediction methods) for performance and accuracy. Briefly, RF-score is a random forest model trained on a large dataset of molecular interactions. A low RF-score generally corresponds to more favourable interactions. X-Score is an empirical score function based on terms such as van der Waals interactions, hydrogen bonding, deformation penalties, and hydrophobic effects. X-Score values are reported as the Gibbs free energy (ΔG) of binding in the unit of kcal mol−1. Therefore a lower value is indicative of more energetically favourable interactions. Cyscore is another empirical score function that has been optimised based on hydrophobic free energy, van der Waals interaction energy, hydrogen-bond energy and the ligand’s entropy. Cyscore values are comparable to the ΔG (kcal mol−1) of binding. Therefore, a lower Cyscore indicates a higher binding affinity. Compared to other binding affinity prediction methods, K DEEP exhibited the lowest root mean square error (RMSE) with respect to the predicted and experimental affinity. The Pearson’s correlation coefficient of K DEEP was higher than that of X-Score and CyScore but was very similar to that of RF-Score. Furthermore, when these methods were benchmarked against independent datasets that the network had not seen more, K DEEP underperformed compared to RF-Score. Binding affinity predictions from K DEEP are reported as the ΔG (kcal mol−1) of binding. K DEEP is a highly successful program and has been used as a tool in numerous studies. A few examples where K DEEP has been successfully utilised are: to engineer maltooligosaccharide-forming amylases and optimise the biosynthesis of maltooligosaccharides (Ding et al., 2022), to determine the inhibitory properties of antiviral drugs and their structural analogues towards coronavirus (Kalamatianos, 2022), during virtual screening (of lead compounds and analogs) to chemically inhibit processes controlled by RecA protein of Acinetobacter baumannii (Tiwari, 2022) and so forth. While K DEEP is a versatile SF for binding affinity predictions, the authors argued that additional exploration of the network architecture and a thorough featurization of the molecular descriptor could further improve the SF’s performance.

Pafnucy (Stepniewska-Dziubinska et al., 2018), developed by Stepniewska-Dzuibinska et. al, is another DL model for predicting binding affinity of protein-ligand complexes. Similar to K DEEP, Pafnucy’s 3D-CNN also treats the ligand and interacting residues of the target protein as a 3D image. This information is then used to create a 3D grid and each atom in the grid is featurized with 19 atomic properties. The network was trained on experimental dissociation constant values of 11,906 protein-ligand complexes (from the PDBbind database) and then evaluated for its performance using RMSE, mean absolute error (MAE), Pearson correlation coefficient, and standard deviation in regression (SD). Therefore, the predicted values from Pafnucy are comparable to experimental dissociation constants. Furthermore, the prediction power of Pafnucy was benchmarked against binding affinity prediction methods such as X-Score, RF-Score, ChemScore, PLP1, ChemPLP (Verdonk et al., 2003), and G-Score (SYBYL 2022). Briefly, ChemScore is an empirical score function based on simple contact terms, a simplistic model for hydrogen bonds, and a penalty function based on flexibility. PLP1 is also an empirical score function that uses terms to account for hydrogen bonds, van der Waals interactions, repulsion potentials, and piecewise linear potentials to model the steric complementarity between protein and ligand. ChemPLP is another empirical score function that is very similar to PLP1. However, in addition to the terms in PLP1, ChemPLP also considers the distance and angle-dependent hydrogen and metal bonding terms from ChemScore. G-Score is a force-field based score function. It is composed of a protein-ligand complexation term (optimised Lenard-Jones potential), a hydrogen bonding term (approximated) and an internal energy term (approximated). All score values from ChemScore, PLP1, ChemPLP, and G-score are reported as the ΔG (kcal mol−1) of binding, therefore lower scores are considered as more favourable interactions. Pafnucy has been successfully used to study the interaction of the mannose receptor of macrophages with carbohydrate ligands (Zlotnikov and Kudryashova, 2022), as well as has been used as benchmark to develop several newer methods. Pafnucy outperformed all other methods except for RF-Score v3 (Li et al., 2015). However, the observed difference in performance was negligible. Additionally, Pafnucy outperformed all 20 binding affinity prediction methods that were used in the CASF-2013 (Li et al., 2014) benchmark. Besides binding affinity prediction, the authors of Pafnucy argue that their model may also be helpful to guide ligand optimization during molecular docking.

Methods that employ DL techniques usually require a large amount of data in order for the method to be properly trained. Thus, limited data could pose a challenge. DeepAtom, a DL method for binding affinity prediction of protein-ligand complexes, developed by Li et al. (2019) addresses this concern with a novel 3D-CNN architecture. The authors of DeepAtom developed an efficient 3D-CNN architecture based on ShuffleNet (Zhang et al., 2018). Briefly, ShuffleNet is an extremely computation-efficient CNN architecture that is designed for cases with limited computational resources. Using this architecture allowed DeepAtom’s network to be designed with fewer trainable parameters, deep layers, and limited training data. Similar to other methods, DeepAtom also treats the protein-ligand complex as a 3D image. In DeepAtom the interacting residues of the target protein (defined from the centre of the ligand) as well as the ligand are voxelized in a grid. The atoms occupying the voxels are feauturized with 12 atomic properties. To evaluate DeepAtom, the authors first trained DeepAtom, Pafnucy, and RF-Score with 3,390 complexes from the PDBbind database. These models were then evaluated with Pearson correlation coefficient, MAE, RMSE and SD. DeepAtom showed significant improvement over Pafnucy and slight improvement over RF-Score in all metrics. Next, the authors re-trained DeepAtom, Pafnucy and RF-Score on a larger training dataset (9,383 complexes) and evaluated all three models for performance. DeepAtom performed significantly better than both Pafnucy and RF-Score. Since the networks in DeepAtom and Pafnucy are based on 3D-CNN, it was observed that a well-designed network architecture (DeepAtom) can yield better predictions with limited data suggesting that effective training in the deep layers results in improvements in the capacity for learning and generalisation. DeepAtom has been employed in several method development studies (as benchmark) and other review articles.

One key factor of a successful DL scoring function is being able to train the model on features that are important to protein-ligand binding affinity. While the methods discussed so far focused on features that localise to the ligand binding site, OnionNet, developed by Zheng et al. (2019), takes a different approach. The authors treat the protein-ligand complex as a 2D image with one colour channel and use a 2D-CNN architecture to train the binding affinity prediction model. OnionNet is able to capture both local and non-local interactions between the protein and ligand by grouping contacts between each atom of the ligand to atoms in the protein in a set of 60 distance groups. In this way, OnionNet uses 3,840 features to define local and non-local interaction between the target protein and ligand. The network was trained on 11,906 protein-ligand complexes from the PDBbind database. Therefore, predicted values from OnionNet are comparable to experimental dissociation constants. Following the training, the prediction model was evaluated for accuracy and also compared to other ML and non-ML binding affinity prediction methods. In terms of RMSE and Pearson correlation coefficient, OnionNet outperformed Pafnucy and RF-Score. While K DEEP performed slightly better than OnionNet, OnionNet significantly outperformed other non-ML SFs used in the CASF-2013 benchmark. The authors further showed that both the local and non-local interactions contribute significantly to the prediction capability of the model. OnionNet has been utilised as a benchmark during the development of several binding affinity prediction methods.

AK-Score developed by Kwon et al. (2020) is yet another binding affinity prediction method that was developed based on the ResNet (He et al., 2016) architecture. Similar to other methods, the protein-ligand system is represented as a 3D image on a grid, with each atom on the grid being defined with eight atomic properties. However, the network architecture uses an ensemble-based approach to perform the binding affinity prediction. AK-Score utilises 20 independently trained networks to make predictions and the average of those values is considered as the final prediction. AK-Scores are reported as the ΔG (kcal mol−1) of binding, therefore a low score corresponds to a more energetically favourable interaction. The networks were trained on 3,772 protein-ligand complexes from the PDBbind database. AK-Score was then evaluated on the CASF-2016 benchmark dataset with Pearson correlation coefficient, Spearman correlation coefficient, Kendall tau, predictive index metrics, MAE, and RSME. AK-Score with ensemble-based networks was benchmarked against AK-Score with a single network and K DEEP. These results showed that the AK-Score ensemble network model had a lower MAE and RMSE as well as higher Pearson correlation coefficient, Spearman correlation coefficient, Kendall tau and predictive index as compared to other methods. Furthermore, from feature analysis, it was shown that the excluded volume of atoms, spatial distribution of hydrophobic and aromatic atoms of the ligand and protein, as well as the distribution of hydrogen bond acceptors of the protein were particularly important for the network to accurately determine the binding affinity. Therefore, more accurate calculations of such descriptors may play an important role in improving the ensemble-based network of AK-Score. AK-Score has been reviewed in several reviews and its prediction quality has been compared in other method development studies.

Similar to AK-Score, RosENet developed by Hassan-Harrirou et al. (2020), also uses an ensemble-based 3D-CNN. However, RosENet uses a hybrid approach where it employs the 3D-CNN to combine molecular mechanics energies calculated from the Rosetta force field (Alford et al., 2017) with molecular descriptors. Briefly, the Rosetta software suite includes algorithms for computational modelling and analysis of protein structures and has enabled scientific advances in areas such as protein design, enzyme design, molecular docking and structure prediction (Leman et al., 2020). The network architecture of RosENet was developed based on the ResNet architecture. Similar to previous methods, protein-ligand complexes were represented in a 3D grid. Atoms of the protein-ligand complex were featurized with 12 molecular descriptors from HTMD (Doerr et al., 2016) and 6 molecular energies obtained from Rosetta. The network was then trained on a curated dataset of 4,463 protein-ligand complexes obtained from the PDBbind database. Therefore, the predicted values from RosENet are comparable to experimental dissociation constants. To evaluate RosENet with respect to the quality of its predictions, the network was first optimised based on a combination of multiple features and architectures, and then compared to Pafnucy and OnionNet. The authors tested two neural network architectures: ResNet (a deep residual neural network) and SqueezeNet (a smaller network architecture). RosENet showed a lower RMSE with the ResNet architecture than it did with the SqueezeNet architecture. Thus, the authors argue that the network implemented in the SqueezeNet architecture was not deep enough to generalise the molecular mechanics energies that were used to featurize the complex. RosENet was also trained with a smaller number of features, leading to a decrease in the prediction quality, however, this change was considered to be insignificant. Overall, RosENet performed better than Pafnucy and comparably to OnionNet. This suggested that the molecular energies described in RosENet may be able to represent similar local and non-local interactions described by the OnionNet. Finally, the RMSE of RosENet decreased when the average of the five best predictions was used. In future studies, the authors of RosENet propose to improve their molecular features by extracting additional dynamic properties from molecular dynamics simulations. RosENet has been featured in other method development studies and as well as review articles.

Accurate prediction of binding affinity is a key step during the drug discovery process. Despite several limitations, recently developed DL-based methods for binding affinity prediction have generally significantly outperformed traditional methods. A summary of such DL-based methods as reviewed in this article can be found in Table 3. These studies indicate the availability of successful in silico tools for rapid and accurate prediction of protein-ligand binding affinity. Additionally, a few ML-based methods (Aggarwal and Koes, 2020; Bao et al., 2021) have also been trained to predict ‘the root mean square deviation (RMSD)’ of a docked structure with reference to the native bound structure. Deep Binding Structure RMSD Prediction model (DeepBSP) (Bao et al., 2021) is one such method that employs a 3D-CNN (same model architecture as K DEEP) to achieve this purpose. DeepBSP exhibited accuracy on predicting RMSD. Furthermore, the docking power of DeepBSP (through model selection with lowest predicted RMSD), outperformed all other scoring functions benchmarked in CASF-2016. While these methods have been successful, this field continues to grow and evolve with new advancements in ML.Table 3.Summary of binding affinity prediction methodsBinding affinity predictionMethodArchitectureFeatures usedBenchmark againstYearCode/WebserverK DEEP3D-CNN (variant of SqueezeNet)Atomic descriptors for local interactionsRF-Score, X-Score, and CyScore2018www.playmolecule.org/kdeep/ Pafnucy3D-CNNAtomic descriptors for local interactionsX-Score, RF-Score, ChemScore, ChemPLP, PLP1, and G-Score2018https://gitlab.com/cheminfIBB/pafnucy DeepAtom3D-CNN (variant of ShuffleNet)Atomic descriptors for local interactionsPafnucy and RF-Score2019Not publicly availableOnionNet2D-CNNAtomic descriptors for local and non-local interactionsPafnucy, RF-Score, and K DEEP2019http://github.com/zhenglz/onionnet/ AK-Score3D-CNN ensemble-based (variant of ResNet)Atomic descriptors for local interactionsAK-Score single network and K DEEP2020Not publicly availableRosENet3D-CNN (variant of ResNet)Molecular energies from Rosetta and atomic descriptorsK DEEP, Pafnucy, and OnionNet2020https://github.com/DS3Lab/RosENet/tree/master/models

Illustration of computational binding affinity prediction. (a) Small molecule is docked into a target protein. (b) The binding site and the small molecule are then characterised with many features in order to predict the binding affinity. The atoms in the small molecule are shown in grey, blue and red for carbon, nitrogen and oxygen, respectively. The carbon, nitrogen, oxygen and sulphur of the binding site residues are shown in blue, purple, red and yellow, respectively. Bonds in the small molecule ligand are shown in black.

Summary of binding affinity prediction methods

## Section: Conclusion

Over recent years, ML has become an increasingly popular field of study. Application of these methods to biological problems will only continue to grow as academic and industry users create better tools to predict biomolecular structure, treat disease, and improve public health. In this work, we summarised recent DL applications in three structure-based drug discovery categories: de novo drug design, binding site prediction and binding affinity prediction. In the interest of the reader, we also provide links to the various methods’ publicly available source code or webservers. The use of ML (more recently DL) methods is not limited solely to SBDD, and they have also been applied to all other areas of the drug discovery pipeline such as LBDD (Bahi and Batouche, 2018), lead optimization (de Souza Neto et al., 2020), and assessment of absorption (Shin et al., 2018), metabolism (Wang et al., 2020; Litsa et al., 2021), binding kinetics (De Benedetti and Fanelli, 2018; Mardt et al., 2018; Gao et al., 2019; Nunes-Alves et al., 2020; Feizpour et al., 2021; Obeid et al., 2021; Hoffmann et al., 2022), efficacy (Lin et al., 2018; Benning et al., 2020; Li et al., 2021a; Zhu et al., 2021) and toxicity properties (Ferreira and Andricopulo, 2019; Liu et al., 2019; Shi et al., 2019; Cáceres et al., 2020; Feinberg et al., 2020). While these studies are not covered in this review, interested readers are encouraged to review these recent works as well.

With the expansion of large datasets, DL algorithms will only become more accurate, thereby increasing cost-effectiveness and time efficiency. However, a major critique of DL methods is their inherit ‘black-box’ nature. In order for the use of large datasets to be truly successful, we must begin to understand the nature of DL algorithms and the connections they make. Another common pitfall of any ML algorithm is the quality of its training dataset(s). In any biological application, an algorithm may easily become hyper-specific to a certain motif if it is not exposed to an unbiased training set. This lack of generalisation prevents the algorithm from solving real-world problems.

Recently the company DeepMind and the Baker research group have released AlphaFold (Jumper et al., 2021) and RoseTTAFold (Baek et al., 2021), DL algorithms for protein structure prediction. These algorithms have been credited with ‘solving the protein folding problem’. Given the impressive prediction capabilities of these tools, it is natural to investigate how relevant such DL-based protein conformations are for drug design. For example, recently the crystal structure of the σ2 receptor has been reported (Alon et al., 2021). In this study, the authors also screened a large library of compounds to the X-ray structure (through molecular docking), which resulted in the identification of around 130 active compounds. However, the molecular docking of these same hits scored relatively poorly against the AlphaFold model. This suggests that additional efforts are needed to employ predicted structures successfully in drug discovery. Within the last year, the CEO of DeepMind announced the plan of applying their knowledge of artificial intelligence to drug discovery with the formation of a new company called Isomorphic Labs (https://www.isomorphiclabs.com). This year another company, CHARM Therapeutics (https://charmtx.com), in the UK have launched DragonFold. DragonFold is the first DL algorithm to rapidly predict protein-ligand co-folding. While we wait on more details of these developments, they however foreshadow a very promising future for the field of computer-aided drug discovery, as the brightest minds from industry and academia continue to collaborate and improve upon ML applications. While the future of the field appears very promising, we must also keep in mind the ethics of good science. As demonstrated by Urbina et al. (2022), artificial intelligence was utilised to predict the toxicity of small molecules. The algorithm developed by the Collaborations team predicted many compounds with higher toxicity as compared to the nerve agent VX. The team calls for a strengthening of ethical training of students, as well as for artificial intelligence drug discovery companies to create a code of conduct to properly train employees and establish protection measures for their technology.


---

# Applications of Quantitative Systems Pharmacology (QSP) in Drug Development for NAFLD and NASH and Its Regulatory Application

- **Authors:** Scott Q Siler
- **Issuer:** Pharmaceutical research
- **Type:** Scientific article
- **Published:** 2022-05-24
- **Language:** en
- **DOI:** 10.1007/s11095-022-03295-x
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35610402/
- **Licence:** CC-BY

## Page 1 (Section: Applications of Quantitative Systems Pharmacology (QSP) in Drug Development for NAFLD and NASH and Its Regulatory Application)

Vol.:(0123456789)
1 3
https://doi.org/10.1007/s11095-022-03295-x
EXPERT REVIEW
Applications of Quantitative Systems Pharmacology (QSP) in Drug 
Development for NAFLD and NASH and Its Regulatory Application
Scott Q. Siler1
Received: 21 March 2022 / Accepted: 17 May 2022 
© The Author(s) 2022
Abstract
Nonalcoholic steatohepatitis (NASH) is a widely prevalent disease, but approved pharmaceutical treatments are not avail-
able. As such, there is great activity within the pharmaceutical industry to accelerate drug development in this area and 
improve the quality of life and reduce mortality for NASH patients. The use of quantitative systems pharmacology (QSP) 
can help make this overall process more efficient. This mechanism-based mathematical modeling approach describes both 
the pathophysiology of a disease and how pharmacological interventions can modify pathophysiologic mechanisms. Multiple 
capabilities are provided by QSP modeling, including the use of model predictions to optimize clinical studies. The use of this 
approach has grown over the last 20 years, motivating discussions between modelers and regulators to agree upon methodo-
logic standards. These include model transparency, documentation, and inclusion of clinical pharmacodynamic biomarkers. 
Several QSP models have been developed that describe NASH pathophysiology to varying extents. One specific application 
of NAFLDsym, a QSP model of NASH, is described in this manuscript. Simulations were performed to help understand if 
patient behaviors could help explain the relatively high rate of fibrosis stage reductions in placebo cohorts. Simulated food 
intake and body weight fluctuated periodically over time. The relatively slow turnover of liver collagen allowed persistent 
reductions in predicted fibrosis stage despite return to baseline for liver fat, plasma ALT, and the NAFLD activity score. 
Mechanistic insights such as this that have been derived from QSP models can help expedite the development of safe and 
effective treatments for NASH patients.
KEY WORDS  fibrosis · modeling · NASH · QSP
Manuscript
Non-alcoholic fatty liver disease (NAFLD) and non-alco-
holic steatohepatitis (NASH) are diseases of the liver that are 
largely the result of excessive lipid accumulation and par-
titioning (1, 2). The incidence of NAFLD and NASH have 
grown substantially over the last 20 years, with estimates 
of 20–40% of populations in various locations throughout 
the world having NAFLD or NASH (3). As such, the inter-
est in understanding and treating this disease has increased 
substantially. NASH is reasonably well-understood, with 
the overall understanding growing every year. The patho-
physiology includes contributions from alterations in lipid 
partitioning, lipotoxicity, inflammation, and fibrosis (1, 2). 
Data from clinical studies with the numerous potential treat-
ments have helped increase the overall understanding of the 
disease in addition to focused clinical studies.
NASH drug development efforts have increased sub-
stantially in the last 10 years. A considerable number of 
potential treatments are being developed across the pharma-
ceutical industry (4, 5). In addition to monotherapies, sev-
eral compounds are being developed as combination treat-
ments; complimentary mechanisms of action may provide 
additional clinical benefit. Unfortunately, the development 
of several compounds has been terminated (6). This has 
primarily been due to an insufficient ability to demonstrate 
favorable responses in treatment cohorts as compared with 
placebo cohorts.
Regulators want to ensure that NASH drugs being devel-
oped are both safe and effective. The United States’ Food and 
Drug Administration has provided definitions of endpoints 
that have the greatest chance of providing health benefits of 
 *	 Scott Q. Siler 
	
scott.siler@simulations-plus.com
1	
DILIsym Services, a Division of Simulations Plus, 
510‑862‑6027, 6 Davis Drive, PO Box 12317, 
Research Triangle Park, North Carolina 27709, USA
/ Published online: 24 May 2022
Pharmaceutical Research (2022) 39:1789–1802

## Page 2 (Section: Applications of Quantitative Systems Pharmacology (QSP) in Drug Development for NAFLD and NASH and Its Regulatory Application)

1 3
patients (7). Data are not yet available identifying ideal sur-
rogate endpoints for preventing adverse clinical outcomes. 
Measures derived from liver biopsies are currently employed 
to characterize resolution of NASH (based on specific histo-
logic endpoints related to pathophysiologic components) as 
well as improvements in hepatic fibrosis (8, 9).
Efficient drug development will benefit NASH patients 
by minimizing the period of time for them to gain access to 
safe and effective medicines. Application of mathematical 
modeling practices such as quantitative systems pharma-
cology (QSP) can expedite clinical drug development (10). 
QSP modeling is a mechanism-based mathematical mod-
eling approach that describes not only the pathophysiology 
of a disease, but also how pharmacological interventions 
can modify the mechanisms of pathophysiology (11–15). 
Simulated populations (aka virtual populations) provide a 
useful approach for capturing the pathophysiology of the 
disease inasmuch as they provide the ability to make predic-
tions that account for inter-patient variability in both disease 
pathophysiology and clinical status (13, 14, 16). Predicted 
pharmacologic effects on simulated patients result from pre-
dicting compound exposure and pharmacodynamics (PD). 
Compound exposure at the site of the target can be pre-
dicted by the use of physiologically-based, pharmacokinetic 
(PBPK) modeling; this is particularly valuable when simu-
lating pharmacologic intervention of intracellular targets. 
The PD and/or mechanism of action (MoA) of compounds 
can be simulated by translating laboratory and/or clinical 
data into equations that describe how existing pathophysi-
ologic processes are altered by the actions of the compound.
QSP is a relatively new approach that has historical ori-
gins (17). Technological advances in computer chip design 
provided the ability for simulations results to be generated 
in much shorter periods of time, enabling this modeling 
approach to be applied to pharmaceutical drug develop-
ment. The use of QSP modeling continues to grow (18, 19). 
Capabilities provided by QSP modeling include predicting 
efficacy, identifying responsive patient types, determining 
appropriate trial duration and measurement timing, delin-
eating placebo response from pharmacologic response, 
understanding the link between mechanisms and biomarker 
responses, and predicting the efficacy potential for combina-
tion treatments (12, 20, 21). Simulation results of these sorts 
can inform clinical trial protocol design.
NAFLD and NASH provide some unique considera-
tions with respect to QSP modeling. The pathophysiology 
includes several discrete, yet interactive areas: steatosis, 
lipotoxicity, inflammation, and fibrosis. QSP models of 
NAFLD and NASH should include representations of each 
of these areas, as the response to treatments usually invoke 
responses from each. Within the steatosis area, the uptake 
and/or de novo synthesis of fatty acids as well as esterifi-
cation into triacylglycerol (TG) are primary components. 
Lipotoxicity is characterized by an excess of lipids that 
ultimately leads to hepatocellular apoptosis. Inflammation 
in NASH includes the recruitment of additional immune 
cells to the liver as well as increased production of key 
immune mediators. Fibrosis is characterized both by the 
presence of excessive amounts of collagen as well as the 
activated hepatic stellate cells that produce the extracel-
lular matrix components. QSP models of NASH should 
include equations that describe these pathophysiologic 
mechanisms in addition to the primary biomarkers (e.g., 
plasma ALT) and histologic outputs that are used to deter-
mine efficacy.
QSP models of NASH also need to represent the various 
patient types that are recruited into NASH clinical studies. 
This includes overweight or obese individuals that have not 
had a diagnosis of NASH for Phase I studies; these patients 
may or may not have steatosis, and are unlikely to have 
much lipotoxicity, inflammation, and/or fibrosis. Phase IIa 
studies typically include patients with NASH and varying 
degrees of fibrosis. Phase IIb and Phase III studies typi-
cally recruit patients with stage 3 or 4 fibrosis in addition to 
NASH, as documented by liver histology. Simulated cohorts 
with each of these patient types will enable a NASH QSP 
model to support development throughout the lifecycle of 
the compound.
The awareness of QSP modeling within regulatory agen-
cies such as the FDA has grown as the modeling approach 
has been increasingly utilized. Currently, the FDA has not 
issued any direct guidance about NASH QSP modeling, 
but the agency has indicated that there are certain recom-
mendations that should be applied to all QSP modeling (18, 
22). Model transparency enables reviewers to have access 
to all equations and parameters used to generate simula-
tion results. Not only will it enable reviewers to recapitu-
late simulation results, model transparency will also allow 
reviewers to interpret simulation results. Similarly, docu-
mentation of the modeling rationale facilitates this process. 
Another recommendation from FDA about QSP modeling is 
for model developers to submit a minimum model. Reduc-
ing the complexity of the model further enables reviewers 
to better interpret simulation results. Similarly, prespecified 
quantitative or statistical criteria helps reviewers determine 
the validity of the predicted results. Finally, the FDA has 
recommended that there be maximal inclusion of clinical 
PD markers. Applying this recommendation to NASH indi-
cates that the ability for the QSP model to predict changes 
to the histological measurements, NAFLD Activity Score 
(NAS) and fibrosis stage, is crucial; these are the currently 
acceptable endpoints for efficacy for NASH treatments (7). 
Additional biomarkers such as liver fat, plasma ALT, and 
serum Pro-C3 biomarkers have been routinely employed 
in NASH clinical studies; their inclusion in a NASH QSP 
model further enhances its utility.
1790
Pharmaceutical Research (2022) 39:1789–1802

## Page 3 (Section: Applications of Quantitative Systems Pharmacology (QSP) in Drug Development for NAFLD and NASH and Its Regulatory Application)

1 3
An additional utility of a NASH QSP model would be the 
ability to reproduce the key results of clinical studies. This 
includes not only the response to the investigational treat-
ment but also the response of the placebo group. The lack 
of separation between the treatment and placebo cohorts has 
been a significant reason for the termination of a number of 
promising potential treatments for NASH (6). In particular 
the fraction of patients within the placebo cohorts that show 
improvement in fibrosis stage over 26, 48, or 72 week studies 
is surprisingly high (20–30%, (23)). There is some indication 
that operator variability in the reading of the histological 
liver biopsy samples may play a significant role (24), and 
there may be contributions from other factors as well.
Several useful QSP models of hepatic steatosis, hepatic 
fibrosis, and NAFLD/NASH have been reported. Ashworth 
et al. developed a QSP model of lipid partitioning and stea-
tosis, including zonal differences across the hepatic acinus 
(25). Liao et al. extended this model to include the effects of 
fructose on lipid partitioning and hepatic steatosis (26). Nei-
ther of these QSP models included representations of lipo-
toxicity, inflammation, fibrosis, or NASH biomarkers or the 
primary histologic endpoints of NAS and stage of fibrosis. 
Holzhutter and Berndt also developed a QSP model of zonal 
influences on hepatic steatosis (27); this model also includes 
hepatocellular death as a consequence of lipid accumulation. 
It does not, however, include representations of inflamma-
tion, fibrosis, or NASH biomarkers. Dutta-Moscato et al. 
developed an agent-based QSP model of hepatic fibrosis, 
but it is not specific to NASH (28).
A more comprehensive QSP model of NAFLD and 
NASH is NAFLDsym (29–33). This QSP model includes 
interactive sub-models of steatosis, lipotoxicity, inflam-
mation, and fibrosis. Several important sub-models, such 
a hepatocyte death and proliferation, meal administration 
and post-prandial metabolites, mechanistic representa-
tions of alanine aminotransferase (ALT) and aspartate ami-
notransferase (AST) amongst others, were replicated from 
the quantitative systems toxicology (QST) model, DILIsym 
(34, 35). Also replicated from DILIsym are discrete repre-
sentations of hepatocytes within the periportal, midlobular, 
and centrilobular sections of the hepatic acinus. NAFLDsym 
also includes representations of a variety of useful, NASH-
specific biomarkers, including histologic NAS and fibrosis 
stage outputs as well as serum pro-C3. Moreover, there are 
more than 1700 simulated patients, enabling focused explo-
ration of different subsets of NAFLD and NASH patients 
(e.g., fibrosis stage 3). These simulated patients have been 
validated by simultaneous comparison to many clinical data 
measurements that focus on specific aspects of the patho-
physiology. A variety of treatments in clinical development 
have been simulated with NAFLDsym, including cenicrivi-
roc and anti-FGFR1/KLB bispecific antibody (36, 37). Pre-
dictions of improvement with weight loss as well as disease 
progression with weight gain have also been reported with 
NAFLDsym (30), providing further validation of the model.
There are four sub-models within NAFLDsym that par-
ticularly address the major elements of NASH pathophysiol-
ogy: steatosis, lipotoxicity, inflammation, and fibrosis. Con-
cise descriptions of each submodel are given below. Figure 1 
also displays several simulation results that characterize 
some of the key outputs of these sub-models.
The steatosis sub-model within NAFLDsym includes 
multiple processes essential for the trafficking of fatty acids, 
diacylglycerols, and TG within hepatocytes. One of these 
key processes included in NAFLDsym is the uptake of cir-
culating fatty acids from the circulation in a concentration-
dependent manner following the release of fatty acids into 
the circulation by adipocytes (38, 39). Hepatic de novo lipo-
genesis of fatty acids is also represented within NAFLDsym, 
including contributions in the overnight-fasted as well as 
the post-prandial states (40–42); hepatocytes in NAFLDsym 
take up glucose from the circulation in the post-prandial 
period, when plasma glucose levels are elevated (43, 44). In 
NAFLDsym, hepatocytes can also use either intracellular 
fatty acids or pyruvate to as fuels support the production 
of ATP to meet bioenergetic demands. The representation 
of ATP production is quite similar to what has previously 
been modeled in DILIsym (34, 35). Fatty acid oxidation is 
regulated by both ATP levels as well as the relative avail-
ability of both fatty acids and pyruvate (45). Fatty acids can 
be esterifed to TG in NAFLDsym; lipolysis of hepatocellular 
TG is also represented (46). Finally, the export of intracel-
lular TG as part of very-low-density lipoprotein (VLDL-TG) 
is also represented (47, 48).
Lipotoxicity in NAFLDsym is primarily represented 
based on the mechanistic interactions between saturated 
fatty acids (SFA), oxidative stress, and hepatocellular apop-
tosis (49–51). A variety of clinical data were used to guide 
the optimization of parameter values within these processes 
(52–55). Both liver SFA and unsaturated fatty acids (UFA) 
are separately tracked within NAFLDsym. The accumulation 
of hepatocellular SFA elicits an increase in reactive oxygen 
species (49–51). The resultant cellular oxidative stress, in 
sufficient quantities, yields hepatocellular apoptosis; necro-
sis can occur at very high levels of oxidative stress. How-
ever, circulating biomarkers such as cleaved cytokeratin 19 
(cK18) and histological ballooning indicate that apoptosis 
predominates (55, 56). The magnitude of hepatocyte loss 
due to lipotoxicity can be estimated by computational meth-
ods (57), providing validation of the steady state numbers of 
viable hepatocytes in the simulated NASH patients. Apop-
totic hepatocytes release vesicles that contain cellular frag-
ments. These vesicles and the fragments within them can 
interact with Kupffer cells, macrophages, neutrophils, and 
other immune cells to provide a degree of activation of the 
immune system (58–60).
1791
Pharmaceutical Research (2022) 39:1789–1802

## Page 4 (Section: Applications of Quantitative Systems Pharmacology (QSP) in Drug Development for NAFLD and NASH and Its Regulatory Application)

1 3
Fig. 1   Simulation results and clinical data enabling characterization of sub-model behavior and several important aspects of NASH pathophysi-
ology as simulated by NAFLDsym. The relationship between liver fat and plasma ALT in the simulated patients is quite similar to the measured 
data from Maximos et al. (a); the simulated population retains a distribution of BMI that is comparable to the clinical data reported by Dudekala 
et al. (b); the relationship between fat mass and adipose fatty acid (FA) release rates is comparable between the simulated patients and the clini-
cal data reported by Mittendorfer et al. Note that there are few simulated patients with adipose FA release rates in excess of 50 mmol/h (c); the 
ranges of de novo lipogenesis (DNL) and liver fat are comparable between the simulated patients and the clinical data reported by Lambert et al. 
and Smith et al. (d); the number of lobular macrophages in NAFLD and NASH patients is consistent with the clinical data reported by Tajiri et 
al. Note that there are minimal differences between patients below or above NAS = 4. (e); the range of TGF-beta levels in simulated patients and 
clinical cohorts with varying plasma ALT levels, as reported by Dal et al. (f); synthesis rates and quantities of hepatic collagen type I in clini-
cal and simulated patients across a range of fibrosis scores. Clinical data were reported by Decaris et al. and Masugi et al. Clinical patients with 
fibrosis stage = 4 were excluded from figure, as data for only two patients were reported. (g,h). In each figure, black or grey symbols represent 
clinical data sets while red symbols represent simulated patients. In figures a, c-h, individual simulated patients are displayed.
1792
Pharmaceutical Research (2022) 39:1789–1802

## Page 5 (Section: Applications of Quantitative Systems Pharmacology (QSP) in Drug Development for NAFLD and NASH and Its Regulatory Application)

1 3
The inflammation sub-model in NAFLDsym includes 
resident Kupffer cells as well as recruited macrophages and 
neutrophils. The numbers of each cell type in the simulated 
patients have been calibrated to be consistent with clinical 
data (61, 62). Interestingly, the numbers of macrophages 
and neutrophils do not vary much between NASH patients 
of differing severities (61, 62); the simulated patients within 
NAFLDsym are consistent with these reported data (Fig. 1). 
The Kupffer cells, macrophages and neutrophils generate a 
variety of mediators, depending on the various queues pre-
sented to them. Within NAFLDsym, these cells can pro-
duce TNF-alpha, IL-10, TGF-beta, PDGF, MMP, CCL3, and 
TIMP. Total mediator production is regulated by the number 
of viable cells, the ability of each cell type to make each 
mediator, as well as the cross-regulatory influence of media-
tors on each other’s production. The levels of each mediator 
across a range of disease severity in the simulated patients of 
NAFLDsym are consistent with a variety of different clinical 
data sets (63–68). Several mediators act on hepatocytes in 
addition to immune cells, while others participate in regulat-
ing fibrotic processes.
The fibrosis sub-model includes the activation and turno-
ver of hepatic stellate cells (HSC) as well as the synthesis 
and breakdown of collagen. Early in the disease sequelae, 
the loss of hepatocytes to lipotoxic influences initiates colla-
gen synthesis as part of the wound healing response. Chronic 
cell loss and ongoing activation of HSC lead to a fibrotic 
state in NASH patients, which is captured in a subset of the 
simulated patients of NAFLDsym. HSC are activated via 
stimulus from TGF-beta, transforming them to a myofibro-
blast-type state (69–72). The mediator PDGF encourages 
proliferation of HSC, regulating the number of activated 
HSC (73). Procollagen synthesis and collagen release by 
activated HSC are included in NAFLDsym as well as the 
release of the Pro-C3 fragment that can be used as a circulat-
ing biomarker of collagen synthesis rates (74, 75). Similar to 
the representation in the inflammation sub-model, the total 
amount of collagen synthesis reflects both the number of 
activated HSC as well as the propensity for HSC to produce 
collagen. Collagen synthesis rates are relatively slow (74, 
76), and the simulated patients with fibrosis in NAFLDsym 
are consistent with this observation (Fig. 1). Also partici-
pating in the turnover of collagen in the simulated patients 
with fibrosis are MMP. This group of mediators are respon-
sible for degrading collagen in a multi-step process (77). In 
addition to being released by macrophages and neutrophils, 
MMP are also released by activated HSC in the simulated 
patients (77).
NAFLDsym simulation outputs include representa-
tions of the currently-accepted histologic biomarkers of 
efficacy for NASH; the NAFLD activity score (NAS) and 
fibrosis stage (7). The representation of NAS includes the 
individual components, including steatosis, ballooning, 
and inflammation histologic (78, 79). These outputs have 
been validated by comparing with various types of clinical 
Fig. 2   Simulation results and clinical data describing the correspond-
ence between the simulated histologic components of NAS with 
related outputs. The range of cytokeratin-cleaved K18 (cK18) and 
histologic ballooning (a), liver fat measured by MRI-PDFF and his-
tologic steatosis (b), andCCL3 and histologic lobular inflammation 
scores. Red bars or symbols denote results from simulated patients 
while black symbols and black bars denote clinical data from Aida et 
al. (a), Middleton et al. (b), and du Plessis et al. (c).
1793
Pharmaceutical Research (2022) 39:1789–1802

## Page 6 (Section: Applications of Quantitative Systems Pharmacology (QSP) in Drug Development for NAFLD and NASH and Its Regulatory Application)

1 3
Table I   Summary of Parameters Included in NAFLD SimPops
Parameter Name in NAFLDsym
Data Source for Distribution
Vmax for aHSC proliferation
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D. 
and validated with data from Abdeen 2009, El Gendi 2012, Washington 2000
ATP decrement necrosis Vmax
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D. 
and validated with outcome data
Basal fasting glucose
Browning 2004, Maximos 2015, Copaci 2015, Dudekula 2014, Wong 2013, 
Stepnova 2010, Tanaka 2013, Zein 2012
Basal plasma triglycerides concentration
Yki-Jarvinen 2014, Maximos 2015
Basal value of mito ETC flux
Perez-Carreras 2003
Rate constant for FFA release from Peripheral storage
Based on relationship between fat mass and adipose fatty acid release described 
by Mittendorfer 2009
Basal liver triglycerides
Yki-Jarvinen 2014, Maximos 2015, Browning 2004
Body Mass
Yki-Jarvinen 2014, Maximos 2015, Browning 2005
Caspase-mediated apoptosis scaling constant
Bantel 2001
Liver macrophage CCL3 production Vmax
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D. 
and validated with data from DuPlessis 2015, DuPlessis 2016
CL activated HSC apoptosis scalar
El-Gendi 2012, Abdeen 2012, Carpino 2004 (to provide steady state aHSC 
in accordance with the effects of the CL_aHSC crowding_scalar on aHSC 
proliferation)
CL activated HSC crowding scalar
El-Gendi 2012, Abdeen 2012, Carpino 2004
CL fibrosis hepatocyte displacement scalar
Carpino 2004, D’Ambrosio 2012
Collagen 1 baseline formation rate
Decaris 2017, Masugi 2018
Collagen 1 formation rate
Decaris 2017, Masugi 2018
Collagen 3 baseline formation rate
Decaris 2017, Masugi 2018
Collagen 3 formation rate
Decaris 2017, Masugi 2018
Extracellular vesicle release from apoptotic cells
Povero 2016
Maximum LSEC HGF production rate per liver LSEC
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D. 
and validated with outcome data
Maximum macrophage HGF production rate per macrophage
Dominguez-Perez 2016, Balaban 2006, Agrawal 2013
Maximum neutrophil HGF production rate per liver neutrophil Dominguez-Perez 2016, Balaban 2006, Agrawal 2013
HGF mediated regeneration Vmax
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D. 
and validated with outcome data
Vmax for HSC activation
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D. 
and validated with data from Abdeen 2009, El Gendi 2012, Washington 2000
Rate constant for DNL precursor production
Lambert 2014, Donnely 2005, Lee 2015, Diraison 2003
Rate constant for lactate contribution to DNL
Lambert 2014, Donnely 2005, Lee 2015, Diraison 2003
Conversion of mature to labile collagen rate constant
Arima 2004, D’Ambrosio 2012
Rate constant for hepatic Chylo-TG uptake
Tushuizen 2010, McQuaid 2011
Rate constant for hepatic glucose uptake
McMahon 1989, Cersosimo 2011
Rate constant for hepatic VLDL-TG uptake
Yki-Jarvinen 2014, Maximos 2015, Mittendorfer 2003, Sane 1988, Beil 1982
Km for FFA2DAG
Required to have appropriate dynamics with TG Lipolysis mechanism activated
Km for triglyceride lipolysis
Variability in this parameter provides variability in the liver TG-ALT relation-
ship described by Yki-Jarvinen 2014, Maximos 2015, Browning 2004
Rate constant for Chylo-TG uptake by peripheral tissues
Tushuizen 2010, McQuaid 2011
Rate constant for VLDL-TG uptake by peripheral tissues
Yki-Jarvinen 2014, Maximos 2015, Mittendorfer 2003, Sane 1988, Beil 1982
Vmax for LOX
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D. 
and validated with data from Mesarwi 2015
ML fibrosis hepatocyte displacement scalar
Carpino 2004, D’Ambrosio 2012
Vmax for MMP
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D
Vmax for MMP (fragments)
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D
PP fibrosis hepatocyte displacement scalar
Carpino 2004, D’Ambrosio 2012
Half-life for plasma Pro-C3
Assumed standard deviation of ± 50% and parameter range of 2.5 times the S.D. 
and validated with data reported by Levin 2017 (abstract)
1794
Pharmaceutical Research (2022) 39:1789–1802

## Page 7 (Section: Applications of Quantitative Systems Pharmacology (QSP) in Drug Development for NAFLD and NASH and Its Regulatory Application)

1 3
data (56, 80–85) (Fig. 2). Fibrosis stage is also simulated in 
NAFLDsym; this representation accounts for both the loca-
tion (centrilobular, midlobular, peripoportal) and quantity of 
collagen within the liver and is consistent with the histologic 
scoring paradigm for NASH patients (79, 86). Additional 
simulation outputs that align with commonly-measured 
NASH biomarkers include the relative amount of liver fat 
(consistent with MRI-PDFF measurements), body weight, 
BMI, plasma ALT, plasma AST, and plasma triglycerides. 
As mentioned above, the circulating biomarker Pro-C3 is 
also simulated as an indicator of collagen biosynthesis. It 
should additionally be pointed out that NAFLDsym does not 
include several additional combination NASH biomarkers 
that continue to undergo qualification such as FIB-4, NFS, 
and ELF (87). These biomarkers could be added in the future 
as they become qualified.
The substantial degree of inter-patient variability amongst 
NASH and NAFLD patients highlights the utility of the 
inclusion of > 1700 simulated patients within the NAFLD-
NASH SimPops in NAFLDsym. This SimPops includes 
both mechanistic and clinical between-patient variability. 
Mechanistic variability is imposed within key aspects of 
each submodel, including parameters from the following 
categories across NASH pathophysiology: body weight 
(55, 88, 89), adipose fatty acid release rates (39), hepatic de 
novo lipogenesis (40, 41, 90, 91), hepatic VLDL-TG export 
(47, 48), hepatocellular mitochondrial function (92), hepatic 
glucose uptake(43, 44), hepatic and extrahepatic plasma TG 
clearance (55, 89, 93–97), hepatic antioxidant status (52, 98, 
99), hepatocellular apoptotic sensitivity to oxidative stress 
(100), hepatocellular regeneration rates (101, 102), hepato-
cyte extracellular vesicle release rates (60), macrophage and 
neutrophil recruitment (80, 85), immune mediator produc-
tion rates, hepatic stellate cell activation and proliferation 
(70–72), collagen synthesis and proteolysis rates (32, 33, 
36). Parameters and references supporting the selection of 
these parameters are listed in Table I. Each simulated patient 
within the SimPops is validated by simultaneous compari-
son with clinical data across each of these axes. Simulated 
patients that produce simulation results within the reported 
ranges of these clinical data boundaries is considered 
acceptable. Some examples are given in Fig. 1. Inter-patient 
variability in key clinical measurements emerges from the 
parametrically-imposed mechanistic variability. Figure 3 
illustrates the wide range of variability across several key 
clinical outputs, including fibrosis stage, NAS, plasma ALT, 
liver fat, and BMI. The SimPops includes patients with a 
wide range of NASH patient characteristics (no NASH to 
severe NASH, no fibrosis to substantial fibrosis, no steatosis 
to high liver fat, normal plasma ALT to above upper limit 
Table I   (continued)
Parameter Name in NAFLDsym
Data Source for Distribution
Procollagen 1 production rate
Decaris 2017, Masugi 2018
Procollagen 1 baseline production rate
Decaris 2017, Masugi 2018
Procollagen 3 production rate
Decaris 2017, Masugi 2018
Procollagen 3 baseline production rate
Decaris 2017, Masugi 2018
Scaling coeff. representing reserve mitochondria function
Perez-Carreras 2003
Liver RNS/ROS baseline clearance Vmax
Hardwick 2010, Videla 2004, Tanaka 2013
Serum adiponectin initial value
Adiels 2006
Prior (weight) for liver TG % to steatosis Grade 0 model
Randomized distribution of histologic steatosis to provide variability between 
the four grades
Prior (weight) for liver TG % to steatosis Grade 1 model
Randomized distribution of histologic steatosis to provide variability between 
the four grades
Prior (weight) for liver TG % to steatosis Grade 2 model
Randomized distribution of histologic steatosis to provide variability between 
the four grades
Prior (weight) for liver TG % to steatosis Grade 3 model
Randomized distribution of histologic steatosis to provide variability between 
the four grades
Triglyceride lipolysis switch
Required to ensure TG Lipolysis mechanism activated
Liver macrophage TGF-beta production Vmax
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D. 
and validated with data from Das 2011
Maximum inhibition of MMP by TIMPs
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D
Liver macrophage TIMP production Vmax
Ando 2018, Miele 2009
Liver macrophage TNF-alpha production Vmax
Assumed standard deviation of ± 20% and parameter range of 2.5 times the S.D. 
and validated with data from Das 2011, Zahran 2013, Hui 2004, Paredes-
Turrubiarte 2016
Vmax for FFA2DAG
Required to ensure appropriate hepatocyte fatty acid and DAG dynamics
VLDL-triglyceride secretion rate Vmax
Fabbrini 2008, Adiels 2006
1795
Pharmaceutical Research (2022) 39:1789–1802

## Page 8 (Section: Applications of Quantitative Systems Pharmacology (QSP) in Drug Development for NAFLD and NASH and Its Regulatory Application)

1 3
of normal). Simulated cohorts (SimCohorts) that include 
simulated patients with certain clinical characteristics can 
be selected from the larger SimPops to support simulations 
of clinical studies at various points in the clinical develop-
ment pipeline (103).
While there has been substantial activity towards devel-
oping pharmaceutical treatments for NASH patients, none 
are currently available. As such, the standard of care for 
NASH treatment remains weight loss (104–107). Weight 
loss has been shown to be an efficacious treatment approach, 
although patient compliance is challenging (107). Consistent 
with current QSP methodologies, we applied weight loss to 
our SimPops to further validate the simulated patients (13, 
14, 16). Included as a submodel within NAFLDsym is the 
QSP model of body weight developed by Hall et al. (108). 
As such, NAFLDsym is capable of accurately predicting 
weight loss and changes in body composition with reduced 
caloric intake. This submodel mechanistically interacts with 
the other NAFLDsym sub-models in the following ways: 
Reduced food intake acta to diminish substrate availability 
for hepatic de novo lipogenesis and adipose fatty acid release 
rates are reduced as fat mass is decreased (38, 42, 109). 
These mechanisms combine to reduce the lipid burden upon 
the liver, leading to further improvements in the downstream 
Fig. 3   Simulation results for 
untreated simulated patients 
within SimPops in NAFLDsym, 
including liver fat (a, units are 
%), plasma ALT (b, units are 
U/L), NAS (c), fibrosis stage 
(d), and BMI (e, units are kg/
m2). Note that each simulated 
patient retains the same position 
on each radial plot.
1796
Pharmaceutical Research (2022) 39:1789–1802

## Page 9 (Section: Applications of Quantitative Systems Pharmacology (QSP) in Drug Development for NAFLD and NASH and Its Regulatory Application)

1 3
pathophysiology of NASH as well. Figure 4 illustrates the 
simulation results for SimCohorts selected to align with clin-
ical cohorts for the given studies. Of note is the appropriate 
simulated reductions in liver fat, NAS (including individual 
components), and fibrosis stage with 5–10% weight loss via 
reduced caloric intake over 6–12 months. NAFLDsym has 
additionally been used to simulate several potential treat-
ments for NASH patients (e.g., anti-FGFR1/KLB bispe-
cific antibody, cenicriviroc), including those that elicited 
improvements in NASH and others that did not (36, 37). 
The accurate prediction of the responses to these treatments 
further validates NAFLDsym and the SimPops.
NAFLDsym has recently been used to identify potential 
mechanistic contributors to the relatively high response rate in 
improved fibrosis stage within placebo cohorts in clinical stud-
ies (23). Specifically, NAFLDsym was used to simulate sub-
tle adjustments in food intake over the course of a simulated 
52 week study that led to periodic weight loss and weight gain; 
Fig. 4   Simulation results and clinical data illustrating the appropriate degree of relief in simulated NASH patients in response to 5–10% weight 
loss achieved via restriction of caloric intake. Liver fat before and after six months of 10% weight loss, as compared with clinical data from 
Smith et al. Mean responses and individual simulated and clinical patient results displayed (a); absolute change in overall NAS and respec-
tive components after 5–7% weight loss over 12 months, as compared with clinical data from Vilar-Gomez et al. and Hameed et al. Note that 
a negative value indicates reduction relative to initial values (b); fraction of patients with worsened, stabilized, or regressed fibrosis stage after 
12 months of 5–7% weight loss, as compared with clinical data from Vilar-Gomez et al. (c). Clinical results are summarized in figure on left, 
while simulation results are in figure on right Red bars or symbols denote results from SimCohorts while black or gray symbols denote clinical 
data.
1797
Pharmaceutical Research (2022) 39:1789–1802

## Page 10 (Section: Applications of Quantitative Systems Pharmacology (QSP) in Drug Development for NAFLD and NASH and Its Regulatory Application)

1 3
body weight was not predicted to change appreciably by the 
end of the simulated study (Fig. 5a, 5b). A simulated cohort 
of 90 simulated NASH patients was subjected to this so-called 
yo-yo dieting protocol. The baseline characteristics of the simu-
lated cohort are given in Table II. Food intake was adjusted 
every four weeks to enable 1% weight gain and weight loss in 
repeated order. Figure 5 illustrates not only the small changes in 
body weight over the simulated study, but also the consequent 
predicted changes in liver fat, plasma ALT, and liver collagen. 
Both liver fat and plasma ALT are predicted to decline with the 
reduced food intake (and associated weight loss) and increase 
with the periodic rebound in body weight. The absolute amounts 
of body weight, liver fat, and plasma ALT at the conclusion of 
the 52 week simulated study are quite similar to the values at 
the beginning of the study. However, liver collagen levels did 
not follow the same pattern as the other biomarkers. Rather liver 
collagen was predicted to decline, leading to a predicted reduc-
tion in fibrosis stage in 10% of the simulated patients within 
the cohort (Table III). The notably slow turnover rate of liver 
collagen (74, 76) prevents liver collagen from having the same 
Fig. 5   Predicted relative 
changes (left) in and absolute 
levels (right) of body weight 
(a, b), liver fat (c, d), plasma 
ALT (e, f), and liver collagen 
(g,h) in NASH SimCohorts 
over time due to yo-yo dieting. 
Mean ± standard deviation plot-
ted for all figures.
Table II   Baseline Simulated Cohort Characteristics
Body 
weight
(kg)
Liver fat
(%)
Plasma 
ALT
(U/L)
NAS
(score)
Fibrosis
score = 2
Fibrosis
score = 3
89.1 ± 19.4
17 ± 5
50 ± 12
5.6 ± 3.2 39%
61%
Table III   Proportion of Simulated NASH Patients with Predicted His-
tologic Reductions Over time with Yo-Yo Dieting
13 weeks
26 weeks
39 weeks
52 weeks
Fibrosis
6%
10%
12%
10%
NAS
4%
0%
0%
0%
1798
Pharmaceutical Research (2022) 39:1789–1802

## Page 11 (Section: Conclusion)

1 3
periodicity that body weight, liver fat, and plasma ALT do in 
response to the cyclical adjustments in simulated food intake. 
These simulation results suggest that, within clinical studies, 
some proportion of NASH patients in placebo cohorts with 
reduced fibrosis stage could be experiencing the yo-yo dieting 
behavioral pattern. Confirmation of these simulation results with 
additional clinical studies and/or data collection during existing 
clinical studies could impact the interpretation of data from the 
placebo cohorts in these studies.
Conclusion
The increasing prevalence of NAFLD and NASH accentu-
ates the need for available treatments in this patient popu-
lations. Application of QSP modeling to the development 
of NASH drug development can help accelerate this pro-
cess. Moreover, such NASH QSP models should adhere 
to recommendations put forth by regulatory agencies such 
as the FDA. These include model transparency and doc-
umentation, minimizing complexity of the QSP model, 
utilizing predefined, quantitative criteria for model vali-
dation, as well as the inclusion of useful NASH clinical 
biomarkers such as NAS and fibrosis stage. Several useful 
QSP models are currently available to help support NASH 
drug development to varying extents, with NAFLDsym, in 
particular, providing the capability of simulating numer-
ous useful aspects of NASH. Ultimately, the partnership 
between clinical studies and QSP modeling should help 
provide safe and effective medicines for NASH patients 
in short order.
ACKNOWLEDGMENTS AND DISCLOSURES  The author would like to 
acknowledge the contributions of several individuals who contributed 
to the manuscript via numerous useful discussions. This list includes 
Lisl Shoda, Grant Generaux, Christina Battista, Zack Kenz, Kyung-
hee Yang, Jeff Woodhead, Brett Howell, Fulya Akpinar-Singh, Richard 
Allen, and Theodore Rieger. The author contributed to the development 
of the NASH QSP model, NAFLDsym, and works for the owner of the 
model, Simulations Plus.
Funding  This work was supported by Simulations Plus, as the author 
is an employee of the organization.
Open Access  This article is licensed under a Creative Commons Attri-
bution 4.0 International License, which permits use, sharing, adapta-
tion, distribution and reproduction in any medium or format, as long 
as you give appropriate credit to the original author(s) and the source, 
provide a link to the Creative Commons licence, and indicate if changes 
were made. The images or other third party material in this article are 
included in the article's Creative Commons licence, unless indicated 
otherwise in a credit line to the material. If material is not included in 
the article's Creative Commons licence and your intended use is not 
permitted by statutory regulation or exceeds the permitted use, you will 
need to obtain permission directly from the copyright holder. To view a 
copy of this licence, visit http://​creat​iveco​mmons.​org/​licen​ses/​by/4.​0/.
References
	 1.	 Chalasani N, Younossi Z, Lavine JE, Diehl AM, Brunt EM, Cusi 
K, et al. The diagnosis and management of non-alcoholic fatty 
liver disease: practice guideline by the american association for 
the study of liver diseases, american college of gastroenterology, 
and the american gastroenterological association. Am J Gastro-
enterol. 2012;107(6):811–26.
	 2.	 Vernon G, Baranova A, Younossi ZM. Systematic review: The 
epidemiology and natural history of non-alcoholic fatty liver dis-
ease and non-alcoholic steatohepatitis in adults. Aliment Phar-
macol Therapeut. 2011;34(3):274–85.
	 3.	 Younossi ZM, Golabi P, de Avila L, Paik JM, Srishord M, 
Fukui N, et al. The global epidemiology of NAFLD and 
NASH in patients with type 2 diabetes: A systematic review 
and meta-analysis. J Hepatol. 2019;71(4):793–801.
	 4.	 Brown E, Hydes T, Hamid A, Cuthbertson DJ. Emerging and 
established therapeutic approaches for nonalcoholic fatty liver 
disease. Clin Ther. 2021;43(9):1476–504.
	 5.	 Satiya J, Snyder HS, Singh SP, Satapathy SK. Narrative 
review of current and emerging pharmacological therapies for 
nonalcoholic steatohepatitis. Transl Gastroenterol Hepatol. 
2021;6:60–60.
	 6.	 Drenth JPH, Schattenberg JM. The nonalcoholic steatohepati-
tis (NASH) drug development graveyard: established hurdles 
and planning for future success. Expert Opin Investig Drugs. 
2020;29(12):1365–75.
	 7.	 FDA-CDER. Noncirrhotic Nonalcoholic Steatohepatitis with 
Liver Fibrosis: Developing Drugs for Treatment: Guidance for 
Industry. https://​www.​fdagov/​media/​119044/​downl​oad. 2018;
	 8.	 Brunt EM. Nonalcoholic steatohepatitis. Semin Liver Dis. 
2004;24(1):3–20.
	 9.	 Brunt EM, Neuschwander-Tetri BA, Oliver D, Wehmeier KR, 
Bacon BR. Nonalcoholic steatohepatitis: Histologic features and 
clinical correlations with 30 blinded biopsy specimens. Hum 
Pathol. 2004;35(9):1070–82.
	 10.	 Fediuk DJ, Nucci G, Dawra VK, Callegari E, Zhou S, Musante 
CJ, et al. End-to-end application of model-informed drug 
development for ertugliflozin, a novel sodium-glucose cotrans-
porter 2 inhibitor. CPT Pharmacometrics Syst Pharmacol. 
2021;10(6):529–42.
	 11.	 Sorger PK, Allerheiligen SRB, Abernethy DR, Altman RB, Brou-
wer KLR, Califano A, et al. Quantitative and systems pharma-
cology in the post-genomic era: new approaches to discovering 
drugs and understanding therapeutic mechanisms. An NIH White 
Paper by the QSP Workshop Group. 2011.
	 12.	 Musante C, Ramanujan S, Schmidt B, Ghobrial O, Lu J, Heather-
ington A. Quantitative systems pharmacology: a case for disease 
models. Clin Pharmacol Ther. 2017;101(1):24–7.
	 13.	 Schmidt BJ, Casey FP, Paterson T, Chan JR. Alternate virtual 
populations elucidate the type I interferon signature predictive 
of the response to rituximab in rheumatoid arthritis. BMC Bio-
informatics. 2013;14(1):221.
	 14.	 Abbiati RA, Pourdehnad M, Carrancio S, Pierce DW, Kasib-
hatla S, McConnell M, et al. Quantitative systems pharma-
cology modeling of avadomide-induced neutropenia enables 
virtual clinical dose and schedule finding studies. AAPS J. 
2021;23(5):103.
	 15.	 Rieger TR, Musante CJ. Benefits and challenges of a QSP 
approach through case study: Evaluation of a hypothetical GLP-1/
GIP dual agonist therapy. Eur J Pharm Sci. 2016;30(94):15–9.
	 16.	 Allen RJ, Rieger TR, Musante CJ. Efficient generation and 
selection of virtual populations in quantitative systems phar-
macology models. CPT Pharmacometrics Syst Pharmacol. 
2016;5(3):140–6.
1799
Pharmaceutical Research (2022) 39:1789–1802

## Page 12 (Section: Conclusion)

1 3
	 17.	 Guyton AC, Coleman TG, Granger HJ. Circulation: overall regu-
lation. Annu Rev Physiol. 1972;34:13–46.
	 18.	 Bai JPF, Earp JC, Florian J, Madabushi R, Strauss DG, Wang Y, 
et al. Quantitative systems pharmacology: Landscape analysis of 
regulatory submissions to the US Food and Drug Administration. 
CPT Pharmacom & Syst Pharma. 2021;10(12):1479–84.
	 19.	 Azer K, Kaddi CD, Barrett JS, Bai JPF, McQuade ST, Merrill 
NJ, et al. History and future perspectives on the discipline of 
quantitative systems pharmacology modeling and its applica-
tions. Front Physiol. 2021;25(12): 637999.
	 20.	 Leil TA, Bertz R. Quantitative systems pharmacology can 
reduce attrition and improve productivity in pharmaceutical 
research and development. Front Pharmacol. 2014;5:247.
	 21.	 Ermakov S, Schmidt BJ, Musante CJ, Thalhauser CJ. A survey 
of software tool utilization and capabilities for quantitative 
systems pharmacology: what we have and what we need. CPT 
Pharmacometrics Syst Pharmacol. 2019;8(2):62–76.
	 22.	 Bai JPF, Earp JC, Strauss DG, Zhu H. A perspective on 
quantitative systems pharmacology applications to clinical 
drug development. CPT Pharmacometrics Syst Pharmacol. 
2020;9(12):675–7.
	 23.	 Tong X fei, Wang Q yi, Zhao X yan, Sun Y meng, Wu X ning, 
Yang L ling, et al. Histological assessment based on liver biopsy: 
the value and challenges in NASH drug development. Acta Phar-
macol Sin [Internet]. 2022 Feb 14 [cited 2022 Mar 17]; Available 
from: https://​www.​nature.​com/​artic​les/​s41401-​022-​00874-x
	 24.	 Rowe IA, Parker R. The placebo response in randomized trials in 
nonalcoholic steatohepatitis simply explained. Clin Gastroenterol 
Hepatol. 2022;20(3):e564–72.
	 25.	 Ashworth WB, Davies NA, Bogle IDL. A computational model 
of hepatic energy metabolism: understanding zonated damage 
and steatosis in NAFLD. Beard DA, editor. PLoS Comput Biol. 
2016 Sep 15;12(9):e1005105.
	 26.	 Liao Y, Davies NA, Bogle IDL. Computational modeling of 
fructose metabolism and development in NAFLD. Front Bioeng 
Biotechnol. 2020;22(8):762.
	 27.	 Holzhütter HG, Berndt N. Computational hypothesis: how intra-
hepatic functional heterogeneity may influence the cascading 
progression of free fatty acid-induced non-alcoholic fatty liver 
disease (NAFLD). Cells. 2021;10(3):578.
	 28.	 Dutta-Moscato J, Solovyev A, Mi Q, Nishikawa T, Soto-Gut-
ierrez A, Fox IJ, et al. A multiscale agent-based in silico model 
of liver fibrosis progression. frontiers in bioengineering and 
biotechnology [Internet]. 2014 May 30 [cited 2018 Dec 18];2. 
Available from: http://journal.frontiersin.org/article/https://​doi.​
org/​10.​3389/​fbioe.​2014.​00018/​abstr​act
	 29.	 Generaux G. QSP modeling of liver AMPK activation using 
NAFLDsym is predicted to reduce steatosis in NAFLD patients. 
Clin Pharmacol Ther. 2017;101(S1):S65.
	 30.	 Siler SQ. Using systems pharmacology modeling to under-
stand the pathophysiology of NAFLD and response to dietary 
intervention in a simulated population. Clin Pharmacol Ther. 
2017;101(S1):S88.
	 31.	 Siler SQ. Using quantitative systems pharmacology modeling to 
understand the effects of acetyl CoA carboxylase inhibition on 
liver and plasma triglycerides in a simulated population. Hepatol-
ogy. 2018;68(S1):448A.
	 32.	 Longo D. Zonal hepatic stellate cell activation in nonalcoholic 
steatohepatitis characterized by a mathematical model. Hepatol-
ogy. 2018;68(s1):625A.
	 33.	 Generaux G. Zonal Extracellular Matrix (ECM) accumula-
tion in nonalcoholic steatohepatitis (NASH) characterized by a 
mathematical model of fibrosis. J Pharmacokinet Pharmacodyn. 
2018;45: s17.
	 34.	 Shoda LKM, Woodhead JL, Siler SQ, Watkins PB, Howell BA. 
Linking physiology to toxicity using DILIsym(®), a mechanistic 
mathematical model of drug-induced liver injury. Biopharm 
Drug Dispos. 2014;35(1):33–49.
	 35.	 Woodhead JL, Howell BA, Yang Y, Harrill AH, Clewell HJ 
3rd, Andersen ME, et al. An analysis of N-acetylcysteine 
treatment for acetaminophen overdose using a systems 
model of drug-induced liver injury. J Pharmacol Exp Ther. 
2012;342(2):529–40.
	 36.	 Kenz Z, Howell BA, Dash A, Wong C, Yeh F, Chinn L, et al. 
Mathematical Modeling with NAFLDsym Supports the Role of 
Adiponectin in the Reduction of Steatosis by the Anti-FGFR1/
KLB Bispecific Antibody. In 2020.
	 37.	 Battista C, Shoda LKM, Akpinar F, Siler SQ, Generaux G. Quan-
titative systems pharmacology (QSP) model predicts lack of effi-
cacy for cenicriviroc, a CCR2/5 antagonist, in NAFLD/NASH 
patients. Hepatology. 2021;74(1S):1149A.
	 38.	 Klein S, Luu K, Gasic S, Green A. Effect of weight lipid metabo-
lism loss on whole body and cellular in severely obese humans. 
American Journal of Physiology - Endocrinology And Metabo-
lism. 1996;33:739–45.
	 39.	 Mittendorfer B, Magkos F, Fabbrini E, Mohammed BS, Klein S. 
Relationship between body fat mass and free fatty acid kinetics in 
men and women. Obesity (Silver Spring). 2009;17(10):1872–7.
	 40.	 Lambert JE, Ramos-Roman MA, Browning JD, Parks EJ. 
Increased de novo lipogenesis is a distinct characteristic of indi-
viduals with nonalcoholic fatty liver disease. Gastroenterology. 
2014;146(3):726–35.
	 41.	 Donnelly KL, Smith CI, Schwarzenberg SJ, Jessurun J, Boldt 
MD, Parks EJ. Sources of fatty acids stored in liver and secreted 
via lipoproteins in patients with nonalcoholic fatty liver disease. 
J Clin Invest. 2005;115(5):1343–51.
	 42.	 Smith GI, Shankaran M, Yoshino M, Schweitzer GG, Chondron-
ikola M, Beals JW, et al. Insulin resistance drives hepatic de 
novo lipogenesis in nonalcoholic fatty liver disease. J Clin Invest. 
2020;130(3):1453–60.
	 43.	 Cersosimo E, Gastaldelli a, Cervera a, Wajcberg E, Sriwijilka-
mol a, Fernandez M, et al. Effect of exenatide on splanchnic 
and peripheral glucose metabolism in type 2 diabetic subjects. 
The Journal of clinical endocrinology and metabolism. 2011 
Jun;96(6):1763–70.
	 44.	 McMahon M, Marsh HM, Rizza R a. Effects of basal insulin 
supplementation on disposition of mixed meal in obese patients 
with NIDDM. Diabetes. 1989 Mar;38(3):291–303.
	 45.	 Randle PJ. Regulatory interactions between lipids and carbohy-
drates: the glucose fatty acid cycle after 35 years. Diabetes Metab 
Rev. 1998;14(4):263–83.
	 46.	 Quiroga AD, Lehner R. Pharmacological intervention of liver 
triacylglycerol lipolysis: The good, the bad and the ugly. Bio-
chem Pharmacol. 2018;155:233–41.
	 47.	 Fabbrini E, Mohammed BS, Magkos F, Korenblat KM, Patter-
son BW, Klein S. Alterations in adipose tissue and hepatic lipid 
kinetics in obese men and women with nonalcoholic fatty liver 
disease. Gastroenterology. 2008;134(2):424–31.
	 48.	 Adiels M, Taskinen MR, Packard C, Caslake MJ, Soro-Paavonen 
A, Westerbacka J, et al. Overproduction of large VLDL particles 
is driven by increased liver fat content in man. Diabetologia. 
2006;49(4):755–65.
	 49.	 Nakamura S, Takamura T, Matsuzawa-Nagata N, Takayama H, 
Misu H, Noda H, et al. Palmitate induces insulin resistance in 
H4IIEC3 hepatocytes through reactive oxygen species produced 
by mitochondria. J Biol Chem. 2009;284(22):14809–18.
	 50.	 Noguchi Y, Young JD, Aleman JO, Hansen ME, Kelleher JK, 
Stephanopoulos G. Effect of anaplerotic fluxes and amino 
acid availability on hepatic lipoapoptosis. J Biol Chem. 
2009;284(48):33425–36.
1800
Pharmaceutical Research (2022) 39:1789–1802

## Page 13 (Section: Conclusion)

1 3
	 51.	 Bao J, Scott I, Lu Z, Pang L, Dimond CC, Sack MN. SIRT3 is 
regulated by nutrient excess and modulates suscptibility to lipo-
toxicity. Free Radical Biol Med. 2010;49(7):1230–7.
	 52.	 Hardwick RN, Fisher CD, Canet MJ, Lake AD, Cherrington 
NJ. Differences in antioxidant response enzymes in progressive 
stages of human nonalcoholic fatty liver disease. Drug Metab 
Dispos. 2010;38:2293–301.
	 53.	 Cuchel M, Bloedon LT, Szapary PO, Kolansky DM, Wolfe ML, 
Sarkis A, et al. Inhibition of microsomal triglyceride trans-
fer protein in familial hypercholesterolemia. N Engl J Med. 
2007;356(2):148–56.
	 54.	 Stein EA, Dufour R, Gagne C, Gaudet D, East C, Donovan JM, 
et al. Apolipoprotein B synthesis inhibition with mipomersen 
in heterozygous familial hypercholesterolemia: results of a 
randomized, double-blind, placebo-controlled trial to assess 
efficacy and safety as add-on therapy in patients with coronary 
artery disease. Circulation. 2012;126(19):2283–92.
	 55.	 Maximos M, Bril F, Portillo Sanchez P, Lomonaco R, Orsak 
B, Biernacki D, et al. The role of liver fat and insulin resist-
ance as determinants of plasma aminotransferase elevation in 
nonalcoholic fatty liver disease. Hepatology (Baltimore, MD). 
2015;61(1):153–60.
	 56.	 Aida Y, Abe H, Tomita Y, Nagano T, Seki N, Sugita T, et 
al. Serum cytokeratin 18 fragment level as a noninvasive bio-
marker for non-alcoholic fatty liver disease. Int J Clin Exp 
Med. 2014;7(11):4191–8.
	 57.	 Longo DM, Generaux GT, Howell BA, Siler SQ, Antoine DJ, 
Button D, et al. Refining liver safety risk assessment: appli-
cation of mechanistic modeling and serum biomarkers to 
cimaglermin alfa (GGF2) clinical trials. Clin Pharmacol Ther. 
2017;102(6):961–9.
	 58.	 Hirsova P, Ibrahim SH, Krishnan A, Verma VK, Bronk SF, 
Werneburg NW, et al. Lipid-induced signaling causes release 
of inflammatory extracellular vesicles from hepatocytes. Gas-
troenterology. 2016;150(4):956–67.
	 59.	 Hirsova P, Gores GJ. Death receptor-mediated cell death and 
proinflammatory signaling in nonalcoholic steatohepatitis. 
CMGH Cellular and Molecular Gastroenterology and Hepa-
tology. 2015;1(1):17–27.
	 60.	 Povero D, Eguchi A, Li H, Johnson CD, Papouchado BG, Wree 
A, et al. Circulating extracellular vesicles with specific pro-
teome and Liver MicroRNAs are potential biomarkers for liver 
injury in experimental fatty liver disease. Sookoian SC, editor. 
PLoS ONE. 2014 Dec 3;9(12):e113651.
	 61.	 Krenkel O, Puengel T, Govaere O, Abdallah AT, Mossanen 
JC, Kohlhepp M, et al. Therapeutic inhibition of inflammatory 
monocyte recruitment reduces steatohepatitis and liver fibro-
sis. Hepatology [Internet]. 2017 Sep 21 [cited 2017 Nov 10]; 
Available from: http://doi.wiley.com/https://​doi.​org/​10.​1002/​
hep.​29544
	 62.	 Tajiri K, Shimizu Y, Tsuneyama K, Sugiyama T. Role of liver-
infiltrating CD3+CD56+ natural killer T cells in the pathogen-
esis of nonalcoholic fatty liver disease: European Journal of 
Gastroenterology & Hepatology. 2009 Jun;21(6):673–80.
	 63.	 Zahran WE, Salah El-Dien KA, Kamel PG, El-Sawaby AS. 
Efficacy of tumor necrosis factor and interleukin-10 analysis 
in the follow-up of nonalcoholic fatty liver disease progression. 
Indian J Clin Biochem. 2013;28(2):141–6.
	 64.	 Das SK, Balakrishnan V. Role of cytokines in the pathogenesis 
of non-alcoholic fatty liver disease. Indian J Clin Biochem. 
2011;26(2):202–9.
	 65.	 Hui JM, Hodge A, Farrell GC, Kench JG, Kriketos A, George 
J. Beyond insulin resistance in NASH: TNF-alpha or adiponec-
tin? Hepatology (Baltimore, MD). 2004;40(1):46–54.
	 66.	 Yoshida S, Ikenaga N, Liu SB, Peng ZW, Chung J, Sverd-
lov DY, et al. Extrahepatic platelet-derived growth factor-β, 
delivered by platelets, promotes activation of hepatic stel-
late cells and biliary fibrosis in mice. Gastroenterology. 
2014;147(6):1378–92.
	 67.	 Miele L, Forgione A, La Torre G, Vero V, Cefalo C, Racco S, et 
al. Serum levels of hyaluronic acid and tissue metalloproteinase 
inhibitor-1 combined with age predict the presence of nonalco-
holic steatohepatitis in a pilot cohort of subjects with nonalco-
holic fatty liver disease. Transl Res. 2009;154(4):194–201.
	 68.	 Ando W, Yokomori H, Tsutsui N, Yamanouchi E, Suzuki Y, 
Oda M, et al. Serum matrix metalloproteinase-1 level represents 
disease activity as opposed to fibrosis in patients with histologi-
cally proven nonalcoholic steatohepatitis. Clin Mol Hepatol. 
2018;24(1):61–76.
	 69.	 Zhao XK, Yu L, Cheng ML, Che P, Lu YY, Zhang Q, et al. 
Focal Adhesion kinase regulates hepatic stellate cell activation 
and liver fibrosis. Sci Rep. 2017;7(1):4032.
	 70.	 Washington K, Wright K, Shyr Y, Hunter EB, Olson S, Raiford 
DS. Hepatic stellate cell activation in nonalcoholic steatohepati-
tis and fatty liver. Hum Pathol. 2000;31(7):822–8.
	 71.	 Abdeen SM, Olusi SO, Askar HA, Thalib L, Al-Azemi A, George 
S. The predictive value of CD38 positive hepatic stellate cell 
count for assessing disease activity and fibrosis in patients with 
chronic hepatitis. Acta Histochem. 2009;111(6):520–30.
	 72.	 El-Gendi SM, Shaaban AAA, Ali ES. CD38+ hepatic stellate 
cell count as a predictor of disease activity and fibrosis in chronic 
hepatitis C virus patients: Egyptian Journal of Pathology. 2012 
Jul;32(1):59–67.
	 73.	 Pinzani M, Milani S, Herbst H, DeFranco R, Grappone C, Cali-
giuri A, et al. Expression of platelet-derived growth factor and 
its receptors in normal human liver and during active hepatic 
fibrogenesis. Am J Pathol. 1996;178(3):785–800.
	 74.	 Decaris ML, Li KW, Emson CL, Gatmaitan M, Liu S, Wang 
Y, et al. Identifying nonalcoholic fatty liver disease patients 
with active fibrosis by measuring extracellular matrix remod-
eling rates in tissue and blood: Decaris et al. Hepatology. 2017 
Jan;65(1):78–88.
	 75.	 Boyle M, Tiniakos D, Schattenberg JM, Ratziu V, Bugianessi 
E, Petta S, et al. Performance of the PRO-C3 collagen neo-
epitope biomarker in non-alcoholic fatty liver disease. JHEP Rep. 
2019;1(3):188–98.
	 76.	 Decaris ML, Emson CL, Li K, Gatmaitan M, Luo F, Cattin J, et 
al. Turnover rates of hepatic collagen and circulating collagen-
associated proteins in humans with chronic liver disease. PLoS 
ONE. 2015;10(4): e0123311.
	 77.	 Geervliet E, Bansal R. Matrix metalloproteinases as potential 
biomarkers and therapeutic targets in liver diseases. Cells. 2020 
May 13;9(5).
	 78.	 Kleiner DE, Brunt EM, Van Natta M, Behling C, Contos MJ, 
Cummings OW, et al. Design and validation of a histological 
scoring system for nonalcoholic fatty liver disease. Hepatology. 
2005;41(6):1313–21.
	 79.	 Brunt EM, Neuschwander-Tetri BA. Nonalcoholic Steatohepati-
tis: A Proposal for Grading and Staging the Histological Lesions. 
1999;94(9):8.
	 80.	 du Plessis J, Korf H, van Pelt J, Windmolders P, Vander Elst I, 
Verrijken A, et al. Pro-inflammatory cytokines but not endo-
toxin-related parameters associate with disease severity in 
patients with NAFLD. Strnad P, editor. PLOS ONE. 2016 Dec 
19;11(12):e0166048.
	 81.	 Middleton MS, Heba ER, Hooker CA, Bashir MR, Fowler KJ, 
Sandrasegaran K, et al. Agreement between magnetic reso-
nance imaging proton density fat fraction measurements and 
pathologist-assigned steatosis grades of liver biopsies from 
adults with nonalcoholic steatohepatitis. Gastroenterology. 
2017;153(3):753–61.
1801
Pharmaceutical Research (2022) 39:1789–1802

## Page 14 (Section: Conclusion)

1 3
	 82.	 Permutt Z, Le TA, Peterson MR, Seki E, Brenner DA, Sirlin C, 
et al. Correlation between liver histology and novel magnetic 
resonance imaging in adult patients with non-alcoholic fatty liver 
disease - MRI accurately quantifies hepatic steatosis in NAFLD. 
Aliment Pharmacol Ther. 2012;36(1):22–9.
	 83.	 Schwimmer JB, Middleton MS, Behling C, Newton KP, Awai HI, 
Paiz MN, et al. Magnetic resonance imaging and liver histology 
as biomarkers of hepatic steatosis in children with nonalcoholic 
fatty liver disease. Hepatology. 2015;61(6):1887–95.
	 84.	 Feldstein A, Kleiner D, Kravetz D, Buck M. Severe hepatocel-
lular injury with apoptosis induced by a hepatitis C polymerase 
inhibitor. J Clin Gastroenterol. 2009;43(4):374–81.
	 85.	 du Plessis J, van Pelt J, Korf H, Mathieu C, van der Schueren 
B, Lannoo M, et al. Association of adipose tissue inflammation 
with histologic severity of nonalcoholic fatty liver disease. Gas-
troenterology. 2015;149(3):635-648.e14.
	 86.	 Albhaisi S, Sanyal AJ. Applying non-invasive fibrosis measure-
ments in NAFLD/NASH: progress to date. Pharmaceut Med. 
2019;33(6):451–63.
	 87.	 Alkhouri N, Tincopa M, Loomba R, Harrison SA. What does 
the future hold for patients with nonalcoholic steatohepatitis: 
diagnostic strategies and treatment options in 2021 and beyond? 
Hepatol Commun. 2021;5(11):1810–23.
	 88.	 Browning JD, Szczepaniak LS, Dobbins R, Nuremberg P, Horton 
JD, Cohen JC, et al. Prevalence of hepatic steatosis in an urban 
population in the United States: Impact of ethnicity. Hepatology. 
2004;40(6):1387–95.
	 89.	 Yki-Järvinen H. Non-alcoholic fatty liver disease as a cause and 
a consequence of metabolic syndrome. Lancet Diabetes Endo-
crinol. 2014;2(11):901–10.
	 90.	 Lee JJ, Lambert JE, Hovhannisyan Y, Ramos-Roman MA, Trom-
bold JR, Wagner DA, et al. Palmitoleic acid is elevated in fatty 
liver disease and reflects hepatic lipogenesis. Am J Clin Nutr. 
2015;101(1):34–43.
	 91.	 Diraison F, Moulin P, Beylot M. Contribution of hepatic de novo 
lipogenesis and reesterification of plasma non esterified fatty 
acids to plasma triglyceride synthesis during non-alcoholic fatty 
liver disease. Diabetes Metab. 2003;29(5):478–85.
	 92.	 Pérez-Carreras M, Del Hoyo P, Martín M a, Rubio JC, Martín A, 
Castellano G, et al. Defective hepatic mitochondrial respiratory 
chain in patients with nonalcoholic steatohepatitis. Hepatology 
(Baltimore, Md). 2003 Oct;38(4):999–1007.
	 93.	 Tushuizen ME, Pouwels PJ, Bontemps S, Rustemeijer C, Mati-
kainen N, Heine RJ, et al. Postprandial lipid and apolipoprotein 
responses following three consecutive meals associate with liver 
fat content in type 2 diabetes and the metabolic syndrome. Ath-
erosclerosis. 2010;211(1):308–14.
	 94.	 McQuaid SE, Hodson L, Neville MJ, Dennis AL, Cheeseman 
J, Humphreys SM, et al. Downregulation of adipose tissue fatty 
acid trafficking in obesity: a driver for ectopic fat deposition? 
Diabetes. 2011;60(1):47–55.
	 95.	 Mittendorfer B, Patterson BW, Klein S. Effect of sex and obe-
sity on basal VLDL-triacylglycerol kinetics. Am J Clin Nutr. 
2003;77(3):573–9.
	 96.	 Sane T, Nikkilä EA. Very low density lipoprotein triglyceride 
metabolism in relatives of hypertriglyceridemic probands. Evi-
dence for genetic control of triglyceride removal. Arteriosclero-
sis. 1988 Jun;8(3):217–26.
	 97.	 Beil U, Grundy SM, Crouse JR, Zech L. Triglyceride and choles-
terol metabolism in primary hypertriglyceridemia. Arterioscle-
rosis. 1982;2(1):44–57.
	 98.	 Videla L a, Rodrigo R, Orellana M, Fernandez V, Tapia G, 
Quiñones L, et al. Oxidative stress-related parameters in the 
liver of non-alcoholic fatty liver disease patients. Clinical sci-
ence (London, England : 1979). 2004;106(3):261–8.
	 99.	 Tanaka S, Miyanishi K, Kobune M, Kawano Y, Hoki T, Kubo T, 
et al. Increased hepatic oxidative DNA damage in patients with 
nonalcoholic steatohepatitis who develop hepatocellular carci-
noma. J Gastroenterol. 2013;48(11):1249–58.
	100.	 Bantel H, Lügering A, Heidemann J, Volkmann X, Poremba 
C, Strassburg CP, et al. Detection of apoptotic caspase activa-
tion in sera from patients with chronic HCV infection is asso-
ciated with fibrotic liver injury. Hepatology (Baltimore, MD). 
2004;40(5):1078–87.
	101.	 Balaban YH. Metabolic syndrome, non-alcoholic steatohepati-
tis (NASH), and hepatocyte growth factor (HGF). Ann Hepatol. 
2006;5(2):109–14.
	102.	 Agrawal R, Sheroan V, Ola V, Sulemani A, Singh N, Sirohi P, 
et al. Hepatocyte growth factor, adiponectin and hepatic histo-
pathology in non-alcoholic steatohepatitis. J Assoc Physicians 
India. 2013;61:4.
	103.	 Konerman MA, Jones JC, Harrison SA. Pharmacotherapy for 
NASH: Current and emerging. J Hepatol. 2018;68(2):362–75.
	104.	 Vilar-Gomez E, Martinez-Perez Y, Calzadilla-Bertot L, Torres-
Gonzalez A, Gra-Oramas B, Gonzalez-Fabian L, et al. Weight 
Loss Through Lifestyle Modification Significantly Reduces Fea-
tures of Nonalcoholic Steatohepatitis. Gastroenterology. 2015 
Aug;149(2):367–78.e5; quiz e14–15.
	105.	 Sevastianova K, Santos A, Kotronen A, Hakkarainen A, Mak-
konen J, Silander K, et al. Effect of short-term carbohydrate 
overfeeding and long-term weight loss on liver fat in overweight 
humans. Am J Clin Nutr. 2012;96(4):727–34.
	106.	 Browning JD, Baker J a, Rogers T, Davis J, Satapati S, Bur-
gess SC. Short-term weight loss and hepatic triglyceride reduc-
tion : evidence of a metabolic advantage with dietary carbohy-
drate restriction 1 – 3. American Journal of Clinical Nutrition. 
2011;93:1048–52.
	107.	 Promrat K, Kleiner DE, Niemeier HM, Jackvony E, Kearns M, 
Wands JR, et al. Randomized controlled trial testing the effects 
of weight loss on nonalcoholic steatohepatitis. Hepatology (Bal-
timore, MD). 2010;51(1):121–9.
	108.	 Hall KD. Predicting metabolic adaptation, body weight change, 
and energy intake in humans. AJP: Endocrinology and Metabo-
lism. 2010 Mar 1;298(3):E449–66.
	109.	 McMurray RG, Ben-Ezra V, Forsythe WA, Smith AT. Responses 
of endurance-trained subjects to caloric deficits induced by diet 
or exercise. Med Sci Sports Exerc. 1985;17(5):574–9.
Publisher's Note  Springer Nature remains neutral with regard to 
jurisdictional claims in published maps and institutional affiliations.
1802
Pharmaceutical Research (2022) 39:1789–1802


---

# Applied Machine Learning Toward Drug Discovery Enhancement: Leishmaniases as a Case Study

- **Authors:** Emna Harigua-Souiai, Rafeh Oualha, Oussama Souiai, Ines Abdeljaoued-Tej, Ikram Guizani
- **Issuer:** Bioinformatics and biology insights
- **Type:** Scientific article
- **Published:** 2022-04-22
- **Language:** en
- **DOI:** 10.1177/11779322221090349
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35478992/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractDrug discovery (DD) research is a complex field with a high attrition rate. Machine learning (ML) approaches combined to chemoinformatics are of valuable input to this field. We, herein, focused on implementing multiple ML algorithms that shall learn from different molecular fingerprints (FPs) of 65 057 molecules that have been identified as active or inactive against Leishmania major promastigotes. We sought to build a classifier able to predict whether a given molecule has the potential of being anti-leishmanial or not. Using the RDkit library, we calculated 5 molecular FPs of the molecules. Then, we implemented 4 ML algorithms that we trained and tested for their ability to classify the molecules into active/inactive classes based on their chemical structure, encoded by the molecular FPs. Best performers were random forest (RF) and support vector machine (SVM), while atom-pair and topology torsion FPs were the best embedding functions. Both models were further assessed on different stratification levels of the dataset and showed stable performances. At last, we used them to predict the potential of molecules within the Food and Drug Administration (FDA)-approved drugs collection to present anti-Leishmania effects. We ranked these drugs according to their anti-Leishmanial probability and obtained in total seven anti-Leishmania agents, previously described in the literature, within the top 10 of each model. This validates the robustness of the approach, the algorithms, and FPs choices as well as the importance of the dataset size and content. We further engaged these molecules into reverse docking experiments on 3D crystal structures of seven well-studied Leishmania drug targets and could predict the molecular targets for 4 drugs. The results bring novel insights into anti-Leishmania compounds.Keywords: Machine learning, molecular fingerprints, Leishmania, classification, drug repurposing, drug target

## Section: Background

Drug discovery (DD) and lead optimization are becoming very challenging tasks to researchers from academia and the private sector. As the number of approved drugs is decreasing, the development costs of a novel valid therapeutic molecule exceed US $1.2 billion for a discovery process lasting over more than 12 years. In this context, computational approaches appeared as promising avenues in lowering the cost, duration, and attrition rate of the DD process. Multiple groups have focused on developing machine learning (ML) and deep learning (DL) algorithms for drug discovery and development.1-3 Unfortunately, drug discovery and lead optimization are still low-data domains with too few molecules reaching the market. Because of this low-data challenge, adapted ML/DL approaches were proposed, such as one-shot learning methods based on structure–activity relationships for activity predictions Altae-Tran et al 4 . Compared to more classical approaches, they demonstrated higher predictive power using small positives in their training sets. However, they showed poor capability of generalization to distinct datasets. Thus, sufficient data are still a cornerstone in the domain.

The low-data issue is even worse for neglected tropical diseases (NTDs), which mainly affect the poorest and most vulnerable populations. For such diseases, available data mostly describe early stages of drug discovery, such as extracellular assays or primary high-throughput screenings (HTSs). It is not likely to access large datasets of molecules validated at different levels of experimental validation (enzymatic, in vitro, in cellulo, ex vivo, in vivo, etc). There is an urgent need to implement alternative cost-effective approaches for drug discovery and repurposing against such diseases using early-stage drug discovery data. We herein focus on Leishmaniases, a group of largely distributed vector-borne parasitic diseases affecting 700 000–1 million cases/year and causing 26 000–65 000 deaths annually. The lack of low-cost and non-toxic treatments for these diseases brings the urge to develop novel therapeutic strategies. However, drugs Research & Development (R&D) faces many challenges that range from increasing costs and pressure on pricing to the high attrition rate. This puts NTDs—including Leishmaniases—in the least prioritized diseases for therapeutics development because of their poor financial potential in the market.

The present work was designed to demonstrate the power of common ML algorithms in classifying molecules as active or inactive against Leishmania parasites based on their chemical structures. We used data originating from a bioassay targeting the Leishmania major promastigote growth and viability, retrieved from the PubChem database. We also implemented a pipeline for data preprocessing and encoding toward their use as input to ML algorithms. Multiple encoding systems of chemical structures, called molecular fingerprints (FPs), were used. We then compared the performances of different ML algorithms on stratified subsets of the data. The best combinations of (ML, FP, and subset) were further validated on unseen data from a second bioassay, prior to their use for drug repurposing predictions against Leishmaniasis, and identification of potential targets for the molecules selected.

## Section: Methods › Datasets

Data were retrieved from 2 phenotypic bioassays targeting the Leishmania promastigotes and deposited in the PubChem database under the references AID 1063 and AID 1258. Data corresponded to parasite growth and viability inhibition experiments with a binary activity outcome (active and inactive). The experiments measured Leishmania spp promastigotes drug susceptibility through Alamar blue-based assay. The number of viable promastigotes correlated with a colorimetric reading, which indicated the anti-Leishmanial effect of the active molecules. The first bioassay (AID 1063) is a preliminary HTS of 65 057 molecules whose results were used for the training of multiple ML algorithms and their optimization toward selecting the most performing one(s). The second bioassay (AID 1258) is a confirmatory screening performed on 1 122 molecules derived from the first bioassay that were tested at a lower concentration of 1 µM. We used it as an external validation set that has not been seen by the best performer(s). For simplicity’s sake, molecules with “Inconclusive” activity outcome were discarded from the AID (1258) dataset.

The Food and Drug Administration (FDA)-approved drugs collection used herein was downloaded on April 13, 2021, from the ZINC database. 5

## Section: Methods › Data encoding

Chemical structures of the molecules were encoded using the Simplified Molecular Input Line Entry System (SMILES), retrieved directly from the PubChem database, and merged with the bioassay data frame according to the PubChem identifier of each compound (CID).

Prior to molecular structure encoding into numerical vectors, we performed a series of data splitting to obtain multiple datasets with different sizes. We first performed a data equilibration of the dataset using the random over sampling (ROS) algorithm, previously described as one of the most performing methods in drug discovery. 3 Then, we performed a random undersampling (RUS) through a reduction of the elements within the largest class inactive. Finally, we performed 2 sub-sampling of the RUS dataset up to 10% and 1%. Thus, we disposed of 5 datasets, namely, the original dataset, the ROS dataset, the RUS dataset, the 10% sub-sample of the RUS dataset, and the 1% sub-sample of the RUS dataset. Molecule structures were then encoded into intelligible format for the ML algorithms used herein. Out of the SMILES within each dataset, we generated molecule objects using the RDkit 6 library under Python (http://www.rdkit.org). We then calculated different types of molecular FPs that consist of binary vectors. All datasets were split into training (80%), validation (10%), and test (10%) sets. The validation set will be used to fine-tune the ML models’ hyperparameters prior to evaluating its performances on the test set.

Five molecular FPs were calculated using RDkit for each compound within the datasets: (1) the RDkit molecular fingerprints (RDFPs), (2) the atom-pair FPs (APFPs), (3) the topology torsion FPs (TTFPs), and (4) the extended-connectivity FPs with a radius of 2 atoms (ECFP4) and the extended-connectivity FPs with a radius of 3 atoms (ECFP6).

## Section: Methods › Machine learning

Four ML algorithms were implemented under Sci-kit learn, an open-source Python library. 7 The molecular FP vectors were used as input to perform a binary classification of the molecules into active and inactive classes. The algorithms are: linear regressor (LR), gradient boosting (GB), random forest (RF), and support vector machine (SVM). We performed a 5-fold cross-validation tuning to optimize the ML models based on their accuracy when trained on all 5 datasets.

For most performant models, the receiver operating characteristic (ROC) and the precision–recall (PR) curves were generated and their area under the curve (AUC) scores were calculated. Based on the confusion matrix elements: the true positives (TP), the false positives (FP), the true negatives (TN), and the false negatives (FN), we calculated different metrics to assess models’ performances, namely, sensitivity (also called recall), specificity, precision, balanced accuracy, and the F1-score.

The best classifier(s) were then used to identify potential anti-Leishmania effectors within the FDA-approved drugs collection for which suitable FPs were generated. For each molecule, probabilities of being classified as active and inactive are calculated.

All simulations were run on one machine with the following specifications: Hardware (CPU—Inteli7-9750H @ 5.00 Ghz, RAM-32GB DDR4) and Software (Ubuntu 20.04 LTS, Python-3.6, RDkit 2017.09.1, Scikit-Learn 0.23.1, Matplotlib 3.2.2, Numpy 1.19.0).

## Section: Methods › Machine learning › Reverse docking

Crystal structures of Leishmania proteins that are considered as potential drug targets for anti-Leishmania therapeutics were retrieved from the Protein Data Bank (PDB). These were the pteridine reductase 1 (PTR1; PDBid: 2BFM), the trypanothione reductase (TR; PDBid: 2KJ6), the dihydroorotate dehydrogenase (DHODH; PDBid: 3MJY), the mitogen-activated protein kinase 10 (MAPK10; PDBid: 3UIB), the arginase (PDBid: 4IU0), the UDP-glucose pyrophosphorylase (UDP-GP; PDBid: 5NZL) and the N-myristoyltransferase (NMT; PDBid: 6QD9).

All structures were retrieved from the PDB using their IDs and prepared for docking simulations using the Open Babel software. 8 Water molecules and co-crystallized ligands were removed. Explicit hydrogens were added and atomic charges were calculated using the Gasteiger model. Prepared structures will be here referred to as receptors. On each receptor, we defined the docking space as a large virtual box that included the catalytic site, based on the 3D coordinates of the co-crystal ligand atoms. Drug molecules were also prepared for docking simulations through adding hydrogen atoms and Gasteiger atomic charges, using Open Babel. They will be here referred to as ligands. Docking of all ligands were performed against all receptors using the AutoDock Vina program. 9

The docking outputs were analyzed and scores from all simulations were retrieved. The minimum, the maximum, and the mean value of all docking scores were calculated to assess their distribution and interval of variation.

In addition, a contact analysis was performed to assess for each receptor the list of residues within 3.5 Å of both the co-crystal ligand and the docked drug considering the best scored pose. For co-crystal ligands and docked drugs, we calculated a contact rate (CR) as the fraction between the total number of contacts established between the target and the ligand divided by the total number of the ligand atoms. The software PyMol, Schrödinger & DeLano 10 was used for visualization of the docking outputs and figures generation.

## Section: Results

Datasets descriptive statistics. (A) Histogram of the chemical similarity distribution calculated pairwise between molecules constituting the dataset. (B) Bar plots of the proportions of active and inactive molecules within each dataset. RUS indicates random undersampling.

Algorithms’ accuracy obtained with the different ML models on the 5 datasets encoded through 5 molecular fingerprints. All simulations included hyperparameters’ tuning through a five-fold cross-validation. (A) ML models’ accuracy distribution for each type of fingerprints. (B) ML models’ accuracy distribution for each dataset. GB indicates gradient boosting; LR, linear regressor; ML, machine learning; RF, random forest; ROS, random over sampling; SVM, support vector machine.

ROC and PR curves of the optimized RF and SVM optimized on the original dataset. (A) ROC curves for models trained on the ROS dataset. (B) PR curves for models trained on the ROS dataset. (C) ROC curves for models trained on the original dataset. (D) PR curves for models trained on the original dataset. (E) ROC curves for models trained on the RUS dataset. (F) PR curves for models trained on the RUS dataset. AUC indicates area under the curve; PR, precision–recall; RF, random forest; ROC, receiver operating characteristic; ROS, random over sampling; SVM, support vector machine.

RF and SVM models’ performances when trained on the original dataset. For each model TP, FP, TN, and FN counts were reported. Percentages of the TP and TN (shown between parentheses) were calculated as the fraction: (predicted count/real count) × 100.

Docking scores for each (receptor, ligand) pair. Scores from the best poses (lowest scores) were retrieved. The threshold value T = –9.6 kcal/mol is also indicated for reference.

List of the top 10 FDA-approved drugs with the highest probabilities of being anti-Leishmania effectors that were predicted by RF and SVM trained on the original dataset encoded using the atom-pair fingerprints. The compounds already described as anti-Leishmania appear in bold. Four drugs matched with Leishmania targets in our docking experiments. Their docking scores with the identified potential targets are indicated along with the PDB structure used for the reverse docking simulations.

Docking poses of the predicted target–drug pairs using reverse docking simulations. All figures show the protein targets in cyan cartoon representation, with superimposed co-crystal ligands in yellow licorice and docked drugs in magenta. (A) Docking of ganciclovir on the pteridine reductase 1 (PDBid: 2BFM). (B) Docking of domperidone on the trypanothione reductase (PDBid: 2JK6). (C) Docking of prilocaine on the MAPK10 (PDBid: 3UIB). (D) Docking of albendazole on the N-myristoyltransferase (PDBid: 6QD9). MAPK10 indicates mitogen-activated protein kinase 10.

## Section: Results › Datasets presented a satisfactory chemical diversity

The first dataset (AID 1063) contained 47 427 inactive compounds and 17 630 active compounds; indicating a non-equilibrated state, with 72.9% of inactive versus 27.1% of active molecules. We further explored the content of this dataset to estimate its chemical diversity prior to its use for the training of the ML models. We calculated pairwise chemical similarity of the molecules using the RDkit FPs as embedding function and the Tanimoto coefficient as a distance metric. The pairwise distance histogram showed that the dataset presents a satisfactory chemical diversity with an average value of the Tanimoto coefficient equal to 0.28 +/– 0.08 and too few values higher than 0.6 (Figure 1).

Through 2 equilibration simulations based on oversampling and undersampling methods, we generated the ROS and RUS datasets, respectively. Then, we randomly subsampled 10% and 1% of the RUS dataset with respect to class equilibration to obtain the RUS_10% and RUS_1% datasets, respectively. The 4 equilibrated datasets presented equivalent class sizes of 47 427, 17 630, 1736, and 177 for ROS, RUS, RUS_10%, and RUS_1%, respectively (Figure 1).

Datasets descriptive statistics. (A) Histogram of the chemical similarity distribution calculated pairwise between molecules constituting the dataset. (B) Bar plots of the proportions of active and inactive molecules within each dataset. RUS indicates random undersampling.

## Section: Results › RF and SVM were identified as the best performing models

For the 5 datasets derived from the AID1063 bioassay, we generated molecular FPs based on the molecules’ SMILES. Five molecular FPs were used to encode all molecules, namely: ECFP4, ECFP6, RDFP, APFP, and TTFP. Each encoded dataset was split into a training, a validation and a test set with 80/10/10 proportions. The training sets were used to train 4 ML algorithms and the validation sets were used for hyperparameters optimization. We performed cross-validation with 5-fold stratification and estimated the models’ accuracy. Figure 2 shows the obtained results for each algorithm trained on all datasets encoded through the different molecular FPs. Accuracy distributions obtained by each ML model revealed similar distributions for all types of FPs suggesting little impact on the models’ performances (Figure 2A; Supplementary Figure S1A). On the other hand, the size and composition of the datasets appeared to be the most influencing condition on accuracy distributions (Figure 2B; Supplementary Figure S1B). When comparing the models’ performances, GB presented the least accuracy values, followed by LR while RF and SVM exhibited the highest accuracy values overall (Figure 2; Supplementary Figure S1C). Noticeably, the ROS dataset encoded with the APFP demonstrated the highest accuracy value of 0.89 obtained with both RF and SVM, while the 10% and 1% subset of the RUS dataset led to values lower that 0.70 (Figure 2B; Supplementary Table S1). Overall, the original dataset presented a comparable accuracy distribution with the ROS dataset, while the RUS dataset led to slightly lower values with the highest obtained with RF and SVM. We chose to focus on these 2 models trained on the original, the ROS and the RUS datasets for further validation.

We aimed at further assessing the impact of the size and the imbalance of the data on models’ performances. We generated the ROC and the precision–recall (PR) curves for each model trained on the original, the ROS and the RUS datasets and calculated their AUC scores. All simulations induced comparable performances in terms of AUC_ROC and AUC_PR scores (Figure 3). The highest AUC scores were obtained with the ROS dataset for both models. Nonetheless, simulations on the ROS dataset revealed an overfitting of the models with AUC scores of 0.99 and 0.98 on the training sets with RF and SVM, respectively. Training the models on the original and RUS datasets induced no overfitting with AUC_ROC scores on the training sets ranging from 0.79 to 0.81 and AUC_PR scores ranging from 0.80 and 0.85 for both models. Thus, we retained models trained on the original dataset for further validation.

Algorithms’ accuracy obtained with the different ML models on the 5 datasets encoded through 5 molecular fingerprints. All simulations included hyperparameters’ tuning through a five-fold cross-validation. (A) ML models’ accuracy distribution for each type of fingerprints. (B) ML models’ accuracy distribution for each dataset. GB indicates gradient boosting; LR, linear regressor; ML, machine learning; RF, random forest; ROS, random over sampling; SVM, support vector machine.

ROC and PR curves of the optimized RF and SVM optimized on the original dataset. (A) ROC curves for models trained on the ROS dataset. (B) PR curves for models trained on the ROS dataset. (C) ROC curves for models trained on the original dataset. (D) PR curves for models trained on the original dataset. (E) ROC curves for models trained on the RUS dataset. (F) PR curves for models trained on the RUS dataset. AUC indicates area under the curve; PR, precision–recall; RF, random forest; ROC, receiver operating characteristic; ROS, random over sampling; SVM, support vector machine.

## Section: Results › External validation revealed satisfactory predictive power

The original dataset contained activity information on 65 057 molecules obtained through a preliminary screening (AID 1063). A subset of 1122 molecules was subject to a confirmatory screening (AID 1258). The results led to confirming 146 active molecules, 963 inactive molecules and 13 molecules with inconclusive activity outcome. We randomly extracted 73 out of the confirmed actives, and 482 out of the inactive molecules from the original dataset to constitute an external validation set. Then, we retrained the RF and SVM models with their optimal parameters on the truncated original dataset using the AID 1063 activity outcome data. RF and SVM achieved TP counts of 59 and 62 out of 73 and FP counts of 193 and 174, respectively (Table 1). As the data are imbalanced, we calculated the balanced accuracy to assess whether the models are correctly classifying both active and inactive molecules. RF and SVM both achieved scores of 0.72. We also calculated the F1-score that balances precision and recall on the positive class and obtained scores of 0.37 and 0.39 for RF and SVM, respectively. Both models achieved high FP counts, which is common in cases where class imbalance is important. Nonetheless, we consider the predictive power of both models satisfying with regards to the fraction of active molecules equal to 13% (73/555) of the total test set.

RF and SVM models’ performances when trained on the original dataset. For each model TP, FP, TN, and FN counts were reported. Percentages of the TP and TN (shown between parentheses) were calculated as the fraction: (predicted count/real count) × 100.

## Section: Results › Application of the selected models to FDA-approved collection suggested repurposing some drugs against Leishmaniasis

At last, we used the optimized SVM and RF model previously trained on the original dataset to predict which of 1 065 FDA-approved drugs can be considered as anti-Leishmania effectors. We sorted the molecules predicted as potentially Leishmanicidal according to their probability of being active and selected the top 10 candidates for each model (Table 1). For RF, literature review demonstrated that 5 out of the top 10 molecules were indeed described as anti-Leishmania agents, namely, albendazole, 11 pyrazinamide (Mendez et al., 2009) 19 , domperidone,12-14 dibucaine 15 , and lidocaine.16,17 For SVM, three molecules out of the 10 were described as anti-Leishmania effectors, namely, phenelzine, 18 domperidone,12-14 and rifabutin. 19 Noticeably, domperidone has been selected by both models. Its potential to treat Leishmaniasis was investigated up to clinical trial phases.12-14 Albendazole was explored for its anti-Leishmania effects until it proved of limited efficacy in hamster models. 11 Also pyrazinamide, an anti-tuberculosis drug showed promising results in early stages of drug discovery investigations. 20 On the other hand, investigations of dibucaine’s effects had stopped at preclinical stages in hamster models. 15 Lidocaine was described as enhancing the outcome of first line anti-Leishmania treatment antimonials through clinical trials.16,17 Rifabutin was validated for inhibiting intracellular parasite growth and had promising pharmacokinetic properties. 19 Finally, phenelzine is an antidepressant molecule with validated anti-Leishmania effects in vitro and in vivo. 18 To conclude, 7 out 19 FDA-approved drugs predicted by RF and SVM were precedingly described for their anti-Leishmania effect. This further validated our approach toward the identification of novel anti-Leishmania drug candidates either within the FDA-approved drugs collection or within other chemical collections for lead discovery in future studies.

Docking scores for each (receptor, ligand) pair. Scores from the best poses (lowest scores) were retrieved. The threshold value T = –9.6 kcal/mol is also indicated for reference.

List of the top 10 FDA-approved drugs with the highest probabilities of being anti-Leishmania effectors that were predicted by RF and SVM trained on the original dataset encoded using the atom-pair fingerprints. The compounds already described as anti-Leishmania appear in bold. Four drugs matched with Leishmania targets in our docking experiments. Their docking scores with the identified potential targets are indicated along with the PDB structure used for the reverse docking simulations.

Docking poses of the predicted target–drug pairs using reverse docking simulations. All figures show the protein targets in cyan cartoon representation, with superimposed co-crystal ligands in yellow licorice and docked drugs in magenta. (A) Docking of ganciclovir on the pteridine reductase 1 (PDBid: 2BFM). (B) Docking of domperidone on the trypanothione reductase (PDBid: 2JK6). (C) Docking of prilocaine on the MAPK10 (PDBid: 3UIB). (D) Docking of albendazole on the N-myristoyltransferase (PDBid: 6QD9). MAPK10 indicates mitogen-activated protein kinase 10.

## Section: Results › Application of the selected models to FDA-approved collection suggested repurposing some drugs against Leishmaniasis › Reverse docking predicted targets among selected Leishmania proteins

The approach used herein to identify novel anti-Leishmania effectors is a top-down approach, also called ligand-based drug discovery. It permits the prediction of molecules activity with no prior knowledge on their molecular targets within the cell. Through this method, we were able to identify, although with no prior knowledge on the targets, 19 drugs among which a set of 7 were previously described in the literature as being anti-Leishmania effectors. This constituted a solid confirmation of the proposed approach.

In addition to these confirmed anti-Leishmania molecules, the second set of 12 drugs thus corresponds to novel potential effectors. Drugs from both sets have unknown molecular targets. Thus, we performed additional analyses using in silico reverse docking simulations of these 19 potential anti-Leishmania drugs against a series of Leishmania enzymes identified as potential drug targets, having available crystal structures in complex with ligands in the PDB database. The score values for all molecules docked on all targets followed a Gaussian-like distribution (Supplementary Figure S2), with a maximal value of –6.8 kcal/mol, a minimal value of –13.9 kcal/mol, and a mean value of –9.6 kcal/mol, that we set as a threshold (T) to define relevant docking poses as those with scores inferior to T.

For each (target and drug) pair, we identified the best docking pose as the one exhibiting the lowest docking score (Figure 4). Noticeably, rifabutin and domperidone exhibited the lowest scores on all receptors. Targets 3MJY, 4IU0, and 5NZL had docking scores mostly higher or equal to the threshold T, except with rifabutin and domperidone (Figure 4). On the other hand, 2JK6 followed by 2BFM and 6QD9 presented the lowest scores for all docked ligands, overall.

To identify the most relevant (target and drug) pairs based on the docking results, we calculated the CRs of each docked drug. We then compared them to those observed with the co-crystal ligands of each receptor. Drugs presenting a CR with a given target that is higher or equal to 50% of the CR of the corresponding co-crystal ligand, were retained, which led to identify 4 potential (target and drug) pairs, namely: (2BFM/PTR1, ganciclovir), (2JK6/TR, domperidone), (3UIB/MAPK10, prilocaine), and (6QD9/NMT, albendazole). Corresponding docking scores were, respectively, –10.1, –10.2, –10.3, and –12.2 kcal/mol for ganciclovir, albendazole, prilocaine, and domperidone, indicating high affinity between the drugs and their predicted targets (Table 2). Visual examination of the docking poses from the above-mentioned (target and drug) pairs revealed superimposition of common chemical substructures with the co-crystal ligand (Figure 5), suggesting similar receptor-ligand interactions between the co-crystal ligands and the predicted drugs.

Docking scores for each (receptor, ligand) pair. Scores from the best poses (lowest scores) were retrieved. The threshold value T = –9.6 kcal/mol is also indicated for reference.

List of the top 10 FDA-approved drugs with the highest probabilities of being anti-Leishmania effectors that were predicted by RF and SVM trained on the original dataset encoded using the atom-pair fingerprints. The compounds already described as anti-Leishmania appear in bold. Four drugs matched with Leishmania targets in our docking experiments. Their docking scores with the identified potential targets are indicated along with the PDB structure used for the reverse docking simulations.

Docking poses of the predicted target–drug pairs using reverse docking simulations. All figures show the protein targets in cyan cartoon representation, with superimposed co-crystal ligands in yellow licorice and docked drugs in magenta. (A) Docking of ganciclovir on the pteridine reductase 1 (PDBid: 2BFM). (B) Docking of domperidone on the trypanothione reductase (PDBid: 2JK6). (C) Docking of prilocaine on the MAPK10 (PDBid: 3UIB). (D) Docking of albendazole on the N-myristoyltransferase (PDBid: 6QD9). MAPK10 indicates mitogen-activated protein kinase 10.

## Section: Discussion

DD is a lengthy and costly process that also suffers from a high attrition rate. Classical approaches to drug discovery refer to screening chemical libraries using either phenotypic or enzymatic assays according to different ligand- or structure-based pipelines. 21 To reduce time and cost, computational and artificial intelligence approaches are increasingly involved in the drug development process. 22 The most common applications of such approaches are (1) novel hit compound identification through docking simulations on targets and (2) predictive analytics of molecules’ biological activity based on their chemical structures. The first approach, structure-based, is heavily focused on known targets and aims at identifying potential inhibitors of its biochemical and/or biological activity. The second approach, called ligand-based, focuses on ligands, and uses their chemical structure/properties toward assessing their potential as novel hits with no prior knowledge of their target. For these ligand-based approaches, combined chemoinformatics and ML are now rapidly evolving toward successful drug discovery research outcomes.23-25 Many groups developed sophisticated deep learning architectures that shall outperform classical ML algorithms. Besides the algorithm performances, the molecular descriptors and/or FPs that are used to encode the chemical structures of the molecules are of utmost importance within the process.26-28 In fact, the hypothetical basis of such approaches considers that molecules with similar chemical structures and properties are likely to have similar biological activities through similar molecular interactions with key proteins (targets).

In this context, we implemented a ligand-based approach for the identification of novel drugs and treatments against Leishmaniases, a group of infectious diseases for which this aim continues to be a challenge and a priority.29-31 We presented a proof of concept that classic ML algorithms can achieve satisfying results. In fact, we have put together a pipeline to compare and optimize the combination of the molecular FPs and an ML algorithm to achieve the highest accuracy. In our specific case, RF and SVM demonstrated the highest accuracy scores on data encoded using the APFPs. Moreover, we performed a series of data stratification to assess the impact of data size and content on algorithms. Results supported the importance of data size toward high accuracy of all ML algorithms tested in the present work. Conversely, data encoding systems (FPs) had no impact on models’ performances. Surprisingly, data imbalance also had no significant effect on the performances of the best models, RF and SVM. In fact, most equilibration techniques add novel entries to the dataset through duplication-based algorithms, and are less likely to add new information.

Best performing algorithm, SVM, demonstrated an accuracy of 0.89 and AUC_ROC score of 0.82. Other groups used similar approaches to train and validate ML algorithms RF, SVM, Bayesian models, etc using the CDD TB database Collaborative Drug Discovery Inc toward antimalarial compounds identification. 25 Using 4 different datasets of sizes between 1248 and 2273, the authors obtained comparable AUC_ROC scores for 4 ML algorithms varying between 0.57 and 0.86. These authors have found that no specific model could be considered as outperforming the others and that the chemical diversity and content of the training dataset was the most important parameter. This is in line with our hypothesis and findings as we were able to validate the robustness of our models across the different datasets derived through stratification and balancing techniques. Through an external validation, we were able to provide reliable proof on the models’ performances in classifying drugs into active vs inactive against Leishmania. We also assessed the models’ performances through the balanced accuracy and the F1-score. Although highly dependent on the number of TP, the F1-score is weighted by the number of FN and FP. Moderate F1-score values are often obtained with unbalanced datasets. Korotcov et al 32 obtained F1-scores for a series of ML models trained on multiple unbalanced datasets that varied between 0.2 and 0.8. Lowest F1-scores 0.2–0.4 correlated with high imbalance rates of the data. In the specific case studied herein, where the active class represents only 13% of the test set, low to medium F1-scores 0.37–0.39 appeared acceptable. These figures were mainly due to the high number of FP, a recurrent issue with imbalanced sets-based classification in drug discovery,28,33,34 even when random oversampling techniques are applied toward equilibration. 3 We used the optimized RF and SVM models to predict potential anti-Leishmania molecules within the FDA-approved drugs collection. The top 10 predicted molecules by each of the RF and SVM models, respectively, contained 5 and 3 molecules with confirmed anti-Leishmania effects.

Our approach has the advantage to overcome the need for a preconceived knowledge about the molecular targets. It uses data from phenotypic screens to train the algorithms and identify active molecules within collections of compounds. We herein used the FDA-approved drugs collection to predict novel anti-Leishmania effectors. Nonetheless, the models could be tested on natural products databases or other large chemical collections. This highlights the potential of bioinformatics and artificial intelligence in drug discovery and design. Furthermore, for neglected diseases, such as Leishmaniases, little knowledge on drug targets is available. Despite the recent progress on Leishmania species genomes elucidation, 35 too few Leishmania proteins have resolved crystal structures or are validated as drug targets. Through our AI-based approach (ie, based on a phenotypic drug screening), we were able to overcome this knowledge shortage and predict novel potential anti-Leishmania effectors.

## Section: Discussion › Molecules

We complemented these findings with target predictions using reverse docking by referring to the crystal structure of well-defined Leishmania drug targets, expecting that some of these could constitute targets for the set of selected molecules. Despite the current limitations, it was possible to identify some of the selected molecules as potential binders to 4 out of 7 known Leishmania targets. Four target and drug pairs were predicted, namely, TPR1, ganciclovir, TR, domperidone, MAPK10, prilocaine, and NTM, albendazole. The docking highlighted alignment of substructures of the co-crystal ligands and the docked drugs. This brings novel insights about the predicted compounds and their potential targets. It also confirms the relevance of using chemical similarity of known active molecules to predict novel bioactive entities. Owing to literature validation of the selected molecules as potentially relevant to DD pipeline to fight Leishmaniases, the developed approach appears accurate. The other novel drugs herein predicted as potential anti-Leishmanial will need to be investigated in the future. This work supports the suggestion of drug repurposing as a new strategy for discovering anti-Leishmanial candidates 36 or optimizing them. It combined both ligand- and structure-based approaches to validate ML models, identify novel potential anti-Leishmania drugs and provide exploratory data on their potential targets in Leishmania.

## Section: Conclusions

Machine learning has proved its interest and power in the field of drug discovery and development. With the rise of data curation and centralization efforts and the democratization of computational power, it is evolving toward more effectiveness. We herein demonstrated the usefulness of state of the art ML algorithms combined with suitable molecular embedding functions to efficiently predict biological activity of molecules based on their chemical structure. Data availability, size, and content remain a cornerstone in this field. Further development can be made toward quantitative activity predictions, for which dedicated datasets are a prerequisite.

## Section: Supplemental Material

Click here for additional data file.

Click here for additional data file.

## Section: Associated Data

Click here for additional data file.

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.

Click here for additional data file.


---

# Artificial intelligence-based decision support model for new drug development planning

- **Authors:** Ye Lim Jung, Hyoung Sun Yoo, JeeNa Hwang
- **Issuer:** Expert systems with applications
- **Type:** Scientific article
- **Published:** 2022-03-08
- **Language:** en
- **DOI:** 10.1016/j.eswa.2022.116825
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35283560/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

New drug development guarantees a very high return on success, but the success rate is extremely low. Pharmaceutical companies have attempted to use various strategies to increase the success rate of drug development, but this goal has been difficult to achieve. In this study, we developed a model that can guide effective decision-making at the planning stage of new drug development by leveraging machine learning. The Drug Development Recommendation (DDR) model, we present here, is a hybrid model for recommending and/or predicting drug groups suitable for development by individual pharmaceutical companies. It combines association rule learning, collaborative filtering, and content-based filtering approaches for enterprise-customized recommendations. In the case of content-based filtering applying a random forest classification algorithm, the accuracy and area under curve were 78% and 0.74, respectively. In particular, the DDR model was applied to predict the success probability of companies developing Coronavirus disease 2019 (COVID-19) vaccines. It was demonstrated that the higher the predicted score from the DDR model, the more progress in the clinical phase of the COVID-19 vaccine development. Although our approach has limitations that should be improved, it makes scientific as well as industrial contributions in that the DDR model can support rational decision-making prior to initiating drug development by considering not only technical aspects but also company-related variables.

## Section: Introduction

New drug development is a high-risk, high-return business that guarantees enormous profits upon success, but the success rate is extremely low (Munos, 2009, Taylor, 2016). It requires extensive research and development (R&D) periods including clinical trials and immense investment costs to develop just a single drug. For these reasons, pharmaceutical companies have eagerly sought various strategies and tactics to increase the possibility of success in their drug development projects (Schuhmacher, Gassmann, & Hinder, 2016). One of these solutions can be to take advantage of big data and artificial intelligence (AI), which have recently undergone exponential growth and expansion (Chang et al., 2020, Henstock, 2019, Tseng et al., 2021).

The pharmaceutical industry has been vigorously adopting data mining, machine learning, and AI technologies to reduce the time and cost required for drug discovery and development, mainly led by multi-national large pharmaceutical companies (Jimenez-Luna et al., 2020, Réda et al., 2020). The value of AI in the drug discovery market is expected to grow rapidly at a compound annual growth rate of 40.8%, increasing from 260 million US dollars (USD) globally in 2019 to reach 1.43 billion USD in 2024 (MarketsandMarkets, 2019). The areas in which AI technologies can be applied in drug discovery and development include target identification and validation, small-molecule design and optimization, prediction of biomarkers, and computational pathology (Vamathevan et al., 2019). Specifically, most of the applications have been focused on optimizing and enhancing efficiency in the drug discovery process (Chan et al., 2019, Freedman and Reardon, 2019, Schneider et al., 2020) that can be segmented into sub-categories of compounds, genomics, targets, and antibodies (Schuhmacher, Gatto, Hinder, Kuss, & Gassmann, 2020).

However, in addition to the experimental drug discovery process, it is necessary to smartly leverage AI technologies in the planning stage of drug development in terms of business and management. Pharmaceutical companies wonder what kind of drugs they should aim for their next development project, considering their company’s situation from managerial and market perspectives. In most cases, the decisions on the drugs aimed at development have been made qualitatively based on the views of the company's board of directors or the technologies possessed by the companies (Schuhmacher, Gassmann, Hinder, & Kuss, 2021). That is, decision-making on drug development has hitherto depended more on human judgment than formal analytical or data-based methodologies (Jekunen, 2014). Therefore, there is a great need for an effective model or solution that can increase their success rate of drug development.

In this regard, this study arose from the following research questions: “Can AI be utilized for decision-making on drug development plans? Specifically, can data-based machine learning techniques suggest developable drugs depending on the business situation of each pharmaceutical company?” In this context, the objective of this study is to develop a decision-support model to recommend the most developable drug groups in a manner customized for individual pharmaceutical companies. The current technologies recommend new drug candidates that are expected to be effective in particular diseases based on technological factors (Jeon et al., 2014, Wang et al., 2015, Zhang et al., 2014) regardless of the actor to perform the development. That is, the previously reported methods of recommending new drug candidates were difficult to be tailored for a specific company. When generating recommendations, they did not take into account which companies would be most effective at developing a specific drug and which drugs have the highest probability of success for a specific company. However, the possibility of development success can be greatly influenced by factors such as the company's drug development experiences, technical know-how, product portfolio, financial status, and the market environment of the drugs (Arora et al., 2009, Blau et al., 2004, Ringel et al., 2013). In this study, we tried to address these issues, which were insufficiently considered in prior research, by proposing a decision support model that recommends new drugs that is most suitable for a company (or developer), considering not only technological aspects but also management/business aspects. We have adopted the main conception of the recommender systems with the objective of devising a company-tailored drug development recommendation (DDR) model that considers each company's situational conditions.

Specifically, we developed a new model that recommends and/or predicts drug groups with high probability of success in development. The proposed model is based on the hypothesis that “users” information in recommender systems can correspond to “pharmaceutical companies” and “purchased/rated items” information can be matched with “drugs developed successfully.” Among the techniques employed in recommender systems, we applied three types of approaches, namely association rule learning, collaborative filtering (CF), and content-based filtering (CBF), which are the most widely and successfully utilized algorithms. The results obtained through each approach were then combined to create a hybrid model, named the DDR model, in order to compromise the limitations of the individual approaches and improve the quality of recommendations/predictions. The DDR model recommends and/or predict drug groups suitable for development in a highly enterprise-customized (i.e., personalized) manner.

This study added scientific value to the literature by investigating the features which were not fully considered in previous studies and identifying several important characteristics related to companies and drugs that can predict drug development success. Also, it presents a reliable method to improve the quality of recommendation by combining three different algorithms for the purpose of use in drug development planning. In addition, it offers industrial contributions that it can effectively be utilized in the product planning stage to assist decision-making or prioritization about which drug groups to develop, before undertaking the drug development process. It is also feasible to predict which companies are most likely to succeed in the development for a specific drug group, among the companies currently engaged in its development, based on the DDR model. The validity and practical applicability of the DDR model was successfully demonstrated by accurately predicting the companies with high potential of success in the development of COVID-19 vaccines, one of the drugs most urgently in need of development.

## Section: Theoretical backgrounds › AI in pharmaceutical portfolio management

AI technologies have been actively introduced in drug discovery and development since the last few decades. The current state of AI in the pharmaceutical industry is considered to be at an early mature level in the technology life cycle (Schuhmacher et al., 2020). As one of the AI applications, it is utilized not only in the experimental process of drug discovery and development, but also in drug portfolio management.

Portfolio management is known as a dynamic decision process that facilitates the evaluation, selection, and prioritization of new projects, and the acceleration, discontinuation, and deprioritization of existing projects (Cooper, Edgett, & Kleinschmidt, 1999). Pharmaceutical companies have utilized it as one of the most important strategies to increase R&D success rates by reducing project risks (Schuhmacher et al., 2016). Ding et al. (Ding & Eliashberg, 2002) and Jekunen (Jekunen, 2014) identified that the factors mainly considered to construct an optimal pipeline portfolio include the cost of development, likelihood of surviving, expected profitability, competitive situation, market size, and novelty of the drug. In order to make decisions about drug development, pharmaceutical companies have relied heavily on human judgement and prior product development experiences in the past (Betz, 2011, Krishnan and Ulrich, 2001). To address the limitations of these qualitative decisions, quantitative data-driven methods, such as scoring, surveys, discounted cash flow (DCF), real option valuation (ROV), Monte Carlo/discrete event simulations, patent evaluation methods have been applied to lower risks and maximize returns (Betz, 2011, Blau et al., 2004, Jekunen, 2014). More recently, AI technologies such as machine learning or deep learning are expected to rapidly replace much of project and portfolio management in pharmaceutical R&D (Schuhmacher et al., 2021).

Specifically, there have been several attempts to predict the success probability and likelihood of approval (LoA) of clinical trials based on diverse factors affecting the success of the clinical trials, and to utilize it for pharmaceutical portfolio decision-making. DiMasi et al. (DiMasi et al., 2015) developed a predictive model using statistical methods (associations and logistic regressions) and machine learning techniques (random forest and classification and regression trees (CART)) to predict regulatory marketing approval after phase Ⅱ in the case of cancer drugs. They proposed a scoring method that combines the results of these techniques, called the Approved New Drug Index (ANDI) metric. They demonstrated that the predictive performance of the ANDI metric obtained using only four factors (number of patients in pivotal phase Ⅱ, number of patients treated worldwide, phase Ⅱ duration, and activity (response rates)) was sufficiently high for predicting the regulatory marketing approval of cancer drugs.

In addition, Lo et al. (Lo, Siah, & Wong, 2019) developed a model to predict drug approvals based on machine learning using the data on drug development and clinical trials from 2003 to 2015. In particular, they applied statistical imputation methods to missing values to utilize the available data as efficiently as possible. The model built by applying this approach was superior in performance compared to complete case analysis, which generally applied in most previous studies. The important features found to predict drug approvals in this model were trial outcomes, trial status, and trial accrual rates. They asserted that the results obtained from this study offer useful insights into the outcome of drug development because many of these are variables that had not been considered in prior studies.

Feijoo et al. (Feijoo, Palopoli, Bernstein, Siddiqui, & Albright, 2020) also developed a model to predict the phase transition and LoA of clinical trials using supervised machine learning (SML) and Natural Language Processing (NLP) algorithms. The authors used the NLP algorithm to extract an indicator measuring the complexity of eligibility criteria from the text data of ClinicalTrials.gov., which had not been explored in previous studies. Including this predictor, the authors constructed a SML model which can predict the clinical phase success with an accuracy of 80%. This study found that the eligibility criteria complexity and the number of end points were key predictors. They suggested that the SML model can be used to obtain insightful information for clinical protocol design or operational feature management (from the clinical trial practitioners’ perspective) and portfolio assessment and effective decision-making (from the entrepreneurs’ perspective).

Since most of the existing prediction models used the characteristics related to the conditions or results of clinical trials as important variables for prediction, the scope of application of such models may be limited to drugs after the initiation of clinical trials. However, many companies need to forecast which drug will have a high probability of success before starting drug development, that is, in the business planning stage, for effective drug portfolio management and decision-making on investment prioritization. In this context, the DDR model proposed in this study has the advantage of being able to predict in advance the possibility of drug development success using company profiles and a few characteristics of a drug even before the start of clinical trials. In addition, by combining the algorithms used in the recommender systems, which have been widely used for product purchase recommendation but not utilized for drug development planning, it can provide not only the possibility of clinical trial success but a recommendation ranking for specific drug classes (from among 77 drug classes covering all disease areas), tailored to each pharmaceutical company. A more detailed discussion of the recommender systems is continued in the next section.

## Section: Theoretical backgrounds › Recommender systems

Recommender systems, which are one of the most successful applications of AI, suggest preferable items to customers based on user-item interaction information (Adomavicius & Tuzhilin, 2005). Its practical usefulness and effectiveness have been substantially proven by large-scale business applications in industries such as YouTube, Amazon, and Netflix. The recommender systems can generally be categorized into association rule mining methods and information filtering methods. The association rule mining is a traditional data mining technique to find association rules between a set of co-purchased products (Sarwar, Karypis, Konstan, & Riedl, 2000a). Apriori, tree projection, and direct hashing and pruning (DHP) algorithms have been widely used to find association rules from various kinds of transaction databases (Huang, Chen, Wang, & Chen, 2000).

The information filtering methods are classified into CBF approach and CF approach (Adomavicius & Tuzhilin, 2005). The CBF approach is a method of analyzing the contents of the items and/or user profiles and recommending items that are similar to those of previously preferred by a particular user (Lu, Wu, Mao, Wang, & Zhang, 2015). In order to analyze the content of the items, many CBF approaches focus on extracting a set of features from textual information utilizing text mining techniques such as term frequency-inverse document frequency (TF-IDF) measure or semantic analysis (Adomavicius & Tuzhilin, 2005). The user profile is used to predict the users’ preferences even if their past purchase/rating history or other users’ item evaluation scores do not exist (Isinkaye, Folajimi, & Ojokoh, 2015). In the CBF approaches, two techniques have been used to generate recommendations. One technique utilizes traditional information retrieval methods, such as cosine similarity measure, to heuristically generate recommendations. The other technique utilizes machine learning methods to build a model that learns users’ interests from the training dataset of users followed by recommendations generation (Pazzani & Billsus, 1997).

The CF approach predicts users’ preferences on items based on user-to-user or item-to-item similarity from the basic assumption that customers with similar preferences for a particular item will have similar preferences for other items. In other words, the CF approach is a method to select other users with the similar preferences as target customers and recommend their preferred items to the target customers. Since Goldberg et al. (Goldberg, Nichols, Oki, & Terry, 1992) introduced this concept for the first time, there have been numerous applications over the past decades in academia and industries (Bobadilla, Ortega, Hernando, & Gutierrez, 2013). The algorithms used for the CF can also be divided into memory-based and model-based techniques. In the memory-based technique, recommendations are generated through a heuristic way by performing similarity measurements and preference predictions. In the model-based technique, machine learning algorithms such as classification, clustering, and dimension reduction approaches are utilized to build a recommendation model (Hofmann, 2004, Lu et al., 2015).

However, the CBF approach has problems with limited content analyses and overspecialization (Adomavicius & Tuzhilin, 2005). The CF approach also has challenges with cold-start, sparsity, and scalability of data (Isinkaye et al., 2015). In order to address these issues, many hybrid recommender systems have been developed that integrate different approaches to produce high quality recommendations (Al Mamunur Rashid et al., 2006, Barragans-Martinez et al., 2010, Burke, 2002, McNee et al., 2006). When constructing a hybrid recommender system, a variety of combination techniques are used, such as weighted averaging of each algorithm's recommendation scores (Burke, 2002), combining recommendation rankings for each algorithm (Pazzani, 1999), applying the results of the CBF approach into the CF approach or vice versa (Adomavicius and Tuzhilin, 2005, Paulson and Tzanavari, 2003), and selecting the most appropriate recommendation engine in real-time by recognizing the current situation from several already learned recommendation engines (Ducheneaut et al., 2009). In this study, we have developed a hybrid model to recommend and/or predict drug groups suitable for development by individual pharmaceutical companies, by adapting the principles of recommender system and combining the approaches of association rule learning, CBF, and CF.

## Section: Methods › Data collection and refinement

The data on the drugs marketed over the last three years by pharmaceutical company was obtained from IQVIATM Pipeline Intelligence. In order to reflect the latest product development trends, the data collection period was constrained to the last three years (from May 2017 to April 2020). Information such as product name, drug class code, indication, mode of administration (MoA), and developing company was included in the collected data. The main training dataset in the form of the company-drug counting matrix, consisting of the number of marketed drugs by pharmaceutical company and drug class, was prepared from this raw data for all approaches in this study. In addition, the data on the market sizes of the drugs was obtained from IQVIATM therapeutic class profiles and calculated based on the second level Anatomical Classification (AC) of drug class (EphMRA/Intellus Classification Committee, 2019).

The data regarding the pharmaceutical companies for which the drug information was collected as described above were obtained from Standard & Poors Capital IQ. Basic information about the companies such as country/region of incorporation, year founded, and number of employees and financial information such as market capitalization, total revenue, and R&D expense (a total of 27 variables) were acquired and utilized for machine learning in the CBF approach. Given that the information on the drugs covered the last three years, we chose to use company data for 2017 to reflect the time-lag effect.

## Section: Methods › Association rule learning

Association rule learning was performed based on the main dataset on the number of marketed drugs by company and drug class. Association rule learning can find interesting patterns or rules in the relationship between item sets in large transactional data (Agrawal et al., 1993, Özseyhan et al., 2012). Our experiment employed the Apriori algorithm, which is the most widely utilized algorithm for investigating association rules (Agarwal & Srikant, 1994). In order to discover significant rules latent in the dataset, the three metrics of support, confidence, and lift of the rules were measured by the following formula (Hornik et al., 2005, Mining, 2006) and their minimum thresholds were applied:.(1)supportX=frequencyXN (2)confidenceX→Y=supp(X∪Y)supp(X) (3)liftX→Y=supp(X∪Y)supp(X)×supp(Y)

The original definitions were modified as follows: N denotes the total number of pharmaceutical companies (drug developers) in the dataset and frequency(X) denotes the number of companies that include drug class X in their product portfolio. Likewise, support(X ∪ Y) denotes the proportion of companies containing drug class X and drug class Y simultaneously in their product portfolio. As a result of applying minimum threshold criteria of 0.03 for support and 0.8 for confidence, 1,834 association rules were discovered for drug development.

## Section: Methods › CF modeling

The main dataset on the number of marketed drugs by company and drug class was adjusted for the CF approach. Any number of marketed drugs above five was converged to five to compensate for problems that may be caused by a large deviation of the number of the marketed drugs by pharmaceutical company. In addition, the data on companies possessing less than four drug classes were filtered out to ensure there would not be any companies that do not have items to test when evaluating the CF model.

The CF modeling was performed using this modified dataset by employing different algorithms of user-based collaborative filtering (UBCF), item-based collaborative filtering (IBCF), singular value decomposition (SVD), and funk singular value decomposition (SVDF). In the UBCF and IBCF algorithms, cosine similarity was used when calculating the similarity between users or items. The performance of each algorithm was compared to select the best algorithm for the CF model. First, the accuracy of the algorithms was assessed by root mean square errors (RMSE) and mean absolute error (MAE) between the actual number of drug developments and the predicted number of drug developments by the CF model. Secondly, we converted the subject into a binary classification problem of development (or not) and evaluated the performance of the algorithms using the receiver operating characteristic (ROC) curve.

## Section: Methods › CBF modeling

For the CBF model generation, feature selection was preceded in order to identify an optimal set of predictive variables and avoid over-fitting of the data. The filter method that examines the statistical validity of the features and a wrapper method, which selects variables by repeating the task of performing modeling using a part of the variables and checking the results, were applied for the feature selection.

In the filter method, the variance of each feature was checked and the features with variances close to zero were removed because this indicates they rarely have different observations. In our variables on the dataset, the “perrectum” and “sublingual” modes of drug administration and the “depreciation and amortization” and the “selling and marketing expense” of a company showed variances close to zero. Therefore, these four variables were removed. Next, the correlations between the variables were examined to remove the variables with high correlation coefficients. This is because when there are highly correlated variables in the variables set, the performance of the machine learning model may deteriorate or the model may become unstable (Kuhn, 2008). Among the variables with a correlation coefficient of 0.6 or higher, the following four variables were excluded, except for total revenue and R&D expense, in consideration of representativeness: total enterprise value, gross profit, EBITA, and number of total investments and subsidiaries of a company.

In the wrapper method, the Boruta algorithm, which is a feature ranking and selection algorithm, was applied. The concept of the Boruta algorithm is to remove variables that do not affect a model more significantly than the shadow features obtained by shuffling the values of the original attribute across objects (Kursa & Rudnicki, 2010). “Company status” was a variable that was found to be unimportant through the Boruta algorithm. Therefore, after removing this variable last, a total of 31 variables were applied for the CBF modeling (Table 2 and Table S1 and S2 in Supplementary material).

The main dataset of company-drug counting matrix was expanded by adding company profiles and drug features chosen from the feature selection process. The missing values in the company profiles were imputed by the median values according to the classification of country/region of incorporation. The number of marketed drugs by class code and company was converted into a binary class (0 and 1) and used as a dependent variable indicating the success of drug development for the supervised learning classification in the CBF model. Since the deviation between the frequency of two classes was large, they were balanced by the up-sampling method (Van Hulse, Khoshgoftaar, & Napolitano, 2007).

The classification algorithms of decision tree, random forest, support vector machine (SVM), and k-nearest neighbors (kNN) were applied for the CBF modeling. The hyperparameters for each algorithm were optimized using the caret package in R. The CBF model performance was evaluated by 5-fold cross validation and by using the metrics of accuracy, sensitivity, specificity, and area under curve (AUC). The importance of the variables was investigated by mean decrease in accuracy and the Gini index for the features from the random forest-based CBF model.

## Section: Methods › DDR model construction

The DDR model was constructed by incorporating the results of association rule learning, CF, and CBF approaches. It was designed to ensure that recommendation scores were derived for all drug classes of all pharmaceutical companies used for training in this model.

Specifically, regarding association rule learning, the drug classes in the consequents (right hand side; RHS) of the generated rules are recommended when the drug classes in a particular company’s product portfolio are included in the antecedents (left hand side; LHS) of the rules. The lift values of the generated rules are used as a recommendation score. As for the CF approach, the results from utilizing the SVDF algorithm were applied to the DDR model. The predicted counting values were obtained for the drug classes that had not yet been developed by each company, and the actual values were returned for drug classes that had already been developed. For the CBF approach, the results of employing random forest algorithm were applied to the DDR model. The probability values for the success of development obtained for each drug class for each company were used as a recommendation score.

These different recommendation scores were incorporated in the DDR model using a weighted linear combination method. The scores obtained from each approach were normalized since they used different scales when generating recommendations. The total score (S) was calculated using the following formula:.(4)Sj,k=∑i∈R,j∈C,k∈Dwiri,j,k-ri,minri,max-ri,min

Where w i is a weight proportion of the recommendation approach i such that ∑wi=1, r i,j,k is the recommendation score of company j’s drug class k in the recommendation approach i, r i,max and ri,min are the maximum and minimum values of the recommendation score in the recommendation approach i, respectively, R is the set of all recommendation approaches (association rule learning, CF and CBF), C is the set of all pharmaceutical companies, and D is the set of all drug classes. The priority of the drug recommendation is derived based on S within a particular company.

## Section: Methods › Implementation

The DDR model was developed under R version 4.0.2. and relies on the following packages: arules, arulesViz, Recommenderlab, caret, Boruta, and randomForest. The custom code created in this study is available upon reasonable request.

## Section: Results

The framework of the DDR model for new drug development planning. The model consists of three main parts: data input, model building, and output of recommendation/prediction. The data on drug development portfolios by pharmaceutical company, company profiles, and drug features are entered to build the DDR model. Individual models of associate rule learning, CF, and CBF are constructed in the DDR model and the recommendation scores of each model are incorporated by weighted linear combination. The DDR model outputs the recommendations for enterprise-specific drug development and the predictions of companies with high probability of success in the development of a particular drug.

Summary statistics for the input dataset of the DDR model (Summary of the company-drug counting matrix).

Summary of the predictor variables of drug features and company profiles.

Summary statistics for the discovered 1,834 association rules on drug development. The length of rules indicates the number of drug classes included in the discovered rules.

(a) Confidence-support plot on the generated 1,834 association rules on drug development. The confidence and support values of each generated rule are shown as a scatter plot. (b) A grouped matrix with antecedent groups (LHS) as columns and consequents (RHS) as rows on the top 20 association rules based on the lift value of the generated rules. The lift value decreases from top to down and from left to right (i.e., the color of the bubble varies from red to grey in descending order.).

Comparison of the accuracy of the algorithms applied in the CF approach using the metrics of RMSE and MAE.

Comparison of the ROC curve of the algorithms applied in the CF approach. The number from 1 to 20 indicates the number of recommended items (drug classes).

Comparison of the evaluation metrics of accuracy, sensitivity, specificity, and AUC of the algorithms applied in the CBF approach.

(a) The ROC curve for the random forest-based CBF model. (b) The variable importance on the success of drug development obtained from the random forest-based CBF model.

Scaled heatmap depicting the results of recommendations by pharmaceutical company and drug class generated from the DDR model. This map shows that the priorities of the drug classes recommended for development are different for individual companies. The x-axis indicates drug class and the y-axis indicates the company. The company names are indicated anonymously. The color of each cell presents the normalized total recommendation scores (S) obtained from the DDR model.

Comparison of the degree of advancement in the clinical trial phase with the prediction scores (S) obtained from the DDR model. The CBF approach was weighted 100% to generate the DDR model in this case. The ‘Phase advanced’ of zero indicates cases with no progress in the clinical trial phase during the analysis period. Likewise, ‘Phase advanced’ of 3 indicates that there have been three phases of progress in the clinical trial, such as from preclinical to phase 2.

## Section: Results › A framework of the DDR model and summary of input data

An overview of the DDR model is schematically illustrated in Fig. 1 . First, the data on successfully developed (i.e., marketed) drugs classified by company was collected as the main dataset for learning in the DDR model. In addition, the data on company profiles and drug features are also collected and learned. In the DDR model, associate rule learning, CF, and CBF approaches, which are some of the most fundamental and widely utilized algorithms for recommender systems, are adopted and modeled to generate recommendations and predictions. The recommendation scores obtained through the three approaches are incorporated as a hybrid model in order to compensate for the limitations of individual algorithms and improve the quality of the recommendations. Finally, the DDR model outputs the recommendation of the drug classes suitable for development for each company and/or the prediction of the companies with high probability of success for each drug class.Fig. 1The framework of the DDR model for new drug development planning. The model consists of three main parts: data input, model building, and output of recommendation/prediction. The data on drug development portfolios by pharmaceutical company, company profiles, and drug features are entered to build the DDR model. Individual models of associate rule learning, CF, and CBF are constructed in the DDR model and the recommendation scores of each model are incorporated by weighted linear combination. The DDR model outputs the recommendations for enterprise-specific drug development and the predictions of companies with high probability of success in the development of a particular drug.

As for input data entered in the DDR model, the main dataset consists of information about the number of drugs marketed during the last three years classified by pharmaceutical company and by drug class (Fig. 1 and Table 1 ). The classes of drugs were in conformity with the AC of pharmaceutical products established by the European Pharmaceutical Market Research Association (EphMRA). In the AC system, drugs are classified according to anatomical site of action, their indications, therapeutic use, composition, and mode of action and hierarchically organized into four levels (EphMRA, 2020). The first level indicates anatomical main group (e.g., C: cardiovascular system) and the second level identifies therapeutic main group (e.g., C10: lipid-regulating/anti-atheroma preparations). For all the experiments in this study, we constructed the dataset categorized in the second level of the AC code.Table 1Summary statistics for the input dataset of the DDR model (Summary of the company-drug counting matrix).Number of pharmaceutical companiesNumber of drug classesNumber of drug classes by pharmaceutical companyaMean (SD)Median (IQR)Min.Max.957773.655 (5.121)2 (3)142aMultiple counting was allowed if a single drug corresponds to multiple drug class codes and if several companies are involved in the development of a single drug.

The number of pharmaceutical companies and drug classes included in the dataset were 957 and 77, respectively (Table 1). It was found that the number of drug classes marketed by pharmaceutical companies ranged from one to forty-two, with an average of 3.66 classes. In addition, the other dataset consisting of company profiles and drug features was also entered in the DDR model, particularly for CBF in the model (Fig. 1 and Table 2 ). The drugs included in the dataset had single or multiple administration modes and there was originally a total of 12 administration types. Through the feature selection process, the “perrectum” and “sublingual” types were found to be non-informative, so they were not used as predictor variables. The market size of the drug classes was found to have a value between 69 million USD and 98,331 million USD. A summary of 20 characteristics on the pharmaceutical companies with marketed drugs is listed in detail in Table 2 and Table S1 and S2 in Supplementary material.Table 2Summary of the predictor variables of drug features and company profiles.CategoryVariablesTypeDescriptive statisticsUnitMeanMedianMin.Max.NaDrug featuresMode of AdministrationMulti-labelBuccal, implant, inhalation, injection, intranasal, lingual, oral, topical, transdermal, vaginalMarket size of drug classbContinuousMillion USD10,7304,5276998,33177Company profilescCountry/Region of IncorporationMulti-label34 countriesd367Company TypeMulti-labelAssets/Products, Government Institution, Private Company, Public Company, Public Investment Firm386Stock ExchangedMulti-label40 exchangesd275Number of marketed drugsContinuousea52170957Number of EmployeesContinuousperson5,5494404132,200359Year FoundedContinuousyear1975199216782018347Market CapitalizationContinuousMillion USD11,8098354344,850280Total RevenueContinuousMillion USD2,2311330.0372,209369Total EquityContinuousMillion USD2,294162−1,80570,109369R&D ExpenseContinuousMillion USD37926010,944369Total LiabilitiesContinuousMillion USD3,0821320.3194,586362Return on AssetsContinuous%−52−21664350Return on EquityContinuous%−395−2,550126334Gross MarginContinuous%5364−276184341Earnings from Cont. Ops. MarginContinuous%−176−282389297Total Revenues 1 Yr GrowthContinuous%5308−9971,068335Total Debt/ EquityContinuous%1083804,063246Total Asset TurnoverContinuous–0.5300.4620.0013.650358Current RatioContinuous–4.2232.6250.13939.900360Number of Total Professionals ProfiledContinuousperson35271192345aOut of a total of 957 companies, companies for which information was not available were not included in the summary statistics.bMarket size is based on the global market in 2018.cCompany profiles are based on the values for 2017.dThe countries and stock exchanges included in the dataset are described in Table S1 and S2 in Supplementary material.

The framework of the DDR model for new drug development planning. The model consists of three main parts: data input, model building, and output of recommendation/prediction. The data on drug development portfolios by pharmaceutical company, company profiles, and drug features are entered to build the DDR model. Individual models of associate rule learning, CF, and CBF are constructed in the DDR model and the recommendation scores of each model are incorporated by weighted linear combination. The DDR model outputs the recommendations for enterprise-specific drug development and the predictions of companies with high probability of success in the development of a particular drug.

Summary statistics for the input dataset of the DDR model (Summary of the company-drug counting matrix).

Summary of the predictor variables of drug features and company profiles.

## Section: Results › Discovering association rules on drug development

The components of ‘transactions’ and ‘items’ in the general association rule mining approach were substituted as ‘drug developments’ of pharmaceutical companies and ‘drug classes’, respectively in the DDR model. It was observed that the highest number of developed drugs over the last three years were in the V7 class (all other non-therapeutic products, 8.15%), L1 class (antineoplastics, 6.15%), N7 class (other CNS (central nervous system) drugs, 4.28%), L4 class (immunosuppressants, 3.77%), and M1 class (anti-inflammatory and anti-rheumatic products, 3.14%).

For 613 pharmaceutical companies, excluding the companies with only one marketed drug, 1,834 association rules were generated on drug development, by applying 0.03 for the minimum support threshold and 0.8 for the minimum confidence threshold (Table 3 and Fig. 2 ). Out of 1,834 rules, the largest share were rules related to the L4 class (immunosuppressants), followed by the L1 class (antineoplastics) and the M1 class (anti-inflammatory and anti-rheumatic products). It can be interpreted that since these are drug groups for cancers or infectious diseases that are major diseases, recording high incidence and prevalence, pharmaceutical companies have developed many drugs related to these diseases, and accordingly, many rules for them have been discovered.Table 3Summary statistics for the discovered 1,834 association rules on drug development. The length of rules indicates the number of drug classes included in the discovered rules.Length of rulesSupportConfidenceLiftMean4.5100.0360.9065.002Median4.0000.0330.9095.151Min.2.0000.0310.8001.908Max.7.0000.0901.00011.584Fig. 2(a) Confidence-support plot on the generated 1,834 association rules on drug development. The confidence and support values of each generated rule are shown as a scatter plot. (b) A grouped matrix with antecedent groups (LHS) as columns and consequents (RHS) as rows on the top 20 association rules based on the lift value of the generated rules. The lift value decreases from top to down and from left to right (i.e., the color of the bubble varies from red to grey in descending order.).

The mean values of support, confidence, and lift were 0.036, 0.906, and 5.002, respectively, suggesting that strong association rules were identified (Table 3). The rules were derived from the combinations of two to seven drug classes, as shown in the length of rules in Table 3. The top twenty association rules based on the lift value are shown in Fig. 2b. The rules where the L2 (cytostatic hormone therapy), N5 (psycholeptics), N6 (psychoanaleptics excluding anti-obesity preparations), and R3 (anti-asthma and COPD (chronic obstructive pulmonary disease) products) classes came out as the consequents (RHS) were found to have high lift values. In particular, the lift value of the rules was highest for [H1 class (pituitary and hypothalamic hormones)] → [L2 class (cytostatic hormone therapy)] (i.e., if the H1 class is developed, then the L2 class is also developed.). It is assumed to be due to high similarity of both classes as hormonal drugs.

Recommendations are generated based on the discovered association rules in the following manner: if the drug development portfolio of a particular company is subordinated to the antecedents (LHS) of the generated rules, the drug classes in the consequents (RHS) of the rules are recommended to the company. The prioritization of the recommendations follows the order of the lift values of the corresponding rules. For 26.3% of the total of 957 companies, the recommendations were generated because their drug portfolios were included in the antecedents of 1,834 discovered association rules.

Summary statistics for the discovered 1,834 association rules on drug development. The length of rules indicates the number of drug classes included in the discovered rules.

(a) Confidence-support plot on the generated 1,834 association rules on drug development. The confidence and support values of each generated rule are shown as a scatter plot. (b) A grouped matrix with antecedent groups (LHS) as columns and consequents (RHS) as rows on the top 20 association rules based on the lift value of the generated rules. The lift value decreases from top to down and from left to right (i.e., the color of the bubble varies from red to grey in descending order.).

## Section: Results › CF modeling and its performance

CF modeling was conducted based on the ‘company-drug counting matrix’ consisting of the number of developed (marketed) drugs by pharmaceutical company and by drug class, which replaced the ‘user-item rating matrix’ commonly used in CF approaches. We trained the data from the companies with at least four of the developed drug classes for the CF modeling in this study (They accounted for 26.2% of the main dataset). The histogram showing the frequency of the number of developed drugs per drug class of a company is presented in Fig. S1 in Supplementary material. The cases with the greatest frequency were the cases with one developed drug per class. Recommendations were generated for individual companies through CF modeling. The company’s cases that have five or more developed drugs per class were adjusted to converge to five before CF modeling, in order to prevent the drug classes with high frequency from always being high ranked in recommendation regardless of company.

We evaluated the performance of the CF model by 5-fold cross validation with 80% of the training data and 20% of the test data. In the evaluation process, the performance of the CF model utilizing UBCF, IBCF, SVD, and SVDF algorithms were compared with that of random-manner recommendation.

In the case of generating ten items recommendation, it was observed that the values of the evaluation metrics, RMSE and MAE, of all algorithms except for IBCF were lower than those of random recommendation (Table 4 ). The SVDF algorithm showed the lowest value for RMSE, and the UBCF algorithm showed the lowest value for MAE. In addition, the ROC curves for each algorithm were drawn and compared to select the best algorithm, by converting the question to a binary classification problem (Fig. 3 ). That is, we considered the problem as having the purpose of classifying the drugs by recommendation/non-recommendation and development/non-development. In the case of generating 1 to 20 recommendations, the SVDF algorithm showed the largest value of the AUC, compared to the AUCs obtained from all algorithms. Therefore, the SVDF was chosen as a representative algorithm of the CF approach to be applied to final DDR model.Table 4Comparison of the accuracy of the algorithms applied in the CF approach using the metrics of RMSE and MAE.RMSEMAEUBCF0.9630.739IBCF1.2100.928SVD0.9620.777SVDF0.9370.781Random1.2040.918Fig. 3Comparison of the ROC curve of the algorithms applied in the CF approach. The number from 1 to 20 indicates the number of recommended items (drug classes).

Comparison of the accuracy of the algorithms applied in the CF approach using the metrics of RMSE and MAE.

Comparison of the ROC curve of the algorithms applied in the CF approach. The number from 1 to 20 indicates the number of recommended items (drug classes).

## Section: Results › CBF modeling and its performance

A supervised machine learning algorithm was applied to predict the possibility of development success for each drug class by company, based on a total of 31 variables including drug development portfolios, company profiles, and drug features (refer to Table 2 and Table S1 and S2 in Supplementary material). The CBF modeling was performed by applying various types of classification algorithms, namely decision tree, random forest, SVM, and kNN, to select the optimal algorithm with the strongest performance. The prediction scores on development success were computed by the CBF model for all drug classes that had not yet been developed by the companies included in the input dataset, and the recommendations were generated in the order of high prediction scores.

The evaluation of the CBF model applying each algorithm was performed by 5-fold cross validation and the performances for the test dataset were compared using the metrics of accuracy, sensitivity, specificity, and AUC. The random forest algorithm showed the best performance among them when considering the evaluation metrics comprehensively (Table 5 ), and therefore it was adopted as a representative algorithm of the CBF approach for application to the final DDR model. In the ROC curve of the random forest classifier, the AUC was 0.74, indicating it to be capable of properly classifying the development success of drug class (Fig. 4 a).Table 5Comparison of the evaluation metrics of accuracy, sensitivity, specificity, and AUC of the algorithms applied in the CBF approach.ClassifierAccuracySensitivitySpecificityAUCDecision tree0.6530.7980.6450.721Random forest0.7750.7080.7790.744SVM0.8260.6250.8380.731kNN0.7420.6170.7490.683Fig. 4(a) The ROC curve for the random forest-based CBF model. (b) The variable importance on the success of drug development obtained from the random forest-based CBF model.

In addition, the importance of predictor variables was investigated by finding the mean decrease in accuracy and node impurity (Gini index) for the features (Gromping, 2009) from the random forest-based CBF model. It was found that the total number of marketed drugs of a company, whether the drug administration modes are oral and injection, and the market size of the drug class are the most important predictors for drug development success (Fig. 4b).

Comparison of the evaluation metrics of accuracy, sensitivity, specificity, and AUC of the algorithms applied in the CBF approach.

(a) The ROC curve for the random forest-based CBF model. (b) The variable importance on the success of drug development obtained from the random forest-based CBF model.

## Section: Results › DDR model building and its empirical validation

The DDR model was established by combining three individual approaches. The recommendation scores derived from each approach were normalized and summed with weighted combination ratios. Fig. 5 shows a part of the results of recommending drug classes for development tailored to an individual company, based on the DDR model incorporating each approach’s scores with an equal weight combination ratio. The x-axis and y-axis in Fig. 5 indicate drug class and pharmaceutical company, respectively (The company names were filled anonymously). It was observed that the priorities of the drug classes recommended for development were obtained differently for each company, as shown by the color variation in the heatmap. Specifically, in the cases of companies with a drug development portfolio that satisfied the discovered association rules and companies that obtained recommendation scores from the CF approach due to having more than four developed drug classes, the absolute value of the DDR model's total score (S) was relatively high. However, the absolute S value does not affect the recommendation for a particular company, because it is based on the ranking of the S within that company. In addition, the CBF approach generates predictions for all companies in the dataset, so it is possible to generate recommendations for all companies using the DDR model.Fig. 5Scaled heatmap depicting the results of recommendations by pharmaceutical company and drug class generated from the DDR model. This map shows that the priorities of the drug classes recommended for development are different for individual companies. The x-axis indicates drug class and the y-axis indicates the company. The company names are indicated anonymously. The color of each cell presents the normalized total recommendation scores (S) obtained from the DDR model.

The empirical validation was conducted to assess the reliability and utility of the DDR model. The DDR model not only enables personalized recommendations, but also predicts the success probability of development by company for a specific drug class. As an exemplary test, the success likelihood of COVID-19 vaccine development was predicted using the DDR model, because it is one of the drugs that is most urgently in need of development due to the unprecedented, ongoing global pandemic. Since only a few companies have successfully developed COVID-19 vaccines up to now, we compared the progress of the clinical trials on the vaccines between the time when the data was first acquired for this study (end of April 2020) and the time of manuscript writing (end of November 2020) to the scores predicted by the DDR model. The advancement of clinical trial phases is considered to be a prerequisite for drug development success. In the DDR model, the prediction scores were obtained solely through the CBF approach (i.e., the CBF model received all the weights.) to predict accurate values of success probability.

Based on the pipeline data on the development of COVID-19 vaccines (i.e., the drugs belonging to the J7 class (vaccines) and tagging COVID-19 as an indication), we compared the degree of advancement in the clinical trial phase by company and the prediction scores obtained from the DDR model. As shown in Table 6 , the more advanced the clinical trial phase, the higher the score predicted by the DDR model. Remarkably, Pfizer and Moderna, the two companies that have succeeded in developing the vaccine to date, respectively ranked 1st (0.92 of the prediction score) and 5th (0.79 of the prediction score) in the DDR model. In the case of AstraZeneca, the other company that has successfully developed a COVID-19 vaccine, the vaccine development information was not available in the dataset collected in April 2020, so it could not be included in the comparative analysis with clinical trial phase advancement. However, AstraZeneca had the highest value (0.92) of prediction score for the J7 class of the DDR model, same as that of Pfizer. This empirical analysis demonstrates the validity of the DDR model.Table 6Comparison of the degree of advancement in the clinical trial phase with the prediction scores (S) obtained from the DDR model. The CBF approach was weighted 100% to generate the DDR model in this case. The ‘Phase advanced’ of zero indicates cases with no progress in the clinical trial phase during the analysis period. Likewise, ‘Phase advanced’ of 3 indicates that there have been three phases of progress in the clinical trial, such as from preclinical to phase 2.Phase advancedPrediction score (mean)Number of companies00.0294110.1592320.1881430.4118

Scaled heatmap depicting the results of recommendations by pharmaceutical company and drug class generated from the DDR model. This map shows that the priorities of the drug classes recommended for development are different for individual companies. The x-axis indicates drug class and the y-axis indicates the company. The company names are indicated anonymously. The color of each cell presents the normalized total recommendation scores (S) obtained from the DDR model.

Comparison of the degree of advancement in the clinical trial phase with the prediction scores (S) obtained from the DDR model. The CBF approach was weighted 100% to generate the DDR model in this case. The ‘Phase advanced’ of zero indicates cases with no progress in the clinical trial phase during the analysis period. Likewise, ‘Phase advanced’ of 3 indicates that there have been three phases of progress in the clinical trial, such as from preclinical to phase 2.

## Section: Discussion

Despite astronomical and unparalleled R&D investment, the pharmaceutical industry has continued to struggle with low R&D productivity and low success rates in new drug development (Jung et al., 2020, Khanna, 2012, Thakor et al., 2017). Consequently, pharmaceutical companies are facing serious challenges to their business models (Paul et al., 2010). The composite success rate for drugs, which indicates the success of products from clinical phase 1 to the regulatory decision for marketing, has declined in recent years, with an average success rate of 12.9% over the past decade (IQVIA Institute, 2020). In this regard, a rational and data-driven decision-support system is needed to help the companies determine the drugs with high potential for success as their next development goals, tailored to their individual circumstances, in order to reduce risks and maximize profits from the development.

In this study, we developed a decision-support system, named the DDR model, that can effectively guide pharmaceutical companies' new drug development planning by leveraging machine learning. Machine learning algorithms such as supervised/unsupervised learning methods have been widely applied in various fields, but they have rarely been utilized in business decisions on drug development, notwithstanding a large amount of data being produced every day regarding drug development pipelines and activities. The DDR model was constructed by incorporating association rule learning, SVDF-based CF, and the random forest-based CBF model, taking advantage of machine learning algorithms. It has been implemented utilizing the information on recent drug development activities of pharmaceutical companies around the world over the last three years, the developing company’s profiles, and the drug’s properties. In addition, the validity and utility of the DDR model were demonstrated by predicting the success probability of a company developing COVID-19 vaccines.

In the CF approach, recommendations could not be generated for companies with little experience in drug development. This problem is caused by the sparsity of data; the insufficient number of drug classes developed by each company (sparsity of 95.3%). In addition, the IBCF method’s performance was the worst among the tested algorithms. This might be because the number of drug classes, 77 in total, was not enough to generate correct recommendations in the evaluation stage. Meanwhile, the SVDF method showed the best performance. SVD is a matrix factorization technique designed to reduce the dimension of data by decomposing the data matrix into smaller ones (Sarwar, Karypis, Konstan, & Riedl, 2000b). It is known that the SVD method improves the performance of the CF approach by overcoming the sparsity problem of the user-item rating matrix (Sarwar et al., 2000a, Sarwar et al., 2000b). We employed a SVDF method popularized by Simon Funk, which decomposes a matrix by stochastic gradient descent optimization to minimize errors in the known values (Koren, Bell, & Volinsky, 2009).

As for the CBF approach, its performance was superior even as a single model and there was no significant difference in performance depending on the tested classification algorithms (Table 5). These results prove that our proposal of adapting a principle of recommender system to drug development planning is reliable and the model has been built successfully. In addition, the CBF approach has an advantage over association rule learning or the CF approach because it can generate prediction scores followed by recommendations for all drug classes in any company, regardless of past drug development experiences or portfolio composition of drug classes.

We also identified from the CBF model that the total number of drugs developed by the company and the company’s financial status, including factors such as total liabilities, total equity, and revenues are the major factors affecting the success of drug development. The duration of business operation and the number of employees were also important variables. This is consistent with the findings in previous studies in other industries that a company's product development experiences and/or the size and history of a company significantly influence new product development success (Ernst, 2002, Murphy and Kumar, 1996). More specifically, in the previous study on the prediction of the clinical approval of drugs, it was found that firms with larger sales had a higher rate of regulatory approval of oncology compounds than firms with lower sales (DiMasi et al., 2015). However, the financial conditions of a company have been rarely explored in detail, so by including these variables in this study, the factors in the financial management aspects of a company that can predict the success of drug development were identified.

In terms of drug features, the type of administration (oral, injection, and topical) was found to be an important factor and the market size of the drug class was also an important explanatory variable. It is in line with the finding of DiMasi et al. that oral and injectable modes of administration were associated with the clinical approval of new cancer drugs (DiMasi et al., 2015). Orally administered drugs (32.7%) showed a higher probability of clinical trial success than the injectable drugs (10.2%) in the authors' study. Regarding the market size, previous studies focusing on other industries have already revealed that the market size of products is one of the key factors in R&D success (Astebro, 2003, Balachandra and Friar, 1997). We also found in this study that market size is a major factor affecting the success of new drug development in the pharmaceutical industry. The CBF model showed a comparable performance with the existing models, even though it did not use the conditions for clinical trials or disease characteristics as predictor variables.

It may be concerned that the results of the CBF model only made an obvious prediction that companies which completed a lot of drug developments in the past would perform well in the future. However, we found other significant predictors, as well as the number of marketed drugs, regarding drug features and company profiles. For example, in order to increase the success rate of drug development, companies can strategically choose the drug’s administration type to be an oral or injection type, and intentionally focus on the development of the drugs with a large market size. It can also be inferred from the results that managing a company's total debt will be more beneficial to its drug development success. Importantly, the DDR model does not only predict the success probability of a drug by using these variables (in the CBF model), but it also finds the rules for drug development from the drug development portfolios of pharmaceutical companies across the world (in the association rule mining). Also, by calculating the similarity in drug development of pharmaceutical companies, it can provide insights into which of the 77 drug classes would be relatively more advantageous to develop for a specific company (in the CF model).

Since the individual approaches we employed had their pros and cons, they were combined as a hybrid model to reinforce their strengths and compensate for their weaknesses. Three approaches in the DDR model were combined by averaging the normalized recommendation scores of each approach with an identical weight ratio. However, different weights can be applied depending on the business situation of the target company. For instance, for companies that have a relative abundance of experience in drug development, a higher weight ratio is given to the CF approach in the DDR model, and for companies with cold start problems due to the lack of a drug development history, a higher weight ratio is applied to the CBF approach to generate recommendations. In the validation stage of the DDR model, we used the prediction scores obtained solely by the CBF approach to provide an accurate value ​​of each company's success probability for specific drug class development.

## Section: Implications

Considering the high cost and risk of new drug development, a more prudent utilization of the recommendation model is required, compared to product purchases or preferable contents recommendations. In this study, the significant rules and reliable model performances were achieved from each algorithm (association rule learning, CF, and CBF approach) in the DDR model. It implies that the principles of recommendation model can effectively be applied to establish a decision-support model for drug development plans. In addition, a hybrid model combining three algorithms was presented in this study to improve the quality of recommendations. In this regard, this study makes a theoretical contribution in that it suggests a new methodology that can be used in the purpose of product development planning. Furthermore, this study identified the predictors related to financial management of a company that can predict the success of new drug development, which have been hardly addressed in prior research.

From practical (managerial) perspectives, pharmaceutical companies can benefit from the DDR model in making rational decisions about which drug (classes) to develop for the purpose of business planning or portfolio management. It may contribute to reduce the time and cost invested in new drug development of the companies. Furthermore, it provides implications for the government agencies in charge of public health that a data-driven approach as adopted in our model can be used to predict the success probability of drugs under R&D in order to preemptively secure drugs that urgently needed for public health, especially in an emergency situation. Even drugs that have not yet been developed can be purchased in advance by predicting the likelihood of success for the safety of the public. In the wake of COVID-19, the emergence of another new strain of virus is widely predicted, and as the occurrence cycle of such viruses is expected to be shortened, it is essential for the public sector to prepare for the threat of another pandemic.

## Section: Conclusions

To the best of our knowledge, this study devised a novel recommendation/prediction model that can help overcome the challenge that the success rate of drug development has not improved for quite a long time. The DDR model is expected to contribute to cutting down the time and cost required for new drug development in the private sector by suggesting the most developable drug groups, highly customized for individual companies’ circumstances. Furthermore, using the DDR model in the public sector, national investment and support efforts can be strategically strengthened for companies developing drugs that can improve public health, and systems can be put in place to preemptively respond to the sudden emergence of new infectious diseases such as SARS, MERS, and COVID-19, because the DDR model can predict which companies are more likely to succeed in developing particular drugs in urgent need. In this context, the DDR model can be an attractive and essential tool utilized as a decision-support system adaptively in both the private and public sectors.

Since this is just an initial step to showcase the feasibility of our proposed concept, the DDR model has several limitations that require further improvement. First, although this study showed the recommendation/prediction results by the AC second level due to the sparsity of data, it is necessary to specify the level of recommended drugs to provide more practically useful and helpful recommendations for pharmaceutical companies. In addition, although we have tried to include as many variables as possible regarding the success of drug development based on previous studies to derive meaningful implications on the success of drug development, it will be necessary to add more drug-related variables that can distinguish unique properties by drug. Lastly, we plan to further study on how to combine each algorithm more rationally to build a robust hybrid model. We believe subsequent studies and improvements can readily catalyze the DDR model to advance towards the next step in the near future, such as expansion into product development assistance in the bioindustry.

## Section: Conclusions › CRediT authorship contribution statement

Ye Lim Jung: Conceptualization, Data curation, Methodology, Software, Supervision, Validation, Writing – original draft, Funding acquisition. Hyoung Sun Yoo: Data curation, Methodology, Validation, Investigation, Writing – review & editing. JeeNa Hwang: Formal analysis, Investigation, Writing – review & editing.

## Section: Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.


---

# Artificial Intelligence Based on Machine Learning in Pharmacovigilance: A Scoping Review

- **Authors:** Benjamin Kompa, Joe B Hakim, Anil Palepu, Kathryn Grace Kompa, Michael Smith, Paul A Bain, Stephen Woloszynek, Jeffery L Painter, Andrew Bate, Andrew L Beam
- **Issuer:** Drug safety
- **Type:** Scientific article
- **Published:** 2022-05-17
- **Language:** en
- **DOI:** 10.1007/s40264-022-01176-1
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35579812/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractIntroductionArtificial intelligence based on machine learning has made large advancements in many fields of science and medicine but its impact on pharmacovigilance is yet unclear.ObjectiveThe present study conducted a scoping review of the use of artificial intelligence based on machine learning to understand how it is used for pharmacovigilance tasks, characterize differences with other fields, and identify opportunities to improve pharmacovigilance through the use of machine learning.DesignThe PubMed, Embase, Web of Science, and IEEE Xplore databases were searched to identify articles pertaining to the use of machine learning in pharmacovigilance published from the year 2000 to September 2021. After manual screening of 7744 abstracts, a total of 393 papers met the inclusion criteria for further analysis. Extraction of key data on study design, data sources, sample size, and machine learning methodology was performed. Studies with the characteristics of good machine learning practice were defined and manual review focused on identifying studies that fulfilled these criteria and results that showed promise.ResultsThe majority of studies (53%) were focused on detecting safety signals using traditional statistical methods. Of the studies that used more recent machine learning methods, 61% used off-the-shelf techniques with minor modifications. Temporal analysis revealed that newer methods such as deep learning have shown increased use in recent years. We found only 42 studies (10%) that reflect current best practices and trends in machine learning. In the subset of 154 papers that focused on data intake and ingestion, 30 (19%) were found to incorporate the same best practices.ConclusionAdvances from artificial intelligence have yet to fully penetrate pharmacovigilance, although recent studies show signs that this may be changing.Supplementary InformationThe online version contains supplementary material available at 10.1007/s40264-022-01176-1.

## Section: Introduction

Pharmacovigilance (PV) is fundamentally a data-driven field as it requires the collection, management, and analysis of a large amount of data gathered from a wide range of disparate sources [1]. The primary type of data used in PV are individual case safety reports (ICSRs), which are records of suspected adverse events collected via multiple channels, aggregated and organized into large databases, and constantly monitored to detect safety signals [2]. ICSRs come from a multitude of sources, including chatbot interactions, electronic health records (EHRs), published literature, patient registries, patient support programs, or even directly from patients via social media [3]. Reports are collected worldwide and characterized by heterogeneity in format, language, and unique characteristics of the underlying healthcare systems. Adverse events must be identified and analyzed in order to find potential emerging safety issues in medicines and vaccines.

The central challenge of PV is how to make sense of these large and heterogeneous data to quickly and reliably find the ‘needles in the haystack,’ which are safety signals that require escalation and triage [4]. Given the rise of artificial intelligence (AI) powered by new advancements in machine learning (ML) across many fields of science [5–7] and medicine [8–11] over the last decade [12, 13], many have speculated [14, 15] that these same technologies could be brought to bear on the core problems of PV. The use of these methods for human safety data first appeared in the early 1990s [16] and has steadily increased since the 2000s. The goal of this review is to systematically identify works that use ML, broadly defined, for safety data to characterize the current state of ML in PV, and to provide clarity on ways that recent advances in AI and ML can be translated to improve various components of PV.

Care must be taken when attempting to extrapolate the success of ML in other areas compared with PV since there are specific factors that may account for the recent success of ML that may or may not be present for PV applications [15]. More so than any other ML technique, it has been the rise of ‘deep learning’ methods that have catalyzed the current AI revolution [13]. These methods are scalable and can train on petabytes of data through the use of graphical processing units (GPUs) [17] and continue to improve even when the performance of non-deep learning methods has saturated [18, 19]. In addition to scalability, deep learning’s modular nature brings the added benefit of easily incorporating domain-specific knowledge (often called an inductive bias) to point the model in the direction of good or parsimonious solutions [20]. Although image recognition is not commonly a task in the current PV pipeline, deep learning models known as convolutional neural networks (CNNs) offer a particularly salient example of how potent the combination of large data and domain knowledge can be.

CNNs were introduced in 1988 [21] but it was not until 2010 when datasets [22] with millions of images became available that they began to transform the field of computer vision [23, 24]. Moreover, the convolution operator and the network structure (modeled loosely on the visual cortex [25]) in CNNs are powerful image-specific inductive biases that give the deep learning model a head start when learning a new image recognition task. Without either of these components (large data and the inductive bias of convolution), it is unlikely that deep learning would have caused the computer vision revolution of the 2010s. Indeed, numerous studies have found that without large data and inductive biases, deep learning is often no better than traditional statistical models [26–28]. These lessons have been born out repeatedly in subsequent applications of game playing [29, 30], biology [5, 6], natural language processing (NLP) [31, 32], and image generation [33–35].

Taken as a whole, it is thus reasonable to expect that a field is unlikely to experience a true paradigm shift from the current crop of deep learning-powered AI techniques without having at least some of these prerequisites in place. Despite the widespread interest in AI and its application to safety data [36, 37], including several review articles [14, 15], there are no scoping reviews that critically assess the extent to which PV is poised to be improved by AI under this framework. Previous reviews have focused on specific elements such as NLP techniques for clinical narrative mining in EHRs [38] or in reducing the frequency or impact of adverse events to patients [39]. Our review is unique in that it seeks to fill this gap to provide a clearer understanding of how current AI/ML practices and standards in PV align with the critical factors for success identified in adjacent areas such as biology and medicine.

To be as comprehensive as possible, we take a broad definition of ML for safety data and include traditional signal detection methods such as Bayesian Confidence Propagation Neural Networks (BCPNN) and related techniques [40, 41] given their roots in ML (see the Methods section for the full search details). We surveyed a 21-year period from the year 2000 to September 2021, reflective of the time before and after significant AI breakthroughs in 2012–2015 [23, 42–46], to see what effect, if any, these results had on PV. The scope of this review is limited only to (1) ingestion of safety data from all sources, including the safety data pipeline, social media, EHRs, and scientific literature, followed by (2) the processing and structuring of data, as well as (3) the processes of analyzing, understanding, linking, and disseminating or sharing, the safety data. While ML has made advances in healthcare more broadly [47–51] and ML research in these areas does have the potential to impact PV, we sought to characterize the use of ML that directly analyzed safety data (e.g. social media, forums, or ICSRs such as those in the FDA Adverse Event Reporting System [FAERS]) and excluded studies that performed adjacent kinds of tasks (e.g. ML research on biochemical pathways or meta research on drug safety). Thus, for the purposes of this review, we have chosen to retain our focus by limiting the review to those topics related specifically to the application of ML and human safety data (i.e. work that explicitly analyzes data on suspected adverse events of drugs and vaccines) for data ingestion or analysis.

## Section: Methods › Study Design

We queried four databases (PubMed, Embase, Web of Science Core Collection, and IEEE Xplore) for abstracts of full-text research papers containing terms related to ML and PV. The searches were carried out on 9 September 2021 and were limited to articles published in the year 2000 or later. Furthermore, our review was limited to full-text English articles and conference abstracts (non-English papers were excluded). The full list of search terms and the search query used to identify the articles in this review are available as an electronic supplementary file.

We focused our search criteria on ML terms related to disproportionality analysis, common to PV research, as well as modern ML techniques (e.g. deep learning). This allowed us to compare traditional methods of PV alongside cutting-edge ML research. Articles solely focused on rules-based methods or knowledge graph- or ontology-based methods (e.g. Merrill et al. [52, 53]) were excluded from this review since, on their own, these are not direct ML methods per se.

Two independent reviewers determined if an abstract was in the scope of this review. A third reviewer adjudicated conflicts between reviewers or indecision by a reviewer (indicated by a ‘maybe’ vote). For studies that met the inclusion criteria, one reviewer conducted a full-text review to extract data. Analysis of extracted data was performed using the R statistical programming language [54]. Statistical significance for testing for a difference in proportions Chi-square test enabled subgroup analysis of studies that proposed methods for the intake and processing of safety data. This subgroup was enriched for ML models of interest. Topic modeling, described below, enabled an analysis of temporal trends in methods development.

## Section: Methods › Evaluation Criteria

To understand the extent to which PV studies are amenable to current trends in the broader ML literature, we assessed each paper using the following criteria:

## Section: Methods › Topic Modeling

We trained a structural topic model (Latent Dirichlet Allocation [LDA]) using the ‘stm’ R package [55]. In order to process the documents included in our final screen, we preprocessed the text to remove all non-alpha-numeric text and removed references (e.g. ‘[1]’). We then removed punctuation and limited analysis to words between 2 and 20 characters. For each document, we only considered words that appeared at least 10 times in that respective document. After preprocessing by removing stop words and stemming words, we needed to select the number of topics, K, to instantiate the topic model with. We considered a range of 5–45 topics and chose K = 25 based on log-likelihood on held-out data, exclusivity, and semantic coherence. Finally, we fit the topic model using a semi-collapsed variational expectation-maximization algorithm regressed on the year of publication.

## Section: Results

Summary of inclusion and exclusion process. Articles identified in one of the four databases using keyword and MeSH term searches were manually screened for inclusion. MeSH Medical Subject Heading, ML machine learning, PV pharmacovigilance

Summary of datasets, primary algorithms, and task type of the included studies. a Primary dataset used in each study. b Primary analysis method or model used by each study. c Study task classification. EHR electronic health record, FAERS FDA Adverse Event Reporting System, JADER Japanese Adverse Drug Event Report, KAERS Korea Adverse Event Reporting System, VAERS Vaccine Adverse Event Reporting System, WHO World Health Organization, ROR reporting odds ratio, IC information component, BCPNN Bayesian Confidence Propagation Neural Network, LSTM long short-term memory, RNN recurrent neural network, SVM support vector machine, CNN convolutional neural network

Summary statistics for types of data utilized and sample sizes used

Distribution of sample size for the most popular datasets. EHR electronic health record, FAERS FDA Adverse Event Reporting System, KAERS Korea Adverse Event Reporting System, VAERS Vaccine Adverse Event Reporting System

Breakdown of the use of a transfer learning, b methodological novelty, and c popular algorithms for data intake and pre-processing studies. LSTM long short-term memory, RNN recurrent neural network, SVM support vector machine, CNN convolutional neural network, ROR reporting odds ratio

Summary of sample sizes used in intake and processing pipeline studies

Temporal trends in the pharmacovigilance literature. a Total number of publications by year shows an increasing volume of articles that use ML for PV. b The type of task performed by each study. c Trends in usage for several classes of models. ML machine learning, PV pharmacovigilance, SVM support vector machine

Top four topics discovered by LDA by prevalence

Topics on deep learning and critical systems had their relative expected proportions increase

Topics on disproportionality analysis, BCPNN had their relative expected proportions decrease. BCPNN Bayesian Confidence Propagation Neural Network

## Section: Results › Main Results

We manually reviewed 7744 unique abstracts that were identified by searching the PubMed, Embase, Web of Science, and IEEE Xplore databases. After manual screening by at least two reviewers, 672 (8.7%) abstracts passed inspection and had their full-text retrieved (Fig. 1). Of these, 279 (41.5%) did not meet the inclusion criteria due to lack of relevance after reviewing the full text, or did not have the full text available, resulting in 393 articles for analysis. Figure 2 displays summary information for the primary datasets and models in addition to the task classification for each study.

Overall, FAERS was the most popular single database (Fig. 2a) and was used by 24% of the studies. Social media data were used by 12% of studies, while EHR data were used by 11% of studies. Traditional statistical PV methods such as disproportionality scores remain very popular, with 144 (37%) of the included studies using one of them as the primary analysis model. Sample sizes varied greatly across studies and across datasets (Table 1 and Fig. 3), with FAERS being notable for having a mean sample size of 4.3 million and a median sample size of 243,510. Note that the notion of sample size is difficult to compare across data sources since the unit of analysis can be quite different. For example, studies using social media data often reported the number of posts (e.g. Tweets), while EHR studies often reported the number of patients. Ten percent of studies reported no explicit sample size at all.

With respect to method novelty, the vast majority (73%) used ‘off-the-shelf’ methods with little to no problem-specific adaptation or domain knowledge. Method novelty varied with respect to method type; 61% of papers using deep learning or other ML methods had novel adaptations, while only 10% of disproportionality papers did. Similarly, 92% trained a model ‘from scratch’, leaving only 8% of studies that leverage a pretrained model in some capacity, and only 18% explicitly used some kind of external information or data. Six-three percent of the studies used data that were publicly available, while 7% had code that was publicly accessible at some point in time. Our reviewers’ subjective evaluation found that 42 (10%) studies were reflective of modern best practices in ML.

Summary of inclusion and exclusion process. Articles identified in one of the four databases using keyword and MeSH term searches were manually screened for inclusion. MeSH Medical Subject Heading, ML machine learning, PV pharmacovigilance

Summary of datasets, primary algorithms, and task type of the included studies. a Primary dataset used in each study. b Primary analysis method or model used by each study. c Study task classification. EHR electronic health record, FAERS FDA Adverse Event Reporting System, JADER Japanese Adverse Drug Event Report, KAERS Korea Adverse Event Reporting System, VAERS Vaccine Adverse Event Reporting System, WHO World Health Organization, ROR reporting odds ratio, IC information component, BCPNN Bayesian Confidence Propagation Neural Network, LSTM long short-term memory, RNN recurrent neural network, SVM support vector machine, CNN convolutional neural network

Summary statistics for types of data utilized and sample sizes used

Distribution of sample size for the most popular datasets. EHR electronic health record, FAERS FDA Adverse Event Reporting System, KAERS Korea Adverse Event Reporting System, VAERS Vaccine Adverse Event Reporting System

## Section: Results › Subgroup Analysis of Data Intake and Pipeline Studies

We performed a subgroup analysis of studies that proposed methods for the intake and processing of safety data. The use of transfer learning, methodological novelty, and the types of models used are shown in Fig. 4 and the sample size by dataset is shown in Table 2. Compared with all included studies of the previous section, this category had significantly higher levels of methodological innovation and novelty (40% vs. 27%; p = 0.03) and had higher uses of pretrained models (19% vs. 8%; p = 0.03). We found that 30 (20%) of these studies reflect current best practices, higher than the 10% estimate when considering all included papers.

Breakdown of the use of a transfer learning, b methodological novelty, and c popular algorithms for data intake and pre-processing studies. LSTM long short-term memory, RNN recurrent neural network, SVM support vector machine, CNN convolutional neural network, ROR reporting odds ratio

Summary of sample sizes used in intake and processing pipeline studies

## Section: Results › Temporal Trends

Next, we assessed how some of the patterns from the previous sections varied during the study period. Figure 5 shows trends for the number of publications, task type, and model use for each year in the study period. By and large, the volume of ML-related PV publications went up year-over-year (Fig. 5a). Starting in 2015, the number of studies leveraging ML for data intake (Fig. 5b) markedly increased, which coincided with a rapid increase in the number of studies using deep learning (Fig. 5c), and, by 2020, deep learning was the most popular technique used in the included PV studies. These trends suggest that, especially for data intake studies, ML may be starting to gain traction.

Temporal trends in the pharmacovigilance literature. a Total number of publications by year shows an increasing volume of articles that use ML for PV. b The type of task performed by each study. c Trends in usage for several classes of models. ML machine learning, PV pharmacovigilance, SVM support vector machine

## Section: Results › Topic Model Analysis

We then performed a topic model analysis of the full text using Latent Dirichlet Allocation (LDA) [56] to see what high-level trends were present. In Table 3, we show four of the most prevalent topics discovered by LDA along with keywords that identify the topic and our subjective assessment of topic focus. We analyzed topic model results using the ‘stm’ and ‘LDAvis’ packages [55, 57]. Figures 6 and 7 show topics whose expected relative proportion increased and decreased, respectively, during the study period. These results align with those from the manual annotation presented in the previous section. Deep learning has seen relative gains in use recently and is likely to see further increases in coming years.

Top four topics discovered by LDA by prevalence

Topics on deep learning and critical systems had their relative expected proportions increase

Topics on disproportionality analysis, BCPNN had their relative expected proportions decrease. BCPNN Bayesian Confidence Propagation Neural Network

## Section: Discussion

Our scoping review revealed several interesting trends. First and most obvious, traditional signal detection methods in PV (e.g. BCPNN) and data sources remain quite popular and, until very recently, comprised the bulk of signal detection research. That is not to say that the use of these approaches has slowed, but that research development has shifted to other areas of method development. Interest at the intersection of ML and PV is growing; Fig. 5a shows that the number of publications has increased approximately sixfold in the past 10 years alone. Figure 5c indicates that deep learning-based methods have recently eclipsed statistical methods in terms of publication numbers. This may have been enabled by new developments in deep learning for text analysis (e.g. transformers [32]), as initial deep learning progress focused on image recognition and was thus less relevant to PV tasks. Moreover, easy to use frameworks such as Tensorflow and PyTorch have enabled rapid development of ML models. In particular, there has been a rise in the amount of papers focusing on more sophisticated ML techniques. This indicates that the field is shifting towards classification or regression tasks in addition to the more traditional safety signal statistical analyses. Figure 5b shows this fourfold increase in supervised tasks over the last 5 years alone.

In our subgroup analysis of studies that proposed methods for the intake and processing of safety data, we found articles within this category demonstrated higher levels of methodological innovation and novelty (40% vs. 27%; p = 0.03) and made more use of pretrained models (19% vs. 8%; p = 0.03). This could be the result of more freedom to define the task and model when compared with signal detection tasks and the ability to leverage existing pretrained models trained on other types of non-PV text data. Although these crucial ML ingredients were more frequently present in this task, this is lower than what would be expected for other areas where transfer learning is ubiquitous [11, 58].

One limitation of our review is a property of scientific publishing: only novel results are typically published in peer-reviewed journals. For signal detection papers, that means our scoping review has covered both novel methods of signal detection and new drug/adverse event relationships identified by standard methods. In contrast, innovative data intake and analysis methods have been included in our review, but routine use of ML for these parts of PV are missing from the published record. This is partially reflected in our method novelty results; 61% of papers with deep learning or ML made novel changes, while only 10% of disproportionality analyses made novel changes in our reviewers’ estimations. While this bias is unavoidable, we believe that this scoping review likely captures most uses of ML for data ingestion and analysis due to the fact that the rapid rise of ML has been so recent. This bias will affect the ratio between signal detection and other papers, but the conclusions within subgroups should be unaffected.

However, returning to our original framing, it is not yet clear whether PV has assembled the critical mass of ingredients needed to benefit from the recent AI revolution powered primarily by large-scale deep learning methods, although it may be trending in that direction. Figure 3 shows that there is a large amount of human safety data that can serve as fodder for model training. However, most studies are bespoke, one-off exercises that do not introduce methodological novelty beyond what has been published in other areas, and do not use pretrained models or external data despite an increasing use of deep learning methods. In contrast to other areas that have rapid growth and transformation, PV studies still mostly focus on a single task and use a narrow subset of available data, neglecting to use pretrained models or external data. Models that leverage multimodal data (e.g. text and structured data) have been particularly useful in other areas [34, 59, 60]. Another contrast with other areas is the availability of code. Only 7% of PV studies in our review had publicly available code at one point in time (approximately 1% of papers have dead links to code). This is in contrast to 2019 estimates of code availability, where 21% of studies in ML for healthcare more broadly, 39% of computer vision papers, and 48% of NLP papers provided code [61]. Indeed, sharing of code, data, and rapid dissemination of results through preprint servers have accelerated progress in other areas of ML [62–64]. Code-sharing enables others to build on previous work rapidly, which is extremely important when model complexity is high, as can be the case with many complicated deep learning models.

We wish to emphasize that we are not suggesting that PV researchers must follow the deep learning template, nor do we believe that deep learning is the only viable method for PV tasks. However, if PV tasks are to be improved by current approaches based on deep learning, then the criteria of large datasets, the use of pretrained models when appropriate, method novelty, and reproducibility are a reasonable set of requirements. By these criteria, we found that 10% of all studies and 20% of pipeline/intake studies were reflective of current trends based on deep learning. With the increasing use of large datasets and the rise of more modern ML techniques observed in Fig. 5, it is likely safe to project that this percentage will increase over the next several years.

## Section: Discussion › Recommendations

We provide some concrete recommendations that we believe could enhance AI and deep learning applications in PV.

## Section: Discussion › Promising Near-Term Applications of Machine Learning in Pharmacovigilance

While our review found that there is still much room for improvement, we wish to offer some near-term tasks that could benefit from the well-executed use of ML today. We offer suggestions for areas across the PV pipeline [74], where ML may have impact in the near- to medium-term, but note that some of these tasks will likely still require substantial effort to achieve.

## Section: Discussion › Exemplar Studies

In this section, we wish to highlight several studies that were determined to reflect current ideas and trends in ML to provide good exemplars for how future studies might be conducted. Du et al. [88] provide an example of how an accurate adverse event annotation pipeline can be built, even when there are not large amounts of annotated data, using transfer and self-supervised learning. In the investigation, the authors only had a small set of labeled data in the form of 91 annotated VAERS reports, and the goal was to construct an ML system to automatically extract mentions of named entities (e.g. adverse events, procedures, social circumstances, etc.) from the reports. They accomplished this goal by leveraging a pretrained transformer model known as BioBERT [66] that was fine-tuned on an unannotated set of 43,240 VAERS reports. They show that this approach leads to significantly better performance for this task when compared with traditional NLP methods and when compared against deep learning methods that did not employ transfer learning. Additionally, the annotated dataset they created is publicly available so that others may build on their work [93].

Zhang et al. [94] showed how ML can be useful in complex adverse drug reaction recognition tasks. Adverse drug reactions can be found in all types of media, including scientific literature, EHR data, and Tweets. In these settings, the drug and reaction are not necessarily in the same sentence or near each other in text. Typical ML methods rely on local semantic information (e.g. words in a single sentence) and can struggle in identifying these adverse drug reactions. Zhang et al. leverage a novel mechanism known as multi-hop attention to endow models with the ability to focus across multiple words in a single sentence and between sentences. They used the publicly available benchmarks TwiMed and ADE to assess model performance and to compare with baselines. They demonstrate that their method outperforms well-established ML models such as SVM, CNNs, and LSTMs. Additionally, they show multi-hop attention is superior at identifying adverse drug reactions compared with self-attention and multi-head self-attention, two recent mechanisms found in transformer models. They also performed a comprehensive ablation study to isolate which of their innovations resulted in improved performance.

Finally, Wang et al. [95] demonstrate how ML can assist in determining causation from case reports. The authors utilize causal inference, which is a conceptual framework that, under certain assumptions, allows for estimation of causal effects. This means that one can answer counterfactual or ‘what if’ questions such as ‘what if a patient took medication A rather than medication B?’. They combine causal inference with transformer models that are trained on FAERS safety reports. Wang et al. assess their proposed transformer-causal inference model on two tasks: identifying causes of analgesic-induced acute liver failure and identifying causes of tramadol-related mortalities. Their model is able to recapitulate known risk factors for these adverse events (e.g. acetaminophen consumption for liver failure, and suicidality for tramadol mortalities). Moreover, the model was able to identify potential secondary risk factors that predispose individuals to liver failure. Importantly, Wang et al. published their code and preprocessed data (i.e. FAERS reports). This will enable future researchers to reproduce and extend their work.

## Section: Conclusions

We have conducted a scoping review of the use of ML for PV applications. Our aim was to assess the extent to which PV has been or is ready to be improved by current deep learning-based AI techniques. We found that while certain modern practices have begun to appear, many of the primary reasons for the recent success of AI have yet to be translated. We conclude that without certain structural changes, PV is unlikely to experience similar kinds of advancements from current approaches to AI.

## Section: Supplementary Information

Supplementary file1 (PDF 626 KB)

## Section: Supplementary Information

Below is the link to the electronic supplementary material.

Supplementary file1 (PDF 626 KB)

## Section: Declarations › Funding

GlaxoSmithKline (GSK) was a sponsor of this project and provided funding to Harvard. No additional external funding was received for the conduct of this study or the preparation of this article.

## Section: Declarations › Conflicts of Interest

Jeffery L. Painter and Andrew Bate were current full-time employees and stockholders of GSK at the time this study was completed. Benjamin Kompa, Joe B. Hakim, Anil Palepu, Kathryn Grace Kompa, Michael Smith, Paul A. Bain, Stephen Woloszynek, and Andrew L. Beam have no conflicts of interest to declare.

## Section: Declarations › Ethics Approval

Not applicable.

## Section: Declarations › Consent to Participate

Not applicable.

## Section: Declarations › Consent for Publication

Not applicable.

## Section: Declarations › Availability of Data

The datasets generated and/or analyzed during this scoping review are available on Github (https://github.com/beamlab-hsph/drug_safety_scopingreview). All references included in the final analysis are available in the ‘references’ folder in the repo. Additionally, a companion website to our review is available at https://beamlab.shinyapps.io/MLforPVReview.

## Section: Declarations › Code Availability

The code to reproduce our figures and LDA analysis is available at https://github.com/beamlab-hsph/drug_safety_scopingreview

## Section: Declarations › Authors’ Contributions

Conceptualization: AB, ALB. Methodology: BK, JBH, PAB, SW, JLP, AB, ALB. Query formation: BK, JBH, PAB, JLP, AB, ALB. Abstract review: BK, JBH, AP, KGK, MS, SW, ALB. Abstract review conflict adjudication: BK, ALB. Full-text review: BK, JBH, AP, KGK, MS, SW, ALB. Full-text conflict adjudication: BK, ALB. Data extraction: BK, JBH, AP, KGK, MS, ALB. Formal analysis and investigation: BK, SW, ALB. Writing – original draft preparation: BK, ALB. Writing – review and editing: BK, JLP, AB, ALB. Funding acquisition: AB, ALB. Resources: AB, ALB. Supervision: AB, ALB.All authors read and approved the final version.

## Section: Associated Data

Supplementary file1 (PDF 626 KB)

## Section: Associated Data › Supplementary Materials

Supplementary file1 (PDF 626 KB)


---

# Artificial intelligence in cancer target identification and drug discovery

- **Authors:** Yujie You, Xin Lai, Yi Pan, Huiru Zheng, Julio Vera, Suran Liu, Senyi Deng, Le Zhang
- **Issuer:** Signal transduction and targeted therapy
- **Type:** Scientific article
- **Published:** 2022-05-10
- **Language:** en
- **DOI:** 10.1038/s41392-022-00994-0
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35538061/
- **Licence:** CC-BY

## Page 1 (Section: Artificial intelligence in cancer target identification and drug discovery)

REVIEW ARTICLE
OPEN
Artiﬁcial intelligence in cancer target identiﬁcation and drug
discovery
Yujie You1, Xin Lai
2, Yi Pan3, Huiru Zheng4, Julio Vera2, Suran Liu1, Senyi Deng5✉and Le Zhang
1,6,7✉
Artiﬁcial intelligence is an advanced method to identify novel anticancer targets and discover novel drugs from biology networks
because the networks can effectively preserve and quantify the interaction between components of cell systems underlying
human diseases such as cancer. Here, we review and discuss how to employ artiﬁcial intelligence approaches to identify novel
anticancer targets and discover drugs. First, we describe the scope of artiﬁcial intelligence biology analysis for novel anticancer
target investigations. Second, we review and discuss the basic principles and theory of commonly used network-based and
machine learning-based artiﬁcial intelligence algorithms. Finally, we showcase the applications of artiﬁcial intelligence approaches
in cancer target identiﬁcation and drug discovery. Taken together, the artiﬁcial intelligence models have provided us with a
quantitative framework to study the relationship between network characteristics and cancer, thereby leading to the identiﬁcation
of potential anticancer targets and the discovery of novel drug candidates.
Signal Transduction and Targeted Therapy (2022) 7:156 
; https://doi.org/10.1038/s41392-022-00994-0
INTRODUCTION
As one of the cutting-edge cancer treatments, targeted drug
therapy has the advantages of high efﬁciency, few side effects,
and low drug resistance for patients1. However, there are several
drawbacks to the existing targeted therapies, such as a few
druggable targets2, ineffective coverage of the patient population,
and the lack of alternative responses to drug resistance in
patients1. Therefore, identifying novel therapeutic targets and
evaluating their druggability3,4 becomes the current cancer
research focus of targeted drug therapy.
Since we have difﬁculty in comprehensively understanding the
pathogenesis of cancer due to the complexity of the disease5,
most of the current targeted drugs are developed based on the
experimentally validated hypothesis that can explain a possible
mechanism underlying carcinogenesis but ignore other facts of
the disease6. As a result, these therapies could have undesired
impacts on normal tissues and even provoke serious side effects
for patients7,8.
To elucidate the molecular mechanisms underlying cancer
genesis, interactome data can be comprised and modelled in
network structures in which components are biological entities
(e.g., genes, proteins, mRNAs, and metabolites) and edges are
associations/interactions between them (e.g., gene co-expression,
signalling transduction, gene regulation, and physical interaction
between proteins9–14). Artiﬁcial intelligence biology analysis
algorithms are effective method to process the biological
network data, which build machines or programs to simulate
human intelligence, so as to implement classiﬁcation, clustering
and prediction tasks in biological network15. Therefore, artiﬁcial
intelligence algorithms can effectively tackle the complexity of
cancer that arises from interactions between genes and their
products16,17 in biological network structures, so as to improve
our understanding of carcinogenesis11,12,18–22 and explore novel
anticancer targets23–29.
Over the past few decades, we have seen a fast development
of artiﬁcial intelligence biology analysis algorithms. To make
this study easy to understand, we not only divide these
artiﬁcial intelligence algorithms into network-based biology
analysis algorithm and machine learning-based (ML-based)
biology analysis algorithm according to the data of biological
network structure, but also employ Fig. 1 to describe the
historical milestone for these artiﬁcial intelligence biology
analysis algorithms.
On the one hand, network-based biology analysis algorithms
provide a variety of alternative network approaches to identify
cancer targets. More importantly, various network-based biology
analysis algorithms can investigate network data from different
perspectives, therefore they can compensate each other to
provide accurate biological explanations30.
On the other hand, ML-based biology analysis31–33 not only can
efﬁciently handle high throughput, heterogeneous, and complex
molecular data, but also can mine the feature or relationship in the
biological networks. Thus, we should develop more ML-based
biology analysis algorithms to provide such advanced biology
Received: 4 July 2021 Revised: 14 March 2022 Accepted: 5 April 2022
1College of Computer Science, Sichuan University, Chengdu 610065, China; 2Laboratory of Systems Tumor Immunology, Friedrich-Alexander-Universität Erlangen-Nürnberg (FAU)
and Universitätsklinikum Erlangen, Erlangen 91052, Germany; 3Faculty of Computer Science and Control Engineering, Shenzhen Institute of Advanced Technology, Chinese
Academy of Sciences, Room D513, 1068 Xueyuan Avenue, Shenzhen University Town, Shenzhen 518055, China; 4School of Computing, Ulster University, Belfast BT15 1ED, UK;
5Institute of Thoracic Oncology, Department of Thoracic Surgery, West China Hospital, Sichuan University, Chengdu 610065, China; 6Key Laboratory of Systems Biology,
Hangzhou Institute for Advanced Study, University of Chinese Academy of Sciences, Chinese Academy of Sciences, Hangzhou 310024, China and 7Key Laboratory of Systems
Health Science of Zhejiang Province, Hangzhou Institute for Advanced Study, University of Chinese Academy of Sciences, Hangzhou 310024, China
Correspondence: Senyi Deng (senyi_deng@scu.edu.cn) or Le Zhang (zhangle06@scu.edu.cn)
These authors contributed equally: Yujie You, Xin Lai.
www.nature.com/sigtrans
Signal Transduction and Targeted Therapy
© The Author(s) 2022
1234567890();,:

## Page 2 (Section: The scope of artificial intelligence biology analysis for novel anticancer target investigations)

analyses that can allow precise target identiﬁcation and drug
discovery for cancer.
Although artiﬁcial intelligence biology analysis has been widely
used to improve our understanding of carcinogenesis, to the best
of our knowledge, there is no systematic review that introduces
the scope of related research and explains the network-based and
the ML-based biology analysis algorithms to identify novel
anticancer targets and discover drugs. Therefore, in the next
section, we will describe the scope of artiﬁcial intelligence biology
analysis for novel anticancer targets investigation. In the third
section, we will introduce the basic principles and theory of
commonly used artiﬁcial intelligence biology analysis algorithms.
Then, we will brieﬂy review and discuss studies that utilize
network-based and ML-based biology analysis for cancer target
identiﬁcation and drug discovery. Finally, we will summarize the
content of the article, discuss the limitations and challenges faced
by the community, and point out the potential of artiﬁcial
intelligence biology analysis to identify the therapeutic targets
and discover drugs for cancer.
THE SCOPE OF ARTIFICIAL INTELLIGENCE BIOLOGY ANALYSIS
FOR NOVEL ANTICANCER TARGET INVESTIGATIONS
Recently, the rapid development of cancer-related multiomics
technologies34–36 has been one of the most important factors for
artiﬁcial intelligence biology analysis to explore novel anticancer
targets37–39. Figure 2 classiﬁes these technologies into ﬁve
aspects: epigenetics, genomics, proteomics, metabolomics, and
multiomics integration analysis. Furthermore, Table 1 lists the
related major diseases, drug targets, genomics, and network
databases commonly used in multiomics integration analysis for
these ﬁve aspects. Next, we will detail these ﬁve aspects.
Epigenetics analyses the reversal modiﬁcations of DNA or DNA-
related proteins54. These modiﬁcations affect gene expression
without changing the DNA sequence54. Investigating epigenetic
data through artiﬁcial intelligence is not only important for
elucidating fundamental mechanisms of cancer but also necessary
for the design of targeted therapeutics. For example, Wilson
et al.55 took advantage of information-rich transcriptomic and
epigenetic data to study regulatory networks surrounding histone
lysine demethylation and highlighted the importance of epige-
netic regulators in mitogenic control and their potential as
therapeutic targets, which showed that epigenetic regulators such
as KDM1A, KDM3A, EZH2, and DOT1L56 are critical in oncogenesis
and drug resistance.
Genomics aims to characterize the function of every genomic
element of an organism by using genome-scale assays such as
genome sequencing57. Applications of genomics include ﬁnding
associations between genotype and phenotype58, discovering
biomarkers for patient stratiﬁcation59, predicting the function of
genes60 and charting biochemically active genomic regions such
as transcriptional enhancers49. Recent developments in network-
based biology analysis methods, such as sequence-similarity
networks, genome networks, and gene family networks, have
signiﬁcantly improved the usability of molecular datasets in
comparative genomics analysis61. These network methods collect
expression and interaction data in the beginning and then
transform them into interpretable biological processes62,63, lead-
ing to the identiﬁcation of tumour subtypes and the discovery of
drug targets64.
For example, Medi et al.65 integrated gene expression proﬁles
into genome-scale molecular networks to identify novel ther-
apeutic targets for cervical cancer, including receptors, microRNAs
(miRNAs), transcription factors (TFs), proteins (e.g., CRYAB, CDK1,
PARP1, WNK1, GSK3B, and KAT2B), and metabolites (arachidonic
acids). Laura et al.66 developed a network-based biology analysis
workﬂow that integrates different layers of genomic information,
including transcription factor cotargeting, miRNA cotargeting,
protein–protein
interaction
and
gene
coexpression,
into
a
biological network. Then, the authors applied a consensus
clustering algorithm (An ML-based biology analysis algorithm
that
divide
the
network
into
sub-modules
with
different
functions)67–73 on identiﬁed network communities to discover
cancer driver genes, which demonstrated that F11R, HDGF, PRCC,
ATF3, BTG2, and CD46 could be oncogenes and promising
markers for pancreatic cancer.
For proteomics, proteomic experiments are performed for
annotation and correlation of genome sequences, quantitation
of protein abundance, detection of posttranslational modiﬁca-
tions, and identiﬁcation of protein-protein interactions (PPIs)74.
PPIs not only play fundamental roles in structuring and mediating
biological
processes
but
also
have
been
widely
used
for
proteomics data analysis75. For example, Vinayagam et al.37
analysed the human PPI interaction network to identify indis-
pensable proteins that affect the controllability of the network
with control theory76, which shows that if a system can be driven
from any initial state to any desired ﬁnal state in ﬁnite time with a
suitable choice of inputs, the system is controllable. By changing
the number of driver nodes in the network upon removal of that
protein, the hub can be classiﬁed as “indispensable” “neutral” or
Fig. 1
The historical milestones of network-based and ML-based biology analysis. (Created with BioRender.com)
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
2
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 3 (Section: The scope of artificial intelligence biology analysis for novel anticancer target investigations)

“dispensable”, which correlates with increasing, no effect, or
decreasing the number of driver nodes in the network upon
removal of the key protein. The evidence shows that these
indispensable proteins are primary targets of disease-causing
mutations, viruses, and drugs.
Furthermore,
analysing
data
from
1,547
cancer
patients
revealed 56 indispensable genes in nine cancers. 46 of these
genes were associated with cancer for the ﬁrst time, demonstrat-
ing the ability of intelligent network controllability analysis to
identify novel disease genes and potential drug targets77. More-
over, Valle et al.78 developed a network-based biology analysis
framework to compute the proximity between polyphenol targets
and disease proteins. The calculated results indicated that the
diseases whose proteins are proximal to polyphenol targets have
signiﬁcant gene expression changes, while the diseases whose
proteins are distal to polyphenol targets have no such change. The
network relationship between disease proteins and polyphenol
targets provides not only a computing method to reveal the effect
of polyphenols on diseases but also a basis to identify novel
anticancer targets.
Metabolomics is routinely applied for biomarker discovery by
proﬁling metabolites in bioﬂuids, cells and tissues34. Because of
the inherent sensitivity of biotechnology, subtle alterations in
metabolic pathways can be detected to provide insights into the
mechanisms that underlie various physiological conditions and
cancer processing34. Owing to innovative developments in
network biology, researchers employ biological networks to
perform metabolomic analyses and provide us with a systems-
level understanding of the role that metabolites play in cancer.
For example, Basler et al.79 proposed an effective network-
based biology analysis framework for the systematic study of
ﬂow control and identiﬁcation of driver reactions in large-scale
metabolic networks. They found that the driver reactions were
under complex cellular regulation in Escherichia coli, suggesting
their preeminent role in facilitating cellular control. Correlation
statistics indicate that the driven response plays an important
role in inhibiting tumour growth and represents a potential
therapeutic target.
For multiomics integration analysis, addressing the complexity
of tumour-host interactions requires an approach to handle
integrative omics data80. Compared to single omics studies,
multiomics data provide researchers with various and intercon-
nected
molecular
proﬁles
to
study
carcinogenesis80.
Thus,
integrated multiomics datasets in a network structure to artiﬁcial
Fig. 2
Artiﬁcial intelligence to integrate multiomics data (e.g., epigenetics, genomics, proteomics, and metabolomics) for cancer therapeutic
targets identiﬁcation. (Created with BioRender.com)
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
3
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 4 (Section: The principles and theories for commonly used artificial intelligence biology analysis algorithms)

intelligence biology analysis has emerged as a powerful tool to
fully appreciate the complex interlayer regulatory interactions in
cancer progression. Such an approach allows us to beneﬁt from
prior information that can be summarized and presented in
networks, thereby providing us with insights into carcinogenesis
from an overall perspective81.
For example, Gov et al.82 ﬁrst performed comparative analyses of
transcriptome data, and then identiﬁed common and tissue-
speciﬁc reporter biomolecules such as genes, receptors, membrane
proteins, TFs, and miRNAs. Second, they used the interactions
among receptors, TFs, miRNAs, and their targeted DEGs to
reconstruct a tissue-speciﬁc network for ovarian cancer and used
network-based biology methods to identify interaction hubs.
Finally, GATA2 and miR-124-3p were identiﬁed as hub nodes,
suggesting that they are potential biomarkers for ovarian cancer.
THE PRINCIPLES AND THEORIES FOR COMMONLY USED
ARTIFICIAL INTELLIGENCE BIOLOGY ANALYSIS ALGORITHMS
This study divides these commonly used artiﬁcial intelligence
biology analysis algorithms into two categories. One is network-
based biology analysis algorithm, including shortest path83,
module detection84, and network centrality85; the other is ML-
based biology analysis algorithm including decision tree86–88 and
deep learning models89–91.
The principles and theory of network-based biology analysis
algorithms
Biological networks are efﬁcient in integrating complicated
biological data, because they can capture the property of
biological entities and their relationships92. Mathematically, a
network can be represented as a graph G = (V, E) where V and E
are a set of nodes (vertices) and edges, respectively. Nodes in
biological networks can represent proteins, genes, diseases, and
drugs and edges in the network represent various biochemical
physical or functional interactions between nodes. Therefore,
network-based biology analysis algorithms focuses on identifying
therapeutic targets and discovery of novel drugs for cancer from
molecular networks such as protein-protein interaction net-
works75, gene regulatory networks93, metabolic networks94, and
drug-drug interaction networks95.
Computational biologists have developed several network-
based biology analysis algorithms to effectively process and
Table 1.
Commonly used repositories related to human diseases, drug targets, genomics, and biological networks
Database name
Description
Web link
Ref
Disease
Online Mendelian Inheritance in
Man (OMIM)
A comprehensive, authoritative, and timely knowledgebase
of human genes and genetic disorders
http://www.omim.org/
40
Pathologisch Anatomisch Landelijk
Geautomatiseerd Archief (PALGA)
A database of histopathology and cytopathology was
stored.
https://www.palga.nl
41
Drug Target
DrugBank
DrugBank is a web-enabled database containing
comprehensive molecular information about drugs, their
mechanisms, their interactions, and their targets.
https://www.drugbank.ca/
42
Therapeutic Targets Database (TTD)
A database to provide information about the known and
explored therapeutic protein and nucleic acid targets, the
targeted disease, etc.
http://db.idrblab.net/ttd/
43
PubChem
PubChem is an open repository for chemical structures and
their biological test results.
http://pubchem.ncbi.nlm.nih.gov
44
ChEMBL
ChEMBL is an open data database containing binding,
functional and ADMET information for many drug-like
bioactive compounds.
https://www.ebi.ac.uk/chembldb
45
Genomics Data
Gene Expression Omnibus (GEO)
GEO is a public functional genomics data repository. Array-
and sequence-based data are accepted.
https://www.ncbi.nlm.nih.gov/geo/
46
The Cancer Genome Atlas (TCGA)
TCGA contains clinical data of various human cancers,
genomic mutations, mRNA expression, miRNA expression,
methylation, etc.
https://www.cancer.gov/about-nci/
organization/ccg/research/structural-
genomics/tcga
47
Cancer Cell Line Encyclopedia (CCLE)
A compilation of gene expression, chromosomal copy
number and massively parallel sequencing data from 947
human cancer cell lines.
https://sites.broadinstitute.org/ccle
48
ENCyclopedia Of DNA Elements
(ENCODE)
ENCODE has systematically mapped regions of
transcription, transcription factor association, chromatin
structure, and histone modiﬁcation.
https://www.encodeproject.org/
49
Catalogue Of Somatic Mutations In
Cancer (COSMIC)
COSMIC curates comprehensive information on somatic
mutations in human cancer.
http://www.sanger.ac.uk/cosmic
50
Biological Network
Search Tool for the Retrieval of
Interacting Genes/Proteins (STRING)
A database of known and predicted protein interactions
http://string-db.org/
51
Gene Ontology (GO)
The world’s largest source of information on the functions
of genes.
http://www.geneontology.org/
52
Kyoto Encyclopedia of Genes and
Genomes (KEGG)
A collection of databases dealing with genomes, biological
pathways, diseases, drugs, and chemical substances
http://www.genome.jp/kegg/
53
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
4
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 5 (Section: Tthe shortest path algorithm)

analyze non-ordered or non-Euclidean data in biological networks,
which can perform tasks such as link prediction96, node ranking85,
network propagation97, network modularization98, and network
control99. Here, we brieﬂy review and discuss the shortest path
algorithm, module detection algorithm, and node prioritization
methods using node centrality in identifying cancer therapeutic
targets and discovering drugs.
Tthe shortest path algorithm.
The shortest path algorithm, one of
network link algorithm, is used to intelligently identify the shortest
connection between two genes or proteins in a graphical model
that
represents
a
cellular
network100,101.
The
algorithm
is
illustrated in Fig. 3 and Algorithm 1. The shortest distance for a
given network is calculated by Eq. (1):
dðS; TÞ ¼ min
K2V dðS; KÞ þ dK;T
(1)
Here, S and T stand for the source and target node, respectively. d
(S,T) is the length of the shortest path from node S to T. V is a set of
network nodes. K stands for a node in the network, and dK,T
represents the lengths of possible paths connecting nodes K and T.
Algorithm 1. The shortest path algorithm102
1:
Input: Network G, Source S, Target T, Nodes
2:
create an empty set P and a set Q contains all nodes
3:
for each vertex V in Network:
4:
d(S,V) ←inﬁnity
5:
d(S,S) ←0
6:
do:
7:
U ←vertex in Q with minimal d(S,U)
8:
remove U from Q
9:
for each vertex V in Q that is connected with U:
10:
alt ←d(S,U) + dU,V
11:
if alt < d(S,V):
12:
d(S,V) ←alt
13:
add U to the set P
14:
until Q is empty
15:
Output: the shortest path from S to T
Fig. 3
The ﬂow chart of the shortest path algorithm. The red paths in the bottom network are the identiﬁed shortest path from node S to T
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
5
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 6 (Section: Tthe shortest path algorithm)

The shortest path algorithm has been widely used to determine
regulatory paths in cancer networks103,104 and then discover the
key targets on the paths105. For example, Li et al.106 ﬁrst identiﬁed
a set of six genes that can distinguish colorectal tumours from
normal adjacent tissues using the maximum relevance minimum
redundancy approach107. The method ranks genes according to
their
relevance
to
the
class
of
samples
concerned
while
considering the redundancy of genes. Those genes that had the
best trade-off between the maximum relevance to the sample
class and the minimum redundancy were considered “good”
biomarkers. Then, the authors applied the shortest path algorithm
among the six genes in a PPI network underlying cancer and
identiﬁed 15 shortest paths between any two genes of the gene
set. Last, they found 35 genes on the identiﬁed shortest paths and
ranked them according to their betweenness108. The results
showed
that
androgen
receptor
(AR),
a
ligand-dependent
transcription factor, is ranked as the top gene, suggesting its
involvement in colon carcinogenesis through regulating the
proliferation and differentiation of tumour cells109.
Additionally, Chen et al.105 used a network-based biology
analysis method, SAM (Signiﬁcance Analysis of Microarrays)110, to
analyse omics data and identiﬁed 153 differentially methylated
CpG sites and differentially expressed molecules, including 42
miRNAs and 1,373 protein-coding genes. The authors ﬁrst used
the differentially expressed genes from the STRING database111 to
construct a PPI network. Then, they searched all the shortest
paths connecting dysfunctional genes to identify potential cancer
driver genes. Next, they ranked the genes by a permutation test
and their network properties, such as betweenness and interac-
tion scores. The top-ranking genes at different levels (i.e.,
methylation level, miRNA level, mutation level, and mRNA level)
were regarded as driver genes of lung adenocarcinoma. Among
these cancer driver genes, some appeared to be top candidates at
different levels, suggesting their multifaceted contribution to
lung carcinogenesis.
Above all, the shortest path algorithms100,101 can help us
efﬁciently identify regulatory paths in networks, allowing us to
identify potential genes that are proximate to known cancer
genes and thereby important for tumorigenesis. However, due to
the complexity of the disease, potential cancer genes are not
always on the identiﬁed shortest paths106, revealing the limita-
tions of such algorithms. To resolve this issue, Lu et al.112
proposed a random walk with restart algorithm method and
identiﬁed 298 potential CRC-associated genes, which is more
Fig. 4
The ﬂow chart of the module detection algorithm
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
6
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 7 (Section: The module detection algorithm)

effective and accurate than the shortest path algorithm proposed
by Li et al.106. In particular, the computing efﬁcacy of the shortest
path algorithm could be compromised by large networks and
their search strategies112.
The module detection algorithm.
Cancers usually result from
disruption of interactions of key regulatory genes with their
partners81,113. Module detection algorithms114, one of network
propagation algorithm, identify communities of cancer genes in
complex networks115 by analysing their topological structures
(Fig. 4 and Algorithm 2). Here, we explain and illustrate the
commonly used modularity maximization algorithm116, which
identiﬁes network modules with the maximum modularity
coefﬁcients by Eq. 2.
Q ¼ 1
2M
X
i;j 2 V
½Aij  Pij  δCi;Cj
(2)
where Q represents the modularity coefﬁcient of an identiﬁed
module, M is the total number of edges in the network, Aij is the
adjacency matrix, and Pij represents the expected number of edges
between nodes i and j. Ci or Cj represents the module to which
node i or node j belongs. If i and j belong to the same module,
δCi;Cj ¼ 1; otherwise, δCi;Cj ¼ 0. The identiﬁed modules are a group
of genes that are supposed to have a similar biological function,
such as promoting or inhibiting tumourigenesis.
Algorithm 2. Module detection algorithm.
1:
Input: Network G
2:
M ←the total number of edges in the Network
3:
for each vertex i in Network:
4:
i ←a single module
5:
ki ←degree of vertex i
6:
ai ←ki/2 M
7:
for each edge in Network:
8:
if vertex i connects j:
9:
ei.j ←1/2 M
10:
else:
11:
ei.j ←0
12: do:
13:
ΔQ ←ei.j + ej,i-2aiaj
14:
consolidate related communities
15:
direction ←the greatest increase (or smallest decrease) in Q
16: until the entire network becomes a module
17: Output: the module with a local maximum Q
Currently, many researchers employ module detection algo-
rithms to intelligently identify potential therapeutic targets
for cancer117–119. For example, Ghiassian et al.120 used the
DIseAse MOdule Detection (DIAMOnD) method121 to identify
the local modules within the interconnected map of molecular
components. They found that disease-related genes were
signiﬁcantly enriched in highly overlapping modules, which
indicated that the predicted modules may help identify new
anticancer targets. Of note, since the results of module
detection algorithms depend mainly on network structures,
the identiﬁed modules may vary for the same disease network
with slightly different topology85,117.
Since potential drug targets may exist in different network
modules, we can make use of the correlation between modules
to identify reliable cancer treatment targets81. Therefore, Wang
et al.122 proposed the seed connector algorithm (adding a few
extra hidden nodes as much as possible to link disease
proteins) by considering the interactions among cancer-
associated proteins. First, this algorithm starts with known
seed proteins and induces a loosely connected subnetwork
consisting of only seed proteins. Second, Wang et al. sequen-
tially select such proteins as seed connectors that maximally
increase the size of the largest connected component of the
subnetwork until there is no additional protein that can be
selected as a seed connector. Finally, the cancer modules are
pinpointed.
While these aforementioned algorithms122–124 can intelli-
gently identify meaningful functional modules from network
topologies, it may be difﬁcult to capture disease modules125.
One possible reason is that disease proteins do not constitute
particularly densely connected subgraphs but agglomerate in
speciﬁc large regions of the network. For this reason, Tripathi
et al.126 considered analysing the patterns of connectivity in a
disease module to be an effective way to understand the
properties of disease modules.
The node centrality.
Node centrality measures the importance of
nodes and is suitable to intelligently locate key nodes with
important biological functions for network biology127.
Usually, we listed four types of node centrality as follows: (1)
As the simplest form of network centrality, degree centrality is
the number of nodes directly connected to the network127,128;
(2) Coreness centrality considers both the degree of nodes and
their positions in a network129; (3) Betweenness centrality of a
node is the probability for the shortest path between two
randomly chosen nodes to go through that node, and it
determines the actor that controls information among other
nodes by connecting paths130; (4) Eigenvector centrality131 not
only considers the number of edges and the position of
nodes but also the impact of adjacent nodes on the interactive
network.
Table 2 shows the formulas for node centrality computing.
Figure 5(a–d) illustrates the above four types of node centrality,
and Algorithm 3 presents the pseudocode to compute four
types of node centrality.
Table 2.
The formula to compute degree centrality, coreness centrality, betweenness centrality and eigenvector centrality
Node centrality
Formula
Description
Eq.
Degree centrality
CDðiÞ ¼ di
di is the degree of vertex i.
(3)
Coreness centrality
CCðiÞ ¼ P
j2NðiÞ ksðjÞ
Vertex j belongs to the neighbours of vertex i, ks(j) is the k-shell index of vertex j.
(4)
Betweenness centrality
CBðiÞ ¼ P
j<k gj;kðiÞ=gj;k
gj,k is the number of all shortest paths between j and k, gj,k(i) is the number of shortest
paths between j and k containing i.
(5)
Eigenvector centrality
CEðiÞ ¼ 1
λ
P
j2G ai;jxj
if vertex i is linked to vertex j, ai,j = 1, xj is the degree of vertex j, λ is a constant.
(6)
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
7
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 8 (Section: The module detection algorithm)

Algorithm 3. The algorithm of degree centrality, coreness
centrality, betweenness centrality and eigenvector centrality.
1:
function1 Degree centrality:
2:
Input: Network G
3:
for each vertex i in Network:
4:
di ←the number of ties that vertex i has
5:
CD(i)=di
6:
Output: CD(i)
7:
function2 Coreness centrality:
8:
Input: Network G
9:
for each vertex i in Network:
10:
N(i) ←the set of the neighbours adjacent to vertex i
11:
for each vertex j in N(i):
12:
ks(j) ←the k-shell index of vertex j
13:
CC(i) ←CC(i) + ks(j)
14:
Output: CC(i)
15: function3 Betweenness centrality:
16:
Input: Network G
17:
for each vertex i in Network:
18:
for each vertex j in Network:
19:
for each vertex k in Network:
20:
if j < k:
21:
gj,k ←number of all shortest paths between j and k
22:
gj,k(i) ←number of shortest paths between j and k containing i
23:
CB(i) ←CB(i) + gj,k(i)/gj,k
24:
Output: CB(i)
25: function4 Eigenvector centrality:
26:
Input: Network G
27:
for each vertex i in Network:
28:
for each vertex j in Network:
29:
if vertex i is linked to vertex j:
30:
ai,j=1
31:
else:
32:
ai,j=0
33:
xj ←the degree of vertex j
34:
CE(i) ←CE(i)+ 1/λ ∙ai,jxj
35:
Output: CE(i)
As described in Fig. 5(a) and Eq. 3, the degree centrality of node
2 is 3 (CD (2) = 3) because node 2 interacts with nodes 0, 1, and 3.
We demonstrated that highly connected nodes or hubs are more
likely to be essential127. Because the more direct connections a
node has, the greater the impact that the node can exert on the
network132, we can utilize the degree centrality of nodes to
identify cancer therapeutic targets.
For example, Zhang et al.133 predicted that hypoxia inducible
factor-1α (HIF-1α) and prolyl 4-hydroxylase beta polypeptide
(P4HB) may be considered potential biomarkers of gastric
cancer by constructing a PPI network. Nevertheless, not only
Jalili et al.130 suggested that high connectivity does not
necessarily imply its essentiality, but also Kitsak et al.129 argued
that the location of nodes is more signiﬁcant than the
immediate neighbours to evaluate its spreading inﬂuence
because degree centrality considers only direct interactions of
a node but not its impact on other nodes, resulting in low
accuracy for target prediction compared to other methods such
as coreness centrality134.
As shown in Fig. 5(b) and Eq. 4, the coreness centrality of
node 3 is 8 (CC (3) = 8) because the neighbours adjacent to the
labelled vertex (3) are vertex (1), vertex (2), vertex (4) and vertex
(5), and these four nodes belong to a 2-shell. Coreness centrality
is an advanced form of node centrality because it considers
both the degree of nodes and their positions in a network to
quantify the importance of nodes in a network129. A node with
a greater coreness means that the node is located in a more
central
place
and
is
much
more
inﬂuential
in
network
propagation
than
the
nodes
with
high-degree
but
less
coreness129. Among them, the most classic method to calculate
the
coreness
centrality
of
network
nodes
is
the
k-core
decomposition method135, which decomposes the network
iteratively according to the remaining degree of the nodes.
For instance, Li et al.136 employed the k-core decomposition
method to obtain the coreness of the PPI network. Subsequently,
the targets were screened for topological importance. Then, the
major hubs in the hub interaction network were determined, and
a total of 62 major hubs were identiﬁed, including 11 indirubin
(EGFR, JAK2, ERBB2, CHUK, CDK5, KIF11, DRD2, CDK3, HTR1A,
JAK3 and TYK2) and derivative targets and 51 differentially
expressed genes (DEGs) for imatinib resistance. These 11 major
hubs were closely related to DEGs that were resistant to imatinib.
Indirubin and its derivatives may inhibit imatinib resistance
through the regulation of these genes to treat chronic myeloid
leukaemia (CML).
Described by Fig. 5(c) and Eq. 5, the betweenness centrality of
node 1 is 3.5 (CB (1) = 3.5) because there are four node pairs
contributing to node one (g0,2(1)/g0,2(1) = 1, g0,3(1)/g0,3 = 1,
g0,4(1) / g0,4 = 1, and g2,3(1)/g2,3 =0.5). Betweenness centrality is
based upon the frequency with which a node lies between the
shortest path of all other possible pairs of nodes within a
network and identiﬁes the gatekeepers that control commu-
nication of nodes in the network130.
For example, Taylor et al.137 used betweenness centrality
analysis to identify intermodular hub proteins and intramodular
hub proteins in the breast cancer network. The identiﬁed
proteins may serve as an indicator of breast cancer prognosis.
Moreover, Raman et al.138 computed degree, betweenness, and
closeness indices in PPI networks for 20 organisms and showed
that the degree and betweenness centralities of nodes correlate
with their lethality in many organisms.
As described in Fig. 5(d) and Eq. 6, the eigenvector centrality
of node 1 is 3 (CE (1) = 3) because node 1 is connected to nodes
0, 2 and 3 (a1,0, a1,2 and a1,3 equal 1, respectively), and the
degree of x0, x2 and x3 equals 1, respectively. Eigenvector
centrality considers not only the number of edges and the
position of nodes but also the impact of adjacent nodes on a
network.
For example, Mallik et al.139 ﬁrst identiﬁed differentially
expressed and methylated genes in uterine leiomyoma tumours
and then found TFs and miRNAs that regulate the expression of
these genes. Subsequently, they reconstructed a network that
comprised
the
genes,
TFs,
and
miRNAs
and
then
used
eigenvector centrality to identify potential biomarkers. They
speciﬁed that PTGS2 and TACSTD2 are potential novel biomar-
kers, since both genes are downregulated and hypermethylated
in the tumour.
Moreover, several researchers have attempted to integrate
more than one centrality index to increase the efﬁciency of
the node centrality algorithm. For instance, Chen et al.140 used
the differentially expressed proteins of prostate cancer (PC) to
construct a PPI network. Then, they integrated the connectivity
degree, betweenness centrality, and closeness centrality of
nodes to evaluate critical nodes to identify the core module of
the PPI network. Finally, they identiﬁed SLC2A4 and TUBB2C as
important proteins regulating the pathogenesis of cancer,
suggesting the proteins involved in biological processes and
pathways as potential targets for PC diagnosis and treatment. In
addition, Aamri et al.141 constructed a gene-gene-interaction
network for the entire human genome and then applied
betweenness, closeness, eigenvector, and degree centrality
metrics to rank the central genes of the network to identify
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
8
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 9 (Section: Machine learning-based biology analysis algorithms)

possible cancer-related genes. The results showed that the
average precision for identifying breast, prostate, and lung
cancer genes varied between 80–100%.
Although highly connected nodes in the network architecture
are essential, recent studies point out that integrating the prior
knowledge of cancer into centrality indices can accurately
identify anticancer targets130. For this reason, Jiang et al.142
developed a network-based biology analysis method, named
NEST,
which
predicts
essential
proteins
according
to
the
expression levels of their interacting partners in a network.
Additionally, the results showed that NEST signiﬁcantly out-
performed the classic centralities on gene essentiality prediction
and functional screen result enhancement.
Machine learning-based biology analysis algorithms
Machine learning (ML) algorithm is a subset of AI algorithms that
can learn from data, therefore removing the need for explicit
instructions on how to do certain tasks15. The key to identify
therapeutic targets and discover drugs using ML-based biology
analysis is to make use of network features in biological networks.
The network features include the topological features (such as
node centrality, interaction, local structure, subgraph, network
propagation results, and network-based structure similarities) and
the biological information that is embedded in network nodes
(such as the gene expression proﬁle, gene mutation frequency,
and gene functional annotation).
Here, we introduce two classical ML-based algorithms: one is
the decision tree algorithm, which selects signiﬁcant topologi-
cal features for cancer; the other is deep learning, which uses
the network features to identify cancer targets and discover
drugs.
The decision tree algorithm.
A decision tree is a supervised
classiﬁcation algorithm143 with three steps: feature selection,
decision tree generation, and decision tree pruning86–88. Figure 6
shows how to classify a set of samples into two groups using the
decision tree algorithm.
In the network-based biology analysis, network topology
features88 are usually integrated into a decision tree to classify
gene-phenotype associations for cancers144–146 to select signiﬁ-
cant topological features for cancer.
For instance, Ramadan et al.147 extracted thirteen network
topological features (Table 3) from a publicly available gene co-
expression network and a PPI network of breast cancer. Then, to
assess the signiﬁcance of topological measurements associated
with breast cancer, they used Decision Tree Bagger156 to classify
breast cancer gene-phenotype associations. The importance of
each topological measure was then evaluated using a score that
combines the accuracy of breast cancer classiﬁcation and the Gini
index148 (Table 3). The computed scores of the top ﬁve identiﬁed
features (i.e., structural holes, node degree, node coreness, k-Step
Markov and subgraph) outperformed the others, and they were
selected as key features for the classiﬁcation of breast cancer
phenotype-gene associations.
Although the decision tree algorithm can help us select key
network features, it usually has the overﬁtting problem when too
many features exist in the network157, which signiﬁcantly decreases
the classiﬁcation and prediction on independent testing157.
Fig. 5
Four types of node centralities of biological networks. (a) Degree centrality; (b) Coreness centrality; (c) Betweenness centrality; (d)
Eigenvector centrality
Fig. 6
An illustration of a simple decision tree model
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
9
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 10 (Section: Machine learning-based biology analysis algorithms)

At present, there are two commonly used methods to resolve
overﬁtting caused by the decision tree algorithm. One method is
using dimension reduction157 and pruning strategy86 to improve the
classiﬁcation accuracy by feature reduction; the other is employing
the random forest algorithm158, an ensemble algorithm with
multiple decision trees. The random forest algorithm adopts a
bagging strategy, which has higher accuracy and reliability than the
classical decision tree algorithm159.
For example, Toth et al.160 used the random forest algorithm to
predict
the
aggressive
behaviour
of
prostate
cancer.
Their
methylation-based classiﬁer demonstrated excellent performance
in discriminating prognosis subgroups of the test set (Kaplan-Meier
survival analyses with log-rank p value < 0.0001) with an AUC value
of 0.95161 for the sensitivity analysis. Finally, the experimental
veriﬁcation showed that the loss of ZIC2 protein expression was
associated with poor prognosis and correlated with a signiﬁcantly
shorter time to biochemical recurrence.
In addition to the overﬁtting problem, it is difﬁcult for decision
trees to visualize the complicated classiﬁcation procedure146.
Recently, the alternating decision tree (ADTree)162 has made the
classiﬁcation procedure intuitive and easy to understand by adding
an intuitive graphical model, and the algorithm builds decision trees
over a user-deﬁned number of iterations using conﬁdence-rated
boosting, so it returns both a class label and a score that measures
conﬁdence in the classiﬁcation, as shown in Fig. 7 and Algorithm 4.
For example, Carson et al.146 used ADTree to classify proteins in a
breast cancer network. As indicated in Fig. 7, the most effective
attributes to distinguish disease and non-disease proteins are node
degree, disease neighbour ratio, eccentricity, and neighbourhood
connectivity, which was proven by Hao et al.163 and Zhang et al.164.
Table 3.
Thirteen network topological features for decision tree classiﬁcation147. The score is a combination of the classiﬁcation accuracy and the
Gini index148
Topological measures
Concept
Score
Structural holes149
Rank nodes by their connectivity and lack of redundancy
13.37
Node degree
The number of connections of a node
13.36
Node coreness
Considers both the degree of nodes and their positions in a network
12.05
k-Step Markov150
The probability that a random walk of length k makes the system reach a certain vertex
10.47
Subgraph151
The number of times a given vertex participates in different connected subgraphs of a network
10.36
Within–module z-score152
Measure how nodes are related.
8.88
Katz status index153
Rank a vertex as highly important if many nodes are connected to it.
8.64
Closeness
The average length of the shortest path between nodes
8.18
Proximity prestige
The average shortest path length of a node
8.12
Eigenvector centrality
The inﬂuence of directly adjacent nodes on central node
8.09
Betweenness
A node acts as a bridge along the shortest path between two other nodes
7.93
Bary centre score154
Rank the nodes by the total shortest path of the vertex
5.70
Clustering coefﬁcient155
Measure the degree of cohesiveness
0.15
Fig. 7
An example of an ADTree model. The root nodes indicate the ratio between positive and negative class examples. The numbers in
parentheses within each decision node (rectangles) indicate the order in which the rule was found. The amount of node conservation
between each of the trees is indicated by the colour of the box. Ovals (prediction nodes) contain the value for the weighted vote. The
numbers next to the arrows correspond to the threshold for the prediction
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
10
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 11 (Section: The deep learning algorithms)

Algorithm 4. The algorithm of ADTree model165
1:
Input: labelled dataset
2:
root node ←the bias in the dataset
3:
for each decision node in the tree:
4:
ai ←attribute value
5:
ti ←threshold
6:
for each decision node in the tree
7:
if (the decision node has a parent node):
8:
if ai ≥ti:
9:
return the score of the prediction node for the left path
10:
else:
11:
return the score of the prediction node for the right path
12:
else:
13:
return 0
14: s ←the sum of all scores acquired
15: if s > 0:
16:
Output: the positive class
17: else:
18:
Output: the negative class
Although the decision tree, random forest and ADTree86–88,158
demonstrate the tendency to identify such proteins that are well
annotated and studied for cancer, these methods are subject to
producing local optimal solutions. Therefore, Chen et al.143
proposed using the decision tree classiﬁer based on particle
swarm optimization166 to avoid falling into the trap of local
minima by adding randomness to optimize the number of
features and detection accuracy of cancer treatment targets.
Furthermore, the gradient boosting decision tree167 is a very
ﬂexible and scalable method to classify network nodes for
future study.
The deep learning algorithms.
Deep learning is a subﬁeld of
machine learning, and the origin of neural networks sets the stage
for the emergence of deep learning models168. Deep learning
model is a neural network composed of complex structures and
nonlinear transformations90,91 that attempts to model high-level
abstractions of data using multilayer neurons. Through training
and iteratively updating its hyperparameters (Eq. 7), the initial low-
level feature representation (such as topological features and
biological information) of samples is transformed into the high-
level representation that shows the distinction between samples.
The strength of deep learning is its ability to detect complex
patterns in data, making it suitable to interrogate the biological
networks that consist of complex, interdependent relationships
among genes.
Wk ! Wkþ1 ¼ Wk  η ∂C
∂Wk
(7)
W, k, and C are the weight, iteration, learning rate, and loss
function, respectively.
Currently, there are many neural network models and complex
functions for ML-based biology analysis. In this paper, we only
present several commonly used neural networks (Table 4).
Beneﬁting from the strong ability of neural networks in mining
complex information on links or nodes, deep learning is a suitable
method to identify potential cancer targets and discover drugs for
cancer treatment in complex biological networks175. For example,
Selvaraj et al.176 searched for therapeutic targets for lung
adenocarcinoma in a network of protein-protein and protein-
drug interactions and employed a neural network to identify
candidate drugs, where phosphothreonine is predicted via
molecular dynamics simulations to target the hub node MAPK1
in the network.
Currently, artiﬁcial intelligence biology analysis has bene-
ﬁted from the utilization of graph-based neural networks
instead
of
commonly
used
non-graph
neural
networks
such as CNN170 or DNN169, because graph-based neural
networks can take the biological network structure as the
input directly, learn an embedding that contains information
about the neighbourhood of a target node in a graph, and
analyse the biological network with neural networks technol-
ogy. Figure 8 illustrates the basic ﬂowchart of graph-based
neural networks for the investigation of different properties of
biological networks.
There are two advantages in using graph-based neural
networks to identify cancer targets or discover drugs from
biological networks.
1. Feature representation. Graph embedding177 is the core
method to extract features in graph-based neural networks,
which represent network nodes as a low-dimensional vector
representation, preserving both network topology and node
content information178. For example, Li et al174 proposed a
similarity-based miRNA-disease prediction method that
used DeepWalk, a graph embedding algorithm, to compute
the topological similarities between two diseases nodes. The
model extracts the disease node features in the disease-
disease network based on the random walk algorithm, and
signiﬁcantly
enhances
the
prediction
performance
by
utilizing global network association information. For dis-
eases nodes with similar features, if one of the diseases is
Table 4.
Commonly used neural networks in ML-based biology analysis
Model
Characteristic
Application scenarios
Non-graph Neural Network
DNN
Deep neural network (DNN), also called multi-layer perceptron, is a neural network with multi-layer hidden layer.
169
CNN
Convolutional neural network (CNN) obtains local information between input data by convolution.
170
Graph-based Neural Network
GCN
Graph convolutional network (GCN) applied cconvolution in networks to obtain local information between nodes
and neighbour nodes.
171
GAE
Graph autoencoder (GAE) uses autoencoder to extract the embedded features of the network.
172
GAN
Graph attention network (GAN) uses attention mechanism instead of convolution to obtain local or global
information between nodes.
173
DeepWalk DeepWalk is a network embedding model, which can represent the attributes of graph nodes as low dimensional
and dense eigenvectors.
174
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
11
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 12 (Section: The artificial intelligence biology analysis for biomedical applications)

associated with miRNA, the other is predicted to be
associated with the miRNA.
In addition, Zheng et al.179 proposed an attention-based
graph
neural
networks
(attention
mechanism
assigns
different weight parameters to different targets through
learning, so as to consider the importance of key targets
locally and globally180) to learn the graph embedding
feature (association scores) from piRNA-disease association
network. The results showed that the predicted scores of
piRNA-disease associations are positively correlated with the
association probability between a piRNA and a disease,
suggesting that piRNAs with closer distances to tumour
genes in the network are more likely to be therapeutic
targets of cancer.
2. Feature integration, which integrates the heterogeneous,
noisy,
nonlinear-related
biological
network
information
(such as node similarity, node interactions, upstream and
downstream
relationships)
multi-views
(such
as
drug
molecular structures and drugs’ indications)181. For example,
Ma et al.172 proposed a novel graph autoencoders model
(GAE) to learn accurate and interpretable drug similarity
measures from multiple types of drug properties. The GAE
uses attention mechanism180 to integrate multi-view (multi-
ple types of drug properties) from drug-drug interactions
network
and
determines
the
weights
for
each
view
with respect to the similarity measure tasks for better
explaining the contribution of drug properties to drug
similarity. Due to the ability to integrate network data from
multi-views and autoencoder structures, GAE can resist the
noise interference in the data. Thus, graph-based neural
networks are more robust and reliable in most application
scenarios182.
Overall, deep learning can comprehensively explore features
such as node degree, edge length, and module in biological
networks83–85,183 to provide an accurate prediction for drug
targets of cancer through artiﬁcial intelligence of multiomics data
in complex biology networks184. However, there are still two key
issues to be addressed. One is the interpretability of the models,
which is critical for clinical adoption185. The other is how to
demonstrate the generalizability of the approach185 and validate
these approaches in the context of multi-institutional datasets.
Therefore, these issues are actively being tackled from model
interpretation, extraction of biological insights186 and model
reproducibility187.
THE ARTIFICIAL INTELLIGENCE BIOLOGY ANALYSIS FOR
BIOMEDICAL APPLICATIONS
Because the wide and easy accessibility of high-throughput data
in oncology has provided the basis for developing novel artiﬁcial
intelligence methods and validating their capability to identify
therapeutic targets, this section will focus on reviewing the
biomedical applications from four perspectives. First, we present
the artiﬁcial intelligence applications to identify novel anticancer
targets. Second, we present the artiﬁcial intelligence applications
Fig. 8
The illustration of graph-based neural networks for ML-based biology analysis. The graph-based neural networks take the topology
of the biological networks data (such as gene-gene networks, protein-protein networks and drug-target networks) as input data. And then,
the graph-based neural network realizes the functions of link prediction, classiﬁcation and clustering by analyzing the biological information
in the network topology. (Created with BioRender.com)
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
12
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 13 (Section: Identification of novel anticancer targets)

to evaluate the druggability of potential target genes. Third, we
show the artiﬁcial intelligence applications for drug discovery.
Fourth, we show the artiﬁcial intelligence applications for drug
property prediction.
Identiﬁcation of novel anticancer targets
Artiﬁcial intelligence biology analysis applications188 usually use
omics data to build networks and identify co-expression modules
of
genes,
proteins,
metabolites,
critical
pathways
between
molecules, and key molecules in biological networks189. This
study will introduce these applications from two perspectives: one
is network-based biology analysis applications, and the other is
ML-based biology analysis applications.
Network-based artiﬁcial intelligence for identifying novel anticancer
targets.
Network-based
biology
analysis
applications
ﬁrstly
reconstruct networks by computing differential expressions of
molecules and their correlations190–193. Then, gene set enrichment
analysis are performed to identify network modules with different
biological functions194. Finally, the identiﬁed network modules are
used to discover key genes that are potential therapeutic targets
(or biomarkers) for cancer. Here, we show the key target
identiﬁcation
procedure
by
network-based
biology
analysis
applications as follows.
WGCNA195 is a commonly used network-based biology analysis
application that uses various gene expression matrices as input.
Then, WGCNA outputs different gene network modules and the
core genes in the biological network. For example, Zhou et al.196
used WGCNA to analyse colorectal cancer data from TCGA (Fig. 9),
which demonstrated that 11 hub genes and 5 hub miRNAs have
predictive power for the prognosis of colorectal cancer patients by
the following steps.
In Step 1, the correlation between all pairs of genes and miRNAs
by differential gene expression analysis was calculated, and two
similarity matrices were constructed. In Step 2, the adjacency
matrix, which comes from similarity matrices, is transformed into a
topological overlap matrix (TOM) by using TOM similarity, and
then the coexpressed gene and miRNA modules are identiﬁed by
using dynamic tree cutting197. In Step 3, after module preservation
analysis, six gene modules were found to have strong stability,
Fig. 9
The workﬂow to identify novel anticancer targets by network-based. (Created with BioRender.com)
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
13
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 14 (Section: ML-based artificial intelligence for identifying novel anticancer targets)

and one miRNA module was found to have low stability. In Step 4,
they performed module-trait relationship analysis to further
validate the module–clinical trait relationships, and two patholo-
gical stage-related gene modules and one pathological stage-
related miRNA module were identiﬁed. In Step 5, hub genes and
hub miRNAs were identiﬁed by calculating the module member-
ship and gene signiﬁcance.
Though network-based biology analysis methods are useful in
identifying anticancer targets, they have some limitations, such as
they cannot effectively handle multiomics data, leading to high
false-positive rates of identiﬁed targets42. Developing compre-
hensive network-based biology analysis applications may resolve
the problems and increase the precision for predicting cancer
biomarkers198.
For example, Lai et al.199 deployed an integrated approach that
combined network-based algorithms and RNA sequencing data to
delineate miRNA-based strategies that enhanced DC (dendritic cell)-
elicited immune responses. First, the authors performed RNA
sequencing to obtain the protein-coding genes and miRNAs in
relation
to
standard
DCs.
Then,
they
analysed
miRNA-gene
interactions at the pathway level and reconstructed regulatory
networks underlying the immunological functions of DCs. Finally,
they performed network-based prioritization of miRNAs by combin-
ing their expression proﬁles and strength of association with other
protein-coding genes. Their analysis identiﬁed dozens of promising
miRNA candidates, of which miR-15a and miR-16 are the most
promising ones for increasing the immunogenic potency of DCs and
therefore improving DC-based immunotherapy against cancer.
In summary, we consider that an increasing number of network-
based biology analysis applications will be developed for novel
anticancer targets identiﬁcation in the distant future.
ML-based artiﬁcial intelligence for identifying novel anticancer
targets.
ML-based biology network analysis applications are
applied to interrogate the large, complex data and thus iden
tifying reliable potential novel targets as effective treatments of
human diseases200. These ML-based biology analysis applications
for novel anticancer targets identiﬁcation consist of classiﬁca-
tion201, clustering202, neural networks203,204, and so on205. Here,
due to the limit space of the review, we only focus on the ML-
based biology network analysis applications for classiﬁcations and
graph-based neural networks.
ML-based biology network analysis applications for classiﬁcations
identify key targets by determining the key factors of classiﬁca-
tions206. It considers speciﬁc biomarkers (such as gene or protein
nodes) of the deﬁned classes as key targets206. Recently, the
classiﬁcation-based applications and molecular proﬁling207, use
genome-wide gene transcription proﬁles, protein expression proﬁles
and/or mutational landscapes to make a more accurate classiﬁcation
of tumor subtypes and identify biomarkers for speciﬁc tumor types.
For example, Sinkala et al,208 applied classiﬁcation analysis on
networks to reveal subtypes of pancreatic cancer and their
molecular characteristics. Firstly, the authors employed K-means
clustering to the reverse phase protein array (RPPA), determined
proteomics data with 45 high-purity pancreatic cancer samples, and
then identiﬁed two clusters of samples.
Secondly, they compared their clustering results to other
subtypes that have been reported in the literature for various
other molecular data types (such as DNA methylation status,
protein expression levels and expression levels of mRNAs and
miRNAs), and then applied the similarity network fusion (SNF) to
identify two-cluster and three-cluster solutions comprised 25 and
20 tumors. The SNF method solves the disparate clustering problem
by constructing similarity networks of samples for each available
molecular data type and then efﬁciently fuses these into one
network that represents clustering based on all the underlying data.
Thirdly,
they
applied
proteomics-based
signaling
pathway
analysis to distinguish disease subtypes and found that, for tumors
of the two major pancreatic cancer subtypes, oncogenesis may be
primarily driven by perturbation in either SMAD4 or mTOR signaling
pathways. Furthermore, they performed gene set enrichment
analysis using the Gene Ontology database52 and found that
pancreatic cancer subtypes classiﬁed by mRNA expression levels
and DNA methylation statuses show differences in molecular
functions in terms of mRNA.
Finally, given that different types of molecular data yield different
patterns of tumor clustering, they attempted to identify a list of
biomarkers that can differentiate the two tumor subtypes. Using
neighborhood component analysis, they identiﬁed biomarker sets
comprising 50 mRNAs, 49 methylated genes, 14 proteins, and 20
miRNAs. Subsequently, they separately applied hierarchical cluster-
ing using each type of the molecular data and successfully
reproduced the two pancreatic cancer subtypes.
For graph-based neural networks, they take advantage of not
only making use of the correlation among samples described by
similar networks, but also message passing between targets and
neighbors to improve the accuracy of targets identiﬁcation209.
For example, to the best of our knowledge, the MOGONET
proposed by Wang et al.203 is the ﬁrst to make use of both graph
convolution networks (GCNs) and cross-omics relationships in the
label space for effective multiomics integration in biomedical data
classiﬁcation tasks. The speciﬁc process is as follows:
Firstly, they constructed a weighted sample similarity network for
each type of omics data using cosine similarity. Taking both the
omics features and the corresponding similarity network as the input,
a GCN is trained for each type of omics data to predict class labels.
Secondly, the predictions generated by each omics data-
speciﬁc GCN are further utilized to construct a new tensor,
named cross-omics discovery tensor, which can reﬂect the cross-
omics label correlations.
Finally, the cross-omics discovery tensor is forwarded to VCDN
(view correlation discovery network) to explore the latent
correlations across different omics data for ﬁnal label prediction.
Because the importance of a feature to the classiﬁcation task can
be measured by the performance decrease after removing
individual features. Therefore, they used this method on the test
data set to quantify and rank the contribution of each feature of
different omics data to the prediction. Using the method, they
identiﬁed top-ranking features as biomarkers for breast cancer.
In addition, Xuan et al.204 proposed a novel method based on
the graph convolutional network and convolutional neural
network (GCNLDA) to infer disease-related lncRNA candidates.
First, they developed a network that is comprised of lncRNA,
disease, and miRNA nodes. Then, they developed an embedding
matrix of lncRNA-disease node pairs with respect to the
biological premises. Then, they employed a convolutional neural
network to explore various connections related to lncRNA-
disease on node pair embedding. Finally, they learned the local
network representations of lncRNA-disease pairs by deeply
integrating the graph convolution autoencoder into topological
lncRNA-disease-miRNA
heterogeneous
networks.
Cross-
validation conﬁrmed that GCNLDA outperforms other state-of-
the-art methods in terms of both AUC and AUPR161. Case
studies204 on stomach cancer, osteosarcoma and lung cancer
conﬁrmed that GCNLDA effectively discovered potential lncRNA-
disease
associations.
Therefore,
GCNLDA
is
becoming
an
effective tool to screen reliable candidates for lncRNA-disease
association validation with the help of biological experiments.
In summary, we consider that an increasing number of ML-
based biology analysis applications will be developed to identify
novel anticancer targets with the development of deep learning
in the future.
Evaluation of the druggability of potential targets
Druggability is a concept that assesses whether a drug can bind
to a protein to alter its activity3,4. The human proteome has
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
14
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 15 (Section: Network-based artificial intelligence for evaluating the druggability of potential targets)

approximately 6,000 to 8,000 potential pharmacological targets,
but only a small fraction can be targeted by drugs7,210.
Therefore, it is important for us to evaluate druggability after
ﬁnding novel anticancer targets. This study will introduce these
applications from two perspectives: one is network-based
biology analysis applications, and the other is ML-based biology
analysis applications.
Network-based artiﬁcial intelligence for evaluating the druggability
of
potential
targets.
The
druggability
evaluating
approach
requires a long development cycle and high ﬁnancial cost for
the 3D structures of protein analysis211, while network-based
biology analysis application provides an alternative methods to
accelerate the evaluation procedure for the druggability of
potential targets212.
Described by Fig. 10, PockDrug is a novel web server that is
employed to predict pocket druggability on proteins and queried
for a protein or a set of proteins213. For example, Yang et al.214
constructed a protein–protein interaction network for thyroid
cancer and identiﬁed three key targets, HEY2, TNIK, and LRP4.
Then, they used PockDrug to predict whether HEY2, TNIK, or LRP4
have targetable pockets for drugs in the following three steps.
In Step 1, they inputted the potential target and located
pocket estimation methods. In Step 2, they predicted the
druggability of the pockets by computing the physicochemical
properties of the target pockets. In Step 3, they screened three
hub genes, HEY2, TNIK, and LRP4. Based on the predictions, TNIK,
which has 8 out of 538 residues, has an average druggability
probability
greater
than
0.5
and
thus
was
considered
a
druggable pocket for thyroid cancer.
In short, with the in-depth study of protein pocket, an
increasing number of network-based biology analysis applica-
tions are developed to accurately evaluate the druggability of
anticancer targets, providing reliable druggable targets for
cancer treatment.
ML-based artiﬁcial intelligence for evaluating the druggability of
potential targets.
These ML-based biology analysis applications
for evaluating the druggability of potential targets consist of
protein structure modeling and drug-target afﬁnity analysis.
Previously, traditional analysis of protein structure modeling
required considerable time and ﬁnancial cost211, which greatly
limited the traditional application of PockDrug since it is heavily
dependent on an accurate 3D protein structure. Recent ML-based
biology
analysis
applications
have
focused
on
developing
methods to predict the 3D structure of a protein from its genetic
sequence, also known as the protein folding problem. The cutting-
edge ML-based modelling method215–217 can generate 3D protein
structures with high accuracy and efﬁciency, which makes it
possible for PockDrug to be widely used.
For example, Yang et al.218 developed the trRosetta algorithm,
which fast and accurately predicts protein structures based on
energy minimizations with restrained trRosetta. They employ a
deep residual neural network to predict the restrained trRosetta,
which consists of inter-residue distance and orientation distribu-
tions. Since trRosetta outperforms all previously protein modelling
methods in benchmark tests on CASP13-219 and CAMEO-220
derived sets, it turns out that trRosetta can accurately predict
protein structure. Furthermore, Senior et al.221 developed Alpha-
fold to predict protein structures from amino acid sequences. First,
Alphafold predicts the distances between pairs of residues by
training a neural network to analyse the covariation of homo-
logous sequences. Then, Alphafold constructs a potential mean
force that accurately describes the shape of a protein. Finally,
Alphafold optimizes the protein structure by a gradient descent
algorithm. Because AlphaFold can predict protein structure with
high accuracy even for such sequences with fewer homologous
sequences, we consider that AlphaFold makes great progress in
protein-structure prediction.
ML-based biology analysis applications for drug-target afﬁnity
(DTA) analysis application estimates the interaction strength of
Fig. 10
The workﬂow to evaluate the druggability of potential target proteins. (Created with BioRender.com)
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
15
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 16 (Section: Drug discovery)

novel drug–target pairs based on previous studies to evaluate the
druggability of targets222.
Compared with other methods, such as molecular docking223
and collaborative ﬁltering224, graph-based neural networks are
more effective in DTA prediction, because graph-based models
facilitate the learning by considering both drug structure and
drug-target interaction information instead of representing the
drugs as string, as string sequences may lose the structural
information of the molecule and may impair the predictive power
of models225.
For example, Nguyen et al.225 is the ﬁrst to use GNN for
predicting DTA. The authors proposed GraphDTA, a new neural
network model for regression tasks, which takes the drug-target
pair as the input and outputs the continuous measurement of the
binding afﬁnity of the pair.
In detail, for the input drug-target pair, the protein targets are
represented as sequence information instead of the molecular
diagram of tertiary structure. While the drug compounds are
represented as network graphs of atomic interaction, where each
node is an eigenvector that represents ﬁve kinds of information: the
atom symbol, the number of adjacent atoms, the number of adjacent
hydrogens, the implicit value of the atom, and whether the atom is in
an aromatic structure. For the output, GraphDTA combined the drug-
target pair feature information to predict the continuous measure-
ment of the binding afﬁnity of the drug-target pair.
Through a multivariable statistical analysis of GraphDTA’s output
data from hidden layers, the authors have two conclusions. One is to
identify the correlations between hidden node activations and
domain-speciﬁc drug annotations, such as the number of aliphatic
hydroxyl groups, which suggests that the graph neural network can
automatically assign importance to well-deﬁned chemical features
without any prior knowledge. The other is that the model makes it
easier to extract features from drugs with obvious molecular
structure patterns to achieve high-precision predictions. Especially,
drugs that do not have an obvious molecular structure pattern are
more difﬁcult to predict.
In short, with the development of deep learning, an increasing
number of ML-based biology analysis applications can quickly and
accurately evaluate the druggability of anticancer targets, providing
reliable druggable targets for cancer treatment and reducing the
time and ﬁnancial costs of experiments.
Drug discovery
After evaluating the druggability of potential targets, it is essential
to discover the drugs that interact with the potential therapeutic
targets. As complex or concomitant diseases may usually require
treatment with multiple drugs, but the use of multiple drugs will
increase the risk of side effects200, it is very essential for drug
discovery to predict the interactions between drug-target and
drug-drug.
This study will introduce these applications from two perspec-
tives as the above section: one is network-based biology analysis
applications,
and
the
other
is
ML-based
biology
analysis
applications.
Network-based artiﬁcial intelligence for drug discovery.
These
network-based analysis applications for drug discovery consist of
drug screening and drug repurposing. Drug screening is a process
that potential drugs are identiﬁed and optimized before selecting
a candidate drug to progress to clinical trials226. Since screening
drugs through biological experiment is quite laborious, expensive,
and time-consuming226, network-based biology analysis applica-
tion becomes an alternative way for efﬁciently drugs screening.
Identifying drug-target interactions (DTIs) is crucial for drug
screening. Especially, novel DTIs can be employed to look for the
novel anticancer drugs with known targets227.
The
network-based
biology
analysis
applications
for
DTI
prediction are usually based on guilt-by-association principle that
a protein may be a target for a drug if many of the protein’s
neighbors in the interaction network are targets of the drug228.
Based on this principle, we classify the network-based biology
analysis applications for predicting DTI into two categories.
One is ‘top-down’, which is from observable characteristics, such
as side-effects or the diseases treated by a drug, to the interaction.
For example, Campillos et al.229 used the physiological effect
information from side effect similarity networks between entities
for DTI prediction to predict whether two molecules could
interact.
The other is ‘bottom-up’, which is from molecular features, such
as protein structure, to interactions. For example, Feng et al.230
and Lee et al.231 predicted DTI based on the proteins in protein-
protein interaction networks with similar property features that
may interact with the same drug.
Drug repurposing, also known as drug repositioning, is another
drug discovery application. It refers to a method that identiﬁes
new indications for approved drugs or drug candidates which
have failed in the development phase232. Compared to the drug
screening process, since drug repurposing can signiﬁcantly reduce
the drug development period and costs233, it is a better
application to discover anticancer drugs.
The network-based biology analysis applications are efﬁcient to
carry out drug repurposing analysis, because the constructed drug
similarity networks contain the similarity, interaction or linkages
between drugs, diseases, and targets. Here, we introduce four
major
network-based
biology
analysis
applications
of
drug
repurposing234–241 as follows.
The ﬁrst network-based biology analysis application of drug
repurposing quantiﬁes the similarities or relationships for known
drug-disease associations, and then uses regression models or
statistical models to predict novel drug-disease associations234,235.
For example, Cheng et al.242 presented a network-based drug
repurposing tool, which can accurately predicts drug responses in
cancer cell lines by integrating human protein-protein inter-
actome with transcriptome proﬁles, whole-exome sequencing,
drug-target interactions and drug-induced microarray data.
The second network-based biology analysis application of drug
repurposing infers new indications of drugs through analyzing
information ﬂow or performing random walks on drug-disease
association networks236–238. For example, Luo et al.243 proposed a
novel random walk method to measure the similarity of drugs and
diseases respectively by the drugs properties and diseases
properties, so as to predict potential indications of drugs.
The third network-based biology analysis application of drug
repurposing, named individualized Network-based Co-Mutation,
quantiﬁes putative genetic interactions in cancer and it can be
used to identify candidate therapeutic pathways for cancer239. For
example, Cheng et al.244 used the approach to identify potential
targets or new indications of existing cancer drugs that directly
target signiﬁcantly mutated genes or their neighbor genes in the
human PPI interaction network.
The fourth network-based biology analysis application of drug
repurposing can be realized directly through calculating the
adjacency matrix of drug and disease network240,241. Based on this
method, Luo et al.245 utilized the matrix completion algorithm to
ﬁlls out the unknown entries in the drug–disease matrix by
constructing a low-rank matrix approximation. New drug–disease
associations will be screened by the predicted ﬁll value.
Taken
together,
the
network-based
drug
screening
and
repurposing applications provide researchers a lot of alternative
approaches for quickly anticancer drugs discovery.
ML-based artiﬁcial intelligence for drug discovery.
Currently, ML-
based biology analysis applications have been employed to carry
out drug screening and drug repurposing. For drug screening,
previous studies have shown that network-based biology analysis
applications can only screen the neighbour proteins of known
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
16
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 17 (Section: Drug discovery)

targets, while drug-protein interactions may dysregulate the
targets’ interacting neighbours227 resulting in high false positive
prediction results. ML-based biology analysis applications, such as
graph-based neural network, have the advantage of integrated
features that combine both ‘bottom-up’229 and ‘top-down’230
approaches to reduce the high false positive prediction results.
For example, Hinnerichs et al.227 developed the DTI-Voodoo
that combines molecular features and phenotypes information
with an interaction network using graph neural networks to
predict drug-protein interactions (Fig. 11).
Firstly, the model takes the two features, phenotypes features
and molecular features, as input. To extracted phenotypes
features,
they
utilized
DL2Vec246
to
obtain
ontology-based
representations. DL2vec constructs a PPI network by introducing
nodes for each ontology class and edges for ontology axioms,
followed by random walks starting from each node in the graph to
generate representations that enable encoding drug effects or
protein functions while preserving their semantic neighborhood
within that graph. To extract molecular features, they utilized
SmilesTransformer247 to capture the molecular organization of
each drug from molecular structures of drugs and utilized
DeepGOPlus248 to capture protein molecular features from protein
amino acid sequences.
Secondly, they used two learnable feature transformer models
to
investigate
the
latent
relationship
between
phenotypes
features
and
molecular
features.
According
to
relationship
information, the transformer model, which input the phenotypes
features, will output the protein embedding for PPI networks (the
top-down approach), and the other transformer model, which
input the molecular features, will output drug embedding (the
bottom-up approach).
Finally, a DNN was used to extract similar information related to
protein from drug embedding, while a GCN is used to update the
nodes embedding in PPI networks. Then both protein features and
both drugs’ features are combined to calculate the similarity by
cosine similarity. Since DTI-Voodoo performs well, it demonstrated
that graph-based neural networks are good at identifying novel
drug-protein interactions.
For drug repurposing, graph-based neural networks take the
advantage of feature representation, which can not only utilize the
drug-drug links information, but also the features between drug-
cancer pairs.
Fig. 11
The graph-based neural network for DTI prediction by combining both bottom-up and top-down biology analysis approaches.
(Created with BioRender.com)
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
17
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 18 (Section: Drug properties prediction)

For example, Cui et al.249 proposed GraphRepur, a model for
drug repurposing prediction based on graph neural networks.
Firstly, the authors collected the drug-induced gene expression
data from the LINCS project250 as well as the drug-drug links
information from the STITCH database251. Secondly, to obtain the
signature of drugs, they identiﬁed differentially expressed genes
for breast cancer and used the drug-induced genes from LINCS as
drug signatures. Thirdly, based on the drug-drug links information
from the STITCH database and drug signatures, they constructed a
drug-drug links graph with drug signatures as node features.
Fourthly, they input drug signatures and drug-drug links informa-
tion into GraphRepur, and then the model computes scores for
drugs that can be repurposed for treating breast cancer. Finally,
the authors validated some predictive drugs for breast cancer
using experimental data from the literature and showed that the
model has signiﬁcantly better performances than others, such as
GCN, DNN, and random forest, in drug repurposing. using
published studies.
Furthermore, the authors summarize three conclusions. The
ﬁrst conclusion is that the drug-drug links information plays an
important role in studying drug repurposing. The second
conclusion is that if such a network with fewer isolated nodes
can provide a lot of network topology information, it will
signiﬁcantly improve the prediction performance of graph
neural networks. The third is that the drug-induced genetic
feature help to improve the DTI prediction accuracy of graph
neural network.
Taken together, with the development of graph-based neural
networks, an increasing number of ML-based drug screening
and
repurposing
applications
can
quickly
and
accurately
discover anticancer drugs, reducing the time and ﬁnancial
costs of experiments.
Drug properties prediction
ADMET properties prediction.
As discussed in section 4.3 (drug
discovery step), after we have a list of drug molecules showing
high afﬁnity with the therapeutic target, it is necessary to
investigate the properties of these candidates’ drugs252–255. Since
the prediction of drug properties usually adopts the ML-based
methods, this study mainly reviews the ML-based biology analysis
applications for drug properties prediction such as the absorption,
distribution, metabolism, excretion, and toxicity (ADMET) proper-
ties of chemical compounds256. Table 5 brieﬂy described the
ADMET properties.
ADMET properties prediction can be considered as a classiﬁca-
tion or regression problem. Because of the strong ability of feature
representation177, graph-based neural networks can capture the
drug descriptors (the physicochemical properties, molecular
representations, and drug-like properties of molecules) from the
drug ﬁngerprints (the substructure features of a molecule)257, so
as to predict ADMET properties by classiﬁcation or regression
algorithm (Fig. 12)258.
For example, Duvenaud et al.259 proposed a graph convolution
network to learn drug molecular ﬁngerprints, which shows better
performance than the state-of-the-art circular ﬁngerprint method
for ADMET properties prediction. After that, more and more
scientists have used graph-based neural networks to predict the
ADMET properties of drug molecules.
For example, Liu et al.171 proposed Chemi-Net, which utilizes
GCN for ADMET properties prediction. They set the characteriza-
tion of the atoms of the drug molecule and the relationship
between atoms as the input of the Chemi-Net, while the output of
Chemi-Net is the ADMET properties prediction of drug molecules.
The predictive process of Chemi-Net is as follows.
Firstly, the model projects the assembling of the atoms and
atom pair descriptors (features between atomic pairs)257 onto a 3D
space
to
obtain
a
drug
molecule-shaped
graph
structure.
Secondly, Chemi-Net carries out a series of graph convolution
operations to output a single ﬁxed-sized molecule embedding.
Finally, they obtain accurate ADMET properties predictions of
drugs after passing the molecule embedding representation
through fully connected layers.
In summary, we consider that more artiﬁcial intelligence models
for drug properties prediction will be developed in the distant
future.
The drug properties application in clinical trial.
Since there have
been a large number of applications based on artiﬁcial intelligence
to study the properties of drugs, it still takes on average 10–15
years and 1.5–2.0 billion to bring a new drug to market260. One of
the main stumbling blocks is the high failure rate of clinical trials.
Therefore, some research are committed to the application of
artiﬁcial intelligence for clinical trial design.
For example, Shah et al261 construct an artiﬁcial intelligence
system that made use of the ‘self-learning’ deep reinforcement
learning technology to looks at treatment regimens currently in
use, and iteratively adjusts the doses. Therefore, the system can
determine the fewest, smallest doses that could still shrink brain
tumors, reduce toxicity and eventually ﬁnd an optimal treatment
plan with the lowest possible potency and frequency of doses that
should still reduce tumor sizes to a degree comparable to that of
traditional regimens. In simulated trials of 50 patients, the system
designed treatment cycles that reduced the potency to less than a
half of all the doses while maintaining the same tumor-shrinking
potential.
In conclusion, we believe that with the development of artiﬁcial
intelligence applications for drug property prediction, these
applications will provide better help for clinical trial.
DISCUSSION AND CONCLUSIONS
Modelling of cellular networks underlying cancer has provided us
with a quantitative framework to investigate the link between
network properties and the disease by artiﬁcial intelligence
biology analysis, thereby leading to the discovery of potential
novel anticancer targets and drugs23–29. However, there is no
systematic review that introduces artiﬁcial intelligence biology
analysis in cancer target identiﬁcation and drug discovery. For this
reason,
this
study
brieﬂy
reviewed
the
scope
of
artiﬁcial
intelligence
biology
analysis
to
explore
new
anticancer
Table 5.
The brief description of the ADMET properties256
Property
Description
Absorption
The ability of a drug that cross membranes of many cell to reach its site of action, when drug is administered via oral ingestion.
Distribution After absorption or systemic administration into the bloodstream, a drug is distributed to its site of action through the circulatory
systems.
Metabolism The process of chemically converting a drug to a metabolite is called metabolism or biotransformation.
Excretion
The collective term used for irreversibly removing a drug from the body
Toxicity
The extent to which a drug damages an entire organism, an organism’s substructure, or an organ.
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
18
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 19 (Section: Drug properties prediction)

targets34,54,57,74,80, the principles and theory of commonly used
artiﬁcial intelligence biology analysis algorithms83–91, and the
artiﬁcial intelligence applications for artiﬁcial intelligence biology
analysis42,195,213.
The scope of artiﬁcial intelligence analysis to explore novel
anticancer targets consists of epigenetics54, genomics57, proteo-
mics74, metabolomics34, etc. Since it is not accurate to have
anticancer targets by single omics studies, we have to employ
artiﬁcial intelligence biology analysis to effectively integrate
multiple omics data and tackle the complexity of cancer that
arises from interactions between genes and their products16,17
and improve our understanding of carcinogenesis23–29. Therefore,
how to employ artiﬁcial intelligence biology analysis algorithms to
integrate multiomics data and identify novel anticancer targets
will be an important future study direction.
Next, we introduced two categories of commonly used artiﬁcial
intelligence algorithms. One is network-based biology analysis
algorithms and the other is ML-based biology analysis algorithms.
We here discuss their limitations and advantages.
The network-based biology analysis algorithms usually are
comprised of shortest path83, module detection84 and network
centrality85, which have three major advantages: First, they
provide a variety of alternative approaches to identify cancer
targets, and different algorithms can compensate each other to
identify targets from various perspectives, therefore providing
new biological explanations30; Second, since they are not limited
by the scale of the network, they are good at dealing with the case
of small sample network; Third, prior biological knowledge and
experience could be conveniently integrated into network-based
biology analysis algorithms to make them interpretable.
However, previous studies also show two major shortcomings
for the network-based algorithms: First, the current biological
network data are biased toward much-studied targets262. Since
previous studies have paid much attention to these targets, the
network-based algorithms will more likely identify these well-
studied targets than others due to the data bias262. Second, most
algorithms only use the topological information of the biological
network, but neglect the association between cell function or
phenotypes and topological features (such as centrality-based
algorithms that are discussed in Section 3.1.2).
ML-based biology analysis algorithms are usually comprised
of decision trees86–88 and deep learning89–91, which have two
major advantages.
One is feature learning and detection177,181, which employ
sophisticated neural network architectures to link up features of
biological networks and characterize their relationships. Subsequently,
they iteratively train the model to detect such features that are hard
to be detected by network-based biology analysis algorithms.
The other is their ability to effectively integrate large and
diverse data. It is possible for ML-based networks biology analysis
algorithms to integrate multiomics biological network data and
identify novel targets263, because of the fast development of deep
learning
models
and
the
easy
access
to
high-throughput
biological.
Although employing ML-based algorithms greatly beneﬁts the
target identiﬁcation and drug discovery for cancer treatment174,
we still have three major challenges to overcome.
The ﬁrst challenge is the lack of consistent data for validation33.
Although the recent advances in biotechnologies have enabled
the fast generation of massive biomedical data, such data often
suffer from inconsistency in production and information missing
in annotation, resulting in the lack of reliable and consistent data
for validating deep learning models264.
The second challenge is the integration of heterogeneous
information103. Although deep learning models facilitate the
integration of multimodal biological data, it is still difﬁcult to
build up a universal deep learning model due to the lack of
biological domain knowledge200.
The third challenge is hard to provide interpretability of deep
learning models185. However, a recent study sheds a light to
resolve the issue through a combination of a disease network with
a neural network to characterize the mechanism of melanoma263.
In addition, graphs-based neural networks can improve the
interpretability of deep learning models265.
In the last section of the study, we have reviewed the
applications of artiﬁcial intelligence biology analysis for cancer
therapy from four perspectives: novel anticancer targets identiﬁ-
cation189, evaluating the druggability of potential targets3,4, drug
discovery200, and drug properties prediction252–255.
First, we presented several widely used applications to identify
novel anticancer targets. However, exempliﬁed by WGCNA195,
these network-based biology analysis applications not only
requires
high
computing
costs
to
reconstruct
gene
co-
expression networks42 but also has difﬁculty in accurately locating
effective network nodes. Although ML-based biology analysis
applications employ collaborative modelling by neighbourhood
nodes information to reduce the computational cost and improve
the predictive accuracy for anticancer targets, biological networks
still have data bias262, resulting in most of the identiﬁed targets by
current applications already have been reported in previous
studies. Therefore, how to develop such an efﬁcient feature
selection application that can solve the data bias problem will be
appealing for novel therapeutic anticancer target identiﬁcation266–
268 in the distant future.
Second, we introduce several widely used applications to
evaluate the druggability of potential targets. For example,
PockDrug is usually used to predict druggable pockets on
proteins213. Although trRosetta218 and Alphafold221 offer oppor-
tunities for Pockdrug to evaluate the pharmaceuticals of potential
targets, Pockdrug neither accurately predicts druggability due to
the complexity of protein structure269–271 nor costs low efforts to
validate through biological experiments272,273. Nevertheless, since
DTA prediction can quickly provide reliable druggable targets for
cancer care with low ﬁnancial costs211, it is potential to develop
Fig. 12
The graph-based neural network capture the features related to drug properties from drug molecular structure to predict ADMET
properties of drugs. (Created with BioRender.com)
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
19
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 20 (Section: Author contributions)

the related efﬁcient artiﬁcial intelligence biology analysis applica-
tions for DTA prediction in the distant future.
Third, we investigated several widely used applications for drug
discovery, which consists of drug screening and drug repurposing.
For drug screening, identifying drug-target interactions (DTIs) is
a crucial step. Since network-based biology analysis applications
for DTI prediction are usually based on the guilt-by-association
principle228, it can only predict the interacting neighbors of known
cancer targets. Currently, ML-based biology analysis applications
can extend the predictions to downstream consequences227,
thereby screening out more possible anticancer drugs.
For drug repurposing232, there are four commonly used network-
based biology analysis applications234–241 that integrate the
similarities among various drugs but ignore prior knowledge.
However, ML-based biology analysis applications not only can take
advantage of the similarity among drugs, but also can integrate
drug properties to improve the accuracy of drug repurposing.
Fourth, we introduce widely used applications for drug properties
prediction. For example, graph convolution networks, which have a
strong ability of feature representation177, can capture the features
related to ADMET properties of drugs from their molecular
structures. Therefore, it is becoming a popular method to predict
drug properties by integrating drug molecular structures and drug
clinical phenotype for drug properties prediction through graph
convolution networks274. Here, we wish once more and more
artiﬁcial intelligence biology analysis models are developed to
capture the features related to ADMET properties from the drug
molecular structure, to improve the success rate of clinical trials.
In summary, although we have reviewed and discussed many
artiﬁcial intelligence algorithms and corresponding applications
for novel anticancer target identiﬁcation and drug discovery, this
review is still too brief to cover the entire research area. However,
because artiﬁcial intelligence algorithms are effective in exploring
new anticancer targets and discovering drugs, we wish this review
could offer valuable enlightenments for interested researchers to
develop an understanding of the principles behind artiﬁcial
intelligence biology analysis in cancer target identiﬁcation and
drug discovery. Moreover, we wish that our perspective on
artiﬁcial intelligence and related applications will provide the
pathway for further advancement in the ﬁeld.
AUTHOR CONTRIBUTIONS
Y.Y. and X.L. contributed equally to this work. Y.Y., X.L., Y.P., H.Z., J.V., S.L., S.D. and L.Z.
contributed to writing and revising the paper. X.L., S.D., and L.Z. supervised the
research. All authors have read and approved the article.
ADDITIONAL INFORMATION
Competing interests: The authors declare no competing interests.
REFERENCES
1. Shabani, M. & Hojjat-Farsangi, M. Targeting receptor tyrosine kinases using
monoclonal antibodies: the most speciﬁc tools for targeted-based cancer
therapy. Curr. Drug Targets 17, 1687–1703 (2016).
2. Paananen, J. & Fortino, V. An omics perspective on drug target discovery plat-
forms. Brief. Bioinform 21, 1937–1953 (2019).
3. Hopkins, A. L. & Groom, C. R. Opinion: The druggable genome. Nat. Rev. Drug
Discov. 1, 727–730 (2002).
4. Bushweller, J. H. Targeting transcription factors in cancer—from undruggable to
reality. Nat. Rev. Cancer 19, 611–624 (2019).
5. Colaprico, A. et al. Interpreting pathways to discover cancer driver genes with
Moonlight. Nat. Commun. 11, 69 (2020).
6. Dugger, S. A., Platt, A. & Goldstein, D. B. Drug development in the era of pre-
cision medicine. Nat. Rev. Drug Discov. 17, 183–196 (2018).
7. Manzari, M. T. et al. Targeted drug delivery strategies for precision medicines.
Nat. Rev. Mater. 6, 351–370 (2021).
8. Rosenblum, D., Joshi, N., Tao, W., Karp, J. M. & Peer, D. Progress and challenges
towards targeted delivery of cancer therapeutics. Nat. Commun. 9, 1410 (2018).
9. Song, H. et al. Denoising of MR and CT images using cascaded multi-supervision
convolutional neural networks with progressive training. Neurocomputing 469,
354–365 (2022).
10. Zhang, L. et al. MCDB: a comprehensive curated mitotic catastrophe database
for retrieval, protein sequence alignment, and target prediction. Acta Pharm. Sin.
B 11, 3092–3104 (2021).
11. Gao, J., Liu, P., Liu, G. D. & Zhang, L. Robust needle localization and enhance-
ment algorithm for ultrasound by deep learning and beam steering methods. J.
Comput. Sci. Technol. 36, 334–346 (2021).
12. Liu, G. D., Li, Y. C., Zhang, W. & Zhang, L. A brief review of artiﬁcial intelligence
applications and algorithms for psychiatric disorders. Eng.-Prc 6, 462–467 (2020).
13. Zhang, L., Bai, W., Yuan, N. & Du, Z. Comprehensively benchmarking applications
for detecting copy number variation. PLoS Comput. Biol. 15, e1007069 (2019).
14. Zhang, L. & Zhang, S. Using game theory to investigate the epigenetic control
mechanisms of embryo development: Comment on: “Epigenetic game theory:
How to compute the epigenetic control of maternal-to-zygotic transition” by
Qian Wang et al. Phys. Life Rev. 20, 140–142 (2017).
15. Zhou, Y., Wang, F., Tang, J., Nussinov, R. & Cheng, F. Artiﬁcial intelligence in
COVID-19 drug repurposing. Lancet Digit. Health 2, e667–e676 (2020).
16. Suhail, Y. et al. Systems biology of cancer metastasis. Cell Syst. 9, 109–127 (2019).
17. Barabási, A.-L. & Oltvai, Z. N. Network biology: understanding the cell’s func-
tional organization. Nat. Rev. Genet. 5, 101–113 (2004).
18. Lv, J., Deng, S. & Zhang, L. A review of artiﬁcial intelligence applications for
antimicrobial resistance. Biosaf. Health 3, 22–31 (2021).
19. Wu, W. et al. Exploring the dynamics and interplay of human papillomavirus and
cervical tumorigenesis by integrating biological data into a mathematical
model. BMC Bioinform. 21, 152 (2020).
20. Xiao, M. et al. 2019nCoVAS: developing the web service for epidemic trans-
mission prediction, genome analysis, and psychological stress assessment for
2019-nCoV. IEEE/ACM Trans. Comput. Biol. Bioinform. 18, 1250–1261 (2021).
21. Xiao, M., Yang, X., Yu, J. & Zhang, L. CGIDLA: developing the web server for CpG
island related density and LAUPs (Lineage-Associated Underrepresented Per-
mutations) study. IEEE/ACM Trans. Comput Biol. Bioinform 17, 2148–2154 (2020).
22. Zhao, J., Cao, Y. & Zhang, L. Exploring the computational methods for protein-
ligand binding site prediction. Comput. Struct. Biotechnol. J. 18, 417–426 (2020).
23. Chen, Y. et al. Variations in DNA elucidate molecular networks that cause dis-
ease. Nature 452, 429–435 (2008).
24. Hu, J. X., Thomas, C. E. & Brunak, S. Network biology concepts in complex
disease comorbidities. Nat. Rev. Genet. 17, 615–629 (2016).
25. Ideker, T. & Nussinov, R. Network approaches and applications in biology. PLoS
Comput. Biol. 13, e1005771 (2017).
26. Lai, X. et al. MiR-205-5p and miR-342-3p cooperate in the repression of the E2F1
transcription factor in the context of anticancer chemotherapy resistance.
Theranostics 8, 1106 (2018).
27. Lai, X., Eberhardt, M., Schmitz, U. & Vera, J. Systems biology-based investigation
of cooperating microRNAs as monotherapy or adjuvant therapy in cancer.
Nucleic Acids Res. 47, 7753–7766 (2019).
28. Seyfried, N. T. et al. A multi-network approach identiﬁes protein-speciﬁc co-
expression in asymptomatic and symptomatic Alzheimer’s disease. Cell Syst. 4,
60–72.e64 (2017).
29. Vidal, M., Cusick, Michael, E. & Barabási, A.-L. Interactome networks and human
disease. Cell 144, 986–998 (2011).
30. Chen, L. & Wu, J. Bio-network medicine. J. Mol. Cell Biol. 7, 185–186 (2015).
31. Ghanat Bari, M., Ung, C. Y., Zhang, C., Zhu, S. & Li, H. Machine learning-assisted
network inference approach to identify a new class of genes that coordinate the
functionality of cancer networks. Sci. Rep. 7, 6993 (2017).
32. Muzio, G., O’Bray, L. & Borgwardt, K. Biological network analysis with deep
learning. Brief. Bioinform. 22, 1515–1530 (2021).
33. Camacho, D. M., Collins, K. M., Powers, R. K., Costello, J. C. & Collins, J. J. Next-
generation machine learning for biological networks. Cell 173, 1581–1592
(2018).
34. Johnson, C. H., Ivanisevic, J. & Siuzdak, G. Metabolomics: beyond biomarkers and
towards mechanisms. Nat. Rev. Mol. Cell Biol. 17, 451–459 (2016).
35. Hasin, Y., Seldin, M. & Lusis, A. Multi-omics approaches to disease. Genome Biol.
18, 1–15 (2017).
36. Kim, H. & Kim, Y.-M. Pan-cancer analysis of somatic mutations and tran-
scriptomes reveals common functional gene clusters shared by multiple cancer
types. Sci. Rep. 8, 6041 (2018).
37. Vinayagam, A. et al. Controllability analysis of the directed human protein
interaction network identiﬁes disease genes and drug targets. Proc. Natl Acad.
Sci. USA 113, 4976–4981 (2016).
38. do Valle, Í. F. et al. Network integration of multi-tumour omics data suggests
novel targeting strategies. Nat. Commun. 9, 1–10 (2018).
39. Yang, K. et al. A comprehensive analysis of metabolomics and transcriptomics in
cervical cancer. Sci. Rep. 7, 43353 (2017).
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
20
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 21 (Section: Author contributions)

40. Hamosh, A., Scott, A. F., Amberger, J. S., Bocchini, C. A. & McKusick, V. A. Online
Mendelian Inheritance in Man (OMIM), a knowledgebase of human genes and
genetic disorders. Nucleic Acids Res. 33, D514–D517 (2005).
41. Casparie, M. et al. Pathology databanking and biobanking in The Netherlands, a
central role for PALGA, the nationwide histopathology and cytopathology data
network and archive. Cell Oncol. 29, 19–24 (2007).
42. Wishart, D. S. et al. DrugBank 5.0: a major update to the DrugBank database for
2018. Nucleic Acids Res. 46, D1074–D1082 (2017).
43. Wang, Y. et al. Therapeutic target database 2020: enriched resource for facil-
itating research and early development of targeted therapeutics. Nucleic Acids
Res. 48, D1031–D1041 (2019).
44. Wang, Y. et al. PubChem: a public information system for analyzing bioactivities
of small molecules. Nucleic Acids Res. 37, W623–W633 (2009).
45. Gaulton, A. et al. ChEMBL: a large-scale bioactivity database for drug discovery.
Nucleic Acids Res. 40, D1100–D1107 (2011).
46. Edgar, R., Domrachev, M. & Lash, A. E. Gene Expression Omnibus: NCBI gene
expression and hybridization array data repository. Nucleic Acids Res. 30,
207–210 (2002).
47. McLendon, R. et al. Comprehensive genomic characterization deﬁnes human
glioblastoma genes and core pathways. Nature 455, 1061–1068 (2008).
48. Barretina, J. et al. The Cancer Cell Line Encyclopedia enables predictive mod-
elling of anticancer drug sensitivity. Nature 483, 603–607 (2012).
49. Consortium, E. P. An integrated encyclopedia of DNA elements in the human
genome. Nature 489, 57–74 (2012).
50. Forbes, S. A. et al. COSMIC: mining complete cancer genomes in the Catalogue
of Somatic Mutations in Cancer. Nucleic Acids Res. 39, D945–D950 (2010).
51. Szklarczyk, D. et al. The STRING database in 2021: customizable protein–protein
networks, and functional characterization of user-uploaded gene/measurement
sets. Nucleic Acids Res. 49, D605–D612 (2020).
52. Consortium, G. O. The Gene Ontology (GO) database and informatics resource.
Nucleic Acids Res. 32, D258–D261 (2004).
53. Kanehisa, M. & Goto, S. KEGG: Kyoto encyclopedia of genes and genomes.
Nucleic Acids Res. 28, 27–30 (2000).
54. Perakakis, N., Yazdani, A., Karniadakis, G. E. & Mantzoros, C. Omics, big data and
machine learning as tools to propel understanding of biological mechanisms
and to discover novel diagnostics and therapeutics. Metabolism 87, A1–A9
(2018).
55. Wilson, S. & Filipp, F. V. A network of epigenomic and transcriptional coopera-
tion encompassing an epigenomic master regulator in cancer. NPJ Syst. Biol.
Appl. 4, 24 (2018).
56. Filipp, F. V. Crosstalk between epigenetics and metabolism—Yin and Yang of
histone demethylases and methyltransferases in cancer. Brief. Funct. Genom. 16,
320–325 (2017).
57. Holmes, M. V., Richardson, T. G., Ference, B. A., Davies, N. M. & Davey Smith, G.
Integrating genomics with biomarkers and therapeutic targets to invigorate
cardiovascular drug development. Nat. Rev. Cardiol. 18, 435–453 (2021).
58. Ozaki, K. et al. Functional SNPs in the lymphotoxin-α gene that are associated
with susceptibility to myocardial infarction. Nat. Genet. 32, 650–654 (2002).
59. Golub, T. R. Molecular classiﬁcation of cancer: class discovery and class pre-
diction by gene expression monitoring. Science 286, 531–537 (1999).
60. Oliver, S. Proteomics: guilt-by-association goes global. Nature 403, 601–603
(2000).
61. Lanza, V. F., Baquero, F., Cruz, F. D. L. & Coque, T. M. AccNET (Accessory Genome
Constellation Network): comparative genomics software for accessory genome
analysis using bipartite networks. Bioinformatics 33, btw601 (2016).
62. Fernandes, E. G., Lombardi, A., Solaro, R. & Chiellini, E. Leveraging models of cell
regulation and GWAS data in integrative network-based association studies.
Nat. Genet. 44, 841–847 (2012).
63. Escala-Garcia, M., Abraham, J. & Andrulis, I. L. et al. A network analysis to identify
mediators of germline-driven differences in breast cancer prognosis. Nat.
Commun. 11, 312 (2020).
64. Pidò, S., Ceddia, G. & Masseroli, M, MM. Computational analysis of fused co-
expression networks for the identiﬁcation of candidate cancer gene biomarkers.
NPJ Syst. Biol. Appl. 7, 17 (2021).
65. Medi, K., Kazim, Y. A. & Craig, M. Potential biomarkers and therapeutic targets in
cervical cancer: Insights from the meta-analysis of transcriptomics data within
network biomedicine perspective. PLoS One 13, e0200717 (2018).
66. Cantini, L., Medico, E., Fortunato, S. & Caselle, M. Detection of gene communities
in multi-networks reveals cancer drivers. Sci. Rep. 5, 17386 (2015).
67. Zhang, L., Dai, Z., Yu, J. & Xiao, M. CpG-island-based annotation and analysis of
human housekeeping genes. Brief. Bioinform. 22, 515–525 (2021).
68. Zhang, L. et al. Computed tomography angiography-based analysis of high-risk
intracerebral haemorrhage patients by employing a mathematical model. BMC
Bioinform. 20, 193 (2019).
69. Zhang, L. et al. EZH2-, CHD4-, and IDH-linked epigenetic perturbation and its
association with survival in glioma patients. J. Mol. Cell Biol. 9, 477–488
(2017).
70. Zhang, L. et al. Investigation of mechanism of bone regeneration in a porous
biodegradable calcium phosphate (CaP) scaffold by a combination of a multi-
scale agent-based model and experimental optimization/validation. Nanoscale
8, 14877–14887 (2016).
71. Zhang, L., Xiao, M., Zhou, J. & Yu, J. Lineage-associated underrepresented per-
mutations (LAUPs) of mammalian genomic sequences based on a Jellyﬁsh-
based LAUPs analysis application (JBLA). Bioinformatics 34, 3624–3630 (2018).
72. Zhang, L. et al. Building up a robust risk mathematical platform to predict
colorectal cancer. Complexity 2017, 8917258 (2017).
73. Zhang, L. et al. Bioinformatic analysis of chromatin organization and biased
expression of duplicated genes between two poplars with a common whole-
genome duplication. Horticult. Res. 8, 62 (2021).
74. Ong, S.-E. & Mann, M. Mass spectrometry–based proteomics turns quantitative.
Nat. Chem. Biol. 1, 252–262 (2005).
75. Li, Z., Ivanov, A. A. & AL, e The OncoPPi network of cancer-focused
protein–protein interactions to inform biological insights and therapeutic stra-
tegies. Nat. Commun. 8, 14356 (2017).
76. Kalman, R. E. Mathematical description of linear dynamical systems. J. Soc. Ind.
Appl. Math. Ser. A Control 1, 152–192 (1963).
77. Ravindran, V., Sunitha, V. & Bagler, G. Identiﬁcation of critical regulatory genes in
cancer signaling network using controllability analysis. Phys. A: Stat. Mech. Appl.
474, 134–143 (2017).
78. do Valle, I. F. et al. Network medicine framework shows that proximity of
polyphenol targets and disease proteins predicts therapeutic effects of poly-
phenols. Nat. Food 2, 143–155 (2021).
79. Basler, G., Nikoloski, Z., Larhlimi, A., Barabási, A.-L. & Liu, Y.-Y. Control of ﬂuxes in
metabolic networks. Genome Res. 26, 956–968 (2016).
80. Chakraborty, S., Hosen, M. I., Ahmed, M. & Shekhar, H. U. Onco-Multi-OMICS
approach: a new frontier in cancer research. Biomed. Res. Int. 2018, 9836256
(2018).
81. Zhang, C. et al. The identiﬁcation of key genes and pathways in hepatocellular
carcinoma by bioinformatics analysis of high-throughput data. Med. Oncol. 34,
101 (2017).
82. Gov, E., Kori, M. & Arga, K. Y. Multiomics analysis of tumor microenvironment
reveals Gata2 and miRNA-124-3p as potential novel biomarkers in ovarian
cancer. OMICS 21, 603–615 (2017).
83. Guney, E., Menche, J., Vidal, M. & Barábasi, A.-L. Network-based in silico drug
efﬁcacy screening. Nat. Commun. 7, 10331 (2016).
84. Fortunato, S. Community detection in graphs. Phys. Rep. 486, 75–174 (2009).
85. Lü, L. et al. Vital nodes identiﬁcation in complex networks. Phys. Rep. 650, 1–63
(2016).
86. Jiménez-Luna, J., Grisoni, F. & Schneider, G. Drug discovery with explainable
artiﬁcial intelligence. Nat. Mach. Intell. 2, 573–584 (2020).
87. Loh, W.-Y. Classiﬁcation and regression trees. Phys. Rep. 1, 14–23 (2011).
88. Cao, Y., Geddes, T. A., Yang, J. Y. H. & Yang, P. Ensemble deep learning in
bioinformatics. Nat. Mach. Intell. 2, 500–508 (2020).
89. Nordhausen & Klaus An introduction to statistical learning—with applications in
R by Gareth James, Daniela Witten, Trevor Hastie & Robert Tibshirani. Int. Stat.
Rev. 82, 156–157 (2014).
90. Hao, X., Zhang, G. & Ma, S. Deep learning. Int. J. Semantic Comput. 10, 417–439
(2016).
91. Lecun, Y., Bengio, Y. & Hinton, G. E. Deep learning. Nature 521, 436–444 (2015).
92. Barabási, A.-L., Gulbahce, N. & Loscalzo, J. Network medicine: a network-based
approach to human disease. Nat. Rev. Genet. 12, 56–68 (2011).
93. Karlebach, G. & Shamir, R. Modelling and analysis of gene regulatory networks.
Nat. Rev. Mol. Cell Biol. 9, 770–780 (2008).
94. Stelling, J., Klamt, S., Bettenbrock, K., Schuster, S. & Gilles, E. D. Metabolic net-
work structure determines key aspects of functionality and regulation. Nature
420, 190–193 (2002).
95. T-M, H. Architecture of the drug-drug interaction network. J. Clin. Pharm. Ther.
36, 135–143 (2011).
96. Martinez, V., Berzal, F. & Cubero, J. C. A survey of link prediction in complex
networks. ACM Comput. Surv. 49, 69.61–69.33 (2017).
97. Hens, C., Harush, U., Haber, S., Cohen, R. & Barzel, B. Spatiotemporal signal
propagation in complex networks. Nat. Phys. 15, 403–412 (2019).
98. Lazareva, O., Baumbach, J., List, M. & Blumenthal, D. B. On the limits of active
module identiﬁcation. Brief. Bioinform. 22, bbab066 (2021).
99. Liu, Y.-Y., Slotine, J.-J. & Barabási, A.-L. Controllability of complex networks.
Nature 473, 167–173 (2011).
100. Abhik, S. & Wild, D. J. Netpredictor: R and Shiny package to perform drug-target
network analysis and prediction of missing links. BMC Bioinform. 19, 265 (2018).
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
21
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 22 (Section: Author contributions)

101. Kuperstein, I. et al. The shortest path is not the one you know: application of
biological network resources in precision oncology research. Mutagenesis 30,
191–204 (2015).
102. Rabbani, M. & Kazemi, S. Solving uncapacitated multiple allocation p-hub center
problem by Dijkstra’s algorithm-based genetic algorithm and simulated
annealing. Int. J. Ind. Eng. Comput. 6, 405–418 (2015).
103. Li, Z. et al. Identifying novel genes and chemicals related to nasopharyngeal
cancer in a heterogeneous network. Sci. Rep. 6, 25515 (2016).
104. Ruiz, C., Zitnik, M. & Leskovec, J. Identiﬁcation of disease treatment mechanisms
through the multiscale interactome. Nat. Commun. 12, 1796 (2021).
105. Chen, L. et al. Identiﬁcation of novel candidate drivers connecting different
dysfunctional levels for lung adenocarcinoma using protein-protein interactions
and a shortest path approach. Sci. Rep. 6, 29849 (2016).
106. Li, B.-Q., Huang, T., Liu, L., Cai, Y.-D. & Chou, K.-C. Identiﬁcation of colorectal
cancer related genes with mrmr and shortest path in protein-protein interaction
network. PLoS One 7, e33393 (2012).
107. Peng, H., Long, F. & Ding, C. Feature selection based on mutual information
criteria of max-dependency, max-relevance, and min-redundancy. IEEE Trans.
Pattern Anal. Mach. Intell. 27, 1226–1238 (2005).
108. Barthélemy, M. Betweenness centrality in large complex networks. Eur. Phys. J. B
38, 163–168 (2004).
109. Maclean, H. E., Warne, G. L. & Zajac, J. D. Localization of functional domains in
the androgen receptor. J. Steroid Biochem. Mol. Biol. 62, 233–242 (1997).
110. Tusher, V. G., Tibshirani, R. & Chu, G. Signiﬁcance analysis of microarrays applied
to the ionizing radiation response. Proc. Natl Acad. Sci. USA 98, 5116 (2001).
111. Szklarczyk, D. et al. STRING v11: protein–protein association networks with
increased coverage, supporting functional discovery in genome-wide experi-
mental datasets. Nucleic Acids Res 47, D607–D613 (2018).
112. Lu, S., Zhu, Z.-G. & Lu, W.-C. Inferring novel genes related to colorectal cancer via
random walk with restart algorithm. Gene Ther. 26, 373–385 (2019).
113. Menche, J. et al. Uncovering disease-disease relationships through the incom-
plete interactome. Science 347, 1257601–1257601 (2015).
114. Choobdar, S. et al. Assessment of network module identiﬁcation across complex
diseases. Nat. Methods 16, 843–852 (2019).
115. Fortunato, S. & Hric, D. Community detection in networks: a user guide. Phys.
Rep. 659, 1–44 (2016).
116. Newman, M. E. J. Communities, modules and large-scale structure in networks.
Nat. Phys. 8, 25–31 (2012).
117. Cowen, L., Ideker, T., Raphael, B. J. & Sharan, R. Network propagation: a universal
ampliﬁer of genetic associations. Nat. Rev. Genet. 18, 551–562 (2017).
118. Silverbush, D. et al. Simultaneous integration of multi-omics data improves the
identiﬁcation of cancer driver modules. Cell Syst. 8, 456–466.e455 (2019).
119. Hossain, S. M. M., Halsana, A. A., Khatun, L., Ray, S. & Mukhopadhyay, A. Dis-
covering key transcriptomic regulators in pancreatic ductal adenocarcinoma
using Dirichlet process Gaussian mixture model. Sci. Rep. 11, 7853 (2021).
120. Ghiassian, S. D. et al. Endophenotype network models: common core of com-
plex diseases. Sci. Rep. 6, 27414 (2016).
121. Ghiassian, S. D., Menche, J. & Barabási, A.-L. A DIseAse MOdule Detection
(DIAMOnD) algorithm derived from a systematic analysis of connectivity pat-
terns of disease proteins in the human interactome. PLoS Comput. Biol. 11,
e1004120 (2015).
122. Wang, R.-S. & Loscalzo, J. Network-based disease module discovery by a novel
seed connector algorithm with pathobiological implications. J. Mol. Biol. 430,
2939–2950 (2018).
123. Wang, Q., Yu, H., Zhao, Z. & Jia, P. EW_dmGWAS: edge-weighted dense module
search for genome-wide association studies and gene expression proﬁles.
Bioinformatics 31, 2591–2594 (2015).
124. Zhang, Y. et al. A gene module identiﬁcation algorithm and its applications to
identify gene modules and key genes of hepatocellular carcinoma. Sci. Rep. 11,
5517 (2021).
125. Paci, P. et al. Gene co-expression in the interactome: moving from correlation
toward causation via an integrated approach to disease module discovery. NPJ
Syst. Biol. Appl. 7, 3 (2021).
126. Tripathi, B., Parthasarathy, S., Sinha, H., Raman, K. & Ravindran, B. Adapting
community detection algorithms for disease module identiﬁcation in hetero-
geneous biological networks. Front. Genet. 10, 164 (2019).
127. Jeong, H., Mason, S. P., Barabási, A. L. & Oltvai, Z. N. Lethality and centrality in
protein networks. Nature 411, 41–42 (2001).
128. Mangangcha, I. R., Malik, M. Z., Küçük, Ö., Ali, S. & Singh, R. K. B. Identiﬁcation of
key regulators in prostate cancer from gene expression datasets of patients. Sci.
Rep. 9, 16420 (2019).
129. Kitsak, M. et al. Identiﬁcation of inﬂuential spreaders in complex networks. Nat.
Phys. 6, 888–893 (2010).
130. Jalili, M. et al. Evolution of centrality measurements for the detection of essential
proteins in biological networks. Front. Physiol. 7, 375 (2016).
131. Pastor-Satorras, R. & Castellano, C. Distinct types of eigenvector localization in
networks. Sci. Rep. 6, 18847 (2016).
132. Barabási, A.-L. & Albert, R. Emergence of scaling in random networks. Science
286, 509–512 (1999).
133. Zhang, J. et al. P4HB, a novel hypoxia target gene related to gastric cancer
invasion and metastasis. Biomed. Res. Int. 2019, 9749751 (2019).
134. Ahajjam, S. & Badir, H. Identiﬁcation of inﬂuential spreaders in complex net-
works using HybridRank algorithm. Sci. Rep. 8, 11932 (2018).
135. Malliaros, F. D., Rossi, M.-E. G. & Vazirgiannis, M. Locating inﬂuential nodes in
complex networks. Sci. Rep. 6, 19307 (2016).
136. Li, H. et al. Deciphering the mechanism of Indirubin and its derivatives in the
inhibition of Imatinib resistance using a “drug target prediction-gene microarray
analysis-protein network construction” strategy. BMC Complement. Alter. Med.
19, 75 (2019).
137. Taylor, I. W. et al. Dynamic modularity in protein interaction networks predicts
breast cancer outcome. Nat. Biotechnol. 27, 199–204 (2009).
138. Raman, K., Damaraju, N. & Joshi, G. K. The organisational structure of protein
networks: revisiting the centrality-lethality hypothesis. Syst. Synth. Biol. 8, 73–81
(2014).
139. Mallik, S. & Maulik, U. MiRNA-TF-gene network analysis through ranking of
biomolecules for multi-informative uterine leiomyoma dataset. J. Biomed. Infor.
57, 308–319 (2015).
140. Chen, C. et al. Construction and analysis of protein-protein interaction networks
based on proteomics data of prostate cancer. Int. J. Mol. Med. 37, 1576–1586
(2016).
141. Al-Aamri, A., Taha, K., Al-Hammadi, Y., Maalouf, M. & Homouz, D. Analyzing a co-
occurrence gene-interaction network to identify disease-gene association. BMC
Bioinform. 20, 70 (2019).
142. Jiang, P. et al. Network analysis of gene essentiality in functional genomics
experiments. Genome Biol. 16, 1–10 (2015).
143. Chen, K.-H., Wang, K.-J., Wang, K.-M. & Angelia, M.-A. Applying particle swarm
optimization-based decision tree classiﬁer for cancer classiﬁcation on gene
expression data. Appl. Soft Comput. 24, 773–780 (2014).
144. Chen, K.-H. et al. Gene selection for cancer identiﬁcation: a decision tree model
empowered by particle swarm optimization algorithm. BMC Bioinform. 15, 49
(2014).
145. Li, Y., Tang, X.-Q., Bai, Z. & Dai, X. Exploring the intrinsic differences among
breast tumor subtypes deﬁned using immunohistochemistry markers based on
the decision tree. Sci. Rep. 6, 1–13 (2016).
146. Carson, M. B. & Lu, H. Network-based prediction and knowledge mining of
disease genes. BMC Med. Genom. 8, S9 (2015).
147. Ramadan, E., Alinsaif, S. & Hassan, M. R. Network topology measures for
identifying disease-gene association in breast cancer. BMC Bioinform. 17, 274
(2016).
148. Lerman, R. I. & Yitzhaki, S. A note on the calculation and interpretation of the
Gini index. Econ. Lett. 15, 363–368 (1984).
149. Burt, R. S. Structural holes and good ideas. Am. J. Sociol. 110, 349–399 (2004).
150. Ye, N., Zhang, Y., Wang, R. & Malekian, R. Vehicle trajectory prediction based on
Hidden Markov Model. KSII Trans. Internet Infor. Syst. 10, 3150–3170 (2016).
151. Ernesto, E. Subgraph centrality in complex networks. Phys. Rev. E Stat. Nonlin
Soft Matter Phys. 71, 056103 (2005).
152. Guimerà, R. & Nunes Amaral, L. A. Functional cartography of complex metabolic
networks. Nature 433, 895–900 (2005).
153. Katz, L. A new status index derived from sociometric analysis. Psychometrika 18,
39–43 (1953).
154. Towﬁc, F. et al. Detection of gene orthology from gene co-expression and
protein interaction networks. BMC Bioinform. 11, S7 (2010).
155. Soffer, S. N. & Vázquez, A. Network clustering coefﬁcient without degree-
correlation biases. Phys. Rev. E Stat. Nonlin. Soft Matter Phys. 71, 057101 (2005).
156. Breiman, L. Bagging predictors. Mach. Learn. 24, 123–140 (1996).
157. Ezzat, A., Wu, M., Li, X. L. & Kwoh, C. K. Drug-target interaction prediction using
ensemble learning and dimensionality reduction. Methods 129, 81 (2017).
158. Breiman, L. Random forests. Mach. Learn. 45, 5–32 (2001).
159. Sarica, A., Cerasa, A. & Quattrone, A. Random Forest algorithm for the classiﬁ-
cation of neuroimaging data in Alzheimer’s disease: a systematic review. Front.
Aging Neurosci. 9, 329 (2017).
160. Toth, R., Schiffmann, H., Hube-Magg, C., Büscheck, F. & Gerhuser, C. Random
forest-based modelling to detect biomarkers for prostate cancer progression.
Clin. Epigenet. 11, 148 (2019).
161. Jin, H. & Ling, C. X. Using AUC and accuracy in evaluating learning algorithms.
IEEE Trans. Knowl. Data Eng. 17, 299–310 (2005).
162. Kingsford, C. & Salzberg, S. L. What are decision trees? Nat. Biotechnol. 26,
1011–1013 (2008).
163. Hao, D. & Li, C. The dichotomy in degree correlation of biological networks. PLoS
One 6, e28322 (2011).
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
22
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 23 (Section: Author contributions)

164. Zhang, Q., Wang, F. Y., Zeng, D. & Wang, T. Understanding crowd-powered
search groups: a social network perspective. PLoS One 7, 1–16 (2012).
165. Freund, Y. & Mason, L. The Alternating Decision Tree Learning Algorithm. In Proc.
Sixteenth International Conference on Machine Learning, 124–133 (1999).
166. Zhang, L. et al. Revealing dynamic regulations and the related key proteins of
myeloma-initiating cells by integrating experimental data into a systems bio-
logical model. Bioinformatics 37, 1554–1561 (2021).
167. Tabrizchi, H., Tabrizchi, M. & Tabrizchi, H. Breast cancer diagnosis using a multi-
verse optimizer-based gradient boosting decision tree. SN Appl. Sci. 2, 1–19 (2020).
168. Rumelhart, D. E., Hinton, G. E. & Williams, R. J. Learning representations by back-
propagating errors. Nature 323, 533–536 (1986).
169. Liu, H., Zhang, W., Song, Y., Deng, L. & Zhou, S. HNet-DNN: inferring new
drug–disease associations with deep neural network based on heterogeneous
network features. J. Chem. Inform. Modeling 60, 2367–2376 (2020).
170. Ragoza, M., Hochuli, J., Idrobo, E., Sunseri, J. & Koes, D. R. Protein–ligand scoring
with convolutional neural networks. J. Chem. Inform. Modeling 57, 942–957 (2017).
171. Korotcov, A., Tkachenko, V., Russo, D. P. & Ekins, S. Comparison of deep learning
with multiple machine learning methods and metrics using diverse drug dis-
covery data sets. Mol. Pharm. 14, 4462–4475 (2017).
172. Ma, T., Xiao, C., Zhou, J. & Wang, F. Drug similarity integration through attentive
multi-view graph auto-encoders. In Proc. Twenty-Seventh International Joint
Conference
on
Artiﬁcial
Intelligence,
3477–3483,
https://doi.org/10.24963/
ijcai.2018/483 (2018).
173. Lan, W. et al. GANLDA: graph attention network for lncRNA-disease associations
prediction. Neurocomputing 469, 384–393 (2022).
174. Li, G. et al. Predicting MicroRNA-disease associations using network topological
similarity based on DeepWalk. IEEE Access 5, 24032–24039 (2017).
175. Webb, S. Deep learning for biology. Nature 554, 555–557 (2018).
176. Selvaraj, G. et al. Identiﬁcation of target gene and prognostic evaluation for lung
adenocarcinoma using gene expression meta-analysis, network analysis and
neural network algorithms. J. Biomed. Inform. 86, 120–134 (2018).
177. Goyal, P. & Ferrara, E. Graph embedding techniques, applications, and perfor-
mance: a survey. Knowl.-Based Syst. 151, 78–94 (2017).
178. Wu, Z. et al. A comprehensive survey on graph neural networks. IEEE Trans.
Neural Netw. Learn Syst. 32, 4–24 (2021).
179. Zheng, K., You, Z.-H., Wang, L., Wong, L. & Chen, Z.-H. Inferring disease-
associated Piwi-interacting RNAs via graph attention networks. 239–250, (2020).
180. Vaswani, A. et al. Attention is all you need. In Proc. 31st International Conference
on Neural Information Processing Systems, 5998–6008 (2017).
181. Singh, M., Singh, R. & Ross, A. A comprehensive overview of biometric fusion.
Inform. Fusion 52, 187–205 (2019).
182. Shi, Z., Zhang, H., Jin, C., Quan, X. & Yin, Y. A representation learning model
based on variational inference and graph autoencoder for predicting lncRNA-
disease associations. BMC Bioinform. 22, 136 (2021).
183. Jordan, M. I. & Mitchell, T. M. Machine learning: trends, perspectives, and pro-
spects. Science 349, 255–260 (2015).
184. Kim, D. et al. Using knowledge-driven genomic interactions for multi-omics data
analysis: metadimensional models for predicting clinical outcomes in ovarian
carcinoma. J. Am. Med. Inform. Assoc. 24, 577–587 (2016).
185. Vamathevan, J. et al. Applications of machine learning in drug discovery and
development. Nat. Rev. Drug Discov. 18, 463–477 (2019).
186. Alex, F., Song, J. S. & Ilya, I. Maximum entropy methods for extracting the
learned features of deep neural networks. PLoS Comput. Biol. 13, e1005836-
(2017).
187. Hutson, M. Artiﬁcial intelligence faces reproducibility crisis. Science 359, 725–726
(2018).
188. Ozerov, I. V. et al. In silico Pathway Activation Network Decomposition Analysis
(iPANDA) as a method for biomarker development. Nat. Commun. 7, 13427
(2016).
189. Xia, J., Benner, M. J. & Hancock, R. E. NetworkAnalyst-integrative approaches for
protein–protein interaction network analysis and visual exploration. Nucleic
Acids Res. 42, W167–W174 (2014).
190. Hernández-de-Diego, R. et al. PaintOmics 3: a web resource for the pathway
analysis and visualization of multi-omics data. Nucleic Acids Res. 46, W503–W509
(2018).
191. Tuhkuri, A. et al. Patients with early-stage oropharyngeal cancer can be iden-
tiﬁed with label-free serum proteomics. Br. J. Cancer 119, 200–212 (2018).
192. Abbas, S. Z., Qadir, M. I. & Muhammad, S. A. Systems-level differential gene
expression analysis reveals new genetic variants of oral cancer. Sci. Rep. 10,
14667 (2020).
193. Ren, G. & Liu, Z. NetCAD: a network analysis tool for coronary artery disease-
associated PPI network. Bioinformatics 29, 279–280 (2012).
194. Reimand, J. et al. Pathway enrichment analysis and visualization of omics data
using g:Proﬁler, GSEA, Cytoscape and EnrichmentMap. Nat. Protoc. 14, 482–517
(2019).
195. Langfelder, P. & Horvath, S. WGCNA: an R package for weighted correlation
network analysis. BMC Bioinform. 9, 559 (2008).
196. Xian-Guo, Z. et al. Identifying miRNA and gene modules of colon cancer asso-
ciated with pathological stage by weighted gene co-expression network ana-
lysis. Onco Targets Ther. 11, 2815–2830 (2018).
197. Langfelder, P., Zhang, B. & Horvath, S. Deﬁning clusters from a hierarchical
cluster tree: the Dynamic Tree Cut package for R. Bioinformatics 24, 719–720
(2008).
198. Wang, A. et al. Cell adhesion-related molecules play a key role in renal cancer
progression by multinetwork analysis. Biomed. Res. Int. 2019, 2325765
(2019).
199. Lai, X. et al. Network- and systems-based re-engineering of dendritic cells with
non-coding RNAs for cancer immunotherapy. Theranostics 11, 1412–1428
(2021).
200. Jin, S., Zeng, X., Xia, F., Huang, W. & Liu, X. Application of deep learning methods
in biological networks. Brief. Bioinform. 22, 1902–1917 (2020).
201. Zhu, Y., Shen, X. & Pan, W. Network-based support vector machine for classiﬁ-
cation of microarray samples. BMC Bioinform. 10, S21 (2009).
202. Sanchez, R. & Mackenzie, S. A. Integrative network analysis of differentially
methylated and expressed genes for biomarker identiﬁcation in leukemia. Sci.
Rep. 10, 2123 (2020).
203. Wang, T. et al. MOGONET integrates multi-omics data using graph convolutional
networks allowing patient classiﬁcation and biomarker identiﬁcation. Nat.
Commun. 12, 3445 (2021).
204. Xuan, P., Zhang, P. S., Liu, T., Sun, Y. & Graph, H. Convolutional network and
convolutional neural network based method for predicting lncrna-disease
associations. Cells 8, 1012 (2019). Aug 30.
205. Wu, M.-Y. et al. Regularized logistic regression with network-based pairwise
interaction for biomarker identiﬁcation in breast cancer. BMC Bioinform. 17, 108
(2016).
206. Swan, A. L., Mobasheri, A., Allaway, D., Liddell, S. & Bacardit, J. Application of
machine learning to proteomics data: classiﬁcation and biomarker identiﬁcation
in postgenomics biology. OMICS 17, 595–610 (2013).
207. Gigliotti, B. J., Russell, M. D., Shonka, D. & Stathatos, N. Fine-needle aspiration
and molecular analysis. Surgery of the Thyroid and Parathyroid Glands (Third
Edition), 118–131, https://doi.org/10.1016/B978-0-323-66127-0.00012-0 (2021).
208. Sinkala, M., Mulder, N. & Martin, D. Machine learning and network analyses
reveal disease subtypes of pancreatic cancer and their molecular characteristics.
Sci. Rep. 10, 1212 (2020).
209. Kaczmarek, E. et al. Multi-Omic graph transformers for cancer classiﬁcation and
interpretation. In Proc. Paciﬁc Symposium on Biocomputing 27, 373–384, https://
doi.org/10.1142/9789811250477_0034.
210. Vermeulen, M. & Lelie, N. The current status of nucleic acid ampliﬁcation
technology in transfusion-transmitted infectious disease testing. ISBT Sci. Ser. 11,
123–128 (2016).
211. Kuhlman, B. & Bradley, P. Advances in protein structure prediction and design.
Nat. Rev. Mol. Cell Biol. 20, 681–697 (2019).
212. Kandoi, G., Acencio, M. L. & Lemke, N. Prediction of druggable proteins using
machine learning and systems biology: a mini-review. Front. Physiol. 6, 366 (2015).
213. Hussein, H. A. et al. PockDrug-Server: a new web server for predicting pocket
druggability on holo and apo proteins. Nucleic Acids Res. 43, W436–W442
(2015).
214. Yang, Y.-F., Yu, B., Zhang, X.-X. & Zhu, Y.-H. Identiﬁcation of TNIK as a novel
potential drug target in thyroid cancer based on protein druggability prediction.
Medicines 100, e25541–e25541 (2021).
215. Sheng, W. et al. Accurate de novo prediction of protein contact map by ultra-
deep learning model. PLoS Comput. Biol. 13, e1005324 (2017).
216. Ovchinnikov, S. et al. Protein structure determination using metagenome
sequence data. Science 355, 294–298 (2017).
217. Wang, T. et al. Improved fragment sampling for ab initio protein structure
prediction using deep neural networks. Nat. Mach. Intell. 1, 347–355 (2019).
218. Yang, J. et al. Improved protein structure prediction using predicted interresidue
orientations. Proc. Natl Acad. Sci. USA 117, 1496–1503 (2020).
219. Kryshtafovych, A., Schwede, T., Topf, M., Fidelis, K. & Moult, J. Critical assessment
of methods of protein structure prediction (CASP)—Round XIII. Proteins 87,
1011–1020 (2019).
220. Haas, J. et al. Continuous Automated Model EvaluatiOn (CAMEO) com-
plementing the critical assessment of structure prediction in CASP12. Proteins
86, 387–398 (2018).
221. Senior, A. W. et al. Improved protein structure prediction using potentials from
deep learning. Nature 577, 706–710 (2020).
222. Shim, J., Hong, Z.-Y., Sohn, I. & Hwang, C. Prediction of drug–target binding afﬁnity
using similarity-based convolutional neural network. Sci. Rep. 11, 4416 (2021).
223. Liu, B., He, H., Luo, H., Zhang, T. & Jiang, J. Artiﬁcial intelligence and big data
facilitated targeted drug discovery. Stroke Vasc. Neurol. 4, 206–213 (2019).
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
23
Signal Transduction and Targeted Therapy (2022) 7:156

## Page 24 (Section: Author contributions)

224. He, T., Heidemeyer, M., Ban, F., Cherkasov, A. & Ester, M. SimBoost: a read-across
approach for predicting drug–target binding afﬁnities using gradient boosting
machines. J. Cheminform. 9, 24 (2017).
225. Nguyen, T. et al. GraphDTA: predicting drug–target binding afﬁnity with graph
neural networks. Bioinformatics 37, 1140–1147 (2020).
226. Roda, A., Guardigli, M., Pasini, P. & Mirasoli, M. Bioluminescence and chemilu-
minescence in drug screening. Anal. Bioanal. Chem. 377, 826–833 (2003).
227. Hinnerichs, T. & Hoehndorf, R. DTI-Voodoo: machine learning over interaction
networks and ontology-based background knowledge predicts drug–target
interactions. Bioinformatics 37, 4835–4843 (2021).
228. Oliver, S. Guilt-by-association goes global. Nature 403, 601–602 (2000).
229. Monica, C. Drug target identiﬁcation using side-effect similarity. Science 321,
263–266 (2008).
230. Feng, Y., Wang, Q. & Wang, T. Drug target protein-protein interaction networks:
a systematic perspective. Biomed. Res. Int. 2017, 1289259 (2017).
231. Lee, I., Keum, J. & Nam, H. DeepConv-DTI: prediction of drug-target interactions
via deep learning with convolution on protein sequences. PLoS Comput. Biol. 15,
e1007129 (2019).
232. Parvathaneni, V., Kulkarni, N. S., Muth, A. & Gupta, V. Drug repurposing: a pro-
mising tool to accelerate the drug discovery process. Drug Discov. Today 24,
2076–2085 (2019).
233. Pritchard, J. E., O’Mara, T. A. & Glubb, D. M. Enhancing the promise of drug
repositioning through genetics. Front. Pharm. 8, 896 (2017).
234. Gottlieb, A., Stein, G. Y., Ruppin, E. & Sharan, R. PREDICT: a method for inferring
novel drug indications with application to personalized medicine. Mol. Syst. Biol.
7, 496 (2011).
235. Iwata, H., Sawada, R., Mizutani, S. & Yamanishi, Y. Systematic drug repositioning
for a wide range of diseases with integrative analyses of phenotypic and
molecular data. J. Chem. Inform. Model. 55, 446–459 (2015).
236. Liu, H., Song, Y., Guan, J., Luo, L. & Zhuang, Z. Inferring new indications for
approved drugs via random walk on drug-disease heterogenous networks. BMC
Bioinform. 17, 539 (2016).
237. Luo, H. et al. Drug repositioning based on comprehensive similarity measures
and Bi-Random walk algorithm. Bioinformatics 32, 2664–2671 (2016).
238. Wang, W., Yang, S., Zhang, X. & Li, J. Drug repositioning by integrating target
information through a heterogeneous network model. Bioinformatics 30,
2923–2930 (2014).
239. Liu, C. et al. Individualized genetic network analysis reveals new therapeutic
vulnerabilities in 6,700 cancer genomes. PLoS Comput. Biol. 16, e1007701 (2020).
240. Yang, M., Luo, H., Li, Y. & Wang, J. Drug repositioning based on bounded nuclear
norm regularization. Bioinformatics 35, i455–i463 (2019).
241. Yang, M., Luo, H., Li, Y., Wu, F.-X. & Wang, J. Overlap matrix completion for
predicting drug-associated indications. PLoS Comput. Biol. 15, e1007541 (2019).
242. Cheng, F. et al. A genome-wide positioning systems network algorithm for in
silico drug repurposing. Nat. Commun. 10, 3476 (2019).
243. Luo, H. et al. Drug repositioning based on comprehensive similarity measures
and Bi-Random Walk algorithm. Bioinformatics 32, btw228 (2016).
244. Feixiong, C., Junfei, Z., Michaela, F. & Zhongming, Z. A network-based drug
repositioning infrastructure for precision cancer medicine through targeting
signiﬁcantly mutated genes in the human cancer genomes. J. Am. Med. Inform.
Assoc. 23, 681–691 (2016).
245. Luo, H. et al. Computational drug repositioning using low-rank matrix approx-
imation and randomized algorithms. Bioinformatics 34, 1904–1912 (2018).
246. Chen, J., Althagaﬁ, A. & Hoehndorf, R. Predicting candidate genes from phenotypes,
functions and anatomical site of expression. Bioinformatics 37, 853–860 (2020).
247. Honda, S., Shi, S. & Ueda, H. R. SMILES transformer: pre-trained molecular ﬁn-
gerprint for low data drug discovery. CoRR abs/1911.04738 (2019).
248. Kulmanov, M. & Hoehndorf, R. DeepGOPlus: improved protein function pre-
diction from sequence. Bioinformatics 36, 422–429 (2019).
249. Cui, C. et al. Drug repurposing against breast cancer by integrating drug-
exposure expression proﬁles and drug–drug links based on graph neural net-
work. Bioinformatics 37, 2930–2937 (2021).
250. Aravind, S. A next generation connectivity map: L1000 platform and the ﬁrst
1,000,000 proﬁles. Cell 171, 1437–1452.e1417 (2017).
251. Szklarczyk, D. et al. STRING v10: protein–protein interaction networks, integrated
over the tree of life. Nucleic Acids Res. 43, D447–D452 (2014).
252. Huang, L.-C., Wu, X. & Chen, J. Y. Predicting adverse side effects of drugs. BMC
Genom. 12, S11 (2011).
253. Arrowsmith & John Trial watch: phase III and submission failures: 2007–2010.
Nat. Rev. Drug Discov. 10, 87 (2011).
254. Kuhn, M., Letunic, I., Jensen, L. J. & Bork, P. The SIDER database of drugs and side
effects. Nucleic Acids Res. 44, D1075–D1079 (2016).
255. Shaked, I., Oberhardt, M. A., Atias, N., Sharan, R. & Ruppin, E. Metabolic network
prediction of drug side effects. Cell Syst. 2, 209–213 (2016).
256. Zhong, H. A. ADMET properties: overview and current topics. Drug Design:
Principles and Applications, 113–133, https://doi.org/10.1007/978-981-10-5187-
6_8 (2017).
257. Lei, T. et al. ADMET evaluation in drug discovery: 15. Accurate prediction of rat
oral acute toxicity using relevance vector machine and consensus modeling. J.
Cheminform. 8, 6 (2016).
258. Tropsha, A., Gramatica, P. & Gombar, V. K. The importance of being earnest:
validation is the absolute essential for successful application and interpretation
of QSPR models. QSAR Comb. Sci. 22, 69–77 (2003).
259. Duvenaud, D. et al. ConvolutioNal networks on graphs for learning molecular
ﬁngerprints. Adv. Neural Inform. Process. Syst. 13, 2224–2232 (2015).
260. Harrer, S., Shah, P., Antony, B. & Hu, J. Artiﬁcial intelligence for clinical trial
design. Trends Pharm. Sci. 40, 577–591 (2019).
261. Yauney, G. & Shah, P. Reinforcement learning with action-derived rewards for
chemotherapy and clinical trial dosing regimen selection. Proc. 3rd Mach. Learn.
Healthc. Conf. 85, 161–226 (2018).
262. Cusick, M. E. et al. Literature-curated protein interaction datasets. Nat. Methods
6, 934–935 (2009).
263. Lai, X. et al. A disease network-based deep learning approach for characterizing
melanoma. Int. J. Cancer 150, 1029–1044 (2022).
264. Ching, T. et al. Opportunities and obstacles for deep learning in biology and
medicine. J. R. Soc. Interface 15, 20170387 (2018).
265. Mohamed, S. K., Nováček, V. & Nounu, A. Discovering protein drug targets using
knowledge graph embeddings. Bioinformatics 36, 603–610 (2019).
266. Zhang, Q. et al. Deep learning based classiﬁcation of breast tumors with shear-
wave elastography. Ultrasonics 72, 150–157 (2016).
267. Takahashi, Y. et al. Improved metabolomic data-based prediction of depressive
symptoms using nonlinear machine learning with feature selection. Transl.
Psychiatry 10, 157 (2020).
268. Schulte-Sasse, R., Budach, S., Hnisz, D. & Marsico, A. Integration of multiomics
data with graph convolutional networks to identify new cancer genes and their
associated molecular mechanisms. Nat. Mach. Intell. 3, 513–526 (2021).
269. Wu, F., Ma, C. & Tan, C. Network motifs modulate druggability of cellular targets.
Sci. Rep. 6, 36626 (2016).
270. Abi Hussein, H. et al. Global vision of druggability issues: applications and
perspectives. Drug Discov. Today 22, 404–415 (2017).
271. Hiba Abi, H. PockDrug-Server: a new web server for predicting pocket drugg-
ability on holo and apo proteins. Nucleic Acids Res. 43, W436–442 (2015).
272. Zhang, A. et al. Discovery and veriﬁcation of the potential targets from bioactive
molecules by network pharmacology-based target prediction combined with
high-throughput metabolomics. RSC Adv. 7, 51069–51078 (2017).
273. Madhamshettiwar, P. B., Maetschke, S. R., Davis, M. J., Reverter, A. & Ragan, M. A.
Gene regulatory network inference: evaluation and application to ovarian
cancer allows the prioritization of drug targets. Genome Med. 4, 41–41 (2012).
274. Zheng, Y., Peng, H., Ghosh, S., Lan, C. & Li, J. Inverse similarity and reliable
negative samples for drug side-effect prediction. BMC Bioinform. 19, 554 (2019).
Open Access This article is licensed under a Creative Commons
Attribution 4.0 International License, which permits use, sharing,
adaptation, distribution and reproduction in any medium or format, as long as you give
appropriate credit to the original author(s) and the source, provide a link to the Creative
Commons license, and indicate if changes were made. The images or other third party
material in this article are included in the article’s Creative Commons license, unless
indicated otherwise in a credit line to the material. If material is not included in the
article’s Creative Commons license and your intended use is not permitted by statutory
regulation or exceeds the permitted use, you will need to obtain permission directly
from the copyright holder. To view a copy of this license, visit http://creativecommons.
org/licenses/by/4.0/.
© The Author(s) 2022
Artiﬁcial intelligence in cancer target identiﬁcation and drug discovery
You et al.
24
Signal Transduction and Targeted Therapy (2022) 7:156


---

# Artificial intelligence in interdisciplinary life science and drug discovery research

- **Authors:** Jürgen Bajorath
- **Issuer:** Future science OA
- **Type:** Scientific article
- **Published:** 2022-03-08
- **Language:** en
- **DOI:** 10.2144/fsoa-2022-0010
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35369273/
- **Licence:** CC-BY

## Section: Text

Artificial intelligence (AI) is lauded as an auspicious problem solver in many areas. However, the methodology is not always sufficiently understood. In fact, there often is an aura of mystery – and also concern – created around AI. For example, the expectation that machines would ‘think’ independently and reach autonomous decisions beyond human reasoning, which might also be threatening, depending on the situation, is not factual and falls into the realm of science fiction. In science, the popularity and promise of AI mostly originate from notable advances in a few fields, but are also influenced by business-driven hype and partly unrealistic expectations.

In computer science, various disciplines are covered under the term AI [1]. Among these, deep learning (DL) using deep neural networks (DNN) – a sub-discipline of machine learning (ML) – has been responsible for recent progress in computer vision (image analysis) or natural language processing. These advances have greatly contributed to the popularity of AI in science. Robotics, another AI discipline, is a mainstay in industry and also plays an important role in laboratory automation. Furthermore, expert and recommender systems, which are also a part of AI, are beginning to be explored in the natural sciences. In the life sciences including medicinal chemistry and early-phase drug discovery, the focal points of this discussion, DL clearly dominates [2–5], and the term AI is for the most part synonymously used with DL. In medicine, a similar dominance of DL is observed across different therapeutic areas [6] such as radiology or oncology [7,8]. In clinical practice, medical image analysis represents a prime growth area for DL [7,9].

## Section: Deep machine learning

Generally, ML uses algorithms for the extraction of feature patterns from training data to classify test objects or address regression tasks. Hence, ML methods are statistical in nature and derive predictive models capturing linear or non-linear instance–feature relationships based on inference from data. DNNs contain varying (and typically large) numbers of ‘hidden’ layers formed by mathematical ‘neurons’ and are particularly well suited for feature extraction from large volumes of unstructured data (such as pixels in images) and for learning new object representations, which represents a hallmark of DNNs. Using these computational architectures, DL relies on systematic correlation of feature patterns and known object labels (class labels) and derives models with decision functions that are not pre-programmed. ML/DL model performance is primarily assessed in benchmark studies using training and test data with known class labels. DL tends to outperform other ML methods in areas where large volumes of unstructured or low-resolution data are available. Hence, all in all, there is nothing mysterious about this type of supervised ‘machine intelligence’.

## Section: Neural network characteristics

Shallow NNs were popular during the early stages of ML in biology, chemistry and drug discovery, but were largely replaced over time by other approaches such as decision tree methods (random forest and gradient boosting), Bayesian modeling or support vector machines. Reasons for this included a general tendency of shallow NNs to overfit models to training data and their high sensitivity to varying parameter settings. As second-generation NNs, DNNs then received increasing attention over the past decade. A part of the attraction is that DNNs represent highly versatile computational architectures. In computer science, a great variety of DNNs and associated learning strategies have been introduced, sometimes described with terms like a network ‘jungle’ or ‘zoo’ [10]. Hence, for many applications, alternative DNNs can be considered, but finding preferred solutions is not necessarily straightforward. Compared with other ML approaches, DNNs are particularly rich in hyper-parameters and derivation of DNN models requires substantial knowledge, skills and experience. Given the variety of DNN architectures and their many parameters, DNNs are currently not yet as extensively explored as other ML approaches. Accordingly, although public domain software is available for constructing DNNs, DL is not an approach that is readily accessible to non-experts. There is a strong discrepancy between the mechanics of model building, which might be handled by less experienced users, and evaluation of results and recognition of potential caveats or model errors, which requires much more expertise. Importantly, similar to other – but not all – ML methods, DNNs have notorious ‘black box’ character [11], meaning that it is not transparent how these models reach their decisions. The black box of DNNs is a major issue in life science and drug discovery applications, as further discussed below.

## Section: Data heterogeneity

Life science and drug discovery data are highly heterogeneous in terms of volumes, composition and complexity. Early-phase drug discovery concentrating on target validation, bioassays, compounds and activity data is not a data-rich discipline compared with other areas where DL has made a strong impact. In early-phase drug discovery, data sets from medicinal chemistry are typically confined to test results for individual or parallel compound series and therefore limited in size. This also applies to data sets from, for example, probe investigations in chemical biology, time series experiments in biology or confirmatory assays in biological screening. A consequence of data heterogeneity and sparseness is that sufficiently large data sets for ‘hungry’ DNNs are often not available. Moreover, informatics approaches in the life sciences have traditionally employed pre-defined object (for example, target or compound) representations (descriptors) and not relied on representation learning.

## Section: Relative performance & new opportunities

Given data heterogeneity in sparseness in the life sciences and drug discovery, only relatively small sets of structured training data are often available for model building. These conditions do not play into the strengths of DL, as discussed above. As a consequence, currently available benchmark studies indicate that DNNs often reach the performance of simpler ML methods in standard applications such as molecular property predictions, but do not significantly exceed it. Such observations only provide weak support for using highly complex DNNs for predictions tasks in the life sciences and drug discovery.

Importantly, however, DL has enabled a number of applications that have so far been difficult or impossible to address using ML, which represents a major attraction. Among others, topical examples include chemical reaction modeling [12,13], generative compound design [14] or de novo protein structure prediction [15]. In these cases, some unprecedented advances have recently been made. In addition, molecular representation learning is increasingly explored in drug discovery in cases where sufficient data are available [16]. However, whether or not newly learned representations will lead to general performance improvements of DL compared with established pre-defined descriptors remains to be seen. Currently, no firm conclusions can be drawn.

## Section: Model impact & acceptance

Currently, practical applications of DL are still rare in medicinal chemistry and drug discovery [17]. Ultimately, DL will only become an integral part of interdisciplinary research if it measurably impacts experimental programs. This can be achieved, for example, by significantly reducing design–test–make–analyze (DMTA) cycle times or, more importantly, by strongly contributing to the discovery or generation of small molecules or biologicals with new or improved functional properties, more selective chemical probes or novel drug candidates. Importantly, demonstrated advances to further establish DL in interdisciplinary settings are only possible if life science investigators and drug discovery practitioners agree to rely on predictions for experimental design. Compared with the current situation, this will require further increased model acceptance in interdisciplinary settings. As is the case with any new technology, time will be required until DL can realize its full potential in this area. However, there are specific requirements that must be met to further increase the confidence of experimentalists in predictive models.

## Section: Rationalizing predictions

Experimentalists are naturally reluctant to rely on predictions that are difficult or impossible to understand. Given the black box nature of DNNs, this presents a major challenge for the acceptance of complex DL models for experimental design. Therefore, increasing attention is being paid to model-agnostic approaches for ‘explainable AI’ (XAI) that make it possible to rationalize the outcome of predictions and interpret them in chemical or biological terms [18,19]. Among others, these approaches include feature weighting or selection methods to identify representation features making largest contributions to individual predictions or other methods that determine feature subsets minimally required to arrive at a correct (or incorrect) prediction [19]. In medicinal chemistry, such feature subsets might define structural patterns that can be interpreted by mapping them on test compounds.

## Section: Quantifying prediction uncertainty

Closely related to such XAI approaches are methods that quantify the uncertainty of predictions. Obtaining uncertainty estimates also helps to build confidence in predictive modeling and further supports model acceptance for planning experiments. Although there are ML methods that provide inherent prediction uncertainties such as Gaussian process modeling [20], most ML/DL methods including DNNs produce numerical end points without uncertainty estimates. Approaches for uncertainty quantification of predictions complementing ML/DL include probabilistic [21] and ensemble methods [22]. The latter methods determine prediction variance on the basis of differently trained models generated with the same algorithm. For probabilistic approaches, Bayesian DNNs provide a prime example [21]. However, due to their computational costs, Bayesian DNNs are only applicable to large data sets if approximations are introduced.

## Section: Data sparseness

In the presence of data sparseness, as discussed above, DL benefits from complementary learning strategies that are designed to limit the number of required training instances [23]. However, whether or not DL in combination with such learning strategies yields significant performance increases over standard ML methods in practical applications also remains to be determined. Currently available benchmarks do not provide a clear picture.

## Section: Prospective applications

The ultimate assessment of the potential of DL for life science and drug discovery research depends on prospective applications, that is, predictions that are experimentally tested in ‘real’ projects (rather than benchmark-type settings). This requires that experimentalists are willing to accept predictions to guide their work, as discussed above. Moreover, confidence in predictive modeling is essential to rely on predictions in high-priority projects where impact is critically important and highly valued. Currently, a number of AI companies claim successes in proprietary drug discovery projects, but scientifically rigorous reports of such case studies are rare. In prospective applications, it must also be considered that predictions relying on project data also assess data generation processes and data integrity [24] and that predictions might succeed or fail for different reasons. Accordingly, an incorrect prediction might not necessarily be attributable to methodological failure. Hence, in prospective applications, predictions should be analyzed, explained and carefully evaluated within a given project context and care should be taken not to prematurely generalize successes of failures.

## Section: Conclusion

The rise of AI in many scientific fields comes along with promises and new challenges. In most cases, AI refers to DL, which is only a part of methodological spectrum of AI. In the life sciences and drug discovery, deep learning will ultimately only live up to expectations if it impacts experimental research and development efforts. This will require time and no immediate breakthroughs should be expected, especially not in drug discovery, given the long drug development times. For example, medicinal chemists currently witness exciting methodological advances through DL in synthesis design, but frequently point out that no easily accessible DL tools are available at present to support their day-to-day efforts in compound optimization. Thus, transforming expert-dependent complex DNN models into robust and widely usable computational tools will be one of the grand challenges going forward. Moreover, increasing numbers of prospective applications will be essential to further advance DL in interdisciplinary research and demonstrate true impact on high-profile projects. In turn, this will require narrowing the gap between DL and experiments and further increasing the confidence of practitioners to rely on computational predictions. The sooner these challenges are tackled, the better – not only for DL and its proponents, but also for the life science arena as a whole.

## Section: References

Papers of special note have been highlighted as: • of interest; •• of considerable interest


---

# Artificial Intelligence Technologies for COVID-19 De Novo Drug Design

- **Authors:** Giuseppe Floresta, Chiara Zagni, Davide Gentile, Vincenzo Patamia, Antonio Rescifina
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2022-03-17
- **Language:** en
- **DOI:** 10.3390/ijms23063261
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35328682/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe recent covid crisis has provided important lessons for academia and industry regarding digital reorganization. Among the fascinating lessons from these times is the huge potential of data analytics and artificial intelligence. The crisis exponentially accelerated the adoption of analytics and artificial intelligence, and this momentum is predicted to continue into the 2020s and beyond. Drug development is a costly and time-consuming business, and only a minority of approved drugs generate returns exceeding the research and development costs. As a result, there is a huge drive to make drug discovery cheaper and faster. With modern algorithms and hardware, it is not too surprising that the new technologies of artificial intelligence and other computational simulation tools can help drug developers. In only two years of covid research, many novel molecules have been designed/identified using artificial intelligence methods with astonishing results in terms of time and effectiveness. This paper reviews the most significant research on artificial intelligence in de novo drug design for COVID-19 pharmaceutical research.Keywords: artificial intelligence, machine learning, drug design, COVID-19, structure-based drug design, ligand-based drug design

## Section: 1. Introduction

In December 2019, in Wuhan, China, a was patient diagnosed with atypical pneumonia. Just a few months later, on 11 March 2020, the COVID-19 pandemic was announced by the World Health Organization. Today, it is still a considerable concern for humanity [1]. A problematic aspect for clinicians to address is that the disease caused by the virus can cause a broad spectrum of symptoms and disease outcomes. In most cases, the virus results in common influenza-like symptoms (cough, fever, and fatigue) or even remains asymptomatic. However, in 10 to 20% of the patients, inflammation results in more complicated conditions that have resulted in more than 5.5 million deaths to early 2022 [2]. Because of the COVID-19 pandemic, the research on developing new treatments/therapies and vaccines against the virus, including drug repurposing and de novo design, gained remarkable significance and implications at the global level, and time plays a fundamental role in this field [3,4]. Drug development is long and expensive process; it is estimated that during the years 2000 to 2015, the average cost of developing a newly approved drug was over USD 2.5 billion per single approved molecule. Commonly, it takes up to 15 years from the design of a single drug to reach the market, and less than 15% of selected compounds that are tested on humans, are later proved as safe and effective and can be finally used [5,6]. It sounds reasonable that humanity can’t wait 15 years for the development of a new molecule for COVID-19 treatment and in this case, the computational chemistry applied in drug design is helping accelerate research and providing stunning results.

AI refers to machines, mainly computers, working like humans. In AI, machines execute tasks such as speech recognition, solving problems, and learning. Machines can work and act like humans if they have enough instruction and knowledge. AI systems can be divided into four groups based on machines’ ability to use past experiences to predict future decisions: (1) Machine learning refers to AI where machines are not explicitly programmed to perform tasks, but they learn and improve from training automatically. Deep learning is a subdivision of machine learning based on artificial neural networks for predictive analysis. (2) Natural language processing (NLP) is the interaction between computers and human language. (3) Automation and robotics aim to allow monotonous and repetitive tasks to be performed by machines. (4) Machine vision—machines can capture visual information and then analyze it [7]. AI has been used in applications to solve specific problems throughout industry and academia. Like electricity or computers, AI is a general-purpose technology that has a multitude of applications. It has enhanced language translation, image recognition, credit scoring, e-commerce, and many other aspects of our lives.

In the field of computer-aided drug discovery (CADD), the scientific community worldwide is regularly developing new technologies and algorithms to obtain hit compounds in a short time and reduce the overall cost [8]. Nowadays, the introduction of artificial intelligence (AI) and all the related techniques such as deep learning (DL), machine learning (ML), and other classical computational chemistry tools to drug discovery has had a significant effect on the success rate and velocity of novel pharmaceutical identification [9].

AI and classical CADD tools can be used alone or combined to produce new approaches that integrate a broad range of algorithms with enhanced prediction capabilities. CADD is classically classified into two methods: structure-based drug design and ligand-based drug design. Both are faces of the same coin and massively rely on force fields, scoring functions, and algorithms to evaluate and rank the studied molecules’ energy contribution in the targeted macromolecular biological system. While computer-aided structure-based drug design (e.g., docking) depends on the actual 3D structure of the targeted binding site of the targeted receptor protein to understand the stabilizing interactions at the molecular level between the studied ligand/receptor system, the ligand-based drug design (e.g., 3D-QSAR modeling) approach relies on the recognition of a database of already-known ligands interacting with the target receptor. Both structure- and ligand-based technologies have several success stories and play key roles in the drug modern drug discovery process [10,11,12,13,14]. In this context, several of these approaches have recently been employed to research novel drug candidates against COVID-19. The absence of complete protection from vaccination and powerful drugs for the treatment of the infection, the mutability of the virus, and the mortality rate impel the fast discovery of novel molecules active against COVID-19, and CADD is believed to be a valuable tool to achieve this goal [15]. Moreover, AI and ML have been broadly exercised from the beginning of the pandemic in discovering new treatments, vaccines, and drug repurposing, and helping clinicians in pharmaceutical-related big-data analysis and explanation for a better understanding of the outcome of the disease. Ongoing evidence shows that AI is being exploited to find potential novel molecules, repurpose drugs, find novel drug targets, and design novel and more effective vaccines. This review describes the current state of the art and the stunning results of AI and ML in the last two years of research in the field of de novo drug design since the COVID-19 pandemic started. Despite occasional difficulty in classification due to the multidimensional structure- and ligand-based approaches used, we divided the review into three main sections reflecting the application of the AI in each paper (i.e., if most AI used is structure- or ligand-based for the multidimensional approaches), a section regarding de novo vaccine design is also presented.

## Section: 2. Structure-Based Artificial Intelligence Methods for Small Molecules

The SARS-CoV-2 spike protein (S protein) is the leading mediator of viral entry into cells, and thereby infection, by binding the human angiotensin-II converting enzyme (ACE2) and therefore represents an attractive target for drug therapies [16]. Recently, Srinivasan et al. developed a surrogate multi-task neural network (MTNN) model that replaces docking simulation in the finding of new molecules targeting the spike protein [17]. Monte Carlo algorithms and recurrent neural networks (RNN) were used to explore the chemical space of millions of potential molecules using SMILES input. In this way, they discovered 97,973 new molecules, not included in the existing starting databases. The molecules were docked using Vina for their ability to bind the pocket region of the SARS-CoV-2 S-protein/ACE2 complex (SARS-CoV-2 S-protein (NCBI Reference Sequence YP_009724390.1)/ACE2 receptor (PDB ID: 2AJF) [18]. The docking calculation search space was chosen as 1.2 nm × 1.2 nm × 1.2 nm and includes the binding pocket located at the S-protein/ACE2 interface [19].

Several molecules with good scores were selected and compared to FDA-approved drugs and the BindingDB dataset. Despite identifying compounds with great binding affinity, MTNN performance had to be improved using active learning and extending the training data to have a correlation between the SMILES string and Vina scores considering the larger domain of SMILES space. This method increased the number of molecules selected to over 300,000. Of these, 200 promising molecules were chosen using Vina scores as selection criteria.

This method accelerated the exploration of the vast chemical space represented by SMILES strings to evaluate structural features and discover structural similarities between top-performing candidates.

Many of the reported computational studies have selected molecules with high affinity to the spike protein. However, these studies are limited to the receptor ACE2/protein spike interface [19]. This represents a limitation since it dramatically reduces the possibility of identifying potential allosteric inhibitors of ACE2-spike complex formation, leading to identification of a limited number of potentially active compounds.

To overcome this, a new machine learning approach, namely SSnet, was used to identify new potential drugs by screening a library of approved drugs from the DrugBank and ZINC databases [20] targeting two different conformations (open and closed) of the ACE2 receptor as well as ACE2 in complex with the S1 domain of the S protein, that is the protein responsible for binding with human cells [21]. After cross-validation of the hits using the Autodock Vina scoring function [22], the SSnet approach was extended to a library of 750,000 molecules in BindingDB to gain additional information regarding de novo drug design.

After that, to accelerate the identification of high-affinity scaffolds to test for their in vitro activity, a web interface, where molecules are grouped according to their similarity on a 2D map and colored based on binding affinity to the protein, was developed. This system allows selecting a certain point of the interface to explore the effect of singular scaffolds and functional groups on the binding score or affinity. Moreover, this approach can be applied to other therapeutical targets besides COVID-19.

SARS-CoV-2 3CLpro main protease (Picornain 3C-like protease, also referred to as Mpro for the main protease) is a homodimeric cysteine protease representing an attractive target for trans-variant activity since no mutations have yet been observed in this protein.

High-throughput virtual screening (HTVS) coupled with ML experiments have been performed to obtain potential virtual inhibitors against the targeted protein rather than trusting commercial “corona-focused libraries”. The system was associated with an ML classification experiment where each compound is indexed into the chemical space of Mpro inhibitors, viral protease inhibitors, or a new chemical space. This approach has the advantage of taking into consideration potential drugs that would otherwise have been omitted and gaining information into the possible mechanism of action of the selected compounds [23]. Initially, the ZINC 15 library [24] was employed, and over 9 million compounds with a molecular weight below 200 g/mol were selected. The target SARS-CoV-2 Mpro crystal structure downloaded from the database has the PDB ID 6Y7M [25]. HTVS docking was performed using CmDock docking calculations considering the QuickProp, QPlogS descriptor that indicates possible soluble compounds, and 200 hits were selected. A set of Mpro inhibitors and viral cysteine protease inhibitors collected in the ChEMBL database with experimental IC50 < 100 μM were selected, and a set of 208 chemical descriptors were calculated to organize the compounds from the perspective of their representative chemical space [26].

Using this HTVS method, a set of top-scoring compounds that could inhibit SARS-CoV-2 main protease were identified for further compound prioritization in biological evaluation experiments (Table 1).

A different research group screened a library of molecules for their potential ability to inhibit SARS-CoV-2’s main protease (Mpro) and the receptor-binding domain (RBD) of the spike protein by using the molecular docking software AutoDock Vina [27]. Mpro is a peculiar cysteine protease of the coronavirus family and has a crucial role in mediating viral replication and transcription. The absence of a homologous human protease makes this protein an important target against COVID-19 [28].

The studies included 7675 molecules from the African Natural Product Database (AfroDB) and North African Natural Product Database (NANPDB), 43 FDA-approved antivirals, and 940 compounds derived from a machine learning study on viral Mpro [29]. AfroDB and NANPDB 470 were filtered using an ADMET predictor in order to include in the study only the compounds with low toxicity and molecular weight between 250 and 350 g/mol.

A library of 2430 compounds was selected and docked for the Mpro-ligand complex and RBD-ligand complex using Autodock Vina. A total of 36 compounds with binding affinities ≤−7.5 (kcal/mol) against both RBD and Mpro were selected and characterized for their binding affinity. After that, a predictor of biological activity using a Bayesian-based approach was accomplished and led to identifying 6 novel potential bioactive molecules. The leads selected NANPDB2245, NANPDB2403, fusidic acid, ZINC000095486008, ZINC0000556656943, and ZINC001645993538 (Figure 1) were subjected to molecular mechanics simulations involving molecular mechanics Poisson–Boltzmann surface area (MM/PBSA) calculations that showed stable protein–ligand complexes with all the compounds with free binding energies <−3.58 kcal/mol with each receptor. The compounds identified showed good pharmacological profiles with little toxicity. However, in vitro studies are still needed to corroborate the findings.

Recently, Born et al., devised a new method for discovering and synthesizing drugs against SARS-CoV-2 [30]. This procedure merges biology and chemistry for target-driven molecular design associated with an automatic synthesis plan generator and can be virtually applied to any protein target. The approach uses deep generative models that implement a conditional molecule generator to propose drug candidates by exploring the latent space of proteins and small molecules. The promise of this approach is the possibility to generalize to unseen targets.

In this way, a conditional molecular generator can produce novel structures expressly designed to target a protein of interest [31]. In this work, 41 SARS-CoV-2-related protein targets, as labeled in UniProt, have been retrieved, among which Mpro and spike are the most targeted ones.

The first step of the procedure consists of encoding the selected protein sequence in a continuous and compressed latent space. The latent representation of the profile is decoded through the molecular decoder of trained variational autoencoders (VAE), generating valid molecules as drug candidates. Prediction studies of the toxicity were also performed by employing the Tox21 database [32], and the molecules were screened against 12 toxicity assays of nuclear receptor and stress response pathways. Finally, they were divided into toxic and non-toxic. The selected compounds’ binding affinity was predicted using a multimodal deep learning model that classified compound–protein interaction samples as binding or non-binding.

To assess the feasibility of synthesizing the generated compounds, the retrosynthetic pathways of a subset of candidates for each target were assessed using the interface of IBM RXN (https://rxn.res.ibm.com/, accessed on 10 February 2022) [21]. For half of the generated molecules, the synthetic route could be accomplished in one or two steps starting from commercially available materials indicating that they are attractive drug candidates.

The founders of COVID Moonshot, a non-profit, open-science consortium of scientists from around the world dedicated to discovering globally affordable and easily manufactured antiviral drugs against COVID-19, demonstrated the utility of a de novo design using machine learning with synthesis route prediction [33]. The purpose of the study was to generate potential new drugs targeting the main protease (Mpro) of the novel coronavirus. In fact, while classic approaches tend to modify existing compounds, exploring limited chemical space, this machine learning method searches in a larger chemical space. The inconvenience of this approach is the expense of synthetic accessibility, but this can be overcome using machine learning to predict the synthetic route.

The learning-to-rank machine learning model [34] here reported consists of a classifier that predicts the activity of a molecule compared to another compound by considering the difference in pharmacophore fingerprint. The output is plotted in a curve reporting the relative activities of the considered compounds. The ligands’ ranking is better than a model that directly learns IC50. The model used for training was the FastAI Tabular model (J. Howardet et al., https://github.com/fastai/fastai, accessed on 10 February 2022) with the initial input features composed by Morgan, Atom Pair, and Topological Torsion fingerprints implemented in RDkit (RDKit: Open-Source Cheminformatics Software, https://www.rdkit.org, accessed on 10 February 2022).

After a selection of reasonable chemical perturbations, a fragmentation of synthetically accessible bonds, including amides and aromatic C–C and C–N, were performed, generating 8.8 million molecules that were compared to the most potent molecule in the dataset. The manifold platform was used to predict the synthetic route prediction of the identified compounds (https://postera.ai/manifold, accessed on 10 February 2022). Finally, the best five predicted molecules with no more than 4-step synthesis prediction were synthesized and evaluated for their ability to inhibit Mpro by fluorescence assay and are reported in Table 2, together with the most potent molecules obtained from the training set. Compound 16 that showed the best IC50 was also tested against OC43 coronavirus in a live-virus assay showing low cytotoxicity and discrete activity toward the virus (EC50 = 13 µM).

The Oak Ridge National Laboratory Summit supercomputer was used for in silico drug discovery using enhanced sampling molecular dynamics (MD) and assembly docking using the popular docking program Autodock Vina [35]. The Summit supercomputer is currently the fastest in the United States, hosted at the Oak Ridge Leadership Computing Facility (OLCF). Summit is an IBM AC922 system consisting of 4608 large nodes, each with six NVIDIA Volta V100 GPUs per node. The temperature replica exchange molecular dynamics (T-REMD) routine [36,37], which was chosen here for the MD calculations (see below), uses the interconnect not only to allow for parallelization of a single simulated molecule but also to communicate between separate replicas of the system, each carried out at a different temperature, and performs exchanges between replicas to accelerate the conformational sampling of the structures [38].

The 24 systems analyzed comprise nine protein domains. Two of these, RBD of protein S (spike) and the N-terminal region of protein N (nucleocapsid), are structural domains that are bound within the virion. Protein N is used for packaging the viral genome and is essential for virion assembly [39]. The remaining seven domains come from non-structural proteins (NSPs) 3, 5, 9, 10, 15, and 16, which form the replication complex and are involved in many key tasks that create new viral particles (Table 3) [40].

Two different docking databases were used—a potential ligand database merging the contents of SWEETLEADS [41] and the NCI-diversity database, yielding 13,757 compounds, and the Enamine database using an accelerated version of Autodock (Autodock-GPU).

The authors used an experimental screening database of 2900 chemicals tested by the National Institutes of Health, National Center for Advancing Translational Sciences (NCATS) and listed at https://opendata.ncats.nih.gov/covid19/databrowser, accessed on 10 February 2022), to compare with positives identified experimentally by NCATS.

Interestingly, all four experimentally tested compounds (i.e., 100% of the tested compounds in the top 10 lists) were strongly active.

The ensemble docking performed affects database reuse limited to approximately 10,000 compounds. Many of these compounds are expected to be quite promiscuous in binding to targets. Two of the compounds identified in the richest 1% of the preliminary protein S screening have been reported in two registered clinical trials (quercetin and hypericin).

Pirolli D. et al., with the support of machine learning approaches, reported a structure-based virtual screening as an effective strategy to discover inhibitors of protein–protein interactions (PPIs) between SARS-CoV-2 RBD and human ACE2 using the ZINC database [42].

Using different ligand- and structure-based approaches, a customized virtual screening (VS) strategy was set up. The first step of the VS strategy was the selection of a library focused on small molecule PPIs from a dataset of 2 million compounds, using a ligand-based approach capable of recognizing chemical characteristics and scaffolds common to known modulators. For this purpose, a convolutional neural network (cNN) was trained to obtain a QSAR model capable of identifying potential PPI modulators within a virtual library of unknown molecules. The molecules classified by the cNN-based QSAR as potential PPI modulators were further filtered by the expected toxicological properties to discard compounds harmful to human health. The resulting virtual library was hooked to ACE2 to identify compounds with the best binding affinity for the spike protein interaction surface. The dataset of 30,029 ligands obtained from QSAR modeling and toxicity analysis against the druggable site-4 pocket region was used to screen for effective inhibitors of the protein–protein interactions of the SARS-CoV-2 RBD/ACE2 tip. Then a virtual Glide screening in SP mode was performed, and the next phase was done by XP docking. Based on the docking score, the first 15,015 classified ligands (50%) were selected and reassessed with Prime MM-GBSA to estimate their binding free energy. The compounds were then filtered based on distance constraints by selecting only small molecules within 4.5 Å away from any atom of Tyr83 and Gln24 residues. The remaining 9730 molecules were then grouped based on their diversity, and the resulting 973 virtual hit compounds were further assembled into 66 clusters using interaction fingerprints.

The results indicated that most of the compounds screened share a high similarity (0.6–0.7) with the training set.

Four compounds were selected as potential ACE2 surface binders capable of preventing RBD spike recognition and thus infection (Table 4). The presence of an aromatic region facilitates the interaction with ACE2 Phe28 (compounds 2 and 3) and Tyr83 (compounds 1 and 4). Furthermore, ACE2 Gln24 and Tyr83 contribute to the stabilization of ligands 1, 2, and 4 within the binding site by forming hydrogen bonds to their hydroxyl groups. Compound 1 is stabilized by the hydrogen bonds formed by the catechol with the oxygen atom Gln24 and the cycloheptyl fraction with Tyr83. Similarly, compound 2 is hydrogen-bonded to Tyr83 and Gln24 oxygen atoms by its hydroxyl and carbonyl oxygen atoms.

Selected top-scoring compounds by HTVS on the SARS-CoV-2 main protease.

Ligand ID and structures of selected hit compounds.

The 5 compounds with predicted routes < 4 steps. The top 3 compounds from the training set, with potency and cytotoxicity measurements.

24 different model systems.

Structures and calculated free binding energies (MM-GBSA score, in kcal/mol) of four top-ranking compounds.

## Section: 3. Ligand-Based Artificial Intelligence Methods for Small Molecules

F. Pereira et al., succeeded in predicting five new inhibitors against SARS-CoV-2 Mpro using a CADD method based on a quantitative structure-activity relationship (QSAR) classification model that was built from 5276 organic molecules extracted from the ChEMBL database. Virtual screening was then performed using 11,162 marine natural products (MNPs) retrieved from the Reaxys® database. From the QSAR approach, 494 MNPs were selected and subsequently subjected to molecular docking against the Mpro. Among the evaluated compounds, five MNPs have been proposed as the most promising marine drugs as inhibitors of SARS-CoV-2 Mpro, among them a benzo[f]pyrano [4,3-b]chromene (Reaxys ID 7450892), notoamide I (Reaxys ID 19384758), hemindole SB beta-mannoside (Reaxys ID 26845562), and two derivatives of bromoindole (Reaxys IDs 10,714,788 and 10720065) Figure 2 [43].

The reported model developed by F. P. Silva-Jr et al., also outperformed the Chemprop model available for free on an external test set of fragments shielded against SARS-CoV-2 Mpro [45]. The method is divided into three main phases—formation and validation of the generative model based on general chemistry, development of the model for Mpro chemical space of SARS-CoV-inhibitors, and formation of a classifier for the prediction of bioactivity using transfer learning. Using the improved classifier to predict the bioactivity of the 70,000 valid SMILES, the authors classified 1697 active molecules, and the Uniform manifold approximation and projection (UMAP) plot showed good to optimal overlap between the predicted results and the actual value of inhibition for Mpro inhibitors in the studied chemical space. Among the resulting molecules, 20 compounds were classified as high-confidence hits, with probabilities ranging from 0.99 to 1.0. These molecules found to be potential inhibitors were then subjected to a docking simulation using the crystalline structure of SARS-CoV-2 Mpro (PDB: 6W79). Nine compounds showed binding poses similar to experimentally validated inhibitors in X-ray crystal complexes with Mpro. These molecules include three benzotriazoles and four benzothiazolylketones, a peptidomimetic, and an N-(2-pyridyl) acetamide derivative (Figure 4).

Roy et al. recently identified new chemical entities (NCEs) starting from a dataset of approximately 1.6 million drug-like small molecules from the ChEMBL database, which were collected for pre-training of a generative model [46]. The set of molecules obtained after applying the physicochemical property filters was screened using RDKit by applying the following four filters: Pan Assay Interference Compounds, the BRENK filter, the NIH filter, and the ZINC filter. These filters use rules to avoid toxic compounds and synthetically impractical molecules. Potential NCEs for synthesis and testing against SARS-CoV-2 were finally subjected to docking simulation and selected using a virtual screening score cutoff of −8.5 kcal/mol. The results showed that 5 of the top 15 compounds have a high virtual screening score and a remarkable similarity to existing protease inhibitors, notably one of these NCEs possessed a higher virtual screening score of −9.1 kcal/mol (Figure 5).

The unique approach to data curation coupled with random forest (RF) analysis by K. Cooper et al., produced a specific target and validated predictive fingerprints (PFFs) that have a high predictability value on multiple targets such as plasma kallikrein, HIV protease, NSP5, NSP12, AT-1, and the JAK family. This broad applicability to different biologically relevant targets (protease, RNA polymerase, G protein-coupled receptor (GPCR), tyrosine kinase, and a phenotypic assay) as well as to different chemotypes within a target is an important strength and differentiator of the applied methodology. The capability of this methodology allows for each target to create a binary decision tree for inactive or active compounds or a ternary decision tree for weakly active, moderately active, and highly active compounds also suggests that the models could be used for virtual screening of libraries of target-specific compounds to select the most active compounds for synthesis and/or clinical testing. Regarding the SARS-CoV-2 target, about 5600 FDA-approved drugs were examined in this study. Molecules that showed more than 75% inhibition were considered active, and among the wide range of FDA-approved drugs, 267 were identified as active. Leveraging the bioactivity data of ChEMBL and a subset of the data, it was trained on physicochemical characteristics from the set of 110 chemical properties, and a set of 868 compounds was then used to establish a binary classification model capable of predicting whether a molecule was active or inactive in the test; overall the model was able to identify the bioactivity with an accuracy of 65% [47].

E. Glaab et al., reported a combined virtual screening study, molecular dynamics (MD) simulation, machine learning, and in vitro experimental validation analysis, which led to the identification of small molecule inhibitors of 3CLpro with micromolar activity and to a pharmacophore model. The methodology consisted of a filtering system involving screening multiple receptors and ligands in combination with a final MD simulation to confirm the binding stability of the selected compounds. The structural screening was then integrated with machine learning-based screening for compound selection using a molecular-descriptive dataset derived from known ligands and non-ligands for 3CLpro. The best compounds selected using these in silico screening methods were then experimentally evaluated to determine the subset of stable ligands and their 3CLpro inhibitory activity using the in vitro Forster-type resonance energy transfer (FRET) assay. From the various screening analyses conducted, 95 molecules were identified and tested. Seven of these compounds were confirmed active, and one of them showed the lowest IC50 value of 31 µM [48].

The deep learning (DL) model can generate 1D or 2D sequences ligands structures. However, rational drug design requires 3D ligand structures that target the crystalline structure of proteins. To solve this problem, Q. Bai and coworkers developed MolAICal software, which allows to generate 3D drugs in the 3D pocket of protein targets by combining the merits of the deep learning model and classical algorithm. The software essentially consists of two modules. In the first one, FDA-approved drug fragments are used to train the Wasserstein-based deep learning model generative adversarial networks (WGANs). The generated fragments of the deep learning model are further used to grow the 3D ligands in the protein pocket. In the second module, drug-like molecules from the ZINC database are used to train the WGAN-based deep learning model. Then the affinities between the generated molecules and the proteins are evaluated through molecular docking experiments with AutodockVina. The membrane protein glucagon receptor (GCGR) and the non-membrane target SARS-CoV-2 Mpro were chosen to analyze the drug design capabilities of MolAICal. In this way, the software can generate various ligands that have an ever-higher 3D structural similarity with the ligand crystallized in the active site of GCGR or SARS-CoV-2 Mpro [49].

Mekni N. et al., developed a machine learning approach using support vector machine (SVM) classification, to share new knowledge for designing novel Mpro inhibitors from a dataset of two million commercially available compounds. The model was able to classify two hundred new chemotypes as potentially active against the viral protease [50].

Feature selection was made by implementing a python3 script using the Sklearn libraries. The script is available in the GitHub repository (https://github.com/NedraMekni/COVID-19, accessed on 10 February 2022).

The selection of the characteristics was based on the training set, with the aim of identifying the crucial molecular descriptors able to explain the possible correlation between the activity of the Mpro inhibitors and their chemical structures, implemented the elimination of the recursive characteristics of the random forest (RF-RFE) in order to select relevant molecular descriptors [51], leading to the automatic optimization of the number of features to be selected and to the definition of the optimal number of decision trees to build the forest. Compounds labeled as active by SVM were subsequently evaluated through consensus docking studies on two PDB structures, and their binding modes were compared with known protease inhibitors. Of the 25 facilities analyzed, only five (5RF6, 5RGW, 6WCO, 5R82, and 6W79) met the criteria. On these five PDBs, factor B (mean of the PDB B-value) was checked to assess the quality of the protein structure.

The five best compounds selected by consensus were then subjected to molecular dynamics to investigate the stability of the binding interactions.

MD simulations at 200 ns were performed on the two best performing PDBs (6WCO and 5RGW) to verify the stability of the interactions recovered within the crystal structure.

The five best compounds selected by consensus were then subjected to molecular dynamics to investigate the stability of the binding interactions. It should be noted that the compounds selected by SVM showed all the essential interactions reported in the literature.

Joel Kowalewski and Anandasankar Ray, collected test data from 65 known human target proteins that could interact with SARS-CoV-2 proteins, including the ACE2 receptor [52]. Next, they trained machine learning models to predict the inhibitory activity and used them to examine FDA-registered chemicals and approved drugs (~100,000) and ~14 million purchasable chemicals. The results were then filtered for mammalian toxicity and vapor pressure. Potential volatile candidates were proposed as drugs for inhalation therapies as the nasal cavity and airways are the first bottlenecks for infection. They also identified some candidates that may act on multiple targets.

S. Ekins et al., implemented several machine learning methods to develop predictive models from recent in vitro SARS-CoV-2 inhibition data and used them to prioritize additional FDA-approved compounds for in vitro testing selected from our in-house library of compounds [53]. From the compounds predicted using a Bayesian machine learning model, lumefantrine, an antimalarial, was selected for testing and showed limited antiviral activity in cells, whereas it was shown to bind (Kd 259 nM) to the spike protein using microscale thermophoresis. Several other selected compounds were tested in vitro by other research groups and found to be quite active. This combined machine learning approach and in vitro testing can be expanded to virtually screen available molecules with predicted activity against SARS-CoV-2 WIV04 and other circulating variants.

MNPs have been proposed as the most promising marine drug leads as inhibitors of SARS-CoV-2 Mpro.Combining a generative recurrent neural network model with transfer learning methods and active learning algorithms, R. Yassine et al. designed a novel set of small molecules capable of effectively inhibiting the 3CL protease in human cells [44]. The novelty of this work is the use of active learning methods with generative recurrent neural networks (RNNs) containing long-term memory cells (LSTM). The active learning method facilitates the selection process by focusing on the areas of the chemical space that have the best chance of success, considering structural novelties. The authors built a database consisting of multiple datasets such as FDA-approved drugs (from the ZINC database), natural products (from SuperNatural), and a manually developed database representing drug-like bioactive molecules. In the first phase of this study, by applying the RNN deep learning methodology, the LSTM-based RNN model was created to generate reliable and high-quality SMILES to design new drugs. Subsequently, molecules structurally similar to drugs with known activity against the specific SARS-CoV-2 target were generated. In this way, they were able to find a model capable of discovering new drugs using fragment-based drug discovery (FBDD) to create a library containing a series of SMILES inspired by the well-known compounds. The model generated 25,000 small molecules from the learned chemical space as described above. After removing duplicates and identical molecules from the database used for training, the remaining dataset consisted of 22,173 molecules. These molecules were then subjected to other filters such as physicochemical properties, drug similarity, and synthetic accessibility, resulting in a set of 6962 molecules. The generated molecules were then screened for affinity to the 3CL protease. After the virtual screening, a total of 41 molecules were obtained, with a virtual screening score of less than −7.0 kcal/mol. Among these, four molecules resulted in a binding affinity score lower than −18 kcal/mol (Figure 3).

The nine compounds reported by F. P. Silva-Jr et al., that showed similar binding positions to the experimentally validated inhibitors in X-ray crystal complexes with Mpro.

NCEs with the highest virtual screening score and a remarkable similarity to existing protease inhibitors.

## Section: 4. Artificial Intelligence Methods Vaccine Design

An in silico deep learning approach was proposed to predict and design a multiepitope vaccine (DeepVacPred), in combination with in silico immunoinformatics and deep neural network strategies. The DeepVacPred computing system directly predicted 26 potential vaccine subunits from the SARS-CoV-2 tip protein sequence [54].

The DNN architecture to block 26 fragments in the SARS-CoV-2 spike protein as candidates for the vaccine subunit was the first step proposed by the authors. Subsequently, linear B cell, CTL, and HTL epitopes were used to select and construct the final vaccine.

All overlapping protein fragments with a length of 30 aa were generated by the spike protein sequence 1273 aa SARS-CoV-2. DeepVacPred first tested these protein sequences and predicted 132 potential vaccine subunits. Following this prediction, DeepVacPred provided 26 potential vaccine subunits for further evaluation and construction. These subunits were those most likely to contain B cell epitopes and multiple T cell epitopes and have high antigenicity and low allergenicity.

In silico methods were used to study linear B cell epitopes, cytotoxic T cell epitopes (CTL), helper T cell epitopes (HTL) in the 26 candidate subunits.

The B cell epitopes, predicted on the 26 vaccine subunits, are parts of antigens that bind to immunoglobulin or antibody, capable of activating B cells to provide the immune response [55]. Linear B cell epitopes were predicted from four online servers, including BepiPred [56], SVMtrip [57], ABCPred [58], and BCPreds [59]. First, they used BepiPred for the main forecast and the other three servers to check the results of the BepiPred forecast. Additionally, the proprietary RaptorX server was used to evaluate the surface accessibility of SARS-CoV-2 to validate that the B cell epitopes in those subunits were well exposed.

CTLs recognize infected cells using class I MHCs to bind to certain CTL 26 epitopes. The NetMHCpan 4.1 server [60] 43 was used to predict potential CTL epitopes. All overlapping 9aa peptide sequences in the 14 vaccine subunits were tested with the 12 most common class I alleles of human leukocyte antigen (HLA), including HLA-A1, HLA-A2, HLA-A3, HLA-A24, HLA-A26, HLA-B7, HLA-B8, HLA-B27, HLA-B39, HLA-B44, HLA-B58, and HLA-B62, to evaluate their binding affinities and predict potential CTL epitopes [61,62].

HTL helps other immune cells’ activity and recognizes infection by using MHC class II to bind with specific HTL epitopes [63]. The NetMHCIIpan 4.0 [64] server was used to predict potential HTL epitopes. All overlapping 15aa peptide sequences in the 14 vaccine subunits were tested with the 13 most common HLA Class II alleles, including HLA-DRB1-0101, HLA-DRB1-0301, HLA-DRB1-0401, HLA-DRB1-0701, HLA-DRB1 -0801, HLA-DRB1-0901, HLA-DRB1-1001, HLA-DRB1-1101, HLA-DRB1-1201, HLA-DRB1-1301, HLA-DRB1-1401, HLA-DRB1-1501, and HLA-DRB1-1601, to evaluate their binding affinities and predict potential HTL epitopes [64]. The total HLA score was calculated for each vaccine subunit.

The 3D structure of the designed vaccine was then predicted, refined, and validated by other in silico tools. The GalaxyRefine [65] server was employed to refine the 3D structure model of the final vaccine. Among the five refined models predicted by GalaxyRefine, model 2 was chosen as the final vaccine model based on its quality scores with a reported RMSD of 0.58.

In conclusion, this proposed artificial intelligence (AI)-based vaccine discovery facility accelerated the vaccine design process and built a 694 aa multiepitope vaccine containing 16 B cell epitopes, 82 CTL epitopes, and 89 HTL epitopes, which promise to fight SARS-CoV-2 viral infection with good antigenicity, population coverage, and good physicochemical properties and structures, providing great potential for next stage of COVID-19 vaccine design with actual clinical trials.

AI was used in another study to predict the rationale for designing universal vaccines against SARS-CoV-2, which contain an extensive repertoire of T-cell epitopes capable of providing coverage and protection to the global population. To achieve these goals, the authors profiled the entire SARS-CoV-2 proteome through the 100 most frequent HLA-A, HLA-B, and HLA-DR alleles in the human population, using the presentation of the cell surface antigen infected with host and immunogenicity predictors from the NEC Immune Profiler suite of tools and generated sufficiently complete epitope maps [66].

Antigen (AP) presentation was predicted by a machine learning model that integrates information from several HLA binding predictors (in this case, three distinct HLA binding predictors trained on IC50 nm binding affinity data) and 13 different antigen processing predictors. The emitted AP score ranged from 0 to 1 and was used as an input to calculate immune presentation (IP) through the epitope map, penalizing those peptides that have degrees of similarity when compared to the human proteome, and rewarding peptides that are less similar. The resulting IP score represents those presented HLA peptides that can be recognized by circulating T cells.

Epitope maps were created for all viral proteins and an example based on IP scores for proteins containing the candidate CD8 and CD4 epitopes for the 100 most frequent human HLA-A, HLA-B, and HLA-DR alleles.

Epitope hotspots that shared significant homology with proteins in the human proteome were removed to reduce the possibility of inducing off-target autoimmune responses. In addition, the antigen presentation and immunogenic landscape of all non-synonymous mutations in 3400 different virus sequences in the GISAID database with the AP potential of the Wuhan Genbank reference sequence were also analyzed to identify a trend by which SARS-CoV-2 mutations are expected to have a reduced potential to be introduced by host-infected cells and, consequently, be detected by the host’s immune system.

In order to assess whether epitope hotspots are solid enough across sequenced and mutant strains of SARS-CoV-2, the AP-based Monte Carlo epitope hotspot statistical model was used, and 10 virus sequences were analyzed among the 10 most mutated viral sequences across different geographical regions [67]. Most of the hotspots were present in all sequenced viruses; however, the hotspots were eliminated and/or new hotspots emerged in these divergent strains.

This is the first computational approach to generate vaccine designs from large-scale epitope maps of SARS-CoV-2, optimized on diverse T-cell immune responses across the global population.

Finally, an HLA haplotype database of approximately 22,000 individuals was evaluated to develop a “digital twin” simulation to model the effectiveness of different combinations of hotspots in a diverse human population; the approach identified an optimal variety of epitope hotspots that could provide maximum coverage in the global population.

The CD8 epitope maps of these optimized epitope hotspots are based on AP predictions of the peptides presented on the surface of the host-infected cells and visible to the host’s CD8 T cells. Furthermore, these antigen-presented peptides are subject to IP predictions, which infer the epitopes most likely to activate a T cell.

In conclusion, the authors combined antigen presentation at the infected host cell surface and immunogenicity predictions from the NEC Immune Profiler with a robust Monte Carlo and digital twin simulation in order to delineate the entire SARS-CoV-2 proteome and identify a subset of epitope hotspots that could be exploited in rational vaccine design to provide broad coverage across the global population [68].

Kesarwani et al., examined data acquired from proteomic analyses of human cell lines infected with SARS-CoV-2 and COVID-19 patient samples to identify peptides useful for diagnostics and vaccine development. Initially, a large-scale meta-analysis of changes in 358,558 SARS-CoV-2 protein sequences detected in samples from 42 countries was performed. For sequence conservation analysis, a protein data cluster was generated for each SASR-CoV-2 protein. Hence, there were 5 regions and 14 regions for the nucleocapsid and spike proteins, respectively [69].

Two cell lines and four proteomes from naturally infected human patients were used for high-confidence identification of peptides using viral and human protein sequences as references. In total, 361 and 81 peptides of viral origin were identified in cell lines and patient samples, respectively. A few peptides with varying lengths were found from different parts of the same proteins, including 57 component peptides of the spike protein. Of these 57 peptides, three are components of the S1 (14–685), S2 (686–1273), and RBD (319–541) regions of the spike protein, respectively.

Therefore, the authors explored host responses to the virus in both cell lines (colon carcinoma-2 and H1299) and naturally infected COVID-19 patient samples. Many proteins are involved in biological processes related to the immune system, such as regulation of immune responses, leukocyte migration, autophagy, processing, immune system development, antigen presentation, or leukocyte-mediated cytotoxicity.

323 and 143 human peptides were identified in the cell line and patients, respectively. Only five (MDGA1, PIK3C2A, FOXP2, DCAF5, and IVD) were detected in both sample sets. While MDGA1 plays an important role in inhibitory synapse formation [70], PIK3C2A is involved in several intracellular traffic and signaling pathways [71]. FOXP2 is a transcription factor that can regulate hundreds of genes in different tissues, including the brain [72]. DCAF5 is a receptor of the CUL4-DDB1 E3 ubiquitin-protein ligase [73], and IVD is an enzyme essential for the beta-oxidation of mitochondrial fatty acids.

Thirty-three proteins were found and matched entries in the InnateDB database. Most of these proteins are involved in immune-related functions such as protein binding (TAB1, SREBF2, HSP90AA1, RB1, STAT3, DCN, IL1R1, BNT3A2, PIK3R2, CCR6), transferase activity (TREM2, ABL1, S100A12, C4BPB), the protein dimerization (UBE2N, CSF1R) and lipopeptide binding (EPS8, CD36) [74].

Once the proteins related to the immune system process were identified from the patients’ cell line and proteomes, they were used to generate a protein interaction network. The generated protein interaction network, which includes 403 nodes and 671 edges, identified higher-ranking hubs and bottlenecks.

Therefore, multi-step filtering was applied to identify potential diagnostic peptides. Initially, to avoid cross-reactivity, the identified peptides (442) were filtered to exclude peptides from the human and human saliva microbiome (418) and subsequently peptides from a targeted group of pathogenic bacteria and viruses (129). Subsequently, using the results of the RNA-Seq data analysis of the infected cell lines, the expression of the selected peptides was verified to avoid the selection of poor peptides for diagnostic purposes. Then, four antigenic peptides were selected for attachment to known viral T-cell receptor (TCR), class I and II peptide major histocompatibility complex (pMHC), and paratopes sequences identified. They also tested the paratope binding affinity of SARS-CoV-1 T and B cell peptides that had previously been experimentally validated. The resulting antigenic peptides have a high potential for generating antibodies specific to SARS-CoV-2, and the peptides of the paratopes can be used directly to develop a COVID-19 diagnostic assay

The antigenic peptides found in this study have a high potential for generating antibodies specific to SARS-CoV-2, and the paratopes peptides can be used directly to develop a COVID-19 diagnostic assay. In addition, the paratope binding affinity of SARS-CoV-1 T and B cell peptides that had previously been experimentally validated was also tested. The assembled paratopes showed a greater binding affinity for SARS-CoV-2 antigens and proteins than SARS-CoV-1.

In conclusion, the authors in this study explored both the cell line and proteomes of naturally infected COVID-19 patients via in silico methods and identified four SARS-CoV-2 antigens and three antigen-binding peptides that could be used to develop diagnostic assays. The proposed antigenic peptides can be used for antibody generation, and the paratopes sequences can be used directly for COVID-19 diagnostic test and vaccine development.

## Section: 5. Conclusions and Perspective

AI technologies have shown impressive ability in COVID-19 research, from real-time tracking of the virus spread to the development of novel drugs and vaccines faster than ever before. Unfortunately, the high number of positive cases and deaths from COVID-19 infection and the absence of effective treatments and complete cover by vaccination persist in influencing global health, necessitating the discovery of novel molecules for the cure and prevention of the infection. Structural definition of targetable proteins for therapy and prevention of the infection has recently boosted the structure-based virtual identification of small molecules. The discovery of some promising compounds has driven the optimization of those scaffolds through ligand-based drug design.

In this review, we reported and discussed the more cutting-edge technologies in the field of COVID-19 de novo drug design, from ligand-based AI technologies, where only the ligands’ structures are considered to train the models, to structure-based AI technologies, where the protein target is also taken into account in the process of drug design, and to vaccine design aided by AI. ML on its own and other AI-based technologies are of critical importance in responding to problems in COVID-19 research. They are proven to be efficient tools to quickly analyze large amounts of data, estimate drug repurposing against COVID-2019, identify the association of these repurposed drugs, or estimate dosage adjustments and other clinical issues such as early diagnosis, identifying people at risk, and predicting disease evolution [75,76].

The de novo drug design field is also part of the AI-lead research in the COVID-19 field. As reported in this review, several molecules have already been identified from impressively large databases of billions of compounds. Additionally, pairing different approaches considering all the information produced by omics sciences should lead to developing personalized strategies. Due to the mutability of this RNA virus and the emergence of drug resistance problems, it is mandatory to start considering targeting multiple targets which may be more effective and help in overcoming future drug resistance.

Interestingly, although none of the de novo-identified molecules has entered clinical trials, some of the repurposed molecules identified by AI technologies have entered this phase. These are mainly already used and approved antibiotics, anti-inflammatory, antivirals, anticancer, and ACE2, and some other drugs, that are already in clinical trials according to ClinicalTrials.gov (https://clinicaltrials.gov/, accessed on 10 February 2022) [77]. In conclusion, as the pandemic crisis has exponentially accelerated the adoption of analytics and AI, it is not surprising that AI leads the research on prevention, not only of COVID-19-related issues but also many for other diseases in the following decade, speeding up the drug design process and placing AI at the forefront of the battle against public health problems.

## Section: Text

The generated molecules by R. Yassine et al., with the lowest binding affinity scores.

## Section: Author Contributions

Conceptualization, G.F. and A.R.; formal analysis, C.Z., V.P., G.F., D.G. and A.R.; investigation, C.Z., V.P., G.F., D.G. and A.R.; resources, C.Z., V.P., G.F., D.G. and A.R.; writing—original draft preparation, C.Z., V.P., G.F. and D.G.; writing—review and editing, C.Z., V.P., G.F. and A.R.; supervision, A.R. and G.F.; project administration, A.R. All authors have read and agreed to the published version of the manuscript.

## Section: Funding

This research received no external funding.

## Section: Institutional Review Board Statement

Not applicable.

## Section: Informed Consent Statement

Not applicable.

## Section: Data Availability Statement

Data sharing not applicable to this article as no data sets were generated or analyzed during the current study.

## Section: Conflicts of Interest

The authors declare no conflict of interest.

## Section: Associated Data › Data Availability Statement

Data sharing not applicable to this article as no data sets were generated or analyzed during the current study.


---

# Automated Drug Coding Using Artificial Intelligence: An Evaluation of WHODrug Koda on Adverse Event Reports

- **Authors:** Eva-Lisa Meldau, Shachi Bista, Emma Rofors, Lucie M Gattepaille
- **Issuer:** Drug safety
- **Type:** Scientific article
- **Published:** 2022-05-17
- **Language:** en
- **DOI:** 10.1007/s40264-022-01162-7
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35579817/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractIntroductionCoding medicinal products described on adverse event (AE) reports to specific entries in standardised drug dictionaries, such as WHODrug Global, is a time-consuming step in case processing activities despite its potential for automation. Many organisations are already partially automating drug coding using text-processing methods and synonym lists, however addressing challenges such as misspellings, abbreviations or ambiguous trade names requires more advanced methods. WHODrug Koda is a drug coding engine using text-processing algorithms, built-in coding rules and machine learning to code drug verbatims to WHODrug Global.ObjectiveOur aim was to evaluate the drug coding performance of WHODrug Koda on AE reports from VigiBase, the World Health Organization’s global database of individual case safety reports, in terms of level of automation and coding quality.MethodsKoda was evaluated on 4.8 million drug entries from VigiBase. Automation level was computed as the proportion of drug entries automatically coded by Koda and was compared to a simple case-insensitive text-matching algorithm. Coding quality was evaluated in terms of coding accuracy, by comparing Koda’s prediction to the WHODrug entries found on the AE reports in VigiBase. To better understand the cases in which Koda’s coding results did not match with the WHODrug entries in VigiBase, a manual assessment of 600 samples of disagreeing encodings was performed by two teams of expert drug coders.ResultsCompared with a simple direct-match baseline, Koda can increase the automation level from 61% to 89%, while providing high coding quality with an accuracy of 97%.ConclusionsEven though Koda was designed for use in clinical trials, Koda achieves automation level and coding quality for drug coding of AE reports comparable with the performance observed in a previous evaluation of Koda on clinical trial data. Koda can thus help organisations to automate their drug coding of AE reports to a large degree.

## Section: Introduction

Drug coding to standardised terminologies is a crucial data processing step to enable structuring drug information from various data sources such as Electronic Health Records (EHRs) systems, Electronic Data Capturing systems for clinical trials and spontaneous reporting databases for postmarketing surveillance of drugs [1–3]. In EHRs, mentions of medications can be found in clinical notes or coded directly to a drug dictionary [4]. Being able to accurately associate patients to drug exposures allows the statistical utilisation of the data for epidemiological studies in these real-world data sources [5]. The use of standardised drug terminology in EHR systems can also facilitate the exchange of information between different parts of healthcare [6, 7]. In clinical trials, coding concomitant medications uniformly can be challenging due to multicentric trials across several countries. Coding trade names of local markets into a global drug dictionary allows identification of the active ingredients involved and thus the harmonisation of inclusion and exclusion criteria across all drug markets. In postmarketing surveillance, coding reported medications to standardised terminologies is necessary to link the adverse events (AE) to the appropriate medicinal products and subsequently to identify safety signals for the associated active ingredients across all related products or groups of products sharing similar properties [2, 3].

In the three aforementioned contexts, data about medications may be first entered in the respective systems in free-text form before being handled manually or programmatically in a second standardisation step, where the verbatim descriptions of the medications are coded to a standardised terminology. Even with some degree of automation, this task can be time-consuming [8] and fully automating it is non-trivial. Verbatims might contain abbreviations, misspellings, or ambiguous trade names, or might not match directly to a record in the drug terminology for other reasons, and thus require either trained experts or support of advanced technical tools, either based on synonym dictionaries or on artificial intelligence (AI).

In this paper, we evaluate one such system, WHODrug Koda, an AI-powered drug coding engine that is designed to automatically code drug verbatims to entries in WHODrug Global [2], with the help of optional, user-provided additional drug information. Originally developed for the purpose of coding concomitant drugs in clinical trials, WHODrug Koda could be used in the context of coding drugs reported on the AE reports used in postmarketing surveillance. The purpose of this paper was therefore to evaluate WHODrug Koda in such a context by quantifying the algorithm’s effectiveness and accuracy on reported drugs found in VigiBase, the WHO global database of individual case safety reports. In this article, individual case safety reports from VigiBase are referred to as AE reports and WHODrug Koda is referred to as Koda.

## Section: Background › Drug Coding

In Natural Language Processing (NLP), in general and especially medical NLP, the task of mapping a concept of interest given in free text (either recognised during Named Entity Recognition [NER] or given in a free-text data field) to a specific, unambiguous entry in a terminology of choice is a challenging task and still an open area of research [4]. During subsequent analysis, the concept may then be represented by the entry in the terminology. This allows grouping semantically identical or related concepts into a single term and limits the number of concepts in the analyses [4, 9]. Most data-mining pipelines based on free text include such a mapping step. For example, numerous studies based on clinical text describe a mining algorithm to extract clinically relevant information and map that information to appropriate terminologies (e.g. medical conditions mapped to SNOMED CT [10–12] or MedDRA [13, 14] codes, temporal expressions mapped to the ISO-TimeML standard [15, 16]).

Drug coding or drug mapping is an example of a standardisation task where the concepts to be mapped are medicinal products and the terminologies used are drug dictionaries such as RxNorm, the Anatomical Therapeutic Chemical (ATC) classification system, or WHODrug Global. Developed by the US National Library of Medicine (NLM), RxNorm has been created to address the need for interoperability across medical information systems. It provides standardised drug codes based on ingredient(s), dose form and strength(s), and links these codes to other drug terminologies, such as the National Drug File Reference Terminology (NDF-RT) or the National Drug Code (NDC) directory used by the US FDA [3]. RxNorm has been used for drug NER [17]. The ATC system is a hierarchical classification system developed and maintained by the WHO Collaborating Centre for Drug Statistics Methodology that classifies active drugs according to the organ or system on which they act, as well as their therapeutic, pharmacological and chemical properties. WHODrug Global [2] is a resource for drug coding in international databases. It has global coverage of trade names from 167 different drug markets and is developed and maintained by the Uppsala Monitoring Centre (UMC), the WHO Collaborating Centre for International Drug Monitoring. WHODrug Global contains information about medicinal products and active substances intended for human and medicinal use, both of conventional and natural origin. The records included in the dictionary are classified as trade names (the name under which a medicinal product is marketed), generic records (substance information) or umbrella records, which describe a drug category (e.g., Hormonal contraceptives for systemic use or Cough and cold preparations). In the remainder of the paper, we refer to WHODrug Global as WHODrug. All drug names in WHODrug have one or more assigned ATC codes, representing either an official code assigned by the WHO Collaborating Centre for Drug Statistics Methodology or additional UMC-assigned codes. UMC-assigned ATC codes are included due to the specific use cases of WHODrug, when official ATC codes are not sufficient for efficient analysis of medicinal products and their properties.

In postmarketing surveillance and clinical trials, drug coding involves coding the verbatim describing the active substance or product used by the patient to a drug terminology. Additional information, such as the strength, the dosage form or the indication of the product may be used to inform the coding decision [18]. Since the verbatim might be entered manually, it can contain abbreviations, misspellings, and the trade name, with or without the corresponding active ingredients, and might not be formatted consistently, depending on data entry conventions. Drug coding can also be challenging when the trade names used are ambiguous. Aircort, for example, is a trade name that is marketed in both Morocco and Italy; however, while it represents a product containing Beclometasone dipropionate in Morocco, Aircort represents a product containing Budesonide in Italy. Even within a single drug market, ambiguous trade names can be found: Losec is a trade name in Sweden marketed in different pharmaceutical formulations such as injections and tablets. Depending on the form, different variations of the active ingredient are used, for example the omeprazole magnesium variation is used in tablets and the omeprazole sodium variation is used in injection formulations. Addressing these challenges, which present varying degrees of complexity, may require the expertise of trained coders and makes drug coding a time-consuming task. In the context of safety case processing, based on a survey of pharmaceutical companies, the drug and AE coding part of the case processing is estimated to take 1–4 min per case [8]. Although drug coding appears to be performed manually to a large degree, in both the postmarketing surveillance and the clinical trials contexts, there have been some recent efforts to automate the task [19, 20].

Tools for drug coding through direct matches of the verbatim, with or without transformation, to drug terminologies can be referred to as auto-encoders and the process itself auto-coding or auto-encoding [2, 18]. Direct matches are coded automatically to the drug terminology of interest [18] and synonym lists are commonly created by organisations during manual coding to record and reapply coding decisions. However, the creation and maintenance of such synonym lists requires considerable amounts of manual work. In order to facilitate some of this work, some drug-coding systems proposed use reordering of tokens or different text-processing steps. Systems developed for RxNorm, for example, identify the different parts of the drug name, i.e., ingredient, product name, strength and form, and standardise to the appropriate format [1, 17, 21]. Neither synonym lists nor text-processing methods can, with certainty, select between ambiguous drug names.

More advanced, AI-based systems may help in dealing with ambiguities. To our knowledge, there are very few such systems in use. One study explored the use of deep neural networks to code non-standardised drug order texts in EHRs to ATC codes [22]. The authors evaluated their drug-coding system as a ranking system and reached a Mean Reciprocal Rank of 98% on their dataset comprising fewer than 1000 drug-order texts from one medical centre. In another study, Abatemarco and colleagues [20] proposed a deep neural network approach to WHODrug coding and other case processing tasks. They trained two different models towards this task, a drug entity recognition model that identifies the drug mentions in the case narrative and a subsequent classifier mapping the detected entities to WHODrug. They reported a top-5 accuracy score of 98% for the mapping task. However, a system that can only reliably predict the correct record in a top-5 list would require a human expert to select the correct record in all cases. Therefore, such a system is only supporting, instead of automating, the task. In contrast to drug coding, the task of drug name extraction or NER of drugs has been more frequently approached using machine-learning methods and, in recent years, deep neural networks have been applied for drug name extraction [20, 23, 24].

## Section: Background › Drug Coding with WHODrug Koda

WHODrug Koda is an automated coding engine custom built by UMC. Koda is one of the first AI-based drug coding systems available for use.1 The purpose of Koda is to assist coders in interpreting free-text drug information selecting the most appropriate drug name in WHODrug. Koda can scale-up coding capacity and support drug coders in their manual work.

For a given drug entry, Koda does one of the following: (1) select a WHODrug record with high certainty; (2) suggest a set of WHODrug records to choose from; or (3) leave the entry uncoded, in cases requiring human expertise. Inputs to Koda consist of a verbatim and optional fields about the route, indication and country in which the product was obtained. In the case of ambiguous drug names, Koda harnesses the additional information, if provided, to identify the correct WHODrug record. Koda also has the ability to select the most appropriate of the ATC codes assigned to a WHODrug record per intended use, meeting regulatory expectations for coding concomitant medications in clinical trials [26]. However, because ATC selection is usually not part of AE case processing, evaluating Koda for its ATC selection capabilities is out of scope in this study and we evaluated Koda on its WHODrug coding capabilities exclusively.

To select the correct record in WHODrug, Koda uses a combination of text-processing algorithms, built-in coding rules and machine learning. The machine learning module was trained on a dataset of millions of reported drugs in VigiBase, combined with annotations established by a team of drug-coding experts. It is retrained by UMC on every new WHODrug version to ensure that Koda stays up to date with new additions and changes in the dictionary.

To ensure that Koda follows the most recent coding guidelines for coding concomitant drugs, it also uses built-in coding rules. The coding rules have been developed in collaboration with a reference group consisting of experienced coders from the industry and are aligned with accepted best practices (such as the WHODrug Best Practices [27]) and regulatory expectations [26]. Three coding rules can be toggled in Koda to enable user-specific coding conventions: the preferred base rule, the generic rule, and the country rule. Koda can fall back on these coding rules in cases where route and indication information cannot disambiguate the drug names. The preferred base coding rule allows Koda to select the base substance in cases where the trade name is ambiguous. For example, the trade name Doxycyclin Al contains different salt variations of Doxycycline depending on the pharmaceutical formulation. In cases where Koda is unable to code to one specific trade name, the preferred base substance Doxycycline will be selected. The generic rule allows Koda to select the generic record in the dictionary if a trade name is marketed with the same name as a generic record. For example, the generic record Magnesium will be selected even though there is a trade name with the same name but different active ingredients. The country rule allows Koda to utilise the country information to select the correct trade name in the dictionary.

An independent study performed at Novo Nordisk evaluated Koda for its coding performance for coding concomitant drugs in clinical trials [19]. The authors found that 79% of the concomitant drugs in their dataset could be coded to a WHODrug record with a high certainty by Koda. Koda could additionally make suggestions for 15% of the drugs, leaving 6% of the drugs uncoded. For 96% of the drugs coded with high certainty, Koda’s prediction agreed with the existing coding done by Novo Nordisk internal coding practices. During manual evaluation of a sample of 181 disagreeing drug encodings, the assessors found the Koda encoding to be at least as acceptable and precise as the Novo Nordisk encoding for 90% of the drugs. The performance of Koda for drug coding on AE reports is as yet unknown. Evaluation of Koda for drug coding on AE reports is the purpose of this study.

## Section: Methods

Steps for the extraction of the evaluation dataset and the general data statistics after each step

Description of Koda input fields

## Section: Methods › Evaluation Data

Figure 1 shows the creation of the evaluation dataset. In a first step, we extracted all AE reports first received in VigiBase between 1 January 2020 and 31 December 2020 (included). The deduplicated version of VigiBase for this time period was used, where duplicate removal had been performed using the vigiMatch algorithm [28]. For each reported drug, we extracted the description of the drug—the original, verbatim description of the drug received from the primary source of the report, the indication (when provided), the route of administration (when provided), and the country where the drug was obtained (when available, otherwise inferred as the primary source country of the report) (Table 1). In this study, each instance of verbatim, route, indication and country for a given reported drug is referred to as a Koda input and represents one reported drug in our evaluation dataset.

As Koda does not handle non-Latin characters, we excluded all Koda inputs containing at least two non-Latin characters2 (see step 2 in Fig. 1). In step 3, we also excluded reported drugs that, at the extraction date, had not been mapped in VigiBase to any WHODrug record (e.g., invalid drug information, drugs awaiting manual coding). The remaining Koda inputs constituted our final evaluation dataset, all written using the Latin alphabet and associated with a valid WHODrug record. Newline characters were removed from all free-text fields. No additional pre-processing was applied. As our evaluation dataset is extracted from VigiBase, each Koda input has a corresponding VigiBase encoding, which is what the drug has been mapped to in VigiBase. This VigiBase encoding is considered a gold-standard label and is used to evaluate the Koda prediction. Importantly, none of the reports included in the evaluation dataset and their associated gold-standard labels were used to train Koda.

Steps for the extraction of the evaluation dataset and the general data statistics after each step

Description of Koda input fields

## Section: Methods › Construction of the Gold Standard

The WHODrug records created by UMC’s internal coding processes and stored in VigiBase formed our gold-standard labels and were used to evaluate the correctness of Koda encodings. During UMC’s coding processes, reported drugs on AE reports in VigiBase are coded by an automated process that is independent of Koda and consists of directly matching verbatims to WHODrug in combination with text-processing algorithms, as well as a compiled synonym list. When this is not successful, the more challenging cases are manually coded by an expert who investigates the information on the report to make the coding decision. The coding experts follow UMC’s internal coding rules, which are based on WHODrug Best Practices [27], to assure high quality and consistency of the coded data. They also feed coding decisions back to the automated process by updating the synonym list to reuse the coding decisions on similar contexts in the future.

A significant proportion of the manual coding step involves resolution of ambiguous drug names, also referred to as non-unique trade names. They share the same drug name in WHODrug but include different active ingredients and thus correspond to different records in the dictionary [27]. To differentiate ambiguous drug names in WHODrug, in the B3-format3 of the dictionary, trade names are appended with an alphabetically ordered list of active ingredients. Ambiguous drug names appear in WHODrug if:

To measure Koda’s performance against ambiguous drug names, we defined a Koda input to reference an ambiguous drug name if the gold-standard WHODrug record fulfilled any of the five above-mentioned criteria in the WHODrug March 2021 release.

## Section: Methods › Models

This study used the March 2021 release of Koda, with the preferred base, generic and country rules turned on. It coded drug entries to the March 2021 release of WHODrug (B3-format), selecting records at high certainty, as suggested, or leaving them uncoded.

To give Koda a baseline comparator and to show how much simple automation can be used to solve the task of drug coding on AE reports, we compared Koda’s coding results to the encodings created by a case-insensitive text-matching algorithm, where verbatims were searched against all drug names in the March 2021 release of WHODrug in B3-format. This baseline algorithm coded to the record for which the drug name in WHODrug matches the verbatim exactly, disregarding letter case differences. No preprocessing was performed on the verbatim to keep the model as simple as possible. Based on the text-matching approach described above, ambiguous drug names were only matched when the verbatim provided the list of active ingredients in the correct format, or, alternatively, if they corresponded exactly to a generic record. This behaviour corresponded to a coding convention allowing ambiguous drug names to be coded to a generic record if it exists.

## Section: Methods › Evaluation Metrics

Automation level was measured by the proportion of Koda inputs coded by Koda at high certainty. The proportion was compared with the baseline model described in the paragraph above, where a successful match to a WHODrug drug name was considered coded.

Coding quality indicates how good Koda was at selecting or suggesting the correct drug record for a given input. This was measured in terms of accuracy as well as precision, recall and F1 score, comparing Koda’s prediction against the gold-standard drug encoding present in our evaluation dataset. The accuracy was computed overall and per Koda confidence level (high certainty, suggested or uncoded). For the high-certainty cases, we directly compared the drug encoding in the gold standard with the drug encoding predicted by Koda. A positive match was obtained when the gold-standard encoding and Koda encoding were identical, while a mismatch was obtained in any other case. A similar strategy was used to compare Koda’s suggested encodings to the gold standard. A positive match was obtained when one of the suggested encodings was identical to the gold standard at the detail level provided by the B3-format. The coding quality was then computed as the proportion of positive matches between the outputs from Koda and the gold standard. Precision, recall and F1-score were computed for all Koda inputs as the macro average across all WHODrug records present in the gold standard and as a weighted average of the metrics per WHODrug record, weighing each record by its prevalence in the gold standard. In all precision, recall and F1 computations, any suggested or uncoded Koda prediction counts as a false negative for the associated gold-standard WHODrug record.

## Section: Methods › Manual Evaluation of Mismatches to the Gold Standard

To better understand Koda’s coding quality, we manually evaluated cases in which Koda failed to predict the gold-standard encodings. For this, we randomly sampled 200 high-certainty mismatches, 200 suggested encodings where no suggestion matched the gold standard, and 200 Koda inputs left uncoded by Koda. We consequently categorised each mismatch and summarised the results on Koda's confidence levels. The assessment was done by five drug coding experts divided into two independent teams. Inter-annotator agreement for each confidence level was measured between the two teams using Cohen’s kappa statistic to judge the reliability of the assessments and as an indirect measure for the difficulty of the task.

For the high-certainty samples, we considered four categories of mismatches: (1) Koda’s encoding was more precise; (2) the gold-standard encoding was more precise; (3) both were acceptable; and (4) both were incorrect.

For the suggested samples, the categories were (1) the gold-standard encoding was more precise than any of Koda’s predictions; (2) at least one Koda suggestion was more precise; (3) both the gold-standard encoding and at least one Koda suggestion were acceptable; and (4) none of the encodings was acceptable.

Finally, for the uncoded samples, we considered the three following categories: (1) the gold-standard encoding was correct; (2) the gold-standard encoding needed manual review based on the available information from the Koda input; or (3) the gold-standard encoding was not correct.

## Section: Methods › Effect of Route, Indication and Country Fields

Koda was designed to not only automate simple coding decisions but to also enable the coding of ambiguous drug names. Fields such as indication, route, and country, while optional, are assumed to provide additional context to Koda when the verbatim alone is not enough to resolve these ambiguous drug names. To test this hypothesis, we performed a masking experiment on a sample of Koda inputs in the evaluation dataset. Due to computational limitations, it was not possible to perform this experiment for all Koda inputs from the gold standard that had been coded to an ambiguous drug name. We therefore randomly sampled 2500 Koda inputs from the set of unique Koda inputs where all fields were non-empty and where the gold-standard label was an ambiguous drug name (ambiguous, as defined in Sect. 3.2). We refer to these 2500 unique ambiguous Koda inputs as the Verbatim-Route-Indication-Country (VRIC) dataset.

From the VRIC dataset, five additional synthetic datasets were derived through masking combinations of the optional fields: (1) the V dataset, retaining only the verbatim field while route, indication and country fields are masked; (2) the VC dataset, where the verbatim and country were kept but the route and indication were masked; (3) the VRC dataset, where only the indication was masked; (4) the VIC dataset, where only the route was masked; and finally (5) the VRI dataset, where only the country field was masked. Together, these five datasets were run through Koda with identical coding rule configuration. Country was treated slightly differently from the route and indication fields because the country field is linked to the country coding rule of Koda. Country information is also typically present on AE reports but not necessarily available in the clinical trial context.

In our analysis, we used the VRIC dataset with all fields present as a reference dataset, which we compared against the masked versions to see how the additional fields affected Koda’s automation level and the WHODrug record selection.

## Section: Results

Top-5 report countries in the evaluation dataset

Top-5 report qualification in the evaluation dataset

Top-5 reported drugs in the evaluation dataset

Top-5 reported ATC codes in the evaluation dataset

Descriptive statistics of WHODrug records in the evaluation dataset

a Koda’s automation level showing percentages of high certainty, suggested encodings and uncoded Koda inputs compared with the direct-match baseline. b Agreement between high-certainty Koda encodings and gold standard. c Agreement between Koda suggestions and gold standard

Number of options provided by Koda when coding as suggested

Centre and dispersion of the number of options for suggested encodings

Macro average precision, recall and F1 score across all WHODrug records in the gold standard, and the average of these metrics per WHODrug record weighted by the classes’ prevalence in the gold standard for WHODrug Koda and our direct-match baseline

Manual assessment results for Koda’s three confidence levels

Result of masking exper﻿iment, masking various fields

## Section: Results › Evaluation Data Overview

After step 1 in our dataset preparation as depicted in Fig. 1, we had extracted 2,643,724 reports that had been received in VigiBase in 2020 and after duplicate removal. These covered 184 countries and territories and contained 6,210,569 reported drugs, with an average of two reported drugs per report.

Our final evaluation dataset contains 1,936,062 reports from 181 countries and territories and 4,845,505 Koda inputs, all written using the Latin alphabet and associated with a valid WHODrug record. The 4,845,505 Koda inputs can be grouped into 907,153 unique Koda inputs.

The top-five countries represented on the reports, as well as the reporter qualifications, are presented in Tables 2 and 3, respectively. The drugs in the dataset have been coded to 63,010 distinct WHODrug records. The top-five reported WHODrug records and the most common ATC level 2 codes associated with reported drugs are presented in Tables 4 and 5, respectively. Statistics about the number of times a WHODrug record has been reported and the number of unique inputs associated with them is presented in Table 6.

The presence of a route or indication field in the dataset does not imply that they are informative. Of all Koda inputs in the dataset, 46% have an informative indication4 and 51% have an informative route5. Only three Koda inputs in this dataset have country reported as unknown.

Top-5 report countries in the evaluation dataset

Top-5 report qualification in the evaluation dataset

Top-5 reported drugs in the evaluation dataset

Top-5 reported ATC codes in the evaluation dataset

Descriptive statistics of WHODrug records in the evaluation dataset

## Section: Results › Automation Level and Coding Quality

On the evaluation dataset, Koda shows an automation level of 89%. This is significantly higher than our direct-match baseline, which is automatically coding 61% of the drug entries in this dataset. For an additional 6% of inputs, Koda makes one or more suggestions, while leaving 5% of inputs uncoded (Fig. 2a). Figure 2b shows the coding quality of Koda’s high-certainty encodings. Koda codes at high certainty with an accuracy of 97%; this means that for 97% of the cases, Koda’s high-certainty predictions agree with the gold-standard encoding. Similarly, in Koda′s suggested predictions, 76% of the suggested encodings contain the gold-standard WHODrug record (Fig. 2c).

Manual inspection of a sample of inputs showed that Koda’s coding quality is affected by verbatims that contain non-trivial misspellings, and verbatims with much additional information such as unrelated text, or strength without units. Koda also struggles on verbatims describing combination products—products containing more than one ingredient—that are listed in various formats. Collective terms such as vitamins or antibiotics, which should often be coded to an umbrella term, also seem to be particularly challenging for Koda to code. In a few cases, Koda’s performance was negatively affected by the indication information, mainly when the reported indication was rare or formulated in an unusual way, and therefore very different from the training dataset.

We observed that 61% of the Koda inputs for which Koda provided suggestions had been coded manually in the gold standard. Similarly, 98% of the inputs Koda left uncoded had been coded manually in the gold standard. Many of the uncoded Koda inputs were identical or referred to a very specific brand of over-the-counter products, showing that only very few unique Koda inputs are left fully uncoded by Koda. Even when coding as suggested, Koda suggests only a single WHODrug record for most inputs (Fig. 3), and, for more than 99% of inputs, Koda suggests six or fewer WHODrug records (Table 7).

The evaluation result of Koda’s coding quality across all Koda inputs, including those that Koda chooses to leave as suggested encodings or uncoded requiring human input, is presented in Table 8. Compared with the direct-match baseline with an accuracy of 60.4%, Koda increases accuracy to 86.0%. We find that Koda reaches a macro average F1 score of 87.6% and weighted average F1 score of 88.2%, which is significantly higher than the direct-match baseline (64.4% and 66.1%, respectively).

a Koda’s automation level showing percentages of high certainty, suggested encodings and uncoded Koda inputs compared with the direct-match baseline. b Agreement between high-certainty Koda encodings and gold standard. c Agreement between Koda suggestions and gold standard

Number of options provided by Koda when coding as suggested

Centre and dispersion of the number of options for suggested encodings

Macro average precision, recall and F1 score across all WHODrug records in the gold standard, and the average of these metrics per WHODrug record weighted by the classes’ prevalence in the gold standard for WHODrug Koda and our direct-match baseline

## Section: Results › Mismatches to the Gold Standard

Manual evaluation of the 200 sampled Koda predictions coded at high certainty that did not match the gold standard showed that Koda’s predictions were as good as or more precise than the gold standard in over 90% of the samples (Fig. 4), with an inter-annotator score of 0.83 (Cohen’s kappa), which suggests strong agreement between the teams [29].

Similarly, in the 200 samples for which Koda suggested one or several WHODrug records that did not contain the gold-standard WHODrug record, the two teams found that approximately 50% of Koda’s suggestions were as good as or better than the gold standard (Fig. 4). The gold standard was considered more correct in 48% of the mismatches by Team 1 and 44% by Team 2. None of the encodings were judged acceptable in 1.5% and 7.5% of mismatches according to Team 1 and Team 2, respectively. The inter-annotator agreement score for this evaluation was 0.81, which can also be considered strong agreement [29].

Of the 200 mismatches that Koda left uncoded, the gold-standard encoding was found to either be incorrect or require manual review in more than 80% of the samples. The Cohen Kappa inter-annotator score for these samples was 0.89, indicating strong agreement between the two teams [29].

Manual assessment results for Koda’s three confidence levels

## Section: Results › Effect of Route, Indication and Country Fields

None of the Koda inputs in the VRIC dataset with confidence level suggested transitioned to high certainty when one or more of the optional fields were masked. We thus provide the results of the effect of the optional fields only for the 2124 entries coded by Koda at high certainty in the VRIC dataset. For each of the dataset variations (VRC, VIC, VC, VRI and V), we report the changes in encoding and Koda’s confidence in Table 9.

As can be seen in Table 9, Koda can still resolve ambiguous drug names even when additional fields are removed. Addition of the country field seems to have a larger effect, compared with route and indication, on increasing the automation level from suggested to high certainty: 129 entries were demoted to suggested when the country field was removed (Table 9, row VRI), while only 9 were demoted to suggested when the route and indication fields were removed (Table 9, row VC). The combined effect of removing all additional fields had the greatest impact, with 246 entries being demoted to suggested (Table 9, row V). No records were demoted to uncoded for any of the masked datasets.

Most entries stayed at high certainty when additional fields were removed. However, upon removal of these additional fields, a small proportion of these high-certainty coded Koda inputs were coded to a different WHODrug record. When route and indications were removed (Table 9, row VC), 105 entries at high certainty were coded to a different WHODrug record, while 81 entries at high certainty were coded to a different WHODrug record when all fields were masked (Table 9, row V). Removing only route (Table 9, row VIC) led to more changes in the chosen WHODrug record than removing only indication (Table 9, row VRC), while the removal of only the country field (Table 9, row VRI) did not change the WHODrug record chosen for this dataset.

Of the 105 Koda inputs whose WHODrug record changed when route and indication were masked (Table 9, row VC), 86 were changed to an entry with the same active moiety; 61 of 86 were coded to the preferred base substance. Similarly for the case when all fields were masked (Table 9, row V), 78 were changed to a WHODrug record with the same active moiety, of which 59 were coded to the preferred base substance. These results show that Koda can select a sensible, but less specific, WHODrug record even when route and indication fields are missing.

Result of masking exper﻿iment, masking various fields

## Section: Discussion

Our evaluation revealed Koda’s performance for drug coding on AE reports to be on par with its performance on drug coding of concomitant drugs in clinical trials, on both automation level and coding quality [19]. Furthermore, Koda could automatically code significantly more than a simple text-matching baseline and managed to automate the coding of inputs with ambiguous drug names to a large extent. Ambiguous drug names were resolved mostly by Koda’s internal coding rules, while the country field marginally increased Koda’s confidence level, and the route and indication fields maintained Koda’s confidence level but marginally influenced the choice of WHODrug record. Records of trade names are more likely to be coded to generic records of the base substance in the absence of route and indication fields, leading to correct but less precise encodings. Built-in coding rules are thus an important component of Koda’s intelligence compared with standard text processing-based systems.

Not only could Koda automate the coding of a large proportion of cases, but also for approximately half of the non-automated cases, Koda suggested one or multiple WHODrug records, significantly reducing the search space of possible records. These suggestions were found to be sensible for three of four inputs, and manual evaluation of mismatches with the gold standard revealed that Koda’s effective coding quality is likely even higher. From a coder’s perspective, Koda can reduce manual coding effort to a minimum in many cases, including non-trivial ones. Koda cannot however support all coding decisions, with 5% of all inputs from the evaluation dataset remaining uncoded.

Even though route and indication are optional, their presence improved the record selection. Since indication is provided in free text, it allows greater room for error due to variations in its content. Machine learning can help in cases where information is entered in free text, but it requires high-coverage training datasets. Even though a well-trained model should generalise to new, unseen input, it may fail if the data are too different from what was seen during training, which was also seen in this study. Therefore retraining and continuous evaluation of the model is crucial.

In this study, we evaluated Koda for its ability to code drugs on AE reports, while in a previous study, Koda had been evaluated for its ability to code concomitant drugs in clinical trials. In the context of EHRs, drug coding may be applied to free-text drug fields or as the mapping step following the NER of drugs. Evaluating Koda’s coding capabilities on drug mentions in EHRs would be an interesting future study. When coding drug verbatims that were extracted from narratives in EHRs, Koda’s performance might be negatively affected since they might differ in nature and since additional drug information might be challenging to extract from the narratives.

There are several limitations to consider when interpreting the results of our study. First, we have only evaluated Koda using its default configuration with all coding rules turned on. The default configuration partly reflects UMC’s internal coding conventions and is thus much in line with how the gold standard was developed. A different configuration may affect the results negatively.

Second, the baseline in this study was chosen for its simplicity and does not make use of synonym lists that organisations may develop as part of their automated coding processes. The addition of a synonym list to the baseline would likely increase its automation level. Constructing such a synonym list is a non-trivial, manual task that often requires domain-specific knowledge and maintenance. A comparison with more intelligent, automated drug coding systems for WHODrug would be of interest, however, to the best of our knowledge, no such systems are publicly available.

Third, in the manual evaluation of the mismatches to the gold standard, assessors were provided the same information as Koda, namely verbatim, route, indication and country, instead of the full AE report, which is used in practice during manual drug coding. As a result, there may be cases where the gold-standard encoding was in fact more correct based on the information derived from the entire AE report, but was judged to be as good or worse than Koda’s prediction. This approach was chosen to be fair to Koda, which can only use the verbatim, route, indication and country information to produce its predictions.

Furthermore, our results should be interpreted considering the difficulty of the drug coding task. Many Koda predictions mismatching with the gold standard were nevertheless deemed acceptable and since several assessments made by the two evaluation teams were different, we can deduce that there is a certain amount of imprecision to drug coding, which makes evaluation of drug coding systems harder. Additionally, differences between the WHODrug versions used by Koda or the gold standard may affect the accuracy of both Koda and the baseline method when compared with the gold standard.

Moreover, while Koda is an independent system developed and maintained by an independent team and sharing no modules or code with UMC’s automated drug coding processes for VigiBase reports, there is a possible influence on Koda’s development from the automated processes used during the creation of the gold standard in the form of transfer of knowledge and learnings.

Finally, during the creation of our gold-standard dataset, all reported drugs considered invalid during manual coding were excluded. Koda’s ability to recognise these inputs as invalid and leave them uncoded would be worth evaluating during future studies but was outside the scope of this evaluation of Koda.

## Section: Conclusion

Drug coding to a standardised dictionary, such as WHODrug, is an essential step in case processing activities for pharmacovigilance; however, it is a non-trivial task due to the varying data quality for the reported drugs, variation in submitted information, as well as presence of ambiguous drug names. Auto-encoders based on text-processing algorithms and synonym lists commonly used during drug coding can usually only automate the coding of drug names that have a single record in the drug dictionary. Resolving ambiguous drug names is however harder and perhaps represents the fundamental challenge for automation in drug coding. It requires additional decision making in the form of coding conventions to choose the correct record among a list of possible candidates. Automating or supporting this process could save a significant amount of time for drug coders.

WHODrug Koda is a product developed for the specific purpose of automatically coding free-text drug information of concomitant drugs in clinical trials to WHODrug. Evaluation of Koda’s coding performance on AE reports was the focus of this study. In our dataset of reports from VigiBase, Koda achieved an automation level gain of 46% compared with the simple baseline, requiring no human assistance. While Koda is designed as a human-in-the-loop coding system, its high automation level minimises manual interaction. Human assistance is only required in particularly difficult cases and is in many cases supported by sensible coding suggestions provided by Koda. Koda appears to handle ambiguous trade names very well and at high quality with the help of additional information, even when additional information is not provided, by following configurable coding rules.

Koda’s ability to automatically code reported drugs on AE reports at a high confidence level (including drugs with ambiguous names) and suggest WHODrug records in cases identified as more challenging appears to be a novelty. To the best of our knowledge, there are no such systems in use whose performance have been systematically studied.

Even though Koda was designed for concomitant drug coding in clinical trials, it achieves high automation level and coding quality for drug coding of AE reports in VigiBase. Koda can thus be a valuable tool for automating and supporting coding practices during case processing for pharmacovigilance while ensuring high data quality.

## Section: Acknowledgements

The authors sincerely thank the WHODrug Terminology specialists Anna Frisk, Jenny Adamsson, Jenny Klint, Michaela Lindh, and Susanna Johansson for the thorough assessment of our data during the manual evaluation study. They would also like to thank Klas Östlund for his support in running their dataset through Koda and in understanding Koda’s inner workings. The authors would further like to thank Jessica Nilsson for helping them understand UMC’s internal coding processes and her support during data extraction and Jim W. Barrett for proofreading the manuscript. The authors are indebted to the national centres that make up the WHO Programme for International Drug Monitoring (PIDM) and contribute reports to VigiBase. However, the opinions and conclusions of this study are not necessarily those of the various centres or of the WHO.

## Section: Declarations › Funding

There was no specific funding for this study.

## Section: Declarations › Conflicts of interest/competing interests

The UMC is a non-profit organisation and the WHO Collaborating Centre for International Drug Monitoring. UMC sells WHODrug Koda as part of its product offerings to pharmaceutical companies. Eva-Lisa Meldau, Shachi Bista, Emma Rofors and Lucie Gattepaille declare being employed by UMC at the time of writing but have no other conflicts of interest that are directly relevant to the contents of this article.

## Section: Declarations › Availability of data and material

The datasets generated and analysed during the current study are not publicly available due to agreements between contributors of data to the database used (VigiBase) and the custodian of this database. National centres (mainly national drug regulatory authorities) constituting the WHO PIDM contribute data to VigiBase and the UMC is the custodian in its capacity as WHO Collaborating Centre for International Drug Monitoring. Some subsets of the data may be available from the corresponding author on reasonable request.

## Section: Declarations › Code availability

WHODrug Koda is proprietary software provided by the UMC (an independent, non-profit foundation) and neither the software nor the code for this evaluation are available for public release.

## Section: Declarations › Authors' contributions

All authors designed and conceptualised the manuscript, interpreted the data, drafted the manuscript, and revised the manuscript. Additionally, EM and SB generated and analysed the data, LG supervised the study, and ER provided support to the manual evaluation teams. All authors read and approved the final version.

## Section: Declarations › Ethics approval

Not applicable.

## Section: Declarations › Consent to participate

Not applicable.

## Section: Declarations › Consent for publication

Not applicable.


---

# Big data and artificial intelligence (AI) methodologies for computer-aided drug design (CADD)

- **Authors:** Jai Woo Lee, Miguel A Maria-Solano, Thi Ngoc Lan Vu, Sanghee Yoon, Sun Choi
- **Issuer:** Biochemical Society transactions
- **Type:** Scientific article
- **Published:** 2022-02-28
- **Language:** en
- **DOI:** 10.1042/bst20211240
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35076690/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractThere have been numerous advances in the development of computational and statistical methods and applications of big data and artificial intelligence (AI) techniques for computer-aided drug design (CADD). Drug design is a costly and laborious process considering the biological complexity of diseases. To effectively and efficiently design and develop a new drug, CADD can be used to apply cutting-edge techniques to various limitations in the drug design field. Data pre-processing approaches, which clean the raw data for consistent and reproducible applications of big data and AI methods are introduced. We include the current status of the applicability of big data and AI methods to drug design areas such as the identification of binding sites in target proteins, structure-based virtual screening (SBVS), and absorption, distribution, metabolism, excretion and toxicity (ADMET) property prediction. Data pre-processing and applications of big data and AI methods enable the accurate and comprehensive analysis of massive biomedical data and the development of predictive models in the field of drug design. Understanding and analyzing biological, chemical, or pharmaceutical architectures of biomedical entities related to drug design will provide beneficial information in the biomedical big data era.Keywords: artificial intelligence, big data, computer-aided drug design, statistics, structure-based drug discovery

## Section: Introduction

Drug design and discovery is a complicated, costly and laborious process considering the complexity of diseases. It involves the identification of potential targets and the development of therapeutically safe and effective drugs [1–3]. The process can benefit from computer-aided drug design (CADD), where various computational and statistical methods can be applied to effectively analyze biomedical entities for target identification and hit hunting [4,5]. CADD can further utilize the combined biochemical space to gain safety, efficacy and avoid toxicity for the completion of drug development. With the adoption of in silico techniques in academia, industry and government [6,7], significant progress has been made in drug design and discovery. Recently, with the growth of big data in biological, chemical and pharmaceutical medicine, various machine learning algorithms have been optimized and applied in the field of CADD. This integration offers significant improvement in the efficiency of drug design and discovery process. Successful applications in drug design, discovery and development can be achieved only when effective computational methods and tools are provided with accurate and reliable pre-processed data [8,9]. Hereafter, big data and artificial intelligence (AI) approaches to data pre-processing [10], modeling [11,12] and representative applications in drug design and discovery will be introduced.

## Section: Big data and AI methods in the drug discovery process

The limitations in the traditional drug discovery field caused by size and complexity of biomedical data can be computationally formulated and solved with the advent of computing and analysis techniques using big data and AI algorithms [13,14]. Big data and AI approaches covering pre-processing data, applications of AI algorithms and statistical methods help to build automated models to analyze protein three-dimensional structures, drug-receptor interactions, ADMET property prediction, etc. [15] (Figure 1).

Data pre-processing steps include missing data imputation, outlier detection, and redundant feature elimination. After the input data are pre-processed, predictive modeling including unsupervised learning (clustering and dimensionality reduction) and supervised learning (regression and classification) can be utilized.

## Section: Big data and AI methods in the drug discovery process › Pre-processing and understanding data in CADD

The pre-processing steps are crucial for properly understanding and analyzing biochemical data and most importantly providing reliable data in the development of predictive models. For biomedical big data analysis, a data matrix with n samples and p biomedical features is considered. In the data matrix, p features can be any biomedical entities such as molecular descriptors, fingerprints, genes, sequence positions, protein structures, metabolites, etc. To statistically pre-process data, missing data imputation, outlier detection and redundant feature elimination are used (Figure 1). Implementing methods for data pre-processing requires effective algorithms for the accuracy of prediction and efficiency to run the program with optimized speed. The most relevant R packages for data pre-processing are listed in Table 1.

## Section: Big data and AI methods in the drug discovery process › Pre-processing and understanding data in CADD › Missing data imputation

AI models, which learn the patterns and structures of sparse drug discovery data, often include insufficient information about the data. The size of experimental values in sparse drug discovery data may not be sufficient, and if a model is trained on sparse data, the prediction of an outcome using this model may lead to inaccurate or inconsistent prediction results. Filling missing values with an imputation model handling molecular descriptors will improve AI models to analyze drug discovery data.

Since there are very few methods imputing missing values in drug discovery data analysis, a missing data imputation model such as Alchemite [16], a novel application of neural network, can be utilized to replace missing values. In missing data imputation, the Alchemite method clearly outperforms random forest models, which present uncertainties. Alchemite deep learning imputation improving the prediction model has been proved to outperform collective matrix factorization, deep neural network or random forest when using sparse experimental ADMET data. Alchemite can estimate uncertainties on outcome prediction detecting assay activities [16].

## Section: Big data and AI methods in the drug discovery process › Pre-processing and understanding data in CADD › Outlier detection

Data values in drug discovery datasets, such as the quantitative structure-activity relationship (QSAR) model, can be grouped by similarity using standard statistical methods. Identifying outlier compounds based on the standardization techniques can have a great impact on the QSAR model [17]. If data values that do not follow patterns in the data (i.e., outliers) are included or significant data values are excluded as outliers, the constructed model would lead to wrong predictions. For reliable prediction results, the molecular datasets, which are used to build the prediction model should cover the chemical space, and a new compound outside the applicability domain of molecule dataset should be detected [18,19]. Hence, outliers should be excluded before building the prediction model. There are very few QSAR models setting a reliable approach using dataset that includes potential outliers. Alchemite algorithm can also be used to detect potential outliers in the drug discovery data [16]. In this process, features following patterns in the data can be clustered and outliers excluded from the clustering procedure will be detected. Thus, Alchemite software program can conduct both missing data imputation and outlier detection to impute missing values and detect extreme values not following the patterns in data.

## Section: Big data and AI methods in the drug discovery process › Pre-processing and understanding data in CADD › Redundant feature elimination

When the prediction model selects multiple significant features in the dataset, selecting redundant features such as highly correlated variables in statistical analysis and biological meaning can lead to a misinterpretation of the model analysis. It is essential to exclude redundant features for the appropriate comprehension of predictive models [20]. For instance, redundant feature elimination based on the information of target proteins in drug–protein interactions can avoid the class imbalance problem and remove the repeated features [21] to determine the best filtered significant molecular features. RGIFE, a ranked guided iterative feature elimination method [22], which iteratively removes the redundant features in the drug discovery data can be utilized. By removing redundant features and selecting relatively small set of relevant features, RGIFE helps machine learning classifiers to obtain a similar or better performance. RGIFE utilizing RF (Random Forest) algorithm can recursively select significant features by removing redundant features in the data. It is shown that over different biomedical datasets, RGIFE produces similar or better results compared with other feature selection algorithms such as correlation-based feature selection (CFS), Support Vector Machine Recursive Feature Elimination (SVM-RFE), ReliefF, Chi-Square and L1-based feature selection. The features selected by RGIFE were proven to produce relevant findings from a biological point of view [22].

## Section: Big data and AI methods in the drug discovery process › AI-based modeling methods

In this section, AI methods for the construction of predictive models are introduced. In particular, we focus on regression methods, which build the models for the prediction of continuous outcomes; classification methods, which build the model for prediction of different classes; clustering methods, which group features based on similarity or distance between two features; and dimensionality reduction methods, which extract low-dimensional data consisting of significant features from high-dimensional data (Figure 1). Regression and classification belong to supervised learning, which estimates the outcome learning the structure of the input data. Clustering and dimensionality reduction belong to unsupervised learning, which investigates the interaction of features in the input data. Regarding regression and classification approaches, given input data and a target outcome, each model can be trained to learn the data to predict an outcome involving testing and possibly validation processes; training data is a portion of the input data used to build a model whereas testing data is a portion of the input data used to test and validate the performance of the model. It should be noted that most AI methods can be used for different categories of learning or analysis: As an example, neural networks can be used for clustering, regression and classification, and k-nearest neighbors can be utilized for missing data imputation to pre-process data and for classification of data values. It should be assumed that for each AI-based modeling method, drug discovery data with n rows of samples and p columns of features are used. In Tables 2 and 3, up-to-date software programs using AI-based modeling methods are listed including a brief description and their application in CADD.

## Section: Recent applications of big data & AI-driven technologies in CADD

There are several drug design areas where AI technologies have been successfully implemented in CADD. In this section, we focus on three relevant applications for the structure-based drug design processes: the identification of binding sites in target proteins, structure-based virtual screening (SBVS) and prediction of pharmacokinetic (ADME) and toxicity (T) properties. Furthermore, algorithms based on DT with molecular data can be utilized to analyze the effect of FDA-approved drugs, such as drug-induced liver injury and methods including NBC can be used to build frameworks to investigate exposures related to biologically, chemically or pharmaceutically diverse compound datasets [52]. AI-based software programs and tools used for these three applications are listed in Table 4. Each application includes different AI modeling methods.

On the left, the training data set sources and curation process are shown. The data type and the relevant information for the training process of each application are described in the horizontal arrows. On the right, the different neural network models built using the training data are represented. Application i uses protein ensembles as input and provides druggable conformations encompassing binding sites as output. Application ii is fed with the docked complexes between the druggable conformations and drug candidates as input, yielding hit compounds as output. Application iii takes the hit compounds as input to finally obtain the lead compounds.

## Section: Recent applications of big data & AI-driven technologies in CADD › Identification of binding sites in target proteins

Protein binding sites are structural elements whereupon drug-like molecules bind and trigger a therapeutic response. The large-scale identification of such binding sites still remains challenging [53,54]. This is in part attributed to the dynamic nature of proteins, which sample a wide range of conformations in solution and often only a fraction of them harbor binding sites. The increasing number of available conformations together with the complexity of protein conformational landscapes make protein data analysis more challenging [55,56]. To search for those pharmaceutically rich protein conformations, several tools have been developed using classical approaches including Fpocket [57], SiteHound [58] and MetaPocket [59]. These tools can predict binding sites considering geometric and potential energy factors of protein surfaces. Different AI methods such as over-sampling and binary classification (ENRI) [56], random forest (P2Rank) [53] and most recently deep learning approaches (DeepSite) [41,60] have emerged as potential strategies to enhance the binding pocket identification performance.

In this new scenario, Kozlovskii and Popov [54] developed BiteNet (Binding site neural Network), a rapid and accurate deep learning approach. After a curation procedure, 5,946 protein–ligand complexes containing 11,949 binding sites from Protein data bank [61] were used as training data set for the construction of a neural network model. Protein–ligand complexes structures offer a wide coverage of protein binding pockets, which usually are not detectable in ligand-free structures [62]. In the BiteNet fashion, protein ensembles are treated as 3D videos, protein structures as 3D images and binding sites as objects. This is performed by processing the data in a 3D-CNN as protein multi-channel grids of voxels in which the channels only consider atomic densities. It proves that in absence of geometry and energy descriptors (i.e., by essentially treating proteins as 3D images), binding sites can be successfully predicted. In fact, BiteNet significantly outperforms classical binding site prediction methods and state-of-the-art AI methods in terms of predictive power and computational efficiency. The thoughtful curation of the training set and preparation of the training process were found to be the key for the outperformance of BiteNet [54]. Thus, deep learning-based tools can be successfully applied to identify druggable conformations along molecular dynamics (MD) trajectories as input (Figure 2). The detected druggable conformations are advantageous to the following structure-based drug design procedures.

In practice, there are some aspects that need special attention for users when using a deep learning software for binding site prediction. First, it is inevitable that such training sets contain false negatives because protein–ligand complexes may also encompass empty binding sites, as a consequence, the prediction of some binding sites and especially novel allosteric sites could be omitted. Thus, the combination of classical and deep learning approaches could be beneficial by yielding complementary outcomes. Second, it is advisable to consider the applicability domain derived from the training data set. It has been shown that the performance of different methods depend on the protein family under study. Third, training sets overlook protein flexibility since they are usually constructed from X-ray rigid structures. This can be addressed with data augmentation techniques by computationally generating ensembles of protein–ligand conformations [63].

On the left, the training data set sources and curation process are shown. The data type and the relevant information for the training process of each application are described in the horizontal arrows. On the right, the different neural network models built using the training data are represented. Application i uses protein ensembles as input and provides druggable conformations encompassing binding sites as output. Application ii is fed with the docked complexes between the druggable conformations and drug candidates as input, yielding hit compounds as output. Application iii takes the hit compounds as input to finally obtain the lead compounds.

## Section: Recent applications of big data & AI-driven technologies in CADD › Structure-based virtual screening (SBVS)

Once druggable protein conformations are identified, one may proceed to obtain good binders from a chemical space of drug candidates that can cause the desired therapeutic effects. Those potent binders are referred to as hit compounds. Molecular interactions between drug candidates and protein binding sites can be virtually simulated using docking techniques. Specifically, in SBVS, a vast number of ligands from chemical libraries are ranked according to their binding affinity, which is predicted by a regression model, known as scoring function (SF) [64].

Recently, a new generation of SFs has been developed, which apply AI to utilize the ever-growing biological and structural data [65]. AI-based SFs continue to show their outperformance over classical SFs, with their ability to learn from low-level features in protein–ligand complexes [66]. In addition, unlike traditional SFs, the flexible nature of AI-based SFs allows customization of training datasets to focus on protein families of interest [67], including additional information to improve predictive performance [66] or diversify outcomes. For instance, instead of binding affinity, AI-based SFs developed in the DeepBSP tool [68] can directly predict the root mean square deviation (RMSD) between the docked and the native binding poses. In DeepBSP, a thoroughly curated dataset of 11,925 native protein–ligand complexes from PBDbind database [69] and more than 165,000 docked poses were represented using 3D voxel grids. These volumetric data, together with respective RMSD values calculated using DockRMSD program were used to train the model with a 3D-CNN structure (Figure 2). This model does not generate ligand–protein poses but re-rank ensembles of docked poses used as inputs by predicting their hypothetical RMSD values. The AI-based SF shows significantly improved docking power compared with that produced by the native SF of the baseline docking program (Autodock Vina) [68]. This model can support one in selecting good binders with correct binding structures from a pool of generated docking poses to eventually identify hit compounds.

However, there is current controversy over the applications of AI-based SFs in SBVS due to the lack of eligible validation experiments [66,70]. In retrospective validation on frequently used benchmark datasets, AI-based SFs stably showed good performance both when trained with protein–ligand complex information and when trained with ligand information alone [66,70]. These results indicate that the protein structural information does not significantly affect the prediction tasks. Bias-controlled validation considering the lack of interpretability of AI-based algorithms in general is required in order to ensure the reliability of the methods in the field [70].

## Section: Recent applications of big data & AI-driven technologies in CADD › Prediction of pharmacokinetic properties and toxicity

The prediction of absorption, distribution, metabolism, and excretion (ADME) properties and toxicity (T) helps the selection of good drug candidates [71,72] and fosters drug-likeness in the process of drug development. Recent studies have employed a wide range of AI-based methods to predict ADMET properties to reduce a preclinical failure in the drug discovery industry (Figure 2). The SwissADME web tool provides the prediction of physicochemical properties, descriptors, and drug-likeness with the ADMET properties, which are built by SVM or Bayesian methods [73]. AdmetSAR web server with 27 predictive models [74] and admetSAR2.0 with 47 predictive models were developed. The collected dataset was represented as molecular fingerprints and constructed using RF, SVM, and kNN models. In another study, variable nearest neighbor (vNN) method was developed as a complement to the kNN method [75]. Fifteen prediction models were constructed using vNN and implemented in the vNN-ADMET web server [76]. ATOM Modeling PipeLine, an open-source software pipeline was built to construct prediction models [77]. It covers data curation, model training and tuning, visualization and analysis. Regarding data curation, RDKit and MolVS packages were provided, and DeepChem, Mordred, and Molecular Operating Environment were included in the module. Diverse datasets can be used and supported by RF, XGBoost, NN, GCNN methods to construct new models.

As prediction model quality depends on input data, large high-quality data are required to obtain accurate prediction results. With numerous efforts to build comprehensive databases and benchmarks [78] together with algorithmic development, a better prediction of ADMET properties will be obtained in the field of drug discovery using AI-based modeling.

## Section: Competing Interests

The authors declare that there are no competing interests associated with the manuscript.

## Section: Funding

This work was supported by the Mid-career Researcher Program (NRF-2020R1A2C2101636), Medical Research Center (MRC) grant (2018R1A5A2025286), Brain Pool Program (NRF-2021H1D3A2A02038434), and Bio & Medical Technology Development Program (NRF-2019M3E5D4065251) funded by the Ministry of Science and ICT (MSIT) and the Ministry of Health and Welfare (MOHW) through the National Research Foundation of Korea (NRF). It was also supported by the Ewha Womans University Research Grant of 2021.

## Section: Author Contributions

Conceptualization, J.W.L. and S.C.; Writing — original draft preparation, J.W.L.; Writing — review and editing, J.W.L., M.A.M.S., T.N.L.V., S.Y. and S.C.; Visualization, J.W.L., M.A.M.S., T.N.L.V. and S.Y.; Supervision and Funding acquisition, S.C.


---

# Checklist for Artificial Intelligence in Medical Imaging Reporting Adherence in Peer-Reviewed and Preprint Manuscripts With the Highest Altmetric Attention Scores: A Meta-Research Study

- **Authors:** Umaseh Sivanesan, Kay Wu, Matthew D F McInnes, Kiret Dhindsa, Fateme Salehi, Christian B van der Pol
- **Issuer:** Canadian Association of Radiologists journal = Journal l'Association canadienne des radiologistes
- **Type:** Scientific article
- **Published:** 2022-10-27
- **Language:** en
- **DOI:** 10.1177/08465371221134056
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36301600/
- **Licence:** CC-BY

## Section: Abstract

Purpose: To establish reporting adherence to the Checklist for Artificial Intelligence in Medical Imaging (CLAIM) in diagnostic accuracy AI studies with the highest Altmetric Attention Scores (AAS), and to compare completeness of reporting between peer-reviewed manuscripts and preprints. Methods: MEDLINE, EMBASE, arXiv, bioRxiv, and medRxiv were retrospectively searched for 100 diagnostic accuracy medical imaging AI studies in peer-reviewed journals and preprint platforms with the highest AAS since the release of CLAIM to June 24, 2021. Studies were evaluated for adherence to the 42-item CLAIM checklist with comparison between peer-reviewed manuscripts and preprints. The impact of additional factors was explored including body region, models on COVID-19 diagnosis and journal impact factor. Results: Median CLAIM adherence was 48% (20/42). The median CLAIM score of manuscripts published in peer-reviewed journals was higher than preprints, 57% (24/42) vs 40% (16/42), P < .0001. Chest radiology was the body region with the least complete reporting (P = .0352), with manuscripts on COVID-19 less complete than others (43% vs 54%, P = .0002). For studies published in peer-reviewed journals with an impact factor, the CLAIM score correlated with impact factor, rho = 0.43, P = .0040. Completeness of reporting based on CLAIM score had a positive correlation with a study's AAS, rho = 0.68, P < .0001. Conclusions: Overall reporting adherence to CLAIM is low in imaging diagnostic accuracy AI studies with the highest AAS, with preprints reporting fewer study details than peer-reviewed manuscripts. Improved CLAIM adherence could promote adoption of AI into clinical practice and facilitate investigators building upon prior works.


---

# Clinical Efficacy Evaluation of Psychological Nursing Intervention Combined with Drugs Treatment of Children with ADHD under Artificial Intelligence

- **Authors:** Ying Guo, Jinping Wang, Shuyan Yan, Shujie Sui
- **Issuer:** Journal of healthcare engineering
- **Type:** Scientific article
- **Published:** 2022-03-29
- **Language:** en
- **DOI:** 10.1155/2022/1818693
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35392149/
- **Licence:** CC-BY

## Section: Abstract

AbstractADHD in children is one of the most common neurodevelopmental disorders. It is manifested as inattention, hyperactivity, impulsiveness, and other symptoms that are inconsistent with the developmental level in different occasions, accompanied by functional impairment in social, academic, and occupational aspects. At present, the treatment for children with ADHD is mainly based on psychological nursing intervention combined with drug therapy. Therefore, the actual efficacy evaluation of this treatment regimen is very important. Neural networks are widely used in smart medical care. This work combines artificial intelligence with the evaluation of clinical treatment effects of ADHD children and designs an intelligent model based on neural networks for evaluating the clinical efficacy of psychological nursing intervention combined with drug treatment of children with ADHD. The main research is that, for the evaluation of clinical treatment effect of ADHD in children, this paper proposes a 1D Parallel Multichannel Network (1DPMN), which is a convolutional neural network. The results show that network models can extract different data features through different channels and can achieve high accuracy evaluation of clinical efficacy of ADHD in children. On the basis of the model, performance is improved through the study of Adam optimizer to speed up the model convergence, adopts batch normalization algorithm to improve stability, and uses Dropout to improve the generalization ability of the network. Aiming at the problem of too many parameters, the 1DPMN is optimized through the principle of local sparseness, and the model parameters are greatly reduced.

## Section: 1. Introduction

Childhood ADHD, or mild brain dysfunction syndrome, is a relatively common childhood behavioral disorder syndrome. These children have normal or near-normal intelligence, hyperactivity, inattention, emotional instability, impulsive willfulness, and learning difficulties of varying degrees. ADHD can be divided into three types, namely, , inattentive, hyperactive, and impulsive [1–4].

The main harm of ADHD to children is mainly manifested in personal growth and family life. In terms of children's personal growth, because children cannot concentrate on their studies and cannot take the initiative to study, their academic performance declines. They are unable to self-control in behavior, showing disobedience and being discriminated against. As we get older, because we cannot control ourselves and are vulnerable to bad influences and temptations, we may fight, lie, and steal and even commit crimes. In terms of children's family life, due to children with ADHD, their ability to control themselves is poor, their academic performance is poor, and there will be phenomena such as weariness and truancy. Because of this, they are often criticized by teachers, making parents feel ashamed and irritable, so they often use beatings and sticks to educate their children, strictly disciplining children in their studies and adding more learning tasks to children; however, the effect is twice the result with half the effort, making children more rebellious and adopting a confrontational and hatred attitude towards parents' demands, which affects family harmony. Therefore, it is very important to achieve early recognition and early intervention to alleviate the symptoms of patients and reduce their social damage [5–8].

Childhood ADHD is considered to be a psychobehavioral disease caused by both genetic factors and environmental factors and is the result of multiple physiological, psychological, and environmental factors. (1) Physiological factors: children suffering from attention deficit hyperactivity disorder have certain familial inheritance, and various research results at home and abroad have shown this. In addition, the mother's heavy smoking and drinking during pregnancy or encountering other risks that lead to brain damage to the fetus are also a high-risk factor for children with attention deficit hyperactivity disorder. Studies have found that when children lack trace elements such as zinc and iron and the metabolism of some important amino acids in the body is out of balance, children will increase the probability of suffering from attention deficit hyperactivity disorder. (2) Psychological factors: children with ADHD are more sensitive and insecure and often use aggressive and talkative methods to cover up their inner fears and unease. If parents and teachers cannot understand their mistakes, they treat them with harsh beatings and insults. This can lead to heightened hyperactivity and even in adulthood can lead to antisocial emotions and behaviors that increase crime rates. (3) Environmental factors: in the family environment of children with ADHD, a case-control study has shown that the results show that parents' low educational level and poor family discord and intimacy are important reasons for the bad behavior of ADHD children [9–12].

Due to different research directions of ADHD children at home and abroad, the intervention methods used are also different. For children with ADHD who have obvious attention deficit and hyperactive behaviors, a common and more effective method is psychological nursing intervention combined with drug treatment [13–16]. Therefore, how to evaluate the clinical efficacy of this treatment is very important. With the development of computer technology, artificial intelligence is widely used in the field of intelligent medical care. This paper aims to design a neural network for efficient evaluation of clinical efficacy of this treatment based on artificial intelligence.

The key contribution of this study is as follows:

The rest of the paper is organized as follows. Section 2 presents the related work. The methodology applied is discussed in Section 3. In Section 4, experimental details are mentioned. Finally, Section 5 addresses the conclusion of this study.

## Section: 2. Related Work

ADHD is one of the most common psychobehavioral disorders in children. Literature [17] proposes that the prevalence of ADHD in children worldwide is estimated to have risen to 10%. Literature [18] conducted a systematic analysis of the prevalence of ADHD among children in the United States in 2003, 2007, and 2011 and found that the prevalence of boys was 11.0%, 13.2%, and 15.1%, respectively, and the prevalence of girls was 4.4%, 5.6%, and 6.7%. Literature [19] proposed that, due to the limited awareness of ADHD and the existence of many undiagnosed cases, the prevalence of ADHD was underestimated, and the actual prevalence may far exceed this number. Literature [20] proposed that the impact of ADHD on children is reflected in academic achievement, interpersonal communication, and other aspects. Literature [21] proposed that ADHD not only affects children, but also includes the effects of comorbidities and disorders. About 66% of ADHD children have at least one comorbidity, mainly including oppositional defiant, conduct disorder, depression and anxiety, tic disorder, learning or communication disorder, sleep problems and disorders, and substance abuse. These problems and barriers can also have serious consequences for children themselves and their families. Literature [22] believes that 80% of individuals diagnosed with ADHD in childhood will continue to be between adolescence and 30 years of age. These symptoms and damage persist into adolescence and even into adulthood, and the risk of developing antisocial personality or even delinquency is 5 to 10 times that of normal children. Literature [23] believes that ADHD is a disease caused by a combination of genetic and environmental factors. Genetic studies have confirmed that ADHD is a highly hereditary polygenic genetic disease. Related genes include dopamine metabolism genes, serotonin metabolism genes, catecholamine oxygen methyl-transferase genes, and norepinephrine transporter genes. Literature [24] believes that although environmental factors have not been proven to have a causal relationship with ADHD, it is certain that environmental factors play an important role in the induction and aggravation of ADHD and the prognosis of children with ADHD. Literature [25] pointed out that the risk of ADHD in the offspring of mothers who smoked during pregnancy increased by 2.64 times, and the risk of ADHD in the offspring of mothers who drank during pregnancy increased by 1.55 times.

In [26], a CNN model LeNet-5 with a 5-layer structure was proposed, which was initially mainly used for the recognition of handwritten digits. Based on the LeNet-5 model, a large number of convolutional neural network models with different structures have also been proposed. Reference [27] proposed an AlexNet model with an eight-layer structure based on LeNet-5, which for the first time enhanced the performance of the model by using a linear rectification function and local response normalization operations during training. Therefore, AlexNet won the ImageNet Challenge with a score of 10.9% more than the second place that year, setting off a wave of deep learning since then. Reference [28] proposed the VGGNet series of models. Compared with AlexNet, which uses a 7×7 convolution kernel, VGGNet reduces model parameters by using a 3×3 small convolution kernel during the design process and increases the nonlinear expression ability of the model by stacking small-sized convolution kernels. In response to the problem that the fitting ability of CNN increases with the increase of the number of layers, ResNet is proposed in [29]. The network solves the problem of gradient disappearance and gradient explosion in the learning process of deep neural networks by means of residual learning. Reference [30] proposed the DenseNet model, which is different from the residual learning method of the ResNet model. This model avoids the risk of gradient disappearance and gradient explosion during the training process by enhancing feature transfer between layers of the network. With the continuous optimization of CNN structure and major breakthroughs in the field of pattern recognition, CNN has been gradually introduced into the medical field by scholars in recent years.

## Section: 3. Method

The structure of 1DPMN.

Design parameters of 1DPMN.

Local sparse structures (a) and (b).

The structure of improved 1DPMN model.

## Section: 3. Method › 3.1. 1D Parallel Multichannel Network

This work proposes an evaluation network 1DPMN for evaluating the clinical efficacy of psychological nursing intervention combined with drug therapy on children with ADHD. The network structure is shown in Figure 1. The input data of the network model is the original efficacy index feature. The model contains three parallel channels, and the scales of the convolution kernels used in each channel are different. The local information features of different scales of the input data are extracted through different size convolution kernels of each different channel, and these information features are highly complementary and complement each other. The tandem network structure using convolution kernels of different scales does not capture complementary informative features well. Therefore, the use of parallel multichannel convolution kernels can deeply mine the local information correlation of the internal space of the original data and reduce the semantic gap between features.

The network model consists of three parallel channels, each of which is connected by three basic unit modules. Each basic unit module includes a convolution layer and a pooling layer, and the feature information is fused in the fusion layer according to the feature information extracted from each channel. The fused information features are input into the fully connected layer, and finally the classification results are output through the Softmax layer. The specific parameter settings of the 1DPMN model are shown in Table 1.

The model contains three parallel channels, Conv1, Conv2, and Conv3, and the size and shape of the original data are expanded to 1024×1. In the first channel, the number of convolution kernels of the first convolutional layer is 64, the length and width of the convolution kernel are set to 64×1, the depth is 1, and the moving step size is 16×1. The size of the output data after the first layer of convolution is 64×64. Input the data after convolution to the first layer of pooling layer, the number of filters in the pooling layer is 64, the size of the filter length and width is 3×1, the depth is 1, the moving step size is 2×1, and the output size is 32×64.

Similarly, the convolution and pooling process of the second channel and the third channel is the same as the first channel. It can be concluded that the output data sizes of the second and third channels are 32×64 and 32×64, respectively. The output results of these three channels are passed through the fusion layer, and the features of the three channels are spliced to obtain the final feature size of 32×192. The final feature is then transported to a flattening layer, which flattens the feature to a dimension length of 6144. The output length after two fully connected layers is 512, and the final output length is 10 through the Softmax layer. The above is the specific operation process of the initial data in the entire 1DPMN model.

The structure of 1DPMN.

Design parameters of 1DPMN.

## Section: 3. Method › 3.2. Underfitting and Overfitting

The phenomenon of underfitting is usually when the model has poor learning ability during training. Due to the insufficient learning ability of the model, it is difficult to extract the general features in the data. The performance is that the accuracy of the network model in the training set is low, the accuracy of the validation set and test set is close to the training set, and the output results have high bias characteristics, so the generalization of the model is weak. The reasons for underfitting may be caused by many factors, usually caused by the simple structure of the model, the small amount of data, the small number of model training times, the size of the batch-size, and the small amount of features of the data samples.

The phenomenon of overfitting is usually caused by the learning ability of the model being too strong. At this time, the general law of model learning is too strong. When training the model, the characteristics of a single training sample can be captured, and the model will recognize it as a general rule. This leads to the deterioration of the generalization ability of the model, which is mainly manifested in the high variance of the output results. The reasons for overfitting are also caused by various factors, generally due to the complex network model structure and too many parameters, too many model training rounds, too small training datasets, and other factors. The solution is usually to reduce the model complexity, increase the training set data, data augmentation, dropout techniques, and batch regularization, and reduce the number of model trainings, etc.

## Section: 3. Method › 3.3. Adam Optimizer

In the process of deep learning model training, the internal weights and biases of the model are constantly updated iteratively, which is critical to the final performance of the model. Therefore, when training a PMCNN model, it is essentially iteratively updating its weights and biases. The optimizer plays a pivotal role in this process, and the main role of the optimizer is in the process of deep learning gradient backpropagation. It guides each parameter in the loss function to update the appropriate size in the direction of optimization, so that the updated parameters can make the loss function value continuously tend to the global minimum value. Therefore, choosing a suitable optimizer can not only speed up the model convergence speed and reduce the number of training rounds and time, but also improve the final performance of the model.

This section compares the commonly used Stochastic Gradient Descent (SGD) algorithm with the Adaptive Moment (Adam) algorithm. The SGD algorithm has lower requirements on gradients and is faster when training models on large datasets. The formula for calculating SGD is

In the process of model training, the learning rate is also a key factor affecting the final performance of the model. The learning rate is generally set before training the model and cannot be dynamically adjusted during the model training process. The Adam algorithm adjusts the adaptive row learning rate of each parameter by calculating the first and second moment estimates of the gradient. It is suitable for situations where the amount of data and network model parameters are large, and the update of model parameters is not affected by the scaling changes of gradients, making model training more efficient. The formula for calculating Adam is

## Section: 3. Method › 3.4. BN Layer

Batch normalization (BN) is to solve the problem of internal covariate shift, which mainly occurs in the deep neural network training process. Because there are many layers in a deep network model, usually when the parameters of the previous layer are iteratively updated, the input data distribution of the latter layer changes. Therefore, the latter layer also needs to be continuously adjusted in the iterative process to eliminate this effect, making network training more difficult.

BN realizes the operation of preprocessing in the middle of the neural network layer; that is, the output of the previous layer is normalized and then used as an input into the next layer of the network. This can effectively prevent the gradient from disappearing and speed up network training. The BN algorithm generally performs batch normalization on the feature responses without ReLU activation. Therefore, the BN layer is placed after each convolutional layer of the network, and the processed output is used as the input of the excitation layer to achieve the effect of adjusting the partial derivative of the excitation function. The calculation of BN is as follows:

where m represents the size of the minibatch, xi is the value in the feature map, xi is a constant, and γ and β are two learnable variables. The BN layer normalizes the distribution of each layer's features by computing the mean μ and variance σ2 of the data in the minibatch. Moreover, the network is trained with a small batch of samples, so that the network will not generate a certain value from a given training sample, which is beneficial to improve the generalization ability of the network. Considering that the standardization operation will weaken the network's ability to express features, two learnable scaling parameters γ and offset parameters β are given to allow the network to adaptively adjust the feature distribution of the network layer.

## Section: 3. Method › 3.5. Dropout

In deep learning model training, if the number of samples in the training set is too small and the model has many parameters, the network is prone to overfitting. It is mainly manifested in that the accuracy of the training set is high, while the accuracy of the test set is low; that is, the generalization ability of the model is not enough. Aiming at the above problems, this work uses the Dropout strategy to solve it. Dropout is a computationally simple and effective method that can effectively regularize neural network models and is suitable for training and testing many neural networks. The Dropout method does not have too many restrictions on the type of model or training process and is applicable to almost any model.

The idea of the Dropout method is to drop or discard nonoutput units probabilistically in the original network. This method can act on the input layer and the hidden layer, and the general probability value ranges from 0 to 0.5. In the process of model training, the mechanism of Dropout enables the neurons in the subnetwork to better transmit information and obtain more gradient change values, so it can learn more features in the dataset. During the training process, the complete neural network generates a series of subnetworks through dropout, and these subnetwork models share parameters. During testing or generalization, the final model is complete. That is, without deleting or discarding nonoutput units, the subnetworks during training share the weights into the final model, and then the final model can be regarded as the integration of these subnetworks. Therefore, the dropout method is formally an ensemble of models with shared hidden units.

## Section: 3. Method › 3.6. Local Sparse Structure

In the 1DPMN model structure proposed in the previous section, the size of the convolution kernel in the same convolutional layer in each channel is the same, but the parameters of each convolution kernel are different. In the feature extraction of the original data, the use of convolution kernels of different sizes will be a new direction of neural network design. According to Hebbian theory, neurons with similar functions tend to cluster together. Using this theory, the convolution kernel in the convolution layer can be designed as a sparse structure, so that the convolution kernel with larger size can be decomposed into multiple convolution kernels with smaller size. That is, the convolution kernel with a smaller size replaces the convolution kernel with a larger convolution kernel, and each small convolution kernel is responsible for extracting a certain feature. Using this method can greatly reduce the redundant parameters of the convolutional layer and further reduce the overall parameter amount of the entire network model. Figure 2 shows a schematic diagram of two kinds of local sparsity.

When the convolution kernel size is 3×1, two different improvement mechanisms of the local sparse mechanism guarantee the feature map size-invariant structure and dimension-changing structure. The core idea of the local sparse mechanism is to use a small convolution kernel instead of a larger convolution kernel, which is controlled by changing the size of the feature maps before and after. The other is mainly to achieve the purpose by changing the dimension size before and after the output. Increasing the 1×1 convolution is mainly to change the dimension of the feature. The dimension here mainly refers to the number of channels of the feature, not the length or width of the feature. In addition, the nonlinear excitation of the network is increased, which improves the performance of the model.

Since the size of the convolution kernel may vary, in this chapter, we mainly optimize and improve the 3×1, 5×1, and 7×1 convolution kernel layers used in the three channels of the PMDCNN model. The improved 1DPMN structure is shown in Figure 3.

Local sparse structures (a) and (b).

The structure of improved 1DPMN model.

## Section: 4. Experiment Details

Efficacy evaluation index of ADHD treatment.

Evaluation for training progress in (a) and (b).

Comparison of Adam with SGD.

Evaluation for BN layer.

Evaluation for Dropout.

Evaluation on local sparseness.

Comparison of techniques.

## Section: 4. Experiment Details › 4.1. Dataset

This work uses one self-produced datasets to evaluate clinical efficacy in children with ADHD. The input features of each data sample are 10 ADHD evaluation indicators, and the specific indicator information is shown in Table 2. It should be noted that these 10 characteristic indicators were collected after psychological nursing intervention combined with drug treatment. The output for each data sample is 10 efficacy evaluation levels.

This dataset contains 2903 training samples and 1227 testing samples. The evaluation metrics are precision, recall, and F1 score in this work.

Efficacy evaluation index of ADHD treatment.

## Section: 4. Experiment Details › 4.2. Evaluation for Training Progress

In convolutional neural networks and any kind of neural network, the convergence of the network is an important indicator. A network can only be used for testing tasks if it can fit effectively on the training set. Therefore, this work first evaluates the convergence of the network, and the training error and training precision of the network are shown in Figure 4.

It can be seen from the figure that with the progress of network training, the training loss gradually decreases and the training precision gradually increases. When the number of iterations exceeds 60, the loss of the network does not decrease, and the precision does not increase, which indicates that the network has converged at this time. The experimental results can ensure the reliability and robustness of the network.

Evaluation for training progress in (a) and (b).

## Section: 4. Experiment Details › 4.3. Evaluation for Network Optimizer

As mentioned earlier, this work uses the Adam optimizer to optimize the training process of the network. To verify the effectiveness of this strategy, this work compares the network performance when using Adam optimizer and when using SGD optimizer. The experimental results are illustrated in Figure 5.

Obviously, the network gets the best performance when using the Adam optimizer. Compared to the performance when using the SGD optimizer, it can get 1.6% precision improvement, 1.4% recall improvement, and 1.2% F1 score improvement. This can prove the effectiveness and feasibility of this work using the Adam optimizer to optimize the network training process.

Comparison of Adam with SGD.

## Section: 4. Experiment Details › 4.4. Evaluation for BN Layer

As mentioned earlier, this work uses the BN layer to constrain the distribution of feature values, thereby improving network convergence speed and accuracy. To verify the effectiveness of this strategy, this work compares the network performance when using the BN layer and when not using it. The experimental results are illustrated in Figure 6.

Obviously, the network gets the best performance when using the BN layer. Compared to the performance when not using the BN layer, it can get 1.0% precision improvement, 0.8% recall improvement, and 1.1% F1 score improvement. This can prove the effectiveness and feasibility of this work using the BN layer to optimize the network training process.

Evaluation for BN layer.

## Section: 4. Experiment Details › 4.5. Evaluation for Dropout

As mentioned earlier, this work uses the Dropout strategy to deactivate certain neurons to alleviate overfitting, thereby improving network convergence speed and accuracy. To verify the effectiveness of this strategy, this work compares the network performance when using Dropout strategy and when not using Dropout strategy. The experimental results are illustrated in Figure 7.

Obviously, the network gets the best performance when using the Dropout strategy. Compared to the performance when not using the Dropout strategy, it can get 0.8% precision improvement, 0.7% recall improvement, and 1.2% F1 score improvement. This can prove the effectiveness and feasibility of this work using the Dropout strategy to optimize the network training process.

Evaluation for Dropout.

## Section: 4. Experiment Details › 4.6. Evaluation on Local Sparseness

As mentioned earlier, this work uses the local sparseness (LS) to reduce network complexity, thereby improving network convergence speed and reducing training time. To verify the effectiveness of this strategy, this work compares the network training time and network parameters when using local sparseness and when not using local sparseness. The experimental results are illustrated in Table 3.

Obviously, when the local sparse strategy is used, the parameters and training time of the network are greatly optimized. This verifies the effectiveness and correctness of this strategy.

Evaluation on local sparseness.

## Section: 4. Experiment Details › 4.7. Comparison of Techniques

Numerous techniques were proposed in the literature and we analyzed them and made comparisons with our techniques as shown in Table 4.

Comparison of techniques.

## Section: 5. Conclusion

This work mainly focuses on the clinical effect of psychological nursing intervention combined with drug therapy on children with ADHD as the research object. Aiming at the problems of traditional efficacy evaluation methods relying on expert diagnosis experience, low accuracy and low efficiency, a clinical efficacy evaluation a model for ADHD children based on deep learning theory was proposed. Through the strong automatic feature extraction ability and the strong feature learning ability of the network model, efficient efficacy evaluation can be achieved. The main research work and results of this paper are as follows. (1) Design an efficacy evaluation model based on the 1DPMN. The method uses CNN to automatically extract features from raw statistical data, instead of manual feature extraction and feature engineering, and can achieve efficacy evaluation with high accuracy. (2) The 1DPMN model is optimized. Choose the Adam optimizer to speed up model convergence and reduce training epochs and training time. The batch normalization algorithm is used to improve the stability of the network model and speed up the learning speed of the network. The use of Dropout technology improves the generalization ability of the network model and prevents overfitting. Aiming at the problem of too many parameters of the network model, the internal network structure is optimized by using the principle of local sparseness, which greatly reduces the amount of network parameters. Comprehensive and systematic experiments verify the validity and correctness of this work.

## Section: Acknowledgments

This work was supported by the Science and Technology Commission of Sichuan Municipality, Science and Technology Innovation Action Plan (No. 175111300).

## Section: Data Availability

The datasets used during the current study are available from the corresponding author on reasonable request.

## Section: Conflicts of Interest

The authors declare that they have no conflicts of interest.

## Section: Associated Data › Data Availability Statement

The datasets used during the current study are available from the corresponding author on reasonable request.


---

# Covid-19 and Artificial Intelligence: Genome sequencing, drug development and vaccine discovery

- **Authors:** Sali Abubaker Bagabir, Nahla Khamis Ibrahim, Hala Abubaker Bagabir, Raghdah Hashem Ateeq
- **Issuer:** Journal of infection and public health
- **Type:** Scientific article
- **Published:** 2022-01-19
- **Language:** en
- **DOI:** 10.1016/j.jiph.2022.01.011
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35078755/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractObjectivesTo clarify the work done by using AI for identifying the genomic sequences, development of drugs and vaccines for COVID-19 and to recognize the advantages and challenges of using such technology.MethodsA non-systematic review was done. All articles published on Pub-Med, Medline, Google, and Google Scholar on AI or digital health regarding genomic sequencing, drug development, and vaccines of COVID-19 were scrutinized and summarized.ResultsThe sequence of SARS- CoV-2 was identified with the help of AI. It can help also in the prompt identification of variants of concern (VOC) as delta strains and Omicron. Furthermore, there are many drugs applied with the help of AI. These drugs included Atazanavir, Remdesivir, Efavirenz, Ritonavir, and Dolutegravir, PARP1 inhibitors (Olaparib and CVL218 which is Mefuparib hydrochloride), Abacavir, Roflumilast, Almitrine, and Mesylate. Many vaccines were developed utilizing the new technology of bioinformatics, databases, immune-informatics, machine learning, and reverse vaccinology to the whole SARS-CoV-2 proteomes or the structural proteins. Examples of these vaccines are the messenger RNA and viral vector vaccines. AI provides cost-saving and agility. However, the challenges of its usage are the difficulty of collecting data, the internal and external validation, ethical consideration, therapeutic effect, and the time needed for clinical trials after drug approval. Moreover, there is a common problem in the deep learning (DL) model which is the shortage of interpretability.ConclusionThe growth of AI techniques in health care opened a broad gate for discovering the genomic sequences of the COVID-19 virus and the VOC. AI helps also in the development of vaccines and drugs (including drug repurposing) to obtain potential preventive and therapeutic agents for controlling the COVID-19 pandemic.Keywords: COVID-19, Artificial Intelligence, Genome sequencing, Drugs, Vaccines, Challenges

## Section: Introduction

Severe Acute Respiratory Syndrome Coronavirus 2 (SARS-CoV-2) causing COVID-19 is one of the most important devastating emerging infectious diseases. COVID-19 pandemic leaves enormous overwhelming loads on wellbeing, survives, economy, with limitation of the globe’s social activities, closing borders, banning travel, shutting schools and businesses, applying strict isolation and quarantines, and others [1], [2].

Artificial Intelligence (AI) helps on identifying the genomic sequencing of the SARS-CoV-2 virus. Furthermore, there are many strains of SARS-CoV-2. The latest Omicron (B.1.1.529) variants of concern (VOC) has been accompanied by panic responses around the world due to its contagious and vaccine escape mutations. The essential infectivity and antibody resistance of the SARS-CoV-2 variant is determined by its mutations on the spike (S) protein receptor-binding domain (RBD) [3]. AI can help in the rapid discovery of new variant strains. For example, a complete experimental evaluation of the Omicron variant might take weeks or even months, if AI was not applied. Omicron variant mutations are widely distributed on multiple proteins of SARS-CoV-2 such as non-structural protein (NSP) as (NSP3, NSP4, NSP5, NSP6, NSP12, NSP14, S, envelope, membrane, and nucleocapsid proteins [3].

For the quickly increasing pandemic as COVID-19, AI can also make vaccines and drugs more efficient [4]. The morbidity and death results from COVID-19 can be declined through a rapid intervention, which is possible through an accurate and prompt prediction of disease advance. Progressions in AI algorithms assist to analyze a countless volume of data and create significant predictions, decisions, and automation [5]. Nowadays, several target drugs have been identified and listed to be potential inhibitors of SARS-CoV-2 [6], [7]. For the development of drugs and vaccines for COVID-19, AI can improve the identification of genetic materials [6]. AI technology has become a digital arming in the development of new drugs, vaccines, diagnostic methods, and forecasting programs [7]. COVID-19 is the most important global health problem nowadays. However, scanty studies were conducted for reviewing the research done on use of AI for helping in the controlling COVID-19 pandemic. In consequence, a review on AI application for identifying the genomic sequence, development of drugs and vaccines for COVID-19 is essential.

The objective of the current study was to clarify the work done by using AI for identifying the genomic sequences, development of drugs and vaccines for COVID-19 and to recognize the advantages and challenges of using such technology.

## Section: Methods

A non-systematic review was done. All articles published on Pub-Med, Medline, Google, Google scholar on the use of AI and/or digital health for identifying the genomic sequencing, drug development, and vaccine discovery for SARS-CoV-2 were scrutinized and summarized. Results of the advantages, challenges and the limitations of using such methods were also summarized.

## Section: Results

A total of 38 papers fitting the objectives of the study were selected. The results are presented in the following sections.

Characteristics of the included articles on the use of Artificial Intelligence on COVID-19 diagnosis, drug and vaccine discovery.

## Section: Results › Journey of COVID-19 genomic sequencing through the help of AI

Regarding the genomic sequencing of the SARS-CoV-2 virus, Lopez-Rincon et al. [8] used the deep learning (DL) method for DNA sequences classification using Convolutional Neural Networks (CNN). The training of CNN has been used to separate different viral genome strains from the family of Coronaviruses. Then, AI techniques have been applied to find representative sequences. In this method the network was utilized to identify SARS-CoV-2 genomic sequence. The discovered sequences have been validated using different experiments and different repositories (Datasets) such as the National Center for Biotechnology Information (NCBI), the Global Initiative on Sharing All Influenza Data (GISAID), and the National Genomics Data Center (NGDE). This is done to prove the ability to separate the complementary DNA (cDNA), which is the DNA synthesized from a single-stranded RNA template in a reaction catalyzed by the enzyme reverse transcriptase. The use of the cDNA sequence of SARS-CoV-2 from different virus strains was done for being near to the perfection accuracy, and to create an innovative set of viral sequence features. Twelve sequences of 21-base-pairs (bps) of SARS-CoV-2 were specified using this procedure. One of these feature sequences is nominated to create a primer set. The primer sets are tested versus the state-of-the-art primer sets, synthesized, and hence used for laboratory testing. It is observed that this primer set has a high specificity for the detection of SARS-CoV-2. In addition, it was found that this procedure evaluates SARS-CoV-2 with an accuracy of more than 99%. However, in Quantitative reverse transcription PCR (RT-qPCR), the accuracy is around 70%. Meanwhile, the CT scan coupled with DL to reach an accuracy of 83% [8]. In 2021, a viral reverse engineering design was done to find out the similarity in viral protein & genomic sequences, and the additional mutations were extracted depending on the phylogenetic tree for capturing the evolutionary behavior [5].

Concerning the Omicron VOC, an AI model has been trained with tens of thousands of experimental data points data on SARS-CoV-2 [3]. An efficient and reliable in-silico analysis is imperative and valued for such an urgent situation. A comprehensive topology-based AI model called TopNetmAb was used to predict the binding free energy (BFE) changes of S and ACE2/antibody complexes induced by mutations on the spike RBD. The positive BFE change induced by a specific RBD mutation indicates its potential ability to strengthen the binding of an S protein-ACE2/antibody complex, while a negative BFE change suggests a likely capacity to reduce the binding strength of an S protein-ACE2/antibody complex. Since the S protein, particularly its RBD, plays a vital role in viral infection, it has been a key target of vaccines and antibody drugs. The study of Omicron’s 15 RBD mutations, and based on a well-tested and experimentally confirmed DL model trained with tens of thousands of experimental data, the impacts of Omicron’s RBD mutations on its infectivity were investigated. Results found that Omicron is about ten times more infectious than the original virus or about twice as infectious as the Delta variant. Using the structures of 132 known antibody-RBD complexes, it was found that Omicron’s vaccine-escape capability is nearly twice as high as that of the Delta variant. Omicron may significantly reduce the efficacy of the Eli Lilly antibody cocktail. Omicron RBD mutations may also compromise monoclonal antibodies (mAbs) [3].

## Section: Results › Journey of COVID-19 drugs discovering through the help of AI

Several studies report the usage of AI to generate modern drug compounds. Zhavoronkov et al. [9] used an AI-based drug discovery pipeline to generate a new drug compound that is cost-effective and with time productivity. Those compounds are inhibitors for the SARS-CoV2 3C-like protease (3CLpro). Tang et al. [10] developed an advanced deep Q-learning network with the fragment-based drug design (ADQN-FBDD) (a model-free reinforcement learning algorithm) to generate novel lead compounds. Based on their AI methodology, different derivatives were obtained from the generated lead compounds (47 lead compounds). Gao et al. [11] used an AI-based generative network complex to generate 15 potential drugs. When those drugs were compared with HIV inhibitors, it was found that it has enhanced drug properties [11]. Hofmarcher et al. [12] used a deep neural network protocol on three drug discovery databases to generate small compounds that are SARS-CoV-2 inhibitors. Firstly, they screened around one billion compounds from a database and then reduced them to 30 thousand compounds. Those compounds are accessible in the ZINC Database (collection of commercially available chemical compounds prepared especially for virtual screening). Furthermore, those 30,000 compounds are available in the library on: https://github.com/ML-jku/sars-cov-inhibitors-chemai.

Zhang et al. created a DL protocol and used four chemical compounds and tripeptides databases to identify potential drugs for COVID-19. A list of chemical ligands and peptide drugs was provided [13].

It is generally believed that the development of a new drug for the therapy of COVID-19 takes a long time. It is commonly considered that the therapeutic shortcut is to use the drug repurposing technique to find new uses of the already existing drugs [13]. Concerning drug repurposing, several studies used such a strategy based on DL algorithms. Beck et al. used the DL-based architecture to estimate drug-target interactions that could disturb the component of SARS-CoV-2 using the model called ‘Molecule Transformer-Drug Target Interaction (MT-DTI). Based on their procedure, a list of antiviral drugs was identified (Atazanavir, Remdesivir, Efavirenz, Ritonavir, and Dolutegravir). The best chemical compound is Atazanavir, which is used to prevent HIV/AIDS. Compared with other listed drugs, Atazanavir is shown to be effective for the COVID-19 treatment as it has a high ability to bind to six proteins of SARS-CoV-2; including the replication component of SARS-CoV-2, 3CLpro, and RNA-dependent RNA polymerase (RdRP, RDR). However, the in vitro and in vivo experimental study is required to validate the findings for safety and efficacy [14]. Meanwhile, in another study, Ge et al. used a drug repurposing strategy based on machine learning (ML) and statistical analysis to retrieve data related to coronavirus and the drug candidates followed by experimental validation. Based on the computational framework, a list of drug candidates was observed. It is discovered that poly-ADP-ribose polymerase 1 (PARP1) inhibitors showed antiviral activities against SARS-CoV-2. Two PARP1 inhibitors were selected, Olaparib, which is Food and Drug Administration (FDA) approved drug, and CVL218, which is Mefuparib hydrochloride and is still under clinical trial. Experimental studies, both in vitro and in vivo, have been conducted on these two drugs and several other tested drugs. Results revealed that CVL218 is a potential and effective drug that can be used for COVID-19 treatment. In vitro studies revealed that 3 µM and 30 µM doses of CVL218 showed successful inhibitory activity against SARS-CoV-2 replication by 35.16% and 99.68%, respectively. The results showed no evidence of a cytopathogenic effect. Furthermore, pharmacokinetic and toxicokinetic studies, in vivo, indicated that the high concentration of CVL218 showed no sign of toxicity [15].

Previous conducted studies illustrated that patients with SARS-CoV-2 have a significant increased level of interleukin-6 (IL-6), and hence an outrageous stimulated immune response [16], [17], [18]. According to Ge et al. [15] the in vitro studies done showed that CVL218 has the ability to suppress the production of IL-6 that induced by CpG DNA (regions of DNA) in peripheral blood mononuclear cells. Hence, it was suggested that it might have an anti-inflammatory effect to prevent immunopathology generated by the infection of SARS-CoV-2. In addition, a molecular docking simulation was conducted and showed that CVL218 binds more effectively than Olaparib. Hence, it decreases its RNA binding and inhibits viral replication.

In another study, Hu, and his colleagues used a computational-based methodology for in silico screening (that may decrease the time and expense of discovering treatment). They found that the drug abacavir is expected to have a high affinity to bind to numerous proteins of SARS-CoV-2. Abacavir is a nucleoside analog reverse-transcriptase inhibitor (NRTI) which applied for the treatment of HIV/AIDS. It is also discovered that roflumilast and almitrine mesylate are expected to show an inhibitory outcome. Furthermore, according to the procedure of Hu et al. a list of ten target drugs that showed a potential inhibitory effect against SARS-CoV-2 are generated [19]. In March 2020, an integrative, antiviral drug repurposing methodology implementing a systems pharmacology-based network medicine platform was applied for drug repurposing. Sixteen candidate drugs were identified and suggested to be potential drugs that can be used for the treatment of the COVID-19 virus [20].

In July 2020, another study using a network-deep learning methodology in which a medical knowledge graph named CoV-KGE was constructed. It consisted of 15 million edges crosswise different types of relationships between drugs, proteins, diseases, genes, protein expression, and pathways. In addition to the computing resources of Amazon Web Service (AWS), which is a cloud provider where 41 repurposing drugs have been discovered. These drugs were then authenticated via three transcriptomic and one proteomics data set in COVID-19 infected human cell-line as well as data from the current clinical trials [21].

A similar study was reported in August 2020. It constructed a comprehensive graph neural network. The authors utilized the developments of the network medicine for defining 81 drug repurposing candidates for the treatment of COVID-19 by using in vitro data. They reported that such drugs affected the biological processes targeted by the virus [22].

Traditional Chinese Medicine (TCM) can be considered as a promising treatment for COVID-19. However, it has been reported that there are many side effects. Hence, the ontology-based side-effect prediction framework (OSPF) was developed. This protocol will separate the ingredients of TCM into two main categories; either hot or cold. After that, a database was established to convert each TCM prescription into a vector that contains ingredients dosage according to the two categories and label as safe and unsafe. Artificial Neural Network (ANN)-based DL used this database to evaluate the TCM prescription in which the safety indicator (SI) is given (High to Low). SI is the percentage of the possibility of occurrence of side effects. Then, the list of proposed TCM prescriptions is re-arranged from high to low. It was stated that seven of them have an indicator of more than 0.8 in which will consider in the therapeutics of SARS-CoV-2 [23].

In Egypt, a new framework called DL for prediction drug-target affinities (DeepH-DTA) was proposed for predicting DT binding affinities for heterogeneous drugs. Heterogeneous graph attention (HGAT) model was developed to learn topological information of compound molecules and bidirectional ConvLSTM layers for modeling spatio-sequential information in simplified molecular-input line-entry system (SMILES) sequences of drug data. For protein sequences, a squeezed-excited dense convolutional network for learning hidden representations within amino acid sequences was proposed; while utilizing advanced embedding techniques for encoding both kinds of input sequences. A study using FDA-approved drugs from the Drug Bank database is performed using DeepH-DTA to predict the affinity scores of drugs against SARS-CoV-2 amino acid sequences. The results showed that the model can predict some of the SARS-Cov-2 inhibitors that have been recently approved in many clinical studies [24].

Currently, one way to predict the treatment of viral diseases is to identify the MicroRNAs (miRNAs). They are non-coding and small RNAs that have an essential role in gene expression regulation. Demirci and Adan [25] used a machine learning-based miRNA prediction methodology for the SARS-CoV-2 for predicting the pre-miRNA and mature miRNA. They searched for the interaction between human genes and viral miRNAs as well as between viral genes and human miRNAs for studying the mechanism of SARS-CoV-2 infection. They concluded that when the level of human miRNAs is increased in a way that targets the structural protein of SARS-CoV-2, the viral entry and replication would be blocked. Meanwhile, when the level of human miRNAs is decreased, the viral entry and replication would be increased, and hence it will be more visible for the human immune system. This could build a new window for the development of new therapeutics. However, it was stated that more in vivo and in vitro experiments are needed to validate the miRNAs candidate [25].

## Section: Results › Journey of COVID-19 vaccine discovery through the help of AI

The types of vaccine discovered for COVID-19 until now are either: the whole virus (inactivated or attenuated), viral vector (replicating and non-replicating), nucleic acid (RNA and DNA), and protein-based (protein subunit, virus-like particle) [26]. The main advantages of AI are rapid and accurate discovery with which it recognizes cases and efficacy in screening for vaccine production. AI modalities are utilized for effective vaccine development and for evaluating the safety of such vaccines. Some of the vaccines that had emergency use approval (EUA) during the pandemic were Messenger RNA (mRNA) BNT162b2 from Pfizer-BioNTech (Pfizer/BioNTech), mRNA-1273 (Moderna), Covishield (Oxford-AstraZeneca), and JNJ-78436735/Ad26. COV2. S (Johnson and Johnson), etc. [5].

On the 2nd of March 2020, epitope vaccines (T cell epitope-based peptide vaccines) against SARS-CoV-2 were designed by using protein E as antigenic site [27]. The vaccine was designed by firstly determining the antigenic target in order to determine the peptides in which it performs as ligands. Sophisticated bioinformatics tools and databases were used and determined 20 peptides in protein E as a candidate for SARS-CoV-2. Firstly, the whole genome of SARS-CoV-2 was analyzed by using the comparative genomic method. Then, a comparison between human coronavirus and COVID-19 sequences was carried out using Artemis Comparison Tool (ACT). A high mutation rate was found in the four structural proteins in coronavirus. Those four proteins are the S, Membrane (M), Nucleocapsid (N), and Envelope (E) proteins. These proteins were analyzed by VaxiJen Software (for Prediction of Protective Antigens and Subunit Vaccines) to find the highest possibility of antigenic protein. Protein E was chosen at that time as an immunogenic target. After that, binding affinities to the major histocompatibility complex (MHC) which are the MHC class I and II were evaluated to select the peptides that can be used for vaccine design. Three peptides (SLVKPSFYV and LAILTALRL and YVYSRVKNL) were selected with high potentiality for vaccine design. In this study, a recommendation was stated to validate the designed vaccine for safety and immunogenic report. On the 6th of March 2020, a study used the methodology of immune-informatics and reverse vaccinology to design an epitope-based subunit vaccine against COVID-19. Three vaccines were successfully constructed, meanwhile only one vaccine was designated as the greatest vaccine according to the molecular docking analysis [1].

In early March 2020, a computational methodology was also carried out to identify several epitopes in SARS-CoV-2. The viral genome of SARS-CoV-2 was analyzed for identifying several epitope candidates that can be used for the development of potential vaccines. It has been reported that 405T-cell epitopes with strong MHC-I and II scores and two B-Cell epitopes were identified near spike protein. Moreover, while analyzing the 68 viral genome mutation profiles, it is stated that there is no mutation found near the S protein. Consequently, it is identified as an immunogenic and effective vaccine candidate [28]. Hence, the spike protein has been discovered nowadays as the most intergenic gene used for vaccine discovery.

Ong et al. has predicted a vaccine against COVID-19 using the ML and reverse vaccinology to the whole SARS-CoV-2 proteomes as well as the structural and non-structural proteins. Accordingly, they have found six proteins that are predicted to be adhesions (one structural protein S-protein and five non-structural proteins (nsp3, 3CL-pro, nsp8, nsp9, and nsp10)). In addition, they reported that three of these proteins (S protein, nsp3, and nsp8 proteins) have high protective antigenicity scores. The nsp3 protein has not been tested before, and hence, in their study, they investigated more about this protein using ML methodology. It has been found that nsp3 is more conserved between Middle East Respiratory Syndrome (MERS-CoV), SARS-CoV, and SARS-CoV-2. Adding to that, it is predicted to have promiscuous MHC-I and MHC-II T-cell and B-cell epitopes. Therefore, it is indicated that many of the non-structural proteins can be applied as potential vaccine candidates. Furthermore, they proposed a cocktail vaccine with structural and non-structural proteins; such as the S protein/nsp3 cocktail vaccine in order to cover the different sides of protection, and it would accelerate efficient complementary immune responses [29].

A multi-epitope-based chimeric vaccine design against structural proteins of SARS-CoV-2 was constructed. Rahman et al. used an advanced bioinformatics technique (an immune-informatics methodology) alongside comparative genomics to develop an effective chimeric vaccine and named CoV-RMEN [30]. Susithra Priyadarshni et al. [31] used an in silico approach to design a multi-epitopic vaccine candidate targeting the non-mutational immunogenic regions in envelope protein and surface glycoprotein of SARS-CoV-2.

The emerging of lethal and new VOC of COVID-19, such as the delta variants and Omicron puts the health systems under a burden, and yields hesitancy concerning the upcoming efficacy of the existing vaccines. Adding to prevention, the therapy of COVID-19 is also affected by emergent strains. So, AI modalities have been established as a fundamental method for tracking, and forecasting the mutational sites and for rapid and adequate application of prevention and control measures of COVID-19 [5].

Concerning Omicron and based on 132 three-dimensional (3D) structures of antibody- RBD complexes, it was found that Omicron is maybe twice more likely to escape current vaccines than the Delta variant. The Food and Drug Administration (FDA)-approved mAbs from Eli Lilly may be seriously compromised by this variant. Omicron may also diminish the efficacy of mAbs from Celltrion and Rockefeller University. However, its impact on the Regeneron mAb cocktail appears to be mild [3]. The combined use of both molecular prediction tools and computer simulation in the development or regulatory evaluation of medical intervention is making the difference to better predict the efficacy and safety of new vaccines. An integrated bioinformatics pipeline that merges the prediction power of different software that act at different scales for evaluating the elicited response of the human immune system against every pathogen is proposed. The authors applied a problem-solving protocol to predict the cross-reactivity of pre-existing vaccination interventions against SARS-CoV-2. This study sheds the light on the fact that they can support the ‘3 Rs’ principles (replace, reduce, refine) in drug development and better predict the efficacy of new vaccines. Moreover, in the context of the VOC, the proposed in silico pipeline can be applied to predict the potential cross-reactive immunity induced by existing vaccinations against SARS-CoV-2 new emerging variants (e.g. B.1.1.7, B.1.351, and other lineages). Together with the possibility to use this problem-solving protocol to estimate the degree of the induced immune response by completely newly developed vaccines, it can speed up the development of vaccines tailored to the emerging antigenic variants [32]. Table 1.

Characteristics of the included articles on the use of Artificial Intelligence on COVID-19 diagnosis, drug and vaccine discovery.

## Section: Discussion

Many types of AI were used in the journey of genomic sequencing discovery, development of drugs and vaccines for COVID-19. The AI types used in the current work are ML, DL, and ANN [5].

The AI approaches open a new gate for all scientists in a different discipline to retrieve a huge amount of useful biomedical data in a short time to identify genomic sequence, design and discover a vaccine or a new therapy for emerging diseases. In addition, AI is a core of advanced technologies where the discovered therapy would be available for a clinical trial, and when it is approved it uses for health care [33]. AI provides cost-saving and agility methods in Covid-19 when it is approved it can be used for health care [34]. Genomic surveillance and AI are the main weapons for the early detection of new VOC of SARS-CoV-2. Detecting VOC and developing an evidence-based and timely public health response to mitigate the spread of the new variants, requires a robust genomic surveillance program. Monitoring is also required for assessing the effectiveness of vaccines against the circulating virus. Data need to be publicly available to drive real-time decision-making, enhance transparency, and fuel relevant research by national and international institutions [35]. However, other factors should be taken into account as challenges and limitations for the use of AI. Some of these challenges are represented by the forecast of the side effects, the rate of drug production, the therapeutic effect and the drug costs [19]. DL is used to classify virus species dividing the sequences into a fixed-length that varies from 300 bps to 3000 bps cannot be filled completely [8]. The data should also be reliable and of high quality to ensure accurate result prediction. During the occurrence of disease, the amount of data about it is not always enough to o retrieve information and predict algorithms (AI-based algorithms) needed to implement further analysis about the disease or to discover specific vaccines or drugs. Takes also further time, hence the time to discover the new vaccines and drugs is very crucial. The external validation should be performed in different geographical regions. Hence, the algorithms will be more accurate for those specific populations rather than in other geographical regions [36], [37], [38].

## Section: Conclusion

The growth of AI techniques in health care opened a broad gate for discovering the genomic sequences of the COVID-19 virus and the VOC. AI helps also in the development of vaccines and drugs (including drug repurposing) to obtain potential preventive and therapeutic agents for controlling the COVID-19 pandemic. The AI types used in the current study are ML, DL, and ANN [5] are the commonest used methods. AI provides cost-saving and agility methods for prevention and control of Covid-19. However, the challenges of its usage are the difficulty of collecting data, the internal and external validation, ethical consideration, therapeutic effect, and the time needed for clinical trials after drug approval.

## Section: Funding

No funding Sources.

## Section: Ethical approval

Not required.

## Section: Competing interests

None declared.

## Section: Acknowledgements

There is no fund.


---

# Deep Learning and Structure-Based Virtual Screening for Drug Discovery against NEK7: A Novel Target for the Treatment of Cancer

- **Authors:** Mubashir Aziz, Syeda Abida Ejaz, Seema Zargar, Naveed Akhtar, Abdullahi Tunde Aborode, Tanveer A Wani, Gaber El-Saber Batiha, Farhan Siddique, Mohammed Alqarni, Ashraf Akintayo Akintola
- **Issuer:** Molecules (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2022-06-25
- **Language:** en
- **DOI:** 10.3390/molecules27134098
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35807344/
- **Licence:** CC-BY

## Section: Abstract

NIMA-related kinase7 (NEK7) plays a multifunctional role in cell division and NLRP3 inflammasone activation. A typical expression or any mutation in the genetic makeup of NEK7 leads to the development of cancer malignancies and fatal inflammatory disease, i.e., breast cancer, non-small cell lung cancer, gout, rheumatoid arthritis, and liver cirrhosis. Therefore, NEK7 is a promising target for drug development against various cancer malignancies. The combination of drug repurposing and structure-based virtual screening of large libraries of compounds has dramatically improved the development of anticancer drugs. The current study focused on the virtual screening of 1200 benzene sulphonamide derivatives retrieved from the PubChem database by selecting and docking validation of the crystal structure of NEK7 protein (PDB ID: 2WQN). The compounds library was subjected to virtual screening using Auto Dock Vina. The binding energies of screened compounds were compared to standard Dabrafenib. In particular, compound 762 exhibited excellent binding energy of −42.67 kJ/mol, better than Dabrafenib (−33.89 kJ/mol). Selected drug candidates showed a reactive profile that was comparable to standard Dabrafenib. To characterize the stability of protein–ligand complexes, molecular dynamic simulations were performed, providing insight into the molecular interactions. The NEK7–Dabrafenib complex showed stability throughout the simulated trajectory. In addition, binding affinities, pIC50, and ADMET profiles of drug candidates were predicted using deep learning models. Deep learning models predicted the binding affinity of compound 762 best among all derivatives, which supports the findings of virtual screening. These findings suggest that top hits can serve as potential inhibitors of NEK7. Moreover, it is recommended to explore the inhibitory potential of identified hits compounds through in-vitro and in-vivo approaches.

## Section: 1. Introduction

Cancer is the most common cause of death, with a high mortality rate worldwide causing 10 million fatalities per year. Cancer is characterized by unregulated cell growth and rapid proliferation [1]. Uncontrolled cell proliferation, aggregation, and an aberrant cell cycle are hallmarks of human cancer. Typically, cell division is controlled by several regulatory factors, including protein kinases [2]. Among all known protein kinases, NIMA (never in mitosis, gene A) related kinase7 (NEK7) plays a multifunctional role [3], including centrosome duplication, intracellular protein transport, mitotic spindle assembly, DNA repair, and cytokinesis [4,5,6,7].

NEK7 is a highly conserved serine/threonine kinase consisting of approximately 302 amino acids [6]. NEK7 is structurally related to NEK6, which shares 85% amino acid sequence identity. However, NEK7 is involved in critical roles that NEK6 cannot take over. NEK7 is centrosome-localized and is known to be highly expressed in a variety of vital organs such as the heart, lung, fat, brain, liver, and spleen [8]. It enhances the centrosome duplication efficiency by promoting the pericentriolar material at the centrosome during the S and G1 phases [3].

In addition, NEK7 also encourages the proliferation of resting cells, which indicates its high-level involvement in various cancer types, including non-small lung cancer, breast cancer, NLRP3-related inflammatory disease, and gastric cancer progression [9]. NEK7 also has a promising role in growth and survival. NEK9 regulates the activation of NEK7 during mitosis, which promotes spindle assembly, centrosome separation, and mitotic division of the cell [7].

Besides promoting the proliferation of various resting cells, NEK7 is also involved in the progression and development of fatal inflammatory diseases, including Alzheimer’s disease, auto-immune disorders, inflammatory bowel disease, gout, and tumor formation [10]. Researchers have reported the involvement of NEK7 in the activation of NLRP3 inflammasome via ROS species formation, lysosomal destabilization, and potassium efflux. Stimulation of inflammatory mediators by NEK7 induces fibrosis and diabetic retinopathy and leads to hepatic carcinoma [10]. In brief, any mutation or atypical expression of NEK7 leads to the development of cellular oncogenesis and may provoke a fatal inflammatory response, causing tumorigenesis of multiple organs. These findings lend testimony to the involvement of NEK7 in the progression and development of numerous deadly diseases.

NEK7 is a promising target for multiple diseases, primarily cancer-related therapy research. NEK7 came into consideration two decades ago [2], but it has yet to be explored as a therapeutic target for preventing and treating NEK7-related diseases. A few medications have recently been developed to target the NEK7-mediated inflammasome pathway, but the mechanism and treatment outcomes are not specific and consistent [2].

Moreover, there is no FDA-approved medication that can selectively inhibit the expression of NEK7. Only Dabrafenib has shown activity against BRAF-mutant melanoma, which expresses more NEK9 [1]. These findings indicate that no published work has reported the selective and potent inhibitors of NEK7. As a result, the current study seeks more specific inhibitors that will provide a beneficial treatment option for NEK7-related cancer malignancies.

The current study focused on structure-based virtual screening (SBVS) of 1200 compounds library and drug repurposing of FDA-approved drug Dabrafenib. Dabrafenib demonstrated inhibitory potential against NEK9 with an IC50 value ranging from 1–9 nM [11,12]. Dabrafenib is comprised of benzene sulphonamide scaffolds. The basic sulphonamide group occurs in numerous biological active compounds [12], including anti-microbial [13], anti-tumor [14], anti-thyroid [15], antibiotics [16], and carbonic anhydrase inhibitors [17].

Clinically, sulphonamide-possessing drugs are used to treat lower urinary tract infections, whereas aromatic or hetero-aromatic sulphonamide derivatives possess a wide range of biological activities, including anti-tumor, anti-rheumatic, anti-microbial, and anti-inflammatory [18,19,20,21]. These findings have provided a strong rationale to retrieve structural analogues of Dabrafenib containing a basic sulphonamide nucleus.

The library of 1200 structural analogues of Dabrafenib was retrieved from the PubChem database and subjected to the in-silico drug discovery process. The discovery of a new anti-cancer agent is an extensive and laborious process. Thus, computer-aided drug design (CADD) [22] methods could serve as an alternative drug development strategy [23]. Among in-silico approaches, drug repurposing is an advanced tool for revisiting the activities of already approved drugs [24], which can save time and money [25].

The current study was focused to revisit the activity of Dabrafenib against NEK7 protein [26]. In addition, structure-based virtual screening (SBVS) [26] of 1200 structural analogues of Dabrafenib was carried out using molecular docking [27] and deep learning models [28]. SBVS is an advanced technology for the identification of potential hits with significant pharmacological properties against multiple molecular targets. Several robust docking programs are available for docking purposes in commercial and academic settings. In the present study, the Auto Dock Vina was used for virtual screening [29,30]. Moreover, density functional theory studies were conducted to explore the chemical reactivity profile of top-ranked analogues obtained through virtual screening. The structural geometry optimization and frequency calculations were performed. In addition, frontier molecular orbital (FMO) analysis and global reactivity descriptors were also determined. The efficacy of any drug is determined by its interaction with targeted biomolecules. Deep learning algorithms [31] were used for prediction of binding affinity and pIC50 values of top hits obtained via virtual screening. Predicted values of top hits were compared to in-vitro activity of Dabrafenib.

Furthermore, in-silico ADMET properties were also determined using a message-passing neural network (MPNN). The MPNN model is widely used for prediction of molecular properties such as blood brain barriers, human intestinal absorption, and solubility profiles [32]. The molecular docking approach only provides a static view of the molecular interactions of the complex. Still, to determine the stability of the protein–ligand complex, molecular dynamic simulations (MD simulations) have been performed to determine the stability, which provide significant insight into the molecular interactions of top-ranked complexes under accelerated conditions. Top hits obtained through structure based virtual screening a shown in Figure 1. All hits shared the same pharmacophore with standard Dabrafenib.

This is the first comprehensive computational study for the identification of selective inhibitors of the NEK7 protein. The current study has utilized the latest computational approaches, suggesting identified hits as a new strategy for treatment of NEK7-associated malignancies. Findings of the current study suggest the exploration of the inhibiting potential of these hits at the molecular level using in-vitro and in-vivo experimental techniques.

## Section: 2. Experimental › 2.1. Computational Studies › 2.1.1. Density Functional Theory Calculation

The ground state electronic energy is ascertained by electron density of the compound [33]. The electron density defines the number of electrons, nuclear charge and position of the nuclei in a compound [34]. Variation in electron density yields different ground state energy, and both of these properties are related by density functional theory methods [35]. DFT methods are based on suggestions that electron density can be accurately assumed by the set of specific orbitals using an exchange correlation such as B3LYP [36]. Based on their computational accuracy, DFT methods are a reliable and efficient approach for correct estimation of electronic properties of the compound [37]. The structural geometries of selected compounds were optimized through DFT studies. DFT calculations were executed on Guassian09 program [38] using B3LYPfunctional correlation and 6-31G* as a basis set [39]. It is a compelling theory to calculate the electronic structure of atoms and molecules. Gauss View 6 was used for visualization of output files [40]. In addition, DFT/B3LYP method was employed for generation of Frontier molecular orbitals (FMOs), electrostatic surface potential map and global and local reactivity of descriptors. After completion of calculations, the output log file was visualized in Gauss View 6 for determination of optimization energy, dipole moment, frequency and polarizability [41].

## Section: 2. Experimental › 2.1. Computational Studies › 2.1.2. Structure Based Virtual Screening (SBVS)

Drug candidates were retrieved from the PubChem database (https://pubchem.ncbi.nlm.nih.gov/) (accessed on 28 April 2022) to create the ligand library. There were 1200 structural analogues of Dabrafenib in the library. PyRx software was used to prepare the compounds library, which was converted to pdbqt format for virtual screening using Auto Dock Vina. The MMFF94 force field was used to minimize the energy of ligands. The crystallographic structure of the targeted protein was retrieved from Protein Data Bank (https://www.rcsb.org/) (accessed on 1 May 2022) (PDB ID: 2WQN). After that, MGL tools were used to prepare macromolecule, which included removing Het atoms and water molecules, and the addition of polar hydrogen. The protein was examined for any missing residues. Furthermore, Kollman’s charges were used to neutralize protein, and Gasteiger charges were calculated. Finally, for virtual screening of the compound library using Auto Dock Vina, a 1-angstrom grid box was built centered on the crystalline structure of protein at the point of co-crystal ligand (ADP) binding-site coordinates. The central xyz axis of the grid box was set to 80 × 80 × 80. Virtual screening was carried out after the targeted protein was prepared utilizing Auto Dock Vina’s script-based technique. The exhaustiveness was set to 5 and the number of nodes was set to 20. The virtual screening was repeated twice to ensure the accuracy of docking results. In addition, docking protocol was validated by re-docking the co-crystal ligand with targeted protein. A RMSD value of less than 2 angstrom indicates the reliability of the docking pose. After completion of virtual screening, the output findings of the virtual screening module were analyzed and docking scores of drug candidates were compared to standard Dabrafenib. Only four compounds were found to have higher docking scores than standard Dabrafenib. The top hits were subjected to further analysis using deep learning algorithms. Deep learning models were used to predict drug affinity and determine the stability of protein–ligand complexes.

## Section: 2. Experimental › 2.1. Computational Studies › 2.1.3. Molecular Dynamics Simulation

The molecular docking experiment provided an initial static protein–ligand complex for molecular dynamic studies. Desmond, a package from Schrödinger LLC [42], was used to run molecular dynamic simulation for 100 ns. Molecular docking studies provide insight into the binding state of ligand with protein. Docking produces the static orientation of a ligand molecule inside active pockets of targeted protein [43], and MD simulations measure the average displacement of atoms with respect to a reference. MD simulations provide information about the stability of the best complex [44,45].

Maestro or Protein Preparation Wizard were employed for processing of the protein–ligand complex. The system was prepared in the system builder tool of the Desmond package. The system was solvated by Monte-Carlo equilibration, TIP3P solvent model extended 10.0 angstrom in each direction. The counter NaCl ions at a concentration of 0.15 M were added to neutralize the system. The optimized potential for liquid simulation (OPLS 2005) [46] was used as a forcefield to generate parameter files [46]. The pressure control was conducted through the Martyna−Tuckerman−Klein chain coupling scheme with a coupling constant of 2 ps [47], whereas the Noose–Hoover chain coupling scheme was used for temperature control [48]. The energy minimization was performed for 20,000 steps in order to remove any intra-molecular steric clashes. Initially, the system was equilibrated (NVT ensemble) for 1 ns, and afterwards the NPT ensemble was performed for an additional 1 ns at 300 K temperature and 1 bar pressure. Finally, production run was performed for 100 ns under periodic boundaries conditions. The Particle Mesh Ewald (PME) method [49] was used to determine electrostatic interactions [50]. The Verlet/Leapfrog algorithm was used for numerical integration. A time step of 1 fs was used for minimization and a time step of 2 fs was used for molecular dynamic simulation [51]. Thermal MM-GBSA.py script [52,53] was used to calculate the ligand strain and ligand-binding free energy for docked conformations over a 100 ns period [54].

## Section: 2. Experimental › 2.1. Computational Studies › 2.1.4. Prediction of Binding Affinities, pIC50 and ADMET Properties Using Deep Learning Models

Dabrafenib, which has been approved by the FDA, has been found to be effective against BRAF-mutant melanoma with a high level of NEK9 protein expression. Dabrafenib’s inhibitory concentration was in the nanomolar range, 1–9 nM [1]. The drug’s effectiveness is largely determined by its binding affinity (IC50) and ADMET profile. Therefore, we have employed deep learning models to predict IC50, pIC50, and ADMET properties of top hits acquired through virtual screening in order to provide a direct comparison of binding affinities of top hits with standard Dabrafenib. Predicting the binding affinity and ADMET characteristics in silico, rather than using an experimental method, is a promising alternative. Deep learning (DP) models were used to predict drug target interactions (DTI) in the current work, which were formulated on encoder and decoder architectures. A DL model takes the SMILES string and amino acid sequence of the targeted protein as input and uses over 17 state-of-the-art DP learning techniques to predict drug efficacy indicators (Figure 2). The MPNN-CNN deep learning algorithms were used for affinity prediction in this work, while the MPNN model was used for ADMET predictions [32].

## Section: 3. Results and Discussion

The 1200-compound library was retrieved from the PubChem database and subjected to SBVS and the FDA drug Dabrafenib. Dabrafenib was maintained as the standard drug to which docking scores of 1200 compounds were compared. It was observed that only four combinations have better docking scores and binding affinity than standard Dabrafenib. These four compounds were considered top hits and subjected to further analysis, including geometry optimization and FMO analysis via density functional theory studies. Moreover, IC50, pIC50, and ADMET properties of the top four compounds were also predicted using deep learning models.

## Section: 3. Results and Discussion › 3.1. Density Functional Theory Studies (DFTs)

Quickly calculating physicochemical properties of atoms, bonds and molecules is necessary to process thousands or millions of structures in data mining investigations. Calculations in quantum chemistry based on ab initio and density functional theory (DFT) yield increasingly reliable assessments of many characteristics [55]. The B3LYP hybrid functional is likely the most popular DFT functional, and its cost-effectiveness has been widely acknowledged. Nonetheless, DFT computations are still too computationally expensive to be conducted on single workstations or tiny clusters in less than a few hours [56].

## Section: 3. Results and Discussion › 3.1. Density Functional Theory Studies (DFTs) › 3.1.1. Optimized Geometries

In the present study, geometries of FDA-approved drug Dabrafenib and top hits were completely optimized using the DFT/B3LYP method and 6-31G* as a basis set. No negative frequencies were obtained after the geometry optimization, which demonstrates that current geometries are true local minima. Optimized structures of drug candidates are presented in Figure 3.

The compound 762 showed high value for polarizability and dipole moment, which indicates its high polarity and chemical reactivity. Optimization and polarizability values of top hits and Dabrafenib are given in Table 1.

## Section: 3. Results and Discussion › 3.1. Density Functional Theory Studies (DFTs) › 3.1.2. Frontier Molecular Orbital (FMOs)

The way a molecule interacts with other species is determined by its frontier molecular orbitals. The highest occupied molecular orbital, or HOMO, is the outermost orbital-bearing electrons, and it primarily works as an electron donor. The lowest unoccupied molecular orbital, or LUMO, is the innermost orbital with free electron acceptor sites. The ionization potential ought to be proportional to the HOMO energy, while the LUMO energy should be proportional to the electron affinity (Table 2).

The energy gap is the difference in energy between the HOMO and LUMO orbitals, and it is the most key variable in predicting the stability of a molecule. The HOMO–LUMO energy gap is used to evaluate the chemical reactivity and kinetic stability of the molecule. A soft molecule is a structure with a narrow gap that has a higher degree of polarization. As a measure of electron conductivity, the energy difference between HOMO and LUMO was recently employed to illustrate the bioactivity of intramolecular charge transfer (ICT). The stronger the chemical reactivity and the less stable the kinetics, the smaller the gap. The compound 762 has the narrowest energy gap at 0.127 eV among all the compounds. Compound 248 has a greater energy gap, measuring 0.152 eV. Thus, it shows compound 762 is chemically more reactive than all other compounds, which are comparatively the stable ones. In addition, the electron density of HOMO orbitals for Dabrafenib was localized over morpholine and piperdinyl rings, whereas electron density of LUMO is localized to the carbonitrile and benzocarbazole moiety of the drug. FMOs orbitals are shown in Figure 4.

## Section: 3. Results and Discussion › 3.1. Density Functional Theory Studies (DFTs) › 3.1.3. Global and Local Reactivity Descriptors

The HOMO and LUMO frontier orbitals are used to predict chemical reactivity. The HOMO orbital energy of a compound is significantly correlated with its vulnerability to electrophilic attack and ionization potential. A compound’s LUMO orbital energy is a reliable predictor of electron affinity and nucleophilic attack. The energy of LUMO is proportional to its electron affinity, indicating that it is susceptible to nucleophile attack. The frontier molecular orbital energies are also related to the hard and soft characteristics of a molecule. Hard nucleophiles have a low HOMO, whereas soft nucleophiles have a high HOMO. Similarly, hard electrophiles have a high LUMO energy, whereas soft electrophiles have a low LUMO energy. According to the frontier theory of electron reactivity, the chemical reaction occurs at the point where the HOMO and LUMO have the most overlap. All reactions require the HOMO density of the donor molecule, while all reactions require the LUMO density of the acceptor molecule. The frontier orbital densities of individual atoms can be used to quantify their reactivity inside a molecule. Chemical behavior is frequently predicted using electronegativity and hardness. Compound 248 presented greater energy gaps, indicating it to be the tougher among all compounds. Compound 208 demonstrated the greatest electrophilicity index value of 0.207 eV. This indicates that compound 208 is an excellent electrophile among all the other compounds. The HOMO–LUMO energy gap for Dabrafenib was found to be 0.159 eV. Dabrafenib showed a softness value of 6 (Table 3). The Koopman’s theorem was used to express ionization energy and electron affinity of drug candidates. I = −EHOMO: A = −ELUMO

We evaluated the following parameters by using their respective formulas: Hardness: η = 1/2(ELUMO − EHOMO); Softness: S = 1/2η; Electronegativity: χ = −1/2(ELUMO + EHOMO); Chemical potential: µ = −χ; Electrophilicity index: ω = µ/2η.

## Section: 3. Results and Discussion › 3.2. Structure Based Virtual Screening and Predicted Binding Affinities

Initially, the Molecular docking methodology was validated by redocking a co-crystal ligand with targeted protein using the same coordinates. RMSD values of less than 2 angstrom were obtained, which demonstrate the successful validation of the docking protocol and can be used to describe ligand poses with specificity and accuracy. Afterward, virtual screening was conducted with 1200 ligands library and Dabrafenib. The coordinates of co-crystal ligand were used to dock the ligand library and Dabrafenib. Out of 1200 drug candidates, only four drug candidates showed excellent binding energies that were even better than Dabrafenib. The binding energies of top hits and Dabrafenib are tabulated in Table 4. In particular, compound 762 showed a maximum binding energy of −42.67 kJ/mol and exhibited strong binding affinity with NEK7 protein when subjected to the DL prediction model.

Among the four top hits, compound 208 exhibited promising hydrophobic and hydrophilic interactions. The amino acid residues involved in important molecular interactions were as follows: ASP115, ARG121, GLY117, ASP179, PHE168, ILE195, ALA114, ALA61, ILE40, and ASP118. It was observed that two hydrogen bonds were involved in stabilizing the protein–ligand complex. One hydrogen bond was observed with ASP118 with a bond length of 2.97 angstrom, while the second hydrogen bond was observed with GLY117 having a bond length of 3.14 angstrom. Important residues of the active site were engaged in hydrophobic interactions, including van der Waals interactions, pi-alkyl and alkyl–alkyl interactions. The docking score of compound 208 was found to be −33.47 kJ/mol. Similarly, compound 248 exhibited stronger molecular interactions with the following amino acid residues: ARG121, ASP118, ALA165, LYS63, ASN166, ASP179, PHE168, LEU111, VAL48, ALA116, ASP115, and GLY117. It was discovered that important amino acid residues of the NEK7 protein’s DLG/DFG motifs were involved in interactions. Furthermore, the amino acids LEU111 and LYS163 interacted via hydrophobic bonds. Two important hydrogen bonds were contributing toward the stability of conformations. One hydrogen bond engaged GLY117 residues with a bond length of 2.2 angstroms. Another hydrogen bond was engaging ASN166 amino acid with a bond length of 3.34 angstroms. Among hydrophobic interactions, van der Waals interactions played a pivotal role in stabilizing the complex. The docking score of the compound 248 was −35.56 kJ/mol. The putative 2D and 3D binding modes of compounds 208 and 248 are shown in Figure 5.

Another important top hit was compound 255, which exhibited potent molecular interactions with amino acid residues of the active site. It was the second-best drug candidate obtained via virtual screening. Amino acid residues involved in bonding and nonbonding interactions were as follows: PHE45, SER46, LYS63, ALA114, ASP115, GLU112, PHE168, ASP179, VAL48, GLY43, and GLN44. It was observed that two important hydrogen bonds with short bond lengths were contributing toward stabilizing the complex. One hydrogen bond occurs between the electronegative oxygen atom of the compound 255 and the SER46 residue of the targeted protein. Moreover, the second hydrogen bond was engaged in GLY117 with a bond length of 3.16 angstroms. As shown in Figure 5, amino acid residues from the active site were involved in hydrophobic interactions with compound 255.

Now referring to the top hit obtained through SBVS, namely compound 762, It has shown excellent docking scores and demonstrated significant binding affinity obtained through deep learning models. It was observed that compound 762 was engaged in three hydrogen bonds of moderate-to-strong strength. One hydrogen bond occurred between the pentazole ring of the compound 762 and the electronegative oxygen atom of TYR201. The bond length of interaction was 3.08 angstroms. Similarly, the second hydrogen bond engaged SER234 residues with a surprisingly smaller bond length of 2.92 angstroms. These interactions lend enough testimony to stronger molecular interactions and more stabilized protein–ligand complexes. Furthermore, the third and last hydrogen bond occurred between TYR237 and compound 762 with a bond length of 3.02 angstroms. All three amino acid residues involved in hydrogen bonding belong to the activation loop of the NEK7 protein. The remaining active site residues, ILE123, GLU228, PHE236, MET203, PRO200, LEU246 and LEU232, engaged in hydrophobic interactions with compound 762. The docking score and binding affinity (IC50) were predicted to be best among all top hits, i.e., −42.67 kJ/mol and 61.74 nM, respectively. Compound 762 could be a promising drug candidate for the treatment of NEK7-associated malignancies. The binding interactions of compounds 255 and 762 are shown in Figure 6.

The bonding and non-bonding interactions of standard Dabrafenib was involving important amino acid residues of NEK7 activation loop. ARG50, LYS38, ALA165, ILE40, GLY117, ASP115, PHE168, LEU111, LEU112, ALA114, LEU113, ALA161, ASP179, and ILE95 were the amino acid residues implicated in molecular interactions with Dabrafenib. Dabrafenib exhibited significant molecular interactions, which contributed towards complex binding affinity. The strong interactions were observed with targeted protein and sulphonamide rings. The sulphonamide ring was implicated in several important stabilizing contacts, including conventional hydrogen bonding with ASP115 of the activation loop, Pi-cation interaction with ARG50, and interactions with ILE40 and ASP115 by two fluorine atoms connected to the ring. PHE168 formed pi-cation and pi-pi T-shaped contacts with the butylthiazole ring, whereas the pyrimidine ring produced conventional hydrogen bonds with GLU112 and ASP179, a carbon–hydrogen connection with ALA114, and a pi-alkyl interaction with ALA161. Due to important chemical interactions, Dabrafenib has a good binding energy of −33.89 kJ/mol. van der Walls interactions are essential hydrophobic interactions that have been observed with the amino acids LYS38, ALA165, GLY117, LEU111, LEU113, and ILE95. Figure 7 depicts the probable binding mode of Dabrafenib with NEK7.

## Section: 3. Results and Discussion › 3.3. Electrostatic Surface Potential Map

Investigating the electrostatic surface potential (ESP) map is a key activity in drug design as it determines the chemical reactivity of the compound and its ability to produce important molecular interactions. It is an effective way to visualize the molecular reactivity and evaluate the nature of ligand-binding with a targeted protein. The ESP map is depicted by different colored regions depending upon the electronegativity of the compound. The highly electronegative part is represented by the color red, whereas the electropositive part is represented by the color blue. The QM calculations were performed using DFTs at the B3LYP/6-31G* level of theory. Figure 8 depicts the ESP potential and the nature of ligand-binding with the targeted protein. In this study, the contribution of the electronegative oxygen atom in all interactions is indicated by the color red, whereas the contribution of the nitrogen atom is provided in the color blue. Considering the electrostatic surface potential map, the contribution of oxygen atoms toward interaction potential is higher than that of nitrogen atoms. It was observed that in the case of compound 208, the electronegative oxygen atom was acting as a hydrogen acceptor and was producing strong hydrogen bonding with GLY117. Similarly, in compound 248, 255 and 762, electronegative oxygen atoms were involved in stronger intermolecular interactions. In contrast, nitrogen atom was involved in hydrogen bonding by donating the hydrogen bond for example, in case of compound 208, nitrogen was donating hydrogen bond to ASP118 residue. In addition, the docked conformation of ligands on the protein surface is also represented by different colored regions (Figure 8). The red surface indicates the hydrogen bond acceptor region, while the blue surface indicates the hydrogen bond donor locations. Whereas the grey color areas indicate the hydrophobic interactions, including van der Waals interactions. The red-colored surface area of protein is buried by nitrogen atoms as they act as proton donors, whereas the blue-colored protein surface is buried by electronegative atoms such as oxygen, fluorine and chlorine, which acts as a hydrogen bond acceptor. It can be observed that the grey surface area of protein is mostly involved in hydrophobic interactions, and these regions are buried by alkyl, phenyl rings and other hydrophobic groups present in all compounds.

## Section: 3. Results and Discussion › 3.4. Buried Surface Area (BSA)

Molecular interactions are the critical factors in determining the stability of protein–ligand complexes. Molecular interactions existing between protein–ligand complexes can be modelled by taking into account the physicochemical properties and complementarity of the shape of the binding interface. A useful method for determining the complementarity of the shape and extent of molecular interactions is the estimation of the buried surface area (BSA) of a protein–ligand complex. In the current study, the BSA of best complexes was calculated using a new Shrake–Ruply algorithm-based tool (dr_sasa) [57] used for calculating the solvent accessible surface area (SASA), buried surface area (BSA), and contact surface area (CSA). All four top compounds (208, 248, 255, and 762) were subjected to the calculation of BSA. It was observed that the targeted NEK7 protein was buried up to 80% and 70% by compounds 208 and 248, respectively. In particular, amino acid residues ILE40 and PHE168 were strongly buried by compound 208 (49 Å2). Compound 248, on the other hand, was strongly engaging the ARG121 and PHE168 with BSA of 39 Å2 and 41.3 Å2 respectively. The detailed buried surface area of both compounds is shown in Figure 9.

In terms of compounds 255 and 762, it was observed that both compounds significantly engaged the amino acid residues of the target protein. Compound 255, in particular, was burying the surface area of the NEK7 protein by up to 360 Å2. The BSA of compound 255 with VAL48, LYS63, ALA114, and PHE168 was 168, 212, 187, and 351 Å2, respectively, which was the best among all top hits. These values demonstrate the strong nature of molecular interactions existing between the target protein and compound 255. In the case of compound 762, important amino acid residues were buried by compound 762. In particular, TYR201, TYR237, and MET241 were significantly buried by compound 762 with BSA of 64, 72, and 25.6 Å2. Moreover, it was worth noticing that the major contributing atoms were oxygen, nitrogen, fluorine, sulphur, and chlorine, which were involved in increasing the contact surface area of compounds with a targeted protein. The BSA of compounds 255 and 762 is shown in Figure 10.

## Section: 3. Results and Discussion › 3.5. Molecular Dynamic Simulation

The molecular docking technique is comparatively rapid and imprecise. The docking deficiencies and flexibility of protein may interfere with protein–ligand complex. However, molecular dynamic simulations are computationally expensive and time-consuming but provide reliable and accurate illustration of protein displacement. Considering these facts, molecular dynamic simulations were undertaken using Desmond software package [58,59]. The root-mean-square deviation (RMSD) patterns provide significant insight into average change in displacement of atoms with respect to a frame. The RMSD trajectory provides information about the structural configuration of protein. It is computed for each frame of the trajectory. In order to gain insight into the structure of a protein, it is important to monitor the protein’s RMSD. Plotting the RMSD of the ligand is possible once the protein–ligand complex is aligned on a reference protein backbone and the RMSD of the ligand heavy atoms is measured. It is likely that the ligand has diffused from its initial binding site if measured values exceed the protein’s RMSD by a substantial margin. Molecular dynamic trajectory analysis is also used to determine the root-mean-square fluctuation of the targeted protein.

## Section: 3. Results and Discussion › 3.5. Molecular Dynamic Simulation › 3.5.1. RMSD Analysis of Protein and Protein–Ligand Complexes

The RMSD patterns for C-alpha atoms of NEK7 protein were estimated in order to determine the effect of the bounded drug on the conformational stability of NEK7 protein. Figure 11 is displaying the progression of RMSD values for the C-alpha atoms of NEK7 as a function of time. The 2wqn–Dabrafenib complex reaches the equilibrium after around 5 nanoseconds of simulation, and although side chain residues displayed fluctuations, they remained in the permissible range of 1–4 angstroms, which can be considered insignificant [60]. The NEK7–Dabrafenib complex showed slight fluctuations after 50 ns, which again became stable after 60 ns of simulation and remained equilibrated throughout the simulated trajectory. RMSD fluctuation was observed from 70 to 90 ns, which is due to the decrease in the number of contacts during this time, but after 90 ns, the number of contacts with amino acid residues increased and RMSD pattern became stable. It demonstrate the existence of stable molecular interactions. After being equilibrated, NEK7 RMSD values fluctuated within 2 angstrom. After 80 ns, protein RMSD showed slight fluctuation up to 2.5 angstrom and dropped again after 95. The average RMSD value for the protein–ligand complex and NEK7 protein is tabulated in Table 5.

These findings suggest that the ligands stayed firmly bound to the receptor throughout the simulation period. Moreover, small RMSD patterns indicate the fewer structural re-arrangements and lesser conformational changes within binding site residues [61].

It is beneficial to identify local differences in the protein chain by using the root-mean-square fluctuation (RMSF). Figure 12 peaks on the RMSF graph represent the regions of the protein that change the most during the simulation. The average RMSF for the NEK7 backbone was 0.87 angstrom, indicating the fewer structural rearrangements (Table 5). The N- and C-terminal ends of proteins are more likely to undergo alteration than any other portion of the protein. In the range of amino acids from 180 to 220, the RMSF value fluctuated, as can be seen in the RMSF graph. These residues are found in the C-terminal lobe. The protein’s structure, such as its alpha and beta helices and strands, tends to be stiffer and less variable than its unstructured component. According to MD trajectories, the residues with the highest peaks are found in loop areas or the N- and C-terminal regions. Binding site residues with low RMSF values imply a stable ligand–protein interaction.

The contact profiles of NEK7–Dabrafenib were computed from simulated trajectories, as shown in Figure 13. FDA-approved drug Dabrafenib interacted with ILE40, LYS163 and ARG121 through Water Bridge and hydrogen bonding. The amino acid residues, ILE40, LYS163, and ARG42, were involved in H-bonding. During MD simulations, 12 hydrogen bonds were found to be dominant with significant occupancy. Details of hydrogen bonding is given in Table 6.

The hydrogen bond with ALA114 existed for more than 25% of simulation time. Hydrophobic interactions existed between VAL48, LEU113, VAL48, and PHE168. These molecular interactions contributed towards stabilizing the protein–ligand complex.

## Section: 3. Results and Discussion › 3.5. Molecular Dynamic Simulation › 3.5.2. Radius of Gyration (Rg) and Solvent-Accessible Surface Area of Protein (SASA)

Radius of gyration (Rg) is measure of protein compactness, stability, integrity and foldness of protein backbone. The Rg trajectory for NEK7 is depicted in Figure 14. Trajectory analysis for the radius of gyration revealed that protein retained compactness throughout the simulated trajectory, and only slight fluctuations were observed around 30 ns, which stabilized after a short period of time.

Solvent-accessible surface area (SASA) is the area of protein that is accessible by the solvent. The higher the value for SASA, the lower the stability of the protein. In the current study, residue wise SASA was calculated and ranged between 180 to 350 Å2, which is quite acceptable. The average SASA value was computed to be 282.72 Å2 (Table 5). The residue wise SASA of targeted protein is shown in Figure 15.

## Section: 3. Results and Discussion › 3.5. Molecular Dynamic Simulation › 3.5.3. Principle Component Analysis (PCA)

It is an essential multivariate statistical technique used to describe the protein dynamics in a spatial scales. It is a linear relationship that extracts essential features of protein using covariance and/or correlation matrices. These matrices are derived from the atomic coordinate that represents the accessible degree of freedom (DOF) of the protein in a simulated trajectory. In the current study, Pearson’s cross-correlation matrix was employed as it can normalize the large protein variables and prevent high atomic variations that can skew the results. In addition, eigenvectors with a specific variance value also play an important role in characterizing the motion of protein in spatial scales. In the current study, essential dynamics of protein were calculated by applying PCA analysis to the protein trajectory. It was observed that different variables were forming tight clusters with narrow angles, which indicates that they were correlated with vectors (PCs) [62]. PCs are the vectors that are used to describe protein motion with respect to variables. Two PCs are used in the current study to characterize the protein motion. In Figure 16, it can be observed that PC1 and PC2 are clearly indicating the behavior of various variables. Distribution on the scatter plot indicates the protein components are tightly clustered with small angles.

Correlation matrices are also the correlation coefficients between variables and PCs. In Pearson’s cross-correlation, the percent of variance in a protein variable is explained by PCs. Figure 17 is depicting the Pearson correlation graph for NEK7 variables.

## Section: 3. Results and Discussion › 3.5. Molecular Dynamic Simulation › 3.5.4. MM-GBSA Energy Calculations

Molecular docking is a robust technique for determining the binding orientation of a protein–ligand complex. However, it is still lacking in its ability to correctly identify the binding affinities of docked ligands. In order to determine correct binding energies of docked conformations, MM-GBSA energy calculations were performed, which are an efficient and reliable method for the determination of binding free energies. The MM-GBSA method provides free energy calculations by taking into account all hydrophobic, hydrophilic and electrostatic interactions [63]. After energy calculations, values obtained were more negative and showed stronger binding affinities, as compared to the docking scores obtained from molecular docking. The following equation was used to calculate binding free energy [64]; ΔGbind = ΔE mm + ΔG sol + ΔG SA

The MM-GBSA energies for the protein–ligand complex was determined through the Thermal_mmgbsa script of Schrodinger. MM-GBSA energies are tabulated in Table 7.

## Section: 3. Results and Discussion › 3.5. Molecular Dynamic Simulation › 3.5.5. MM-PBSA Energy Calculations

In MMPBSA energy analysis, the free binding energies of protein, ligand and protein–ligand complex are estimated by following equation; G = Ebnd + Eel + EvdW + Gpol +Gnp − TS where, Ebnd I refers to bond energy, Eel refers to electrostatic energy and EvdW represents van der Waals interactions. In the current study, Poisson–Boltzmann calculations were performed using the internal PBSA solver in mmpbsa_py_energy. All units are represented in kcal/mol. MM-PBSA energy analysis is given in Table 8.

## Section: 3. Results and Discussion › 3.6. ADMET Profile

In-silico ADMET properties of top-ranked hits were determined by deep learning models; more than 17 models were employed at the backend, which provided predictions on the ADME profile of each hit. It is an important part in drug development that can identify the desired pharmacological properties of compounds. In the current study, the message passing neural network (MPNN) is employed for the determination of ADMET properties. It was observed that compound 762 showed the lowest clinical toxicity value of 0.28%. The ADMET profile of top hits is tabulated in Table 9.

## Section: 4. Conclusions

In the current study, structure-based virtual screening of a 1200-compound library and Dabrafenib was carried out using Auto Dock Vina. These compounds are in the early stages of drug development, and the in-silico approach used in this study was contributing toward investigating the inhibiting potential of these compounds through molecular docking, DFTs, and MD simulation, as well as determining the drug-like properties of these compounds through deep learning models. The FDA-approved drug, Dabrafenib, was considered as a standard drug to which in-silico findings could be compared. SBVS findings discovered four important hits having better binding energies as compared to standard Dabrafenib. In addition, the chemical reactivity profiles of top hits were determined via DFT studies. Findings from DFT studies revealed the reactive nature of the compounds. Moreover, the current study has utilized deep learning models for prediction of binding affinity, pIC50, and ADMET properties. It was observed that compound 762 showed good binding affinity and demonstrated a promising ADMET profile. Moreover, molecular dynamics simulations were performed to determine the stability of the protein–ligand complex under accelerated conditions. It was observed that the ligand remained significantly attached to the protein-activation loop, suggesting potential inhibiting activity of the compound. In short, the findings of the current study identify top hits that could prove an effective treatment strategy for NEK7-associated cancer malignancies. These findings will assist researchers to develop newer leads without consuming much time and money. Further experimental studies are also recommended for future prospects.


---

# Deep learning-based molecular dynamics simulation for structure-based drug design against SARS-CoV-2

- **Authors:** Yao Sun, Yanqi Jiao, Chengcheng Shi, Yang Zhang
- **Issuer:** Computational and structural biotechnology journal
- **Type:** Scientific article
- **Published:** 2022-09-07
- **Language:** en
- **DOI:** 10.1016/j.csbj.2022.09.002
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36091720/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

Coronavirus disease 2019 (COVID-19), caused by severe acute respiratory syndrome coronavirus type 2 (SARS-CoV-2), has led to a global pandemic. Deep learning (DL) technology and molecular dynamics (MD) simulation are two mainstream computational approaches to investigate the geometric, chemical and structural features of protein and guide the relevant drug design. Despite a large amount of research papers focusing on drug design for SARS-COV-2 using DL architectures, it remains unclear how the binding energy of the protein-protein/ligand complex dynamically evolves which is also vital for drug development. In addition, traditional deep neural networks usually have obvious deficiencies in predicting the interaction sites as protein conformation changes. In this review, we introduce the latest progresses of the DL and DL-based MD simulation approaches in structure-based drug design (SBDD) for SARS-CoV-2 which could address the problems of protein structure and binding prediction, drug virtual screening, molecular docking and complex evolution. Furthermore, the current challenges and future directions of DL-based MD simulation for SBDD are also discussed.

## Section: Introduction

Since the end of 2019, the COVID-19 caused by SARS-CoV-2 has emerged into an unprecedented public health crisis, causing many deaths around the world. By July 2022, more than 566 million confirmed cases and 6.37 million deaths had been reported globally (https://covid19.who.int/). The common symptoms of COVID-19 are pneumonia, shortness of breath, dry cough, tiredness [1], and even some neurological complications [2]. Besides, the coronavirus is continuously mutating, with some new variants being more virulent and transmissible than the original ones. At present, the Omicron is the dominant variant globally and accounts for almost all sequences reported to Global Initiative on Sharing Avian Influenza Data (GISAID) [3]. Up to now, the Omicron variant has emerged several sub-lineages including BA.1, BA.1.1, BA.2, BA.3, BA.4 and BA.5. The BA.2 and BA.3 are highly relative to BA.1 but contain some different mutations in the N-terminal domain (NTD) and receptor binding domain (RBD) of the spike (S) (Fig. 1a). Comparing to BA.1, the BA.1.1 has an additional R346K mutation in the RBD [4]. The S sequences of BA.4 and BA.5 are identical which are speculated evolving from BA.2. The BA.4 and BA.5 show additional mutations in the RBD, including R493Q, L452R and F486V. It is worthy of noting that the R493Q is a reverse mutation of Q493R appeared in other Omicron sub-lineages (Fig. 1) [5]. Rao et al. have analyzed 1.79 million S glycoprotein sequences of SARS-CoV-2 and found that the virus is fine-tuning the S protein with numerous amino acids (AA) insertions and deletions [6]. Facing of the fast mutating, possibly more virulent, transmissible, and cunning virus, new therapeutic molecules are urgently required [7]. However, the traditional experimental drug discovery is usually expensive and time-consuming. Structure-based drug design (SBDD) is a proven highly effective and economical computer-aided design approach that could speed up the drug discovery for SARS-CoV-2 [8], [9], [10]. A typical SBDD starts from the input protein sequence, builds a three-dimensional (3D) structure by structure biology or structure prediction, identifies binding sites, discovers active modulators through virtual screening or de novo design, predicts the protein–protein/ligand docking sites with high accuracy, and lastly simulates the dynamics evolution of the macromolecule (Fig. 2) [11], [12].Fig. 1The mutations of Omicron sub-lineages. (a) The mutations in S of BA.1, BA.1.1, BA.2, BA.3, BA.4 and BA.5 with NTD and RBD indicated; (b) The positions of RBD mutations, with mutations common to all Omicron colored in white, common to BA.1 and BA.1.1 colored in cyan, unique to BA.1.1 colored in blue, and unique to BA.2 colored in magenta. Residue Serine 371 is mutated to Leucine 371 (S371L) in BA.1 and BA.1.1, but mutated to Phenylalanine (S371F) in BA.2 and BA.3. The RBD is plotted by gray surface with the hACE2 footprint colored in dark green [5]. Reproduced with permission. Copyright 2022, Elsevier. (For interpretation of the references to colour in this figure legend, the reader is referred to the web version of this article.)Fig. 2The basic steps involved in the SBDD method. The first panel shows target protein structure prediction, at which the sequence is input and, through DL algorithm, the protein structure is obtained. The second panel shows the identification of ligand binding sites, and the next step is drug virtual screening. In the last panel, compounds obtained by molecular docking are synthesized and tested in vitro, and finally MD simulations are performed.

During the past few years, the deep learning (DL) technology has been rapidly implemented into drug discovery. DL is an algorithm based on an artificial neural network (ANN) for data representation learning [13]. Up to now, several DL frameworks, such as deep neural network (DNN) [14], [15], convolutional neural network (CNN) [16], [17], deep confidence network [18], recurrent neural network (RNN) [19], and generative adversarial network (GAN) [20], [21], etc. have been broadly applied in various fields, achieving better results comparing to other computational models [22].

In terms of novel Coronavirus treatment, DL-based computer-aided drug bio-computation can quickly identify drug molecules that effectively prevent infection, showing potentials in finding the cures for COVID-19 [23]. In addition, some new programs of DL such as AlphaFold and its 2nd version (AlphaFold2) have been utilized in 3D structure prediction of protein which show ultra-high accuracy comparable to data collected by cryo-EM [24], [25], [26]. Artificial intelligence (AI) has attracted tremendous interests in the research of SBDD [27], [28], [29], [30], [31]. However, limitations of DL models used in drug design are that they learn through observations, and fail to consider the dynamic interactions of protein–protein/ligand. The molecular dynamics (MD) simulations act a crucial role in studying biological systems, which can be used to reveal different conformations of proteins, evolutions of protein-protein/ligand interactions and spontaneously complex phenomena such as protein folding [32], [33], [34]. In the past decades, more researchers have realized that MD can overcome the major limitations of SBDD, including those limitations routinely appear in ligand docking calculations without sampling the protein conformational rearrangements during ligand binding. The MD simulations also offer opportunities to make sound scientific breakthroughs in COVID-19 research, which contribute to a comprehensive understanding of mechanisms of virus infection and pathogenesis of COVID-19 [35], [36]. In addition, they are effective ways to visualize the essence of protein–protein/ligand interactions and guide the drug discovery and design. For example, MD simulations can be performed to evaluate the stabilities and interactions of the human angiotensin-converting enzyme 2 (hACE2) receptor with screened natural inhibitors to identify novel drug candidates against SARS-CoV-2 [37]. A major drawback of MD is the accuracy of simulations should always rely on proteins with known structures (usually downloaded from the Protein Data Bank (PDB) [38]).

Considering the advantages of both the DL and MD computational methods, DL-based MD simulation for SBDD has been adopted against SARS-CoV-2. This paper firstly reviews the latest applications and research progresses of DL technology in SBDD. Then, the DL-based MD simulation in SBDD for SARS-CoV-2 is highlighted and discussed. At last, we discuss the future direction for computational methods in SBDD. During the COVID-19 global pandemic, we believe this review could offer novel insights into the drug design against SARS-CoV-2.

The mutations of Omicron sub-lineages. (a) The mutations in S of BA.1, BA.1.1, BA.2, BA.3, BA.4 and BA.5 with NTD and RBD indicated; (b) The positions of RBD mutations, with mutations common to all Omicron colored in white, common to BA.1 and BA.1.1 colored in cyan, unique to BA.1.1 colored in blue, and unique to BA.2 colored in magenta. Residue Serine 371 is mutated to Leucine 371 (S371L) in BA.1 and BA.1.1, but mutated to Phenylalanine (S371F) in BA.2 and BA.3. The RBD is plotted by gray surface with the hACE2 footprint colored in dark green [5]. Reproduced with permission. Copyright 2022, Elsevier. (For interpretation of the references to colour in this figure legend, the reader is referred to the web version of this article.)

The basic steps involved in the SBDD method. The first panel shows target protein structure prediction, at which the sequence is input and, through DL algorithm, the protein structure is obtained. The second panel shows the identification of ligand binding sites, and the next step is drug virtual screening. In the last panel, compounds obtained by molecular docking are synthesized and tested in vitro, and finally MD simulations are performed.

## Section: Basic steps of SBDD

(a) All binding site pockets observed from 137 inhibitors in SARS-CoV-2; (b) Distribution of 137 ligands across 13 distinct binding sites; (c) Box plot of predicted binding energies (kcal/mol) of all inhibitors in each binding site [64]. Reproduced with permission. Copyright 2020, Royal Society of Chemistry.

A schematic illustration of the generative network complex. SMILES strings are encoded into the latent space vectors via a gated RNN-based encoder. A molecule generator is applied on the latent vectors to achieve desirable druggable properties, such as binding affinity, partition coefficient (LogP), similarity, etc. from pre-trained DNNs. The resulting drug-like molecules are then decoded into SMILES strings via an RNN-based decoder. The physical properties of the decoded SMILES strings are examined by multitask DNNs. Potential drug candidates are then input into a MathPose unit to generate 3D structures, which are further validated by a mathematical DL (MathDL) unit to recommend new drug candidates [80]. Reproduced with permission. Copyright 2020, PubMed Central.

## Section: Basic steps of SBDD › Target protein structure prediction by DL

With the rapid development of structural analysis techniques such as X-ray and nuclear magnetic resonance, more and more protein structures have been solved and stored in the PDB [39]. However, the structures of many target proteins have not been solved yet due to the limitations of experimental techniques. Obtaining the accurate structure of a protein is essential to understand its biological function [40].

In the initial study, some researchers use Swiss model to do homology modeling of protein structure with the target sequence as input (http://swissmodel.expasy.org/interactive) [41]. But this online model has some deficiencies, which is impossible to model proteins with insertion of short AA chains or without highly similar templates [42], [43]. Another online modeling server, the iterative threading assembly refinement (I-TASSER) (http://zhanglab.ccmb.med.umich.edu/I-TASSER/) predicts protein structure based on the sequence-to-structure-to-function paradigm [44]. It uses AA sequence information to generate 3D atomic models from multiple threading alignments and iterative structural assembly simulations. The function of the protein is then inferred by structurally matching the 3D models with other known proteins. Although I-TASSER can provide disulfide bonding modes, secondary and tertiary structures, and functional annotations on ligand binding sites, but it takes a quite long time to build complex structures [45]. In 2020, DeepMind unveiled its AlphaFold2, a DL-based structure prediction method that ranked the first in protein structure prediction in 14th Critical Assessment of Techniques for Protein Structure Prediction (CASP14) competition [46]. AlphaFold2 is now freely accessible with novel neural network architectures that have improved the accuracy from its earlier version AlphaFold. The full realization of AlphaFold2 mainly consists of the neural network EvoFormer and the structure module [24], [47]. The EvoFormer uses two transformers and one clear communication channel between them. Each head is specialized for one particular type of data, such as a multiple sequence alignment (MSA), and a representation of pairwise interactions between AA. The information of the contiguous representation which allows for regular exchange of information and iterative refinement is also incorporated. The structure module uses the first part of MSA, as well as the pair features obtained by calculation, and initializes all the residual frames from the coordinate origin and calculates the updated backbone frames. Finally, the specific 3D atomic coordinates are predicted [24]. Later, researchers have independently reproduced many ideas of AlphaFold2 and implemented in the so-called RoseTTAFold [48]. Evans et al. have released AlphaFold-multimer, a refined version of AlphaFold2 for the prediction of protein complexes [49], generalizing the use of AlphaFold2 and RoseTTAFold which are usually for single chain prediction. Most recently, Mirdita et al. have developed ColabFold, which offers accelerated prediction of protein structures and complexes based on fast homology search of many-against-many sequence searching N(MMseqs2) by AlphaFold2 or RoseTTAFold [50]. The fast development of DL technology has provided more opportunities for accurate protein structure prediction. SARS-CoV-2 is a single-stranded RNA virus with a genome of about 30 kb [51], [52]. In addition to the 4 structural proteins (S, nucleocapsid (N), membrane (M), and envelope (E)), the SARS-CoV2 genome encodes 16 non-structural proteins (NSPs 1–16) which are essential for virus replication, eliciting the immune response and representing targets to develop future prophylactic and therapeutic approaches against COVID-19 [53]. Yang et al. have predicted the structures of S, M, and N proteins of the Omicron variant using AlphaFold2, and investigated the effects of mutations on the S1, NTD and RBD domains of S protein [54]. The high-precision structures of M and N proteins obtained by AlphaFold2 could provide a basis for understanding the replication and propagation characteristics of Omicron. Robertson et al. have evaluated the consistency of the models generated by AlphaFold2 by atomic pairs measured with residual dipole coupling (RDC) in solution [55]. They have found that the AlphaFold2 models are entirely consistent with the experimental RDC data for most proteins. Yang et al. have adopted AlphaFold2 to predict the structures of S proteins according to the sequences of the mutants and successfully predicted the S proteins of 10 major variants of SARS-CoV-2, including the Original, Alpha, Beta, Gamma, Delta, Epsilon, IOTA, Kappa, Lambda and 21H strains [56]. Gupta et al. have combined the cryo-EM with AlphaFold2 to obtain the atomic model of full-length SARS-COV-2 non-structural protein 2 (NSP2) [57], which reveals a highly-conserved zinc ion-binding site, suggesting a role for NSP2 in RNA binding. Through the mapping of emerging mutations from variants of SARS-CoV-2 on the resulting structures, the potential host-NSP2 interaction regions can be observed. These studies demonstrate that DL is more likely to be locally accurate for domain structure prediction, sufficient for global structure prediction and to offer comprehensive structure modeling strategies combined with experimental constraints.

The current literature on target protein structure prediction by DL mainly uses AlphaFold2 and analogical methods mentioned above. Although the structure prediction of a protein by DL could provide some essential resources for speculating its function, experimental works are still needed to further confirm the result. Besides, AlphaFold2 and other DL computational approaches have intrinsic defects. For example, AlphaFold2 predicts protein structures according to protein structures (training data) in the PDB, but many of these structures are not actually in their folded states. That is, the proteins could only correctly fold into specific structures upon binding to other proteins, substrates or metal ions, or assemble into large complexes. We are still facing the problems of the difficulties of analyzing protein functions, and the high costs of protein structure determinations through experiments. To address those problems, further studies in accurate determination of protein structures are necessary [58].

## Section: Basic steps of SBDD › Identification of ligand binding sites

A typical SBDD procedure involves the development of potential drug molecules or ligands which can form stable complexes with a given receptor at its binding sites. A prerequisite is to find out the druggable and functionally relevant binding sites on the 3D structure of the protein [59]. Information about binding sites is also required for specific docking. The binding sites could be traditionally identified by site-directed mutation studies or X-ray crystal structures of target protein [60]. Compared with traditional methods, DL-based models can be trained in a fully data-driven manner with little expert knowledge to predict the binding sites more quickly and accurately [61].

Nazem et al. have used an improved U-Net model based on the dice loss function to accurately predict binding sites of SARS-CoV-2 proteins [59]. The performance of the model on independent test datasets and SARS-CoV-2 shows that the segmentation model could predict binding sites more accurate than the recently released DL model DeepSite [62]. Nguyen et al. have integrated algebraic topology and DL (MathDL) to provide a reliable ranking of the binding affinities for 137 SARS-CoV-2 3-chymosin-like cysteine protease (3CLpro) inhibitors. The 3CLpro is an essential molecular target of SARS-CoV-2 [63]. They have reported 13 distinct binding pockets of the SARS-CoV-2 3CLpro which are denoted by Pi, i = 1, 2, …, 13, as illustrated in Fig. 3a. Among all the 13 binding pockets, P1 is the most common binding region of the SARS-CoV-2 3CLpro, which attracts around 80 % of ligands in the data set of 137 complexes while the binding pockets P2, P3, P5, P7, P8, and P10 are the least common binding sites consisting of only one ligand (Fig. 3b). In addition, the binding pocket P1 with the lowest media binding energy value has been found as the best region on the SARS-CoV-2 3CLpro for inhibitor design (Fig. 3c)[64]. Li et al. have developed the ligand neural network (l-Net), a novel graphic-generating model for the end-to-end design of chemically and conformationally efficient 3D molecules with high drug similarity [65]. Later, l-Net has been combined with Monte Carlo tree search for SBDD. The drawbacks of l-Net include limited versatility, requirement of expert knowledge, and heavily dependence on feature engineering. Then, Li et al. have introduced the DeepLigBuilder, a new drug design method based on DL which could generate 3D molecular structures of the binding sites of the target protein [65]. In a case study of SARS-CoV-2 3CLpro inhibitor design, DeepLigBuilder has recommended a list of drug-like compounds with novel chemical structures, high predictive affinity, and similar binding characteristics to known inhibitors by combining deep generation models with atomic-level interaction assessments.Fig. 3(a) All binding site pockets observed from 137 inhibitors in SARS-CoV-2; (b) Distribution of 137 ligands across 13 distinct binding sites; (c) Box plot of predicted binding energies (kcal/mol) of all inhibitors in each binding site [64]. Reproduced with permission. Copyright 2020, Royal Society of Chemistry.

It is worthy to note that SARS-CoV-2 has undergone several mutations since its emergence and is still evolving rapidly [66]. In particular, the S protein has been profoundly mutated with RBD as a primary domain showing many mutant clusters [67], [68]. The virus may accumulate further mutations at the RBD site to improve its interaction with hACE2 and escalate its infectivity. Predicting potential sites of non-synonymous mutations and the evolution of protein structural modifications that lead to drug tolerance are critical problems regarding the treatments of new mutants. Padhi and Tripathi have used a computational high-throughput interface-based protein design strategy to identify mutation hot spots and potential adaptation characteristics in the binding sites of 3CLPro. They have found that several mutants exhibit reduced binding affinity to drugs Boceprevir and Telaprevir, out of which hotspot residues having a strong tendency to undergo positive selection have been identified. The results indicate that these drugs have larger footprints in the mutational landscape of 3CLpro and hence encompass the highest potential for positive selection and adaptation [69].

These state-of-the-art models for SBDD demonstrate the capability of computational approaches especially the incorporation of DL methods in predicting protein binding sites and its potential in accelerating drug design and discovery for COVID-19. However, a majority of them have been limited by the expressivity of the handcrafted features and the availability of similar proteins. In addition, some of the DL methods are surprisingly failed in the identification and ranking of binding sites accurately. Recently, Tubiana et al. have introduced ScanNet, an end-to-end, interpretable geometric DL model that learns features directly from 3D structures of proteins. It builds representations of atoms and amino acids based on the spatial-chemical arrangements of their neighbors. The ScanNet is trained for detecting protein–protein and protein-antibody binding sites, demonstrating high accuracy in presenting folding of unseen protein and interpreting the filters learned. They have successfully predicted epitopes of the SARS-CoV-2 S protein and validated known antigenic regions [70]. ScanNet is also demonstrated easily to be generalized to other classes of binding sites with sufficient available training data. Extension to partner-specific binding prediction and guiding molecular docking is a promising future direction in SBDD.

(a) All binding site pockets observed from 137 inhibitors in SARS-CoV-2; (b) Distribution of 137 ligands across 13 distinct binding sites; (c) Box plot of predicted binding energies (kcal/mol) of all inhibitors in each binding site [64]. Reproduced with permission. Copyright 2020, Royal Society of Chemistry.

## Section: Basic steps of SBDD › Compound library preparation-drug virtual screening

DL-aided virtual screening by using the 3D structures of target protein and small molecule drugs together with their binding could help to achieve very large-scale drug screening from chemical libraries [71]. The DL methods are typically data type dependent and have been extensively used in drug prediction and design. For example, text mining techniques and graphics-based approaches are used for drug reuse, while autoencoder approaches are largely helpful in predicting drug possibilities, drug target relationships, and generation of new drug molecules. Graph Convolutional Network like DL and molecule transformer-drug target interaction (MT-DTI) methods have been proved to be successful in predicting available antiviral drugs that are effective against SARS-CoV-2. AI/DL subsets, homology modeling, virtual screening and molecular docking are the most commonly used SARS-COV-2 drug reuse approaches to identify potentially effective drugs for the treatment of COVID-19 infection [72]. Up to now, hundreds of potential drugs have been discovered by the AI/DL technology [73], [74], [75], [76], [77], saving more time and effort for drug development than the traditional experimental methods.

Joshi et al. have used DL methods to conduct virtual screening of natural compounds to find effective drugs against COVID-19 [78]. In their work, DL is used to predict 3CLpro inhibitor in CHEMBL3927 dataset, and the predicted models have been developed and evaluated based on coefficient of determination (R2), mean absolute error (MAE), mean square Error (MSE), root mean squared error (RMSE) and loss. Karki et al. have introduced the application of an end-to-end DNN framework called SSnet, which is used to repurpose approved drugs from a large drug library [79]. They have firstly screened a small library of approved drugs from DrugBank and ZINC by SSnet to identify compounds that have high-binding affinities. The results are cross-validated against traditional drug docking algorithm using the Autodock Vina scoring function. Then the SSnet approach has been extended to a library of 750,000 compounds in BindingDB, with the compounds that have poor predicted binding capacity discarded. In this way, potential binding agents can be identified to target hACE2 for possible COVID-19 treatments. Nand et al. have used the DL prediction model, drug similarity screening and molecular docking to screen 1528 anti-HIV-1 compounds, and finally screened out 41 compounds against 3CLpro. Considering the IC50 values of known inhibitors, a DL model has been constructed to re-screen the 41 compounds and resulted in 22 hit compounds. Finally, 2 out of the 22 hit compounds have been screened out as potential targets of 3CLpro, which could be used as drugs to treat SARS-CoV-2. Gao et al. have developed a generative network complex (GNC) platform to design new drug candidates for treatment of SARS-CoV-2, as shown in Fig. 4. The first component of the platform is a generative network including an encoder, a latent space, a molecule generator, and a decoder. The simplified molecular input line entry specification (SMILES) strings are the input to generative network to generate novel molecules, which are fed into the second component of GNC, a 2D fingerprint-based DNN, to re-evaluate their druggable properties. The next component is the MathPose model which is used to predict the 3D structure information of the compounds selected by the 2D fingerprint-based DNN. The bioactivities of those compounds are further estimated by the structure-based DL model named MathDL. The druggable properties predicted by the last component of GNC are used as an indicator to select the promising drug candidates [80]. Kumari and Subbarao have proposed a DL model based on a CNN architecture which could be used to predict the inhibitory activity of 3CLpro against unknown compounds during virtual screening for SARS-CoV-2 [81]. The descriptors which represent the chemical molecules are input into the CNN framework training model to predict active compounds, and could be further used to develop new targeted anti-SARS-CoV-2 compounds. Ahmed et al. have integrated a CNN to find the spatial relationship between input and output data to help predict the affinity of protein binding to multiple ligands in the general family without docking postures or complex user inputs [82]. They have proposed to predict ligands by using the structures of target proteins (PDB format) and ligands (SDF format) as inputs for target binding affinities. The CNN has been used to learn representations from hidden layers and affinity prediction tasks can be extracted from inputs. In comparison to some widely used methods, their work shows better performance for predicting high-resolution protein crystals and non-peptide ligands. In detail, they have used two levels (atomic level and composite level) for feature extraction and compared their performance using the same network. The algorithm is relied on sensitive binding cavity detection which uses mathematical morphology to find deep and shallow pockets (if any) in a given protein. The coordinates of the predicted binding cavity of the protein are placed around the center of mass of the ligand and rotated to various combinations, while the resultant 4D tensor is further processed with CNN. The dataset has approximately more than 5000 complexes including complexes that are not part of PDBbind. The ligand set they have used also represents a diverse set and is one of the highlights of their approach. Joshi et al. have developed a domain aware generation framework called 3D-scaffold which takes the 3D coordinates of the required scaffold as input, and the 3D coordinates of the new treatment candidate scaffold as output, while always preserving the required scaffold in the generated structure [83]. It shows good performance on SARS-CoV-2 3CLpro and NSP15 targets. Most importantly, their DL model performs well with relatively small 3D structural training data and could quickly learn to generalize new scaffolds, highlighting their potential applications in generating target-specific candidates. Wang et al. have adopted a directed message passing neural network which could learn the structure–activity behaviors from a collection of anti-beta-CoV active and inactive compounds to successfully construct a broad-spectrum anti-viral compound prediction model for new active drugs against SARS-CoV-2. After that, they have applied transfer learning to fine-tune the model with the newly reported SARS-COV-2 drugs, generating a specific SARS-COV-2 predictive model called COVIDVS-3. The COVIDVS-3 has been proved capable of screening a large compound library with 4.9 million drug-like molecules from ZINC15 database and recommending a list of potential anti-SARS-CoV-2 compounds for further experimental tests [84]. The experimental validation has demonstrated that the COVIDVS-3 is highly efficient and can be used to screen large compound databases containing millions or more compounds, successfully accelerating the drug discovery process for COVID-19. Gentile et al. have developed an AI-powered virtual screening pipe, which uses deep docking with the Autodock GPU, Glide SP, FRED, ICM and QuickVina2 programs to screen 40 billion molecules that target SARS-CoV-2 3CLpro [85]. Their findings have provided a new starting point for the lead-to-lead optimization campaign for 3CLpro and encouraged the developments of fully automated AI-based drug discovery protocols. Budak et al. have successfully used structural information of molecules and proteins to prepare a list of repurposed drug candidates from FDA-approved drugs by a graph neural network-based graph early fusion affinity (GEFA) model. The Tanimoto/jaccard similarity analysis is conducted on data sets from public databases DrugBank and PubChem, and a list of similar drugs have been prepared by comparing the drugs used in the treatment of COVID-19 with the drugs used in the treatment of other diseases [86]. Kang et al. have analyzed RNA-seq datasets using various bioinformatics methods (e.g., gene ontology, protein–protein interaction-based networks) to profile the upregulation of molecular pathways and analyze the gene enrichment of normal human bronchial epithelial (NHBE) cells infected with SARS-CoV-2. The results suggest that COVID-19 is similar to acute mode of chronic obstructive pulmonary disease (COPD) caused by SARS-CoV-2 infection and the drug Tiotropium may be effective for patients with COVID-19 [87]. Ting et al. have identified basic infections of pathogenesis by comparing core signaling pathways between COVID-19-ARDS (acute respiratory distress syndrome) and non-viral-ARDS. The DNN of the Drug-target interaction model (DNN-DTI) has been trained in advance through the drug-target interaction database to predict drug candidates with identified biomarkers. These predicted drug candidates have been further narrowed down as potential multimolecular drugs through a drug design specification filter [88]. Hu et al. have proposed a new framework called AI model and enzymological experiments (AIMEE) to identify inhibitors of 3CLpro against SARS-COV-2. Based on two rounds of experiments, interpretability of the central model in AIMEE, and mapping of the DL extracted features to the domain knowledge of chemical properties, a commercially available compound has been selected and proven to be an activity-based probe of 3CLpro [89]. Zeng et al. have reported an integrative, network-based DL methodology to identify repurposable drugs for COVID-19. Specifically, they have built a comprehensive knowledge graph which includes 15 million edges across 39 types of relationships connecting drugs, diseases, proteins/genes, pathways, and expression collecting from 24 million PubMed publications. Using such network-based DL methodology, they have successfully identified 41 repurposable drugs whose therapeutic associations with COVID-19 can be validated by transcriptomic and proteomics analysis in SARS-CoV-2 infected human cells [90]. Yuvaraj et al. have designed a DNN model that can accurately sense the protein–ligand interactions of specific drugs and make decision on which drug produces effective interactions against SARS-COV-2 [91].Fig. 4A schematic illustration of the generative network complex. SMILES strings are encoded into the latent space vectors via a gated RNN-based encoder. A molecule generator is applied on the latent vectors to achieve desirable druggable properties, such as binding affinity, partition coefficient (LogP), similarity, etc. from pre-trained DNNs. The resulting drug-like molecules are then decoded into SMILES strings via an RNN-based decoder. The physical properties of the decoded SMILES strings are examined by multitask DNNs. Potential drug candidates are then input into a MathPose unit to generate 3D structures, which are further validated by a mathematical DL (MathDL) unit to recommend new drug candidates [80]. Reproduced with permission. Copyright 2020, PubMed Central.

As shown above, different DL architectures and databases have been adopted and successfully applied in drug virtual screening against SARS-COV-2. However, one of the major challenges for drug screening from large databases is the growing demand for computational resources, which are usually unaffordable for most labs due to the high computational costs. Therefore, various DL-based docking simulation technologies have been proposed to perform such tasks without a large amount of computing resources. Another major challenge for drug virtual screening is the possibility of generating false positives and incorrect ranking of ligands docked. Different results can be obtained through different virtual screening methods even with the same input. We hope that more and better virtual screening technologies will flourish in future and become the mainstream in SBDD.

A schematic illustration of the generative network complex. SMILES strings are encoded into the latent space vectors via a gated RNN-based encoder. A molecule generator is applied on the latent vectors to achieve desirable druggable properties, such as binding affinity, partition coefficient (LogP), similarity, etc. from pre-trained DNNs. The resulting drug-like molecules are then decoded into SMILES strings via an RNN-based decoder. The physical properties of the decoded SMILES strings are examined by multitask DNNs. Potential drug candidates are then input into a MathPose unit to generate 3D structures, which are further validated by a mathematical DL (MathDL) unit to recommend new drug candidates [80]. Reproduced with permission. Copyright 2020, PubMed Central.

## Section: Basic steps of SBDD › Molecular docking

Molecular docking is a computational technique to study the interaction between a target protein and a ligand at the atomic level, which can be used to predict the ligand conformation as well as its position and orientation within binding sites, and offers assessment of the binding affinity [92]. Various scoring functions [93] have been used to evaluate the binding affinity between a ligand and a receptor. In most cases, the success of molecular docking is dependent on the target and computational methods[94]. In literature, most studies on molecular docking prediction tend to predict molecules that bind protein targets with detectable affinities and solved crystal structures [95]. The real challenge is to calculate the relative binding energy with sufficient accuracy to allow as many true positives as possible in the final selection of compounds. With the assistance of DL technologies, sliding docking (or other docking events) and docking scores can be predicted and achieved quickly and more accurately. Notably, the Drug Design Data Resource (D3R), a community-oriented initiative that collects and uses scientific data to test and advance the computer aided Drug Design technology through community-wide blind prediction challenges, has been established to provide opportunities for prediction of protein–ligand poses, affinity rankings, and relative binding free energies. D3R enables rigorous evaluation of normally used computational techniques and succeeds in reducing costs and accelerating the discovery of new drugs in a range of therapeutic areas. However, it does not have the power to clearly distinguish among most approaches with respect to incorporation of machine learning or choosing from structure-based, ligand-based methods and alchemical free energy methods [96].

Ton et al. have developed a new deep docking platform, deep docking (DD), which could quickly predict docking scores for sliding docking, enabling structure-based virtual screening of billions of purchasable molecules in a short period [97]. Mylonas et al. have reported a method which combines a variety of conformation ligands with ResNET-based CNN scoring feature, including the docking output scores in the evaluation. When tested against the DUD-E dataset (a dataset to help benchmark molecular docking programs by providing challenging decoys), it shows significant performance, especially in early enrichment which exceeds the current benchmarks [98]. Their proposed method is eventually applied to target the emerging COVID-19, and successfully discovers the inhibitors for the SARS-COV-2 S protein-hACE2 interaction. By introducing MolAICal software and combining the advantages of DL model and classical algorithm, Bai et al. have proposed a method to generate 3D drugs in 3D pockets of the target proteins [99]. The MolAICal software is mainly composed of two 3D drug design modules. In the first module of MolAICal, genetic algorithm and DL model are used for drug design and training of FDA-approved drug fragments, and Vinardo score fitting is performed based on PDBbind database (a comprehensive collection of experimentally measured binding affinity data for the protein–ligand complexes deposited in the PDB). In the second module, DL generative model is trained by drug-like molecules from ZINC database while molecular docking is invoked by Autodock Vina automatically. For the drug design of SARS-COV-2, MolAICal is demonstrated capable of generating various and novel ligands with good binding scores to SARS-COV-2 3CLpro. Nguyen et al. have combined mathematics and DL methods to provide a reliable ranking of the binding affinities of 137 SARS-CoV-2 3CLpro inhibitor structures [64]. Anwar et al. have proposed a robust experimental design that combines DL methods with molecular docking experiments to identify the most promising drug candidates from the FDA-approved list of drugs which could be used for the treatment of COVID-19. FDA-approved drugs with the highest KIBA scores (representing drug-protein binding affinities) are selected for molecular docking simulations. The results show that 16 drugs demonstrate the highest predicted inhibitory potential against key SARS-CoV-2 viral proteins. In addition, the highest inhibition of papain-like cysteine protease (PLpro) activity can be seen with rifapentine and Flavin adenine dinucleotide (FAD) disodium which have high predicted KIBA scores and binding affinities [100].

In view of the above-mentioned works, we understand that computational drug virtual screening works as a prefilter to select molecules according to a particular predefined criterion of potentially active drugs against a target protein. The DL-based molecular docking is used to further select and investigate the protein-more potent drugs interactions. The docking-based virtual screening is the best example which performs the selections of drugs from large libraries and anlyzes the binding affinities of drugs at particular regions of the target protein receptor with elucidated 3D structures. The combination of DL technology and molecular docking enables fast selection and ideal binding results on drug design, however, there exists a typical drawback at the present stage. A large number of docking software including X-Score, Autodock Vina, and ChemScore use the empirical scoring functions which are limited to features extracted from structural information and often assume a linear relationship existed between the features and the binding affinity. Therefore, researchers are still committed to search for alternative scoring functions that are able to describe the nonlinear relationships between the features and the binding affinity [101].

## Section: Basic steps of SBDD › Molecular dynamics (MD) simulation

MD simulations of proteins were first carried out in the late 1970s [102]. This powerful tool is used to predict the position of each atom in a molecular system in time domain based on Newton's laws of motion [103]. MD simulations have been widely used in SBDD processes because the technique can help to investigate dynamic atomic details such as binding, unbinding, and conformational changes of receptors which are not easily available from experimental studies [32], [104]. Furthermore, MD simulations can reveal receptor-ligand interaction dynamics such as association and dissociation, and quantify the thermodynamics, dynamics, and free energy landscape [105].

Chloroquine (CQ) has been a potential effective treatment for COVID-19 [106]. Hydroxychloroquine, a CQ derivative, has been reported as a better inhibitory effect than CQ against SARS-COV-2 [107]. Beura and Chetti have adopted a series of computational methods, including pharmacophore model, molecular docking, MM_GBSA (molecular mechanics with generalized Born and surface area) study, ADME (absorption, distribution, metabolism and excretion) property analysis and MD simulations to study the interactions of CQ and its derivatives with SARS-CoV-2 [67]. The structural properties of the compounds and the interactions between the ligand and receptor have been investigated by the pharmacophore model and molecular docking study. The MM_GBSA study and ADME property analysis have revealed the binding free energy of the protein–ligand complex and the pharmacological properties of the compounds. The optimal synthesized CQ derivative molecule CQD15 has been selected and further simulated by MD to obtain the root-mean-square deviation (RMSD), ligand properties, and protein–ligand contact. Their work offers a complete process of SBDD for SARS-CoV-2. The MD simulation plays a critical role in drug design which allows a more accurate estimate of the thermodynamics and kinetics associated with drug-target recognition and binding [32]. Compared with CQ and hydroxychloroquine, CQD15 shows a better inhibitory effect on SARS-COV-2. The anti-influenza drug, Arbidol, has been reported able to neutralize SARS-CoV-2 [36]. However, the detailed mechanism behind the inhibition remains unclear. Herein, Padhi et al. have presented the atomic insights into the SARS-CoV-2 membrane fusion inhibition mechanism. Analyses based on MD simulations show that Arbidol binds with high affinity and is stable at the RBD/hACE2 interface [36]. In addition, identifying key residues of RBD and hACE2 that interact with Arbidol by MD could open the door to therapeutic strategies and developments of higher efficacy Arbidol derivatives or primary drug candidates.

In drug development, the discovery of lead compounds and subsequent optimization of identified compounds into drug candidates should be followed by target identification or target validation. The goal is to discover and design compounds with good binding affinity and selectivity for the target. Docking and scoring are standard tools for rapidly estimating favorable ligand binding positions and energies. However, as it is mentioned above, the scoring functions of the current docking tools still have many limitations [108]. Using MD to address these limitations allows a more accurate and facilitative assessment of the binding affinity of selected compounds. In addition, MD could help to unravel the atomic details of protein-drug interaction and explain the molecular mechanism behind it.

## Section: DL-based MD simulation in SBDD for SARS-CoV-2

Predictions of protein–ligand binding has broad biological significance [102], [105]. However, performing such analyses to cover the entire chemical space of small molecules together with complex biological proteins requires tremendous computational power [109]. DL is now playing an increasingly pivotal role in SBDD as described above. In particular, the advances of the use of DL-based MD computational methods have enabled researchers to understand the binding mode, affinity and evolution of atomic system by using appropriate models and algorithms in which the selected model could “learn” the patterns inherent in the input data. Here, we have summarized some representative works in Table 1.Table 1Current literature on DL-based MD Simulation in SBDD for SARS-CoV-2.ReferenceMethodsObjectiveInputResults(Joshi et al., 2021)DL regression model, molecular docking and MD simulationTo identify potential drugs against SARS-CoV-2 3CLproCHEMBL3927 datasetTwo compounds have been identified to be potential hits against 3CLpro..(Arshia et al., 2021)DL LSTM generative network via transfer learning, fine-tuning over ten generations, molecular docking and MD simulationTo identify potential inhibitors against SARS-CoV-2 3CLproChEMBL and Moses datasets, SMILESFour top-ranked ligands have been found to be potential inhibitors against SARS-CoV-2 3CLpro.(Zhang et al., 2020)DFCNN and DeepBindBC DL models, molecular docking, pocket localized MD simulation, metadynamics and inhouse developed toolsTo identify potential drugs targeting SARS-CoV-2 RdRp from drugs available on the marketTargetMol-Approved_Drug_LibraryAn FDA-approved drug called Pralatrexate that strongly inhibits the replication of SARS-CoV-2 in vitro has been identified.(Casalina et al., 2021)DL variational autoencoder model and DeepDriveMD simulationTo investigate the mechanism of infectivity of SARS-CoV-2 S proteinConformational sampling across different systemsHave provided the elucidation of the full glycan shield of S, the role of S glycans in modulating the infectivity of the virus, and the characterization of the flexible interactions between the S and the hACE2.(Lee et al., 2019)DeepDriveMD simulationTo understand how coupling DL approaches to MD simulationVillin headpiece proteinHave achieved a performance gain in sampling the folded states by 2.3x and provided quantitative basis to understand how DL drives MD simulation.

Virus replication is controlled by the coronavirus 3CLpro which is therefore considered a major target and promising opportunity for antiviral discovery with direct acting agents [110]. Joshi et al. have screened 9101 drugs from the drug bank database for SARS-COV-2 3CLPro using DL, molecular docking, and MD simulation techniques [111]. Prior to MD simulations, 500 drugs have been screened by DL regression model and subjected to molecular docking, resulting in ten screened compounds with strong binding affinity. Afterwards, MD simulations have been conducted for five compounds in order to obtain their binding potentials. Two compounds, {4-[(2 s,4e)-2-(1,3-Benzothiazol-2-Yl)-2-(1 h-1,2,3-Benzotriazol-1-Yl)-5-Phenylpent-4-Enyl]Phenyl}(Difluoro)Methylphosphonic Acid and 1-(3-(2,4-dimethylthiazol-5-yl)-4-oxo-2,4-dihydroindeno[1,2-c]pyrazol-5-yl)-3-(4-methylpiperazin-1-yl)urea have been screened as potential hits. Their study suggests two potential drugs that can be tested under experimental conditions to assess efficacy against SARS-COV-2 (Fig. 5a). Arshia et al. have used 2.5 million compounds to train a long short-term memory (LSTM) generative network through transfer learning to identify-four optimal candidates that inhibit 3CLpro in SARS-COV-2 [112]. Fig. 5b shows the block diagram of the network’s training and generation phases, fine-tuning and evaluation sessions for design of potential inhibitors against SARS-COV-2 3CLpro. The datasets used to train the DNN models have been obtained from ChEMBL and ZINC. The SMILE format has collected 2.1 million compound structures from the ChEMBL dataset and 1.9 million molecular structures from Moses, a subset of the ZINC dataset. After removing the molecules containing undesirable atoms or groups, a total of 2.5 million SMILES have been used to train the neural network. The LSTM_Chem network has been used to generate drugs, with its weights trained on ChEMBL. Validity determines whether the generated SMILES are truly valid candidates for a molecule. Uniqueness ensures the uniqueness of the compound within the dataset. Originality guarantees that the generated SMILES are not in any datasets. Then, SMILES that satisfy all three criteria are chosen as eligible molecules. Followingly, molecular docking and MD simulation are conducted. The extensive calculations and statistical analyses of the study indicate that the chosen candidates can be used as potential inhibitors against SARS-COV-2 in computational environments. However, additional in vitro, in vivo, and clinical trials are needed to further prove their true efficacy. Zhang et al. have proposed a hybrid drug screening program based on DL and MD simulations which consists of a dense fully connected neural network (DFCNN) [113], DeepBindBC (https://cbblab.siat.ac.cn/DeepBindBC/index.php) [114], Autodock Vina [115], pocket local MD simulations and metadynamics simulations. DFCNN uses molecular vector data of protein pocket and ligand to estimate the protein–ligand pair as binding or non-binding with a probability value between 0 and 1. DeepBindBC estimates the binding possibility from atom contact information at interaction surface of a modelled 3D protein–ligand complex. DFCNN and DeepBindBC are both DL-based methods. This program could help explore the binding potentials of drugs in TargetMol-Approved_Drug_Library, a drug library containing 1906 of currently available drugs in market. After the predictions by DFCNN and DeepBindBC, 14 candidates have been selected. MD simulations on RNA-dependent RNA polymerase (RdRp)-drug complexes have been adopted to further screen the 14 selected drugs and understand the interactions and stabilities of the complexes. RdRp is believed to be one of the most promising therapeutic targets [116], [117]. Molecules that can bind to the catalytic site of RdRp could potentially interfere the synthesis of viral RNA [118]. Finally, 4 approved drug candidates targeting RdRp have been screened out, and 2 out of 4 (Pralatrexate and Azithromycin) can effectively inhibit SARS-CoV-2 replication in vitro with EC50 values (effective concentration or dose that produces 50 % of the maximum response) of 0.008 μM and 9.453 μM [119].Fig. 5(a) Graphic illustration of drug virtual screening for SARS-COV-2 3CLPro by DL, molecular docking and MD simulation techniques. In the initial stage, 500 drugs have been screened by a DL regression model and subjected to molecular docking, resulting in 10 screened compounds with strong binding affinity. Further, five compounds have been checked for their binding potentials by analyzing MD simulations for 100 ns. In the final stage, two compounds have been screened as potential hits [111]. Reproduced with permission. Copyright 2021, Springer Nature; (b) A block diagram of training and generation phases of the network, fine-tuning and evaluation sessions for design of potential inhibitors against SARS-COV-2 3CLpro. The datasets used to train the DNN models have been obtained from ChEMBL and Moses. The LSTM_Chem network has been used to generate drugs, with its weights trained on ChEMBL. The SMILES that satisfy-three criteria (validity, uniqueness and originality) are retained as eligible molecules. Followingly, molecular docking and MD simulation are conducted [112]. Reproduced with permission. Copyright 2021, Elsevier.

Although DL methods have demonstrated their potential to be efficient by learning from sufficient training data, there are still problems such as overfitting and discrepancies between training data and actual data. Casalino et al. have developed an AI-driven multiscale simulation framework to investigate SARS-CoV-2 S dynamics, revealing the full glycan shield of S protein and discovering that glycans play an active role in infection [120]. In their work, all-atomic MD simulations have been adopted to combine, augment, and extend the available experimental data set to study the structure, dynamics, and function of SARS-CoV-2 S protein. Traditional MD and weighted integrated enhanced sampling methods have been used. Then the simulations have been combined with a DL-based method as an integrated workflow that “drives” sampling from knowledge gained at one scale to another. Specifically, the DL-based method uses a variational autoencoder (VAE), which is developed based on convolution filters on contact graphs (from MD simulations) to analyze simulated data sets over long-time scales and organize them into a small number of conformational states along with biophysically related response coordinates. For SARS-CoV-2 S protein, the intrinsic size of the such simulation presents a significant challenge in scaling DL-based method to elucidate conformational states associated with functions. Therefore, Casalino et al. have further developed the DeepDriveMD [121], an approach that extends the AI-driven multiscale simulation framework to adaptively run MD simulations ensembles to fold small proteins. The DeepDriveMD has also been performed on a S-hACE2 system with 8.5 million atoms. Three conformations have been extracted from the first set of MD simulations and then been used as a starting point for a new round of MD simulations. Such a dl-driven adaptive MD approach has expanded the conformational space explored and described the flexibility of S in the context of hACE2 binding, revealing the effects of internal structure of S on RBD-hACE2 interaction and the infectious mechanism of SARS-CoV-2 S protein. Their work has successfully uncovered many aspects of peak dynamics and function that are currently unavailable from experiments. In addition, it has provided information on the basic mechanism of viral infection and advanced the technical and methodological limits of molecular simulations.

Simulations of biological macromolecules play an important role in understanding the physical basis of many complex processes [122]. However, the simulations of protein folding at the atomic scale remain challenging, even though computing power has improved and specialized architectures have evolved [123]. This is due to the high dimensional nature of protein conformational landscapes and the inability of atomic and MD simulations to adequately sample these landscapes for observation of the dual aspects of folding events [124]. DL-based MD simulation in SBDD can effectively fold small proteins on supercomputer [32]. Compared with traditional MD approaches, DL-based MD simulation in SBDD provides a quantitative basis with improved performance and reduced computing time, showing strong potentials in structural discovery and drug design in COVID-19 research.

Current literature on DL-based MD Simulation in SBDD for SARS-CoV-2.

(a) Graphic illustration of drug virtual screening for SARS-COV-2 3CLPro by DL, molecular docking and MD simulation techniques. In the initial stage, 500 drugs have been screened by a DL regression model and subjected to molecular docking, resulting in 10 screened compounds with strong binding affinity. Further, five compounds have been checked for their binding potentials by analyzing MD simulations for 100 ns. In the final stage, two compounds have been screened as potential hits [111]. Reproduced with permission. Copyright 2021, Springer Nature; (b) A block diagram of training and generation phases of the network, fine-tuning and evaluation sessions for design of potential inhibitors against SARS-COV-2 3CLpro. The datasets used to train the DNN models have been obtained from ChEMBL and Moses. The LSTM_Chem network has been used to generate drugs, with its weights trained on ChEMBL. The SMILES that satisfy-three criteria (validity, uniqueness and originality) are retained as eligible molecules. Followingly, molecular docking and MD simulation are conducted [112]. Reproduced with permission. Copyright 2021, Elsevier.

## Section: Perspective and future direction › Strengths and challenges

Recognizing the steadily increasing number of positive cases of infection and the lack of approved treatments for SARS-CoV-2, SBDD has emerged as a rapid and reliable technique in pharmaceutical and medical research because it not only saves time, but also helps reduce the cost of designing therapeutic agents [9], [125]. In particular, the DL applications in SBDD can facilitate the discovery of new drugs and reuse of FDA-approved drugs whose safety and side effects have already been known [126]. Due to inherent mutations in the SARS-CoV-2 genome that may hinder disease treatment, applications of DL in SBDD also play a key role in accelerating the process of drug discovery and development against new SARS-CoV-2 variants. MD simulations have been widely used in SBDD because the technique helps to unravel many SARS-CoV-2 atomic details, such as binding, unbinding and conformational changes, at a high resolution that is not normally available from experimental studies [127]. In addition, MD simulations can be used to explore the dynamics of SARS-CoV-2 receptor-ligand interactions and quantify the thermodynamic, kinetic and free energy landscape [128]. In particular, the DL-based MD simulations could undoubtedly inherit the advantages of both DL and MD which could reveal the dynamic evolution of large, complex biological system with selected drugs.

However, the SBDD method used at the current stage still has some limitations. For example, the current drug design method is mainly based on the structures of drug and target biological macromolecules [129]. As mentioned above, many protein structures in the PDB are not actually the folded states of proteins. Some protein structures may only fold upon binding to other proteins, substrates or metal ions, some may only fold when they are chemically modified, and some may fold directly into large complexes such as the ribosome. Moreover, SBDD only considers the interaction between the compound and the target biomolecule but does not consider other interaction modes between the two [129]. Although SBDD is a powerful tool that can provide an intuitive model for scientists to design drugs [11], the results still need to be verified by experiments at the present stage [130].

## Section: Perspective and future direction › Future outlook and concluding thoughts

Research on the pathogenesis of COVID-19 is still ongoing, and the existence of bias, imbalance, and limited data may have a significant impact on the prediction accuracy of DL methods in SBDD [131]. In addition, the increase in COVID-19 positive cases and the lack of approved drugs remain global health issues that require urgent discovery of drugs to prevent and treat the disease [132]. DL prediction has accelerated the virtual identification of structure-based drug target inhibitors for SARS-CoV-2 [133]. The application of DL-based MD simulations in SBDD for SARS-CoV-2 has accelerated the development of new drugs. But the current DL and MD computational methods remain to be further developed. There are two approaches regarding the future developments of these computational methods in SBDD. The first is to continue optimizing the parameters under the existing framework of molecular mechanics, incorporating DL to expand the scope of application, and further introducing the polarization effect of molecular interactions. The second is to introduce a new paradigm, which requires the development of both computational methods and the theory. In this review, we hope to provide the scientific community with a comprehensive review of major new applications of DL methods and DL-based MD simulations in SBDD procedures, as well as their applications in the research of SARS-CoV-2. However, we only focus on protein–ligand problems in SBDD but do not include the protein–protein interactions, which might be the future direction for better designing drugs against SARS-CoV-2.

## Section: CRediT authorship contribution statement

Yao Sun: Conceptualization, Writing – original draft, Writing – review & editing. Yanqi Jiao: Writing – original draft. Chengcheng Shi: Writing – review & editing. Yang Zhang: Writing – review & editing.

## Section: Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.


---

# Deep learning in drug discovery: an integrative review and future challenges

- **Authors:** Heba Askr, Enas Elgeldawi, Heba Aboul Ella, Yaseen A M M Elshaier, Mamdouh M Gomaa, Aboul Ella Hassanien
- **Issuer:** Artificial intelligence review
- **Type:** Scientific article
- **Published:** 2022-11-17
- **Language:** en
- **DOI:** 10.1007/s10462-022-10306-1
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36415536/
- **Licence:** CC-BY

## Page 1 (Section: Deep learning in drug discovery: an integrative review and future challenges)

Vol.:(0123456789)
Artificial Intelligence Review (2023) 56:5975–6037
https://doi.org/10.1007/s10462-022-10306-1
1 3
Deep learning in drug discovery: an integrative review 
and future challenges
Heba Askr1 · Enas Elgeldawi2 · Heba Aboul Ella4 · Yaseen A. M. M. Elshaier5 · 
Mamdouh M. Gomaa2 · Aboul Ella Hassanien3
Accepted: 24 October 2022 / Published online: 17 November 2022 
© The Author(s) 2022
Abstract
Recently, using artificial intelligence (AI) in drug discovery has received much attention 
since it significantly shortens the time and cost of developing new drugs. Deep learning 
(DL)-based approaches are increasingly being used in all stages of drug development as 
DL technology advances, and drug-related data grows. Therefore, this paper presents a sys-
tematic Literature review (SLR) that integrates the recent DL technologies and applications 
in drug discovery Including, drug–target interactions (DTIs), drug–drug similarity inter-
actions (DDIs), drug sensitivity and responsiveness, and drug-side effect predictions. We 
present a review of more than 300 articles between 2000 and 2022. The benchmark data 
sets, the databases, and the evaluation measures are also presented. In addition, this paper 
provides an overview of how explainable AI (XAI) supports drug discovery problems. The 
drug dosing optimization and success stories are discussed as well. Finally, digital twining 
(DT) and open issues are suggested as future research challenges for drug discovery prob-
lems. Challenges to be addressed, future research directions are identified, and an extensive 
bibliography is also included.
Keywords  Drug discovery · Artificial intelligence · Deep learning · Drug–target 
interactions · Drug–drug similarity · Drug side-effects · Drug sensitivity and response · 
Drug dosing optimization · Explainable artificial intelligence · Digital twining
1  Introduction
The examination of how various drugs interact with the body and how a medication needs 
to act on the body to have a therapeutic impact is known as drug discovery. Drug discovery 
strategy constitutes from different approaches as physiology-based and target based. This 
strategy is based on information about the ligand and the target. In this regard, our attention 
was directed in certain topics especially drug (ligand)–target interactions, drug sensitivity 
and response, drug–drug interaction, and drug–drug similarity. For certain diseases such as 
cancer or pandemic situations as COVID-19, more than one drug combination is required 
 *	 Aboul Ella Hassanien 
	
aboitcairo@cu.edu.eg
Extended author information available on the last page of the article

## Page 2 (Section: Deep learning in drug discovery: an integrative review and future challenges)

5976
	
H. Askr et al.
1 3
to alleviate the prognosis and pathogenesis interactions. Despite all the recent advances in 
pharmaceuticals, medication development is still a labor-intensive and costly process. As a 
result, several computational algorithms are proposed to speed up the drug discovery pro-
cess (Betsabeh and Mansoor 2021).
As DL models progress and the drug data size is getting bigger, a slew of new DL-
based approaches is cropping up at every stage of the drug development process (Kim et al. 
2021). In addition, we’ve seen large pharmaceutical corporations migrate toward AI in the 
wake of the development of DL approaches, eschewing outmoded, ineffective procedures 
to increase patient profit while also increasing their own (Nag et al. 2022). Despite the DL 
impressive performance, it remains a critical and challenging task, and there is a chance for 
researchers to develop several algorithms that improve drug discovery performance. There-
fore, this paper presents a SLR that integrates the recent DL technologies and applications 
in drug discovery. This review study is the first one that incorporates the recent DL mod-
els and applications for the different categories of drug discovery problems such as DTIs, 
DDIs similarity, drug sensitivity and response, and drug-side effects predictions, as well 
as presenting new challenging topics such as XAI and DT and how they help the advance-
ment of the drug discovery problems. In addition, the paper supports the researchers with 
the most frequently used datasets in the field.
The paper is developed based on six building blocks as shown in Fig. 1. More than 300 
articles are presented in this paper, and they are divided across these building blocks. The 
papers are selected using the following criteria:
•	 The papers which published from 2000 to 2022.
•	 The papers which published in IEEE, ACM, Elsevier, and Springer have more priority.
Fig. 1   The main building blocks 
of the paper

## Page 3 (Section: 2 Review of related studies)

5977
Deep learning in drug discovery: an integrative review and future…
1 3
The following analytical questions are discussed and completely being answered in the 
paper:
–	 AQ1: What DL algorithms have been used to predict the different categories of drug 
discovery problems?
–	 AQ2: Which deep learning methods are mostly used in drug dosing optimization?
–	 AQ3: Are there any success stories about drug discovery and DL?
–	 AQ4: What about the newest technologies such as XAI and DT in drug discovery?
–	 AQ5: What are the future and open works related to drug discovery and DL?
The remainder of this review paper is organized as: Sect. 2 presents a review of related 
studies; Sect. 3 covers the various DL techniques as an overview. Section 4 presents the 
organization of DL applications in drug discovery problems through explaining each drug 
discovery problem category and gives a literature review of the DL techniques used. Sec-
tion 5 discusses the numerous benchmark data sets and databases that have been employed 
in the drug development process. Section 6 presents the evaluation metrics used for each 
drug discovery problem category. The drug dose optimization, successful stories, and XAI 
are introduced in Sect. 7, Sect. 8, and Sect. 9. DT and open problems are suggested as 
future research challenges in Sects. 10 and 11. Section 12 presents a discussion of the ana-
lytical questions. Finally, Sect. 13 concludes the paper.
2  Review of related studies
Although the drug discovery is a large field and has different research categories, there 
is a few review studies about this field and each related study has focused only on a one 
research category such as reviewing the DL applications for the DTIs. This section aims to 
review these related studies and a summary is presented in Table 1.
Kim et  al. (2021) presented a survey of DL models in the prediction of drug–target 
interaction (DTI) and new medication development. They start by providing a thorough 
summary of many depictions of drugs and proteins, DL applications, and widely used 
exemplary data sets to test and train models. One good point for this study, they identify a 
few obstacles to the bright future of de novo drug creation and DL-based DTI prediction. 
However, the major drawback of this study was that it did not consider the latest technol-
ogy in DL application for the DTIs such as XAI and DTs.
Rifaioglu et al. (2019) presented the recent ML applications in Virtual Screening (VS) 
with the techniques, instruments, databases, and materials utilized to create the model. 
They outline what VS is and how crucial it is to the process of finding new drugs. Good 
points for this study, they highlighted the DL technologies that are accessible as open 
access programming libraries and provided instances of VS investigations that resulted in 
the discovery of novel bioactive chemicals and medications, tool kits and frameworks, and 
can be employed for the foreseeable future’s computational drug discovery (including DTI 
prediction). However, they did not consider the drug dose optimization in their literature 
review.
Sachdev and Gupta (2019) presented the various feature based chemogenomic methods 
for DTIs prediction. They offer a thorough review of the different methodologies, datasets, 
tools, and measurements. They give a current overview of the various feature-based meth-
odologies. Additionally, it describes relevant datasets, methods for determining medication

## Page 4 (Section: 3 Deep learning (DL) techniques)

5978
	
H. Askr et al.
1 3
or target properties, and evaluation measures. Although the study considered the initial 
integrated review which concentrate only on DTI feature-based techniques, they did not 
consider the latest technology in DL application for the DTIs such as XAI and DTs.
3  Deep learning (DL) techniques
Detecting spam, recommending videos, classifying images, and retrieving multimedia 
ideas are just a few of the techniques used are just a few of the applications where machine 
learning (ML) has lately gained favor in research. Deep learning (DL) is one of the most 
extensively utilized ML methods in these applications. The ongoing appearance of new 
DL studies is due to the unpredictability of data acquisition and the incredible progress 
made in hardware technologies. DL is based on conventional neural networks but outper-
forms them significantly. Furthermore, DL uses transformations and graph technology to 
build multi-layer learning models (Kim et al. 2021). With their groundbreaking invention, 
Machine Learning and Deep Learning have revolutionized the world’s perspective. Deep 
learning approaches have revolutionized the way we tackle problems. Deep learning mod-
els come in various shapes and sizes, capable of effectively resolving problems that are too 
complex for standard approaches to tackle. We’ll review the various deep learning models 
in this section (Sarker 2021).
3.1  Classic neural networks
As shown in Fig.  2, Multi-layer perceptron are frequently employed to recognize Fully 
Connected Neural Networks. It involves converting the algorithm into simple two-digit 
data inputs (Mukhamediev et al. 2021). This paradigm allows for both linear and nonlin-
ear functions to be included. The linear function is a single line with a constant multiplier 
that multiplies its inputs. Sigmoid Curve, Hyperbolic Tangent, and Rectified Linear Unit 
are three representations for nonlinear functions. This model is best for categorization and 
regression issues with real-valued data and a flexible model of any kind.
3.2  Convolutional neural networks (CNN)
As shown in Fig. 3, The classic convolutional neural network (CNN) model is an advanced 
and high-potential variant ANN Which developed to manage escalating complexity levels, 
as well as data pretreatment and compilation. It is based on how an animal’s visual cortex’s 
neurons are arranged (Amashita et al. 2018). One of the most flexible algorithms for the 
Table 1   Related studies included DL for drug discovery
Reference
Main context
Year
Category
Kim et al. (2021)
Survey of DL models in drug–target interaction (DTI) and 
new medication development
2021
DTI
Rifaioglu et al. 
(2019)
A discussion about the most recent uses of ML techniques in 
VS (DTI application), including DL
2019
DTI
Sachdev et al. 
(2019)
Survey of the feature based chemogenomic methods for DTIs 
prediction
2019
DTI

## Page 5 (Section: 3.3 Recurrent neural networks (RNNs))

5979
Deep learning in drug discovery: an integrative review and future…
1 3
processing of data with and without images is CNNs. CNN can be processed through 4 
phases:
–	 For analyzing basic visual data, such as picture pixels, it includes one input layer that is 
often the case a 2D array of neurons.
–	 Some CNNs analyze images on their inputs using a single-dimensional output layer of 
neurons coupled to distributed convolutional layers.
–	 Layer number 3, called as the sampling layer, is included in CNNs o restrict the number 
of neurons which It took part in the relevant network levels.
–	 The sampling and output layers are joined by one or more connected layers in CNNs.
This network concept can potentially aid in extracting relevant visual data in pieces or 
smaller units. In the CNN, the neurons are responsible for the group of neurons from the 
preceding layer.
After the input data has been included into the convolutional model, the CNN is con-
structed in four steps:
–	 Convolution: The method produces feature maps based on supplied data., which are 
then subjected to a purpose.
–	 Max-Pooling: It aids CNN in detecting an image based on supplied changes.
–	 Flattening: The data is flattened in this stage so that a CNN can analyze it.
–	 Full Connection: It’s sometimes referred to as a "hidden layer" which creates the loss 
function for a model.
Image recognition, image analysis, image segmentation, video analysis, and natural lan-
guage processing (NLP) (Chauhan et al. 2018; Tajbakhsh et al. May 2016; Mohamed et al. 
2020; Zhang et al. 2018) are among the tasks that CNNs are capable of.
3.3  Recurrent neural networks (RNNs)
RNNs were first created to help in sequence prediction. These networks rely solely on data 
streams with different lengths as inputs. For the most recent forecast, the knowledge of its 
previous state is used as an input value by the RNN. As a result, it can help a network’s 
short-term memory achievers (Tehseen et al. 2019). As shown in Fig. 4, The Long Short-
Term Memory (LSTM) method, for example, is renowned for its adaptability.
Fig. 2   Multilayer Perceptron or ANN

## Page 6 (Section: 3.4 Generative adversarial networks: GAN)

5980
	
H. Askr et al.
1 3
LSTMs, which are advantageous in predicting data in time sequences using memory, 
and LSTMs, which are useful in predicting data in time sequences using memory, are two 
forms of RNN designs that aid in the study of problems. The three gates are Input, Output, 
and Forget. Gated RNNs are particularly helpful for temporal sequence prediction using 
memory-based data. Both types of algorithms can be used to address a range of issues, 
including image classification (Chandra and Sharma 2017), sentiment analysis (Failed 
2018), video classification (Abramovich et al. 2018), language translation (Hermanto et al. 
2015), and more.
3.4  Generative adversarial networks: GAN
As shown in Fig.  5, It combines a Generator and a Discriminator DL neural network 
approach. The Discriminator helps to discriminate between real and fake data while the 
Generator Network creates bogus data (Alankrita et al. 2021).
Both networks compete with one another as The Discriminator still distinguishes 
between actual and fake data, and the Generator keeps making fake data look like real 
data. The Generator network will generate simulated data for the authentic photos if a pic-
ture library is necessary. Then, a deconvolution neural network would be created. Then, 
an Image Detector network would be utilized to discriminate between fictitious and real 
images. This competition would eventually help the network’s performance. It can be 
employed in creating images and texts, enhancing the image and discovering new drugs.
3.5  Self‑organizing maps (SOM)
As shown in Fig.  6, Self-Organizing Maps operate by leveraging unsupervised data to 
decrease a model’s number of random variables (Kohonen 1990). Given that every synapse 
is linked to both its input and output nodes, the output dimension in this DL approach is 
set as a two-dimensional model. The competition between each data point and its model 
representation in the Self-Organizing Maps, the weight of the closest nodes or Best Match-
ing Units is adjusted (BMUs). The value of the weights varies based on how close a BMU 
is. The value represents the node’s position in the network because weights are a node 
attribute in and of themselves. It’s great for evaluating dataset frameworks that don’t have a 
Y-axis value or project explorations that don’t have a Y-axis value.
3.6  Boltzmann machines
As shown in Fig. 7, the nodes are connected in a circular pattern because there is no set ori-
entation in this network model. This deep learning technique is utilized to generate model 
Fig. 3   Convolutional Neural Networks (CNN)

## Page 7 (Section: 3.4 Generative adversarial networks: GAN)

5981
Deep learning in drug discovery: an integrative review and future…
1 3
parameters because of its uniqueness. The Boltzmann Machines model is stochastic, unlike 
all preceding deterministic network models. It can monitor systems, create a binary recom-
mendation platform, and analyze specific datasets (Hinton 2011).
The architecture of the Boltzmann Machine is a two-layer neural network. The visible 
or input layer is the first, while the hidden layer is the second. They are made up of several 
neuron-like nodes that carry out computations. These nodes are interconnected at different 
levels but are not linked across nodes in the same layer. As a result, there is no connectivity 
between layers, which is one of the Boltzmann machine’s disadvantages. When data is sup-
plied into these nodes, it is transformed into a graph, and they process it and learn all the 
parameters, motifs, and relations between them before deciding whether to transmit it. As a 
result, an Unsupervised DL model is often known as a Boltzmann Machine.
Fig. 4   LSTM Network
Fig. 5   GAN: Generative Adversarial Networks

## Page 8 (Section: 3.7 Autoencoders)

5982
	
H. Askr et al.
1 3
3.7  Autoencoders
As shown in Fig. 8, This algorithm, one of the most popular deep learning algorithms, 
automatically based on its inputs, applies an activation function, and decodes the result 
at the end. Because of the backlog, there are fewer types of data produced, and the built-
in data structures are used to their fullest extent (Zhai et al. 2018).
There are various types of autoencoders:
–	 Sparse: The generalization technique is used when the hidden layers outnumber the 
input layer to decrease the overfitting. It constrains the loss function and restricts the 
autoencoder from utilizing all its nodes simultaneously.
–	 Denoising: In this case, randomly, the inputs are adjusted and made to equal 0.
–	 Contractive: When the hidden layer outnumbers the input layer, to avoid overfitting and 
data duplication, a penalty factor is introduced to the loss function.
–	 Stacked: When another hidden layer is added to an autoencoder, it results in two stages 
of encoding and Initial stages of decoding.
Feature identification, establishing a strong recommendation model, and adding features 
to enormous datasets are some of the difficulties it can solve.
4  Organization of DL applications in drug discovery problems
The evolution of safe and effective treatments for human is the primary goal of drug dis-
covery (Kim et al. 2021). Drug discovery is the problem of finding the suitable drugs to 
treat a disease (i.e., a target protein) which relies on several interactions. This paper divides 
the drug discovery problems into four main categories, as presented in Fig. 9. They are 
drug–target interactions, drug–drug similarity, drug combinations side effects, and drug 
sensitivity and response predictions. The following subsections provide a literature review 
of DL with these problems and some of the investigated literature articles related to each 
category are summarized in Table 2.
Fig. 6   Self-Organizing Maps (SOM)

## Page 9 (Section: 4.1 Drug–target interactions prediction using DL)

5983
Deep learning in drug discovery: an integrative review and future…
1 3
4.1  Drug–target interactions prediction using DL
Drug repurposing attempts to uncover new uses for drugs that are already on the market 
and have been approved. It has attracted much attention since it takes less time, costs less 
money, and has a greater success rate than traditional de novo drug development (Thafar 
et al. 2022). The discovery of drug–target interactions is the initial step in creating new 
medications, as well as one of the most crucial aspects of drug screening and drug-guided 
synthesis (Wang et al. 2020a). Exploring the link between possible medications and targets 
can aid researchers in better understanding the pathophysiology of targets at the drug level, 
which can help with the disease’s early detection, treatment prognosis, and drug design. 
This is well known as drug–target interactions (DTIs) (Lian et al. 2021). Achieving success 
to the drug repositioning mechanism largely reliant on DTI’s forecast because it reduces 
the number of potential medication candidates for specific targets. The approaches based 
on molecular docking and the approaches based on drugs are the two basic tactics used in 
traditional computational methods. When target proteins’ 3D structures aren’t available, the 
effectiveness of molecular docking is limited. When there are only a few known binding 
molecules for a target, drug-based techniques typically produce subpar prediction results. 
Fig. 7   Boltzmann Machines
Fig. 8   Autoencoders

## Page 10 (Section: 4.1.1 Drug-based models)

5984
	
H. Askr et al.
1 3
DL technologies overcome the restrictions of the high-dimensional structure of drug and 
target protein by using unstructured-based approaches which do not need 3D structural 
data or docking for DTI prediction. Therefore, this section provides a recent comprehen-
sive review of DL-based DTIs prediction models (Chen et al. 2012).
As shown in Fig. 10, there are known interactions (solid lines) and unknown interac-
tions (dashed lines) between diseases (proteins) and drugs. DTIs forecast unknown interac-
tions or what diseases (or target proteins) a new drug might treat. According to their input 
features, we divided the latest DL models used to predict DTIs into three categories: drug-
based models, structure (graph)-based models, and drug-protein(disease)-based models.
4.1.1  Drug‑based models
Figure 10A shows drug-based models that assume a potential drug will be like known 
drugs for the target proteins. It calculates the DTI using the target’s medication informa-
tion. Similarity search strategies are used in these models, which postulate that structur-
ally similar substances have similar biological functions (Thafar et al. 2019; Matsuzaka 
and Uesawa 2019). These methods have been used for decades to select compounds 
in vast compound libraries employing massive computer jobs or solve problems using 
human calculations. Deep neural network models gradually narrow the gap between in 
silico prediction and empirical study, and DL technology can shorten these time-con-
suming procedures and manual operations.
Drug Discovery
Drug-target interactions
Drug-based models
Drug-protein (disease)-
based models 
Graph-based models 
Drug sensitivity and 
response
Drug-combinations side 
effects
Drug-Drug similarity
The similarity in chemical 
structure
Target protein sequence-
based similarity
Target Protein funconal 
similarity
Drug-induced pathway
similarity
Fig. 9   Drug discovery problem categories

## Page 11 (Section: 4.1.1 Drug-based models)

5985
Deep learning in drug discovery: an integrative review and future…
1 3
Table 2   Classification of articles related to drug discovery and DL
References
Publishing year
Method
Advantages
Drawbacks
Drug–target interactions (DTIs)
 Yang et al. (2019)
2019
A graph convolutional model that con-
sistently equals or outperforms models 
with constant molecular descriptors 
and earlier graph neural designs on 
both open-source and closed-source 
data sets
The model performs equally well or bet-
ter on 12 of the 19 open data sets
The proposed model is underperforming 
other models when either (1) the 3D 
information from the other models, (2) 
the data set is especially small, or (3) the 
classes are particularly imbalanced
 Hirohara et al. (2018)
2020
A brand-new CNN for assessing data 
about chemical compounds. The CNN 
processes picture data similarly to tra-
ditional CNNs using a SMILES-based 
feature matrix
The standard fingerprint method used for 
the virtual screening of chemical com-
pounds performed worse than the CNN 
based on SMILES string. Additionally, 
the use of motif detection with learnt 
filters allowed the detection of undis-
covered functional group substructures 
in addition to significant recognised 
substructures like protein-binding sites
The model performed better than DNN 
using simply ECFP in the TOX 21 Chal-
lenge 2014 experiment, but somewhat 
worse than models utilising both ECFP 
and DeepTox features
 Shin et al. (2019)
2019
A novel representation of a molecule 
employing the self-attention method 
that has been pre-trained using massive 
data on chemicals that is available to 
the public
Regarding four evaluation metrics, the 
model performs better than all other 
techniques now in use. Furthermore, 
the strategy is successful in including 
all the existing EGFR medications 
in the top-30 promising prospects, as 
demonstrated by the example study of 
discovering drug candidates targeting a 
cancer protein (EGFR)
The protein was ignored by the model. One 
explanation is because, on average, a 
protein sequence is 10 times longer than 
a molecule sequence, which requires a 
significant amount of computation time. 
Another justification is the requirement 
of a protein dataset with adequate data to 
pre-train the model
 Lee et al. (2019)
2019
A new DTI prediction model by iden-
tifying regional residue trends from 
the complete sequences of the target 
protein via CNN
Other protein descriptors, such as CTD 
and SW scores, do not perform as 
well as the local properties of protein 
sequences that have been found. 
Compared to techniques requiring 
3D structures, it can be more broadly 
utilized to predict DTIs
To attain enhanced performance, more 
detailed chemical characteristics are used 
for DTI forecasting. Chemical elabora-
tion can be replaced by the consideration 
of 3D structure information

## Page 12 (Section: 4.1.1 Drug-based models)

5986
	
H. Askr et al.
1 3
Table 2   (continued)
References
Publishing year
Method
Advantages
Drawbacks
 Wang et al. (2020b)
2020
A novel method MDADTI to predict 
DTIs based on MDA
MDA lowered the size of the charac-
teristic of medications and objec-
tives, which accelerate the training of 
MDADTI
Did not consider predicting the binding 
affinity scores for drug–target pairs
 Wan et al. (2019)
2019
DeepCPI is a new and scalable approach 
that predicts innovative CPIs by 
combining data-driven representation 
learning and DL (DTIs)
To effectively utilize the enormous 
amount of data on the interactions 
between compounds and proteins 
accessible from expansive databases, 
including PubChem and ChEMBL, the 
synthesis of the efficient feature embed-
ding methodologies with the potent DL 
model is especially helpful
Better prediction results may be reached by 
combining other accessible data, like as 
gene expression and protein structures, 
into the suggested DL model
 Vazquez et al. (2020)
2020
Model for defining hybrid LB (ligand-
based) + SB (structure-based) 
computational schemes in VS (Virtual 
screening) studies
VS has been a powerful alternative to 
high-throughput screening assays. 
The performance of VS campaigns is 
significantly impacted by the inherent 
weaknesses of both LB and SB proce-
dures while being the most popular way 
for exposing innovative hit compounds 
in the early phases of drug discovery
Although the progress is encouraging, it 
can be assumed that two primary ele-
ments will determine if these integrated 
tactics are adopted. Initially, a thorough 
benchmarking of the various combina-
tion tactics Secondly, convenient access 
to screening of focused chemical library 
searches should be made possible by 
the capacity to integrate the combined 
LB and SB techniques into automated 
modelling platforms
 Xie et al. (2018)
2018
A framework that offers better prospects 
for inferencing and for DTI prediction 
based on L1000 database transcriptome 
data from pharmacological perturba-
tion and gene knockdown experiments
The outcomes showed that our system 
can find DTIs that are more trustwor-
thy than those discovered by previous 
techniques
investigating a possibility to discover an 
internal characteristic for assessing fresh 
DTI potential

## Page 13 (Section: 4.1.1 Drug-based models)

5987
Deep learning in drug discovery: an integrative review and future…
1 3
Table 2   (continued)
References
Publishing year
Method
Advantages
Drawbacks
Drug sensitivity and response
 Dincer et al. (2018)
2018
A low-dimensional representation (LDR) 
is encoded using the DeepProfile 
framework, which learns a variational 
autoencoder (VAE) network using 
tens of thousands of publicly available 
gene expression samples. This network 
is then used to predict complicated 
disease symptoms
DeepProfile successfully disentangles 
data inconsistencies and discovers a 
useful LDR that precisely foretells 
complicated phenotypes of many 
malignancies
The work needs some future directions 
which include: (1) training DeepProfile 
using samples from various cancers and 
(2) expanding the application of Deep-
Profile by utilizing multi-omics data to 
produce more insightful embeddings for 
cancer
 Rampášek et al. (2019)
2019
‘Dr.VAE’, the first unified machine learn-
ing method for the semi-supervised 
learning for drug response prediction 
that successfully exploits the prior 
knowledge of drug-induced transcrip-
tomic perturbations
First, the flexibility of This paradigm 
made it possible to incorporate the 
effects of transcriptional disruption into 
the framework for predicting medica-
tion reaction in a special way Second, 
neural networks with the ability to 
simulate complex non-linear interac-
tions are employed to parametrize all 
conditional distributions that make up 
their model, in addition to variational 
posteriors employed by Dr. VAE to 
make a rough inference
The study could be limited in numerous 
ways. As it has repeatedly been demon-
strated to offer the greatest predictive 
potential in several prior research on 
treatment response, they first just took 
the gene expression modality into con-
sideration. Second, they modeled CMap-
L1000v1 perturbations following a 6-h 
treatment period. Since many feedback 
regulatory processes take 6 h to appear, 
it may be argued that these studies alone 
do not give a complete picture of the 
transcriptome response

## Page 14 (Section: 4.1.1 Drug-based models)

5988
	
H. Askr et al.
1 3
Table 2   (continued)
References
Publishing year
Method
Advantages
Drawbacks
 Ahmed et al. (2020)
2020
Two neural network models based on 
graphs for predicting drug sensitivity as 
well as a network-based feature selec-
tion approach
To predict drug sensitivity, using a 
network to pick features. first identifies 
additional illustrative characteristics 
based on the network of gene co-
expression. Second, Random Forest 
performs better than all the other estab-
lished prediction techniques., Third, 
compared to DNN, the graph-based 
neural network models exhibit higher 
drug response prediction capability., 
Fourth, the performance of the predic-
tion is reliant on the drug and could 
be related to the drug’s mode of action 
(MOA)
In this study, there was little improvement 
for DNNs using graphs. Multi-omics 
data can be used for analysis to further 
improve drug prediction accuracy. In 
addition to the extensive biological fea-
tures, data acquisition using multi-omics 
the genomic, epigenomic, and tran-
scriptomic traits of each cell line in the 
cohort and offer more precise molecular 
fingerprints to forecast medication reac-
tion than single-omics data alone
 Ren et al. (2022)
2022
DeepGRMF, which demonstrated 
enhanced capability for predicting drug 
sensitivities
model can predict new responses to 
drugs or medications not previously 
seen, which It makes it possible to use 
already FDA approved medications 
in new ways to both cure cancer and 
maybe find new molecules that fight 
cancer
the DeepGRMF model only uses data from 
gene expression profiling, incorporating 
genetic changes further and epigenetic 
data will probably help the model per-
form even better
Drug–drug interactions (DDIs) side effect
 Jae et al. (2018)
2018
DeepDDI that accurately forecasts DDI 
types for medication combinations as 
well as drug-food component pairings 
using as inputs names and chemical 
structures
According to the seven common 
performance criteria, DeepDDI’s 
feature vector of pharmaceuticals, 
which combines an improved DNN 
and SSP, demonstrated great accuracy 
(84.8–93.2%)
Only two medications are included in the 
best DDI database provided by Drug-
Bank. The DNN can be updated by train-
ing DeepDDI for numerous medications 
and food ingredients once DDI data for 
multiple drugs and/or food ingredients 
becoming accessible

## Page 15 (Section: 4.1.1 Drug-based models)

5989
Deep learning in drug discovery: an integrative review and future…
1 3
Table 2   (continued)
References
Publishing year
Method
Advantages
Drawbacks
 Xiang et al. (2020)
2020
An overview of various graph embedding 
approaches is provided, along with an 
assessment of how well they perform 
on link prediction and node categoriza-
tion, two significant biological tasks
Through comprehensive testing, they 
discover that current graph embedding 
techniques can compete favorably with 
state-of-the-art techniques or even out-
perform them in a variety of biological 
prediction tasks
The idea of pre-training followed by fine-
tuning becomes increasingly intriguing 
as there are more entities that may have 
pre-trained embeddings as biomedical 
data volume increases. The relationships 
between the freshly created network 
propagation (diffusion) methods and the 
graph embedding techniques may also 
have an impact on future research
 Xifan et al. (2020)
2020
A multimodal deep learning system 
called DDIMDL uses deep learning 
and a variety of pharmacological char-
acteristics to forecast DDI events
The experimental findings demonstrate 
that DDIMDL performs better than 
the approaches that were examined in 
terms of efficiency and accuracy
to enhance the forecast of DDI events. 
First, there needs to be consideration of 
unique strategies for dealing with the 
unbalanced dataset due to the extreme 
imbalance in the amount of DDIs for 
various occurrences. Second, certain 
events have insufficient numbers of 
interactions, making it easier for the DL 
approach to underfit, hence techniques to 
increase the size of the event dataset can 
be investigated
 Karim et al. (2019)
2019
A new ML approach for forecasting 
DDIs using a variety of sources
The incorporation of drug data from 
many sources using knowledge graphs. 
This candidate will get comprehensive 
background information on medica-
tions, illnesses, processes, proteins, 
enzymes, chemical structures, etc
The approach’s inability to offer reasons 
for the projected DDIs is one of its 
limitations

## Page 16 (Section: 4.1.1 Drug-based models)

5990
	
H. Askr et al.
1 3
Table 2   (continued)
References
Publishing year
Method
Advantages
Drawbacks
 Bongini et al. (2022)
2022
Graph Neural Networks (GNNs) are 
exploited to predict DSEs
A GNN-based predictor aids in foresee-
ing the incidence of adverse effects. 
Additionally, its use with novel can-
didate medications would assist drug 
discovery studies save time and money 
while avoiding health problems for the 
volunteers taking part in clinical trials
An exciting future path is the creation 
of a prediction based on a GNN that It 
has the capacity to analyze molecular 
structural formulae, which are displayed 
as graphs. Features could be added to 
these molecular graphs to improve them 
by way of genes and links between genes 
and drugs
 Iorio et al. (2010)
2010
A broad method to identify previ-
ously unknown uses for well-known 
medications as well as to forecast the 
molecular actions and MOA of new 
compounds
Using information buried in the gene 
expression profiles after drug treatment 
to identify pharmacological MoA 
similarities
The approach’s primary drawback is the 
network’s small number of chemicals. If 
a chemical is not like any of the medica-
tions in the network, no inferences about 
its MoA or its biological effects can be 
made because the approach is predicated 
on comparing how similar two drugs are
 Wang et al. (2019)
2019
An approach using networks to find 
clinically effective drug combinations 
for disorders
Provides a network-level analysis of the 
comparative efficacy and harmful inter-
actions of treatment combinations
The applicability of their findings to dif-
ferent disorders must be investigated in 
further research
 Heba et al. (2021)
2021
The ML-based on similarity for drug 
interaction prediction (SMDIP) 
framework, which incorporates popular 
ML models utilizing internal similarity 
models based on products to choose the 
characteristics and benefit from more 
sparse feature space to enhance DDI 
prediction efficiency
creating a generalizable machine learn-
ing framework based on similarities 
to reveal innovative DDIs having 
excellent forecasting abilities; and 
(2) Showcasing superior predictor 
elements in comparison to the body of 
existing research
SMDIP exhibits some restrictions. SMDIP 
is first and foremost a binary classifier 
framework with DDI results. It cannot, 
however, predict how serious a DDI will 
be. Second, SMDIP cannot make recom-
mendations for the best course of action 
to be done for the management of DDI 
since it cannot forecast the unfavorable 
effects brought on by the interaction

## Page 17 (Section: 4.1.1 Drug-based models)

5991
Deep learning in drug discovery: an integrative review and future…
1 3
Researchers may now use deep neural networks to analyze medicines and predict 
drug-related features, including as bioactivities and physicochemical qualities, thanks 
to using benchmark packages like MoleculeNet (Wu et al. 2018) and DeepChem (). As 
a result, basic neural networks like MLP and CNN have been used in numerous drug-
based DL approaches (Zeng et al. 2020; Yang et al. 2019; Liu et al. 2017). The repre-
sentation power of molecular descriptors was often the focus of ADMET investigations 
rather than the model itself (Zhai et al. 2018; Liu et al. 2017; Kim et al. 2016; Tang 
et al. 2014). Hirohara et al. trained a CNN model with the SMILES string and then used 
learned attributes to discover motifs using significant structures for locations that bind 
proteins or unidentified functional groupings (Hirohara et  al. 2018). Atom pairs and 
pharmacophoric donor–acceptor pairings have been employed by Wenzel et al. (2019) 
as adjectives in multi-task deep neural networks to predict microsomal metabolic liabil-
ity. Gao et al. (2019) compared 6 different kinds of 2D fingerprints in the prediction of 
affinity between proteins and drugs using ML methods such as RF, single-task DNN, 
and multi-task DNN models. Matsuzaka and Uesawa (2019) used 2D pictures of 3D 
chemical compounds to train a CNN model to predict constitutive androstane recep-
tor agonists. They optimized the greatest performance in snapshots of a 3D ball-and-
stick model taken at various angles or coordinates. Therefore, the method outperformed 
seven common 3D chemical structure forecasts.
Since the GCN’s development, drug related GCN models have created depictions of 
graphs which concerned with molecules that incorporate details on the chemical structures 
by adding up the adjacent atoms’ properties (Gilmer et al. 2017).
GCNs have been employed as 3D descriptors instead of SMILES strings in a lot 
of research, and it’s been discovered that these learned descriptors outperform standard 
descriptors in prediction tests and are easier to understand (Shin et al. 2019; Ozturk et al. 
2018; Yu et al. 2019). Chemi-net employed GCN models to represent molecules and com-
pared the performance of single-task and multi-task DNNs on their own QSAR datasets 
Fig. 10   DL models used for predicting the DTIs are grouped into three categories: a drug-based models, b 
structure (graph)-based models, and c drug-protein(disease)-based models

## Page 18 (Section: 4.1.2 Structure (graph)-based models)

5992
	
H. Askr et al.
1 3
(Liu et  al. 2019a). Yang et  al. (2019) introduced the directed message passing neural 
network, which uses a directed message-passing paradigm, as a more advanced model 
(D-MPNN). They tested their approaches on 19 publicly available and 16 privately held 
datasets and discovered that in most situations, they were correct. The D-MPNN mod-
els outperformed the previous models. In two datasets, they underperformed and were 
not as resilient as typical 3D descriptors when the sample was small or unbalanced. The 
D-MPNN model was then employed by another research group to correctly forecast a kind 
of antibiotic named HALICIN, which demonstrated bactericide effects in models for mice 
(Stokes et al. 2020). This was the first incident that resulted in the finding of an antibiotic 
by using DL methods to explore a large-scale chemical space that current experimental 
methodologies cannot afford. The application of attention-based graph neural networks is 
another interesting contemporary method (Sun et al. 2020a). Edge weights and node fea-
tures can be learned together since a molecule’s graph representations can be altered by 
edge properties. As a result, Shang et al. suggested a multi-relational GCN with edge atten-
tion (Shang et al. 2018). For each edge, they created a reference guide on attention spans. 
Because it is used throughout the molecule, the approach can handle a wide range of input 
sizes.
In the Tox21 and HIV benchmark datasets, they found that this model performed bet-
ter than the random forest model. As a result, the model may effectively learn pre-aligned 
features from the molecular graph’s inherent qualities. Withnall et  al. (2020) extended 
the MPNN model with AMPNN (attention MPNN), which is an attention technique that 
the message forwarding step employs weighted summation. Moreover, they termed the 
D-MPNN model the edge memory neural network because it was extended by the same 
attention mechanism as the AMPNN (EMNN). Although it is computationally more inten-
sive than other models, this model fared better than others on the uniformly absent infor-
mation from the maximal unbiased validation (MUV) reference.
4.1.2  Structure (graph)‑based models
Unlike the drug- and structure-based models in Fig. 10b, protein targets and medication 
information should be included. Typical molecular docking simulation methods aim to 
predict the geometrically possible binding of known tertiary structure drugs and proteins. 
Atom sequences and amino acid residues can be used to express both the medicine as well 
as the target. Descriptors based on sequences were selected because DL approaches may be 
implemented right away with non-significant pre-processing of the entering data.
The Davis kinase binding affinity dataset (Davis et al. 2011) and the KIBA dataset (Sun 
et al. 2020a) were used in that study. DeepDTA, suggested by Ozturk et al. (2018), out-
performed moderate ML approaches such as KronRLS (Nascimento et al. 2016) and Sim-
Boosts (Tong et al. 2017) by applying solely information about the sequence of a CNN 
model based on the SMILES string and amino acid sequences. Wen et al. used ECFPs and 
protein sequence composition descriptors as examples of common and basic features and 
trained them using semi-supervised learning via a deep belief network (Wen et al. 2017). 
Another study, DeepConv-DTI, built a deep CNN model using only an RDKit Morgan fin-
gerprint and protein sequences (Lee et al. 2019). They also used the pooled convolution 
findings to capture local residue patterns of target protein sequences, resulting in high val-
ues for critical protein areas like actual binding sites.
The scoring feature, which ranks the protein-drug interaction with 3D structures and 
makes the training data parametric to forecast values for binding affinities of targeted

## Page 19 (Section: 4.1.2 Structure (graph)-based models)

5993
Deep learning in drug discovery: an integrative review and future…
1 3
proteins, is used to predict binding affinity values or binding pocket sites of the tar-
get proteins as a key metric for the structure-based regression model. The protein–drug 
complexes’ 3D structural characteristics were included in the CNNs by AtomNet (Wal-
lach et al. 2015). They placed 3D grids with set sizes (i.e., voxels) in comparison to pro-
tein–drug combinations, with every cell in the grid representing structural properties at that 
position. Several researchers have examined the situation since then, deep CNN models 
that use voxels to predict binding pocket location or binding affinity (Wang et al. 2020b; 
Ashburner et al. 2000; Zhao et al. 2019). In comparison to common docking approaches 
such as AutoDock Vina (Trott and Olson 2010) or Smina (Koes et al. 2013), these models 
have shown enhanced performance. This is since CNN models are relatively impervious 
even with large input sizes. It can be taught and is resilient to input data noise.
Many DTI investigations using GCNs based on structure-based approaches have been 
reported (Feng et al. 2018; Liu et al. 2016). Feng et al. (2018) used both ECFPs and GCNs 
as pharmacological characteristics. In the Davis et al. (2011), Metz et al. (2011), and KIBA 
Tang et  al. (2014) benchmark datasets, their methods outperformed prior models such 
as KronRLS (Nascimento et al. 2016) and SimBoost (Tong et al. 2017). However, they 
did agree that their GCN model couldn’t beat their ECFP model due to time and resource 
constraints in implementing the GCN. In a different DTI investigation study, Torng et al. 
employed a graph without supervision to become familiar with constant size depictions 
of protein binding sites (Torng and Altman 2019). The pre-trained GCN model was then 
trained using the newly created protein pocket GCN, the drug GCN model, on the other 
hand, used attributes to be trained and which were generated automatically. They con-
cluded that without relying on target–drug complexes, their model effectively captured pro-
tein–drug binding interactions.
Because the models that implement the attention mechanism have key qualities that ena-
ble the model to be interpreted, attention-based DTI prediction approaches have evolved 
(Hirohara et al. 2018; Liu et al. 2016; Perozzi et al. 2014).
For protein sequences, Gao et al. (2017) employed compressed vectors with the LSTM 
RNNs and the GCN for drug structures. They concentrated on demonstrating their meth-
od’s capacity to deliver biological insights into DTI predictions. To do so, Mechanisms for 
two-way attention were employed. to calculate the binding of drug–target pairs (DTPs), 
allowing for flexible interpretation of superior data from target proteins, such as GO key-
words. Shin et al. (2019) introduced the Molecule transformer DTI (MT-DTI) approach for 
drug representations, which uses the self-attention mechanism. The MT-DTI model was 
tweaked to perfection and assessed using two Davis models Using pre-trained parameters 
from the 97 million chemicals PubChem (Davis et al. 2011) and (KIBA) (Tang et al. 2014) 
benchmark datasets, which are both publicly available. However, the attention mechanism 
was not used to depict the protein targets because it would take too long to calculate the 
target sequence in an acceptable amount of time. Pre-training is impossible due to a lack of 
target information.
On the other hand, attention DTA presented by Zhao et al. incorporates a CNN atten-
tion mechanism model to establish the weighted connections between drug and protein 
sequences (Zhao et al. 2019). They showed that these attention-based drug and protein rep-
resentations have good MLP model affinity prediction task performance. DeepDTIs used 
external, experimental DTPs to infer the probability of interaction for any given DTP. Four 
of the top ten predicted DTIs have previously been identified, and one was discovered to 
have a poor glucocorticoid receptor binding affinity (Huang et al. 2018). DeepCPI was used 
to predict drug–target interactions. Small-molecule interactions with the glucagon-like

## Page 20 (Section: 4.1.3 Drug–protein(disease)-based models)

5994
	
H. Askr et al.
1 3
peptide one receptor, the glucagon receptor, and the vasoactive intestinal peptide receptor 
have been tested in experiments (Wan et al. 2019).
4.1.3  Drug–protein(disease)‑based models
According to poly pharmacology, most medicines have multiple effects on both primary 
and secondary targets. The biological networks involved, as well as the drug’s dose, 
influence these effects. As a result, the drug–protein(disease)-based models shown in 
Fig. 10c are particularly beneficial when evaluating protein promiscuity or drug selec-
tivity (Cortes-Ciriano et al. 2015). Furthermore, Neural networks that can do multiple 
tasks are ideal for simultaneously learning the properties of many sorts of data (Cama-
cho et al. 2018). Several DL model applications, such as drug-induced gene-expression 
patterns and DTI-related heterogeneous networks, leverage relational information for 
distinct views. A network-based strategy employs heterogeneous networks includes a 
variety of nodes and edges kinds (Luo et al. 2017; David et al. 2019). The nodes in these 
networks have a local similarity, which is a significant aspect of these models. One can 
anticipate DTIs using their connections and topological features when a network of sim-
ilarity with medications as its nodes and drug–drug similarity values as a measure of 
the edges’ weights is investigated. Machine to support vectors (Bleakley and Yamanishi 
2009; Keum and Nam 2017), Machine learning techniques that use heterogeneous net-
works as prediction frameworks include the regularized least square model (RLS) (Liu 
et al. 2016; Xia et al. 2010; Hao et al. 2016) and random walk with the restart model 
Nascimento (Lian et al. 2021; Nascimento et al. 2016). DTI prediction research using 
networks have employed DL to enhance the methods used to forecast associations today 
for evaluating the comparable topological structures of drug and target networks that 
are bipartite and tripartite linked networks, owing to the increased interest in the usage 
of DL technologies (drug, target, and disease networks) (Hassan-Harrirou et al. 2020; 
Lamb et al. 2006; Korkmaz 2020; Townshend et al. 2012; Vazquez et al. 2020). Zong 
et al. (2017) used the DeepWalk approach to collect local latent data, compute topol-
ogy-based similarity in tripartite networks, and demonstrate the technology’s promise as 
a medication repurposing solution.
Relationship-based features collected by training the AE were used in some network-
based DTI prediction studies. Zhao et al. (2020) developed a DTI-CNN prediction model 
that combined depth information that is low-dimensional but rich with a heterogeneous 
network that has been taught using the stacked AE technique. To construct the topological 
similarity matrix of drug and target, Wang et al. used a deep AE and mutually beneficial 
pointwise information in their analysis (Wang et al. 2020b). Peng et al. (2020) employed 
a denoising Autoencoder to pick network-based attributes and decrease the representation 
dimensions in another investigation.
By helping the self-encoder learn to denoise, the anti-aliasing effect (Autoencoder) 
enhances high-dimensional images with noise, input data that is noisy and incomplete, 
allowing the encoder to learn more reliably. These approaches, however, have a drawback 
in that it is challenging to foresee recent medications or targets, a problem. The problem 
of recommendation systems’ "cold start" is known as the "cold start" problem (Bedi et al. 
2015). The size and form of the network have a big impact on these models, so if the net-
work isn’t big enough, they will not be able to collect all the medications or targets that 
aren’t in the network (Lamb et al. 2006).

## Page 21 (Section: 4.2 Drug sensitivity and response prediction using DL)

5995
Deep learning in drug discovery: an integrative review and future…
1 3
Various investigations have also utilized Gene expression patterns as chemogenomic 
traits to predict DTIs. This research presumes that medications with similar expression pat-
terns have similar effects on the same targets (Hizukuri et al. 2015; Sawada et al. 2018).
The revised version of CMAP, the LINCS-L1000 database, has been integrated into 
the DL DTI models in recent works (Subramanian et al. 2017; Thafar et al. 2020; Karpov 
et al. 2020; Arus-Pous et al. 2020). Based on the LINCS pharmacological perturbation and 
knockout gene data, using a deep neural network, Xie et al. developed a binary classifica-
tion model (Xie et al. 2018).
On the other hand, Lee and Kim employed as a source of expression signature genes 
medication and target features. They used node2vec to train the rich data by examining 
three elements of protein function, including pathway-level memberships and PPI (Lee 
and Kim 2019). Saho and Zhang employed a GCN model to extract drug and target attrib-
utes from LINCS data and a CNN model to forecast DTPs by extracting latent features in 
DTIGCCN (Shao et al. 2020). The Gaussian kernel function was identified to aid in the 
production of high-quality graphs, and as a result, this hybrid model scored better on clas-
sification tests.
DeepDTnet employs a heterogeneous drug–gene-disease network to uncover known 
drug targets containing fifteen types of chemicals and genomic, phenotypic, and cellular 
network properties. DeepDTnet predicted and experimentally confirmed topotecan, a new 
direct inhibitor of the orphan receptor linked to the human retinoic acid receptor (Zeng 
et al. 2020).
4.2  Drug sensitivity and response prediction using DL
Drug response is the clinical outcome treated by the drug of interest (https://​www.​scien​
cedir​ect.​com/​topics/​drug-​respo​nse). This is due to the normally low ratio of samples to 
measurements each sample, which makes traditional feedforward neural networks unsuit-
able. The main idea of drug response prediction is shown in Fig.  11. The DL method 
takes the heterogenous network of drug and protein interactions as inputs and predicts 
the response scores. Although the widespread use of the deep neural network (DNN) 
approaches in various domains and sectors, including related topics like computational 
chemistry (Gómez-Bombarelli et al. 2018), DNNs have only lately made their way into 
drug response prediction. Overparameterization, overfitting, and poor generalization are 
common outcomes of recent simulation datasets. However, more public data has become 
available recently, and freshly built DNN models have shown promise. As a result, this 
section summarizes current DL computational problems and drug response prediction 
breakthroughs.
Since the 1990s, neural networks have been used to predict drug response (El-Deredy 
et  al. 1997) revealed that data from tumor nuclear magnetic resonance (NMR) spectra 
might be used to train a neural network and can be utilized to predict drug response in glio-
mas and offer information on the metabolic pathways involved in drug response.
In 2018, The DRscan model was created by Chang et al. (2018), and it uses a CNN 
architecture that was trained on 1000 drug reaction studies per molecule. Compared to 
other traditional ML algorithms like RF and SVM, their model performed much better. 
CDRscan’s ability to incorporate genomic data and molecular fingerprints is one of the 
reasons it outperformed these baseline models. Furthermore, its convolutional design 
has been demonstrated to be useful in various machine learning areas. A neural network 
called an autoencoder attempts to recreate the original data from the compressed form after

## Page 22 (Section: 4.2 Drug sensitivity and response prediction using DL)

5996
	
H. Askr et al.
1 3
compressing its input. As proven by Way and Greene (2018), this is very useful for fea-
ture extraction, which condensed a gene expression profile with 5000 dimensions with a 
maximum of 100 dimensions, some of which revealed to significant characteristics such as 
the patient’s sexual orientation or melanoma status. Using variational autoencoders, Dincer 
et al. (2018) created DeepProfile, a technique for learning a depiction of gene expression in 
AML patients in eight dimensions that is then fitted to a Lasso linear model for treatment 
response prediction with superior results to that of no extracting features.
Ding et al. (2018) proposed a deep autoencoder model for representation learning of 
cancer cells from input data consisting of gene expression, CNV, and somatic mutations.
In 2019, MOLI (Multi-omics Late Integration) (Sharifi-Noghabi et al. 2019) was a deep 
learning model that incorporates multi-omics data and somatic mutations to characterize a 
cell line. Three separate subnetworks of MOLI learn representations for each type of omics 
data. A final network identifies a cell’s response as responder or non-responder based on 
concatenated attributes. Those methods share two characteristics: integrating multiple 
input data (multi-omics) and binary classification of the drug response. Although combin-
ing several forms of omics data can improve the learning of cell line status, it may limit 
the method’s applicability for testing on different cell lines or patients because the model 
requires extra data beyond gene expression.
Furthermore, a certain threshold of the IC50 values should be set before binary clas-
sification of the drug response, which may vary depending on the experimental condition, 
such as drug or tumor types. Twin CNN for drugs in SMILES format (TCNNS) (Liu et al. 
2019b) takes a one-hot encoded representation of drugs and feature vectors of cell lines as 
the inputs for two encoding subnetworks of a One-Dimensional (1D) CNN. One-hot encod-
ings of drugs in TCNNS are Simplified Molecular Input Line Entry System (SMILES) 
strings which describe a drug compound’s chemical composition. Binary feature vectors 
of cell lines represent 735 mutation states or CNVs of a cell. KekuleScope (Cortés-Ciriano 
and Bender 2019) adopts transfer learning, using a pre-trained CNN on ImageNet data. 
The pre-trained CNN is trained with images of drug compounds represented as Kekulé 
structures to predict the drug response.
Yuan et al. (2019) offer GNNDR, a GNN-based technique with a high learning capac-
ity and allows drug response prediction by combining protein–protein interactions (PPI) 
Fig. 11   Drug binding with proteins and drug sensitivity (response) scores prediction

## Page 23 (Section: 4.2 Drug sensitivity and response prediction using DL)

5997
Deep learning in drug discovery: an integrative review and future…
1 3
information with genomic characteristics. The value of including protein information has 
been empirically proven. The proposed method offers a viable avenue for the discovery 
of anti-cancer medicines. Semi-supervised variational autoencoders for the prediction of 
monotherapy response were examined by the Rampášek et al. (2019). In contrast to many 
conventional ML methodologies, together developed a model for predicting medication 
reaction that took advantage of expression of genes before and after therapy in cell lines 
and demonstrated enhanced evaluation on a variety of FDA-approved pharmaceuticals. 
Chiu et al. (2019) trained a deep drug response predictor after pre-training autoencoders 
using mutation data and expression features from the TCGA dataset. The use of pretrain-
ing distinguishes their strategy from others. Compared to using only the labeled data, the 
pretraining process permits un-labelled data from outside sources, like TCGA, as opposed 
to just gene expression profiles obtained from drug reaction tests, resulting in a significant 
increase in the number of samples available and improved performance.
Chiu et al. (2019) and Li et al. (2019) used a combination of auto-encoders and pre-
dicted drug reactions in cell lines with deep neural networks and malignancies that had 
been gnomically characterized. To anticipate cell lines reactions to drug combinations, in 
https://​string-​db.​org/​cgi/​downl​oad.​pl?​sessi​onId=​uKr0o​dAK9h​Ps used deep neural encod-
ers to link genetic characteristics with drug profiles.
In 2020, Wei et al. (2020) anticipate drug risk levels (ADRs) based on adverse drug reac-
tions. They use SMOTE and machine learning techniques in their studies. The proposed 
framework was used to investigate the mechanism of ADRs to estimate degrees of drug risk 
and to assist with and direct decision-making during the changeover from prescription to 
over-the-counter medications. They demonstrated that the best combination, PRR-SMOTE-
RF, was built using the above architecture and that the macro-ROC curve had a strong clas-
sification prediction effect. They suggested that this framework could be used by several drug 
regulatory organizations, including the FDA and CFDA, to provide a simple but dependable 
method for ADR signal detection and drug classification, as well as an auxiliary judgement 
basis for experts deciding on the status change of Rx drugs to OTC drugs. They propose 
that more ML or DL categorization algorithms be tested in the future and that computational 
complexity be factored into the comparison process. Kuenzi et al. (2020) built DrugCell, an 
interpretable DL algorithm of personal cancer cells based on the reactions of 1235 tumor cell 
lines to 684 drugs. Genotypes of cancer cause conditions in cellular systems combined with 
medication composition to forecast therapeutic outcome while also learning the molecular 
mechanisms underlying the response. Predictions made by DrugCell in cell lines are pre-
cise and help to categorize clinical outcomes. The study of DrugCell processes results in the 
development of medication combinations with synergistic effects, which we test using com-
binatorial CRISPR, in vitro drug–drug screening, and xenografts generated from patients. 
DrugCell is a step-by-step guide to building interpretable predictive medicine models.
Artificial Neural Networks (ANNs) that operate on graphs as inputs are known as Graph 
Neural Networks (GNNs). Deep GNNs were recently employed for learning representa-
tions of low-dimensional biomolecular networks (Hamilton 2020; Wu et al. 2020). Ahmed 
et al. (2020) used two separate GNN methods to develop a GNN using GE and a network 
of genes that are expressed together. This is a network that depicts the relationship between 
gene pairs’ expression.
The CNN is one of the neural network models adopted for drug response prediction. 
The CNN has been actively used for image, video, text, and sound data due to its strong 
ability to preserve the local structure of data and learn hierarchies of features. In 2021, 
several methods had been developed for drug response prediction, each of which utilizes 
different input data for prediction (Baptista et al. 2021).

## Page 24 (Section: 4.3 Drug–drug interactions (DDIs) side effect prediction using DL)

5998
	
H. Askr et al.
1 3
Nguyen et al. (2021) proposed a method to predict drug response called GraphDRP, 
which integrates two subnetworks for drug and cell line features, like CNN in Liu et al. 
(2019b) and Qiu et al. (2021). Gene expression data from cancer cell lines and medication 
response data, the author finds predictor genes for medications of interest and provides a 
reliable and accurate drug response prediction model. Using the Pearson correlation coef-
ficient, they employed the ElasticNet regression model to predict drug response and fine-
tune gene selection after pre-selecting genes. They ran a regression on each drug twice, 
once using the IC50 and once with the area under the curve (AUC), to obtain a more trust-
worthy collection of predictor genes (or activity area). The Pearson correlation coefficient 
for each of the 12 medicines they examined was greater than 0.6. With 17-AAG, IC50 has 
the highest Pearson correlation coefficient of 0.811.
In contrast, AUC has the highest Pearson correlation coefficient of 0.81. Even though 
the model developed in this study has excellent predictive performance for GDSC, it still 
has certain flaws. First, the cancer cell line’s properties may differ significantly from those 
of in vivo malignancies, and it must be determined whether this will be advantageous in 
a clinical trial. Second, they primarily use gene expression data to predict drug response. 
While drug response is influenced by structural changes such as gene mutations, it is also 
influenced by gene expression levels. To improve the prediction capacity of the model, 
more research is needed to use such data and integrate it into the model.
In 2022, Ren et al. (2022) suggested a graph regularized matrix factorization based on 
deep learning (DeepGRMF), which uses a variety of information, including information 
on drug chemical composition, their effects on cell biology signaling mechanisms, and the 
conditions of cancer cells, to integrate neural networks, graph models, and matrix-factori-
zation approaches to forecast cell response to medications. DeepGRMF trains drug embed-
dings so that drugs in the embedding space with similar structures and action mechanisms, 
(MOAs) are intimately linked. DeepGRMF learns the same representation embeddings 
for cells, allowing cells with similar biological states and pharmacological reactions to be 
linked. The Cancer Cell Line Encyclopedia (CCLE) and On the Genomics of Drug Sen-
sitivity in Cancer (GDSC) datasets, DeepGRMF outperforms competing models in pre-
diction performance. In the Cancer Genome Atlas (TCGA) dataset, the suggested model 
might anticipate the effectiveness of a treatment plan on lung cancer patients’ outcomes. 
The limited expressiveness of our VAE-based chemical structure representation may 
explain why new cell line prediction outperforms innovative drug sensitivity prediction in 
terms of accuracy. A family of neural graph networks has recently been shown to depict 
better chemical structures that can be investigated in the future. Pouryahya et al. (2022) 
proposed a new network-based clustering approach for predicting medication response 
based on OMT theory. Gene-expression profiles and cheminformatic drug characteristics 
were used to cluster cell lines and medicines, and data networks were used to represent the 
data. Then, RF model was used regarding each pair of cell-line drug clusters. by compari-
son, prediction-clustered based models regarding the homogenous data are anticipated to 
enhance drug sensitivity and precise forecasting and biological interpretability.
4.3  Drug–drug interactions (DDIs) side effect prediction using DL
Drugs are chemical compounds consumed by people and interact with protein targets to 
create a change. The drugs may alter the human body positively or negatively. Drug side 
effects are the undesirable alterations medications cause in the human body. These adverse

## Page 25 (Section: 4.3 Drug–drug interactions (DDIs) side effect prediction using DL)

5999
Deep learning in drug discovery: an integrative review and future…
1 3
effects might range from moderate headaches to life-threatening reactions like cardiac 
arrest, malignancy, and death. They differ depending on the person’s age, gender, stage of 
sickness, and other factors (Kuijper et al. 2019). In the laboratory, to determine whether the 
medications have any unfavorable side effects, several tests are conducted on them. How-
ever, these examinations are both pricey and additionally lengthy. Recently, many compu-
tational algorithms for detecting medication adverse effects have been created. Computa-
tional methodologies are replacing laboratory experiments.
On the other hand, these methods do not provide adequate data to predict drug–drug 
interactions (DDIs). The phenomenon of DDIs is discussed in Fig. 12. The desired effects 
of a drug resulting from its interaction with the intended target and the unfavorable reper-
cussions emerging from drug interactions with off targets make up a drug’s entire reaction 
on the human body (undesirable effects). Even though A medication has a strong affinity 
for binding to one target, it binds to several proteins as well with varied affinities, which 
might cause adverse consequences (Liu et al. 2021). Predicting DDIs can assist in reducing 
the likelihood of adverse reactions and optimizing the medication development and post-
market monitoring processes (Arshed et al. 2022). Side effects of DDIs are often regarded 
as the leading cause of drug failure in pharmacological development. When drugs have 
major side effects, the market is quickly removed from them. As a result, predicting side 
effects is a fundamental requirement in the drug discovery process to keep drug develop-
ment costs and timelines in check and launch a beneficial drug in terms of patient health 
recovery.
Furthermore, the average drug research and development cost is $2.6 billion (Liu et al. 
2019). As a result, determining the possibility of negative consequences is important for 
lowering the expense and risk of medication development. The researchers use various 
computer tools to speed up the process. In pharmacology and clinical application, DDI pre-
diction is a difficult topic, and correctly detecting possible DDIs in clinical studies is cru-
cial for patients and the public. Researchers have recently produced a series of successes 
utilizing deep learning as an AI technique to predict DDIs by using drug structural proper-
ties and graph theory (Han et al. 2022). AI successfully detected potential drug interac-
tions, allowing doctors to make informed decisions before prescribing prescription combi-
nations to patients with complex or numerous conditions (Fokoue et al. 2016).
Therefore, this section comprehensively reviews the researchers’ most popular DL algo-
rithms to predict DDIs.
In 2016, Tiresias is a framework proposed by Achille Fokoue et al. (2017) for discover-
ing DDIs. The Tiresias framework uses a large amount of drug-related data as input to gen-
erate DDI predictions. The detection of the DDI approach begins using input data that has 
been semantically integrated, resulting in a knowledge network that represents drug prop-
erties and interactions using additional components like enzymes, chemical structures, and 
routes. Numerous similarity metrics between all pharmacological categories were deter-
mined using a knowledge graph in a scalable and distributed setting. To forecast the DDIs, 
a large-scale logistic regression prediction model employs calculated similarity metrics. 
According to the findings, the Tiresias framework was proven to help identify new interac-
tions between currently available medications and freshly designed and existing drugs. The 
suggested Tiresias model’s necessity for big, scaled medication information was negative, 
resulting in the developed model’s high cost.
In 2017, Reza et al. (2017) developed a computational technique for predicting DDIs 
based on functional similarities among all medicines. Several major biological aspects 
were used to create the suggested model: carriers, enzymes, transporters, and targets 
(CETT). The suggested approach was implemented on 2189 approved medications, for

## Page 26 (Section: 4.3 Drug–drug interactions (DDIs) side effect prediction using DL)

6000
	
H. Askr et al.
1 3
which the associated CETTs were obtained, and binary vectors to find the DDIs were cre-
ated. Two million three hundred ninety-four thousand seven hundred sixty-seven potential 
drug–drug interactions were assessed, with over 250,000 unidentified possible DDIs dis-
covered. Inner product-based similarity measures (IPSMs) offered good values predicted 
for detecting DDIs among the several similarity measures used. The lack of pharmaco-
logical data was a key flaw in this strategy, which resulted in the erroneous detection of all 
potential pairs of DDIs.
In 2018, Ryu et al. (2018) proposed a model that predicts more DDI kinds using the 
drug’s chemical structures as inputs and applied multi-task learning to DDI type prediction 
in the same vein Decagon (Zitnik et al. 2018) models polypharmacy side effects using a 
relational GNN. To comprehend the representations of intricate nonlinear pharmacological 
interactions, Chu et al. (2018) utilized an auto-encoder for factoring. To predict DDIs, Liu 
et al. (2019c) presented the DDI-MDAE based on shared latent representation, a multi-
modal deep auto-encoder. Recently, interest in employing graph neural networks (GNNs) 
to forecast DDI has increased. Distinct aggregation algorithms lead to different versions 
of GNNs to efficiently assemble the vectors of its neighbors’ feature vectors (Asada et al. 
2018) uses a convolutional graph network (GCN) to encode the molecular structures to 
extract DDIs from text. Furthermore, Ma et al. (2018) has incorporated attentive Multiview 
graph auto-encoders into a coherent model.
Chen (2018) devised a model for predicting Adverse Drug Reactions (ADR). SVM, LR, 
RF, and GBT were all used in the predictive model. The DEMO dataset, which contains 
properties such as the patient’s age, weight, and sex, and the DRUG dataset, which includes 
features such as the drug’s name, role, and dosage, were employed in this model. Males 
make up 46% of the sample, while females make up 54%. The developed model had a fair 
forecasting accuracy for a representative sample set. Furthermore, the outputs revealed that 
the suggested model is only accurate for a significant number of datasets.
To anticipate the possible DDI, Kastrin et  al. (2018) employed statistical learning 
approaches. The DDI was depicted as a complex network, with nodes representing medica-
tions and links representing their potential interactions. On networks of DDIs, the proce-
dure for predicting links was represented as a binary classification job. A big DDI database 
was picked randomly to forecast. Several supervised and unsupervised ML approaches, 
such as SVM, classification tree, boosting, and RF, are applied for edge prediction in vari-
ous DDIs. Compared to unsupervised techniques, the supervised link prediction strategy 
Fig. 12   Drug binding with proteins and DDI side effects

## Page 27 (Section: 4.3 Drug–drug interactions (DDIs) side effect prediction using DL)

6001
Deep learning in drug discovery: an integrative review and future…
1 3
generated encouraging results. To detect the link between the pharmaceuticals, The pro-
posed method necessitates Unified Medical Language System (UMLS) filtering, which 
provided a dilemma for the scientists. Furthermore, the suggested system only considers 
fixed network snapshots, which is problematic for DDI’s system because It’s a fluid system.
In 2019, Lee et al. (2019) proposed a deep learning system for accurately forecasting 
the results of DDIs. To learn more about the pharmacological effects of a variety of DDIs, 
an assortment of auto-encoders and a deep feed-forward neural network was employed 
in the suggested method that were honed utilizing a mix of well-known techniques. The 
results revealed that using SSP alone improves GSP and TSP prediction accuracy, and 
the autoencoder is more powerful than PCA at reducing profile features. In addition, the 
model outperformed existing approaches and included numerous novel DDIs relevant to 
the current study Yue et al. (2020) combines numerous graphs embedding methods for the 
DDI job, while models DDI as link prediction with the help of a knowledge graph (Karim 
et al. 2019). There’s also a system for co-attention (Andreea and Huang 2019), which pre-
sented a deep learning model based solely on side-effect data and molecular drug structure. 
CASTER in Huang et al. (2020) also based on drug chemical structures, develops a frame-
work for dictionary learning to anticipate DDIs (Chu et al. 2019) and proposes using semi-
supervised learning to extract meaningful information for DDI prediction in both labeled 
and unlabeled drug data. Shtar et al. (2019) used a mix of computational techniques to 
predict medication interactions, including artificial neural networks and graph node factor 
propagation methods such as adjacency matrix factorization (AMF) and adjacency matrix 
factorization with propagation (AMFP). The Drug-bank database was used to train the 
model, containing 1142 medications and 45,297 drug drugs. With 1442 drugs and 248,146 
drug–drug interactions, the trained model was tested from the drug bank’s most recent ver-
sion. AMF and AMFP were also used to develop an ensemble-based classifier, and the 
outcomes were assessed using the receiver operating characteristic (ROC) curve. The find-
ings revealed that the suggested a classifier that uses an ensemble delivers important drug 
development data and noisy data for drug prescription. In addition, drug embedding, which 
was developed during the training of models utilizing interaction networks, has been made 
available. To anticipate adverse drug events caused by DDIs, Hou et al. (2019) suggested 
a deep neural network architecture model. The suggested model is based on a database of 
5000 medication codes obtained from Drug Bank. Using the computed features, it discov-
ers 80 different types of DDIs. Tensor Flow-GPU was also used to create the model, which 
takes 4432 drug characteristics as input.
Medicines for inflammatory bowel disease (IBD) can predict how they will react; the 
trained model has an accuracy of 88 percent. The findings also revealed that the model per-
forms best when many datasets are used. Detecting negative effects of drugs with a DNN 
Model was proposed by Wang et al. (2019). The model predicts ADRs by using synthetic, 
biological, and biomedical knowledge of drugs. Drug data from SIDER databases was also 
incorporated into the model. The proposed system’s performance was improved by distrib-
uting. Using a word-embedding approach, determine the association between medications 
using the target drug representations in a vector space. The suggested system’s fundamen-
tal flaw was that it only worked well with ordinary SIDER databases.
In 2020, numerous AI-based methods were developed for DDI event prediction, includ-
ing evaluating chemical structural similarity using neural graph networks (Huang et  al. 
2020). Attempts to forecast DDI utilizing different data sources have also been made, such 
as leveraging similarity features to create pharmacological features for the DDI job predict-
ing occurrences (Deng et al. 2020).

## Page 28 (Section: 4.3 Drug–drug interactions (DDIs) side effect prediction using DL)

6002
	
H. Askr et al.
1 3
With the help of word embeddings, part-of-speech tags, and distance embeddings. Bai 
et al. (2020) suggested a deep learning technique that executes the DDI extraction task 
and supports the drug development cycle and drug repurposing. According to experimental 
data, the technique can better avoid instance misclassifications with minimal pre-process-
ing. Moreover, the model employs an attention technique to emphasize the significance of 
each hidden state in the Bi-LSTM layers.
A tool for extracting features regarding a graph convolutional network (GCN) and a 
predictor based on a DNN. Feng et al. (2020) suggested DPDDI, an effective and robust 
approach for predicting potential DDIs by utilizing data from the DDI network lack-
ing a thought of drug characteristics (i.e., drug chemical and biological properties). The 
proposed DPDDI is a useful tool for forecasting DDIs. It should benefit from other DDI-
related circumstances, such as recognizing unanticipated side effects and guiding drug 
combinations. The disadvantage of this paradigm is that it ignores drug characteristics.
Zaikis and Vlahavas (2020), by developing a bi-level network with a more advanced 
level reflecting the network of biological entities’ interactions, suggested a multi-level 
GNN framework for predicting biological entity links. Lower levels, however, reflect indi-
vidual biological entities such as drugs and proteins, although the proposed model’s accu-
racy needs to be enhanced.
In 2021, To overcome the DDI prediction, Lin et al. (2021) suggested an end-to-end sys-
tem called Knowledge Graph Neural Network (KGNN). KGNN expands the use of spatial 
GNN algorithms to the knowledge graph by selectively various aggregators of neighbor-
hood data, allowing it to learn the knowledge graph’s topological structural information, 
semantic relations, and the neighborhood of drugs and drug-related entities. Medical risks 
are reduced when numerous medications are used correctly, and drug synergy advantages 
are maximized. For multi-typed DDI pharmacological effect prediction, Yue et al. (2021) 
used knowledge graph summarization. Lyu et al. (2021) also introduced a Multimodal Deep 
Neural Network (MDNN) framework for DDI event prediction. On the drug knowledge 
graph, a graph neural network was used, MDNN effectively utilizes topological informa-
tion and semantic relations. MDNN additionally uses joint representation structure informa-
tion, and heterogeneous traits are studied, which successfully investigates the multimodal 
data’s complementarity across modes. Karim et al. (2019) built a knowledge graph that used 
CNN and LSTM models to extract local and global pharmacological properties across the 
network. DANN-DDI is a deep attention neural network framework proposed by Liu et al. 
(2021). To anticipate unknown DDIs, it carefully incorporates different pharmacological 
properties (Chun and Yi-Ping Phoebe 2021) and developed a deep hybrid learning (DL) 
model to provide a descriptive forecasting of pharmacological adverse reactions. It was one 
of the initial hybrid DL models through conception models that could be interpreted. The 
model includes a graph CNN through conception models to improve the learning efficiency 
of chemical drug properties and bidirectional long short-term memory (BiLSTM) recurrent 
neural networks to link drug structure to adverse effects. After concatenating the outputs 
of the two networks (GCNN and BiLSTM), a fully connected network is utilized to fore-
cast pharmacological adverse reactions. Regardless of the classification threshold, the model 
obtains an AUC of 0.846. It has a 0.925 precision score. Even though a tiny drug data set 
was used for adverse drug response (ADR) prediction, the Bilingual Evaluation Understudy 
(BLEU) concluded results were 0.973, 0.938, 0.927, and 0.318, indicating considerable 
achievements. Furthermore, the model can correctly form words to explain pharmacological 
adverse reactions and link them to the drug’s name and molecular structure. The projected 
drug structure and ADR relationship will guide safety pharmacology research at the preclin-
ical stage and make ADR detection easier early in the drug development process. It can also

## Page 29 (Section: 4.4 Drug–drug similarity prediction using DL)

6003
Deep learning in drug discovery: an integrative review and future…
1 3
aid in the detection of unknown ADRs in existing medications. DDI extraction using a deep 
neural network model from medical literature was proposed by Mohsen and Hossein (). This 
model employs an innovative approach of attracting attention to improve the separation of 
essential words from other terms based on word similarity and location concerning candi-
date medications. Before recognizing the type of DDIs, this method calculates the results of 
a bi-directional long short-term memory (Bi-LSTM) model’s attention weights in the deep 
network architecture. On the standard DDI Extraction 2013 dataset, the proposed approach 
was tested. According to the findings of the experiments, they were able to get an F1-Score 
of 78.30, which is comparable to the greatest outcomes for stated existing approaches.
In 2022, Pietro et al. (2022) introduced DruGNN, a GNN-based technique for predicting 
DDI side effects. Each DDI corresponds to a class in the prediction, a multi-class, multi-
label node classification issue. To forecast the side effects of novel pharmaceuticals, they 
use a combination inductive-transudative learning system that takes advantage of drug and 
gene traits (induction path) and knowledge of known drug side effects (transduction path). 
The entire procedure is adaptable because the base for machine learning can still be used if 
the graph dataset is enlarged to include more node properties and associations. Zhang et al. 
(2022) proposed CNN-DDI, a new semi-supervised algorithm for predicting DDIs that 
uses a CNN architecture. They first extracted interaction features from pharmacological 
categories, targets, pathways, and enzymes as feature vectors. They then suggested a novel 
convolution neural network as a predictor of DDIs-related events based on feature repre-
sentation. Five convolutional layers, two full-connected layers, and a CNN-based SoftMax 
layer make up the predictor. The results reveal that CNN-DDI superior to other cutting-
edge techniques, but it takes longer to complete (Jing et al. 2022) presented DTSyn. This 
unique dual-transformer-based approach can select probable cancer medication combina-
tions. It uses a multi-head attention technique to extract chemical substructure-gene, chem-
ical-chemical, and chemical-cell-line connections. DTSyn is the initial model that incorpo-
rates two transformer blocks to extract linkages between interactions between genes, drugs, 
and cell lines, allowing a better understanding of drug action processes. Despite DTSyn’s 
excellent performance, it was discovered that balanced accuracy on independent data sets 
is still limited. Collecting more training data is expected to solve the problem. Another 
issue is that the fine-granularity transformer was only trained on 978 signature genes, 
which could result in some chemical-target interactions being lost.
Furthermore, DTSyn used expression data as the only cell line attributes. To fully repre-
sent the cell line, additional omics data may be added going forward, including methylation 
and genetic data. He et al. (2022) proposed MFFGNN, a new end-to-end learning frame-
work for DDI forecasting that can effectively combine information from molecular drug 
diagrams, SMILES sequences, and DDI graphs. The MFFGNN model used the molecular 
graph feature extraction module to extract global and local features from molecular graphs.
They run thorough tests on a variety of real-world datasets. The MFFGNN model rou-
tinely beats further cutting-edge models, according to the findings. Furthermore, the mod-
ule for multi-type feature fusion configures the gating mechanism to limit the amount of 
neighborhood data provided to the node.
4.4  Drug–drug similarity prediction using DL
Drug similarity studies presume that medications with comparable pharmacological quali-
ties have similar activation mechanisms, and side effects are used to treat problems like 
each other (Brown 2017; Zeng et al. 2019).

## Page 30 (Section: 4.4.1 Drug similarity measures)

6004
	
H. Askr et al.
1 3
The drug-pharmacological similarity is critical for various purposes, including identi-
fying drug targets, predicting side effects, predicting drug–drug interactions, and reposi-
tioning drugs. Features of the chemical structure (Lu et al. 2017; O’Boyle 2016), protein 
targets (Vilar 2016; Wang et al. 2014), side-effect profiles (Campillos et al. 2008; Tatonetti 
et al. 2012), and gene expression profiles (Iorio et al. 2010) provide a multi-perspective 
viewpoint for forecasting medications that are similar and can correct for data gaps in dif-
ferent data sources and offer fresh perspectives on drug repositioning and other uses. The 
main idea of drug–drug similarity is presented in Fig. 13. The vector represents the drug 
features, and the links reflect the similarity between the two drugs.
4.4.1  Drug similarity measures
The similarity estimations are calculated based on chemical structure, target protein 
sequence-based, target protein functional, and drug-induced pathway similarities.
4.4.1.1  The similarity in chemical structure  DrugBank (2019) provides tiny molecule 
medicine chemical structures in SDF molecular format. Invalid SDFs can be recognized 
and eliminated, such as those with a NA value or fewer than three columns in atom or 
bond blocks. For valid compounds, atom pair descriptors can be computed, pairwise 
comparison of compounds, δc (di, dj), was evaluated using atom pairs using the Tanimoto 
coefficient, which is defined as the number of atom pairs in each fraction shared by two 
different compounds divided by their union (Eq. 1).
where ­APi and ­APj are atom pairs from pharmaceuticals ­di and dj, respectively, the numer-
ator is the total number of atom pairs in both compounds, while the denominator is the 
number of common atom pairs in both compounds.
4.4.1.2  Target protein sequence‑based similarity  DrugBank provides all small mole-
cule drugs have target sequences in FASTA format. The basic Needleman-Wunsch et al. 
(1970) dynamic programming approach for global alignment can be used to compare 
pairwise protein sequences. The proportion of pairwise sequence identity (Raghava 
2006) can be represented as the corresponding sequence similarity. Equation 2 was used 
to calculate drug–drug similarity based on target sequence similarities:
where δt (di, dj) denotes target-based similarity between medicines di and dj. Drugs di 
target a group of proteins known as Ti. Tj is a set of proteins that pharmaceuticals dj target 
and S(x,y) is a similarity metric based on symmetric sequences between two targeted pro-
teins, x ∈ Ti and y ∈ Tj. Overall, Eq. 2 calculates the average of the best matches, wherein 
each first medicine’s target is only connected to the second medicine’s most comparable 
phrase, and vice versa.
(1)
훿c(di, dj) = |||APi ∩APj|||
/|||APi ∪APj|||
(2)
훿t
di, dj
 =
∑
x∈Ti max∀y∈Tj{S(x, y)} + ∑
x∈Tj max∀x∈Ti{S(y, x)}


Ti∗Tj


## Page 31 (Section: 4.4.1.3 Target protein functional similarity )

6005
Deep learning in drug discovery: an integrative review and future…
1 3
4.4.1.3  Target protein functional similarity  Protein targets that are overrepresented by 
comparable biological functions and have similar sequences imply shared pharmacological 
mechanisms and downstream effects (Passi et al. 2018). As a result, each protein has a set of 
Gene Ontology (GO) concepts from all three categories associated with it, such as cellular 
components (CC), molecular functions (MF), and biological processes (BP). We filtered 
out GO keywords that were either very specialized (with 15 linked genes) or very general 
(with 100 genes). DrugBank (2019) provided the Human Protein–Protein Interaction (PPI) 
network. Wang et al. (2007) proposed leveraging the topology of the GO graph structure to 
determine the semantic similarity of their linked GO terms, which was used to determine 
how functionally comparable two drugs are, such as δf ­(di, ­dj). Using a best-match average 
technique, any two GO keywords are compared for pairwise semantic similarity connected 
with di and ­dj were aggregated into a single semantic similarity measure and presented into 
a final similarity matrix.
4.4.1.4  Drug‑induced pathway similarity  A medication pair that triggers similar pathways 
or overlaps shows that the drugs’ mechanisms of action are similar, which is useful informa-
tion for drug similarities and repositioning research (Zeng et al. 2015). Kanehisa and Goto 
(2000) was used to find the pathways activated by each small molecule medication. Using 
dice similarity, the similarity in pairs of any two options was calculated based on their con-
stituent genes’ closeness. After that, a pathway-based similarity score was calculated for 
each medication pair ­di and ­dj, i.e., δp (di, dj), was calculated using Eq. 3:
where Pi and Pj are a group of drug-induced pathways di and dj, respectively; x and 
y are two paths represented by a group of genes that make up their constituents, and 
DSC(x, y) = 2|x ∩y|∕(|x| + |y|) is the probability of a pair of dice matching, this deter-
mines how much the two trajectories overlap. When no gene is shared by any two pathways 
(3)
훿p
(di, dj
) =
max
∀x∈Pi,∀y∈Pj {DSC(x, y)},
Fig. 13   Drug–drug similarity main idea

## Page 32 (Section: 4.4.2 DL for drug similarity prediction)

6006
	
H. Askr et al.
1 3
produced by the comparing drug pair, the similarity is set to 0.0. Overall, Eq. 3 implies that 
if two medications stimulate one or more identical pathways, the maximum pathway-based 
similarity will be achieved (s).
4.4.2  DL for drug similarity prediction
Wang et al. (2019) introduced a gated recurrent units (GRUs) model that employs similar-
ity to predict drug–disease interactions. In this approach, CDK turned the SMILES into 2D 
chemical fingerprints, and the Jaccard score of the 2D chemical fingerprints was used to 
compare the two medicines. This section comprehensively reviews the researchers’ most 
popular DL algorithms to predict drug similarity.
Hirohara et al. (2018) employed a CNN to learn molecular representation. The network 
is given the molecule’s SMILES notation as input to feed into the convolutional layers in 
this scenario. The TOX 21 dataset was used.
To conduct similarity analysis, Cheng et al. (2019) used the Anatomical Therapeutic 
Chemical (ATC) based on the drug ATC classification systems and code-based commonal-
ities of drug pairs. The authors created interaction networks, performed drug pair similarity 
analyses, and developed a network-based methodology for identifying clinically effective 
treatment combinations for a specific condition.
Xin et al. (2016) presented a Ranking-based k-Nearest Neighbour (Re-KNN) tech-
nique for medication repositioning. The method’s key feature combines the Ranking 
SVM (Support Vector Machine) algorithm and the traditional KNN algorithm. Chemi-
cal structural similarity, target-based similarity, side-effect similarity, and topological 
similarity are the types of similarity computation methodologies they used. The Tani-
moto score was then used to determine the similarity between the two profiles.
Seo et al. (2020) proposed an approach that combined drug–drug interactions from 
DrugBank, network-based drug–drug interactions, polymorphisms in a single nucleo-
tide, and anatomical hierarchy of side effects, as well as indications, targets, and chemi-
cal structures.
Zeng et al. (2019) developed an assessment of clinical drug–drug similarity derived 
from data from the clinic and used EHRs to analyse and establish drug–diagnosis con-
nections. Using the Bonferroni adjusted hypergeometric P value, they created connec-
tions between drugs and diagnoses in an EMR dataset. The distances between medica-
tions were assessed using the Jaccard similarity coefficient to form drug clusters, and a 
k-means algorithm was devised.
Dai et al. (2020) reviewed, summarized representative methods, and discussed appli-
cations of patient similarity. The authors talked about the values and applications of 
patient similarity networks. Also, they discussed the ways to measure similarity or dis-
tance between each pair of patients and classified it into unsupervised, supervised, and 
semi-supervised.
Yan et al. (2019) created BiRWDDA, a new computational methodology for medi-
cation repositioning that combines bi-random walk and various similarity measures to 
uncover potential correlations between diseases and pharmaceuticals. First drug and 
disease–disease similarities are assessed to identify optimal drug and disease similari-
ties. The information entropy is evaluated between the similarity of medicine and dis-
ease to determine the right similarities. Four drug–drug similarity metrics and three 
disease–disease similarity measurements were calculated depending on some drug- and

## Page 33 (Section: 5 Benchmark datasets and databases)

6007
Deep learning in drug discovery: an integrative review and future…
1 3
disease-related characteristics to create a heterogeneous network. The drug’s protein 
sequence information, the extracted drug interaction from DrugBank then utilized 
the Jaccard score to determine this similarity, the chemical structure, derived canoni-
cal SMILES from DrugBank, and the side effect, respectively the four drug–drug 
similarities.
Yi et al. (2021) constructed the model of a deep gated recurrent unit to foresee drug–dis-
ease interactions that likely employ a wide range of similarity metrics and a kernel with a 
Gaussian interaction profile. Based on their chemical fingerprints, the similarity measure 
is utilized to detect a distinguishing trait in medications. Meanwhile, based on established 
disease–disease relationships, the Gaussian interactions profile kernel is used to derive 
efficient disease features. After that, a model with a deep gated recurrent cycle is created 
to anticipate drug-disease interactions that could occur. The outputs of the experiments 
showed that the suggested algorithm could be used to anticipate novel drug indications 
or disease treatments and speed up drug repositioning and associated drug research and 
discovery.
To forecast DDIs, Yan et  al. (2022) suggested a semi-supervised learning technique 
(DDI-IS-SL). DDI-IS-SL uses the cosine similarity method to calculate drug feature simi-
larity by combining chemical, biological, and phenotypic data. Drug chemical structures, 
drug–target interactions, drug enzymes, drug transporters, drug routes, drug indications, 
drug side effects, harmful effects of drug discontinuation, and DDIs that have been identi-
fied are all included in the integrated drug information.
Heba et al. (2021) used DrugBank to develop a machine learning framework based on sim-
ilarities called "SMDIP" (Similarity-based ML for Drug Interaction Prediction), where they 
calculated drug–drug similarity utilizing a Russell–Rao metric for the biological and structural 
data that is currently accessible on DrugBank to represent the limited feature area. The DDI 
classification is carried out using logistic regression, emphasizing finding the main predictors 
of similarity. The DDI key features are subjected to six machine learning models (NB: naive 
Bayes; LR: logistic regression; KNN: k-nearest neighbours; ANN: neural network; RFC: ran-
dom forest classifier; SVM: support vector machine).
For large-scale DDI prediction, Vilar et al. (2014) provided a procedure combining five 
similar drug fingerprints (Two-dimensional structural fingerprints, fingerprinting of interac-
tion profiles, fingerprints of the target profile, Fingerprints of ADE profiles, and pharmacoph-
oric techniques in three dimensions).
Song et  al. (2022) used similarity theory and a convolutional neural network to create 
global structural similarity characteristics. They employed a transformer to extract and pro-
duce local chemical sub-structure semantic characteristics for drugs and proteins. To create 
drug and protein global structural similarity characteristics, The Tanimoto coefficient, Leven-
shtein distance, and CNN are all utilized in this study.
5  Benchmark datasets and databases
Drug development or discovery has been based on a range of direct and indirect data sources 
and has regularly demonstrated strong predictive capability in finding confirmed repositioning 
candidates and other applications for computer-aided drug design. This section reviews the 
most important and available benchmark datasets and databases used in the drug discovery 
problem and which the researchers may need according to each problem category. Thirty-five 
datasets are summarized in Table 3.

## Page 34 (Section: 6 Evaluation metrics)

6008
	
H. Askr et al.
1 3
6  Evaluation metrics
Performance measures are required for evaluating machine learning models (Benedek et al. 
2021). The measures serve as a tool for comparing different techniques. They aid in compar-
ing many approaches to identify the best one for execution. This section describes the many 
metrics defined for the four categories of drug discovery difficulties below.
Table 4 shows the metrics employed in drug discovery problems—understanding the met-
rics aids in assessing the effectiveness of various prediction systems. True positives (TP) are 
drug side effects that have been recognized appropriately, False positives (FP) are adverse 
pharmacological effects that aren’t present but were detected by the model, and True nega-
tives (TN) are pharmacological side effects that do not exist but that the model failed to detect. 
False negatives (FN) are adverse pharmacological effects the model did not predict.
7  Drug dosing optimization
Drugs are vital to human health and choosing the proper treatment and dose for the right 
patient is a constant problem for clinicians. Even when taken as studied and prescribed, 
drugs have adverse impact profiles with varying response rates. As a result, all medications 
must be well-managed, especially those utilized in treating critical ailments or with a tight 
exposure window between efficacy and toxicity. Clinicians follow typical guidelines for 
the first dosage, which is not always optimal or secure for every patient, especially if the 
medicine no longer is evaluated in various dosages for various patient types. Precision dos-
age can revolutionize by increasing perks in health care while reducing drug therapy risks. 
While precise dosing will probably influence some pharmaceuticals significantly, perhaps 
not essential or practical to apply to all drugs or therapeutic classes. As a result, recogniz-
ing the characteristics that make medications suitable for precision dosage targets will aid 
in directing resources to where they’ll have the most impact. Precision-dosing meds with 
a high priority and therapeutic classes could be crucial in achieving increased health care 
performance, safety, and cost-effectiveness (Tyson et al. 2020).
Due to standard, fixed dosing procedures or gaps in knowledge, imprecise drug dosing 
in specific subpopulations increases the risk of potentiating adverse effects due to supra-
therapeutic or subtherapeutic concentrations (Watanabe et al. 2018). Currently, the Food 
and Medicine Administration (FDA) simply requires a drug to be statistically better than a 
non-inferior to placebo of the existing treatment standard. This does not guarantee that the 
medicine will benefit most patients in clinical trials, especially if malignancies treatment 
can be tough, like diffuse intrinsic pontine glioma (DIPG) and unresectable meningioma, 
where rates of therapy response can be exceedingly low (Fleischhack et al. 2019).
There are essential aspects for dose optimization (https://​frien​dsofc​ancer​resea​rch.​org/​
wpcon​tent/​uploa​ds/​Optim​izing_​Dosing_​in_​Oncol​ogy_​Drug_​Devel​opment.​pdf) that vary 
based on the product, the target population, and the available data to find the most effective 
dose, which varies based on the product, the target population, and the available data:
•	 Therapeutic properties: Drug features such as small molecule vs. large molecule and 
agonist vs. antagonist impact how drugs interact with the body regarding safety and 
efficacy. The therapeutic characteristics impact the first doses used in dose-finding 
studies and the procedures used to determine which doses should be used in registra-
tional trials.

## Page 35 (Section: 6 Evaluation metrics)

6009
Deep learning in drug discovery: an integrative review and future…
1 3
Table 4   The important metrics for drug discovery problems
Metrics
Description
Equations
Accuracy
It aids in determining the total number of side effects appropriately identified using 
the proposed technique
Accuracy = (TP + TN)/(TP + TN + FP + FN)
Sensitivity and specificity
The sensitivity metric aids in the identification of accurately identified positive 
samples. Specificity, on the other hand, detects the correctly established negative 
samples
Sensitivity = TP/(TP + FN), Specificity = TN/(TN + FP)
Precision
The precision metric essentially identifies the relevant cases among all the expected 
events. As a result, it can be defined as true side effects resulting from all of a given 
technique’s expected adverse effects
Precision = TP/(TP + FP)
Recall
The total number of real-life situations that have been discovered out of a total of 
accurate occurrences is referred to as recall
Recall = TP/(TP + FN)
F-measure
This statistic is used to assess a technique’s accuracy. Precision and recall’s harmonic 
mean can be defined as this
F-measure = 2 × ((precision × recall)/(precision + recall))
ROC curve and AUC score
The receiving operator characteristic (ROC) curve is used to evaluate a model’s per-
formance across a variety of criterion values. It contrasts the ratio of true positives 
to false positives at various threshold values
The area under the ROC curve is measured by the AUC value. It aids in the model’s 
proper evaluation because it is scale invariant and regardless of the value of the 
threshold
PR curve and AUPR value
Although AUC cure has been used to evaluate the efficacy of several pharmacologi-
cal Prediction models for side effects, most field-specific data sets are unbalanced, 
and the methodologies may exaggerate the AUC scores. As a result, the precision–
recall (PR) curve has been employed to assess performance. At various threshold 
points, it compares the value of precision to recall. In addition, The AUPR value is 
a summary of the PR value over a wide range of thresholds
Rate of predictions
The percentage of accurate projections and the frequency with which targets are 
missed have also been used to evaluate performance in some techniques
Rate of correct predictions = number of predictions/total 
number of experimentally known instances
Computational cost
The computational cost of a technology is defined as the overall time it takes to 
implement it on a given system. In most cases, it is measured in seconds

## Page 36 (Section: 6 Evaluation metrics)

6010
	
H. Askr et al.
1 3
Table 4   (continued)
Metrics
Description
Equations
Multilabel evaluation metrics Some research regard side effect prediction to be a multilabel classification problem, 
and thus use multilabel evaluation measures to assess performance. Hammering 
loss, one error, coverage, and ranking loss are some of the most widely utilized 
measures
Binding Affinity Score
Several assessment indicators can be used to examine it such as mean square error 
(MSE) and root mean square error (RMSE). These standards have been applied 
to rate the quality of the predictive QSAR model. The average squared difference 
between the predicted and actual scores for binding affinity is known as the MSE.
The RMSE is the squaredMSE, as the name implies

## Page 37 (Section: 8 Drug discovery and XAI)

6011
Deep learning in drug discovery: an integrative review and future…
1 3
•	 Patient populations: Patient demographics vary depending on tumour kind, stage of 
disease, and comorbidities. Understanding how diverse factors influence the drug’s 
efficacy may justify modifying the dose correspondingly, especially in the context of 
enlarged clinical trial populations.
•	 Supplemental versus original approval: Differences in disease features and patient 
demographics between tumour types and treatment settings, such as monotherapy ver-
sus combination therapy, must be considered when assessing whether additional dose 
exploration is required for a supplemental application. In cases when more dose explo-
ration is required, the research design can include previous exposure-response knowl-
edge from the initial approval.
8  Drug discovery and XAI
The topic of XAI addresses one of the most serious flaws in ML and DL algorithms: model 
interpretability and explain ability. Understanding how and why a prediction is formed 
becomes increasingly crucial as algorithms grow more sophisticated and can forecast with 
greater accuracy. It would be impossible to trust the forecasts of real-world AI applica-
tions without interpretability and explain ability. Human-comprehensible explanations will 
increase system safety while encouraging trust and sustained acceptance of machine learn-
ing technologies (). XAI has been studied to circumvent the limitations of AI technolo-
gies due to their black-box nature. In contrast to making decisions and model justifications 
which may be provided by AI approaches like DL and XAI (Zhang et al. 2022). Attention 
has been attracted to XAI approaches (Lipton 2018; Murdoch et al. 2019) to compensate 
for the lack of interpretability of some ML models as well as to aid human decision-making 
and reasoning (Goebel et al. 2018). The purpose of presenting relevant explanations along-
side mathematical models is to help students understand them better by (1) Making the 
decision-making process more transparent (Doshi-Velez and Kim 2017), (2) correct predic-
tions should not be made for the wrong motives (Lapuschkin et al. 2019), (3) avoid biases 
and discrimination that are unjust or unethical (Miller 2019), and (4) close the gap between 
ML and other scientific disciplines. Effective XAI can also help scientists in navigating the 
scientific process (Goebel et al. 2018), enabling people to fine-tune their understanding and 
opinions on the process under inquiry (Chander et al. 2018). We hope to provide an over-
view of recent XAI drug discovery research in this section.
XAI has a place in drug development. While the precise definition of XAI is still up for 
controversy (Guidotti et al. 2018), the following characteristics of XAI are unquestionably 
beneficial in applications of drug design (Lipton 2018):
•	 Transparency is accomplished by understanding how the system came to a specific 
result.
•	 The explanation of why the model’s response is suitable serves as justification. It is 
instructive to provide new information to human decision-makers.
•	 Determining the reliability of a prediction to estimate uncertainty.
The molecular explanation of pharmacological activity is already possible with XAI 
(Xu et al. 2017; Ciallella and Zhu 2019), as well as drug safety and organic synthesis plan-
ning (Dey et al. 2018). If It’s working overtime, XAI will be important in processing and 
interpreting increasingly complex chemical data, as well as creating new pharmaceutical

## Page 38 (Section: 8 Drug discovery and XAI)

6012
	
H. Askr et al.
1 3
ideas, all while preventing human bias (Boobier et  al. 2017). Application-specific XAI 
techniques are being developed to quickly reply to unique scientific issues relating to the 
Pathophysiology and biology of the human may be boosted by pressing drug discovery dif-
ficulties such as the coronavirus pandemic.
AI tools can increase their prediction performance by increasing model complexity. As 
a result, these models become opaque, with no clear grasp of how they operate. Because of 
this ambiguity, AI models are not generally utilized in important industries such as medi-
cal care. As a result, XAI focuses on understanding what goes into AI model prediction to 
meet the demand for transparency in AI tools. AI model interpretability approaches can 
be categorized depending on the algorithms used, a scale for interpreting, and the kind 
of information (Adadi and Mohammed 2018). Regarding the objectives of interpretabil-
ity, approaches grouped as white-box model development, black-box model explanation, 
model fairness enhancement, and predictive sensitivity testing (Guidotti et al. 2018).
According to the gradient-based attribution technique (Simonyan et al. 2014), the net-
work’s input features are to blame for the forecast. Because this strategy is commonly 
employed when producing a DNN system’s predictions, it may be a suitable solution for 
various black-box DNN models in DDI prediction (Quan, et al. 2016; Sun et al. 2018). In 
addition, DeepLIFT is a frequent strategy for implementing on top of DNN models that 
have been demonstrated to be superior to techniques based on gradients (Shrikumar et al. 
2017). As opposed to that, the Guided Backpropagation model may be used to construct 
network architectures (Springenberg 2015). A convolutional layer with improved stride can 
be used instead of max pooling in CNN to deal with loss of precision. This method could 
be employed in CNN-based DDI prediction, as shown in Zeng et al. (2015).
Furthermore, in the Tao et al. (2016) was implemented neural networks that parse natu-
ral language. Using rationales, this method aimed to achieve the small pieces of input text. 
This method’s design comprises two parts: a generator and an encoder that seek for text 
subsets that are closely connected to the predicted outcome. Because NLP-based models 
are used to extract DDIs (Quan et al. 2016), the above methods should be examined for 
usage in improving the model’s clarity.
Aside from that, XAI has created methods for developing white-box models, includ-
ing linear, decision tree, rule-based, and advanced but transparent models. However, these 
approaches are receiving less attention due to their weak ability to predict, particularly in 
the NLP-based sector, such as in the DDIs the job of extracting. Several ideas to address 
AI fairness have also been offered. Nonetheless, while extracting DDIs, only a small num-
ber of these scholarly studies looked at non-tabular data impartiality, such as text-based 
data. Many DDIs experiments used the word embedding method (Quan et al. 2016; Zhang 
2020; Bolukbasi 2016). As a result, attempts to ensure fairness in DDI research should be 
considered more. To ensure the reliability of AI models, numerous methods also make an 
effort to examine the sensitivity of the models. Regarding their Adversarial Example-based 
Sensitivity Analysis, Zügner et al. (2018) used this model to explore graph-structured data. 
The technique looks at making changes to links between nodes or node properties to tar-
get node categorization models. Because graph-based methods are frequently utilized in 
DDIs research (Lin et al. 2021; Sun et al. 2020b), methods like those used in the previous 
study suggest that they might be used in a DDIs prediction model. In RNN, word embed-
ding perturbations (Miyato et al. 1605) are also worth addressing. Significantly, the input 
reduction strategy utilized by Feng et al. (2018) to expose hypersensitivity in NLP mod-
els could be applied to DDI extraction studies. The DDIs study of Schwarz et al. (2021) 
attempted to provide model interpretability using Attention ratings derived at all levels of 
modeling in their DDIs study. The significance of similarity matrices to the vectors for

## Page 39 (Section: 8 Drug discovery and XAI)

6013
Deep learning in drug discovery: an integrative review and future…
1 3
medication depiction is determined using these scores, and drug properties that contribute 
to improved encoding are identified using these scores. This method makes use of data that 
travels through all tiers of the network.
Graph neural networks (GNNs) and their explain ability are rapidly evolving in the field 
of graph data. GNNExplainer in Ying et al. (2019) uses mask optimization to learn soft 
masks for edge and node attributes to elaborate on the forecasts. Soft masks have been 
initiated at random and regarded as trainable variables. After that, the masks are then 
combined in comparison to the first graph using multiplications on a per-element basis by 
GNNExplainer. After that, by enhancing the exchange of information between the forecasts 
from the first graph and the recently acquired graph, the masks are maximized. Even when 
various regularization terms, such as element-by-element entropy, motivate optimal dis-
guises for stealth, the resulting Masks remain supple.
In addition, because the masks are tuned for each input graph separately, it’s possible 
that the explanations aren’t comprehensive enough. To elaborate on the forecasts, PGEx-
plainer (Luo et al. 2020) discovers approximated discrete edge masks. To forecast edge 
masks, it develops a mask predictor that is parameterized. It starts by concatenating node 
embeddings to get the embeddings for each edge in an input graph. The predictor then 
forecasts the chances of each edge being selected using the edge embeddings, that regarded 
as an evaluation of significance. The reparameterization approach is then used to sample 
the approximated discrete masks. Finally, the mutual information between the previous 
and new forecasts is optimized to train the mask predictor. GraphMask (Schlichtkrull et al. 
2010) describes the relevance of edges in each GNN layer after the fact. It uses a classifier, 
like the PGExplainer, to forecast if an edge may be eliminated and does not impact the 
original predictions. A binary concrete distribution (Louizos et al. 1712) and a reparam-
eterization method are used to roughly represent separate masks. The classifier is addition-
ally trained by removing a term for a difference, which evaluates the difference between 
network predictions over the entire dataset. ZORRO (Thorben et al. 2021) employs discrete 
masks to pinpoint key input nodes and characteristics. A greedy method is used to choose 
nodes or node attributes from an input network. ZORRO chooses one node characteristic 
with the greatest fidelity score for each stage. The objective function, fidelity score, meas-
ures the degree of the recent forecasts resemble the model’s original predictions by replac-
ing the rest of the nodes/features with random noise values and repairing chosen nodes/
features. The non-differentiable limitation of discrete masks is overcome because no train-
ing process is used.
Furthermore, ZORRO avoids the problem of "introduced evidence" by wearing protec-
tive masks. The greedy mask selection process, on the other hand, may result in optimal 
local explanations. Furthermore, because masks are generated for each graph separately, 
the explanations may lack a global understanding. Causal Screening (Xiang et al. 2021) 
investigates the attribution of causality to various edges in the input graph. It locates the 
explanatory subgraph’s edge mask. The essential concept behind causal attribution is to 
look at how predictions change when an edge is added to the present explanatory subgraph, 
called the influence of causality. It examines the causal consequences of many edges at 
each step and selects one to include in the paragraph. It selects edges using the individual 
causal effect (ICE), which assesses the difference in information between parties after addi-
tional edges are introduced to the subgraph.
Causal Screening, like ZORRO, is a rapacious algorithm that generates undetectable 
masks without any prior training. As a result, it does not suffer due to the issue of the evi-
dence presented. However, it is possible to lack worldwide comprehension and be caught 
in optimum local explanations. SubgraphX (Yuan et  al. 2102) investigates deep graph

## Page 40 (Section: 9 Success stories about using DL in drug discovery)

6014
	
H. Askr et al.
1 3
model subgraph-level explanations. It uses the Monte Carlo Tree Search (MCTS) method 
(Silver et  al. 2017) to effectively investigate various subgraphs by trimming nodes and 
choose the most significant subgraph from the search tree’s leaves as the explanation for 
the prediction.
Furthermore, the Shapley values can be used to update the mask generation algorithm’s 
objective function. Its produced subgraphs are more understandable by humans and suited 
for graph data than previous perturbation-based approaches. However, the computational 
cost is higher because the MCTS algorithm explores distinct subgraphs.
9  Success stories about using DL in drug discovery
Big pharmaceutical companies have migrated toward AI as DL methodologies have 
advanced, abandoning conventional approaches to maximize patient and company profit. 
AstraZeneca is a multinational, science-driven, worldwide pharmaceutical company that 
has successfully used artificial intelligence in each stage of drug development, from virtual 
screening to clinical trials. They could comprehend current diseases better, identify new 
targets, plan clinical trials with higher quality, and speed up the entire process by incor-
porating AI into medical science. AstraZeneca’s success is a shining illustration of how 
combining AI with medical science can yield incredible results. Their collaborations with 
other AI-based companies demonstrate their continual attempts to increase AI utilization. 
One such cooperation is with Ali Health, an Alibaba subsidiary that wants to provide AI-
assisted screening and diagnosis systems in China (Nag et al. 2022).
SARS-CoV-2 virus outbreak placed many businesses under duress to develop the best 
medicine in the shortest amount of time feasible. These businesses have turned to employ 
AI in conjunction based on the data available to attain their goals. Below are some exam-
ples of firms that have been successful in identifying viable strategies to combat the 
COVID-19 virus because of their efforts.
Deargen, a South Korean startup, developed the MT-DTI (Molecule Transformer Drug 
Target Interaction Model), a DL-based drug-protein interaction prediction model. In this 
approach, the strength of an interaction between a drug and its target protein is predicted 
using simplified chemical sequences rather than 2D or 3D molecular structures. A critical 
protein on the COVID-19-causing virus SARS-CoV-2 is highly likely to bind to and inhibit 
the FDA-approved antiviral drug atazanavir, a therapy for HIV. It also discovered three 
more antivirals, as well as Remdesivir, a not-yet-approved medicine that is currently being 
studied in patients. Deagen’s ability to uncover antivirals utilizing DL approaches is a sig-
nificant step forward in pharmaceutical research, making it less time-consuming and more 
efficient. If such treatments are thoroughly evaluated, there is a good chance that we will be 
able to stop the epidemic in its tracks (Beck et al. 2020; Scudellari 2020).
Another example is Benevolent AI, a biotechnology company in London leverages med-
ical information, AI, and machine learning to speed up health-related research. They’ve 
identified six medicines so far, one of which, Ruxolitinib, is claimed to be in clinical trials 
for COVID19 (Gatti et al. 2021). To find prospective medications that might impede the 
procedure for viral replication of SARS-CoV-2, The business has been utilizing a massive 
reservoir of information pertaining to medicine, together Utilizing data obtained from the 
scientific literature by their AI system and ML. They received FDA permission to use their 
planned Baricitinib medication in conjunction with Remdesivir, which resulted in a higher 
recovery rate for hospitalized COVID19 patients (Richardson et al. 2020).

## Page 41 (Section: 10 Future challenges)

6015
Deep learning in drug discovery: an integrative review and future…
1 3
Skin cancer is a form of cancer that is very frequent around the globe. As the rate at 
which skin cancer continues to rise, it is becoming increasingly crucial to diagnose it ini-
tially developed, research demonstrate that early identification and therapy improve the 
survival rate of skin cancer patients. With the advancement of medical research and AI, 
several skin cancer smartphone applications have been introduced to the market, allowing 
people with worrisome lesions to use a specialized technique to determine whether they 
should seek medical care. According to studies, over 235 dermatology smartphone apps 
were developed between 2014 and 2017 (Flaten et al. 2020). Previously, they worked by 
sending a snapshot of the lesion over the internet to a health care provider. Still, thanks to 
smartphones’ internal AI algorithms, these applications can detect and classify images of 
lesions as high or low risk and Immediately assess the patient’s risk and offer advice. Skin-
Vison (Carvalho et al. 2019) is an example of a successful application.
10  Future challenges
10.1  Digital twinning in drug discovery
The development and implementation of Industry 4.0 emerging technologies allow for 
creation of digital twins (DTs), that promotes the modification of the industrial sector 
into a more agile and intelligent one. A DT is a digital depiction of a real entity that 
interacts in dynamic, two-way links with the original. Today, DTs are being used in a 
variety of industries. Even though the pharmaceutical sector has grown to accept digi-
tization to embrace Industry 4.0, there is yet to be a comprehensive implementation of 
DT in pharmaceutical manufacture. As a result, it is vital to assess the pharmaceutical 
industry’s success in applying DT solutions (Chen et al. 1088).
New digital technologies are essential in today’s competitive marketplaces to pro-
mote innovation, increase efficiency, and increase profitability (Legner et al. 2017). AI 
(Venkatasubramanian 2019), Internet of Things (IoT) devices (Venkatasubramanian 
2019; Oztemel and Gursev 2018), and DTs have all piqued the interest of governments, 
agencies, academic institutions, and corporations (Bao et  al. 2018). Industry 4.0 is a 
concept offered by a professional community to increase the level of automation to 
boost productivity and efficiency in the workplace.
This section provides a quick look at the evolution of DT and its application in phar-
maceutical and biopharmaceutical production. We begin with an overview of the tech-
nology’s principles and a brief history, then present various examples of DTs in phar-
macology and drug discovery. After then, there will be a discussion of the significant 
technical and other issues that arise in these kinds of applications.
10.1.1  History and main concepts of digital twin
The idea of making a "twin" of a process or a product returned to NASA’s Apollo pro-
ject in the late 1960s (Rosen et al. 2015; Mayani et al. 2018; Schleich et al. 2017), when 
it assembled two identical space spacecraft. In this scenario, the "twin" was employed to 
imitate the counterpart’s action in real-time.
The DT, according to Guo et al. (2018), is a type of digital data structure that is gen-
erated as a separate entity and linked to the actual system. Michael Grieves presented

## Page 42 (Section: 10.1.2 Digital twin in pharmaceutical manufacturing)

6016
	
H. Askr et al.
1 3
the original meaning of a DT in 2002 at the University of Michigan as part of an indus-
try presentation on product lifecycle management (PLM) (Grieves 2014; Grieves and 
Vickers 2017; Stark et  al. 2019). However, the first actual use of this notion, which 
gave origin to the current moniker, occurred in 2010, when NASA (the United States 
National Aeronautics and Space Administration) attempted to create virtual spaceship 
simulators for testing (Glaessgen and Stargel 2012).
A digital reproduction or representation of a physical thing, process, or service is 
what a DT is in theory. It’s a computer simulation with unique features that dynamically 
connect the physical and digital worlds. The purpose of DTs is to model, evaluate, and 
improve a physical object in virtual space til it matches predicted performance, at which 
time it can be created or enhanced (if already built) in the real world (Kamel et al. 2021; 
Marr 2017).
Since then, DT technology has acquired popularity in both business and academia. 
Main components of DTs presently exist, as shown in Fig.  14. Still, the theoretical 
model comprises three parts: the real entity in the actual world, the digital entity in the 
virtual space, and the interconnection between them (Glaessgen and Stargel 2012).
In an ideal world, the digital component would have all the system’s information that 
could be acquired from its physical counterpart (Kritzinger et al. 2018). When integrated 
with AI, IoT, and other recent intelligent systems, a DT can forecast how an object or pro-
cess will perform.
10.1.2  Digital twin in pharmaceutical manufacturing
Developing a drug is lengthy and costly, requiring efforts in biology, chemistry, and manu-
facturing, and it has a low success rate. An estimated 50,000 hits (trial versions of com-
pounds that are subsequently tweaked to develop a medication in the future) are evaluated 
to develop a successful drug. Only one in every 12 therapeutic compounds, clinical trials 
have been performed on humans, makes it to market successfully. Toxicity (A medication’s 
capacity to offer a patient with respite and slow the progression of a disease) and lack of 
effectiveness contribute to more than 60% of all drug failures (Subramanian 2020).
Making the appropriate decisions about which targets, hits, leads, and compounds to 
pursue is important to a drug’s successful market introduction. However, the decision is 
based on in vitro (Experimental system in a test tube or petri dish.) and in vivo (experi-
ments in animals.) systems, both of which have a shaky correlation with clinical outcomes 
(Mak et al. 2014). Answers to the following inquiries would be provided by a perfect deci-
sion support system for drug discovery:
•	 What is the magnitude of any target’s influence on the desired clinical result?
•	 Is the potential compound changing the target enough to change clinical outcomes?
•	 Is the chemical sufficiently selective and free of side effects or harmful conse-
quences?
•	 Is the ineffectiveness attributable to the drug’s failure to reach its target?
•	 Has the trial chosen the appropriate dose and dosing regimen?
•	 Are there any surrogate or biomarkers such as cholesterol that serves as a proxy for the 
illness’s root cause that can forecast a drug’s success or failure?
•	 Have the correct patients been chosen for the study?
•	 Is it possible to identify hyper- and hypo-responders before the study begins?

## Page 43 (Section: 10.1.2 Digital twin in pharmaceutical manufacturing)

6017
Deep learning in drug discovery: an integrative review and future…
1 3
Therapeutic failures are prevalent and difficult to address, given the complex process of 
developing drugs based on the points above. This issue must be addressed by combining 
data and observations from many stages of the drug development process and develop-
ing a system that can forecast an experiment’s outcome or a chemical modification’s influ-
ence on a therapeutic molecule. This highlights the significance of DT in the field of drug 
discovery.
In the United States, funding organizations such as DARPA, NSF, and DOE have 
aggressively supported bioprocess modeling at the genomic and cellular levels, resulting 
in high-profile programs such as BioSPICE (Kumar and Feidler 2003). These groups have 
shown that smaller models built to answer specific issues can greatly influence drug devel-
opment efficiency. This would make it possible to apply the prediction methodology to 
various stages of the drug discovery and research process, including confirmation of the 
target, enhancing leads, and choosing candidates, Recognition of biomarkers, fabrication of 
assays and screens, and the improvement of clinical trials.
The pharmaceutical business is embracing the overall digitization trend in tandem with 
the US FDA’s ambition to establish an agile, adaptable pharmaceutical manufacturing sec-
tor that delivers high-quality pharmaceuticals without considerable regulatory scrutiny 
(O’Connor et al. 2016). Industries are beginning to implement Industry 4.0 and DT prin-
ciples and use them for development and research (Barenji et al. 2019; Steinwandter et al. 
2019; Lopes et al. 2019; Kumar et al. 2020; Reinhardt et al. 2020). Pharma 4.0 (Ierapetri-
tou et al. 2016) is a digitalization initiative that integrates Industry 4.0 with International 
Council for Harmonisation (ICH) criteria to model a combined operational model and pro-
duction control plan.
Fig. 14   Main components of DT

## Page 44 (Section: 10.1.3 Digital twin in biopharmaceutical manufacturing)

6018
	
H. Askr et al.
1 3
As shown in Fig. 15, live monitoring of the system `by the Process Analytical Tech-
nology (PAT), data collection from the machinery, the supplementary and finished goods, 
and a worldwide modelling and software for data analysis are some of the key require-
ments for achieving smart manufacturing with DT (Barenji et al. 2019). Quality-by-Design 
(QbD) and Continuous Manufacturing (CM) (Boukouvala et al. 2012), flowsheet modeling 
(Kamble et al. 2013), and PAT implementations (James et al. 2006) have all been used by 
the pharmaceutical industry to achieve this. Although some of the instruments have been 
thoroughly examined, DTs’ entire integration and development is still a work in progress.
The pharmaceutical industry has used PAT in different programs across the steps 
involved in producing drugs (Nagy et al. 2013). Even though this has resulted in a rise in 
the use of PAT instruments, their implementations are limited to research and development 
rather than manufacturing on a large scale (Papadakis et al. 2018). They have been success-
ful in decreasing production costs and enhancing product quality monitoring in the small 
number of examples where they have been used in manufacturing (Simon et al. 2019). The 
development of various PAT approaches, as well as their convincing implementation is a 
vital component of a scheme for surveillance and control (Boukouvala et al. 2012) and has 
given a foundation for obtaining essential data from the physical component.
Papadakis et  al. (2018) recently provided a framework for identifying efficient reac-
tion paths for pharmaceutical manufacture (Rantanen and Khinast 2015), which comprises 
modeling reaction route workflows discovery, analysis of reactions and separations, pro-
cess simulation, assessment, optimization, and the use (Sajjia et al. 2017).
To develop models, data-driven modeling methods require the gathering and using of 
many substantial experiments, and the resulting models are solely reliant on the datasets 
provided. Artificial neural networks (ANN) (Pandey et al. 2006; Cao et al. 2018), multivar-
iate statistical analysis, and in Monte Carlo Badr and Sugiyama (2020) are all commonly 
used in pharmaceutical manufacturing. These methods are less computationally costly, 
but the prediction outside the dataset space is frequently unsatisfactory due to the trained 
absence of underlying physics understanding in models. Using IoT devices in pharmaceuti-
cal manufacturing lines results in massive data collection volumes. The virtual component 
must receive this collection of process data and CQAs quickly and effectively. Addition-
ally, for accurate prediction, several pharmaceutical process models need material proper-
ties. As a result, to provide virtual component access to all datasets, a central database site 
is necessary (Lin-Gibson and Srinivasan 2019).
10.1.3  Digital twin in biopharmaceutical manufacturing
The synthesis of big molecule-based entities in various combinations that has applications 
in the treatment of inflammatory, microbial, and cancer issues, is the focus of biopharma-
ceutical manufacturing (Glaessgen and Stargel 2012; Narayanan et al. 2020). The demand 
for biologic-based medications has risen in recent years, necessitating greater production 
efficiency and efficacy (Kamel et al. 2021). As a result, many businesses are switching 
from batch to continuous production and implementing intelligent manufacturing systems 
(Lin-Gibson and Srinivasan 2019). DT can aid in decision-making, risk analysis, product 
creation, and process prediction., which incorporates the physical plant, data collecting, 
data analysis, and system control (Tao et al. 2018).
biological products’ components and structures are intimately connected to treatment effec-
tiveness (Read et al. 2010) and are very sensitive to cell-line. Operating conditions thorough

## Page 45 (Section: 10.2 AI-driven digital twins in today’s pharmaceutical drug discovery)

6019
Deep learning in drug discovery: an integrative review and future…
1 3
actual plant’s virtual description in a simulation environment is required to apply DT in biop-
harmaceutical manufacturing (Tao et al. 2018). This means that each unit activity inside an 
integrated model’s simulation should accurately reflect the crucial process dynamics. Previous 
reviews Narayanan et al. (2020) Tang et al. (2020) Farzan et al. (2017) Baumann and Hubbuch 
(2017) Smiatek et al. (2020) and Olughu et al. (2019) focused on process modelling method-
ologies for both upstream and downstream operations.
Data from a biopharmaceutical monitoring system is typically diverse regarding data kinds 
and time scales. A considerable amount of data is collected during biopharmaceutical manu-
facture thanks to the deployment of real-time PAT sensors. As a result, data pre-processing is 
required to deal with missing data, visualize data, and reduce dimensions (Gangadharan et al. 
2019). In batch biopharmaceutical production, Casola et al. (2019) presented data mining-
based techniques for stemming, classifying, filtering, and clustering historical real-time data. 
Lee et al. (2012) combined different spectroscopic techniques and used data fusion to forecast 
the composition of raw materials.
10.2  AI‑driven digital twins in today’s pharmaceutical drug discovery
In the pharmaceutical industry, challenges are emerging from clinical studies that make drug 
development incomplete, sluggish, uncertain, and maybe dangerous. For example, It is not a 
true reflection of reality where clinical trials can take into account that in the real world, just a 
small portion of a big and diverse population is depicted among the many billions of humans 
on the planet where it is not possible to get a view of how each person based on how they will 
respond to a medicine. Clinical trials’ rigorous requirements for physical and mental health 
in some cases also result in failure because of a lack of qualified participants. Pharmaceutical 
firms battle to provide the precise number and kind of participants needed to comply with the 
stringent requirements of clinical trial designs. Also, in most trials, the actual drug is replaced 
by a placebo as this helps contrast how sick individuals behave when they are not adminis-
tered the experimental medication; This implies that at least some trial participants do not 
receive it. Here, These issues can be solved by using digital twins, which can imitate a range 
of patient features, giving a fair representation of how a medicine affects a larger population. 
AI-enabled digital twinning may reduce the trial’s setup by revealing how susceptible a patient 
Smart manufacturing with DT 
PAT methods
Process modelling
Data integeration
Fig. 15   Main categories of smart manufacturing with DT

## Page 46 (Section: 11 Open problems)

6020
	
H. Askr et al.
1 3
is to various inclusion and exclusion criteria as a result, patients can be rapidly identified, and 
digital twins can predict a patient’s reaction, and placebos won’t be required. Therefore, the 
new treatment can be assured for every patient in the trial, and digital twins can reduce the 
dangerous impact of drugs in the early stages by decreasing the number of patients who need 
to be tested in the real world. Figure 16 illustrates a framework by running all possible combi-
nations. All treatment protocols are tested on a digital twin of the patient to discover an appro-
priate treatment protocol for this patient. Doing this quickly and accurately can lead to provid-
ing the best quality treatment for the patient without experimenting with the patient, which 
saves effort, cost, and accuracy in determining an appropriate treatment protocol for patients.
11  Open problems
This section discusses important issues to consider regarding progression from preclinical 
to clinical and implementation in practice that necessitate new ML solutions to assist trans-
parent, usable, and data-driven decision-making procedures to accelerate drug discovery 
and decrease the number of failures in clinical development phases.
–	 Complex disorders, such as viral infections and advanced malignancies frequently 
necessitate drug combinations (Julkunen et al. 2020; White et al. 2021). For example, 
kinase inhibitor combos or single compounds that block several kinases may improve 
therapeutic efficacy and duration while combating treatment resistance in cancer 
(Attwood et al. 2021). While several ML models have been created to predict response 
pairs of drug–dose combinations, higher-order combination effects can be predicted in 
a systematic way involving more than two medicines or targets is still a problem. In 
cancer cell lines, tensor learning methods have permitted reliable prediction of paired 
drug combination dose-response matrices (Smiatek et  al. 2020). This computation-
ally efficient learning approach could use extensive pharmacogenomic data, determine 
which drug combinations are most successful for additional in vitro or in vivo testing 
in many kinds of preclinical models, such as higher-order combinations among novel 
therapeutic compounds and doses.
–	 While possible toxicity and effectiveness that is targeted are important criteria for clini-
cal development success, most existing ML models for predicting response to the ther-
apy accentuate effectiveness as the primary result. As a result, careful examination, and 
harmful effects prediction of instances in simulated and preclinical settings is required 
to strike a balance between the effectiveness of the toxicity and therapy that is accept-
able to accelerate the next stages of drug development (Narayanan et al. 2020). Apply-
ing single-cell data and ML algorithms to develop combinations of anticancer drugs 
has shown the potential to boost the likelihood of clinical success (Tao et al. 2018). 
Transfer of knowledge and deconvolution techniques for in silico cell set (Avila et al. 
2020) may offer effective ways to reduce the requirement to generate a lot of single-cell 
data to predict combination therapy responders and impacts of toxicity, as well as the 
recommended dosage that optimizes both efficacy and safety.
–	 In addition, patient data and clinical profiles must be used to validate the in-silico 
therapy response forecasts. This real data for ML predictions is crucial for progress in 
medicine and establishing the practical value and providing clinical guidance in making 
decisions. A no-go decision was made early, for example, if the substance has harmful 
consequences. Many of the present issues encountered when using machine learning

## Page 47 (Section: 11 Open problems)

6021
Deep learning in drug discovery: an integrative review and future…
1 3
for drug discovery, particularly in clinical development, are since current AI algorithms 
do not meet the requirements for clinical research. As a result, ML model validation 
requires systematic and comprehensive high-quality clinical data sets. The discovery 
methods must be thoroughly evaluated for accuracy and reproducibility using com-
munity-agreed performance measures in various settings, not just a small collection of 
exemplary data sets. sharing and exploiting private patient information is possible with 
systems that isolate the code from the data or use the model to data method (Guinney 
and Saez-Rodriguez 2018), which It makes it possible for federated learning to utilise 
patient-level data for model construction and thorough assessment.
–	 Even if there are many applications for drug discovery, The majority of ML and par-
ticularly DL models remain "black boxes”, and interpretation by a human specialist is 
sometimes tricky (Jiménez-Luna et al. 2020). Implementing mathematical models as 
online decision support tools must be understandable to users to obtain confidence. 
Comprehensible, accessible, and explainable models should clearly state the optimiza-
tion goals, such as synergy, efficacy, and/or toxicity.
–	 DTI prediction is a notable example of fields of drug discovery research. It has been 
ongoing more than 10 years and aims to enhance the effectiveness of computational 
models using various technologies. The most recent computational approaches for pre-
dicting DTIs are DL technologies. These use unstructured-based approaches that don’t 
need 3D structural data or docking to get over the drug and target protein’s high-dimen-
sional structure restrictions. Despite the DL’s outstanding performance, regression 
inside the DTI prediction remains a critical and difficult issue, and researchers could 
develop several strategies to improve prediction accuracy. Furthermore, data scarcity 
and the lack of a standardized benchmark database are still considered current research 
gaps.
Fig. 16   AI-driven digital twins in today’s pharmaceutical drug discovery

## Page 48 (Section: 12 Discussion)

6022
	
H. Askr et al.
1 3
–	 While DL approaches show promise in detecting drug responses, especially when deal-
ing with large amounts of data, drug response prediction research is in its first stages, 
and more efficient and relevant models are needed.
–	 While DL techniques have shown to be effective in detecting DDIs, especially when 
dealing with large amounts of data, more promising algorithms that focus on complex 
molecular reactions need to be developed.
–	 Only a few studies in the drug discovery field have investigated their models’ explain 
ability, leaving much room for improvement. The explanations generated by XAI for 
human decision-making must be not insignificant, not artificial, and helpful to the 
scientific community. Until now, ensuring that XAI techniques achieve their goals 
and produce trustworthy responses would necessitate a combined effort amongst DL 
specialists, chemo informaticians and chemists, biologists, data scientists, and other 
subject matter experts. As a result, we believe that more developed methodologies to 
explain black-box models for drug discovery fields like DDIs, drug–target interactions, 
drug sensitivity, and drug side effects must be considered in the future to ensure model 
fairness or strict sensitivity evaluations of models. Further exploration of the capabili-
ties and constraints of the existing chemical language for defining these models will be 
critical. The development of novel interpretable molecular representations for DL and 
the deployment of self-explanatory algorithms alongside sufficiently accurate predic-
tions will be a critical area of research in the coming years. Because there are currently 
no methods that combine all the stated advantageous XAI characteristics (transpar-
ency, justification, informativeness, and uncertainty estimation), consensus techniques 
that draw on the advantages of many XAI approaches and boost model dependability 
will play a major role in the short and midterm. Currently, there is no open-community 
platform for exchanging and refining XAI software and model interpretations in drug 
discovery. As a result, we believe that future study into XAI in drug development has 
much potential.
12  Discussion
This section presents a brief about how the proposed analytical questions in Sect. 2 are 
being answered through the paper.
–	 AQ1: What DL algorithms have been used to predict the different categories of drug 
discovery problems?
	
  Several DL algorithms have been used to predict the different categories of drug dis-
covery problems as deeply illustrated in Sect. 4 with respect to the main categories of 
drug discovery problems in Fig. 8. In addition, a summary of a sample of these algo-
rithms, their methods, advantages and weaknesses are presented in Table 2.
–	 AQ2: Which deep learning methods are mostly used in drug dosing optimization?
	
  Recognizing the characteristics that make medications suitable for precision dosage 
targets will aid in directing resources to where they’ll have the most impact. Employing 
DL in drug dosing optimization is a big challenge which increases the health care per-
formance, safety, and cost-effectiveness as presented in Sect. 7.
–	 AQ3: Are there any success stories about drug discovery and DL?
	
  With the advancement of DL methods, we’ve seen big pharmaceutical businesses 
migrate toward AI, such as ‘AstraZeneca’ which is a global multinational pharmaceuti-

## Page 49 (Section: 13 Conclusion)

6023
Deep learning in drug discovery: an integrative review and future…
1 3
cal business that has successfully used AI in every stage of drug development. Several 
success stories have been presented in Sect. 9.
–	 AQ4: What about using the newest technologies such as XAI and DT in drug discovery?
	
  The topic of XAI addresses one of the most serious flaws in ML and DL algorithms: 
model interpretability and explain ability. It would be impossible to trust the forecasts 
of real-world AI applications without interpretability and explain ability. Section 8 pre-
sents the literature that address this issue. A digital twin (DT) is a virtual representation 
of a living thing that is connected to the real thing in dynamic, reciprocal ways. Today, 
DTs are being used in a variety of industries. Even though the pharmaceutical sector 
has grown to accept digitization to embrace Industry 4.0, there is yet to be a compre-
hensive implementation of DT in pharmaceutical manufacture. Success stories regard-
ing employing DT into drug discovery is presented in Sect. 10.
–	 AQ5: What are the future and open works related to the drug discovery and DL?.
	
  Through the paper, we present how DL succeed in all aspects of drug discovery 
problems, However, it is still a very important challenge for future research. Section 11 
covers these challenges.
Figure  17 presents the percentage of the different DL applications for each building 
block of our study. It is well observed that the most percentage segment is dedicated for the 
drug discovery and DL because it is the main core of our research.
13  Conclusion
Despite all the breakthroughs in pharmacology, developing new drugs still requires a lot of 
time and costs. As DL technology advances and the amount of drug-related data grows, a 
slew of new DL-based approaches is cropping up at every stage of the drug development 
process. In addition, we’ve seen large pharmaceutical corporations migrate toward AI in 
the wake of the development of DL approaches.
Although the drug discovery is a large field and has different research categories, there 
is a few review studies about this field and each related study has focused only on a one 
research category such as reviewing the DL applications for the DTIs. So, the main goal of 
our research is to present a systematic Literature review (SLR) which integrates the recent 
DL technologies and applications for the different categories of drug discovery problems 
Including, Drug–target interactions (DTIs), drug–drug similarity interactions (DDIs), drug 
sensitivity and responsiveness, and drug-side effect predictions. That is associated with the 
benchmark data sets and databases. Related topics such as XAI and DT and how they sup-
port the drug discovery problems are also discussed. In addition, the drug dosing optimiza-
tion and success stories are presented as well. Finally, we suggest open problems as future 
research challenges.
Although the DL has proved its strength in drug discovery problems, it is still a promis-
ing open research area for the interested researchers. In this paper, they can find all they 
want to know about using DL in various drug discovery problems. In addition, they can 
find success stories and open areas for future research.
Given the recent success of DL approaches and their use by pharmaceuticals in identify-
ing new medications, it seems clear that current DL techniques being highly regarded in 
the next generation of enormous data investigation and evaluation for drug discovery and 
development.

## Page 50 (Section: References)

6024
	
H. Askr et al.
1 3
Author contributions  Ask wrote the main text, HA wrote the digital twining part, EE wrote the deep learn-
ing part, YAMME wrote the data sets part, MMG wrote the similarly part, AEH, suggest the idea of the 
review and supervision
Funding  Open access funding provided by The Science, Technology & Innovation Funding Authority 
(STDF) in cooperation with The Egyptian Knowledge Bank (EKB).
Declarations 
Competing interests  The authors declare no competing interests.
Open Access  This article is licensed under a Creative Commons Attribution 4.0 International License, 
which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long 
as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Com-
mons licence, and indicate if changes were made. The images or other third party material in this article 
are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the 
material. If material is not included in the article’s Creative Commons licence and your intended use is not 
permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly 
from the copyright holder. To view a copy of this licence, visit http://​creat​iveco​mmons.​org/​licen​ses/​by/4.​0/.
References
Abramovich I, Ben-Yehuda T, Cohen R (2018) Low-complexity video classification using recurrent neu-
ral networks. IEEE Int Conf Sci Electr Eng Israel (ICSEE) 2018:1–4. https://​doi.​org/​10.​1109/​ICSEE.​
2018.​86460​76
Adadi A, Mohammed B (2018) Peeking inside the black-box: a survey on explainable artificial intelligence 
(XAI). IEEE Access 6:2169–3536
Ahmed KT, Park S, Jiang Q et al (2020) Network-based drug sensitivity prediction. BMC Med Genomics 
13:193
Drug discovery and 
DL
Datasets, 
Databases and 
Metrics 
Drug dose 
opmizaon
Drug discovery and 
XAI
Success Stories
Future Challenges 
and Digital Twin
Fig. 17   Percentages of DL applications for each category

## Page 51 (Section: References)

6025
Deep learning in drug discovery: an integrative review and future…
1 3
Alankrita A, Mamta M, Gopi B (2021) Generative adversarial network: an overview of theory and applica-
tions. Int J Inf Manag Data Insights 1(1):100004
Amashita R, Nishio M, Do RKG et al (2018) Convolutional neural networks: an overview and application in 
radiology. Insights Imaging 9:611–629. https://​doi.​org/​10.​1007/​s13244-​018-​0639-9
Andreea D, Yu-Hsiang H, Petar V, Pietro L, Jian T (2019) Drug–drug adverse effect prediction with graph 
co-attention. https://​arxiv.​org/​abs/​1905.​00534
Arshed MA, Mumtaz S, Riaz O, Sharif W, Abdullah S (2022) A deep learning framework for multi drug 
side effects prediction with drug chemical substructure. Int J Innovat Sci Technol 4(1):19–31
Arus-Pous J, Patronov A, Bjerrum EJ, Tyrchan C, Reymond JL, Chen H, Engkvist O (2020) SMILES-based 
deep generative scaffold decorator for de-novo drug design. J Cheminform 12:1–18
Asada M, Miwa M, Sasaki Y (2018) Enhancing drug–drug interaction extraction from texts by molecular 
structure information. In: proceedings of the 56th annual meeting of the association for computational 
linguistics. 2, pp 680–685, https://​doi.​org/​10.​18653/​v1/​P18-​2108
Ashburner M, Ball CA, Blake JA, Botstein D, Butler H, Cherry JM, Davis AP, Dolinski K, Dwight SS, 
Eppig JT et al (2000) Gene ontology: tool for the unification of biology. Nat Genet 25:25–29
Attwood MM, Fabbro D, Sokolov AV et al (2021) Trends in kinase drug discovery: targets, indications and 
inhibitor design. Nat Rev Drug Discov 20(11):839–861
Avila C, Alquicira-Hernandez J, Powell JE et al (2020) Benchmarking of cell type deconvolution pipelines 
for transcriptomics data. Nat Commun 11(1):5650
Azad AKM, Dinarvand M, Nematollahi A, Swift J, Lutze-Mann L, Vafaee F (2021) A comprehensive 
integrated drug similarity resource for in-silico drug repositioning and beyond. Brief Bioinform 
22(3):bbaa126. https://​doi.​org/​10.​1093/​bib/​bbaa1​26
Badr S, Sugiyama H (2020) A PSE perspective for the efficient production of monoclonal antibodies: inte-
gration of process, cell, and product design aspects. Curr Opin Chem Eng 27:121–128
Bao J, Guo D, Li J, Zhang J (2018) The modelling and operations for the digital twin in the context of 
manufacturing. Enterp Inf Syst 13:534–556
Baptista D, Ferreira PG, Rocha M (2021) Deep learning for drug response prediction in cancer. Briefings 
Bioinform 22:360–379
Barenji RV, Akdag Y, Yet B, Oner L (2019) Cyber-physical-based PAT (CPbPAT) framework for Pharma 
4.0. Int J Pharm 567:118445
Baumann P, Hubbuch J (2017) Downstream process development strategies for effective bioprocesses: 
Trends, progress, and combinatorial approaches. Eng Life Sci 17:1142–1158
Beck BR, Shin B, Choi Y, Park S, Kang K (2020) Predicting commercially available antiviral drugs that 
may act on the novel coronavirus (SARS-CoV-2) through a drug–target interaction deep learning 
model. Comput Struct Biotechnol J 18:784–790
Bedi P, Sharma C, Vashisth P, Goel D, Dhanda M (2015) Handling cold start problem in Recommender 
Systems by using Interaction Based Social Proximity factor. In: Proceeding of the 2015 international 
conference on advances in computing, communications and informatics, Kerala, India, 10–13 August 
2015; pp 1987–1993
Benedek R, Stephen B, Andriy N, Michael U, Sebastian N, Eliseo P (2021) A unified view of relational 
deep learning for drug pair scoring. coRR V. https://​arxiv.​org/​abs/​2111.​02916.
Betsabeh T, Mansoor ZJ (2021) Using drug–drug and protein-protein similarities as feature vector for drug–
target binding prediction. Chemom Intell Lab Syst 217:104405. https://​doi.​org/​10.​1016/j.​chemo​lab.​
2021.​104405
Bleakley K, Yamanishi Y (2009) Supervised prediction of drug–target interactions using bipartite local 
models. Bioinformatics 25:2397–2403
Bolukbasi T (2016) Man is to computer programmer as woman is to homemaker? debiasing word embed-
dings. Advances in neural information processing systems, 2016; 29. In Identifying gender and sexu-
ality of data subjects. https://​cis.​pubpub.​org/​pub/​debia​sing-​word-​embed​dings-​2016.
Bongini P, Pancino N, Dimitri GM, Bianchini M, Scarselli F, Lio P (2022) Modular multi-source prediction 
of drug side-effects with DruGNN. http://​arxiv.​org/​abs/​2202.​08147.
Boobier S, Osbourn A, Mitchell JB (2017) Can human experts predict solubility better than computers? J 
Cheminform 9:63
Boukouvala F, Niotis V, Ramachandran R, Muzzio FJ, Ierapetritou MG (2012) An integrated approach for 
dynamic flowsheet modeling and sensitivity analysis of a continuous tablet manufacturing process. 
Comput Chem Eng 42:30–47
Brown AS, Patel CJ (2017) MeSHDD: literature-based drug-drug similarity for drug repositioning. J Am 
Med Inf Assoc 24(3):614–618
Camacho DM, Collins KM, Powers RK, Costello JC, Collins JJ (2018) Next-generation machine learning 
for biological networks. Cell 173:1581–1592

## Page 52 (Section: References)

6026
	
H. Askr et al.
1 3
Campillos M et al (2008) Drug target identification using side-effect similarity. Science 321(5886):263–666. 
https://​doi.​org/​10.​1126/​scien​ce.​11581​40
Cao H, Mushnoori S, Higgins B, Kollipara C, Fermier A, Hausner D, Jha S, Singh R, Ierapetritou M, 
Ramachandran R (2018) A systematic framework for data management and integration in a continu-
ous pharmaceutical manufacturing processing line. Processes 6:53
Casola G, Siegmund C, Mattern M, Sugiyama H (2019) Data mining algorithm for pre-processing biophar-
maceutical drug product manufacturing records. Comput Chem Eng 124:253–269
Chabner BA (2016) NCI-60 cell line screening: a radical departure in its time. J Natl Cancer Inst. https://​doi.​
org/​10.​1093/​jnci/​djv388
Chander A, Srinivasan R, Chelian S, Wang J, Uchino K (2018) Working with beliefs: AI transparency in 
the enterprise. In: Joint proceedings of the ACM IUI 2018 workshops co-located with the 23rd acm 
conference on intelligent user interfaces 2068 (eds Said, A. and Komatsu, T.) (CEUR-WS.org, 2018)
Chandra B, Sharma RK (2017) On improving recurrent neural network for image classification. Int Jt Conf 
Neural Netw (IJCNN) 2017:1904–1907. https://​doi.​org/​10.​1109/​IJCNN.​2017.​79660​83
Chang Y, Park H, Yang HJ, Lee S, Lee KY, Kim TS, Jung J, Shin JM (2018) Cancer drug response profile 
scan (CDRscan): a deep learning model that predicts drug effectiveness from cancer genomic signa-
ture. Sci Rep 8:1–11
Chauhan R, Ghanshala KK, Joshi RC (2018) Convolutional neural network (CNN) for image detection and 
recognition. First Int Conf Secure Cyber Comput Commun (ICSCCC) 2018:278–282. https://​doi.​org/​
10.​1109/​ICSCCC.​2018.​87033​16
Chen AW (2018) Predicting adverse drug reaction outcomes with machine learning. Int J Commun Med 
Public Health 5(3):901–904
Chen JY, Mamidipalli S, Huan T (2009) Happi: an online database of comprehensive human annotated and 
predicted protein interactions. BMC Genomics 10(1):S16
Chen X, Liu M-X, Yan G-Y (2012) Drug–target interaction prediction by random walk on the heterogene-
ous network. Mol BioSyst 8:1970–1978. https://​doi.​org/​10.​1039/​C2MB0​0002D
Chen Y, Yang O, Sampat C, Bhalode P, Ramachandran R, Ierapetritou M (2020) Digital twins in pharma-
ceutical and biopharmaceutical manufacturing: a literature review. Processes 8(9):1088. https://​doi.​
org/​10.​3390/​pr809​1088
Cheng F, Kovács IA, Barabási AL (2019) Network-based prediction of drug combinations. Nat Commun 
10(1):1–11
Chiu Y-C, Chen H-IH, Zhang T, Zhang S, Gorthi A, Wang L-J, Huang Y, Chen Y (2019) Predicting drug 
response of tumors from integrated genomic profiles by deep neural networks. BMC Med Genomics 
12:119
Chu X, Lin Y, Gao J, Wang J, Wang Y, Wang L (2018) Multi-label robust factorization autoencoder and its 
applicationin predicting drug–drug interactions. arXiv:​1811.​00208.
Chu X, Lin Y, Wang Y, Wang L, Wang J, Mlrda JG (2019) A multitask semi-supervised learning framework 
for drug–drug interaction prediction. In: proceedings of the international joint conference on artificial 
intelligence, pp 4518– 4524
Ciallella HL, Zhu H (2019) Advancing computational toxicology in the big data era by artificial intelligence: 
data-driven and mechanism-driven modeling for chemical toxicity. Chem Res Toxicol 32:536–547
Cortes-Ciriano I, Ain QU, Subramanian V, Lenselink EB, Méndez-Lucio O, IJzerman AP, Wohlfahrt G, 
Prusis P, Malliavin TE, van Westen GJP et al (2015) Polypharmacology modelling using proteoch-
emometrics (PCM): recent methodological developments, applications to target families, and future 
prospects. Medchemcomm 6:24–50
Cortés-Ciriano I, Bender A (2019) KekuleScope: prediction of cancer cell line sensitivity and compound 
potency using convolutional neural networks trained on compound images. J Cheminform 11:1–16
Dai L, Zhu H, Liu D (2020) Patient similarity: methods and applications. http://​arxiv.​org/​abs/​2012.​01976
David L, Arús-Pous J, Karlsson J, Engkvist O, Bjerrum EJ, Kogej T, Kriegl JM, Beck B, Chen H (2019) 
Applications of deep-learning in exploiting large-scale and heterogeneous compound data in indus-
trial pharmaceutical research. Front Pharmacol 10:1303
Davis MI, Hunt JP, Herrgard S, Ciceri P, Wodicka LM, Pallares G, Hocker M, Treiber DK, Zarrinkar PP 
(2011) Comprehensive analysis of kinase inhibitor selectivity. Nat Biotechnol 29:1046–1051
De Carvalho TM, Noels E, Wakkee M, Udrea A, Nijsten T (2019) Development of smartphone apps for skin 
cancer risk assessment: progress and promise. JMIR Dermatol 2(1):e13376
De Kuijper GM, Risselada A, van Dijken R (2019) Monitoring drug side-effects. Handbook of intellectual 
disabilities. Springer, Cham, pp 275–301
“deepchem/deepchem: Democratizing Deep-Learning for Drug Discovery”; Quantum Chemistry, Materi-
als Science and Biology; Available online: https://​github.​com/​deepc​hem/​deepc​hem (accessed on 15 
April 2022).

## Page 53 (Section: References)

6027
Deep learning in drug discovery: an integrative review and future…
1 3
Dey S, Luo H, Fokoue A, Hu J, Zhang P (2018) Predicting adverse drug reactions through interpretable 
deep learning framework. BMC Bioinform 19:476
Dincer AB, Celik S, Hiranuma N, Lee S-I (2018) DeepProfile: deep learning of cancer molecular profiles 
for precision medicine. bioRxiv. https://​doi.​org/​10.​1101/​278739
Ding MQ, Chen L, Cooper GF, Young JD, Lu X (2018) Precision oncology beyond targeted therapy: com-
bining omics data with machine learning matches the majority of cancer cells to effective therapeu-
tics. Mol Cancer Res 16:269–278
Doshi-Velez F, Kim B (2017) Towards a rigorous science of interpretable machine learning. https://​arxiv.​
org/​abs/​1702.​08608
DrugBank (2019) DrugBank Release Version 5.1.3, chemical structures. https://​www.​drugb​ank.​com
Dua D, Graff C (2017) UCI machine learning repository. https://​archi​ve.​ics.​uci.​edu/​ml/​index.​php
El-Deredy W et al (1997) Pretreatment prediction of the chemotherapeutic response of human glioma cell 
cultures using nuclear magnetic resonance spectroscopy and artificial neural networks. Cancer Res 
57:4196–4199
Farzan P, Mistry B, Ierapetritou MG (2017) Review of the important challenges and opportunities related to 
modeling of mammalian cell bioreactors. AIChE J 63:398–408
Fatehifar M, Karshenas H (2021) Drug–drug interaction extraction using a position and similarity fusion-
based attention mechanism. J Biomed Inf 115:103707. https://​doi.​org/​10.​1016/j.​jbi.​2021.​103707
Feng S, et al (2018) Pathologies of neural models make interpretations difficult. http://​arxiv.​org/​abs/​1804.​
07781
Feng Q, Dueva E, Cherkasov A, Ester M (2018) PADME: a deep learning-based framework for drug–target 
interaction prediction. arXiv 2018; arXiv:​1807.​09741
Feng YH, Zhang SW, Shi JY (2020) DPDDI: a deep predictor for drug–drug interactions. BMC Bioinform 
21:419. https://​doi.​org/​10.​1186/​s12859-​020-​03724-x
Ferdousi R, Safdari R, Omidi Y (2017) Computational prediction of drug–drug interactions based on drugs 
functional similarities. J Biomed Inform. https://​doi.​org/​10.​1016/j.​jbi.​2017.​04.​021
Finn RD et al (2013) Pfam: the protein families database. Nucleic Acids Res 42(D1):D222–D230
Flaten HK, St Claire C, Schlager E, Dunnick CA, Dellavalle RP (2020) Growth of mobile applications in 
dermatology. Dermatol Online J 24(2):13–16
Fleischhack G, Massimino M, Warmuth-Metz M, Khuhlaeva E, Janssen G, Graf N et al (2019) Nimotu-
zumab and radiotherapy for treatment of newly diagnosed diffuse intrinsic pontine glioma (DIPG): a 
phase III clinical study. J Neurooncol 143:107–113. https://​doi.​org/​10.​1007/​s11060-​019-​03140-z
Fokoue A, Sadoghi M, Hassanzadeh O, Zhang P (2016) Predicting drug–drug interactions through large-
scale similarity-based link prediction. In: European semantic web conference 2016 May 29; pp 
774–789
Fushman D, Shooshan SE, Rodriguez L, Aronson AR, Lang F, Rogers W, Tonning J (2018) A dataset of 
200 structured product labels annotated for adverse drug reactions. Sci Data 5:180001
Gangadharan N, Turner R, Field R, Oliver SG, Slater N, Dikicioglu D (2019) Metaheuristic approaches in 
biopharmaceutical process development data analysis. Bioprocess Biosyst Eng 42:1399–1408
Gao Z et al (2008) PDTD: a web-accessible protein database for drug target identification. BMC Bioinf 
9(1):104
Gao KY, Fokoue A, Luo H, Iyengar A, Dey S, Zhang P (2017) Interpretable drug target prediction using 
deep neural representation. In: Proceedings of the international joint conference on artificial intel-
ligence, Melbourne, Australia, 19–25 August 2017
Gao K, Duy Nguyen D, Sresht V, Mathiowetz AM, Tu M, Wei G-W (2019) Are 2D fingerprints still valu-
able for drug discovery? Phys Chem Chem Phys 22:8373–8390
Gatti M, Turrini E, Raschi E, Sestili P, Fimognari C (2021) Janus kinase inhibitors and coronavirus disease 
(COVID)-19: rationale, clinical evidence and safety issues. Pharmaceuticals 14(8):738
Gaulton A et al (2011) ChEMBL: a large-scale bioactivity database for drug discovery. Nucleic Acids Res 
40(D1):D1100–D1107
Gilmer J, Schoenholz SS, Riley PF, Vinyals O, Dahl GE (2017) Neural message passing for quantum chem-
istry. 34th Int Conf Mach Learn ICML 3:2053–2070
Glaessgen EH, Stargel DS (2012) The digital twin paradigm for future NASA and US Air Force vehicles. 
In: Proceedings of the 53rd AIAA/ASME/ASCE/AHS/ASC structures, structural dynamics and mate-
rials conference, Honolulu, HI, USA. https://​ntrs.​nasa.​gov/​citat​ions/​20120​008178
Goebel R et al (2018) Explainable AI: the new 42? In: Holzinger A, Kieseberg P, Tjoa A, Weippl E (eds) 
Machine learning and knowledge extraction. CD-MAKE Lecture Notes in Computer Science. 
Springer, New York
Gómez-Bombarelli R et al (2018) Automatic chemical design using a data-driven continuous representation 
of molecules. ACS Cent Sci 4:268–276

## Page 54 (Section: References)

6028
	
H. Askr et al.
1 3
Grieves M (2014) Digital twin: manufacturing excellence through virtual factory replication. Glob J Eng Sci 
Res. https://​doi.​org/​10.​5281/​zenodo.​14939​30
Grieves M, Vickers J (2017) Digital twin: mitigating unpredictable undesirable emergent behavior in com-
plex systems. Springer, Cham, pp 85–113
Guidotti R et al (2018) A survey of methods for explaining black box models. ACM Comput Surv 51:93
Guinney J, Saez-Rodriguez J (2018) Alternative models for sharing confidential biomedical data. Nat Bio-
technol 36(5):391–392
Gunther S et al (2007) SuperTarget and Matador: resources for exploring drug–target relationships. Nucleic 
Acids Res 36:D919–D922
Hamilton WL (2020) Graph representation learning. Synth Lect Artif Intell Mach Learn 14:1–159
Han X, Xie R, Li X, Li J (2022) SmileGNN: drug–drug interaction prediction based on the smiles and graph 
neural network. Life (basel). 12(2):319. https://​doi.​org/​10.​3390/​life1​20203​19
Hao M, Wang Y, Bryant SH (2016) Improved prediction of drug–target interactions using regularized least 
squares integrating with kernel fusion technique. Anal Chim Acta 909:41
Hassan-Harrirou H, Zhang C, Lemmin T (2020) RosENet: improving binding affinity prediction by leverag-
ing molecular mechanics energies with an ensemble of 3D convolutional neural networks. J Chem Inf 
Model 60:2791–2802
He C, Liu Y, Li H, Zhang H, Mao Y, Qin X, Liu L, Zhang X (2022) Multi-type feature fusion based on 
graph neural network for drug-drug interaction prediction. BMC Bioinf 23(1):1–8
Hecker N et al (2011) SuperTarget goes quantitative: update on drug–target interactions. Nucleic Acids Res 
40(D1):D1113–D1117
Hermanto A, Adji TB, Setiawan NA (2015) Recurrent neural network language model for English-Indo-
nesian machine translation: experimental study. Int Conf Sci Inf Technol (ICSITech) 2015:132–136. 
https://​doi.​org/​10.​1109/​ICSIT​ech.​2015.​74077​91
Hinton G (2011) Boltzmann machines. In: Sammut C, Webb GI (eds) Encyclopedia of machine learning. 
Springer, Boston
Hirohara M, Saito Y, Koda Y, Sato K, Sakakibara Y (2018) Convolutional neural network based on SMILES 
representation of compounds for detecting chemical motif. BMC Bioinform 19:83–94
Hizukuri Y, Sawada R, Yamanishi Y (2015) Predicting target proteins for drug candidate compounds 
based on drug-induced gene expression data in a chemical structure-independent manner. BMC Med 
Genomics 8:82
Hou X, You J, Hu P (2019) Predicting drug–drug interactions using deep neural network. In: proceedings of 
the ­11th international conference on machine learning and computing, pp 168–172
http://​zinc.​docki​ng.​org
https://​bioinf-​appli​ed.​chari​te.​de/​super​natur​al_​new/​index.​php.
https://​frien​dsofc​ancer​resea​rch.​org/​wpcon​tent/​uploa​ds/​Optim​izing_​Dosing_​in_​Oncol​ogy_​Drug_​Devel​
opment.​pdf.
https://​ncats.​nih.​gov/​tox21
https://​pharm​acodb.​pmgen​omics.​ca/​datas​ets/4
https://​sites.​broad​insti​tute.​org/​ccle/
https://​string-​db.​org/​cgi/​downl​oad.​pl?​sessi​onId=​uKr0o​dAK9h​Ps
https://​www.​cancer.​gov/​about-​nci/​organ​izati​on/​ccct/​ctrp
https://​www.​ebi.​ac.​uk/​chebi/
https://​www.​scien​cedir​ect.​com/​topics/​drug-​respo​nse
Hu J, Gao J, Fang X, Liu Z, Wang F, Huang W, Wu H, Zhao G (2022) DTSyn: a dual-transformer-based 
neural network to predict synergistic drug combinations. bioRxiv. https://​doi.​org/​10.​1101/​2022.​03.​29.​
486200
Huang C-T et al (2018) A large-scale gene expression intensity-based similarity metric for drug reposition-
ing. iScience 7:40–52
Huang K, Xiao C, Hoang TN, Glass LM, Sun J (2020) Caster: predicting drug interactions with chemical 
substructure representation. In: AAAI 2020 34th AAAI Conference on Artificial Intelligence, Ameri-
can Association for Artificial Intelligence (AAAI) Press, pp 702–709
Ibrahim H, El Kerdawy AM, Abdo A, Eldin AS (2021) Similarity-based machine learning framework for 
predicting safety signals of adverse drug–drug interactions. Inf Med Unlocked 26:100699
Ierapetritou M, Muzzio F, Reklaitis G (2016) Perspectives on the continuous manufacturing of powder-
based pharmaceutical processes. AIChE J 62:1846–1862
Iorio F et al (2010) Discovery of drug mode of action and drug repositioning from transcriptional responses. 
PNAS 107(33):14621–14626. https://​doi.​org/​10.​1073/​pnas.​10001​38107
Iorio F, Knijnenburg TA, Vis DJ, Bignell GR, Menden MP, Schubert M, Aben N, Gonçalves E, Barthorpe S, 
Lightfoot H et al (2016) A landscape of pharmacogenomic interactions in cancer. Cell 166:740–754

## Page 55 (Section: References)

6029
Deep learning in drug discovery: an integrative review and future…
1 3
James M, Stanfield CF, Bir G (2006) A review of process analytical technology (PAT) in the US pharma-
ceutical industry. Curr Pharm Anal 2:405–414
Ji ZL, Han LY, Yap CW, Sun LZ, Chen X, Chen YZ (2003) Drug adverse reaction target database (DART). 
Drug Saf 26(10):685–690
Jiménez-Luna J, Grisoni F, Schneider G (2020) Drug discovery with explainable artificial intelligence. Nat 
Mach Intell 2(10):573–584
Julkunen H, Cichonska A, Gautam P et al (2020) Leveraging multi-way interactions for systematic predic-
tion of pre-clinical drug combination effects. Nat Commun 11(1):6136
Kamath U, Liu J (2021) Explainable artificial intelligence: an introduction to interpretable machine learn-
ing. Springer, Cham
Kamble R, Sharma S, Varghese V, Mahadik K (2013) Process analytical technology (PAT) in pharmaceuti-
cal development and its application. Int J Pharm Sci Rev Res 23:212–223
Kamel Boulos MN, Zhang P (2021) Digital twins: from personalised medicine to precision public health. J 
Person Med 11(8):745
Kanehisa M, Goto S (2000) KEGG: kyoto encyclopedia of genes and genomes. Nucleic Acids Res 
28(1):27–30
Karim MR, Cochez M, Jares JB, Uddin M, Beyan O, Decker S (2019) Drug–drug interaction prediction 
based on knowledge graph embeddings and convolutional-LSTM network. In: Proceedings of the 
10th ACM international conference on bioinformatics, computational biology and health informatics, 
pp 113–123
Karim MR, Cochez M, Jares JB, Uddin M, Beyan O, Decker S (2019) Drug–drug interaction prediction 
based on knowledge graph embeddings and convolutional-LSTM network. In: Proceedings of the 
10th ACM International Conference on Bioinformatics, Computational Biology and Health Informat-
ics 2019, pp 113–123
Karpov P, Godin G, Tetko IV (2020) Transformer-CNN: Swiss knife for QSAR modeling and interpretation. 
J Cheminform 12:17
Kastrin A, Ferk P, Leskošek B (2018) Predicting potential drug–drug interactions on topological and seman-
tic similarity features using statistical learning. PLoS ONE 13(5):e0196865
Keum J, Nam H (2017) SELF-BLM: prediction of drug–target interactions via self-training SVM. PLoS 
ONE 12:e0171839
Kim S, Thiessen PA, Bolton EE, Chen J, Fu G, Gindulyte A, Han L, He J, He S, Shoemaker BA et al (2016) 
PubChem substance and compound databases. Nucleic Acids Res 44:D1202–D1213
Kim J, Park S, Min D, Kim W (2021) comprehensive survey of recent drug discovery using deep learning. 
Int J Mol Sci 22:9983. https://​doi.​org/​10.​3390/​ijms2​21899​83
Koes DR, Baumgartner MP, Camacho CJ (2013) Lessons learned in empirical scoring with smina from the 
CSAR 2011 benchmarking exercise. J Chem Inf Model 53:1893–1904
Kohonen T (1990) The self-organizing map. Proc IEEE 78(9):1464–1480
Korkmaz S (2020) Deep learning-based imbalanced data classification for drug discovery. J Chem Inf 
Model 60:4180–4190
Kritzinger W, Karner M, Traar G, Henjes J, Sihn W (2018) Digital Twin in manufacturing: a categorical 
literature review and classification. IFAC-PapersOnLine 51:1016–1022
Kuenzi BM et al (2020) Predicting drug response and synergy using a deep learning model of human cancer 
cells. J Elsevier Cancer Cell 38(5):1535–6108. https://​doi.​org/​10.​1016/j.​ccell.​2020.​09.​014
Kuhn M et al (2010) A side effect resource to capture phenotypic effects of drugs. Mol Syst Biol 6(1):343
Kuhn M et al (2013) STITCH 4: integration of protein–chemical interactions with user data. Nucleic Acids 
Res 42(D1):D401–D407
Kumar SP, Feidler JC (2003) BioSPICE: a computational infrastructure for integrative biology. OMICS J 
Integr Biol 7(3):225. https://​doi.​org/​10.​1089/​15362​31033​22452​350
Kumar S, Talasila D, Gowrav M, Gangadharappa H (2020) Adaptations of pharma 4.0 from industry 4.0. 
Drug Invent Today 14:405–415
Lamb J, Crawford ED, Peck D, Modell JW, Blat IC, Wrobel MJ, Lerner J, Brunet JP, Subramanian A, Ross 
KN et al (2006) The connectivity map: using gene-expression signatures to connect small molecules, 
genes, and disease. Science 313:1929–1935
Lapuschkin S et al (2019) Unmasking clever Hans predictors and assessing what machines really learn. Nat 
Commun 10:1096
Lee CY, Chen YP (2021) Descriptive prediction of drug side-effects using a hybrid deep learning model. Int 
J Intell Syst 36(6):2491–2510
Lee H, Kim W (2019) Comparison of target features for predicting drug–target interactions by deep neural 
network based on large-scale drug-induced transcriptome data. Pharmaceutics 11:377

## Page 56 (Section: References)

6030
	
H. Askr et al.
1 3
Lee HW, Christie A, Xu J, Yoon S (2012) Data fusion-based assessment of raw materials in mammalian cell 
culture. Biotechnol Bioeng 109:2819–2828
Lee G, Park C, Ahn J (2019) Novel deep learning model for more accurate prediction of drug–drug interac-
tion effects. BMC Bioinform 20(1):415
Lee I, Keum J, Nam H (2019) DeepConv-DTI: prediction of drug–target interactions via deep learning with 
convolution on protein sequences. PLoS Comput Biol 15:1–21
Legner C, Eymann T, Hess T, Matt C, Böhmann T, Drews P, Mädche A, Urbach N, Ahlemann F (2017) 
Digitalization: opportunity and challenge for the business and information systems engineering com-
munity. Bus Inf Syst Eng 59:301–308
Lei T, Barzilay R, Jaakkola T (2016) Rationalizing neural predictions. In: 2016 conference on empirical 
methods in natural language processing, 2016; Austin, Texas: Association for computational linguis-
tics, pp 107—117. https://​aclan​tholo​gy.​org/​D16-​1011
Li M, Wang Y, Zheng R, Shi X, Wu F, Wang J, et al. (2019) Deepdsc: a deep learning method to pre-
dict drug sensitivity of cancer cell lines. IEEE/ACM transactions on computational biology and 
bioinformatics
Lian M, Du W, Wang X, Yao Q (2021) Drug–target interaction prediction based on multi-similarity fusion 
and sparse dual-graph regularized matrix factorization. IEEE Access 9:99718–99730. https://​doi.​org/​
10.​1109/​ACCESS.​2021.​30968​30
Lin X, Quan Z, Wang Z-J, Ma T, Zeng X (2021) KGNN: knowledge graph neural network for drug–drug 
interaction prediction. In: Proceedings of the twenty-ninth international joint conference on artificial 
intelligence, Jaban; IJCAI’20
Lin-Gibson S, Srinivasan V (2019) Recent industrial roadmaps to enable smart manufacturing of biophar-
maceuticals. IEEE Trans Autom Sci Eng 2019:1–8
Lipton ZC (2018) The mythos of model interpretability. Queue 16:31–57
Liu Y, Wu M, Miao C, Zhao P, Li X-L (2016) Neighborhood regularized logistic matrix factorization for 
drug–target interaction prediction. PLoS Comput Biol 12:e1004760
Liu B, Ramsundar B, Kawthekar P, Shi J, Gomes J, Luu Nguyen Q, Ho S, Sloane J, Wender P, Pande V 
(2017) Retrosynthetic reaction prediction using neural sequence-to-sequence models. R ACS Cent Sci 
3:1103–1113
Liu N, Chen CB, Kumara S (2019) Semi-supervised learning algorithm for identifying high-priority drug–
drug interactions. IEEE J Biomedic Health Inform. https://​doi.​org/​10.​1109/​JBHI.​2019.​29327​40
Liu K, Sun X, Jia L, Ma J, Xing H, Wu J, Gao H, Sun Y, Boulnois F, Fan J (2019a) Chemi-net: a molecular 
graph convolutional network for accurate drug property prediction. Int J Mol Sci 20:3389
Liu P, Li H, Li S, Leung KS (2019b) Improving prediction of phenotypic drug response on cancer cell lines 
using deep convolutional network. BMC Bioinform 20:408
Liu S, Huang Z, Qiu Y, Chen Y-PP, Zhang W (2019c) Structural network embedding using multi-modal 
deep auto-encoders for predicting drug–drug interactions. IEEE Int Conf Bioinform Biomed 
2019:445–450. https://​doi.​org/​10.​1109/​BIBM4​7256.​2019.​89833​37
Liu S, Zhang Y, Cui Y, Qiu Y, Deng Y, Zhang W, Zhang Z (2021) Enhancing drug–drug interaction predic-
tion using deep attention neural networks. BioRxiv. https://​doi.​org/​10.​1101/​2021.​03.​16.​435553
Lopes MR, Costigliola A, Pinto R, Vieira S, Sousa JMC (2019) Pharmaceutical quality control laboratory 
digital twin—a novel governance model for resource planning and scheduling. Int J Prod Res 58:1–15
Louizos C, Welling M, Kingma DP (2017) Learning sparse neural networks through l 0 regularization. 
http://​arxiv.​org/​abs/​1712.​01312.
Lu Y, Guo Y, Korhonen AJB (2017) Link prediction in drug–target interactions network using similarity 
indices. BMC Bioinf 18(1):39. https://​doi.​org/​10.​1186/​s12859-​017-​1460-z
Luo Y, Zhao X, Zhou J, Yang J, Zhang Y, Kuang W, Peng J, Chen L, Zeng J (2017) A network integration 
approach for drug–target interaction prediction and computational drug repositioning from heteroge-
neous information. Nat Commun 8:573
Luo D, Cheng W, Xu D, Yu W, Zong B, Chen H, Zhang X (2020) Parameterized explainer for graph neural 
network. Adv Neural Inf Process Syst 33:19620–19631
Lyu T, Gao J, Tian L, Li Z, Zhang P, Zhang J (2021) MDNN: a multimodal deep neural network for predict-
ing drug–drug interaction events. In: Proceedings of the thirtieth international joint conference on 
artificial intelligence (IJCAI-21), pp 3536–3542. https://​doi.​org/​10.​24963/​ijcai.​2021/​487
Ma T, Xiao C, Zhou J, Wang F (2018) Drug similarity integration through attentive Multiview graph auto-
encoders. In: IJCAI 2018, proceedings of the 27th international joint conference on artificial intel-
ligence, pp 3477–3483
Mahajan D, Kumar D (2018) Sentiment analysis using RNN and Google translator. In: 2018 8th interna-
tional conference on cloud computing, data science & engineering (Confluence), pp 798–802. https://​
doi.​org/​10.​1109/​CONFL​UENCE.​2018.​84429​24

## Page 57 (Section: References)

6031
Deep learning in drug discovery: an integrative review and future…
1 3
Mak IWY, Evaniew N, Ghert M (2014) Lost in translation: animal models and clinical trials in cancer treat-
ment. Am J Transl Res 6:114–118
Marr B (2017) What is digital twin technology and why is it so important? Forbes. https://​www.​forbes.​com/​
sites/​berna​rdmarr/​2017/​03/​06/​what-​is-​digit​al-​twin-​techn​ology-​and-​why-​is-​it-​so-​impor​tant
Matsuzaka Y, Uesawa Y (2019) Prediction model with high-performance constitutive androstane receptor 
(CAR) using DeepSnap-deep learning approach from the tox21 10K compound library. Int J Mol Sci 
20:4855
Maul J-T, Djamei V, Kolios AG, Meier B, Czernielewskiand J, Jungo P (2016) Efficacy and survival of sys-
temic psoriasis treatments: an analysis of the SWISS registry SDNTT. Dermatology 232(6):640–647
Mayani MG, Svendsen M, Oedegaard SI (2018) Drilling digital twin success stories the last 10 years. 
In: Proceedings of the SPE Norway one day seminar, Bergen, Norway. https://​doi.​org/​10.​2118/​
191336-​MS
Metz JT, Johnson EF, Soni NB, Merta PJ, Kifle L, Hajduk PJ (2011) Navigating the kinome. Nat Chem Biol 
7:200–202
Miller T (2019) Explanation in artificial intelligence: insights from the social sciences. Artif Intell 267:1–38
Miyato T, Dai AM, Goodfellow I (2016) Adversarial training methods for semisupervised text classifica-
tion. http://​arxiv.​org/​abs/​1605.​07725
Mohamed C, Nsiri B, Abdelmajid S, Abdelghani EM, Brahim B (2020) Deep convolutional networks for 
image segmentation: application to optic disc detection. Int Conf Electr Inf Technol (ICEIT) 2020:1–
3. https://​doi.​org/​10.​1109/​ICEIT​48248.​2020.​91132​04
Mukhamediev RI, Symagulov A, Kuchin Y, Yakunin K, Yelis M (2021) From classical machine learning to 
deep neural networks: a simplified scientometric review. Appl Sci 11:5541. https://​doi.​org/​10.​3390/​
app11​125541
Murdoch WJ, Singh C, Kumbier K, Abbasi-Asl R, Yu B (2019) Definitions, methods, and applications in 
interpretable machine learning. Proc Natl Acad Sci USA 116:22071–22080
Nag S, Baidya ATK, Mandal A et al (2022) Deep learning tools for advancing drug discovery and devel-
opment. 3 Biotech 12:110. https://​doi.​org/​10.​1007/​s13205-​022-​03165-8
Nagy ZK, Fevotte G, Kramer H, Simon LL (2013) Recent advances in the monitoring, modelling, and 
control of crystallization systems. Chem Eng Res Des 91:1903–1922
Narayanan H, Luna MF, von Stosch M, Cruz Bournazou MN, Polotti G, Morbidelli M, Butte A, Sokolov 
M (2020) Bioprocessing in the digital age: the role of process models. Biotechnol J 15:e1900172
Nascimento ACA, Prudêncio RBC, Costa IG (2016) A multiple kernel learning algorithm for drug–tar-
get interaction prediction. BMC Bioinforma 17:46
Needleman SB, Wunsch CD (1970) A general method applicable to the search for similarities in the 
amino acid sequence of two proteins. J Mol Biol 48(3):443–453
Nguyen T, Nguyen TT, Nguyen T, Le DH (2021) Graph convolutional networks for drug response pre-
diction. IEEE/ACM Trans Comput Biol Bioinform 19:146–154
O’Connor TF, Yu LX, Lee SL (2016) Emerging technology: a key enabler for modernizing pharmaceuti-
cal manufacturing and advancing product quality. Int J Pharm 509:492–498
Oboyle NM, Sayle RA (2016) Comparing structural fingerprints using a literature-based similarity 
benchmark. J Cheminform 8(1):1–14. https://​doi.​org/​10.​1186/​s13321-​016-​0148-0
Olughu W, Deepika G, Hewitt C, Rielly C (2019) Insight into the large-scale upstream fermentation 
environment using scaled-down models. J Chem Technol Biotechnol 94:647–657
Oughtred R, Rust J, Chang C, Breitkreutz BJ, Stark C, Willems A, Boucher L, Leung G, Kolas N, Zhang 
F, Dolma S (2021) The BioGRID database: a comprehensive biomedical resource of curated pro-
tein, genetic, and chemical interactions. Protein Sci 30(1):187–200
Oztemel E, Gursev S (2018) Literature review of Industry 4.0 and related technologies. J Intell Manuf 
31:127–182
Ozturk H, Ozturk A, Ozkirimli E (2018) DeepDTA: Deep drug–target binding affinity prediction. Bioin-
formatics 34:i821–i829
Pandey P, Katakdaunde M, Turton R (2006) Modeling weight variability in a pan coating process using 
Monte Carlo simulations. AAPS Pharm Sci Tech 7:E2–E11
Papadakis E, Woodley JM, Gani R (2018) Perspective on PSE in pharmaceutical process development 
and innovation. In Process. Systems engineering for pharmaceutical manufacturing. Elsevier, 
Amsterdam pp 597–656
Passi A et al (2018) RepTB: a gene ontology-based drug repurposing approach for tuberculosis. J Chem-
inform 10(1):24. https://​doi.​org/​10.​1186/​s13321-​018-​0276-9
Peng J, Li J, Shang X (2020) A learning-based method for drug–target interaction prediction based on 
feature representation learning and deep neural network. BMC Bioinform 21:1–13

## Page 58 (Section: References)

6032
	
H. Askr et al.
1 3
Perozzi B, Al-Rfou R, Skiena S (2014) DeepWalk: online learning of social representations. In: Pro-
ceeding of the ACM SIGKDD international conference on knowledge discovery and data mining, 
New York, NY, USA, 24–27 August 2014, pp 701–710
Poluzzi E, Raschi E, Piccinni C, De Ponti F (2012) data mining techniques in pharmacovigilance: analy-
sis of the publicly accessible FDA adverse event reporting system (AERS). In: Data mining appli-
cations in engineering and medicine. London, United Kingdom: IntechOpen. https://​doi.​org/​10.​
5772/​50095
Pouryahya M, Oh JH, Mathews JC, Belkhatir Z, Moosmüller C, Deasy JO, Tannenbaum AR (2022) 
Pan-cancer prediction of cell-line drug sensitivity using network-based methods. Int J Mol Sci 
23:1074. https://​doi.​org/​10.​3390/​ijms2​30310​74
Qiu K, Lee J, Kim H, Yoon S, Kang K (2021) Machine learning based anti-cancer drug response pre-
diction and search for predictor genes using cancer cell line gene expression. Genomics Inform. 
https://​doi.​org/​10.​5808/​gi.​20076
Quan C et  al (2016) Multichannel convolutional neural network for biological relation extraction. 
BioMed Res Int. https://​doi.​org/​10.​1155/​2016/​18504​04
Raghava GP, Barton GJ (2006) Quantification of the variation in percentage identity for protein sequence 
alignments. BMC Bioinf 7(1):415. https://​doi.​org/​10.​1186/​1471-​2105-7-​415
Rampášek L et al (2019) Improving drug response prediction via modeling of drug perturbation effects. 
Bioinformatics. https://​doi.​org/​10.​1093/​bioin​forma​tics/​btz158
Rantanen J, Khinast J (2015) The future of pharmaceutical manufacturing sciences. J Pharm Sci 
104:3612–3638
Read EK, Park JT, Shah RB, Riley BS, Brorson KA, Rathore AS (2010) Process analytical technol-
ogy (PAT) for biopharmaceutical products: Part I. Concepts and applications. Biotechnol Bioeng 
105:276–284
Reinhardt IC, Oliveira DJC, Ring DDT (2020) Current perspectives on the development of industry 4.0 
in the pharmaceutical sector. J Ind Inf Integr 18:100131
Ren S, Tao Y, Yu K et al (2022) De novo prediction of Cell-Drug sensitivities using deep learning-based 
graph regularized matrix factorization. Pacif Symp Biocomput. https://​doi.​org/​10.​7490/​f1000​resea​
rch.​11188​07.1
Reza F, Reza S, Yadollah O (2017) Computational prediction of drug–drug interactions based on drugs 
functional similarities. J Biomed Inform 70:54–64
Richardson P, Grifn I, Tucker C, Smith D, Oechsle O, Phelan A, Rawling M, Savory E, Stebbing J 
(2020) Baricitinib as potential treatment for 2019-nCoV acute respiratory disease. Lancet (london, 
England) 395(10223):e30
Rifaioglu AS, Atas H, Martin MJ, Cetin-Atalay R, Atalay V, Dogan T (2019) Recent applications of 
deep learning and machine intelligence on in silico drug discovery: methods, tools and databases. 
Brief Bioinform 20:1878–1912
Rosen R, von Wichert G, Lo G, Bettenhausen KD (2015) About the importance of autonomy and digital 
twins for the future of manufacturing. IFAC-PapersOnLine 48:567–572
Ryu JY, Kim HU, Lee SY (2018) Deep learning improves prediction of drug–drug and drug–food inter-
actions. PNAS 115(18):E4304–E4311
Sachdev K, Gupta MK (2019) A comprehensive review of feature-based methods for drug–target inter-
action prediction. J Biomed Inform 93:103159
Sajjia M, Shirazian S, Kelly CB, Albadarin AB, Walker G (2017) ANN analysis of a roller compaction 
process; in the pharmaceutical industry. Chem Eng Technol 40:487–492
Sarker IH (2021) Deep learning: a comprehensive overview on techniques, taxonomy, applications and 
research directions. SN Comput Sci 2:420. https://​doi.​org/​10.​1007/​s42979-​021-​00815-1
Sawada R, Iwata M, Tabei Y, Yamato H, Yamanishi Y (2018) Predicting inhibitory and activatory drug 
targets by chemically and genetically perturbed transcriptome signatures. Sci Rep 8:156
Schleich B, Anwer N, Mathieu L, Wartzack S (2017) Shaping the digital twin for design and production 
engineering. CIRP Ann 66:141–144
Schlichtkrull MS, De Cao N, Titov I (2020) Interpreting graph neural networks for NLP with differenti-
able edge masking. http://​arxiv.​org/​abs/​2010.​00577
Schwarz K (2021) AttentionDDI: Siamese attention-based deep learning method for drug–drug interac-
tion predictions. BMC Bioinf 22(1):412
Scudellari M (2020) Five companies using AI to fight coronavirus. https://​spect​rum.​ieee.​org/​the-​human-​
os/​artif​icial-​intel​ligen​ce/​medic​al-​ai/​compa​nies-​ai-​coron​avirus
Seo S, Lee T, Kim MH, Yoon Y (2020) Prediction of side effects using comprehensive similarity meas-
ures. BioMed Res Int. https://​doi.​org/​10.​1155/​2020/​13576​30

## Page 59 (Section: References)

6033
Deep learning in drug discovery: an integrative review and future…
1 3
Shang C, Liu Q, Chen KS, Sun J, Lu J, Yi J, Bi J (2018) Edge attention-based multi-relational graph 
convolutional networks. arXiv 2018; arXiv:​1802.​04944.
Shao K, Zhang Z, He S, Bo X (2020) DTIGCCN: prediction of drug–target interactions based on GCN 
and CNN. In: Proceedings of the 2020 IEEE ­2nd international conference on tools with artificial 
intelligence (ICTAI), Baltimore, MD, USA, 9–11 November 2020, pp 337–342
Sharifi-Noghabi H, Zolotareva O, Collins CC, Ester M (2019) MOLI: multi-omics late integration with 
deep neural networks for drug response prediction. Bioinformatics 35:i501–i509
Shin B, Park S, Kang K, Ho JC (2019) Self-attention based molecule representation for predicting drug–
target interaction. Proc Mach Learn Res 106:1–18
Shoemaker RH (2006) The NCI60 human tumour cell line anticancer drug screen. Nat Rev Cancer 
6:813–823
Shrikumar A, Greenside P, Kundaje A (2017) Learning important features through propagating activa-
tion differences. In: Proceedings of the 34th international conference on machine learning 2017; 
70, JMLR.org: Sydney, NSW, Australia. pp 3145–3153
Shtar G, Rokach L, Shapira B (2019) Detecting drug–drug interactions using artificial neural networks 
and classic graph similarity measures. PLoS ONE 14(8):e0219796
Silver D, Schrittwieser J, Simonyan K, Antonoglou I, Huang A, Guez A, Hubert T, Baker L, Lai M, Bol-
ton A et al (2017) Mastering the game of go without human knowledge. Nature 550(7676):354–359
Simon LL, Kiss AA, Cornevin J, Gani R (2019) Process engineering advances in pharmaceutical and 
chemical industries: Digital process design, advanced rectification, and continuous filtration. Curr 
Opin Chem Eng 25:114–121
Simonyan K, Vedaldi A, Zisserman A (2014) Deep inside convolutional networks: visualising image 
classification models and saliency maps. In: 2nd international conference on learning representa-
tions, ICLR 2014, Banff, AB, Canada, April 14–16, 2014, Workshop Track Proceedings; http://​
arxiv.​org/​abs/​1312.​6034
Smiatek J, Jung A, Bluhmki E (2020) Towards a digital bioprocess. Replica: computational approaches in 
biopharmaceutical development and manufacturing. Trends Biotechnol 38(10):1141–1153. https://​
doi.​org/​10.​1016/j.​tibte​ch.​2020.​05.​008
Song T, Zhang X, Ding M, Rodriguez-Paton A, Wang S, Wang G (2022) DeepFusion: a deep learning based 
multi-scale feature fusion method for predicting drug–target interactions. Methods 204:269–277
Springenberg JT (2015) Striving for simplicity: the all-convolutional Net. CoRR, http://​arxiv.​org/​abs/​1412.​
6806
Stark R, Fresemann C, Lindow K (2019) Development and operation of digital twins for technical systems 
and services. CIRP Ann 68:129–132
Steinwandter V, Borchert D, Herwig C (2019) Data science tools and applications on the way to Pharma 4.0. 
Drug Discov Today 24:1795–1805
Stokes JM, Yang K, Swanson K, Jin W, Cubillos-Ruiz A, Donghia NM, MacNair CR, French S, Carfrae LA, 
Bloom-Ackerman Z et al (2020) A deep learning approach to antibiotic discovery. Cell 180:688-702.
e13
Subramanian K (2020) Digital twin for drug discovery and development—the virtual liver. J Indian Inst Sci 
100:653–662. https://​doi.​org/​10.​1007/​s41745-​020-​00185-2
Subramanian A, Narayan R, Corsello SM, Peck DD, Natoli TE, Lu X, Gould J, Davis JF, Tubelli AA, 
Asiedu JK et al (2017) A next generation connectivity map: L1000 platform and the first 1,000,000 
profiles. Cell 171:1437-1452.e17
Sun X, Ma L, Du X, Feng J, Dong K (2018) Deep convolution neural networks for drug–drug interaction 
extraction. In: 2018 IEEE international conference on bioinformatics and biomedicine (BIBM), pp 
1662–1668. https://​doi.​org/​10.​1109/​BIBM.​2018.​86214​05
Sun M, Zhao S, Gilvary C, Elemento O, Zhou J, Wang F (2020a) Graph convolutional networks for compu-
tational drug development and discovery. Brief Bioinform 21:919–935
Sun M, Wang F, Elemento O, Zhou J (2020b) Structure-based drug–drug interaction detection via expres-
sive graph convolutional networks and deep sets. Proc AAAI Conf Artif Intell 34(10):13927–13928. 
https://​doi.​org/​10.​1609/​aaai.​v34i10.​7236
System HSL (2006) Psychoactive Drug Screening Program. https://​www.​hsls.​pitt.​edu/​obrc/​index.​php?​
page=​URL11​33202​727
Tajbakhsh N et al (2016) Convolutional neural networks for medical image analysis: full training or fine tun-
ing? IEEE Trans Med Imaging 35(5):1299–1312. https://​doi.​org/​10.​1109/​TMI.​2016.​25353​02
Tang J, Szwajda A, Shakyawar S, Xu T, Hintsanen P, Wennerberg K, Aittokallio T (2014) Making sense of 
large-scale kinase inhibitor bioactivity data sets: a comparative and integrative analysis. J Chem Inf 
Model 54:735–743

## Page 60 (Section: References)

6034
	
H. Askr et al.
1 3
Tang P, Xu J, Louey A, Tan Z, Yongky A, Liang S, Li ZJ, Weng Y, Liu S (2020) Kinetic modeling of Chi-
nese hamster ovary cell culture: factors and principles. Crit Rev Biotechnol 40:265–281
Tao F, Cheng J, Qi Q, Zhang M, Zhang H, Sui F (2018) Digital twin-driven product design, manufacturing 
and service with big data. Int J Adv Manuf Technol 94:3563–3576
Tatonetti NP et  al (2012) Data-driven prediction of drug effects and interactions. Sci Transl Med 
4(125):12531. https://​doi.​org/​10.​1126/​scitr​anslm​ed.​30033​77
Tatonetti NP, Patrick PY, Daneshjou R, Altman RB (2012) Data driven prediction of drug effects and inter-
actions. Sci Transl Med 4(125):125ra31-125ra31
Tehseen Z, Usman Z (2019) Long short-term memory recurrent neural network architectures for Urdu 
acoustic modelling. Int J Speech Technol 22(1):21–30. https://​doi.​org/​10.​1007/​s10772-​018-​09573-7
Thafar M, Raies AB, Albaradei S, Essack M, Bajic VB (2019) Comparison study of computational predic-
tion tools for drug–target binding affinities. Front Chem 7:782. https://​doi.​org/​10.​3389/​fchem.​2019.​
00782
Thafar MA, Olayan RS, Olayan RS, Ashoor H, Ashoor H, Albaradei S, Albaradei S, Bajic VB, Gao X 
et al (2020) DTiGEMS: drug–target interaction prediction using graph embedding, graph mining, and 
similarity-based techniques. J Cheminform 12:1–17
Thafar MA, Alshahrani M, Albaradei S et al (2022) Affinity2Vec: drug–target binding affinity prediction 
through representation learning, graph mining, and machine learning. Sci Rep 12:4751. https://​doi.​
org/​10.​1038/​s41598-​022-​08787-9
Thorben F, Megha Kh, Avishek A (2021) Hard masking for explaining graph neural networks. In Submit-
ted to international conference on learning representations https://​openr​eview.​net/​forum?​id=​uDN8p​
RAdsoC
Tian X, Xin M, Luo J, Jiang Z (2016) Using the ranking-based KNN approach for drug repositioning based 
on multiple information. Springer, Cham, pp 317–327
Tong H, Heidemeyer M, Ban F, Cherkasov A, Ester M (2017) SimBoost: A read-across approach for pre-
dicting drug–target binding affinities using gradient boosting machines. J Cheminform 9:1–14
Torng W, Altman RB (2019) Graph convolutional neural networks for predicting drug–target interactions. J 
Chem Inf Model 59:4131–4149
Townshend RJL, Powers A, Eismann S, Derry A (2021) ATOM3D: tasks on molecules in three dimensions. 
arXiv 2021: arXiv:​2012.​04035
Trißl S, Rother K, Müller H et al (2005) Columba: an integrated database of proteins, structures, and anno-
tations. BMC Bioinformatics 6:81. https://​doi.​org/​10.​1186/​1471-​2105-6-​81
Trott O, Olson AJ (2010) AutoDock Vina: improving the speed and accuracy of docking with a new scoring 
function, efficient optimization and multithreading. J Comput Chem 31:455
Tyson RJ, Park CC, Powell JR, Patterson JH, Weiner D, Watkins PB, Gonzalez D (2020) Precision dosing 
priority criteria: drug, disease, and patient population variables. J Front Pharmacol. https://​doi.​org/​10.​
3389/​fphar.​2020.​00420
U. Consortium (2014) UniProt: a hub for protein information. Nucleic Acids Res 43(D1):D204–D212
Vazquez J, Lopez M, Gibert E, Herrero E, Luque FJ (2020) Merging ligand-based and structure-based meth-
ods in drug discovery: an overview of combined virtual screening approaches. Molecules 25:4723
Venkatasubramanian V (2019) The promise of artificial intelligence in chemical engineering: is it here, 
finally? AIChE J 65:466–478
Vermeer NS, Straus SM, Mantel-Teeuwisse AK, Domergue F, Egberts TC, Leufkens HG, De Bruin ML 
(2013) Traceability of biopharmaceuticals in spontaneous reporting systems: a cross sectional 
study in the FDA adverse event reporting system (FAERS) and surveillance databases. Drug Saf 
36(8):617–625
Vilar S, Hripcsak GJ (2016) Leveraging 3D chemical similarity, target and phenotypic data in the identifica-
tion of drug-protein and drug-adverse effect associations. J Cheminform 8(1):35. https://​doi.​org/​10.​
1186/​s13321-​016-​0147-1
Vilar S, Uriarte E, Santana L, Lorberbaum T, Hripcsak G, Friedman C, Tatonetti NP (2014) Similarity-
based modeling in large-scale prediction of drug–drug interactions. Nat Protoc 9(9):2147–2163. 
https://​doi.​org/​10.​1038/​nprot.​2014.​151
Wallach I, Dzamba M, Heifets A (2015) AtomNet: a deep convolutional neural network for bioactivity pre-
diction in structurebased drug discovery. arXiv 2015: arXiv:​1510.​02855.
Wan F et al (2019) DeepCPI: a deep learning-based framework for large-scale in silico drug screening. 
Genom Proteomics Bioinform 17:478–495
Wang JZ et  al (2007) A new method to measure the semantic similarity of GO terms. Bioinformatics 
23(10):1274–1281. https://​doi.​org/​10.​1093/​bioin​forma​tics/​btm087
Wang W et al (2014) Drug repositioning by integrating target information through a heterogeneous network 
model. Bioinformatics 30(20):2923–2930. https://​doi.​org/​10.​1093/​bioin​forma​tics/​btu403

## Page 61 (Section: References)

6035
Deep learning in drug discovery: an integrative review and future…
1 3
Wang CS, Lin PJ, Cheng CL, Tai SH, Kao Yang YH, Chiang JH (2019) Detecting potential adverse drug 
reactions using a deep neural network model. J Med Internet Res 21(2):e11016
Wang T, Yi HC, You ZH, Li LP, Wang YB, Hu L, Wong L (2019) A gated recurrent unit model for drug 
repositioning by combining comprehensive similarity measures and Gaussian interaction profile ker-
nel. In: International conference on intelligent computing. Springer, Cham. pp 344–353
Wang YB, You ZH, Yang S et al (2020a) A deep learning-based method for drug–target interaction predic-
tion based on long short-term memory neural network. BMC Med Inform Decis Mak 20:49. https://​
doi.​org/​10.​1186/​s12911-​020-​1052-0
Wang H, Wang J, Dong C, Lian Y, Liu D, Yan Z (2020b) A novel approach for drug–target interactions pre-
diction based on multimodal deep autoencoder. Front Pharmacol 10:1–19
Watanabe JH, McInnis T, Hirsch JD (2018) Cost of prescription drug-related morbidity and mortality. Ann 
Pharmacother 52:829–837. https://​doi.​org/​10.​1177/​10600​28018​765159
Way GP, Greene CS (2018) Extracting a biologically relevant latent space from cancer transcriptomes with 
variational autoencoders. Pac Symp Biocomput 23:80–91
Wei J, Lu Z, Qiu K, Li P, Sun H (2020) Predicting drug risk level from adverse drug reactions using 
SMOTE and machine learning approaches. IEEE Access 8:185761–185775. https://​doi.​org/​10.​1109/​
ACCESS.​2020.​30294​46
Weinstein JN (2004) Integromic analysis of the NCI-60 cancer cell lines. Breast Dis 19:11–22
Wen M, Zhang Z, Niu S, Sha H, Yang R, Yun Y, Lu H (2017) Deep-learning-based drug–target interaction 
prediction. J Proteome Res 16:1401–1409
Wenzel J, Matter H, Schmidt F (2019) Predictive multitask deep neural network models for adme-tox prop-
erties: learning from large data sets. J Chem Inf Model 59:1253–1268
White J, Schiffer JT, Bender R et al (2021) Drug combinations as a first line of defense against coronavi-
ruses and other emerging viruses. Mbio 12(6):e0334721
Withnall M, Lindelöf E, Engkvist O, Chen H (2020) Building attention and edge message passing neural 
networks for bioactivity and physical-chemical property prediction. J Cheminform 12:1
Wu Z, Ramsundar B, Feinberg EN, Gomes J, Geniesse C, Pappu AS, Leswing K, Pande V (2018) Mol-
eculeNet: a benchmark for molecular machine learning. Chem Sci 9:513–530
Wu Z, Pan S, Chen F et al (2020) A comprehensive survey on graph neural networks. IEEE Trans Neural 
Netw Learn Syst 32:4–24
Xia Z, Wu LY, Zhou X, Wong ST (2010) Semi-supervised drug-protein interaction prediction from het-
erogeneous biological spaces. BMC Syst Biol 4:S6
Xiang W, Yingxin W, An Z, Xiangnan H, Tat-seng C (2021) Causal screening to interpret graph neural 
networks. In Submitted to international conference on learning representations. https://​www.​openr​
eview.​net/​forum?​id=​nzKv5​vxZfge
Xie L, He S, Song X, Bo X, Zhang Z (2018) Deep learning-based transcriptome data classification for 
drug–target interaction prediction. BMC Genomics 19:13–16
Xie Y, Peng J, Zhou Y, et al (2019) Integrating protein-protein interaction information into drug response 
prediction by graph neural encoding. 16 December 2019, Available at Research Square https://​doi.​
org/​10.​21203/​rs.2.​18936/​v1.
Xu Y, Pei J, Lai L (2017) Deep learning-based regression and multiclass models for acute oral toxicity 
prediction with automatic chemical feature extraction. J Chem Inf Model 57:2672–2685
Yan CK, Wang WX, Zhang G et al (2019) BiRWDDA: a novel drug repositioning method based on mul-
tisimilarity fusion. J Comput Biol 26(11):1230–1242
Yan C, Duan G, Zhang Y, Wu F-X, Pan Y, Wang J (2022) Predicting drug–drug interactions based 
on integrated similarity and semi-supervised learning. IEEE/ACM Trans Comput Biol Bioinf 
19(1):168–179. https://​doi.​org/​10.​1109/​TCBB.​2020.​29880​18
Yang K, Swanson K, Jin W, Coley C, Eiden P, Gao H, Guzman-Perez A, Hopper T, Kelley B, Mathea 
M et al (2019) Analyzing learned molecular representations for property prediction. J Chem Inf 
Model 59:3370–3388
Yi HC, You ZH, Wang L et al (2021) In silico drug repositioning using deep learning and comprehen-
sive similarity measures. BMC Bioinf 22:293. https://​doi.​org/​10.​1186/​s12859-​020-​03882-y
Yifan D, Xinran X, Yang Q, Jingbo X, Wen Z, Shichao L (2020) A multimodal deep learning framework 
for predicting drug–drug interaction events. Bioinformatics 36:4316–4322
Ying Z, Bourgeois D, You J, Zitnik M, Leskovec J (2019) Gnnexplainer: generating explanations for 
graph neural networks. Adv Neural Inf Process Syst 32:9244–9255
Yu Y, Si X, Hu C, Zhang J (2019) A review of recurrent neural networks: Lstm cells and network archi-
tectures. Neural Comput 31:1235–1270
Yu Y, Huang K, Zhang C, Glass LM, Sun J, Xiao C (2021) SumGNN: multi-typed drug interaction pre-
diction via efficient knowledge graph summarization. Bioinformatics 37(18):2988–2995

## Page 62 (Section: References)

6036
	
H. Askr et al.
1 3
Yuan H, Yu H, Wang J, Li K, Ji S (2021) On explain-ability of graph neural networks via subgraph 
explorations. http://​arxiv.​org/​abs/​2102.​05152
Yue X, Wang Z, Huang J, Parthasarathy S, Moosavinasab S, Huang Y, Lin SM, Zhang W, Zhang P, Sun 
H (2020) Graph embedding on biomedical networks: methods, applications, and evaluations. Bio-
informatics 36(4):1241–1251. https://​doi.​org/​10.​1093/​bioin​forma​tics/​btz718
Yunsheng B, Ken G, Yizhou S, Wei W (2020) Bi-level graph neural networks for drug–drug interaction 
prediction. J Comput Eng arXiv:​2006.​14002
Zaikis D, Vlahavas I (2020) Drug–drug interaction classification using attention based neural networks. 
In: 11th Hellenic conference on artificial intelligence, pp 34–40. https://​doi.​org/​10.​1145/​34114​08.​
34114​61
Zeng H, Qiu C, Cui QJD (2015) Drug-path: a database for drug-induced pathways. J Biol Databases 
Curation. https://​doi.​org/​10.​1093/​datab​ase/​bav061
Zeng T, Rongjian L, Ravi M, Jieping Y, Shuiwang J (2015) Deep convolutional neural networks for 
annotating gene expression patterns in the mouse brain. BMC Bioinformatics 16(1):147
Zeng X et al (2019) Measure clinical drug–drug similarity using electronic medical records. Int J Med 
Inf 124:97–103. https://​doi.​org/​10.​1016/j.​ijmed​inf.​2019.​02.​003
Zeng X, Zhu S, Lu W, Liu Z, Huang J, Zhou Y, Fang J, Huang Y, Guo H, Li L et al (2020) Target 
identification among known drugs by deep learning from heterogeneous networks. Chem Sci 
11:1775–1797
Zhai J, Zhang S, Chen J, He Q (2018) Autoencoder and its various variants. In: 2018 IEEE international 
conference on systems, man, and cybernetics (SMC), pp 415–419. https://​doi.​org/​10.​1109/​SMC.​
2018.​00080
Zhang Y (2020) Predicting drug–drug interactions using multi-modal deep autoencoders based network 
embedding and positive-unlabeled learning. Methods 179:37–46
Zhang M-L, Zhou Z-H (2007) Ml-knn: a lazy learning approach to multi-label learning. Pattern Recogn 
40(7):2038–2048
Zhang H, Liu D, Xiong Z (2018) Convolutional neural network-based video super-resolution for action rec-
ognition. In: 2018 13th IEEE international conference on automatic face & gesture recognition (FG 
2018), pp 746–750. https://​doi.​org/​10.​1109/​FG.​2018.​00117
Zhang Y, Weng Y, Lund J (2022) Applications of explainable artificial intelligence in diagnosis and surgery. 
Diagnostics 12:237. https://​doi.​org/​10.​3390/​diagn​ostic​s1202​0237
Zhang C, Lu Y, Zang T (2022) CNN-DDI: a learning-based method for predicting drug–drug interactions 
using convolution neural networks. BMC Bioinf 23:88. https://​doi.​org/​10.​1186/​s12859-​022-​04612-2
Zhao Y, Zheng K, Guan B, Guo M, Song L, Gao J, Qu H, Wang Y, Shi D, Zhang Y (2020) DLDTI: a 
learning-based framework for drug–target interaction identification using neural networks and net-
work representation. J Transl Med 18:434
Zhao Q, Xiao F, Yang M, Li Y, Wang J (2019) AttentionDTA: prediction of drug–target binding affinity 
using attention model. In: Proceedings of the 2019 IEEE international conference on bioinformatics 
and biomedicine, San Diego, CA, USA, 18–21 November 2019, pp 64–69
Zhou Y, Zhang Y, Lian X, Li F, Wang C, Zhu F, Qiu Y, Chen Y (2022) Therapeutic target database update 
2022: facilitating drug discovery with enriched comparative data of targeted agents. Nucleic Acids 
Res 50:1398–1407
Zitnik M, Agrawal M, Leskovec J (2018) Modeling polypharmacy side effects with graph convolutional 
networks. Bioinformatics 34(13):i457–i466
Zitnik SM, Sosic R, Leskovec J (2018) Biosnap datasets: Stanford biomedical network dataset collection. 
http://​snap.​stanf​ord.​edu/​bioda​ta
Zong N, Kim H, Ngo V, Harismendy O (2017) Deep mining heterogeneous networks of biomedical linked 
data to predict novel drug–target associations. Bioinformatics 33:2337–2344
Zügner D, Akbarnejad A, Günnemann S (2018) Adversarial attacks on neural networks for graph data. In: 
Proceedings of the 24th ACM SIGKDD international conference on knowledge discovery and Data 
Mining. 2018, Association for Computing Machinery: London, United Kingdom. pp 2847–2856
Publisher’s Note  Springer Nature remains neutral with regard to jurisdictional claims in published maps and 
institutional affiliations.

## Page 63 (Section: References)

6037
Deep learning in drug discovery: an integrative review and future…
1 3
Authors and Affiliations
Heba Askr1 · Enas Elgeldawi2 · Heba Aboul Ella4 · Yaseen A. M. M. Elshaier5 · 
Mamdouh M. Gomaa2 · Aboul Ella Hassanien3
	
Heba Askr 
	
heba.askr@fcai.usc.edu.eg
	
Enas Elgeldawi 
	
enas.elgeldawi@mu.edu.eg
	
Heba Aboul Ella 
	
haboelella@ecu.edu.eg
	
Yaseen A. M. M. Elshaier 
	
Yaseen.Elshaier@fop.usc.edu.eg
	
Mamdouh M. Gomaa 
	
mamdouh.gomaa@mu.edu.eg
1	
Faculty of Computers and Artificial Intelligence, University of Sadat City, Sadat City, Egypt
2	
Computer Science Department, Faculty of Science, Minia University, Minia, Egypt
3	
Faculty of Computers and Artificial Intelligence, Cairo University, Cairo, Egypt
4	
Faculty of Pharmacy and Drug Technology, Chinese University in Egypt (CUE), Cairo, Egypt
5	
Faculty of Pharmacy, University of Sadat City, Sadat City, Menoufia, Egypt


---

# Discovery of Novel c-Jun N-Terminal Kinase 1 Inhibitors from Natural Products: Integrating Artificial Intelligence with Structure-Based Virtual Screening and Biological Evaluation

- **Authors:** Ruoqi Yang, Guiping Zhao, Bin Yan
- **Issuer:** Molecules (Basel, Switzerland)
- **Type:** Scientific article
- **Published:** 2022-09-22
- **Language:** en
- **DOI:** 10.3390/molecules27196249
- **Source:** https://pubmed.ncbi.nlm.nih.gov/36234788/
- **Licence:** CC-BY

## Section: Abstract

c-Jun N-terminal kinase 1 (JNK1) is currently considered a critical therapeutic target for type-2 diabetes. In recent years, there has been a great interest in naturopathic molecules, and the discovery of active ingredients from natural products for specific targets has received increasing attention. Based on the above background, this research aims to combine emerging Artificial Intelligence technologies with traditional Computer-Aided Drug Design methods to find natural products with JNK1 inhibitory activity. First, we constructed three machine learning models (Support Vector Machine, Random Forest, and Artificial Neural Network) and performed model fusion based on Voting and Stacking strategies. The integrated models with better performance (AUC of 0.906 and 0.908, respectively) were then employed for the virtual screening of 4112 natural products in the ZINC database. After further drug-likeness filtering, we calculated the binding free energy of 22 screened compounds using molecular docking and performed a consensus analysis of the two methodologies. Subsequently, we identified the three most promising candidates (Lariciresinol, Tricin, and 4′-Demethylepipodophyllotoxin) according to the obtained probability values and relevant reports, while their binding characteristics were preliminarily explored by molecular dynamics simulations. Finally, we performed in vitro biological validation of these three compounds, and the results showed that Tricin exhibited an acceptable inhibitory activity against JNK1 (IC50 = 17.68 μM). This natural product can be used as a template molecule for the design of novel JNK1 inhibitors.

## Section: 1. Introduction

The c-Jun N-terminal kinases (JNKs), members of the mitogen-activated protein kinase (MAPK) family, can be activated by upstream MKK4/7 kinases and are widely involved in many biological processes such as cell proliferation and apoptosis [1]. Studies have shown that JNKs are encoded by three genes, of which JNK1 and JNK2 are expressed in a variety of organs, whereas JNK3 is mainly expressed in the brain [2,3]. As one of the three isoforms of the JNKs, the structure of JNK1 is similar to other closely related kinases and contains three main parts: an N-terminal lobe with β strands, a C-terminal lobe with α helices, and a hinge region connecting them [4]. The over-expression of JNK1 is considered a key mediator of metabolic disorders, and there have been many reports about this target in the treatment of type-2 diabetes [5]. However, the development of JNK1 inhibitors is still in its infancy. Most of the common JNK1 inhibitors are type I inhibitors, and they mainly block the phosphorylation process of the kinase by occupying the highly conserved ATP-binding pocket and forming hydrogen bonds with the key residue MET-111. The search for novel inhibitors targeting JNK1 is a valuable research direction.

The high diversity of natural products in terms of chemical structures and physicochemical properties makes them a precious source for the discovery of novel active chemicals [6]. Compared to synthetic compounds, the structures of natural products are more complex. It is also due to their unique structural characteristics that many natural products are used as a starting point for drug design [7]. In the pharmaceutical industry, high-throughput screening (HTS) and virtual screening (VS) are two tools frequently adopted for the identification of lead compounds. Experiment-based HTS is known to be an inefficient and lengthy process. In contrast, computation-based VS allows for the rapid screening of large compound databases with less time and money investment [8]. However, there are some problems that cannot be ignored. For example, molecular docking, a representative technique of VS, has a generally high rate of false positive results. In recent years, artificial intelligence (AI) techniques, including machine learning and deep learning, have become increasingly sophisticated in the search for novel active compounds. Studies have shown that combining emerging AI with traditional VS can overcome the shortcomings of individual methods, such as high false positive rates or slow computational speed, thus assisting computational chemists to select lead compounds more reliably [9]. Therefore, the integration of multiple virtual screening strategies facilitates the balance of efficiency and accuracy.

As over-expression of kinases is a major trigger for the development of many diseases, the search for inhibitors targeting different kinases has become one of the hotspots in the field of drug discovery. Zhu et al. performed a virtual screening of glycogen synthase kinase-3 beta (GSK3β) in a parallel manner, combining multiple computational tools including molecular docking, pharmacophore modeling, and naive Bayesian classification. Two potential inhibitors were eventually identified through an in vitro kinase assay [10]. Che et al. significantly improved the performance of molecular docking and pharmacophore-based virtual screening using the AI method, which not only reduced the number of false positive compounds but also successfully identified four active interleukin-1 receptor associated kinase-1 (IRAK1) inhibitors [11]. However, to our knowledge, there is no relevant report on the discovery of natural products targeting JNK1 by integrating computational strategies. In this study, we constructed a sequential “multi-stage virtual screening” system. First, we rapidly identified potential JNK1 inhibitors with desirable pharmacokinetic profiles from thousands of natural products based on machine learning classification models and ADMET prediction. Then, we used structure-based molecular docking to calculate the corresponding binding free energies. After the results of two rounds of screening were analyzed by consensus, the candidate compounds with high scores were selected. Subsequently, the action mechanism and binding stability of these inhibitors were further explored by binding mode analysis and molecular dynamics simulation. Finally, the reliability of the protocol was verified by biological assay.

## Section: 2. Results › 2.1. Chemical Space Distribution

In general, using a dataset with a broad chemical space to build a model, as well as a reasonable division of the training and test sets, can facilitate the model in better learning the molecular characteristics of active compounds and, thus, improve the prediction performance. In the present study, we visualized the dataset by a principal component analysis (PCA) algorithm in two-dimensional and three-dimensional spaces, where the former was used to analyze the distribution of active and inactive compounds, and the latter was used to analyze the partitioning of the training and test sets [12]. After the feature selection step, a total of 120 descriptors were finally used for PCA. Their specific information is listed in Table S1. From Figure 1A, we can see that the spatial regions of active and inactive compounds in the JNK1 dataset are mostly overlapping, mainly distributed in the range of −10 to 10 and −7.5 to 7.5 for PCA_1 and PCA_2, respectively. In addition, we also notice that the compounds in the dataset are diverse in molecular structure, which implies that the application domain of the model will be relatively wide. As shown in Figure 1B, the chemical spaces of the training and test sets are very similar, mainly distributed between −10 and 5 for PCA_1, −2.5 and 7.5 for PCA_2, and −7.5 and 2.5 for PCA_3. These results indicate that the division method is feasible.

## Section: 2. Results › 2.2. Establishment and Comparison of Machine Learning Models

Three machine learning models were constructed using the molecular descriptors after feature selection, and the hyperparameters were tuned on the training set by the Bayesian optimization algorithm combined with 10-fold cross-validation. The combination of hyperparameters for each model was set as follows: n_estimators = 283, max_depth = 25, and max_features = 0.231 in the RF model; kernel = “rbf”, C = 4.691, and gamma = 0.013 in the SVM model; hidden_layer_sizes = 201 and alpha = 0.155 in the ANN model. The prediction performance of each model on the training set is shown in Figure 2A, where we can see that the average accuracy of all models was higher than 82%. Generally, lower precision reflects a higher rate of false positives and lower recall represents a weaker ability of the model to discriminate positive samples. In this study, we focused more on the precision of the model, considering that our aim was to increase the proportion of true positive samples among the screened compounds as much as possible. In addition, among the metrics of machine learning models, AUC is more informative in that it provides a reasonable evaluation of the performance of the classifier, and the closer the AUC value of a model is to 1, the stronger its predictive power. In the three models generated for JNK1, the average precision was greater than 79% and the average AUC values exceeded 0.89. The generalization ability reflects the prediction performance of the machine learning models on the unknown dataset, which is usually more valuable than that on the training set. As shown in Figure 2B,C, the performance of the three models on the test set was comparable to that on the training set, which indicates that the models were not overfitted and the prediction results were relatively reliable.

As each algorithm predicts active compounds based on distinct principles and there is no significant difference in the prediction performance of the constructed individual models, we next integrated the three classifiers using two model fusion strategies. Voting is a simple and effective fusion method that can weight the prediction results of individual models to ensure performance while improving model diversity. Stacking is a more powerful learning-based fusion strategy that uses the initial dataset to train the “component learner” and then generates a new dataset for training the “meta-learner”. The results are shown in Table 1; the integrated models generally outperformed the single models in terms of prediction performance on the training and test sets, with AUC values of 0.906 and 0.908, as well as overall accuracies of 84.2% and 83.2%, respectively. This phenomenon demonstrates that the integrated models based on Voting and Stacking strategies have more desirable discrimination abilities and are more suitable for virtual screening of small-molecule databases.

## Section: 2. Results › 2.3. Feature Importance Ranking

To better explain the potential association between each molecular descriptor and compound activity, we obtained the 10 descriptors with the highest correlation based on the ranking of feature importance in the RF model. For the JNK1 activity prediction model, SlogP_VSA8, BCUT2D_MWLOW, and Kappa3 were the features with relatively high importance, which also indicated that they contributed more to the prediction of the machine learning model (Figure S1). These descriptors could provide important guidance for the discovery of potential inhibitors.

## Section: 2. Results › 2.4. Integrated Model-Based Activity Prediction and Drug-Likeness Filter

Following the generation of machine learning models and evaluation of their predictive performance, the activity prediction of 4112 named natural products in the ZINC database was performed using the integrated models. The 208 RDKit descriptors were first calculated for all molecules, and then the same data preprocessing and feature selection steps were performed. To further improve the reliability of the screening results, we set the threshold of both integrated models to 0.8, which finally showed a total of 343 compounds predicted as JNK1 inhibitors. It should be noted that the results will be useful only if the predicted molecules are located in the chemical space of the trained molecules. Therefore, we applied PCA on the 4112 predicted natural products and saw whether they lay within the range of the training set. The results showed that the chemical space distribution of most of the predicted compounds overlapped with that of the trained compounds, which also implies that the virtual screening results based on machine learning are reliable (Figure S2).

Subsequently, we predicted the ADMET properties of these compounds and further filtered them according to the set criterion. Specifically, the desirable compounds should satisfy the Lipinski’s Rule of Five and have the value of Log of the aqueous solubility (LogS) between −4 and 0.5, the value of Human Intestinal Absorption (HIA) greater than 30%, the value of Medicinal Chemistry Evolution (MCE-18) greater than 45, and the ability to penetrate the Blood–Brain Barrier (BBB). In addition, all compounds should have no risk of toxicity, including mutagenicity, carcinogenicity, hepatotoxicity, and oral acute toxicity. We finally obtained 22 drug-like molecules with acceptable ADMET properties, and the correlation clustering analysis among them is shown in Figure 3. The overall similarity among the proposed hits was low, and the matrix color was relatively green (less than 0.5), while the results of hierarchical clustering indicated that these compounds showed diversity in chemical structure.

## Section: 2. Results › 2.5. Virtual Screening Based on Molecular Docking

Molecular docking is one of the most commonly used techniques in computer-aided drug design (CADD) to predict the binding mode of small molecules in the active pocket of target proteins and to calculate the affinity between them. To ensure the reliability of the docking protocol adopted (i.e., whether the true binding conformation between ligand and receptor can be correctly predicted), we performed re-docking and calculated the RMSD between the docking pose and the co-crystallized conformation [13]. In general, if the RMSD value is ≤2.0 Å, it means that the prediction performance of molecular docking is satisfied. In the present study, the RMSD value of the re-docking was 1.27 Å, which indicates that the docking process is reliable. We then docked the candidate compounds obtained after the first round of screening into the binding site of the target protein, and the binding free energies are shown in Figure 4. Specifically, 14 out of 22 candidate compounds had binding free energies below −8.0 kcal/mol, among which ZINC4098820 exhibited the highest affinity (−9.3 kcal/mol). It is worth noting that the affinities of these hits were lower than those of the co-crystallized ligand (−10.6 kcal/mol), which suggests that their efficacy could be improved by further molecular modification.

## Section: 2. Results › 2.6. Identification of Candidate Compounds

Reducing the proportion of inactive compounds in the virtual screening results not only enhances the reliability of the whole process but also saves expenses and time for the subsequent biological evaluation. In this study, we obtained the rankings of 22 candidate compounds for the consensus analysis based on self-defined criteria, and 13 of them have a total score greater than 0.8, which means they have the potential to become lead compounds for JNK1 inhibitors. Details of the top five compounds are shown in Table 2. By searching the relevant literature, we found relatively few reports on Nigracin (ZINC40879757) and Ophiopogonanone E (ZINC13481984). Considering the feasibility and application value, we focused on three compounds: Lariciresinol (ZINC4098820), Tricin (ZINC5998961), and 4′-Demethylepipodophyllotoxin (ZINC5670074), which have excellent effects in anti-inflammation, anti-tumor, and anti-infection [14,15,16].

## Section: 2. Results › 2.7. Analysis of Drug–Protein Interaction

To further elucidate the binding modes of the candidate inhibitors to the target protein, we analyzed the interactions of these three compounds with key amino acids using LigPlot+ software, and the 2D/3D views are illustrated in Figure 5 and Figure 6, respectively. Previous studies have shown that the hydrogen bonding interaction formed by the small-molecule ligand with the hinge region residue MET-111 may be crucial for the inhibitory activity against JNK1 [17]. Lariciresinol exhibited the strongest binding affinity to JNK1, and the hydroxyl groups on its two sides of the benzene ring established hydrogen bonding interactions with three residues GLU-109, MET-111, and GLN-117, while another hydrogen bond was observed between residue SER-34 and the hydroxyl group on the tetrahydrofuran (Figure 5A and Figure 6A). Likewise, the two hydroxyl groups on the benzene ring of Tricin formed three hydrogen bonds with two residues GLU-109 and MET-111, while one hydroxyl group on the other side of the benzene ring interacted with residue SER-34 through another hydrogen bond (Figure 5B and Figure 6B). 4′-Demethylepipodophyllotoxin also formed one hydrogen bond with residue MET-111 (Figure 5C and Figure 6C). In addition, several residues including ILE-32, VAL-158, LEU-168, and ALA-53 were involved in the formation of hydrophobic interactions. These residues are essential for the stable binding of drugs and proteins. Notably, we found two hydrogen bonds between the co-crystallized ligand and residues MET-111 and GLN-117, from which we speculate that these three candidate compounds have similar binding modes with the co-crystallized ligand and belong to type I inhibitors. In recent years, many researchers have conducted extensive research on inhibitors targeting JNK1 in the hope of discovering effective small-molecule inhibitors. Liu et al. utilized the HTS technique for the identification of JNK1 inhibitors and the result showed that the screened hit formed one hydrogen bond with amino acid residue MET-111 [18]. Similarly, another candidate inhibitor designed by Gong et al. interacted with residues LEU-110 and MET-111 in the hinge region through two hydrogen bonds [19]. These results are consistent with our proposed compounds.

## Section: 2. Results › 2.8. Molecular Dynamics Simulation

Molecular dynamics simulations can predict the dynamic processes of complex systems under restrictive conditions and provide a theoretical basis for the validation of experimental results. RMSD is the best parameter to detect the stability of the system as it is usually used to assess the structural shift between two conformations. As shown in Figure 7A, all systems gradually reached the equilibrium state after 10 ns. Specifically, the RMSD values of the JNK1-co-crystallized ligand and JNK1-Tricin complexes were low, while the RMSD values of the JNK1-4′-Demethylepipodophyllotoxin and JNK1-Lariciresinol complexes were generally high, which implies that the latter two systems exhibited more intense motions and greater conformational differences during the simulation. Notably, although the JNK1-4′-Demethylepipodophyllotoxin complex showed a larger degree of dynamic variation, its RMSD values fluctuated in a relatively small range, indicating that the stability of this system was slightly better. RMSF is the best parameter for the evaluation of the structural flexibility of proteins as it is often employed to measure the fluctuation of amino acid residues. As shown in Figure 7B, the trend of RMSF was roughly consistent for all systems, and the residues in region 330–350 fluctuated the most significantly. These results suggest that this region was more flexible and may be the binding site for the ligand to the protein. In addition, Rg is a common parameter to characterize the structural tightness of proteins, and SASA is an important parameter to describe the hydrophobicity of protein surfaces. As shown in Figure 7C,D, all systems displayed stable trajectories of Rg and SASA, which also explains to some extent that the protein was able to bind to the ligands stably during the simulation.

We also analyzed the binding mode of each ligand in the active pocket of the target protein after the simulation was completed. Figure 8 depicts the results, which showed that some compounds retained the key interactions while others formed new interactions with amino acid residues. The reason for the occurrence of the above phenomenon may be the conformational changes of the complexes during the simulation. Specifically, the co-crystallized ligand lost the hydrogen bonding interaction with GLN-117 after the simulation, while the hydrogen bond with MET-111 was retained (and an additional hydrogen bond was formed). Lariciresinol retained only the interaction with MET-111. However, this compound formed two new hydrogen bonds with residues ASN-114 and SER-155 (Figure 8B). Tricin lost one hydrogen bond formed between it and MET-111 after the simulation, while other hydrogen bonds were retained (Figure 8C). 4′-Demethylepipodophyllotoxin not only retained the hydrogen bond with MET-111 but also formed new interactions with residues ASN-114 and GLU-109 (Figure 8D). It should be noted that all three candidate compounds retained hydrogen bonding interactions with the key residue MET-111 after the simulation, which may be the main reason for their stable binding.

To further investigate the binding affinity between the candidate compounds and the target protein, we calculated the binding free energy of the complexes formed by the four ligands with JNK1 using the MM/PBSA method and ranked these values based on the principle that the lower the binding free energy, the more favorable the binding. The results are as follows: co-crystallized ligand (−118.34 ± 29.11) > Lariciresinol (−84.53 ± 9.51 kJ/mol) > Tricin (−80.22 ± 10.08 kJ/mol) > 4′-Demethylepipodophyllotoxin (−78.18 ± 10.67 kJ/mol), which is consistent with molecular docking. Furthermore, the contributions of the energy terms indicate that van der Waals energy, electrostatic energy, and SASA energy play a facilitating role for drug–target binding, while polar solvation energy is detrimental to the stable binding of both (Table 3).

## Section: 2. Results › 2.9. Biological Evaluation

Finally, we purchased the three candidate compounds for in vitro biological validation. The initial concentration of each compound was set at 50 µM, and the final concentration was 195 nM after a two-fold gradient dilution. The results of the kinase assay are shown in Table 4. Tricin exhibited a 75.4% inhibition of JNK1 at the concentration of 50 µM and had an IC50 value of 17.68 μM. In contrast, Lariciresinol and 4′-Demethylepipodophyllotoxin exhibited a relatively weak inhibition of JNK1 (IC50 > 50 μM). These results confirm that our virtual screening process is reliable. In addition, the proposed compound Tricin can also be used as a lead compound for the design of JNK1 inhibitors.

## Section: 3. Discussion

JNK1 in the MAPK family is currently a key target for the treatment of type-2 diabetes. Considering the unique advantages of natural products, the identification of inhibitors targeting JNK1 from them is extremely attractive. In recent years, virtual screening methods based on computational strategies have opened new paths for the development of natural products. Machine learning algorithms have shown high success rates in the discovery of active compounds, and combining them with traditional CADD techniques could improve the efficiency as well as the reliability of virtual screening [20].

In the present study, we first constructed three machine learning classification models for the JNK1 dataset and evaluated the prediction performance of these models with different metrics. It turns out that all three models exhibit good performance on the test set, with accuracy, precision, and AUC ranging from 0.825 to 0.828, 0.748 to 0.777, and 0.891 to 0.896, respectively. In addition, exploring the spatial distribution of the dataset is an integral step. The most commonly adopted space mapping technique is PCA, which is capable of projecting data from high to low dimensions while ensuring minimal information loss [12]. The results of PCA indicated that the training set used for modeling had a wide chemical space.

As the diversity of algorithms leads to different prediction results, we integrated these three individual models based on two model fusion strategies (i.e., Voting and Stacking) to further enhance the generalization performance. The results showed that the integrated models had better performance on the test set than the individual models. Next, we used two integrated models for activity prediction of natural products in the ZINC database and performed pharmacokinetic and toxicity risk assessment. After the first round of screening, we obtained 22 potential candidate compounds.

The molecular docking-based virtual screening strategies have the obvious drawbacks of high false positive rates and slow computational speed. To overcome this problem, we narrowed down the search space using machine learning models, and, thus, only a small number of compounds needed to be docked in the second round of screening. Subsequently, a consensus analysis of the two methodologies was performed to obtain an overall score. According to the literature, we selected three compounds with known activities for further analysis. Molecular docking and molecular dynamics simulation demonstrated that these three compounds interacted with key amino acid residues and bound stably to the target protein via van der Waals and electrostatic interactions. In addition, the results of the kinase assay showed that the proposed molecule Tricin, a flavonoid isolated from Zizania latifolia, exhibited better inhibitory activity against JNK1 (IC50 = 17.68 μM).

In this study, we designed a complete virtual screening process of “machine learning-ADMET prediction-molecular docking-molecular dynamics simulation”. The program is characterized by a comprehensive combination of the advantages of traditional CADD and advanced AIDD, taking into account both the activity of the compounds and the structure of the protein, as well as analyzing the binding mode and binding stability of them. However, it is difficult to ignore that the whole process still has many limitations that need to be addressed. On the one hand, the number of compounds available for the machine learning modeling process is not sufficient. The dependence of the model on data is one of the primary constraints for the application of machine learning in the field of drug development. Considering the quality of training data sourced from various public databases has a great impact on the performance of the model, these data must be reliable to ensure the accuracy of the prediction results [21]. On the other hand, machine learning techniques are limited by the complexity of the model (the so-called “black box”), which makes it difficult to provide a reasonable interpretation or analysis of the prediction results in some cases [22]. Overall, we hope this study could provide a theoretical basis for the drug design of novel JNK1 inhibitors. In the future, we will conduct structure–activity relationship (SAR) research and further improve the activity of the screened compound through rational structural modification methods.

## Section: 4. Materials and Methods › 4.1. Machine Learning Dataset › 4.1.1. Data Preparation

We retrieved the inhibitors of JNK1 from the ChEMBL Database (https://www.ebi.ac.uk/chembl/, accessed on 27 March 2022) and the dataset was processed based on the following criteria: (i) duplicates and compounds with no identified activity were deleted; (ii) compounds with IC50 values less than 1 μM were marked as “active”, while the rest were marked as “inactive”. It should be noted that to ensure the reliability of the data, we only considered compounds with an assay type of “B” (i.e., directly bound to the target). After a series of preprocessing, we obtained a JNK1 dataset containing 1138 active compounds and 285 inactive compounds, which were randomly divided into training and test sets in a 4:1 ratio.

## Section: 4. Materials and Methods › 4.1. Machine Learning Dataset › 4.1.2. Descriptors Pruning

Molecular descriptors mathematically characterize the chemical information of a molecule in the form of numbers [23]. With the help of the open-source toolkit RDKit (http://www.rdkit.org, accessed on 18 September 2022), we calculated 208 molecular descriptors for all compounds to determine the relationship between activity and molecular properties. Generally, in the process of machine learning model building, we need to dimensionalize the dataset (i.e., convert the data to the same specification) to avoid the impact of certain features with a particularly large range of values. Moreover, it is also crucial to select those features that contribute more to the prediction performance. Thus, we eliminated redundant and irrelevant descriptors in three steps: (i) calculate the variance of each descriptor and remove the descriptors with zero variance because these features all take the same value and are useless for sample classification; (ii) calculate the mutual information between descriptors and the IC50 value (label) and remove the descriptors with zero mutual information because these features are independent of the label, which not only wastes computational memory but also introduces noise [24]; (iii) calculate the Pearson correlation coefficient between all descriptors. If the value between any pair is higher than 0.8, only one of them is remained, which can avoid collinearity and enhance the interpretability of the model.

## Section: 4. Materials and Methods › 4.2. Machine Learning Algorithms › 4.2.1. Classifier Construction

Among the available machine learning algorithms, random forest (RF), support vector machine (SVM), and artificial neural network (ANN) are widely used for the discovery of lead compounds due to their excellent performance and outstanding robustness. In this study, three individual machine learning models (RF, SVM, and ANN) and two integrated machine learning models (Voting and Stacking) were constructed based on the Scikit-learn library of Python (https://scikit-learn.org/stable/, accessed on 18 September 2022). Specifically, the RandomForestClassifier(), svm.SVC(), MLPClassifier(), VotingClassifier(), and StackingClassifier() methods were applied.

RF, a representative ensemble algorithm based on Bagging, consists of multiple mutually independent decision trees, and the final prediction is obtained by averaging the results of overall decision trees [25]. The “randomness” of the RF algorithm is mainly reflected in two aspects: one is the formation of different training sets by random sampling with put-back (also known as bootstrapping), and the other is the use of a subset of features to split each node of the decision tree. The hyperparameters “n_estimators”, “max_depth”, and “max_features” have a substantial impact on the performance of RF.

SVM is a supervised machine learning algorithm that distinguishes between different classes of samples in a dataset by establishing a hyperplane (decision boundary) with the maximum interval [26]. The SVM algorithm provides a good balance between model complexity and learning ability, while having excellent generalization performance. The kernel function is the key to the dimensional transformation of SVM, which is divided into a linear kernel, polynomial kernel, and radial basis function (RBF). In addition, “C” and “gamma” are also significant hyperparameters of SVM.

ANN originates from the human nervous system and is composed of many interconnected nodes called artificial neurons [27]. The input signal is first processed by the nodes in the input layer and is then passed to the nodes in the hidden layer connected to it; finally, the corresponding prediction result is obtained through the nodes in the output layer. Two hyperparameters, “hidden_layer_sizes” and “alpha”, are used for the tuning of ANN.

As these machine learning algorithms have many hyperparameters, we need to obtain the best combination of them. Grid search is a traditional automatic tuning method, which searches the entire hyperparameter space exhaustively with low efficiency. The Bayesian optimization algorithm employs the Gaussian process to take full account of the prior information and perform the tuning of hyperparameters with a minimum number of iterations. In this study, we performed the tuning of the key hyperparameters mentioned above on the training set by the Bayesian optimization algorithm combined with 10-fold cross-validation.

## Section: 4. Materials and Methods › 4.2. Machine Learning Algorithms › 4.2.2. Classifier Evaluation

In the present study, we used five common metrics to evaluate the generated machine learning models, including accuracy, precision, recall, F1-score, and the area under the receiver operating characteristic (ROC) curve. These statistical parameters are calculated from true positives (TP), true negatives (TN), false positives (FP), and false negatives (FN). Accuracy represents the proportion of correctly predicted compounds to the total compounds. Precision represents the proportion of truly active compounds out of all compounds predicted to be active, while recall represents the proportion of the compounds that are correctly predicted by the model out of all compounds that are truly active. F1-score is the harmonic average of precision and recall. The ROC curve takes the false positive rate and recall as the horizontal and vertical coordinates (under different thresholds), respectively, and the area under the curve (AUC) is one of the most important metrics in model evaluation. They are calculated by Equations (1)–(4). (1)Accuracy =TP+TNTP+FP+TN+FN (2)Precision =TPTP+FP (3)Recall =TPTP+FN (4)F1−score =2×Precision×RecallPrecision+Recall

## Section: 4. Materials and Methods › 4.3. ADMET Studies

To avoid the failure of the screened drugs at the clinical trial stage, it is necessary to perform the absorption, distribution, metabolism, elimination, and toxicity (ADMET) prediction of compounds. The online server ADMETlab 2.0 (https://admetmesh.scbdd.com/, accessed on 18 September 2022), based on the multi-task graph attention (MGA) framework for model training, is capable of calculating 88 ADMET properties, covering almost all pharmacokinetics and toxicities of interest to medicinal chemists [28]. In this study, we performed ADMET prediction for candidate compounds obtained from the machine learning models and further filtered them according to the set criterion. All drug-like molecules that met these criteria were used for molecular docking studies.

## Section: 4. Materials and Methods › 4.4. Molecular Docking

To calculate the binding affinity of the screened hits to JNK1, we performed a semi-flexible docking. The crystallographic structure of JNK1 was downloaded from Protein Data Bank (https://www.rcsb.org/, accessed on 18 September 2022) and preprocessed as follows: the missing atoms were inserted, the water and the co-crystallized ligand (PubChem CID: 25113171) were removed, the polar hydrogen atoms were added, and the Gasteiger charges were recalculated. The 3D structures of the small-molecule ligands were downloaded from PubChem (https://pubchem.ncbi.nlm.nih.gov/, accessed on 18 September 2022) and minimized with the MM2 force field. The grid box was generated with the co-crystallized ligand as the center, and the parameters were set as follows: center_x = 22.78, center_y = 38.34, center_z = 31.17, size_x = size_y = size_z = 12.5, and exhaustiveness = 30. To verify the feasibility of the docking process, the extracted co-crystallized ligand was re-docked into the target protein and the root-mean-square deviation (RMSD) was calculated. All candidate molecules were subjected to molecular docking studies by AutoDock Vina software [29]. After docking was completed, the protein–ligand complexes were analyzed for interactions using LigPlot+ software [30].

## Section: 4. Materials and Methods › 4.5. Consensus Analysis

To minimize the false positive rate as much as possible, we performed a consistency analysis on the results of the two rounds of screening. In this study, we defined the scores for machine learning classification models and molecular docking calculations. Specifically, the former S(Machine Learning) is the average of the confidence levels of the candidate compounds in the two integrated models, and the latter S(Molecular Docking) is the ratio of the binding free energies of the candidate compounds to the co-crystallized ligand, and they both take values in the range of 0–1. The final total score S(JNK1) is the average of these two values.

## Section: 4. Materials and Methods › 4.6. Molecular Dynamics Simulation

To further investigate the dynamic stability of ligand–protein interactions, we performed molecular dynamics simulations of the complex systems using Gromacs software [31]. The topological parameters of ligands and the target protein were generated with the help of the online webserver Swiss Param (https://www.swissparam.ch/, accessed on 18 September 2022) and the pdb2gmx tool [32]. First, the protein–ligand complex was placed in the center of a cubic box with the boundary set to 1.2 nm and filled with the TIP3P water model [33]. Then, the charge of the system was balanced by adding counterions (Na+ and Cl− ions). Next, the system was subjected to 50,000 steps of energy minimization to avoid steric collisions between the ligand and the protein. To restrict the position of the complex, the system temperature was raised to 300 K followed by the NVT equilibration, and then the system pressure was raised to 1 bar followed by the NPT equilibration. Finally, a molecular dynamics simulation was performed for 30 ns. After the simulation, the RMSD (root-mean-square deviation), RMSF (root-mean-square fluctuation), Rg (radius of gyration), and SASA (solvent accessible surface area) of each system were analyzed. Furthermore, we extracted the trajectory files from 20–30 ns stable dynamics trajectories and employed the MM/PBSA method to calculate the binding free energy of each system [34].

## Section: 4. Materials and Methods › 4.7. Kinase Assay

The inhibitory activity of the candidate compounds against JNK1 was measured by the Lance® Ultra kinase assay from PerkinElmer. The candidate compounds were first dissolved in DMSO solution to the initial concentration, and then serially diluted two-fold for 10 points. Then, 40 µL of the compound solutions at each concentration was added to a 384-well plate. In addition, one compound-free control well and one kinase-free control well were set-up. Subsequently, 10 µL of kinase buffer solution and 10 µL of substrate solution were added to the kinase-free control well of the plate, while 10 µL of kinase solution and 10 µL of substrate solution were added to the remaining wells. The plate was incubated at room temperature for 10 min, and the reaction was stopped by adding EDTA solution. At the same time, 20 µL of the detection solution was added to the plate and incubated for 60 min. After the above procedure was completed, the Lance signal ratio (665 nm/615 nm) for each well was obtained using the Envision program, and the inhibition rate was calculated according to Equation (5). Finally, all data were imported into MS Excel and the IC50 values of the candidate compounds were calculated with the help of the curve fitting tool XLFit (version 5.4.0.8). (5)Percent inhibition =the Ratio of no compound control − the Ratio of samplethe Ratio of no compound control − the Ratio of no kinase control×100
