# Ligand-Receptor Interactions and Machine Learning in GCGR and GLP-1R Drug Discovery

- **Authors:** Mikołaj Mizera, Dorota Latek
- **Issuer:** International journal of molecular sciences
- **Type:** Scientific article
- **Published:** 2021-04-14
- **Language:** en
- **DOI:** 10.3390/ijms22084060
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33920024/
- **Licence:** CC-BY

## Page 1 (Section: Introduction )

International Journal of 
Molecular Sciences
Article
Ligand-Receptor Interactions and Machine Learning in GCGR
and GLP-1R Drug Discovery
Mikołaj Mizera
and Dorota Latek *


Citation: Mizera, M.; Latek, D.
Ligand-Receptor Interactions and
Machine Learning in GCGR and
GLP-1R Drug Discovery. Int. J. Mol.
Sci. 2021, 22, 4060. https://doi.org/
10.3390/ijms22084060
Academic Editor: Irina Moreira
Received: 24 February 2021
Accepted: 7 April 2021
Published: 14 April 2021
Publisher’s Note: MDPI stays neutral
with regard to jurisdictional claims in
published maps and institutional afﬁl-
iations.
Copyright: © 2021 by the authors.
Licensee MDPI, Basel, Switzerland.
This article is an open access article
distributed
under
the
terms
and
conditions of the Creative Commons
Attribution (CC BY) license (https://
creativecommons.org/licenses/by/
4.0/).
Faculty of Chemistry, University of Warsaw, Pasteura 1, 02-093 Warsaw, Poland; mikolajmizera@gmail.com
* Correspondence: dlatek@chem.uw.edu.pl
Abstract: The large amount of data that has been collected so far for G protein-coupled receptors
requires machine learning (ML) approaches to fully exploit its potential. Our previous ML model
based on gradient boosting used for prediction of drug afﬁnity and selectivity for a receptor subtype
was compared with explicit information on ligand-receptor interactions from induced-ﬁt docking.
Both methods have proved their usefulness in drug response predictions. Yet, their successful
combination still requires allosteric/orthosteric assignment of ligands from datasets. Our ligand
datasets included activities of two members of the secretin receptor family: GCGR and GLP-1R.
Simultaneous activation of two or three receptors of this family by dual or triple agonists is not a
typical kind of information included in compound databases. A precise allosteric/orthosteric ligand
assignment requires a continuous update based on new structural and biological data. This data
incompleteness remains the main obstacle for current ML methods applied to class B GPCR drug
discovery. Even so, for these two class B receptors, our ligand-based ML model demonstrated high
accuracy (5-fold cross-validation Q2 > 0.63 and Q2 > 0.67 for GLP-1R and GCGR, respectively). In
addition, we performed a ligand annotation using recent cryogenic-electron microscopy (cryo-EM)
and X-ray crystallographic data on small-molecule complexes of GCGR and GLP-1R. As a result,
we assigned GLP-1R and GCGR actives deposited in ChEMBL to four small-molecule binding sites
occupied by positive and negative allosteric modulators and a full agonist. Annotated compounds
were added to our recently released repository of GPCR data.
Keywords: G protein-coupled receptors; machine learning; gradient boosting; induced-ﬁt docking;
virtual screening; molecular docking; scoring functions; drug discovery; glucagon receptor family;
GCGR; GLP-1R; secretin receptor family; class B GPCRs
1. Introduction
The glucagon receptor subfamily of secretin-like G protein-coupled receptors includes
GCGR, GLP-1R (and GLP-2R), and GIPR. A physiological model of their activation involves
peptide agonists: glucagon, GLP-1, GLP-2, and GIP and is involved in G protein-mediated
signal transduction that leads to an increase or decrease in glucose/insulin blood serum
levels [1,2]. Recent lifestyle and diet changes with increasingly reported drug side effects
have brought attention to new antidiabetic pharmacotherapies involving these receptors [3].
Until recently, drug discovery for the glucagon receptor family succeeded in more potent
analogs of endogenous peptides targeting the orthosteric binding site and small-molecule
ligands targeting the extra-helical, allosteric sites of these receptors [2,4]. The later ones,
with a V-shaped conformation, block transmembrane helix 6 (TMH6) deformation and
prevent receptor activation. Thus, they act as negative allosteric modulators (NAMs),
which binding modes has been discovered only recently [5–7]. Although non-peptide
agonists of the glucagon receptor subfamily members were known, e.g., Boc5 or BETP,
it was not clear how they could interact with transmembrane domains (TMDs) [8,9].
Spacious orthosteric binding sites in all known at that time structures of secretin-like GPCRs
(named also class B GPCRs) seemed to be less druggable for small-molecules compounds
Int. J. Mol. Sci. 2021, 22, 4060. https://doi.org/10.3390/ijms22084060
https://www.mdpi.com/journal/ijms

## Page 2 (Section: Introduction )

Int. J. Mol. Sci. 2021, 22, 4060
2 of 16
comparing class A, except for the region deep inside of the receptor core like in, e.g., CRF1
(PDB id: 4K5Y) [10–12]. Recent advances in cryo-EM have ﬁnally provided a detailed
structural description of class B GPCR receptors bound to small-molecule agonists [13–17].
Namely, three additional small-molecule binding sites of GLP-1R, located in or close to the
TMD orthosteric site, have been revealed, providing a complete picture of class B GPCRs
activation [13,14,16,17].
Despite these recent advances in cryo-EM, cheminformatics data for the glucagon
receptor family deposited in, e.g., ChEMBL—an open-access bioactivity database [18],
is still ambiguous and not mapped into all accessible structural data gathered so far for
these receptors. This prevents efﬁcient use of pharmacological data by machine learning
algorithms in searching for new or more potent actives. As a result, the performance
of ligand-based approaches to drug discovery is still limited and below the actual ML
algorithms capabilities.
In this study, we mapped GCGR and GLP-1R actives deposited in ChEMBL onto
structural data for these receptors, including their four different small-molecule binding
sites. This ligands annotation was not limited to the ortho/allostery distinction, like
in a previous study by Burggraaff et al. [19], but also included a distinction between
three different allosteric binding sites observed so far in structures of GCGR and GLP-1R
receptors [5–7,13,15].
In parallel, we demonstrated that both ligand-based and structure-based approaches
to GPCR drug discovery are sensitive to subtle differences between compounds targeting
different binding sites in the receptor. Only based on results either from ML or from
molecular docking we were able to select one distinct group of GLP-1R ligands among all
curated GLP-1R ligands derived from ChEMBL. What is more, both approaches, molecular
docking, and machine learning, demonstrated moderate-to-high accuracy in the prediction
of half-maximal response concentrations of GCGR and GLP-1R compounds. Nevertheless,
their efﬁcient combination, like in, for example, 4D-QSAR [20], still requires the precise
ligands annotation regarding their binding sites in a receptor. Recently, Venugopal et al. [21]
developed a 3D-QSAR model for GCGR antagonists combined with molecular docking
and molecular dynamics simulations. The model was developed using the Partial Least
Square regression method and 58 structurally similar β-alanine derivatives (44 in a training
set and 14 in a test set) that were presumed to bind the extra-helical, allosteric binding site
of GCGR. The model demonstrated good statistical characteristics with Q2 equal to 0.83,
yet for a much smaller dataset (58 vs. 650 compounds) corresponding to a limited subset
of the chemical space of GCGR actives (β-alanine derivatives) compared to the ChEMBL
dataset.
The main aim of this study was to develop a machine learning approach to identify
new actives of the glucagon receptor family. We achieved Q2 equal to 0.63 (±0.07) for
GLP-1R and 0.67 (±0.04) for GCGR in prediction of half maximal effective/inhibitory
concentration (pEC50/pIC50), respectively. We also attempted ML for GIPR, yet the curated
ChEMBL dataset for this receptor was too small for the current study. Our model can
be used not only in the prediction of GCGR and GLP-1R actives separately but also
in searching for dual-action compounds that could demonstrate increased efﬁciency in
pharmacotherapy without causing additional adverse effects [22]. Known-to-date peptide
compounds demonstrating a dual-action effect on glucagon receptor family members
include dual agonists of GLP-1R/GIPR [23] and GLP1R/GCGR [24], and triple agonists of
GLP-1R/GIPR/GCGR [2]. Previous studies [25,26] also reported peptide compounds that
were simultaneously GLP-1R agonists and GCGR antagonists.
In this paper, the approach we used to model the structure-activity relationship for
GLP-1R agonism, and GCGR antagonism was based on gradient boosting (GB) and our
recent study [27]. The structures of compounds with known pEC50 values for GLP-1R and
pIC50 values for GCGR after curation were parametrized with ﬁngerprints and used for
model development and validation.

## Page 3 (Section: Results )

Int. J. Mol. Sci. 2021, 22, 4060
3 of 16
2. Results
2.1. Recent Advances in Crystallography and Cryo-EM of the Glucagon Receptor Family
Activation of class B GPCRs involves two-domain interactions with peptide agonists
that span across a transmembrane domain (TMD) and an extracellular domain (ECD) of
a receptor. It is known, that small-molecule compounds may act as negative allosteric
modulators when bound to the extra-helical region of TMD [5,7]. Till recently, there had
been no complexes with small-molecule ligands targeting orthosteric sites of class B GPCRs
described by either X-ray crystallography or cryo-EM and it was not clear how small-
molecule agonists could interact with TMD [10,11]. Based on the ﬁrst structure of class B
GPCR (GCGR) [28], it seemed that most residues important for ligand-based activation of
class B GPCRs were rather located further down in the receptor core comparing class A
GPCRs [11]. The exception of CRF1 [12] with NAM located deeply in the orthosteric pocket
and not in a typical orthosteric region observed in class A GPCRs, seemed to conﬁrm this
assumption. Nevertheless, early biochemical data on the GLP-1R response to a non-peptide
agonist BETP conﬁrmed that it indeed interacts with TMD, yet demonstrating a different
binding mode comparing, e.g., a peptide agonist exendin-4 [9].
In our recent work [3,29], we hypothesized, based on results from receptor-based
virtual screening, that small-molecule ligands could effectively bind also orthosteric sites
of class B GPCRs in a similar way to class A GPCRs. Recent advances in cryo-EM of class B
GPCRs have proved that orthosteric sites of glucagon receptor family members are indeed
druggable for small-molecule ligands [14,16,17]. Small-molecule full agonists of class B
GPCRs bind to the orthosteric site of the receptor—the binding site 2 (see Figure 1). What
is more, small-molecule allosteric modulators of class B GPCRs can bind not only the
extra-helical, membrane-facing, TMD site (the binding site 4, see Figure 1 [5–7], but also the
interior and exterior of the orthosteric site (the binding site 1 and 3, see Figure 1) [13,15].
However, no structure of a class B member with a small-molecule antagonist (or inverse
agonist) located in the orthosteric site, as observed in the case of class A ligands, e.g.,
carazolol (β2AR) [30], has been obtained.
The ﬁrst structure of a member of the glucagon receptor family was the structure
of an inactive conformation of GCGR without any ligand (PDB id: 4L6R) [28]. The next
structure released was the GCGR structure (5EE7) [31] that included an allosteric V-shaped
modulator located in the extra-helical region of TMD, between TMH6 and TMH7, and
facing the lipid bilayer. In the following years, other structures of the glucagon receptor
family members have been solved, a semi-active structure (5NX2) [32], an active and
peptide agonist-bound structure (5YQZ) [33], and inactive structures bound to allosteric
modulators (also V-shaped) [5,6] (see Figure 2). In 2020, new structures of GLP-1R appeared
(see Table 1) [13–15] that surprisingly showed new small-molecule binding sites in class B
receptors (binding sites 1-3, see Figure 1) in the peptide-ﬁtted orthosteric site. Although
one of these PDB structures included a rather large, small-molecule full agonist resembling
a short, linear peptide (see Table 1, 7C2E), one structure (6VCB) included a much smaller
PAM modulator located between TMH1 and TMH2 (see Figure 1).

## Page 4 (Section: Results )

Int. J. Mol. Sci. 2021, 22, 4060
4 of 16
Figure 1. Diversity of small-molecule binding sites in GLP-1R. Binding site 1—6ORV [13], site 2—7C2E [14], site 3—6VCB
(Bueno et al. 2020) with an included peptide agonist shown in blue, site 4 (I) (left)—6LN2 (Wu et al. 2020), site 4 (II)
(right)—5VEW [15]. Binding sites 1 and 3 corresponds to allosteric sites with positive allosteric modulators (PAMs), site 2
to the orthosteric site with a full agonist. The binding site 4, showed here in 6LN2 (4 (I)) and 5VEW (4 (II)) structures, is
occupied by negative allosteric modulators (NAMs). In three cases (2, 3, and 4 (I)), an extracellular domain (ECD) of GLP-1R
is also shown. Additionally, an overlay of three active conformations of the GLP-1R receptor with binding sites 1–3 is shown
on the right bottom. In this additional superposition of GLP-1R structures the site 1 ligand is shown in blue, the site 2 ligand
in green, and the site 3 ligand in yellow. The intracellular part of the receptor that interacts with a G protein complex is
nearly identical in all these three superposed structures. However, the extracellular part of GLP-1R differs signiﬁcantly
from binding sites 1 to 3. The most signiﬁcant differences can be observed in the top region of TMH7 (red), the top region
of TMH1 (blue), and in the extracellular loop EC1 region of the receptor that forms a small helix. The structural diversity
observed in conformations of EC3 is mostly due to differences in in the top region of TMH7, which is much closer to the
ligand-binding sites than TMH6 (orange).

## Page 5 (Section: Results )

Int. J. Mol. Sci. 2021, 22, 4060
5 of 16
Figure 2. A two-domain activation model of GCGR (left) with a comparison between an active conformation (grey, 5QYZ)
with a peptide agonist bound (dark grey) and an inactive conformation (blue-to-red, 5XEZ) with a negative allosteric
modulator (blue, shown in sticks). The bottom region of TMD changes signiﬁcantly in the TMH6 region upon the receptor
activation (left). The ECD domain (blue) moves closer to the Z axis of the receptor upon the activation (left), yet without
signiﬁcant changes of its conformation (right, superimposed active—grey, and inactive—blue ECD conformations with
a truncated (for visibility) peptide agonist from 5YQZ shown in lines). In contrast to slight ECD changes, the top region
of TMD domain (middle) noticeably changes upon the peptide agonist binding. Namely, transmembrane helices TMH1,
TMH6, and TMH7 move away from the receptor core. The allosteric binding site of NAMs (left) corresponds to the binding
site 4 (I) and 4 (II) of GLP-1R ligands shown in Figure 1.
Table 1. Diversity of small-molecule, non-peptide ligands binding to GLP-1R and GCGR receptors.
Receptor
PDB Id 1
Ligand
Ligand Type
Binding Site
GCGR
5XEZ, 5XF1 [6]
NAM 2
Binding site 4,
allosteric, lipids-facing,
outside of TMD 3
GLP-1R
5VEX [5]
NAM
Binding site 4,
allosteric, lipids-facing,
outside of TMD
5VEW [5,7]
NAM
Binding site 4,
allosteric, lipids-facing,
outside of TMD

## Page 6 (Section: Results )

Int. J. Mol. Sci. 2021, 22, 4060
6 of 16
Table 1. Cont.
Receptor
PDB Id 1
Ligand
Ligand Type
Binding Site
6ORV [13]
PAM 4
Binding site 1,
allosteric, close to
orthosteric 5
6VCB [15]
PAM
Binding site 3,
allosteric, close to
orthosteric
7C2E [14]
Full agonist
Binding site 2,
orthosteric
6X1A [17]
Full agonist
Binding site 2,
orthosteric
6XOX [16]
Full agonist
Binding site 2,
orthosteric
6X19 [17]
Full agonist
Binding site 2,
orthosteric
1 PDB id—a Protein Data Bank identiﬁer, 2 NAM—negative allosteric modulator, 3 The extra-helical binding site on the outside of TMD,
located between TMH6 and TMH7, and facing the membrane, 4 PAM—positive allosteric modulator, 5 The binding site in the extracellular
region of TMD, close to the orthosteric site.
The most signiﬁcant structural differences between active and inactive receptor con-
formations can be observed in the case of 6ORV (Site 1) vs. inactive 6LN2 or 5VEW (see
Figure 1). These conformational changes include not only the intracellular part of TMH6,
interacting with a G protein complex, but also the extracellular part of the receptor—a
movement of TMH6 and TMH5 away from the receptor core upon the ligand binding. The
6ORV ligand is large and partly located below the extracellular loop EC1. The binding
site 2 (7C2E) can be also observed in two other PDB entries (see Table 1—6XOX and 6X19)
that include ligands dissimilar to the 7C2E ligand. Nevertheless, these 6XOX and 6X19
ligands were also dissimilar (data not shown) regarding Daylight/Tanimoto descriptors to

## Page 7 (Section: Annotation of Compounds Deposited in ChEMBL )

Int. J. Mol. Sci. 2021, 22, 4060
7 of 16
compounds from the ChEMBL dataset, so we discarded these two structures in the study
for computational reasons.
Known-to-date structures of GCGR include peptide analogs of glucagon bound to
the orthosteric site, and NAMs bound to the allosteric, extra-helical, lipid bilayer-facing
site (see Figure 2). Notably, the 5XEZ structure of GCGR includes the same compound
as the 5VEX structure of GLP-1R (see Table 1), in both cases bound to the same binding
site 4. This proves a frequent lack of selectivity observed between ligands of the glucagon
receptor family members and have also been conﬁrmed by recent ﬁndings of other dual
and triple agonists [2]. Based on this, it is plausible that GCGR (or GIPR) may include the
same binding sites 1-4 as observed in all released to date GLP-1R structures.
2.2. Annotation of Compounds Deposited in ChEMBL
For 265 GLP-1R ligands and 650 GCGR ligands extracted from ChEMBL, we computed
Daylight/Tanimoto descriptors to assess their similarity to PDB ligands shown in Table 1.
Among 265 curated ligands of GLP-1R receptor that were extracted from ChEMBL at the
time of the current study (September 2020), 230 compounds were similar to the linear-
shaped ligand from 6ORV [13]. Both datasets, including 265 and 230 compounds were
deposited in our recently released repository (see: https://db-gpcr.chem.uw.edu.pl). The
remaining 35 actives were not similar to any of the other known PDB ligands of GLP-1R (see
Table 1). In the case of GCGR, the ChEMBL dataset was more diverse. Ninety-four ligands
among 650 ligands derived from ChEMBL possessed a distinct V-shape and were similar to
the allosteric modulator of GCGR from 5XEZ. 5XEZ includes NAM located in the binding
site 4, the only small-molecule binding site in TMD of GCGR that has been deposited in
PDB so far. Interestingly, GCGR ligands deposited in ChEMBL were more similar to the
5XEZ ligand than to the best compound from [21]—compound 20 (94 compounds with
Daylight/Tanimoto coefﬁcient in the range of 0.577–0.150 vs. the 5XEZ ligand and only
12 compounds in the maximal range of 0.191–0.150 vs. compound 20, respectively).
As we mentioned above, it is plausible that GCGR, as a close homolog of GLP-
1R, could also be activated by similar small-molecule orthosteric ligands, like GLP-1R.
Unfortunately, the GCGR dataset derived from ChEMBL included only compounds tested
for the receptor inhibition, and no ligands similar to the ligand from the binding site 1, 2,
or 3 of GLP-1R were included in it.
As a result of the above similarity search and ligand type assignment, we divided
ChEMBL-derived compounds into the following subsets (see: https://db-gpcr.chem.uw.
edu.pl). In the case of GLP-1R, there were two subsets—compounds similar to the binding
site 1 ligand and ‘other’ compounds, not similar to any of the binding site 2, 3, or 4 ligands.
In the case of GCGR, there were also two subsets—compounds similar to the binding site 4
ligand extracted from 5XEZ and ‘other’ compounds.
In the case of GLP-1R, compounds similar to the binding site 1 PDB ligand demon-
strated better response (high pEC50, see Supplementary Figure S1) comparing the ‘other’
subset, which could be the reason why the complex of GLP-1R with the binding site 1
ligand succeeded in structural studies (PDB id: 6ORV). A better response could be related
in this case to a higher afﬁnity for GLP-1R and thus possibly to better stability of the ligand-
receptor complex. Interestingly, compounds similar to the binding site 1 ligand were also
of higher AlogP (high lipophilicity and hydrophobicity and thus high blood-brain-barrier
permeability, see Supplementary Figure S2) comparing the ‘other’ subset. On the other
hand, GCGR compounds similar to the binding site 4 ligands were of medium and best
pIC50 values (see Supplementary Figure S1), but they did not form a separate cluster in
terms of either pIC50, atomic 1-octanol/water partition coefﬁcient AlogP, or Autodock
VINA [34] scores like in the case of GLP-1R actives similar to the binding site 1 ligand.
2.3. Response to Drug-Receptor Structure-Based Predictions
Ligands from the ChEMBL datasets were docked to four different types of binding
sites of GLP-1R. As expected, compounds similar to the 6ORV binding site 1 ligand [13]

## Page 8 (Section: Annotation of Compounds Deposited in ChEMBL )

Int. J. Mol. Sci. 2021, 22, 4060
8 of 16
demonstrated the best afﬁnity to GLP-1R structures with binding sites 1 and 2 (see Figure 3).
Binding sites 3, 4 (I) (Wu et al., 2020), and 4 (II) were least ﬁtted to ChEMBL-derived
compounds, possibly also because they were simply less cavity-like. The PDB ligand from
6ORV (the binding site 1 ligand) that was also found in the ChEMBL dataset was not of
the best afﬁnity to GLP-1R and also not the best in terms of pEC50 (see Supplementary
Figure S1). Among compounds similar to the binding site 1 ligand (see Figure 3), an
inversed trend was observed between similarity of compounds to this ligand and predicted
binding afﬁnity for the receptor. It suggests that although data on half-maximal response
concentrations of compounds were probably useful in discarding them from the ‘other’
subset it may not necessarily provide information which compound is of the best afﬁnity
for GLP-1R. It is worth noting that according to the recent study by Nguyen et al. [35]
Autodock4 could be slightly more accurate in afﬁnity predictions while Autodock VINA
outperforms it in binding mode predictions.
Figure 3. Results for GLP-1R compounds similar to the binding site 1 ligand. The lower binding energy (Autodock VINA
score), the better ﬁtness between the ligand and the type of the receptor binding site. Here, sites 1–4 notation corresponds to
the notation presented in Figure 1. Site 4 (I) corresponds to the binding site of NAM in 6LN2, site 4 (II)—to the binding site
of NAM in 5VEW.
In Figure 4, we juxtaposed pEC50 (pIC50 for GCGR) of all ChEMBL-derived com-
pounds with Autodock VINA scores obtained from molecular docking to the binding
site 1 (GLP-1R and 6ORV) and to the binding site 4 (GCGR and 5XEZ), respectively. In the
case of GLP-1R, results were split into two sets, and pEC50 correlated with docking scores.
When we examined ligands from the subset of the lowest binding energy and the highest
pEC50, we found out that this subset included ligands similar to the binding site 1 ligand
from 6ORV. These ligands were of high lipophilicity (see the AlogP plot in Supplementary
Figure S2). Interestingly, the ‘other’ subset was always predicted as of lower binding afﬁn-
ity regardless of the binding site used in molecular docking (see Supplementary Figure S3).
What is more, this set of GLP-1R ligands were examined in functional assays while the
‘other’ subset was mainly from binding assays (see Supplementary Figure S4).

## Page 9 (Section: Response to Drug—Ligand-Based Predictions )

Int. J. Mol. Sci. 2021, 22, 4060
9 of 16
Figure 4. Comparison of Autodock VINA scores obtained from ﬂexible ligand-ﬂexible receptor molecular docking with
pEC50 (GLP-1R, left) and pIC50 (GCGR, right) values.
The most important conclusion from this part of the study was that the Autodock
VINA scoring function enabled to accurately select compounds similar to the binding site 1
ligand from the ChEMBL dataset. This proves that molecular docking could also be used in
ligands annotation along with Daylight/Tanimoto descriptors when such detailed data like
the type of the binding site cannot be extracted by a text mining protocol from databases or
simply does not exist yet.
In the case of GCGR, the ChEMBL dataset was more evenly distributed. Compounds
similar to the binding site 4 ligand did not form a separate cluster in docking results like in
the case of GLP-1R compounds. However, these compounds similar to the site 4 ligand
were still located in the area of medium-to-best Autodock VINA scores and medium-to-
highest pIC50 values. Docking results correlated with experimental results (pIC50) to a
lesser extent than in the case of GLP-1R.
2.4. Response to Drug—Ligand-Based Predictions
We applied the curated compounds data for the development and validation of GLP-
1R and GCGR models. The statistical characteristics of the QSAR model for GLP-1R
computed in 5-fold cross-validation procedure is Q2 = 0.63 (±0.07) and for GCGR is Q2 =
0.67 (±0.04). We also computed mean absolute errors for both models. MAE for GCGR
was 0.445 (±0.031) and for GLP-1R was 0.32 (±0.028). The autocorrelation plots were
presented in Figure 5. Datasets were divided based on similarity to the binding site 1
(GLP-1R) and site 4 (GCGR) ligands. In the case of GLP-1R (left of Figure 5), compounds
similar to the site 1 ligand demonstrated a slightly better correlation between predicted and
experimental pEC50. In Supplementary Figure S4, we presented similar autocorrelation
plots but with datasets divided based on the ChEMBL-derived type of assay (‘Binding’
and ‘Functional’). In the case of GLP-1R, compounds similar to the binding site 1 PDB
ligand were mostly tested in ‘Binding’ assays while ‘other’ compounds were evaluated
using ‘Functional’ assays.

## Page 10 (Section: Response to Drug—Ligand-Based Predictions )

Int. J. Mol. Sci. 2021, 22, 4060
10 of 16
Figure 5. Autocorrelation plots of experimental vs. predicted values of pEC50 (GLP-1R) and experimental vs. predicted
values of pIC50 (GCGR). Correlation coefﬁcient equal to 0.81 (GLP-1R) and 0.83 (GCGR).
To investigate the source of the discriminatory effect, we projected ﬁngerprints onto 2D
embedding space using multidimensional scaling with Jaccard distance. The embedding
is presented in Figure 6. A similar distribution of clusters, as shown in Figure 6, was also
visible when using the unsupervised clustering of ﬁngerprints. Compounds similar to the
binding site 1 ligand of GLP-1R form the same cluster and, what is more, demonstrate
higher pEC50 comparing the ‘other’ subset. Our QSAR model reﬂects these differences in
ligand structures and properties between the ‘Site 1’ and ‘other’ subsets.
Figure 6. Multidimensional scaling embedding (MDS) for the relative similarity of ligand structures in the GLP-1R dataset
(left) and the GCGR dataset (right).
For GCGR, half-maximal response concentrations were not dependent on the similarity
of compounds to the binding site 4 ligands to such an extent as for GLP-1R. We also did
not observe such distinct cluster distribution as in the case of GLP-1R.
At the last stage of our study, we used our GCGR and GLP-1R models for compounds
deposited in CMAUP, a database of Collective Molecular Activities of Useful Plants [36]
(see Figure 7). The term ‘glucagon receptor’ provided two species, Mammea siamensis and
Trigonostemon reidioides, with two compounds that demonstrated nanomolar activity for
GCGR (see Supplementary Figure S6). NPC471603, a compound found in M. siamensis
demonstrated the 80 nM activity for GCGR. The better inhibitor activity (4 nM) demon-
strated NPC62792 from T. reidioides. None of these compounds were similar to any of
the PDB ligands targeting the binding sites 1–4 of GLP-1R or site 4 of GCGR. However,
based on the shape of these compounds (see Supplementary Figure S6), we suggest that
among these two compounds, the M. siamensis compound, which has three aromatic groups

## Page 11 (Section: Discussion )

Int. J. Mol. Sci. 2021, 22, 4060
11 of 16
(phenyl and pyridine) around the imidazole ring, could demonstrate the binding mode
similar to the site 4 ligand binding mode.
Figure 7. Evaluation of CMAUP-derived compounds using our GCGR and GLP-1R models.
None of the compounds derived from CMAUP was described as active for GLP-1R.
The GLP-1R model that we applied to 24 (M. siamensis) and 73 (T. reidioides) compounds
also did not succeed in ﬁnding a potentially active compound (pEC50 > 7) for this receptor.
As expected, predicted GLP-1R pEC50 values for compounds extracted from both of these
species did not exceed 6 (Figure 7). Yet, one compound from M. siamensis was distinctly
better than the others (see Supplementary Figure S7), with predicted pEC50 > 5.6. In the
case of GCGR, our model predicted higher pIC50, around 7, for a few compounds extracted
from M. siamensis. Among these top compounds (see Figure 8), we found NPC471603 that
had experimentally conﬁrmed activity for GCGR (see above). None of the described above
ﬁve compounds (two for GLP-1R and three for GCGR) were similar to the most potent
compound 20 from [21].
Figure 8. Top compounds found by the GCGR model in the CMAUP subset for Mammea siamensis. One of these compounds
(right) was also suggested in CMAUP as GCGR active (80 nM).
3. Discussion
ChEMBL datasets for the glucagon receptor family require a more detailed description
in terms of allostery/orthostery and in terms of four different binding sites that have been
discovered for GLP-1R. Lack of this information severely impedes the performance of both
ligand-based and structure-based approaches to drug design. While the ortho/allostery
ligand assignment often can be done by a text mining approach [19], extracting information
about the speciﬁc binding site referring to the current data in PDB (two sites for PAMs, one

## Page 12 (Section: Materials and Methods )

Int. J. Mol. Sci. 2021, 22, 4060
12 of 16
for NAMs, and one for a full agonist) remains difﬁcult to solve. Without such ligand anno-
tation, ML algorithms are trained on ambiguous data and that decreases their performance
in blind test experiments despite the actual great capabilities. As we also demonstrated in
this study, molecular docking is sensitive to differences between ortho/allosteric ligands.
Yet, an efﬁcient combination of ML and molecular docking in the case of large and diverse
datasets requires a thorough ligands annotation to avoid noise in the data that could
decrease the ML algorithm performance.
We developed and validated QSAR models applicable to the prediction of pEC50 for
GLP-1R and pIC50 for GCGR. For GLP-1R, both structure-based and ligand-based models
were able to discriminate compounds similar to the binding site 1 ligand. Developed QSAR
models allow to predict the absolute measure of agonist/antagonist effects on the receptor
(pEC50 and pIC50, respectively) with Q2 = 0.63 (±0.07) (GLP-1R) and Q2 = 0.67 (±0.04)
(GCGR). Although the QSAR model developed for GCGR by Venugopal et al. [21] achieved
better statistical characteristics, they were not informative in terms of model robustness in
virtual screening for novel chemotypes. Namely, this QSAR model was developed using a
small dataset of structurally similar ligands. In contrast, to develop our QSAR model, we
used much larger, unrestricted, structurally diverse datasets. Thus, our model applies to a
wider domain of chemical structures but at the cost of lower Q2 values.
Structural analysis of ligands in datasets showed a relationship between the compound
similarity to the binding site 1 ligand of GLP-1R and its high agonist activity. This analysis
demonstrated the complexity of the GPCR ligands space in terms of ortho/allostery and
possible locations of PAMs/NAMs binding sites. This complexity is weakly reﬂected in
chemical databases and thus impedes the efﬁcient usage of ML algorithms in drug design.
4. Materials and Methods
4.1. Data Acquisition
PDB ligands (ligands derived from PDB structures of receptors) were extracted and
compared to ChEMBL-derived datasets of experimentally conﬁrmed actives of the glucagon
receptor family members. GLP-1R and GCGR actives were derived from the ChEMBL
database [37]. The agonist activity data against GLP-1R was collected from a dataset with
the identiﬁer CHEMBL1784, while the inhibition data against GCGR was collected from
the dataset CHEMBL1985. The datasets were downloaded as CSV ﬁles and converted into
a pandas data frame [38].
4.2. Data Analysis
The resulting datasets were joined with metadata regarding the type of source assays
(‘Binding’/‘Functional’) that was also acquired from ChEMBL. To assess the similarity
of ChEMBL database compounds to PDB ligands from binding sites 1–4 (GLP-1R, see
Section 2) and from binding site 4 (GCGR, see Section 2), we used Daylight ﬁngerprints [39]
to compute Tanimoto coefﬁcients [40] using the functionality implemented in Maestro [41].
Daylight/Tanimoto similarity descriptors were used for the selection of the most/least
similar ligands to the PDB ones. Results of this ligands annotation were included in
Supplementary Figures S1 and S2 and deposited in: https://db-gpcr.chem.uw.edu.pl
(December 2020).
4.3. Data Curation
The datasets were curated following the best practices protocols [42]. What is more,
we extended the existing guidelines to use ChEMBL-speciﬁc metadata in the curation
pipeline. In Figure 9, we presented the number of ligands that were in the datasets after
each step of data curation, starting from the initial dataset. In the ﬁrst step, the ligand
structures encoded in the SMILES format were converted to 2D molecular structure and
standardized using the MolVS library (https://molvs.readthedocs.io/en/latest/) (accessed
on: September 2020). Records that did not contain structural information were removed
(see Figure 9). We used the conﬁdence score reported in the assay metadata to assess

## Page 13 (Section: Data Storage )

Int. J. Mol. Sci. 2021, 22, 4060
13 of 16
the reliability of data. We included only data with a conﬁdence score greater than 7
(see Figure 9). To further reﬁne the selection, we choose the data produced only in large
assays, i.e., ones that involved testing of more than 5 different compounds. Records that did
not contain any numerical data about the desired property, e.g., EC50 for GLP-1R and IC50
for GCGR were removed. Duplicated structures in datasets were detected by comparison
of their InChI identiﬁers. The duplicated entries were clustered and analyzed. Clusters
containing inconsistent data, e.g., clusters of data that demonstrated signiﬁcant standard
deviation of experimental values, were removed from the datasets. The ﬁnal curated
datasets included: 650 compounds for GCGR and 235 compounds for GLP-1R. The number
of compounds for the GIPR receptor (data not shown) was too small (107 compounds
including 23 compounds similar to the binding site 4 PDB ligand), so we discarded this
dataset from the current study. Vectors encoding Morgan ﬁngerprints (2048-bit) with a
radius of 3 were calculated for each chemical structure in the datasets.
Figure 9. Data records that passed subsequent data curation steps: (1) data acquisition, (2) removing
records with no SMILES included, (3) removing records with Conﬁdence Score <8, (4) keeping only
records from large assays, (5) removing records without numerical value for desired property, and (6)
duplicates merging.
4.4. Data Storage
Results of the current study have been added to the recently published repository
of GPCR data: https://db-gpcr.chem.uw.edu.pl [27]. This repository includes annotated
compounds of GLP-1R and GCGR receptors (compounds similar to the binding site 1
ligand and compounds similar to the binding site 4 ligand, respectively). Data on observed
biological responses (pEC50 and pIC50) were also added for each compound. Structures
and half-maximal response concentrations were visualized on the website with SMViewer.
4.5. Data Usage
4.5.1. QSAR Modeling and Validation
QSAR modeling included the following stages: acquisition of data on EC50 and IC50
for GLP-1R and GCGR, respectively; data curation; Morgan ﬁngerprints calculations;
model development and validation. Morgan ﬁngerprints were used as a feature vector
for the machine learning-based development of the QSAR models for GCGR and GLP-1R.
The machine learning algorithm used for QSAR modeling was Light Gradient Boosting

## Page 14 (Section: Molecular Docking )

Int. J. Mol. Sci. 2021, 22, 4060
14 of 16
Machines (LightGBM) [43]. A grid search was performed to select the best values for hy-
perparameters: the number of trees in an ensemble, regularization, and feature subsample
fraction. The resulting model consisted of 100 boosted trees, feature subsampling was set
to 0.1, and regularization to 1. The models were validated using a 5-fold cross-validation
procedure. The Q2 validation scores were computed on ﬁve randomly selected noninter-
secting subsets of data. For each test subset, the rest of the data was used to train the model.
The predictions from each testing subset were used to calculate the Q2 score against the
ground truth. The procedure was repeated 10 times, and the average Q2 was reported
along with the standard deviation.
In detail, in 5-fold cross-validation, we divided the dataset into 5 non-overlapping test
sets. Each test set consisted of ca. 20% of data, while the rest of the data of each test set
were used as training examples. The model was independently trained and tested for each
cross-validation data fold. The score calculated for each fold was averaged. The procedure
was repeated 20 times to account for random effects that may affect averaged score due to
different random splits of the test folds.
4.5.2. Molecular Docking
Structures of transmembrane domains of GCGR and GLP-1R receptors were prepared
in Maestro [41]. A maximum 10 residues in the binding site area were selected as ﬂexi-
ble during molecular docking due to computational time (see Supplementary Table S1).
The selected residues were in contact with PDB ligands (see Supplementary Table S1).
Ligands were extracted as 2D sdf ﬁles from the ChEMBL datasets and then converted to
3D with OpenBabel [44]. Partial charges were computed in two ways: OPLS-AA [41,45]
and Gasteiger [46] (MGL Tools 1.5.6). The former charges assignment provided a better
correlation with pEC50/pIC50 experimental values (data not shown). Fully ﬂexible (lig-
and and receptor) molecular docking was performed with Autodock VINA [34]. As a
principle, no human intervention was applied to the above procedure, and therefore 5
and 8 compounds from GLP-1R and GCGR datasets, respectively, failed at the stage of
the 2D to 3D conversion, the partial charges assignment, and/or molecular docking, so
they were discarded from the molecular docking part of the study. Failed compounds
contained, e.g., rediocide with a macrocyclic ring and 1,4-naphthyridine derivatives such as
6,7-dichloro-, 6-chloro-7-nitro-, 2-methylsulfonyl-, or 2-methylsulﬁnyl-1,4-naphthyridine.
In each compound of the latter group, either Sδ+Oδ−(sulﬁnyl) or Nδ+Oδ−(from a nitro
group) were present. Values of the Autodock VINA scoring function were juxtaposed with
pEC50/pIC50 experimental results (see Section 2).
4.6. Statistical Analysis
The predictive performance of the model was characterized statistically with the Q2
metric calculated on held-out data for each fold from the cross-validation procedure. The
metric was deﬁned as: Q2 = 1 −∑(y−ˆy)2
∑(y−y)2 , where y is a vector of experimental target values,
ˆy is a vector of predicted target values on held-out data, and y is mean of experimental
target values. A standard deviation of metrics within cross-validation folds was calculated
to estimate the error of the predictive performance estimation. The predictive performance
was reported as an average over cross-validation folds.
Supplementary Materials: The following are available online at https://www.mdpi.com/article/10
.3390/ijms22084060/s1.
Author Contributions: Conceptualization, D.L.; Methodology, M.M. and D.L.; Software, M.M. and
D.L.; Validation, M.M. and D.L.; Formal Analysis, M.M. and D.L.; Investigation, M.M. and D.L.;
Resources: D.L.; Data Curation, M.M. and D.L.; Writing—Original Draft Preparation, M.M. and
D.L.; Writing—Review and Editing, M.M. and D.L.; Visualization, M.M. and D.L.; Supervision, D.L.;
Project Administration, D.L.; Funding Acquisition, D.L. All authors have read and agreed to the
published version of the manuscript.

## Page 15 (Section: Molecular Docking )

Int. J. Mol. Sci. 2021, 22, 4060
15 of 16
Funding: This research received no external funding.
Institutional Review Board Statement: Not applicable.
Informed Consent Statement: Not applicable.
Data Availability Statement: The data presented in this study are openly available on: https://db-
gpcr.chem.uw.edu.pl/.
Conﬂicts of Interest: The authors declare no conﬂict of interest.
References
1.
Gribble, F.M.; Reimann, F. Function and mechanisms of enteroendocrine cells and gut hormones in metabolism. Nat. Rev.
Endocrinol. 2019, 15, 226–237. [CrossRef] [PubMed]
2.
Capozzi, M.; DiMarchi, R.D.; Tschöp, M.H.; Finan, B.; Campbell, J. Targeting the Incretin/Glucagon System With Triagonists to
Treat Diabetes. Endocr. Rev. 2018, 39, 719–738. [CrossRef]
3.
Latek, D.; Rutkowska, E.; Niewieczerzal, S.; Cielecka-Piontek, J. Drug-induced diabetes type 2: In silico study involving class B
GPCRs. PLoS ONE 2019, 14, e0208892. [CrossRef]
4.
Scheen, A.J.; Paquot, N.; Lefèbvre, P.J. Investigational glucagon receptor antagonists in Phase I and II clinical trials for diabetes.
Expert Opin. Investig. Drugs 2017, 26, 1373–1389. [CrossRef]
5.
Song, G.; Yang, D.; Wang, Y.; De Graaf, C.; Zhou, Q.; Jiang, S.; Liu, K.; Cai, X.; Dai, A.; Lin, G.; et al. Human GLP-1 receptor
transmembrane domain structure in complex with allosteric modulators. Nat. Cell Biol. 2017, 546, 312–315. [CrossRef]
6.
Zhang, H.; Qiao, A.; Yang, D.; Yang, L.; Dai, A.; De Graaf, C.; Reedtz-Runge, S.; Dharmarajan, V.; Zhang, H.; Han, G.W.; et al.
Structure of the full-length glucagon class B G-protein-coupled receptor. Nat. Cell Biol. 2017, 546, 259–264. [CrossRef]
7.
Wu, F.; Yang, L.; Hang, K.; Laursen, M.; Wu, L.; Han, G.W.; Ren, Q.; Roed, N.K.; Lin, G.; Hanson, M.A.; et al. Full-length human
GLP-1 receptor structure without orthosteric ligands. Nat. Commun. 2020, 11, 1–10. [CrossRef] [PubMed]
8.
Chen, D.; Liao, J.; Li, N.; Zhou, C.; Liu, Q.; Wang, G.; Zhang, R.; Zhang, S.; Lin, L.; Chen, K.; et al. A nonpeptidic agonist of
glucagon-like peptide 1 receptors with efﬁcacy in diabetic db/db mice. Proc. Natl. Acad. Sci. USA 2007, 104, 943–948. [CrossRef]
9.
Donnelly, D. The structure and function of the glucagon-like peptide-1 receptor and its ligands. Br. J. Pharmacol. 2012, 166, 27–41.
[CrossRef]
10.
Hollenstein, K.; de Graaf, C.; Bortolato, A.; Wang, M.-W.; Marshall, F.H.; Stevens, R.C. Insights into the structure of class B GPCRs.
Trends Pharmacol. Sci. 2014, 35, 12–22. [CrossRef]
11.
Bortolato, A.; Doré, A.S.; Hollenstein, K.; Tehan, B.G.; Mason, J.S.; Marshall, F.H. Structure of Class B GPCRs: New horizons for
drug discovery. Br. J. Pharmacol. 2014, 171, 3132–3145. [CrossRef] [PubMed]
12.
Hollenstein, K.; Kean, J.; Bortolato, A.; Cheng, R.K.Y.; Doré, A.S.; Jazayeri, A.; Cooke, R.M.; Weir, M.; Marshall, F.H. Structure of
class B GPCR corticotropin-releasing factor receptor Nat. Cell Biol. 2013, 499, 438–443. [CrossRef]
13.
Zhao, P.; Liang, Y.-L.; Belousoff, M.J.; Deganutti, G.; Fletcher, M.M.; Willard, F.S.; Bell, M.G.; Christe, M.E.; Sloop, K.W.; Inoue, A.;
et al. Activation of the GLP-1 receptor by a non-peptidic agonist. Nat. Cell Biol. 2020, 577, 432–436. [CrossRef]
14.
Ma, H.; Huang, W.; Wang, X.; Zhao, L.; Jiang, Y.; Liu, F.; Guo, W.; Sun, X.; Zhong, W.; Yuan, D.; et al. Structural insights into the
activation of GLP-1R by a small molecule agonist. Cell Res. 2020, 30, 1140–1142. [CrossRef] [PubMed]
15.
Bueno, A.B.; Sun, B.; Willard, F.S.; Feng, D.; Ho, J.D.; Wainscott, D.B.; Showalter, A.D.; Vieth, M.; Chen, Q.; Stutsman, C.;
et al. Structural insights into probe-dependent positive allosterism of the GLP-1 receptor. Nat. Chem. Biol. 2020, 16, 1105–1110.
[CrossRef] [PubMed]
16.
Kawai, T.; Sun, B.; Yoshino, H.; Feng, D.; Suzuki, Y.; Fukazawa, M.; Nagao, S.; Wainscott, D.B.; Showalter, A.D.; Droz, B.A.; et al.
Structural basis for GLP-1 receptor activation by LY3502970, an orally active nonpeptide agonist. Proc. Natl. Acad. Sci. USA 2020,
117, 29959–29967. [CrossRef] [PubMed]
17.
Zhang, X.; Belousoff, M.J.; Zhao, P.; Kooistra, A.J.; Truong, T.T.; Ang, S.Y.; Underwood, C.R.; Egebjerg, T.; Šenel, P.; Stewart,
G.D.; et al. Differential GLP-1R Binding and Activation by Peptide and Non-peptide Agonists. Mol. Cell 2020, 80, 485–500.e7.
[CrossRef]
18.
Mendez, D.; Gaulton, A.; Bento, A.P.; Chambers, J.; De Veij, M.; Félix, E.; Magariños, M.P.; Mosquera, J.F.; Mutowo, P.; Nowotka,
M.; et al. ChEMBL: Towards direct deposition of bioassay data. Nucleic Acids Res. 2019, 47, D930–D940. [CrossRef] [PubMed]
19.
Burggraaff, L.; Van Veen, A.; Lam, C.C.; Van Vlijmen, H.W.T.; Ijzerman, A.P.; Van Westen, G.J.P. Annotation of Allosteric
Compounds to Enhance Bioactivity Modeling for Class A GPCRs. J. Chem. Inf. Model. 2020, 60, 4664–4672. [CrossRef]
20.
Fourches, D.; Ash, J. 4D-quantitative structure–activity relationship modeling: Making a comeback. Expert Opin. Drug Discov.
2019, 14, 1227–1235. [CrossRef]
21.
Venugopal, P.P.; Das, B.K.; Soorya, E.; Chakraborty, D.; Pushyaraga, P.V. Effect of hydrophobic and hydrogen bonding interactions
on the potency of ß-alanine analogs of G-protein coupled glucagon receptor inhibitors. Proteins Struct. Funct. Bioinform. 2020, 88,
327–344. [CrossRef] [PubMed]
22.
Al-Zamel, N.; Al-Sabah, S.; Luqmani, Y.; Adi, L.; Chacko, S.; Schneider, T.D.; Krasel, C. A Dual GLP-1/GIP Receptor Agonist
Does Not Antagonize Glucagon at Its Receptor but May Act as a Biased Agonist at the GLP-1 Receptor. Int. J. Mol. Sci. 2019, 20,
3532. [CrossRef] [PubMed]

## Page 16 (Section: Molecular Docking )

Int. J. Mol. Sci. 2021, 22, 4060
16 of 16
23.
Mathiesen, D.S.; Bagger, J.I.; Bergmann, N.C.; Lund, A.; Christensen, M.B.; Vilsbøll, T.; Knop, F.K. The Effects of Dual GLP-1/GIP
Receptor Agonism on Glucagon Secretion—A Review. Int. J. Mol. Sci. 2019, 20, 4092. [CrossRef] [PubMed]
24.
Chang, R.; Zhang, X.; Qiao, A.; Dai, A.; Belousoff, M.J.; Tan, Q.; Shao, L.; Zhong, L.; Lin, G.; Liang, Y.-L.; et al. Cryo-electron
microscopy structure of the glucagon receptor with a dual-agonist peptide. J. Biol. Chem. 2020, 295, 9313–9325. [CrossRef]
25.
Pan, C.Q.; Buxton, J.M.; Yung, S.L.; Tom, I.; Yang, L.; Chen, H.; MacDougall, M.; Bell, A.; Claus, T.H.; Clairmont, K.B.; et al. Design
of a Long Acting Peptide Functioning as Both a Glucagon-like Peptide-1 Receptor Agonist and a Glucagon Receptor Antagonist.
J. Biol. Chem. 2006, 281, 12506–12515. [CrossRef] [PubMed]
26.
Claus, T.H.; Pan, C.Q.; Buxton, J.M.; Yang, L.; Reynolds, J.C.; Barucci, N.; Burns, M.; Ortiz, A.A.; Roczniak, S.; Livingston, J.N.;
et al. Dual-acting peptide with prolonged glucagon-like petide-1 receptor agonist and glucagon receptor antagonist activity for
the treatment of type 2 diabetes. J. Endocrinol. 2007, 192, 371–380. [CrossRef]
27.
Mizera, M.; Latek, D.; Cielecka-Piontek, J. Virtual Screening of C. Sativa Constituents for the Identiﬁcation of Selective Ligands
for Cannabinoid Receptor. Int. J. Mol. Sci. 2020, 21, 5308. [CrossRef]
28.
Siu, F.Y.; He, M.; De Graaf, C.; Han, G.W.; Yang, D.; Zhang, Z.; Zhou, C.; Xu, Q.; Wacker, D.; Joseph, J.S.; et al. Structure of the
human glucagon class B G-protein-coupled receptor. Nat. Cell Biol. 2013, 499, 444–449. [CrossRef] [PubMed]
29.
Pasznik, P.; Rutkowska, E.; Niewieczerzal, S.; Cielecka-Piontek, J.; Latek, D. Potential off-target effects of beta-blockers on gut
hormone receptors: In silico study including GUT-DOCK—A web service for small-molecule docking. PLoS ONE 2019, 14,
e0210705. [CrossRef] [PubMed]
30.
Wold, E.A.; Chen, J.; Cunningham, K.A.; Zhou, J. Allosteric Modulation of Class A GPCRs: Targets, Agents, and Emerging
Concepts. J. Med. Chem. 2019, 62, 88–127. [CrossRef]
31.
Jazayeri, A.; Doré, A.S.; Lamb, D.; Krishnamurthy, H.; Southall, S.M.; Baig, A.H.; Bortolato, A.; Koglin, M.; Robertson, N.J.; Errey,
J.C.; et al. Extra-helical binding site of a glucagon receptor antagonist. Nat. Cell Biol. 2016, 533, 274–277. [CrossRef]
32.
Jazayeri, A.; Rappas, M.; Brown, A.J.H.; Kean, J.; Errey, J.C.; Robertson, N.J.; Fiez-Vandal, C.; Andrews, S.P.; Congreve, M.;
Bortolato, A.; et al. Crystal structure of the GLP-1 receptor bound to a peptide agonist. Nat. Cell Biol. 2017, 546, 254–258.
[CrossRef] [PubMed]
33.
Zhang, H.; Qiao, A.; Yang, L.; Van Eps, N.; Frederiksen, K.S.; Yang, D.; Dai, A.; Cai, X.; Zhang, H.; Yi, C.; et al. Structure of the
glucagon receptor in complex with a glucagon analogue. Nat. Cell Biol. 2018, 553, 106–110. [CrossRef] [PubMed]
34.
Trott, O.; Olson, A.J. AutoDock Vina: Improving the speed and accuracy of docking with a new scoring function, efﬁcient
optimization, and multithreading. J. Comput. Chem. 2010, 31, 455–461. [CrossRef] [PubMed]
35.
Nguyen, N.T.; Nguyen, T.H.; Pham, T.N.H.; Huy, N.T.; Van Bay, M.; Pham, M.Q.; Nam, P.C.; Vu, V.V.; Ngo, S.T. Autodock Vina
Adopts More Accurate Binding Poses but Autodock4 Forms Better Binding Afﬁnity. J. Chem. Inf. Model. 2019, 60, 204–211.
[CrossRef]
36.
Zeng, X.; Zhang, P.; Wang, Y.; Qin, C.; Chen, S.; He, W.; Tao, L.; Tan, Y.; Gao, D.; Wang, B.; et al. CMAUP: A database of collective
molecular activities of useful plants. Nucleic Acids Res. 2019, 47, D1118–D1127. [CrossRef]
37.
Gaulton, A.; Hersey, A.; Nowotka, M.; Bento, A.P.; Chambers, J.; Mendez, D.; Mutowo, P.; Atkinson, F.; Bellis, L.J.; Cibrián-Uhalte,
E.; et al. The ChEMBL database in 2017. Nucleic Acids Res. 2017, 45, D945–D954. [CrossRef]
38.
McKinney, W. Data Structures for Statistical Computing in Python. In Proceedings of the 9th Python in Science Conference,
Austin, TX, USA, 28 June–3 July 2010; pp. 51–56.
39.
Daylight Chemical Information Systems, Inc., Laguna Niguel, CA, USA. Available online: https://www.daylight.com/ (accessed
on 17 February 2021).
40.
Rogers, D.J.; Tanimoto, T.T. A Computer Program for Classifying Plants. Science 1960, 132, 1115–1118. [CrossRef]
41.
Schrödinger, Inc. [Computer Software]. New York, NY, USA. Available online: https://www.schrodinger.com/ (accessed on 17
February 2021).
42.
Fourches, D.; Muratov, E.; Tropsha, A. Trust, But Verify: On the Importance of Chemical Structure Curation in Cheminformatics
and QSAR Modeling Research. J. Chem. Inf. Model. 2010, 50, 1189–1204. [CrossRef]
43.
Ke, G.; Meng, Q.; Finley, T.; Wang, T.; Chen, W.; Ma, W.; Ye, Q.; Liu, T.Y. LightGBM: A highly efﬁcient gradient boosting decision
tree. In Advances in Neural Information Processing Systems; NIPS: San Diego, CA, USA, 2017.
44.
O’Boyle, N.M.; Banck, M.; James, C.; Morley, C.; Vandermeersch, T.; Hutchison, G.R. Open Babel: An open chemical toolbox. J.
Chemin. 2011, 3, 33. [CrossRef]
45.
Jorgensen, W.L.; Maxwell, D.S.; Tirado-Rives, J. Development and Testing of the OPLS All-Atom Force Field on Conformational
Energetics and Properties of Organic Liquids. J. Am. Chem. Soc. 1996, 118, 11225–11236. [CrossRef]
46.
Gasteiger, J.; Marsili, M. A new model for calculating atomic charges in molecules. Tetrahedron Lett. 1978, 19, 3181–3184. [CrossRef]


---

# Machine learning identifies candidates for drug repurposing in Alzheimer’s disease

- **Authors:** Steve Rodriguez, Clemens B. Hug, Petar V. Todorov, Nienke Moret, Sarah A. Boswell, Kyle E. Evans, George Zhou, Nathan T. Johnson, Bradley T. Hyman, Peter Karl Sorger, Mark W. Albers, Artem Sokolov
- **Issuer:** Nature Communications
- **Type:** Scientific article
- **Published:** 2021-02-15
- **Language:** en
- **DOI:** 10.1038/s41467-021-21330-0
- **Source:** https://doi.org/10.1038/s41467-021-21330-0
- **Licence:** CC-BY

## Section: Abstract

Clinical trials of novel therapeutics for Alzheimer’s Disease (AD) have consumed a large amount of time and resources with largely negative results. Repurposing drugs already approved by the Food and Drug Administration (FDA) for another indication is a more rapid and less expensive option. We present DRIAD (Drug Repurposing In AD), a machine learning framework that quantifies potential associations between the pathology of AD severity (the Braak stage) and molecular mechanisms as encoded in lists of gene names. DRIAD is applied to lists of genes arising from perturbations in differentiated human neural cell cultures by 80 FDA-approved and clinically tested drugs, producing a ranked list of possible repurposing candidates. Top-scoring drugs are inspected for common trends among their targets. We propose that the DRIAD method can be used to nominate drugs that, after additional validation and identification of relevant pharmacodynamic biomarker(s), could be readily evaluated in a clinical trial.

## Section: Introduction

Alzheimer’s disease (AD) is a growing healthcare crisis with longer life expectancy as its principal risk factor. It is estimated that, in the absence of effective prevention and treatment options, disease prevalence will more than double over the next several decades: from 5.8 million individuals living with AD today in the US to a projected 13.8 million by 2050 (ref. 1). In addition to its direct impact on human health and welfare, the long-term care of affected individuals imposes a substantial economic burden2. Multiple efforts to develop disease-modifying therapeutics for AD, including approximately 200 clinical trials to date, have been largely negative with many failures occurring due to lack of efficacy or excess toxicity3. Every failed clinical trial of a new molecular entity (NME) consumes substantial time and resources. In contrast, repurposing drugs already approved by the Food and Drug Administration (FDA) for a different indication is less expensive, involves already defined possible toxicities, and can have a higher success rate (30%) as compared to development of a NME4.

The traditional approach to repurposing is to use an existing drug in a new indication, perhaps at a different dose or in different formulation5. However, an alternative is to use repurposing as a way of testing a therapeutic concept that could then subsequently be advanced, with additional medicinal chemistry and functional testing, to become a NME. This is potentially valuable in the case of AD in which the underlying disease mechanisms remain poorly understood and the potential for multiple distinct disease drivers exists. Repurposing drugs for AD has received increasing attention6,7, but approaches to date have been largely hypothesis-driven, based on overlap between an existing pharmacological mechanism of action (MOA) and a putative disease-causing mechanism8 or results of a clinical trial9,10. While some of these leads are promising, no successes have been reported to date.

For simplicity, we use the term drug in this work to broadly refer to both FDA-approved chemical entities as well as clinically tested compounds and drug-like pre-clinical molecules (often referred to as chemical probes). As databases of drug information grow, informatics-based approaches to drug repurposing have emerged. Tools such as MeSHDD11, PREDICT12, Rephetio13, Connectivity Map14, and others15–17 seek to establish large-scale associations between perturbations induced by drugs and by disease processes, which can then be mined for repurposing opportunities. One drawback of existing repurposing tools is that they are rarely disease specific and include data on drug mechanisms and disease pathways (typically transcriptional or proteomic signatures) obtained from diverse biological settings, often with a strong bias toward cancer cell lines and biopsies. This is potentially problematic in the case of a disease such as AD that is poorly understood, characterized by phenotypic18 and pathological heterogeneity19, and involves non-proliferating cells.

We therefore sought to develop a repurposing approach that made combined use of -omic datasets on drug-induced perturbation of neuronal cells and molecular changes that occur in the brains of individuals suffering from different stages of AD, as collected by the Accelerating Medicines Partnership - Alzheimer’s Disease (AMP-AD) effort20. We focused on gene expression measurements, because they provide a natural connection between preclinical cell culture platforms, where perturbation experiments can be carried out, and patient-derived tissue specimens. Gene expression also features prominently in previous drug repositioning efforts focused on aging21 and AD16,22, with several approaches making use of the Connectivity Map14 and related tools23,24 to identify compounds that induce similar transcriptional changes in a given disease context25.

The approach we developed, drug repurposing in Alzheimer’s disease (DRIAD), involves a machine learning framework that quantifies the association between the stage of AD (early, mid, or late) as defined by Braak staging26 and any biological process or response that can be characterized by a list of gene names. Data characterizing AD were obtained from AMP-AD datasets and comprised mRNA expression profiles of postmortem brain specimens. In parallel, lists of gene names were obtained by using RNAseq to measure the responses of human neuronal cells to small molecule drugs and then identifying differentially expressed genes to generate drug-associated gene lists (DGLs). In the current work, we focus on kinase inhibitors because they are associated with strong transcriptional signatures and have relatively well annotated target spectra27. DRIAD uses a specific DGL for feature selection and then trains and evaluates a predictor of AD pathological stage from AMP-AD gene expression data. In this way, the relevance of a drug-induced perturbation of neurons and other neural lineage cells grown in culture (which is a reflection of drug mechanism(s) of action) to the pathological processes underlying AD can be evaluated. Drugs whose DGLs resulted in the most accurate predictors were found to target proteins in signaling networks regulating innate immunity, autophagy, and microtubule dynamics; these represent previously unexplored pathways for a potential Alzheimer’s therapeutic28. The direction of this effect is not specified a priori and DRIAD will identify both disease-enhancing and disease-reducing drugs, a topic addressed in the discussion. We show that DRIAD is agnostic to the length of the input gene list and its source, which can be a drug-induced perturbation, as in this work, the results of a previous study, or manual annotation of biological mechanisms.

## Section: Results

a Overview of the machine learning framework used to establish potential associations between gene lists and Alzheimer’s disease. (i) The framework accepts as input gene lists derived from experimental data or extracted from database resources or literature. (ii) Given a gene expression matrix, the framework subsamples it to a particular gene list of interest, and (iii) subsequently trains and evaluates through cross-validation a predictor of Braak stage of disease. (iv) The process is repeated for randomly selected gene lists of equal lengths to determine whether predictor performance associated with the gene list of interest is significantly higher than what is expected by chance. b AMP-AD datasets used by the machine learning framework. The three datasets used to evaluate the predictive power of gene lists are provided by The Religious Orders Study and Memory and Aging Project (ROSMAP), The Mayo Clinic Brain Bank (MAYO), and The Mount Sinai/JJ Peters VA Medical Center Brain Bank (MSBB). The schematic highlights regions of the brain that are represented in each dataset. The MSBB dataset spans four distinct regions, which are designated using Brodmann (BM) area codes. c Performance of predictors trained on gene lists reported in previous studies of AMP-AD datasets. The predictors are evaluated for their ability to distinguish early-vs-late disease stages with performance reported as area under the ROC curve (AUC). The vertical line on each row denotes predictor performance associated with a gene list reported in the literature, while the background distribution is constructed over randomly selected lists of matching lengths. Each row is annotated with the pubmed ID of the study, the supplemental resource that contained the gene list, and a short keyphrase providing functional context. Shown unadjusted p-values were computed with a one-sided empirical test, by counting the fraction of randomly selected lists in the background distribution that outperformed the corresponding literature lists.

a Overview of the 3′ DGE experimental protocol used to derive drug-associated gene expression signatures. ReNcell VM human neural progenitor cells were plated and differentiated for 10 days, resulting in a mixed cell population of neurons, glia, and oligodendrocytes. The mixed culture was subsequently treated with a panel of drugs (Supplementary Data 3) at 10 µM for 24 h and frozen in a lysis buffer until library preparation. RNA was extracted and reverse transcribed into cDNA in each well of the plate, followed by pooling and preparation of mRNA libraries. After sequencing, mRNA reads were demultiplexed according to well barcodes, and the resulting gene expression profiles were processed by a standard differential expression method to derive drug-associated gene lists. b A highlight of two compounds whose gene lists consistently yield improved performance over the randomly selected lists of equal length. Shown is performance associated with predicting early-vs-late disease stages in several AMP-AD datasets. Each row corresponds to an evaluation of gene lists in a single dataset; MSBB evaluation is subdivided into four brain regions, specified as Brodmann Area. The vertical line denotes performance of the drug-associated list, while the background distribution shows performance of gene lists randomly selected from the same dataset. The drugs are annotated with their nominal targets. The unadjusted p-values were computed with a one-sided empirical test, by counting the fraction of randomly selected lists that outperformed the corresponding drug-associated lists.

Each heatmap shows unadjusted empirical p-values associated with a drug’s predictive performance across two AMP-AD datasets, ROSMAP and MSBB. The MSBB analysis is further subdivided by the brain region, specified as Brodmann Area. The empirical p-values were computed by counting the proportion of randomly selected lists that outperformed the gene lists of interest (i.e., a one-sided test). The p-values were then aggregated across the datasets by computing the harmonic mean p-value (HMP), which is shown in the last column of each heatmap. The rows are annotated with the name of the drug/compound, its nominal target, and the index of the corresponding DGE experiment. Additional annotations include information about each compound’s approval status (approved/investigational/experimental) and whether compounds were found to be toxic in neuronal cell cultures.

a Overview of target affinity spectrum (TAS) score computation from raw drug binding data. Three types of drug binding data were sourced from ChEMBL and from the internal Laboratory Systems of Pharmacology dataset that have not yet been incorporated into ChEMBL. Empirically derived thresholds for the different data types were used to assign TAS scores to each drug–target pair. Multiple measurements for the same drug–target combination were aggregated along the first quartile to define the final TAS value. b Binding affinity of compounds in the ranked list to every member of the Janus Kinase family. The compounds are sorted in increasing order by the harmonic mean p-value (as defined in Fig. 3) along the x-axis. The top heatmap shows the binding affinity of each compound to the selected targets, explicitly naming the FDA-approved drugs. Colored and gray tiles denote confirmed binders and non-binders, respectively; missing entries correspond to unknown affinity values. The combined affinity is defined as the strongest binding (lowest TAS score) among all four JAK targets. The bottom plot shows the breakdown of the combined affinity values by TAS-specific empirical cumulative distribution functions (ECDFs). Each line shows ECDFs for all drugs that bind the corresponding target with a TAS score of 1 (dark orange), 2 (orange), or 3 (light orange). c Top targets whose binding affinity correlates most strongly with the compound ranking. The ECDFs of confirmed non-binders (TAS = 10) are shown as gray dashed lines for reference. Area under ECDF can be interpreted as a summary statistic that captures the position of drugs binding to that target with the corresponding affinity in the ranked list. Correlation between the drug ranking and TAS values was computed using the one-sided Kendall’s Tau test, with the associated unadjusted p-value displayed in the bottom right corner of each plot.

a An example polypharmacology test with a focus on RPS6KA1 and TYK2. The drugs are ranked by the harmonic mean p-value (as in Figs. 3 and 4), and the distributions of drugs bindings to both RPS6KA1 and TYK2 (left), those binding to RPS6KA1 but not TYK2 (middle) and, conversely, TYK2 but not RPS6KA1 (right) are shown along this ranking. Individual drugs that bind those targets are annotated by vertical tick marks directly below the corresponding distribution. b Top ten positive and top ten negative interactions between pairs of targets. The distributions in each plot are compared using Wilcoxon Rank Sum test, with the resulting p-value presented in the bottom right corner. If compounds that bind both targets appear significantly closer to the top of the ranked list (left side of the x axis), we define the target pair to be a positive interaction. Conversely, a pair of targets with an explicit non-binding interaction observed among the top-ranking compounds is defined to be antagonistic. A set of five neutral target pairs (i.e., no significant positive or negative effect) is included for reference.

Top ten targets that consistently appear in the top positive or negative interactions.

## Section: Results › Machine learning framework for identifying potential associations between gene lists and disease

When used for AD repurposing, DRIAD requires two types of inputs: (i) mRNA expression profiles from human brains at various stages of AD progression and (ii) a dataset comprising DGLs—lists of genes differentially expressed when neuronal cells (in the current work, a mixed population of neurons, astrocytes, and oligodendrocytes, differentiated from an immortal neuroprogenitor line) are exposed to a test panel of drugs. Human brain gene expression levels were taken from AMP-AD datasets20 provided by The Religious Orders Study and Memory and Aging Project (ROSMAP), The Mayo Clinic Brain Bank (MAYO), and The Mount Sinai/JJ Peters VA Medical Center Brain Bank (MSBB), each encompassing measurements from one or more regions of the brain (Fig. 1b). Braak staging scores26, assigned through neuropathological assessment of neurofibrillary tangle accumulation, were used to group samples into three categories of disease progression: early (A; stages 1–2), intermediate (B; stages 3–4), and late (C; stages 5–6). This grouping recapitulates the spatio-temporal progression of neurofibrillary tangles from the entorhinal region to the hippocampus area and, subsequently, to neocortical association areas29.Fig. 1The definition and validation of the DRIAD framework.a Overview of the machine learning framework used to establish potential associations between gene lists and Alzheimer’s disease. (i) The framework accepts as input gene lists derived from experimental data or extracted from database resources or literature. (ii) Given a gene expression matrix, the framework subsamples it to a particular gene list of interest, and (iii) subsequently trains and evaluates through cross-validation a predictor of Braak stage of disease. (iv) The process is repeated for randomly selected gene lists of equal lengths to determine whether predictor performance associated with the gene list of interest is significantly higher than what is expected by chance. b AMP-AD datasets used by the machine learning framework. The three datasets used to evaluate the predictive power of gene lists are provided by The Religious Orders Study and Memory and Aging Project (ROSMAP), The Mayo Clinic Brain Bank (MAYO), and The Mount Sinai/JJ Peters VA Medical Center Brain Bank (MSBB). The schematic highlights regions of the brain that are represented in each dataset. The MSBB dataset spans four distinct regions, which are designated using Brodmann (BM) area codes. c Performance of predictors trained on gene lists reported in previous studies of AMP-AD datasets. The predictors are evaluated for their ability to distinguish early-vs-late disease stages with performance reported as area under the ROC curve (AUC). The vertical line on each row denotes predictor performance associated with a gene list reported in the literature, while the background distribution is constructed over randomly selected lists of matching lengths. Each row is annotated with the pubmed ID of the study, the supplemental resource that contained the gene list, and a short keyphrase providing functional context. Shown unadjusted p-values were computed with a one-sided empirical test, by counting the fraction of randomly selected lists in the background distribution that outperformed the corresponding literature lists.

DRIAD trains and then evaluates a predictor that can recognize the A, B, or C disease categories from mRNA expression levels, restricting the predictor to those genes in the DGL (Fig. 1a) (see “Methods”). It is likely that the molecular mechanisms involved in initiation and progression of AD are obscured in end-stage RNAseq profiles as a result of the actions of myriad signaling pathways and feedback loops, leading to widespread transcriptional changes only indirectly associated with disease mechanism30–33. This is reflected in the fact that many randomly selected list of genes in human brain gene expression profiles is weakly predictive of disease stage (Supplementary Fig. 1). We therefore sought lists of genes that outperformed random lists in predicting AD stage at a pre-specified level of significance. Statistical significance was assessed by repeatedly sampling the space of all gene names to create a background distribution of random gene lists (of the same length) against which to evaluate a DGL (Fig. 1a). An empirical p-value was provided by the fraction of random gene lists that outperformed the DGL in the prediction task.

a Overview of the machine learning framework used to establish potential associations between gene lists and Alzheimer’s disease. (i) The framework accepts as input gene lists derived from experimental data or extracted from database resources or literature. (ii) Given a gene expression matrix, the framework subsamples it to a particular gene list of interest, and (iii) subsequently trains and evaluates through cross-validation a predictor of Braak stage of disease. (iv) The process is repeated for randomly selected gene lists of equal lengths to determine whether predictor performance associated with the gene list of interest is significantly higher than what is expected by chance. b AMP-AD datasets used by the machine learning framework. The three datasets used to evaluate the predictive power of gene lists are provided by The Religious Orders Study and Memory and Aging Project (ROSMAP), The Mayo Clinic Brain Bank (MAYO), and The Mount Sinai/JJ Peters VA Medical Center Brain Bank (MSBB). The schematic highlights regions of the brain that are represented in each dataset. The MSBB dataset spans four distinct regions, which are designated using Brodmann (BM) area codes. c Performance of predictors trained on gene lists reported in previous studies of AMP-AD datasets. The predictors are evaluated for their ability to distinguish early-vs-late disease stages with performance reported as area under the ROC curve (AUC). The vertical line on each row denotes predictor performance associated with a gene list reported in the literature, while the background distribution is constructed over randomly selected lists of matching lengths. Each row is annotated with the pubmed ID of the study, the supplemental resource that contained the gene list, and a short keyphrase providing functional context. Shown unadjusted p-values were computed with a one-sided empirical test, by counting the fraction of randomly selected lists in the background distribution that outperformed the corresponding literature lists.

## Section: Results › Validation of DRIAD using gene lists associated with AD pathophysiology

To test the DRIAD framework, lists of gene names previously reported in the literature to be associated with an aspect of AD progression32,34–41 were substitute for DGLs (Supplementary Data 2). Each input gene list was used to train DRIAD to distinguish between early (A) and late (C) stage disease based on mRNA levels in AMP-AD data. We found that most of the published lists of AD-associated genes outperformed randomly selected lists of equal length (Fig. 1c). Thus, DRIAD effectively recapitulates previous attempts to identify genes and co-expression modules associated with disease severity. Similar results were obtained with human gene sets and mouse homologs previously reported to be associated with AD. For example, McKenzie et al. used AMP-AD data to establish that UGT8 is a key regulator of oligodendrocyte function and reported a list of genes that are differentially expressed in the frontal cortex of a UGT8 knockout mouse model40. DRIAD shows that these differentially expressed genes have a significant association with disease severity in AMP-AD data (Fig. 1c), providing further evidence that UGT8 may play a role in neurodegeneration in humans.

Similarly, Mostafavi et al. identified a co-expression module of 390 genes that has a strong association with cognitive decline34. DRIAD confirms that a predictor trained to recognize pathological stage based on these 390 genes performs significantly (empirical p-value = 0.05) better than equivalent predictors trained on arbitrary sets of 390 genes chosen at random (Fig. 1c). In contrast, when we examined gene lists associated with Progressive Supranuclear Palsy (PSP) Tau Neuropathology and Angiogenesis, DRIAD found that they correlated with Braak staging no better than random gene lists. This suggests that models trained using DRIAD can distinguish molecular features of tauopathies and pathologic processes not known to be relevant to AD. Consistency in performance was observed across datasets and brain regions, with one exception: whenever a predictor was trained on late-stage samples in the MAYO dataset, it substantially outperformed similar predictors evaluated on all other datasets (Supplementary Fig. 1). This suggests the presence of a strong batch effect in the late-stage MAYO samples that the predictors pick up in lieu of learning disease severity. Because the nature of this batch effect is unknown, we chose to exclude MAYO data in the current study. However, future studies could adjust for batch effects of unknown origin using established methods from the literature42–44.

## Section: Results › 3ʹ Digital Gene Expression profiles drug-induced perturbation of mRNA expression

Drug responses were generated using the RenCell VM human neural progenitor cell line. Upon growth factor withdrawal, RenCell VM cells differentiate into a mixed culture of neurons, glia, and oligodendrocytes over a period of ~10 days45. Differentiated RenCells were exposed for 24 h to one of 80 kinase inhibitors at two doses in triplicate, or to a vehicle-only (DMSO) control, and mRNA levels were then measured using the high-throughput, intermediate read density RNAseq method 3′ Digital Gene Expression (3′ DGE)46 (Fig. 2a). The advantage of 3′ DGE in this setting is that it provides high-quality gene expression signatures at relatively low cost, allowing data to be collected from multiple repeats, doses, and drugs. The small molecule panel was designed to include FDA-approved drugs, which could potentially be repurposed, compounds that have been tested in human clinical trials—and for which toxicity data are available—that could be further developed for use in AD, as well as pre-clinical compounds designed to extend the range of targets and test therapeutic concepts not explorable with clinical grade compounds (Supplementary Data 3). Kinase inhibitors were chosen as a class of well-annotated drugs that target many different members of a single gene family and elicit strong transcriptional signatures. The 80 kinase inhibitors were profiled across two separate 3′ DGE experiments and, to establish reproducibility, 5 of the 80 compounds were included in both experiments. The experiments are indexed separately (Supplementary Data 3), and the compounds in common provide a measure of biological and technical variation. High concordance of the measurements between the two experiments was observed (Supplementary Fig. 2) suggesting that batch effects were not strong. Overall, the drug-response data comprised 767 DGE gene expression profiles.Fig. 2Collection and evaluation of drug-associated gene lists.a Overview of the 3′ DGE experimental protocol used to derive drug-associated gene expression signatures. ReNcell VM human neural progenitor cells were plated and differentiated for 10 days, resulting in a mixed cell population of neurons, glia, and oligodendrocytes. The mixed culture was subsequently treated with a panel of drugs (Supplementary Data 3) at 10 µM for 24 h and frozen in a lysis buffer until library preparation. RNA was extracted and reverse transcribed into cDNA in each well of the plate, followed by pooling and preparation of mRNA libraries. After sequencing, mRNA reads were demultiplexed according to well barcodes, and the resulting gene expression profiles were processed by a standard differential expression method to derive drug-associated gene lists. b A highlight of two compounds whose gene lists consistently yield improved performance over the randomly selected lists of equal length. Shown is performance associated with predicting early-vs-late disease stages in several AMP-AD datasets. Each row corresponds to an evaluation of gene lists in a single dataset; MSBB evaluation is subdivided into four brain regions, specified as Brodmann Area. The vertical line denotes performance of the drug-associated list, while the background distribution shows performance of gene lists randomly selected from the same dataset. The drugs are annotated with their nominal targets. The unadjusted p-values were computed with a one-sided empirical test, by counting the fraction of randomly selected lists that outperformed the corresponding drug-associated lists.

For each drug, we defined the DGL to be the set of significantly perturbed genes, as identified through differential gene expression analysis47 comparing 3′ DGE profiles of drug-treated and control cells (see “Methods”). For most drugs, we identified between 10 and 300 significantly perturbed genes. DRIAD evaluated each DGL by constructing a predictor of pathological stage based on mRNA expression of these genes in AMP-AD datasets. The accuracy of the predictor assessed over multiple brain regions measures the association between a drug’s mechanism (encapsulated in the DGL) and AD severity. We focused specifically on the binary classification task of distinguishing early vs. late disease stages (A-vs-C), because it contrasts groups of maximally distinct samples and yields higher signal to noise ratio than attempting to predict all three disease stages. This caused random gene lists to have higher predictive power, creating a higher bar for DGLs to surpass to be considered significant.

a Overview of the 3′ DGE experimental protocol used to derive drug-associated gene expression signatures. ReNcell VM human neural progenitor cells were plated and differentiated for 10 days, resulting in a mixed cell population of neurons, glia, and oligodendrocytes. The mixed culture was subsequently treated with a panel of drugs (Supplementary Data 3) at 10 µM for 24 h and frozen in a lysis buffer until library preparation. RNA was extracted and reverse transcribed into cDNA in each well of the plate, followed by pooling and preparation of mRNA libraries. After sequencing, mRNA reads were demultiplexed according to well barcodes, and the resulting gene expression profiles were processed by a standard differential expression method to derive drug-associated gene lists. b A highlight of two compounds whose gene lists consistently yield improved performance over the randomly selected lists of equal length. Shown is performance associated with predicting early-vs-late disease stages in several AMP-AD datasets. Each row corresponds to an evaluation of gene lists in a single dataset; MSBB evaluation is subdivided into four brain regions, specified as Brodmann Area. The vertical line denotes performance of the drug-associated list, while the background distribution shows performance of gene lists randomly selected from the same dataset. The drugs are annotated with their nominal targets. The unadjusted p-values were computed with a one-sided empirical test, by counting the fraction of randomly selected lists that outperformed the corresponding drug-associated lists.

## Section: Results › Systematic assessment of drug signatures derived from 3′ DGE leads to a ranked list of repurposing candidates

Each DGL is evaluated against randomly selected gene lists of the same length (Fig. 1a). The empirical p-value, computed as the fraction of random lists that outperform a DGL, constitutes a natural starting point for comparing predictor performance across drugs, because it is effectively normalized by the number of genes in the DGL. An example of drugs whose DGL consistently outperform random lists include the pre-clinical compound TAE684 and the approved drug ruxolitinib, whose primary targets are ALK and JAK1/2 kinases, respectively (Fig. 2b). Next, we combined the empirical p-values from multiple datasets and brain regions to create a harmonic mean p-value (HMP) for each drug. The HMP facilitates the detection of significant hypothesis groups in a multiple hypothesis setting, while being less restrictive and providing greater statistical power than similar multiple hypothesis testing procedures48. Using HMP as a prioritization scheme, we identified the top 15 FDA-approved and top 15 pre-clinical drugs (Fig. 3) in the full ranking of all 80 drugs that were profiled in differentiated RenCell cultures (Supplementary Data 3).Fig. 3Top 15 FDA-approved (left) and experimental/investigational (right) drugs, sorted by harmonic mean p-value.Each heatmap shows unadjusted empirical p-values associated with a drug’s predictive performance across two AMP-AD datasets, ROSMAP and MSBB. The MSBB analysis is further subdivided by the brain region, specified as Brodmann Area. The empirical p-values were computed by counting the proportion of randomly selected lists that outperformed the gene lists of interest (i.e., a one-sided test). The p-values were then aggregated across the datasets by computing the harmonic mean p-value (HMP), which is shown in the last column of each heatmap. The rows are annotated with the name of the drug/compound, its nominal target, and the index of the corresponding DGE experiment. Additional annotations include information about each compound’s approval status (approved/investigational/experimental) and whether compounds were found to be toxic in neuronal cell cultures.

Some of top-performing drugs were developed as antineoplastics and are known to be cytotoxic in some cell types (e.g. TAE684 (ref. 49)). To assess the magnitude of this cytotoxicity, we used fixed cell microscopy to quantify the fraction of differentiated RenCells that were viable following 48 h of exposure to a high drug dose (10 µM; see “Methods” and Supplementary Fig. 3). Drugs that significantly reduced viable cell number were annotated cytotoxic (Fig. 3). We also observed that viable cell number was correlated with total RNA yield (Wilcoxon Rank Sum test, p < 4 × 10−9), suggesting that compound toxicity could also be inferred from a reduction in mRNA abundance in post-perturbational gene expression profiles (Supplementary Fig. 3). A cytotoxic drug does not seem a promising lead for an AD therapeutic but since DGLs of cytotoxic drugs consistently outperform random lists across multiple AMP-AD dataset (Figs. 2b and 3), the mechanisms of cell death induced by these drugs may share some similarity with mechanisms of cell death in AD, potentially leading to hypotheses that could be tested in follow on studies targeting cell death mechanisms in neurodegeneration.

Each heatmap shows unadjusted empirical p-values associated with a drug’s predictive performance across two AMP-AD datasets, ROSMAP and MSBB. The MSBB analysis is further subdivided by the brain region, specified as Brodmann Area. The empirical p-values were computed by counting the proportion of randomly selected lists that outperformed the gene lists of interest (i.e., a one-sided test). The p-values were then aggregated across the datasets by computing the harmonic mean p-value (HMP), which is shown in the last column of each heatmap. The rows are annotated with the name of the drug/compound, its nominal target, and the index of the corresponding DGE experiment. Additional annotations include information about each compound’s approval status (approved/investigational/experimental) and whether compounds were found to be toxic in neuronal cell cultures.

## Section: Results › Elucidating target affinity spectrum properties associated with the observed drug ranking

Do high-scoring drugs have features in common? With respect to primary targets, we observed that many drugs, including ruxolitinib, inhibit one or more of members of Janus Kinase family, which comprises JAK1, JAK2, JAK3, and TYK2 (Fig. 3). However, these compounds are known to have additional off-targets that might also contribute to activity27,50. To investigate the potential role of these secondary targets we used the target affinity spectrum (TAS), a vector of activities against a range of targets computed from experimental data that quantifies the potency of a drug based on a variety of biochemical assays27. TAS vectors were constructed by aggregating information about targets and non-targets from published dose–response measurements, experimental profiling data involving multiple targets assayed in parallel, and manual annotations in the literature. Confirmed drug–target interaction was assigned a TAS score of 1, 2, or 3 (with lower values indicating higher binding affinity), while confirmed non-binders were annotated with a TAS score of 10 (Fig. 4a). While less precise than affinity measurements, TAS assertions offer a more complete picture of known targets and known non-targets, enabling more comprehensive target discovery for high-scoring drugs. This is important in the current work because virtually all kinase inhibitors, including clinical grade drugs, have multiple targets, and the best known target, or the one listed in an FDA approval, is not necessarily the highest affinity binder. The full set of TAS scores, which includes the 80 compounds considered in this study, is publicly available at http://smallmoleculesuite.org.Fig. 4Analysis of target affinity among the top-scoring drugs.a Overview of target affinity spectrum (TAS) score computation from raw drug binding data. Three types of drug binding data were sourced from ChEMBL and from the internal Laboratory Systems of Pharmacology dataset that have not yet been incorporated into ChEMBL. Empirically derived thresholds for the different data types were used to assign TAS scores to each drug–target pair. Multiple measurements for the same drug–target combination were aggregated along the first quartile to define the final TAS value. b Binding affinity of compounds in the ranked list to every member of the Janus Kinase family. The compounds are sorted in increasing order by the harmonic mean p-value (as defined in Fig. 3) along the x-axis. The top heatmap shows the binding affinity of each compound to the selected targets, explicitly naming the FDA-approved drugs. Colored and gray tiles denote confirmed binders and non-binders, respectively; missing entries correspond to unknown affinity values. The combined affinity is defined as the strongest binding (lowest TAS score) among all four JAK targets. The bottom plot shows the breakdown of the combined affinity values by TAS-specific empirical cumulative distribution functions (ECDFs). Each line shows ECDFs for all drugs that bind the corresponding target with a TAS score of 1 (dark orange), 2 (orange), or 3 (light orange). c Top targets whose binding affinity correlates most strongly with the compound ranking. The ECDFs of confirmed non-binders (TAS = 10) are shown as gray dashed lines for reference. Area under ECDF can be interpreted as a summary statistic that captures the position of drugs binding to that target with the corresponding affinity in the ranked list. Correlation between the drug ranking and TAS values was computed using the one-sided Kendall’s Tau test, with the associated unadjusted p-value displayed in the bottom right corner of each plot.

We evaluated whether the strength of a binding interaction (i.e., binding affinity) between a compound and its target or a set of biologically related targets contributes to the ranking of a compound by DRIAD. Significant positive correlations between the drug ranking and the binding affinity suggest that the target or class of targets is likely to be pertinent to one or more disease mechanisms. To illustrate this effect, we constructed empirical cumulative distribution functions (ECDFs) for the binding of drugs to members of the JAK family. The list of 80 drugs was traversed in the order of increasing harmonic p-value, while keeping track of the cumulative count of drugs with a particular TAS value (Fig. 4b). This results in three different ECDFs, representing all drugs that bind to the corresponding target with a TAS score of 1, 2, or 3. Area under individual ECDF curves (AUC) can be interpreted as a summary statistic capturing the position of JAK binders with a particular affinity in the ranking; larger values of the AUC correspond to a higher saturation of the corresponding drug set near the top of the ranking.

We observed that compounds having higher affinity for members of the JAK family (i.e., lower TAS values) tend to appear earlier in the ranking (Fig. 4b), with a significant correlation (p = 0.001; Kendall’s Tau test) between binding affinity and the drug ranking as defined by DRIAD. This suggests that downstream transcriptional changes induced by JAK inhibitors anticorrelate with Braak AD stage severity in an affinity-dependent manner. Direct inspection of the experimental 3′ DGE data confirms that binding affinity directly correlates with the levels of expression of several interferon-stimulated genes: drugs that have a higher affinity to JAK family members resulting in stronger inhibition of interferon gene expression (Supplementary Fig. 4). These observations are in accord with previous studies51 suggesting that inhibition of the JAK-STAT and interferon signaling pathways might be beneficial in the context of AD.

We repeated the binding affinity correlation analysis for all targets that had confirmed binding interactions with at least three drugs used in this study (Fig. 4c). The results showed that most of the affinity-dependent effects were contributed by “off-targets”, i.e., established targets for a drug that are different from the target for which the drug is marketed (the nominal target). For example, we observed strong associations between drug ranking and binding affinity for Unc-51-Like Kinases 1 and 2 (ULK1, ULK2) and their downstream substrate Death-Associated Protein Kinase 3 (DAPK3), all of which are associated with autophagy52–54. Autophagy plays an important role in cellular homeostasis and its dysregulation is emerging as a contributing factor to neurodegenerative diseases, including AD55,56. Previous studies suggest that inhibition of autophagy may impair clearance of neurotoxic aggregates. Thus, effective AD therapies may need to maintain or increase autophagy as part of their MOA (e.g. by perturbing proteins that function upstream)57,58. The Salt Inducible Kinase 1 (SIK1) also appears to have a strong association with the position of compounds in the ranking. This association is driven primarily by TAE684, fedratinib, and GSK1070916, all of which are strong binders of SIK1 (TAS = 1) and appear near the top of ranking established by DRIAD. However, none of these drugs are FDA approved or have been studied in the context of SIK1 inhibition.

a Overview of target affinity spectrum (TAS) score computation from raw drug binding data. Three types of drug binding data were sourced from ChEMBL and from the internal Laboratory Systems of Pharmacology dataset that have not yet been incorporated into ChEMBL. Empirically derived thresholds for the different data types were used to assign TAS scores to each drug–target pair. Multiple measurements for the same drug–target combination were aggregated along the first quartile to define the final TAS value. b Binding affinity of compounds in the ranked list to every member of the Janus Kinase family. The compounds are sorted in increasing order by the harmonic mean p-value (as defined in Fig. 3) along the x-axis. The top heatmap shows the binding affinity of each compound to the selected targets, explicitly naming the FDA-approved drugs. Colored and gray tiles denote confirmed binders and non-binders, respectively; missing entries correspond to unknown affinity values. The combined affinity is defined as the strongest binding (lowest TAS score) among all four JAK targets. The bottom plot shows the breakdown of the combined affinity values by TAS-specific empirical cumulative distribution functions (ECDFs). Each line shows ECDFs for all drugs that bind the corresponding target with a TAS score of 1 (dark orange), 2 (orange), or 3 (light orange). c Top targets whose binding affinity correlates most strongly with the compound ranking. The ECDFs of confirmed non-binders (TAS = 10) are shown as gray dashed lines for reference. Area under ECDF can be interpreted as a summary statistic that captures the position of drugs binding to that target with the corresponding affinity in the ranked list. Correlation between the drug ranking and TAS values was computed using the one-sided Kendall’s Tau test, with the associated unadjusted p-value displayed in the bottom right corner of each plot.

## Section: Results › Polypharmacology analysis reveals additional mechanisms that may correlate with AD severity

We also considered downstream effects of concerted off target binding (polypharmacology) in which genes with a closer association to disease severity are altered more significantly by coordinated activity on two or more targets relative to drugs that selectively bind to only one of the off-targets. To evaluate the impact of polypharmacology on drug–disease associations, we divided the 80 compounds in our dataset into three categories: those with confirmed binding to Target A and Target B and those that bind either Target A or Target B alone (see “Methods”). The three categories were then compared to determine whether compounds binding both targets appear significantly closer to the top of the ranking (Fig. 5a) as defined by the HMP value computed by DRIAD (Supplementary Data 3). We systematically evaluated all pairs of targets that had a least six compounds with confirmed binding interactions associated with TAS values of 1, 2, or 3, and then identified the top pairs in the ranking (Fig. 5b). A pair was deemed to be a positive interaction if compounds binding both targets (A and B) appeared significantly closer to the top of the ranking than compounds binding only one of the targets (A or B, but not both); the pair was deemed to be a negative interaction if the opposite was true.Fig. 5Analysis of polypharmacology effects among the top-scoring drugs.a An example polypharmacology test with a focus on RPS6KA1 and TYK2. The drugs are ranked by the harmonic mean p-value (as in Figs. 3 and 4), and the distributions of drugs bindings to both RPS6KA1 and TYK2 (left), those binding to RPS6KA1 but not TYK2 (middle) and, conversely, TYK2 but not RPS6KA1 (right) are shown along this ranking. Individual drugs that bind those targets are annotated by vertical tick marks directly below the corresponding distribution. b Top ten positive and top ten negative interactions between pairs of targets. The distributions in each plot are compared using Wilcoxon Rank Sum test, with the resulting p-value presented in the bottom right corner. If compounds that bind both targets appear significantly closer to the top of the ranked list (left side of the x axis), we define the target pair to be a positive interaction. Conversely, a pair of targets with an explicit non-binding interaction observed among the top-ranking compounds is defined to be antagonistic. A set of five neutral target pairs (i.e., no significant positive or negative effect) is included for reference.

To determine whether one or more targets consistently participate in positive or negative interactions with other targets, we aggregated individual p-values from the evaluation of target pairs using Brown’s method and Jaccard similarity as the metric of independence between individual tests (see “Methods”). The list of targets was subsequently sorted by the aggregated p-value (Table 1 and Supplementary Data 1). We found that several gene families emerged as candidate for top-scoring compounds in which poly-pharmacology was predicted to be essential. For example, the top-scoring compounds TAE684, dovitinib, ruxolitinib, and fedratinib are observed to bind RPS6KA1 (Fig. 5a and Table 1), a component of a microglial signature59 with a potential role in AD as identified by previous epigenetic studies60, and RPS6KA2, a gene involved in Neurotrophin signaling61 with previous reports of association with Parkinson’s Disease in GWAS studies62. Similarly, NIMA-related kinases NEK3, NEK6, and NEK9 consistently appear in positive interaction with other drug targets among top-scoring compounds (Table 1). All three genes have known relationships to microtubule function and Tau phosphorylation. NEK3 has been reported to influence neuronal morphogenesis through microtubule acetylation, and its phospho-defective mutant is hypothesized to play a role in axonal degeneration63. NEK6 phosphorylates p70-S6 (ref. 64), a key player in hyperphosphorylation of Tau65,66 that leads to microtubule disruption and deposition of Tau tangles. This was found to be relevant to the progression of AD and proposed as an early diagnostic biomarker67,68. NEK9 was found to be differentially expressed in a tauopathy mouse model69. Taken together, these results suggest that the NEK family may be an important set of co-targets, and a successful future therapeutic might require polypharmacology with respect to these kinases.Table 1Top ten targets that consistently appear in the top positive or negative interactions.SymbolDirectionnppadjNEK6Positive2578.25E−1291.32E−06NEK3Positive2375.45E−712.52E−04RPS6KA2Positive2467.62E−684.80E−04LATS2Positive2803.82E−609.53E−04ABL2Negative2042.88E−519.94E−04DCLK3Positive2501.23E−561.24E−03MARK1Positive2714.12E−521.92E−03STK17BPositive2641.22E−492.21E−03NEK9Positive2955.14E−502.66E−03STK17APositive2028.57E−373.23E−03The table lists targets (symbol), whether those pairs are primarily positive or negative interactions (direction), the number of pairs they appear in (n), and the overall p-value computed by aggregating p-values from individual Wilcoxon Rank Sum tests (Fig. 5b) using the Brown’s method. Additional adjustment for multiple hypothesis testing was performed using the Benjamini Hochberg method (padj).

a An example polypharmacology test with a focus on RPS6KA1 and TYK2. The drugs are ranked by the harmonic mean p-value (as in Figs. 3 and 4), and the distributions of drugs bindings to both RPS6KA1 and TYK2 (left), those binding to RPS6KA1 but not TYK2 (middle) and, conversely, TYK2 but not RPS6KA1 (right) are shown along this ranking. Individual drugs that bind those targets are annotated by vertical tick marks directly below the corresponding distribution. b Top ten positive and top ten negative interactions between pairs of targets. The distributions in each plot are compared using Wilcoxon Rank Sum test, with the resulting p-value presented in the bottom right corner. If compounds that bind both targets appear significantly closer to the top of the ranked list (left side of the x axis), we define the target pair to be a positive interaction. Conversely, a pair of targets with an explicit non-binding interaction observed among the top-ranking compounds is defined to be antagonistic. A set of five neutral target pairs (i.e., no significant positive or negative effect) is included for reference.

Top ten targets that consistently appear in the top positive or negative interactions.

## Section: Discussion

In this paper, we described the development of DRIAD, a machine learning framework for evaluating potential relationships between a disease and any biological process that can be described by a list of genes. We used DRIAD to look for associations between the pathological stage of AD and genes that are differentially expressed when a small molecule drug is applied to a culture of terminally differentiated neuronal progenitor cells, which comprises a mix of neurons, astrocytes, and oligodendrocytes. DRIAD is distinct from the traditional approaches in which a model is constructed over the entire gene space and subsequently interrogated for feature importance scores and the enrichment of predefined gene sets, which then serve as a candidate list for further functional studies70. Traditional approaches are well-suited for predictors that exhibit high accuracy, because they establish a strong association between input features and the predicted phenotype. As predictor accuracy decreases, however, it becomes difficult to distinguish whether a high enrichment score is a true association between the corresponding mechanism and disease, or an artifact in a model that does not accurately predict the phenotype of interest (here, disease stage as defined by Braak score). DRIAD effectively decouples gene set enrichment and predictor performance by filtering the transcriptomic space for genes associated with drugs prior to model training and predictor evaluation. Pre-filtering to a limited set of features also addresses issues with overfitting that often arise when constructing computational models from disease databases where the number of cases is much less than the number of ‘omic features. Thus, DRIAD enables a direct, unbiased quantification of the association between the effects of a drug and AD progression.

The 80 compounds that we profiled in vitro were predominantly kinase inhibitors with anti-cancer activity since kinase inhibitors are the largest class of targeted drugs currently available, both as approved and pre-clinical compounds27, with extensive target information and diversity in chemical structure (Supplementary Fig. 5). An observation of possible significance is that there exists an inverse relationship between incidence of cancer and incidence of AD71,72. Among the 80 compounds tested, 33 were FDA-approved (Supplementary Data 3) and can potentially be used for repurposing directly. The remaining set consisted of 33 pre-clinical and 14 investigational compounds, which allowed us to explore a wider spectrum of mechanisms. Targets of pre-clinical and investigational compounds that were scored highly by DRIAD could potentially be used for selection of FDA-approved compounds in future screens or for the development of NMEs.

We ranked all compounds by how well their MOAs (as represented by a list of gene names) were able to predict disease severity based on gene expression in AMP-AD datasets. We found several drugs whose primary targets are JAK kinases to be among the top performers. We also explored connections between drug and their primary and secondary targets. This revealed that top-ranking drugs modulate pathways related to interferon signaling, autophagy, and microtubule formation and function. Kinases from JAK, ULK, and NEK families were found to be among the most consistent targets of top-scoring drugs. Future investigation will include experimental validation of these targets in cell-based and animal models using CRISPRa and/or CRISPRi, or other gene editing techniques, to evaluate whether a drug “hit” from DRIAD has an impact on AD-associated pathophysiology.

DRIAD has the potential to identify drugs that both mimic (or accelerate) disease and those that inhibit it. From the perspective of actual drug repurposing, only the later compounds are useful. In other studies, gene expression changes have demonstrated increased interferon signaling in AD73 and in ALS74 brains. Recently, we have found that cytoplasmic dsRNA, a known activator of Type I interferon, is present in ALS brains with TDP-43 pathology. Similarly, cytoplasmic dsRNA, which has been linked to increased Type I interferon signaling, was found to accumulate in glia in AD brains75. Activation of interferon signaling in this context promotes neuronal cell death. Thus, it seems probable that the inhibitors of JAK-STAT signaling identified in this study will potentially be useful in blocking neuroinflammation and cell death in the context of AD. Further studies to investigate the role of JAK-STAT signaling in aging and in AD brains are therefore warranted.

DRIAD allows for unbiased assessment of biological processes or drug candidates even when disease mechanisms are not explicitly known. This is valuable from a neuropathological perspective because it is increasingly clear that in addition to the classical AD hallmarks of amyloid plaques, neurofibrillary tangles, and neuronal loss, most patients with a clinical diagnosis of AD dementia have distinct patterns of co-occurring pathologies including TD-P43 inclusions, Lewy bodies, vascular changes, astrocyte and microglial activation, and probably other unrecognized alterations30,76–79. By working directly with the mRNA expression data from postmortem brain specimens and a priori knowledge of which genes encapsulate a proposed mechanism or co-expression module, or which genes are perturbed by a set of drugs, DRIAD can score mechanisms, co-expression modules or drugs without explicit knowledge of co-existing pathologies, such as the presence of Lewy Bodies or TDP-43 inclusions, in individual patients. Thus, DRIAD is capable of evaluating diverse hypotheses, including those associated with repurposing, without a high level of prior knowledge.

The AMP-AD Knowledge Portal is the most comprehensive database of gene expression profiles from AD brains, combining data from multiple large-scale studies. The gene expression profiles from autopsied brains are associated with Braak pathologic stage, making it possible to compare patients with no or mild AD symptoms at the time of death to patients who were demented. However, this anchoring on Braak staging also includes some cases in which symptoms did not correlate with pathological stage. A follow-on computational approach to deconvolve the correlative signals observed between top-performing drug signatures and AD expression profiles would help inform subsequent mechanistic studies. One direction for follow-up is to rerun the DRIAD pipeline on patient subgroups as defined by more detailed clinical or pathologic phenotypes, motivated by the notion of personalized treatment: different molecular pathways of AD arising in different patients will likely require different interventions to rescue neuronal death. Additional directions for follow-up include applying DRIAD to other studies that include age-matched individuals with no evidence of AD pathology as controls to build a predictor for the risk of AD pathology, and studies that include additional molecular modalities (e.g., mass spec proteomics, genome-wide association studies, etc.) and clinical co-variates (e.g., cognitive decline, comorbidities).

Our study has identified associations of gene perturbations by a subset of FDA-approved drugs and investigational compounds—largely kinase inhibitors—in human neural cells with gene perturbations in AD brain regions, but it has a number of limitations. We will extend this approach to small molecule drugs with a greater diversity of mechanisms of actions, e.g. GPRC inhibitors, as well as consider other types of drugs that target key AD genes. Our results require validation in relevant in vitro and in vivo AD model systems with amyloid plaques, neurofibrillary tangles, and neuronal death80 to examine impacts on key pathologic features or through emulated clinical trials in electronic health records81. Another limitation is knowing if drugs cross the blood-brain barrier (BBB), which is important for their use in brain diseases. These compounds were not developed to treat diseases of the brain, and we find inconsistencies in the methodology and animal models used across studies to assess BBB penetration for each compound. Theoretical approaches have been developed that aim to predict the penetration of drugs into the brain based on physical characteristics and chemical structure; however, the predictability is not generalizable across all compounds82. Therefore, the only way to know if a drug crosses the BBB is through empirical studies in patients with the disease of interest by quantifying free and total drug levels in cerebral spinal fluid by performing lumbar punctures in patients in a relevant age range who are already taking an FDA-approved drug of interest or as a pharmacokinetic outcome of a pilot clinical trial for compounds of interest with unknown BBB penetration.

## Section: Methods › High-throughput profiling using 3′ DGE

A multiwell cell dispenser (catalog# 5840300, Thermo Scientific, Waltham, MA) with standard tubing (catalog# 24072670, Thermo Scientific, Waltham, MA) was used to plate 2500 neural stem cells (ReNcell VM, catalog# SCC008, Millipore, Billerica, MA) into each well of a 384-well cell culture plate (Perkin Elmer, Waltham, MA). Neural stem cells were differentiated into mature neural cells for 1 week and then treated with compounds (Supplementary Data 3) or DMSO using a D300 Digital Dispenser (Hewlett-Packard, Palo Alto, CA). D300 software was used to randomize dispensation of compounds. After 24 h, the cells were washed once with PBS using an EL405x plate washer (BioTek, Winooski, VT) leaving 5–10 µl of PBS behind in each well; 10 µl of 1× TCL lysis buffer (catalog# 1070498, Qiagen, Hilden, Germany) with 1% (v/v) β-mercaptoethanol was added per well, and the plates were stored at −80 °C until the RNA extraction was performed.

For RNA extraction, the cell lysate plate was thawed and centrifuged for 1 min at 1000 × g. Using a BRAVO (Agilent, Santa Clara, CA) liquid handler, the lysate was mixed thoroughly before transferring 10 µl to a 384-well PCR plate; 28 µl of home-made Serapure SPRI beads (GE Healthcare Life Sciences, Marlborough, MA) were added directly to the lysate, mixed and incubated for 5 min. The plate was transferred to a magnetic rack and incubated for 5 min prior to removing the liquid to aggregate the beads. The beads were washed with 80% ethanol twice, allowed to dry for 1 min, 20 µl of nuclease-free water was added per well, the plate was removed from the magnetic rack, and the beads were thoroughly resuspended. Following a 5-min incubation, the plate was returned to the magnetic rack and incubated an additional 5 min before transferring the supernatant to a fresh PCR plate. Five microliters of the RNA was transferred to a separate plate containing RT master mix and 3′ and 5′ adapters for reverse transcription and template switching (Soumillon, et al., 2014), and incubated for 90 min at 42 °C. The cDNA was pooled and purified with a QIAquick PCR purification kit according to the manufacturer’s directions with the final elution in 21 µl of nuclease-free water. This was followed by exonuclease I treatment for 30 min at 37 °C that was stopped with a 20-min incubation at 80 °C. The cDNA was then amplified using the Advantage 2 PCR Enzyme System (Takara, Fremont, CA) for six cycles, and purified using AMPure XP magnetic beads (Beckman Coulter Genomics, Chaska, MN). Library preparation was performed using a Nextera XT DNA kit (Illumina, San Diego, CA) on five reactions per sample following the manufacturer’s instructions, amplified 12 cycles, and purified with AMPure XP magnetic beads (Beckman Coulter Genomics, Chaska, MN). All primers used in library preparation are detailed in Supplementary Table 1. The sample was then quantified by qPCR and sequenced on a single Illumina NextSeq run with 75 bp paired end reads at the Harvard University Bauer Core Facility.

Raw RNA reads were aligned against a reference genome and quantified using the bcbio-nextgen single cell/DGE RNAseq analysis pipeline (https://bcbio-nextgen.readthedocs.io/). The pipeline consists of the following steps: (1) well barcodes and unique molecular identifiers (UMIs) were extracted from every RNA read; (2) all reads not within the edit distance of a single nucleotide from a predefined well barcode were discarded; (3) each extant read was quasialigned to the human transcriptome (version GRCh38) using RapMap83; (4) reads per well were counted according to UMIs84, discarding reads with duplicate UMIs, weighting multi-mapped reads by the number of transcripts they aligned to and collapsing transcript counts to gene level by summing across all transcripts of a gene.

Differential gene expression analysis was performed with the R package edgeR 3.18.1. Compound-associated gene lists were composed from genes with a significant (FDR < 0.05) post-perturbation change in expression level compared to DMSO controls. For most compounds, this produced a list with 300 or fewer genes. The remaining few lists were capped at the top 300 genes to (a) make them more consistent with the vast majority of profiled drugs, allowing for fairer comparisons across compounds; (b) increase the sampling space for the corresponding background sets, and (c) help prevent overfitting that arises when the number of features is vastly larger than the number of samples (Supplementary Fig. 1).

## Section: Methods › Prediction of disease stage

Gene expression profiles of postmortem brain specimens along with the corresponding clinical annotations were downloaded from the Synapse portal at www.synapse.org/AMPAD. The entire transcriptional feature space was filtered down to ~20k protein-coding genes to ensure fairness of comparison between transcriptional changes induced by the profiled compounds (which were all kinase inhibitors in this study) and the randomly sampled background lists. Every specimen was assigned a label of disease severity based on the following mapping to the Braak annotations26: A—early (Braak 0–2), B—intermediate (Braak 3–4), and C—late (Braak 5–6). The labels were used to establish three binary classification tasks, contrasting A vs. B, B vs. C, and A vs. C, with the expression of a prespecified list of genes playing the role of the input features.

Data for any given binary classification task were used to train prediction models using four different methods: logistic regression, support vector machines, boosted random forest models, and two-layer fully connected neural networks. The final ranking of drugs was derived from logistic regression models, because they exhibited the highest accuracy among the four machine learning methods (Supplementary Fig. 6). To address overfitting, a ridge regularization term that penalizes the L2-norm of feature weights was included in the models. No LASSO regularization was used, as it induces sparsity and excludes features that were specifically preselected to be included in the model.

Note that the proposed DRIAD framework is generally agnostic to the underlying method used to train classification models; importantly, the same method must be applied to random lists and the feature lists of interest. However, methods that guarantee that all preselected input features will be included in a model are more desirable, since they allow for an effective comparison of feature lists. As such, random forest models are not recommended, because one or more features may not get selected to be included in at least one decision tree.

Model performance was evaluated through leave-pair-out cross-validation. For a given binary classification task, each example in the dataset was associated with the example from the opposite class that was the closest match in age. If there were multiple candidates for the age match, the pairing was selected uniformly at random. The resulting set of age-matched pairs was evaluated in a standard cross-validation setting, by asking whether the later-stage example in each withheld pair was correctly assigned a higher score by the corresponding predictor. The fraction of correctly ranked pairs constitutes an estimate of the area under the ROC curve85.

## Section: Methods › Assessing gene list significance

For a given gene list of interest, 1000 random gene lists of matching lengths were sampled from a uniform distribution over the protein-coding space. Additional analysis did not reveal any significant association of predictor performance to the pairwise correlations among selected genes, nor to the proximity of selected genes on a gene–gene interaction network. Based on these observations, we saw no reason to bias random gene selection toward more (or less) internal connectivity.

Gene lists produced by the random sampling constitute a background for comparison with a particular gene list of interest. After evaluating all lists through cross-validation, an empirical p-value was computed as the fraction of background lists that yield higher predictor performance than the gene list of interest. p-Values calculated for the same gene list across multiple datasets were combined to produce the HMP value48. Gene lists associated with post-perturbational transcriptional changes were sorted by HMP to produce the final ranking of the corresponding compounds.

## Section: Methods › Assessing toxicity

A multiwell cell dispenser (catalog# 5840300, Thermo Scientific,Waltham, MA) with standard tubing (catalog# 24072670, ThermoFisher Scientific, Waltham, MA) was used to plate 10,000 cells per well of a 96-well cell culture plate (catalog# 3603, Corning, Corning NY). Cells were treated with compounds (Supplementary Data 3) or DMSO using a D300 Digital Dispenser (Hewlett-Packard, Palo Alto, CA). D300 software was used to randomize dispensation of compounds. After 48 h, 60 µl of a solution containing 10% Optiprep (catalog# D1556, Millipore Sigma, St. Louis MO) diluted with PBS (catalog# 21-040-CV, Corning, Corning NY), and a 1:5000 dilution of Hoechst 33342 (catalog# H3570, ThermoFisher Scientific, Waltham, MA) was gently added to the side of each well using a multichannel pipette (catalog# 1060-0850, VistaLab Technologies, Brewster, NY) on the lowest speed setting of 1. After 30 min, 80 µl of a solution containing 3.7% formaldehyde (catalog# 15711, Electron Microsopy Sciences, Hatfield, PA), 20% Optiprep in PBS was added. After a 30-min incubation, a multichannel pipette (catalog# 1060-0850, VistaLab Technologies, Brewster, NY) was used to remove all but 15 µl from each well; 100 µl of 1× PBS was added to each well and the plate was covered with a foil seal (catalog# MSF-1001, Bio-Rad, Hercules, CA). Images were taken on an InCell 6000 (GE Healthcare Bio-Sciences, Pittsburgh, PA). Columbus Image Data Storage and Analysis System (Perkin Elmer, Waltham MA) was used to count the number of Hoechst stained nuclei as a readout of cell number.

## Section: Methods › TAS, top targets, and polypharmacology analysis › Systematic classification of compound-target affinities using TAS

Drug affinity data from ChEMBL v25 (ref. 86) and in-house data comprising drug affinity curves, single-dose binding data from the DiscoverX platform and manual binding assertions curated from literature were compiled into a single consistent measure of binding affinity. Multiple measurements for the same drug–target combination were aggregated by calculating the first quartile. For each drug–target pair, we only considered the highest quality source of data. If full dose–response affinity measurements were available, they took precedence over single-dose binding measurements, which took precedence over binding assertions mined from the literature.

Dose–response affinity data were converted to TAS scores based on empirically derived concentration cutoffs (<100 nM: TAS = 1; 100–999 nM: TAS = 2; 1–10 µM: TAS = 3, and >10 µM: TAS = 10). For single-dose drug binding data, we used concentration-specific thresholds derived from the empirical correlation between dissociation constant and percent inhibition (100 nM <25%: TAS = 2, ≥75%: TAS = 10; 1 µM <1%: TAS = 2, ≥90%: TAS = 10; 10 µM <0.1%: TAS = 2, ≥75%: TAS = 10). Drug–target pairs were assigned TAS = 2 or TAS = 10 if they were mentioned in confirming (e.g., drug X was equipotent for Y) or negative (e.g., drug X was found to not inhibit Y) statements in the literature.

All TAS values used in this study are based on v25 of the Small Molecule Suite, which is publicly available through https://smallmoleculesuite.org.

## Section: Methods › TAS, top targets, and polypharmacology analysis › Identification of important target genes using TAS profiles

Drugs were ranked based on their HMP scores, as computed above. If a drug was profiled in more than one 3′-DGE experiment, the corresponding HMP scores were averaged with a geometric mean. For a given target of interest, ECDFs were computed for each TAS value separately, using the HMP-based ranking as input. Area under individual ECDFs provides a summary statistic for the overall placement in the ranking of drugs with the corresponding TAS value.

The importance of a particular drug target was assessed through the one-sided Kendall’s Tau test, which compares whether pairs of drugs are ordered the same way in two different rankings. In our case, a pair of drugs is considered to be concordant if the drug with the higher binding affinity (lower TAS value) appears closer to the front of the HMP-based ranking, and discordant otherwise. The Kendall’s Tau coefficient is then defined as the fraction of concordant pairs among those that can be ordered (i.e., pairs of drugs with non-identical TAS values). The associated p-value of the Tau coefficient is approximated through standard permutation testing. Targets with fewer than three confirmed binders (TAS = 1, 2, 3) were not evaluated.

## Section: Methods › TAS, top targets, and polypharmacology analysis › Polypharmacology analysis of target gene combinations

We first compiled a list of pairwise gene combinations for which we had TAS scores for both targets from at least six compounds, to ensure that enough points were available for meaningful Wilcoxon rank sum tests. For each combination of targets, we split the compounds into three categories based on their TAS scores: compounds that bind both targets (category “A AND B”) and compounds that bind one of the targets but not the other (categories “A AND NOT B” and “B AND NOT A”). A union of the latter two was defined to be an “A XOR B” set. Wilcoxon rank sum tests were performed separately for “A AND NOT B”, “B AND NOT A”, and “A XOR B”. In all cases, the comparison was made relative to “A AND B”.

For each target pair, p-values from individual Wilcoxon rank sum tests were averaged using the harmonic mean48. The resulting p-values were further aggregated using the Brown’s method (an extension of the Fisher’s method) with the test dependence metric being defined as the Jaccard similarity of the corresponding compound sets. For example, DCLK3 participated in 250 pair evaluations. Two of those evaluations included positive interactions “DCLK3 AND DYRK1B” and “DCLK3 AND DAPK3” pairings, with the corresponding HMP values 0.00099 and 0.0015, respectively (Fig. 5b). There are ten compounds binding DCLK3 and DYRK1B, and the same ten compounds also bind to DCLK3 and DAPK3, yielding a Jaccard similarity of 1.0 for the two pairings. The two p-values are thus considered to be coming from entirely non-independent tests by the Brown’s method, which aggregates all 250 p-values into a single metric of importance for DCLK3 (Fig. 5c).

## Section: Methods › Reporting summary

Further information on research design is available in the Nature Research Reporting Summary linked to this article.

## Section: Supplementary information

Supplementary Information

Supplementary Data 1

Supplementary Data 2

Supplementary Data 3

Reporting Summary

Peer Review File

Description of Additional Supplementary Files

## Section: Supplementary information

Supplementary Information

Supplementary Data 1

Supplementary Data 2

Supplementary Data 3

Reporting Summary

Peer Review File

Description of Additional Supplementary Files


---

# MolAICal: a soft tool for 3D drug design of protein targets by artificial intelligence and classical algorithm

- **Authors:** Qifeng Bai, Shuoyan Tan, Tingyang Xu, Huanxiang Liu, Junzhou Huang, Xiaojun Yao
- **Issuer:** Briefings in bioinformatics
- **Type:** Scientific article
- **Published:** 2021-05-20
- **Language:** en
- **DOI:** 10.1093/bib/bbaa161
- **Source:** https://pubmed.ncbi.nlm.nih.gov/32778891/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractDeep learning is an important branch of artificial intelligence that has been successfully applied into medicine and two-dimensional ligand design. The three-dimensional (3D) ligand generation in the 3D pocket of protein target is an interesting and challenging issue for drug design by deep learning. Here, the MolAICal software is introduced to supply a way for generating 3D drugs in the 3D pocket of protein targets by combining with merits of deep learning model and classical algorithm. The MolAICal software mainly contains two modules for 3D drug design. In the first module of MolAICal, it employs the genetic algorithm, deep learning model trained by FDA-approved drug fragments and Vinardo score fitting on the basis of PDBbind database for drug design. In the second module, it uses deep learning generative model trained by drug-like molecules of ZINC database and molecular docking invoked by Autodock Vina automatically. Besides, the Lipinski’s rule of five, Pan-assay interference compounds (PAINS), synthetic accessibility (SA) and other user-defined rules are introduced for filtering out unwanted ligands in MolAICal. To show the drug design modules of MolAICal, the membrane protein glucagon receptor and non-membrane protein SARS-CoV-2 main protease are chosen as the investigative drug targets. The results show MolAICal can generate the various and novel ligands with good binding scores and appropriate XLOGP values. We believe that MolAICal can use the advantages of deep learning model and classical programming for designing 3D drugs in protein pocket. MolAICal is freely for any nonprofit purpose and accessible at https://molaical.github.io.

## Section: Introduction

Deep learning is a popular artificial intelligence (AI) way that has been successfully applied in medical diagnoses [1], cellular image analysis [2], chemical syntheses [3], classification of drugs [4] and so on [5]. Deep learning is a promising technology for the development and discovery of innovative drugs. The quantitative structure–activity relationship (QSAR) is a traditional method to predict the relationship between molecular descriptors and experimental values (Kd, IC50, etc.) for drug discovery [6]. The traditional machine learning methods, which are used to build the QSAR model, contain support vector machine (SVM) [7], random forest (RF) [8], Bayesian algorithm [9], artificial neural networks (ANNs) [10, 11] and so on. The inhibitors of cathepsin L [12] and kallikrein 5 protease [13] are found by QSAR models which are constructed by SVM method. The score function plays an important role in the prediction of ligand-binding affinity in the target pocket. RF-based scoring functions show that Pearson’s correlation coefficients between experimental affinities and predicted values range from 0.559 to 0.783 with different training sets based on PDBbind database v2007 [14]. As a well-known machine learning method, Bayesian algorithms have been successfully used to identify the inhibitors of G protein-coupled receptors [15], kinases [16], etc. ANNs which are the popular machine learning tools for QSAR studies have been used to select new antibacterial ligands [17] and predict chemical immunotoxicity [18]. Although the traditional machine learning methods have been widely used for new drug discovery, some literature shows deep neural networks (DNNs) outperform traditional machine learning methods in the high-performance model construction of QSAR [19–21].

Besides, the deep learning methods also emerge in the research fields of de novo drug design and drug virtual screening [22–27]. The variational autoencoders (VAEs) [28] and generative adversarial net (GAN) [29] are widely used to small molecular generation for de novo drug design [30]. The reported VAE strategy, which contains the encoder and decoder between SMILES and latent-space representations, multilayer perceptron and properties of interest based on ligands, shows a good result for ligand design with the desired properties [31]. The adversarial autoencoder (AAE) introduces the discriminator network that is trained to distinguish the real input data from the produced data following specified distribution [32]. The AAE can be used to train the molecular SMILES representations to generate the drug-like ligands with the desired properties [33]. The objective-reinforced generative adversarial networks (ORGAN) combines the reinforcement and adversarial learning methods to generate the desired molecules [34]. The generator of ORGAN produces the molecules to deceive the discriminator, while the reward function is constructed with the linear combination of the discriminator model and domain-specific desired objectives. The Wasserstein-1 W distance is used to improve the learning stability of GAN in the ORGAN [35]. The introduced above deep learning models are based on the SMILES sequence representation of molecules. The molecular graph considers the nodes as molecular atoms and edges between two nodes as molecular bonds. It is another way to generate the desired properties of molecules [36]. MolGAN, a graph generative model trained by GAN architecture, can produce more meaningful drug-like molecules via the annotation matrix and dense adjacency tensor [37]. Besides, the research reports point out that SVM combined with molecular docking, molecular mechanics/generalized Born surface area (MM/GBSA), ensemble minimization and optimization hyper-parameter shows a good performance for drug virtual screening [38].

In the deep learning model, the input data and corresponding results are provided to train the rules. Then, these rules can be further applied to generate analogous results. However, in classical programming, the input data and rules are supplied to produce corresponding results by running the designed procedures. Comparing with the deep learning model for drug design, the classical programs can generate 3D appropriate ligands based on the three-dimensional (3D) properties of protein pocket by the programmed algorithm. For example, the LigBuilder [39, 40] can build the desired 3D ligands with small fragments in the pocket of protein target. The OpenGrowth [41], which connects the small fragments to grow 3D ligands in the active pocket of proteins, can produce the molecules with drug-like and synthetic accessibility properties. In addition, the virtual screening software such as AutoDock Vina [42] shows a good scoring power for the binding assessment of ligands in the 3D pockets of protein targets [43].

The deep learning can be used to train drug-like generative models based on one-dimensional (1D) SMILES sequence or two-dimensional (2D) molecular graph. It is an interesting and challenging issue for three-dimensional (3D) ligand generation in the 3D pocket of protein target by deep learning. For the classical processes of drug design, it can design the appropriate 3D ligands in the protein pocket by the molecular docking and de novo methods. Based on the characteristics and merits of deep learning and classical programming, the MolAICal soft package is programmed for 3D drug design in the protein pocket. The MolAICal soft package mainly contains two modules which are written by the JAVA program. One module of MolAICal is designed on the basis of the genetic algorithm and deep learning model trained on the fragments of the Food and Drug Administration (FDA)-approved drugs, while the other module of MolAICal is written on the basis of molecular docking and deep learning model trained on drug-like ligands of ZINC database. The classical de novo drug design software of LigBuilder and OpenGrowth needs to produce the seed fragments manually. By contrast, the MolAICal can automatically generate valid and diverse FDA-like fragments for ligand growth by deep learning generative model. Besides, AutoDock Vina shows the best scoring power for the binding assessment of ligands in the 3D pockets of protein targets [43]. The MolAICal has trained the Vinardo score that has better scoring power than the score of AutoDock Vina based on the PDBbind database [44]. Meanwhile, MolAICal can optimize the structures of ligands in the active pocket of receptors by using the classical algorithm. Moreover, the traditional molecular docking or similarity search needs the ligand database to carry out virtual screening. MolAICal provides a virtual screening way that does not depend on the ligand database because the deep learning model of MolAICal can generate enough number of drug-like ligands for drug virtual screening. In addition, MolAICal is designed by JAVA program that is a popular cross-platform language. So it is easy to run with multicore CPU on different operating systems such as Linux or Windows environment.

To assay the drug design processes of these two modules, the membrane protein glucagon receptor (GCGR) and non-membrane protein SARS-CoV-2 main protease (Mpro) are picked up as the research targets. The GCGR is a member of G protein-coupled receptor family which acts on the regulation of blood glucose level. The SARS-CoV-2 Mpro which plays a key role in the replication and transcription of coronavirus leads to the rapid spread of coronavirus disease 2019 (COVID-19) throughout the world. The researchers have developed an interactive server named COVID-19 Docking Server for discovering small molecules, peptide and antibody [45]. Both of COVID-19 Docking Server and MolAICal can be used to design small ligands in the protein pocket. However, the COVID-19 Docking Server has some differences with MolAICal. Firstly, COVID-19 Docking Server is online based on the webserver, while MolAICal is a software that can be run on the users’ computers. Secondly, the COVID-19 Docking Server has different purposes with MolAICal. The COVID-19 Docking Server, which contains 27 essential targets in the virus life cycle, is mainly built for designing small molecules, peptide and antibody of SARS-CoV-2. The MolAICal mainly focuses on small molecule design of protein targets such as SARS-CoV-2 Mpro, GCGR and other disease receptors. Thirdly, COVID-19 Docking Server web does not involve in the deep learning for drug design. But MolAICal contains the deep learning model for drug design. Lastly, the COVID-19 Docking Server has different architectures with MolAICal. The COVID-19 Docking Server web is built on the basis of PHP, HTML and JSmol (http://jmol.sourceforge.net). The COVID-19 Docking Server includes program modules OpenBabel [46], Autodock Vina [42], CoDockPP [47, 48], etc. The OpenBabel is responsible for format transformation and 3D coordinate conversion for the uploaded molecular files. The Autodock Vina is employed for small molecule docking. The CoDockPP is a docking engine module for peptide and antibody docking. The CoDockPP program uses the multistage FFT-based strategy for the global docking and site-specific docking. The binding modes are ranked and clustered on basis of the ligand root mean square deviations. The MolAICal is designed on the basis of deep learning model and classical programming that contains genetic algorithm, molecular docking, etc. The deep learning model of MolAICal can generate the fragments and drug-like ligands for drug design. The classical programming of MolAICal is responsible for ligand growth and filter, etc. In this paper, the detailed principles and algorithms of MolAICal are introduced for 3D drug design in protein pocket. Our results show that MolAICal can design various ligands which show the high and low 3D structural similarities between generated ligands and crystal ligand of the GCGR or SARS-CoV-2 Mpro. The studied results of SARS-CoV-2 Mpro are shared freely as a reference to help scientists develop new potential drugs of COVID-19 (see https://github.com/MolAICal/COVID-19/tree/master/mpro). The MolAICal not only provides a strategy to solve the issue of 3D ligand generation in the protein pocket, but also gives a reliable, free of charge and effective soft tool for the rational drug design.

## Section: Results and discussion

Flowchart of deep learning based on sequence-based model and graph neural networks model.

The diagram of 3D drug growth algorithm in receptor pocket combined with deep learning and de novo drug design method.

Perturbation search and the operators of genetic algorithm. (A) Perturbation search on the sphere grids around the anchored fragment. (B) Crossover and mutation operators between two ligands.

Searching 3D ligands in the protein pocket by deep learning generative model and virtual screening method.

Designing 3D ligands of GCGR and SARS-CoV-2 Mpro via the MolAICal modules which involve deep learning model, de novo drug design and drug virtual screening.

3D structural similarities contour. (A) The contour of 3D structural similarities between growth ligands and crystal ligand MK-0893 of GCGR based on DL model and de novo drug design. (B) The contour of 3D structural similarities between docked ligands and crystal ligand MK-0893 of GCGR based on DL model and drug virtual screening of GCGR. The contour is divided into six color levels. The representative molecules of six color levels are extracted to show the structural similarity with crystal ligand MK-0893 in the pocket of GCGR.

3D structural similarities contour. (A) The contour of 3D structural similarities between growth ligands and crystal ligand N3 of SARS-CoV-2 Mpro based on DL model and de novo drug design. (B) The contour of 3D structural similarities between docked ligands and crystal ligand N3 of SARS-CoV-2 Mpro based on DL model and drug virtual screening. The contour is divided into six color levels. The representative molecules of six color levels are extracted to show the structural similarity with crystal ligand N3 in the pocket of SARS-CoV-2 Mpro.

## Section: Results and discussion › Deep learning generative model for 2D molecular generation

Deep learning (DL) is a popular and effective way to generate novel, synthesizable and drug-like ligands via generative models that are trained on the specified set of small molecules. Especially, the generative adversarial network (GAN), which is a popular way for drug discovery, contains the generative model that produces the counterfeit molecules and discriminative model that tries to distinguish the genuine molecules from the training set and counterfeit molecules. The generative model can be improved for the ligand generation by training the indistinguishable counterfeit molecules from the training set. To use the merit of deep learning, our designed soft tool employs the sequence-based generative model and graph neural networks (GNNs) generative model for producing the ligand set and small molecular fragments (see Figure 1). For the sequence-based generative model, because the drugs can be represented as the SMILES sequences format, the drugs can be trained like natural language and musical notation. The 1930 Food and Drug Administration (FDA)-approved drugs, 21,064 fragments of FDA-approved drugs extracted from e-Drug3D database [49] and 1,060,000 drug-like ligands obtained from ZINC database [50] are chosen to train the generative model. All the ligands and molecular fragments are converted to SMILES. To generate the small FDA-like fragments, the length of trained sequences is constrained within 12. The diversity metrics are used to enhance the diversity generation of FDA-like fragments. The length of molecular sequences from ZINC database is limited within 60 to train the drug-like ligands. For the GNN generative model, the molecule is considered as the undirected graph with a set of nodes and edges. Each node which represents atom type in the molecular graph has an annotation matrix X. And the bond type between two atoms is expressed as the adjacency tensor A in the molecular graph. The annotation matrix X and adjacency tensor A handled by categorical sampling can profile one molecular graph which corresponds to a chemical compound (see Figure 1). The QM9 molecular data [51] which contains 133 885 compounds are selected for training deep learning generative model. All the molecules of QM9 are converted to SDF format. Both the sequence-based generative model and GNNs generative model are trained by Wasserstein generative adversarial networks (WGANs) and reinforcement learning (RL). The WGANs [35] which are minimization problems of Earth Mover distance, supply a reliable way to measure the difference of probability distributions between the real and plausible data distribution (see Equation 1);(1)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{equation*} W\left({\mathbb{P}}_r,{\mathbb{P}}_{\theta}\right)={\sup_{{\left|\left|f\right|\right|}_L\le 1}}{\mathbb{E}}_{x\sim{\mathbb{P}}_r}\left[f(x)\right]-{\mathbb{E}}_{x\sim{\mathbb{P}}_{\theta }}\left[f(x)\right] \end{equation*}\end{document}

The first and second terms in the right-hand side of the equation represent sample discrimination from the real data and generative data, respectively. The WGAN value function is solved to get the best optimization as Equation (2):(2)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{align*} \underset{G}{\min }\ \underset{D}{\max }\ {\mathbb{E}}_{x\sim{\mathbb{P}}_r}\left[D(x)\right]-{\mathbb{E}}_{z\sim p(z)}\left[D(G(z))\right] \end{align*}\end{document} where G and D are the generative and discriminative models, respectively. The discriminator D tries to maximize the distinguishable probability of real data and minimize the indistinguishable probability of fake data. The reward network deals with discrete samples by using reinforcement learning. The reward functions for the molecular generator is a linear combination of WGAN and RL (see Equation 3):(3)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{equation*} R=\lambda \bullet{f}_{WGAN}+\left(1-\lambda \right)\bullet{f}_{RL} \end{equation*}\end{document} where R is a reward function. λ∈[0, 1] represents the hyper-parameter which adjusts the components of WGAN and RL. The sequence-based generative model and GNNs generative model are trained by modifying minor source code of ORGAN [34] and MolGAN [37] based on their benchmark. Besides, the DL generative model can be trained on the user-defined data set with the special purpose. The trained generative model is packaged as a binary module named AIGenMols in MolAICal soft package for generating 1D sequence or 2D structures of fragments and drug-like ligands.

Flowchart of deep learning based on sequence-based model and graph neural networks model.

## Section: Results and discussion › 3D drug design in protein pocket by DL model and classical programming

The deep learning (DL) model can generate 1D sequence or 2D structures of ligands. However, the rational drug design needs 3D structures of ligands that target to the crystal structure of protein. Currently, it is a challenging issue to design the 3D ligands based on 3D structures of protein pocket by deep learning model. To solve this problem, the classical programming is introduced to design 3D structural ligands in the receptor pocket (see Figure 2). The DL and classical programming have their own advantages. The DL trains the rules from the input data and output results, while the classical programming can give the output results from the input data and designed algorithm rules. The classical programming such as de novo drug design is good at 3D drug design in the receptor pocket. We propose one strategy which contains the merits of DL and classical algorithm to solve the problem of 3D ligand design in the receptor pocket (see Figure 2).

The generative model named AIGenMols in MolAICal soft package has been trained for the generation of fragments and ligands. It can be responsible to generate FDA-like fragments that service for ligand growth in the receptor pocket (see Figure 2). The initial fragment for growth can choose the part of crystal ligand in the receptor pocket or be generated around the key protein atom based on the setting SIMLES format fragment. The next fragment growth is based on the previous molecular fragment via the perturbation search of random or Fibonacci algorithm (see Figure 2). As shown in Figure 3A, the random algorithm distributes the points on the sphere randomly, while the Fibonacci algorithm uses the golden angle π(3-\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}$\sqrt{5}$\end{document}) to distribute the points on the sphere. MolAICal only chooses one of the random and Fibonacci algorithms for perturbation search. The positions of points on the sphere are calculated as in Equation (4):(4)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{eqnarray*} && {x}_i=\sqrt{1-{\left(1-\frac{1}{N}-\frac{2i}{N}\right)}^2}\ast \cos \left(\pi \left(3-\sqrt{5}\right)\ast i\right)\\ && {y}_i =\sqrt{1-{\left(1-\frac{1}{N}-\frac{2i}{N}\right)}^2}\ast \sin \left(\pi \left(3-\sqrt{5}\right)\ast i\right)\\ && {z}_i=1-\frac{1}{N}-\frac{2i}{N} \nonumber \end{eqnarray*}\end{document}

where xi, yi and zi represent the coordinates of sphere points. N is the total number of generated points. The next fragment will try to find the best anchoring pose via perturbing search on the generated points around the growth atom (see Figure 3A). When the ligand grows long enough, the genetic algorithm (GA) is further employed to optimize the grown ligands in the pocket of the receptor. The grown ligands can be considered as the formation of rigid fragments and rotational bonds (see Figure 3B). The GA crossover is performed by interchanging rigid fragments between any two ligands in the generated populations. For GA mutation operator, the ligand mutates its rigid fragments according to the mutation ratio. The GA selection is based on the binding score between the ligands and receptors. MolAICal chooses the Vinardo score to estimate the affinity between ligands and receptors. The Vinardo score is trained on the basis of the experimental affinity data and high-resolution crystal structures of protein–ligand complexes which are extracted from PDBbind v2018 database [44]. The complexes that contain cofactors and metal ions are kicked out from the PDBbind refined set. A total of 2903 protein–ligand complexes is selected to train the equation coefficients of Vinardo score [52] (see Equation 5):(5)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{equation*} E=\sum_i{\displaystyle \begin{array}{c}w1\ast Gauss\left({d}_i\right)+w2\ast Repulsion\left({d}_i\right)+\\[3pt] {}\ w3\ast Hydrophobic\left({d}_i\right)+w4\ast Hbond\left({d}_i\right)\end{array}} \end{equation*}\end{document} where E is the binding score between the ligand and protein. di is the distance between two atoms. w1, w2, w3 and w4 are the coefficients. The steric interaction is evaluated by Equations (6) and (7). The hydrophobic and H-bond interactions are assessed using Equations (8) and (9):(6)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{equation*} Gauss(d)={e}^{-{\left(\left(d-o\right)/s\right)}^2} \end{equation*}\end{document}(7)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{equation*} Repulsion(d)=\left\{\kern-4pt\begin{array}{c}{d}^2,\mathrm{if}\ d<0\overset{\circ }{\mathrm{A}}\\{}0,\mathrm{if}\ d\ge 0\overset{\circ }{\mathrm{A}},\end{array}\right. \end{equation*}\end{document}(8)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{equation*} Hydrophobic(d)=\left\{\kern-5pt\begin{array}{c}1,\mathrm{if}\ d<{p}_1\ \\{}{p}_2-d,\mathrm{if}\ {p}_1\le d\le{p}_2\ \\{}0,\mathrm{if}\ d>{p}_2\ \end{array}\right. \end{equation*}\end{document}(9)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{equation*} Hbond(d)=\left\{\kern-5pt\begin{array}{c}1,\mathrm{if}\ d<{h}_1\ \\{}1-\frac{d-{h}_1}{-{h}_1},\mathrm{if}\ {h}_1\le d\le 0\overset{\circ }{\mathrm{A}}\ \\{}0,\mathrm{if}\ d>0\overset{\circ }{\mathrm{A}}\ \end{array}\right. \end{equation*}\end{document} where d is the distance between two atoms. o, s, p1, p2 and h1 are the tuning parameters. Here, the Pearson and Spearman (rp/rs) correlations of our fitting Vinardo score are 0.582/0.592, which are better than rp/rs of 0.569/0.584 in Autodock Vina [43, 53]. The Vinardo score can select the elitist ligands for the next GA evolution process.

The Vinardo score can assess the affinity of the ligands in the protein pocket. It still needs to estimate the drug-likeness for the selection of the good affinity ligands. MolAICal supplies the filter rules of Lipinski’s rule of five (RO5) [54], Pan-assay interference compounds (PAINS), synthetic accessibility (SA) and other user-defined rules to enhance the drug-likeness selection of the good affinity ligands. The SwissADME is a wonderful tool for predicting the drug-likeness, pharmacokinetics, PAINS and so on. The SwissADME [55] has a slight difference with MolAICal in the calculated method of RO5. The SwissADME employs the MLOGP for evaluating the octanol–water partition coefficient, while MolAICal uses the XLOGP for RO5. With the new drug development and discovery, the RO5 cutoff values of molecular weight, hydrogen bond acceptors and rotatable bonds have increased substantially according to the statistics of FDA-approved oral drugs [56]. In order to enhance the druggability, the cutoff of molecular weight, hydrogen bond acceptors and rotatable bonds are recommended to 1000, 12 and 14 in the MolAICal soft package, respectively. The PAINS are the ligands which tend to react with biological receptor nonspecifically. The MolAICal filters out the PAINS via mapping the molecular patterns SMARTS of PAINS library. Because the growth ligands may be difficult to synthesize, the SA prediction model can be used to pick up the easy synthetic compounds. The MolAICal predicts the synthetic accessibility of compounds based on Ambit JAVA library. In addition, the MolAICal also supplies the function module to filter the user-defined unwanted fragments. The ligands with similar binding scores may have similar structures. To pick up the representative ligands for the subsequent experiment, the generated 3D ligands are clustered by the K-means algorithm based on binding scores and similarities of molecular fingerprints. By comparing with other algorithms, MolAICal can use the merits of deep learning model and classical algorithm to generate molecules with high validity and diversity (see Table S2). In total, the MolAICal can take advantage of the DL model and classical algorithm to design the rational 3D ligands in the protein pocket.

The diagram of 3D drug growth algorithm in receptor pocket combined with deep learning and de novo drug design method.

Perturbation search and the operators of genetic algorithm. (A) Perturbation search on the sphere grids around the anchored fragment. (B) Crossover and mutation operators between two ligands.

## Section: Results and discussion › 3D drug design in protein pocket by DL model and VS

The DL generative model and de novo drug designed method can design the 3D ligands in the receptor pocket fragment by fragment. In addition, virtual screening (VS) is another way to screen the rational 3D ligands in the receptor pocket based on the ligand database. The MolAICal soft tool supplies a way to search the rational 3D ligands in the receptor by combining deep learning (DL) generative model and classical programming of VS. The entire procedure is mainly divided into three parts to screen 3D ligands in the receptor pocket (see Figure 4). Firstly, the trained DL generative model is employed for generating drug-like ligands with SMILES format. Secondly, the Merck Molecular Force Field 94 (MMFF94) of Open Babel [46] is used to generate the 3D conformations of SMILES format ligands produced by DL generative model. In the next step, the Autodock Vina is invoked to perform the drug virtual screening based on the generated ligand database. The screened results can be further filtered by Lipinski’s rule of five, Pan-assay interference compounds (PAINS), synthetic accessibility (SA) and other user-defined rules and clustered for selecting the representative ligands on the basis of binding scores and similarities of molecular structures. Besides, MolAICal provides a convenient way to calculate the ligand-binding affinities by MM/GBSA method based on the log files of molecular dynamics (MD) simulations which are performed by NAMD software [57]. The MM/GBSA [58] is considered a relatively accurate way to estimate the binding free energy between two molecules such as ligand and protein, protein and protein, nucleic acid and protein, etc. The dynamical interaction mechanism between receptors and ligands can be elucidated by the calculation of MM/GBSA based on the MD simulations. The MM/GBSA is estimated by Equations (10)–(12):(10)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{equation*} \Delta{G}_{\mathrm{bind}}=\Delta H\hbox{--} T\Delta S\approx \Delta{E}_{\mathrm{MM}}+\Delta{G}_{\mathrm{sol}}\hbox{--} T\Delta S \end{equation*}\end{document}(11)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{equation*} \Delta{E}_{\mathrm{MM}}=\Delta{E}_{\mathrm{internal}}+\Delta{E}_{\mathrm{ele}}+\Delta{E}_{\mathrm{vdw}} \end{equation*}\end{document}(12)\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{upgreek} \usepackage{mathrsfs} \setlength{\oddsidemargin}{-69pt} \begin{document} }{}\begin{equation*} \Delta{G}_{\mathrm{sol}}=\Delta{G}_{\mathrm{SA}}+\Delta{G}_{\mathrm{GB}} \end{equation*}\end{document}

where ΔEMM and -TΔS are the gas phase MM energy and conformational entropy, respectively. ΔEMM contains electrostatic ΔEele, van der Waals energy ΔEvdw and ΔEinternal of bond, angle, and dihedral energies. ΔGsol is the solvation free energy which is the sum of the nonelectrostatic solvation component ΔGSA and electrostatic solvation energy ΔGGB. The conformational entropy is very difficult to get a converged value. Besides, if the ligands do not have any binding-induced structural change in the MD simulations, the conformational entropy is usually ignored to calculate by the normal mode analysis [59]. The MolAICal supplied a fast way to evaluate the binding free energy without the entropy of ligands based on the three-trajectory approach. If conformational entropy needs to be computed, the MMPBSA.py program [60] can be used to assess the entropy of conformational change. The scripts, coordinate files, trajectories and relative parameters of MD simulations of example cases such as glucagon receptor (GCGR) and non-membrane target SARS-CoV-2 main protease (Mpro) can be found at the end of supplementary material file. The authors can perform the MD simulations on their appointed targets according to our supplied files.

Searching 3D ligands in the protein pocket by deep learning generative model and virtual screening method.

## Section: Results and discussion › Examples of 3D ligand design in the protein pocket by MolAICal

Two approaches have been introduced for 3D ligand design in the protein pocket by using artificial intelligence and classical programming of MolAICal. One is de novo drug design by deep learning model and genetic algorithm. The other is drug virtual screening by deep learning model and molecular docking invoked by MolAICal. In order to demonstrate the 3D ligand design by MolAICal, the membrane target glucagon receptor (GCGR) and non-membrane target SARS-CoV-2 main protease (Mpro) are chosen as the drug design targets (see Figure 5). The GCGR [61, 62] is a potential target of type 2 diabetes which is a member of the class B family of G protein-coupled receptors. The SARS-CoV-2 Mpro plays an important role in processing the polyproteins of viral RNA which is a potential drug target of coronavirus disease 2019 (COVID-19) [63, 64].

The 3D structural similarity [65] between the growth ligands and crystal ligand of GCGR or SARS-CoV-2 Mpro can be used to check whether MolAICal software can generate similar or different types of ligands. According to the recent research report [56] and relative values of Lipinski’s rule of five of GCGR antagonist MK-0893 (Table S1), the maximum XLOGP value is set to 6 for filtering out the higher XLOGP values of ligand designed by deep learning model, de novo and virtual screening methods. As shown in Figure 6A, the binding scores and XLOGP values of ligands are chosen as the components to draw the contour of 3D structural similarity between MK-0893 and growth ligands. The growth ligands are divided into six parts based on the 3D structural similarity. The crystal antagonist MK-0893 shows gray, while the representative ligand drawn red has 3D structural similarity ranging from 0.6505 to 0.8220 in level 1. It shows that the ligand in level 1 has a 3D similar structure with crystal antagonist MK-0893 (see Figure 6A). Besides, the binding score of the crystal antagonist MK-0893 is −8.63 kcal/mol in the pocket of GCGR. In comparison with MK-0893, the results show the growth ligands with lower 3D structural similarity still have good binding scores. It indicates that MolAICal can generate potential novel compounds with good affinities theoretically. Figure 6B shows the drug virtual screening results from 2 million drug-like ligands by deep learning generative model and molecular docking. This strategy is different from de novo drug design way. It selects the ligands on the basis of the random generated molecular set. The results show the ligands with ~79% 3D structural similarity are captured from 2 million drug-like molecular sets (see Figure 6B). With the decrease of 3D structural similarity, the ligands with good binding scores show different structures with the crystal antagonist MK-0893. It indicates that the diversity of ligands that have good binding scores are enhanced by using the protocol of MolAICal soft package.

Figure 7A and B shows the results of SARS-CoV-2 Mpro drug design by MolAICal. The crystal structure of SARS-CoV-2 Mpro contains inhibitor N3, which has 19 rotatable bonds (see Table S1). The inhibitor N3 shows more flexible bonds than the antagonist MK-0893. And the small part of N3 is chosen as the initial growth fragment (see Figure S1). Hence, level 4 ligands with blue occupy a very large proportion of contours in Figure 7A and B. It means a large number of novel ligands with good binding scores are generated for SARS-CoV-2 Mpro. The level 1 ligands ranging from 0.6305 to 0.8040 are grown on the basis of the initial fragment of N3 (see Figure 7A). However, the number of level 1 ligands is very few because of the flexible conformation and small initial growth fragment of N3. Figure 7B shows the drug virtual screening results of SARS-CoV-2 Mpro from 2 million drug-like ligands by deep learning generative model and molecular docking. The results show that most of the screened ligands have lower 3D structural similarity with the inhibitor N3 because drug virtual screening depends on the number of generated ligands. It indicates that MolAICal can produce a variety of ligands with good binding scores. Besides, to help the researchers develop the new drugs targeting to SARS-CoV-2, our results are shared in GitHub freely (https://github.com/MolAICal/COVID-19/tree/master/mpro).

We select the representative interesting ligands that have rich in ring groups in Figures 6 and 7. The results also indicate that some ligands that are not rich in benzene rings still have good binding scores (see Figure S2). Figure S2 shows the representative ligands of GCGR and SARS-Cov-2 Mpro that have no rich in ring groups. Especially, the ligands of SARS-Cov-2 Mpro can have structures without any ring group. It indicates that MolAICal can generate the valid and diverse ligands in the protein pocket. For GCGR, the binding sites of antagonist locate outside the seven-transmembrane (7TM) domain in a position between TM6 and TM7. In this case, to get a stable and good binding pose in the allosteric sites of GCGR, the rigid structure such as the ring group is an important factor for growth ligand. In the future version, MolAICal will trace the experiment between ligands and proteins and further improve its performance for drug design.

Designing 3D ligands of GCGR and SARS-CoV-2 Mpro via the MolAICal modules which involve deep learning model, de novo drug design and drug virtual screening.

3D structural similarities contour. (A) The contour of 3D structural similarities between growth ligands and crystal ligand MK-0893 of GCGR based on DL model and de novo drug design. (B) The contour of 3D structural similarities between docked ligands and crystal ligand MK-0893 of GCGR based on DL model and drug virtual screening of GCGR. The contour is divided into six color levels. The representative molecules of six color levels are extracted to show the structural similarity with crystal ligand MK-0893 in the pocket of GCGR.

3D structural similarities contour. (A) The contour of 3D structural similarities between growth ligands and crystal ligand N3 of SARS-CoV-2 Mpro based on DL model and de novo drug design. (B) The contour of 3D structural similarities between docked ligands and crystal ligand N3 of SARS-CoV-2 Mpro based on DL model and drug virtual screening. The contour is divided into six color levels. The representative molecules of six color levels are extracted to show the structural similarity with crystal ligand N3 in the pocket of SARS-CoV-2 Mpro.

## Section: Conclusions

In this study, the MolAICal software is designed for generating 3D structural ligands in the 3D pocket of protein targets by deep learning model and classical algorithm. MolAICal mainly contains two modules. For the first module, the fragments of FDA-approved drugs are used to train deep learning model based on the WGANs. The generated fragments of deep learning model are further used to grow the 3D ligands in the protein pocket. For the second module, the drug-like molecules of ZINC database are employed to train deep learning model based on the WGANs. The affinities between generated molecules and protein are estimated by molecular docking. The membrane target GCGR and non-membrane target SARS-CoV-2 Mpro are chosen for assaying the drug design functions of MolAICal. It shows MolAICal can generate various ligands that have lower and higher 3D structural similarity with crystal ligand of GCGR or SARS-CoV-2 Mpro. The MolAICal contains the useful drug design tools and will help the researchers to find and transform the new potential drugs.

## Section: Materials and methods › Protein structural preparation

The crystal structure of GCGR in complex with antagonist MK-0893 is extracted from PDB database (PDB ID, 5EE7) [61]. The built crystal model of SARS-CoV-2 Mpro (PDB ID, 6LU7) [63] is supplied by the team of Prof. Zihe Rao. The crystal ligands are deleted from the crystal GCGR and SARS-CoV-2 Mpro for de novo and deep learning (DL) drug design, respectively. The grid files of GCGR and SARS-CoV-2 Mpro are produced for fragment growth by MolAICal soft package (https://molaical.github.io). The initial growth fragments of GCGR and SARS-CoV-2 Mpro are selected as shown in Figure S1. The structures of GCGR and SARS-CoV-2 Mpro are prepared for virtual screening by using MGLTools [66]. The Gasteiger charges and polar hydrogens are added on the GCGR and SARS-CoV-2 Mpro, which are saved as the PDBQT molecular format. The pockets for drug design are defined by the crystal ligands of the GCGR and SARS-CoV-2 Mpro, respectively.

## Section: Materials and methods › DL model and de novo drug design

The MolAICal contains the drug deep learning generative model that is trained from the 21,064 fragments of FDA-approved drugs. The 90 fragments generated by MolAICal and additional 30 basic fragments are mixed for fragment growth in the pocket of GCGR and SARS-CoV-2 Mpro by MolAICal. The x, y and z coordinates of the pocket box center of GCGR are set to −30.011, 1.665 and − 36.581 Å, respectively. The x, y and z coordinates of the pocket box center of SARS-CoV-2 Mpro are set to −10.733, 12.416 and 68.829 Å, respectively. The lengths of the pocket box of GCGR and SARS-CoV-2 Mpro are set to 30.0 Å along x, y and z direction.

The elitist molecules are extracted for next evolved growth from 10% of generated molecular populations. The top 140 molecules of generated molecular populations are generated as the parent molecules. To enhance the diversity and novelty of growth ligands, an additional 60 molecules are randomly selected from the generated molecular populations. The maximum population is set to 3000. The 361 Fibonacci points are generated for the perturbation search of fragments. The operators of crossover and mutation are set to 1.0 and 0.5, respectively. According to the Lipinski’s rule of five values of crystal ligands in the pocket of GCGR and SARS-CoV-2 Mpro, the values of XLOGP, hydrogen acceptors, hydrogen donors, molecular weight and rotatable bonds for GCGR and SARS-CoV-2 Mpro are set to 6.0, 12, 6, 1000.0, 14 and 6.0, 12, 7, 1000.0, 20, respectively. The Pan-assay interference compounds (PAINS) filtered out unwanted growth ligands. The synthetic accessibility scores of growth ligands are saved in the file of statistical results. A total of 30 cycle generations are performed for the whole process of drug design. A total of six parallel processes of drug design are performed on the GCGR and SARS-CoV-2 Mpro. The generated ligands of GCGR are stored between 480 and 690 of molecular weight, while the generated ligands of SARS-CoV-2 Mpro are saved between 480 and 785 of the molecular weight. A total of 30 multicores of CPU run parallel for a whole molecular growth process. The whole drug design process combined with deep learning model and classical programming is performed automatically by designed MolAICal soft package. A typical drug design process can be completed in ~19 hours on a computer with 30 of 2.20GHz CPU cores.

## Section: Materials and methods › DL model and drug virtual screening

The MolAICal contains the drug deep learning generative model that is trained from the 1,060,000 drug-like ligands. A total of 2 million drug-like ligands are generated for drug virtual screening of GCGR and SARS-CoV-2 Mpro. The x, y and z coordinates of the pocket box center of GCGR are set to −30.011, 1.665 and − 36.581 Å, respectively. The x, y and z coordinates of the pocket box center of SARS-CoV-2 Mpro are set to −10.86, 12.57 and 68.82 Å, respectively. The length, width and height of GCGR pocket box are set to 30.0, 30.0 and 30.0 Å, respectively. The length, width and height of SARS-CoV-2 Mpro pocket box are set to 25.0, 30.0 and 25.0 Å, respectively. The 2D SMILES format of generated ligands is converted to 3D PDBQT format with Merck Molecular Force Field 94 (MMFF94) by Open Babel [46]. The MolAICal invokes Autodock Vina to carry out virtual screening with 40 CPU cores automatically. The virtual screening results are ranked by the binding scores that save in the files of 2 million outputted ligands. The ligands are filtered out whose XLOGP is higher than 6. The XLOGP and virtual screening calculations are carried out automatically by MolAICal soft package.

## Section: Supplementary Material

Click here for additional data file.


---

# Natural product drug discovery in the artificial intelligence era

- **Authors:** F I Saldívar-González, V D Aldas-Bulos, J L Medina-Franco, F Plisson
- **Issuer:** Chemical science
- **Type:** Scientific article
- **Published:** 2021-12-13
- **Language:** en
- **DOI:** 10.1039/d1sc04471k
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35282622/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractNatural products (NPs) are primarily recognized as privileged structures to interact with protein drug targets. Their unique characteristics and structural diversity continue to marvel scientists for developing NP-inspired medicines, even though the pharmaceutical industry has largely given up. High-performance computer hardware, extensive storage, accessible software and affordable online education have democratized the use of artificial intelligence (AI) in many sectors and research areas. The last decades have introduced natural language processing and machine learning algorithms, two subfields of AI, to tackle NP drug discovery challenges and open up opportunities. In this article, we review and discuss the rational applications of AI approaches developed to assist in discovering bioactive NPs and capturing the molecular “patterns” of these privileged structures for combinatorial design or target selectivity.

## Section: Introduction

Artificial intelligence (AI) refers to the abilities demonstrated by computer machines (and human judgement) to ingest, process and recognise large and complex information patterns. AI has moved from theoretical studies to real-world applications, thanks to the revolution in high-performance computer hardware, extensive storage and accessible software. Machine learning (ML) is a subfield of AI, which englobes the ensemble of mathematical formulas and advanced statistics that humans apply through algorithms to treat such problems. ML algorithms can be executed at very large scales in the cloud at affordable costs and with ease. The digitization of data types (imaging, textual information, soundwaves, biometrics) from sensors or wearables into online public and proprietary databases have inundated the Internet, often referred to as “data deluge”.1 Those databases and scattered online information have been crucial for building practical predictive applications such as recommendation systems. Open-source toolkits, massive online courses, and educational videos on social media platforms have democratized the use of AI applications to many sectors, including finance, law, cybersecurity, transportation, manufacturing, entertainment, robotics, education, health, and services.2

Machine learning algorithms have steadily gained attraction within the pharmaceutical industry, we are seeing numerous supervised and unsupervised learning approaches being applied to the different stages of the drug discovery pipeline. For example, clustering methods have segmented cell type imaging, predicted protein target druggability, and supported de novo molecular design. Supervised learning techniques, i.e., regressions and classifications, identified possible targets for Huntington's disease. They speculated over the biological activities and absorption, distribution, metabolism, excretion, and toxicity (ADME/Tox) properties for drug design and many more applications.3 Lastly, generative algorithms are now supporting the molecular design of new chemical entities in medicinal chemistry.4–6 In 2019, the American company Insilico Medicine developed an AI system named GENTRL (for Generative Tensorial Reinforcement Learning) that successfully invented six kinase inhibitors of discoidin domain receptor 1 linked to lung fibrosis, in just 46 days.7

Natural products (NPs) are primarily recognized as privileged structures to interact with therapeutically relevant protein targets. Their structural diversity and biological activities still inspire the development of small molecules8 and macrocyclic drugs.9 NPs have dominated the sources of novel human therapeutics in the pharmaceutical drug pipeline in the mid-1970s. Two-thirds of the drugs originated from unaltered NPs (5%), NP analogues (28%), or contained NP pharmacophores (35%) between the 1980s and the 2010s.10 Despite being a proven source for modern small-molecule drug discovery, natural product research has declined at most major pharmaceutical companies. The main arguments are the time-consuming dereplication process, complex syntheses and high-throughput screening-unfriendly extracts.11,12 Moreover, many NPs present ADME and physicochemical properties, e.g., high degrees of stereochemistry, fused ring systems or rotatable bonds, that are beyond the current drug-like chemical space.13,14

The uniqueness of NPs continues to marvel laboratory and computer scientists alike. Not surprisingly, researchers have developed and adopted several computational methods throughout the drug pipeline; (1) to assist in the discovery and structural elucidation of bioactive NPs15,16 and (2) to capture the molecular patterns of these privileged structures for combinatorial design or target selectivity (Fig. 1).17–19 Over the years, chemoinformatic, bioinformatic, and other informatics-related disciplines have largely contributed to NP-based drug discovery. Their successful applications and limitations have recently been reviewed.20–23 Computational strategies involving artificial intelligence and machine learning algorithms have slowly made their ways into natural product research, a proven source of modern small molecule drug discovery. For example, in the early 2000s, AI applications mostly included the digitization of organic molecules, and dimensionality reduction techniques (i.e. principal component analysis, self-organizing maps) to map the NP chemical space. The following decade led to the development of ML binary classifiers to predict their biological functions. Recently, scientists have started to implement neural network architectures for genome mining, molecular design. Herein, this perspective article discusses the recent contributions of AI and ML algorithms to assist in the discovery of bioactive NPs and the design of NP-inspired drugs, and their future development.

## Section: Computer-assisted discovery of natural products › Data-mining into traditional medicines and peer-reviewed articles

Scientific compendium has long been documented into codices, dissertations, publications, patents, reports or laboratory notebooks. With an estimated 10 000 chemistry-related articles published every year, retrieving chemical information exceeds human readability, and many findings remain hidden. Machine-readable contents are critically needed. The recent transition from printed hard copies to digitized documents and restricted geographical locations to the World Wide Web has kick-started data-mining technologies. In the field of chemistry alone, many text-mining approaches monitor the 20 000 new compounds published in medicinal and biological chemistry journals every year.24 In 2020, Rajan and co-workers developed DECIMER, the ultimate Optical Chemical Entity Recognition software system using deep learning (DL) that recognized chemical structures from journal articles.25 Deep learning refers to a subfield of machine learning using neural network architectures with 3 or more layers. In the year prior, Tshitoyan and co-workers reported the discovery of “forgotten” thermoelectric materials from peer-reviewed articles published between 1922 and 2018. The authors first curated a corpus of 1.5 million abstracts from which they established semantic relationships using Word2vec, a technique for natural language processing (NLP). They built a ML model with word embeddings (vector representations of words) to predict the thermoelectric property for 1820 known and 7663 candidate materials.26 NLP is a branch of AI focused on understanding the interactions between computers and human languages. NLP methodologies extract, categorize, analyse words or sentences to get insights (e.g., knowledge graphs27) from unstructured documents. Beyond textual information in natural languages (i.e., English), NLP algorithms must process the many molecular representations associated with biomedical research, a domain referred to as BioNLP.28,29 To date, subfields of drug discovery; i.e., protein docking,30,31 protein–protein interactions32,33 or protein-disease associations34 have too benefitted from applying biomedical text mining. In contrast, NLP has shown limited applications to the discovery of bioactive NPs.

So far, BioNLP methodologies have predominantly deciphered ancient texts from disappearing traditional medicines to identify bioactive plants. Traditional medicine has stimulated the search for bioactive NPs from various sources and novel drugs throughout history. Early evidence referred to plants' medicinal use on clay tablets written in cuneiforms.35 Traditional Chinese medicine (TCM) has gained attention worldwide due to its role in discovering treatments for malaria36 and rheumatoid arthritis.37 In 2014, May and co-workers developed an algorithm that could screen, extract, select, classify and score information from ancient texts.38 Equipped with that technology, the authors monitored changes in the terminology used for specific diseases over time. They identified common treatments, and they eased the discovery of NPs in both Zhong Hua Yi Dian (ZHYD; Encyclopaedia of Traditional Chinese Medicine), the most comprehensive encyclopedia of TCM books, and Zhong Yi Fang Ji Da Ci Dian (Great Compendium of Chinese Medical Formulae), the largest compendium of herbal formulas.38 In 2015, Shergis and co-workers conducted a text-mining search within TCM codices, searching natural products as potential treatments for chronic cough, a by-product of cancer, obstructive pulmonary disease, tuberculosis, and asthma.39 Employing the keywords jiǔ hāi, jiǔ sòu, and jiǔ késòu for chronic/prolonged cough and keeping their terminological authenticity, the authors identified 331 compounds in the ZHYD including; 250 from herbal sources, 47 from animals and 34 from minerals.

Despite their originality, these semantic approaches carry many flaws and remain rudimentary. One of the main drawbacks in mining ancient texts is the changing paradigm and concept of medicine over the centuries. For example, the diagnosis and treatment systems in TCM originated from ancient philosophies such as the Qi theory (or the yin-yang theory) and the five elements theory. TCM practitioners call a syndrome a set of patient symptoms that may result from different diseases and be caused by different mechanisms, hampering the identification of treatments.40 Like traditional medicine, ethnobotanical explorations have contributed to discovering countless NPs.41 In 2014, Sharma and co-workers explored the Palau and Pohnpei Primary Health Care Manuals, traditional botanical accounts from Micronesian islands, aiming to pinpoint medicinal plants and their therapeutic usages.35 The authors first digitized the manuals with the Biodiversity Heritage Library to establish individual plants and therapeutic annotations. The extracted information was crossed with contemporary biomedical terminology using MetaMap42 (https://metamap.nlm.nih.gov/). This BioNLP tool employs computational linguistic techniques to identify equivalent terms in the Unified Medical Language System. The team discovered 129 unique plant species and over 700 treatment indications from the Primary Health Care Manuals. Biodiversity Heritage Library commonly reported 72 plant species; ten displayed comparative symptoms (i.e. diarrhea, pain, rash) resulting from venomous stings or pathogen infections.

## Section: Computer-assisted discovery of natural products › Predicting chemical structures from microbial genomes

Rapid fractionations, hyphenated chromatography techniques, and bioassay screenings of natural sources such as plants, marine invertebrates or microbes have traditionally guided the discovery of bioactive NPs.43 The recent advances in genome sequencing have revealed the biosynthetic logic and genetic basis behind NPs of microbial origin and beyond.12,44,45 Enzymatic complexes such as polyketide synthases (PKSs)46 and nonribosomal peptide synthetases (NRPSs),47 or the ribosomally synthesized and post-translationally modified peptides (RiPPs)48 are behind the production of these secondary/specialized metabolites. Microbial genomes encode these multi-domain pieces of machinery as biosynthetic gene clusters (BGCs). Over the last decades, considerable efforts in bioinformatics, commonly referred to as the umbrella term “Genome mining”, recently reviewed,49–52 have enabled the discovery of cryptic BGCs within microbial genomes and the experimental characterization of novel NPs. ML algorithms and pattern-recognition approaches have partaken the genome-mining tools into two areas; (1) scrutinizing novel BGCs and (2) predicting chemical structures.

Biosynthetic gene clusters are traditionally discovered through a rule-based selection process, except for novel RiPPs. These peptides are typically identified from a limited set of known RiPP tailoring enzymes and precursor peptides (PPs). In 2017, Tietz and co-workers developed a multi-layer predictor enabling the discovery of lasso peptides.53 The same year, Mohanty's group created RiPPMiner, a multi-label Support Vector Machine (SVM) classifier that distinguishes between a dozen PP classes.54 Both approaches limited their training to specific RiPP classes. In 2019, de los Santos complemented the ML-guided discovery of novel RiPPs with NeuRiPP; the neural network architectures could identify known PPs and new PP-like sequences.55 The following year, three additional methods pitched the automated discovery of new ribosomal peptides. First, Merwin and co-workers created DeepRiPP, the tripartite pipeline employed natural language processing to capture a wider diversity of RiPPs independently from genomic context (NLPPrecursor). Their other components included Basic Alignment of Ribosomal Encoded Products Locally (BARLEY) and Computational Library for Analysis of Mass Spectra (CLAMS) that indexed biosynthetic loci to candidate RiPPs within a database of thousands of microbial extracts from genomic and metabolomic information.56 The authors applied DeepRiPP to analyze 65,421 sequenced bacterial genomes and identify 19,498 unique unknown RiPPs. Later, Kloosterman and co-workers reported two new bioinformatics tools to support the discovery of novel RiPPs; DecRiPPter (Data-driven Exploratory Class-independent RiPP TrackER)57 and RRE-finder (RRE stands for RiPP recognition element).58 The former applied an SVM with a custom database of RiPP-specific BGCs and PPs to prioritize genomic regions. The latter focused on finding RREs, BGC elements that participate in the RiPP biosynthesis encoding for discrete proteins or fused protein domains. Unlike DecRiPPter, RRE-finder capitalized on sequence similarity and protein homology; the tool either detected known RiPP classes using 35 custom profile Hidden Markov Models (pHMMs) (precision mode) or predicted novel RiPP classes with a modified version of the HHpred pipeline59 (exploratory mode). Both tools confidently identified novel RiPPs; thus, DecRiPPter discovered 42 new RiPP families, including the novel subclass V of lanthipeptides from 1295 Streptomyces genomes.

Finding novel chemical entities early on is critical to the drug discovery process. It could alleviate the costs and the experimental time associated with the dereplication of natural crude extracts (NCEs). Chemical novelty is also inherent to the intellectual property (i.e., patents) of pharmaceutical and biotechnology companies competing to develop new drugs in similar target/disease landscapes.60,61 In 2019, Hannigan and co-workers created DeepBGC, the deep learning framework utilized recurrent neural networks (RNN) to identify novel BGC classes followed by random forest (RF) classifiers to predict their biological activities (i.e., antibacterial, cytotoxic, inhibitor or antifungal). DeepBGC identified adequately many NP classes from predicted BGCs but the algorithm predicted poorly their biological activities, due to the lack of training examples.62 The following year, Skinnider and co-workers63 presented the fourth version of PRISM (stands for PRediction Informatics for Secondary Metabolomes, available at http://prism.adapsyn.com) that could predict the chemical structures for 16 classes of NPs from bacterial BGCs, including aminoglycosides, nucleosides, β-lactams, alkaloids, and lincosamides. PRISM4 employed 1772 HMMs and 618 tailoring reactions, reaching a high degree of chemical similarity between predicted structures and the authentic products of known BGCs. With cryptic BGCs, the tool predicted structural features of known NPs. The authors further set a library of 1281 BGCs and trained moderate SVM classifiers to predict the probability for a BGC to display one or more biological activities (i.e., antibacterial, antifungal, antiviral, antitumor, or immunomodulatory activity). The same year, Agrawal and Mohanty developed two RF classifiers that predicted macrocyclization patterns for PKs and NRPs.64 The first model predicted the capacity of a linear precursor to (or not to) adopt a macrocyclic structure, based on a training dataset made of 196 empirically known macrocyclic PK/NRP compounds and 162 linear chemical entities. The second classifier identified the accurate macrocyclic structure of a PK/NRP compound given its linear precursor, using the 196 macrocyclic compounds previously mentioned and all its theoretically possible macrocyclic structures. Finally, in 2021, Walker and Clardy revisited ML classifiers to predict the antibacterial or antifungal activity based on BGC-derived features. Alongside the development of moderate classifiers (i.e., 57–79% accuracy), which outperformed DeepBGC, the authors uncovered activity-associated BGC domains.65

Besides finding novel chemical entities, microbes have flourished as biofactories for the development of exogenous metabolites, peptides and proteins through recombinant DNA technology.66 As the connections between microbial BGCs and NPs grow, we can foresee that the future steps in metabolite engineering would involve hacking directly the genetic information of biosynthetic powerhouses like streptomyces67 to develop novel and complex NPs, hardly synthesizable and in more sustainable manner.

## Section: Computer-assisted discovery of natural products › Automating natural product dereplication process

Early-stage discovery of NPs from organisms of all kingdoms is characterized by the repetitive extractions, subsequent chromatography/spectrometry-guided fractionations and purifications leading to single metabolites (or mixtures thereof) – the process is known as dereplication. One or more biological assays often guide the process to screen and prioritize the extracts, fractions and isolates containing the bioactive substances. Dereplication is lengthy, tedious and might face problems that would hinder the expected return on investments (time, equipment, human resources), such as discovering already known NPs, purifying supposedly novel structures in insufficient amounts, or screening natural crude extracts (NCEs) with high-throughput robotics.11,12,43 Scientists have strategized different approaches to reduce redundant NCEs with the early chemical profiling of (un-)targeted NPs.68,69 They have notably prioritized NCEs using state-of-the-art analytical chemistry techniques, i.e., gas/liquid chromatography (GC/LC), nuclear magnetic resonance (NMR) spectroscopy, mass spectrometry (MS), and combinations thereof.

The increasing data digitization has enabled the implementation of mathematical and statistical methods. The field of chemometrics has leveraged the multivariate statistical analysis of data from the aforementioned studies and from the optical radiation (i.e., infrared, visible and ultraviolet) for the rapid identification of known and unknown bioactive NPs from NCEs. In 2019, Cornejo-Baez and co-workers documented the most common statistical techniques used to study NPs.70 The list included both unsupervised (i.e., hierarchical cluster analysis, principal component analysis and discriminant analysis) and supervised ML algorithms (i.e., partial least squares, orthogonal projection to latent structures). Beyond NCEs, scientists have capitalized on ML algorithms to extract information from metabolomic data and generate new biological insights. In particular, supervised ML algorithms such as random forest, support vector machine (SVM), artificial neural network, and genetic algorithms have shown great potential in metabolomics research due to the ability to provide quantitative predictions.71 The implementation of these algorithms has facilitated analytical data processing, integrated omics data, and stimulated biological applications. For example, ML algorithms are used to integrate chromatogram peaks,72 predict retention time,73–75 or amputate missing data.76

With the growing volume of MS data, several metabolomics platforms arose such as the software MetaboAnalyst 5.0 (https://www.metaboanalyst.ca/).77 In 2016, Wang and co-workers presented the Global Natural Products Social Molecular Networking (GNPS, http://gnps.ucsd.edu).78 The platform organizes vast tandem MS datasets into visual molecular networks. Molecular networking (MN) uses nodes to display the high-resolution spectra, and edges to characterize the spectrum-to-spectrum alignments. The initiative is gaining attraction in NP dereplication79 as well as other applications related to the study of NPs.80 Overlapping or neighbouring nodes are synonymous with NCE replicates or NCEs with shared fragmentation ions. However, in absence of reference spectra in molecular databases, tandem MS datasets cannot be aligned and molecules cannot be identified. Alternatively, scientists have developed tools such as CSI:FingerID,81 MS2LDA82 and SIRIUS 4 (ref. 83) for small molecules, and VarQuest84 for peptides, that coupled tandem MS spectra to specialised molecular databases in order to identify NP substructures. Of the aforementioned bioinformatic tools, three utilised ML algorithms to match fragmentation ions with molecular substructures. First, CSI:FingerID81 (www.csi-fingerid.org) computed fragmentation trees from MS spectra and applied ML algorithms (multiple kernel learning, SVM) to predict the presence or absence of 1415 molecular fingerprints in unknown compounds. Each molecular fingerprint is scored and ranked using Platt probabilities. In result, CSI:FingerID matched NPs and NP substructures from a molecular structure database such as PubChem to the submitted spectra or fragmentation trees from either Agilent (N = 2055) or GNPS (N = 3868). The platform SIRIUS 4 derived from CSI:FingerID.83 The discovery platform MS2LDA82 (http://ms2lda.org/) implemented latent Dirichlet allocation (“-LDA”), an unsupervised method, originally used for text mining, to decompose tandem MS data (“MS2-”) into sets of co-occurring fragments or neutral losses (called Mass2Motifs). Those motifs were matched to a set of biochemical features (i.e., amino acids, nucleotides, conjugated acids, polyamines, carbohydrates) to deduce molecular ((sub)structures).

Tandem MS data alone remain insufficient to fully elucidate chemical structures, the last half-century has seen the elaboration of computer-assisted structural elucidation (CASE) expert systems. Two recent reviews provide a comprehensive and historical overview of these systems.85,86 CASE expert systems support the identification of an unknown chemical compound by matching its similar spectral properties to a list of potential candidates. Such systems were primarily based on one-dimensional (1D) and two-dimensional (2D) NMR spectra to elucidate the structures of NPs and organic compounds. In 2020, Reher and co-workers87 reported the first ML-driven tool called ‘Small Molecule Accurate Recognition Technology’ or SMART 2.0, for the rapid characterization of NPs from NMR spectra of NCEs. At the core of SMART 2.0, the team trained a convolutional neural network on a set of 53 076 2D-NMR spectra (i.e., HSQC – Heteronuclear Single Quantum Coherence spectroscopy) from NPs of the JEOL database and ACD Labs Predictor reduced to a 180-dimensional embedding space. The authors validated their application by discovering and fully characterizing a novel cytotoxic swinholide NP named symplocolide A from the NMR-based SMART mixture analysis of the filamentous marine cyanobacterium Symploca sp. Besides NMR experiments, several non-spectroscopic techniques, i.e., atomic force microscopy,88 “crystalline sponge” X-ray analysis,89 and micro-electron diffraction90 are starting to provide structural insights in combination with CASE expert systems.

## Section: Machine learning applied to natural products › Encoding natural products into molecular representations

Modelling and predicting the properties and bioactivities of NPs (or any chemical structure per se) primarily pass through their translation into computer-readable format(s), the so-called molecular representations (Fig. 2). Most representations encode chemical information for a specific use. Original generic and IUPAC names retrieve chemical compounds that share nomenclatures. Matching chemical structures based on their bidimensional molecular graph depictions was computationally demanding. Early molecular representations were designed for light-weight storage space of chemical information or efficient structural search. The simplified input line entry system (SMILES),91 SMILES arbitrary target specification (SMARTS, Daylight CIS and OpenEye Scientific Software) and international chemical identifier (InChI)92 were created to store and retrieve molecular information as well as identifying shared molecular features or substructures from databases. Novel molecular representations like DeepSMILES93 and SELFIES94 recently arose for their practical use in ML algorithms.

Chemical and biomolecular databases are central to many AI applications and they are commonly found across informatic-related disciplines.95 Chemical databases96 played an important role to improve the dereplication process of NPs using preassembled NP libraries and chemical fingerprinting (spectroscopic/chromatographic data, calculated physical properties). In the mid-1990s, public and private research entities have initiated several commercial databases from curated literature review including the generalist Chemical Abstracts Service by the American Chemical Society or the highly specialised MarinLit by the University of Canterbury, New Zealand, and now under the British Royal Society of Chemistry. However, the elevated costs and limited access to commercial databases have pushed numerous academic researchers to consider free and open-access options like ChemSpider. Few years ago, the number of NP databases in the public domain was very limited. But the renewed interest in NP research plus rapid advances in informatics and data sharing boosted the generation, and publication of NP collections in the public domain. In 2020, Soronika and Steinbeck reviewed 123 open-access and commercial databases, industrial catalogues, books and collections for NP information, that were still cited in the scientific literature after 2000.97 Many NP databases, commercial and open-access alike, are sporadically maintained by their creators. Less than half of these databases offered substructure searching using at least one of the aforementioned molecular representations, and many lacked stereochemical information. In result, the authors built the largest collection of open-access natural products named COCONUT (https://coconut.naturalproducts.net/) that compiled the structures and related information of over 400 000 non-redundant NPs. The same research group has continued developing and curating COCONUT and has released an improved version called LOTUS.98

The need for efficient substructure searching in growing chemical databases and reduced storage space have also led to the development of molecular fingerprints. Initial bitstring fingerprints denoted the presence (1) or the absence (0) of substructures as binary vectors.99,100 Subsequent topological fingerprints based on atom pairs,101 local circular neighborhoods and Extended Connectivity fingerprints (ECFP),102 Molecular ACCess System (MACCS) keys,103 to name a few, were specifically designed for bioactivity prediction and similarity analysis. Bidimensional fingerprints were implemented to compare the molecular similarity of NPs against synthetic chemical libraries. The similarity of any two molecules is measured using one of many distance metrics such as the Tanimoto coefficient.104–106 In their 1999 seminal paper, Henzel and co-workers107 converted 78 318 entries from the Database of Natural Products, 29 432 entries from the Bioactive Natural Product Database, 182 822 chemical compounds from the Available Chemicals Directory, 14 596 drugs and some synthetic compounds from Bayer AG into MACCS- and UNITY-format. NPs presented larger molecular weights and distinct heteroatom distributions, and over 40% of NP-derived pharmacophores were not represented in the synthetic libraries. In the two decades that followed, pharmaceutical companies and academic institutions have integrated bioactive NP scaffolds to their combinatorial drug design strategies, and they have created diversity-oriented synthesis (DOS), diverted total synthesis (DTS), biology-oriented synthesis (BIOS) and function-oriented synthesis (FOS) of NP-like libraries, as summarized by the many reviews.108–115 In parallel, computational scientists have used the aforementioned fingerprints indifferently between NPs and synthetic molecules to conduct successive structural similarity analyses,107,116–121 novel visual representations of the chemical space (see Mapping NPs in chemical space),121–132 and they generated new metrics, i.e., NP-likeness score or metabolite-likeness score (see Engineering likeness scores),133–141 to monitor the success of that endeavour. In 2020, Seo and co-workers developed NC-MFP as the first natural product molecular fingerprint for NP drug discovery.142 The same year, Capecchi and co-workers created the MinHashed atom-pair fingerprint reaching up to 4 bonds (or MAP4 for short), suitable for both drugs, NPs as well as macromolecules.143 Molecular representations have depicted small and large organic molecules indifferently, natural products and synthetic compounds, with the latest MAP4. The goal is to embrace a universal fingerprint to describe and search chemical space. In contrast, we also see emerging novel fingerprints like NC-MFP that promote the singularity of chemical entities, to possibly classify structures or predict biological activity. Both fingerprints will likely co-exist for specific domain applications.

In the early 2000s, researchers also created 3D fingerprints based on geometric distances144,145 and methods such as the rapid overlay of chemical structures (ROCS)146 to leverage spatial information and shape similarity. Tridimensional fingerprints have predominantly been used to match ligands from virtual screening experiments, based on shape similarity.147,148 Shape-matching has notably been used in scaffold-hopping, a process focused on discovering novel compounds by changing the core of known parent bioactive structures (see Generating de novo NP-inspired compounds).149–151 In 2013, Riniker and Landrum benchmarked several fingerprints for ligand-based virtual screening, where the authors concluded that simpler topological (bidimensional) fingerprints could retrieve structural information, making scaffold-hopping potentially obsolete.152 With respect to bioactive NPs, in 2017, Skinnider and co-workers presented an algorithm named LEMONS for the enumeration of hypothetical modular NPs. The authors leveraged their algorithm to compare different molecular similarity methods with the NP chemical space. Their results suggested that circular fingerprints with a retrosynthetic approach (GRAPE/GARLIC) would outperform the more conventional topological and structural fingerprints.153 In 2020, Chen and co-workers applied ROCS to interrogate the potential macromolecular targets of NPs, a process coined de-orphanizing (see De-orphanizing). They successfully identified the targets for many small molecules, but they struggled to find those of NPs and macrocyclic ligands.154 The overall advantages of 2D over 3D fingerprints remain to be demonstrated.155 However, it is generally accepted that these advantages depend on the application (goal of the study) and the specific types of fingerprints to be compared. More recently, 3D fingerprints have been reported to predict and rank the biological activities from chemical structures, the so-called Quantitative Structure–Activity/Property Relationship (QSA/PR) models.156

## Section: Machine learning applied to natural products › Vectorizing natural products with molecular descriptors

Besides fingerprints (frequently used by chemoinformaticians), computational chemists would use molecular representations to compute thousands of features (variables) known as molecular descriptors157 through well-defined algorithms. These descriptors grasp specific molecular features (e.g., atomic properties, size, shape, flexibility, polarity, lipophilicity, pharmacophore) that researchers could easily interpret. Molecular descriptors have been central to the development of predictive QSA/PR modelling. They have been essential to describe the distributions of NPs and synthetic compounds in low-dimensional representations of chemical space(s). At the turn of the 21st century, Lipinski and co-workers devised a set of empirical rules or guidelines, known as rule-of-five (Ro5), based on key molecular descriptors to rapidly identify orally available small molecules from screening campaigns and combinatorial libraries.158 Together with their structural similarity analyses, several computational studies used molecular descriptors to compare and describe the chemical spaces occupied by NPs, combinatorial chemical libraries, synthetic compounds and marketed drugs.121–123,125–132 Natural products and macrocycles,9 which were not initially considered to establish the Ro5 rules, have been found to violate one or more of these rules and yet, they exhibited oral bioavailability. In 2008, Quinn and co-workers attempted to establish a set of rules for NPs only.159 Several research groups puzzled have followed suit establishing a new set of empirical rules based on molecular descriptors, known as ‘beyond the Ro5’ (bRo5) to explain cell permeability and oral bioavailability of macrocycles.160–168

In a recent chapter, Grisoni and co-workers reviewed the impact of molecular descriptors upon chemoinformatic applications.169 The authors primarily introduced molecular representations beyond 3D leading to new features such as conformational flexibility, protonation states or orientations. Once the irrelevant features are removed (missing values, low variance threshold, multicollinearity) and the remaining descriptors are scaled, they are employed for similarity search or QSA/PR modelling. In the former application, the authors warned upon choosing the correct molecular descriptors, and the distance metrics to quantify (dis-)similarity between chemical entities. They advised that optimal molecular descriptors and distance measures could be selected following their quantification through the enrichment factor.170 In the latter application, identifying the best molecular descriptors to predict the biological activity/property of interest relies mainly on the stability, performance and interpretability of the algorithm in use as well as the metrics (e.g., accuracy, root mean squared error) for model evaluation.

Over the past decade, deep learning (DL) algorithms have been widely adopted in domains such as computer vision171 and natural language processing.172 Recently, DL models emerged for their applications to drug discovery and molecular informatics.173–176 At their cores, neural networks handle large datasets and capture the complex relationships between input features (e.g., 2D/3D fingerprints, molecular descriptors) and output decisions (e.g., biological activity, ADME/Tox). Despite their remarkable improvements over traditional ML algorithms, DL models are mostly built from a chosen set of features (i.e., molecular representations) rather than learning from “raw” chemical information. Existing convolutional neural networks (CNNs), used for image classification, are ill-suited for reading 2D graph depictions or 3D structures. Chemical entities such as NPs, synthetic small molecules or drugs could be depicted as molecular graphs of irregular sizes and shapes. Moreover, CNNs conventionally scan images in a specific order; the DL architectures must correctly read the atoms (i.e., nodes/vertices) and chemical bonds (i.e., edges) that molecular graphs are made of. Recent efforts have been achieved with the development of graph convolutional networks (GCNs), setting the state-of-the-art techniques to read the irregular and raw information coming from molecular graphs. So far, Sun and co-workers have reviewed their applications to four domains of the drug discovery pipeline; QSA/PR modelling, drug-target/drug–drug interaction, synthesis planning, and de novo molecular design.177 Several studies were reported to use large and general chemical datasets such as NCI dataset from the National Cancer Institute (https://cactus.nci.nih.gov/download/nci/), three datasets from European Molecular Biology Laboratory (https://www.ebi.ac.uk – SIDER, STITCH, ChEMBL) or the University of California San Diego's BindingDB (https://www.bindingdb.org/bind/index.jsp) to develop GCNs with domain-specific applications. Close to NPs, Sanchez-Lengeling and co-workers reported the odor profiles (138 labels) for some 5030 molecules from GoodScents perfume materials and Leffingwell 2001 PMP databases in 2019.178 On average, each molecule presented 1–15 odor labels. The authors could predict using GCNs all 138 descriptors for all molecules at once due to the observed strong correlations between structures and odor labels. GCNs remain to be explicitly applied to NP databases like COCONUT or LOTUS (vide supra).

## Section: Machine learning applied to natural products › Mapping natural products in chemical space

The chemical space is the geometric space defined by all the possible chemical compounds, their structural and functional properties. An NP chemical space refers to the space occupied by a set of known NPs. Visualizing this high-dimensional space through human-readable graphical representations (of one to three dimensions) has been critical to decision-making and advances in the drug discovery process.179,180 One of the most common ways to generate visual representations of the chemical space is using coordinate-based representations that often require reducing the number of dimensions. Transforming high-dimensional data into a smaller set of dimensions to better understand and interpret results is known as dimensionality reduction, a technique familiar to many AI projects.181 Over the last two decades, numerous research groups have implemented different dimensionality-reduction techniques to explore NP chemical space, extensively reviewed elsewhere.128,182–184 Besides mapping chemical spaces, dimensionality-reduction techniques expose structure–activity/property relationships (SA/PRs) between compounds and compound datasets. The increasing amount of data stored in chemical datasets makes the visualization of SA/PRs a challenging endeavour.185 Finally, dimensionality-reduction techniques help define the applicability domain of QSA/PR modelling, a specific region in the underlying chemical space where the model predictions are considered reliable. In that application, dimensionality-reduction techniques identify outliers and generate robust models. Overall, three techniques are commonly employed to either map the chemical space, define its limitations or exhibit SARs/SPRs; principal component analysis (PCA), t-distributed stochastic neighbour embedding (t-SNE), and self-organizing map (SOM).

Early accounts to support the analysis, navigation and comparison of chemical space(s) include the works by Schneider and co-workers introducing SOMs to NPs and drugs with scaffold architecture and pharmacophores.120,122 In 2003, Feher and Schmidt117 compared the property distributions of drugs, NPs, combinatorial libraries using PCA. Larsson and co-workers developed ChemGPS-NP,124 a PCA-like representation to compare NP libraries like WOMBAT121 with their biological activities. Waldmann and co-workers have charted the NP chemical space with SCONP,123 and ScaffoldHunter.126 Both tools explore the relationships between the more and more complex scaffolds and their biological activities through the intuitive hierarchical organization of scaffold libraries arranged in tree-like maps.125,127,129,130,132 These tree-like arrangements led the authors of this review to develop the ChemMaps.186 In 2020, Reymond's group embedded chemical spaces with very large dimensions into two-dimensional trees named TMAPs187 along with their recently reported fingerprint MAP4 (ref. 143) to analyze the similarity between 25 523 NPs of bacterial or fungal origin.188 Sánchez-Cruz and co-workers also implemented TMAPs to display NP databases, synthetic compound collections, as well as NP-based fragment libraries.189 The same year, Chávez-Hernández and co-workers applied TMAPs to compare the chemical spaces of 382 248 NPs from the database COCONUT (vide supra), molecules from the ‘dark chemical matter’, and other datasets.190 Similarly, the authors compared 52 630 molecular fragments generated from COCONUTs NPs with 14 001 fragments from dark chemical matter. They concluded that the NPs (complete compounds and fragments) largely delineated the chemical space.191 Of note, fragment libraries of NPs can be very useful for the rational fragment-based design of the so-called “pseudo-NPs”.192 With regards to graphically evaluating the predictive reliability of QSA/PR models, Majumdar and Basak used robust PCA to define a reliable predictive space of 508 chemical mutagens in 2016.193 The same year, Aniceto and co-workers introduced reliability-density neighbourhoods.194 Last year, Plisson and co-workers combined unsupervised multivariate outlier detection methods with a t-SNE manifold to delineate the limitations of their hemolytic QSA/PR models. The authors applied their methods to discover novel (non-)hemolytic antimicrobial peptides of natural origin.195

## Section: Machine learning applied to natural products › Engineering likeness scores

Natural products adopt numerous shapes and ring systems. They contain several oxygens but fewer nitrogen, sulfur, and halogen atoms than synthetic counterparts. Their structural complexity includes a high fraction of carbon sp3 atoms, stereogenic centres, and multiple hydrogen-bonding functional groups (donors and acceptors).107,116,117,122,196–198 Small NPs are intrinsically rigid198 whereas large NPs (more than 500 Daltons), in particular macrocycles,9 present a higher degree of flexibility, which confer to both sized molecules optimal affinity and specificity to bind to proteins and protein–protein interactions. This optimization process has been strongly attributed to the coevolution or complementary chemical design between NPs and specific protein targets to benefit the producer's survival fitness.199,200 Consequently, NPs and their derived physicochemical properties are regarded as privileged features supporting their total syntheses and the design of bioactive compound libraries.

Computational studies have contributed to the design of focused compound libraries by creating new scoring measures to quantify how similar a compound is to the chemical space. In machine learning, generating novel relevant feature(s) is referred to as feature engineering. In 2008, Ertl and co-workers developed a Bayesian measure named NP-likeness score that quantified the similarity of a compound according to the characteristic structural fragments in NPs.133 The authors compared NPs, synthetic molecules (SMs) and drugs from DrugBank based on the unidimensional distributions of their NP-likeness scores. They could also identify common building blocks to both NPs and drugs. Three years later, Jayaseelan, Ertl and co-workers implemented an open-source, open-data version of the scoring system.201 And in 2019, Soronika and Steinbeck created the NaPLeS web application (http://naples.naturalproducts.net) that computes the NP-likeness score for chemical libraries.202 Alongside Ertl's original NP-likeness score, Yu reported an alternative approach to quantify NP-likeness, based on Extended Connectivity Fingerprints (ECFP).203 Recently, Chen and co-workers developed and validated new ML models for the discrimination of NPs and SMs for the quantification of NP-likeness.204 NP-scout is the web application derived from this work that computes the probability of a molecule to be a NP based on its physicochemical properties, Morgan2 fingerprints, and MACCS keys. In addition, NP-scout allows visualizing atoms in molecules that make decisive contributions to the assignment of compounds to any class by integrating similarity maps.

Similarly to the NP-likeness score, ML applications have contributed to rationalization of alternative scoring systems to narrow large chemical compound libraries with metabolite-likeness,135,137,138,141,205,206 lead-likeness,207,208 or drug-likeness209,210 profiles. Such concepts in more sophisticated abstract terms have allowed the elaboration of models that could be applied for the identification of drug-like NPs beyond the application of empirical rules. Recently, Marshall and co-workers introduced the first intrinsic measure of molecular complexity, called the molecular assembly index (MA).211 The team developed the MA index to easily track complex molecules in abundance using mass spectrometry, and to support the existence of living producers within our cryptic terrestrial ecosystems or beyond alien exoplanets. To illustrate an application of the molecular complexity index, the authors retrieved 2.5 million small molecules (less than 600 Daltons) from Reaxys® database (https://www.elsevier.com/solutions/reaxys), and compared the MA distribution (1–25) between four libraries; NPs, industrial compounds, metabolites, and pharmaceuticals. Their results showed that the MA index is mostly constrained by mass, and all libraries exhibited a wide range of values. Moreover, the index estimated well the fragmentation complexity in MS/MS spectra from different biological samples. Beyond its application to identify life in outer space, one might divert the original purpose of the molecular complexity index as a fitness function to optimize the design of NP-inspired drugs.

## Section: Machine learning applied to natural products › Predicting biological functions

Bioactive NPs are present in small amounts in natural crude extracts (NCEs, μg to few mg), sometimes they are insufficient to conduct biological evaluations in multiple and successive phenotypic or target-based assays. Traditional bioassay-guided fractionation looks at a handful of biological responses at times, the fractions that do not respond to the assay(s) are considered inactive, the NPs within are left out, and their biological profile(s) remain unresolved. Atanasov and co-workers recently discussed the roles of genome mining, metabolite engineering and cultivation systems to tackle that recurrent issue.12 On the ground, research laboratories stock their purified NPs and NCEs in freezers (diluted at different concentrations or lyophilized) to maximize their future screening campaigns. Some countries have created national chemical repositories, such as France's Chimiothèque Nationale (https://chembiofrance.cn.cnrs.fr) and Compound Australia (https://www.griffith.edu.au/griffith-sciences/compounds-australia), to facilitate the interactions between chemical and biological laboratories. In silico, structure-based approaches (i.e., docking and virtual screening) and ligand-based approaches (i.e., QSA/PR modelling) predict the biological or ADME/Tox profiles of untapped chemical structures. Quantitative Structure–Activity/Property Relationship (QSA/PR) models use ML algorithms, mainly regressors and classifiers, to link the biological activity or physicochemical property of interest with changes in chemical moieties. In the past half-century, QSA/PR modelling has risen from a niche area of computational/theoretical chemistry to one of the major strategies to monitor large chemical libraries with applications in drug design, quantum mechanics, materials, and nanomaterials science, regenerative medicine and environmental toxicity.212

The application of ML algorithms to predict the biological activities of NPs is new; most models were developed in the last 5–10 years.213,214 Binary classification models predominate the list of ML algorithms for NP biological activity prediction (as active or inactive). Early classifiers include the development of a linear discriminant analysis (LDA) model using topological descriptors for the search of new anti-inflammatory NPs from MicroSource,215–217 and two RF classifiers using CDK descriptors218 to discover antimicrobial and anticancer agents among 1194 marine and microbial NPs from AntiMarin database.219,220 In 2016, Dai and co-workers predicted the anticancer properties for 5278 out of 21 334 plant-derived NPs from TCM.221 The authors used their in-house web server CDRUG222 based on a method coined relative-frequency weighted fingerprints (RFW_FP) and a hybrid score to compare molecular similarity. Between 2017 and 2020, Rayan and co-workers introduced the iterative stochastic elimination (ISE) optimization for the discovery of bioactive NPs; they reported NPs for anticancer,223 antidiabetic,224 anti-inflammatory,225 antibacterial,226 and antifungal227 activities. In all examples mentioned above, the authors constructed binary classifiers using sets of approved drugs with the biological activity of interest as the active class, and 2892 NPs as the inactive class. The ISE algorithm scores iteratively the variables (i.e., physicochemical descriptors) and combinations thereof with the biological activity. The common NPs were not inactive per se; rather, their biological activity was either ignored or unknown. Rayan and co-workers assumed these false negatives in the training set might have a minor effect.223 Noteworthy, the authors did not consider the clear physicochemical differences between NPs and drugs as detrimental factors for their good model performances. In 2018, Egieyeh and co-workers trained several binary classifiers from a dataset of NPs with in vitro antimalarial activity and applied their best models (RF and Sequential Minimization Optimization (SMO) with 82.8% and 85.9% accuracy, respectively) against 450 NPs from InterBioScreen chemical library.228 The same year, Onguéné and co-workers profiled in silico toxicity of 806 African plant-derived NPs from three databases curated for their antimalarial and anti-HIV properties (p-ANAPL, AfroMalariaDb, and Afro-HIV).229 The team implemented the knowledge-based predictive software Derek230 and the Cambridge University small-molecule pharmacokinetics prediction (pkCSM) web server.231 The former detected toxic sub-structures in small molecules, and the latter assessed the ADME/Tox profiles from graph-based structural signatures. The pkCSM predictions used RF and Logistic Regression algorithms for classification tasks, GP and Model Tree for regression tasks.231 The following year, Dias and co-workers illustrated the emergence of computational multi-target drug design232 with the development of two QSA/PR models to discover novel antibiotics against methicillin-resistant Staphylococcus aureus (MRSA).233 The first model was a modest regression model trained from 6645 anti-MRSA compounds with molecular descriptors to predict the negative decimal logarithm of minimum inhibitory concentration (pMIC) value against MRSA.

The second model predicted the antibacterial activity using the 1D-NMR data (1H and 13C) from marine samples (crude extracts, fractions and pure compounds) with 77% accuracy. In 2020, Yoo and co-workers developed the first DL-driven multi-classification algorithm to identify the medicinal uses of NPs for 15 diseases.234 The authors trained their model from a heterogeneous dataset of 4507 NPs and 2882 drugs, and 686 variables derived from PubMed text mining, molecular interactions features and physicochemical descriptors. The algorithm predicted 31 NPs and their possible uses in 15 phenotypes, including neurological disorders (Alzheimer's disease, Parkinson's disease, pain, stroke), heart problems (failure, myocardial infarction), infectious diseases (bacterial, urinary tract, skin), and autoimmune diseases (rheumatoid arthritis). Finally, in 2021, Liu and co-workers reported a DL algorithm called pretrained self-attentive message passing neural network (P-SAMPNN) to discover novel and potent anti-osteoclastogenic NPs.235

Most QSA/PR models employed (binary) classification algorithms to predict phenotypic responses such as anticancer or anti-inflammatory activity. Dias and co-workers created the first regression model to predict a phenotypic response, the pMIC value of a compound with antibacterial activity against MRSA.233 Very few research groups have ventured into developing models, regressors and classifiers, to predict the biological activity against specific protein targets, which is primarily due to the heterogeneity of biological information (e.g., MIC, IC50, EC50, Ki, % inhibition) in databases, and the variety of biological assay conditions these results came from. All the following models were developed to prioritize the virtual screening of sizable chemical libraries. The earliest target-based QSA/PR model could be attributed to Rupp and co-workers for discovering NP-derived Peroxisome Proliferator-Activating Receptor γ (PPARγ) activators for type 2 diabetes mellitus.236 The authors trained Gaussian process (GP) regression models with 144 PPARγ synthetic ligands and their pKd values. The compounds were encoded using molecular descriptors (i.e., 2D properties, topological pharmacophores, fragment counts), structure graphs (i.e., bond types, pharmacophores types) and combinations thereof, leading to 16 different GP models. Besides classical performance metrics, the authors evaluated their models using the so-called fraction of inactive among top-20-ranked compounds or FI20. They selected the 30 top-ranked compounds from the Asinex and Platinum collections (http://www.asinex.com), including ten compounds from the model with the best FI20 score. A total of eight displayed moderate-high and selective agonistic activity towards PPARα or PPARγ activation assays. One of their hits, the moderate yet selective PPARγ agonist compound 8 is a derivative of truxillic acid.236 In 2016, Sun and co-workers constructed five inductive logic programming (ILP) models to predict NPs that inhibit Sirtuin 1 (SIRT1), a promising target to treat type 2 diabetes and cancer.237 The first “inhibitor” model used 179 SIRT1/2 inhibitors (IC50 < 50 μM), whereas the “activator” model was made from 51 activators with EC50 < 2.15 μM. A third “differential” model compared SIRT1/2 inhibitors and activators. Two additional models estimated inhibitor binding energy and inhibitor affinity to SIRT1. The inhibitor models prioritised the virtual screening of 1.4M TCM compounds, leading to twelve candidates for AutoDock Vina software. In 2018, Pang and co-workers developed two classifiers (Naive Bayesian – NB, Recursive Partitioning – RP) to identify NPs with agonistic activity against estrogen receptor α (ERα), a protein target for breast cancer.238 The authors employed 9075 ERα agonists (IC50 < 10 μM) from the BindingDB and DUD-E databases and a suite of 2–3D physicochemical descriptors. The original dataset was divided into a 60:40 train/test split (6556:2519) with an imbalanced representation of active (2075) and inactive (7000) compounds. Both NB and RF classifiers showed good performances with a clear bias towards the inactive class in both training and testing sets. The authors applied their two best models to a library of 13 166 NPs; 393 NB-derived candidates, 193 RP-derived candidates, 162 NPs were commonly found in both sets. All candidates were docked against ERα (PDB ID: 3ERT) using the docking programs LibDock and CDOCKER, leading to the discovery and biological evaluations of eight NPs with antiestrogenic effects.

Besides their cost-effectiveness and time economy, many ML models have inconveniently incorporated drugs and synthetic compounds into their training sets, affecting the performances and the applicability domains of NP bioactivity predictors. For example, in 2017, Zhang and co-workers developed blood–brain barrier (BBB) permeability models that were applied to Traditional Chinese Medicine (TCM).239 Their preliminary models, based on a synthetic chemical library, performed poorly. Their subsequent models (SVM, RF, Naïve Bayes, and probabilistic neural network), integrating an NP dataset, showed an overall 90% accuracy. Additional in vitro evaluation further validated the BBB permeability predictions for 25 out of 32 TCM molecules. Alternatively, in 2019, Plisson and Piggott created good BBB permeability models based on ensemble classifiers built from 448 disclosed small molecules,240 that they applied to 471 marine NPs exhibiting kinase inhibition.241 The authors further implemented univariate Mahalanobis distance measures to define the applicability domain of their models, leading to the discovery of 13 marine-derived kinase inhibitors with appropriate physicochemical characteristics for BBB permeability. These strategies are mainly due to the lack of experimental data on the activity of NPs and the difficulty of representing compounds of natural origin in linear notations. Inadequate molecular representations could impact the performances of ML models as well.169,214 To date, the same representations define any organic molecule, drug and NP alike. Current proposals to address these issues include integrating experimental NP data to training sets, harmonizing NP bioassay results in public databases, applying ML algorithms that deal with small and imbalanced datasets, and creating NP-specific molecular representations.213 Finally, the democratization of AI/ML algorithms without proper training and expertise has also led to a surge of malpractices in ML modelling and chemoinformatics, with numerous non-reproducible QSA/PR models. Computational experts remind the scientific community about the best practices to adopt in QSA/PR and ML modelling.242–244

## Section: Machine learning applied to natural products › De-orphanizing

We rarely know the native binding targets of NPs. Moreover, most bioactive NPs are discovered through phenotypic assays, where their (protein) drug targets remain elusive. Recent advances in screening technologies245 and novel laboratory strategies help to identify their plausible modes of action,246–248 a process known as “target fishing.” In parallel, growing computational efforts for ligand-based target fishing include developing ML models and web servers to analyze the medicinal potential of the many NPs annotated in public chemical databases.249 These tools represent an opportunity to “de-orphanize” NPs by predicting their macromolecular (protein) targets. De-orphanizing predictors of NP drug targets typically employ supervised or semi-supervised ML algorithms trained with combinations of labelled and unlabelled features such as structural representations and types of interactions important for NP pharmacological effects.250

Several examples of web servers recently developed with ML methods for ligand-based target fishing are described in Table 1. The majority of these servers rely on chemical similarity searches. The PASS (Prediction of Activity Spectra for Substances) software is one of the earliest attempts to predict thousands of biological activities from two-dimensional chemical structures using molecular fragment descriptors.251 Applications of the PASS web server in the study of NPs have been extensively described.252 Recently, PASS was implemented in the SistematX Web Portal to profile a large NP database of Brazil.253 In a similar context, the SEA (similarity ensemble approach) server compares the structural similarity of a query molecule to a group of compounds of a potential target and has evaluated the statistical significance of the resulting similarity score.254 This server has been validated with NPs such as miconidine acetate (main metabolite of the Brazilian plant Eugenia hiemalis),255 and the physalins A, D, F and G.256

However, these tools might not predict the biological targets of structurally intricate NPs because of their somewhat different molecular constitution compared with that of synthetic drugs. In 2014, Reker and co-workers presented SPiDER (self-organizing map-based prediction of drug equivalence relationships) to tackle this problem. This approach relies on self-organizing maps (SOMs), a clustering approach that uses pharmacophore correlations and physicochemical properties to map the relationships between chemical compounds.257 SPiDER was adapted to predict the targets of natural products with more complex and challenging structures, such as the macrocyclic archazolid A (ArcA),258 resiniferatoxin,259 (−)-englerin A260 and doliculide.261 The authors demonstrated that by deconvoluting the macrocyclic structures into fragments, assuming that the bioactivity fingerprint could be partly stored into those fragments and subsequently used them as surrogate structures for processing SPiDER, natural product-derived fragments (NPDFs) may help for the prediction of macromolecular targets of their corresponding parent NPs. In 2016, Keum and co-workers created good ML classifiers to predict the interactions between orphan herbal compounds and several protein targets (i.e., GPCRs, ion channels, transporters, receptors, enzymes).262 In 2017, Schneider and Schneider presented TIGER (Target Inference GEneratoR) in subsequent development, a chemocentric computational method for target prediction that leverages a consensus of two SOMs with slightly modified descriptors.263 TIGER scores each target unlike previous approaches, where higher score values suggest greater confidence in the prediction. TIGER was validated for the target prediction of resveratrol,263 (±)-marinopyrrole A264 and (−)-galantamine.265 In 2018, Rodrigues and co-workers developed an orthogonal ML workflow called DEcRyPT (Drug–Target Relationship Predictor) based on RF regression to deconvolve phenotypic hit targets and accurately predict affinities. DEcRyPT was used successfully to identify β-lapachone as an allosteric modulator of 5-lipoxygenase.266 The following year, the team reported the alternate method DEcRyPT 2.0, including y-randomization,267 that predicted with more robustness the biological target(s) of celastrol.268 In 2019, Cockroft and co-workers developed the online target prediction tool named STarFish, which was trained with a synthetic composite dataset consisting of 107 190 pairs of compound-targets (88 728 unique compounds and 1907 unique targets) and tested on an NP dataset containing 5589 pairs of compound-targets.269 STarFish uses a stacking approach, where logistic regression is taken as a meta-classifier that combines model predictions and can produce better predictions than individual models. Furthermore, a multilabel classification approach is taken to emphasize the consideration of polypharmacology during training. Beyond fishing the biological targets of NPs, de-orphanizing ML approaches provide new opportunities for drug repurposing/repositioning.270,271

## Section: Generating de novo natural product-inspired compounds

Natural products contain privileged features to interact with (protein) drug targets that have supported their uses as starting, intermediate or final products for the design of synthetic compound libraries. Despite these advantages, most NPs do not fulfil the drug discovery paradigm in terms of toxicity, selectivity, lipophilicity and bioavailability, and require medicinal chemistry interventions (e.g., 92% of NP-inspired drugs were altered between 1980 and 2014 (ref. 10)). Their complex structures (i.e., stereogenic centres, heteroatom-containing functional groups, fused rings) have often handicapped the synthetic routes to analogues and their structure–activity/property relationship (SA/PR) studies. Moreover, patenting bioactive NPs in their original form might not be authorised where the compounds were discovered.272 Consequently, multiple synthetic strategies have led to designing lead structures that would preserve the NP privileges.192,273,274 The first strategy is the biology-oriented synthesis (BIOS), where NPs are taken as templates to generate synthetically accessible derivatives and mimetics.275,276 The diversity-oriented or diverted total synthesis (DOS/DTS) focuses on populating the underexplored chemical space by creating new chemical structures with NP-like pharmacophores.277–279 The complexity-to-diversity strategy (CtD) synthetically mimics enzymatic processes by chemically functionalizing and distorting NPs to structurally diverse compound collections.280,281 Finally, the function-oriented synthesis or FOS refines the BIOS concept to recapitulate or fine-tuning the function of a biologically active lead structure to obtain simpler scaffolds, increase their ease of synthesis, and achieve synthetic innovation.282,283 Waldmann and co-workers have recently introduced a set of principles to guide the generation of the “pseudo-NPs”, small molecule compound libraries that combine two or more NP-derived fragments (NPDFs), leading to unprecedented scaffolds. Their chemoinformatic analyses suggested that pseudo-NPs shared more characteristics (sizes, shapes, lipophilicity) with drugs than other libraries such as BIOS and ChEMBL NPs.192,284,285

Computer-aided de novo design tools286,287 have appeared alongside the synthetic strategies over the last 20 years and have recently started to generate NP-like compounds. One FOS-inspired approach automatically morphs NPs into synthetically accessible and isofunctional compounds. First, several chemical candidates are produced in silico using a generative algorithm. The compound generation is steered by optimizing the topological similarity between the candidates and a NP template. Subsequently, the computational prediction of the biological target is carried out. In 2016, Friedrich and co-workers reported the computational de novo design of the natural anticancer agent (−)-englerin A, the NP and its mimetics were all identified as potent TRPM8 agonists (TRPM8 stands for transient receptor potential calcium channel subfamily M (melastatin) member 8).288 In 2018, Merk and co-workers successfully applied two generative algorithms to design fatty acid mimetics as new modulators of retinoid X receptor (RXR) and peroxisome proliferator-activated receptor (PPAR). The authors first used their in-house de novo design algorithm named DOGS289 (Design Of Genuine Structures) to generate and test NP mimetics from dehydroabietic acid, isopimaric acid and valerenic acid, three known RXR agonists.290 In 2021, Friedrich and co-workers revisited the computational de novo DOGS design by generating (±)-marinopyrrole A mimetics as moderate-high inhibitors of cyclooxygenases COX-1 and COX-2.291

In the last five years, scientists have started to design de novo organic chemical entities for material science and drug discovery applications using generative AI.4–6,292,293 Early applications of DL algorithms to produce new molecules include the use of recurrent neural networks (RNN) with long-short term memory (LSTM),294 autoencoders,295,296 generative adversarial networks297 and reinforcement learning.298 In 2018, Merk and co-workers implemented LSTM-RNN to produce new RXR and PPAR agonists inspired by 25 fatty acid mimetics.299,300 The same year, Mȕller and co-workers adapted LSTM-RNNs to generate novel peptide sequences inspired by natural antimicrobial peptides, exempted from repetitive cysteine and proline residues.301 In 2019, Zheng and co-workers developed a de novo molecular generator to make quasi-biogenic compounds named QBMG.302 The authors used RNN with a gated recurrent unit (GRU) and trained the generator with 153 733 biogenic compounds from the ZINC15 library.303 In 2021, Bung and co-workers applied transfer learning and reinforcement learning to create novel small molecule inhibitors of the protease 3CL from the severe acute respiratory syndrome virus 2 (SARS-CoV-2). The team pre-trained the deep neural network architecture with 1.6 million drug-like small molecules from ChEMBL and generated 42 484 molecules. They filtered the generated dataset based on physicochemical descriptors, rule-based criteria, and virtual screening scores resulting in 33 new chemical entities, including two aurantiamide-like compounds.304

Scaffold-hopping comes as an alternative strategy to computer-aided de novo design. The computational process, widely used in medicinal chemistry, aims at identifying chemical compounds with different molecular backbones that share similar activity/property space.149–151 Scaffold-hopping applied to NPs means finding simpler NP mimetics, but their structural differences with synthetic compounds could hamper the computational process. In 2018, Grisoni and co-workers introduced a molecular similarity approach that hopped from complex NP scaffolds to simpler isofunctional synthetic mimetics while retaining their biological functions. The authors hopped from structures to structures using their in-house descriptors called weighted holistic atom localization and entity shape (WHALES) for the computational search. They exemplified their strategy using four natural cannabinoids as queries leading to seven novel biologically active compounds; three compounds became cannabinoid receptor modulators.19 The following year, the team employed WHALES descriptors in conjunction with SPiDER and TIGER tools in a multitarget ligand design approach. Grisoni and coworkers identified eight small molecules inspired by the natural product (−)-galantamine exhibiting multiple target activity profiles against enzymes and protein receptors related to Alzheimer's disease.265

In addition to the generation of simpler NP-inspired compounds, the total syntheses of NPs305 and NP analogues306 are the livelihoods of many chemists and mesmerize the field of organic chemistry, driven by synthetic efficiency, elegance and quality. Training algorithms to support the autonomous synthetic planning of complex NPs has also evolved over half a century since LHASA,307 giving rise to multiple softwares.308 Artificial intelligence has integrated computer-aided synthetic planning (CASP) such as Chematica/Synthia, a hybrid human-AI system.309,310 Artificial intelligence has also informed the fully automated platforms for the synthesis of NPs.311,312 The next paradigm shift aims to combine CASP with ML-driven models for predicting biological activities, biological targets, ADME/Tox properties to automate the discovery of biologically active NPs and the de novo design of NP-inspired drugs.180

## Section: Conclusions

Natural products have originated multiple drug discovery success stories, yet the many challenges associated with their discovery or their design – minute amounts, unfriendly extracts, unknown biological functions, missing biological targets, difficult chemical syntheses, complex SA/PR studies, undruggable ADME/Tox properties – led to the decline of NP drug discovery programmes. However, laboratory and computer scientists alike continue to marvel at NPs for their unique privileges to bind biological drug targets specifically for their therapeutic potentials. Artificial intelligence and machine learning algorithms have slowly integrated different stages of NP drug discovery (1) to assist discovering and elucidating bioactive structures and (2) to capture the molecular patterns of these privileged structures for molecular design and target selectivity. About the early discovery of bioactive NPs, natural language processing and text-mining tools have barely deciphered the many bioactive compounds hidden or forgotten in codices of traditional medicines and peer-reviewed articles. In contrast, ML-fuelled applications in genome mining and dereplication processes have reduced the screening of redundant producers or natural crude extracts and accelerated the discovery of novel natural chemical entities such as the subclass V lanthipeptides. With reported NPs, the inclusion of new AI technologies started at the turn of the 21st century with encoding their structures into computer-readable formats (i.e., 1–3D molecular representations, molecular descriptors) and generating chemical space visualization methods to manage and interpret the many naturally occurring compounds present in publicly available databases. The successive application of dimensionality reduction techniques such as PCA, t-SNE, SOM and lately TMAP has provided the means to compare NP privileged features (i.e., physicochemical properties, fragments, likeness scores) with those of drugs and synthetic libraries. In the 2010s, the development of ML models, i.e., regressions and classifications, to predict the biological activity/property of NPs has pushed candidates towards more advanced stages of drug development. It is worth noting that many predictions might inadvertently discard several bioactive NPs due to their striking physicochemical and structural differences with the model training sets (i.e., drugs). The limitations of these predictive models, also known as the applicability domains, are not systematically identified. Future improvements of predictive ML models should include an understanding of the scope and limitations of the available data. Besides biological activities, predictive algorithms and derived web servers have de-orphanized NPs to identify therapeutically relevant protein partners, expanding the realm of applications beyond their natural functions. Finally, deep generative models are re-routing NP-inspired de novo design with the autonomous generation of new drug candidates with simplified structures and inherited biological activities from NPs. Likewise, combining de novo design with de-orphanizing models produces novel isofunctional chemotypes (i.e., NP mimetics) that populate NP-exclusive and uncharted regions of the chemical space. These strategies are improving the synthetic accessibility, potency, and drug-likeness similarity of NP-inspired molecules.

## Section: Author contributions

FISG: visualization, investigation, writing – original draft, review & editing. VDAB: investigation, Writing – original draft & review. JLMF: writing – review & editing. FP: conceptualization, visualization, investigation, writing – original draft, review & editing. All authors read and approved the final manuscript.

## Section: Conflicts of interest

There are no conflicts to declare.

## Section: Acknowledgments

This work was supported by the Mexican research council Consejo Nacional de Ciencia y Tecnología (CONACYT). FISG and VDAB are thankful to CONACYT for their respective granted scholarships numbers 848061, and 772901. JLMF is supported by DGAPA, UNAM, Programa de Apoyo a Proyectos de Investigación e Innovación Tecnológica (PAPIIT), grant IN201321. FP is supported by a Cátedras CONACYT fellowship – 2017-present.

## Section: Biographies › Biography

Fernanda I. Saldivar-González received her BSc degree in Chemistry Pharmacy and Biology (2017) from the National Autonomous University of Mexico (UNAM). She received the Master's degree in Chemical Sciences in 2019 under the supervision of Prof. José Luis Medina, after spending a research period in the group of Prof. Andrea Trabocchi at the University of Florence, Italy. She is currently a PhD student in Chemistry in the area of pharmacy where she develops her project focused on the design of virtual chemical libraries of antidiabetic compounds.

## Section: Biographies › Biography

Victor D. Aldas-Bulos is a MSc student in Integrative Biology from Centre for Research and Advanced Studies of the National Polytechnic Institute (CINVESTAV-IPN) Advanced Genomics Unit (LANGEBIO) under the supervision of Dr Fabien Plisson since 2020. He received a BSc degree in Biotechnology from the Autonomous University of the State of Mexico (UAEMex) in 2021. His current research interests are in the development and discovery of antimicrobial peptides using artificial intelligence.

## Section: Biographies › Biography

José L. Medina-Franco received his Ph.D. degree from the National Autonomous University of Mexico (UNAM). He was a postdoctoral fellow at the University of Arizona and joined the Torrey Pines Institute for Molecular Studies in Florida in 2007. In 2013, he moved to the Mayo Clinic and later joined UNAM as Full Time Research Professor. He currently leads the DIFACQUIM research group. In 2017 he was named Fellow of the Royal Society of Chemistry. His research interests include development and application of chemoinformatics and molecular modeling methods for bioactive compounds with emphasis on drug discovery.

## Section: Biographies › Biography

Fabien Plisson obtained his Ph.D. degree from the University of Queensland (UQ), Australia, combining marine natural product chemistry, kinase drug discovery and chemoinformatics in partnership with biopharmaceutical company Noscira, Spain. In 2012, he carried out postdoctoral studies in peptide drug design at UQ, in collaborations with Pfizer and Protagonist Therapeutics. In late 2017, he moved to Mexico and joined the Centre for Research and Advanced Studies of the National Polytechnic Institute (CINVESTAV-IPN) Advanced Genomics Unit (LANGEBIO) as Assistant Research Professor. His research foci combine peptide drug design, drug discovery and artificial intelligence.


---

# New machine learning and physics-based scoring functions for drug discovery

- **Authors:** Isabella A Guedes, André M S Barreto, Diogo Marinho, Eduardo Krempser, Mélaine A Kuenemann, Olivier Sperandio, Laurent E Dardenne, Maria A Miteva
- **Issuer:** Scientific reports
- **Type:** Scientific article
- **Published:** 2021-02-04
- **Language:** en
- **DOI:** 10.1038/s41598-021-82410-1
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33542326/
- **Licence:** CC-BY

## Section: Abstract

Scoring functions are essential for modern in silico drug discovery. However, the accurate prediction of binding affinity by scoring functions remains a challenging task. The performance of scoring functions is very heterogeneous across different target classes. Scoring functions based on precise physics-based descriptors better representing protein–ligand recognition process are strongly needed. We developed a set of new empirical scoring functions, named DockTScore, by explicitly accounting for physics-based terms combined with machine learning. Target-specific scoring functions were developed for two important drug targets, proteases and protein–protein interactions, representing an original class of molecules for drug discovery. Multiple linear regression (MLR), support vector machine and random forest algorithms were employed to derive general and target-specific scoring functions involving optimized MMFF94S force-field terms, solvation and lipophilic interactions terms, and an improved term accounting for ligand torsional entropy contribution to ligand binding. DockTScore scoring functions demonstrated to be competitive with the current best-evaluated scoring functions in terms of binding energy prediction and ranking on four DUD-E datasets and will be useful for in silico drug design for diverse proteins as well as for specific targets such as proteases and protein–protein interactions. Currently, the MLR DockTScore is available at www.dockthor.lncc.br.

## Section: Introduction

Structure-based drug design and virtual screening have become common approaches for drug discovery. The predictive performance of scoring functions is essential for such methodologies1–3. However, accurate prediction of protein–ligand binding affinity remains a major challenge for current scoring functions. Despite the improvement over the last years of empirical, force-field or knowledge-based scoring functions, most of them still show unsatisfactory correlation with the experimental binding affinity or are based on meaningless description of protein–ligand interactions exhibiting overestimated accuracies in some cases4–6.

Empirical scoring functions are based on a set of individual contributions or interaction descriptors calibrated by regression or statistical approaches using a training set of experimental affinity data for protein–ligand complexes7,8. Improvement of scoring functions can be achieved by developing new terms, training on larger high-quality datasets or using sophisticated machine learning-based algorithms for regression analysis, e.g. XGBoost and LightGBM boosting approaches9–13. Next, solvation and entropy contributions are key for ligand binding14–20. Although several previous scoring functions have considered such effects14,15,17,19common limitations of scoring functions are related to often neglecting them10,21–23. New scoring functions based on more precise physics-based descriptors to better represent protein–ligand recognition process are thus needed. Furthermore, a number of studies demonstrated that scoring functions performance is very heterogeneous across different target classes22–26. Target-specific scoring functions have shown to achieve better affinity prediction performance than general scoring functions trained over diverse protein families21–23,27–29.

In this work, we developed a set of new empirical scoring functions, named DockTScore, to estimate protein–ligand binding affinity by explicitly accounting for physics-based interaction terms contributing to the binding free energy. Our models are based on the MMFF94S force field and trained and validated on high-quality large datasets properly curated. DockTScore scoring functions incorporate classical van der Waals and electrostatic energy terms, optimized terms accounting for solvation, lipophilic protein–ligand interactions and an improved estimation of ligand torsional entropy contribution to ligand binding for better describing of protein–ligand recognition. Firstly, we employed multiple linear regression (MLR)30,31 to ensure a physical interpretation of the individual term contribution. Then, we developed more sophisticated nonlinear scoring functions using support-vector machine (SVM) for regression (named “SMOReg”)32 and random forest (RF)33 algorithms using the theory-inspired physics-based terms selected from the initial MLR analysis. The development of scoring functions using physics-based descriptors representing protein–ligand recognition process together with the assessment of the accuracies of different linear and nonlinear models are important to avoid unrealistic overestimations of scoring functions accuracy due to some known biases, especially when training nonlinear models4,6,34,35.

In addition to general scoring functions appropriate for diverse protein targets, we have developed MLR, SMOReg and RF scoring functions for two specific protein classes: proteases, and protein–protein interactions (PPIs) to be targeted by small-molecule inhibitors (iPPIs). Proteases are key drug targets, for which focused scoring functions have already been developed (e.g. targets such as HIV-1 protease35). Interestingly, only one work has been reported thus far aiming at developing a linear scoring function to predict the binding affinity of inhibitors of PPIs36 using a training set of 27 PPIs complexes. Our MLR DockTScore for iPPIs gave new insights into the determinant factors contributing to inhibiting PPIs by small molecules. Moreover, we report here the first nonlinear scoring functions focusing on iPPIs and developed on 60 PPI complex structures carefully selected and curated. We evaluated the accuracy of affinity prediction and success of virtual screening to discriminate between active and decoys compounds of our scoring functions on four DUD-E datasets.

## Section: Methods

The iPPIs dataset.

Illustration of the algorithm for computing the ligand torsional entropy term. (A) Selection of the rotatable bonds in the ligand. (B and C). Each rotatable bond is divided into two sides (i in yellow and j in orange) and the root (*) and the neighboring ( +) atoms are detected. (D) A rotatable bond is considered as frozen if both sides become buried with more than 50% due to the binding (case 1). If at least one side does not become buried with more than 50% due to the binding the rotatable bond is not taken into consideration (case 2).

## Section: Methods › Data sets

The iPPIs dataset.

## Section: Methods › Data sets › Data sets of diverse protein–ligand complexes for general scoring functions

We trained and tested the general scoring functions appropriate for diverse protein targets based on the PDBbind v2013 refined set (http://www.pdbbind-cn.org/, version 2013), which is composed of 2959 protein–ligand complexes with binding affinity data manually collected from their original source37–40. PDBbind is known as the largest dataset of high-quality structures available for the development and validation of docking-scoring methods. The refined set was constructed according to several criteria concerning (i) the quality of the structures, (ii) the binding affinity data and (iii) the nature of the complex. Binding affinities in PDBbind comprise a large interval of values, ranging from 1.2 pM (1.2 × 10−12 M) to 10 mM (1.0 × 10−3 M). We converted the original binding constants to energy unit in kcal mol−1.

The PDBbind core set, a subset of the refined set widely used as benchmarking data for evaluation of docking-scoring methods, was used here to assess the performance of our general scoring functions as an external test set only, not being used during the training step. The core set version 2013 is composed of 195 protein–ligand complexes carefully collected from the refined set for comparative studies of scoring functions38–40.

## Section: Methods › Data sets › Data sets for target-specific scoring functions

We selected a random subset from the PDBbind v2013 refined set according to specific ranges of the EC Number, (Enzyme Commission Number (EC Number) is a system of enzyme nomenclature that numerically classifies enzymes based on the chemical reaction catalyzed.) ranging from 3.4.11.0 to 3.4.25.69, to create a dataset for training and testing the scoring function focused for proteases, resulting in a subset composed of 783 structures (Table S1).

To create the dataset for inhibitors of protein–protein interactions (iPPIs), we took the X-Ray-based iPPIs dataset previously described in Kuenemann and colleagues41, which was composed of 85 protein–ligand complexes. Here, we collected the binding affinity data from the original sources and manually prepared each complex using the Protein Preparation Wizard from Maestro (Maestro, version 9.7, Schrödinger, LLC, New York, NY, 2014). From the initial 85 iPPIs dataset, 25 complexes were removed due to their low resolution (value higher than 2.5 Å), the presence of covalently bound ligands or absence of affinity data. The remaining 60 structures were suitable for training and testing the specific scoring functions for iPPIs (Table 1).Table 1The iPPIs dataset.Protein (short name)TotalaAffinities (kcal mol−1)TrainingbTestcBcl2-like/BAX10−12.636d, −5.244e73Bromodomain2/Histone2−9.968, −8.56120Bromodomain4/Histone11−9.931, −6.14592K-Ras/SOS11−4.71210MDM2-like/P5320−12.768, −6.737146Menin1−10.40401Xiap/Smac7−11.278, −5.37861E1/E21−10.05110IL2/IL2R1−6.91010LEDGF/Integrase4−10.490, −6.67622ZipA/ftsZ2−6.685, −5.54420Total604515aTotal number of protein–ligand complexes in the dataset.bNumber of complexes in the training set.cNumber of complexes in the random test set.dBinding affinity of the strongest protein–ligand interactions.eBinding affinity of the weakest protein–ligand complex.

The iPPIs dataset.

## Section: Methods › Data sets › Training and test sets

All datasets were randomly separated into a training set with 75% of the structures and an independent test set with the remaining 25% structures (Table S1). For the general scoring functions, the core set (N = 195) was extracted from the refined set, initially containing 2959 complexes. Thus, the random selection of complexes for the independent test and training sets was performed exclusively with the remaining 2764 complexes. The random 75% of the 2764 complexes used to train the general scoring functions is called “General::random” training set (N = 2073, Table S1. In addition, we tested the influence of the training data set size on the predictive capacity for the general scoring functions. Thus, we also trained general scoring functions using all the 2764 protein–ligand complexes (called here “General::all”, Table S1). In this case, the predictive performance was evaluated only on the v2013 core set (N = 195).

For proteases, the training set was composed of 587 complexes and the test set was composed of 196 distinct complexes, not being used during the training step. Given the smaller size of the iPPI dataset, we characterized the composition of both training and test sets according to the protein families and the range of the binding affinity data (Table 1). Complexes of MDM2-like/P53 interacting with small ligands are the most frequent with 20 available structures, followed by complexes of Bromodomain4/Histone (11 complexes) and Blc2-like/BAX (10 complexes).

## Section: Methods › Data sets › Preparation of the structures

Protein–ligand complexes of the v2013 refined set consist of the complete unit taken from Protein Data Bank (PDB)42 (rcsb.org) and is available as prepared structures following an automatic procedure with some manual inspection performed by Li and colleagues38. Originally, the protein–ligand complexes were prepared following a simple protonation scheme considering a neutral pH: (i) all carboxylic acid and phosphate groups were deprotonated, and (ii) all aliphatic amine, guanidine and amidine groups were protonated. As well known, the correct assignment of both protein and ligand protonation/tautomeric states is crucial for correct binding mode and affinity predictions, but is a very time-consuming task for a large number of ligands43–45. In this work, we applied an improved protocol for the preparation of the structures of the v2013 refined set using the Protein Preparation Wizard from Maestro (Maestro, version 9.7, Schrödinger, LLC, New York, NY, 2014). Protonation assignment and hydrogen-bond optimization were performed using ProtAssign and PROPKA46 considering the presence of the bound ligand. Protonation and tautomeric states of the ligand were calculated using Epik47 (Epik, version 2.7, Schrödinger, LLC, New York, NY, 2014). Metal ions were considered as cofactors, and all waters were removed from the structures. Finally, energy minimization was performed to optimize the hydrogen atoms positions. A special attention was paid for the preparation of the core set due to its importance for the benchmarking studies. The protonation/tautomeric states of the binding-site residues and the bound ligand of the core set were further visually inspected and appropriate corrections were made guided by the original reference corresponding to the respective crystallographic structure and the Protoss program48. The curated core set (protein, ligand and cofactors) is freely available in the Supplementary Material. All structures of the iPPIs datasets and the proteases from DUD-E were prepared using the same protocol adopted for the core set.

## Section: Methods › Physics-based interaction terms

In this work, we implemented and evaluated several physicochemical terms contributing to the binding free energy to obtain pertinent descriptors for the derivation of the empirical scoring functions: protein–ligand electrostatic interactions (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul}$$\end{document}Ecoul), van der Waals interactions (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdW}$$\end{document}EvdW), lipophilic contact interactions (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{lipo}$$\end{document}Elipo), polar (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{polar\_solv}$$\end{document}Epolar_solv) and nonpolar (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{np\_solv}$$\end{document}Enp_solv) solvation contributions, and ligand torsional entropy contribution (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{entropy}$$\end{document}Eentropy).

Illustration of the algorithm for computing the ligand torsional entropy term. (A) Selection of the rotatable bonds in the ligand. (B and C). Each rotatable bond is divided into two sides (i in yellow and j in orange) and the root (*) and the neighboring ( +) atoms are detected. (D) A rotatable bond is considered as frozen if both sides become buried with more than 50% due to the binding (case 1). If at least one side does not become buried with more than 50% due to the binding the rotatable bond is not taken into consideration (case 2).

## Section: Methods › Physics-based interaction terms › Electrostatic and van der Waals protein–ligand interactions

The protein–ligand electrostatic and van der Waals interactions are calculated using the MMFF94S force field49,50. The MMFF94S force field was parameterized using high-quality ab initio quantum–mechanical data and demonstrated to accurately reproduce protein–ligand binding geometry in docking studies51,52. The electrostatic interaction \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul}$$\end{document}Ecoul was calculated using:\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul} = \frac{{332.0716q_{i} q_{j} }}{{\varepsilon \left( {R_{ij} + \delta_{elec} } \right)}}$$\end{document}Ecoul=332.0716qiqjεRij+δelecwhere \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$q_{i}$$\end{document}qi and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$q_{j}$$\end{document}qj are the partial charges of atoms i and j, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\varepsilon$$\end{document}ε is the dielectric constant, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$R_{ij}$$\end{document}Rij is the distance between the centers of the atoms i and j, and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\delta_{elec} = 0.05$$\end{document}δelec=0.05 is the electrostatic buffering constant. The partial charges \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$q_{i}$$\end{document}qi and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$q_{j}$$\end{document}qj are calculated through a bond-charge-increment method starting from an initial formal charge of the atom i (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$q_{i}^{0}$$\end{document}qi0) and adding the bond-charge-increment contributions (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\omega_{ki}$$\end{document}ωki), which reflect the polarity of the covalent bonds of the atoms i and k:\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$q_{i} = q_{i}^{0} + \sum \omega_{ki}$$\end{document}qi=qi0+∑ωki

In this work, we evaluated two sigmoidal distance-dependent dielectric functions to consider the electrostatic screening due to the dielectric medium of protein–ligand complexes. The first one developed by Hingerty and colleagues53 is currently implemented in the MMFF94S functional form used by the DockThor program for protein–ligand docking51,52 (available as a web server at https://www.dockthor.lncc.br):\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\varepsilon \left( r \right) = 78 - 77\left( {\frac{r}{2.5}} \right)^{2} \frac{{e^{r/2.5} }}{{\left( {e^{r/2.5} - 1} \right)^{2} }}$$\end{document}εr=78-77r2.52er/2.5er/2.5-12where \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$r$$\end{document}r is the internuclear separation between the atoms i and j.

The second dielectric function was formulated by Ramstein and Lavery, allowing to change both the maximal value of the dielectric constant (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$D$$\end{document}D) and the limiting value of the dielectric (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$D_{i}$$\end{document}Di) when the interatomic distance approaches 0 (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\varepsilon \left( r \right) \to D_{i}$$\end{document}εr→Di when \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$r \to 0$$\end{document}r→0)54. Here, we tested \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$D_{i}$$\end{document}Di values of 1 and 4 to simulate the relatively low dielectric at the interior of protein binding sites55.\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\varepsilon \left( r \right) = D - \left( {\frac{{D - D_{i} }}{2}} \right)\left[ {\left( {rs} \right)^{2} + 2rs + 2} \right]e^{ - rs}$$\end{document}εr=D-D-Di2rs2+2rs+2e-rs\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$r$$\end{document}r is the internuclear separation between the atoms i and j, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$s = 0.16$$\end{document}s=0.16 is the slope of the sigmoidal segment and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$D = 78$$\end{document}D=78.

The van der Waals potential (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdW}$$\end{document}EvdW) as implemented in the MMFF94S force field representing a “Buffered 14–7” form50 includes specific buffering constants \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\delta_{vdW}$$\end{document}δvdW and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\gamma = 0.12$$\end{document}γ=0.12:\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdW} = \varepsilon_{ij} \left( {\frac{{\left( {1 + \delta_{vdW} } \right)R_{ij}^{*} }}{{R_{ij} + \delta_{vdW} R_{ij}^{*} }}} \right)^{7} \left( {\frac{{\left( {1 + \gamma } \right)R_{ij}^{*7} }}{{R_{ij}^{7} + \gamma R_{ij}^{*7} }} - 2} \right)$$\end{document}EvdW=εij1+δvdWRij∗Rij+δvdWRij∗71+γRij∗7Rij7+γRij∗7-2where \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$R_{ij}$$\end{document}Rij is the interatomic distance (Å), \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\varepsilon_{ij}$$\end{document}εij is the well depth (kcal mol−1) and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$R_{ij}^{*}$$\end{document}Rij∗ is the minimum-energy separation (Å), which depends on the MMFF94S types of the atoms i and j. The original buffering constant \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\delta_{vdW} = 0.07$$\end{document}δvdW=0.07 was replaced in this work by \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\delta_{vdW} = 0.67$$\end{document}δvdW=0.67, which was empirically obtained to produce a more softened version of the van der Waals potential noted as \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdWS}$$\end{document}EvdWS.

## Section: Methods › Physics-based interaction terms › Lipophilic protein–ligand interactions

We developed two descriptors \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{lipo}$$\end{document}Elipo to calculate the lipophilic contact interactions effect \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{lipo}$$\end{document}Elipo by summing all hydrophobic atom pairs between the ligand and the protein following the previously proposed functional forms in ChemScore56 and X-Score57 scoring functions. For each of them, the atoms considered for lipophilic contacts were: (i) all carbon atoms, or (ii) any non-hydrogen atom with MMFF94S partial charge q in the interval \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$- 0.4 < q < + 0.4$$\end{document}-0.4<q<+0.4. We empirically estimated this range of partial charges through analysis of several protein–ligand complexes parameterized with the MMFF94S force field. The \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{lipo}$$\end{document}Elipo descriptor for each lipophilic contact following e.g. the ChemScore is calculated by:\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{lipo} = \begin{cases}1, &d\leq d_{vdW}+0.5{\AA}\\1-\frac{d-d_{vdW}+0.5}{3}, &d_{vdW}+0.5{\AA}<d\leq d_{vdW}+3.5{\AA} \\ 0,&d>d_{vdW}+3.5{\AA}\end{cases}$$\end{document}Elipo=1,d≤dvdW+0.5Å1-d-dvdW+0.53,dvdW+0.5Å<d≤dvdW+3.5Å0,d>dvdW+3.5Åwhere \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$d$$\end{document}d is the distance between the pairs of atoms and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$d_{vdW}$$\end{document}dvdW is the sum of their van der Waals radii.

## Section: Methods › Physics-based interaction terms › Polar and nonpolar solvation contributions

In this work, the solvation contribution was calculated using a polar solvation term, which accounts for the loss of polar interactions of the charged groups of both protein and ligand with the solvent, and a nonpolar solvation term, which reflects the desolvation of the hydrophobic protein and ligand groups due to binding. The polar solvation term \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{polar\_solv}$$\end{document}Epolar_solv was calculated by summing up the number of charged atoms becoming buried after the complex formation and not interacting with a charged atom in the protein–ligand complex. In this term, two charged atoms were considered as interacting if the distance between them (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$d$$\end{document}d) was equal to or lower than \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$d_{vdW} + 1.0 {\AA}$$\end{document}dvdW+1.0Å, where \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$d_{vdW}$$\end{document}dvdW is the sum of their van der Waals radii. A charged atom was defined as a non-hydrogen and a non-carbon atom with a partial charge \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\left| q \right| > 0.8$$\end{document}q>0.8.

The nonpolar solvation \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{np\_solv}$$\end{document}Enp_solv was calculated based on the total loss of the solvent-accessible surface area (SAS) of the protein and the ligand due to the binding converted into energy (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{np\_solv}$$\end{document}Enp_solv in kcal mol−1) following Kuhn and Kollman58. The SAS of atoms in the free and complexed states was calculated with the program MSMS59.\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{np\_solv} = G_{np} complex - \left( {G_{np} protein + G_{np} ligand} \right)_{free}$$\end{document}Enp_solv=Gnpcomplex-Gnpprotein+Gnpligandfreewhere \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$G_{np}$$\end{document}Gnp is calculated by:\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$G_{np} = 0.0092*SAS + 0.82$$\end{document}Gnp=0.0092∗SAS+0.82

## Section: Methods › Physics-based interaction terms › Ligand torsional entropy contribution

We revisited here the ligand torsional entropy term based on the conformational component of the ligand entropy and arising from the loss of the torsional degrees of freedom for a flexible ligand upon binding. Instead of a crude approximation based on the total number of all rotatable bonds14–17,19, we propose an improved estimation of the lost torsional freedom of the ligand by considering only the rotatable bonds, which become “frozen” due to binding. Similar approaches were previously adopted to approximate protein side-chain entropic contributions15,60.

The bonds are considered as “frozen” based on the change of the solvent-accessible surface areas of the ligand atoms directly involved in each rotatable bond, aiming to penalize only dihedrals that are unable to rotate after the complex formation.

Firstly, each rotatable bond of the ligand (Fig. 1A) is divided into two sides for the two atoms i and j (Fig. 1B,C). Each side is composed of (i) the atom i, which is directly involved in the bond (symbol *), and (ii) the first neighbors of the atom i (symbol +). The same procedure is applied to the other side (atom j). The change of the SAS (ΔSAS) for each side upon the binding is computed taking into account all atoms of the side. If SAS decreases ≥ 50% for the two sides, the rotatable bond is considered as frozen due to the binding. We consider that a hiding of a rotatable bond by more than 50% is significant for the ligand flexibility, and thus critical to the change of the ligand entropy due to the binding. In fact, the protein receptor is kept rigid during the docking and slight protein movements could compensate for a small change of the SAS of a ligand rotatable bond. We thus take into consideration only those bonds becoming frozen due to the binding for the ligand torsional entropy contribution estimation (Fig. 1D).Figure 1Illustration of the algorithm for computing the ligand torsional entropy term. (A) Selection of the rotatable bonds in the ligand. (B and C). Each rotatable bond is divided into two sides (i in yellow and j in orange) and the root (*) and the neighboring ( +) atoms are detected. (D) A rotatable bond is considered as frozen if both sides become buried with more than 50% due to the binding (case 1). If at least one side does not become buried with more than 50% due to the binding the rotatable bond is not taken into consideration (case 2).

Illustration of the algorithm for computing the ligand torsional entropy term. (A) Selection of the rotatable bonds in the ligand. (B and C). Each rotatable bond is divided into two sides (i in yellow and j in orange) and the root (*) and the neighboring ( +) atoms are detected. (D) A rotatable bond is considered as frozen if both sides become buried with more than 50% due to the binding (case 1). If at least one side does not become buried with more than 50% due to the binding the rotatable bond is not taken into consideration (case 2).

## Section: Methods › Derivation of linear scoring functions

We performed the selection of the descriptors based on the assumption that the major contributions to the free energy of binding are the intermolecular interactions, represented by the van der Waals and electrostatic interactions between the protein and the ligand, and the solvation and entropy changes due to the binding. We developed thus independent descriptors accounting for van der Waals and electrostatic interactions, protein–ligand lipophilic contacts, the change of the conformational entropy of the ligand, and polar/nonpolar solvation contribution to the binding (see their definition in “Physics-Based Interaction Terms”). Then, we selected the best descriptors (see below), assuring that all above mentioned classes of interactions have been present in the final scoring functions, instead of using a combinatorial or sequential descriptors selection.

We applied multiple linear regression (MLR) ensuring a physical interpretation of the individual terms’ contributions. A tenfold cross-validation was used to select the best performing physics-based descriptors. This initial descriptor selection was applied only for the derivation of the general scoring function since it was trained with the largest training set containing diverse protein–ligand complexes. We started with the basic function FMMFF containing the electrostatic term with the Ramstein dielectric function tending to 4, Di = 4, (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul4}$$\end{document}Ecoul4) and the soft van der Waals term (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdWS}$$\end{document}EvdWS) based on the original MMFF94S force field. These two terms were selected since they achieved the best correlation among four combinations tested for the electrostatic and vdW terms (see Table S2).

Then, each of the remaining physics-based descriptors (lipophilic contacts, entropy, polar solvation and nonpolar solvation) was individually added to the basic function FMMFF one at a time, to find the best variation for each of them leading to the best correlation on cross-validation experiments. Thus, the combinations evaluated herein were: FMMFF + lipophilic contacts (4 variants), FMMFF + entropy, FMMFF + polar solvation, and FMMFF + nonpolar solvation. The correlations obtained for all combinations are present in the Supplementary Material (Tables S3 and S4). We considered the best variation of each specific term to finally combine them into the general scoring function (Ffinal = FMMFF + lipophilic contacts + ligand conformational entropy + polar solvation + nonpolar solvation). Next, the best combination of terms of the general scoring function was applied to the class-specific scoring functions, and was also used for the descriptors in the development of nonlinear scoring functions with machine learning methods.

## Section: Methods › Derivation of nonlinear scoring functions

In this work, we also developed nonlinear scoring functions using the Support Vector Machine for Regression (SMOReg) and Random Forest (RF) algorithms. Such scoring functions were trained using the same physics-based descriptors selected for the final linear scoring functions.

Support Vector Machine (SVM) aims to find the hyperplane that maximizes the margin of separation between data classes. In particular, in the kernel application the original nonlinear separable data can be transformed to a linear hyperplane separable problem on a higher dimension space61. SMOReg uses the sequential minimal optimization (SMO) for training support-vector machines (SVM) models in regression problems. In regression problems, all prediction errors less than a value of ε are ignored (insensitive-loss function)30,62. This strategy reduces the risk of overfitting on the training set and is controlled by the complexity parameter C, which is user-defined together with ε.

Random Forests (RF) were introduced by Breiman in 2001 as a powerful strategy for ensemble learning33. The RF combines several random trees (numTrees) in a bagging ensemble model, often leading to excellent results in diverse classification problems33,62. The output variable of a RF model is usually an average value of the predictions of the regression trees (as used in this work), where the node splitting is performed using a finite subset of features randomly chosen (numFeatures).

All the machine-learning procedures were carried out using the Weka v3.8.3 package30. We explored diverse configurations of SMOReg and RF on a tenfold cross-validation procedure. For SMOReg, we varied the complexity parameter C, tolerance in loss function epsilon (ε), kernel (puk or rbf), gamma (γ) of the rbf kernel, and sigma (σ) and omega (ω) of the puk kernel. In the RF training, we explored the number of trees (numTrees) and the number of features that are randomly chosen for splitting the parent node (numFeatures).

The tested learning parameters and their optimal values found are present in Tables S5 and S6, respectively (see Supporting Information).

## Section: Methods › Validation of the scoring functions › Binding affinity accuracy

The best model of each machine-learning algorithm was selected according to the Pearson’s Correlation Coefficient (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$R$$\end{document}R) using the tenfold cross-validation strategy. Then, we applied the scoring functions to the respective test sets to validate their affinity predictability according to R and root mean squared error (RMSE). Both R and RMSE were calculated using the experimental and predicted free energy of binding (ΔGbind):\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$R = \frac{{\mathop \sum \nolimits_{i = 1}^{N} \left( {y_{i} - \overline{y}} \right)\left( {t_{i} - \overline{t}} \right)}}{{\sqrt {\mathop \sum \nolimits_{i = 1}^{N} \left( {y_{i} - \overline{y}} \right)^{2} } \sqrt {\mathop \sum \nolimits_{i = 1}^{N} \left( {t_{i} - \overline{t}} \right)^{2} } }}$$\end{document}R=∑i=1Nyi-y¯ti-t¯∑i=1Nyi-y¯2∑i=1Nti-t¯2where \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$y_{i}$$\end{document}yi and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$t_{i}$$\end{document}ti are respectively the predicted and the experimental binding affinities for the i-th complex, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\overline{y}$$\end{document}y¯ and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\overline{t}$$\end{document}t¯ are the arithmetic average values for y and t and N is the number of points in the data set.\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$RMSE = \sqrt {\frac{1}{N}\mathop \sum \limits_{i = 1}^{N} \left( {y_{i} - t_{i} } \right)^{2} }$$\end{document}RMSE=1N∑i=1Nyi-ti2where N is the number of points in the dataset, \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$y_{i}$$\end{document}yi is the predicted binding affinity and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$t_{i}$$\end{document}ti is the experimental binding affinity.

## Section: Methods › Validation of the scoring functions › Virtual screening experiments

In order to evaluate the success of our scoring functions to discriminate active and decoys compounds, we performed docking experiments using the protein–ligand docking program DockThor51,52 and re-scoring with DockTScore on core set and the DUD-E datasets63 for the proteases FA7 (coagulation factor VII, PDB code 1W7X), RENI (renin, PDB code 3G6Z), TRYB1 (tryptase β1, PDB code 2ZEC), and UROK (urokinase-type plasminogen activator, PDB code 1SQT), and the kinases AKT2 (serine/threonine-protein kinase AKT2, PDB code 3D0E), KIT (stem cell growth factor receptor, PDB code 3G0E) and MK01 (MAP kinase ERK2, PDB code 2OJG). Proteases were selected to evaluate the screening success of the DockTScore general and target-specific scoring functions trained on the PDBbind refined set due to the large size of the training set used to calibrate the focused scoring functions for proteases. The protease and kinase datasets from DUD-E were chosen according to the following criteria: (i) no metal ions interacting with the ligand, and (ii) co-crystallized ligand successfully redocked with the top-energy solution with RMSD ≤ 2.0 Å. For PPIs, we constructed screening datasets for Bcl2-like/BAX and MDM2/p53 systems composed of actives taken from the iPPI-DB64 database (https://ippidb.pasteur.fr/) and inactive compounds taken from the BDM chemical library available at ChemREST (https://chem-rest.pasteur.fr/#?&versioned_sources=8&used_filters =). The iPPI-DB is a database that contains the structure, some physicochemical characteristics, the pharmacological data and the profile of about 2000 modulators of protein–protein interactions. It contains exclusively small molecules and therefore no peptides. BDM compounds have been previously shown to be negative on MDM2 and Bcl2 interactions via fluorescence polarization assays65. For the PPIs screening datasets, we selected only the compounds without chiral centers and having only one protonation/tautomer state as predicted by Epik. Following the DUD-E sets construction, we selected randomly 50 inactives for each active compound to keep an adequate balance between actives and inactives to evaluate the scoring functions performance on virtual screening experiments. The PDB codes 3QKD and 4IPF were used for the receptor structures of the Bcl-2-like protein 1 and MDM2, respectively.

The docking poses were generated with the program DockThor for protein–ligand docking freely available as a web server at https://dockthor.lncc.br). The DockThor program uses a grid box to define the search space, the DMRTS genetic algorithm as the search algorithm, and an MMFF94S-based scoring function for pose prediction51,52. Configuration of the search space of each protein target was automatically determined according to the reference ligand: (i) the center of coordinates was defined as the center of coordinates of the ligand, (ii) the grid size was defined as the largest axis value of the ligand plus a tolerance of 6 Å on each dimension, (iii) the discretization (i.e. spacing between two points of the grid) was set to the default value of 0.25 Å except for the cases where the grid size was greater than 26 Å. The parameters of the search algorithm were set as follows for redocking experiments: (i) 24 docking runs, (ii) 1,000,000 evaluations on each docking run, (iii) initial population of 1,000 individuals. The MMFF94S-based scoring function for ranking the docking poses (Etotal) consists of (i) the torsional, electrostatic and Buf-14–7 van der Waals potential terms for the internal energy, and (ii) the electrostatic and Buf-14–7 van der Waals potential terms for the intermolecular interactions. The docking poses are clustered using our in-house tool dtstatistic using a criterion of diversity equals to 2.0 Å.

The screening experiments were performed using the computational facilities provided by the Brazilian SINAPAD (Sistema Nacional de Alto Desempenho, https://www.lncc.br/sinapad/) high-performance platform and the Supercomputer SDumont. We used a set of GA parameters named “virtual screening” for the screening experiments used to reduce the computational cost, consisting of 12 docking runs, 500,000 GA evaluations and initial population of 750 individuals. The top-energy docking pose ranked by the total energy Etotal were selected for the virtual screening experiments and binding affinity predictions.

The screening success was evaluated according to the area under the curve for the receiver operation characteristics (ROC AUC), the enrichment factor at 1% of the screened libraries (i.e., EF1%), and the Boltzmann-enhanced discrimination of ROC values (α = 20 and α = 100, respectively BEDROC20 and BEDROC100)66 using the open-source tool for virtual screening analysis Rocker67.

## Section: Results

Coefficients of the terms obtained for the general scoring functions trained with MLR.

Correlation plot of the experimental and predicted binding affinities by the MLR (left) and RF (right) general scoring functions. Models trained on the PDBbind v2013 refined set (N = 2764) and evaluated on curated v2013 core set (N = 195). R is the Pearson’s correlation coefficient and RMSE is the root mean squared error given in kcal mol−1.

Correlation plot of experimental and predicted binding affinities by MLR (left) and SMOReg (right) specific scoring functions for proteases. The scoring functions were evaluated on the independent test set for proteases (N = 196). R is the Pearson’s correlation coefficient and RMSE is the root mean squared error given in kcal mol−1.

Coefficients of the terms obtained for the protease-specific scoring functions trained with MLR.

Coefficients of the terms obtained for the iPPI-specific scoring functions trained with MLR.

Correlation plot of predicted and predicted binding affinity by MLR (left) and SMOReg (right) specific scoring functions for iPPIs using one solvation term evaluated on the independent test set for iPPIs (N = 15). R is the Pearson’s correlation coefficient and RMSE is the root mean squared error given in kcal mol-1.

Screening success of the general and target-specific scoring functions trained with MLR, SMOreg and RF for the FA7, RENI, TRYB1 and UROK datasets from DUD-E. ac, dec and tot are the number of active, decoy compounds and the total number of molecules in the final dataset (i.e., compounds that were docked and rescored with DockThor and DockTScore, respectively). Only the top-scored protonation state of a compound according to each scoring function (SF) was kept.

AUC ROC curves of the general (left) and protease-specific scoring functions (right) trained with MLR, SMOreg and RF for the FA7 (A), RENI (B), and UROK (C) datasets from DUD-E.

Surface representation of the binding sites of the proteases (A) FA7, (B) UROK, (C) RENI, and (D) TRYB1 colored by chain. The co-crystallized ligand is represented as sticks.

AUC ROC curves of the protease-specific (left) and PPI-specific (right) scoring functions trained with MLR, SMOreg and RF for the TRYB1 datasets from DUD-E.

Screening success of the general and PPI-specific scoring functions trained with MLR, SMOreg and RF evaluated on the Bcl2-like protein/BAX and MDM2/p53 datasets. ac, inac and tot are the number of active, inactive compounds and the total number of molecules in the final dataset (i.e., compounds that were docked and rescored with DockThor and DockTScore, respectively). Only the top-scored protonation state of each compound according to each scoring function (SF) was kept.

AUC ROC curves of the general (left) and PPI-specific (right) scoring functions trained with MLR, SMOreg and RF for the Bcl2-like/BAX (A) and MDM2/p53 (B) datasets.

Screening success of the general scoring functions trained with MLR, SMOreg and RF evaluated on the AKT2, KIT, and MK01 datasets from DUD-E. ac, dec and tot are the number of active, decoy compounds and the total number of molecules in the final dataset (i.e., compounds that were docked and rescored with DockThor and DockTScore, respectively). Only the top-scored protonation state of each compound according to each scoring function (SF) was kept.

AUC ROC curves for the general scoring functions trained with MLR, SMOreg and RF evaluated on the AKT2, KIT and MK01 kinase datasets from DUD-E.

## Section: Results › Performance of physics-based terms for the scoring functions

The best correlation between the predicted and experimental affinities (R = 0.493) using tenfold cross-validation on the General::random training set (N = 2073) with MLR for a scoring function accounting only for \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdW}$$\end{document}EvdW and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul}$$\end{document}Ecoul was obtained with our softened version of the Buf-14-7 van der Waals potential (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdWS}$$\end{document}EvdWS, with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\delta_{vdW} = 0.67$$\end{document}δvdW=0.67) and the electrostatic term using the sigmoidal dielectric function of Ramstein and Lavery58 with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$D_{i} = 4$$\end{document}Di=4 (Table S2), noted here as \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul4}$$\end{document}Ecoul4. The scoring function composed of only \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdWS}$$\end{document}EvdWS and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul4}$$\end{document}Ecoul4 terms is noted in this work as the “basic scoring function” \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$F_{MMFF}$$\end{document}FMMFF. No correlation was obtained in cross-validation experiments (R = 0.053) using only the two original MMFF94S force field terms \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdW}$$\end{document}EvdW Buf-14–7 (with \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\delta_{vdW} = 0.07$$\end{document}δvdW=0.07) and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul}$$\end{document}Ecoul (\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$D_{i} = 1$$\end{document}Di=1). It is interesting to note that the best correlation was obtained with the softened version \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdWS}$$\end{document}EvdWS , which is expected because no energy minimization of the complex structures was performed. Soft vdW potentials are more permissive for small clashes that can be present, in particular in structures generated by molecular docking without subsequent energy minimization. For X-ray derived structures shorter non-bonded atom–atom distances may be present when compared to energy minimized structures through classical force fields optimizations. Indeed, when dealing with non-optimized structures such as those used in X-ray models, it is indicated to softening the Buf-14-7 potential increasing the \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$\delta_{vdW}$$\end{document}δvdW buffering constant50. The \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{lipo}$$\end{document}Elipo lipophilic contact term provided better results when nonpolar atoms were defined based on the MMFF94S partial charges instead of considering only carbon atoms, achieving here a Pearson correlation of R = 0.538 when added to the \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$F_{MMFF}$$\end{document}FMMFF basic scoring function (Table S3). This result indicated that our description of the atom types according to their partial atomic charges, specific for the MMFF94S force field is relevant. Adding our original and simple term for the polar solvation also improved the accuracy of the basic scoring function FMMFF (R = 0.514). Similarly, adding the nonpolar solvation term to FMMFF improved the correlation in tenfold cross-validation experiments (R = 0.503). In the same line, our proposed improved term for ligand torsional entropy contribution demonstrated to be important for the affinity prediction when associated with the basic scoring function, improving its correlation on cross-validation experiments (R = 0.507). The observed improvement due to our individual physics–based terms permitted their validation for further training of the general and target-specific empirical scoring functions.

## Section: Results › General scoring functions

The MLR coefficients obtained for the general scoring functions considering all validated six terms are shown in (Table 2). As expected, the coefficients are in accordance with the physical meaning of the corresponding terms (i.e., favorable or unfavorable contribution). Energy terms such as van der Waals, electrostatic and nonpolar solvation increase the binding affinity when the associated coefficients have positive values and the corresponding interactions for \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul}$$\end{document}Ecoul and \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{np\_solv}$$\end{document}Enp_solv are favorable for the binding. The empirical term related to the counting of the lipophilic atom pairs has a favorable contribution as the associated coefficient has a negative value. The polar solvation and the entropy terms are unfavorable as the coefficients are positive.Table 2Coefficients of the terms obtained for the general scoring functions trained with MLR.Scoring functions\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul4}$$\end{document}Ecoul4\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdWS}$$\end{document}EvdWS\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{lipo}$$\end{document}Elipo\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{entropy}$$\end{document}Eentropy\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{polar\_solv}$$\end{document}Epolar_solv\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{np\_solv}$$\end{document}Enp_solvc0General::randoma0.00390.0386−0.01110.05600.10250.0169−5.5197General::allb0.00450.0343−0.01040.06050.09870.1180−5.5178aScoring function trained with the random training set (N = 2073).bScoring function trained with the refined set minus core set (N = 2764).

MLR general scoring function trained with the random training set (N = 2073) exhibited a good performance on tenfold cross-validation experiments (R = 0.548) and on the curated core set (R = 0.602), and a lower performance on the random test set (R = 0.494) (Table S7). Our MLR general scoring function has predictive capacity comparable to the best evaluated linear scoring functions, with performance close to X-Score:HMScore (R = 0.614) and X = Score::SAS (R = 0.606) reported in the v2013 core set benchmark paper39.

According to the tenfold cross-validation in the random general training set (N = 2073), it is seen that the SMOReg and RF models outperformed the MLR model, providing significantly better performances with R = 0.653 and R = 0.655, respectively (Table S7). These results confirm previous findings that nonlinear regression may better predict binding affinities than MLR and that the additive assumption adopted in the linear scoring functions could be too restrictive68. Using two different size training sets, the General::all one (N = 2764) and the General::random one (N = 2073) did not change the predictive performance of MLR model (R = 0.601 vs R = 0.602) while the larger training set improved the predictive performance of the SMOReg and RF models on the core set (Fig. 2 and Table S7), respectively RSMOReg = 0.668 vs RSMOReg = 0.687 and RRF = 0.678 vs RRF = 0.705. These results are consistent with other studies evaluating the influence of the training size, indicating that nonlinear scoring functions increase performance when more data is included in the training set while linear models seem to be less sensitive to the training set size69,70.Figure 2Correlation plot of the experimental and predicted binding affinities by the MLR (left) and RF (right) general scoring functions. Models trained on the PDBbind v2013 refined set (N = 2764) and evaluated on curated v2013 core set (N = 195). R is the Pearson’s correlation coefficient and RMSE is the root mean squared error given in kcal mol−1.

Coefficients of the terms obtained for the general scoring functions trained with MLR.

Correlation plot of the experimental and predicted binding affinities by the MLR (left) and RF (right) general scoring functions. Models trained on the PDBbind v2013 refined set (N = 2764) and evaluated on curated v2013 core set (N = 195). R is the Pearson’s correlation coefficient and RMSE is the root mean squared error given in kcal mol−1.

## Section: Results › Target-specific scoring functions

Correlation plot of experimental and predicted binding affinities by MLR (left) and SMOReg (right) specific scoring functions for proteases. The scoring functions were evaluated on the independent test set for proteases (N = 196). R is the Pearson’s correlation coefficient and RMSE is the root mean squared error given in kcal mol−1.

Coefficients of the terms obtained for the protease-specific scoring functions trained with MLR.

Coefficients of the terms obtained for the iPPI-specific scoring functions trained with MLR.

Correlation plot of predicted and predicted binding affinity by MLR (left) and SMOReg (right) specific scoring functions for iPPIs using one solvation term evaluated on the independent test set for iPPIs (N = 15). R is the Pearson’s correlation coefficient and RMSE is the root mean squared error given in kcal mol-1.

## Section: Results › Target-specific scoring functions › Proteases

The linear scoring function for proteases exhibited good performance on the cross-validation experiments (R = 0.614) and on the independent test set (R = 0.653) (Fig. 3). All coefficients were very similar to those obtained for the general scoring function and their signals were in accordance with the physical meaning of the corresponding terms (Table 3). Likewise to the results observed for general scoring function, the nonlinear models for proteases exhibited significant improvements in the prediction capacity for both tenfold cross-validation experiment (RSMOReg = 0.749 and RRF = 0.735) and the independent test set (RSMOReg = 0.730 and RRF = 0.723).Figure 3Correlation plot of experimental and predicted binding affinities by MLR (left) and SMOReg (right) specific scoring functions for proteases. The scoring functions were evaluated on the independent test set for proteases (N = 196). R is the Pearson’s correlation coefficient and RMSE is the root mean squared error given in kcal mol−1.Table 3Coefficients of the terms obtained for the protease-specific scoring functions trained with MLR.Scoring functions\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul4}$$\end{document}Ecoul4\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdWS}$$\end{document}EvdWS\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{lipo}$$\end{document}Elipo\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{entropy}$$\end{document}Eentropy\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{polar\_solv}$$\end{document}Epolar_solv\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{np\_solv}$$\end{document}Enp_solvc0Proteases0.00890.0399−0.11200.01530.05150.0809−4.8954

Correlation plot of experimental and predicted binding affinities by MLR (left) and SMOReg (right) specific scoring functions for proteases. The scoring functions were evaluated on the independent test set for proteases (N = 196). R is the Pearson’s correlation coefficient and RMSE is the root mean squared error given in kcal mol−1.

Coefficients of the terms obtained for the protease-specific scoring functions trained with MLR.

## Section: Results › Target-specific scoring functions › Protein–protein interactions (PPI)

For the iPPI linear scoring function, the representation of solvation as two independent terms leads to an unexpected favorable contribution of polar solvation instead of penalizing the buried charged atoms not involved in charge-charge interactions (Table 4). Thus, we decided to consider a single term for both polar and nonpolar solvation (called “oneSolv”), which has the same functional form of the nonpolar term but taking into account all heavy atoms, i.e., both polar and nonpolar ones. The solvation term “oneSolv” performed slightly better for the PPI-specific scoring function on cross-validation than using two solvation terms (R = 0.552 versus R = 0.545). Comparing the magnitude of the coefficients in the “oneSolv” model, the entropic and electrostatic terms exhibited a significantly higher contribution for iPPIs (Table 4). It has been widely demonstrated that iPPIs have higher hydrophobicity, aromaticity and molecular weight compared to enzyme inhibitors, as usually interacting within flatter, larger and more hydrophobic binding sites than the enzyme catalytic sites41,71,72. Given this, it is expected that the hydrophobic effect due to the binding represented here by the lipophilic contact and “oneSolv” solvation terms exhibit a strongly favorable contribution for this class of complexes. The unfavorable contribution of the \documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdWS}$$\end{document}EvdWS term might be due to some overlapping with the lipophilic contact and the “oneSolv” solvation terms. Further, a larger dataset set would allow to better evaluate the solvation contribution for inhibiting PPI.Table 4Coefficients of the terms obtained for the iPPI-specific scoring functions trained with MLR.Scoring functions\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{coul4}$$\end{document}Ecoul4\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{vdWS}$$\end{document}EvdWS\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{lipo}$$\end{document}Elipo\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{entropy}$$\end{document}Eentropy\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{polar\_solv}$$\end{document}Epolar_solv\documentclass[12pt]{minimal} \usepackage{amsmath} \usepackage{wasysym} \usepackage{amsfonts} \usepackage{amssymb} \usepackage{amsbsy} \usepackage{mathrsfs} \usepackage{upgreek} \setlength{\oddsidemargin}{-69pt} \begin{document}$$E_{np\_solv}$$\end{document}Enp_solvc0iPPIs0.05050.0024−0.01300.1967−0.16981.0569−0.7898iPPIs-oneSolv0.0335−0.0207−0.01530.20381.1227−1.1397

Regarding the ligand entropy, it is clearly unfavorable for the binding. We expect that our improved entropic term penalizing only frozen rotatable bonds instead of all rotatable bonds is particularly important for the PPI class taken into account the large size of iPPIs and thus a possibly larger number of rotatable bonds. To confirm this hypothesis, we evaluated the linear scoring function for iPPIs on tenfold cross-validation experiments using the commonly used total number of rotatable bonds instead of the number of frozen torsions, and we obtained a slightly reduced correlation (R = 0.515). In this context, our entropic term demonstrated to be more appropriate for iPPIs than the total number of rotatable bonds.

As expected, the nonlinear scoring functions specific for iPPIs, mainly the SMOReg model, improved the predictive performance when compared with the MLR model (Fig. 4), obtaining correlations of RSMOReg = 0.600 and RRF = 0.666 on the tenfold cross-validation, and RSMOReg = 0.613 and RRF = 0.478 on the test set. Curiously, despite the RF performing better on the tenfold cross-validation, the SMOReg model achieved a real improvement on the test set.Figure 4Correlation plot of predicted and predicted binding affinity by MLR (left) and SMOReg (right) specific scoring functions for iPPIs using one solvation term evaluated on the independent test set for iPPIs (N = 15). R is the Pearson’s correlation coefficient and RMSE is the root mean squared error given in kcal mol-1.

Coefficients of the terms obtained for the iPPI-specific scoring functions trained with MLR.

Correlation plot of predicted and predicted binding affinity by MLR (left) and SMOReg (right) specific scoring functions for iPPIs using one solvation term evaluated on the independent test set for iPPIs (N = 15). R is the Pearson’s correlation coefficient and RMSE is the root mean squared error given in kcal mol-1.

## Section: Results › Virtual screening

In general, the DockTScore functions performed well in virtual screening experiments for the proteases (Table 5 and Fig. 5). According to the results, the best models achieved AUC ROC values better than 0.70 in most of the cases, while the early recognition of active compounds according to the EF1% and the BEDROC values was variable between the different proteases studied, keeping in mind that BEDROC100 is very exigent for the early recognition of actives. Following the same trend observed for the binding affinity prediction, the nonlinear models generally performed better than the MLR models in terms of the screening success. Best results were obtained when using the specific scoring functions for proteases with the SMOreg model being the best-performing scoring function to distinguish actives from decoys. As an exception, the general and target-specific scoring functions exhibited low predictive performance for the TRYB1 target, with AUC ROC values lower than 0.651, a maximum EF1% only of 8, BEDROC20 of 0.203, BEDROC100 of 0.167. In this case, the accuracy is very low, taking into consideration that depending on the library size, often one can screen experimentally about 1% of the in silico screened compounds. The TRYB1 is a particular case, its binding site is remarkably exposed to the solvent. It is located in the interface of the two TRYB1 monomers belonging to the active tetramer8 sharing thus PPI-like properties. The co-crystallized ligand is bound with only one “frozen” rotatable bond in the dimer out of four rotatable bonds (Fig. 6). Therefore, we also evaluated the performance of the DockTScore PPI-specific scoring functions on the TRYB1 target (Fig. 7). Interestingly, the PPI-specific MLR scoring function outperformed the other scoring functions evaluated (i.e., general and protease-specific, linear and nonlinear), achieving an AUC ROC curve of 0.762 (SMOregprotease was 0.651), EF1% = 15.626 (SMOregprotease was 7.473), BEDROC20 = 0.291 (SMOregprotease was 0.203) and BEDROC100 = 0.272 (SMOregprotease was 0.167).Table 5Screening success of the general and target-specific scoring functions trained with MLR, SMOreg and RF for the FA7, RENI, TRYB1 and UROK datasets from DUD-E. ac, dec and tot are the number of active, decoy compounds and the total number of molecules in the final dataset (i.e., compounds that were docked and rescored with DockThor and DockTScore, respectively). Only the top-scored protonation state of a compound according to each scoring function (SF) was kept.TargetMetricsGeneral SFsProtease-specific SFsMLRSMOregRFMLRSMOregRFFA7AUC0.7890.8600.8750.8180.8930.869ac = 112EF1% (max = 52.973)8.9799.8768.97912.57017.05917.059dec = 5,821BEDROC200.2990.3460.3280.3500.4780.397tot = 5,933BEDROC1000.1810.1810.1650.2300.3330.310RENIAUC0.7860.7690.7630.8070.7710.782ac = 73EF1% (max = 86.425)16.46220.57710.97517.83416.4628.231dec = 6,236BEDROC200.3000.3340.2710.3490.3460.268tot = 6,309BEDROC1000.2530.2810.1550.2830.2070.119TRYB1AUC0.6190.6490.6140.6510.6510.633ac = 147EF1% (max = 51.633)1.3591.3592.0384.0767.4738.153dec = 7,443BEDROC200.0990.1030.0800.1410.2030.169tot = 7,590BEDROC1000.0370.0400.0460.0800.1670.167UROKAUC0.7400.7740.7750.7620.8140.788ac = 129EF1% (max = 69.837)7.7608.5366.20811.64014.74310.088dec = 8,880BEDROC200.2620.3060.2950.2950.3520.283tot = 9,009BEDROC1000.1230.1470.1180.1790.2320.182Figure 5AUC ROC curves of the general (left) and protease-specific scoring functions (right) trained with MLR, SMOreg and RF for the FA7 (A), RENI (B), and UROK (C) datasets from DUD-E.Figure 6Surface representation of the binding sites of the proteases (A) FA7, (B) UROK, (C) RENI, and (D) TRYB1 colored by chain. The co-crystallized ligand is represented as sticks.Figure 7AUC ROC curves of the protease-specific (left) and PPI-specific (right) scoring functions trained with MLR, SMOreg and RF for the TRYB1 datasets from DUD-E.

The screening of actives and inactives on the two PPIs datasets resulted in AUC values better than 0.70 for the two targets for almost all scoring functions (Table 6 and Fig. 8), while the early recognition problem was successfully addressed only for the Bcl2-like system, reaching high BEDROC values of 0.474 (α = 20) for SMOreg and 0.539 (α = 100) for MLR. For the Bcl2-like protein/BAX system, the SMOreg scoring functions generally outperformed the other machine learning methods, whereas the PPI-specific scoring functions improved the EF1% and BEDROC for all algorithms. Interestingly, the linear PPI-specific scoring function, with a satisfactory AUC ROC value of 0.709, obtained the best EF1% value and the highest BEDROC100 value of 0.539. In the case of MDM2 target, the nonlinear general scoring functions outperformed the specific models in terms of AUC ROC, whereas the RF-based achieved the best overall screening performance. However, for this target all methods exhibited insufficient early recognition capacity according to the EF1% and the BEDROC values.Table 6Screening success of the general and PPI-specific scoring functions trained with MLR, SMOreg and RF evaluated on the Bcl2-like protein/BAX and MDM2/p53 datasets. ac, inac and tot are the number of active, inactive compounds and the total number of molecules in the final dataset (i.e., compounds that were docked and rescored with DockThor and DockTScore, respectively). Only the top-scored protonation state of each compound according to each scoring function (SF) was kept.TargetMetricsGeneral SFsPPI-specific SFsMLRSMOregRFMLRSMOregRFBcl2-like protein/BAXAUC0.7550.8380.7400.7090.8010.716ac = 98EF1% (max = 51.510)22.66420.60420.60429.87623.69522.664inac = 4,950BEDROC200.3700.3750.3300.4710.4740.418tot = 5,048BEDROC1000.3860.3680.3780.5390.4450.430MDM2/p53AUC0.7410.7910.7940.7360.6540.553ac = 114EF1% (max = 50.991)4.4004.4006.1542.6371.7585.275inac = 5,699BEDROC200.2040.2510.2620.1630.1140.117tot = 5,813BEDROC1000.0100.1120.1240.0680.0420.090Figure 8AUC ROC curves of the general (left) and PPI-specific (right) scoring functions trained with MLR, SMOreg and RF for the Bcl2-like/BAX (A) and MDM2/p53 (B) datasets.

In addition to the proteases and PPIs targets, we also evaluated the performance of our general scoring functions trained with MLR, SMOreg and RF on three protein kinases datasets taken from DUD-E. Kinases are considered as challenging targets mainly due to binding site flexibility, which frequently leads to induced-fit effects due to ligand binding. Although DockTScore is not developed to deal with the receptor flexibility, our scoring functions exhibited satisfactory performances for two out of three kinases in virtual screening experiments, with AUC ROC values higher than 0.745 (Table 7 and Fig. 9). It is interesting to note that for AKT2 and MK01 targets, the MLR function showed better values for early the recognition metrics (e.g., EF, BEDROC20 and BEDROC100) than the SMOreg (AKT2and MK01) and RF (only for MK01) nonlinear functions. However, for the KIT target all the functions achieved insufficient performance for all evaluated metrics. It is important to note that in the screening experiments, we used a softened version of the MMFF94S Buf-14-7 force field to implicitly account for the protein flexibility to some extend explicitly permitting small clashes by reducing the repulsive energy between the protein–ligand atoms. However, the use of strategies that account for large movements of the binding site, such as ensemble docking with more than one representative structure of the protein, might be necessary to achieve better screening results on highly flexible systems such as kinases. Table 7Screening success of the general scoring functions trained with MLR, SMOreg and RF evaluated on the AKT2, KIT, and MK01 datasets from DUD-E. ac, dec and tot are the number of active, decoy compounds and the total number of molecules in the final dataset (i.e., compounds that were docked and rescored with DockThor and DockTScore, respectively). Only the top-scored protonation state of each compound according to each scoring function (SF) was kept.TargetMetricsGeneral SFsMLRSMOregRFAKT2AUC0.7690.8000.814ac = 116EF1% (max = 60.414)24.16615.53513.809dec = 6,892BEDROC200.4210.3780.379tot = 7,008BEDROC1000.3940.2880.269KITAUC0.6400.6350.657ac = 166EF1% (max = 63.934)3.0162.4135.428dec = 10,447BEDROC200.1480.1460.176tot = 10,613BEDROC1000.0630.0430.090MK01AUC0.7860.7660.745ac = 78EF1% (max = 59.308)10.31412.8937.736dec = 4,548BEDROC200.3520.3640.340tot = 4.626BEDROC1000.1530.2200.193Figure 9AUC ROC curves for the general scoring functions trained with MLR, SMOreg and RF evaluated on the AKT2, KIT and MK01 kinase datasets from DUD-E.

Screening success of the general and target-specific scoring functions trained with MLR, SMOreg and RF for the FA7, RENI, TRYB1 and UROK datasets from DUD-E. ac, dec and tot are the number of active, decoy compounds and the total number of molecules in the final dataset (i.e., compounds that were docked and rescored with DockThor and DockTScore, respectively). Only the top-scored protonation state of a compound according to each scoring function (SF) was kept.

AUC ROC curves of the general (left) and protease-specific scoring functions (right) trained with MLR, SMOreg and RF for the FA7 (A), RENI (B), and UROK (C) datasets from DUD-E.

Surface representation of the binding sites of the proteases (A) FA7, (B) UROK, (C) RENI, and (D) TRYB1 colored by chain. The co-crystallized ligand is represented as sticks.

AUC ROC curves of the protease-specific (left) and PPI-specific (right) scoring functions trained with MLR, SMOreg and RF for the TRYB1 datasets from DUD-E.

Screening success of the general and PPI-specific scoring functions trained with MLR, SMOreg and RF evaluated on the Bcl2-like protein/BAX and MDM2/p53 datasets. ac, inac and tot are the number of active, inactive compounds and the total number of molecules in the final dataset (i.e., compounds that were docked and rescored with DockThor and DockTScore, respectively). Only the top-scored protonation state of each compound according to each scoring function (SF) was kept.

AUC ROC curves of the general (left) and PPI-specific (right) scoring functions trained with MLR, SMOreg and RF for the Bcl2-like/BAX (A) and MDM2/p53 (B) datasets.

Screening success of the general scoring functions trained with MLR, SMOreg and RF evaluated on the AKT2, KIT, and MK01 datasets from DUD-E. ac, dec and tot are the number of active, decoy compounds and the total number of molecules in the final dataset (i.e., compounds that were docked and rescored with DockThor and DockTScore, respectively). Only the top-scored protonation state of each compound according to each scoring function (SF) was kept.

AUC ROC curves for the general scoring functions trained with MLR, SMOreg and RF evaluated on the AKT2, KIT and MK01 kinase datasets from DUD-E.

## Section: Discussion

We validated our physics-based terms for the general scoring functions using MLR. Despite its simplest form, MLR has the advantage to provide practical insights into relationships between the predicted binding affinity and the individual contribution of each specific term to the scoring function. In this work, all decisions regarding the selection of terms and machine-learning algorithms were made based on cross-validation experiments on the training set. The strategy of selecting random and independent test sets as employed here is particularly important in order to avoid performance overestimation. The performance of binding affinity prediction of the DockTScore general scoring functions are comparable with other well-known empirical scoring functions also tested on the v2013 PDBBind core set, e.g., X-score::HMScore (R = 0.644)57, Surflex-Dock (R = 0.388)73, VinaRF20 (R = 0.686)74, and RF::VinaElem (R = 0.752) (Fig. 10). We obtained better performance on the carefully prepared core set compared to the random test set. One reason is that the selection of the complexes to form the core set ensured that all protein families in this benchmarking set were also present in the training set. Also, we believe that a correct preparation of the system, like the protonation state assignment as done for the core set, is important for proper binding energy prediction and a reliable assessment of scoring functions based on a more sophisticated protein–ligand interactions description.Figure 10Scoring power of DockTScore linear and nonlinear models compared to the scoring functions evaluated on the core set 2013. Performances collected from the literature: BT-Score75, CompSPA76, AutoDockHybrid23, and the remaining were recalculated from raw data in the recent work of T. Gaillard77. Nonlinear models are highlighted with a star. Scoring functions with Pearson’s correlation coefficients higher or equal than 0.7 are colored purple and those lower than or equal to 0.4 are colored red.

Interestingly, the RF-Score::VinaElem (R = 0.752)78, a nonlinear scoring function based on 36 element-element distance counts, the five Vina scoring function energy terms and the number of rotatable bonds in the ligand, showed highest performance in comparison with other well-established scoring functions validated on the same v2013 core set39. On the other hand, it has been recently suggested that linear scoring functions, which can be less-accurate for binding affinity prediction but are composed of meaningful protein–ligand interaction terms, can be more robust than nonlinear scoring functions based only on element-element distance counts4. Definitely, element-element pair approaches are less sensitive to the proper dataset preparation, discarding the necessity of the time-consuming task of a careful assignment of the protonation states and atom types. However, scoring functions based on the calculation of physics-based binding energy terms might capture free energy changes arising from subtle protein–ligand interaction changes, useful particularly for hit-to-lead optimization.

It is widely recognized that target-specific scoring functions increase the efficiency of virtual screening exercises21,24,27. Different targeted docking-scoring strategies have been employed during the last decade. Some recent studies focused on combining scoring and pharmacophore/fingerprint filtering showed to improve target-specific pose/ligand selection22,79,80. We decided to develop new target-specific scoring functions for two protein classes to directly improve the prediction of the binding affinity by considering physics-based protein–ligand interaction terms. We obtained a remarkable improvement for the best nonlinear scoring function specific for PPIs (i.e., the SMOReg model) compared to the general scoring function, achieving a significantly higher performance R = 0.613 against R = 0.431 obtained by the SMOReg general scoring function. For protease, such direct comparison is not reliable since most of the protease complexes present in the respective test set were also present in the training set used to derive the general scoring functions. Specific scoring functions have already been developed for well-established key protease targets as HIV-1 protease28 and their performances are comparable with our SMOreg models. The advantage of our targeted scoring functions for proteases compared to the above-cited studies is the physical interpretability of the terms describing the protein–ligand interactions and good performances on virtual screening experiments evaluated with AUC ROC, EF1% and BEDROC metrics for the screening assessment.

Despite the insufficient accuracy exhibited by our linear scoring function specific for iPPIs on the independent test set, it served as a basis for the development of nonlinear models using SMOReg and RF techniques. As expected, the nonlinear scoring function specific for iPPIs, in particular SMOReg, showed a significant improvement of the predictive performance when compared with the MLR model in terms of binding affinity prediction. However, analyzing the virtual screening metrics for the Bcl2 target, we observe distinct results. The AUC values obtained using the SMOReg specific functions are better than the values obtained using MLR specific ones, yet the MLR specific function outperformed following the early recognition metrics (principally for EF1% and BEDROC 100). Thus, both the affinity prediction and ranking of compounds are important to properly evaluate the scoring functions performance. Our PPI-specific scoring functions were trained with 45 different PPI complexes covering thus a larger PPI interaction space than the previously used one for the only one reported linear scoring function specific for iPPIs HADDOCK2P2I36. The two PPI-specific scoring functions SMOReg and HADDOCK2P2I seem to perform similarly in terms of binding affinity prediction, yet the studies have been done on different PPI targets. To the best of our knowledge, the present SMOReg DockTScore is the first reported nonlinear scoring function tailored for the iPPI class that facilitates further optimization of the terms and the machine-learning algorithm used for training. In addition, the screening results obtained for the two PPI systems indicate that our PPI-specific scoring function trained with MLR is sufficiently robust to be used in virtual screening experiments, despite being trained with a small training set. Taking into consideration the very few scoring functions dedicated to score properly inhibitors of PPI both HADDOCK2P2I and DockTScore scoring functions can be very helpful e.g., for consensus scoring strategies. Furthermore, the growth of the number of experimentally derived iPPI structures available with associated affinity data enables the further development of more robust scoring functions specific for PPIs.

The variable performances achieved by the DockTScore models on the screening validation for the three different classes of proteins (e.g., proteases, PPIs and kinases) are in agreement with other works published in the literature showing that the accuracy of scoring functions is strongly target-dependent. Further, although our scoring functions consider most of the interactions key for ligand binding, yet we do not take into account some contributions like the vibrational entropy16 or particular cases as water molecules present in the binding pocket. The vibrational entropy is strongly related to the protein flexibility and to solvent entropy, and their precise estimation is not evident to be included in classical scoring functions. Other approaches as molecular dynamics or normal mode analysis can help to resolve such problems, however they are unpractical for a huge number of ligands and thus they are out of the scope of this work. Kinases are known to be very flexible proteins, and in our study KIT is the kinase protein for which our models exhibited the lowest performances on both AUC ROC and early recognition capacity evaluated through EF1% and BEDROC. The protein conformation of KIT provided by the DUD-E database and used here as the reference structure is complexed with the kinase inhibitor sunitinib. That KIT state corresponds to a more closed conformation of the ATP-binding site. The superposition of the autoinhibited KIT complexed with sunitinib (PDB code 3G0E) and the KIT-ponatinib complex (PDB code 4U0I), ponatinib being larger than sunitinib, shows an induced inactive DFG-out conformation of the enzyme, illustrating thus two possible distinct conformations adopted by the enzyme due to different ligands (Figure S1). Such results reinforce the importance of a careful selection of the receptor conformation to be used for virtual screening campaigns and the consideration of the protein flexibility to some extent81.

Next, many inhibitors of proteases such as TRYB1 and UROK are known to displace water molecules interacting with catalytic residues of the binding site, however, in some cases such molecules can serve as a bridge between the receptor and the ligand. The analysis of the nine experimental complexes used in the virtual screening experiments showed that some of them contain ligands able to displace water molecules (e.g., the proteases) and/or contain bridging waters in the experimental structure of the protein used in the virtual screening experiments (e.g., FA7, TRYB1, and MDM2). In the case of MDM2-like protein, there is a complex network of water molecules mediating hydrogen bonds with the receptor important for the ligand binding. Such data support the importance of the enthalpic and entropic contributions of the water molecules in the binding pocket for the binding energy. The consideration of the contribution arising from bridged water molecules is a complex problem usually treated with more sophisticated methods that take into account the flexibility of the entire system and explicit water molecules. We have previously developed the AMMOS2 web server82, which permits to take into consideration the presence of explicit water molecules in the binding pocket in order to optimize the predicted protein–ligand interactions.

The better performance of our MLR scoring function specific for PPIs on the protease TRYB1 dataset indicates that it could be applied on targets with similar profiles with those observed for PPI interfaces, such as those with highly solvent-exposed binding sites. We have recently reported similar observations when analyzing solvent-exposed co-crystallized ligands to support the design of novel protein–protein interaction inhibitors83. Our scoring function specific for PPIs also reinforces the fact that nonlinear scoring functions are more dependent on larger training sets, while robust linear models can be developed even when scarce data for training is available. Future growth of data for new PPI interfaces including dimer interfaces will allow to develop more robust nonlinear scoring functions specific for protein targets with binding site profiles similar to those found in PPIs.

Scoring power of DockTScore linear and nonlinear models compared to the scoring functions evaluated on the core set 2013. Performances collected from the literature: BT-Score75, CompSPA76, AutoDockHybrid23, and the remaining were recalculated from raw data in the recent work of T. Gaillard77. Nonlinear models are highlighted with a star. Scoring functions with Pearson’s correlation coefficients higher or equal than 0.7 are colored purple and those lower than or equal to 0.4 are colored red.

## Section: Conclusion

In this work, we developed general and target-specific scoring functions using physics-based features for predicting binding affinities of protein–ligand complexes. Target-specific scoring functions were derived to account for binding characteristics specific for a target class of interest, focusing here on proteases and protein–protein interactions (PPIs). With regard to the increasing interest toward targeting PPIs by small-molecule inhibitors, here we reported the first and well-performing SVM-based scoring function specific for PPI binding sites that can serve as a valuable tool for discovering new iPPIs. Improved solvation and ligand torsional entropy terms were implemented in DockTScore for a reliable representation of ligand binding. DockTScore scoring functions demonstrated to be competitive with state-of-the-art scoring functions in reported benchmarking studies. As expected, the nonlinear scoring functions generally performed better than the respective MLR models. Finally, we demonstrated that the scoring functions developed in this work also exhibited good performances on virtual screening experiments to distinguish actives from inactive/decoy compounds for various protein targets. DockTScore functions are independent of docking software and can be used for affinity prediction or consensus scoring to improve the performance of docking-scoring approaches on virtual screening experiments. Currently, the MLR DockTScore predictions are provided for the DockThor docking at the DockThor-VS web server (available at www.dockthor.lncc.br). All the developed scoring functions in this work are under implementation in a dedicated web server.

## Section: Supplementary Information

Supplementary Information.

## Section: Supplementary Information

Supplementary Information.

Supplementary Information.


---

# Novel Development of Predictive Feature Fingerprints to Identify Chemistry-Based Features for the Effective Drug Design of SARS-CoV-2 Target Antagonists and Inhibitors Using Machine Learning

- **Authors:** Kelvin Cooper, Christopher Baddeley, Bernie French, Katherine Gibson, James Golden, Thiam Lee, Sadrach Pierre, Brent Weiss, Jason Yang
- **Issuer:** ACS omega
- **Type:** Scientific article
- **Published:** 2021-02-05
- **Language:** en
- **DOI:** 10.1021/acsomega.0c05303
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33644594/
- **Licence:** CC-BY-NC-ND

## Section: Abstract

AbstractA unique approach to bioactivity and chemical data curation coupled with random forest analyses has led to a series of target-specific and cross-validated predictive feature fingerprints (PFF) that have high predictability across multiple therapeutic targets and disease stages involved in the severe acute respiratory syndrome due to coronavirus 2 (SARS-CoV-2)-induced COVID-19 pandemic, which include plasma kallikrein, human immunodeficiency virus (HIV)-protease, nonstructural protein (NSP)5, NSP12, Janus kinase (JAK) family, and AT-1. The approach was highly accurate in determining the matched target for the different compound sets and suggests that the models could be used for virtual screening of target-specific compound libraries. The curation-modeling process was successfully applied to a SARS-CoV-2 phenotypic screen and could be used for predictive bioactivity estimation and prioritization for clinical trial selection; virtual screening of drug libraries for the repurposing of drug molecules; and analysis and direction of proprietary data sets.

## Section: Introduction

The zoonotic transmission and emergence of the new coronavirus, severe acute respiratory syndrome due to coronavirus 2 (SARS-CoV-2), in the Hubei Province of China in late November of 20191 has triggered a global pandemic that has infected over 84 million people and killed over 1.8 million people.2 The sequence of the SARS-COV-2 virus was published in January 2020, and since then much of the genome function has been elaborated and published.3,4 The worldwide scientific community has responded to the COVID-19 pandemic with an intense focus on discovering and testing of therapeutic modalities and that focus is reflected in the rapid vaccine development,5 a large volume of publications,6,7 and multiple clinical studies.8,9 Much of the global effort to address COVID-19 by many organizations and research and academic institutes has been accompanied by free and open access to publications and data from the scientific efforts.

In concert with this theme of open access, CAS released a database of 50 000 compounds based on 100 known antivirals.10 The CAS COVID-19 Antiviral Candidate Compounds Dataset contained CAS REGISTRY numbers, chemical structures, and chemical properties associated with each compound. As a follow up to that data release, we have undertaken a program to conduct analyses of the 50 000 compounds with the goal of providing a curated resource to assist drug discovery and development researchers in the hunt for COVID-19 therapeutants. Specifically, the team aimed to provide access to curated CAS chemical and biological data with potential links to COVID-19 targets and also provide artificial intelligence (AI)-based analysis of the data sets to create predictive connections and associations.

Quantitative structure–activity relationship (QSAR) development has been employed as a critical tool in medicinal chemistry for almost 70 years with the pioneering work of Corwin Hansch as the first exploration of the association of biological activity with physicochemical properties of molecules.11 The field of QSAR has evolved and expanded considerably since then and has been reviewed in multiple articles and books with the 2013 review by Cherkasov et al. being a useful look at the history and future of QSAR.12 Since that review, the application of machine learning techniques has allowed the rapid analyses of large data sets to build predictive models and a wide range of approaches to chemoinformatic classifications have been used.13−15

Indeed, artificial intelligence (AI) has been applied to the field of drug discovery for drug repurposing,16 for multiobjective lead optimization,17 in the design-make-test-analyze cycle for reducing cycle times,17 and in predicting protein–protein interactions using machine learning techniques such as classification or supervised learning approaches.18 In addition, several groups have employed AI-based approaches to the COVID-19 pandemic, in particular, with the aim of repurposing existing drugs to treat the disease,19 including most recently a machine learning QSAR study of 3-chymotrypsin-like proteinase (3CLpro) and RdRp inhibitors.20

In this study, the initial target selection was driven by the desire to map small molecule to target interactions across multiple stages of SARS-CoV-2 infection.21 Thus, we focused on the selection of targets that were involved in (1) viral entry; (2) viral replication, budding, and release; (3) host cell immune responses related to the late-stage cytokine storm; and (4) organ damage.22,23 Additional consideration was given to the quality of the biological data available, the size of the data sets for each potential target, the range of bioactivity in those data sets, and whether there were ongoing clinical trials related to the target.

## Section: Results and Discussion

For a detailed description of the curation process, see the Materials and Methods section.

Binary confusion matrix (a) and the predicted property fingerprint (b) for plasma kallikrein inhibitors. The confusion matrix labels are 0 for inactive and 1 for active with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

Ternary confusion matrix (a) and predicted feature fingerprints (PFF) (b) for HIV protease inhibitors. The confusion matrix labels are 1 for weakly active, 2 for moderately active, and 3 for highly active with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

Binary confusion matrix (a) and predicted feature fingerprint (b) for NSP5 inhibitors. The confusion matrix labels are 0 for inactive and 1 for active with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

Binary confusion matrix (a) and predicted feature fingerprint (b) for NSP12 inhibitors. The confusion matrix labels are 0 for inactive and 1 for active with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

Confusion matrices and predictive feature fingerprint characteristics for AT-1 binary classification, panels (a) and (c), and AT-1 ternary classification, panels (b) and (d). The binary confusion matrices (a) labels are 0 for inactive and 1 for active with true label on the y-axis and predicted label on the x-axis. The ternary confusion matrix (b) labels are 3 for highly active, 2 for moderately active, and 1 for weakly active. The feature importance plots (b) and (d) show the top 15 features in increasing order of importance from top to bottom.

Predicted vs actual activity grades for the six FDA-approved AT-1 antagonists.

Distribution of bioactivity for the 6638 compounds across the JAK family.

Ternary confusion matrices and predictive feature fingerprint characteristics for JAK-1—panels (a) and (d), JAK-2—panels (b) and (e), and JAK-3—panels (c) and (f). The confusion matrix labels are 1 for weakly active, 2 for moderately active, and 3 for highly active with true label on the y-axis and predicted label on the x-axis. The feature importance plots (d), (e), and (f) show the top 15 features in increasing order of importance from top to bottom.

Confusion matrix (a) and predictive feature fingerprint characteristics (b) for JAK selectivity. The confusion matrix labels are 1 for JAK-1, 2 for JAK-2, 3 for JAK-3, and 4 for nonselective with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

Predicted vs actual selectivity for the four FDA-approved drugs and eight clinical candidates with activity against the JAK family.

Confusion matrix (a) and predictive feature fingerprint characteristics (b) for classification of AT-1, HIV protease, and JAK family targets. The confusion matrix labels are 1 for AT-1, 2 for HIV protease, and 3 for JAK family with true label on the y-axis and the predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

Binary confusion matrix (a) and predictive feature fingerprint characteristics (b) for classification of activity in a SARS-CoV-2-induced CACO-2 cell cytotoxicity assay. The confusion matrix labels are 0 for inactive and 1 for active with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

## Section: Results and Discussion › Kallikrein

SARS-CoV-2 gains entry to the host cells through the docking of the spike (S) protein on the surface of the virus with the ACE-2 receptor of host cells. The S-protein is then cleaved at the S1–S2 site by the serine protease transmembrane serine protease type 2 (TMPRSS2) and kallikrein 13, allowing the virus to unfold and enter the host cell.24 Bioactivity values were available for the kallikrein family with plasma kallikrein having the largest and best spread of activity data. Since the serine protease active site of the kallikreins is conserved, a data set of 1050 unique compounds active against plasma kallikrein was compiled from the ChEMBL database and submitted to the model process. The biological activities were converted through the series of manipulations to activity “grades” that could be cross-compared (see Scheme 1).

The activity classification models were trained on physiochemical features from CAS and ChEMBL and engineered features from simplified molecular-input line-entry system (SMILES) strings as well as structural features such as azoles, sulfonamides, nitriles, trifluoro groups, and carboxyl groups to provide a total of 110 properties for inclusion. A binary classification was the best at distinguishing between active and weakly active compounds with an accuracy of 73% at predicting inactive compounds vs 100% at predicting active compounds (see Figure 1a). Features that predict for “druglike” properties (hydrogen donor and acceptor counts, Alog P, and quantitative estimate of drug likeness (QED) weighted) were key characteristics for the plasma kallikrein model (see Figure 1b), with predicted densities, predicted pKas, and polar surface area (PSA) among the most important structural features.

In a structure-based cluster analysis of the test data set, the 210 compounds were clustered into 10 clusters, with 6 clusters having less than 10 representatives (see Table 1 for the total counts in the 10 clusters and their respective successful prediction counts and percentages).

The compounds associated with each cluster were mapped into the confusion matrix to assess the distribution of the cluster over true-positive (TP), true-negative (TN), false-positive (FP), and false-negative (FN) labels. This would potentially indicate the degree of bias of a cluster to yield false results (see Table 2).

The analysis shows that clusters 1 and 3 (center structures 1 and 2, respectively) have a high false-positive rate for inactive members of the clusters (58 and 67%, respectively), but the remaining clusters have a good to excellent predictability for low activity. For example, clusters 2, 4, and 6 (center structures 3, 4, and 5) have high predictability for low activity at 97, 69, and 58%, respectively. In addition, the model has an excellent predictivity for high activity at 100% for clusters 1 and 6 (center structures 1 and 5).

For a detailed description of the curation process, see the Materials and Methods section.

Binary confusion matrix (a) and the predicted property fingerprint (b) for plasma kallikrein inhibitors. The confusion matrix labels are 0 for inactive and 1 for active with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

## Section: Results and Discussion › Human Immunodeficiency Virus (HIV) Protease

Once the SARS-CoV-2 virus has gained entry to the cell, the viral RNA is translated to a set of large polyproteins that are then processed into the proteins required for viral replication. Nonstructural protein (NSP)3 also known as papain-like proteinase (PLpro) and NSP5, also known as 3-chymotrypsin-like proteinase (3CLpro), are proteinases responsible for the processing of polyprotein ORF-1. Inhibition of one or both of these enzymes should result in reduced viral translation and consequently a lower viral load and potentially milder disease. Although the HIV-protease inhibitors were designed to inhibit the HIV aspartyl protease, there were indications that some members of the class are thought to interact with NSP3 and/or NSP5.25,26 Accordingly, we assembled a data set from the ChEMBL database with 3844 unique compounds and bioactivity data points.

The biological activities were converted through the series of manipulations to activity “grades” that could be cross-compared (see Scheme 1). The activity classification models were trained on physiochemical features from CAS and ChEMBL and engineered features from SMILES strings as well as structural features such as azoles, sulfonamides, nitriles, trifluoro groups, and carboxyl groups to provide a total of 110 properties for inclusion.

A ternary model was the best at distinguishing inactive, moderately active, and highly active compounds in the HIV protease family. The model provides a 73% success rate at predicting poorly active compounds; a 57% probability of predicting moderate activity; and an 81% success rate at predicting the highly active compounds (see Figure 2a). Features that predict for “druglike” properties (Alog P, CX log D, QED weighted, hydrogen donor–acceptor counts, and freely rotatable bonds) were among the most important characteristics for the HIV protease model (see Figure 2b), with predicted densities, molar volumes, and PSA among the most important structural features.

In a structure-based cluster analysis of the hold-out data set, the 769 compounds can be clustered into 22 distinct clusters with 4 clusters containing over 35 unique compounds (see Table 3, which shows the total counts for the 10 major clusters and their respective successful prediction counts and percentages).

The compounds associated with each cluster were mapped into the confusion matrix to assess the distribution of the cluster over true-positive (TP), true-negative (TN), false-positive (FP), and false-negative (FN) labels. This would potentially indicate the degree of bias of a cluster to yield false results (see Table 4).

The largest cluster, cluster 1 with 471 unique compounds, is the prototypical protease inhibitor with center structure 6 and, as with the other highly active clusters, clusters 2, 6, and 10 (center structures 7, 8, and 9); the model was highly predictive across the activities with moderate activity being the most difficult to accurately predict.

Ternary confusion matrix (a) and predicted feature fingerprints (PFF) (b) for HIV protease inhibitors. The confusion matrix labels are 1 for weakly active, 2 for moderately active, and 3 for highly active with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

## Section: Results and Discussion › NSP5—3CLpro

As discussed previously, NSP5, also known as 3-chymotrypsin-like proteinase (3CLpro), is one of the proteinases responsible, in part, for the processing of polyprotein ORF-1. Inhibition of this enzyme should result in reduced translation and consequently a lower viral load and potentially milder disease. Accordingly, we assembled a data set of 303 unique compounds and bioactivity data points from the CAS REGISTRY.

The biological activities were converted through the series of manipulations to activity “grades” that could be cross-compared (see Scheme 1). The activity classification models were trained on physiochemical features from CAS and ChEMBL and engineered features from SMILES strings as well as structural features such as azoles, sulfonamides, nitriles, trifluoro groups, and carboxyl groups to provide a total of 110 properties for inclusion.

A binary classification was the best at distinguishing between active and weakly active compounds with an accuracy of 83% at predicting inactive compounds vs 100% at predicting active compounds (see Figure 3a). Features that predict for “druglike” properties (Alog P and QED weighted) were among the most important characteristics for the NSP5 model (see Figure 3b), with predicted molar and mass solubilities at pH 1, 7, and 10 among the most important structural features.

In a structure-based cluster analysis of the hold-out data set of 61 compounds, nine distinct clusters were formed with two clusters containing the most compounds (see Table 5, which shows the total counts for the nine major clusters and their respective successful prediction counts and percentages).

The compounds associated with each cluster were mapped into the confusion matrix to assess the distribution of the cluster over true-positive (TP), true-negative (TN), false-positive (FP), and false-negative (FN) labels. This would potentially indicate the degree of bias of a cluster to yield false results (see Table 6).

In general, the model makes highly accurate predictions across all structural classes indicating that there is no structural bias. The most populated clusters, 3 and 6 (center structures 10 and 11), have a high predictivity for their low activity, and cluster 5 (center structure 12) has excellent predictivity for low and high activity.

Binary confusion matrix (a) and predicted feature fingerprint (b) for NSP5 inhibitors. The confusion matrix labels are 0 for inactive and 1 for active with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

## Section: Results and Discussion › NSP12—RNA-Dependent RNA Polymerase

The SARS-CoV-2 virus genome encodes an RNA-dependent RNA polymerase (RdRp), named NSP12, that is essential for viral replication. The NSP12 protein requires a docking interaction with the viral proteins NSP7 and NSP8 for enzymatic function, and X-ray data for remdesivir bound into the active site has been published.27 Although bioactivity data for the SARS-CoV-2 RdRp has not been published, the sequence, functionality, and active site configuration of several other RdRps overlap with the SARS-CoV-2 sequence/functionality.28 We assembled a data set of 2888 unique compounds with bioactivity data points from the CAS database. The biological activities were converted through the series of manipulations to activity “grades” that could be cross-compared (see Scheme 1). The activity classification models were trained on physiochemical features from CAS and ChEMBL and engineered features from SMILES strings as well as structural features such as azoles, sulfonamides, nitriles, trifluoro groups, and carboxyl groups to provide a total of 110 properties for inclusion.

A binary classification was the best at distinguishing between active and weakly active compounds with an accuracy of 85% at predicting inactive compounds vs 83% at predicting active compounds (see Figure 4a). Features that predict for “druglike” properties (Alog P and CX log P) were among the most important characteristics for the NSP12 model (see Figure 4b), with predicted densities molar volumes, and PSA among the most important structural features. Interestingly, the predicted molar and mass solubilities at pH 7 were also in the top 15 predictive features of the model.

In a structure-based cluster analysis of the hold-out data set of 575 compounds, 13 distinct clusters were formed with 4 clusters containing 20 or more unique compounds (see Table 7, which shows the total counts for the top 10 major clusters and their respective successful prediction counts and percentages). In general, the model makes very accurate predictions.

The compounds associated with each cluster were mapped into the confusion matrix to assess the distribution of the cluster over true-positive (TP), true-negative (TN), false-positive (FP), and false-negative (FN) labels. This would potentially indicate the degree of bias of a cluster to yield false results (see Table 8). Clusters 1, 2, 5, and 10 (center structures 13–16) have excellent predictivity with at least a 73% rating. Disappointingly the data set contained a disproportionate number of weakly actives, and the structural class that is closest to the antiviral remdesivir was weakly active and, not surprisingly, the model predicted weak bioactivity for remdesivir. This probably indicates a lack of suitable bioactivity data for the remdesivir-like class of molecules that could strengthen the predictability of the NSP12 model.

Binary confusion matrix (a) and predicted feature fingerprint (b) for NSP12 inhibitors. The confusion matrix labels are 0 for inactive and 1 for active with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

## Section: Results and Discussion › Angiotensin II Type-1 Receptor (AT-1)

SARS-CoV-2 gains entry to its target cell by binding to the angiotensin-converting enzyme type-2 receptor. Angiotensin levels are elevated in animal models, where the SARS-CoV S-protein is injected and the high levels could contribute to the severe lung injury in patients.29

A set of 1186 AT-1 receptor antagonists with a wide range of activities were selected for modeling from the ChEMBL database and included six known FDA-approved drugs. The biological activities were converted through a series of manipulations to activity “grades” that could be cross-compared (see Scheme 1). The activity classification models were trained on physiochemical features from CAS and ChEMBL and engineered features from SMILES strings as well as structural features such as azoles, sulfonamides, nitriles, trifluoro groups, and carboxyl groups. In the final model, 110 molecular features were chosen for each compound.

A binary model is highly predictive for highly active and poorly active compounds with the combination of CAS and ChEMBL properties giving the best predictive power: poorly active compounds were predicted with 84% success and highly active compounds were predicted with an 81% success rate (see Figure 5a). Ternary evaluation accurately predicts for a decision tree that distinguishes poorly active (88%), moderately active (60%), and highly active compounds (75%) (see Figure 5c).

The top 15 properties from the 110 that were initially selected as the most important for the model are a mixture of physicochemical and structural features (see Figure 5b,d). Features that are linked to acidic pH predictions (predicted pKas most acidic, log D at pH1, Kocs at pH1) were important, as were features linked to being “druglike” (CX log P, CX log D, and QED weighted).

In a structure-based cluster analysis of the hold-out data set of 239 compounds, 10 discrete clusters were formed with 4 of the clusters having just a single representative (Table 9 shows the total counts for the top 10 clusters and their respective successful prediction counts and percentages).

The compounds associated with each cluster were mapped into the confusion matrix to assess the distribution of the cluster over true-positive (TP), true-negative (TN), false-positive (FP), and false-negative (FN) labels. This would potentially indicate the degree of bias of a cluster to yield false results. The three largest clusters follow the general confusion matrix outcome with clusters 1, 3, and 5 (center structures 17–19 respectively) showing 50, 92, and 65% success at predicting the most active compounds (see Table 10).

A set of six Food and Drug Administration (FDA)-approved drugs (fimasartan, pratosartan, saprisartan, losartan, candesartan, and zolasartan), not included in the model’s training set, were run through the model to determine whether it could predict their bioactivities. The model was quite successful in providing a predicted activity score for each compound with a match of ±1 to the true values, with four of the six compounds having exact predicted values (see Figure 6).

Confusion matrices and predictive feature fingerprint characteristics for AT-1 binary classification, panels (a) and (c), and AT-1 ternary classification, panels (b) and (d). The binary confusion matrices (a) labels are 0 for inactive and 1 for active with true label on the y-axis and predicted label on the x-axis. The ternary confusion matrix (b) labels are 3 for highly active, 2 for moderately active, and 1 for weakly active. The feature importance plots (b) and (d) show the top 15 features in increasing order of importance from top to bottom.

Predicted vs actual activity grades for the six FDA-approved AT-1 antagonists.

## Section: Results and Discussion › Janus Kinases (JAK) 1–3

The Janus kinases are intracellular, nonreceptor tyrosine kinases that are intimately involved in the signal transduction of cytokine-mediated signals and therefore central to many immunologic and inflammatory processes. In seriously ill patients, there is an overwhelming inflammatory response, also known as the cytokine storm, which can lead to multiple organ failure and death.30−32 Several JAK inhibitors including pacritinib, baricitinib, and tofacitinib are being studied in the clinic.5

A set of 6638 JAK inhibitors with a wide and well-distributed range of activities was selected from the ChEMBL database (see Figure 7 for a Venn diagram showing the distribution of bioactivities across the three kinases). The biological activities were converted through a series of manipulations to activity “grades” that could be cross-compared (see Scheme 1). For each of the three kinases, the activity classification models were trained on physiochemical features from CAS and ChEMBL and engineered features from SMILES strings including structural features such as azoles, sulfonamides, nitriles, trifluoro groups, and carboxyl groups. In the final model, 110 molecular features were chosen for each compound.

Three models were built, and ternary classifications provided the best predictions for each of the kinases. Thus, for JAK-1, the model accurately predicts for a decision tree that distinguishes poorly active (90%), moderately active (60%), and highly active compounds (74%) (see Figure 8a); for JAK-2, the model accurately predicts for a decision tree that distinguishes poorly active (82%), moderately active (66%), and highly active compounds (81%) (see Figure 8b); and for JAK-3, the model accurately predicts for a decision tree that distinguishes poorly active (77%), moderately active (64%), and highly active compounds (84%) (see Figure 8c).

The predictive feature fingerprints of each kinase are unique, emphasizing druglike properties as the best predictors. Thus, for JAK-1, -2, and -3, 7 of the top 15 properties are the same but have different factor levels (polar surface areas, monoisotopic molecular weight, predicted pKas most acidic, molar volumes, predicted pKas most basic, Alog P, and QED weighted). JAK-1 has three unique factors (f count, hydrogen donor–acceptor sums, and CX log D), four shared with JAK-2 (densities, heavy atoms, hydrogen donor–acceptor counts, and molar intrinsic solubilities), and none shared with JAK-3. JAK-2 has two unique properties, predicted log Ds 25 °C pH 1 and n-count,33 and has four shared with JAK-1 (see above) and one shared with JAK-3 (boiling point). JAK-3 has five unique features (predicted log Ds 25 °C pH 10, and SMILES features “–”, “\[”, “\]”, and “H”).33

In a structure-based cluster analysis of the data set, the 2111 hold-out compounds (623 for JAK-1, 1236 for JAK-2, 459 for JAK-3, and 45 for JAK selectivity) can be clustered into 50 discrete clusters, with 10 of the clusters containing 91% of the data set. The compounds associated with each cluster were mapped into the confusion matrix to assess the distribution of the cluster over true-positive (TP), true-negative (TN), false-positive (FP), and false-negative (FN) labels. This would potentially indicate the degree of bias of a cluster to yield false results.

For JAK-1, the 10 top clusters (Table 11 shows the total counts for the clusters and their respective successful prediction counts and percentages) follow the general confusion matrix outcome with all clusters showing better than 67% predictability success, with the exception of clusters 6 and 9 (center structures 20 and 21). Notably, the most active compounds against JAK-1 are in clusters 5 and 15 (center structures 22 and 23), but the model is the best at predicting most active bioactivity for cluster 15 (center structure 23) (see Table 12).

For JAK-2, the 10 top clusters (Table 13 shows the total counts for the clusters and their respective successful prediction counts and percentages) follow the general confusion matrix outcome with only cluster 26 (center structure 24) showing less than 60% predictivity. Notably, the most active compounds against JAK-2 are in clusters 2, 5, 6, 11, 15, and 19 (center structures 25, 22, 20, 26, 23, and 27, respectively), but the model is the best at predicting most active bioactivity for clusters 5, 15, and 19 (center structures 22, 23, and 27) (see Table 14).

For JAK-3, the 10 top clusters (Table 15 shows the total counts for the clusters and their respective successful prediction counts and percentages) follow the general confusion matrix outcome with clusters 1, 5, 10, 15, 26, and 29 (center structures 28, 22, 29, 23, 24, and 30) showing 74% or higher success at predicting bioactivity for the compounds. Notably, the most active compounds against JAK-3 are in clusters 5, 9, 11, 15, and 29 (center structures 22, 21, 26, 23, and 30) and the model predicts their bioactivity with >85% accuracy (see Table 16), with the exception of cluster 9 (center structure 21), which is at 33%.

A smaller set of the JAK inhibitors, 971 compounds, had published bioactivity data for all three kinases, and this subset of compounds was explored as a validation tool to determine whether selectivity for one or more kinase vs the others could be modeled (see Figure 9a). Compounds were considered to be selective for one kinase over the other two if the compound showed at least 30-fold selectivity over both of the other kinases. Using this curation protocol, 198 inhibitors were chosen, with 76 compounds selective for JAK-1, 43 compounds selective for JAK-2, 54 compounds selective for JAK-3, and 25 compounds with no selectivity for one single kinase over the other two. Seventy compounds with partial selectivity for two of the kinases over the other kinase were excluded from the model. The model was built with 80% of the compounds and a hold-out set of 45 compounds was used to test the model.

The model built on this data set was able to classify compounds based on whether they were selective for JAK-1, 2, or 3 with weak ability to predict for nonselectivity (see Figure 9a). Thus, the model was able to predict JAK-1 selectivity with an 83% success rate, JAK-2 selectivity with an 89% success rate, JAK-3 selectivity with a 100% success rate, and nonselectivity with a 33% success rate. Attempts to further define the partially selective inhibitors were not successful, in part, at least, to the small n-numbers.

The set of features that the model selects to generate the quaternary plot comprise both physicochemical and structural elements. Physicochemical features that are consistent with druglike features, such as Alog P, CX Log D, QED weighted, and CX log P, are extremely important with n-count; chiral count and aromatic rings being key structural features (see Figure 9b). Given the high homology of the active sites of the JAK family, the degree of predictive success that the model achieves is remarkable.

For the selectivity data set, only eight clusters were formed with cluster 5 (center structure 22) having the highest number of compounds (see Table 17 for the total counts for the clusters and their respective successful prediction counts and percentages).

The cluster analysis follows the general confusion matrix outcome with clusters 5, 6, 11, 12, and 26 (center structures 22, 20, 26, 31, and 24) showing 75, 70, 100, and 100% success at predicting the correct selectivity for the compounds (see Table 18).

A set of four FDA-approved drugs (ruxolitinib, fedratinib, midostaurin, and nintedanib) and seven JAK clinical candidates (lestaurtinib, pelitinib, abrocitinib, PF-06651600, KW-2249, CGP-52421, and BMS-911543), which were not included in the model’s training set, were run through the model to determine whether the model could predict their selectivities. The model was quite successful in providing a predicted selectivity score for each compound with a match ±1 to the true. The model correctly predicts that lestaurtinib interacts with JAK-1, correctly predicts that pelitinib and midostaurin interact with JAK-2, correctly predicts that ruxolitinib interacts with JAK-3, and correctly predicts KW-2249 and BMS-911543 as nonselective (see Figure 10).

Distribution of bioactivity for the 6638 compounds across the JAK family.

Ternary confusion matrices and predictive feature fingerprint characteristics for JAK-1—panels (a) and (d), JAK-2—panels (b) and (e), and JAK-3—panels (c) and (f). The confusion matrix labels are 1 for weakly active, 2 for moderately active, and 3 for highly active with true label on the y-axis and predicted label on the x-axis. The feature importance plots (d), (e), and (f) show the top 15 features in increasing order of importance from top to bottom.

Confusion matrix (a) and predictive feature fingerprint characteristics (b) for JAK selectivity. The confusion matrix labels are 1 for JAK-1, 2 for JAK-2, 3 for JAK-3, and 4 for nonselective with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

Predicted vs actual selectivity for the four FDA-approved drugs and eight clinical candidates with activity against the JAK family.

## Section: Results and Discussion › Activity Classification for AT-1, JAK-1–3, and HIV Protease

After having conducted the model building for the AT-1, JAK, and HIV-protease data sets, we wanted to determine whether the three target data sets can be distinguished from each other using a random forest model. Accordingly, a ternary classification model was trained on physiochemical features from the full chemistry feature list of 110 properties. As shown in Figure 11a, the model easily distinguishes between the three data sets, accurately classifying each molecule into the correct target (98% success for AT-1, 99% for HIV protease, and 99% success for JAK family), with the primary features that distinguish the targets being heavily dominated by structural features that include the tetrazole ring, that features heavily in the AT-1 data set (see Figure 11b).

Confusion matrix (a) and predictive feature fingerprint characteristics (b) for classification of AT-1, HIV protease, and JAK family targets. The confusion matrix labels are 1 for AT-1, 2 for HIV protease, and 3 for JAK family with true label on the y-axis and the predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

## Section: Results and Discussion › Phenotypic Screening

Several independent groups have performed screening of different sets of FDA-approved drugs in SARS-CoV-2 phenotypic assays, and their data outputs have been compiled in ChEMBL and released. Three such screening exercises that measure SARS-CoV-2-induced cytotoxicity and the ability of FDA-approved drugs to prevent the cell death were considered for inclusion in the modeling effort.34−36

Ultimately, we examined the SARS-CoV-2-induced cytotoxicity of CACO-2 (human colon cell line used extensively for in vitro permeability studies). In this study, approximately 5600 FDA-approved drugs were screened in a 48 h cytotoxicity study to measure the degree of inhibition of cell death. Compounds that displayed a greater than 75% inhibition were considered active, and from the large set of FDA-approved drugs, 267 were considered active.34

We used the bioactivity data from ChEMBL, and a subset of the data was trained on physiochemical features from the set of 110 chemical properties and a hold-out set of 868 compounds were then used to establish a binary classification model that could predict whether a molecule was active or inactive in the phenotypic assay; the model was able to identify bioactivity with 65% accuracy (35% false-negative rate for inactive compounds) (see Figure 12).

Binary confusion matrix (a) and predictive feature fingerprint characteristics (b) for classification of activity in a SARS-CoV-2-induced CACO-2 cell cytotoxicity assay. The confusion matrix labels are 0 for inactive and 1 for active with true label on the y-axis and predicted label on the x-axis. The feature importance plot shows the top 15 features in increasing order of importance from top to bottom.

## Section: Discussion/Conclusions

We have used a highly methodical approach to addressing the COVID-19 pandemic challenge by dividing the life cycle of the disease into phases and identifying targets that address each stage. It was important in building the data sets on which to base the modeling to extract high-quality bioactivity data, followed by careful curation to ensure comparability of the data both within specific targets and across the targets. In addition, it was critical to include a uniform set of chemical features that are also curated to avoid repetition and redundancy in the model building. In this model building, we used highly curated chemical features available from CAS and ChEMBL and included a unique, curated SMILES feature set designed for this type of analysis. Once the data sets were assembled, we used a combination of random forest classification and structure-based cluster analyses to interpret the results.

We have found that the unique approach to data curation coupled with RF analyses produces target-specific and cross-validated predictive feature fingerprints (PFFs) that have high predictability across multiple targets: plasma kallikrein, HIV protease, NSP5, NSP12, AT-1, and the JAK family. This wide applicability to different target types (protease, RNA polymerase, G protein-coupled receptor (GPCR), tyrosine kinase, and a phenotypic assay) as well as to different chemotypes within a target is a major strength and differentiator of our methodology. Most QSAR methods, including regression analyses and principal component analysis (PCA) analyses, require a highly specific and tailored approach based on the specific target and are primarily based on a single chemotype that is active against the selected target. In addition, our methodology provides the medicinal chemist with a set of key features (the PFF) that can be used as a guide to the next round of compound design.

Our approach was also highly accurate in determining the matched target for the different compound sets, and this abilty to distinguish compounds on the basis of a target fingerprint suggests that the models could be used for AI-based sorting of chemical structures with the potential for virtual screening of compound libraries for assessing compounds for clinical trial potential.

The ability of each target model to create a binary decision tree for inactive or active compounds or a ternary decision tree for weakly active, moderately active, and highly active compounds also suggests that the models could be used for virtual screening of target-specific compound libraries to select the most active compounds for synthesis and or clinical testing. The PFFs have wide structural applicability as shown by cluster analyses of each of the data sets, and the PFFs could also be used to guide additional synthesis or virtual library creation for screening through the models.

The ability to distinguish clinical candidates in the AT-1 and JAK data sets also suggests that this methodology could be used for honing virtual libraries toward compounds with druglike characteristics.

In addition, the model process is applicable to phenotypic screening and could be used for large-scale virtual screening of compound libraries given a training set of bioactivity values. This model building process could be used for predictive bioactivity estimation and prioritization for clinical trial selection; virtual screening of drug libraries for repurposing of drug molecules; and analysis and direction of proprietary data sets.

The model building process appears to be highly reproducible and should be applicable to a wider range of targets and therapeutic areas. The successful application of this unique curation-modeling methodology could effectively reduce medicinal chemistry cycle times by 18–24 months and reduce the overall drug discovery timelines by similar amounts. Additional studies to explore the applicability of the model building process are underway and will be targeted toward establishing the complete rules-based set of medicinal chemistry descriptors for each target to aid in compound design, plus a network tool to link targets, structures, and diseases that will be used to construct a medicinal chemistry knowledge graph.

## Section: Materials and Methods › Workflow

The process workflow for the development of the models is illustrated in Scheme 2. The first step of target selection was followed by identifying molecules with bioactivity data from a variety of sources. The bioactivity data, molecule descriptors, and predicted physicochemical properties were then curated and compiled in a consolidated data set for each target. The data was partitioned into a training set for model development and a testing set for model evaluation. Next was model development, which involved designing and tuning a model to optimize its cross-validated performance on the training set. The tuned model was then further tested using a one-off hold-out test on the testing data set. A more detailed description for each step of the process follows.

## Section: Materials and Methods › Derivation of the CAS COVID-19 Antiviral Candidate Compounds Data Set

CAS scientists selected a seed list of 100 known antiviral agents with known clinical activity from the CAS REGISTRY that was expanded by a combination of a similarity search based on the Tanimoto algorithm37,38 and based on a substructure search of the seed list compound base structure. The resulting set of 65 000 compounds was trimmed to eliminate overlapping structures from the two approaches, and the resulting data set of 50 000 unique compounds has been released for open access.10

## Section: Materials and Methods › Target Selection

Target selection was driven by the desire to map small molecule to target interactions across multiple stages of SARS-CoV-2 infection.

SARS-CoV-2 host cell entry is mediated by the viral spike protein (S-protein), which docks to the angiotensin-converting enzyme type-II receptor (ACE-2). The spike protein–ACE-2 complex is then processed by transmembrane serine protease type 2 (TMPRSS2), which enables membrane fusion and the release of the viral contents into the cell.39−41 The serine protease Kallikrein 13 has also been linked to SARS-CoV-2 cell entry in cleaving the S1–S2 region of the viral spike protein.41

The virus RNA encodes at least 14 open reading frames (ORFs) that are released into the cell for translation and processing. The ORF1a/ORF1b complex, which encodes a large polyprotein, is self-processed into a series of 16 proteins that control the viral replication (nonstructural protein [NSP] 1–12, 14, and 16) and downregulation of the host interferon response (NSP13, NSP15, and ORF9b).21

Viral replication, budding, and release are controlled through a number of viral proteins that include NSP3, a papain-like protease (PLpro); NSP5, a chymotrypsin-like protease (3CLpro);42 and NSP12, the RNA-dependent RNA polymerase (RdRp).43−46 Although HIV-protease inhibitors are designed as inhibitors of the HIV aspartyl protease, there are indications that some members of the class may interact with NSP3 and/or NSP5.25,26

The release of multiple viral particles prompts the host to initiate an immune response,47 which in many patients becomes an overwhelming inflammatory response that can lead to cytokine storm, precipitating multiple organ failure and death.30−32 Among the many inflammatory mediators involved in this process, the Janus kinases are heavily implicated as they are obligatory partners in cytokine signaling.48,49

Additional consideration was given to the quality of the biological data available, size of the data sets for each potential target, range of bioactivity in those data sets, and whether there were ongoing clinical trials related to the target. Ideally, data sets of at least 1000 unique compounds with bioactivity spread evenly from mM to nM are required for the model generation to comply with an appropriate data point to feature ratio. Accordingly, we selected the following targets: plasma kallikrein; NSP3/HIV protease; NSP5 (3CLpro); NSP12 (RdRp); angiotensin II receptor type 1 (AT-1);50 and JAK-1, -2, and -3. In addition, we sought to develop a model based on phenotypic screen results as a holistic approach to the problem. A summary of the selected targets, the stage of the disease targeted, the size of the unique compounds with bioactivity data sets, and clinical candidates is given in Table 19.

## Section: Materials and Methods › Biodata Sources and Curation

Biological data was collected from three main sources: GoStar,51 Liceptor,52 and ChEMBL,53 using the target descriptor as the primary filter for compound selection. The bioactivities from the three databases were a complex mix of activity type, activity unit, and activity value and were subjected to a curation process prior to incorporation into the modeling analysis. In consideration of the different evaluation standards that each primary source of bioactivity data uses, we used single sources of bioactivity data for each of the targets, and this is noted in each target described in the Results and Discussion section.

Each data set was narrowed to bioactivities represented by EC50, IC50, Ki, Kb, pKi, and pKb and, to use as much of the data as possible, the individual values were converted through the series of manipulations to values that could be cross-compared (see Scheme 1). We used the statistically validated methodology published by the ChEMBL group to make the conversions of the different activity types to a single cross-comparable value.60 Thus, EC50 and IC50 values were converted to their −log 10 values; Ki and Kb values were divided by 2.3 and then converted to their −log 10 values; and pKi values were adjusted by subtracting 0.32. All values were then converted to activity grades starting with a value of pIC50, pEC50, pKi, pKb < 5.5 assigned a grade of 1, stepping up by half log units and finishing with activity values of >9.5 being assigned a grade of 10 (see Scheme 1).

## Section: Materials and Methods › Chemical Property Sources and Curation

The primary sources of chemical property data were taken from the CAS REGISTRY and from the ChEMBL data set and comprised both physiochemical and structural properties.

## Section: Materials and Methods › Chemical Property Sources and Curation › Physicochemical Properties

The CAS REGISTRY properties correspond to the physicochemical characteristics of each small molecule. They include: polar surface area (PSA); hydrogen bond acceptor (HBA) count; hydrogen bond donor (HBD) count; bio-concentration factors (predicted for pH 1–10); mass solubilities (predicted for pH 1–10); predicted molar solubilities (pH 1, 7, and 10); pKa (under acidic and basic conditions); predicted log D (pH 1, 7 and 10); predicted boiling point; predicted enthalpies of vaporization, predicted densities; predicted molar volumes; predicted mass intrinsic solubilities; and predicted molar intrinsic solubilities (pH 1, 7, and 10). From the ChEMBL set, we selected the following physical properties: molecular formula; estimated lipophilicity (Alog P); Lipinski’s rule of five violations (RO5 violations); QED weighted; CX log P; CX log D; aromatic rings; heavy atoms, HBA Lipinski; HBD Lipinski; and monoisotopic molecular weight.

## Section: Materials and Methods › Chemical Property Sources and Curation › Structural Properties

The structural properties included in the data are the following: hydrogen bond acceptor counts; hydrogen bond donor counts; hydrogen donor–acceptor sums; freely rotatable bond counts; and polar surface areas. The SMILES strings of each molecule were used to engineer features, generating the set of unique characters across all of the SMILES strings across data for each target. A distributed representation of each symbol in the SMILES was calculated. Each feature vector consists of 74 features, 17 of which are atomic symbols and the remaining 57 are SMILES symbols.

## Section: Materials and Methods › AI Methods › Classification Model: Random Forests

In this study, we used the random forest (RF) methodology, which is a tree-based learning method initially introduced by Breiman in 2001.61 The RF algorithm generates multiple decision trees from randomly selected feature sets. This results in unpruned classification trees that reduce overfitting to training data. Activity classification predictions are made by each decision tree and a majority vote rule is used to combine the results. Here, we implement random forests using scikit-learn.62 Random forests have been used in a variety of benchmark studies. In 2003, Feuston et al. used random forests to build regression and classification models to predict quantitative and categorical biological activity based on quantitative descriptions of compounds’ molecular structures.63 Further, in 2019, Gitter et al. published a study using random forests to recover active molecules assay against Pria-SSB from a library of 22 000 molecules.64 In another study, Gitter et al. looked at using random forests and molecular fingerprints to classify drug functions.65

## Section: Materials and Methods › AI Methods › Model Development

Model parameter selection was done using 10-fold cross validation on the training sets. Separate hyperparameter grid searches were performed for each model. The best set of hyperparameters were selected based on cross-validation accuracy (see Table 20).

The training and test sets for each model were generated using randomized 80/20 train/test splits. The hold-out test sets were left out of training and model selection steps and reserved for model evaluation. To avoid overfitting, we did our best to satisfy the “1 in 10 rule,” which states that values of events per variable (EPV) greater than or equal to 10 reduces bias in model training.66 Trained models were evaluated using the hold-out test set. For each model, we report the following performance metrics from scikit-learn 0.21.3: confusion matrix metrics, accuracy, balanced accuracy, Matthew’s correlation coefficient, receiver operating characteristic area under the curve (ROC AUC), and average precision. For multiclass classification models, we report the one-vs-rest comparisons for average precision and ROC AUC for each class (see Supporting Information).67

For the purpose of training and testing the models, we built binary and ternary classification models for predicting bioactivity with each target (see Table 21 for activity score classifications).

## Section: Materials and Methods › AI Methods › Cluster Analysis

Each of the data sets for the six selected targets was subjected to a cluster analysis using MolsoftChemist64.68 Each set of unique compounds was loaded into MolSoftChemist64 as an SDF file, and the clustering was performed on the structures using the MolSoft fingerprint technology,69 based on the molecular structure alone and clustered using an unweighted pair group method with arithmetic mean.70 The distance range was adjusted to give at least five large clusters, and the centers for each cluster were noted.

## Section: Acknowledgments

We acknowledge the support of WorldQuant Predictive and CAS organizations. Specifically, we thank Steven Watkins, Angela Daniels, Albert Ihochi, Brendon Pittman at CAS for data compilation and curation, as well as Michael Dennis, Dana Albaiu, and Mark Grabau at CAS for their support and guidance of this work.

## Section: Supporting Information Available

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsomega.0c05303.

## Section: Author Contributions

The manuscript was written through the contributions of all authors. All authors have given approval to the final version of the manuscript.

## Section: Text

The authors thank CAS and WorldQuant Predictive for their financial support of this work.

## Section: Text

The authors declare no competing financial interest.

## Section: Supplementary Material

ao0c05303_si_001.xlsx

## Section: Associated Data

ao0c05303_si_001.xlsx

## Section: Associated Data › Supplementary Materials

ao0c05303_si_001.xlsx


---

# On the Dangers of Stochastic Parrots

- **Authors:** Emily M. Bender, Timnit Gebru, Angelina McMillan-Major, Shmargaret Shmitchell
- **Issuer:** ACM Conference on Fairness, Accountability, and Transparency (FAccT)
- **Type:** Scientific article
- **Published:** 2021-03-01
- **DOI:** 10.1145/3442188.3445922
- **Source:** https://doi.org/10.1145/3442188.3445922
- **Licence:** CC-BY

## Section: Abstract

The past 3 years of work in NLP have been characterized by the development and deployment of ever larger language models, especially for English. BERT, its variants, GPT-2/3, and others, most recently Switch-C, have pushed the boundaries of the possible both through architectural innovations and through sheer size. Using these pretrained models and the methodology of fine-tuning them for specific tasks, researchers have extended the state of the art on a wide array of tasks as measured by leaderboards on specific benchmarks for English. In this paper, we take a step back and ask: How big is too big? What are the possible risks associated with this technology and what paths are available for mitigating those risks? We provide recommendations including weighing the environmental and financial costs first, investing resources into curating and carefully documenting datasets rather than ingesting everything on the web, carrying out pre-development exercises evaluating how the planned approach fits into research and development goals and supports stakeholder values, and encouraging research directions beyond ever larger language models.


---

# Pandemic drugs at pandemic speed: infrastructure for accelerating COVID-19 drug discovery with hybrid machine learning- and physics-based simulations on high-performance computers

- **Authors:** Agastya P Bhati, Shunzhou Wan, Dario Alfè, Austin R Clyde, Mathis Bode, Li Tan, Mikhail Titov, Andre Merzky, Matteo Turilli, Shantenu Jha, Roger R Highfield, Walter Rocchia, Nicola Scafuri, Sauro Succi, Dieter Kranzlmüller, Gerald Mathias, David Wifling, Yann Donon, Alberto Di Meglio, Sofia Vallecorsa, Heng Ma, Anda Trifan, Arvind Ramanathan, Tom Brettin, Alexander Partin, Fangfang Xia, Xiaotan Duan, Rick Stevens, Peter V Coveney
- **Issuer:** Interface focus
- **Type:** Scientific article
- **Published:** 2021-10-12
- **Language:** en
- **DOI:** 10.1098/rsfs.2021.0018
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34956592/
- **Licence:** CC-BY

## Section: Abstract

The race to meet the challenges of the global pandemic has served as a reminder that the existing drug discovery process is expensive, inefficient and slow. There is a major bottleneck screening the vast number of potential small molecules to shortlist lead compounds for antiviral drug development. New opportunities to accelerate drug discovery lie at the interface between machine learning methods, in this case, developed for linear accelerators, and physics-based methods. The two in silico methods, each have their own advantages and limitations which, interestingly, complement each other. Here, we present an innovative infrastructural development that combines both approaches to accelerate drug discovery. The scale of the potential resulting workflow is such that it is dependent on supercomputing to achieve extremely high throughput. We have demonstrated the viability of this workflow for the study of inhibitors for four COVID-19 target proteins and our ability to perform the required large-scale calculations to identify lead antiviral compounds through repurposing on a variety of supercomputers.

## Section: Introduction

The COVID-19 pandemic has shaken the world, and the scale and rapidity of the crisis have also challenged existing methods of doing research, not least the current drug design process, which takes about 10 years and $1–3 billion to develop a single marketable drug molecule [1,2]. The disease is caused by the novel severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2), a member of the coronavirus family, which was first identified in the mid-1960s at the Common Cold Unit in Wiltshire, England [3]. Discovering how to combat the pandemic rests on understanding recent outbreaks, such as severe acute respiratory syndrome coronavirus (SARS-CoV), which has the most closely related genome, and Middle East respiratory syndrome coronavirus (MERS-CoV), and taking advantage of the explosion of research in 2020 on various aspects of SARS-CoV-2 biology, from the transmission to the life cycle. Based on this research, notably experimentally derived structures for the various viral target proteins, several drug repositioning and drug designing studies have been conducted using in silico computer-based modelling technologies [4–6]. However, the identification of conclusive drug molecules has been hampered by the huge chemical space that needs to be explored.

Because of the vast number of potential ligands (ranging from a few hundred million to billions), it is clearly not possible to synthesize them in wet laboratories, nor is it desirable given that most of them are not going to bind with SARS-CoV-2 proteins at all. This is where in silico methods can play an important role in screening the binding affinity of ligands with SARS-CoV-2 proteins to identify and rank potential drug candidates.

There is an increasingly large number of in silico methods available to screen candidate ligands. The two most popular categories are physics-based (PB) techniques including molecular dynamics (MD) based methods and machine learning (ML) techniques. However, both have inevitable limitations and, even after months of research, there is a disappointing lack of potential antiviral drug candidates for COVID-19 given that so many lives are at stake. There is an urgent need to accelerate the current drug design process and the work presented here is a step in that direction.

PB techniques involve ab initio as well as semi-empirical methods which are fully or partially derived from firm theoretical foundations [7–10]. For example, MD is a popular approach for conformational sampling which is derived from Newtonian equations of motion and the concepts of statistical thermodynamics. MD-based free energy calculation methods have been widely applied for predicting protein–ligand binding affinities and are subject to extensive experimental validation [11–22]. There are many such free energy methods, some ‘approximate’; others more ‘accurate’.

In the last decade or so, ensemble simulation-based methods have been proposed which overcome the issue of variability in predictions from MD-based methods due to their extreme sensitivity to simulation initial conditions [13,19–23] which leads to chaotic behaviour, and non-Gaussian statistics [24,25]. In particular, two methods named enhanced sampling of MD with approximation of continuum solvent (ESMACS) [13,14,17,26] and thermodynamic integration with enhanced sampling (TIES) [19–22] have been shown to deliver accurate, precise and reproducible binding affinity predictions within a few hours. Their excellent scalability allows them to calculate binding affinities for a large number of protein–ligand complexes in parallel, using the large size and multiple nodes of current supercomputers.

Another important factor affecting the reliability of results is the extent of conformational sampling achieved by MD simulations. Thus, several enhanced methods have also been developed to better sample the phase space [27]. However, even such enhanced sampling is prone to variability in results due to extreme sensitivity to initial conditions. Once again, ensemble simulations are required to control uncertainties in predictions [20–22].

However, these in silico methods are computationally demanding and are unable to explore the extensive chemical space relevant for drug molecule generation. To focus the hunt, they require extensive consultation with chemists to suggest structural features or specific functional groups that may improve a ligand's interaction with the target protein, based on the chemical environment of the binding pocket. Drawing on human intelligence (HI) and insights takes time and slows the process of drug discovery by delaying the pipeline of candidate ligands to wet laboratories for testing. Even if this step is accelerated, another bottleneck in drug design looms because there is a limit to the number of compounds that can be studied experimentally.

To overcome the limitations of PB methods, ML methods can be employed. Prediction of binding affinities using a deep neural network has been an active area of research over the past few years. ML represents a set of techniques that rely on inferring complex relationships from big data and applications that include diverse fields such as robotics, gaming, language processing and chemoinformatics. Some examples include classifying kinase conformations [28], predicting antimicrobial resistance [29], modelling quantitative structure–activity relationships [30] and predicting contact maps in protein folding [31], with AlphaFold making important progress in protein structure prediction [32].

In the field of drug discovery, ML, specifically deep learning (DL), allows us to generate novel drug-like molecules by sampling a significant subset of the chemical space of relevance. DL techniques are computationally much cheaper and enable quick turnaround of results which allows millions to billions of compounds to be handled [33]. Recent developments in DL allow the generation of novel drug-like molecules in silico by sampling a large fraction of the chemical space of relevance (estimated to be about 1068 compounds). However, the accuracy of ML/DL methods is very much dependent on the training data. Their predictive capability can be improved by providing them with reliable data and by curating them with theoretical understanding [34], neither of which may always be available. This restricts their applicability in the drug discovery domain.

ML and PB methods have their own advantages and limitations. Fortunately, their strengths and weaknesses complement each other and so it makes sense to couple them in drug discovery. In the past few years, several attempts have been made to create synergies between PB and ML methods in order to get favourable outcomes. A major application has been to enhance sampling in MD simulations which includes learning of optimal biasing potentials, optimal collective variables (CVs) or free energy surfaces [35–42]. Examples are also available for approaches that involve deriving MD-based descriptors that can be used to train ML models for predictions of solvation, hydration and/or transfer free energies [43–45]. Studies have shown that the accuracy of alchemical free energy predictions may be improved by ‘correcting’ them through ML-based post-processing [46–47]. In addition, it has been reported that the prediction of ligand activity/affinity against a target can be achieved with a combination of MD and ML [48–51]. Recently, a method combining DL and MD for generation of antimicrobial peptides has been reported where DL methods were used to generate 90 000 peptide sequences which underwent in silico screening to finally obtain 20 sequences for experimental validation [52].

ML/DL techniques can be employed to augment HI with artificial intelligence (AI) for exploring the large chemical space to predict ‘useful’ ligand molecules. This substantially speeds up the process of ligand discovery. On the other hand, reliable PB free energy methods can rank the ligands on the basis of their binding affinities and ground the simulations on theoretical understanding. These binding affinities can then be fed back into the DL algorithm to augment its knowledge base and hone predictions. Such a combination can be an effective tool for drug design and can prove useful in prospective drug design projects. Robust predictive mechanistic models are of particular value for constraining ML when dealing with sparse data, exploring vast design spaces to seek correlations and, most importantly, testing if correlations are causal [53].

It is well accepted that drug targets can undergo significant conformational changes during their biological activity. Some of these changes may involve large-scale rearrangements, such as a domain motion over a hinge region, while some others may be more limited in size, such as the short-lived opening of a mostly hydrophobic cryptic site. The interesting point is that they can involve targetable structures that might otherwise remain hidden to experimental structural determination. Although PB models, such as MD simulations, can explore conformational space to some extent, they can hardly achieve ergodicity, resulting in some of the potential new target structures remaining hidden. Here DL approaches are envisaged to explore whether a short stretch of an MD trajectory may exhibit the hallmarks of potentially biologically relevant structural transitions, even though such transitions are not observed in the trajectory itself.

Not only will exploitation of AI ensure that the best use is made of medicinal chemists for drug discovery, it also helps counter chemists' bias during exploration of the chemical space. Carefully trained DL algorithms may be expected to reach regions of the extensive chemical space that may remain untouched by humans.

In this work, we present a novel in silico method for drug design by coupling ML with PB methods. We bring together several methods into a coherent scientific workflow—some of which are already being applied in drug discovery while others are relatively new to the field and yet to be adopted. Rather than performing only blind ML/DL, we couple them with accurate PB methods to make them ‘smarter’. Potential candidates are selected from the output of a DL algorithm and they are scored using PB methods to calculate binding free energies. This information is then fed back to the DL algorithm to refine its predictive capability. This loop proceeds iteratively involving a variety of PB scoring methods with increasing levels of accuracies at each step ensuring that the DL algorithm gets progressively more ‘intelligent’. As described above, several methods employing a constructive combination of ML and PB methods have been reported in the past few years. However, the pipeline described in this article is unique in several ways. We attempt to generate ligand structures with improved binding potency towards a given target protein using an iterative loop with both upward and downward exchange of information at each step—this, we believe, has not been attempted before. We posit that our innovative integration of PB and ML-based methods can substantially reduce the throughput time for exploring huge chemical space and improve the efficacy of the exploration of chemical libraries for lead discovery. It is worth mentioning here that since the success of lead molecules identified at pre-clinical stages is heavily dependent on several factors like membrane permeability, toxicity, water solubility, etc., drug repurposing provides another avenue for quick availability of COVID-19 therapeutics and needs to be pursued. This approach has not been very successful so far despite several studies published for repurposing; only a couple of drugs (remdesivir and baricitinib) have been approved by USFDA for emergency use against COVID-19 (not actually addressing COVID-19 but secondary infections caused by it). Nevertheless, the approach has potential. We have applied our approach for drug repurposing as well with thus far encouraging results [54]. We obtained binding affinities agreeing well with experimental measurements and also gained detailed energetic insight into the nature of drug–protein binding that would be useful in drug discovery for the target studied.

Given the large-scale supercomputing infrastructure available to us, we are able to scale to the vast number of calculations required to provide input to the ML models. Equally important, our methods are designed to provide key uncertainty quantification, a feature vital to our goal of using active learning to optimize campaigns of simulations to maximize the chance that predictive ML models will find promising drug candidates. Our present paper is not a scientific research paper in a conventional sense. We report an accelerated drug discovery pipeline but do not include any novel scientific findings here, which will be the subject of subsequent publications. Currently, PB components of our workflow have already been implemented successfully in isolation, whereas it is work in progress for some of the ML components that still need optimization. Our integrated workflow implementation has also not been fully realized. In addition, we are working towards improving the overall computational performance of this complicated and heterogeneous workflow. We have made substantial progress in this regard in the past few months as described in the following sections. In this paper, we report preliminary results obtained using our workflow as it stands now to demonstrate that our approach has the potential to impact the process of drug discovery.

## Section: Methods

No single algorithm or method can achieve the necessary accuracy with required efficiency to sample the huge chemical space inhabited by lead compounds for drug discovery. We innovated by combining multiple algorithms into a single unified pipeline (figure 1), using an interactive and iterative methodology, allowing both upstream and downstream feedback to overcome the limitations of classical in silico drug design as described above. Figure 1. Integrated modelling pipeline for new COVID-19 treatments where blind ML is made ‘smarter’ with accurate PB methods. It represents an entire virtual drug discovery pipeline, from hit to lead through to lead optimization. The constituent components are DL-based surrogate model for docking (ML1), Autodock-GPU (S1), coarse and fine-grained binding free energies (S3-CG and S3-FG) and S2 (DeepDriveMD). The arrows show the information transferred between the different methods. (Source: IMPECCABLE [55].)

We first describe the different components of our workflow, notably their standalone strengths and weaknesses, then show how we couple them constructively in the workflow such that the sum is greater than the parts.

Integrated modelling pipeline for new COVID-19 treatments where blind ML is made ‘smarter’ with accurate PB methods. It represents an entire virtual drug discovery pipeline, from hit to lead through to lead optimization. The constituent components are DL-based surrogate model for docking (ML1), Autodock-GPU (S1), coarse and fine-grained binding free energies (S3-CG and S3-FG) and S2 (DeepDriveMD). The arrows show the information transferred between the different methods. (Source: IMPECCABLE [55].)

Classes of secondary structure that DSSP defines.

Jensen–Shannon divergence (a measure of the similarity between two probability distributions; bounded between 0 and 1) between predicted and observed secondary class transitions in the 6VXX trajectory of the spike protein system. Data are presented in decreasing order of similarity. The labels code for the initial and final class. When they are identical, it means that after some oscillation, the residue goes back to the initial class.

## Section: Methods › High-throughput docking

Protein–ligand docking involves ligand three-dimensional structure (conformer) enumeration, exhaustive docking and scoring and pose scoring. The input requires a protein structure with a designed binding region, or a crystallized ligand from which a region can be inferred, as well as a database of small molecules to dock, where the chemical structure is represented in the SMILES format.

Conversion of the two-dimensional structures into three-dimensional structures ready for structural docking is performed through proteinization and conformer generation using Omega-Tautomers that also includes enumeration of enantiomers prior to conformer generation if stereochemistry is not specified [56]. Conformer generation is performed on the ensemble of structures, typically generating 200–800 three-dimensional conformers for every enantiomer.

Each of the three-dimensional structures so generated is docked against the protein binding pocket and scored. The best scoring pose is returned along with its ChemGauss4 score from exhaustive rigid docking [57]. The ranking obtained using such docking scores are useful in the initial hit identification stage of the drug discovery pipeline.

As a consequence, the outputs of docking runs include a three-dimensional protein (receptor) structure with the docked ligand in its binding site. The docking score (evaluated by the scoring function specific to a docking protocol) provides a qualitative measure of the intrinsic complementarity between a given ligand and protein binding site. While docking protocols are generally good at estimating the binding poses (i.e. three-dimensional conformation) of ligands within a binding site, the energetics of interaction can be challenging to determine and are a function of how a specific scoring function is implemented. Nevertheless, docking is extensively used in structure-based drug design approaches. This is so because docking can predict whether or not a molecule binds at all with the target protein. In addition, given that it is a computationally cheap technique, it makes economic sense to have an additional filter before performing the expensive binding affinity calculations. In our protocol, docking is implemented at the initial stage to identify an area of interest in the chemical space and filter out all the obvious non-binders. Thereafter, we employ MD-based binding affinity prediction methods for more accurate ranking of the available compounds on the top ranked compounds based on their docking scores.

Furthermore, there is a need to account for the intrinsic flexibility of the protein in response to the ligand (which may also induce conformational changes) in the energetics of how ligands/proteins interact. For this purpose, extensive conformational sampling is often necessary. The enhanced/adaptive sampling techniques described below can address some of the intrinsic limitations of these techniques.

## Section: Methods › Machine learning-based conformation transition classifier

In order to investigate the conformational transitions during MD simulations, we used two 10 µs trajectories, made available by D.E. Shaw Research [58], of the SARS-CoV-2 spike glycoprotein starting from two main different conformations (i.e. 6VYB and 6VXX, partially open and closed states, respectively). The dictionary of secondary structure of proteins (DSSP) [59] is used to classify each residue according to its secondary structure in all the frames of the trajectory. A total of 8334 frames are extracted from the 10 µs simulations of the spike glycoprotein. The data used for the analysis consist of the atomic coordinates of the protein's Cα atoms and secondary structures of the protein residues, according to DSSP. To analyse the conformations, we adapted the ML-based anomaly detection techniques previously designed and employed at the European Organization for Nuclear Research (CERN) for scientific and medical linear accelerators [60]. We predicted the probability of a local protein conformational change based on transitions occurring in individual trajectories.

The trajectory of each Cα in class-space is followed in time until a change of class is observed at time ta. From that time on, the transitions between different classes, if any, are tracked for 100 subsequent frames, forming a corresponding set of stochastic transitions matrices, whose elements Tkl represent the transition frequency from class k to class l, where k,l = {0..7} (cf. table 1). Only a few transitions out of the possible 64 are effectively observed within the examined dataset. The most frequently observed are the transitions between identical or structurally adjacent classes. Table 1. Classes of secondary structure that DSSP defines.letter IDnumber IDclass of the secondary structureG0310 helix (first helix)H1α helixI2π helixE3β sheetB4β bridgeT5helix turnS6bendC7coil (no SS found)

The stochastic transition matrices are then turned into heat maps and fed into a convolutional neural network (CNN). The neural network was a two-layer CNN, trained using the Reptile meta-learning algorithm [61]. The input layer has a single channel of 8 by 8 pixels. It uses Keras implementation of the relu activation function, the sparse categorical cross entropy loss function and the adam optimizer. The transition-based classification is used to predict the probability of belonging to a class and of the class that the selected residue might land at a future time, typically after 1500 frames since the initial class change. We compared the prediction with the frequency of belonging to each class, as observed throughout the simulation that was not used for training, i.e. that starting from the 6VXX structure. The similarity between the different distributions was evaluated via the Jensen–Shannon divergence [62]. Our preliminary results, shown in table 2, are encouraging, although subject to a number of caveats. First and foremost, the training and the validation dataset (70 : 30) pertain to a single trajectory, which implies that some transitions are trained on a very small number of events. Hence, multi-trajectory data are needed to consolidate these preliminary results. Using more data would also allow additional classes to be introduced, thus obtaining a more precise estimation of residues' behaviour. This is currently the subject of ongoing research. Table 2. Jensen–Shannon divergence (a measure of the similarity between two probability distributions; bounded between 0 and 1) between predicted and observed secondary class transitions in the 6VXX trajectory of the spike protein system. Data are presented in decreasing order of similarity. The labels code for the initial and final class. When they are identical, it means that after some oscillation, the residue goes back to the initial class.transitionJensen–Shannon divergence‘43’4.91 × 10−3‘34’5.67 × 10−3‘01’7.70 × 10−3‘33’1.02 × 10−2‘12’1.21 × 10−2‘00’1.62 × 10−2‘11’1.93 × 10−2‘21’4.38 × 10−2‘22’6.14 × 10−2‘44’6.51 × 10−2‘10’1.54 × 10−1‘04’3.68 × 10−1

Classes of secondary structure that DSSP defines.

Jensen–Shannon divergence (a measure of the similarity between two probability distributions; bounded between 0 and 1) between predicted and observed secondary class transitions in the 6VXX trajectory of the spike protein system. Data are presented in decreasing order of similarity. The labels code for the initial and final class. When they are identical, it means that after some oscillation, the residue goes back to the initial class.

## Section: Methods › Machine learning-driven enhanced sampling

DL methods have been widely applied to understand protein conformational dynamics, and a number of methods have been proposed to enhance sampling of conformational landscapes using adaptive sampling strategies that include DL methods in their workflows. One such approach, namely DeepDriveMD, uses variational autoencoders to cluster high-dimensional data on conformations from multiple MD trajectories into a more manageable low dimensional manifold from which ‘novel’ conformations can be selected, based on certain reaction coordinates (RCs) or CVs and new simulations can be instantiated from such conformations [63]. This approach has been demonstrated for protein folding trajectories, offering at least 2× speedup compared to traditional conformational sampling methods, and in a recent application, DeepDriveMD was able to enhance sampling by nearly 25% with just 12% of computing time for studying conformational transitions of the SARS-CoV-2 spike protein bound to the ACE2 receptor [64]. Thus, DeepDriveMD offers a way forward in sampling conformational events, providing a framework to extend its functionality to account for studying protein–ligand interactions.

Ligands bound to the protein target of interest induce specific conformational changes; some ligands may induce changes that are local to the binding site, whereas others may induce changes farther away from the binding site. We posit that even with reasonably short timescale simulations, our variational autoencoder can cluster protein–ligand interaction landscapes based on such conformational differences and provide a quantitative way to extract ligand-specific protein conformational signatures that could help bound the uncertainty in binding affinity calculations. To this effect, we extracted the contact maps between the protein Cα-atoms (defined at an 8 Å cut-off) and analysed them with our variational autoencoder. Optimal hyperparameters were determined as described previously [65] and the resulting latent space embedding was visualized using t-stochastic neighbourhood embedding (t-SNE) approach. In our analysis, we observe clear separation between protein and ligand complexes, and that some ligands induce more conformational changes than others.

## Section: Methods › Molecular dynamics-based binding affinity prediction

Hit-to-lead (H2L) is a step in the drug discovery process where promising lead compounds are identified from initial hits—small molecules which have the desired activity—generated during preceding stages. After evaluation of initial hits, optimization of promising compounds is carried out to achieve nanomolar affinities. The change in free energy between free and bound states of protein and ligand, also known as binding affinity, is a promising measure of the binding potency of a molecule and is used as a parameter for evaluating and optimizing hits at the H2L stage.

A protocol known as ESMACS [13,17] was used to estimate binding affinities of protein–ligand complexes. It involves performing an ensemble of MD simulations followed by free energy estimation using a semi-empirical method called molecular mechanics Poisson–Boltzmann surface area (MMPBSA). The free energies for the ensemble of conformations are analysed in a statistically robust manner, yielding precise free energy predictions for any given complex.

The use of ensembles is particularly important because the usual practice of performing MMPBSA calculations on conformations generated using a single MD simulation does not give reliable binding affinities [66]. Consequently, ESMACS predictions can be used to rank a large number of hits based on their binding affinities. ESMACS is able to handle large variations in ligand structures and hence is very suitable for H2L stage where hits have been picked out after covering a substantial region of chemical space.

The ensemble of conformations for the protein–ligand complex generated using MD simulations are also analysed using the variational autoencoder technique described above to get insights into favourable as well as unfavourable interactions of different functional groups in a molecule with the target protein. This knowledge is helpful in performing further optimization of the lead structures. The information and data generated with ESMACS are additionally used to train our ML model (described below) to improve its predictive capability.

Lead optimization (LO) is the final step of pre-clinical drug discovery. It involves altering the structures of selected lead compounds in order to improve properties, such as selectivity, potency and pharmacokinetic parameters. Binding affinity is a useful parameter to make in silico predictions about the effects of any chemical alteration in a lead molecule. However, LO requires theoretically more accurate (without much/any approximations) methods to make predictions with high confidence. In addition, relative binding affinity of pairs of compounds that are structurally similar are of interest, rendering ESMACS unsuitable for LO.

Because of these issues, we employ TIES [19–21], which is based on an alchemical free energy method called thermodynamic integration (TI) [67]. Alchemical methods involve calculating free energy along a non-physical thermodynamic pathway to get relative free energy between the two endpoints. A best practice guide for alchemical free energy calculations was recently published with useful recommendations [68]. Usually, the alchemical pathway corresponds to transformation of one chemical species into another defined with a coupling parameter (λ), ranging between 0 and 1. TIES involves performing an ensemble simulation at each λ value to generate the ensemble of conformations to be used for calculating relative free energy. It also involves performing a robust error analysis to yield relative binding affinities with statistically meaningful error bars. The parameters such as the size of the ensemble and the length of simulations are determined keeping in mind the desired level of precision in the results [19].

## Section: Methods › Machine learning-based model to predict useful ligands

In our drug discovery workflow, ML is used to gather and accumulate information from all the other PB components described above so as to quickly locate the most interesting region(s) in the chemical space in terms of the potential of a lead compound to bind strongly. We have created a ML surrogate model using a simple featurization method, namely two-dimensional image depictions, as it does not require complicated architectures such as graph convolution networks while demonstrating good prediction. We obtain these image depictions from the nCov-Group Data Repository [69] that contains various descriptors for 4.2 billion molecules generated on high-performance computing (HPC) systems with Parsl [70]. By using two-dimensional images, we are able to initialize our models with pre-trained weights that are typically scale and rotation invariant under image classification. This model is used to generate ligand molecules that can be analysed using the PB methods described above. We train our ML model using data from both docking as well as MD-based binding affinity predictions so as to enable it to actively relate structural/chemical features with corresponding binding potencies. This allows our ML model to progressively make more accurate predictions of ligand structures that can be classified as initial hits. The predicted structures are then fed into the PB pipeline to filter them, first using docking and then by ESMACS and TIES, to finally select those that bind most effectively. This is repeated with the ML model getting better after each iteration. Thus, we provide reliable training data to our ML models, whereas potentially good initial structures are identified for our PB methods. In this way, our workflow couples ML and MD such that each compensates for the weaknesses in the other method. It is our expectation that, together, they are more effective.

## Section: Workflow management

Our workflow (figure 1) integrates different methods and dynamically selects active ligands for progressively computationally expensive methods. At each stage, only the most promising candidates advance to the next stage, yielding a pipeline in which each downstream stage is computationally more expensive, but also more accurate, than upstream stages. Execution of such a complicated workflow requires scalable tools with advanced resource management, task-placement and adaptive execution capabilities, in this case RADICAL-Cybertools (RCT) [71] middleware.

RCT executes tasks concurrently or sequentially, depending on their arbitrary priority relation. Tasks are grouped into stages and stages into pipelines, depending on the priority relation among tasks. Tasks without reciprocal priority relation can be grouped into the same stage, tasks that need to be executed before other tasks have to be grouped into different stages. Stages are then grouped into pipelines and, in turn, multiple pipelines can be executed either concurrently or sequentially. RCT uses RADICAL-Pilot (RP) [72] to execute tasks on HPC resources, allowing the execution of workflows with heterogeneous tasks.

RCT middleware has been used in two ways:

Scalable concurrent multi-stage task-execution. A work around was required to use the middleware on one of Europe's largest supercomputers, SuperMUC-NG. As RADICAL-Cybertools depend on third-party software modules, the virtual environment required by RP could not be created on SuperMUC-NG because access is granted only to allowed IP addresses. Thus, we prepared RCT's virtual environment outside of the system and then moved it to SuperMUC-NG login node. In this way, RCT could be launched from a login node via the pre-set environment, without the need for outbound Internet access. RCT uses MongoDB and RabbitMQ as communication services. These services need to be accessible from both login and compute nodes. On SuperMUC-NG, we automated the launching of both services on a dedicated compute node, which was provided by a special service queue with unlimited walltime, while the workers for RP were provided by the regular batch system.

Concurrent multiple workflow execution. RCT's fine-level task-placement feature allows the concurrent use of both CPUs and GPUs on supercomputer nodes. That is achieved by employing RADICAL-Pilot's unique capability of concurrently executing heterogeneous tasks on CPU cores and GPUs as an integrated hybrid workflow. This allows the concurrent execution and interleaving of different workflows, making better use of compute resources. RP places tasks on specific compute nodes, cores and GPU [73]. When scheduling tasks that require different amounts of cores and/or GPUs, RP keeps tracks of the available slots on each compute node of its pilot. Depending on availability, RP schedules CPU tasks (e.g. MPI) within and across compute nodes and reserves a CPU core for each GPU task. This results in efficient placement of heterogeneous tasks on heterogeneous resources.

Leveraging aforementioned RP's heterogeneous task-placement capabilities, we merge ESMACS and TIES into an integrated hybrid workflow with heterogeneous tasks that use CPU and GPU concurrently. Running these two calculations concurrently reduces the total execution time, substantially saving computational cost, thereby improving resource utilization at scale.

In the past few months, we have progressed substantially with the implementation of our workflow. RCT is now fully functional on Summit [55,73,74] as well as Theta [75], in addition to several other HPC resources. It has successfully executed workloads at 95% usage on these machines. We characterized scaling performance of various components of our workflow using up to 392 000 cores and 24 582 GPUs to execute 24 552 heterogeneous executable tasks and 126 × 106 python function tasks [74]. Recently, we have been able to achieve a performance of 144 M h−1 docking hits screening approximately 1011 ligands using over 8000 compute nodes, which is better than the previous best by a factor of two [76]. This has substantially boosted our ability to screen large compound libraries as well as generating training data for surrogate models. We have already analysed several million compounds from a set of orderable compound libraries using the current implementation of our workflow and filtered out compounds for the second iteration of our iterative workflow. Recently accepted publications in IEEE TPDS, ACM SIGHPC ICPP, ACM SIGHPC PASC [55,73–74], as well as publications under review [75,76] provide evidence of our progress towards the fully optimized implementation of the workflow.

## Section: High-performance computing resources

Our workflow is by design based on high-throughput computational (HTC) calculations. Even though it reduces the overall number of necessary computations tremendously, an acceptable time to solution is only achievable on HPC resources. To illustrate the impact of our workflow, we applied it to four target proteins of SARS-CoV-2 in this work, namely 3C like protease (3CLPro; also known as the main protease), papain-like protease (PLPro), ADP-ribose phosphatase (ADRP; a macrodomain of NSP3) and non-structural protein 15 (NSP15) (figure 2). These proteins have diverse functions for the replication and transcription of the coronavirus and are important targets for pharmaceutical drug design and discovery [77–81]. For this, docking calculations were performed on thousands of ML model-generated ligand conformations, leading to a ranking of candidates with corresponding ligand structures. Afterwards, we conducted several hundred ESMACS calculations on the top ranked ligands based on their docking and 19 TIES calculations on a selection of ligand pairs. Note that the ML-based generation of ligand structures accelerated the whole HTC process significantly. Figure 2. Structures of the four target proteins studied, in each case shown bound to a compound. From left to right: 3CLPro, PLPro, ADRP and NSP15. The proteins are shown in cartoon representation and compounds in stick representation.

We would like to emphasize here that the above results are only preliminary and do not constitute novel scientific findings. The above-mentioned calculations were performed on a small scale for testing and optimizing our workflow. We have the PB components already working well in isolation. However, we are still optimizing the DeepDriveMD protocol for application in prospective drug discovery. In addition, we are yet to realize the fully optimized implementation of our workflow as a whole with all its components working in tandem. This paper is about the development of the infrastructure, so we have not included novel scientific results in terms of potential drug candidates identified in this paper. Nevertheless, we have started applying the current implementation of our workflow to a large-scale dataset of millions of orderable compounds. Using our docking protocols, we identified 10 000 compounds for each of the four target proteins which were used for performing ESMACS calculations. The top 500 compounds, based on their ESMACS ranking, are being further optimized using DeepDriveMD (as it stands) to identify potentially better binding conformations that will be used for the second iteration of our workflow. This work is underway, and we have some very encouraging results with input from experimental colleagues that will be published in due course.

Drug repurposing is another promising approach that bypasses all the stringent requirements of drug approval and hence could accelerate the availability of COVID-19 therapeutics. We have, recently, used our workflow to make a detailed assessment of a set of proposed repurposed drugs [54]. We obtained binding affinities agreeing well with experimental measurements and also gained detailed energetic insight into the nature of drug–protein binding that would be useful in drug discovery for the target studied.

All calculations were performed on a variety of supercomputers including Leibniz Rechenzentrum's SuperMUC-NG, Hartree Centre's ScafellPike, Oak Ridge National Laboratory's Summit and Texas Advanced Computing Center's Frontera. Table 3 summarizes performance and cost numbers for the calculations on Summit to understand the overall cost of the presented pipeline. Note that the ESMACS calculations were accelerated with OpenMM as MD engine on GPUs. TIES required longer wall-clock times as only CPUs were employed to obtain the data for table 3. However, recently we have developed a GPU-enabled version of TIES on Summit (using NAMD3 as well as OpenMM as MD engines), which costs only 11 node-hours per ligand–protein complex. This would substantially reduce the computational cost associated with our workflow.

Structures of the four target proteins studied, in each case shown bound to a compound. From left to right: 3CLPro, PLPro, ADRP and NSP15. The proteins are shown in cartoon representation and compounds in stick representation.

## Section: ESMACS and TIES applied to COVID-19 on high-performance computing resources

Correlations between the ESMACS results and docking predictions. Weak or no correlations are obtained for the four protein targets—3CLPro, ADRP, NSP15 and PLPro—with correlation coefficients of 0.25, −0.06, 0.16 and 0.20, respectively.

Overview of computing cost for the different calculations in the computing pipeline on Oak Ridge National Laboratory's Summit supercomputer.

Number of the most promising compounds for each of the four proteins investigated. For each protein, the top 100 compounds, chosen from 10 000 docked small molecules, are evaluated by the ESMACS approach. The number of compounds, which have the most favourable binding free energies in the ranges corresponding to KD values of 10 nM (−10.98 kcal mol−1), 100 nM (−9.61 kcal mol−1), 1 µM (−8.24 kcal mol−1), are listed.

Results from TIES calculations on a set of ligand transformations studied for ADRP. ΔΔG is the relative binding affinity for a transformation, that is the change in binding affinity on morphing one ligand into the other. σ corresponds to the uncertainty associated with the relative binding affinity predicted by TIES.

## Section: ESMACS and TIES applied to COVID-19 on high-performance computing resources › ESMACS findings

ESMACS is used at the hit identification and H2L stage of the drug discovery. The DL-based surrogate model was used to screen the small molecules in the zinc database, a collection of commercially available chemical compounds. A high-throughput docking study was then performed to generate binding poses of the compounds to the four COVID-19 target proteins in this work (figure 2). While docking programs are generally good at pose prediction, they are less effective in predicting binding free energy of the compounds to the target proteins. To better rank the binding potentials of the compounds, we performed ESMACS simulations for the top 100 compounds for each of the selected proteins. The compounds were chosen from 10 000 docked small molecules, based on their docking scores from the high-throughput docking study.

Preparation and set-up of the simulations were implemented using a binding affinity calculator, including parametrization of the compounds, building simulation-ready topologies and structures of the complexes and generating configurations files for the simulations. MD simulations were performed using two MD engines, NAMD and OpenMM, on three machines, Frontera, Summit and SuperMUC-NG. For each replica, energy minimizations were first performed, followed by 2 ns equilibration. Finally, 10 ns production simulations were run for each replica. MMPBSA calculations were then performed for all of the 1000 frames from the 10 ns production runs, while configurational entropies were calculated using NMODE on 48 or 56 frames for each replica, depending on the number of cores per node on the computers used for NMODE calculations.

For most of the molecular systems studied, about 4–19% of the compounds show promising binding affinities (cf. table 4), with free energies more negative than −8.24 kcal mol−1 (corresponding to a KD value on the nanomolar scale). Although the distributions of predicted free energies from independent simulations are non-normal [24,25], the ensemble-based ESMACS predictions are highly reproducible, independent of which MD code is used, or on which supercomputer the simulations are performed. As stated above, the docking scores are not a good indicator for binding affinities; the free energies from ESMACS calculations only show weak correlations with the docking scores (figure 3). The inclusion of configurational entropy has a negligible impact on the ranking of the binding free energies. The ESMACS study shows that the most promising compounds can be selected more reliably using the ESMACS prediction than the docking scores. Figure 3. Correlations between the ESMACS results and docking predictions. Weak or no correlations are obtained for the four protein targets—3CLPro, ADRP, NSP15 and PLPro—with correlation coefficients of 0.25, −0.06, 0.16 and 0.20, respectively. Table 3. Overview of computing cost for the different calculations in the computing pipeline on Oak Ridge National Laboratory's Summit supercomputer.calculationphysical time required in each MD simulation (ns)no. independent MD simulations per ligand–protein complexcomputing time per calculation (node-hours)computing time per ligand–protein complex (node-hours)used theoretical performance (TF)docking—several thousands0.0001——ESMACS1225—10420TIES665—70029 400

Correlations between the ESMACS results and docking predictions. Weak or no correlations are obtained for the four protein targets—3CLPro, ADRP, NSP15 and PLPro—with correlation coefficients of 0.25, −0.06, 0.16 and 0.20, respectively.

Overview of computing cost for the different calculations in the computing pipeline on Oak Ridge National Laboratory's Summit supercomputer.

## Section: ESMACS and TIES applied to COVID-19 on high-performance computing resources › TIES findings

TIES is used at the LO stage of drug discovery to hone interactions between protein and ligand so to enhance the binding potency of selected lead compounds. To demonstrate this capability, we performed TIES on a set of 19 compound transformations (that is chemically mutating the ‘original’ compound into a ‘new’ compound) to study the effect of small structural changes on a compound's binding potency with ADRP. The calculated free energy differences show a non-normal nature, as we have recently reported [24,25]. The ensemble-based TIES approach ensures high-precision predictions, with uncertainties less than 0.82 kcal mol−1 for all but one of the calculations (cf. table 5). The relative binding affinities (ΔΔG) predicted by TIES for these transformations fall between −0.55 and +4.62 kcal mol−1 (cf. table 5). A positive value indicates a diminished relative binding potency for the ‘new’ compound, whereas a negative value means that the transformation studied is favourable. Twelve out of the 19 transformations studied have ΔΔG >+1 suggesting that they all correspond to unfavourable structural changes. The remaining seven transformations have statistically zero value for ΔΔG, which implies that the corresponding structural modifications do not affect the binding. It is difficult to predict what structural changes will improve the binding. Thus, the knowledge of both ‘useful’ as well as ‘rubbish’ transformations is of much value at the LO stage so as to make informed structural changes. TIES provides us an excellent tool to do so with confidence. Such information then informs our ML predictive model about the desirable as well as undesirable chemical modifications to be introduced into the selected lead compounds. In this way, it improves the predictive accuracy of the ML models, progressively leading to quicker convergence towards the region of our interest in the huge chemical space. Table 4. Number of the most promising compounds for each of the four proteins investigated. For each protein, the top 100 compounds, chosen from 10 000 docked small molecules, are evaluated by the ESMACS approach. The number of compounds, which have the most favourable binding free energies in the ranges corresponding to KD values of 10 nM (−10.98 kcal mol−1), 100 nM (−9.61 kcal mol−1), 1 µM (−8.24 kcal mol−1), are listed.energy (kcal mol−1)3CLProADRPNSP15PLProΔG < −10.981036−10.98 ≤ ΔG <−9.612218−9.61 ≤ ΔG < −8.2414105ΔG < −8.24 total461419 Table 5. Results from TIES calculations on a set of ligand transformations studied for ADRP. ΔΔG is the relative binding affinity for a transformation, that is the change in binding affinity on morphing one ligand into the other. σ corresponds to the uncertainty associated with the relative binding affinity predicted by TIES.transformationΔΔG (kcal mol−1)σ (kcal mol−1)a0–a21.480.60a0–a41.820.66a0–a51.140.60a0–a63.220.44a0–a71.320.43a0–a90.250.57a0–a101.520.70a0–a413.410.53a0–a441.180.49a0–a45−0.460.52a0–a462.910.70a0–a470.360.57a0–a48−0.550.57a0–a491.840.46a0–a500.520.64a1–a42−0.290.82a1–a432.051.03a3–a420.490.81a42–a434.620.82

Number of the most promising compounds for each of the four proteins investigated. For each protein, the top 100 compounds, chosen from 10 000 docked small molecules, are evaluated by the ESMACS approach. The number of compounds, which have the most favourable binding free energies in the ranges corresponding to KD values of 10 nM (−10.98 kcal mol−1), 100 nM (−9.61 kcal mol−1), 1 µM (−8.24 kcal mol−1), are listed.

Results from TIES calculations on a set of ligand transformations studied for ADRP. ΔΔG is the relative binding affinity for a transformation, that is the change in binding affinity on morphing one ligand into the other. σ corresponds to the uncertainty associated with the relative binding affinity predicted by TIES.

## Section: Conclusion

We describe an innovative, iterative and interactive heterogeneous workflow that has the potential to accelerate the existing drug discovery process substantially by coupling ML with PB methods such that each compensates for the weaknesses of the other. This workflow requires high-throughput screening of a large number of small molecules based on their binding potencies evaluated using various types of methods. Molecules filtered at one stage are advanced to the next to be filtered once again using a more accurate and computationally intensive method. A refined set of lead compounds emerges at the end of this multi-stage process for wet laboratories studies. With information relating structural features to energetics and binding potencies being fed into the ML model at each stage, it learns how to improve the prediction of the next set of compounds. This iterative process, along with the upstream and downstream flow of information, allows it to accelerate the sampling of relevant chemical space much faster than traditional methods. We have demonstrated the application of our workflow on four SARS-CoV-2 target proteins. The workflow requires HPC resources for efficient implementation and a dedicated workflow manager to handle the large number of heterogeneous computational tasks on a multitude of supercomputers. We believe that this hybrid ML–PB approach offers the potential in the long term—with the rise of exascale, quantum and analogue processing—to deliver novel pandemic drugs at pandemic speed.


---

# Pharmaceutical Strategy for Europe: Reflections on Public Health-Driven Drug Development, Regulation, and Policies

- **Authors:** Silvio Garattini, Yannis Natsis, Rita Banzi
- **Issuer:** Frontiers in pharmacology
- **Type:** Scientific article
- **Published:** 2021-04-28
- **Language:** en
- **DOI:** 10.3389/fphar.2021.685604
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33995113/
- **Licence:** CC-BY

## Page 1 (Section: Pharmaceutical Strategy for Europe: Reflections on Public Health-Driven Drug Development, Regulation, and Policies)

Pharmaceutical Strategy for Europe:
Reﬂections on Public Health-Driven
Drug Development, Regulation,
and Policies
Silvio Garattini 1, Yannis Natsis 2 and Rita Banzi 3*
1Istituto di Ricerche Farmacologiche Mario Negri IRCCS, Milan, Italy, 2European Public Health Alliance, Brussels, Belgium,
3Center for Health Regulatory Policies, Istituto di Ricerche Farmacologiche Mario Negri IRCCS, Milan, Italy
Keywords: pharmaceutical policies, incentives, drug development—clinical trials, European commission, added
value, health policies, pharmaceutical medicine
INTRODUCTION
Never before has the central role of medicines and other health care interventions for society been so
recognized. Europe’s pharmaceutical sector is a major contributor to the European Union’s
economy. According to the European Federation of Pharmaceutical Industries and Associations
(EFPIA), it contributes with more than €110 billion to the EU trade balance and employs almost
800,000 people across Europe. In 2019, it invested an estimated € 37,500 million in R&D in Europe
(European Federation of Pharmaceutical Industries and Associations, 2020). However, despite these
investments, the drug market is not without some low-value drugs and alleged innovations, resulting
in an excess of public and private spending that could be reduced in favour of other health-related
activities. A survey by the independent scientiﬁc journal Prescrire found that only 10% of the new
authorisations in 2019 presented a notable therapeutic advance (Prescrire, 2020), a view shared by
the German Institute for Quality and Efﬁciency in Health Care (IQWiG) (Wieseler et al., 2019).
On 25 November 2020, in the midst of the COVID-19 pandemic, the European Commission
adopted a new “Pharmaceutical strategy for Europe,” after intense rounds of consultation with
stakeholders and the public between July and September 2020. This pharmaceutical strategy “aims to
ensure the quality and safety of medicines, while boosting the sector’s global competitiveness”
(European Commission, 2020a). It is a roadmap based on four speciﬁc pillars (Table 1), an inventory
of actions. Some will make the legislative cut by the end of the current European Commission’s term.
Unquestionably, this document offers an opportunity for thorough reﬂection on drug development,
regulation, and policies.
ACCESS TO AFFORDABLE MEDICINES ADDRESSING UNMET
MEDICAL NEEDS
The need for affordable medicine is a central issue of the Strategy, reﬂecting one of the top priorities
in the European Health Commissioner’s mission statement (Von Der Leyen, 2019). The Strategy
acknowledges that research investment does not necessarily focus on the greatest unmet needs,
mainly because of limited commercial interest. The call for “research priorities aligned to the needs of
patients and health systems” can be made concretely by promoting shared agendas that identify,
prioritize, and achieve consensus on the research areas or questions of importance to stakeholders.
Methods have been developed but should now become a standard approach of European and
national research bodies. New types of incentives may be explored, for instance, in the ﬁeld of rare
Edited by:
Domenico Criscuolo,
Italian Society of Pharmaceutical
Medicine, Italy
Reviewed by:
Elena Bresciani,
University of Milano-Bicocca, Italy
*Correspondence:
Rita Banzi
rita.banzi@marionegri.it
orcid.org/0000-0002-2211-3300
Specialty section:
This article was submitted to
Drugs Outcomes Research
and Policies,
a section of the journal
Frontiers in Pharmacology
Received: 25 March 2021
Accepted: 15 April 2021
Published: 28 April 2021
Citation:
Garattini S, Natsis Y and Banzi R (2021)
Pharmaceutical Strategy for Europe:
Reﬂections on Public Health-Driven
Drug Development, Regulation,
and Policies.
Front. Pharmacol. 12:685604.
doi: 10.3389/fphar.2021.685604
Frontiers in Pharmacology | www.frontiersin.org
April 2021 | Volume 12 | Article 685604
1
OPINION
published: 28 April 2021
doi: 10.3389/fphar.2021.685604

## Page 2 (Section: Competitiveness, Innovation and Sustainability)

diseases, given the substantial limitations of the current
approach. The methodological quality of orphan medicinal
product applications is generally poor, as well as the
information about their harm-beneﬁt proﬁles at the time of
approval (Joppi et al., 2013). A recent analysis of 20 years of
orphan drugs reported that average annual sales rose from
€133m in 2001 to €723m in 2019 (Marselis and Hordijk, 2020).
The European Commission itself looked at the orphan
medicines introduced between 2001 and 2016 and estimated
that the number of new orphan medicines that can be
attributed to the EU Orphan Regulation was extremely
low (12–16%), and the majority would probably have
reached
the
market
anyway
(European
Commission,
2020b).
These
orphans,
however,
had
beneﬁted
from
superﬂuous
monopoly
rights.
The
revision
of
the
EU
orphan
legislation—rightly
prioritized
by
the
European
Commission—should
also
increase
the
availability
and
affordability of these medicines in all EU Member States,
promoting fair access that has been far from guaranteed
to date.
New approaches should prioritize a critical review and a
possible
scale-back
of
intellectual
property
(IP)-based
monopolies and exclusivities, and lay emphasis on not-for-
proﬁt business models. The EMA lists about 2,000 candidate
orphan drugs that could be adopted by networks of academic and
health research institutes and foundations, duly funded to
develop them, and possibly achieve their licensing. This could
also set in motion a new role for academic independent clinical
research, more closely embedded in drug development and
licensing, to directly provide answers to public health needs
(Garattini and Chalmers, 2009).
A new paradigm will require strong governance and long-term
commitments in funding and investments. It could also help re-
establish the correct symmetry in public-private partnerships.
COMPETITIVENESS, INNOVATION AND
SUSTAINABILITY
The current pharmaceutical innovation and IP system has
repeatedly shown its fault line, besides a failure in global
health goals (Boulet et al., 2019). The COVID-19 crisis
magniﬁes the need for a shift in this paradigm to allow rapid
and widespread access to effective low-priced treatments. Any
revision of the patent-based monopolies-exclusivities will not
only have an impact on competition and public health
expenditures in the EU, but could drive a global change that is
pressing for lowest-income countries.
The Commission recently adopted an Action Plan on IP,
reafﬁrming
its
importance
for
innovation
and
the
competitiveness
of
the
European
industry
(European
Commission, 2020c). Several actions relevant for access to
medicines and global public health are included, illustrating
the willingness to develop a more balanced system (Ellen’t
Hoen, 2020). Voluntary pooling and licensing of patents may
be applicable not just in emergencies; it should become an
option whenever a public health issue arises. This would
also help increase the production of old but effective
products and reduce drug shortages. It would be even more
obvious to abandon the supplementary protection certiﬁcates
that are applied differently in the Member States and pose
impossible obstacles to the development and licensing of
generics and biosimilars. The Action Plan on IP calls on
Member States to put in place procedures for issuing
compulsory licenses when necessary, i.e,
allowing the
production of patented products without the consent of
the
patent
owner
(World
Trade
Organisation,
2020).
Though some may view compulsory licensing in the EU as
a radical measure, it has been recently endorsed by such
unexpected observers as the Financial Times (Financial
Times, 2021).
Experience with the EU joint procurement for COVID-19
vaccines and therapeutics (as for remdesivir) showed that
EU countries can exchange information, negotiate drug
prices
jointly
and
even
buy
pharmaceutical
products
together. The publication of redacted versions of contracts
signed between pharma and EU is an important precedent
for good governance and transparency. Joint procurement
procedures aim to ensure that participating countries have
uninterrupted supply and increase the bargaining power of the
public counterpart in price negotiations. However, it is hard to
assess its actual impact because of the conﬁdentiality of price
TABLE 1 | Pillars of the pharmaceutical strategy and key proposals.
Pillars of the pharmaceutical strategy for
Europe (European Commission 2020a)
Proposals for health-driven drug development, regulation,
and policies
Ensuring access to affordable medicines for patients, and addressing unmet medical
needs
Shared agendas and reform of the incentive schemes, including intellectual
properties, to address patients’ and public health needs, with an eye to equity and
affordability
Supporting competitiveness, innovation and sustainability of the EU’s pharmaceutical
industry and the development of high quality, safe, effective and greener medicines
Introduction of alternative paradigms to support competition and innovation to
develop a more balanced system
Enhancing crisis preparedness and response mechanisms, diversiﬁed and secure
supply chains, address medicines shortages
Promote coordination rather than competition, from R&D to manufacturing and
distribution
Ensuring a strong EU voice in the world, by promoting a high level of quality, efﬁcacy
and safety standards
Assessment of added therapeutic value for marketing approval and transparent and
accountable EU agencies
Frontiers in Pharmacology | www.frontiersin.org
April 2021 | Volume 12 | Article 685604
2
Garattini et al.
Comment on the Pharmaceutical Strategy for Europe

## Page 3 (Section: Crisis Preparedness and Response Systems)

negotiation. To be accountable, any co-operation between
public authorities and industry should be based on full
transparency on agreements and price deﬁnitions, including
clinical trial costs and other determinants of pricing along the
value chain from laboratory to patient (World Health
Organization, 2019).
CRISIS PREPAREDNESS AND RESPONSE
SYSTEMS
The pandemic has highlighted the need to strengthen the EU’s
capacity to respond to health issues. A major step will be the
establishment of an EU Health Emergency Response Authority to
anticipate and monitor threats but also to identify “promising and
innovative countermeasures” (European Commission, 2020a).
The Commission is currently exploring its functions and
possible structure, working on a proposal that will be openly
discussed and presented to the Member States and European
Parliament in the second half of 2021.
Though focused on emergencies, this authority may promote
overall harmonization and effective public-driven coordination
of the EU pharmaceutical environment, from R&D investments
to manufacturing and distribution.
As for research, networks already in place have the potential to
assist researchers in setting up multinational studies and are the
ideal collector of the best expertize in the Union. The COVID-19
crisis dramatically showed how innovative trial designs to
evaluate multiple interventions simultaneously can produce
rapid and reliable answers (Gaba and Bhatt, 2020). Research
institutions and public hospitals should be ﬁrmly encouraged and
duly funded to work collaboratively rather than competitively,
avoiding fragmenting and the conduction of small national
monocentric trials, that are often inconclusive and lead to
waste
of
research.
Large
consortia
can
promote
shared
approaches to data measurement and collection, forming the
bases for better exploitation of new technologies for drug
development and assessment. Health digitalization and open
data are the pillars of this change.
Besides research, the pharmaceutical environment needs to
ensure the proper preparation and distribution of medicinal
products, as for instance to address medical shortages. The
current system dominated by the private sector often shows
drawbacks. Measures to manage and prevent shortages of
medicines
include
monitoring,
facilitated
regulatory
procedures, and legal provisions to impose export bans so as
to maintain supply reserves. Stronger actions may include a
mechanism
for
building
up
or
converting
facilities
in
emergency situations.
EU LEADERSHIP IN QUALITY, EFFICACY
AND SAFETY STANDARDS
The Strategy mentions that the revision of the pharmaceutical
legislation should include new methods of evidence generation
and assessment, as well as analysis of big and real-world data to
support the development, authorization and use of medicines.
The Strategy clearly re-afﬁrms the pivotal role of robust clinical
trials with suitable comparators for the authorization of
innovative medicines, without any intention of lowering the
evidence standards (European Commission, 2020a). However,
there is an opportunity here to revise the current criteria for the
approval of new medicines. Although “quality, efﬁcacy and
safety” are fundamental characteristics for any drug on the
market, health systems, clinicians and patients need to know if
a new drug is better or worse than the drugs already available for
the same indications (Garattini, 2021). Including the concept of
“added therapeutic value” in the legislation would boost
knowledge on the actual value of new drugs, thus setting the
bases for fairer prices and appropriate use in clinical practice.
Furthermore, the added therapeutic value would require the
assessment of a real advantage, such as a reduction in
symptoms or mortality or improvement of quality of life, thus
boosting more relevant clinical studies in the interests of patients
and public health. A more pronounced shift in the paradigm of
drug development could be achieved if regulatory authorities
were to require at least one pivotal phase III trial to be conducted
by independent scientiﬁc organisations to support the marketing
authorization.
Strengthening the EU voice in the global pharma endeavour
should involve the recognition of the accountability and
independence of EU agencies. The EMA has undoubtedly
raised its level of transparency and openness to dialogue with
society. An important area of better transparency is that of the
scientiﬁc advice. Implementing the European Ombudsman’s
recommendations on how to strengthen transparency in the
pre-submission activities in the assessment of new drugs goes
in the right direction (European Ombudsman, 2019). However, it
is the essence of the EMA funding mechanism to cast a shadow.
Almost the whole EMA budget comes from fees and charges from
industry, 86% in 2020 (European Medicines Agency, 2020).
Alternative
funding
schemes
should
be
explored,
as
for
instance direct support from the Commission funded by tax-
driven systems. The public’s perception of independence and
integrity is of the utmost importance and the EMA should
actively dispel any fears about regulatory capture.
DISCUSSION
The Strategy is a pivotal document. It sets the basis for important
improvements in the pharma ﬁeld and responds to needs and
requests widely shared by many health professionals and services.
It is also broad in scope, with important references to important
challenges such as the EU’s economy sustainability, Europe’s
Beating Cancer Plan, and the European Digital Strategy.
We have discussed four main areas where efforts should be
concentrated. First, legislative action to reform the incentive
schemes to address patients’ and public health needs, with an eye
to equity and affordability. Second, the introduction of
alternative paradigms supporting competition and innovation.
Third, efforts to promote coordination rather than competition
in the EU. Last, the maintenance of high standards for drug
Frontiers in Pharmacology | www.frontiersin.org
April 2021 | Volume 12 | Article 685604
3
Garattini et al.
Comment on the Pharmaceutical Strategy for Europe

## Page 4 (Section: Author Contributions)

approval by transparent and accountable decision-making
bodies.
Moving from auspices to facts will not be cost-free. Any
change to the rules of the game in a ﬁeld like pharma will
affect many stakeholders and interests. The medical and
research
communities
should
reinforce
and
suggest
to
politicians measures that could shape health-driven drug
development, regulation, and policies.
AUTHOR CONTRIBUTIONS
SG suggested the idea to comment the Pharmaceutical Strategy
for Europe. YN provided essential insight about the ongoing
discussion on the Pharmaceutical Strategy for Europe in the
European context. RB drafted the manuscript and led its
ﬁnalization. All the authors contributed to the text and
approved the ﬁnal version of the manuscript. SG is guarantor.
FUNDING
This study was supported by internal institutional funds.
ACKNOWLEDGMENTS
We thank J. D. Baggott for editing.
REFERENCES
Boulet, P., Garrison, C., and Ellen’t Hoen, E. (2019). European Union Review of
Pharmaceutical Incentives: Suggestions for Change. Available at: https://
medicineslawandpolicy.org/wp-content/uploads/2019/06/MLP-European-Union-
Review-of-Pharma-Incentives-Suggestions-for-Change.pdf (Accessed March 18,
2021)
Ellen’t Hoen, E. (2020). Some Surprises in the European Commission’s New
Intellectual Property Strategy. Available at: https://medicineslawandpolicy.org/
2020/12/some-surprises-in-the-european-commissions-new-intellectual-property-
strategy/ (Accessed March 18, 2021)
European Commission (2020a). Communication from the Commission to the European
Parliament, the Council, the European Economic and Social Committee and the
Committee of the Regions. A Pharmaceutical Strategy for Europe. Available at:
https://ec.europa.eu/health/human-use/strategy_en (Accessed March 18, 2021)
European Commission (2020b). Evaluation of the Orphan and Paediatric
Regulation.
Available
at:
https://ec.europa.eu/health/sites/health/ﬁles/ﬁles/
committee/ev_20200312_791_en.pdf (Accessed March 18, 2021)
European Commission (2020c). Commission Adopts Action Plan on Intellectual
Property to Strengthen EU’s Economic Resilience and Recovery. Available at:
https://ec.europa.eu/commission/presscorner/detail/en/IP_20_2187 (Accessed
March 18, 2021)
European Federation of Pharmaceutical Industries and Associations (2020). The
Pharmaceutical Industry: a Key Asset to Medical Progress and the European
Economy. Available at: https://efpia.eu/publications/downloads/efpia/2020-
the-pharmaceutical-industry-in-ﬁgures/ (Accessed March 18, 2021)
European Medicines Agency (2020). Available at: https://www.ema.europa.eu/en/about-
us/how-we-work/governance-documents/funding (Accessed March 18, 2021)
European Ombudsman (2019). Ombudsman Inquiry Strengthens Transparency
and Objectivity of EMA’s Assessment of New Medicines. Available at: https://
www.ombudsman.europa.eu/en/case/en/49999 (Accessed March 18, 2021)
Financial Times (2021). Coronavirus Must Not Destroy an Open World Economy.
Available at: https://www.ft.com/content/4a3bf282-701c-11ea-9bca-bf503995cd6f
(Accessed March 18, 2021)
Gaba, P., and Bhatt, D. L. (2020). The COVID-19 Pandemic: a Catalyst to Improve
Clinical Trials. Nat. Rev. Cardiol. 17, 673–675. doi:10.1038/s41569-020-00439-7
Garattini, S., and Chalmers, I. (2009). Patients and the Public Deserve Big Changes
in Evaluation of Drugs. BMJ 338, b1025. doi:10.1136/bmj.b1025
Garattini, S. (2021). Quality, Efﬁcacy, Safety—It is not Enough!. Eur. J. Clin.
Pharmacol. doi:10.1007/s00228-021-03110-3
Joppi, R., Bertele’, V., and Garattini, S. (2013). Orphan Drugs, Orphan Diseases.
The First Decade of Orphan Drug Legislation in the EU. Eur. J. Clin. Pharmacol.
69, 1009–1024. doi:10.1007/s00228-012-1423-2
Marselis, D., and Hordijk, L. (2020). From Blockbuster to “Nichebuster”: How a
Flawed Legislation Helped Create a New Proﬁt Model for the Drug Industry.
BMJ 370, m2983. doi:10.1136/bmj.m2983
Prescrire (2020). Drugs in 2019: a Brief Review. Prescrire Int. 40, 146
Von Der Leyen, U. (2019). Mission Letter. December 2019. Available at:
https://ec.europa.eu/commission/commissioners/sites/comm-cwt2019/
ﬁles/commissioner_mission_letters/mission-letter-stella-kyriakides_en.pdf
(Accessed March 18, 2021).
Wieseler, B., McGauran, N., and Kaiser, T. (2019). New Drugs: where Did We Go
Wrong and what Can We do Better?. BMJ 366, l4340. doi:10.1136/bmj.l483710.
1136/bmj.l4340
World Health Organization (2019). World Health Assembly, 72. Improving the
Transparency of Markets for Medicines, Vaccines, and Other Health Products.
Available at: https://apps.who.int/iris/handle/10665/329301 (Accessed March
18, 2021)
World Trade Organisation (2020). Overview: the TRIPS Agreement. Available at:
https://www.wto.org/english/tratop_e/trips_e/intel2_e.htm (Accessed March
18, 2021)
Conﬂict of Interest: The authors declare that the research was conducted in the
absence of any commercial or ﬁnancial relationships that could be construed as a
potential conﬂict of interest.
Copyright © 2021 Garattini, Natsis and Banzi. This is an open-access article
distributed under the terms of the Creative Commons Attribution License (CC
BY). The use, distribution or reproduction in other forums is permitted, provided the
original author(s) and the copyright owner(s) are credited and that the original
publication in this journal is cited, in accordance with accepted academic practice.
No use, distribution or reproduction is permitted which does not comply with
these terms.
Frontiers in Pharmacology | www.frontiersin.org
April 2021 | Volume 12 | Article 685604
4
Garattini et al.
Comment on the Pharmaceutical Strategy for Europe


---

# Potential of artificial intelligence to accelerate diagnosis and drug discovery for COVID-19

- **Authors:** Indira Mikkili, Abraham Peele Karlapudi, T C Venkateswarulu, Vidya Prabhakar Kodali, Deepika Sri Singh Macamdas, Krupanidhi Sreerama
- **Issuer:** PeerJ
- **Type:** Scientific article
- **Published:** 2021-10-05
- **Language:** en
- **DOI:** 10.7717/peerj.12073
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34707924/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe coronavirus disease (COVID-19) pandemic has caused havoc worldwide. The tests currently used to diagnose COVID-19 are based on real time reverse transcription polymerase chain reaction (RT-PCR), computed tomography medical imaging techniques and immunoassays. It takes 2 days to obtain results from the RT-PCR test and also shortage of test kits creating a requirement for alternate and rapid methods to accurately diagnose COVID-19. Application of artificial intelligence technologies such as the Internet of Things, machine learning tools and big data analysis to COVID-19 diagnosis could yield rapid and accurate results. The neural networks and machine learning tools can also be used to develop potential drug molecules. Pharmaceutical companies face challenges linked to the costs of drug molecules, research and development efforts, reduced efficiency of drugs, safety concerns and the conduct of clinical trials. In this review, relevant features of artificial intelligence and their potential applications in COVID-19 diagnosis and drug development are highlighted.Keywords: Machine learning, Neural networks, Drug discovery, Reverse transcriptase polymerase chain reaction, Artificial intelligence, Computed tomography, SARS CoV-2, Pharmacogenomics, Homology modeling, Protein prediction

## Section: Introduction

The COVID-19 pandemic is a worldwide health crisis. The causative agent for COVID-19 disease is severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2) (Singhal, 2020). Various vaccines and drugs are being tested in trials for the treatment of COVID-19 disease and released in to the market for emergency purpose. SARS-CoV-2 infects the respiratory tract, mainly the lungs that leads to acute respiratory syndrome and finally death in severely ill and co-morbid patients. One challenge facing the health care workers is identifying people with COVID-19 (Wu et al., 2020). The disease is diagnosed using the test reverse transcriptase polymerase chain reaction (RT-PCR), which is the preferred method. However, the time taken to run the test and return the results is 2 days. Furthermore, there is an under-supply of RT-PCR test kits, lack of advanced technologies limits the disease identification and drug development process (Tahamtan & Ardebili, 2020). An advanced and accurate diagnosis tool that yields rapid results is required (Carter et al., 2020). Artificial intelligence (AI) comprises advanced cognitive systems that are progressing rapidly across the world (Ahuja, 2019). AI algorithms can be used to enhance the findings from chest computed tomography (CT) imaging (Hosny et al., 2018) that enable the rapid diagnosis of a disease (Mei et al., 2020). Considering the public health perspective and the need to quickly isolate patients with COVID-19, chest CT is used for diagnostic imaging due to its sensitivity than chest radiography (Xu et al., 2020). There are few articles related to the detailed methods for detection of SARS CoV-2 and drug discovery using AI. AI tools and software can be used for the development of drugs in the pharmaceutical industry (Agrawal, 2018). Machine learning is a fundamental AI tool that uses algorithms to recognize various patterns in input data collected for disease as well as drug identification (Jiang et al., 2017). Within machine learning, the subfield of deep learning involves neural networks that play an important role in collecting the input data and generating the output data (Nguyen et al., 2019). Artificial neural networks include recurrent neural networks, multilayer perception and convolutional neural networks (Nguyen et al., 2019). A convolutional network consists of a dynamic system with local connections characterized by its biological system modeling, use of images, topology, processing of complex brain functions, recognitions, signal processing and video processing (Abiodun et al., 2018). Multilayer perception consists of pattern recognition, identification of process and controls in a single direction only (Abiodun et al., 2019). A recurrent neural network consists of a closed loop that memorizes and stores information (Abiodun et al., 2019). In the traditional drug discovery method, the first step is the target (disease) validation, followed by in vitro assays, screening of compounds, lead identification, preclinical trails, clinical trials (Phase I, II, III and IV) and finally approval of drugs for clinical use (Riaz et al., 2020). The entire process takes 10–15 years to develop a potential drug molecule for disease therapy (Mohs & Greig, 2017). With AI, drug discovery starts with prediction of a target protein’s role in disease, design of in silico compounds from libraries, novel target identification, prediction of structure–activity relationship, prediction of ADMET properties, drug repurposing, selection of patient population for clinical trials to increase success rates, pharmacovigilance, observation of adverse effects and interrogation of transcriptomic data (Paul et al., 2021). In every step in the development of potential lead molecules for disease therapy, AI plays an important role in minimizing the time required to produce good results (Bohr & Memarzadeh, 2020). Machine learning tools and software helps in identifying specific target virtual molecules and optimizing the efficacy and safety of the drug molecules in human population. AI reduces the time for identification of potential target molecules virtually compared with the synthesis of multiple compounds used for in vitro and in vivo assays (Paul et al., 2021). Currently, the health sector is facing the problems related to drugs and therapies for emerging diseases where nine out of ten drugs will fail in clinical trials and regulatory approval (Fleming, 2018). Using the AI technologies, the drug discovery process will speed up the drugs that are released into the market with short period of time, desired dose, overall safety, efficacy and other parameters required according to the individual patient need (Bender & Cortes-Ciriano, 2020; Paul et al., 2021).

The authors have identified the potential role of artificial intelligence in both disease and drug discovery process. The AI tools used for drug discovery process are highlighted in this manuscript. This article is intended for all researchers and academicians who studies about the applications of artificial intelligence related to medicine and health care. Considering the facts, the paper is arranged as follows. The review of literature is provided in a literature survey in which the SARS-CoV-2 detection methods, artificial intelligence role in disease identification and drug discovery are discussed. In another part, the features of artificial intelligence, the role of artificial intelligence for disease diagnosis and drug discovery and finally conclusions are addressed.

## Section: Survey methodology

The electronic searches were performed to retrieve literature in journal databases such as Google Scholar, Nature, WHO and Pub Med. A list of search terms can be seen in Table S1. The search terms used for collecting the data are SARS-CoV-2 disease, pathology, identification methods, RT-PCR, Immunoassay, artificial intelligence, drug discovery using artificial intelligence, machine learning, computed tomography, radiology, ophthalmology and COVID-19 disease data. The qualitative and quantitative articles were retrieved from literature and the insights related to COVID-19 disease diagnosis, measurable data to formulate the facts related to drug discovery aspects in research was highlighted. The following types of studies are included: review articles, research papers and short communications. The research papers with only abstracts, books and conference papers are excluded. The information provides the current knowledge by identifying the gaps in the literature, different theoretical perspectives and also suggests the future directions for research. All authors assessed the cited studies for quality of the information.

## Section: Literature survey

Mei et al. (2020) discussed how AI enabled diagnosis of COVID-19. In this study, AI algorithms were used to detect the disease based on chest findings, laboratory tests, exposure history and clinical symptoms. A total of 905 patients were tested using RT-PCR, and of them, 279 patients were diagnosed using AI. In 905 tested cases, 419 patients (46.3%) were positive for COVID-19 infection (Mei et al., 2020). AI system correctly identified 17 of 25 patients who had CT scans and tested positive for COVID-19 using RT-PCR. The researchers in this study highlighted the importance of AI to accelerate COVID-19 diagnosis (Mei et al., 2020).

Dhamad & Rhida (2020) provided insights about the serological and molecular methods for detection of COVID-19. In case of molecular methods RT-PCR, CRISPR-Cas 12 based method and isothermal amplification-based approaches are used for detection of COVID-19 where as in serological methods lateral flow assay and ELISA are used for detection of COVID-19. Molecular method RT-PCR is the gold standard method for detection of COVID-19 with accuracy.

Porte et al. (2021) evaluated the performance of two fluorescence immunoassays SOFIA SARS Antigen FIA and STANDARD F COVID-19 Antigen FIA. The two FIA kits showed 100% sensitivity and 96.9% specificity which indicates that the FIA kits can be used as diagnostic tools for early stages of COVID-19 infection other than RT-PCR.

A recent study by Vaishya et al. (2020) also highlighted the importance of AI and its applications for COVID-19. Eight different and significant applications for COVID-19 were discussed including early detection of disease, monitoring the treatment of patients, tracing the primary and secondary contacts of COVID-19-positive cases, projection of cases and mortality, drug development, vaccine development, reduction of workload on health care workers and finally disease prevention (Vaishya et al., 2020). This study provides support for the use of AI in detecting and managing disease in near future (Vaishya et al., 2020).

Li et al. (2020) evaluated the diagnostic accuracy of detecting COVID-19 disease and community-acquired pneumonia using pulmonary CT. In this study, deep learning technology was used to identify community-acquired COVID-19 on chest CT scans. This study used a multidisciplinary approach to diagnose the disease (Li et al., 2020).

Lalmuanawma, Hussain & Chhakchhuak (2020) discussed about AI and machine learning tools applications in COVID-19. The AI tools used for screening, prediction, contact tracing and drug development for COVID-19. Mohanty et al. (2020) highlighted the importance of drug repurposing for COVID-19 using AI. Deep learning algorithms can help in predicting potential antiviral drug molecules for COVID-19.

In a study reported by Stokes et al. (2020), machine learning techniques were used in drug discovery process. Deep neural networks are used for predicting the inhibitor molecule for disease causing agents. Although machine learning tools are available there is a need to discover and study the proteins of interest in disease and drug discovery process.

Allam, Dey & Jones (2020) reported on a health policy for detection of COVID-19 using an AI tool that can be applied internationally. In China, the companies Blue dot and Meta biota developed AI algorithms for accurate diagnosis of COVID-19. Ho (2020) discussed drug combinations for COVID-19, whose results must be evaluated to develop antiviral therapy for COVID-19. Drug combinations are screened and evaluated for drug dose compositions for personalized therapy are optimized using AI.

Das, Mishra & Gopalan (2020) highlighted the importance of open source machine learning tool for prediction of mortality risk among COVID-19 patients. The machine learning algorithm such as logistic regression, k-nearest neighbor, support vector machine, gradient boosting and random forest were used to analyze the mortality rate and found that logistic regression algorithm was the best one for mortality risk prediction.

A recent study by Kumar et al. (2021) highlighted the importance of artificial intelligence in diagnosis and prediction of COVID-19 disease. Further, the data sets and visualization techniques for COVID-19, designing of drugs for COVID-19 using artificial intelligence and role of deep learning and machine learning tools were discussed.

## Section: Features of ai

AI programming tools can help to identify signs of certain diseases (Caruso et al., 2020). Large volumes of health data are collected to identify a particular disease, including magnetic resonance images, X-ray results, CT scans, vaccinations, skin lesions, eye images, DNA sequences, blood samples, past medical history and current medications (Hosny et al., 2018) (Fig. 1). However, AI programming tools must be validated in large groups of people. Machine learning tools particularly deep learning algorithms have been used to diagnose disease automatically, which makes diagnosis cheaper and more accessible (Davenport & Kalakota, 2019). Using the data, the algorithms can draw conclusions in fraction of seconds and these can be accessed more easily for disease diagnosis. The process is inexpensive and less time-consuming for identifying disease compared with traditional methods of diagnosis (Agrebi & Larbi, 2020). In the case of COVID-19, two companies called Blue Dot and Meta biota (Allam, Dey & Jones, 2020) demonstrated the role of AI in early detection of SARS-CoV-2; Blue Dot predicted the outbreak areas in China, and Meta biota used big data analytics to count the outbreaks globally (Allam, Dey & Jones, 2020). In India, qure.ai algorithm tool has been used successfully to interpret the radiology images for diagnosis COVID-19and tuberculosis. The X-ray screening tool qXR (deep learning tool) was used for diagnostic and critical care management. Q Scout is another algorithm tool helps in contact monitoring of COVID-19 patients (https://qure.ai). RadVid-19 is the algorithm tool used by the Brazilian doctors to analyze chest X-rays and CT scans to find the spots in lungs which are markers of infection due to SARS-CoV-2 (https://radvid19.com.br/). Deep COVID-XR is the deep learning algorithm tool used for detecting COVID-19 in patients based on chest radiographs by US clinical radiologists during pandemic period (Wehbe et al., 2020). Elzeki et al., 2021 evaluated the performance of CXRVN (Chest X-ray COVID Network) deep learning computer aided model for early detection of COVID-19. In this model three different datasets were used and compared with pretrained models viz. Google net, Alex Net and Res Net. The evaluation results showed 94.5% accuracy for the proposed CXRVN model.

The data related to CT scan, MRI, X-ray, skin lesions, eye, blood tests, patient medical history, medicines, vaccines and genetic information applied for diagnosing the disease using artificial intelligence (Source: https://mindthegraph.com).

## Section: Covid-19 detection methods

The swab collected from suspected person is used for RNA extraction, conversion to cDNA, PCR amplification and finally fluorescence light data conversion into digital data. The digital graph describes the test sample is COVID-19 positive/negative. (Source: http://www.fredhutch.org/en/research/diseases/coronavirus/serology-testing.html; http://www.researchamerica.org/blog/explained-how-identify-active-covid-19-infection-people; http://www.medmastery.com/guide/covid-19-clinical-guide/how-rt-pcr-used-test-covid-19; www.advanced-biotechs.com/quantstudio).

## Section: Covid-19 detection methods › RT-PCR

Currently the corona virus SARS CoV-2 is detected using methods like RT-PCR, Rapid test kits, and CT scanning. In these methods, RT-PCR is preferred one and also called as gold standard method (Carter et al., 2020). In this method nasopharyngeal swab or oral pharyngeal swab is collected and kept in viral transport medium (Lopez et al., 2019). The genetic material i.e. RNA is extracted and converted into cDNA using reverse transcriptase enzyme. The cDNA further undergoes PCR amplification involves denaturation, annealing, extension and cleavage (Udugama et al., 2020). The DNA probe is used and in amplification process and it consists of reporter dye and quencher dye at 5′ end and 3′ end respectively. The reporter dye gets multiplied during amplification process, excited and leads to emission upon focusing a beam of light (fluorescence). The final step of this RT-PCR technique is conversion of light into digital data (Carter et al., 2020). The formation of graphs with cycle on x-axis and fluorescence intensity on y-axis is formed. The data is analyzed and considered as COVID positive or negative (Fig. 2). However, this method takes 2 days to release the output. In present adverse conditions there is undersupply of the RT-PCR kits. In order to renew this kit, something advanced and accurate tool are required whose response is efficient (Udugama et al., 2020).

The swab collected from suspected person is used for RNA extraction, conversion to cDNA, PCR amplification and finally fluorescence light data conversion into digital data. The digital graph describes the test sample is COVID-19 positive/negative. (Source: http://www.fredhutch.org/en/research/diseases/coronavirus/serology-testing.html; http://www.researchamerica.org/blog/explained-how-identify-active-covid-19-infection-people; http://www.medmastery.com/guide/covid-19-clinical-guide/how-rt-pcr-used-test-covid-19; www.advanced-biotechs.com/quantstudio).

## Section: Immunoassay method

The other method is immunoassay which is rapid test kit. In this, the immunoglobulins IgG and IgM antibodies are measured against the SARS-COV-2 proteins. The method is considered as fast and precise as it produces output in 10–15 min by examining whole blood (Jacofsky, Jacofsky & Jacofsky, 2020). In this the blood sample is collected and tested in which red colored lines are formed opposite to their respective sites as shown in Fig. 3. The presence of IgG and IgM antibodies results in the formation of red colored lines against ‘G’ site and ‘M’ site respectively (Jacofsky, Jacofsky & Jacofsky, 2020). Formation of red lines at the minimum of two confirms that the sample is having SARS-COV-2 proteins. However, this technique is not specific as it cannot detect virus in the incubation period and may show false negative result which leads to adverse effect in future (Udugama et al., 2020).

## Section: Ct and ai

Computed tomography (CT) is a sensitive medical imaging technique used for identification of diseases. It involves imaging the organs with the help of computational knowledge (Shi et al., 2020). AI algorithms are used to enhance the chest CT findings for rapid diagnosis. The method is sensitive as it captures every small detail of the lungs. For detection of COVID-19, the imaging features used are ground glass opacities, consolidations and crazy paving patterns (Ozturk et al., 2020). Considering the public health perspective and the need to quickly isolate patients with COVID-19, chest CT is used because it is more sensitive than chest radiography and other techniques. However, these methods can be used in combination for accurate and better results and can be accelerated with new AI algorithms (Xu et al., 2020). AI accelerates the process compared to conventional techniques and does not involve symptomatic treatment. Daily updates from patients can be studied, and the rate of infection can be inspected by observing each movement of an infected person (Davenport & Kalakota, 2019). A recent study by Li & Xia (2020) reported that CT scan data was analyzed for 51 patients and found good results. Hence, CT scan data can be used for rapid diagnosis of COVID-19. The AI-based mobile app AI4COVID-19 was developed for evaluating COVID-19 patients based on cough samples (Imran et al., 2020).

## Section: Artificial intelligence in drug discovery

The use of AI in pharmacogenomics and drug development quickens the process of drug production. Drug development and market release takes at least 14 years, but AI uses an in-silico approach, which makes in vitro and in vivo tests easier (Zhavoronkov, Vanhaelen & Oprea, 2020). The first step in drug discovery using AI is to set a hypothesis. Next the hypothesis is validated by selecting potential lead molecules from the lead database. The activity of the lead molecules is evaluated using in-vitro and in-vivo tests (Vamathevan et al., 2019). The potential lead molecule is said to be a drug after optimizing parameters like affinity to bind the target, adverse effects, efficacy, bioavailability and therapeutic effect (Batool, Ahmad & Choi, 2019; Chan et al., 2019). The potential lead molecule from thousands of compounds is identified using neural networks, homology modeling, protein fold prediction, omics analytics, SMILES, LSTM models, etc. (Fig. 4) (Yang et al., 2019). The drug toxicity is essential to prevent the side effects and toxic effects in humans. The web-based tools used for evaluating the toxicity are Deep Tox, Lim Tox, Tox21 and admetSAR (Cheng et al., 2012; Yang et al., 2018). In COVID-19 disease, the enzyme 3CLpro can be considered as a target that is inhibited by a lead molecule. D. novo design tools would be used to obtain a potential drug candidate for COVID-19 (Amin et al., 2020). The AI tools used in drug discovery are PADME, MANTRA, PREDICT, deep neural Net QSAR, Deep chem, Deep Tox, XenoSite, SMARTCyp, FAME, ORGANIC, Potential Net, Hit Dexter, Delta Viva, Neural graph finger print, Alpha fold and Chemputer (Paul et al., 2021).

However, advanced and new algorithms are required to substitute the human brains in near future. Collaboration among biotechnology, pharmaceutical and AI companies could streamline research and development efforts to identify novel, rare drug molecules and also personalized medicine.

## Section: Conclusion

The AI supports the future needs of medicine and health care by accelerating disease identification and drug discovery process. The technology develops the machine learning tools in health care particularly in the area of emerging diseases like COVID-19, regenerative medicine, gene therapy and pharmacology. Further, the artificial intelligence entails personalized medicine, assisted diagnostics, biomarkers, drug discovery and development. However, the advanced and new algorithms are required to substitute the human brains in near future. This enables an opportunity to collaborate biotech, pharma and artificial intelligence companies to streamline their research and development to identify the novel, rare drug molecules and also personalized medicine.

## Section: Supplemental Information

Click here for additional data file.

## Section: Acknowledgments

The authors thank mind the graph for providing the web platform to draw the figure.

## Section: Funding Statement

This work was supported by DST-FIST Networking Facility Project LSI-576/201 and Vignan’s Foundation for Science, Technology and Research (Vadlamudi-522213). The funders had no role in study design, data collection and analysis, decision to publish, or preparation of the manuscript.

## Section: Associated Data

Click here for additional data file.

## Section: Associated Data › Supplementary Materials

Click here for additional data file.

## Section: Associated Data › Data Availability Statement

The following information was supplied regarding data availability:

This is a literature review therefore there is no code or raw data.


---

# Predicting Antituberculosis Drug-Induced Liver Injury Using an Interpretable Machine Learning Method: Model Development and Validation Study

- **Authors:** Tao Zhong, Zian Zhuang, Xiaoli Dong, Ka Hing Wong, Wing Tak Wong, Jian Wang, Daihai He, Shengyuan Liu
- **Issuer:** JMIR medical informatics
- **Type:** Scientific article
- **Published:** 2021-07-20
- **Language:** en
- **DOI:** 10.2196/29226
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34283036/
- **Licence:** CC-BY

## Section: Abstract

AbstractBackgroundTuberculosis (TB) is a pandemic, being one of the top 10 causes of death and the main cause of death from a single source of infection. Drug-induced liver injury (DILI) is the most common and serious side effect during the treatment of TB.ObjectiveWe aim to predict the status of liver injury in patients with TB at the clinical treatment stage.MethodsWe designed an interpretable prediction model based on the XGBoost algorithm and identified the most robust and meaningful predictors of the risk of TB-DILI on the basis of clinical data extracted from the Hospital Information System of Shenzhen Nanshan Center for Chronic Disease Control from 2014 to 2019.ResultsIn total, 757 patients were included, and 287 (38%) had developed TB-DILI. Based on values of relative importance and area under the receiver operating characteristic curve, machine learning tools selected patients’ most recent alanine transaminase levels, average rate of change of patients’ last 2 measures of alanine transaminase levels, cumulative dose of pyrazinamide, and cumulative dose of ethambutol as the best predictors for assessing the risk of TB-DILI. In the validation data set, the model had a precision of 90%, recall of 74%, classification accuracy of 76%, and balanced error rate of 77% in predicting cases of TB-DILI. The area under the receiver operating characteristic curve score upon 10-fold cross-validation was 0.912 (95% CI 0.890-0.935). In addition, the model provided warnings of high risk for patients in advance of DILI onset for a median of 15 (IQR 7.3-27.5) days.ConclusionsOur model shows high accuracy and interpretability in predicting cases of TB-DILI, which can provide useful information to clinicians to adjust the medication regimen and avoid more serious liver injury in patients.Keywords: accuracy, drug, drug-induced liver injury, high accuracy, injury, interpretability, interpretation, liver, machine learning, model, prediction, treatment, tuberculosis, XGBoost algorithm

## Section: Introduction

Tuberculosis (TB) is an infectious disease caused by the bacillus Mycobacterium tuberculosis. It is one of the top 10 causes of death worldwide and the leading cause of death from a single infectious disease [1]. In 2019, approximately 10 million people were diagnosed with TB and 1.4 million people died worldwide [1]. To prevent the spread of pulmonary TB, timely and effective anti-TB treatment is very important [2]. First-line anti-TB drugs include pyrazinamide (PZA), ethambutol (EMB), isoniazid (INH), and rifampin (RIF) [3-6]. When treating patients with TB, drug-induced liver injury (DILI) is the most frequent and serious side effect [7-10]. Among various populations, the incidence of TB-DILI ranges from 2.3% to 27.7% during anti-TB therapy [11-14]. Researchers have suggested that anti-TB drugs are hepatotoxic [11,15-18].

TB-DILI may result from direct toxic injury to hepatocytes by anti-TB drugs or their metabolites or immune-mediated liver injury and induction of hepatocyte apoptosis caused by anti-TB drugs that trigger multiple inflammatory immune pathways [11,19]. TB-DILI is characterized by a transient mild elevation of transaminases or acute hepatitis [20]. Fulminant hepatic failure is likely to develop in severe cases, whereas chronic hepatitis occurs in a minority of patients.

Currently, clinical liver tests usually include biochemical parameters of blood, such as transaminases including alanine transaminase (ALT), alkaline phosphatase, bilirubin, lactate dehydrogenase, and albumin, along with liver imaging and histopathologic evaluation. It is difficult to distinguish DILI from non-DILI on the basis of these indicators, since test results are largely consistent in DILI and non-DILI detection. In addition, clinical markers commonly used at present, accounting for neither differences in type and mechanisms of action of hepatotoxic drugs nor individual patients’ characteristics, only facilitate evaluation based on toxicity outcomes [21]. Therefore, identification of predictors at clinical stages and risk predictors of TB-DILI among patients has become an urgent and necessary task.

Previous studies have shown that TB-DILI is associated with some demographic characteristics and underlying chronic disease [12,22-26]. Patterson et al [27] suggested that an increase in pretreatment ALT and the gradient of ALT changes increase the risk of late TB-DILI. Thus, in addition to the cumulative anti-TB drug dose, ALT levels and demographic variable such as age, gender, education level, income, and BMI were included in our model as predictors. Various models are used to identify drugs associated with the risk of DILI at the preclinical stage [28]. Machine learning models have demonstrated strong predictive power and retained a simple form for communication with researchers [29-39]. XGBoost is a boosting ensemble machine learning algorithm that integrates a few classification and regression trees models to form a strong classifier [40,41]. It performs well in dealing with nonlinear and complex relationships among variables [42]. We designed an interpretable prediction model by using the XGBoost algorithm and identified the most robust and meaningful predictors of the risk of TB-DILI. Then, using these discriminative predictors, the machine learning model built an interpretable decision tree to provide early warning signals before TB-DILI occurs, so as to help clinicians adjust the medication plan in time and potentially reduce the possibility of TB-DILI. In this study, we retrospectively assessed 757 patients with TB who were registered for treatment in Nanshan District (Shenzhen, China) from 2014 to 2019.

## Section: Methods › Data

We extracted data on 757 pulmonary TB cases registered in the Hospital Information System of Shenzhen Nanshan Center for Chronic Disease Control from 2014 to 2019, including those that are smear-positive and undergoing initial treatment. Some patients did not have continuous treatment or were initially discharged from hospital and subsequently rehospitalized, resulting in the recorded treatment duration exceeding the normal range and unclear cumulative dosage of anti-TB drugs. Such abnormal cases are not able to contribute to predictions among patients receiving regular treatment. Thus, we selected 300 days as a time-window empirically on the basis of the typical course of TB treatment [1]. We excluded cases of TB-DILI that were recorded 300 days after the start of the anti-TB treatments. In total, data from 743 patients were finally included in the model. We defined patients as positive DILI cases in accordance with the American Thoracic Society criteria [11]: in the presence of hepatitis symptoms, the increase in ALT levels was 3-fold the normal upper limit, and in the absence of hepatitis symptoms, this increase was 5-fold the normal upper limit.

Patients’ demographic and clinical data included gender, age, weight, education level, income, height, hepatitis B status, diabetes status, cumulative anti-TB drug dose, and ALT levels. For patients who did not develop TB-DILI, we collected their total amount of prescribed anti-TB medication as of the latest hepatic examination. For patients who developed TB-DILI, we recorded their cumulative dose of anti-TB medication as of the time when TB-DILI was detected. In addition, we measured the patient’s most recent ALT levels before the last hepatic examination, and the average rate of change of the last 2 ALT levels tested before the final liver function test. We calculated the cumulative dose of each drug separately (PZA, RFP, EMB, and INH) for combination drug therapy.

Upon initiation of therapy, the patients were segregated to form the training and validation data sets. The data of patients admitted before April 2019 (607 patients and 186 smear-positive cases) and after April 2019 (136 patients and 95 smear-positive cases) were included in the training and validation data sets, respectively.

## Section: Methods › Descriptive Statistics

Descriptive statistics were calculated for positive and TB-DILI cases. Demographic and laboratory data of the 2 groups were compared using 2-sample t tests for normally distributed continuous variables, the Kruskal–Wallis rank sum test for nonnormally distributed continuous variables, and chi-square tests for categorical variables. Missing values were omitted when tested for differences. Multimedia Appendix 1 shows the proportion of missing values for each variable.

## Section: Methods › Prediction Model

We used the XGBoost algorithm for the prediction model [41]. XGBoost is a high-performance machine learning algorithm based on the tree boosting system [43-47]. It uses a sparsity-aware learning algorithm to process sparse data and weighted quantile sketch to approximate tree learning [41]. Since the decision tree is a simple classifier composed of hierarchically organized dichotomous determinations, its structure also demonstrates good interpretability [48-50]. In addition, the model can deal with missing values well. When the model searches for the best candidate split criteria for tree growth, they will also assign a default direction for the missing values on those nodes [41]. The interpretable criteria and high tolerance for missing data in the decision tree make the model robust and meaningful when dealing with clinical data. To obtain a model that can be conveniently applied in a clinical setting, we attempted to reduce the complexity of the model as much as possible. Hence, we choose the single-tree XGBoost algorithm as the prediction model.

To build the model, we first included all demographic and clinical data as predictors. The dependent variable is DILI status, which is a binary outcome. We trained the single-tree XGBoost algorithm with the training set. By considering each feature’s contribution for each tree in the model, we determined their relative importance to the tree model [51]. We repeated stratified 10-fold cross-validation 100 times to model on the training data set to obtain the mean value of each feature’s relative importance. Then, we arranged the top 10 predictors in accordance with their relative importance. The predictors were added into the model individually in descending order of relative importance to form 10 candidate models. We repeated stratified 10-fold cross-validation 100 times to the candidate models on the basis of the training data set to obtain the mean area under the receiver operating characteristic curve (AUC) and selected the model with the maximum AUC as the final model. Then, we trained the selected model with the whole training data set to obtain the interpretable decision tree. The detailed process of the stratified k-fold cross-validation and the parameters set in model is provided in Multimedia Appendix 1.

## Section: Methods › Evaluation of Model Performance

We trained the model with the whole training data set and applied the model on the validation data set. We then evaluated the prediction results on the basis of the confusion matrix, which is a specific table to visualize the performance of a classification model [52]. In accordance with the confusion matrix, we calculated the value of the following evaluation indicators: precision, recall, F1 value, classification accuracy, and balanced error rate. Detailed descriptions of the formulae for the indicators are provided in Multimedia Appendix 1. To determine whether the model can send early an warning signal in time, we also calculated the duration from the timepoint when model sent the warning signal to the actual date of TB-DILI diagnosis among incorrectly classified cases. Meanwhile, we compared the performance (AUC) of the single-tree XGBoost algorithm with that of the multitree XGBoost algorithm, logistic regression, single-tree random forest algorithm, and multitree random forest algorithm through 10-fold cross-validation using the whole data set. We determined 95% CI values for AUC values with the DeLong method [53]. We applied selected variables to train the single-tree XGBoost model since variable selection is part of the whole algorithm. The complete data set was applied to train the other models. In addition, we applied multiple imputation by chained equations [54] to address missing data for logistic regression.

## Section: Methods › Sensitivity Analysis

We selected 250 days and 350 days as alternative time windows to filter data. Then, we trained the model and compared the selected predictors. Performance (AUC) of the original model and that of 2 alternative models were also compared on the basis of the whole data set through 10-fold cross-validation. All analyses were performed with R (version 4.0.4, The R Foundation). The codes used in this study can be found in the GitHub repository [55].

## Section: Results

In total, 743 patients were included in the analysis, of whom 281 (37.8%) and 462 (62.2%) were classified as TB-DILI–positive and –negative, respectively. Table 1 shows the descriptive statistics. The median age of patients was 30 (IQR 25-45) years, and 484 (65.1%) patients were male. Most patients (n=272, 43.5%) had a bachelor’s degree or higher education level. Median weight of the patients was 56 (IQR 50-63) kg and their median height was 168 (IQR 160-173) cm. In total, 24 (3.2%) patients had hepatitis B, and 69 (9.3%) patients had diabetes. The proportion of male patients who had DILI (n=281, 74.0%) was significantly higher than that of patients who did not have DILI (n=276, 59.7%). The most recently determined ALT level and average rate of change of the last 2 ALT measures of patients with DILI (27.0 U/L, IQR 17.0-34.0 U/L and 0.27 U/[Lday], IQR 0.0-0.6 U/[Lday], respectively) were significantly higher than those of patients who did not have DILI (11.0 U/L, IQR 8.3-16.0 U/L and 0.0 U/[Lday], IQR –0.1 to 0.1 U/[Lday], respectively). Figure 1 shows the number of TB-DILI cases on each day after the initiation of anti-TB treatment. The median time from treatment to the onset of DILI is 27 (IQR 15-48) days.

Figure 2 shows the top 10 important variables selected by the single-tree XGBoost model. The most recent ALT levels were found to be the most important factor in the prediction process. We added 10 variables in the model individually to form 10 candidate models. After 10-fold cross-validation 100 times with the training and testing data sets, the model with 4 variables had the maximum AUC value (Table 2). Thus, we selected the model with 4 variables (the most recent ALT measure, average rate of change of the last 2 ALT measures, cumulative dose of PZA, and cumulative dose of EMB) as the final model. Then, we trained the selected model with the whole training data set. Figure 3 shows the content of a single decision tree of the model. The decision process starts from the most recent ALT test value, and then dichotomous determinations are made at each node in the decision tree; this process ends with outputting predictions (high or low risk of DILI).

Table 3 summarizes the performance of the model on basis of the validation data set (136 cases). A total of 70 cases of DILI were correctly predicted, and 33 negative cases were successfully predicted. The model had a precision of 90%, recall of 74%, classification accuracy of 76%, balanced error rate of 77%, and F1 value of 81%. For correctly predicted cases, the median number of days between DILI onset and the provision of warnings of high risk by the model for the patients was 15 (IQR 7.3-27.5) days (Figure 4). Multimedia Appendix 1 shows a comparison of the performance of the single-tree XGBoost model and the multitree XGBoost model, logistic regression model, and multi- or single-tree random forest model on the whole data set, based on the receiver operating characteristic curve and the AUC. The multitree XGBoost model performed the best (AUC=0.940, 95% CI 0.924-0.956). The single-tree XGBoost model had an AUC of 0.912 (95% CI 0.890-0.935), which was very similar to that of the multitree model and higher than that of the rest of the models.

Table 4 shows the AUC values for candidate models under different time windows upon sensitivity analysis. Both final models under different time windows included the 4 most important predictors, same as those of our original model. The most recent ALT measure, average rate of change of patients’ last 2 ALT measures, and cumulative dose of PZA were identified as the best predictors in all 3 models. Nevertheless, our original model also selected the cumulative dose of EMB as an important predictor and, while being trained on the basis of 250-day and 350-day time windows, selected cumulative doses of RFP and INH, respectively. The performance of the 3 models is summarized in Multimedia Appendix 1, which shows that all 3 models have similar patterns of the receiver operating characteristic curve and provided largely consistent AUC values.

Demographic and clinical characteristics of patients (N=743).

Days from tuberculosis treatment to the onset of drug-induced liver injury among the patients in our study. DILI: drug-induced liver injury, TB: tuberculosis.

Top 10 important variables selected by the single-tree XGBoost model. ALT: alanine transaminase, EMB: ethambutol, INH: isoniazid, PZA: pyrazinamide, RFP: rifampicin.

Summary of AUCa values for candidate model.

Detailed overview of the single decision tree of the model. The decision process starts from the left (most recent ALT measure) and ends at the right ("Yes": high risk of drug-induced liver injury or "No": low risk of drug-induced liver injury). Dichotomous determinations are made at every node in the decision tree. Cumulative doses of PZA and EMB are referenced. Black paths are the default direction for missing values. ALT: alanine transaminase, EMB: ethambutol, PZA: pyrazinamide, RFP: rifampicin.

Model performancea with the validation data set.

Number of days between the onset of drug-induced liver injury and the model providing warnings of high risk for patients with TB-DILI. TB-DILI: tuberculosis with drug-induced liver injury.

Summary of AUCa values for candidate models upon sensitivity analysis.

## Section: Discussion › Principal Findings

Anti-TB drugs are one of the most common and effective means of treating TB in the clinical setting and can effectively control disease progression among patients with TB. Nevertheless, studies have suggested that patients are likely to develop DILI during the treatment process owing to the hepatotoxicity of anti-TB drugs [11,15-18] and long duration of TB treatment [56]. Clinicians often have difficulties in predicting the efficacy of anti-TB treatment as well as liver injury status in patients with TB. To identify reliable and accurate predictors and better predict DILI during TB treatment, we built the single-tree XGBoost machine learning model and selected variables with significant effects. Our model can provide suggestions to clinicians to adjust their medication regimens in a timely manner to avoid causing more severe liver injury. To our knowledge, this is the first time that XGBoost model has been applied to predict DILI at the clinical treatment stage.

Interestingly, the proportion of TB-DILI cases is significantly higher among men compared than among women (Table 1). This result is consistent with that of Chang et al [23], which suggested that males were 2.1-fold more likely to develop hepatotoxicity than females after being adjusted for age. We found that patients with DILI had significantly higher values for the most recent ALT measure and higher mean rates of change between the 2 most recent ALT measures than those without DILI (Table 1). Singanayagam et al [57] also demonstrated the association between pretreatment ALT and 2-week on-treatment ALT levels in patients with DILI.

Based on the results of variable selection, the significant predictors for predicting DILI are the most recent ALT measure, average change rate of the last 2 ALT measures, and the cumulative doses of PZA and EMB. According to the decision tree (Figure 3), the decision process of our model was to initially focus on the most recent ALT measure of a patient and then comprehensively evaluate the rate of change in ALT levels and the cumulative intake dose of both PZA and EMB to make predictions. A previous study [58] reported that the initial concentration of PZA and its metabolites are associated with hepatotoxicity [58]. Cao et al [59] suggested that combination therapy with PZA, INH, and RIF is likely to increase the risk of hepatotoxicity compared to monotherapy with INH and RIF. In addition, the addition of a low dose of PZA to a regimen of INH, RIF, and EMB did not significantly increase the incidence of DILI in the first 2 months of anti-TB therapy [60]. In the branches of our single-tree model (Figure 3), thresholds to determine whether the cumulative dose of anti-TB drugs contributed to the development of DILI under different situations were also provided.

Currently, various machine learning algorithms have been assessed for early detection of DILI and have shown to have a high prediction accuracy [61,62]. Xu et al [63] proposed a deep learning model, which achieved a classification accuracy of 86.9% in external validation for DILI prediction after training with a set of 475 samples. Dominic et al [64] combined mechanistic detection of hepatic safety with a Bayesian machine learning algorithm to build the model, which has a balanced accuracy of 86%, sensitivity of 87%, and specificity of 85%, thus improving the prediction of DILI risk. In addition, the XGBoost model was applied to increase the specificity of mass TB screening [65]. Our model also demonstrated the high prediction accuracy and interpretability of the XGBoost model at the clinical treatment stage.

Compared with alternative models, the multitree XGBoost model performed the best, as revealed from the AUC value upon cross-validation (Multimedia Appendix 1). The single-tree XGBoost model displayed similar performance to that of the multitree XGBoost model. Since the single-tree model is easier to interpret, takes up fewer computing resources, and provides predictions in a shorter period of time, the single-tree XGBoost model is more suitable in the clinical setting. In addition, the single-tree XGBoost model performed better than multitree random forest model and single-tree random forest model. The logistic regression model is also interpretable. Nevertheless, since linear models cannot directly process missing values, the missing clinical data could affect the performance of logistic regression. For multiple imputation, additional assumptions and prior information are required, which is likely to complicate the process and reduce the robustness of the model. In addition, sensitivity analysis has shown that our model has a consistently high prediction accuracy when trained with different time windows. Therefore, the single-tree XGBoost model is the most appropriate among all candidate models.

## Section: Discussion › Limitations

Our model also has some limitations of note. First, although the model identified the most meaningful predictors for the risk of TB-DILI, pathological conclusions should be made cautiously since the model was entirely driven by the data input. The model needs to be adjusted accordingly when the data are updated. Second, there is a lack of validation for our model on other data sets. Future studies could further explore these issues by applying the model in a combined larger data set. Inputting more data is likely to contribute to the identification of more effective predictors and generate higher prediction accuracy. In addition, it is also necessary to validate the model’s performance on an imbalanced data set to determine whether a further reweighting or resampling is needed to improve prediction accuracy.

## Section: Discussion › Conclusions

We developed a single-tree XGBoost model, which demonstrated the patients’ most recent ALT measure, average rate of change of patients’ 2 latest ALT measures, and cumulative doses of PZA and EMB as the best predictors for assessing the DILI risk. In the validation data set, the model displayed high accuracy (precision=90%, recall=74%, classification accuracy=76%, and balanced error rate=77%) and interpretability in predicting the TB-DILI cases. In addition, the median number of days between the model providing warnings of high risk among patients and DILI onset is 15 (IQR 7.3-27.5) days, which suggests that it is possible for clinicians to adjust the medication regimen by referring to the model’s prediction and avoid causing more serious liver injury.

## Section: Acknowledgments

Funding was obtained from Shenzhen Science and Technology Innovation Commission: Research on Early Warning Model of Drug-induced Liver Injury in Tuberculosis Patients Based on Machine Learning (award# JCYJ20190809153201668) and the Sanming Project of Medicine in Shenzhen (award# SZSM201603029).


---

# Prefix-Tuning: Optimizing Continuous Prompts for Generation

- **Authors:** Xiang Lisa Li, Percy Liang
- **Issuer:** Scientific journal
- **Type:** Scientific article
- **Published:** 2021-01-01
- **Language:** en
- **DOI:** 10.18653/v1/2021.acl-long.353
- **Source:** https://doi.org/10.18653/v1/2021.acl-long.353
- **Licence:** CC-BY

## Page 1

Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics
and the 11th International Joint Conference on Natural Language Processing, pages 4582–4597
August 1–6, 2021. ©2021 Association for Computational Linguistics
4582
Preﬁx-Tuning: Optimizing Continuous Prompts for Generation
Xiang Lisa Li
Stanford University
xlisali@stanford.edu
Percy Liang
Stanford University
pliang@cs.stanford.edu
Abstract
Fine-tuning is the de facto way of leveraging
large pretrained language models for down-
stream tasks. However, ﬁne-tuning modiﬁes
all the language model parameters and there-
fore necessitates storing a full copy for each
task. In this paper, we propose preﬁx-tuning, a
lightweight alternative to ﬁne-tuning for natu-
ral language generation tasks, which keeps lan-
guage model parameters frozen and instead op-
timizes a sequence of continuous task-speciﬁc
vectors, which we call the preﬁx. Preﬁx-tuning
draws inspiration from prompting for language
models, allowing subsequent tokens to attend
to this preﬁx as if it were “virtual tokens”.
We apply preﬁx-tuning to GPT-2 for table-to-
text generation and to BART for summariza-
tion. We show that by modifying only 0.1% of
the parameters, preﬁx-tuning obtains compara-
ble performance in the full data setting, outper-
forms ﬁne-tuning in low-data settings, and ex-
trapolates better to examples with topics that
are unseen during training.
1
Introduction
Fine-tuning is the prevalent paradigm for using
large pretrained language models (LMs) (Radford
et al., 2019; Devlin et al., 2019) to perform down-
stream tasks (e.g., summarization), but it requires
updating and storing all the parameters of the LM.
Consequently, to build and deploy NLP systems
that rely on large pretrained LMs, one currently
needs to store a modiﬁed copy of all the LM pa-
rameters for each task. This can be prohibitively
expensive given the size of current LMs; for exam-
ple, GPT-2 has 774M parameters (Radford et al.,
2019) and GPT-3 has 175B parameters (Brown
et al., 2020).
A natural approach to this problem is lightweight
ﬁne-tuning, which freezes most of the pretrained
parameters and only tunes a smaller set of param-
eters. For example, adapter-tuning (Rebufﬁet al.,
Figure 1:
Fine-tuning (top) updates all LM param-
eters (the red Transformer box) and requires storing
a full model copy for each task. We propose preﬁx-
tuning (bottom), which freezes the LM parameters and
only optimizes the preﬁx (the red preﬁx blocks). Con-
sequently, we only need to store the preﬁx for each
task, making preﬁx-tuning modular and space-efﬁcient.
Note that each vertical block denote transformer activa-
tions at one time step.
2017; Houlsby et al., 2019) inserts additional task-
speciﬁc layers between the layers of pretrained
language models. Adapter-tuning has promising
performance on natural language understanding
and generation benchmarks, attaining comparable
performance with ﬁne-tuning while adding only
around 2–4% task-speciﬁc parameters (Houlsby
et al., 2019; Lin et al., 2020).
At the limit, GPT-3 (Brown et al., 2020) can
be deployed using in-context learning, which is
a form of prompting, without modifying any LM
parameters. In in-context learning, Brown et al.
(2020) prepend a natural language task instruction
(e.g., TL;DR for summarization) and a few exam-
ples to the task input, and then generate the task
output from the LM. However, since Transformers
can only condition on a bounded-length context
(e.g., 2048 tokens for GPT-3), in-context learning
is restricted to very small training sets.

## Page 2

4583
In this paper, we propose preﬁx-tuning, a
lightweight alternative to ﬁne-tuning for natural lan-
guage generation (NLG) tasks, inspired by prompt-
ing. Consider the task of generating a textual de-
scription of a data table, as shown in Figure 1,
where the task input is a linearized table (e.g.,
“name: Starbucks | type: coffee shop”) and the out-
put is a textual description (e.g., “Starbucks serves
coffee.”). Preﬁx-tuning prepends a sequence of
continuous task-speciﬁc vectors to the input, which
we call a preﬁx, depicted by red blocks in Figure 1
(bottom). To generate each token, the LM can at-
tend to the preﬁx as if it were a sequence of “virtual
tokens”, but unlike prompting, the preﬁx consists
entirely of free parameters which do not correspond
to real tokens. In contrast to ﬁne-tuning in Figure 1
(top), which updates all LM parameters and thus
requires storing a tuned copy of the model for each
task, preﬁx-tuning only optimizes the preﬁx. Con-
sequently, we only need to store one copy of the
large LM and a learned task-speciﬁc preﬁx, yield-
ing a very small overhead for each additional task
(e.g., 250K parameters for table-to-text).
In contrast to full ﬁne-tuning, preﬁx-tuning is
also modular: we train an upstream preﬁx which
steers an unmodiﬁed LM, and therefore, a single
LM can support many tasks at once. In the con-
text of personalization where the tasks correspond
to users (Shokri and Shmatikov, 2015; McMahan
et al., 2016), we would have a separate preﬁx for
each user trained only on that user’s data, thereby
avoiding data cross-contamination. Moreover, the
preﬁx-based architecture enables us to even pro-
cess examples from multiple users/tasks in a single
batch, something that is not possible with other
lightweight ﬁne-tuning approaches like adapter-
tuning.
We evaluate preﬁx-tuning on table-to-text gen-
eration using GPT-2 and abstractive summariza-
tion using BART. In terms of storage, preﬁx-tuning
stores 1000x fewer parameters than full ﬁne-tuning.
In terms of performance when trained on full
datasets, preﬁx-tuning and ﬁne-tuning are compara-
ble for table-to-text (§6.1), while preﬁx-tuning suf-
fers a small degradation for summarization (§6.2).
In low-data settings, preﬁx-tuning outperforms ﬁne-
tuning on both tasks (§6.3). Preﬁx-tuning also ex-
trapolates better to tables (for table-to-text) and arti-
cles (for summarization) with unseen topics (§6.4).
2
Related Work
Fine-tuning for natural language generation.
Current state-of-the-art systems for natural lan-
guage generation (NLG) are based on ﬁne-tuning
pretrained LMs. For table-to-text generation, Kale
(2020) ﬁne-tunes a sequence-to-sequence model
(T5; Raffel et al., 2020). For extractive and abstrac-
tive summarization, researchers ﬁne-tune masked
language models (e.g., BERT; Devlin et al., 2019)
and encode-decoder models (e.g., BART; Lewis
et al., 2020), respectively (Zhong et al., 2020; Liu
and Lapata, 2019; Raffel et al., 2020). For other
conditional NLG tasks such as machine transla-
tion and dialogue generation, ﬁne-tuning is also the
prevalent paradigm (Zhang et al., 2020c; Stickland
et al., 2020; Zhu et al., 2020; Liu et al., 2020). In
this paper, we focus on table-to-text using GPT-2
and summarization using BART, but preﬁx-tuning
in principle can be applied to other generation tasks
and pretrained models, such as masked LMs.
Lightweight
ﬁne-tuning.
Preﬁx-tuning
falls
under the broad class of lightweight ﬁne-tuning
methods, which freeze most of the pretrained
parameters and only tune a smaller set of param-
eters. The key question is how to augment the LM
architecture and decide which subset of pretrained
parameters to tune. One line of research learns a
task-speciﬁc parameter mask (Zhao et al., 2020;
Radiya-Dixit and Wang, 2020).
Another line
of research inserts new modules with trainable
parameters. For example, Zhang et al. (2020a)
trains a “side” network that is fused with the
pretrained model via summation; adapter-tuning
inserts task-speciﬁc layers (adapters) between each
layer of the pretrained LM (Houlsby et al., 2019;
Lin et al., 2020; Rebufﬁet al., 2017; Pfeiffer et al.,
2020). Compared to this line of work, which tunes
around 3.6% of the LM parameters, our method
obtains a further 30x reduction in task-speciﬁc
parameters, tuning only 0.1% while maintaining
comparable performance on table-to-text tasks.
Prompting.
Prompting is a way of leveraging a
pretrained LM by prepending instructions and a
few examples to the task input and generating the
task output from the LM. For autoregressive LMs,
the most successful form of prompting is GPT-3’s
in-context learning (Brown et al., 2020), which
uses manually designed prompts to adapt its gen-
eration for different tasks in few-shot settings. For
masked LMs like BERT and RoBERTa (Liu et al.,

## Page 3

4584
2019), prompt engineering has been explored for
natural language understanding tasks (Jiang et al.,
2020; Schick and Sch¨utze, 2020). For example,
AutoPrompt (Shin et al., 2020) searches for a se-
quence of discrete trigger words and concatenates
it with each input to elicit sentiment or factual
knowledge from BERT and RoBERTa. In contrast
with AutoPrompt, our method optimizes contin-
uous preﬁxes, which are more expressive (§7.2);
moreover, we focus on language generation tasks.
Continuous vectors have been used to steer LMs;
for example, Subramani et al. (2020) showed that a
pretrained LSTM language model can reconstruct
arbitrary sentences by optimizing a continuous vec-
tor for each sentence, making the vector input-
speciﬁc. In contrast, preﬁx-tuning optimizes a task-
speciﬁc preﬁx that applies to all instances of that
task. As a result, unlike the previous work whose
application is limited to sentence reconstruction,
preﬁx-tuning can be applied to NLG tasks.
Controllable generation.
Controllable genera-
tion aims to steer a pretrained language model
to match a sentence-level attribute (e.g., positive
sentiment or sports). Such control can happen at
training time: Keskar et al. (2019) pretrains the
language model (CTRL) to condition on metadata
such as keywords or URLs. The control can also
happen at decoding time, by weighted decoding
(GeDi, Krause et al., 2020) or iteratively updat-
ing the past activations (PPLM, Dathathri et al.,
2020). However, there is no straightforward way
to apply these controllable generation techniques
to enforce ﬁne-grained control over generated con-
tents, as demanded by tasks like table-to-text and
summarization.
P*-tuning.
Preﬁx tuning is an instance of a new
class of methods that has emerged, which we call
p*-tuning (since the other prominent instances, p-
tuning and prompt-tuning, also start with p), all
based on the idea of optimizing a continuous preﬁx
or prompt. Concurrent with our work, Qin and Eis-
ner (2021) learn mixtures of soft ﬁll-in-the-blank
prompts to elicit knowledge from LMs such as
BERT and BART. Hambardzumyan et al. (2021)
learns task-speciﬁc embeddings that adapts BERT
for sentiment classiﬁcation. Both works show that
tuning soft prompts outperforms previous work,
which optimizes over discrete prompts. P-tuning
(Liu et al., 2021) shows that jointly updating the
prompt embeddings and LM parameters improves
GPT-2’s performance on natural language under-
standing tasks, in both few-shot and full data set-
tings. In a followup work, Prompt-tuning (Lester
et al., 2021) simpliﬁes our approach and applies
it to T5 (Raffel et al., 2020), demonstrating that
the performance gap between ﬁne-tuning and p*-
tuning vanishes as the model size grows.
3
Problem Statement
Consider a conditional generation task where the
input x is a context and the output y is a sequence
of tokens. We focus on two tasks, shown in Fig-
ure 2 (right): In table-to-text, x corresponds to a lin-
earized data table and y is a textual description; in
summarization, x is an article and y is a summary.
3.1
Autoregressive LM
Assume we have an autoregressive neural language
model pφ(y | x) parametrized by φ (e.g., GPT-2;
Radford et al., 2019). As shown in Figure 2 (top),
let z = [x; y] be the concatenation of x and y;
let Xidx denote the sequence of indices that corre-
sponds to x, and Yidx denote the same for y.
The activation vector at time step i is hi ∈Rd,
where hi = [h(1)
i ; · · · ; h(n)
i
] is a concatenation of
all activation layers at this time step, and h(j)
i
is the
activation vector of the j-th layer at time step i.1
An autoregressive neural LM computes hi as a
function of zi and the past activations in its left
context, as follows:
hi = LMφ(zi, h<i),
(1)
where the last layer of hi is used to compute the
distribution for the next token: pφ(zi+1 | h≤i) =
softmax(Wφ h(n)
i
) and Wφ is a matrix that maps
h(n)
i
to logits over the vocabulary.
3.2
Encoder-Decoder Architecture
We can also use an encoder-decoder architecture
(e.g., BART; Lewis et al., 2020) to model pφ(y | x),
where x is encoded by the bidirectional encoder,
and the decoder predicts y autoregressively (condi-
tioned on the encoded x and its left context). We
use the same indexing and activation notation, as
shown in Figure 2 (bottom): each hi for i ∈Xidx
is computed by the a bidirectional encoder; each
hi for i ∈Yidx is computed by an autoregressive
decoder using the same equation (1).
1In GPT-2, h(n)
i
consists of a key-value pair, and the di-
mension of each key and value is 1024.

## Page 4

4585
Figure 2: An annotated example of preﬁx-tuning using an autoregressive LM (top) and an encoder-decoder model
(bottom). The preﬁx activations ∀i ∈Pidx, hi are drawn from a trainable matrix Pθ. The remaining activations are
computed by the Transformer.
3.3
Fine-tuning
In the full ﬁne-tuning framework, we initialize with
the pretrained parameters φ. Here pφ is a train-
able language model distribution and we perform
gradient updates on the following log-likelihood
objective:
max
φ
log pφ(y | x) = max
φ
X
i∈Yidx
log pφ(zi | h<i).
(2)
4
Preﬁx-Tuning
We propose preﬁx-tuning as an alternative to full
ﬁne-tuning for conditional generation tasks. We
ﬁrst provide intuition in §4.1 before deﬁning our
method formally in §4.2.
4.1
Intuition
Prompting has demonstrated that conditioning on a
proper context can steer the LM without changing
its parameters. For example, if we want the LM
to generate a word (e.g., Obama), we can prepend
its common collocations as context (e.g., Barack),
and the LM will assign much higher probability to
the desired word. Extending this intuition beyond
generating a single word or sentence, we want to
ﬁnd a context that steers the LM to solve an NLG
task. Intuitively, the context could inﬂuence the
encoding of the task input x by guiding what to ex-
tract from x, and it could inﬂuence the generation
of the task output y by steering the next token distri-
bution. However, it’s non-obvious whether such a
context exists. Using natural language task instruc-
tions (e.g., “summarize the following table in one
sentence”) for the context might guide a human to
solve the task, but this fails for moderately-sized
pretrained LMs.2 Optimizing over the discrete in-
structions might help, but discrete optimization is
computationally challenging.
Instead of optimizing over discrete tokens, we
can optimize the instruction as continuous word em-
beddings, whose effects will be propagated upward
to all Transformer activation layers and rightward
to subsequent tokens. This is strictly more expres-
sive than a discrete prompt which is constrained to
the embeddings of real words. Preﬁx-tuning goes
one step further in increasing expressivity by op-
timizing the activations of all the layers, not just
the embedding layer. As another beneﬁt, preﬁx-
tuning can directly modify representations deeper
in the network, therefore, avoiding long computa-
tion paths across the depth of the network.
4.2
Method
Preﬁx-tuning prepends a preﬁx for an autoregres-
sive LM to obtain z = [PREFIX; x; y], or prepends
preﬁxes for both encoder and decoder to obtain
z = [PREFIX; x; PREFIX′; y], as shown in Figure 2.
Here, Pidx denotes the sequence of preﬁx indices,
and we use |Pidx| to denote the length of the preﬁx.
We follow the recurrence relation in equa-
tion (1), except that the activations of the preﬁx
indices are free parameters, given by a matrix Pθ
(parametrized by θ) of dimension |Pidx| × dim(hi).
hi =
(
Pθ[i, :],
if i ∈Pidx,
LMφ(zi, h<i),
otherwise.
(3)
2In our preliminary experiments, GPT-2 and BART fail in
this setting; the only exception is GPT-3.

## Page 5

4586
The training objective is the same as equation (2),
but the set of trainable parameters changes: the lan-
guage model parameters φ are ﬁxed and the preﬁx
parameters θ are the only trainable parameters.
Here, each hi is a function of the trainable Pθ.
When i ∈Pidx, this is clear because hi copies
directly from Pθ. When i̸ ∈Pidx, hi still depends
on Pθ, because the preﬁx activations are always
in the left context and will therefore affect any
activations to the right.
4.3
Parametrization of Pθ
Empirically, directly updating the Pθ parameters
leads to unstable optimization and a slight drop
in performance.3 So we reparametrize the matrix
Pθ[i, :] = MLPθ(P ′
θ[i, :]) by a smaller matrix (P ′
θ)
composed with a large feedforward neural network
(MLPθ). Now, the trainable parameters include P ′
θ
and the parameters of MLPθ. Note that Pθ and
P ′
θ has the same number of rows (i.e., the preﬁx
length), but different number of columns.4
Once training is complete, these reparametriza-
tion parameters can be dropped, and only the preﬁx
(Pθ) needs to be saved.
5
Experimental Setup
5.1
Datasets and Metrics
We evaluate on three standard neural generation
datasets for the table-to-text task: E2E (Novikova
et al., 2017), WebNLG (Gardent et al., 2017), and
DART (Radev et al., 2020), as shown in Table 1.
The datasets are ordered by increasing complexity
and size. E2E only has 1 domain (i.e. restaurant
reviews); WebNLG has 14 domains, and DART
is open-domain, using open-domain tables from
Wikipedia. For evaluation, we report the metrics
using the ofﬁcial evaluation scripts (see details in
Appendix A.1).
For the summarization task, we use the XSUM
(Narayan et al., 2018) dataset, which is an abstrac-
tive summarization dataset on news articles. We
report ROUGE-1, ROUGE-2 and ROUGE-L.
5.2
Methods
For table-to-text generation, we compare preﬁx-
tuning with three other methods: full ﬁne-tuning
3We ﬁnd in preliminary experiments that directly optimiz-
ing the preﬁx is very sensitive to initialization.
4Pθ has dimensions |Pidx| × dim(hi) while Pθ has
dimensions |Pidx| × k. We choose k = 512 for table-to-text
and 800 for summarization. MLPθ maps from k to dim(hi).
#examples
input length
output length
E2E
50K
28.5
27.8
WebNLG
22K
49.6
30.7
DART
82K
38.8
27.3
XSUM
225K
473.3
28.1
Table 1:
Datasets statistics.
The input and output
length is the number of BPE tokens per example. For
the three table-to-text datasets, the input length is the
length of linearized tables (details in Appendix A.1).
(FT-FULL), ﬁne-tuning only the top 2 layers (FT-
TOP2), and adapter-tuning (ADAPTER).5 We also
report the current state-of-the-art results on these
datasets: On E2E, Shen et al. (2019) uses a prag-
matically informed model without pretraining. On
WebNLG, Kale (2020) ﬁne-tunes T5-large. On
DART, no ofﬁcial models trained on this dataset
version are released.6 For summarization, we com-
pare against ﬁne-tuning BART (Lewis et al., 2020).
5.3
Architectures and Hyperparameters
For table-to-text, we use GPT-2MEDIUM and GPT-
2LARGE. For summarization, we use BARTLARGE.
Our implementation is based on the Hugging Face
Transformers (Wolf et al., 2020).
At training time, we use the AdamW optimizer
(Loshchilov and Hutter, 2019) and a linear learn-
ing rate scheduler, as suggested by the Hugging
Face default setup. The hyperparameters we tune
include the number of epochs, batch size, learning
rate, and preﬁx length. Hyperparameter details are
in the appendix. The default setting is 10 epochs,
batch size 5, learning rate 5·10−5 and preﬁx length
10. The table-to-text models are trained on TITAN
Xp or GeForce GTX TITAN X machines. Preﬁx-
tuning takes 0.2 hours per epoch to train on 22K
examples, whereas ﬁne-tuning takes around 0.3
hours per epoch. The summarization models are
trained on Tesla V100 machines, taking 1.25 hours
per epoch on the XSUM dataset. For time efﬁ-
ciency, preﬁx-tuning is around 30% faster than
ﬁne-tuning. For GPU memory efﬁciency, preﬁx-
tuning with batchsize 1 takes 18% of the total GPU
memory, whereas ﬁne-tuning takes 50%.
At decoding time, for table-to-text, we use beam
search with beam size 5. For summarization, we
use beam size 6 and length normalization 0.8. De-
coding takes 1.2 seconds per sentence (without
5Same implementation as Lin et al. (2020).
6The ofﬁcial benchmark model is trained on v.1.0.0 while
the release dataset is v1.1.1.

## Page 6

4587
batching) for table-to-text, and 2.6 seconds per
batch (using a batch size of 10) for summarization.
6
Main Results
6.1
Table-to-text Generation
We ﬁnd that by updating only 0.1% task-speciﬁc pa-
rameters,7 preﬁx-tuning is effective in table-to-text
generation, outperforming other lightweight base-
lines (ADAPTER and FT-TOP2) even by updating
30x fewer parameters and achieving a comparable
performance with (full) ﬁne-tuning. This trend
holds for all datasets: E2E, WebNLG,8 and DART.
If we match the number of parameters for preﬁx-
tuning and adapter-tuning to be 0.1%, Table 2
shows that preﬁx-tuning is signiﬁcantly better than
ADAPTER (0.1%), attaining 4.1 BLEU improve-
ment per dataset on average. Even when we com-
pare with ﬁne-tuning (100%) and adapter-tuning
(3.0%), which update signiﬁcantly more parame-
ters than preﬁx-tuning, preﬁx-tuning still achieves
results comparable or better than those two systems.
This demonstrates that preﬁx-tuning is more Pareto
efﬁcient than adapter-tuning, signiﬁcantly reducing
parameters while improving generation quality.
Additionally, attaining good performance on
DART suggests that preﬁx-tuning can generalize
to tables with diverse domains and a large number
of relations. We will delve deeper into extrapo-
lation performance (i.e., generalization to unseen
categories or topics) in §6.4.
In summary, preﬁx-tuning is an effective and
space-efﬁcient method to adapt GPT-2 to table-to-
text generation. It also maintains the performance
gains when scaling up to GPT-2LARGE, suggesting
it has the potential to scale to even larger models
with a similar architecture, like GPT-3.
6.2
Summarization
As shown in Table 3, with 2% parameters, preﬁx-
tuning obtains slightly lower performance than ﬁne-
tuning (36.05 vs. 37.25 in ROUGE-L). With only
0.1% parameters, preﬁx-tuning underperforms full
ﬁne-tuning (35.05 vs. 37.25). There are several
differences between XSUM and the three table-to-
text datasets which could account for why preﬁx-
tuning has comparative advantage in table-to-text:
7250K for E2E, 250K for WebNLG, and 500K for DART
versus 345M GPT-2 parameters.
8The S,U,A columns in WebNLG represents SEEN, UN-
SEEN, and ALL respectively; SEEN categories appear at
training time; UNSEEN categories only appears at test time;
and ALL is the combination of the two.
(1) XSUM contains 4x more examples than the
three table-to-text datasets on average; (2) the input
articles are 17x longer than the linearized table in-
put of table-to-text datasets on average; (3) summa-
rization is more complex than table-to-text because
it requires selecting key contents from an article.
6.3
Low-data Setting
Based on the results from table-to-text (§6.1)
and summarization (§6.2), we observe that preﬁx-
tuning has a comparative advantage when the num-
ber of training examples is smaller. To explore
the low-data setting more systematically, we sub-
sample the full dataset (E2E for table-to-text and
XSUM for summarization) to obtain small datasets
of size {50, 100, 200, 500}. For each size, we sam-
ple 5 different datasets and average over 2 training
random seeds. Thus, we average over 10 models
for each low-data setting.9
Figure 3 (right) shows that preﬁx-tuning outper-
forms ﬁne-tuning in low-data regimes by 2.9 BLEU
on average, in addition to requiring much fewer pa-
rameters, but the gap narrows as the dataset size
increases.
Qualitatively, Figure 3 (left) shows 8 examples
generated by both preﬁx-tuning and ﬁne-tuning
models trained on different data levels. While both
methods tend to undergenerate (missing table con-
tents) in low data regimes, preﬁx-tuning tends to be
more faithful than ﬁne-tuning. For example, ﬁne-
tuning (100, 200)10 falsely claims a low customer
rating while the true rating is average, whereas
preﬁx-tuning (100, 200) generates a description
that is faithful to the table.
6.4
Extrapolation
We now investigate extrapolation performance to
unseen topics for both table-to-text and summariza-
tion. In order to construct an extrapolation setting,
we split the existing datasets so that training and
test cover different topics. For table-to-text, the
WebNLG dataset is labeled with table topics. There
are 9 categories that appear in training and dev, de-
noted as SEEN and 5 categories that only appear at
test time, denoted as UNSEEN. So we evaluate ex-
trapolation by training on the SEEN categories and
testing on the UNSEEN categories. For summa-
rization, we construct two extrapolation data splits:
9We also sample a dev split (with dev size = 30% × train-
ing size) for each training set. We use the dev split to choose
hyperparameters and perform early stopping.
10The number in the parenthesis refers to the training size.

## Page 7

4588
E2E
WebNLG
DART
BLEU NIST MET R-L CIDEr
BLEU
MET
TER ↓
BLEU MET TER ↓Mover BERT BLEURT
S
U
A
S
U
A
S
U
A
GPT-2MEDIUM
FT-FULL
68.8
8.71
46.1
71.1
2.43
64.7 26.7 45.7 0.46 0.30 0.38 0.33 0.78 0.54
46.2
0.39
0.46
0.50
0.94
0.39
FT-TOP2
68.1
8.59
46.0
70.8
2.41
53.6 18.9 36.0 0.38 0.23 0.31 0.49 0.99 0.72
41.0
0.34
0.56
0.43
0.93
0.21
ADAPTER(3%)
68.9
8.71
46.1
71.3
2.47
60.5 47.9 54.8 0.43 0.38 0.41 0.35 0.46 0.39
45.2
0.38
0.46
0.50
0.94
0.39
ADAPTER(0.1%)
66.3
8.41
45.0
69.8
2.40
54.5 45.1 50.2 0.39 0.36 0.38 0.40 0.46 0.43
42.4
0.36
0.48
0.47
0.94
0.33
PREFIX(0.1%)
70.3
8.82
46.3
72.1
2.46
62.9 45.3 55.0 0.44 0.37 0.41 0.35 0.51 0.42
46.4
0.38
0.46
0.50
0.94
0.39
GPT-2LARGE
FT-FULL
68.5
8.78
46.0
69.9
2.45
65.3 43.1 55.5 0.46 0.38 0.42 0.33 0.53 0.42
47.0
0.39
0.46
0.51
0.94
0.40
Preﬁx
70.3
8.85
46.2
71.7
2.47
63.4 47.7 56.3 0.45 0.39 0.42 0.34 0.48 0.40
46.7
0.39
0.45
0.51
0.94
0.40
SOTA
68.6
8.70
45.3
70.8
2.37
63.9 52.8 57.1 0.46 0.41 0.44
-
-
-
-
-
-
-
-
-
Table 2: Metrics (higher is better, except for TER) for table-to-text generation on E2E (left), WebNLG (middle)
and DART (right). With only 0.1% parameters, Preﬁx-tuning outperforms other lightweight baselines and achieves
a comparable performance with ﬁne-tuning. The best score is boldfaced for both GPT-2MEDIUM and GPT-2LARGE.
Source
name : The Eagle | type : coffee shop | food : Chinese | price : cheap | customer
rating : average | area : riverside | family friendly : no | near : Burger King
Preﬁx (50)
The Eagle is a cheap Chinese coffee shop located near Burger King.
Preﬁx (100)
The Eagle is a cheap coffee shop located in the riverside near Burger King. It
has average customer ratings.
Preﬁx (200)
The Eagle is a cheap Chinese coffee shop located in the riverside area near
Burger King. It has average customer ratings.
Preﬁx (500)
The Eagle is a coffee shop that serves Chinese food. It is located in the riverside
area near Burger King. It has an average customer rating and is not family
friendly.
FT (50)
The Eagle coffee shop is located in the riverside area near Burger King.
FT (100)
The Eagle is a cheap coffee shop near Burger King in the riverside area. It has
a low customer rating and is not family friendly.
FT (200)
The Eagle is a cheap Chinese coffee shop with a low customer rating. It is
located near Burger King in the riverside area.
FT (500)
The Eagle is a cheap Chinese coffee shop with average customer ratings. It is
located in the riverside area near Burger King.
100
200
300
400
500
training data size
32
33
34
35
36
37
ROUGE-1
FT-full
Prefix
100
200
300
400
500
training data size
10
11
12
13
14
15
ROUGE-2
FT-full
Prefix
100
200
300
400
500
training data size
0.50
0.55
0.60
BLEU
FT-full
Prefix
100
200
300
400
500
training data size
0.60
0.62
0.64
0.66
ROUGE
FT-full
Prefix
Figure 3: (Left) qualitative examples in lowdata settings. (Right) preﬁx-tuning (orange) outperforms ﬁne-tuning
(blue) in low-data regimes in addition to requiring many fewer parameters. The top two plots correspond to sum-
marization, measured by ROUGE-1 and ROUGE-2. The bottom two plots correspond to table-to-text, measured
by BLEU and ROUGE-L. The x-axis is the training size and the y-axis is the evaluation metric (higher is better).
R-1 ↑
R-2 ↑
R-L ↑
FT-FULL(Lewis et al., 2020)
45.14
22.27
37.25
PREFIX(2%)
43.80
20.93
36.05
PREFIX(0.1%)
42.92
20.03
35.05
Table 3: Performance of methods on the XSUM sum-
marization dataset.
Preﬁx-tuning slightly underper-
forms ﬁne-tuning in the full-data regime.
news-to-sports
within-news
R-1 ↑
R-2 ↑
R-L ↑
R-1 ↑
R-2 ↑
R-L ↑
FT-FULL
38.15
15.51
30.26
39.20
16.35
31.15
PREFIX
39.23
16.74
31.51
39.41
16.87
31.47
Table 4: Extrapolation performance on XSUM. Preﬁx-
tuning outperforms ﬁne-tuning on both news-to-sports
and within-news splits.
In news-to-sports, we train on news articles
and test on sports articles. In within-news, we
train on {world, UK, business} news and test on
the remaining news categories (e.g., health, tech).
On both table-to-text and summarization, preﬁx-
tuning extrapolates better than ﬁne-tuning under all
metrics, as shown in Table 4 and the ‘U’ columns
of Table 2 (middle).
We also ﬁnd that adapter-tuning achieves good
extrapolation performance, comparable with preﬁx-
tuning, as shown in Table 2. This shared trend
suggests that preserving LM parameters indeed has
a positive impact on extrapolation. However, how
preﬁx-tuning improves extrapolation is an open
question and we will discuss this further in §8.
7
Intrinsic Evaluation
We compare different variants of preﬁx-tuning to
study the impact of various design decisions. §7.1
studies the impact of the preﬁx length. §7.2 studies
tuning only the embedding layer, which is more
akin to tuning a discrete prompt. §7.3 compares
preﬁxing and inﬁxing, which inserts trainable acti-
vations between x and y. §7.4 studies the impact of
various preﬁx initialization strategies. §7.5 further
studies the data efﬁciency of preﬁx-tuning.
7.1
Preﬁx Length
A longer preﬁx means more trainable parameters,
and therefore more expressive power.11 Figure 4
shows that performance increases as the preﬁx
11Empirically, longer preﬁxes have a negligible impact on
training and inference speed per batch, because attention com-
putation over the entire preﬁx is parallellized on GPUs.

## Page 8

4589
0
100
200
300
Prefix Length (XSUM)
18.5
19.0
19.5
20.0
20.5
21.0
ROUGE-2
33.5
34.0
34.5
35.0
35.5
36.0
ROUGE-L
ROUGE-2
ROUGE-L
0
10
20
30
40
Prefix Length (DART)
44.0
44.5
45.0
45.5
46.0
BLEU
0.460
0.465
0.470
0.475
0.480
TER
BLEU
TER
Figure 4:
Preﬁx length vs. performance on summer-
ization (left) and table-to-text (right). Performance in-
creases as the preﬁx length increases up to a threshold
(200 for summarization and 10 for table-to-text) and
then a slight performance drop occurs. Each plot re-
ports two metrics (on two vertical axes).
E2E
BLEU
NIST
MET
ROUGE
CIDEr
PREFIX
70.3
8.82
46.3
72.1
2.46
Embedding-only: EMB-{PreﬁxLength}
EMB-1
48.1
3.33
32.1
60.2
1.10
EMB-10
62.2
6.70
38.6
66.4
1.75
EMB-20
61.9
7.11
39.3
65.6
1.85
Inﬁx-tuning: INFIX-{PreﬁxLength}
INFIX-1
67.9
8.63
45.8
69.4
2.42
INFIX-10
67.2
8.48
45.8
69.9
2.40
INFIX-20
66.7
8.47
45.8
70.0
2.42
Table 5: Intrinsic evaluation of Embedding-only (§7.2)
and Inﬁxing (§7.3). Both Embedding-only ablation and
Inﬁx-tuning underperforms full preﬁx-tuning.
length increases up to a threshold (200 for sum-
marization, 10 for table-to-text) and then a slight
performance drop occurs. Preﬁxes longer than the
threshold lead to lower training loss, but slightly
worse test performance, suggesting that they tend
to overﬁt the training data.
7.2
Full vs Embedding-only
Recall in §4.1, we discussed optimizing the contin-
uous embeddings of the “virtual tokens.” We instan-
tiate that idea and call it embedding-only. The word
embeddings are free parameters, and the remaining
activation layers are computed by the Transformer.
Table 5 (top) shows that the performance drops
signiﬁcantly, suggesting that tuning only the em-
bedding layer is not sufﬁciently expressive.
Embedding-only upper bounds the performance
of discrete prompt optimization (Shin et al., 2020),
because discrete prompt restricts the embedding
layer to exactly match the embedding of a real word.
Consequently, we have this chain of increasing ex-
pressive power: discrete prompting < embedding-
only < preﬁx-tuning.
7.3
Preﬁx-tuning vs Inﬁx-tuning
We also investigate how the trainable activations’
position in the sequence affects performance. In
random
"active"
"elephant"
"summarize"
"table-to-text:"
"banana"
"beautiful"
"divide"
"keep"
0.45
0.50
0.55
0.60
BLEU
Figure 5: Initializing the preﬁx with activations of real
words signiﬁcantly outperforms random initialization,
in low-data settings.
preﬁx-tuning, we place them at the beginning
[PREFIX; x; y]. We can also place the trainable
activations between x and y (i.e. [x; INFIX; y]) and
call this inﬁx-tuning. Table 5 (bottom) shows that
inﬁx-tuning slightly underperforms preﬁx-tuning.
We believe this is because preﬁx-tuning can affect
the activations of x and y whereas inﬁx-tuning can
only inﬂuence the activations of y.
7.4
Initialization
We ﬁnd that how the preﬁx is initialized has
a large impact in low-data settings.
Random
initialization leads to low performance with high
variance. Initializing the preﬁx with activations of
real words signiﬁcantly improves generation, as
shown in Figure 5. In particular, initializing with
task relevant words such as “summarization” and
“table-to-text” obtains slightly better performance
than task irrelevant words such as “elephant”
and “divide”, but using real words is still better
than random. Moreover, in full data settings, the
initialization trick has no impact, and random
initialization leads to equally good performance.
Since we initialize the preﬁx with activations of
real words computed by the LM, this initialization
strategy is concordant with preﬁx-tuning’s philos-
ophy, which preserves the pretrained LM as much
as possible.
7.5
Data Efﬁciency
We also investigate the data efﬁciency of preﬁx-
tuning (without initialization trick, a.k.a random
initialization) and full ﬁne-tuning by comparing
their performance on 5 different data scales of the
E2E task (10%, 20%, 40%, 60%, and 80%). Fig-
ure 6 shows that preﬁx-tuning has better perfor-
mance than ﬁne-tuning when using more than 20%
of the data. For data scale of 10%, preﬁx-tuning
with random initialization yields comparable or
slightly lower performance than full ﬁne-tuning,

## Page 9

4590
20
40
60
80
percentage of training data
65
66
67
68
69
BLEU
FT-full
Prefix
20
40
60
80
percentage of training data
68
69
70
71
ROUGE-L
FT-full
Prefix
Figure 6: Data efﬁciency curves: percentage of train-
ing set vs. performance on table-to-text (E2E). Preﬁx-
tuning (without the initialization trick) is more data-
efﬁcient than ﬁne-tuning when using more than 20%
of the data.
necessitating the initialization trick (§6.3) to im-
prove the performance in this low-data regime.
8
Discussion
We will discuss several favorable properties of
preﬁx-tuning and some open problems.
Personalization.
As we note in §1, preﬁx-tuning
is advantageous when there are a large number
of tasks that needs to be trained independently.
One practical setting is user privacy (Shokri and
Shmatikov, 2015; McMahan et al., 2016). In order
to preserve user privacy, each user’s data needs to
be separated and a personalized model needs to be
trained independently for each user. Consequently,
each user can be regarded as an independent task. If
there are millions of users, preﬁx-tuning can scale
to this setting and maintain modularity, enabling
ﬂexible addition or deletion of users by adding or
deleting their preﬁxes without cross-contamination.
Batching across users.
Under the same person-
alization setting, preﬁx-tuning allows batching dif-
ferent users’ queries even though they are backed
by different preﬁxes. When multiple users query
a cloud GPU device with their inputs, it is compu-
tationally efﬁcient to put these users in the same
batch. Preﬁx-tuning keeps the shared LM intact;
consequently, batching requires a simple step of
prepending the personalized preﬁx to user input,
and all the remaining computation is unchanged.
In contrast, we can’t batch across different users
in adapter-tuning, which has personalized adapters
between shared Transformer layers.
This batching beneﬁt could also help create efﬁ-
cient ensembles of multiple preﬁxes trained on the
same task (Lester et al., 2021).
Inductive bias of preﬁx-tuning.
Recall that ﬁne-
tuning updates all pretrained parameters, whereas
preﬁx-tuning and adapter-tuning preserve them.
Since the language models are pretrained on gen-
eral purpose corpora, preserving the LM parame-
ters might help generalization to domains unseen
during training. In concordance with this intuition,
we observe that both preﬁx-tuning and adapter-
tuning have signiﬁcant performance gain in extrap-
olation settings (§6.4); however, how these methods
improve extrapolation is an open question.
While preﬁx-tuning and adapter-tuning both
freeze the pretrained parameters, they tune different
sets of parameters to affect the activation layers of
the Transformer. Recall that preﬁx-tuning keeps the
LM intact and uses the preﬁx and the pretrained at-
tention blocks to affect the subsequent activations;
adapter-tuning inserts trainable modules between
LM layers, which directly add residual vectors to
the activations. Moreover, we observe that preﬁx-
tuning requires vastly fewer parameters compared
to adapter-tuning while maintaining comparable
performance. We think this gain in parameter efﬁ-
ciency is because preﬁx-tuning keeps the pretrained
LM intact as much as possible, and therefore ex-
ploits the LM more than adapter-tuning.
Recent work by Aghajanyan et al. (2020) uses
intrinsic dimension to show that there exists a low-
dimensional reparameterization that is as effective
for ﬁne-tuning as the full parametrization. This
explains why good accuracy on downstream tasks
can be obtained by updating only a small num-
ber of parameters. Our work echoes this ﬁnding
by showing that good generation performance can
also be attained by updating a very small preﬁx.
However, preﬁx-tuning is not just about the size of
trainable parameters, but more importantly, which
subset of parameters to modify. Therefore, it would
be interesting future work to explore other light-
weight ﬁne-tuning methods that achieve an even
better accuracy-size tradeoff.
Acknowledgments
We thank the members of p-lambda group as well
as anonymous reviewers for valuable feedback. We
gratefully acknowledge the support of a PECASE
award. XLL is supported by a Stanford Graduate
Fellowship.
Reproducibility
Our code is available at https://github.com/
XiangLi1999/PrefixTuning.
Experiments and data are available at https:
//worksheets.codalab.org/worksheets/
0x16e0c8e7ab1f4b22aaccddc8b586541f.

## Page 10

4591
References
Armen Aghajanyan, Luke Zettlemoyer, and Sonal
Gupta. 2020. Intrinsic dimensionality explains the
effectiveness of language model ﬁne-tuning.
Anja Belz and Ehud Reiter. 2006.
Comparing auto-
matic and human evaluation of NLG systems.
In
11th Conference of the European Chapter of the
Association for Computational Linguistics, Trento,
Italy. Association for Computational Linguistics.
Tom B. Brown, Benjamin Mann, Nick Ryder, Melanie
Subbiah, Jared Kaplan, Prafulla Dhariwal, Arvind
Neelakantan, Pranav Shyam, Girish Sastry, Amanda
Askell,
Sandhini Agarwal,
Ariel Herbert-Voss,
Gretchen Krueger, Tom Henighan, Rewon Child,
Aditya Ramesh, Daniel M. Ziegler, Jeffrey Wu,
Clemens Winter, Christopher Hesse, Mark Chen,
Eric Sigler, Mateusz Litwin, Scott Gray, Benjamin
Chess, Jack Clark, Christopher Berner, Sam Mc-
Candlish, Alec Radford, Ilya Sutskever, and Dario
Amodei. 2020. Language models are few-shot learn-
ers.
Sumanth Dathathri, Andrea Madotto, Janice Lan, Jane
Hung, Eric Frank, Piero Molino, Jason Yosinski, and
Rosanne Liu. 2020. Plug and play language mod-
els: A simple approach to controlled text generation.
In International Conference on Learning Represen-
tations.
Jacob Devlin, Ming-Wei Chang, Kenton Lee, and
Kristina Toutanova. 2019.
BERT: Pre-training of
deep bidirectional transformers for language under-
standing.
In Proceedings of the 2019 Conference
of the North American Chapter of the Association
for Computational Linguistics: Human Language
Technologies, Volume 1 (Long and Short Papers),
pages 4171–4186, Minneapolis, Minnesota. Associ-
ation for Computational Linguistics.
Claire Gardent, Anastasia Shimorina, Shashi Narayan,
and Laura Perez-Beltrachini. 2017. The WebNLG
challenge: Generating text from RDF data. In Pro-
ceedings of the 10th International Conference on
Natural Language Generation, pages 124–133, San-
tiago de Compostela, Spain. Association for Compu-
tational Linguistics.
Karen Hambardzumyan,
Hrant Khachatrian,
and
Jonathan May. 2021. WARP: word-level adversar-
ial reprogramming. CoRR, abs/2101.00121.
Neil Houlsby, Andrei Giurgiu, Stanislaw Jastrzebski,
Bruna Morrone, Quentin De Laroussilhe, Andrea
Gesmundo, Mona Attariyan, and Sylvain Gelly.
2019. Parameter-efﬁcient transfer learning for NLP.
In Proceedings of the 36th International Conference
on Machine Learning, volume 97 of Proceedings
of Machine Learning Research, pages 2790–2799,
Long Beach, California, USA. PMLR.
Zhengbao Jiang, Frank F. Xu, Jun Araki, and Graham
Neubig. 2020.
How can we know what language
models know? Transactions of the Association for
Computational Linguistics, 8:423–438.
Mihir Kale. 2020. Text-to-text pre-training for data-to-
text tasks.
N. Keskar, B. McCann, L. R. Varshney, Caiming Xiong,
and R. Socher. 2019.
Ctrl: A conditional trans-
former language model for controllable generation.
ArXiv, abs/1909.05858.
Ben Krause, Akhilesh Deepak Gotmare, Bryan Mc-
Cann, Nitish Shirish Keskar, Shaﬁq Joty, Richard
Socher, and Nazneen Fatema Rajani. 2020. GeDi:
Generative Discriminator Guided Sequence Genera-
tion. arXiv preprint arXiv:2009.06367.
Alon Lavie and Abhaya Agarwal. 2007. Meteor: An
automatic metric for mt evaluation with high levels
of correlation with human judgments. In Proceed-
ings of the Second Workshop on Statistical Machine
Translation, StatMT ’07, pages 228–231, Strouds-
burg, PA, USA. Association for Computational Lin-
guistics.
Brian Lester, Rami Al-Rfou, and Noah Constant. 2021.
The power of scale for parameter-efﬁcient prompt
tuning.
Mike
Lewis,
Yinhan
Liu,
Naman
Goyal,
Mar-
jan Ghazvininejad, Abdelrahman Mohamed, Omer
Levy, Veselin Stoyanov, and Luke Zettlemoyer.
2020. BART: Denoising sequence-to-sequence pre-
training for natural language generation, translation,
and comprehension. In Proceedings of the 58th An-
nual Meeting of the Association for Computational
Linguistics, pages 7871–7880, Online. Association
for Computational Linguistics.
Chin-Yew Lin. 2004.
ROUGE: A package for auto-
matic evaluation of summaries. In Text Summariza-
tion Branches Out, pages 74–81, Barcelona, Spain.
Association for Computational Linguistics.
Zhaojiang Lin, Andrea Madotto, and Pascale Fung.
2020.
Exploring versatile generative language
model via parameter-efﬁcient transfer learning. In
Findings of the Association for Computational Lin-
guistics: EMNLP 2020, pages 441–459, Online. As-
sociation for Computational Linguistics.
Xiao Liu, Yanan Zheng, Zhengxiao Du, Ming Ding,
Yujie Qian, Zhilin Yang, and Jie Tang. 2021. Gpt
understands, too. arXiv preprint arXiv:2103.10385.
Yang Liu and Mirella Lapata. 2019. Text summariza-
tion with pretrained encoders.
In Proceedings of
the 2019 Conference on Empirical Methods in Nat-
ural Language Processing and the 9th International
Joint Conference on Natural Language Processing
(EMNLP-IJCNLP), pages 3730–3740, Hong Kong,
China. Association for Computational Linguistics.
Yinhan Liu, Jiatao Gu, Naman Goyal, Xian Li, Sergey
Edunov, Marjan Ghazvininejad, Mike Lewis, and
Luke Zettlemoyer. 2020.
Multilingual denoising
pre-training for neural machine translation.

## Page 11

4592
Yinhan Liu, Myle Ott, Naman Goyal, Jingfei Du, Man-
dar Joshi, Danqi Chen, Omer Levy, Mike Lewis,
Luke Zettlemoyer, and Veselin Stoyanov. 2019.
Roberta: A robustly optimized BERT pretraining ap-
proach. CoRR, abs/1907.11692.
Ilya Loshchilov and Frank Hutter. 2019.
Decoupled
weight decay regularization. In International Con-
ference on Learning Representations.
H. Brendan McMahan, Eider Moore, Daniel Ramage,
and Blaise Ag¨uera y Arcas. 2016. Federated learn-
ing of deep networks using model averaging. Pro-
ceedings of the 20 th International Conference on
Artiﬁcial Intelligence and Statistics (AISTATS) 2017,
abs/1602.05629.
Shashi Narayan, Shay B. Cohen, and Mirella Lapata.
2018. Don’t give me the details, just the summary!
Topic-aware convolutional neural networks for ex-
treme summarization. In Proceedings of the 2018
Conference on Empirical Methods in Natural Lan-
guage Processing, Brussels, Belgium.
Jekaterina Novikova, Ondrej Dusek, and Verena Rieser.
2017. The E2E dataset: New challenges for end-to-
end generation. CoRR, abs/1706.09254.
Kishore Papineni, Salim Roukos, Todd Ward, and Wei-
Jing Zhu. 2002. Bleu: A method for automatic eval-
uation of machine translation.
In Proceedings of
the 40th Annual Meeting on Association for Com-
putational Linguistics, ACL ’02, pages 311–318,
Stroudsburg, PA, USA. Association for Computa-
tional Linguistics.
Jonas Pfeiffer, Aishwarya Kamath, Andreas R¨uckl´e,
Kyunghyun
Cho,
and
Iryna
Gurevych.
2020.
Adapterfusion:
Non-destructive task composition
for transfer learning.
Guanghui Qin and Jason Eisner. 2021. Learning how
to ask: Querying LMs with mixtures of soft prompts.
In Proceedings of the 2021 Conference of the North
American Chapter of the Association for Computa-
tional Linguistics: Human Language Technologies
(NAACL-HLT), Mexico City.
Dragomir Radev, Rui Zhang, Amrit Rau, Abhinand
Sivaprasad, Chiachun Hsieh, Nazneen Fatema Ra-
jani, Xiangru Tang, Aadit Vyas, Neha Verma,
Pranav Krishna, Yangxiaokang Liu, Nadia Irwanto,
Jessica Pan, Faiaz Rahman, Ahmad Zaidi, Murori
Mutuma, Yasin Tarabar, Ankit Gupta, Tao Yu,
Yi Chern Tan, Xi Victoria Lin, Caiming Xiong, and
Richard Socher. 2020.
Dart: Open-domain struc-
tured data record to text generation.
A. Radford, Jeffrey Wu, R. Child, David Luan, Dario
Amodei, and Ilya Sutskever. 2019. Language mod-
els are unsupervised multitask learners.
Evani Radiya-Dixit and Xin Wang. 2020. How ﬁne can
ﬁne-tuning be? learning efﬁcient language models.
In Proceedings of the Twenty Third International
Conference on Artiﬁcial Intelligence and Statistics,
volume 108 of Proceedings of Machine Learning Re-
search, pages 2435–2443, Online. PMLR.
Colin Raffel, Noam Shazeer, Adam Roberts, Kather-
ine Lee, Sharan Narang, Michael Matena, Yanqi
Zhou, Wei Li, and Peter J. Liu. 2020.
Exploring
the limits of transfer learning with a uniﬁed text-to-
text transformer. Journal of Machine Learning Re-
search, 21(140):1–67.
Sylvestre-Alvise Rebufﬁ, Hakan Bilen, and Andrea
Vedaldi. 2017.
Learning multiple visual domains
with residual adapters. In Advances in Neural Infor-
mation Processing Systems, volume 30, pages 506–
516. Curran Associates, Inc.
Timo Schick and Hinrich Sch¨utze. 2020. Exploiting
cloze questions for few shot text classiﬁcation and
natural language inference.
Thibault Sellam, Dipanjan Das, and Ankur Parikh.
2020.
BLEURT: Learning robust metrics for text
generation. In Proceedings of the 58th Annual Meet-
ing of the Association for Computational Linguistics,
pages 7881–7892, Online. Association for Computa-
tional Linguistics.
Sheng Shen, Daniel Fried, Jacob Andreas, and Dan
Klein. 2019.
Pragmatically informative text gen-
eration.
In Proceedings of the 2019 Conference
of the North American Chapter of the Association
for Computational Linguistics: Human Language
Technologies, Volume 1 (Long and Short Papers),
pages 4060–4067, Minneapolis, Minnesota. Associ-
ation for Computational Linguistics.
Taylor Shin, Yasaman Razeghi, Robert L. Logan IV
au2, Eric Wallace, and Sameer Singh. 2020. Auto-
prompt: Eliciting knowledge from language models
with automatically generated prompts.
Reza Shokri and Vitaly Shmatikov. 2015.
Privacy-
preserving deep learning.
In Proceedings of
the 22nd ACM SIGSAC Conference on Computer
and Communications Security, CCS ’15, page
1310–1321, New York, NY, USA. Association for
Computing Machinery.
Matthew Snover, Bonnie Dorr, Richard Schwartz, Lin-
nea Micciulla, and Ralph Weischedel. 2006. A study
of translation error rate with targeted human annota-
tion. In In Proceedings of the Association for Ma-
chine Transaltion in the Americas (AMTA 2006.
Asa
Cooper
Stickland,
Xian
Li,
and
Marjan
Ghazvininejad.
2020.
Recipes
for
adapting
pre-trained monolingual and multilingual models to
machine translation.
Nishant
Subramani,
Samuel
R.
Bowman,
and
Kyunghyun Cho. 2020.
Can unconditional lan-
guage models recover arbitrary sentences?
Ramakrishna Vedantam, C. Lawrence Zitnick, and
Devi Parikh. 2015. Cider: Consensus-based image
description evaluation. In CVPR, pages 4566–4575.
IEEE Computer Society.

## Page 12

4593
Thomas Wolf, Lysandre Debut, Victor Sanh, Julien
Chaumond, Clement Delangue, Anthony Moi, Pier-
ric Cistac, Tim Rault, R´emi Louf, Morgan Funtow-
icz, Joe Davison, Sam Shleifer, Patrick von Platen,
Clara Ma, Yacine Jernite, Julien Plu, Canwen Xu,
Teven Le Scao, Sylvain Gugger, Mariama Drame,
Quentin Lhoest, and Alexander M. Rush. 2020.
Transformers: State-of-the-art natural language pro-
cessing. In Proceedings of the 2020 Conference on
Empirical Methods in Natural Language Processing:
System Demonstrations, pages 38–45, Online. Asso-
ciation for Computational Linguistics.
Jeffrey
O
Zhang,
Alexander
Sax,
Amir
Zamir,
Leonidas Guibas, and Jitendra Malik. 2020a. Side-
tuning: A baseline for network adaptation via addi-
tive side networks.
Tianyi Zhang, Varsha Kishore, Felix Wu, Kilian Q.
Weinberger, and Yoav Artzi. 2020b.
BERTScore:
Evaluating text generation with bert.
In Interna-
tional Conference on Learning Representations.
Yizhe Zhang, Siqi Sun, Michel Galley, Yen-Chun Chen,
Chris Brockett, Xiang Gao, Jianfeng Gao, Jingjing
Liu, and Bill Dolan. 2020c. DIALOGPT : Large-
scale generative pre-training for conversational re-
sponse generation. In Proceedings of the 58th An-
nual Meeting of the Association for Computational
Linguistics:
System Demonstrations, pages 270–
278, Online. Association for Computational Linguis-
tics.
Mengjie Zhao, Tao Lin, Fei Mi, Martin Jaggi, and Hin-
rich Sch¨utze. 2020. Masking as an efﬁcient alterna-
tive to ﬁnetuning for pretrained language models.
Wei Zhao, Maxime Peyrard, Fei Liu, Yang Gao, Chris-
tian M. Meyer, and Steffen Eger. 2019. MoverScore:
Text generation evaluating with contextualized em-
beddings and earth mover distance. In Proceedings
of the 2019 Conference on Empirical Methods in
Natural Language Processing and the 9th Interna-
tional Joint Conference on Natural Language Pro-
cessing (EMNLP-IJCNLP), pages 563–578, Hong
Kong, China. Association for Computational Lin-
guistics.
Ming Zhong, Pengfei Liu, Yiran Chen, Danqing Wang,
Xipeng Qiu, and Xuanjing Huang. 2020.
Extrac-
tive summarization as text matching. In Proceedings
of the 58th Annual Meeting of the Association for
Computational Linguistics, pages 6197–6208, On-
line. Association for Computational Linguistics.
Jinhua Zhu, Yingce Xia, Lijun Wu, Di He, Tao Qin,
Wengang Zhou, Houqiang Li, and Tieyan Liu. 2020.
Incorporating bert into neural machine translation.
In International Conference on Learning Represen-
tations.

## Page 13

4594
A
Supplementary Material
A.1
Datasets and Metrics
We evaluate on three standard neural generation
datasets for the table-to-text task: E2E (Novikova
et al., 2017), WebNLG (Gardent et al., 2017), and
DART (Radev et al., 2020).
The E2E dataset contains approximately 50K ex-
amples with 8 distinct ﬁelds; it contains multiple
test references for one source table, and the average
output length is 22.9. We use the ofﬁcial evalua-
tion script,12 which reports BLEU (Papineni et al.,
2002), NIST (Belz and Reiter, 2006), METEOR
(Lavie and Agarwal, 2007), ROUGE-L (Lin, 2004),
and CIDEr (Vedantam et al., 2015).
The WebNLG (Gardent et al., 2017) dataset con-
sists of 22K examples, and the input x is a sequence
of (subject, property, object) triples. The average
output length is 22.5. In the training and validation
splits, the input describes entities from 9 distinct
DBpedia categories (e.g., Monument). The test
split consists of two parts: the ﬁrst half contains
DB categories seen in training data, and the sec-
ond half contains 5 unseen categories. These un-
seen categories are used to evaluate extrapolation.
We use the ofﬁcial evaluation script, which reports
BLEU, METEOR and TER (Snover et al., 2006).
DART (Radev et al., 2020) is an open domain
table-to-text dataset, with similar input format
(entity-relation-entity triples) as WebNLG. The av-
erage output length is 21.6. It consists of 82K ex-
amples from WikiSQL, WikiTableQuestions, E2E,
and WebNLG and applies some manual or auto-
mated conversion. We use the ofﬁcial evaluation
script13 and report BLEU, METEOR, TER, Mover-
Score (Zhao et al., 2019), BERTScore (Zhang et al.,
2020b) and BLEURT (Sellam et al., 2020).
For the summarization task, we use the XSUM
(Narayan et al., 2018) dataset, which is an abstrac-
tive summarization dataset on news articles. There
are 225K examples. The average length of the ar-
ticles is 431 words and the average length of the
summaries is 23.3. We report ROUGE-1, ROUGE-
2 and ROUGE-L, computed by the python package
rouge-score.
Data pre-processing.
For table-to-text, we lin-
earize a table x in order to ﬁt into a language model
context. In the E2E dataset, for example, “(ﬁeld A,
12https://github.com/tuetschek/
e2e-metrics
13https://github.com/Yale-LILY/dart
value A), (ﬁeld B, value B)” is linearized to “ﬁeld
A : value A | ﬁeld B : value B”. Also, in WebNLG
and DART, a sequence of triple “(entity1.1, rela-
tion1, entity1.2), (entity2.1, relation2, entity2.2)”
is linearlized as “entity1.1 : relation1 : entity1.2 |
entity2.1 : relation2 : entity2.2”.
For summarization, we truncate the articles x to
512 BPE tokens.
Extrapolation data splits.
We construct two ex-
trapolation data splits news-to-sports and
within-news from the original XSUM dataset.
XSUM dataset is drawn from BBC news, and we
identify the topic of each article based on its URL.
Since “news” and “sports” are the two domains
with the most articles, we create our ﬁrst train/test
split. Additionally, “news” has subdomains such as
“UK”, “world”, and “technology”. Consequently,
we create a second data split, using the top 3 news
subdomains (i.e. {world, UK, business }) as train-
ing data and the rest as test data.
A.2
Hyperparameters
In Table 6, we report the hyperparameters used to
train the best-performing models documented in
the experiment section.
As for the search range of each hyperparameters:
the learning rates are selected from {1e-5, 5e-05,
8e-05}; the number of epochs are selected from {5,
10} for table-to-text and {5, 25, 30 } for summa-
rization; We select the largest batch size that can ﬁt
into GPU memory and didn’t explicitly tune for an
optimal batch size. Preﬁx length are selected from
{1, 5, 10, 20, 40} for table-to-text and {1, 10, 20,
50, 80, 100, 200, 300} for summarization. We use
perplexity and automatic generation metrics on the
validation set to select the best-performing models.
For table-to-text in the low data settings, we use a
learning rate of 5e-5, and a batch size of 10. We use
a preﬁx length of 6, since we apply the initialization
trick and initialize the preﬁx with “table-to-text:”,
which contains 6 BPE tokens. Instead of tuning
the number of epochs, we tune the max steps of
updates in {100, 200, 400, 600 }, as shown in
Table 8. We apply early stopping based on the
performance of validation set, where the validation
size =30% training size.
For summarization in the low data settings, we
use a learning rate of 5e-5 and a warmup step of
100. We use a batch size of 5 for preﬁx-tuning
and 6 for ﬁne-tuning. We apply the initialization
trick and use the word “summarize” to initialize

## Page 14

4595
learning rate
# epoch
batch size
preﬁx length
Preﬁx:
E2E
8e-05
5
10
5
WebNLG
5e-05
5
5
5
DART
5e-05
10
5
10
XSUM
5e-05
30
14
100
Adapter:
E2E (3%)
5e-05
5
5
-
E2E (0.1%)
8e-05
10
5
WebNLG (3%)
5e-05
5
5
-
WebNLG (0.1%)
5e-05
10
5
-
DART (3%)
5e-05
5
5
-
DART (0.1%)
8e-05
5
5
-
Fine-tune:
E2E
5e-05
5
10
-
WebNLG
1e-05
10
6
-
DART
1e-05
10
6
-
FT-top2:
E2E
5e-05
5
10
-
WebNLG
5e-05
10
9
-
DART
5e-05
5
5
-
within-news
Fine-tune
3e-5
5
18
-
Preﬁx
5e-5
30
36
80
news-to-sports
Fine-tune
3e-5
5
18
-
Preﬁx
5e-5
15
36
40
Table 6: Hyperparameter settings for our method and
baseline methods.
R-1 ↑
R-2 ↑
R-L ↑
PREFIX(2%)
43.30
20.35
35.21
PREFIX(0.1%)
41.54
18.56
33.13
Table 7: Metrics for summarization on XSUM valida-
tion set.
the preﬁx, resulting in a preﬁx length of 1. We tune
the number of epochs in {3, 5, 10, 20, 30}, shown
in Table 8. We also apply early stopping based on
validation performance.
For the extrapolation setting, the hyperparame-
ters for our table-to-text model is the same as the
hyperparameters of WebNLG. The hyperparame-
ters for summarization is shown in the last block of
Table 6.
A.3
Validation Performance
Table 9 shows the validation performance on the
three table-to-text datasets. Table 7 shows the vali-
dation performance on XSUM.
size=50
size=100
size=200
size=500
Preﬁx (max steps)
200
200
200
400
Finetune (max steps)
100
100
200
400
Preﬁx (epoch)
30
20
20
20
Finetune (epoch)
30
10
3
3
Table 8: Max # update steps for low data settings.
A.4
Additional Results for Low-data Settings
Figure 7 supplements the low-data performance
curves in Figure 3 by plotting the relationship be-
tween training size and generation metrics for both
preﬁx-tuning and ﬁne-tuning.
A.5
Additional Results for the Initialization
Experiment
Figure 8 supplements Figure 3 by plotting addi-
tional metrics for our initialization technique §7.4.
It validates that random initialization (from a uni-
form (0,1) distirbution) signiﬁcantly underperforms
initializing with real words; Additionally, initializ-
ing with task-relevant words (e.g., “summarization”
and “table-to-text”) attains slightly better gener-
ation scores than initializing with task-irrelevant
words (e.g., “elephant” and “banana”).
A.6
Qualitative Examples for Extrapolation
Table 10 contains qualitative examples from both
seen and unseen categories in WebNLG. We ﬁnd
that for unseen categories, both preﬁx-tuning and
ﬁne-tuning tend to undergenerate (generated out-
put do not cover full table contents) or generate
untruthfully (generated output is inconsistent with
table contents). In particular, preﬁx-tuning tends to
undergenerate whereas ﬁne-tuning tends to gener-
ate untruthfully. For seen categories, both perform
fairly well in terms of coverage and truthfulness.

## Page 15

4596
E2E
WebNLG
DART
BLEU NIST MET R-L CIDEr BLEU MET TER ↓BLEU MET TER ↓Mover BERT BLEURT
GPT-2MEDIUM
FT-FULL
74.2
8.76
49.3
76.9
2.66
66.03
0.47
0.30
50.46
0.41
0.44
0.52
0.95
0.41
FT-TOP2
72.7
8.51
48.2
75.3
2.60
54.61
0.39
0.47
48.41
0.39
0.48
0.48
0.94
0.33
ADAPTER(3%)
71.7
8.53
48.4
74.6
2.60
60.63
0.43
0.33
48.56
0.40
0.44
0.51
0.95
0.40
ADAPTER(0.1%)
68.1
8.30
45.9
71.4
2.41
53.24
0.40
0.39
44.72
0.38
0.47
0.47
0.94
0.35
PREFIX(0.1%)
74.8
8.80
49.4
76.8
2.69
64.52
0.46
0.32
51.11
0.41
0.43
0.52
0.95
0.42
GPT-2LARGE
FT-FULL
72.1
8.62
48.5
75.1
2.56
64.69
0.46
0.31
51.00
0.41
0.44
0.52
0.95
0.43
Preﬁx
74.8
8.81
49.5
77.0
2.72
64.11
0.46
0.33
50.84
0.41
0.43
0.52
0.95
0.42
Table 9: Metrics on the development set (higher is better, except for TER) for table-to-text generation on E2E
(left), WebNLG (middle) and DART (right).
100
200
300
400
500
training_data_size
32
34
36
rouge-1
method
FT
PT
100
200
300
400
500
training_data_size
10
11
12
13
14
15
rouge-2
method
FT
PT
100
200
300
400
500
training_data_size
24
26
28
rouge-L
method
FT
PT
100
200
300
400
500
training_data_size
3
4
5
6
7
NIST
method
FT
PT
100
200
300
400
500
training_data_size
0.32
0.34
0.36
0.38
METEOR
method
FT
PT
100
200
300
400
500
training_data_size
1.2
1.4
1.6
1.8
CIDEr
method
FT
PT
Figure 7: Preﬁx-tuning (orange) outperforms ﬁne-tuning (blue) in low-data regimes in addition to requiring many
fewer parameters. The top three plots correspond to summarization, measured by ROUGE-1, ROUGE-2, and
ROUGE-L. The bottom three plots correspond to table-to-text, measured by NIST, METEOR, and CIDEr. The
x-axis is the training size and the y-axis is the evaluation metric (higher is better).
random init
"active"
"elephant"
"summarize"
"table-to-text:"
"banana"
"beautiful"
"divide"
"keep"
2
3
4
5
6
7
NIST
random init
"active"
"elephant"
"summarize"
"table-to-text:"
"banana"
"beautiful"
"divide"
"keep"
0.30
0.32
0.34
0.36
0.38
METEOR
random init
"active"
"elephant"
"summarize"
"table-to-text:"
"banana"
"beautiful"
"divide"
"keep"
0.58
0.60
0.62
0.64
0.66
ROUGE
random init
"active"
"elephant"
"summarize"
"table-to-text:"
"banana"
"beautiful"
"divide"
"keep"
1.0
1.2
1.4
1.6
1.8
CIDEr
Figure 8: Initializing the preﬁx with activations of real words signiﬁcantly outperforms random initialization, in a
low-data setting with 100 training data.

## Page 16

4597
Source [Unseen, Athelete]
(Al Kharaitiyat SC, club, Alaa Abdul-Zahra), (Al Khor, ground, Al Kharaitiyat SC), (Shabab Al-Ordon Club,
club, Alaa Abdul-Zahra) (Amar Osim, manager, Al Kharaitiyat SC)
Preﬁx-tuning
Al Kharaitiyat SC are managed by Amar Osim and play at their ground at Al Khor. Al Kharaitiyat SC are also
the club for which Alaa Abdul-Zahra is a player.
Fine-tuning
Alaa Abdul-Zahra plays for Al-Kharaitiyat SC and Shabab Al-Ordon Club. He also plays for Al-Khor and
manages Al-Kharaitiyat SC.
Reference
Alaa Abdul Zahra plays for Al Kharaitiyat SC which is located at Al Khor and managed by Amar Osim. The
Shabab Al-Ordon club is associated with Alaa Abdul-Zahra.
Source [Unseen, Transportation]
(Genoa, location, Costa Crociere), (AIDA Cruises, operator, AIDAstella), (Costa Crociere, owner, AIDAstella)
Preﬁx-tuning
AID Astella is operated by Aida Cruises and is owned by the Costa Rican tourist resort of Genoa.
Fine-tuning
AID Astella, operated by AIDA-Cruises, is located in Genoa and is owned by the Costa Rican government.
Reference
Costa Crociere is the owner of the AIDAstella and are based in Genoa. The operator of AIDAstella is AIDA
Cruises.
Source [Unseen, Politician]
(Euro, currency, Netherlands), (Stellendam, birthPlace, Ab Klink ), (Netherlands, nationality, Ab Klink)
Preﬁx-tuning
Ab Klink was born in Stellendam and is a national of the Netherlands where the currency is the Euro.
Fine-tuning
Ab Klink is a national of the Netherlands where the currency is the Euro. He was born in Stellendam.
Reference
Ab Klink was born in Stellendam in the Netherlands, where the national currency is the euro.
Source [Unseen, Politician]
(Robert E, Lee, commander, Battle of Salem Church), (American Civil War, isPartOfMilitaryConﬂict, Battle of
Salem Church), (Battle of Salem Church, battles, Aaron S. Daggett)
Preﬁx-tuning
Robert E. Lee was the commander of the Battle of Salem Church which was part of the military conﬂict in the
American Civil war.
Fine-tuning
The Battle of Salem Church is part of the American Civil War and was commanded by Robert E. Lee.
Reference
Robert E Lee was a commander in the Battle of Salem Church, which was one of the military conﬂicts in the
American Civil War. Aaron S Daggett fought in the same battle.
Source [Unseen, Artist]
(Christian alternative rock, musicSubgenre, Alternative rock), (Alternative rock, genre, Andrew White (musi-
cian))
Preﬁx-tuning
Andrew White is a Christian alternative rock musician.
Fine-tuning
Andrew White, a Christian alternative rocker, performs.
Reference
The musician Andrew White’s genre is alternative rock, the genre which has the sub genre Christian alternative
rock.
Source [Unseen, Artist]
(Hip hop music, genre, Allen Forrest), (solo singer, background, Allen Forrest)
Preﬁx-tuning
Allen Forrest is a solo singer.
Fine-tuning
Born in
Reference
Allen Forrest is a solo singer whose genre is Hip Hop music.
Source [Seen, ComicsCharacter]
(Americans, nationality, Ducan Rouleau), (Ducan Rouleau, creator, Baymax),(Alan Tudyk, starring, Big Hero 6
(ﬁlm)), (Steven T Segle, creator, Baymax), (Big Hero 6 (ﬁlm), serires, Baymax)
Preﬁx-tuning
Baymax is a character in Big Hero 6 which stars Alan Tudyk. He was created by Steven T. Seagle and the
American, Duncan Rouleau.
Fine-tuning
Alan Tudyk stars in the ﬁlm Big Hero 6 in which Baymax is a character created by Steven T. Seagle and the
American, Duncan Rouleau.
Reference
Baymax is a character who appeared in Big Hero 6 starring Alan Tudyk. It was created by Steven T Seagle and
the American, Duncan Rouleau.
Source [Seen, City]
(Washington, D.C., capital, United States), (White Americans, ethnicGroup, United States), (United States,
country, New Jersey), (New York City, largest City, United States), (New Jersy, isPartOf, Atlantic City)
Preﬁx-tuning
Washington D.C. is the capital of the United States where the largest city is New York City and the White
Americans are an ethnic group. Atlantic City, New Jersey is also part of the United States.
Fine-tuning
Atlantic City, New Jersey is part of New Jersey in the United States. The capital city is Washington D.C. and
one of the ethnic groups is White Americans.
Reference
New York City (NYC) is the largest U.S. city. Atlantic City, New Jersey are also part of the United States with
its capital as Washington, DC and home to White Americans.
Table 10: Qualitative examples from WebNLG. The ﬁrst 6 examples are from the unseen categories, labeled next
to source; the last two examples are from the seen categories. For unseen categories, both preﬁx-tuning and ﬁne-
tuning tend to undergenerate (generated output do not cover full table contents) or generate untruthfully (generated
output is inconsistent with table contents). In particular, preﬁx-tuning tends to undergenerate more often than
generate untruthfully whereas ﬁne-tuning tends to generate untruthfully. For seen categories, both perform fairly
well in terms of coverage and truthfulness.


---

# Redefinition of Fatty Liver Disease from NAFLD to MAFLD through the Lens of Drug Development and Regulatory Science

- **Authors:** Yasser Fouad, Melissa Palmer, Minjun Chen, Arie Regev, Rajarshi Banerjee, Rob Myers, Robert Riccio, Richard Torstenson, Ramy Younes, Puneet S Arora, Henrik Landgren, Morten A Karsdal, Martin Blake, David A Shapiro, Hans-Juergen Gruss, Muhammad Y Sheikh, Dina Attia, Steven Bollipo, Alastair D Smith, Bradley Freilich, Robert G Gish, Detlef Schuppan
- **Issuer:** Journal of clinical and translational hepatology
- **Type:** Scientific article
- **Published:** 2021-10-22
- **Language:** en
- **DOI:** 10.14218/jcth.2021.00408
- **Source:** https://pubmed.ncbi.nlm.nih.gov/35528969/
- **Licence:** CC-BY-NC

## Section: Abstract

AbstractMetabolic (dysfunction)-associated fatty liver disease (MAFLD) affects a third of the population and is a leading cause of liver-related death. Since no effective treatments exist, novel approaches to drug development are required. Unfortunately, outdated terminology and definitions of the disease are hampering efforts to develop new drugs and treatments. An international consensus panel has put forth an influential proposal for the disease to be renamed from nonalcoholic fatty liver disease (NAFLD) to MAFLD, including a proposal for how the disease should be diagnosed. As allies with the many stakeholders in MAFLD care―including patients, patients’ advocates, clinicians, researchers, nurse and allied health groups, regional societies, and others―we are aware of the negative consequences of the NAFLD term and definition. We share the sense of urgency for change and will act in new ways to achieve our goals. Although there is much work to be done to overcome clinical inertia and reverse worrisome recent trends, the MAFLD initiative provides a firm foundation to build on. It provides a roadmap for moving forward toward more efficient care and affordable, sustainable drug and device innovation in MAFLD care. We hope it will bring promising new opportunities for a brighter future for MAFLD care and improve care and outcomes for patients of one of the globe’s largest and costliest public health burdens. From this viewpoint, we have revisited this initiative through the perspectives of drug development and regulatory science.Keywords: NAFLD, MAFLD, NASH, Fatty liver disease, Liver, Fibrosis

## Section: Introduction

Despite the global shift in the burden of disease from viral hepatitis toward nonalcoholic fatty liver disease (NAFLD), high morbidity and mortality is still experienced by these patients. It is a leading cause of liver transplants and hepatocellular carcinoma, and it is associated with exorbitant healthcare costs. At this time, there are no approved medications for it.1 This is sobering, given the sharp contrast with the great victories that hepatology has witnessed in the treatment of viral hepatitis or as compared to other related metabolic diseases, such as type 2 diabetes and cardiovascular diseases, which have witnessed substantial evolution over the past few decades with the introduction of multiple new drug classes to the treatment landscape.

The rising prevalence of NAFLD and the lack of treatments has prompted many pharmaceutical companies to pursue novel treatments for this disease, with a significant escalation in drug development and randomized controlled trials in NAFLD.2 However, most phase 2b and phase 3 studies have shown no or a modest margin of benefit. This has led many experts to wonder why so many NAFLD clinical trials fail.3,4 In addition, recruiting patients for these clinical trials is difficult, with high screening failure rates. For those trials relying on histology for enrollment, it is even more challenging. This complicated situation has a serious negative impact on the process of drug development for NAFLD.

Using NAFLD as a definition for fatty liver disease has unique limitations. First is the limited awareness of the NAFLD term. Second is that inclusion of patients into clinical trials is based on histologic grading and staging, which affects patient recruitment since NAFLD is a much broader disease when imaging or elevated liver tests may signal this disease. Third, the diagnosis of the disease, which relies solely on “exclusion,” has a negative impact on case definition and target population when alcohol use and alcohol use disorder is a widely prevalent pair of conditions. Lastly, healthcare providers often do not consider the impact of the heterogeneity of the fatty liver disease on diagnostics modalities and therapeutic interventions. The adoption of a one-size-fits-all approach for such a heterogeneous liver disease is likely to be defective. Patient stratifications and examination for overlap of disease states are needed to prevent suboptimal performance of the investigational targets in clinical trials (Fig. 1).

In order for advancement to be achieved in the treatment of this disease, it is crucial to integrate multiple stakeholder efforts that involve the hepatology community, advocacy groups, regulatory agencies, patients, and pharmaceutical companies. Together, they need to find novel solutions to the problems posed above and apply innovative strategies for more effective clinical trial design. Recently, an international consensus panel put forth a novel redefinition for fatty liver disease, including shifting the name of the disease from NAFLD to MAFLD, as a new and more appropriate nomenclature, and providing a positive and inclusive set of diagnostic criteria of the disease to replace the previous exclusion-based set of diagnostic criteria.4–6 The proposal is generating momentum, with support from numerous liver regional societies, patients’ advocacy groups, and nursing experts.7–17 In addition, multiple studies have revealed the utility of these criteria in identifying patients with significant hepatic fibrosis, cardiovascular disease, and chronic kidney disease.18–20

Here, we intend to provide the readers with a viewpoint on this change through the lens of drug development and regulatory science. We will first discuss the challenges with the definition of the disease, then the failure of nonalcoholic steatohepatitis (NASH) trials, and lastly, we will cover how the new term and definition will improve outcomes for clinical trials and patients.

## Section: NAFLD term and definition: How does it impact patient recruitment?

There is universal recognition that patient recruitment is a predeterminate of success for clinical trials. A recent analysis of registered trials showed that 19% of clinical trials were closed or terminated early because they could not accrue enough participants.21 Even if trials do progress, they may experience significant delays due to difficulties in recruiting enough patients. Data suggest that despite the enormous patient population of those with NASH, the average rate of enrollment for NASH studies in the USA and Europe is just 0.1 patients per site, per month.22 This impacts on huge time and cost challenges and has important consequences.

At least four major barriers arising out the previous nomenclature NAFLD/NASH are identified to contribute to this low recruitment rate: (1) patients’ low awareness of NASH and physician underestimation of patient population; (2) necessity of a liver biopsy, which has to show specific histological characteristic to diagnose NASH; (3) impact of the NAFLD-related stigma, which detracts from the expansion of recruitment centers geographically; and (4) impact on building networks with other metabolic diseases with a high risk of NASH. One way to achieve the required trial enrollment numbers is to be strategic, creative, and thorough in effecting a paradigm shift that will change current approaches.

## Section: NAFLD term and definition: How does it impact patient recruitment? › Low awareness of NASH

Of the challenges that pharmaceutical companies face in enrolling patients into NASH studies, the biggest is the lack of awareness of the disease, even among patients most at risk, those with metabolic abnormalities, such as type 2 diabetes, obesity, and hypertension.23–26 Patients do not perceive the disease as a health challenge. A recent study showed that more than 80% of patients indicated they would not be concerned if they were diagnosed with NAFLD and would undertake no actions. For comparison, more than 90% of these patients indicated they would be very concerned if they were diagnosed with either hepatitis C or diabetes.27 Worryingly, many physicians are also skeptical about the significance of NAFLD, and they do not perceive it as a priority in primary care,28 which leads to underdiagnosing NAFLD in real-world settings.29,30 This suggests that healthcare providers find the current term for the disease hard to articulate or explain to patients, partly because it has a certain stigma.12 In order to overcome this stigma and uneasiness in discussing the disease, over 30 patient advocacy groups across different disciplines―including liver, renal, diabetes, and obesity―have expressed their support to the MAFLD proposal to overcome these limitations.

## Section: NAFLD term and definition: How does it impact patient recruitment? › NASH and the necessity for biopsy and histology scoring

A major barrier that hinders drug development and effective management of NAFLD is the necessity for liver histology, obtained through liver biopsy, for the diagnosis of NASH and to determine response to different therapeutic agents. This contrasts with type 2 diabetes, for example, where a simple blood test (i.e. HbA1c) is used to establish the diagnosis and assess treatment response.

Beside the technical problems with liver biopsy, including the relatively small tissue size and possibility for sampling error, the procedure is unpleasant for the patient, costly, and carries a risk of rare but potentially life-threatening complications. All of these challenges limit the use of liver biopsy as a tool for mass screening of patients.

Histology scoring of NAFLD involves the quantification of a qualitative assessment of the histology sample. For example, the scoring of balloon cells in the widely used NASH Clinical Research Network (CRN) system uses a 2-point score (as opposed to a 3-point score for steatosis or steatohepatitis) that does not specify the area (e.g., number of high-power fields) that need to be examined for the evaluation.31 Perhaps unsurprisingly, when the utility of NASH histology scoring in practice was recently evaluated in the EMMINENCE trial, both the inter- and intra-expert reader correlations were low. Inter-reader kappa scores ranged from 0.37 to 0.61, and intra-reader-weighted kappa scores ranged from 0.23 to 0.88. In addition, nearly half (46%) of patients whose qualifying histology scores were judged by at least one of three other readers did not meet the study histologic entry criteria as originally determined by a single reader. As the authors note, such inconsistencies in histologic reading diminish the apparent efficacy for a therapeutic drug.32

It has been reported that only a minority (less than 25%) of academic gastroenterologists and hepatologists in the USA routinely perform liver biopsies in patients with presumed NASH.33 A 2020 study in Germany showed that the biopsy rate of patients with NAFLD presenting at outpatient unit was low (13.6%).34 Similarly, two recent studies in Egypt showed that over 95% of patients will decline liver biopsy to assess for NASH if they are asked, as they believe the disease is not serious.27 Over 90% of physicians indicated that the acceptance rate for liver biopsy is substantially lower in patients with NAFLD as compared to that in patients with hepatitis C.35 This indicates that the low acceptance rate for liver biopsy is a widespread phenomenon, regardless of the cultural background of the patient.

Patients enrolled in phase 3 clinical trials for NASH are usually required to have a NAFLD activity score (NAS) of 4 or higher and a fibrosis stage of F2 or higher by liver biopsy according to the NASH CRN. However, approximately half of the screened individuals fail to meet these eligibility criteria.36,37 In the FLINT and REGENERATE trials for individuals with non-cirrhotic NASH histology, this was the most important selection criterion, with 71% of pre-selected study candidates being excluded because they did not have a NAFLD NAS of 4 or higher and 63% of pre-selected study candidates being excluded because they did not have a fibrosis stage of F2 or higher.38,39

In addition, the current histological endpoints of NASH clinical trials require both resolution of NASH without worsening of fibrosis and improvement of fibrosis without worsening of NASH during the treatment phase.40 This implies the need for two liver biopsies within a 48- to 72-week period. Given the exclusion criteria of NAFLD, liver biopsy is also performed to rule out other differential diagnoses just to make the diagnosis of NAFLD.

Histological baseline criteria and the need for two liver biopsies represent the major hurdles for the recruitment of patients in clinical trials and could lead to selection bias, as individuals who make it through the hurdles might be not representative of the total NAFLD patient population. It is, therefore, crucial to identify efficient noninvasive parameters. Although we have many good markers for fibrosis, fat, and inflammation, and imaging modalities for fibrosis, it may take two, three, or four studies to focus on an implied histological diagnosis.41–43 We have many noninvasive markers for NASH, yet none are accepted by the USA Food and Drug Administration (FDA) or European Medicines Agency (EMA) for phase 2b and 3 trials, which still require two liver biopsies.43 In addition, it is still a nonvalidated surrogate endpoint that is “likely” to anticipate clinical benefit (i.e. how a patient feels, functions, and survive). The implication being that registrational studies still need to have the phase 3/phase 4 design, which adds further complexity.

Fibrosis is the major determinant of liver-related complications and mortality.44 Fibroblast activity drives fibrosis progression, organ function loss, and comorbidities.45 The fibroblast is the principle promoter of extracellular matrix, which is expanded in all fibrotic disorders.46 The fibrotic extracellular matrix consists mainly of collagens, which are produced by activated fibroblasts. This is important, independent of insults, as there are serological biomarkers that may quantify the overall fibrotic activity, which drives progression, independent of insult, and can objectively quantify the level of activity. All of this may be associated with outcome, response to treatment, and thus the quality of life of patients. For example, type III collagen, either quantified by N-terminal pro-peptide of type III collagen (PIIINP) or type III procollagen (PRO-C3),47 have been directly associated with fibroblast activity, which predicts fibrosis progression,48 response to therapy,49 and relation to fibrosis stage in algorithms such as the ADAPT score (Age, presence of DiAbetes, PRO-C3 [a marker of type III collagen formation], and plateleT count).41 Elevated levels of type III collagen formation is the common denominator in most fibrotic diseases and have been reported in hepatitis B,50 hepatitis C,51 MAFLD,41–43 idiopathic pulmonary fibrosis,52 systemic sclerosis,53 and chronic kidney disease.54

## Section: NAFLD term and definition: How does it impact patient recruitment? › Limited geography and site location

To access the required number of patients for developing large clinical trials, recruitment outside of traditional Western markets would be required. Despite its large population and having the highest prevalence of NAFLD worldwide,1,11 the Middle East North Africa (MENA) region has not been considered in most NAFLD clinical trials. The disease remains substantially underdiagnosed in the region, due to the severe social stigma associated with the word alcohol in the NAFLD term.11–13

There are many preferential advantages for recruitment in the MENA region. These include the projected higher recruitment rate because of the large general population, and the productivity estimated as aggregated average number of patients per site is approximately 2-fold higher in the MENA region than developed markets in the West.55 The MENA region has shown great capacity for drug development in the era of hepatitis C trials. Additionally, the patients in this region are typically study-naïve and are not recruited in competing clinical trials.56 The costs of conducting a trial are usually considerably lower in the MENA region (including costs for selection of a trial site and patient enrollment compared to Western countries). The unique different ethnicities, the geographic isolation of subpopulations, and the high rate of consanguineous marriages suggest the region can contribute its distinctive gene pool of the MENA region to research.56 Finally, the pharmaceutical market in the Middle East combined with Africa has one of the highest growth rates globally.57 These numbers and reasons reflect that the region has a sizable population and unique opportunity not yet tapped. Overcoming the challenge of the NAFLD term would open new horizons for the market of drug development for fatty liver disease.

## Section: NAFLD term and definition: How does it impact patient recruitment? › No link to other metabolic diseases

One of the major problems with the current NAFLD term is that it implies no link with metabolic diseases. Many stakeholders cite this as a barrier for educating healthcare providers outside of the hepatology community on NAFLD/NASH and for integrating NAFLD/NASH into public health policies and action plans on obesity and other related metabolic conditions.12 The current NAFLD term and definition presents a barrier to diagnosis in primary care and non-hepatology settings, particularly in resource-constrained health systems.

## Section: Failure of so many NASH trials: Are current structures designed to fail?

Recent, largely negative, trials beg the question: why do so many NASH trials fail?3,4 (Table 1).

Apart from generic concerns in trial design, various reasons for failure are specific to the definition of the disease.

## Section: Failure of so many NASH trials: Are current structures designed to fail? › Relying on outdated case definitions

Prevention of cirrhosis and demonstrating a positive effect on well-defined liver outcomes are key clinical goals when considering a NASH drug development program. Therefore, for trials aiming to support a marketing application, it is important that patients with the greatest risk of progression to cirrhosis be enrolled. Among individual features, liver fibrosis has proven the best independent association with liver-related mortality.44 The MAFLD new definition could identify patients at the highest risk of fibrosis, unlike the current NAFLD definition, which does not help identify the right target population.

## Section: Failure of so many NASH trials: Are current structures designed to fail? › Relying on histology rather than disease drivers

One of the main issues with the current definition of the disease is that phase 2b and 3 trial recruitment is based on histologic grading and staging.4 Because many pathways can lead to the same histologic stage, dissection of the predominant pathogenic pathways or the target pathway of the drug (and the stage of the disease at which it is administered) are needed.58,59 Unfortunately, stratifications based on NASH dichotomization do not recognize where an individual patient lies in this pathogenic continuum within liver injury. Due to the differing manifestations of NAFLD, several classes of drugs are required for NAFLD that can be tailored with personalized medicine for patients across the entire continuum of the disease.

## Section: Failure of so many NASH trials: Are current structures designed to fail? › Relying on a one-size-fits-all approach

The heterogeneous nature of fatty liver diseases suggest that they cannot be conceptualized as a single entity and managed using a one-size-fits-all strategy.4 Not considering heterogeneity, particularly for metabolic comorbidities may affect treatment response and may interfere with the ability to aptly select patients for clinical trials and evaluate therapeutic drugs. For instance, in the CENTAUR study, cenicriviroc showed a substantial variation in achieving the histologic endpoints in the diabetic groups compared to non-diabetic groups.60 Similarly, in the FLINT trial, the effect of obeticholic acid was negatively affected by baseline hypertriglyceridemia.61

In addition, the disease heterogeneity may also affect the performance of non-invasive fibrosis diagnostic tools such as the NAFLD fibrosis score (NFS), fibrosis 4 index (FIB-4), transient elastography liver stiffness measurement (LSM), and controlled attenuation parameter (CAP), which may vary across the lifespan and between different ethnic populations, and in special subpopulations such as patients with diabetes or those who are obese.62,63

To overcome the challenges described earlier, a stratified randomization approach, may be needed. Such an approach will require new definitions of the disease to be developed that pave the way for patient stratification (Fig. 2).

## Section: MAFLD term and definition: New solutions to fatty liver disease’s challenging questions

To change the paradigm in NAFLD/NASH, a novel approach is needed. Embracing real-world evidence and interrogating multiple stakeholders for their views (particularly patients) will allow us to better identify undiagnosed patients, engage primary care providers and non-hepatologists, and create market access and networking strategies that make sense for fatty liver diseases and the patients they affect.

To overcome these challenges, in 2020, an international consortium of 32 experts from 22 countries put forth an influential proposal to update the nomenclature of fatty liver disease associated with metabolic dysfunction from NAFLD to MAFLD. They also formulated a novel set of positive diagnostic criteria to replace the previous negative criteria.4,5 We strongly believe that a transformational change from NAFLD to MAFLD,4,5 with the accompanied new definition of the disease, will be an important initial step in achieving this and may circumvent many challenges faced in the era of NAFLD use.

MAFLD is a multisystem disease with links to other metabolic disorders, such as diabetes, cardiovascular disease, and chronic kidney disease. MAFLD will bring fatty liver disease closer to other metabolic diseases and enhance understanding of the shared pathways and phenotypes between MAFLD and these related metabolic disorders that are usually investigated in larger cohorts, which can ultimately help in drug repurposing.

## Section: MAFLD term and definition: New solutions to fatty liver disease’s challenging questions › Improve case detection and identification of target population

Emerging evidence shows that the diagnostic criteria in the MAFLD definition identify patients with significant hepatic fibrosis, cardiovascular disease, or chronic kidney disease,18–20,64 and those who would benefit from evaluating genetic risks for fatty liver65 better than the previous NAFLD criteria. The utility of the MAFLD criteria have also been shown in patients with other diseases such as hepatitis B,66 hepatitis C,67,68 human immunodeficiency virus,69 celiac disease,70 Gaucher disease,71 and myotonic dystrophy type 1,72 which need to be excluded to diagnose NAFLD. Not being able to concomitantly diagnose NAFLD and these diseases is another disadvantage to using the NAFLD definition since alcohol and these conditions are excluded, by definition!

## Section: MAFLD term and definition: New solutions to fatty liver disease’s challenging questions › Enhance patient recruitment

To overcome the limitation of recruitment, new tools and strategies are needed to more efficiently recruit patients. The correction of terminology may bring MAFLD to the visibility of other metabolic diseases.12 Shifting to the MAFLD term and definition would enable a recruitment strategy to focus on patients with high risk factors and/or diagnosis. This model allows active engagement of diverse stakeholders and the building of an innovation network that would help to identify the large pool of patients with comorbidities such as obesity, type 2 diabetes, or other cardiovascular disease risk factors, who are at a greater risk for NAFLD/NASH. A recent study showed that changing from using NAFLD to MAFLD increased awareness of the disease among primary care providers and physicians in other specialties,35 which can increase trial enrollment rates. Two other studies have demonstrated improved patient awareness with the new term MAFLD.27,73

Use of this new term could lead to efforts to include MAFLD in public health policies and action plans on other related conditions and to launch shared health promotion campaigns. This would allow for establishing new multidisciplinary models of care and teams for MAFLD and foster the development of cross-specialty guidelines to help implement multidisciplinary care in practice.

As recently suggested by the Latin American Association for the Study of the Liver (ALEH), Chinese Society of Hepatology and the Sub-Saharan Africa position statement,9,14,16 simplification of the diagnosis of MAFLD would facilitate the education of primary care providers on MAFLD and develop clear care pathways. This would encourage more effective diagnosis at the community level and the screening of high-risk individuals for MAFLD in primary care and non-hepatology settings, with more efficient and likely cost-effective referral pathways. This would be crucial particularly in resource-constrained health systems.

Such change would enable an expansion of geographic regions for recruiting sites to areas such as MENA and Africa that are not considered at the moment. Based on the conceptualized diagnostic criteria of MAFLD and the reality of the real-world patient landscape, with the high prevalence of MAFLD and alcohol intake worldwide, we may need to consider a more pragmatic approach to target patients with MAFLD with potentially a higher threshold of alcohol intake than used in the past.

Setting definitions for MAFLD based on “positive” criteria and excluding patients with fatty liver unrelated to metabolic dysfunction (with fatty liver but not MAFLD) will render study cohorts more homogeneous, increasing the likelihood of detecting a significant impact on clinical approaches targeting MAFLD.

## Section: MAFLD term and definition: New solutions to fatty liver disease’s challenging questions › Improve assessment of drug efficacy

Relying on biopsies makes diagnosing NASH a difficult task for physicians and patients, and it likely complicates the assessment of drug efficacy. Recent studies have raised concerns that the suboptimal reliability of liver biopsy evaluations is having a negative impact on clinical trials.32 This is usually more profound with pathological assessment of NASH compared to fibrosis. There is tremendous plasticity in metabolic liver disease over the life span, and patients can fluctuate from steatosis to NASH and vice versa over short spans of time, with a strong evidence that fibrosis is the major determinant of adverse outcomes.44 To use an analogy, assessment of NASH is like measuring blood glucose in diabetes, while fibrosis is like measuring HbA1c. These factors create serious obstacles for pharmaceutical companies and clinical researchers working to develop treatments for this condition.

Again, redefinition of the disease and considering the disease as a continuum that can be assessed similar to other chronic liver diseases (with some activity and a stage of fibrosis) would help. It would refocus the attention to the need for identification and approval of drugs for the whole spectrum of the disease, as currently exists to treat hypertension or diabetes.

## Section: MAFLD term and definition: New solutions to fatty liver disease’s challenging questions › Create novel clinical trial design

The population of patients with MAFLD is diverse and complex.4 The proposed change to using the term MAFLD and its new definition would allow the consideration of alternative and innovative trial designs, such as umbrella, basket, and adaptive designs that could circumvent the aforementioned challenges.

Umbrella trial designs or master protocols allow multiple questions to be assessed and different drugs to be investigated in different conditions (more than one patient subtype or disease), within the same overall trial structure.74 Emerging evidence suggest the presence of subtypes of MAFLD based on the diagnostic criteria; for example, those who meet the overweight/obesity criterion having different characteristics from those who meet the diabetes criterion.20

Basket trials include designs to evaluate a particular drug for multiple diseases that share similar features or pathways (e.g., MAFLD, cardiovascular disease, and type 2 diabetes mellitus), paving the way for clinical trials for shared metabolic diseases.

Adaptive trial designs provide flexibility to adapt one or more aspects of the basic features of the study design based on early findings,75 for example include more patients with diabetes or hyperlipidemia, if early interim analysis shows efficacy in this group (Fig. 3).

MAFLD is a multisystem disease with links to other metabolic disorders, such as diabetes, cardiovascular disease, and chronic kidney disease. MAFLD will bring fatty liver disease closer to other metabolic diseases and enhance understanding of the shared pathways and phenotypes between MAFLD and these related metabolic disorders that are usually investigated in larger cohorts, which can ultimately help in drug repurposing.

## Section: The importance of renaming NAFLD to MAFLD for the pediatric population

NAFLD occurs in approximately 40% of obese children and adolescents and in up to 10% of the general pediatric population.76–78 The pathophysiology of NAFLD/NASH in children is complex and multifactorial, may begin in utero, and is different from adult disease.79–82 But there are similarities to adults with NAFLD; children often have insulin resistance, central or generalized obesity, and dyslipidemia and are at increased risk of cardiovascular disease,83 renal disorders,84 and obstructive sleep apnea. As with NAFLD in adults, treatment is limited to lifestyle modification, which is rarely sustainable.

Despite the increased prevalence, its seriousness, and the unmet medical need of patients with pediatric NAFLD, very few clinical trials have been or are being conducted in this population. This starkly contrasts with the explosion of clinical trials available to adults with NAFLD/NASH. Presently on clinicaltrials.gov, there are no actively recruiting industry-sponsored interventional, multicenter, placebo-controlled clinical trials for pediatric NAFLD.

Thus, the term NAFLD may be an important contributing factor to this discrepancy, as this term is an even greater misnomer in children than in adults. First, excessive alcohol use, especially in younger children, is rarely a contributing factor or a consideration when assessing the etiology of a fatty liver, and second, inherited metabolic disorders often resemble and/or may also occur with NAFLD.85 Using the term nonalcoholic when referring to a pediatric patient with a fatty liver is not only usually inaccurate, it is also likely to be a source of confusion to the family. This may be an important factor contributing to the difficulties in recruiting a pediatric NAFLD/NASH trial. When discussing a child’s diagnosis and potential trial participation, using the term MAFLD would likely be easier for the family to understand and to accept, and it may generate increased interest in clinical trial participation. Recent suggestions from experts encourage the change from NAFLD to MAFLD.85

The prevalence of pediatric obesity is increasing at alarming rates. Using body mass index alone has become a less accurate means for distinguishing NAFLD from an underlying inherited metabolic disorder as the etiology of a fatty liver.85 Notably, recently, a novel set of diagnostic criteria for pediatric MAFLD was released.6

## Section: Conclusions

In this work, we revisited the redefinition of fatty liver disease through the perspective of drug development and regulatory science. As allies with the many stakeholders in MAFLD healthcare―including patients, patients’ advocates, clinicians, researchers, nursing and allied health groups, regional societies, and others―we share the sense of urgency for change and will act in new ways to achieve our goals. Although there is much work to be done to overcome clinical inertia and reverse worrisome recent trends,86 we believe that the MAFLD initiative provides a firm foundation to build on. It provides a roadmap for moving forward on more efficient care and affordable, sustainable drug and device innovation in MAFLD care. We hope it will bring promising new opportunities for a brighter future for MAFLD care and improve care and outcomes for patients of one of the globe’s largest and costliest public health burdens.

## Section: Acknowledgments

We thank Kelly Schrank, MA, ELS, of Bookworm Editing Services LLC for her editorial services in preparing the manuscript for publication.


---

# Reporting guidelines for artificial intelligence in healthcare research

- **Authors:** Hussein Ibrahim, Xiaoxuan Liu, Alastair K Denniston
- **Issuer:** Clinical & experimental ophthalmology
- **Type:** Scientific article
- **Published:** 2021-05-25
- **Language:** en
- **DOI:** 10.1111/ceo.13943
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33956386/
- **Licence:** CC-BY

## Section: Abstract

Reporting guidelines are structured tools developed using explicit methodology that specify the minimum information required by researchers when reporting a study. The use of artificial intelligence (AI) reporting guidelines that address potential sources of bias specific to studies involving AI interventions has the potential to improve the quality of AI studies, through improvements in their design and delivery, and the completeness and transparency of their reporting. With a number of guidance documents relating to AI studies emerging from different specialist societies, this Review article provides researchers with some key principles for selecting the most appropriate reporting guidelines for a study involving an AI intervention. As the main determinants of a high-quality study are contained within the methodology of the study design rather than the intervention, researchers are recommended to use reporting guidelines that are specific to the study design, and then supplement them with AI-specific guidance contained within available AI reporting guidelines.


---

# Reporting guidelines for clinical trials of artificial intelligence interventions: the SPIRIT-AI and CONSORT-AI guidelines

- **Authors:** Hussein Ibrahim, Xiaoxuan Liu, Samantha Cruz Rivera, David Moher, An-Wen Chan, Matthew R Sydes, Melanie J Calvert, Alastair K Denniston
- **Issuer:** Trials
- **Type:** Scientific article
- **Published:** 2021-01-06
- **Language:** en
- **DOI:** 10.1186/s13063-020-04951-6
- **Source:** https://pubmed.ncbi.nlm.nih.gov/33407780/
- **Licence:** CC-BY

## Section: Abstract

BackgroundThe application of artificial intelligence (AI) in healthcare is an area of immense interest. The high profile of ‘AI in health’ means that there are unusually strong drivers to accelerate the introduction and implementation of innovative AI interventions, which may not be supported by the available evidence, and for which the usual systems of appraisal may not yet be sufficient.Main textWe are beginning to see the emergence of randomised clinical trials evaluating AI interventions in real-world settings. It is imperative that these studies are conducted and reported to the highest standards to enable effective evaluation because they will potentially be a key part of the evidence that is used when deciding whether an AI intervention is sufficiently safe and effective to be approved and commissioned. Minimum reporting guidelines for clinical trial protocols and reports have been instrumental in improving the quality of clinical trials and promoting completeness and transparency of reporting for the evaluation of new health interventions. The current guidelines—SPIRIT and CONSORT—are suited to traditional health interventions but research has revealed that they do not adequately address potential sources of bias specific to AI systems. Examples of elements that require specific reporting include algorithm version and the procedure for acquiring input data. In response, the SPIRIT-AI and CONSORT-AI guidelines were developed by a multidisciplinary group of international experts using a consensus building methodological process. The extensions include a number of new items that should be reported in addition to the core items. Each item, where possible, was informed by challenges identified in existing studies of AI systems in health settings.ConclusionThe SPIRIT-AI and CONSORT-AI guidelines provide the first international standards for clinical trials of AI systems. The guidelines are designed to ensure complete and transparent reporting of clinical trial protocols and reports involving AI interventions and have the potential to improve the quality of these clinical trials through improvements in their design and delivery. Their use will help to efficiently identify the safest and most effective AI interventions and commission them with confidence for the benefit of patients and the public.

## Section: Background

Artificial intelligence (AI) is an area of immense and increasing interest within medicine. Developments in machine learning (ML) techniques, such as deep learning, and their application to data-rich problems, such as medical imaging, have highlighted several potential healthcare applications. Examples are wide ranging and include AI interventions for screening and triage [1–3], diagnosis [4–6], prognostication [7, 8], decision support [9], and treatment recommendation [10]. The high profile of ‘AI in health’ means that there are unusually strong drivers to accelerate the introduction and implementation of these innovative interventions, which may not be supported by the available evidence, and for which the usual systems of appraisal may not yet be sufficient.

## Section: Main text › The evidence gap for AI health interventions

Evidence that an AI intervention improves patient outcomes and is cost-effective is a prerequisite to implementation if the ultimate goal is to bring benefits to patients and society. However, in most cases, existing evidence for AI consists of in silico, early-phase, validation experiments. The outcome is mostly diagnostic or predictive accuracy and the comparator is often poorly reflective of real-world standards. These initial experiments provide early evidence of potential efficacy but, critically, they are not prospective and do not evaluate patient outcomes or provide evidence of cost-effectiveness.

The strongest evidence for the safety and efficacy of an intervention requires evaluation in the context of one or more randomised clinical trials [11]. This is true for all interventions, including those involving AI systems. Although most AI interventions in health have not yet been evaluated in clinical trials, this is likely to be an area of rapid expansion as the field matures, and as policy makers become clearer as to the evidence they require. These studies should place AI interventions within their intended clinical setting, consider patient outcomes as the primary endpoint, and consider potentially deleterious downstream consequences. Crucially, the evidence from these studies should be, like all trials, conducted and reported to the highest standard to enable effective evaluation, because they will potentially be a key part of the evidence that regulators, payers, and policy makers use when deciding whether an AI intervention is sufficiently safe and effective to be approved and commissioned.

## Section: Main text › Complete and transparent reporting of clinical trial protocols and reports

The critical appraisal of clinical trials is an essential part of evidence-based practice where the quality of research and thereby the trustworthiness of its results are carefully and systematically evaluated [12]. Reviewers are able to assess the quality, value, and relevance of a clinical trial by considering the way it was designed, conducted, and analysed and by evaluating its internal and external validity. This process supports relevant stakeholders when making considered decisions about whether or not an intervention should be approved and commissioned.

The critical appraisal of clinical trial protocols is equally important in enabling readers and reviewers to evaluate proposed investigative plans. Reviewers of trial protocols can ensure investigators design clinical trials that should yield valid results in an ethically sound way. As a shared reference point, it also enables reviewers of clinical trial reports to ensure that investigators did what they intended on doing.

Critical appraisal is contingent on clear and comprehensive reporting. Reviewers cannot evaluate a clinical trial protocol unless investigators explain exactly what they intend on doing. Similarly, reviewers cannot evaluate a clinical trial unless investigators explain exactly what they did. This highlights two important characteristics of clinical trial protocols and reports: completeness and transparency of reporting.

The SPIRIT 2013 [13] (Standard Protocol Items: Recommendations for Interventional Trials) and CONSORT 2010 [14] (Consolidated Standards of Reporting Trials) statements are minimum reporting guidelines for clinical trial protocols and completed trials, respectively. The endorsement of these guidelines by the International Committee of Medical Journal Editors [15] as well as medical journals that require authors to comply by them at the point of submission has been instrumental in promoting completeness and transparency for the effective evaluation of new health interventions [16].

## Section: Main text › The SPIRIT-AI and CONSORT-AI guidelines

Systematic reviews of existing clinical trials evaluating AI interventions have highlighted gaps in their reporting, and it has been recognised that current reporting guidelines do not adequately address potential sources of bias specific to AI systems [17, 18]. Examples of elements that require detailed and specific reporting include, but are not limited to, the algorithm version, the procedure for acquiring the input data, and the criteria for inclusion at the level of the input data in addition to the level of participants. For instance, in a clinical trial evaluating an AI system for diagnosing knee osteoarthritis using knee radiographs, authors must specify which version of the AI system was used and state whether this changed throughout the course of the trial; describe how knee radiographs were acquired, selected, and pre-processed before analysis by the AI system; and report the eligibility criteria at both the level of participants, such as patient age, and input data, such as knee radiograph image quality. Detailed and specific reporting of the input data criteria separately to the participant criteria is especially important as it enables evaluators to differentiate between those AI interventions that only work in ideal conditions and those that are more robust and suitable for real-world settings.

The risk of an AI intervention being approved and commissioned based on incomplete information highlights the need for AI-specific reporting guidance. To address this, the SPIRIT-AI and CONSORT-AI Steering Group announced in October 2019 an initiative to develop evidence-based extensions for clinical trial protocols and reports involving AI interventions [19]. The SPIRIT-AI [20–22] and CONSORT-AI [23–25] guidelines have since been developed in accordance with the EQUATOR (Enhancing the Quality and Transparency of Health Research) Network recommendations. The guidelines were developed using a Delphi methodology with an international multidisciplinary consortium. The consensus process involved relevant stakeholders with expertise in the application of AI in health and key users of the technology. Stakeholders included clinicians, computer scientists, experts in law and ethics, funders, health informaticists, industry partners, journal editors, methodologists, patients, policy makers, regulators, and statisticians.

The SPIRIT-AI [20–22] and CONSORT-AI [23–25] guidelines include 15 and 14 new items, respectively, that should be routinely reported in addition to the core SPIRIT 2013 [13] and CONSORT 2010 [14] items. For example, the new guidelines recommend that investigators should provide clear descriptions of the AI intervention, including instructions and skills required for use, the study setting in which the AI intervention is integrated, the handling of inputs and outputs of the AI intervention, the human-AI interaction, and the analysis of error cases. Each item, where possible, was informed by challenges identified in existing studies of AI systems in health settings.

The SPIRIT-AI [20–22] and CONSORT-AI [23–25] guidelines have the potential to improve the quality of clinical trials of AI systems in health, through improvements in design and delivery, and the completeness and transparency of their reporting. It is, however, important to appreciate the context in which these guidelines sit. First, the new items within SPIRIT-AI [20–22] and CONSORT-AI [23–25] are all extensions or elaborations rather than substitutes for the core items. Core considerations addressed by SPIRIT 2013 [13] and CONSORT 2010 [14] remain important in all clinical trial protocols and reports, regardless of the intervention itself. In addition, depending on the trial design and outcomes, other SPIRIT or CONSORT guidelines may be relevant [26, 27].

Second, SPIRIT-AI [20–22] and CONSORT-AI [23–25] are specific to clinical trials, whereas it should be recognised that most current evaluations of AI systems are some form of diagnostic accuracy or prognostic model study. AI-specific guidelines that will address such studies, STARD-AI [28] (Standards for Reporting Diagnostic Accuracy Studies – Artificial Intelligence) and TRIPOD-AI [29] (Transparent Reporting of a Multivariable Prediction Model for Individual Prognosis or Diagnosis – Artificial Intelligence), are currently under development. Whilst there are likely to be common elements between these AI extensions, investigators reporting should use, and reviewers appraising should receive, the most suitable guideline available which considers both the study design and the type of intervention.

Third, the SPIRIT-AI [20–22] and CONSORT-AI [23–25] guidelines will evolve to keep pace with this fast-moving field. The dearth of clinical trials involving AI interventions to date means that discussions that took place and decisions that were made during the development of these guidelines were not always supported by ‘real life’ lessons from the literature. Additionally, the recommendations are most relevant to the current context and contemporaneous challenges. The extensions proactively rather than reactively address reporting issues in this rapidly evolving field and, naturally, newer and more nuanced versions will be necessary as the field continues to evolve.

For example, SPIRIT-AI [20–22] and CONSORT-AI [23–25] were mostly informed by current applications of AI, mainly focussing on disease detection and diagnosis, and will need updating as additional applications such as those that utilise AI as therapy begin to emerge. Similarly, current extensions do not yet address AI systems involving ‘adaptive’ algorithms. The performance of these types of AI systems—which continue to ‘learn’ as they are updated or tuned on new training data—can change over time. This is unlikely to pose a problem at present because these AI systems are still at an early stage in their development but will be an important issue to address in future iterations.

## Section: Conclusion

The SPIRIT-AI [20–22] and CONSORT-AI [23–25] guidelines—co-published in Nature Medicine, The BMJ, and The Lancet Digital Health in September 2020—provide the first international standards for clinical trials of AI systems in health. The extensions are designed to ensure complete and transparent reporting and enable effective evaluation of clinical trial protocols and reports involving AI interventions. They have been developed by key stakeholders from across sectors with widespread support and representation. As we now look to their implementation, we are delighted that leading medical journals including Trials are endorsing these guidelines, and their extensions, and encouraging their widespread adoption to support the design, delivery, and reporting of clinical trials of AI systems in health. It is only through this process that we will be able to adequately evaluate AI interventions, and enable safe and effective systems to be deployed with confidence for the benefit of patients and the public.


---

# Review of study reporting guidelines for clinical studies using artificial intelligence in healthcare

- **Authors:** Susan Cheng Shelmerdine, Owen J Arthurs, Alastair Denniston, Neil J Sebire
- **Issuer:** BMJ health & care informatics
- **Type:** Scientific article
- **Published:** 2021-08-01
- **Language:** en
- **DOI:** 10.1136/bmjhci-2021-100385
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34426417/
- **Licence:** CC-BY-NC

## Section: Abstract

High-quality research is essential in guiding evidence-based care, and should be reported in a way that is reproducible, transparent and where appropriate, provide sufficient detail for inclusion in future meta-analyses. Reporting guidelines for various study designs have been widely used for clinical (and preclinical) studies, consisting of checklists with a minimum set of points for inclusion. With the recent rise in volume of research using artificial intelligence (AI), additional factors need to be evaluated, which do not neatly conform to traditional reporting guidelines (eg, details relating to technical algorithm development). In this review, reporting guidelines are highlighted to promote awareness of essential content required for studies evaluating AI interventions in healthcare. These include published and in progress extensions to well-known reporting guidelines such as Standard Protocol Items: Recommendations for Interventional Trials-AI (study protocols), Consolidated Standards of Reporting Trials-AI (randomised controlled trials), Standards for Reporting of Diagnostic Accuracy Studies-AI (diagnostic accuracy studies) and Transparent Reporting of a multivariable prediction model for Individual Prognosis Or Diagnosis-AI (prediction model studies). Additionally there are a number of guidelines that consider AI for health interventions more generally (eg, Checklist for Artificial Intelligence in Medical Imaging (CLAIM), minimum information (MI)-CLAIM, MI for Medical AI Reporting) or address a specific element such as the ‘learning curve’ (Developmental and Exploratory Clinical Investigation of Decision-AI). Economic evaluation of AI health interventions is not currently addressed, and may benefit from extension to an existing guideline. In the face of a rapid influx of studies of AI health interventions, reporting guidelines help ensure that investigators and those appraising studies consider both the well-recognised elements of good study design and reporting, while also adequately addressing new challenges posed by AI-specific elements.

## Section: Introduction

Recent, rapid developments in computational technologies and increased volumes of digital data for analysis have resulted in an unprecedented growth in research activities relating to artificial intelligence (AI), particularly within healthcare. This volume of work has even led to several high impact journals launching their own subjournals within the ‘AI healthcare’ field (eg, Nature Machine Intelligence,1 Lancet Digital Health,2 Radiology: Artificial Intelligence).3 High-quality research should be accompanied by transparency, reproducibility and validity of techniques for adequate evaluation and translation into clinical practice. Standardised reporting guidelines help researchers define key components of their study, ensuring that relevant information is provided in the final publication.4 Studies pertaining to algorithm development and clinical application of AI however, have brought unique challenges and added complexities in how such studies are reported, assessed and compared in relation to elements that are not conventionally prespecified in traditional reporting guidelines. This could lead to missing information and high risk of hidden bias. If these actual or potential limitations are not identified, then it may lead to tacit approval through publication which in turn may support premature adoption of new technologies.5 6 Conversely well-designed, well-delivered studies that are poorly reported may be judged unfavourably due to being adjudged to have a high risk of bias, simply due to a lack of information.

Inadequacies of reporting of AI clinical studies are increasingly well-recognised. In 2019, a systematic review by Liu et al7 reviewed over 20 500 articles, but found that fewer than 1% of these were sufficiently robust in their design and reporting allowing independent reviewers to have confidence in their claims. Similarly Nagendran et al8 identified high levels of bias in the field. In another study,9 it was reported that only 6% of over 500 eligible radiological-AI research publications performed any external validation of their models, and none used multicentre or prospective data collection. Similarly most studies using machine learning (ML) models for medical diagnosis10 did not have adequate detail on how these were evaluated nor sufficient detail for these to be reproduced. Inconsistencies in how ML models from electronic health records have also been reported, with details regarding race and ethnicity of participants omitted in 64% of studies, and only 12% of models being externally validated.11

In order to address these concerns, adapted research reporting guidelines based on the well-established EQUATOR Network (Enhancing the QUAlity and Transparency Of health Research)12 13 and de novo recommendations by individual societies have been published, with a greater relevance for AI research. In this review, we highlight those that will cover the majority of healthcare focused AI-related studies, and explain how they differ to the well-known guidance for non-AI related clinical work. Our intention is to raise awareness of how such studies should be structured, thereby improving the quality of future submissions and providing a helpful aid for researchers, peer reviewers and editors.

In compiling a detailed, yet relevant list of study guidelines, we reviewed the EQUATOR network13 website for those containing the terms AI, ML or deep learning. A separate search was also conducted using Medline, Scopus and Google Scholar databases for publications using the same search terms with the addition of ‘reporting guideline’, ‘checklist’ or ‘template’. Opinion pieces were excluded. Articles were included where the description of the recommendations were provided, and published at time of the search (March 2021).

## Section: Types of research reporting guidelines

An ideal reporting guideline should be a clear, structured tool with a minimum list of key information to include within a published scientific manuscript. The EQUATOR Network13 is the international ‘standard bearer’ for reporting guidelines, committed to improving ‘the reliability and value of published health research literature by promoting transparent and accurate reporting and wider use of robust reporting guidelines’. Since the landmark publication of Consolidated Standards of Reporting Trials (CONSORT),14 the network has overseen the development and publication of a number of guidelines that address other types of study design (eg, diagnostic accuracy studies). The EQUATOR guidelines are centrally registered (available via a core library) which ensures adherence to robust methodology of development and avoids redundancy of parallel initiatives to address the same issue. Importantly these guidelines are not medical specialty specific but are focused on the type of study, which helps ensure that there is a consistent approach and quality for addressing the same study design. It is recognised that certain specific scenarios may require specific extensions to these guidelines. For example, the increasing recognition of the importance of patient-reported outcomes (PROs) has led to the development of Standard Protocol Items: Recommendations for Interventional Trials (SPIRIT-PRO)15 and CONSORT-PRO.16 In a similar way, the specific attributes of AI as an intervention, has led to a number of AI extensions, both published and in process, which build on the robust methodology of the original EQUATOR guidelines, while ensuring AI-specific elements are also addressed.

In parallel to the work of the EQUATOR network, a number of experts and institutions have developed their own recommendations for good practice and reporting. In contrast, these start with the intervention (ie, AI) rather than the study type (ie, randomised controlled trial (RCT)), and therefore, cover essentially the same territory. They vary in depth, and there can be differences in nuance depending on their primary purpose. For example some have originated from the need to support reviewers and editorial staff (‘is this complete and is it good enough?’), whereas others are addressing at building a shared understanding of appropriate design and delivery (‘this is what good looks like’).

Given the number of different reporting guidelines in this area, there is value in setting them in context to help support users in understanding which is most appropriate for a particular setting (table 1). Ultimately the most important elements of a high-quality study are contained within the methodology of the study design itself and not within the intervention. It is these elements that help minimise the major biases that all studies must address. In line with leading journals, we would, therefore, recommend starting with the guideline that addresses that particular study design (eg, CONSORT14 for an RCT). If an AI extension is already in existence for that study type then these are clearly appropriate for that study (eg, CONSORT-AI).17–19 If no such -AI extension exists then we recommend using the appropriate EQUATOR guideline (eg, Standards for Reporting of Diagnostic Accuracy Studies (STARD)20 for diagnostic accuracy studies), but supplementing with AI-specific elements recommended in other guidelines (eg, SPIRIT-AI,21–23 CONSORT-AI17–19 or the non-EQUATOR guidelines described below). Indeed all the guidelines considered here contain valuable insights into the specific challenges of AI studies, and are recommended reading into good practice for design and reporting.

Summary of reporting guidelines for common study types used in radiological research, and their corresponding guideline extensions where these involve artificial intelligence

## Section: EQUATOR network guidelines

Additional items proposed for studies relating to AI intervention clinical protocols within the SPIRIT-AI statement (in addition to the SPIRIT 2013 statement)

Additional criteria to be included for studies relating to AI interventions within the CONSORT-AI statement (in addition to the CONSORT 2010 statement)

## Section: EQUATOR network guidelines › Clinical trials protocols

The quality of a study and the trustworthiness of its findings, starts at the design phase. The study protocol should contain all elements of the study design, sufficient for independent groups to carry out the study and expect replicability. Prepublication of the study protocol, helps avoid biases such as post-hoc assignment of the primary outcome in which the triallist can ‘cherry pick’ one of a number of outcomes that point in the desired direction.

Guidance for recommended items to include in a trial protocol are provided by the SPIRIT Statement (latest version published in 2013),24 which has been recently adapted for trials with an AI-related focus, termed the ‘SPIRIT-AI’ guideline.21–23 This adaptation includes an additional 15 items (12 extensions, 3 elaborations) to the existing 33-item SPIRIT 2013 guideline. The key differences are outlined in table 2, mostly focused on the methodology of the trial, (accounting for eight extensions, one elaboration) with emphasis on inclusion/exclusion of data and participants, dealing with poor quality data and how the AI intervention will be applied to and benefit clinical practice.

Additional items proposed for studies relating to AI intervention clinical protocols within the SPIRIT-AI statement (in addition to the SPIRIT 2013 statement)

## Section: EQUATOR network guidelines › Clinical trials reports

While most AI studies are currently at early-phase validation stages, those evaluating the use of ‘AI-interventions’ in real world setting are fast emerging, and will become of increasing importance, since these are required for real-world clinical benefit demonstration. RCTs are the exemplar study design in providing a robust evidence basis for efficacy and safety of a given intervention, with the CONSORT statement, 2010 version14 providing a 25-item checklist for the minimum reporting content in such studies. An adapted version, entitled the ‘CONSORT-AI’ extension17–19 was published in September 2020 for ‘AI intervention’ studies. This includes an additional 14 items (11 extensions, 3 elaborations) to the existing CONSORT 2010 statement, the majority of which (8 extensions, 1 elaboration) relate to the study participants and details of the ‘AI intervention’ being evaluated, which are similar to those additions already described in the SPIRIT-AI extension. Specific key differences in the new guideline are outlined in table 3. Although not specific for AI interventions, some aspects of the checklist Template for Intervention Description and Replication, 201425 may be a helpful addition when reporting details of the interventional elements of a study (ie, as an extension of item 5 of the CONSORT 2010 statement or as item 11 of the SPIRIT 2013 statement). These include details regarding any modifications of the intervention during a study, including how and why certain aspects were personalised or adapted. There are currently no publicly proposed plans to publish an ‘AI’ extension to this guideline to the best of our knowledge.

Additional criteria to be included for studies relating to AI interventions within the CONSORT-AI statement (in addition to the CONSORT 2010 statement)

## Section: EQUATOR network guidelines › Diagnostic accuracy studies

The STARD statement, 2015 version20 is the most widely accepted reporting standard for diagnostic accuracy studies. A steering group has been established to devise an AI-specific extension to the latest version of the 30-item STARD statement (called the STARD-AI extension.26 At the time of writing this is undergoing an international consensus survey among leaders in the AI field for suggested adaptations and pending publication.

## Section: EQUATOR network guidelines › Prediction models

Extensions to reporting guidelines describing prediction models that use ML have been announced, and are anticipated for publication soon. These include adapted versions of the ‘Transparent Reporting of a multivariable prediction model for Individual Prognosis Or Diagnosis’ (TRIPOD), 2015 version,27 which will be entitled ‘TRIPOD-AI’,28 29 and supported by the ‘Prediction model Risk Of Bias Assessment Tool’ (PROBAST, 2019 version)30 which is proposed to be entitled PROBAST-ML.28 29

## Section: EQUATOR network guidelines › Human factors

Another upcoming guideline, focused on the evaluation of the ‘human factors’ in algorithm implementation, has been announced: the checklist (Developmental and Exploratory Clinical Investigation of Decision-support systems driven by AI).31 This checklist is intended for use in early small-scale clinical trials that evaluate and provide information on how algorithms may be used in practice, bridging the gap between the algorithm development/validation stage (which would follow TRIPOD-AI, STARD-AI or Checklist for Artificial Intelligence in Medical Imaging (CLAIM)), but before large-scale clinical trials of AI interventions (where the CONSORT-AI would be used). Publication is anticipated to be late 2021 or early 2022.

## Section: EQUATOR network guidelines › Systematic reviews

Given the increasing volume of radiological AI-related research for a growing variety of conditions and clinical settings, it is also likely that we will encounter more systematic reviews and meta-analyses that aim to aggregate the evidence from studies in this field (eg, recent publications have already emerged that summarise research regarding the role of AI in COVID-19.32–34 At present, the ‘Preferred Reporting Items for Systematic Reviews and Meta-analyses’ (PRISMA), 200935 guidelines are the most established for systematic reviews and meta-analyses, with a modified version specifically tailored for meta-analyses relating to diagnostic test accuracies (ie, the PRISMA-Diagnostic Trials of Accuracy (DTA), 2018).36 Currently, there have not been any announcements for an update to these guidelines for AI-related systematic reviews or meta-analyses, and therefore, it is suggested that the PRSIMA 200935 or PRISMA-DTA 201836 guidance should be followed.

In the planning stages for conducting systematic reviews of prediction models, the ‘Checklist for critical appraisal and data extraction for systematic reviews of prediction modelling studies’ (CHARMS, 201437 was developed by the Cochrane Prognosis Methods Group. This was not intentionally created for publications relating to AI per se, but applicable to a wide range of studies, which also happen to include the evaluation of ML models. The developers provide the checklist to help authors frame their review question, design and extract relevant items from published reports of prediction models and guide assessment of risk of bias (rather than in the analysis of these). This checklist will, therefore, be useful to those who wish to plan a review of AI tools that provide a ‘risk score’ or ‘probability of diagnosis’. A tutorial on how to carry out a ‘CHARMS analysis’ for prognostic multivariate models with real-life worked examples has been published38 and may be a helpful resource for readers wishing to carry out similar work. It is worth noting that the authors of CHARMS still recommend reference to the PRISMA 200935 and PRISMA-DTA 201836 statements for the reporting and analysis of trial results, in conjunction with their own checklist for planning of the review design.

## Section: Other (NON-EQUATOR network) guidelines

Alternative guidelines have been published by expert interest groups and endorsed by different specialty societies. A few are described here to supplement further reading and interest.

The Radiological Society of North America recently published the ‘CLAIM’39 in 2020, containing elements of the STARD 2015 guideline and applicable for trials addressing a wide spectrum of AI applications using medical images (eg, classification, reconstruction, text analysis, work flow optimisation). This checklist comprises of 42 items, of which 6 are new (pertaining to model design and training), 8 are extensions of pre-existing STARD 2015 items, 14 items are elaborations (mostly relating to methods and results) and 14 items remain the same. Particular emphasis is given to data, the reference standard of ‘ground truth’ and the precise development and methodology of the AI algorithm being tested. These are listed in further detail in table 4, where differences to the STARD 2015 are highlighted. Care should be taken to avoid any confusion with another similarly named checklist entitled ‘minimum information about clinical AI modelling’ (MI-CLAIM),40 which is less of a reporting guideline but a document outlining required shared understanding in the development and evaluation of AI models aimed to serve clinical and data scientists), repository managers and model users.

It is also worth noting that the American Medical Informatics Association produced a set of guidelines in 2020 termed the ‘MI for Medical AI Reporting’ (MINIMAR),41 specific to studies reporting the use of AI solutions in healthcare. Rather than a list of items for manuscript writing, this guidance provides suggestions for details pertaining to data sources used in algorithm development and their intended usage, spread across four key subject areas (ie, study population and setting, patient demographics, model architecture and model evaluation). There are many similarities with the aforementioned CLAIM checklist, although the key differences include the granularity by which the MINIMAR suggests researchers should explicitly state participant demographics (eg, ethnicity and socioeconomic status, rather than just age and sex) and how code and data can be shared with the wider community.

Criteria for the CLAIM checklist for diagnostic accuracy studies using AI

## Section: Further reading

There is an increasing need to build a cadre of researchers and reviewers with sufficient domain knowledge of technical aspects (including limitations and risk) and of the principles of good trial methodology (including areas of potential bias, analysis issues, etc). There is also a need for ML experts and clinical trial communities to increasingly learn each other’s language, to ensure accurate and precise communication of concepts, and enable comparison between studies. A number of reviews are highlighted here for further reading42–46 along with work47 explaining different evaluation metrics used in AI and ML studies. It is also worth bearing in mind the wider clinical and ethical context of how any AI tool would fit into our existing clinical pathways and healthcare systems.48

## Section: Conclusion

In conclusion, this article has provided readers an overview of changes to standard clinical reporting guidelines specific for AI-related studies. The fundamental basics of describing the trial setup, inclusion and exclusion criteria, detailing the study methodology and standards used, together with details on algorithm development, should create transparency and address reproducibility. Those which are most relevant for a particular healthcare specialty will depend on the type of research being conducted in that particular field (eg, guidelines for AI-related diagnostic accuracy trials may be more relevant for radiological or pathological specialties, whereas those addressing patient outcomes with the aid of an AI algorithm may be more relevant for oncological or surgical specialties).

Although the reporting guidelines outlined may seem comprehensive, there remain areas that will need to be addressed, such as for economic health evaluation of AI-tools and algorithms (many are currently developed for ‘pharmacoeconomic evaluations’.49 It is likely that future guidelines may take the form of an extension to the widely used CHEERS guidance (Consolidated Health Economic Evaluation Reporting Standards50 51 available via the EQUATOR network.13 Nevertheless, a wide variation in opinion regarding the most appropriate economic evaluation guideline already exists for non-AI related tools, and this may be reflected in future iterations of such guidelines depending on how the algorithms are funded in different healthcare systems.52

The current guidelines outlined here will likely continue to be updated in the light of new understanding of the specific challenges of AI as an intervention and, how traditional study designs and reports need to be adapted.


---

# Schistosomiasis Drug Discovery in the Era of Automation and Artificial Intelligence

- **Authors:** José T Moreira-Filho, Arthur C Silva, Rafael F Dantas, Barbara F Gomes, Lauro R Souza Neto, Jose Brandao-Neto, Raymond J Owens, Nicholas Furnham, Bruno J Neves, Floriano P Silva-Junior, Carolina H Andrade
- **Issuer:** Frontiers in immunology
- **Type:** Scientific article
- **Published:** 2021-05-31
- **Language:** en
- **DOI:** 10.3389/fimmu.2021.642383
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34135888/
- **Licence:** CC-BY

## Section: Abstract

AbstractSchistosomiasis is a parasitic disease caused by trematode worms of the genus Schistosoma and affects over 200 million people worldwide. The control and treatment of this neglected tropical disease is based on a single drug, praziquantel, which raises concerns about the development of drug resistance. This, and the lack of efficacy of praziquantel against juvenile worms, highlights the urgency for new antischistosomal therapies. In this review we focus on innovative approaches to the identification of antischistosomal drug candidates, including the use of automated assays, fragment-based screening, computer-aided and artificial intelligence-based computational methods. We highlight the current developments that may contribute to optimizing research outputs and lead to more effective drugs for this highly prevalent disease, in a more cost-effective drug discovery endeavor.Keywords: schistosomiasis, drug discovery, artificial intelligence, fragment-based drug discovery, phenotypic screening, target-based screening

## Section: Introduction

Schistosomiasis is a neglected tropical disease (NTD) caused by trematode parasites belonging to the genus Schistosoma. The most clinically-relevant species are S. mansoni, S. japonicum and S. haematobium while S. mekongi, S. guineensis and S. intercalatum have lower prevalence (1, 2). According to the World Health Organization (WHO), approximately 229 million people are infected worldwide, causing around 200,000 deaths annually (2). However, this is probably an underestimation, due to the low sensitivity of the available diagnostic methods to detect low intensity parasite infections (3, 4). It ranks second behind malaria in terms of prevalence and socioeconomic impact, causing the loss of more than 2.6 million disability-adjusted life years (DALYs) (5).

Humans become infected when the cercariae larvae, released by the snail intermediate hosts, penetrate through the skin during contact with contaminated freshwater (1, 6). Then, cercariae access the host circulation and develop into juvenile and adult worms (7). Paired female and male adult schistosomes live in the blood vessels where they produce eggs that are excreted in faeces (S. mansoni, S. japonicum, S. intercalatum, S. guineenses and S. mekongi) or urine (infections by S. haematobium) (6). Eggs become trapped in human tissues causing inflammatory immune reactions (including granulomata) that damage organs resulting in intestinal, hepatosplenic, or urogenital disease (8). The eggs that reach the environment, hatch in the water and release the larval stage miracidia. The Miracidia infect the intermediate hosts and continue the parasite’s life-cycle (9).

Because the development of a schistosomiasis vaccine has proved challenging (10, 11), the treatment and control of schistosomiasis continue to depend, on the almost 50-year-old drug, praziquantel (PZQ) (12, 13). PZQ is generally effective against adult and schistosomula stages of all schistosome species and is well tolerated, causing only mild and transient side effects (14, 15). However, PZQ is ineffective against juvenile schistosomes, which contributes to the failure of the drug to cure the disease and the need for new rounds of treatment (16, 17). Moreover, PZQ is administered as a racemic mixture, wherefore only half of PZQ dose (i.e., R-PZQ stereoisomer) is pharmacologically active. The S-PZQ, besides being pharmacologically inactive, contributes to the bitter taste and the large size of PQZ tablets, both of which decrease patient compliance and are not suitable for children (18, 19). Moreover, PZQ has been used in mass drug administration campaigns for many decades and this may account for a selection pressure that can promote the development of parasitic resistance (20). In fact, reduced PZQ efficacy has been demonstrated both in laboratory and field isolates (21–28). Consequently, there is an urgent need for new antischistosomal drugs.

One of the foremost challenges to the discovery of new anti-schistosomal drugs is the long and complex life cycle of the parasite, which makes screening campaigns technically difficult (29). The phenotypic screening of whole-organisms in vitro and/or in animal models is the approach that is most used for finding hit compounds (i.e., active compounds in vitro based on a defined activity threshold) (30–32), though animal models tend to be costly and time-consuming (33). These assays require the maintenance of the parasites’ life cycle – including both the intermediate (snails) and the definitive hosts (hamsters or mice) – in order to have regular access to parasites. However, these laboratory-based life cycles can only produce a restricted number of adult-stage schistosomes (34). As a consequence, most early compound screening efforts use newly transformed schistosomula (NTS), which are obtained from the mechanically transformed cercariae (35). This can limit the finding of new hits, as the sensitivity to compounds can vary between life cycle stage and gender of the parasite (36, 37).

Screening compounds for anti-schistosomal activity is typically carried out manually where an analyst identifies the 5presence of morphological or behavioral changes in the parasites by microscopy (29). A numerical scale (“severity score”), usually including four (38, 39) or five (29, 40) scores, is used to describe the phenotypes. However, this analysis is subjective, semi-quantitative, time-consuming and the results can vary largely from analyst to analyst (41–43). Nonetheless, severity scoring systems have been successful in identifying hits, defining SAR, and identifying compounds that translate with in vivo efficacy in the mouse model of S. mansoni infection (44).

In this review we focus on innovative approaches to the identification of antischistosomal drug candidates, including the use of automated assays, fragment-based screening, computer-aided and artificial intelligence-based computational methods. We also highlight the current developments that may contribute to optimizing research outputs and lead to more cost-effective drugs for this highly prevalent disease.

## Section: Phenotypic Screening

Phenotypic screening consists of testing substances that could possibly cause phenotypic changes considered relevant to a biological system. Phenotypic-based drug discovery (PDD), compared to target-based drug discovery (TDD), has the advantage of presenting a greater probability of identifying compounds which will be translated to in vivo tests since they better mimic the complex environment of living systems. For example, in a cellular assay, a test compound may have to cross cellular membranes and/or resist degradation by metabolic enzymes before interacting with its target(s). These factors may have a significant impact in a compound’s biological activity and are not taken into account in a target-based assay. Hence, a hit coming from a phenotypic screen has much more biological value than one coming from a target-based screen (45, 46). Nonetheless, an important consideration must be given to the higher cases of false negatives in PDD campaigns when compared to TDD. As discussed by Geary and colleagues (33), the false negatives result from the inability of some compounds to reach a proper concentration inside a whole organism, which may hinder the detection of potential schistosomicidal molecules.

PDD approach tends to be more time-consuming and costly to develop and run than TDD (47). This is mainly due to the implementation of higher complexity screening assays, and to other factors such as the parallel use of genetic and small molecules screens, as well as more complicated hit validation and target identification efforts (48). Furthermore, the establishment of structure-activity relationship (SAR) is more challenging due to other concurrent factors, such as membrane permeability and off-target binding, though there are several examples of successful SAR studies using schistosome phenotypic assays in the literature (49–51). Hence, PDD approach is limited in this sense due to unknown mechanism of action, potentially targeting different types of proteins, such as receptors, enzymes, transcription factors and even different signaling pathways (45). Additional assays may be necessary to support the SAR in PDD approaches. On the other hand, the multiplicity of potential targets in PDD can be a source of serendipity (33, 46). In contrast, the prior knowledge of the target in TDD helps to accelerate the interpretation of SAR data. In spite of their differences, it is increasingly known that PDD and TDD must be seen as complementary in the R&D of new drugs (48, 52, 53).

In the following topics we will address some of the main phenotypic assays that have been used for schistosomiasis drug discovery. They consist in labelled (employing fluorescent or luminescent dyes) and label-free assays that are able to detect drug-induced phenotypes in different stages of the parasite, such as schistosomula (NTS), juvenile (1-5 weeks post infection) and adult (6-7 weeks or over post infection) (38).

Summary of some luminescence and fluorescence schistosomal drug assay methodologies.

Label-free image-based and non-image-based automated methods used in schistosomiasis drug discovery. (A) Overall description of label-free methods, (B) image-based methods, (C) non-image-based methods.

Label-free automated assays used in schistosomiasis drug discovery.

## Section: Phenotypic Screening › Luminescence- and Fluorescence-Based Phenotypic Assays

Some methodologies used in schistosome phenotypic screening are based on fluorescent or luminescent dyes commonly employed in cellular viability/cytotoxicity assays ( Table 1 ). Propidium iodide (PI), a DNA intercalator, for instance, is a fluorescent dye that is not able to cross membrane cells and can only stain nucleic acids of cells that have lost their membrane integrity. For this reason, such fluorophore is used to differentiate living and dead cells. Unlike PI, fluorescein diacetate (FDA) can cross biological membranes, and is converted by healthy cells into fluorescein, another fluorescent dye. Peak et al. (54) developed a microplate-based assay to measure schistosomula viability using PI/FDA. In this method, the fluorescence emitted by FDA and PI stained parasites is quantified by a microplate reader and later converted into worm viability using the fluorescence ratio FDA/(PI + FDA). This assay was able to detect the effect of some known schistosomicidal drugs, namely auranofin, gambogic acid and amphotericin b, but failed in measuring the effect of praziquantel and other compounds previously identified as actives by microscopy (55). Braun et al. (56) also used PI and FDA probes in the development of a quantitative HTS (qHTS) fluorescent-based bioassay to identify schistosomula in water samples (56). The results obtained with this method showed no statistically significant differences when compared to visual inspections carried out by manual microscopy.

Mansour et al. (42) used a commercial solution of resazurin (Alamar Blue®), a redox-sensitive probe, to measure the viability of schistosomula in microplates. This assay is based on the principle that only metabolic active worms can reduce resazurin to resorufin, a fluorescent molecule. During validation, this assay proved to be useful in evaluating the effect of compounds that kill or provoke severe damage to the parasite (e.g., oltipraz), but showed less sensitivity towards those that elicited more subtle effects (e.g., praziquantel) detectable by conventional microscopy.

Lalli et al. (38) developed and validated a luminescence-based method for the evaluation of schistosomula viability by quantifying ATP (38). This assay is carried out using a commercial kit (CellTiter-Glo®) which contains luciferase and its substrate luciferin as the main components. In principle, metabolic active worms produce ATP which participates in the reaction catalysed by luciferase. As a result, a luminescence signal is produced and registered in a microplate reader. This medium-throughput method is suitable for semi-automated screening of chemical libraries and has several benefits such as speed in screening, reproducibility and non-subjectivity. Guidi et al. (57) used the same luminescence-based technique, combined with HTS, to search for molecules with schistosomicidal activity. As a result, a few compounds capable of impairing the viability of the larval, juvenile, and adult phases were identified, with potency against juveniles higher than PZQ. In addition, changes in egg formation and production are among the phenotypic modifications.

However, despite its success in generating dose-response curves for some known schistomicidal drugs (e.g., gambogic acid and oltipraz) this method was unable to detect the effect of praziquantel and oxamniquine on schistosomula viability. Maccesi et al. (44) also could not detect the biological effect of some schistomicidal compounds using another phenotypic assay. In their work, S. mansoni schistosomula were screened with the 400 compounds of the MMV Pathogen Box in three different institutions. Two of them employed visual scoring (microscopy) to describe drug-induced phenotypes while the other used a colorimetric assay based on the metabolic reduction of XTT to measure parasites viability. In nearly 74% of the cases, all three methods agreed on the classification of the compounds (active/inactive) after 72h of incubation. Nonetheless, unlike the visual methods, the XTT-based assay did not identify PZQ and other compounds (e.g., auranofin, nitazoxanide) as actives against schistosomula. This may be due to the fact that metabolic-based assays were originally designed to be used in cell and unicellular organisms. Its use in multicellular and more complex models are prone to missing important phenotypes (44) found in these organisms, like the dysregulation of the neuromuscular system, a mechanism attributed to PZQ (58).

Panic et al. (39) performed a review of fluorescent and luminescent markers used on S. mansoni drug assays and confirmed Lalli et al. (38) studies of development and validation of a luminescence-based assay (CellTiter-Glo®). In contrast to resazurin assays, which are also used to determine the viability of Schistosoma parasites, CellTiter-Glo® was able to determine the IC50 of mefloquine and to detect the schistomicidal activity of some FDA-approved compounds, showing results that correlate with microscopic findings.

The assays described in this topic represent a major advance in schistosomiasis drug discovery. Nonetheless, they show some limitations that must be taken into consideration. Compared to colorimetric methods, such as XTT-based assay, fluorescence/luminescence-based assays require black/white microplates which are more expensive (59). In some cases, a given method may not detect the schistomicidal effect of a compound recognized as active by other techniques, including conventional microscopy (39). Moreover, some test compounds may interfere with the assay (e.g., compounds auto-fluorescence), leading to a misinterpretation of the results (38). Therefore, it is advisable to be cautious when considering the results obtained from a single method, being recommended to corroborate the results using at least one orthogonal assay.

Summary of some luminescence and fluorescence schistosomal drug assay methodologies.

## Section: Phenotypic Screening › Label-Free Automated Phenotypic Assays for Schistosomiasis Drug Discovery

Label-free automated assays detect phenotypic alterations in schistosomes in the absence of any kind of label (e.g., fluorescent probe). In general, they can be divided into two main groups: image-based (most common) (60–63) and non-image-based methods (64, 65) ( Figure 1A ). The former use visual information, such as morphology and/or motility of the parasite, to describe a phenotype ( Figures 1A, B ). In contrast, non-image-based methods, herein exemplified by electrical impedance spectroscopy (65) and microcalorimetry (64), create phenotypic profiles based on worm’s metabolic activity and/or its motility ( Figures 1A, C ). Image-based and non-image-based assays have been largely employed in drug discovery campaigns to identify new schistosomicidal compounds and calculate their potencies. Some of these methods and their main characteristics (e.g., type of readout, assay format and the number of parasites required per assay) are shown in Table 2 and will be discussed in more detail in the following section.

Label-free image-based and non-image-based automated methods used in schistosomiasis drug discovery. (A) Overall description of label-free methods, (B) image-based methods, (C) non-image-based methods.

Label-free automated assays used in schistosomiasis drug discovery.

## Section: Phenotypic Screening › Label-Free Automated Phenotypic Assays for Schistosomiasis Drug Discovery › Image-Based Methods

The automatic quantification of phenotypic features from schistosomes images has been addressed in several ways (60–63, 66, 69, 70, 72). Most assays rely on home-made (60) or commercial (63, 70) systems, equipped with digital cameras/camcorders to acquire images of unstained parasites in microplates. Image analysis is carried out, using either commercial (62, 69, 70) or custom-built (60, 68) software and generally consists of three main steps: image processing, parasite(s) detection and features extraction ( Figure 1B ). By the end of the analysis, a phenotypic profile, composed of a variable number of features, is created for one (63, 69, 70) or more (60) worms. These profiles can be used to identify schistosomicidal compounds, measure their effect and potency, as well compare their responses to those elicited by other compounds (60, 63, 69, 70).

One common strategy to acquire schistosome images is by video microscopy. Ribeiro and colleagues implemented two assays using this technique to measure the motility of NTS (62) and adult (66) forms of S. mansoni. In these assays, parasites are distributed in microplates and their videos recorded over a few minutes. Image frames are analyzed in ImageJ (73), an open-source software. For NTS analysis, worms are detected as ellipsoid objects and their body length are estimated by the size of the major axis of the ellipses. NTS movements (shortening and elongation of the body) are calculated by the frequency of length changes over time (62). For adult analysis, each image frame is submitted to a series of pre-processing steps (e.g., illumination correction and background removal) before representing the worms as binary objects. Then, the difference in pixels between pairs of consecutive images are measured throughout the entire video. The subtracted pixels represent a change in parasite position over time and are used as a metric to measure worm´ motility (66). These methods were employed to evaluate the effect of different compounds on schistosome NTS/adults worms, such as tyrosine-derived signaling agonists/antagonists (74), natural alkaloids (75–77) and analogs (77, 78), as well as others with biological activity in humans (e.g., NPS-2143, a calcium-sensing receptor antagonist) (77).

McCusker and colleagues (67, 72) also applied video microscopy to record morphological and motility aspects of adult schistosomes. In their assay, 1 min videos of adult worms, distributed in 6-well dishes, are acquired, and saved as images Z-stacks. During image analysis in ImageJ, maximum intensity projections are generated to each Z-stack resulting in a composite image for which pixel integrated pixel values are measured. This metric represents the total movement of the parasite over time and can be used to compare treated and non-treated parasites. This method detected the schistosomicidal effect of non-sedating benzodiazepines (72) and FPL-64176 (67), a human L-type Ca2+ channel agonist.

WormAssay is a home-made low-cost solution to screen compounds against adult schistosomes (and other macroscopic parasites) developed by Marcellino et al. (60). This system consists of two devices: an imaging apparatus and a Mac computer (image acquisition control and analysis). The former can be described as a light-tight box containing a high-definition video (HDV) camcorder mounted at the bottom and a hinge lid at the top harboring the microplate chamber. Inside the chamber a white LED strip is used to laterally illuminate the microplate. During acquisition, dark-field videos of 0.5 – 1 min length are recorded from the entire microplate. Image analysis is performed in real-time using a custom open-source free software (Mac application) installed in the computer. The overall motility of worms, measured for each well, is determined by two algorithms: one that calculates the average velocity of moving contours inside the well and another which detects changes in the occupation and vacancy of pixels between a group of frames. WormAssay quantified the effect of several compounds on worm motility, including neuromodulatory drugs (79), phenylpyrimidines (80) and inhibitors of S. mansoni cyclic nucleotide phosphodiesterase 4 (SmPDE4) (81) and proteasome (82). Recently, a modified version of WormAssay software, named WormAssayGP2, was released by Padalino and colleagues (83, 84) and contains minor modifications related to the source code and user interface (85). To date, WormAssayGP2 has been used to detect the schistomicidal activity of putative inhibitors of S. mansoni lysine specific demethylase 1 (SmLSD1) (86) and histone methyltransferase mixed lineage leukemia-1 (SmMLL-1) (84), as well as human ubiquitin-proteasome system (85) inhibitors.

One of the first attempts to describe complex phenotypes is schistosomes was carried out by Singh et al. (87). They developed an automated method to detect, track and classify individual NTS in microscopy videos. Since then, several modifications have been made regarding worms segmentation (88) and phenotypic analysis (63, 68, 89, 90). The algorithms developed in these studies have proved to be useful in quantifying the schistosomicidal activity of PZQ (63), chlorpromazine (63), statins (91) and inhibitors of human polo-like kinase 1 (PLK1) (89, 92). They have also been implemented in the “quantal dose-response calculator” (QDREC), a web server that automatically extracts quantal time- and dose-response information from bright-field images of schistosomes NTS (or other parasites) (68). QDREC quantifies 71 image-based features related to the appearance, shape and texture, of each segmented parasite. These features serve as inputs for supervised machine learning algorithms which classify parasites as “normal” or “degenerate”. The proportion of “degenerate” worms in a well is employed as a metric to estimate the schistosomicidal effect of a given compound and can be used to create dose-response curves. QDREC was validated with 12 schistosomicidal compounds (e.g., statins, PZQ, closantel, niclosamide and sorafenib) showing comparable results with visual annotation for both parasite classification and dose-response curves.

Paveley et al. (70) was a pioneer in implementing automated microscopy, also known as high content screening (HCS), to extract multivariate data from schistosomes. They created an HCS-based automated platform to identify active compounds on NTS of S. mansoni. In this assay, a HCS system collects bright-field images of each well of a 384-wells microplate through two distinct modes: a time-lapse image acquisition (5x6 s interval) using a 4x objective, for motility analysis, and one acquisition of four adjacent images using a 10x objective, for morphology measurements. Image analysis is performed in Pipeline Pilot 8.5 software (Accelrys Inc., San Diego, USA) and includes a series of sequential image operations, such as thresholding, filtering, detecting boundaries prior worm´s segmentation. Morphological (e.g., area, texture, pixel intensity) and motility-related features are quantified for each NTS and summarized into a phenotype (processed through Bayesian models) and a motility score, respectively. The final scores are obtained by averaging the scores of all parasites inside each well. Test compounds are declared “hits” (i.e., actives) if phenotype and motility scores exceed a defined threshold for each metric. This assay was able to detect the anti-worm effect of known schistosomicidal drugs (oltipraz and dihydroartemisinin) (70), several drug candidates from small (93, 94) and large (70, 95) chemical libraries, as well FDA-approved drugs (e.g., kinase inhibitors) (96). This analysis has also been employed by Hoffmann and colleagues (84, 86, 97–100) who measured the schistosomicidal activity of plant-derived compounds [e.g., diterpenoids (97, 99) and triterpenoids (100)] and of potential inhibitors of S. mansoni histone-modifying enzymes (40, 84, 86, 98).

Recently, Chen et al. (61) developed another HCS-based high-throughput assay to extract phenotypic features from treated and non-treated NTS. It consists of a fully integrated platform that can perform multiple automated operations ranging from liquid handling of NTS suspensions to image acquisition/analysis. The latter tasks are carried out as follows: time-lapse bright-field images (30 x 0.66 s interval) are acquired from each well of a U-bottom 96-wells microplate using a 10x objective in a HCS system. During image analysis, each NTS is segmented and classified as “clear” (normal) or “degenerate” (damaged/dying) using 15 phenotypic features based on the appearance of worms (e.g., pixel intensity, area, length). Motility measurements are inferred from the magnitude of a change in a feature over time or how often its sign or direction changes (e.g., when the worm becomes longer than shorter). Two statistical methods are employed to measure significant changes in phenotypes: glass effect size (monoparametric) and Mahalanobis distance (multiparametric). The results are analyzed in “SchistoView”, a graphic interface supported by MySQL database, which allows users to visualize, query and explore NTS data. This method shows several improvements in comparison to the HCS-based assay developed by Paveley et al. (70), including a higher NTS segmentation accuracy, it requires less parasites per assay and quantifies how parasites move instead of simply determine if the movement has occurred or not. In part, these improvements were achieved due to an innovative solution that allows the segmentation of touching objects in bright-field images, a challenging task for image analysis in general. In fact, many techniques implemented in this platform, such as automated liquid handling of 100 µm-sized organisms and statistical analysis of multiparametric data, can be useful to other screening projects. The HCS approach by Chen et al. (61) was successfully used to create the phenotypic profile of known schistosomicidal agents, as well of 1,323 human approved compounds, identifying new potential drug candidates.

HCS has also been applied to screen compounds against adult forms (male and females) of schistosomes. Neves et al. (69) described a HCS-based method to extract morphological and motility measurements from time-lapse bright-field images of S. mansoni. In this assay, schistosomes were distributed in 96-well microplates (1 worm per well) and their images acquired over time (100 x 0.3 s interval) using a 2x objective. Image analysis was carried out in a customized pipeline of the open-source software Cellprofiler (101) comprising a series of image processing modules, including those responsible for detection of wells, illumination correction, parasites segmentation and features extraction. More than 90 features were quantified during this analysis though only two, related to worm motility, were used to describe drug-induced phenotypes. So far, this method has been applied to detect the schistomicidal effect of antidepressant paroxetine (69) as well as putative inhibitors of S. mansoni thioredoxin glutathione reductase (SmTGR) (93, 94).

## Section: Phenotypic Screening › Label-Free Automated Phenotypic Assays for Schistosomiasis Drug Discovery › Non-Image-Based Methods

Electrical impedance spectroscopy (EIS) is noninvasive and label-free method that has been explored in schistosomiasis drug discovery (65, 71, 102, 103) ( Figure 1C ). In summary, ESI systems quantify dielectrical properties of samples while applying an alternative current (AC) electrical field using electrodes. EIS measurements can be used to detect phenotypic changes in cells/organisms induced by perturbagens, such as small molecules (104). Smout et al. (102) employed the xCELLigence real time cell analysis (RTCA) system to measure the effect of chemical compounds on the motility of helminths, including adult schistosomes. The experiments are carried out in E-plates, commercial microplates with gold electrodes embedded in the base of the wells that allow monitoring electrical resistance. Later, an improved version of this assay (xCELLigence worm real-time motility assay - xWORM) expanded its applications to detect alterations in the motility of schistosomes cercariae and egg hatching (71). xWORM is a sensitive method and was able to reveal the schistosomicidal effect of natural-derived [phytochemicals (105, 106) and puromycin (107)] and synthetic [forchlorfenuron (108) and polyridylruthenium(II) complexes (109)] compounds. Nonetheless, it is not sensitive enough to detect NTS small movements and requires a relativity larger number of samples compared to conventional microscopy (103). These limitations were addressed by Modena et al. (110) who developed a microfluid impedance-based platform to measure changes in NTS motility. Their system consisted of a microfluidic chip, made of polydimethylsiloxane (PDMS), attached to a glass substrate with patterned electrodes. This method showed high sensitivity towards both viable and non-viable parasites and required a lower number of worms per assay to operate in comparison to microscopy. Later, this concept evolved into a parallelized platform which was able to run four experiments simultaneously (103). More recently (65), the system was reformulated, becoming more automated, performing at a higher throughput (32 experiments run in parallel) and allowing long-term culturing of NTS. This assay was successful in determining the EC50 of mefloquine and oxethazaine which were of the same order of magnitude as those calculated by microscopy (65).

## Section: Phenotypic Screening › Label-Free Automated Phenotypic Assays for Schistosomiasis Drug Discovery › Non-Image-Based Methods

Isothermal microcalorimetry (IMC) is a very sensitive technique that measures the heat released or consumed by physical or chemical events under essentially isothermal conditions (111, 112). IMC has been used in different areas of biomedicine, such as in the detection of infection and tumors, antibiotic testing, parasitology and screening for new drugs (111, 113). Manneck et al. (64) developed an IMC-based assay to study the effect of chemical compounds on NTS and adult worms of S. mansoni. In this method, the overall heat production of a suspension of parasites is continuously recorded by the microcalorimeter. After the injection of a schistosomicidal compound it is expected that the heat-flow curves change their behavior indicating compounds effect on worm metabolism and/or motility ( Figure 1C ). This assay proved to be highly sensitive, capturing subtle effects that were not detected by conventional microscopy and was used to measure the schistosomicidal activity of known anti-schistosome agents (mefloquine, praziquantel) (64, 114), their isomers/racemates (115, 116), as well as mefloquine-related arylmethanols (117) and 3-alkoxy-1,2-dioxolanes (118)

## Section: Phenotypic Screening › Label-Free Automated Phenotypic Assays for Schistosomiasis Drug Discovery › Label-Free Methods: Concluding Remarks

In the previous topics we described the main label-free methods available today for schistosomiasis drug discovery. They represent more automated alternatives for conventional microscopy, overcoming some of its major limitations (e.g., visual phenotypic scoring). These methods vary according to several features, such as equipment/readout (e.g., microscope/image), assay cost (equipment and supplies), automation and screening throughput. They all have their pros and cons and the choice of one over another depends, in many cases, on equipment availability. In low-budget labs, video microscopy and WormAssay represent more affordable solutions for compound screening against schistosomula and/or adult schistosomes, since they require low-cost equipment, and the assays are carried out in regular microplates. On the other hand, HCS-based assays demand a high initial investment but use regular microplates as supplies, operate at a higher throughput and can be readily incorporated into automated platforms. Moreover, HCS systems can be easily coupled with a wide range of objective lens, allowing them to capture images of schistosomula, adults and potentially other parasites forms (e.g., eggs and juveniles). In contrast to image-based, non-image-based methods are less employed in screening campaigns. Overall, they demand expensive (microcalorimeter and RTCA systems) or customized (EIM platform) equipment, more costly supplies (e.g., E-plates), operate at a lower-throughput in comparison with automated microscopy and, in the case of xWORM, it is not able to detect phenotypic changes in schistosomula. Nonetheless, they are highly sensitive, may reveal drug-induced phenotypes which cannot be captured by image-based methods (e.g., metabolic activity), and xWORM already offers protocols for measuring the effect of compounds on schistosome eggs and cercariae. In conclusion, it is our understanding that HCS-based assays represent today the most advanced approaches to schistosomes phenotypic screening due to their ability to describe complex phenotypes of different forms of the parasite at a high throughput.

## Section: Target-Based Screening

Target-based drug discovery (TDD) consists of finding ligands for a known biological target, previously identified as having potential relevance in a disease. One of its main advantages is the possibility of knowing characteristics of the target binding site, which allows the optimization of ligands and the development of an efficient structure-activity relationship. Its emergence was made possible by advances in molecular biology and genetics, which allowed the identification of individual biological targets, as well as the possibility of developing compounds that interact with these targets. The genome project, the development of techniques such as RNA interference and gene knockout, advances in structural biology and the development of computational tools were of great importance for the emergence of this alternative to the phenotypic approach in drug discovery (47, 119–121).

Ligand-binding assays are at the core of TDD strategies. In the context of pharmacological screening, the classical assay provides, for example, affinity, potency, and maximum response data of the analyzed molecules. It is also possible to determine the intrinsic activity of ligands (122, 123), through functional binding assays, in addition to assessing the residence time of the ligand to its target molecule (124). In contrast to the classical binding assays, HTS is a strategy that allows for the testing of tens of thousands of compounds per day, for activity against biological targets. Considered one of the most used strategies in TDD, HTS can be performed using different approaches, that can be mainly divided into biochemical assays and cell-based assays (125–127).

Although in-solution assays are commonly used for in vitro screenings, immobilized enzyme reactors (IMER) systems have proved to be a valid alternative drug screening strategy. The immobilization of a target protein to a solid support has the advantage of longer maintenance of the stability of the molecule, and the possibility of extracting the protein from the reaction medium, allowing it to be reused. In addition, IMER can be coupled to different separation systems, such as high performance liquid chromatography (HPLC), which solve the possible problem of product and assayed compounds fluorescing at the same wavelength, since these analytes can be separated and analyzed individually (128). Active anti-cancer compounds (129), enzyme inhibitors (130–133) and G protein-coupled receptors (GPCR) (134) binders have recently been identified using this approach.

After the sequencing and decoding of the S. mansoni genome, several putative drug targets were identified ( Table 3 ), and studies using a the target-based approach emerged (157).

S. mansoni encodes 252 kinases, which have already been shown to have a relevant role in the biology of the parasite (158). S. mansoni polo-like kinase (SmPLK1) is mainly expressed in reproductive organs of the adult parasite, which suggests a contribution of this enzyme to cell division. The screening of a series of analogues compounds, derived from a human PLK1 inhibitor bioactive against S. mansoni parasites, yielded the identification of potent compounds against schistosomula and adults (92). Buskes et al. (49) reported the optimization of a compound, analogous to the tyrosine kinase inhibitor lapatinib which had initially been identified as a potent antitrypanosomal. From this optimization, analogues were selected for a repurposing approach, and screened against S. mansoni parasites. As a result, several potent compounds against the adult form of the parasite were identified and considered promising leads for further assessment as antischistosomal compounds. The main drawback to exploit kinases as drug targets is the difficulty to achieve selectivity among the vastness of homologues present both in schistosomes and humans. One promising route to achieve this selectivity is exploring allosteric binding sites as alternatives to the more conserved active sites.

Targeting histone-modifying enzymes (HMEs) has been a widely explored strategy for the discovery of new drugs to treat parasitic diseases. In S. mansoni, two classes of histone deacetylases (HDAC and sirtuins) have been identified and are considered potential drug targets for the treatment of schistosomiasis (159). Kalinin et al. (135) designed and synthesized a series of compounds, derived from weak human HDAC8 (hsHDAC8) inhibitors, which varied in the size and flexibility of their side chains. These molecules were screened on S. mansoni HDAC8 (SmHDAC8) to assess their ability to inhibit enzyme activity, and a potent and selective SmHDAC8 inhibitor was identified. Crystallographic and docking studies with SmHDAC8 and the compound revealed key interactions between them, which are not observed with the human orthologue hsHDAC8. Another study identified the first S. mansoni sirtuin 2 (SmSirt2) inhibitors with activity in the low micromolar range, potency against larval schistosome and adult worms, and no toxicity to human cells. These inhibitors were previously identified by an in vitro screening of a compound library, comprising potent and specific growth inhibitors of other parasites, such as Leishmania donovani and Trypanosoma cruzi (136).

Another drug target for schistosomiasis is thioredoxin glutathione reductase (TGR), an enzyme responsible for maintaining the redox homeostasis. A high-throughput screening against a compound library comprising 59,360 synthetic compounds was carried out, of which 74 inhibited SmTGR activity by more than 90% at 10 µM. Some of these had potent schistosomicidal activity against the larvae and adult worms (137). After the flood of date coming from the large q-HTS campaign, there was a feeling of certain disappointment since no major pre-clinical or clinical candidate arose from all this effort. However, the work with SmTGR as a drug target is slowly picking up pace again. A recent work selected the most active chemotypes from HTS plus analogues and re-tested against the enzyme. Ninety-seven had SmTGR inhibitory activity confirmed, and five of them killed S. japonicum, S. haematobium and S. mansoni (with LD50 ≤ 10 µM) adult worms, and all other development stages of S. mansoni (138). SmTGR has also been recently explored under the fragment-based drug discovery paradigm, as it will be discussed further ahead in this review.

3-oxoacyl-ACP reductase (OAR) is an enzyme involved in lipid biosynthesis that is absent in mammals. The cloning, expression, and purification of Schistosoma japonicum OAR (SjOAR) was performed by Liu et al. (139), as well as the elaboration of a homology model of the three-dimensional structure of this protein. A library consisting of more than 14,000 small molecules was chosen for an in silico screening against the model of SjOAR, and 30 initial hits were identified. Of these hits, two were shown to have schistosomicidal activity on both juvenile and adult forms, relatively low cytotoxicity, and could significantly inhibit the activity of the purified recombinant enzyme, confirming that SjOAR is the primary target of these compounds.

From a library focused on exploring phosphodiesterases (PDEs) as potential drug targets for several parasites, 265 compounds were obtained and had their antischistosomal activity evaluated (160). In vivo screening revealed that 171 of the compounds had activity against adult parasites. All these hits showed some level of activity in a mouse model, and two of them, when combined with PZQ, managed to a near complete eradication of viable eggs. Despite being structurally related to PDE10 inhibitors, further studies are needed to validate SmPDEs as the targets of these compounds (140). Another important work was carried out by Long and colleagues (81), which undertook considerable efforts to validate S. mansoni PDE4A as a target for a series of benzoxaboroles. From a library of 1085 benzoxaboroles, the authors identified some compounds which induced hypermotility and degeneration of S. mansoni worms. Employing phenotypic assays with transgenic C. elegans, chemical and functional characterization, it was possible to observe a positive correlation between the hypermotile phenotype of the parasite and the inhibition of SmPDE4A, suggesting that this enzyme is a target for the tested bezaxoboroles. In another recent study, inhibitors of SmPDE4A were discovered, using a virtual screening approach. Homology models of the enzyme structure were generated and used to screen a chemical library. 25 hits were selected and tested as inhibitors of the recombinant SmPDE4A, and five of them were able to inhibit its activity (141).

Schistosome aspartic proteases, as well as cysteine proteases, play a major role in life cycle of Schistosoma parasites by breaking down host hemoglobin an essential source of amino acids from the parasite. Studies have shown that reductions in transcript levels of SmCD1, an enzyme of S. mansoni similar to cathepsin D, lead to phenotypic changes in the parasite, such as growth retardation (161). Thus, SmCD1, as well as the orthologue from S. japonicumi (SjCD1), are considered validated targets in antischistosomal drug discovery. A homology modelling study and SAR analysis with peptidomimetic compounds designed against SjCD1 revealed unique structural features for achieving selectivity to this enzyme (144). Recombinant SmCD1 was recently expressed in HEK293 cells, characterized biophysically and biochemically (153). This is an important step towards further exploring this enzyme in TDD, since they can be considered promising druggable targets as demonstrated in the past with the development of HIV-1 protease inhibitors.

With over 10 years of publications, cysteine proteases are some of the oldest targets against schistosomiasis and S. mansoni cysteine protease cathepsin B1 (SmCB1) is one example. The SmCB1 has stood out as an important target for drug development. Some studies have described structural and functional characteristics (152, 162) of how SmCB1 is inhibited. Some of these applied scoring methods based on quantum mechanics (QM) to describe important interactions between vinyl sulfone chemotype inhibitors and SmCB1 (163). Furthermore, these inhibitors were important to map druggable hot spots in SmCB1 (150). The vinyl sulfones inhibitors also showed desirable properties such as activity in phenotypic assays, selectivity for SmCB1 over human cathepsin B and metabolic stability. Besides this new SmCB1 inhibitor class, in a recent publication Jiková et al. (149) showed that azanitriles chemotypes can act as potent covalent inhibitors of SmCB1. Using recombinantly expressed SmCB1, crystal structure determination, QM methods, phenotypic and target-based assays, these authors were able to identify azanitriles with nanomolar range potency. These studies trace an important path to the identification of new molecules with therapeutic potential to treat schistosomiasis, whilst reinforcing the importance of SmCB1 as a valuable S. mansoni drug target.

In addition to enzymes, receptors (164–166) and transporters (62, 166) are also targeted in schistosomiasis drug discovery. Serotonin (5-HT) GPCRs have already been identified in S. mansoni and related to worm movement regulation (66). Marchant et al. (78) characterized the pharmacological profile of the schistosome receptor Sm.5HTR, a GPCR involved in worm movement, and a screening of 143 previously studied compounds was performed, leading to the identification of scaffolds that regulate the activity of this receptor Similarly, a commercial GPCR compound library has been screened against Sm.5HTR, and 23 compounds identified as potential antagonists, with the majority showing selective inhibition of the parasite serotonin receptor (167).

In 2019, a paper published by Park et al. (58) presented important insights regarding the role of praziquantel on schistosome worms. This work showed that PZQ activates a S. mansoni transient receptor potential channel (SmTRPM) showing properties consistent with the observed responses on worms, like nanomolar sensitivity to PZQ, stereoselectivity and sustained Ca2+ entry response. The authors were able to identify nanomolar sensitive of SmTRPM to (R)-PZQ isomer (eutomer), which is approximately 50 times more sensitive to (S)-PZQ. Further screening campaigns will be necessary to assess the therapeutic potential of this target. Nevertheless, these findings elevate the SmTRPM as a promising clinical target to treat schistosomiasis.

Some classes of molecular targets in Schistosoma sp.

A schematic illustration of fragment optimization strategies. (A) Fragment growing: initial fragment with low affinity is optimized by stepwise addition of functional groups to obtain a larger compound with high affinity. 3D and 2D schemes represents the growing evolution of navoximod, an indoleamine 2,3-deoxygenase 1 (IDO1) inhibitor with antineoplastic properties (solid tumors) (215); (B) Fragment merging: two or more fragments sharing the same pocket are covalently merged to obtain a larger compound with higher affinity. 3D and 2D schemes represent an example of fragment merging to the discovery of inhibitors of the Mycobacterium tuberculosis cytochrome P450 CYP121 (216). (C) Fragment linking: two or more fragments bound independently in proximity are covalently linked with suitable linkers to obtain a larger compound with higher affinity. 3D and 2D schemes represent an example of fragment linking to the discovery of inhibitors of M. tuberculosis pantothenate synthetase (217).

Doorstop pocket of SmTGR adjacent to the NADPH binding site. The Tyr296 of the doorstop pocket is represented in (A) closed and (B) open conformation, as well as in the presence of (C) NADPH and (D) two fragments (1,8-naphthyridine-2-carboxylate and 1-(2-hydroxyethyl)piperazine).

## Section: Target-Based Screening › Fragment-Based Drug Discovery (FBDD)

In the last decades, fragment-based drug discovery (FBDD) has been established as an efficient approach for the identification of new biologically active compounds (168–172). To date, four marketed drugs have been discovered by FBDD (173), including vemurafenib (174), venetoclax (175), erdafitinib (160), and pexidartinib (176), while over 40 fragment-based drug candidates are in different stages of clinical trials (177). In FBDD campaigns, small and less complex compounds, commonly with molecular weight (MW) <300 Da and <20 heavy atoms, are screened against therapeutic targets (178, 179). The use of very small molecules offers advantages over screening larger compounds, including a more efficient sampling of chemical space with fewer compounds (180), higher hit rates (181), and also better physicochemical properties (182, 183). Besides, lower investments are needed, and FBDD projects progress relatively faster between the research and development (R&D) phases (184). As an example, vemurafenib took only six years from hit identification to the approval by the US Food and Drug Association (FDA) in 2011 (171, 174). Therefore, incorporating FBBD into anti-schistosome drug discovery may help to accelerate the identification and development of drug candidates for schistosomiasis and other NTDs (185, 186). FBDD involves steps of library design, screening, and optimization and these steps are discussed in the subsequent sections.

A schematic illustration of fragment optimization strategies. (A) Fragment growing: initial fragment with low affinity is optimized by stepwise addition of functional groups to obtain a larger compound with high affinity. 3D and 2D schemes represents the growing evolution of navoximod, an indoleamine 2,3-deoxygenase 1 (IDO1) inhibitor with antineoplastic properties (solid tumors) (215); (B) Fragment merging: two or more fragments sharing the same pocket are covalently merged to obtain a larger compound with higher affinity. 3D and 2D schemes represent an example of fragment merging to the discovery of inhibitors of the Mycobacterium tuberculosis cytochrome P450 CYP121 (216). (C) Fragment linking: two or more fragments bound independently in proximity are covalently linked with suitable linkers to obtain a larger compound with higher affinity. 3D and 2D schemes represent an example of fragment linking to the discovery of inhibitors of M. tuberculosis pantothenate synthetase (217).

Doorstop pocket of SmTGR adjacent to the NADPH binding site. The Tyr296 of the doorstop pocket is represented in (A) closed and (B) open conformation, as well as in the presence of (C) NADPH and (D) two fragments (1,8-naphthyridine-2-carboxylate and 1-(2-hydroxyethyl)piperazine).

## Section: Target-Based Screening › Fragment-Based Drug Discovery (FBDD) › Fragment Library Design

Most early fragment libraries were designed based on the Rule of Three (RO3), i.e. MW ≤300 Da, the number of hydrogen bond donors ≤3, the number of hydrogen bond acceptors is ≤3 and cLogP is ≤3 (178). However, this paradigm has been changing based on incremental experience in FBDD acquired in the last years and considering the facilitation of fragment screening and/or subsequent fragment optimization chemistry (187, 188). Nowadays, several strategies exist, which cover the use of labeled fragments for nuclear magnetic resonance (NMR) spectroscopy, covalent linkage for mass spectrometry, dynamic combinatorial chemistry, X‐ray crystallographic screening of specialized fragments and fragments optimized for easy elaboration (189).

The last two strategies are blended and available to the community through the XChem fragment screening facility at Diamond Light Source in the UK (190). For this facility, a library of chemical compounds poised for expansion called DSPL (191) was designed to allow rapid and low cost follow-up synthesis and to provide quick SAR data through X-ray crystallography. Poised fragments contain at least one functional group which can be synthesized using a robust, well-characterized reaction. Reactions include amide couplings, Suzuki-type aryl-aryl couplings and reductive aminations, amongst others. The library was designed by analyzing all commercially available fragment space (using the ZINC reference library), yielding nearly 30,000 compounds of which a chemically diverse subset of 800 compounds was selected for the poised library. In practice, the available chemical material shows bias towards the most commonly used chemical reactions (192), however, it still the case that the XChem program delivers between 2% and 10% fragment hit rates (soaks yielding bound fragments in the structure) for projects amenable to multi-crystal soaking and screening by crystallography. A remarkable result exemplified by the more than 100 projects screened since 2016, including the successful screening and follow-up of the SARS-CoV-2 Mpro protein, also released as an open science public service (193, 194).

## Section: Target-Based Screening › Fragment-Based Drug Discovery (FBDD) › Fragment Screening Strategies

Screening strategies rely on identifying and ranking chemical fragments that bind to the protein target. Methods need to be sufficiently sensitive to measure low affinity interactions and therefore do not typically rely on activity assays. The NMR, surface plasmon resonance (SPR), thermal shift assays (TSA) (also known as differential scanning fluorimetry (DSF) and X-ray crystallography are the most widely used techniques for high throughput fragment screening.

## Section: Target-Based Screening › Fragment-Based Drug Discovery (FBDD) › Fragment Screening Strategies

The NMR spectroscopy is the most robust fragment screening method for detecting very weak binding (KDs in the µM to mM range). The NMR approach used to identify target-ligand interactions can be based on observation of the target (target-observed) or ligand (ligand-observed) (195). In the case of ligand-observed NMR methods, only the resonance of the nuclei present in the ligands is measured (196). This type of approach includes methods such as saturation-transfer difference (STD), water LOGSY, cross saturation (CS) and transferred-cross saturation (TCS), transferred nuclear Overhauser effect (trNOE), NOE editing/filtering diffusion editing, relaxation editing, use of paramagnetic tags and residual dipolar couplings (197, 198). On the other hand, the target-observed methods provide data on the target nuclei that are directly involved in the interaction with the ligand (197). Among the target-observed methods, there are chemical shift mapping using 15N-HSQC, backbone amide hydrogen exchange and solvent paramagnetic relaxation enhancement methods. In comparison with other methods, NMR spectroscopy has the advantage of being conducted in solution, which allows the protein to be as close as possible to its native conformation. In addition, NMR enables both the target and the ligand to be structurally characterized serving as quality control assay to verify the structural integrity of the ligand. However, compared to other methods, fragment screening by NMR is relatively slow (199).

## Section: Target-Based Screening › Fragment-Based Drug Discovery (FBDD) › Fragment Screening Strategies

Screening by SPR involves immobilization of the target protein on a gold or silver sensor surface and measurement in the change in reflected light following ligand interaction (200, 201). The method is high throughput and very sensitive (µM to nM range) providing kinetic binding data (Kon and Koff rates), from which, KDs are calculated. The main disadvantage of the technique is the potential difficulty of immobilizing proteins in native conformation and therefore it is important to test a reference compound to assess correct binding behavior. The relatively high concentration of immobilized target and fragment affinities can lead to false positives through non-specific binding (202).

## Section: Target-Based Screening › Fragment-Based Drug Discovery (FBDD) › Fragment Screening Strategies

In the thermal shift assay protein denaturation is monitored by fluorescence either intrinsic tryptophan fluorescence or using dyes that preferentially bind partially or completely denatured proteins (203). Ligand binding is measured indirectly as the increase in thermal stability resulting from interaction with the target protein in the native state (204). This method is easy, fast and inexpensive for fragment screening (185). However, could not be appropriate for all target proteins, because indirect readout of the protein’s denaturation, and chances to generate false positives. Thereby, it is necessary to confirm the identified hits with other methods (205).

## Section: Target-Based Screening › Fragment-Based Drug Discovery (FBDD) › Fragment Screening Strategies

Crystallography is the current method for delivering atomic resolution information and is arguably the method of choice for primary screening if a project is amenable to this approach, i.e., access to high quality purified protein that can be reproducibly crystallized (206). There are two strategies for obtaining protein-fragment complexes, namely, co-crystallization or soaking (207). Co-crystallization is the mixing of the free protein in solution with a ligand prior to crystallization, which allows the small molecule to bind to the protein prior to crystal lattice formation. This is the preferred method if a protein complex with a specific ligand is required. A potential downside is co-crystallization with different small molecules can lower the success rate for crystallization, or introduce changes in resolution and crystal form, burdening the downstream analysis and limiting high throughput. In crystal soaking, false negatives come from protein failing to crystallize, or protein crystals growing without bound compounds. A simpler approach is soaking, where the compound is added, (dissolved or pure), directly to the crystallization drop which already contains crystals. In this method, compounds diffuse through solvent channels in the crystal accessing binding pockets in the protein (208). However, false negatives can still arise through a lack of fragment binding. Compounds may also dissolve crystals by disrupting the crystal lattice. Both co-crystallization and soaking are sensitive to low compound solubility.

## Section: Target-Based Screening › Fragment-Based Drug Discovery (FBDD) › Fragment-to-Lead (F2L) Optimization

The fragment hits commonly have weak binding affinities (from mM to high µM range) as a consequence of the reduced number of heavy atoms to form attractive interactions with the target (209). Despite the low MW, the fragment hits form high-quality interactions, i.e., highly energetically favorable interactions that surpass the entropic penalties for binding (210, 211). Thus, fragments constitute starting points that can be optimized iteratively into larger higher-affinity compounds – a process known as fragment-to-lead (F2L) (205, 210). The F2L process is guided by the information of binding mode, growth vectors available, and ligand efficiency (LE) and its derivatives (212, 213). LE is a metric used to describe the average free energy of binding per heavy atom (Equation 1) (214), and LE ≥0.3 is frequently used to select the most promising fragment hits to F2L (183). Three main strategies are used to optimize fragments, including fragment growing, merging, and linking ( Figure 2 ).

LE=ΔGHAC (1) where, ΔG is the free energy of binding and HAC is the heavy atoms count of a compound.

Fragment growing ( Figure 2A ) is the most commonly applied strategy in F2L (218). The effectiveness of this strategy is shown by its use in F2L process of three out of the four marketed drugs derived from FBDD (173), namely vemurafenib (174), erdafitinib (160), and pexidartinib (176). The fragment growing strategy involves a several steps. Firstly, potential growth vectors are identified in the chemical structure of the fragment hit (212, 219). Then, atoms or chemical groups are added to the fragment hit to explore additional interactions with the binding site and increase the potency (205). Structural information of the binding mode is essential during fragment growing to identify potential sub-pockets to explore and assess the maintenance of the fragment’s original binding mode and additional molecular interactions (198, 220). At each iteration of growing, synthesis and testing, success can be evaluated by LE, monitoring if the extra molecular mass added was beneficial (221).

Fragment merging ( Figure 2B ) can be applied when two fragments bind in an overlapping position of the binding site and can be merged into a unique and more potent hybrid compound (222, 223). As in fragment linking, both fragments can work additively when merged or even synergistically (224). Here, structural information is also crucial to understand the binding mode (198). Fragment merging is also difficult to achieve and less frequently used because of the challenging task of maintaining the original binding modes of the fragments after merge (225).

Fragment linking consists of the connection of fragments binding to different but adjacent sub-pockets in the binding site by a linker moiety ( Figure 2C ) (168, 177) and is the most powerful strategy for converting fragments into potent ligands (198). This is due to the potential super additivity effect, where the binding free energy of linked fragments is higher than the sum of binding free energy of the individual fragments (226, 227). The main challenge is the design of a linker group that does not affect the original binding mode of fragment hits (218). As a successful case, the marketed drug venetoclax was optimized by applying the fragment linking method (173, 177).

The SmTGR is a flavoenzyme expressed by schistosomes involved in the detoxification pathways that are pivotal for their survival in the host organism (228–230). Most SmTGR inhibitors are reactive electrophilic compounds, such as metal derivatives or Michael acceptors, presumably targeting the nucleophilic residues (selenocysteine and low pKa redox active cysteines), which may result in low selectivity and toxicity (231, 232). Attempts to obtain crystal structures of SmTGR in complex with such inhibitors have been unsuccessful, reflecting the problem of crystallizing non-homogenous protein preparations resulting from the presence of several redox and nucleophilic centers in the SmTGR, which are the sites of action for electrophilic inhibitor (233).

Given the challenges posed by the redox properties of the enzyme, allosteric and secondary binding sites could be explored, as they present less reactive amino acids which could lead to less toxic and more selective inhibitors. For this reason, Silvestri and coworkers (233) prioritized 1,000 fragment inhibitors of the SmTGR from a quantitative HTS campaign. Then, by X-ray crystallography identified two fragments (1,8-naphthyridine-2-carboxylate and 1-(2-hydroxyethyl)piperazine) that bound in a secondary pocket adjacent to the NADPH binding site ( Figure 3 ), named as “doorstop pocket”. The pockets are separated by the Tyr296 residue, where the aromatic ring of Tyr296 could adopt the closed ( Figures 3A, D ) and open ( Figures 3B, C ) conformations. Small molecules bound at the doorstop pocket disturb the well-known and conserved conformational adjustments associated with NADPH binding and enzyme reduction (233). Subsequently, chimeric compounds blending the structural features of the initial fragments into single compounds were synthesized and showed improved SmTGR inhibition activity, ex vivo activity against larval and adult S. mansoni worms at low micromolar concentrations. In addition, the designed compounds tended to have selectivity for SmTGR, as the amino acid residues of the doorstop pocket are not conserved between members of the FAD/NAD-linked reductase family (233). Although strictly this work was not a FBDD campaign (at least not originally designed as one), it was an interesting effort that showed the potential of the fragment-based approach to disclose new binding sites that can be explored to develop novel potent ligands.

Although FBDD has been established as an efficient approach for the identification of new biologically active compounds for several diseases, very few applications had been reported for schistosomiasis. Thus, FBDD has a great potential for anti-schistosomal drug discovery in the future.

A schematic illustration of fragment optimization strategies. (A) Fragment growing: initial fragment with low affinity is optimized by stepwise addition of functional groups to obtain a larger compound with high affinity. 3D and 2D schemes represents the growing evolution of navoximod, an indoleamine 2,3-deoxygenase 1 (IDO1) inhibitor with antineoplastic properties (solid tumors) (215); (B) Fragment merging: two or more fragments sharing the same pocket are covalently merged to obtain a larger compound with higher affinity. 3D and 2D schemes represent an example of fragment merging to the discovery of inhibitors of the Mycobacterium tuberculosis cytochrome P450 CYP121 (216). (C) Fragment linking: two or more fragments bound independently in proximity are covalently linked with suitable linkers to obtain a larger compound with higher affinity. 3D and 2D schemes represent an example of fragment linking to the discovery of inhibitors of M. tuberculosis pantothenate synthetase (217).

Doorstop pocket of SmTGR adjacent to the NADPH binding site. The Tyr296 of the doorstop pocket is represented in (A) closed and (B) open conformation, as well as in the presence of (C) NADPH and (D) two fragments (1,8-naphthyridine-2-carboxylate and 1-(2-hydroxyethyl)piperazine).

## Section: Target-Based Screening › Fragment-Based Drug Discovery (FBDD) › In Silico Approaches for FBDD

In silico approaches have been used in several parts of FBDD pipelines as an alternative or complementary approach, with the benefits of speed and low cost (234, 235). Many fragment libraries are available in the literature (188) and computational methods can be used to design a fragment library with high chemical diversity, synthetically accessible to be easily optimized during F2L, and also select or exclude fragments based on physicochemical properties (236, 237). The biophysical techniques applied for fragment screening are low-to-medium throughput (188), limiting the number of fragments that can practically be screened, and therefore the coverage of chemical space (180, 238). To compensate for this, molecular docking and machine learning can be used to virtually screen a large number of fragments and prioritize the most promising for experimental testing (224, 239–242).

Several in silico methods are also used during the F2L process (243). When no structural information about the binding is available, molecular docking and molecular dynamics are used to predict the binding mode and inform the growing, linking, and merging strategies (244, 245). The fragment hits can also be optimized with the help of de novo, machine learning, and deep learning methods (209, 243). These methods will be discussed in more details in the next sections.

## Section: Computer Assisted- and Artificial Intelligence-Based Drug Design

Databases and webservers for gene and protein functional annotation.

Architecture of several popular neural networks. (A) classical Feed Forward Network; (B) Deep Feed Forward Network; (C) Convolutional Neural Network; (D) Recurrent Neural Network; (E) Variational Autoencoder Network; and (F) Generative Adversarial Network.

## Section: Computer Assisted- and Artificial Intelligence-Based Drug Design › Schistosome Post-Genomic Era

Databases and webservers for gene and protein functional annotation.

## Section: Computer Assisted- and Artificial Intelligence-Based Drug Design › Schistosome Post-Genomic Era › Genes and Proteins Functional Annotation

The “-omics” era for schistosomiasis drug discovery started when the first versions of the S. mansoni (157, 246), S. haematobium (247), and S. japonicum (248) genomes were published. Recently, revised versions of the S. japonicum (249) and S. haematobium (250) genomes were released, enhancing the quality of the available genomics data for these three main trematode responsible for the majority of schistosomiasis cases in the world. The latest genome versions of these trematode species, together with other parasitic worms species, are available online at (https://parasite.wormbase.org/species.html#Platyhelminthes).

Most of the genome of schistosomes (like many other organisms) has yet to be explored experimentally. Consequently, bioinformatic tools and resources have become pivotal for the functional annotation and analysis of genes and their products. There are a wide range of general resources available that host biological information (genomics sequences, transcription data, protein structures, metabolomic data and more, see Table 4 ) as well as bioinformatic tools to perform analysis to unveil useful information within the data. Databases and webservers such as (but not limited to) InterPro (251), CATH-Gene3D (252, 253), the Conserved Domains Database (CDD) (254), HAMAP (196), PANTHER (255), Pfam (256, 257), PROSITE Patterns and Profiles (258), ProDom (196), PIRSF (196), PRINTS (259), SMART (260), Structure-Function Linkage Database (SFLD) (261), SUPERFAMILY (262, 263), TIGRFAMs (264) are integrated to identify specific motifs and domains to classify the protein of interest. Other resources such as the Kyoto Encyclopedia of Genes and Genomes (KEGG) database (265) provide functional annotation that encompasses molecular-level information about biological systems, integrating molecular datasets resulting from genome sequencing or other large-scale experimental technology. The KEGG website (https://www.genome.jp/kegg/) offers several tools to find data-oriented and organism-specific entry points, as well as analytical tools for diverse ends, such as genome and metagenome functional annotation (BlastKOALA and GhostKOALA respectively), pathway mapping tools (KEGG Mapper), sequence and chemical similarity search (BLAST/FASTA and SIMCOMP respectively).

Gene Ontology (GO) model (266) (http://www.geneontology.org) is commonly used for describing genes using a unified and common vocabulary applicable to any organism. GO is a hierarchical way of describing information gathered on genes and proteins at different levels of annotation and is used by many of the databases mentioned above as it provides the top three different categories of high-quality annotation: (i) biological process, (ii) molecular function, and (iii) cellular component; each one referring to the biological objective of the gene/gene product, biochemical activity of the gene/gene product, and place in the cell where the gene product is active respectively (267). The unified annotation/vocabulary provided by GO is dynamic and entirely based on the principle of shared orthology by all eukaryotic organisms. It can be updated as the ontologies become mature through the integration of more experimental results.

As an exemplar of how these tools and resources can be used in the context of Schistosoma is by Padalino and colleagues (40) who identified S. mansoni Lysine Specific Demethylase-1 (SmLSD1) as a druggable epigenetic target, as well as daunorubicin and pirarubicin as potential inhibitors. This was possible using bioinformatics tools, such as Uniprot, PROSITE, InterPro, and Pfam, BLAST in combination with homology modeling, molecular docking, and a whole-organism screening.

Likewise, the latest revised versions of S. haematobium and S. japonicum published by Stroehlein et al. (250) and Luo et al. (249) demonstrate the use of several tools in an extensive way. Luo and colleagues (249) combine tools whose functions range from genome evaluation to RNA, protein prediction and phylogenetic analysis and all of them converge to the evaluation and comparison of the revised genome and the previously published versions. Stroehlein and colleagues (250) used a lesser extent of tools, however a deep comparison between previously published versions of Schistosoma genomes was conducted and a careful data curation was carried out to ensure the quality of the assembled genome.

Since 2017, many efforts in terms of RNA-seq data have been reported in the context of Schistosoma (85, 269–272). A thorough protocol of how to gather, process, reconstruct the transcripts, and identify novel long non-coding RNA (lncRNAs), as well as their expression levels (273). In this protocol, Maciel and Verjovski-Almeida use a set of open-source Unix-based tools combined with several R (274) packages to support the analysis of differential expression of some lncRNAs. Wang and colleagues (85) reported a large RNAi screening against S. mansoni to uncover new therapeutic targets. The authors conducted a GO enrichment to better understand the roles of the essential genes to the parasite development and attachment to substrate. Furthermore, this study demonstrated the essentiality of SmTK25 kinase to maintain the muscular function of the parasite, thus representing a promising therapeutic target.

Databases and webservers for gene and protein functional annotation.

## Section: Computer Assisted- and Artificial Intelligence-Based Drug Design › Schistosome Post-Genomic Era › Phylogenetic Analysis – Computational Phylogenomic Inference Methods

One of the principal methods for integrating and inferring functional annotation is phylogenetics - the study of the evolutionary story of organisms and their relationships with other organisms or group of organisms. The relationships among the organisms are described in a detailed and hierarchical manner through phylogenomic inference methods, which will result in a phylogeny, represented by a phylogenetic tree (275). It is the best way for identifying and confirming whether two or more sequences are orthologs (276).

Phylogenomic inference methods are applied to assign a biological function to an unannotated gene or protein (277). Their overall accuracy is high and theoretically the topology of a generated phylogenetic tree is correct unless highly dissimilar sequences (identity <25%) are present among the aligned sequences (278). The methods are directly dependent on a multiple sequence alignment (MSA), whereby main objective is to align more than two sequences, allowing the identification of conserved motifs, domains and regions in the compared sequences (nucleic or amino acids) (277). Therefore, the quality of a final phylogenetic tree will strongly depend on the MSA quality and accuracy. The most popular tools for phylogenetic analysis are PhyML (279), RAxML/ExaML (280), FastTree (281), and IQ-TREE (281, 282).

There are many methods that can be used to build phylogenetic trees from an MSA. Distance-based methods such as neighbor-joining and Unweighted Pair Group Method with Arithmetic Mean (UPGMA) are the simplest examples which provide a genetic distance calculation between the multiple sequences aligned, but do not give evolutionary information (275, 282, 283). More complex methods, such as maximum parsimony, minimum evolution, and maximum likelihood can be employed considering the Bayes’ theorem for the estimation of an evolutionary model (284, 285).

Maximum parsimony’s principle relies on the sum of the number of minimum possible sites substitutions in each sequence. The sum will constitute the tree length for the investigated topology and the topology with the minimum length is called maximum parsimony tree (279). Minimum evolution is a distance-based method which generates a tree topology based on the lowest value among the values obtained from the sum of all branches (286). This method has a high time-cost mainly when dealing with too many sequences, e.g. protein superfamilies. The Maximum likelihood statistical method is known as the method which produces the most reliable phylogenetic trees in comparison with distance-based methods and the parsimony method (283). A phylogenetic tree is constructed through the maximum likelihood method accordingly to the following steps: (i) generate a starting tree; (ii) rearrange the starting tree through topological substitutions and evaluate the new tree; (iii) replace the starting tree and repeat the step ii if no better tree is identified; on the contrary, terminate the search (283).

For the cited methods, even for those based on distance, the robustness of the tree is assured by a bootstrap resampling technique (275, 282, 287) which is based on the replacement of nucleotides, codons or amino acids and the construction of a new tree with the new sequences. Next, each interior branch of the original tree is compared to the newly branches and, if the branches are different, a bootstrap score 0 is given while a score 1 is assigned to the other branches. The process is repeated a few hundred times, the percentage of times which the bootstrap score 1 was given is calculated, and the topology can be considered correct if the percentage is equal or greater than 95%. In the context of Schistosoma species and other helminths, these types of phylogenetic analysis have been boosted by the availability of a wide range of high quality genomes captured and analyzed within the 50 Helminth Genome Project (https://www.sanger.ac.uk/collaboration/50hgp/) and well as the other genomes and resources found in WormBase (268).

## Section: Computer Assisted- and Artificial Intelligence-Based Drug Design › Cheminformatics

Despite all advances achieved in the field of automation of screens, FBDD, and also in the understanding of disease biology in the post-genomic era, delivering new drugs to the market remains a highly complex, expensive and time-consuming process (288, 289). Therefore, there is a need for innovative approaches that could bring new drugs for patients at a lower cost-to-market. In this context, computer-assisted drug design approaches (CADD) has been considered as a potential opportunity (290, 291). Cheminformatics is a field of CADD and has the objective of utilizing computer and information sciences to solve problems in the area of chemistry (292, 293). This involves the design, creation, retrieval, storage, management, organization, analysis, visualization, dissemination, and use of chemical information (294). Over the last few years, the advances in data processing power and the development of new artificial intelligence (AI) tools, has fueled the field of CADD and cheminformatics (295, 296). Moreover, AI tools abilities have increasingly been applied to a wide variety of chemical challenges, from improving computational chemistry to end-to-end drug discovery as well as to synthesis planning/prediction (297, 298).

The developments in phenotypic and target-based screening provide data essential for applying computational tools to accelerate the discovery of new drugs to treat schistosomiasis (299, 300). These advances coupled with data storage in public databases such as PubChem (301–303) and ChEMBL (304) have enabled the compilation, curation, analysis, and application of chemical and biological information to support antischistosomal lead generation and optimization (305–307). Thus, cheminformatics has an important role in schistosomiasis drug discovery through the conversion of data to information and information into knowledge (308, 309), supporting data-driven decisions in lead identification and optimization (310, 311).

In the last years, pivotal advances in cheminformatics-driven drug discovery have been achieved in three main sub-fields: molecular de novo design, virtual screening, and synthesis prediction. Machine learning approaches have also progressively been applied in these areas. Therefore, in the next sections, machine learning approaches will be described and important aspects to schistosomiasis drug discovery will be highlighted.

Architecture of several popular neural networks. (A) classical Feed Forward Network; (B) Deep Feed Forward Network; (C) Convolutional Neural Network; (D) Recurrent Neural Network; (E) Variational Autoencoder Network; and (F) Generative Adversarial Network.

## Section: Computer Assisted- and Artificial Intelligence-Based Drug Design › Cheminformatics › Machine Learning

Machine learning (ML), mainly supervised methods, is a growing field of AI that uses different algorithms to enable computers to learn from sample data, known as “training data”, without being explicitly programmed for this task (312). ML algorithms are capable of recognizing complex patterns in chemical structures that evade human rationales because of the enormous number of parallel variables that should be addressed in drug design (313). On the other hand, molecular modeling techniques (e.g., docking, molecular dynamics) are based on explicit physical equations derived from molecular mechanics and quantum mechanics theory (314). Consequently, ML techniques are considered to have higher predictive value than classic molecular modeling methods. Combining human and ML -derived models should enable medicinal chemists to make better decisions and move projects forward more quickly (315, 316).

ML has applications in several stages of drug discovery and development, accelerating the overall process (317), including automation of whole-organism assays (70, 94), lead identification and optimization (318), and clinical development, for example in patient recruitment, prediction of diagnosis, prognosis, treatment planning, and clinical trial outcomes (317, 319). ML provides robust methods such as random forest (RF) (320, 321) for learning from large and multi-dimensional chemical data to make predictions and select new chemical entities for experimental testing (322). The generation of ML models for drug design and discovery consists of a multi-step protocol (323). The first step is the data collection of chemical and biological information from the literature and/or databases, followed by preparation and curation of data employing standardized protocols (324–326). Then, descriptors are calculated from molecular representations varying from one-dimension to n-dimensions (327). These molecular descriptors are derived from a logical and mathematical method that converts the chemical information into a useful number (328). The third step is the model training (learning), where a ML technique is applied to establish Quantitative Structure-Activity Relationships (QSAR) between the molecular descriptors and continuous (e.g., pIC50, Ki, etc.) or categorical/binary (e.g., active, inactive, toxic, nontoxic, etc.) experimental bioactivities or properties (329, 330). The models that are developed need to be validated using appropriate metrics to assess their predictive value (331, 332), and then used to predict the biological activity of new compounds (318).

It is worth pointing out that the initial training data underpins ML models generation. The data should be high-quality and in sufficient quantity to lead in models with high performance (295). However, in the current scenario, the data of pharmaceutical industry is scarce, costly, and need substantial resources, which could limit the use of ML for drug discovery (329).

Some guidelines for model generation and validation should be followed to ensure the reliability of the model. In this context, some principles for assessing the validity of ML-based QSARs have been proposed by the Organization for Economic Cooperation and Development (OECD) (333) stating that they should have:

As an example of application of ML to schistosomiasis drug discovery, Zorn and coworkers (338) used data from phenotypic screens against the schistosomula and adult stages of S. mansoni to develop ML models. Firstly, the authors elaborated two rule books and associated scoring systems used to normalize 3,898 phenotypic data points and transform to categorical data. Then, using the Assay Central software, they generated eight Bayesian machine learning models based on each developmental stage of the parasite and four experimental time points (≤24, 48, 72, and >72 h). Subsequently, the generated models were used to predict the activity of compounds from several libraries of commercial vendors. Finally, 40 compounds predicted as active and 16 compounds predicted as inactive were selected and purchased for in vitro phenotypic assays against schistosomula and adult stages of S. mansoni. In this manner, the authors achieved a prediction accuracy for active and inactives of 61% and 56% for schistosomula and adults, respectively. Additionally, the hit rates achieved were 48% and 34% for schistosomula and adults, respectively (338).

## Section: Computer Assisted- and Artificial Intelligence-Based Drug Design › Cheminformatics › Deep Learning

DL is a type of ML that uses a hierarchical recombination of features to extract pertinent information and then learn the patterns represented in the data. In other words, DL uses artificial neural networks (ANNs) with many layers of nonlinear processing units for learning data representations. DL has emerged to deal with the high volume and exponentially growth of sparse data, coming from different sources around the globe (339). Conceptually, DL was conceived in the 1980s, with the development of ANNs, which, at the time, could not out-perform ML algorithms due to the small amounts of data available. As soon as advances in hardware were achieved, in 2010s, with graphic processing units and cloud computing technologies, deep neural networks (DNNs) became more popular and able to be trained and accomplish complex tasks (340).

The basic structure of a classical ANN and DL representations are represented in Figure 4 and are inspired by the structure of the human brain. There are three basic layers in a neural network: the input layer, hidden layer and output layer. Depending on the type of ANN, the nodes, also called neurons, in neighboring layers are either fully connected or partially connected. The major difference between DL and traditional ANN is the complexity of the NNs. Traditional ANNs ( Figure 4A ) normally only have one hidden layer whereas DL architectures such as Deep Feed Forward Network ( Figure 4B ) uses larger numbers of hidden layers.

Since the advent of QSAR in the 1960s for drug discovery projects, and the use of so called “shallow methods” for the identification of new chemical entities with drug like properties (341), the application of DL methods has been increasing (276, 315, 317–323). The applications of DL can be as diverse as the creativity of those who applies and develops the methods. The possibilities are unlimited in terms of algorithms [see (342)] but are restricted in terms of data quality and chemical space coverage (325). However, DL has broadened even the ability of generating new chemical data, allowing the usage of autoencoders to interpret SMILES data and, within that chemical space, generate new scaffolds sharing a few physicochemical properties with their parental molecules (343). From virtual screening processes to synthesis prediction, DL has been largely used in the field of CADD, and its applications are exemplified in the next sections.

Architecture of several popular neural networks. (A) classical Feed Forward Network; (B) Deep Feed Forward Network; (C) Convolutional Neural Network; (D) Recurrent Neural Network; (E) Variational Autoencoder Network; and (F) Generative Adversarial Network.

## Section: Computer Assisted- and Artificial Intelligence-Based Drug Design › Cheminformatics › Deep Learning

As a fundamental part of CADD strategies, virtual screening (VS) is an in silico screening alternative to the experimental HTS approach to search libraries of small molecules and identify those structures which are most likely to have biological activity (344, 345). VS represents a rapid and low-cost and method for screen promising compounds against pathogens, cells and/or specific biological targets (344, 346). A VS campaign is basically a funnel-like process (347) composed of different filters. A large chemical database can be submitted to those different filters and, throughout the process, the compounds presenting undesired properties will be filtered out. In the end of the process, virtual hits with drug-, lead- or even fragment-like properties are presented in a ranked list.

In the last few years, the success of machine and deep learning has enabled the development of VS methods that can extract task-specific features directly from chemical data (295, 296). Convolutional Neural Networks (CNN, Figure 4C ) are a subclass of DL that search for recurring spatial patterns in data and compose them into complex features in a hierarchical manner (348, 349). Chemical descriptors have very high dimensionality, and hence training a standard Feedforward network to recognize chemical patterns would require hundreds of thousands of input cells. This can cause many problems associated with the “curse of dimensionality” in neural networks. The CNNs provide a solution to this (350) by utilizing convolutional and pooling layers to help reduce the dimensionality from compound graphs (351). As convolutional layers are trainable but have significantly fewer parameters than a standard hidden layer, they can highlight important parts of the chemical structure and pass each of them forward.

Although DL have important advantages, the most prominent demonstration of DL’s capability are in areas where large amount of data are available, which is not the reality of all drug discovery campaigns (297, 352). In addition, studies demonstrated that simpler ML methods can outperform DL for activity prediction (353).

## Section: Computer Assisted- and Artificial Intelligence-Based Drug Design › Cheminformatics › Deep Learning

Regardless of the advances in cheminformatics, the conception of the large majority of new molecules in drug discovery campaigns comes from the inventiveness of medicinal chemists (354). Since the 1990s, de novo methods have been used to design new molecules from scratch, commonly using structure-based approaches and resulting in compounds that are sterically and electrostatically complementary to the binding site of a protein target (355). However, the molecules generated by early de novo design methods were usually synthetically challenging, with poor pharmacokinetic properties, and the generation process required long runtimes (356, 357).

With the progress in deep learning, a variation of the de novo design method called generative modeling has appeared as a promising approach (358). These methods model the underlying probability distribution of chemical features from a training dataset and, thus, learn the essential aspects that characterize molecules (296, 359). Then, new molecules are generated combining these features by sampling the learned distribution of chemical features (360). The most common deep learning architectures for generative models are Recurrent neural networks (RNNs) (361), generative adversary network (GAN) (362), and variational autoencoder (VAE) ( Figure 4 ) (363).

The RNNs ( Figure 4D ) are commonly trained with a large number of Simplified Molecular Input Line-Entry System (SMILES) strings, which encode chemical structures (364). Then, the RNN predict the probability of the next SMILES character considering a sequence of preceding characters (365). Thereby, the new molecules are generated by RNN character by character until the required number of characters have been produced (360).

The VAEs ( Figure 4E ) are composed by an autoencoder model that contains an encoder and a decoder network. The encoder translate a higher-dimensional molecular representation (e.g., SMILES) into a lower-dimensional representation, called latent space (366). The decoder translate the latent-space representation back to the higher-dimensional representation to generate new molecules (295, 366, 367). In addition, this network uses probabilistic hidden cells, which applies a radial basis function to the difference between the test sample and the cells’ mean. In this sense, VAE learns the parameters of a probability distribution representing the chemical structure data. Instead of just learning a function representing the chemical space, it gains a more detailed and nuanced view of the chemical structures, sampling from the distribution and generating new chemical structures (359).

GANs ( Figure 4F ) consist of two specialized networks that “contest” with each other: a generative network and a discriminative network (367). With careful regulation, these two adversaries compete with each other, each’s drive to succeed improving the other. The end result is a well-trained generator that can spit out a new chemical structure with desired biological property. The generative network (usually a CNN) tries to generates new molecules, while discriminative network tries to discern generated molecules as artificial or real (296). Mechanistically, discriminating network receives either training data or generated content from the generative network. How well the discriminating network was able to correctly predict the biological property is then used as part of the error for the generating network. Both networks are trained alternatively aiming the generation of molecules that are indiscernible from the real data (319).

In addition to the deep learning architectures for generative modeling, it is possible to use techniques such as transfer learning and reinforcement learning to fine-tune the models to generate molecules with the desired properties (e.g., activity against a target and physicochemical properties) and also optimize compounds such as fragments (368, 369). The power of these methodologies is the design of new molecules with ideal properties in shorter periods and lower costs (370, 371).

Despite the innovation of generative models, the novelty and accessibility of generated molecules must be evaluated (372–374). Gao and Coley (375) observed that generative models can produce infeasible molecules even with good performance in benchmarks. On the other hand, in a work for the discovery of discoidin domain receptor family member 1 (DDR1) kinase inhibitors (370), Walters and Murcko (366) pointed out that the top inhibitor is very similar to a known DDR1 inhibitor (366, 371).

## Section: Computer Assisted- and Artificial Intelligence-Based Drug Design › Cheminformatics › Synthesis Prediction

The synthetic feasibility of virtual compounds identified in VS campaigns is a key point when considering synthesizing and further optimizing their properties (376, 377). Efforts from several research groups to improve the evaluation of synthetic routes and their inherent accessibility have been published and well-known software has been produced, e.g. SYNCHEM (378), RASA (379), LHASA (376), CAMEO (380), SOPHIA (381), EROS (382), and Reaxys (295, 383). Their main goal is to assess synthetically accessible routes, reaction predictions, and start material selection. To achieve this goal, approaches based on basic rules for organic synthesis, data-driven intelligent systems, sequence-to-sequence, template-based models, knowledge-graph based, and retrosynthetic prediction models have been proposed and published (384–386). To list the main obstacles for reaching a good accuracy in predicting both accessible synthetic routes and retrosynthetic disconnections, we can point out (i) the low number of unsuccessful reactions reported, (ii) the extensive data curation process, which impacts on the data quality and, consequently the predicted outcomes (384, 385). The current state-of-the art relies on treating the task as a text processing problem. Natural Language Processing (NLP) algorithms have been tested, implemented, and shown to provide of promising outcomes. The IBM RXN platform (387) represents a successful application and example of how to deal with chemical reactions as text. The platform uses the simplified molecular-input line-entry system (SMILES) as the source of local and global features potentially involved in a chemical reaction (388).

As well as in FBDD, very few applications of cheminformatics have been reported for schistosomiasis. Thus, cheminformatics also has a great potential for anti-schistosomal drug discovery in the future.

## Section: Concluding Remarks and Future Directions

In conclusion, we would like to emphasize that the recent advances in automation of whole organism screening and target-based assays, as well as FBDD, CADD and AI tools integrated in drug design projects, represent a new era in anti-schistosomiasis drug discovery. The phenotypic assay methods described here are more sensitive and faster than traditional microscopy an have enabled the identification of several new antischistosomal candidates. In parallel, significant contributions are coming from the genomics to target-based screening approaches, especially with prospecting and prioritizing biological targets with key/essential roles in parasite survival and/or host-parasite interactions. The automated collection and processing of X-ray crystallography data at synchrotons has transformed fragment-based screening enabling the acquisition of structural data at atomic resolution. The generation of large datasets from advances in the automation of phenotypic screening and target-based approaches has created a fertile ground for drug discovery. These data have enabled the use of artificial intelligence tools, such as machine learning and deep learning, to generate predictive QSAR models for prioritization of VS hits or structural design of novel compounds. These tools can be also used for in silico multi-parameter optimization, for achieving a favorable balance between target potency, selectivity, physicochemical, pharmacokinetic and toxicological properties. Therefore, we see the use of AI tools and QSAR models as a time-, labor-, and cost-effective way to discover hit compounds and to optimize lead candidates in the early stages of drug discovery process. We hope that these new technologies collectively will empower schistosomiasis drug discovery and increase the efficiency of the various processes involved to deliver new drugs to the market.

## Section: Author Contributions

All authors contributed to the article and approved the submitted version.

## Section: Funding

The authors would like to thank Brazilian funding agencies, CNPq, CAPES, FAPERJ, FAPEG and FIOCRUZ for financial support and fellowships. JM-F, AS, and LS are supported by CAPES fellowship (Finance code 001). CA and FS-J are CNPq research fellows. AS thanks CAPES for PDSE fellowship to perform part of his Ph.D. studies in UK (#88881.131626/2016-01). NF is supported by the Medical Research Council (Grant No: MR/T000171/1).

## Section: Conflict of Interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

The reviewer CC declared a past co-authorship with one of the authors CA to the handling Editor.

## Section: Acknowledgments

RO, NF, and JB-N thank Diamond Light Source UK for the XChem facility time and the use of beamline I04-1 (Proposal LB16978). We are grateful to ChemAxon and OpenEye Inc. for providing academic license of their software for our projects. We are also grateful to DataCamp for providing academic license for our students perform training courses.


---

# Scientific and regulatory evaluation of mechanistic in silico drug and disease models in drug development: Building model credibility

- **Authors:** Flora T Musuamba, Ine Skottheim Rusten, Raphaëlle Lesage, Giulia Russo, Roberta Bursi, Luca Emili, Gaby Wangorsch, Efthymios Manolis, Kristin E Karlsson, Alexander Kulesza, Eulalie Courcelles, Jean-Pierre Boissel, Cécile F Rousseau, Emmanuelle M Voisin, Rossana Alessandrello, Nuno Curado, Enrico Dall'ara, Blanca Rodriguez, Francesco Pappalardo, Liesbet Geris
- **Issuer:** CPT: pharmacometrics & systems pharmacology
- **Type:** Scientific article
- **Published:** 2021-07-13
- **Language:** en
- **DOI:** 10.1002/psp4.12669
- **Source:** https://pubmed.ncbi.nlm.nih.gov/34102034/
- **Licence:** CC-BY

## Section: Abstract

AbstractThe value of in silico methods in drug development and evaluation has been demonstrated repeatedly and convincingly. While their benefits are now unanimously recognized, international standards for their evaluation, accepted by all stakeholders involved, are still to be established. In this white paper, we propose a risk‐informed evaluation framework for mechanistic model credibility evaluation. To properly frame the proposed verification and validation activities, concepts such as context of use, regulatory impact and risk‐based analysis are discussed. To ensure common understanding between all stakeholders, an overview is provided of relevant in silico terminology used throughout this paper. To illustrate the feasibility of the proposed approach, we have applied it to three real case examples in the context of drug development, using a credibility matrix currently being tested as a quick‐start tool by regulators. Altogether, this white paper provides a practical approach to model evaluation, applicable in both scientific and regulatory evaluation contexts.

## Section: INTRODUCTION

In healthcare‐related academic and industrial research and development, modelling and simulation (M&S) (in silico) approaches are combined with other advanced scientific tools to support innovation for better understanding physiology, pathophysiology, complex diseases and effects of medical interventions. The value of in silico methods in drug development and evaluation has been demonstrated repeatedly and convincingly. 1 , 2 Computational models have evolved from being a possible alternative to other data sources (e.g. clinical trials), to being an unmissable must for development of new medicines, drug maintenance on the market and extension of indications for existing drugs (i.e. their repurposing in completely new indications). From additional or descriptive evidence used in some sparse cases, digital evidence (as generated by in silico models) is now included in almost all regulatory submissions. In many cases in silico models constitute the key source of evidence in drug development programs and related regulatory submissions (e.g. in case of extension of indications to children based on extrapolation). The term model‐informed drug development (MIDD) is often used to describe the approach of using models to inform drug development (see e.g. 3, 4, 5, 6, 7 ).

Modelling and simulation is a rapidly evolving area in terms of both technologies and application field. The latter are expanding beyond the description of drug exposure, towards the dynamic description of complex drug effects and disease subtypes and progressions. With the combination of increased uptake and expanding technologies, it is essential to have clarity and consensus in the in silico community on the most appropriate tools for in silico model evaluation. Therefore, the aim of this white paper is to present a high‐level framework that can guide the process of the evaluation of models and simulations in a holistic and comprehensive manner. The suggested framework can be seen as a generic umbrella that can be used irrespective of model and simulation technology, by guiding the process of their evaluation rather than providing the technical content and requirements. In making the process of their assessment explicit, it facilitates better informed dialogue between stakeholders, which currently is a challenge as modelers often may overwhelm other domain experts with technical details. 8 , 9

Ideally, in silico tools should be endorsed by all the relevant stakeholders, including academia and industry researchers, regulators, payers (HTA), healthcare professionals and patients. 10 An important aspect of this approach is that, principally, the quality standards for establishing model credibility should be driven by the scientific question to be addressed by the modelling and simulation exercise, the context of use and the risk involved rather than by the type of sponsor (academia, industry, health care etc.), or whether the use is early experimental development versus regulatory use. Of note, The EU HMA/EMA strongly encourages academic consortia to engage actively in the process of drug development and regulatory science and several schemes are put in place at EMA level to facilitate this process.

A common language and approach can give us an environment that could permit establishing the credibility of in silico models and their adequate use in an objective and consistent manner across the various modelling and simulation technologies and applications. In the context of drug development, the credibility framework can be seen as complementing the stepwise model building and validation that today is standard for drug development. One could say that MIDD is this step wise building and consolidation of the in silico backbone of knowledge on the medicinal product coupled with an open dialogue between developers and regulators on finding potential applications for modelling and simulation to inform the development and approval. 3 , 4 , 5 , 6 , 7

State‐of‐the‐art papers, tutorials and regulatory guideline documents exist for methodological validation and reporting of Quantitative Structure‐Activity Relationship (QSAR) methods 11 , 12 as well as some pharmacometric approaches, such as population‐pharmacokinetics (popPK), pharmacokinetics/pharmacodynamics (PK/PD), and dose/exposure‐response (DER) models. 13 , 14 , 15 In contrast, regulatory guidance on mechanistic models (models developed starting from mechanisms, see Table in Section 2 for a full definition) is scarce. The EMA and FDA physiology‐based guidelines on pharmacokinetics (PBPK) models can be cited as pioneers in this domain. 16 , 17 With the aforementioned increase in model technologies used in drug development, there is an unmet need to provide an environment that would permit establishing the credibility of mechanistic in silico models and their adequate (regulatory) evaluation in a consistent manner.

This white paper aims to provide input on rigorous scientific and regulatory evaluation strategy for the expanding range of in silico technologies currently used in drug development. We will present a high‐level framework, inspired by the ASME V&V40 for medical devices, 18 that could guide the evaluation process of models and associated simulations in a holistic and comprehensive manner without necessary focusing on very technical and specific aspects related to different applications or types of models (these topics will be covered in future communications). To properly frame the required credibility building activities, concepts such as context of use, regulatory impact and risk‐based analysis will also be discussed. An overview of the relevant in silico terminology used throughout this paper will be provided. The steps of the risk informed credibility assessment will be presented, framing the required verification and validation activities, and concepts such as context of use, regulatory impact and risk‐based analysis will be introduced and discussed in the paper. During model building and validation activities, data from different sources are often used. Therefore, considerations of model predictions relative to data from other sources, and adequate uncertainty quantification and mitigation are some of the key and challenging steps. To illustrate the feasibility of the proposed approach, we have applied it to three real use cases use cases in the context of drug development, showing the variety of technologies and applications that are covered by the framework proposed in this white paper.

## Section: TERMINOLOGY

One main challenge in the communication between relevant stakeholders is the terminology associated with the in silico methodology. A uniform and widely adopted consensus terminology is lacking amongst all in silico developers, assessors and users. Scientists reporting their results to their community or sponsors presenting their submissions to the regulators often use terms with a different understanding than the one expected by their audience (be it reviewers, readers, regulatory assessors or others). The need for at least a mutual understanding of the in silico terminology used by each party is thus of utmost importance as it directly affects the communication efficiency between stakeholders.

For example, the term qualification is more commonly used in the EU drug regulatory space (EMA) 19 to design requirements for a model to be considered fit‐for‐purpose whereas terms verification and validation will rather be encountered in the medical device developers’ space to discuss model adequacy requirements. 18 This can be explained in part by the fact that drug regulators are used to risk‐based decision making in a multifactorial context and will aim to qualify models for a particular context of use given the established regulatory impact (with as bottom line: the perfect model does not exist). In contrast, for medical device, the mechanisms (i.e. physical laws) are better defined: developers can define tools to assess the adequacy of their model predictions. Another example pertains to the terminology used to indicate a specific type of model. Clinical pharmacologists will mostly use the term pharmacometric modelling and simulation while engineers will use the term in silico models to indicate almost exactly the same concept: a set of mathematical equations and/or computer algorithms that can be used to predict drug effects and/or health outcomes in different scenarios.

In our opinion, even if very convenient, the use of the same terminology becomes less critical when there is a common understanding of what is meant by specific terms used by each party. Given the continuous expansion of the modelling application domain, harmonization of language should not be the first target. The first target should rather be the understanding of nuances, similarities and differences in the terms used for different applications and by different stakeholders. It is important to understand which terms are interchangeable or overlapping, and which ones have different meanings when used in different settings. When different stakeholders communicate (e.g. scientists publishing a paper, sponsors meeting regulators), it is paramount that the most important terms are clearly defined at the onset, so misunderstandings are avoided. This effort may be supported by leveraging existing organized ontologies relative to modelling of biological processes (e.g., Mathematical Modelling Ontology, Systems Biology Ontology). 20 , 21 Consistency across requirements for model acceptability by assessors/reviewers will strongly depend on the appropriate use of terms by developers/reporters and their adequate understanding by users/ readers/reviewers/assessors. This is particularly important for in silico models requiring multidisciplinary expertise at the intercept of several scientific fields. To set the example, we start this white paper with a glossary (Table 1), clarifying our understanding of the most commonly used in silico‐related terminology in the field of drug development and evaluation. Ideally, this list should be expanding and regularly updated based on new application domains of modelling and simulation.

Definition of key terms related to computer modelling and simulation in drug development

## Section: CURRENT REGULATORY APPROACH FOR IN SILICO MODEL EVALUATION IN THE CONTEXT OF DRUG DEVELOPMENT AND EVALUATION

Modelling and simulation takes its roots in academia and has been embraced by sponsors (including drugs’ commercial sponsors) who have rapidly understood the economic potential of this approach. When developing and assessing the models, academic researchers have emphasized the innovation and the scientific (technical) value of the models, focusing on different requirements to define their acceptability (e.g. mathematical, statistical, computational, pathophysiological, pharmacological). This has led to a multiplication of tools for model evaluation, covering a wide range of methodologies for mathematical and statistical model evaluation, independent/external validation, scientific ((patho)physiological/pharmacological) plausibility of parameter estimates, etc. 42 Some model evaluation tools were developed specifically for the purpose of transfer to clinical applications. 43

However, these tools still have a long way to go in terms of implementation and general uptake and in terms of rigor in their implementation which currently can be variable and unbalanced (i.e. very strong claims are often made by developers with poor reporting and/or a weak verification/validation process). In this white paper, we will discuss the different available evaluation tools that we believe could be of interest for model evaluation (see section 9).

Drug developers and regulators have hitherto more focused on the application itself (drug) and the specific question that can be addressed by the models. Model development and evaluation are proposed in well‐defined contexts of use that take into account the regulatory impact (cf. section 7) and the consequence of model inadequacies for the relevant decision making at the level of the patient and public health, making some models acceptable for some contexts but not for others. This entails the necessity of pre‐defining the requirements for model acceptability in an application‐wise manner, irrespectively of the specific model technology used (e.g. empirical statistics vs. two‐stage approach vs. empirical models vs. PBPK(‐PD), SM/QSP models vs. agent‐based models). This also shows the need for understanding the actual value (strengths and limitations) of the proposed/available tools for model evaluation, their applicability to various model technologies and their relevance for the scientific question(s) of interest.

The regulatory evaluation of models is ideally supposed to be in line with the latest scientific knowledge in the field. While sponsors have the full liberty (and are encouraged to be as innovative as possible) in the choice of the approaches for evidence generation to support their claims, the regulatory assessors’ role is to ensure that the proposal is scientifically sound and valid given the context of use, the regulatory impact, and given pre‐established standards. For the interest of patients and public health, the regulators should always push the sponsor to provide the highest level of evidence and quality of modelling data. Although driven by regulators, establishment of standards should be a joint effort between all the stakeholders involved in the process (i.e. regulators, industry, academia, patients, healthcare professionals, HTA and payers). The current gaps and challenges encountered in in silico model reporting and evaluation likely affect the interactions between sponsors and regulators and, in some cases, this can delay drug market access for new drugs that patients need.

From a practical perspective, the regulators are expected to provide some guidance to sponsors on the presentation of their model development and evaluation results for optimal communication. At EMA, a range of regulatory procedures exists to interact and dialogue with sponsors on case‐by‐case basis, including for M&S related aspects. These procedures include Innovation Task Force (ITF) meetings, scientific advice protocol assistance and qualification advice/opinion. 44 , 45 , 46

The ongoing Model‐Informed Drug Development (MIDD) Pilot Program at the FDA is a very good example of how modelling related questions and context are fine‐tuned to ensure clarity and set expectations, thanks to regular interactions between sponsors and regulators. 47 Additionally, reference documentation is available such as Q&A documents, concept and reflection papers and specific guidelines. 9 , 16 , 48 , 49

It should however be noted that, apart from the PBPK guideline, none of these guidance documents refers specifically to the in silico models beyond the pharmacometric family. Hence, there is an unmet need for regulatory guidance for in silico model evaluation also including models built with other technologies (e.g., agent‐based models) in the context of drug development and evaluation, a need shared by regulatory agencies worldwide. One possible reason explaining this absence of specific guidance could be the lack of focus within the scientific community on creating evaluation tools able to meet regulatory scrutiny. Another reason could be that historically, the number of regulatory submissions including these types of models is rather low compared to pharmacometric models, which is a vicious cycle as without proper guidance sponsors are reluctant to include digital evidence into their dossier. Importantly, the framework presented in the white paper, including regulatory impact aspects, can contribute to the consistency of regulatory assessment across world regions. The authors therefore strongly support the idea that this subject constitutes a good candidate for a consensus approach (e.g. through a new ICH guideline).

## Section: POINTS TO CONSIDER FOR EVALUATION OF MECHANISTIC IN SILICO MODELS

While this paper is not intended to provide a definite recommendation for evaluation, it is the authors’ conviction that a framework to support the in silico model evaluation rationale is needed, similarly to what is proposed in the ASME V&V40 for medical devices. 18 The steps listed below and elaborated in the following sections are considered essential in the process of model evaluation, being it for communication between in silico scientists (e.g. publications in scientific journals, communications in meetings) or for regulatory submissions. A flowchart of the different steps is provided in Figure 1.

Ideally, these points should be defined at planning stage and included in a modelling and simulation plan, i.e., a document in which relevant assumptions, input data, implementation steps and output are clearly presented along with mitigation measures. This can constitute the basis for continued dialogue and interaction with regulators. To illustrate the points made below, we will work with three use cases, examples of in silico models in the context of drug development. A full description can be found in section 11.

In silico Model Process flowchart

## Section: QUESTION OF INTEREST AND CONTEXT OF USE

The scientific question(s) to be addressed by the modelling exercise need(s) to be clear and well described. Each question should be stated separately in case several questions would be addressed by the proposed model. Once all the questions are well identified, the next step is to describe the proposed modelling approach to answer each question, including the data sources for model development and evaluation. It is critical to ensure that the modelling and simulation final output really addresses the scientific question. According to the EMA current policy, the Context of Use (COU) is considered to be the full, clear and concise description of the way the methodology is to be used and the related purpose of the use. 9 The COU is a critical reference point for the regulatory evaluation of any qualification application as will become clear by the frequent referral to the COU in the following sections.

Examples of questions of interest are given below. These examples show that questions of interest are not limited only to interactions between drugs or their pharmacodynamics effects or even the interaction between a drug and organs/diseases. They can extend to the demonstration of clinical utility in the wider population after market uptake.

Some examples of COU are provided below:

Of course, the question of interest and the COU are strongly linked to one another. This can be observed clearly in the credibility matrix of the three core examples of this white paper (section 11).

## Section: MODEL ACCEPTABILITY CRITERIA FOR A PROPOSED QUESTIONS AND CONTEXT OF USE

Model acceptability criteria need to be well established. This should be done upfront during the planning phase before the start of any data collection (see flowchart Figure 1). This includes the level of credibility and validity of models intended to support scientific claims in communications (e.g. publications) and/or regulatory decision making. For regulatory submissions, it is recommended to consider the regulatory endorsement of the set of criteria selected and the approach planned to be used for model evaluation. Different regulatory procedures and guidance documents in place should be consulted to facilitate these interactions.

Model acceptability criteria will depend heavily on the COU and on the available tools for model evaluation. For regulatory submissions, the regulatory impact also needs to be taken into account as discussed below. It is very possible that the COU needs to be refined after acceptability evaluation, especially in case an adaptive pathway approach is adopted 50 and HTA bodies, patients and healthcare professionals enter in an early dialogue with the regulators and industry before the beginning of Phase 2 clinical studies. In turn, it is also possible that the acceptability criteria might be expanded after new model evaluation tools become available for the proposed type of model.

In case a mechanistic in silico model (e.g. PBPK, agent‐based or QSP) would be used to waive a clinical study (i.e. for high regulatory impact applications) the following could be included in the acceptability criteria:

Three examples of how model acceptability criteria can be made explicit and linked to context of use and scientific questions are provided in section 11.

## Section: REGULATORY IMPACT

Regulatory impact is a terminology proposed for the first time by Terry Shepard 51 , 52 to describe the role played by modelling data in the regulatory decision‐making. This terminology is now largely understood and widely used in the EU regulatory network. According to the regulatory impact terminology, when modelling and simulation data are only considered to play a descriptive role, because the key data for the question addressed is coming from other sources, the regulatory impact is considered to be low. However, when modelling results constitute the key source of evidence to answer the question of interest, i.e. replacing data traditionally generated in a clinical trial, the regulatory impact is considered to be high. The medium regulatory impact lies somewhere in between: modelling results are additional evidence to be complemented by other data from other sources, such as for dosing selection in a given patient (sub)population. 51 , 52

The concept of regulatory impact should be perceived as broader than the model influence as per the risk informed credibility assessment (ASME V&V40). Benchmarking against the current evidentiary standard is implicitly included in the regulatory impact concept. The ‘regulatory impact’ terminology is therefore interesting because it puts the in silico modelling data in perspective as compared to the other potential data sources (nonclinical in vitro, ex vivo and in vivo or clinical trials) to address the questions of interest. In addition, it implicitly compares the role of in silico modelling data in model‐informed drug development programs to what would have been done traditionally to address the same question without in silico modelling.

The stringency and the demandingness of the acceptability criteria in regulatory submissions defined in the previous section will also depend on the regulatory impact, with increasing levels of requisites/demandingness from low to high regulatory impact applications.

As illustrated in the examples in section 11, regulatory impact should in principle be explicit in each submission.

## Section: RISK BASED ANALYSIS OF DECISION CONSEQUENCE AND MODEL RISK

After establishing the regulatory impact, the next step is a risk‐based analysis of the decision consequence. This means assessing the consequence of an adverse outcome resulting from an incorrect decision that was made based on the model. The concept of model risk has been thoroughly discussed in the ASME V&V40 standard for medical devices and can be summarised as the combination of the influence of the computational model on the decision‐making (model influence) and the consequence of an adverse outcome resulting from an incorrect decision based on the model (decision consequence). The same concept can also apply to the drug development related models as shown here. The higher the model influence and the decision consequence, the higher is the model risk. An example of such high model risk is when extrapolating efficacy and safety information from limited clinical data collected during Phase 1 and exploratory Phase 2 clinical trials.

An additional source of uncertainty in disease and drug mechanistic in silico models is the trial and human errors that are not easy to anticipate when creating virtual populations (e.g. dosing errors, compliance). The level of uncertainty can directly influence decisions taken based on the modelling results. It therefore becomes critical to quantify an in silico model's estimated uncertainties and to evaluate the implications of these uncertainties on the targeted patient populations to demonstrate the specified clinical utility. As long as the uncertainty decreases and the confidence in the new drug increases thanks to newly generated data across the clinical trials phases, the model risk lowers. An example of this is a model‐based dose selection for a confirmatory phase 3 study, based on preclinical observations and PK data in healthy volunteers and patients. 14 Confirmatory datasets (retrospective, real‐world data and prospective), when available, can mitigate the model risk.

## Section: MODEL CREDIBILITY ACTIVITIES

After completion of all previous steps, model credibility activities can be designed and executed. These activities start with identification of credibility goals, including desired qualitative or quantitative outcomes (e.g. pre‐specified acceptance criteria) based on scientific rationale. 18 Credibility activities include verification of the software, the code and the calculations, validation of the model using comparator studies, and evaluation of the applicability of validation assessments to the COU. Credibility factors are the individual elements of these credibility activities, for instance the credibility activity of code verification encompasses credibility factors such as software quality assurance and numerical code verification.

The identification, design, execution and regulatory assessment of the credibility activities are general for the model assessment process. However, the specific tools and technical approaches/aspects relevant for the verification and the validation activities often differ between model types, as illustrated in. 32 Such specific requirements are beyond the scope of this paper.

## Section: MODEL CREDIBILITY ACTIVITIES › Model verification

Verification is often termed as “solving the equations right” as opposed to validation which is “solving the right equations”. Verification is to be performed on the level of the software platform (software quality assurance), the numerical code and the calculations. The term software platform refers to a computational modelling and simulation (CM&S) software executable running on a specified offline or online computational environment characterized by its underlying operative system and hardware components. All together, these verification activities ensure that a CM&S software executable and a model are correctly implemented on the computational platform of choice, that the model is accurately solved for its intended COU, and that adequate documented evidence of the verification activities is established to enable appropriate regulatory/scientific revision.

## Section: MODEL CREDIBILITY ACTIVITIES › Model verification › Software quality assurance (SQA)

SQA ensures that the CM&S software executable is correctly functioning, and that it produces repeatable results. A relevant aspect of this testing activity is a full understanding of the CM&S requirements and specifications, the test cases, their limits, and their execution in the regression testing to ensure all the bugs, errors, and faults are addressed accordingly to their potential effect(s) on the COU and the model risk.

CM&S software can generally be classified as user‐developed software, off‐the‐shelf software (commercial or open source license), modified off‐the‐shelf software, or most frequently combinations thereof. A software developer should tailor SQA activities upon the characteristics of the software components present in the model.

For user‐developed and/or modified off‐the‐shelf software, SQA activities should comprise:

For off‐the‐shelf software (components), SQA activities should comprise:

A guidance document as developed for the R statistical programming package 53 is an example of supporting documentation to R users.

## Section: MODEL CREDIBILITY ACTIVITIES › Model verification › Numerical code verification (NCV)

The NCV process is generally carried out by the software developer and/or user. It is a process that ensures the correct implementation and functioning of the CM&S software executable and model by means of estimating the correctness and numerical error in the calculated results (including, but not limited to, the spatial and temporal convergence rates & order) as well as by performing graphical and numerical checks. When the model equations allow, this verification step can be executed with the full model (blurring the distinction between code verification and calculation verification). However, when the model becomes more complex (due to more complex geometries, equations etc.), relevant benchmark problems should be identified and used to perform code verification. See e.g. 54 for an example of the development of simplified flow problems that can be used as standard benchmark tests for code verification for blood damage predictive models. Of note here is that, as a less stringent NCV, simulated data obtained from benchmark tests implemented with a verified code can be used for the verification of other codes. 18

To achieve a robust NCV, the model developer should (depending on the COU):

## Section: MODEL CREDIBILITY ACTIVITIES › Model verification › Calculation verification

Calculation verification encompasses estimation of discretisation errors, numerical solver errors and (human) use errors and the effect these errors have on the model results. The discretisation error arises from solving the computational problem at a finite number of spatial and/or temporal grid points. Numerical solver errors refer to errors induced by the selection of specific solver parameters. Human errors are errors introduced into the calculation by the model user in key inputs and output (e.g. typos). 18

To achieve a robust calculation verification, the model developer could (depending on the COU).

## Section: MODEL CREDIBILITY ACTIVITIES › Model verification › Specificities of in silico models for drug development

The aforementioned verification process corresponds to that of general engineering models and in silico models of medical devices that are heavily physics‐based. These verification actions require a well‐accepted “source of truth”. For many physics‐based models used in medical device modelling, this source is the fundamental differential equation or law that usually depends on space and time (such as the Navier‐Stokes equation to describe fluid dynamics). Models of biomedical processes rely on mechanistic knowledge, which is not always quantitative and which is not error‐free. Additionally, said processes often span multiple scales, which are intricately coupled and cannot be separated without considerable errors. 55 Because of this, there is an increase in models that consist of multiple submodels capturing different scales (multiscale models) or phenomena (multiphysics models). In case of multiscale models, orchestration between the different space/time scales is taken care through homogenization approaches and in case of multiphysics models through transformation of properties across physics theories. 56 For such models, the general philosophy is that credibility should be assessed at the level of an individual submodel as well as on the orchestration. In certain cases, where the homogenisation functions are also models, they too should be explicitly included in the credibility process. Another family of models that is increasingly used in the context of drug development is that of agent‐based models, which are mechanistic with at least some of the inputs being discrete. The discrete elements can range from cell state transitions (with everything else described by differential equations in a space‐time continuum) to the entire system being based on discrete rules. Verification of the continuous part of the model requires extensive verification whereas the discrete parts only require code verification as they involve algebraic calculations. However, as local instabilities might arise, a parameter exploration is warranted.

For all the aforementioned models, it is also important to ensure that model structure and related parameters are identifiable with the data used for model development. Appropriate tools should be used for this purpose. 57 , 58

## Section: MODEL CREDIBILITY ACTIVITIES › Model validation

As previously mentioned, validation activities are about showing whether the right equations are being solved, i.e. whether the in silico model is able to predict/simulate the reality of interest and the sensitivities and uncertainties of the model are clear. This starts with a clear description of the model's conceptual form along with its assumptions, ontology and input data quality. Subsequently, model validation requires the development of a validation comparator providing data to perform the evaluation. No validation can be performed without such comparator data. 32 The assessment step then compares the prediction/simulation results with the comparator data to ascertain model credibility. Besides this direct comparison, it is equally important to estimate the uncertainty in this comparison.

## Section: MODEL CREDIBILITY ACTIVITIES › Model validation › In silico models, related assumptions, ontology and input data quality

Credibility factors related to the in silico model evaluate model form/structure (governing equations, geometry, computational domain, variables, quantities, boundary/initial conditions etc.) and model input (parameter values for model form elements). In silico models used in the context of drug development are mainly describing biological processes, in contrast to models used in medical devices that often depend on physics. Their form and input depend largely on non‐exhaustive and poorly measurable material (knowledge and data) even on fundamental behaviour. Consequently, there may be multiple assumptions, gaps and hypotheses necessary to construct the conceptual form and to derive (or suggest) a convenient mathematical form. These need to be clearly described in the modelling report and their impact discussed. While every model is built on hypotheses, their high quantity and potentially large impact on the output of a pathophysiology model imposes specific attention to the following points:

Given the aforementioned points, the modellers should ensure and report compliance with model annotation and curation quality standards applicable for the type of model under scrutiny whenever available. Systems biology models can benefit from years of community effort into community standard ontology building. 60 , 61 To give an example, the use of a “scorecard” when reporting a model was recently proposed by a community effort to ensure the reproducibility of models in systems biology. 62 As previously stated, in silico models of biochemical cellular and biomedical processes rely heavily on knowledge, often in the form of heterogeneous and semantic data. For that reason, important efforts must be put to thoroughly reference and annotate the model and to make sure entities and variables can be identified unambiguously, for which one can rely on the use of standard ontologies (e.g. Gene Ontology, ChEBI). That endeavor to ensure model transparency and reproducibility can be achieved by following guidelines arising from modelling community efforts such as the BioModels initiated‐effort MIRIAM (Minimal Information Required in the Annotation of Models) 63 or the standard SBML and CellML formats to encode models, in systems biology. 64

A set of questions is listed below to qualitatively evaluate the credibility of an in silico model.

## Section: MODEL CREDIBILITY ACTIVITIES › Model validation › Comparator data

When performing the model validation, comparator data is required. This data can come from various sources, including dedicated (in vitro/ex vivo/in vivo) validation experiments, or historical nonclinical, clinical trials or real‐world validation data. Additionally, this data can come from the same experiment used in model development, provided it is a different (unused) subset and is clearly defined in the approach upfront. Regardless of the source, data used to perform the validation needs to be trustworthy, meaning of good quality, and relevant to the COU. Comparator data credibility factors are related to the test sample (e.g. animal disease model) and the test conditions (e.g. drug administration). For all factors, elements such as the quantity, range of characteristics, measurements and measurement uncertainty need to be reported. The measurements performed to characterize these test samples can be used as model inputs but can, in case of quantification of the uncertainty on the input, also enable quantification of the uncertainty in the model output. Furthermore, the measurement data can be used during model evaluation to determine equivalency between model input and comparator data. All aspects of the test samples and conditions need to be investigated separately, as they will have an impact on the comparator data and hence on its usefulness to establish model credibility. Below, a non‐exhaustive list is provided of comparator data elements requiring characterisation:

When experimental data are reported in the literature as comparator data, most often insufficient information is available to assess the quality of said comparator data, including information on how exactly this data was established: which model systems were used, which protocols were followed, etc. This meta‐data is sometimes also referred to as the birth certificate of the data. As an example, consider the mechanical properties of arterial tissues which play an important role in models of arterial disease progression. Almost all publications describing the mechanical properties of arterial tissues will mention information such as the species and anatomical location of the tested sample, the machine used and the loading protocol. Far less publications also include information on the time between donor death and sampling, time between sampling and testing, and transport conditions of the sample even though these factors have been shown to have substantial influence on the obtained parameter values. Efforts are undertaken to ensure presence of the necessary metadata. The recently published standard ISO 21899:2020 specifies the general requirements for the validation and verification of processing methods for biological material in biobanks. ASME is looking into expanding the IT’IS (Foundation for Research on Information Technologies in Society) tissue properties database, 65 in eight material property groups (including mechanical, thermal and electromagnetic). Additionally, at the end of 2020, a new community challenge, C4BIO (c4bio.eu) was launched jointly by academia and industry to develop community‐wide standardized testing protocols that include recording of the necessary metadata that will allow the data to pass regulatory scrutiny.

## Section: MODEL CREDIBILITY ACTIVITIES › Model validation › Assessment

With the previous steps completed, the accuracy of the model output can be assessed in terms of equivalency of input parameters as well as (rigor of the) output comparison. 18 Equivalency of input parameters between the in silico model and comparator data is described for both type and range, with higher degrees of equivalency leading to higher credibility. Output comparison is related to a number of elements, starting with quantity – i.e. how many outputs were compared. Additionally, increased equivalency of types of output between in silico model and comparator leads to higher credibility. Comparison of the output can be done through visual inspection (low credibility) and direct assessment of the difference between experimental and computational results. Depending on the COU also statistical testing of predictions against random prediction null hypotheses (e.g. classification: AUROC; ranking: spearman correlation) might be warranted. To further increase credibility, uncertainties coming from experiments and computations need to be quantified and incorporated in the output. Finally, when making the comparison, the level of qualitative and quantitative agreement between quantities of interest that is deemed satisfactory needs to be in accordance with the COU (e.g. high regulatory impact requires high model accuracy and inclusion of uncertainties on both comparator and model results).

## Section: MODEL CREDIBILITY ACTIVITIES › Applicability and uncertainty

Once a model has been successfully run, then it is necessary to compare the completed activities and results with what was expected. If both are within the accepted parameters, then the model can be considered as credible; otherwise, it might be necessary to review the model or the question of interest. 66 By evaluating the applicability of the verification and validation activities to the COU, again mindful of the model risk, an assessment of whether there is sufficient model credibility to support the COU can be made. 32 Applicability as defined in the ASME V&V40 refers to whether the measured quantities and the application domain of the Comparator and the model are identical, which is not always the case. Pathmanathan et al. provide a step‐by‐step guide for analysing applicability during the validation of evidence for biomedical in silico models. 67

Uncertainty is one of the critical aspects while assessing the credibility of a model. To study the model's uncertainty, it is necessary to check the uncertainty quantification (UQ) and sensitivity analysis (SA). UQ is the process of determining the uncertainty in model inputs, and then estimating the resultant uncertainty in model outputs whereas SA is the study of which inputs most affect a model output. Overall, UQ and SA test the robustness of model predictions. 67 A critical component of any uncertainty analysis is openness of the assumptions being or not made, the tools used, and the way that results are interpreted. Educated decisions can only be made through an understanding of both the process of estimating uncertainty and its numerical results. 68

## Section: REMAINING GAPS AND CHALLENGES FOR THE FUTURE

The aim of the white paper is to present a high‐level framework that could guide the whole model evaluation process in a holistic and comprehensive manner without necessary focusing on very technical and specific aspects related to different specific applications or types of models. These topics will be covered in future communications. ASME V&V40 standard was indeed initially proposed for medical devices. However, this approach of establishing the credibility of a model and its associated simulations as a method to answer a scientific question of interest is general and also applicable to drug development. Some adaptation is needed to better fit to the context of drug development: of note the regulatory impact, which is one additional key point in the framework as proposed in the white paper, is not included in the ASME V&V40: The regulatory impact (which is conceptually different from the model influence) was added, to better fit to the drug development setting.

There is an increasing need for use of in silico models and simulations in drug development. There are for example settings where clinical data generation to demonstrate drug efficacy and/or safety is just not feasible due to ethical or practical constraints. Reliable models would offer an alternative source of evidence for drug efficacy and safety assessment and per se would accelerate the availability of safe and effective drugs for patients.

There is a need for rigor and transparency in the methods used for model development and validation on the one hand and their wider acceptance as a valuable source of evidence by the scientific community including academia scientists, pharmaceutical industry, regulatory bodies and HTA/payers, on the other hand. Adequate model evaluation is considered a corner stone. An environment that permit establishing the credibility of mechanistic models and their adequate regulatory evaluation/assessment in a very objective and consistent manner is currently lacking with an unmet need for that. The proposed framework can be considered as an important step toward the creation of such an environment with well established, transparent and commonly agreed criteria for establishment of mechanistic model acceptability. The methods used for this purpose need to be well described and commonly agreed. Given the novelty, the multidisciplinary nature and the relatively recent arrival in the drug development setting of these mechanistic in silico models, we consider that we are still in the learning phase of identifying the most appropriate tools for model verification, validation/qualification. Similar as for other quantitative tools which have been used for longer and are more widely accepted (e.g. statistical approaches, popPK, PK/PD models), it is expected that the model evaluation tools will evolve in number and in performance with the increase of the use of these types of models.

Therefore, a need exists for documenting the available tools , the manners they are being used, the conditions for their adequate use and the challenges encountered. This white paper is one step in that direction, outlining a framework, similar to that of the ASME V&V40 for medical devices, emphasizing the need for transparency in the data sources and methods used, the clear link with the scientific question and the context of use, as well as the proposed acceptability of criteria. In addition, this white paper contains a glossary of key terms used in the context of in silico model development and evaluation. Given the sometimes‐conflicting terminologies that exist in this domain, such a glossary should be included in all communication to facilitate the communication and avoid misunderstanding during scientific review of regulatory submissions or research papers.

The current hurdles for larger acceptability of in silico models as a reliable source of evidence for high (regulatory) impact applications in drug development include:

There is currently an unmet need for regulatory guidance/best practice documents clearly describing standards for mechanistic in silico model development, evaluation and reporting considering the specificities not only in their structure, the data sources for their construction and evaluation but also in the software and algorithms used for their implementation. Ideally, this should take the format of an ICH guideline to ensure involvement of all relevant stakeholders and wider acceptability by regulators, drug developers and the scientific community. Lack of general framework of reference inevitably results in fragmentation of initiatives, development of conflicting terminologies, and difficult communication. A general framework on the other hand would ensure coordination of initiatives, harmonization of terminology and efficient communication among different stakeholders. Such a general framework for computer modelling and simulation is highly needed. Stakeholders such as the EMA, the VPH institute and the Avicenna Alliance already initiated the dialog and brainstorming on best practices for computer modelling and simulation, as illustrated in this white paper.

Besides this, the VPH institute and Avicenna Alliance are also leading an initiative focusing on Good Simulation Practice (GSP), in analogy with the Good Laboratory Practice (GLP), Good Clinical Practice (GCP) and Good Manufacturing Practice (GMP) guidelines. GSP will indeed provide a quality framework for recognition of compliance monitoring procedures. Compliance with GSP will ensure that validated models and digital data generated by in silico methods will be of high quality, valid and reliable.

## Section: EXAMPLES WORKED OUT ACCORDING TO THE CREDIBILITY MATRIX

In this section, we provide three use cases of models following the above‐described verification and validation strategy. These are models that have not yet received formal regulatory approval but the developers are in various stages of interaction with regulatory bodies. After a brief summary of the model, a credibility matrix is used to provide key information on the different steps of the flowchart show in Figure 1.

EXAMPLE 1: Universal system simulator.

The Universal Immune System Simulator (UISS) is an agent‐based model of the human immune system that accounts for both innate and acquired immune response. In the past, UISS has been successfully applied to a large number of immune system disease modelling scenarios. 69 , 70 , 71 , 72 , 73 , 74 In preliminary studies, 75 , 76 , 77 , 78 it has been shown that the resulting simulator (UISS‐TB) could be used to simulate the relevant individual human physiology and physiopathology in patients affected by Mycobacterium tuberculosis (MTB) and to test in silico the efficacy of new vaccines against tuberculosis. (Figure 2) Moreover, UISS shows the capability of simulating the intrinsic immune system behaviour against MTB infection (eliciting or not eliciting the complete clearance of the infection or, eventually, allowing the chronic establishment of MTB reservoir inside the host due to both MTB characteristics and genetic features of the host). The key elements of the framework for UISS agent‐based model as proposed by the developer are summarized below.

Of note, the credibility matrix above was initially proposed by the authors and refined after discussion with regulators. As described, two related questions are to be addressed by the agent‐based model: characterization of the dose‐response relationship for efficacy and dose selection. The COU is presented with a link to the question, the data source and an analysis of clinical consequences if the model is wrong (as part of a risk‐based analysis). Regulatory impact is considered medium, model acceptability criteria are provided a reference as well for the results credibility activities implemented to meet the pre‐specified criteria.

EXAMPLE 2: Virtual Assay for Drug Cardiac Testing.

Virtual Assay is a software for running human in silico drug trials to augment drug cardiac testing. 79 The core engine provides a user‐friendly graphical user interface (GUI) to efficient algorithms for the sampling and solution of populations of virtual human cardiac cell models (Figure 3). Each model in the population is characterized by a different set of ion channel parameters, with biology described in the form of systems of ordinary differential equations, producing non‐identical action potential outputs to account for variability. The Drug Module directly converts the drug action parameters for their use by the Core Engine in each of the models of the population. The Analysis Module finally generates visual reports of the conducted drug‐dose response studies, per individual model and provides statistics of biomarkers of drug action across the entire population, including the automatic detection of adverse drug effects. The key elements of the framework Virtual Assay model for drug cardiac safety testing as proposed by the developer are summarized below.

The credibility matrix above was also proposed by the authors and discussed with regulators. One question is addressed by the model and associated simulations for each tested drug: characterization of risk of developing Torsade de Pointes. The COU is presented is presented in relation to its role in the overall decision making and analysis of clinical consequences if the model is wrong (as part of a risk‐based analysis). Regulatory impact is considered high, model acceptability criteria are provided as well as a reference for the results credibility activities implemented to meet the pre‐specified criteria.

EXAMPLE 3: Myocardial physiology.

A QSP type disease model and a Virtual Population are used to evaluate the ranges of clinical benefit through C1 modulation, and refine the target population based on response variability analysis in a Virtual Population of ST Elevation Myocardial Infarction (STEMI) treated with percutaneous coronary intervention (PCI) (Figure 4). It is hypothesized that blocking ROS production at the level of the complex 1 (C1), the beginning of the respiratory chain, will reduce damage of the overwhelming ROS production during the reperfusion and bring a relevant clinical benefit. Key features of the model as per the framework are presented below.

Based on the provided information in the credibility matrix by the Sponsor above, the question of interest for the Myocardial physiology model consists in the characterization of the target population to demonstrate the effect of C1 modulation. The COU in link to the scientific question is related to the optimization of the confirmatory trial design. The mechanistic model and related simulator were developed using data from the scientific literature, preclinical in vitro experiments and in vivo experiments. Individual patient data from a subset of a clinical trial dataset were used for a quantitative calibration of the clinical outcomes calculated by the model combined with a Virtual Population. Regulatory impact is considered medium, Model acceptability criteria are provided as well as the credibility activities implemented to meet the pre‐specified criteria. Risk‐based analysis and final model informed decision are also provided.

UISS‐TB predicts the dynamic of the tuberculosis course with a specific vaccine administered, suggesting possible interactions to maximize the chance of success in a personalized fashion

schematic overview of the Virtual Assay software platform at its main components: the Core Engine (middle), Drug Module (left) and Analysis Module (right). X: ion channel availability; h: hill coefficient; D: doses; IC50: half‐maximal inhibitory concentration; M.P.: Membrane Potential; CTRL: Control (no drug)

Disease Computational Model structure. Light blue rectangles represent the submodels with the associated number of parameters, variables and reactions. Dark blue rectangles represent the major connector variables shared between submodels. Myocardium submodels are duplicated throughout 10 zones to introduce a spatial discretization of the myocardium

## Section: CONFLICT OF INTEREST

The authors declared no competing interests for this work.

## Section: Text

Musuamba FT, Skottheim Rusten I, Lesage R, et al. Scientific and regulatory evaluation of mechanistic in silico drug and disease models in drug development: Building model credibility. CPT Pharmacometrics Syst Pharmacol. 2021;10:804–825. 10.1002/psp4.12669
